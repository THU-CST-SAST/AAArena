"""SnakeGo process placement and terminal score interpretation."""

from __future__ import annotations

import json
import math
import subprocess
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]


class SnakeGoMatchError(RuntimeError):
    """The SnakeGo terminal payload is malformed."""


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or not self.role:
            raise ValueError("match role must be a non-empty string")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise ValueError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.rounds is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or not self.error:
                raise ValueError("incomplete match requires an error and no outcome")
        else:
            raise ValueError(f"unknown match status: {self.status}")


def run_native_match(
    *,
    game: ProcessSpec,
    candidate_process: ProcessSpec,
    opponent_process: ProcessSpec,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    candidate_player = 0 if case.role == "P0" else 1
    players = (
        (candidate_process, opponent_process)
        if candidate_player == 0
        else (opponent_process, candidate_process)
    )
    judged = run_stdio_match(
        backend=game,
        players=players,
        config={"random_seed": case.seed},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    return _result_from_end(
        case,
        dict(judged.end_message),
        replay_path,
        events_path,
        tuple(judged.process_returncodes[:3]),
    )


def _result_from_end(
    case: MatchCase,
    end_info: dict[str, Any],
    replay_path: Path,
    events_path: Path,
    returncodes: tuple[int, int, int],
) -> MatchResult:
    raw_scores = end_info.get("end_info")
    if isinstance(raw_scores, str):
        try:
            raw_scores = json.loads(raw_scores)
        except json.JSONDecodeError as exc:
            raise SnakeGoMatchError("terminal end_info is not valid JSON") from exc
    if not isinstance(raw_scores, dict):
        raise SnakeGoMatchError("terminal end_info missing scores")
    try:
        score0 = float(raw_scores["0"])
        score1 = float(raw_scores["1"])
    except (KeyError, TypeError, ValueError) as exc:
        raise SnakeGoMatchError("terminal scores are malformed") from exc
    if not all(math.isfinite(score) for score in (score0, score1)):
        raise SnakeGoMatchError("terminal scores must be finite")
    from .replay import load_replay

    terminal = load_replay(replay_path).get("end_info", {})
    player_error = isinstance(terminal, dict) and terminal.get("type") == "PLAYER_ERROR"
    # A player forfeit is an adjudicated result. Preserve its scores and replay
    # rather than throwing away the winner and fabricating a draw downstream.
    winner_player = 0 if score0 >= score1 else 1
    candidate_player = 0 if case.role == "P0" else 1
    won = winner_player == candidate_player
    return MatchResult(
        case=case,
        status="complete",
        result="win" if won else "loss",
        rounds=_count_replay_rounds(replay_path),
        payload={"terminal_scores": (score0, score1), "winner_player": winner_player,
                 "player_error": player_error,
                 "error_detail": terminal.get("err") if player_error else None},
        replay_path=replay_path,
        events_path=events_path,
        process_returncodes=returncodes,
    )


def _count_replay_rounds(replay_path: Path) -> int:
    try:
        from .replay import load_replay

        document = load_replay(replay_path)
        rounds = document.get("round_info")
        if isinstance(rounds, list):
            return len(rounds)
    except Exception:  # noqa: BLE001 - rounds are best-effort
        pass
    return 0


class SnakeGoArena:
    def __init__(
        self,
        *,
        game: ProcessSpec,
        opponents: Mapping[str, ProcessSpec],
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
    ) -> None:
        self.game = game
        self.opponents = dict(opponents)
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)

    def run_case(self, case: MatchCase, candidate_process: ProcessSpec) -> MatchResult:
        try:
            opponent = self.opponents[case.opponent_id]
        except KeyError as exc:
            raise ValueError(f"unknown or unrunnable opponent: {case.opponent_id}") from exc
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role.lower()
            / f"seed-{case.seed}"
        )
        try:
            return run_native_match(
                game=self.game,
                candidate_process=candidate_process,
                opponent_process=opponent,
                case=case,
                replay_path=root / "replay.json",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            SnakeGoMatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                rounds=None,
                error=str(exc),
            )

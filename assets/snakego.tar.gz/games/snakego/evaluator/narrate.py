"""SnakeGo 回放 → 自然语言。

SnakeGo（第 26 届）的回放不是"每回合一条"，而是**一个大字典**：
``game_config`` / ``item_list``（全局道具投放表）/ ``round_info``（每回合的道具变化）/
``operations``（逐次操作，长度 = 决策次数，不是回合数）/ ``end_info``。

这个结构决定了叙述的组织方式：``operations`` 才是时间轴，而 ``round_info`` 与
``item_list`` 是叠加在时间轴上的环境事件。把两者对齐讲出来，读者才能看懂
"为什么这条蛇在第 N 步突然分裂了"（因为它刚吃到了某个道具）。

本游戏的胜负是**比分制**（吃豆 + 击杀），不是清盘制，所以叙述必须给出比分的
**增长过程**，而不只是终局比分 —— 中途一次大的比分跳变往往对应一次成功的射线击杀。
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, render_events

_ROLES = ("P0", "P1")

#: 操作码 → 人话（与 `decision_space.yaml` 的 atomic_actions 一致）。
_OPS = {1: "向下移动", 2: "向右移动", 3: "向上移动", 4: "向左移动", 5: "发射融化射线", 6: "分裂"}

#: 道具类型（`item_list[].type`）。
_ITEMS = {0: "增长豆", 1: "陷阱", 2: "射线弹药"}


def _load(path: Path) -> Mapping[str, object]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, Mapping):
        # ValueError 而非 TypeError：这是"回放文件内容不对"（数据问题），
        # 不是"调用方传错了类型"（编程问题）。narrate() 会把它降级成一段说明。
        raise ValueError("snakego 回放应当是单个 JSON 对象")  # noqa: TRY004
    return document


def _snake_owner(snake_id: object) -> str:
    """蛇 id 的阵营归属：偶数属 P0、奇数属 P1（后端按阵营交替分配）。"""

    if isinstance(snake_id, int):
        return f"P{snake_id % 2}"
    return "?"


def _iter_rounds(rounds: Sequence[object]) -> list[list[Mapping[str, object]]]:
    """把 ``operations`` 规整成"每回合一批操作记录"。

    ⚠️ 这里踩过一次：``operations`` 的元素是**列表**（该回合内所有蛇的操作），
    不是单条操作记录。按 dict 去读会一条都读不到，叙述里出现"0 次决策"而不报错 ——
    典型的静默失败，所以规整这一步单独成函数并做类型收窄。
    """

    batches: list[list[Mapping[str, object]]] = []
    for entry in rounds:
        if isinstance(entry, Mapping):
            batches.append([entry])
        elif isinstance(entry, list):
            batches.append([item for item in entry if isinstance(item, Mapping)])
        else:
            batches.append([])
    return batches


def _verdict(document: Mapping[str, object], context: NarrationContext) -> tuple[list[str], str | None, int]:
    end = document.get("end_info")
    end = end if isinstance(end, Mapping) else {}
    raw_winner = end.get("winner")
    winner = f"P{raw_winner}" if raw_winner in {0, 1} else None
    winner = context.official_winner or winner
    config = document.get("game_config")
    config = config if isinstance(config, Mapping) else {}
    operations = document.get("operations")
    op_count = len(operations) if isinstance(operations, list) else 0
    round_info = document.get("round_info")
    rounds = context.official_rounds or (len(round_info) if isinstance(round_info, list) else 0)

    lines: list[str] = []
    if winner is None:
        lines.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        lines.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        lines.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        lines.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    lines.append(f"- 终止类型：{end.get('type', '未知')}；错误信息：{end.get('err') or '无'}。")
    score = end.get("score")
    if isinstance(score, list) and len(score) == 2:
        labels = [context.label(role) for role in _ROLES]
        lines.append(f"- 终局比分：{labels[0]}={score[0]} / {labels[1]}={score[1]}。")
    lines.append(
        f"- 棋盘 {config.get('length')}×{config.get('width')}，"
        f"回合上限 {config.get('max_round')}，实际打了 {rounds} 回合、"
        f"共 {op_count} 次决策。"
    )
    if context.diagnostic:
        lines.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")
    return lines, winner, rounds


def _item_landscape(document: Mapping[str, object]) -> list[str]:
    """道具投放的统计 —— 这是环境的先验，策略应当围绕它安排路线。"""

    items = document.get("item_list")
    if not isinstance(items, list) or not items:
        return ["- 本局没有道具投放记录。"]
    tally: dict[str, int] = {}
    earliest: dict[str, int] = {}
    for item in items:
        if not isinstance(item, Mapping):
            continue
        name = _ITEMS.get(item.get("type"), f"类型{item.get('type')}")  # type: ignore[arg-type]
        tally[name] = tally.get(name, 0) + 1
        time = item.get("time")
        if isinstance(time, int) and (name not in earliest or time < earliest[name]):
            earliest[name] = time
    lines = [
        f"- 全局共投放 {len(items)} 个道具："
        + "、".join(f"{name} {count} 个" for name, count in sorted(tally.items()))
        + "。"
    ]
    for name, time in sorted(earliest.items()):
        lines.append(f"- 最早出现的{name}在第 {time} 回合。")
    lines.append("- 道具记录包含 time 与坐标字段。")
    return lines


def _score_progress(document: Mapping[str, object], context: NarrationContext) -> list[str]:
    """胜负的**因果链**：击杀、吃豆、分裂。

    ⚠️ 回放里**没有逐步比分**（``score`` 只出现在 ``end_info``），所以不能像别的游戏
    那样报"比分跳变"。这里改报造成比分的三类事件本身：``dead_snake``（击杀，最大宗
    得分来源）、``got_item``（吃到道具）、``new_snake_id``（分裂，改变后续吞吐）。
    这比一条比分曲线更有用：它直接告诉你**是哪一步换来的分**。
    """

    rounds = document.get("operations")
    if not isinstance(rounds, list):
        return []
    kills: list[str] = []
    splits: dict[str, int] = {}
    items: dict[str, int] = {}
    growth: dict[str, int] = {}
    for round_index, batch in enumerate(_iter_rounds(rounds)):
        for record in batch:
            basic = record.get("basic")
            if not isinstance(basic, Mapping):
                continue
            owner = _snake_owner(basic.get("snake"))
            dead = record.get("dead_snake")
            if isinstance(dead, list) and dead:
                kills.append(
                    f"- 第 {round_index} 回合：{context.label(owner)} 的操作记录死亡蛇 {dead}"
                )
            if isinstance(record.get("new_snake_id"), int) and record["new_snake_id"] >= 0:
                splits[owner] = splits.get(owner, 0) + 1
            if isinstance(record.get("got_item"), int) and record["got_item"] >= 0:
                items[owner] = items.get(owner, 0) + 1
            extra = record.get("extra_length")
            if isinstance(extra, int) and extra > 0:
                growth[owner] = growth.get(owner, 0) + extra
    lines: list[str] = []
    for role in _ROLES:
        lines.append(
            f"- {context.label(role)} 全局吃到 {items.get(role, 0)} 个道具；"
            f"{role} 长度 +{growth.get(role, 0)}；分裂 {splits.get(role, 0)} 次。"
        )
    if kills:
        lines.append(f"- 全局共发生 {len(kills)} 次致死事件，逐条如下：")
        lines.extend(kills[:40])
        if len(kills) > 40:
            lines.append(f"- （其余 {len(kills) - 40} 次致死事件见完整时间线）")
    else:
        lines.append("- 全局没有记录蛇死亡。")
    return lines


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    document = _load(replay_path)
    verdict, winner, rounds = _verdict(document, context)

    events: list[Event] = []
    operations = document.get("operations")
    if isinstance(operations, list):
        for round_index, batch in enumerate(_iter_rounds(operations)):
            for record in batch:
                basic = record.get("basic")
                if not isinstance(basic, Mapping):
                    continue
                snake = basic.get("snake")
                op_name = _OPS.get(basic.get("type"), f"操作码{basic.get('type')}")  # type: ignore[arg-type]
                actor = context.label(_snake_owner(snake))
                detail = f"蛇#{snake} {op_name}"
                notable = False
                got = record.get("got_item")
                if isinstance(got, int) and got >= 0:
                    detail += f"，吃到道具 id={got}"
                    notable = True
                extra = record.get("extra_length")
                if isinstance(extra, int) and extra > 0:
                    detail += f"，增长 {extra} 节"
                    notable = True
                spawned = record.get("new_snake_id")
                if isinstance(spawned, int) and spawned >= 0:
                    detail += f"，分裂出蛇#{spawned}"
                    notable = True
                dead = record.get("dead_snake")
                if isinstance(dead, list) and dead:
                    detail += f"，本步死亡蛇 {dead}"
                    notable = True
                events.append(
                    Event(
                        round=round_index,
                        actor=actor,
                        text=detail,
                        ref=f"r{round_index:04d}:s{snake}",
                        # 纯移动最容易连成一片；吃豆/分裂/死亡这些关键步骤永不折叠。
                        # 折叠键**故意不含方向**：一条蛇连续 40 步走位是一个"行进段"，
                        # 按方向分桶会让每次转向都打断折叠，等于折不动
                        # （实测 3092 条事件按方向分桶只能压到 3090 行）。
                        fold_key=(
                            f"move-{snake}"
                            if basic.get("type") in (1, 2, 3, 4) and not notable
                            else ""
                        ),
                        fold_label="纯移动（未吃豆/未分裂/无死亡）",
                    )
                )

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"SnakeGo 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"共 {rounds} 回合 / {len(events)} 次决策。"
            "由 A 仓 `aa_arena.replay` 从官方回放翻译。"
            "终局比分与逐次操作均按公开字段陈述。"
        ),
    )
    doc.section("终局事实", verdict)
    doc.section(
        "状态变化与数值增量",
        _item_landscape(document) + _score_progress(document, context),
    )
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=240)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=240。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="snakego",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights={"decisions": len(events)},
    )

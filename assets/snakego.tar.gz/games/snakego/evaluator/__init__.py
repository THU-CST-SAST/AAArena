"""SnakeGo 对战器 —— 满足 `aa_arena.core.Evaluator` 协议的可运行实现。

SnakeGo 的游戏语义（定位官方 Python 后端、按 Saiblo stdio 协议跑对局、解码回放、
裁决胜负）是仓库 A 的资产。本包对外暴露 `SnakeGoEvaluator`，其
`evaluate(players, roles, seed) -> EvaluateResult` 严格遵循
`docs/evaluator-contract.md`：

- 定位官方 **Python** 后端源码（`games/snakego/backend/.../gamecode_logic`），
  无需编译，直接以 `python main.py` 启动，可复现于全新 checkout；
- 用官方长度前缀 stdio 判题协议驱动后端与两名 Python 或 Make/CMake 原生选手完成一局；
- 解析回放，返回可解析、可复现的 `EvaluateResult`；
- 严格三态：后端进程/环境故障 = `infra_error`；选手超时/非法/崩溃 = `game_error`；
  正常终局 = `complete`。

B (HL) / C (RL) 通过 A 的统一入口 `evaluate("snakego", ...)` 复用本实现。
"""

from __future__ import annotations

import sys
from pathlib import Path

from aa_arena.core.buildcache import backend_run_dir
from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    MatchCase,
    MatchResult,
    ProcessSpec,
    SnakeGoArena,
    SnakeGoMatchError,
    run_native_match,
)
from .replay import SnakeGoReplayError, load_replay, summarize
from .runtime import (
    Opponent,
    PreparedPlayer,
    SnakeGoLayout,
    SnakeGoRuntimeError,
    audit_human_pool,
    prepare_package,
    prepare_player,
    resolve_opponent,
    tree_sha256,
)

__all__ = [
    "MatchCase",
    "MatchResult",
    "Opponent",
    "ProcessSpec",
    "SnakeGoArena",
    "SnakeGoEvaluator",
    "SnakeGoLayout",
    "SnakeGoMatchError",
    "SnakeGoReplayError",
    "SnakeGoRuntimeError",
    "audit_human_pool",
    "load_replay",
    "make_evaluator",
    "resolve_opponent",
    "run_native_match",
    "summarize",
    "tree_sha256",
]


def _resolve_player(
    player: PlayerRef, *, pool: tuple[Opponent, ...], build_root: Path
) -> PreparedPlayer:
    """把 PlayerRef 解析并准备为 Python 或 native 选手进程。"""

    if player.code_path is not None:
        root = Path(player.code_path).resolve()
        return prepare_package(player.player_id, root, build_root=build_root)
    opponent = resolve_opponent(pool, player.player_id)
    if opponent is None:
        raise SnakeGoMatchError(
            f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
        )
    prepared = prepare_player(opponent, build_root=build_root)
    return PreparedPlayer(player.player_id, prepared.argv, prepared.cwd)


class SnakeGoEvaluator:
    """SnakeGo 的对战器：给定两名选手、角色 (P0/P1) 与种子，跑一局并返回契约结果。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        # games/<game>/ 上两级是 A 仓库根（后端源码 + 人类池所在）。
        self.aa_arena_root = self.game_dir.parents[1]
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "snakego-matches"
        )
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "snakego-build"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"snakego requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"snakego roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = SnakeGoLayout.from_root(self.aa_arena_root)
        try:
            layout.validate()
            pool = audit_human_pool(layout)
        except (SnakeGoRuntimeError, FileNotFoundError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        try:
            prepared = [
                _resolve_player(player, pool=pool, build_root=self._build_root)
                for player in players
            ]
        except (SnakeGoMatchError, SnakeGoRuntimeError, PlayerEnvironmentError) as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))

        candidate_role = roles[0]
        candidate_id = players[0].player_id
        opponent_id = players[1].player_id

        case = MatchCase(candidate_id, opponent_id, candidate_role, seed)
        # 后端必须在**可写、每局独占**的目录里跑，不能直接用 A 仓源码树
        # （详见 aa_arena.core.buildcache.backend_run_dir）。snakego 同样没有
        # build_root，靠 backend_run_dir 的降级链兜住 artifact_root 不可写的情况。
        try:
            with backend_run_dir(
                layout.backend_source_root, parent=self._artifact_root, tag="snakego-backend"
            ) as backend_cwd:
                arena = SnakeGoArena(
                    game=ProcessSpec((sys.executable, "main.py"), backend_cwd),
                    opponents={
                        opponent_id: ProcessSpec(prepared[1].argv, prepared[1].cwd)
                    },
                    artifact_root=self._artifact_root,
                    timeout_s=self.timeout_s,
                )
                result = arena.run_case(
                    case, ProcessSpec(prepared[0].argv, prepared[0].cwd)
                )
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend run dir preparation failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        return self._to_evaluate_result(result, candidate_role)

    def _to_evaluate_result(self, result: MatchResult, candidate_role: str) -> EvaluateResult:
        scores_tuple = result.payload.get("terminal_scores")
        if not (isinstance(scores_tuple, tuple) and len(scores_tuple) == 2):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing terminal_scores payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        # terminal_scores 是绝对 (P0, P1) 顺序。
        scores = {"P0": float(scores_tuple[0]), "P1": float(scores_tuple[1])}
        winner_player = int(result.payload.get("winner_player", 0))
        winner = "P0" if winner_player == 0 else "P1"
        return EvaluateResult(
            status=EvaluationStatus.GAME_ERROR if result.payload.get("player_error") else EvaluationStatus.COMPLETE,
            diagnostic=(f"official player forfeit: {result.payload.get('error_detail')}"
                if result.payload.get("player_error") else None),
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
        )


def make_evaluator(game_dir: Path) -> SnakeGoEvaluator:
    """插件工厂：供 `games/snakego/plugin.py` 装配对战器。"""

    return SnakeGoEvaluator(game_dir)

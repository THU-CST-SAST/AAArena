"""Frozen SnakeGo backend location and human-pool audit.

SnakeGo 的对战器内核（游戏资产），属仓库 A。SnakeGo 官方后端是 **Python**
（`games/snakego/backend/logic/gamecode_logic/`），无需编译，直接以
`python main.py`（cwd 指向后端源码目录）启动即可。本模块负责：

- 定位官方 Python 后端源码目录（可复现于全新 checkout）；
- 审计冻结的人类天梯选手池（`games/snakego/players/pool/`）。

本模块复用 A core 的原子构建缓存与入口发现原语，可被 A 的 evaluator 直接调用，
也可被 B/C 通过 A 复用。
"""

from __future__ import annotations

import csv
import hashlib
import os
import sys
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    CppBuildError,
    build_cpp_player,
    has_cpp_build,
    native_build_root,
)
from aa_arena.core.player_environment import player_command
from aa_arena.core.player_entry import find_build_dir, find_python_entry


class SnakeGoRuntimeError(RuntimeError):
    """A frozen runtime resource failed an integrity requirement."""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make", "cmake")
_GAME_DIR = Path(__file__).resolve().parents[1]


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise SnakeGoRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class SnakeGoLayout:
    """SnakeGo 后端与人类池在仓库内的物理布局。"""

    aa_arena_root: Path
    backend_source_root: Path
    backend_main: Path
    human_manifest: Path
    human_extracted_root: Path

    @classmethod
    def from_root(cls, aa_arena_root: str | Path) -> "SnakeGoLayout":
        aa_arena = Path(aa_arena_root).resolve()
        players = aa_arena / "games/snakego/players"
        pool = players / "pool"
        backend = aa_arena / "games/snakego/backend/logic/gamecode_logic"
        return cls(
            aa_arena_root=aa_arena,
            backend_source_root=backend,
            backend_main=backend / "main.py",
            human_manifest=players / "manifest.tsv",
            human_extracted_root=pool,
        )

    def backend_fingerprint(self) -> str:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        return tree_sha256(self.backend_source_root)

    def validate(self) -> None:
        if not self.backend_main.is_file():
            raise FileNotFoundError(self.backend_main)
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_extracted_root.is_dir():
            raise FileNotFoundError(self.human_extracted_root)


@dataclass(frozen=True)
class Opponent:
    """人类池中一个可解析的选手（rank 锚点）。"""

    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    package_root: Path
    entry_root: Path
    archive_sha256: str
    runnable: bool
    lang: str | None
    exclusion_diagnostic: str | None


@dataclass(frozen=True)
class PreparedPlayer:
    player_id: str
    argv: tuple[str, ...]
    cwd: Path


def _find_python_entry(package_root: Path) -> Path | None:
    """在选手目录里定位可运行的 Python 入口（含 `main.py`）。

    统一池的 Python 选手可能把代码放在子目录（如 `main/main.py`），也可能直接在
    根目录。取深度最浅、路径字典序最小的 `main.py` 作为入口，其所在目录即 cwd。
    """

    return find_python_entry(package_root)


def _native_executable(root: Path) -> Path | None:
    candidates = [
        path
        for path in root.rglob("*")
        if path.is_file() and os.access(path, os.X_OK)
        and "CMakeFiles" not in path.relative_to(root).parts
        and path.suffix.lower() not in {".a", ".cmake", ".dll", ".dylib", ".o", ".so"}
    ]
    if not candidates:
        return None
    return min(
        candidates,
        key=lambda path: (
            path.name not in {"main", "main.exe"},
            len(path.relative_to(root).parts),
            path.as_posix(),
        ),
    )


def prepare_package(
    player_id: str,
    package_root: Path,
    *,
    build_root: Path,
    language: str | None = None,
) -> PreparedPlayer:
    """Prepare either a recursive Python entry or a Make/CMake native submission."""

    package = Path(package_root).resolve()
    python_entry = find_python_entry(package)
    build_dir = find_build_dir(package)
    native_requested = (language or "").strip().lower() in {"make", "cmake", "cpp", "c++"}
    if python_entry is not None and not native_requested:
        return PreparedPlayer(player_id, player_command(), python_entry)
    if not has_cpp_build(package):
        raise SnakeGoRuntimeError(
            f"player {player_id} has no runnable entry (main.py / Makefile / CMakeLists.txt)"
        )

    relative_build = (
        build_dir.relative_to(package) if build_dir is not None else Path(".")
    )
    try:
        executable = build_cpp_player(
            player_dir=package,
            game_dir=_GAME_DIR,
            cache_root=Path(build_root) / "players",
        )
    except CppBuildError as exc:
        raise SnakeGoRuntimeError(
            f"native player {player_id} build_error: {exc}"
        ) from exc
    cwd = native_build_root(executable) / relative_build
    return PreparedPlayer(player_id, (str(executable),), cwd)


def prepare_player(opponent: Opponent, *, build_root: Path) -> PreparedPlayer:
    """Prepare a manifest-backed opponent using the same package resolver."""

    return prepare_package(
        opponent.opponent_id,
        opponent.package_root,
        build_root=build_root,
        language=opponent.lang,
    )


def audit_human_pool(layout: SnakeGoLayout) -> tuple[Opponent, ...]:
    """从 `players/manifest.tsv` 读取带 rank 的选手，解析为可运行对手。

    manifest 的 rank 可能不连续（同名用户多个 entity 共享 rank）；这里按
    (rank, player_id) 稳定排序保留全部带 rank 的选手，供 evaluator 按 `rankNN`
    解析第一个匹配的可运行选手。
    """

    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            rel_dir = (row.get("dir") or "").strip()
            if rel_dir:
                package = (layout.human_manifest.parent / rel_dir).resolve()
            else:
                package = (layout.human_extracted_root / str(row.get("player_id"))).resolve()
            if not package.is_dir():
                continue
            entry_root = _find_python_entry(package)
            runnable = entry_root is not None or has_cpp_build(package)
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=(row.get("username") or None),
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    package_root=package,
                    entry_root=entry_root if entry_root is not None else package,
                    archive_sha256=tree_sha256(package),
                    runnable=runnable,
                    lang=(row.get("lang") or None),
                    exclusion_diagnostic=(
                        None
                        if runnable
                        else "no runnable entry (main.py / Makefile / CMakeLists.txt)"
                    ),
                )
            )
    pool.sort(key=lambda item: (item.rank, item.opponent_id, item.package_root.name))
    return tuple(pool)


def resolve_opponent(pool: tuple[Opponent, ...], player_id: str) -> Opponent | None:
    """把 `rankNN` 或具体 player_id 解析为池中第一个可运行选手。"""

    # 精确 player_id 命中（目录名）。
    for opponent in pool:
        if opponent.package_root.name == player_id and opponent.runnable:
            return opponent
    # rank 别名命中（取该 rank 下第一个可运行选手）。
    for opponent in pool:
        if opponent.opponent_id == player_id and opponent.runnable:
            return opponent
    return None


if sys.version_info < (3, 9):  # pragma: no cover - defensive version guard
    raise RuntimeError("SnakeGo evaluator requires Python 3.9+")

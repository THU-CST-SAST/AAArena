"""SnakeGo 官方回放解码（游戏资产），属仓库 A。

SnakeGo 后端在终局时调用 ``History.dump`` 写出回放文件（``logic/formatter.py``
的 ``format_to`` 生成的 JSON 文本）。文档结构：

    {
      "game_config": { "length", "width", "max_round", "random_seed", ... },
      "item_list":   [ { "x", "y", "time", "type", "param" }, ... ],
      "round_info":  [ { gotten_item, expired_item, extra_length }, ... ],
      "operations":  [ { "type", "snake", "direction", "item_id" }, ... ],
      "end_info":    { "0": score0, "1": score1 }
    }

``round_info`` 的长度即对局进行的游戏回合数；``operations`` 为逐操作序列；
``end_info`` 为两名玩家的绝对终局得分。本模块把该文本安全解析为 Python 字典，
并抽取评测所需摘要（不依赖任何框架层）。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class SnakeGoReplayError(RuntimeError):
    """回放文件缺失或无法解析为预期结构。"""


def load_replay(path: Path) -> dict[str, Any]:
    replay_path = Path(path)
    if not replay_path.is_file():
        raise SnakeGoReplayError(f"replay file not found: {replay_path}")
    text = replay_path.read_text(encoding="utf-8", errors="strict")
    try:
        document = json.loads(text)
    except json.JSONDecodeError as exc:
        raise SnakeGoReplayError(f"replay is not valid JSON: {exc}") from exc
    if not isinstance(document, dict):
        raise SnakeGoReplayError("replay root is not an object")
    return document


def terminal_scores(document: dict[str, Any]) -> tuple[float, float]:
    """从回放 ``end_info`` 取双方绝对终局得分。

    后端 ``History.dump`` 把 ``end_info`` 写为 ``Result`` 对象展开的 dict：
    ``{"type": "NORMAL"|..., "winner": int, "score": [s0, s1], "err": null}``。
    （注意这与**终局控制消息**里的 ``end_info`` 字符串 ``{"0":s0,"1":s1}`` 不同——
    后者由 arena 直接解析裁决，此处解析的是回放文件。）
    """
    end_info = document.get("end_info")
    if isinstance(end_info, str):
        end_info = json.loads(end_info)
    if not isinstance(end_info, dict):
        raise SnakeGoReplayError("replay end_info is missing or malformed")
    score = end_info.get("score")
    if isinstance(score, list) and len(score) == 2:
        return float(score[0]), float(score[1])
    if "0" in end_info and "1" in end_info:  # 兼容控制消息形态
        return float(end_info["0"]), float(end_info["1"])
    raise SnakeGoReplayError("replay end_info has no recoverable scores")


def round_count(document: dict[str, Any]) -> int:
    rounds = document.get("round_info")
    return len(rounds) if isinstance(rounds, list) else 0


def summarize(path: Path) -> dict[str, Any]:
    document = load_replay(path)
    score0, score1 = terminal_scores(document)
    return {
        "rounds": round_count(document),
        "operations": len(document.get("operations", []) or []),
        "items": len(document.get("item_list", []) or []),
        "terminal_scores": (score0, score1),
        "winner_player": 0 if score0 >= score1 else 1,
        "game_config": document.get("game_config", {}),
    }

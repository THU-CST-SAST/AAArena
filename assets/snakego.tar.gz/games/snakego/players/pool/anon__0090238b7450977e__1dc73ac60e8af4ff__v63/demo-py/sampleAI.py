from calendar import c

from sys import stderr


from adk import *

# written by lbr

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
INF = 1e9
# constants

SPLIT_LIMIT = 10
SEARCH_LIMIT = 100
ACT_MELT = 5
ACT_SPLIT = 6
MAP_SIZE = 16
def DirOptToAction(x):
    return x + 1
def ActionToDirOpt(x):
    return x - 1
myCamp = -1

# tunable parameters

def Map22List(mp:Map): # mp is a 2D-List like DS.
    wm = []
    sm = []
    for i in range(MAP_SIZE):
        wm.append([])
        sm.append([])
        for j in range(MAP_SIZE):
            wm[len(wm)-1].append(mp.wall_map[i][j])
            sm[len(sm)-1].append(mp.snake_map[i][j])
    return wm, sm
def PosInMap(x, y):
    return x >= 0 and y >= 0 and x < MAP_SIZE and y < MAP_SIZE
def ExtendWM(mp):
    ret = CopyMap(mp)
    for i in range(MAP_SIZE):
        for j in range(MAP_SIZE):
            if(mp[i][j] == 2):
                for dr in range(4):
                    ci = i + dx[dr]
                    cj = j + dy[dr]
                    if PosInMap(ci, cj):
                        ret[ci][cj] = 2
    return ret

def CopyMap(mp):
    ret = []
    for i in range(MAP_SIZE):
        ret.append([])
        for j in range(MAP_SIZE):
            ret[len(ret)-1].append(mp[i][j])
    return ret

# wmx format: -1 -> no wall. 0 -> 0's wall. 1 -> 1's wall.
# smx format: -1 -> no snake. ow: id's snake.

def GetSnakeValidDir(snake: Snake, wmx, smx):
    ret = []
    for i in range(4):
        x = snake.coor_list[0][0] + dx[i] # obviously the first axis is id of block of snake and de Qnget zo X hta Y.
        y = snake.coor_list[0][1] + dy[i]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or wmx[x][y] != -1:
            continue
        # check wall and out of bounds
        if snake.get_len() > 1 and x == snake.coor_list[1][0] and y == snake.coor_list[1][1]:
            continue
        # check turn back
        if smx[x][y] != -1:
            continue
        # check other snake
        ret.append(i)
    return ret
def MovedSnake(snake: Snake, dr, smx, bed):
    # for i in range(bed):
    #     stderr.write('-')
    # stderr.write('{} move {}\n'.format(snake.id, dr))
    ret = Snake(snake.coor_list, snake.item_list, snake.camp, snake.id)
    coo = []
    coo.append([snake.coor_list[0][0]+dx[dr], snake.coor_list[0][1]+dy[dr]])
    for i in range(len(snake.coor_list)-1):
        coo.append(snake.coor_list[i])
    if snake.length_bank > 0:
        coo.append(snake.coor_list[len(snake.coor_list)-1])
        ret.length_bank = snake.length_bank - 1
    ret.coor_list = coo
    newsmx = CopyMap(smx)
    newsmx[coo[0][0]][coo[0][1]] = ret.id
    if snake.length_bank == 0:
        newsmx[snake.coor_list[len(snake.coor_list)-1][0]][snake.coor_list[len(snake.coor_list)-1][1]] = -1
    return ret, newsmx
def KilledSnake(snake: Snake, smx):
    nsmx = smx.copy()
    for i in range(len(snake.coor_list)):
        nsmx[snake.coor_list[i][0]][snake.coor_list[i][1]] = -1
    deadone = Snake([], [], snake.camp, snake.id)
    return deadone, nsmx
def ManhattanDist(x1, y1, x2, y2):
    return abs(x1-x2) + abs(y1-y2)
def FindArea(snk: Snake, wmx, smx):
    area = -1
    q = [[snk.coor_list[0][0],snk.coor_list[0][1]]]
    head = 0; tail = 1
    vis = []
    for i in range(MAP_SIZE):
        vis.append([])
        for j in range(MAP_SIZE):
            vis[i].append(0)
    vis[q[0][0]][q[0][1]] = 1
    while head < tail:
        cpos = q[head]
        head += 1
        area += 1
        for i in range(4):
            tx = cpos[0] + dx[i]
            ty = cpos[1] + dy[i]
            if PosInMap(tx, ty) == False:
                continue
            if wmx[tx][ty] != -1 or smx[tx][ty] != -1:   # 还有len=2的情况。但是还有length_back的情况。
                continue
            if vis[tx][ty] == 1:
                continue
            q.append([tx,ty])
            tail += 1
            vis[tx][ty] = 1
    return area
def BFSDistDir(sx, sy, tx, ty, wmx, smx): # my journey stops here...
    dis = []
    for i in range(MAP_SIZE):
        dis.append([])
        for j in range(MAP_SIZE):
            dis[i].append(100000)
    dis[tx][ty] = 0
    q = []
    q.append([tx,ty])
    head = 0
    tail = 1
    while head < tail:
        cpos = q[head]
        head += 1
        for i in range(4):
            xx = cpos[0] + dx[i]
            yy = cpos[1] + dy[i]
            if PosInMap(xx, yy) == False:
                continue
            if wmx[xx][yy] != -1 or (smx[xx][yy] != -1 and (xx != sx or yy != sy)):   # 还有len=2的情况。但是还有length_back的情况。
                continue
            if dis[xx][yy] != 100000:
                continue
            q.append([xx,yy])
            tail += 1
            dis[xx][yy] = dis[cpos[0]][cpos[1]] + 1
    dir = []
    for i in range(4):
        xx = sx + dx[i]
        yy = sy + dy[i]
        if not PosInMap(xx, yy):
            continue
        if dis[xx][yy] == dis[sx][sy] - 1:
            dir.append(i)
    return dis[sx][sy], dir

BED_MAX = 10
def dfs(snks:List[List[Snake]], wmx, smx, ccamp, cid, bed, original_head):  # cid not must be snake.id
    return 0,[]
    # stderr.write("NOW ccamp {} cid {} bed {}".format(ccamp, cid, bed))
    # s = "CAMP0 snakes:"
    # for i in range(len(snks[0])):
    #     s += str(snks[0][i].id)+", "
    # stderr.write(s)
    # s = "CAMP1 snakes:"
    # for i in range(len(snks[1])):
    #     s += str(snks[1][i].id)+", "
    # stderr.write(s)
    scr = 0
    csnk = snks[ccamp][cid]
    if(len(csnk.coor_list) == 0 or 
       (ManhattanDist(csnk.coor_list[0][0], csnk.coor_list[0][1], original_head[0], original_head[1]) >= 10
        and csnk.get_len() <= 4
       )
        ): # already dead or ignore
        if(bed >= BED_MAX):
            return 0, []
        if(cid != len(snks[ccamp])-1):
            ans, _ = dfs(snks, wmx, smx, ccamp, cid+1, bed+1, original_head)
            return ans, []
        else:
            ncamp = 1 - ccamp
            if(len(snks[ncamp]) == 0):
                ncamp = ccamp
            ans, _ = dfs(snks, wmx, smx, ncamp, 0, bed+1, original_head)
            return -ans, []
    valid = GetSnakeValidDir(csnk, wmx, smx)
    if(len(valid) == 0):
        scr -= 100
    if(bed >= BED_MAX):
        return scr, []
    if len(csnk.coor_list) >= 4:
        for i in range(MAP_SIZE):
            for j in range(MAP_SIZE):
                stderr.write('#' if wmx[i][j]!=-1 else '+' if smx[i][j] != -1 else '.')
            stderr.write('\n')
        stderr.write('---\n')
    if(cid != len(snks[ccamp])-1):
        maxscr = -10000000
        final_op = []
        if len(valid) == 0:
            dead, nsmx = KilledSnake(csnk, smx)
            nsnks = snks.copy()
            nsnks[ccamp][cid] = dead
            tscr, _ = dfs(nsnks, wmx, nsmx, ccamp, cid+1, bed+1, original_head)
            return scr+tscr, -1
        else:
            for i in valid:
                nsnk, nsmx = MovedSnake(csnk, i, smx,bed)
                nsnks = snks.copy()
                nsnks[ccamp][cid] = nsnk
                tscr, _ = dfs(nsnks, wmx, nsmx, ccamp, cid+1, bed+1, original_head)
                if(tscr > maxscr):
                    maxscr = tscr
                    final_op = [i]
                elif(tscr == maxscr):
                    final_op.append(i)
        return scr+maxscr, final_op
    else:
        ncamp = 1 - ccamp
        if(len(snks[ncamp]) == 0):
            ncamp = ccamp
        minscr = 10000000
        final_op = []
        if len(valid) == 0:
            dead, nsmx = KilledSnake(csnk, smx)
            nsnks = snks.copy()
            nsnks[ccamp][cid] = dead
            tscr, _ = dfs(nsnks, wmx, nsmx, ncamp, 0, bed+1, original_head)
            return scr+tscr, []
        else:
            for i in valid:
                nsnk, nsmx = MovedSnake(csnk, i, smx,bed)
                nsnks = snks.copy()
                nsnks[ccamp][cid] = nsnk
                tscr, _ = dfs(nsnks, wmx, nsmx, ncamp, 0, bed+1, original_head)
                if(tscr < minscr):
                    minscr = tscr
                    final_op = [i]
                elif(tscr == minscr):
                    final_op.append(i)
        return scr-minscr, final_op

class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()

    def DirOptLegal(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op] # obviously the first axis is id of block of snake and de Qnget zo X hta Y.
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False   # de Jxhd d 0~15.
        # check wall and out of bounds
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False # 
        # check turn back
        if self.ctx.game_map.snake_map[x][y] != -1:
            return False
        # check other snake
        return True

    def DirOptLegalOrSoli(self, op):
        """
        :param op: the direction
        :return: True if this move is legal, could possibly result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
            return False
        return True
    
    def closest_food_strategy_diropt(self):
        """
        Search for the closest food and to go that direction, if legal.

        :return: the chosen direction
        """
        def calc_dist(x1, y1, x2, y2):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return abs(x1 - x2) + abs(y1 - y2), pos

        valid = []
        for i in range(4):
            if self.DirOptLegal(i):
                valid.append(i)
        if len(valid) == 0:
            if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                return 1
                # 此时哪怕送死都必须要1
            # 此时0即可送死。
            return 0
        # calculate the legal moves without concerning the food
        coor = self.snake.coor_list
        
        wmx,smx = Map22List(self.ctx.get_map())
        
        realid = -1
        mysnks = self.ctx.get_player_snake(self.ctx.current_player)
        yoursnks = self.ctx.get_player_snake(1-self.ctx.current_player)
        for i in range(len(mysnks)):
            if mysnks[i].id == self.snake.id:
                realid = i
                break
        # stderr.write('gonna dfs! my id is {} and realid is {}. Two sides\' snakes are as shown\n'.format(self.snake.id, realid))
        # for i in range(len(self.ctx.get_player_snake(0))):
        #     stderr.write(str(self.ctx.get_player_snake(0)[i].id))
        #     stderr.write(' ')
        # stderr.write('\n')
        # for i in range(len(self.ctx.get_player_snake(1))):
        #     stderr.write(str(self.ctx.get_player_snake(1)[i].id))
        #     stderr.write(' ')
        # stderr.write('\n')
        scr, ops = dfs([self.ctx.get_player_snake(0), self.ctx.get_player_snake(1)]
                        , wmx, smx, self.ctx.current_player, realid, 0, [self.snake.coor_list[0][0], self.snake.coor_list[0][1]])
        # stderr.write("dfs's scr is {}\n".format(scr))
            
        # for i in range(MAP_SIZE):
        #     for j in range(MAP_SIZE):
        #         if wm[i][j] == -1:
        #             wm[i][j] = 0
        #         else:
        #             wm[i][j] = 1
        # for i in range(len(self.ctx.snake_list)):
        #     snk = self.ctx.snake_list[i]
        #     wm[snk.coor_list[0][0]][snk.coor_list[0][1]] = 2
        #     for j in range(1, len(snk.coor_list)):
        #         wm[snk.coor_list[j][0]][snk.coor_list[j][1]] = 1
        
        # mps = [wm]
        # max_epoch = 3
        # for i in range(max_epoch): # 暂定扩展查询16回合
        #     wm = ExtendWM(CopyMap(wm))
        #     mps.append(wm)
        # for t in range(max_epoch, -1, -1):
        #     for i in range(MAP_SIZE):
        #         for j in range(MAP_SIZE):
        #             cnt = 0
        #             for k in range(4):
        #                 tx = i + dx[k]
        #                 ty = j + dy[k]
        #                 if PosInMap(tx, ty) == False or mps[t][tx][ty] != 0:
        #                     cnt += 1
        #             if cnt == 3:
        #                 mps[t][i][j] = -1
        #                 if t > 0:
        #                     mps[t-1][i][j] = 3
        # valid2 = []
        # headx = self.snake.coor_list[0][0]
        # heady = self.snake.coor_list[0][1]
        # for i in range(4):
        #     tx = headx + dx[i]
        #     ty = heady + dy[i]
        #     if(PosInMap(tx, ty) and (mps[0][tx][ty] == 0 or mps[0][tx][ty] == 3)):
        #         valid2.append(i)
        # stderr.write('sdfdsf')
        # print('VALID2:')
        # for i in range(len(valid2)):
        #    print('{} '.format(valid2[i]))
        # print('\n')
        
        val = []
        DirIntoDilemma = []
        
        for i in range(len(valid)):
            dr = valid[i]
            nsnk, nsmx = MovedSnake(self.snake, dr, smx, 0)
            area = FindArea(nsnk, wmx, nsmx)
            if area <= (self.snake.get_len()+self.snake.length_bank) * 3+1:
                DirIntoDilemma.append(dr)
                continue
            _continue_i_for = False
            # not only me, but also my friends.
            # it cin gos, dewoa mn ne Gumer.
            for j in range(len(mysnks)):
                if j == realid: 
                    continue
                jarea = FindArea(mysnks[j], wmx, nsmx)
                if jarea <= (mysnks[j].get_len()+mysnks[j].length_bank)*3+1:
                    DirIntoDilemma.append(dr)
                    _continue_i_for = True
                    break
            if _continue_i_for:
                continue
            for j in range(len(yoursnks)):
                if _continue_i_for:
                    break
                jvalid = GetSnakeValidDir(yoursnks[j], wmx, nsmx)
                for k in jvalid: # haha
                    _, nnsmx = MovedSnake(yoursnks[j], k, nsmx, 0)
                    karea = FindArea(nsnk, wmx, nnsmx)
                    if karea <= (self.snake.get_len()+self.snake.length_bank) * 3+1:
                        DirIntoDilemma.append(dr)
                        _continue_i_for = True
                        break
        if scr > 0:
            val = ops
        else:
            
            minTime = INF
            curTurn = self.ctx.turn
            for item in self.ctx.game_map.item_list:
                #if item.type != 0:
                #    continue
                # search food only ? no no no. 2022年3月3日20:30:23

                # the time span is time ~ time+15
                if item.time > self.ctx.turn + SEARCH_LIMIT+100000 or item.time + 15 < self.ctx.turn:
                    continue
                # search valid food only

                #d, pos = calc_dist(item.x, item.y, coor[0][0], coor[0][1])
                d,pos = BFSDistDir(coor[0][0], coor[0][1], item.x, item.y, wmx, smx)
                if curTurn+d > item.time+15:
                    continue
                kaoTi = d
                if curTurn+d < item.time:
                    kaoTi = item.time - curTurn
                
                pos = [i   for i in pos   if i in valid and  i not in DirIntoDilemma]# and i in valid2]
                # use legal move only

                if len(pos) > 0 and kaoTi < minTime: 
                #and \
                #       d + self.ctx.turn <= item.time + item.param <= d + self.ctx.turn + SPLIT_LIMIT / 2:
                    minTime, val = kaoTi, pos
                # search reachable food only
                # not that the span of a snake is at least SPLIT_LIMIT / 2

        # chose the closest reachable food and use legal move

        if len(val) == 0:
            val = valid
        i = random.randint(0, len(val) - 1)
        # randomly chose one if multiple available

        return val[i]
    
    def GetSnakeDir(self, snk: Snake):
        if snk.get_len() == 1:
            return -1
        ex = snk.coor_list[0][0] - snk.coor_list[1][0]
        ey = snk.coor_list[0][1] - snk.coor_list[1][1]
        if ey == 0:
            if ex == 1:
                return 0
            else:
                return 2
        elif ey == 1:
            return 1
        else:
            return 3
        return 114514

    def active_strategy(self):
        """
        Strategy for the active snake. Split whenever limit is reached.
        Fire whenever possible. Otherwise search for food.
        """
       # if len(self.snake.coor_list) >= SPLIT_LIMIT:
       #     return ACT_SPLIT
        while len(self.snake.item_list) > 0 and len(self.snake.coor_list) > 1:
            mp = self.ctx.get_map()
            snk = self.snake
            dr = self.GetSnakeDir(snk)
            if dr == -1:
                break
            cnt = 0
            cx = snk.coor_list[0][0]
            cy = snk.coor_list[0][1]
            for i in range(0, 1000):
                cx += dx[dr]
                cy += dy[dr]
                if cx < 0 or cy < 0 or cx > 15 or cy > 15:
                    break
                if mp.wall_map[cx][cy] == 1-self.ctx.current_player:
                    cnt += 1
            if cnt == 0:
                break
            return ACT_MELT
        
        return DirOptToAction(self.closest_food_strategy_diropt())

    def solidify_strategy_diropt(self):
        """
        Try to solidify self by forming a 2 * 2 area.
        It requires at most 4 move to solidify.

        :return: direction to move
        """
        if self.snake.id in self.order:
            rk, order = self.order[self.snake.id]
            self.order[self.snake.id] = rk + 1, order
            return order[rk] % 4
            # not the first move, follow the previous move
        else:
            for i in range(4):
                if self.DirOptLegalOrSoli(i):
                    order = [i, i + 1, i + 2, i + 3]
                    self.order.update({self.snake.id: (1, order)})
                    return i % 4
            # the first move, choose a legal direction at store it in self.order
            return 0

    def passive_strategy(self):
        """
        Strategy for other snake. Always solidify.
        """
        return DirOptToAction(self.solidify_strategy_diropt())
    def solidi_strategy(self):
        valid = []
        for i in range(4):
            if self.DirOptLegalOrSoli(i):
                valid.append(i)
        if len(valid) == 0:
            if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                return DirOptToAction(1)
                # 此时哪怕送死都必须要1
            # 此时0即可送死。
            return DirOptToAction(0)
        coor = self.snake.coor_list
        wmx,smx = Map22List(self.ctx.get_map())
        DirIntoDilemma = []
        headx = coor[0][0]
        heady = coor[0][1]
        ftx = -1
        fty = -1
        dirs = []
        for j in range(len(coor)):
            i = len(coor)-j-1
            headmove, dirs = BFSDistDir(headx, heady, coor[i][0], coor[i][1], wmx, smx)
            tailmove = len(coor) - i - 1
            if headmove <=tailmove:
                ftx = coor[i][0]
                fty = coor[i][1]
                #stderr.write("{}/{}".format(i,len(coor)))
                break
        dirs = [i for i in dirs if i in valid]
        realid = -1
        mysnks = self.ctx.get_player_snake(self.ctx.current_player)
        yoursnks = self.ctx.get_player_snake(1-self.ctx.current_player)
        for i in range(len(mysnks)):
            if mysnks[i].id == self.snake.id:
                realid = i
                break
        DirIntoDilemma = []
        
        for i in range(len(valid)):
            dr = valid[i]
            nsnk, nsmx = MovedSnake(self.snake, dr, smx, 0)
            area = FindArea(nsnk, wmx, nsmx)
            if area <= (self.snake.get_len()+self.snake.length_bank) * 3+1:
                DirIntoDilemma.append(dr)
                continue
            _continue_i_for = False
            # not only me, but also my friends.
            # it cin gos, dewoa mn ne Gumer.
            for j in range(len(mysnks)):
                if j == realid: 
                    continue
                jarea = FindArea(mysnks[j], wmx, nsmx)
                if jarea <= (mysnks[j].get_len()+mysnks[j].length_bank)*3+1:
                    DirIntoDilemma.append(dr)
                    _continue_i_for = True
                    break
            if _continue_i_for:
                continue
            for j in range(len(yoursnks)):
                if _continue_i_for:
                    break
                jvalid = GetSnakeValidDir(yoursnks[j], wmx, nsmx)
                for k in jvalid: # haha
                    _, nnsmx = MovedSnake(yoursnks[j], k, nsmx, 0)
                    karea = FindArea(nsnk, wmx, nnsmx)
                    if karea <= (self.snake.get_len()+self.snake.length_bank) * 3+1:
                        DirIntoDilemma.append(dr)
                        _continue_i_for = True
                        break
        val = []
        for i in dirs:
            if i not in DirIntoDilemma:
                val.append(i)
        if(len(val) > 0):
            return DirOptToAction(val[0])
        return DirOptToAction(valid[0])

    def judge(self, snake:Snake, ctx:Context):
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        """
        myCamp = ctx.current_player
        self.ctx = ctx
        self.snake = snake
        snakeLen = len(snake.coor_list)
        hasMelt = len(self.snake.item_list)
        allSnakeNum = ctx.get_snake_count(myCamp)
        # stderr.write("considering id {}\n".format(snake.id))
        if(snakeLen >= 2 and allSnakeNum <= 3 and self.ctx.turn > 8): # 前8回合增长
            # stderr.write("split!\n")
            return ACT_SPLIT
        elif(snakeLen >= 10 and allSnakeNum >= 3):
            return self.solidi_strategy()
        else:
            return self.active_strategy()
        # SAMPLE is a piece of shit!
        #if snake.id == 0 or snake.id == 1:
        #    return self.active_strategy()
        #else:
        #    return self.passive_strategy()
        


def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    # game config
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0

    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI()
    while playing:
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
                logging.debug(str(op))
                if not controller.apply(op):
                    raise RuntimeError("Illegal Action!!! " + str(op))
                c.send_data(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:
        pass

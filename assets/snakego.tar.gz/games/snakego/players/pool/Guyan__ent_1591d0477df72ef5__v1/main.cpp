#include "adk.hpp"
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>
using std::vector;
using std::pair;

/*



对于第一条蛇,一直努力去抢夺物品
对于第二三条蛇,努力去堵截
对于之后的蛇,成墙.
蛇的次序, 由功能决定.

如果处于优势,二三四条蛇都进行堵截.
如果处于均势,按上述方案进行.
如果处于劣势,第二三条蛇也优先吃道具.

对于任何一条蛇. 长度只要大于8就分裂.
只要可以发射激光且对我方有利就发射.

以左下角为原点. x 为横向. y 为纵向.

struct Snake
{
	std::vector<Coord> coord_list;
	int id, length_bank, camp;
	Item railgun_item;

	size_t length() const { return coord_list.size(); }

	const Coord& operator[]( size_t idx ) const { return coord_list[idx]; }
};


struct Item
{
	int x, y, id, time, type, param;
	bool eaten, expired;
};

type0: length 
type1: railgun

todo: 对于第一条蛇特殊判定。

*/

typedef Coord Point;

const int _dir[4][2] = { { 1 , 0 } , { 0 , 1 } , { -1 , 0 } , { 0 , -1 } };

int length , wall_map[16][16] , snake_map[16][16] , mycamp , id , dir , situation , item_map[16][16] , item_now[600];
vector<Snake> mysnake, ensnake;

bool inmap( int x , int y ) {
	if( x < 0 || y < 0 || x > 15 || y > 15 ) return false;
	return true;
}

bool cango( int x , int y ) {
	if( !inmap( x , y ) ) return false;
	if( wall_map[x][y] >= 0 ) return false;
	if( snake_map[x][y] >= 0 ) return false;
	return true;
}

int getdir( int a , int b , int c , int d ) {
	for( int i = 0 ; i < 4 ; ++i ) 
		if( a + _dir[i][0] == c && b + _dir[i][1] == d ) 
			return i;
	fprintf( stderr , "Wrong getdir" );
	abort();
}

int getdir( const Snake & s ) {
	if( s.coord_list.size() < 2 ) return -1;
	int x = s[0].x , y = s[0].y , a = s[1].x , b = s[1].y;
	return getdir( a , b , x , y );
}

int analyze_situation( const Context &ctx ) {
	int res = 0;
	res += mysnake.size() * 5;
	res -= ensnake.size() * 5;
	for( auto t : mysnake ) res += t.coord_list.size() * 4;
	for( auto t : ensnake ) res -= t.coord_list.size() * 4;
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j ) {
			res += ( wall_map[i][j] == mycamp );
			res -= ( wall_map[i][j] == (mycamp ^ 1 ));
		}
	return res;
}

Operation ATTACK( const Snake &nowS , const Context &ctx );
Operation EAT( const Snake &nowS , const Context &ctx );
Operation BEWALL( const Snake &nowS , const Context &ctx );
Operation Struggle( const Snake &nowS , const Context &ctx );

Operation BEWALL( const Snake &nowS , const Context &ctx ) {
	//fprintf(stderr,"BEWALL\n");
	if( length < 5 ) return Operation{ -1 };

	static Point que[16 * 16 + 16] , pre[16][16];
	static int he , ta , dis[16][16] , x , y , a , b;
	he = ta = 1; que[1] = nowS[0];
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j )
			dis[i][j] = -1;
	dis[nowS[0].x][nowS[0].y] = 0;
	while( he <= ta ) {
	  x = que[he].x , y = que[he].y;
		++he;
		for( int i = 0 ; i < 4 ; ++i ) {
			a = x + _dir[i][0] , b = y + _dir[i][1];
			if( !inmap( a , b ) ) continue;
			if( dis[a][b] == -1 ) {
				dis[a][b] = dis[x][y] + 1;
				pre[a][b] = Point{ x , y };
				if( cango( a , b ) ) {
					++ta;
					que[ta].x = a;
					que[ta].y = b;
				}
			}
		}
	}

	Point p , pp; p.x = -1;
	for( int i = length - 1 ; i > 1 ; --i ) {
		Point tp = nowS[i];
		if( dis[tp.x][tp.y] < 0 ) continue;
		if( length - i - 1 - dis[tp.x][tp.y] >= 0 ) {
			p = tp;
			break;
		}
	}
	if( p.x == -1 ) return Operation{ -1 };

	pp = pre[p.x][p.y];

	while( dis[pp.x][pp.y] != 0 ) {
		p = pp;
		pp = pre[p.x][p.y];
	}
	return Operation{ getdir( pp.x , pp.y , p.x , p.y ) + 1 };
}

Operation ATTACK( const Snake &nowS , const Context &ctx ) {
	// fprintf(stderr,"ATTAK\n");
	if( ensnake.size() == 0 ) return Operation{ -1 };
	static int goal[6] , goal_cnt;
	goal_cnt = 0;
	for( int i = 0 , t = ensnake.size() ; i < t ; ++i )
		if( ensnake[i].coord_list.size() > 1 ) 
			goal[++goal_cnt] = i;
	if( goal_cnt == 0 ) return Operation{ -1 };

	static Point que[16 * 16 + 16] , pre[16][16];
	static int he , ta , dis[16][16];
	he = ta = 1; que[1] = nowS[0];
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j )
			dis[i][j] = -1;
	dis[nowS[0].x][nowS[0].y] = 0;
	while( he <= ta ) {
		int x = que[he].x , y = que[he].y;
		++he;
		for( int i = 0 ; i < 4 ; ++i ) {
			if( !cango( x + _dir[i][0] , y + _dir[i][1] ) ) continue;
			if( dis[x + _dir[i][0]][y + _dir[i][1]] == -1 ) {
				dis[x + _dir[i][0]][y + _dir[i][1]] = dis[x][y] + 1;
				++ta;
				que[ta].x = x + _dir[i][0];
				que[ta].y = y + _dir[i][1];
				pre[que[ta].x][que[ta].y] = Point{ x , y };
			}
		}
	}

	static pair<Point,int> togo[6];
	static int togo_cnt;
	togo_cnt = 0;
	for( int i = 1 ; i <= goal_cnt ; ++i ) {
		int endir = getdir( ensnake[goal[i]] );
		Point p = ensnake[goal[i]].coord_list[0];
		for( int j = 0 ; j < 3 ; ++j ) {
			if( cango( p.x + _dir[endir][0] , p.y + _dir[endir][1] ) ) 
				p.x += _dir[endir][0] , p.y += _dir[endir][1];
			if( cango( p.x , p.y ) ) 
				if( dis[p.x][p.y] > 0 ) {
					togo_cnt++;
					togo[togo_cnt] = pair<Point,int>( p , dis[p.x][p.y] );
				}
		}
	}
	if( togo_cnt == 0 ) return Operation{ -1 };
	sort( togo + 1 , togo + 1 + togo_cnt , []( pair<Point,int> a , pair<Point,int> b ) {
		return a.second > b.second; } );
	Point p = togo[1].first , pp;
	pp = pre[p.x][p.y];
	while( dis[pp.x][pp.y] != 0 ) {
		p = pp;
		pp = pre[p.x][p.y];
	}
	return Operation{ getdir( pp.x , pp.y , p.x , p.y ) + 1 };
}

Operation Struggle( const Snake &nowS , const Context &ctx ) {
	//fprintf(stderr,"Struggle\n");
	Point p = nowS[0];
	if( length == 1 ) {
		for( int i = 0 ; i < 4 ; ++i ) {
			if( cango( p.x + _dir[i][0] , p.y + _dir[i][1] ) )
				return Operation{ i + 1 };	
		}
		return OP_UP;
	}
	
	for( int i = 0 ; i < 4 ; ++i ) {
		if( cango( p.x + _dir[i][0] , p.y + _dir[i][1] ) )
			return Operation{ i + 1 };
	}
	for( int i = 0 ; i < 4 ; ++i ) {
		if( p.x + _dir[i][0] == nowS[1].x && p.y + _dir[i][1] == nowS[1].y ) continue;
		return Operation{ i + 1 };
	}
	return OP_UP;
}

Operation EAT( const Snake &nowS , const Context &ctx ) {
	//fprintf(stderr,"EAT\n");
	static Point que[16 * 16 + 16] , pre[16][16];
	static int he , ta , dis[16][16];
	he = ta = 1; que[1] = nowS[0];
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j )
			dis[i][j] = -1;
	dis[nowS[0].x][nowS[0].y] = 0;
	while( he <= ta ) {
		int x = que[he].x , y = que[he].y;
		++he;
		for( int i = 0 ; i < 4 ; ++i ) {
			if( !cango( x + _dir[i][0] , y + _dir[i][1] ) ) continue;
			if( dis[x + _dir[i][0]][y + _dir[i][1]] == -1 ) {
				dis[x + _dir[i][0]][y + _dir[i][1]] = dis[x][y] + 1;
				++ta;
				que[ta].x = x + _dir[i][0];
				que[ta].y = y + _dir[i][1];
				pre[que[ta].x][que[ta].y] = Point{ x , y };
			}
		}
	}

	/*
	for( int i = 0 ; i < 16 ; ++i ) {
		for( int j = 0 ; j < 16 ; ++j ) {
			fprintf(stderr,"%d ",dis[i][j]);
		}
		fprintf( stderr , "\n" );
	}
	fprintf( stderr , "\n" );
	*/

	static pair<Point,int> aitem[300];
	int nitem = 0 , ltime , sn = mysnake.size() + ensnake.size();
	for( auto it : ctx.item_list() ) {
		if( dis[it.x][it.y] > 0 ) {
			ltime = it.time + 15 - ctx.current_round();
			if(  ltime / sn >= dis[it.x][it.y] ) {
				if( it.time <= ctx.current_round() && !item_now[it.id] ) continue;
				++nitem;
				aitem[nitem] = pair<Point,int>( Point{ it.x , it.y } , dis[it.x][it.y] );
			}
		}
	}
	if( !nitem ) return Operation{ -1 };
	sort( aitem + 1 , aitem + 1 + nitem , []( pair<Point,int> a , pair<Point,int> b ) { 
		return a.second > b.second; } );

	Point p , pp;
	p = aitem[1].first;
	pp = pre[p.x][p.y];

	while( dis[pp.x][pp.y] != 0 ) {
		p = pp;
		pp = pre[p.x][p.y];
	}
	return Operation{ getdir( pp.x , pp.y , p.x , p.y ) + 1 };
}


Operation Mild( const Snake &nowS , const Context &ctx ) {
	Operation res; res.type = -1;
	if( id == mysnake[0].id && ctx.item_list().size() > 0 ) {
		res = EAT( nowS , ctx );
		if( res.type == -1 ) res = ATTACK( nowS , ctx );	
		if( res.type == -1 ) res = BEWALL( nowS , ctx );
		if( res.type == -1 ) res = Struggle( nowS , ctx );
	} else if( id == mysnake[1].id || id == mysnake[2].id ) {
		res = ATTACK( nowS , ctx );
		if( res.type == -1 ) res = EAT( nowS , ctx );
		if( res.type == -1 ) res = BEWALL( nowS , ctx );
		if( res.type == -1 ) res = Struggle( nowS , ctx );
	} else {
		res = BEWALL( nowS , ctx );
		if( res.type == -1 ) res = EAT( nowS , ctx );
		if( res.type == -1 ) res = ATTACK( nowS , ctx );
		if( res.type == -1 ) res = Struggle( nowS , ctx );
	}
	if( res.type == -1 ) return OP_UP;
	//fprintf(stderr,"res.type = %d\n",res.type);
	return res;
}

Operation Aggressive( const Snake &nowS , const Context &ctx ) {
	Operation res; res.type = -1;
	if( id == mysnake[0].id ) {
		res = EAT( nowS , ctx );
		if( res.type == -1 ) res = ATTACK( nowS , ctx );
		if( res.type == -1 ) res = BEWALL( nowS , ctx );
		if( res.type == -1 ) res = Struggle( nowS , ctx );
	} else {
		res = ATTACK( nowS , ctx );
		if( res.type == -1 ) res = EAT( nowS , ctx );
		if( res.type == -1 ) res = BEWALL( nowS , ctx );
		if( res.type == -1 ) res = Struggle( nowS , ctx );
	}
	if( res.type == -1 ) return OP_UP;
	return res;
}

Operation Conservative( const Snake &nowS , const Context &ctx ) {
	//fputs("Conservative\n",stderr);
	Operation res; res.type = -1;
	res = EAT( nowS , ctx );
	if( res.type == -1 ) res = ATTACK( nowS , ctx );
	if( res.type == -1 ) res = BEWALL( nowS , ctx );
	if( res.type == -1 ) res = Struggle( nowS , ctx );
	if( res.type == -1 ) return OP_UP;
	return res;
}

Operation
make_your_decision( const Snake &nowS, const Context &ctx ) {
	length = nowS.coord_list.size(); 
	mycamp = nowS.camp;
	id = nowS.id;
	memset( item_now , 0 , sizeof item_now );
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j ) {
			wall_map[i][j] = ctx.wall_map()[i][j];
			snake_map[i][j] = ctx.snake_map()[i][j];
			item_map[i][j] = ctx.item_map()[i][j];
			if( item_map[i][j] >= 0 )
				item_now[item_map[i][j]] = 1;
		}

	mysnake = ctx.snake_list_0();
	ensnake = ctx.snake_list_1();
	if( mycamp == 1 ) std::swap( mysnake , ensnake );

	situation = analyze_situation( ctx );

	if( length > 9 && mysnake.size() <= 3 ) return OP_SPLIT;
	dir = getdir( nowS );
	if( nowS.railgun_item.id >= 0 && dir > -1 ) {
		int x = nowS[0].x , y = nowS[0].y;
		int _my = 0 , _en = 0;
		while( inmap( x , y ) ) {
			if( wall_map[x][y] >= 0 ) {
				if( wall_map[x][y] == mycamp ) ++_my;
				else ++_en;
			}
			x += _dir[dir][0];
			y += _dir[dir][1];
		}
		if( _my < _en )  return OP_RAILGUN;
	}
	
	if( situation <= 20 && situation >= -20 ) return Mild( nowS , ctx );
	if( situation > 20 ) return Aggressive( nowS , ctx );
	if( situation < -20 ) return Conservative( nowS , ctx );
	abort();
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score ) {
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char **argv ) {
	SnakeGoAI start( argc, argv );
}

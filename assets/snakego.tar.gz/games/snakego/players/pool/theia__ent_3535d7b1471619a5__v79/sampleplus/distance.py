from string import ascii_letters
from adk import *
from state import State
from queue import Queue
from constants import *
from copy import copy, deepcopy

def check_for(state: State, another_snake: Snake, op):
    """
    :param op: the direction
    :return: True if this move is legal and will not result in solidification.
                False otherwise.
    """
    x = another_snake.coor_list[0][0] + dx[op]
    y = another_snake.coor_list[0][1] + dy[op]
    if x < 0 or y < 0 or x >= 16 or y >= 16 or state.ctx.game_map.wall_map[x][y] != -1:
        return False
    # check wall and out of bounds
    if another_snake.get_len() > 2 and x == another_snake.coor_list[1][0] and y == another_snake.coor_list[1][1]:
        return False
    # check turn back
    if state.ctx.game_map.snake_map[x][y] != -1 and not(x == another_snake.coor_list[another_snake.get_len() - 1][0] and y == another_snake.coor_list[another_snake.get_len() - 1][1] and another_snake.length_bank == 0):
        return False
    # check other snakes
    return True

def dist_from_tail(state: State, snake_id, coor):
    for snake_it in state.ctx.snake_list:
        if snake_it.id == snake_id:
            ret = 0
            for i in range(len(snake_it.coor_list) - 1, -1, -1):
                if snake_it.coor_list[i][0] == coor[0] and snake_it.coor_list[i][1] == coor[1]:
                    return ret
                ret += 1
    
    sys.stderr.write("dist_from_tail error!\n" + str(snake_id) + " " + str(coor) + "\n")
    sys.stderr.flush()
    return -1

def get_deterministic_bfs_dist(state: State):
    #preprocess start
    #map_copy = deepcopy(state.ctx.game_map.snake_map)
    enemy_proximity = dict()
    for snake_itr in state.ctx.snake_list:
        head_coor = snake_itr.coor_list[0]
        if snake_itr.camp != state.snake.camp and\
             manhattan(head_coor[0], head_coor[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) <= ENEMY_HEAD_PROBE_DISTANCE_THRESHOLD:
            for op in range(4):
                if not check_for(state, snake_itr, op):
                    continue
                probe_coor = (head_coor[0] + dx[op], head_coor[1] + dy[op])
                if manhattan(probe_coor[0], probe_coor[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) > 1:
                    enemy_proximity[probe_coor[0] * 16 + probe_coor[1]] = snake_itr.id
    #preprocess ends
    cur_coor = (state.snake.coor_list[0][0], state.snake.coor_list[0][1])
    q = Queue()
    vis = dict()
    prev = dict()
    q.put(cur_coor)
    vis[cur_coor[0] * 16 + cur_coor[1]] = True
    prev[cur_coor[0] * 16 + cur_coor[1]] = -1
    dist = []
    for i in range(16):
        tmp_list = []
        for j in range(16):
            if i == cur_coor[0] and j == cur_coor[1]:
                tmp_list.append(0)
            else:
                tmp_list.append(INF)
        dist.append(tmp_list)
    
    while(not(q.empty())):
        cur_coor = q.get()
        dirs = [0, 1, 2, 3]
        #random.shuffle(dirs)
        #no shuffle for deterministic outcome
        for op in dirs:
            next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
            if next_coor[0] > 15 or next_coor[0] < 0 or next_coor[1] > 15 or next_coor[1] < 0:
                continue
            if next_coor[0] * 16 + next_coor[1] in vis:
                continue
            if state.ctx.game_map.wall_map[next_coor[0]][next_coor[1]] != -1:
                continue
            if next_coor[0] * 16 + next_coor[1] in enemy_proximity: #TOO conservative
                continue
            if state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]] != -1:
                snake_id = state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]]
                for snake_itr in state.ctx.snake_list:
                    if snake_itr.id == snake_id:
                        length_bank = snake_itr.length_bank
                        enemy_head_coor = snake_itr.coor_list[0]
                        enemy_camp = snake_itr.camp
                if (dist_from_tail(state, snake_id, next_coor) + length_bank - 1 >= manhattan(state.snake.coor_list[0][0], state.snake.coor_list[0][1], next_coor[0], next_coor[1]) * DIST_FACTOR) or\
                    (snake_id == state.snake.id and dist_from_tail(state, snake_id, next_coor) + state.snake.length_bank >= dist[cur_coor[0]][cur_coor[1]]) or\
                    (snake_id != state.snake.id and manhattan(next_coor[0], next_coor[1], enemy_head_coor[0], enemy_head_coor[1]) <= BODY_IGNORE_THRESHOLD):
                    continue
            dist[next_coor[0]][next_coor[1]] = dist[cur_coor[0]][cur_coor[1]] + 1
            vis[next_coor[0] * 16 + next_coor[1]] = 16
            prev[next_coor[0] * 16 + next_coor[1]] = cur_coor[0] * 16 + cur_coor[1]
            q.put(next_coor)

    #sys.stdout.write("At turn " + str(state.ctx.turn) + ", for snake " + str(state.snake.id) + ": \n")
    #for y in range(15, -1, -1):
    #    for x in range(16):
    #        sys.stdout.write(str(dist[x][y]) + " ")
    #        sys.stdout.flush()
    #    sys.stdout.write("\n")
    dist[state.snake.coor_list[0][0]][state.snake.coor_list[0][1]] = INF
    return dist, prev

def get_bfs_dist(state: State):
    #preprocess start
    enemy_proximity = dict()
    for snake_itr in state.ctx.snake_list:
        head_coor = snake_itr.coor_list[0]
        if snake_itr.camp != state.snake.camp and\
             manhattan(head_coor[0], head_coor[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) <= ENEMY_HEAD_PROBE_DISTANCE_THRESHOLD:
            for op in range(4):
                if not check_for(state, snake_itr, op):
                    continue
                probe_coor = (head_coor[0] + dx[op], head_coor[1] + dy[op])
                if manhattan(probe_coor[0], probe_coor[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) > 1:
                    enemy_proximity[probe_coor[0] * 16 + probe_coor[1]] = snake_itr.id
    #preprocess ends
    cur_coor = (state.snake.coor_list[0][0], state.snake.coor_list[0][1])
    q = Queue()
    vis = dict()
    prev = dict()
    q.put(cur_coor)
    vis[cur_coor[0] * 16 + cur_coor[1]] = True
    prev[cur_coor[0] * 16 + cur_coor[1]] = -1
    dist = []
    for i in range(16):
        tmp_list = []
        for j in range(16):
            if i == cur_coor[0] and j == cur_coor[1]:
                tmp_list.append(0)
            else:
                tmp_list.append(INF)
        dist.append(tmp_list)
    
    while(not(q.empty())):
        cur_coor = q.get()
        dirs = [0, 1, 2, 3]
        if random.randint(1, 10) == 1: #maybe not so random...
            random.shuffle(dirs)
        for op in dirs:
            next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
            if next_coor[0] > 15 or next_coor[0] < 0 or next_coor[1] > 15 or next_coor[1] < 0:
                continue
            if next_coor[0] * 16 + next_coor[1] in vis:
                continue
            if state.ctx.game_map.wall_map[next_coor[0]][next_coor[1]] != -1:
                continue
            if next_coor[0] * 16 + next_coor[1] in enemy_proximity:
                continue
            if state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]] != -1:
                snake_id = state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]]
                for snake_itr in state.ctx.snake_list:
                    if snake_itr.id == snake_id:
                        length_bank = snake_itr.length_bank
                        enemy_head_coor = snake_itr.coor_list[0]
                        enemy_camp = snake_itr.camp
                if (dist_from_tail(state, snake_id, next_coor) + length_bank - 1 >= manhattan(state.snake.coor_list[0][0], state.snake.coor_list[0][1], next_coor[0], next_coor[1]) * DIST_FACTOR) or\
                     (snake_id == state.snake.id and dist_from_tail(state, snake_id, next_coor) + state.snake.length_bank >= dist[cur_coor[0]][cur_coor[1]]) or\
                    (snake_id != state.snake.id and manhattan(next_coor[0], next_coor[1], enemy_head_coor[0], enemy_head_coor[1]) <= BODY_IGNORE_THRESHOLD): 
                    continue
            dist[next_coor[0]][next_coor[1]] = dist[cur_coor[0]][cur_coor[1]] + 1
            vis[next_coor[0] * 16 + next_coor[1]] = True
            prev[next_coor[0] * 16 + next_coor[1]] = cur_coor[0] * 16 + cur_coor[1]
            q.put(next_coor)

    #sys.stdout.write("At turn " + str(state.ctx.turn) + ", for snake " + str(state.snake.id) + ": \n")
    #for y in range(15, -1, -1):
    #    for x in range(16):
    #        sys.stdout.write(str(dist[x][y]) + " ")
    #        sys.stdout.flush()
    #    sys.stdout.write("\n")
    return dist, prev

def manhattan(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)

def calc_dist(state: State, x1, y1, x2, y2, bfs_dist: List[List[int]], prev: List[int]): #item(x1,y1), snake(x2,y2)
    """
    Calculate the Manhattan distance between snake head and item.
    And find the possible direction to the item, at most 2.

    :return: (dist, possible_direction)
    """
    MANHATTAN_LIMIT = 4
    if(manhattan(x1, y1, x2, y2) < MANHATTAN_LIMIT):
        pos = []
        if x1 > x2:
            pos.append(0)
        if x1 < x2:
            pos.append(2)
        if y1 > y2:
            pos.append(1)
        if y1 < y2:
            pos.append(3)
        return abs(x1 - x2) + abs(y1 - y2), pos
    else:
        if bfs_dist[x1][y1] == INF:
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return (abs(x1 - x2) + abs(y1 - y2)) * UNREACHABLE_PENALTY, pos
        pos = []
        pos_elem = x1 * 16 + y1
        while prev[prev[pos_elem]] != -1:
            pos_elem = prev[pos_elem]
        head = prev[pos_elem]
        if(head != state.snake.coor_list[0][0] * 16 + state.snake.coor_list[0][1]):
            sys.stderr.write("prev head parse error\n")
        if pos_elem - head == 16:
            pos.append(0)
        elif pos_elem - head == -16:
            pos.append(2)
        elif pos_elem - head == 1:
            pos.append(1)
        elif pos_elem - head == -1:
            pos.append(3)
        return bfs_dist[x1][y1], pos
    
def scout_map(state: State):
    #get distance info
    dist, prev = get_bfs_dist(state)
    #init maps
    height = []
    width = [] #x axis
    realm = [] #y axis
    cut = []
    for i in range(16):
        tmp_list = []
        for j in range(16):
            tmp_list.append(-1) #unreachable marker
        height.append(copy(tmp_list))
        width.append(copy(tmp_list))
        realm.append(copy(tmp_list))
        tmp_list = []
        for j in range(16):
            tmp_list.append(False)
        cut.append(copy(tmp_list))
    #sys.stderr.write("1")
    sys.stderr.flush()
    #start calculating height and width
    for i in range(16):
        height_accumulator = 0
        lower_bound = 0
        for j in range(16):
            accu_flag = False
            if i * 16 + j in prev:
                height_accumulator += 1
                accu_flag = True
            if not accu_flag or j == 15:
                if accu_flag and j == 15:
                    j = 16
                for k in range(lower_bound, j):
                    height[i][k] = height_accumulator
                height_accumulator = 0
                lower_bound = j + 1
    for i in range(16):
        width_accumulator = 0
        left_bound = 0
        for j in range(16):
            accu_flag = False
            if j * 16 + i in prev:
                width_accumulator += 1
                accu_flag = True
            if not accu_flag or j == 15:
                if accu_flag and j == 15:
                    j = 16
                for k in range(left_bound, j):
                    width[k][i] = width_accumulator
                width_accumulator = 0
                left_bound = j + 1
    #start dividing realms using height and width
    #first locate all cut points...
    #sys.stderr.write("2")
    sys.stderr.flush()
    cut_queue = Queue()
    for i in range(16):
        for j in range(16):
            if height[i][j] == 1 or width[i][j] == 1:
                cut[i][j] = True
                cut_queue.put((i, j))
    while not cut_queue.empty(): #enumerate all cut points to see if there are additional ones
        cur_coor = cut_queue.get()
        for op in range(4):
            next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
            if next_coor[0] < 0 or next_coor[0] > 15 or next_coor[1] < 0 or next_coor[1] > 15:
                continue
            if not next_coor[0] * 16 + next_coor[1] in prev:
                continue
            if prev[next_coor[0] * 16 + next_coor[1]] == -1:
                continue
            if cut[next_coor[0]][next_coor[1]]:
                continue
            is_also_cut = True
            for next_op in range(4):
                probe_coor = (next_coor[0] + dx[next_op], next_coor[1] + dy[next_op])
                if probe_coor[0] < 0 or probe_coor[0] > 15 or probe_coor[1] < 0 or probe_coor[1] > 15:
                    continue
                if not probe_coor[0] * 16 + probe_coor[1] in prev:
                    continue
                if prev[probe_coor[0] * 16 + probe_coor[1]] == -1:
                    continue
                if not cut[probe_coor[0]][probe_coor[1]]:
                    is_also_cut = False
                    break
            if is_also_cut:
                cut[next_coor[0]][next_coor[1]] = True
                cut_queue.put(copy(next_coor))
    #...then find all corridors...
    #sys.stderr.write("3")
    sys.stderr.flush()
    corridor_cnt = 0
    corridor: List[List[Tuple(int, int)]]
    corridor = [] #all corridors and their tiles
    exit_point: List[List[Tuple(int, int)]]
    exit_point = [] #marks all exit points of corridors
    dead_end_corridor = []
    corridor_id = dict()
    for i in range(16):
        for j in range(16):
            if cut[i][j] and not i * 16 + j in corridor_id:
                exit_point.append([])
                corridor.append([])
                dead_end_corridor.append(False)
                cur_coor = (i, j)
                cut_queue = Queue()
                cut_queue.put(cur_coor)
                while not cut_queue.empty():
                    cur_coor = cut_queue.get()
                    corridor_id[cur_coor[0] * 16 + cur_coor[1]] = corridor_cnt
                    for op in range(4):
                        next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
                        if next_coor[0] < 0 or next_coor[0] > 15 or next_coor[1] < 0 or next_coor[1] > 15:
                            continue
                        if not next_coor[0] * 16 + next_coor[1] in prev:
                            continue           
                        if prev[next_coor[0] * 16 + next_coor[1]] == -1:
                            continue
                        if next_coor[0] * 16 + next_coor[1] in corridor_id:
                            continue
                        if not cut[next_coor[0]][next_coor[1]]:
                            exit_point[corridor_cnt].append(copy(next_coor))
                        else: # if cut
                            cut_queue.put(copy(next_coor))
                            corridor_id[next_coor[0] * 16 + next_coor[1]] = corridor_cnt
                            corridor[corridor_cnt].append(copy(next_coor))
                if len(exit_point[corridor_cnt]) == 1:
                    dead_end_corridor[corridor_cnt] = True
                corridor_cnt += 1
    #...and finally number all the realms
    #sys.stderr.write("4")
    sys.stderr.flush()
    realm_cnt = 0
    realm: List[List[Tuple(int, int)]]
    realm = [] #all realms and their tiles
    connection: List[List[Tuple(int, int)]]
    connection = [] #all corridor tiles bordering the realm
    pocket = []
    size = [] #the size(area) of all realms
    realm_id = dict()
    for i in range(16):
        for j in range(16):
            if not cut[i][j] and not i * 16 + j in realm_id and i * 16 + j in prev:
                if prev[i * 16 + j] == -1:
                    continue
                realm.append([])
                connection.append([])
                pocket.append(False)
                cur_size = 0
                cur_coor = (i, j)
                realm_queue = Queue()
                realm_queue.put(cur_coor)
                while not realm_queue.empty():
                    cur_size += 1
                    cur_coor = realm_queue.get()
                    #sys.stderr.write("\ncur_coor: " + str(cur_coor))
                    sys.stderr.flush()
                    realm_id[cur_coor[0] * 16 + cur_coor[1]] = realm_cnt
                    for op in range(4):
                        next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
                        if next_coor[0] < 0 or next_coor[0] > 15 or next_coor[1] < 0 or next_coor[1] > 15:
                            continue
                        if not next_coor[0] * 16 + next_coor[1] in prev:
                            continue
                        if prev[next_coor[0] * 16 + next_coor[1]] == -1:
                            continue
                        if next_coor[0] * 16 + next_coor[1] in realm_id:
                            continue
                        if cut[next_coor[0]][next_coor[1]]:
                            connection[realm_cnt].append(copy(next_coor))
                        else: #if not cut
                            realm_queue.put(copy(next_coor))
                            realm_id[next_coor[0] * 16 + next_coor[1]] = realm_cnt
                            realm[realm_cnt].append(copy(next_coor))
                size.append(cur_size)
                if len(connection[realm_cnt]) == 1:
                    pocket[realm_cnt] = True
                realm_cnt += 1
    # sys.stdout.write("\nAt turn " + str(state.ctx.turn) + ", for snake " + str(state.snake.id) + ": \n")
    # sys.stdout.write("width:\n")
    # for y in range(15, -1, -1):
    #     for x in range(16):
    #         sys.stdout.write(str(width[x][y]) + " ")
    #     sys.stdout.write("\n")
    # sys.stdout.write("height:\n")
    # for y in range(15, -1, -1):
    #     for x in range(16):
    #         sys.stdout.write(str(height[x][y]) + " ")
    #     sys.stdout.write("\n")
    # sys.stdout.write("map:\n")
    # for y in range(15, -1, -1):
    #     for x in range(16):
    #         if not x * 16 + y in prev:
    #             sys.stdout.write("X ")
    #         elif prev[x * 16 + y] == -1:
    #             sys.stdout.write("H ")
    #         else:
    #             if cut[x][y]:
    #                 sys.stdout.write(chr(corridor_id[x * 16 + y] + ord("a")) + " ")
    #             else:
    #                 sys.stdout.write(str(realm_id[x * 16 + y]) + " ")
    #     sys.stdout.write("\n")
    # sys.stdout.write("connections: " + str(connection) + "\n")
    # sys.stdout.write("realm sizes: " + str(size) + "\n")
    # sys.stdout.write("pocket realm?: " + str(pocket) + "\n")
    # sys.stdout.write("exit points: " + str(exit_point) + "\n")
    # sys.stdout.write("dead end?: " + str(dead_end_corridor) + "\n\n")
    # sys.stdout.flush()
    return width, height, realm_cnt, size, realm_id, realm, connection, pocket, corridor_cnt, corridor_id, corridor, exit_point, dead_end_corridor


    

from adk import *
from constants import *
from state import State
from check import *

def can_kill(state: State): #returns a list of tuples: [lethal move, kill target id, kill target camp]
    valid = []
    ret = []
    already_dead = dict()
    for another_snake in state.ctx.snake_list:
        if another_snake.id == state.snake.id:
            continue
        if certain_death_for(state, another_snake):
            already_dead[another_snake.id] = True
    for op in range(4):
        if check(state, op) and no_deathtrap(state, op): #no_deathtrap maybe too conservative
            valid.append(op)
    for op in valid:
        #simulate movement
        dest_coor = [state.snake.coor_list[0][0] + dx[op], state.snake.coor_list[0][1] + dy[op]]
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = state.snake.id
        if state.snake.length_bank == 0:
            len = state.snake.get_len()
            erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = -1
        #check for certain death
        for another_snake in state.ctx.snake_list:
            if another_snake.id == state.snake.id or another_snake.id in already_dead:
                continue
            if certain_death_for(state, another_snake):
                ret.append([op, another_snake.id, another_snake.camp])
        #backtrack
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = -1
        if state.snake.length_bank == 0:
            len = state.snake.get_len()
            erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = state.snake.id
    return ret

def can_block(state: State): #returns a list of lists: [blocking move, block target id, block target camp]
    valid = []
    ret = []
    already_blocked = dict()
    for another_snake in state.ctx.snake_list:
        if another_snake.id == state.snake.id:
            continue
        another_state = construct_dependent_state(state.ctx, another_snake, state.order, state.adv_solidify_target, state.map_data)
        free_pass = False
        for op in range(4):
            if check(another_state, op) and no_deathtrap(another_state, op):
                free_pass = True
                break
        if not(free_pass):
            already_blocked[another_snake.id] = True
    
    for op in range(4):
        if check(state, op) and no_deathtrap(state, op): #no_deathtrap maybe too conservative
            valid.append(op)
    for op in valid:
        #simulate movement
        dest_coor = [state.snake.coor_list[0][0] + dx[op], state.snake.coor_list[0][1] + dy[op]]
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = state.snake.id
        if state.snake.length_bank == 0:
            len = state.snake.get_len()
            erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = -1
        #check for certain death
        for another_snake in state.ctx.snake_list:
            if another_snake.id == state.snake.id or another_snake.id in already_blocked:
                continue
            another_state = construct_dependent_state(state.ctx, another_snake, state.order, state.adv_solidify_target, state.map_data)
            free_pass = False
            for another_snake_op in range(4):
                if check(another_state, another_snake_op) and no_deathtrap(another_state, another_snake_op):
                    free_pass = True
                    break
            if not(free_pass):
                ret.append([op, another_snake.id, another_snake.camp])
        #backtrack
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = -1
        if state.snake.length_bank == 0:
            len = state.snake.get_len()
            erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = state.snake.id
    return ret

def can_be_killed_by(state: State, enemy_snake): #simplify!
    valid = []
    kill_list = list()
    already_dead = dict()
    for another_snake in state.ctx.snake_list:
        if another_snake.camp == enemy_snake.camp:
            continue
        if certain_death_for(state, another_snake):
            already_dead[another_snake.id] = True
    for op in range(4):
        if check_for(state, enemy_snake, op): 
            valid.append(op)
    for op in valid:
        #simulate movement
        dest_coor = [enemy_snake.coor_list[0][0] + dx[op], enemy_snake.coor_list[0][1] + dy[op]]
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = enemy_snake.id
        if enemy_snake.length_bank == 0:
            enemy_len = enemy_snake.get_len()
            erase_coor = [enemy_snake.coor_list[enemy_len - 1][0], enemy_snake.coor_list[enemy_len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = -1
        #check for certain death
        if certain_death_for(state, state.snake):
            kill_list.append([op, another_snake.id, another_snake.camp])
        #backtrack
        state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = -1
        if enemy_snake.length_bank == 0:
            enemy_len = enemy_snake.get_len()
            erase_coor = [enemy_snake.coor_list[enemy_len - 1][0], enemy_snake.coor_list[enemy_len - 1][1]]
            state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = enemy_snake.id
    return (len(kill_list) > 0)

def cannot_be_killed(state: State, op):
    #simulate movement for state.snake
    if state.snake.get_len() == 1:
        return True
    ret = True
    dest_coor = [state.snake.coor_list[0][0] + dx[op], state.snake.coor_list[0][1] + dy[op]]
    state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = state.snake.id
    if state.snake.length_bank > 0:
        state.snake.coor_list.append((state.snake.coor_list[state.snake.get_len() - 1][0], state.snake.coor_list[state.snake.get_len() - 1][1]))
    backtrack_mem = (state.snake.coor_list[1][0], state.snake.coor_list[1][1])
    state.snake.coor_list[1] = (state.snake.coor_list[0][0], state.snake.coor_list[0][1])
    state.snake.coor_list[0] = (dest_coor[0], dest_coor[1])
    if state.snake.length_bank == 0:
        len = state.snake.get_len()
        erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
        state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = -1
    #check for enemy kill moves
    for enemy_snake in state.ctx.snake_list:
        if enemy_snake.camp == state.snake.camp:
            continue
        if can_be_killed_by(state, enemy_snake):
            ret = False
            DIR = ["RIGHT", "UP", "LEFT", "DOWN"]
            sys.stderr.write("At turn " + str(state.ctx.turn) + ", snake " + str(state.snake.id) + " can be killed by snake " + str(enemy_snake.id) + " if it moves " + DIR[op] + "\n")
            sys.stderr.flush()
            break
    #backtrack
    state.ctx.game_map.snake_map[dest_coor[0]][dest_coor[1]] = -1
    state.snake.coor_list[0] = (state.snake.coor_list[1][0], state.snake.coor_list[1][1])
    state.snake.coor_list[1] = (backtrack_mem[0], backtrack_mem[1])
    if state.snake.length_bank == 0:
        len = state.snake.get_len()
        erase_coor = [state.snake.coor_list[len - 1][0], state.snake.coor_list[len - 1][1]]
        state.ctx.game_map.snake_map[erase_coor[0]][erase_coor[1]] = state.snake.id
    else:
        state.snake.coor_list.pop()
    return ret




def certain_death(state: State):
    valid = []
    for i in range(4):
        if(check(state, i)):
            valid.append(i)
    if(len(valid) == 0):
        return True
    else:
        return False


def certain_death_for(state: State, another_snake: Snake):
    valid = []
    for i in range(4):
        if(check_for(state, another_snake, i)):
            valid.append(i)
    if(len(valid) == 0):
        #sys.stderr.write("At turn " + str(state.ctx.turn) + ", snake id " + str(another_snake.id) + " faced certain death!\n")
        #sys.stderr.flush()
        return True
    return False

def split_safe(state: State, _controller: Controller):
    tmp_state = construct_independent_state(state.ctx, state.snake, state.order, state.adv_solidify_target, state.map_data)
    tmp_controller = deepcopy(_controller)
    tmp_controller.apply(6)
    tmp_state.ctx = tmp_controller.ctx
    tail_snake_id = tmp_controller.snake_num - 1
    for snake_itr in tmp_state.ctx.snake_list:
        if snake_itr.id == tail_snake_id:
            tail_snake = snake_itr
            break
    if certain_death(tmp_state):
        ret = False
        return ret
    tmp_state.snake = tail_snake
    #tmp_state.map_data = MapData(scout_map(tmp_state))
    sys.stderr.write("At turn " + str(tmp_state.ctx.turn) + ", split_safe() triggered for " + str(state.snake.id) + ", generating " + str(tmp_state.snake.id) + "\n")
    ret = False
    if not certain_death(tmp_state): #no valid moves
        for op in range(4):
            if no_deathtrap(tmp_state, op) and cannot_be_killed(tmp_state, op): #too conservative?
                ret = True
                break
    if ret:
        sys.stderr.write("At turn " + str(tmp_state.ctx.turn) + ", split is safe\n")
    else:
        sys.stderr.write("At turn " + str(tmp_state.ctx.turn) + ", split is not safe\n")
    sys.stderr.flush()
    del tmp_state
    del tmp_controller
    return ret
        
from kill import certain_death
from check import *
from state import State
from constants import *
from adk import *

def melt_is_useful(state: State):
    #sys.stderr.write(str(state.ctx.get_map().length))

    if len(state.snake.coor_list) == 1 or len(state.snake.item_list) == 0:
        return False
    else:
        dx = state.snake.coor_list[0][0] - state.snake.coor_list[1][0]
        dy = state.snake.coor_list[0][1] - state.snake.coor_list[1][1]
        head_dir = [dx, dy]
        reward = 0
        if head_dir == RIGHT:
            for x_coor in range(state.snake.coor_list[0][0] + 1, 16):
                wall_info = state.ctx.get_map().wall_map[x_coor][state.snake.coor_list[0][1]]
                if(wall_info != -1):
                    if(wall_info == state.snake.camp):
                        reward = reward - 1
                    else:
                        reward = reward + 1
        elif head_dir == DOWN:
            for y_coor in range(0, state.snake.coor_list[0][1]):
                wall_info = state.ctx.get_map().wall_map[state.snake.coor_list[0][0]][y_coor]
                if(wall_info != -1):
                    if(wall_info == state.snake.camp):
                        reward = reward - 1
                    else:
                        reward = reward + 1
        elif head_dir == LEFT:
            for x_coor in range(0, state.snake.coor_list[0][0]):
                wall_info = state.ctx.get_map().wall_map[x_coor][state.snake.coor_list[0][1]]
                if(wall_info != -1):
                    if(wall_info == state.snake.camp):
                        reward = reward - 1
                    else:
                        reward = reward + 1
        elif head_dir == UP:
            for y_coor in range(state.snake.coor_list[0][1] + 1, 16):
                wall_info = state.ctx.get_map().wall_map[state.snake.coor_list[0][0]][y_coor]
                if(wall_info != -1):
                    if(wall_info == state.snake.camp):
                        reward = reward - 1
                    else:
                        reward = reward + 1
    if not (certain_death(state)):
        return reward > 0
    else:
        if state.ctx.get_snake_count(state.snake.camp) == 4:
            return reward >= state.snake.get_len()
        elif state.ctx.get_snake_count(state.snake.camp) == 3:
            return reward >= state.snake.get_len() / 2
        else:
            if reward > 0:
                return True #only 1 or 2 snakes, severe disadvantage, survival matters more
            else:
                return False

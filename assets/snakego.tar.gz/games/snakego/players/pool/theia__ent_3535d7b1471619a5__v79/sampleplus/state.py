from copy import deepcopy
from mimetypes import init
from typing import Dict
from adk import *

class MapData:
    width: List[List[int]]
    height: List[List[int]]
    realm_cnt: int
    size: List[int]
    realm_id: Dict
    realm: List[Tuple[int, int]] 
    connection: List[Tuple[int, int]]
    pocket: List[bool]
    corridor_cnt: int
    corridor_id: Dict 
    corridor: List[Tuple[int, int]]
    exit_point: List[Tuple[int, int]]
    dead_end_corridor: List[bool]
    def __init__(self, init_tuple: Tuple[List[List[int]], List[List[int]], int, List[int], Dict, List[Tuple[int, int]], List[Tuple[int, int]], List[bool],\
         int, Dict, List[Tuple[int, int]], List[Tuple[int, int]], List[bool]]):
        self.width = init_tuple[0]
        self.height = init_tuple[1]
        self.realm_cnt = init_tuple[2]
        self.size = init_tuple[3]
        self.realm_id = init_tuple[4]
        self.realm = init_tuple[5]
        self.connection = init_tuple[6]
        self.pocket = init_tuple[7]
        self.corridor_cnt = init_tuple[8]
        self.corridor_id = init_tuple[9]
        self.corridor = init_tuple[10]
        self.exit_point = init_tuple[11]
        self.dead_end_corridor = init_tuple[12]
    def ret_list(self):
        return self.realm_cnt, self.size, self.realm_id, self.realm, self.connection, self.pocket,\
             self.corridor_cnt, self.corridor_id, self.corridor, self.exit_point, self.dead_end_corridor

class State:
    ctx: Context
    snake: Snake
    map_data: MapData
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()
        self.adv_solidify_target = dict()

def construct_dependent_state(cur_ctx, cur_snake, cur_order, cur_ast, cur_md): #use only in checking 
    ret = State()
    ret.ctx = cur_ctx
    ret.snake = cur_snake
    ret.order = cur_order
    ret.adv_solidify_target = cur_ast
    ret.map_data = cur_md
    return ret

def construct_independent_state(cur_ctx, cur_snake, cur_order, cur_ast, cur_md):
    ret = State()
    ret.ctx = deepcopy(cur_ctx)
    ret.snake = deepcopy(cur_snake)
    ret.order = deepcopy(cur_order)
    ret.adv_solidify_target = deepcopy(cur_ast)
    ret.map_data = deepcopy(cur_md)
    return ret

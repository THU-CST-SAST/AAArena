from adk import *
from state import State
from check import *
from melt import *

def count_my_snakes_sol(state: State):
    ret = 0
    for snake_itr in state.ctx.snake_list:
        if snake_itr.camp == state.snake.camp:
            ret += 1
    return ret

def death_strategy_sol(state: State):
    valid = []
    for i in range(4):
        if(check_self(state, i)):
            valid.append(i)
    if len(valid) > 0 and count_my_snakes_sol(state) > 1: #solidify
        return valid[0] + 1
    elif count_my_snakes_sol() < 4 and len(state.snake.coor_list) > 1: #split
        return 6
    elif len(state.snake.item_list) > 0 and melt_is_useful(state) and len(state.snake.coor_list) > 1: #melt my way out
        return 5
    else:
        if state.snake.get_len() == 1: 
            return 1
        else:
            if state.snake.coor_list[0][0] - state.snake.coor_list[1][0] != -1:
                return 1
            else:
                return 2


def solidify(state: State, avoid_list):
    """
    Try to solidify self by forming a 2 * 2 area.
    It requires at most 4 move to solidify.

    :return: direction to move
    """
    if state.snake.id in state.order:
        valid = []
        optimal = dict()
        optimal_list = []
        avoid = dict()
        for avoid_list_item in avoid_list:
            avoid[avoid_list_item[2]] = True
        for op in range(4):
            if check_self(state, op):
                valid.append(op)
                if not(op in avoid):
                    optimal[op] = True
                    optimal_list.append(op)
        rk, order = state.order[state.snake.id]
        state.order[state.snake.id] = rk + 1, order
        if order[rk] % 4 in optimal:  # not the first move, follow the previous move
            return order[rk] % 4 
        else: #following previous move is not an optimal strategy
            state.order.pop(state.snake.id) #re-enter the solidify process next turn
            if len(optimal_list) > 0:
                return optimal_list[random.randint(0, len(optimal_list) - 1)] #don't harm teammates
            elif len(valid) > 0:
                return valid[random.randint(0, len(valid) - 1)] #then at least don't die by suicide
            else:
                return death_strategy_sol(state) #go die...
    else:
        for i in range(4):
            if check_self(state, i):
                order = [i, i + 1, i + 2, i + 3]
                state.order.update({state.snake.id: (1, order)})
                return i % 4
        # the first move, choose a legal direction at store it in self.order
        return 0

def adv_solidify(state: State, avoid_list): #for length >= ADV_SOLIDIFY_THRESHOLD
    #further improvements pending...
    for i in range(state.snake.get_len()):
        if manhattan(state.snake.coor_list[i][0], state.snake.coor_list[i][1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) == 1\
            and i >= int((int(state.snake.get_len() / 2) - 1) * 1.7):
                #sys.stderr.write("At turn " + str(state.ctx.turn) + ", adv_solidify!\n")
                #sys.stderr.write("snake id = " + str(state.snake.id))
                #sys.stderr.write("\ntarget = " + str(state.snake.coor_list[i]) + "\n")
                delta_x = state.snake.coor_list[i][0] - state.snake.coor_list[0][0]
                delta_y = state.snake.coor_list[i][1] - state.snake.coor_list[0][1]
                #sys.stderr.write("ep0: " + str((delta_x, delta_y)) + "\n")
                #sys.stderr.flush()
                if delta_x == 1:
                    return 0
                elif delta_x == -1:
                    return 2
                elif delta_y == 1:
                    return 1
                else:
                    return 3

    valid = dict()
    for i in range(4):
        if check_self(state, i):
            valid[i] = True
    dist_table, prev = get_deterministic_bfs_dist(state)
    if not(state.snake.id in state.adv_solidify_target) or (state.snake.id in state.adv_solidify_target and state.snake.get_len() != state.adv_solidify_target[state.snake.id][3]):
        #sys.stderr.write("At turn " + str(state.ctx.turn) + ", adv_solidify!\n")
        state.adv_solidify_target[state.snake.id] = [(-1, -1), 0, (-1, -1), state.snake.get_len()]
        target_body_tile = (-1, -1)
        target_empty_tile = (-1, -1)
        for i in range(state.snake.get_len() - 2, int((state.snake.get_len() - 1) / 2) - 1, -1):
            min, min_direction = INF, -1
            op_list = []
            for op in range(4):
                tmp_x = state.snake.coor_list[i][0] + dx[op]
                tmp_y = state.snake.coor_list[i][1] + dy[op]
                if tmp_x > 15 or tmp_x < 0 or tmp_y > 15 or tmp_y < 0:
                    continue
                if(dist_table[tmp_x][tmp_y] <= ADV_SOLIDIFY_ABORT):
                    op_list.append((op, dist_table[tmp_x][tmp_y]))
                    if dist_table[tmp_x][tmp_y] < min:
                        min = dist_table[tmp_x][tmp_y]
                        min_direction = op
            if min_direction == -1 or min > 10:
                continue
            op_list.sort(key= lambda x:x[1], reverse= True)
            #sys.stderr.write("dist_list, i " + str(op_list) + " " + str(i) + "\n")
            #sys.stderr.flush()
            break_flag = False
            for op_list_item in op_list:
                if op_list_item[1] + 1 <= state.snake.get_len() - 1 - i:
                    target_body_tile = state.snake.coor_list[i]
                    target_empty_tile = (target_body_tile[0] + dx[min_direction], target_body_tile[1] + dy[min_direction])
                    state.adv_solidify_target[state.snake.id][0] = (target_body_tile[0], target_body_tile[1])
                    state.adv_solidify_target[state.snake.id][2] = (target_empty_tile[0], target_empty_tile[1])
                    break_flag = True
                    break
            if break_flag:
                break
        if target_body_tile[0] == -1:
            #sys.stderr.write("abort, tgt_body_tile = -1\n")
            state.adv_solidify_target.pop(state.snake.id)
            return -1
    else:
        target_body_tile = state.adv_solidify_target[state.snake.id][0]
        state.adv_solidify_target[state.snake.id][1] += 1
        target_empty_tile = state.adv_solidify_target[state.snake.id][2]

    #sys.stderr.write("snake id = " + str(state.snake.id))
    #sys.stderr.write("\ntarget = " + str(target_empty_tile))
    #sys.stderr.write("\nadv_tgt = " + str(state.adv_solidify_target[state.snake.id]) + "\n")
    #sys.stderr.flush()

    if manhattan(target_body_tile[0], target_body_tile[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1]) == 1\
        and state.snake.coor_list[0][0] == target_empty_tile[0] and state.snake.coor_list[0][1] == target_empty_tile[1]:
        delta_x = target_body_tile[0] - state.snake.coor_list[0][0]
        delta_y = target_body_tile[1] - state.snake.coor_list[0][1]
        state.adv_solidify_target.pop(state.snake.id)
        #sys.stderr.write("ep1: " + str((delta_x, delta_y)) + "\n")
        #sys.stderr.flush()
        if delta_x == 1:
            return 0
        elif delta_x == -1:
            return 2
        elif delta_y == 1:
            return 1
        else:
            return 3
    
    if (state.snake.coor_list[0][0] == target_body_tile[0] and state.snake.coor_list[0][1] == target_body_tile[1])\
        or state.adv_solidify_target[state.snake.id][1] >= ADV_SOLIDIFY_ABORT:
        #sys.stderr.write("abort! abort limit reached or invalid target\n")
        #sys.stderr.flush()
        state.adv_solidify_target.pop(state.snake.id)
        return -1

    avoid = dict()
    #if len(avoid_list) > 0:
        #sys.stderr.write("avoid list for snake " + str(state.snake.id) +" at turn " + str(state.ctx.turn) + ": " + str(avoid_list) + "\n")
        #sys.stderr.flush()
    for avoid_list_item in avoid_list:
        avoid[avoid_list_item[0]] = True
    
    pos = -1
    pos_elem = target_empty_tile[0] * 16 + target_empty_tile[1]
    if pos_elem == -1:
        #sys.stderr.write("At turn " + str(state.ctx.turn) + ", in adv_sol pos elem = -1\n")
        #sys.stderr.write("snake id = " + str(state.snake.id))
        #sys.stderr.write("\ntarget = " + str(target_empty_tile))
        #sys.stderr.write("\nadv_tgt = " + str(state.adv_solidify_target[state.snake.id]) + "\n")
        #sys.stderr.flush()
        state.adv_solidify_target.pop(state.snake.id)
        return -1
        
    if dist_table[target_empty_tile[0]][target_empty_tile[1]] == INF or not(pos_elem in prev):
        #sys.stderr.write("abort, target occupied\n")
        #sys.stderr.flush()
        state.adv_solidify_target.pop(state.snake.id)
        return -1

    if prev[pos_elem] == -1:
       head = pos_elem
    else:
        while prev[prev[pos_elem]] != -1:
            pos_elem = prev[pos_elem]
        head = prev[pos_elem]

    #if(head != state.snake.coor_list[0][0] * 16 + state.snake.coor_list[0][1]):
        #sys.stderr.write("prev head parse error\n")
        #sys.stderr.flush()
    if pos_elem - head == 16:
        pos = 0
    elif pos_elem - head == -16:
        pos = 2
    elif pos_elem - head == 1:
        pos = 1
    elif pos_elem - head == -1:
        pos = 3
    
    if pos == -1 or pos in avoid or not(pos in valid):
        #sys.stderr.write("abort, " + str(pos) + " not valid move\n")
        #sys.stderr.flush()
        state.adv_solidify_target.pop(state.snake.id)
        return -1
    #sys.stderr.write("pos: " + str(pos) + "\n")
    #sys.stderr.flush()
    return pos
    

    

    




from operator import itemgetter
from tabnanny import check
from adk import *
import copy

# written by lbr

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]

dx2 = [1, 0, -1, 0, 1, 1, -1, -1, 2, 0, -2, 0]
dy2 = [0, 1, 0, -1, 1, -1, 1, -1, 0, 2, 0, -2]
INF = 1e9
# constants

SEARCH_LIMIT = 16
# tunable parameters


class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """

    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()

    def totmap(self):
        totMap = []
        for i in range(16):
            totMap.append([])
            for j in range(16):
                if self.ctx.game_map.snake_map[i][j] > -1 or self.ctx.game_map.wall_map[i][j] > -1:
                    totMap[i].append(-1)
                else:
                    totMap[i].append(0)
        return totMap

    def calc_dist(self, x1, y1, x2, y2):
        """
        Calculate the Manhattan distance between snake head and item.
        And find the possible direction to the item, at most 2.

        :return: (dist, possible_direction)
        """
        pos = []
        if x1 > x2:
            for i in range(x1 - x2):
                pos.append(0)
        if x1 < x2:
            for i in range(x2 - x1):
                pos.append(2)
        if y1 > y2:
            for i in range(y1 - y2):
                pos.append(1)
        if y1 < y2:
            for i in range(y2 - y1):
                pos.append(3)
        return abs(x1 - x2) + abs(y1 - y2), pos

    def DFS(self, wall, x, y):
        if x < 0 or y < 0 or x >= 16 or y >= 16 or wall[x][y] == -1:
            return 0
        wall[x][y] = -1
        return 1 + self.DFS(wall, x + 1, y) + self.DFS(wall, x, y + 1) + self.DFS(wall, x - 1, y) + self.DFS(wall, x, y - 1)

    def check(self, Snake, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = Snake.coor_list[0][0] + dx[op]
        y = Snake.coor_list[0][1] + dy[op]
        wallMap = self.totmap()
        if Snake.length_bank == 0:
            wallMap[Snake.coor_list[-1][0]][Snake.coor_list[-1][1]] = 0

        if x < 0 or y < 0 or x >= 16 or y >= 16 or wallMap[x][y] == -1:
            return False

        return True

    def check_D(self, Snake, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in death.
                 False otherwise.
        """

        x = Snake.coor_list[0][0] + dx[op]
        y = Snake.coor_list[0][1] + dy[op]
        wallMap = self.totmap()
        if Snake.length_bank == 0:
            wallMap[Snake.coor_list[-1][0]][Snake.coor_list[-1][1]] = 0

        if x < 0 or y < 0 or x >= 16 or y >= 16 or wallMap[x][y] == -1:
            return False
        # check walls and snakes

        D = self.DFS(wallMap, x, y)
        if D < Snake.get_len():
            return False
        # check if the area is too small

        for SSnake in self.ctx.snake_list:
            if Snake.camp != SSnake.camp and Snake.get_len() > 1:
                if self.calc_dist(SSnake.coor_list[0][0], SSnake.coor_list[0][1], x, y) == 2:
                    val = 0
                    for i in range(4):
                        x1, y1 = x + dx[i], y + dy[i]
                        wMap = self.totmap()
                        wMap[x][y] = -1
                        if Snake.length_bank == 0:
                            wMap[Snake.coor_list[-1][0]
                                 ][Snake.coor_list[-1][1]] = 0
                        if self.DFS(wMap, x1, y1) >= Snake.get_len():
                            val += 1
                            if self.calc_dist(SSnake.coor_list[0][0], SSnake.coor_list[0][1], x1, y1) > 1:
                                val += 1
                    if val <= 1:
                        return False
        # check enemy snakes
        return True

    def check_self(self, Snake, op):
        """
        :param op: the direction
        :return: 0 or positive if this move is legal, could possibly result in solidification.
                 -1 otherwise.
        """
        x = Snake.coor_list[0][0] + dx[op]
        y = Snake.coor_list[0][1] + dy[op]

        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return -1
        if Snake.get_len() > 2 and x == Snake.coor_list[1][0] and y == Snake.coor_list[1][1]:
            return -1
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != Snake.id:
            return -1
        for i in range(3, Snake.get_len() - 1, 2):
            if Snake.coor_list[i] == (x, y):
                return i
        return 0

    def closest_food_strategy(self):
        """
        Search for the closest food and to go that direction, if legal.

        :return: the chosen direction
        """
        if self.ctx.get_snake_count(self.snake.camp) == 4:
            for Snake in self.ctx.snake_list:
                if Snake.camp == self.snake.camp and Snake != self.snake and Snake.get_len() + Snake.length_bank > self.snake.get_len() + self.snake.length_bank:
                    val = []
                    for op in range(4):
                        if self.check_self(Snake, op) > -1:
                            val.append(op)
                    if len(val) == 0:
                        for i in range(4):
                            X, Y = Snake.coor_list[0][0] + \
                                dx[i], Snake.coor_list[0][1] + dy[i]
                            if 0 <= X < 16 and 0 <= Y < 16 and self.ctx.game_map.snake_map[X][Y] == self.snake.id:
                                for D in range(4):
                                    if self.check(self.snake, D) == 0:
                                        x = self.snake.coor_list[0][0] + dx[D]
                                        y = self.snake.coor_list[0][1] + dy[D]
                                        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
                                            continue
                                        return D
        # suicide to protect longer allies

        valid = []
        valt = []
        for i in range(4):
            if self.check_D(self.snake, i):
                valt.append(i)
                flag = 0
                for Snake in self.ctx.snake_list:
                    if Snake.camp == self.snake.camp and Snake != self.snake and Snake.get_len() + Snake.length_bank > (self.snake.get_len() + self.snake.length_bank) / 2:
                        val = []
                        for op in range(4):
                            if self.check(Snake, op):
                                val.append(op)
                        if len(val) == 1:
                            op = val[0]
                            X, Y = Snake.coor_list[0][0] + \
                                dx[op], Snake.coor_list[0][1] + dy[op]
                            if X == self.snake.coor_list[0][0] + dx[i] and Y == self.snake.coor_list[0][1] + dy[i]:
                                flag = 1
                                break
                if flag == 0:
                    valid.append(i)
                # Don't kill your allies!

        if len(valid) == 0:
            valid = valt

        if len(valid) == 0:
            for i in range(4):
                if self.check(self.snake, i):
                    valid.append(i)

        if len(valid) == 0 and self.snake.get_len() > 1 and len(self.snake.item_list) > 0:
            x1, y1 = self.snake.coor_list[0]
            x2, y2 = self.snake.coor_list[1]
            direction = (x1 - x2, y1 - y2)
            if direction == (-1, 0):
                Iter = range(self.snake.coor_list[0][0], -1, -1)
            if direction == (0, -1):
                Iter = range(self.snake.coor_list[0][1], -1, -1)
            if direction == (1, 0):
                Iter = range(self.snake.coor_list[0][0], 16)
            if direction == (0, 1):
                Iter = range(self.snake.coor_list[0][1], 16)

            wallMap = self.totmap()
            x, y = self.snake.coor_list[0]
            for i in Iter:
                if direction[0] == 0:
                    y = i
                else:
                    x = i
                if self.ctx.game_map.wall_map[x][y] != -1:
                    wallMap[x][y] = 0
            if self.DFS(wallMap, x1, y1) >= self.snake.get_len() and self.fire_gain(x1, y1, direction) > - self.snake.get_length():
                return 4
        # fire when necessary

        if len(valid) == 0 and self.snake.get_len() > 1 and self.ctx.get_snake_count(self.snake.camp) <= 3:
            return 5
        # split when necessary

        if len(valid) == 0:
            maxl = 0
            for i in range(4):
                if self.check_self(self.snake, i) > maxl:
                    maxl = self.check_self(self.snake, i)
                    mID = i
            if maxl > 0:
                return mID
        # solidify when necessary

            if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                return 1
            return 0
        # calculate the legal moves without concerning the food

        coor = self.snake.coor_list
        dist, val, gain, = INF, [], 0

        for item in self.ctx.game_map.item_list:
            if item.type != 0 and (self.ctx.turn < 64 or len(self.snake.item_list) > 0 or self.snake.get_len() == 1):
                continue
            # search food only when have fire

            if item.time > self.ctx.turn + SEARCH_LIMIT or item.time + SEARCH_LIMIT < self.ctx.turn:
                continue
            # search valid food only

            wallMap = self.totmap()
            if wallMap[item.x][item.y] == -1:
                continue
            count = 0
            for i in range(4):
                xn, yn = item.x + dx[i], item.y + dy[i]
                if 0 <= xn < 16 and 0 <= yn < 16 and (wallMap[xn][yn] == 0 or self.snake.coor_list[0] == (xn, yn)):
                    count += 1
            if count <= 1:
                continue

            def dijkstra(wall, now, goal, dist):
                New = []
                Can = []
                for place in now:
                    for op in range(4):
                        xn, yn = place[0] + dx[op], place[1] + dy[op]
                        if 0 <= xn < 16 and 0 <= yn < 16:
                            if (xn, yn) == goal:
                                Can.append((op + 2) % 4)
                            if wall[xn][yn] == 0:
                                wall[xn][yn] = dist + 1
                                New.append((xn, yn))
                if len(Can) > 0:
                    return dist + 1, Can
                if len(New) == 0:
                    return INF, Can
                return dijkstra(wall, New, goal, dist+1)

            d, pos = dijkstra(wallMap, [(item.x, item.y)], coor[0], 0)
            if d == INF:
                continue
            # use legal move only

            flag = 0
            for Snake in self.ctx.snake_list:
                if Snake.camp != self.snake.camp or Snake == self.snake:
                    continue
                di, _ = dijkstra(
                    wallMap, [(item.x, item.y)], Snake.coor_list[0], 0)
                if di < d:
                    flag = 1
                    break
            if flag:
                continue
            # only choose food which can be got

            if item.type == 0:
                g = item.param
            else:
                g = 2
            if g / d > gain / dist and item.time <= d + self.ctx.turn <= item.time + SEARCH_LIMIT:
                dist, val, gain = d, pos, g
            # search the nearest and highest-value food

        # choose the closest reachable food and use legal move

        maxgain = 1
        if len(self.snake.item_list) > 0:
            for j in val:
                g = self.fire_gain(coor[0][0], coor[0][1], (dx[j], dy[j]))
                if maxgain < g:
                    maxgain = g
                    op = j
            if maxgain > 2:
                return op

        if len(val) == 0:
            val = copy.copy(valid)

        if self.snake.get_len() > 1:
            for op in valid:
                if self.snake.coor_list[0][0] - dx[op] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] - dy[op] == self.snake.coor_list[1][1]:
                    if op in val:
                        val.append(op)

        MaxDFS = 0
        Tval = []
        for op in val:
            wallMap = self.totmap()
            x = self.snake.coor_list[0][0] + dx[op]
            y = self.snake.coor_list[0][1] + dy[op]
            D = self.DFS(wallMap, x, y)
            if MaxDFS == D:
                Tval.append(op)
            if MaxDFS < D:
                Tval = [op]
                MaxDFS = D
        val = Tval
        # choose the widest direction

        if random.random() > 0.8:
            i = random.randint(0, len(val) - 1)
            return val[i]
        # randomly chose one if multiple available
        else:
            MaxD = 0
            Tval = []
            for i in val:
                minD = INF
                x2, y2 = self.snake.coor_list[0][0] + \
                    dx[i], self.snake.coor_list[0][1] + dy[i]
                for Snake in self.ctx.snake_list:
                    if Snake.camp == self.snake.camp and Snake != self.snake:
                        x1, y1 = Snake.coor_list[0]
                        Di, _ = self.calc_dist(x1, y1, x2, y2)
                        if minD > Di:
                            minD = Di
                if minD == MaxD:
                    Tval.append(i)
                if minD > MaxD:
                    MaxD = minD
                    Tval = [i]
            i = random.randint(0, len(Tval) - 1)
            return Tval[i]
        # choose the direction away from allies

    def fire_gain(self, X, Y, op):
        """
        Strategy for the active snake with fire. Changes with time.
        Fire when your walls are less than enemy.
        """
        gain = 0
        if op == (-1, 0):
            Iter = range(X, -1, -1)
            y = Y
        if op == (0, -1):
            Iter = range(Y, -1, -1)
            x = X
        if op == (1, 0):
            Iter = range(X, 16)
            y = Y
        if op == (0, 1):
            Iter = range(Y, 16)
            x = X
        for i in Iter:
            if op[0] == 0:
                y = i
            else:
                x = i
            if self.ctx.game_map.wall_map[x][y] == self.snake.camp:
                gain -= 1
            if self.ctx.game_map.wall_map[x][y] == 1 - self.snake.camp:
                gain += 1
        return gain

    def active_strategy(self):
        """
        Strategy for the active snake. Split whenever limit is reached for the longest.
        Fire whenever condition is reached. Otherwise search for food.
        """

        maxlen, ID = INF, self.snake.id
        x = self.snake.coor_list[0][0]
        y = self.snake.coor_list[0][1]
        NMap = self.totmap()
        for Snake in self.ctx.snake_list:
            if Snake.camp != self.snake.camp:
                continue
            if maxlen <= Snake.get_len():
                maxlen = Snake.get_len()
                ID = Snake.id
        if len(self.snake.coor_list) >= 4 + (self.ctx.turn//128) * 4 and self.ctx.get_snake_count(self.snake.camp) <= 2 and self.ctx.turn > 8 and ID == self.snake.id:
            return 6
        elif len(self.snake.item_list) > 0 and len(self.snake.coor_list) > 1 and self.fire_gain(x, y, (x - self.snake.coor_list[1][0], y - self.snake.coor_list[1][1])) > 1:
            return 5
        else:
            for Snake in self.ctx.snake_list:
                if Snake.camp != self.snake.camp:
                    val = []
                    for op in range(4):
                        if self.check(Snake, op) == 1:
                            val.append(op)
                    if len(val) == 1:
                        op = val[0]
                        X, Y = Snake.coor_list[0][0] + \
                            dx[op], Snake.coor_list[0][1] + dy[op]
                        for i in range(4):
                            if X == x + dx[i] and Y == y + dy[i]:
                                return i + 1
            return self.closest_food_strategy() + 1

    def solidify_strategy(self):
        """
        Try to solidify self by forming a k * l area.
        :return: direction to move
        """

        k = (self.snake.get_len() - 1) // 4
        l = (self.snake.get_len() - 1) // 2 - k
        if self.snake.id in self.order and self.order[self.snake.id][1] == self.snake.get_len():
            rk, _, order = self.order[self.snake.id]
            self.order[self.snake.id] = rk + 1, self.snake.get_len(), order
            if self.check_self(self.snake, order[rk % len(order)] % 4) >= 0:
                return order[rk % len(order)] % 4
            # not the first move, follow the previous move

        for i in range(4):
            if self.check_self(self.snake, i) >= 0:
                order = []
                p = random.random()
                for j in range(k):
                    order.append(i)
                if p > 0.5:
                    for j in range(l):
                        order.append(i + 1)
                else:
                    for j in range(l):
                        order.append(i + 3)
                for j in range(k):
                    order.append(i + 2)
                if p > 0.5:
                    for j in range(l):
                        order.append(i + 3)
                else:
                    for j in range(l):
                        order.append(i + 1)
                self.order.update(
                    {self.snake.id: (1, self.snake.get_len(), order)})
                return i % 4
        # the first move, choose a legal direction at store it in self.order
        return 0

    def passive_strategy(self):
        """
        Strategy for passive snake.
        Get food when near enough. Else solidify.
        """

        valid = []
        for i in range(4):
            if self.check_D(self.snake, i):
                valid.append(i)
        if len(valid) == 0:
            if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                return 2
            return 1
        # calculate the legal moves without concerning the food

        coor = self.snake.coor_list
        dist, val = INF, []
        for item in self.ctx.game_map.item_list:
            if item.type != 0:
                continue
            # search food only

            if item.time > self.ctx.turn + 1 or item.time + SEARCH_LIMIT < self.ctx.turn:
                continue
            # search exist food only

            d, pos = self.calc_dist(item.x, item.y, coor[0][0], coor[0][1])
            pos = [i for i in pos if i in valid]
            # use legal move only

            if len(pos) > 0 and d < dist and item.time <= d + self.ctx.turn <= item.time + SEARCH_LIMIT:
                dist, val = d, pos

        if len(val) == 0:
            val = valid
        i = random.randint(0, len(val) - 1)

        if dist <= 3:
            return val[i] + 1

        if self.snake.get_len() > 8:
            return self.solidify_strategy() + 1

        return self.active_strategy()

    def judge(self, snake, ctx):
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        """
        self.ctx = ctx
        self.snake = snake

        minlen, ID = INF, snake.id
        for Snake in ctx.snake_list:
            if Snake.camp != snake.camp:
                continue
            if minlen <= Snake.get_len():
                minlen = Snake.get_len()
                ID = Snake.id

        if ctx.turn <= 4:
            return ID + 1
        if ctx.turn <= 8:
            return 4 - ID

        if ctx.get_snake_count(snake.camp) - 1 > ctx.get_snake_count(1 - snake.camp):
            if ID == snake.id and snake.get_len() > 8:
                return self.passive_strategy()
        return self.active_strategy()


def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    # game config
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0

    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI()
    while playing:
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                # TODO: Complete the Judge Function
                op = ai.judge(current_snake, controller.ctx)
                logging.debug(str(op))
                if not controller.apply(op):
                    pass
                    # raise RuntimeError("Illegal Action!!!")
                c.send_data(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:
        pass

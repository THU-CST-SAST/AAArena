#include "adk.hpp"
#include <cmath>
#include<vector>
using namespace std;

const int dx[4] = { 1, 0, -1, 0 };
const int dy[4] = { 0, 1, 0, -1 };
int movement[4];

struct Node{
    Coord position;
    int distance;
    Node(){
        position.x = -1;
        position.y = -1;
        distance = 999;
    }
};
class DjPoint{
	public:
    int distance;
    bool set;
    bool inBox;
	Coord from;
    DjPoint(){
        distance = 999;
        set = false;
        inBox = false;
		from.x = -1;
		from.y = -1;
    }
	void Set(){
		distance = 999;
        set = false;
        inBox = false;
		from.x = -1;
		from.y = -1;
	}
};
DjPoint Dj_map[50][50];
class Dijkstra{
	vector<Node> _data;
	public:
	Dijkstra(){
		_data.clear();
	}
	void push_back(Node temp){
		_data.push_back(temp);
	}
	void erase(int index){
		_data.erase(_data.begin() + index);
	}
	bool empty(){
		return _data.empty();
	}
	int GetMin(){
		int index = 0;
        int min_dis = 999;
        for(int i = 0; i < _data.size(); i++){
            if(_data[i].distance < min_dis){
                min_dis = _data[i].distance;
                index = i;
            }
        }
        return index;
	}
	int BoxFind(int x, int y){
        int i = 0;
        for(; i < _data.size(); i++){
            if((_data[i].position.x == x) && (_data[i].position.y == y)){
                return i;
            }
        }
        return i;
    }
	Node& operator[](int index){
        return _data[index];
    }
};

class Point{
	public:
	bool reachable;
	int distance;
	Coord father;
	int root;
	Point(){
		reachable = false;
		distance = 999;
		father.x = -1;
		father.y = -1;
		root = -1;
	}
	void Set(){
		reachable = false;
		distance = 999;
		father.x = -1;
		father.y = -1;
		root = -1;
	}
};
Point point_map[50][50];

bool DirectionSameMatrix[4][4];
bool SafeDireciton[4];

// functions
bool MeltStrategy(const Snake& snake_to_operate, const Context& ctx);
bool SplitStrategy(const Snake& snake_to_operate, const Context& ctx);
void MoveSet(const Snake& snake_to_operate, const Context& ctx);
bool EmptyPointCheck(int x, int y, const Context& ctx);
void DjPath(const Snake& snake_to_operate, const Context& ctx);
void GoRight(int x, int y,int root, const Context& ctx);
void GoLeft(int x, int y,int root, const Context& ctx);
void GoUp(int x, int y,int root, const Context& ctx);
void GoDown(int x, int y,int root, const Context& ctx);
void RootSet(const Snake& snake_to_operate, const Context& ctx);
int DestinationOrientateMove(Coord dest, const Snake& snake_to_operate);
int PropStratgy(const Snake& snake_to_operate, const Context& ctx);
int ToLeft(Coord p, Coord q, Coord s);
int TailStrategy(const Snake& snake_to_operate, const Context& ctx);

Operation make_your_decision( const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_list ){
	// fprintf( stderr, "%s %d\n", "current round:", ctx.current_round() );
	// fprintf( stderr, "%s %d\n", "snake id:", snake_to_operate.id );
	
	// melt check
	if(MeltStrategy(snake_to_operate, ctx)){
		return OP_RAILGUN;
	}

	// split check
	if(SplitStrategy(snake_to_operate, ctx)){
		return OP_SPLIT;
	}

	Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };

	MoveSet(snake_to_operate, ctx);

	for(int i = 0; i < ctx.length(); i++){
		for(int j = 0; j < ctx.width(); j++){
			point_map[i][j].Set();
		}
	}
	DjPath(snake_to_operate, ctx);
	// fprintf( stderr, "%s\n", "Djpath ok" );

	if(snake_to_operate.length() >= 15){
		int tail_startegy = TailStrategy(snake_to_operate, ctx);
		if(tail_startegy != -1){
			// tail trategy ok
			return direction[tail_startegy];
		}
	}
	
	// fprintf( stderr, "%s\n", "tail strategy ok" );

	RootSet(snake_to_operate, ctx);
	// fprintf( stderr, "%s\n", "root ok" );

	// prop strategy
	int prop_num = PropStratgy(snake_to_operate, ctx);
	if(prop_num != -1){
		// fprintf( stderr, "%s\n", "Prop in" );
		Coord current;
		current.x = ctx.item_list()[prop_num].x;
		current.y = ctx.item_list()[prop_num].y;
		Coord next = point_map[current.x][current.y].father;
		while(!((next.x == snake_to_operate.coord_list[0].x) && (next.y == snake_to_operate.coord_list[0].y))){
			// fprintf( stderr, "%s %d %d\n", "current:", current.x, current.y );
			current = next;
			next = point_map[current.x][current.y].father;
		}

		int dir = DestinationOrientateMove(current, snake_to_operate);
		if(SafeDireciton[dir] == true){
			return direction[dir];
		}
	}
	// fprintf( stderr, "%s\n", "Prop ok" );

	// normal move
	for(int dir = 0; dir < 4; dir++){
		if((movement[dir] == 0) && (SafeDireciton[dir] == true)){
			return direction[dir];
		}
	}
	// fprintf( stderr, "%s\n", "normal move ok" );

	// solidation
	for(int dir = 0; dir < 4; dir++){
		if(movement[dir] == 10){
			return direction[dir];
		}
	}
	// fprintf( stderr, "%s\n", "solidation ok" );

	for(int i = 0; i < 4; i++){
		if(movement[i] == 0){
			return direction[i];
		}
	}

	// no way to go
	// check rail gun
	if (snake_to_operate.railgun_item.id != -1){
		// do not have railgun
		if(snake_to_operate.length() > 1){
			return OP_RAILGUN;
		}
	}

	// check split
	if(ctx.my_snakes().size() < 4 && snake_to_operate.length() > 1){
		// check split conditions
		return OP_SPLIT;
	}

	// kill itself
	for(int dir = 0; dir < 4; dir++){
		if(movement[dir] == -1){
			return direction[dir];
		}
	}

}

void game_over( int gameover_type, int winner, int p0_score, int p1_score ){
	// fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char** argv ) { SnakeGoAI start( argc, argv ); }


int Min(int a, int b){
	if(a < b){
		return a;
	}else{
		return b;
	}
}
int Max(int a, int b){
	if(a > b){
		return a;
	}else{
		return b;
	}
}

int ToLeft(Coord p, Coord q, Coord s){
	return p.x * q.y - p.y * q.x + q.x * s.y - q.y * s.x + s.x * p.y - s.y * p.x;
}
int TailStrategy(const Snake& snake_to_operate, const Context& ctx){
	int head_to_tail = abs( snake_to_operate.coord_list.back().x - snake_to_operate.coord_list[0].x ) +
					abs( snake_to_operate.coord_list.back().y - snake_to_operate.coord_list[0].y );
	if(head_to_tail == 1){
		Coord target;
		target.x = snake_to_operate.coord_list.back().x;
		target.y = snake_to_operate.coord_list.back().y;
		return DestinationOrientateMove(target, snake_to_operate);
	}
	
	// calculte convex hull
	// find all the corner in snake
	vector<Coord> corner;
	Coord head = snake_to_operate.coord_list[0];
	Coord tail = snake_to_operate.coord_list.back();
	for(int i = 1; i < snake_to_operate.coord_list.size() - 1; i++){
		Coord current = snake_to_operate.coord_list[i];
		Coord previous = snake_to_operate.coord_list[i - 1];
		Coord after = snake_to_operate.coord_list[i + 1];

		// check if previous and after are algin
		if((previous.x != after.x) && (previous.y != after.y)){
			corner.push_back(current);
		}
	}

	vector<Coord> extreme_points;


	// basic tail strategy
	int tail_x = snake_to_operate.coord_list.back().x;
	int tail_y = snake_to_operate.coord_list.back().y;
	
	// find a cloesest block
	Coord block_position;
	int min_dis = 999;
	for(int dir = 0; dir < 4; dir++){
		int t_x = tail_x + dx[dir];
		int t_y = tail_y + dy[dir];
		if(EmptyPointCheck(t_x, t_y, ctx)){
			if(point_map[t_x][t_y].distance < min_dis){
				min_dis = point_map[t_x][t_y].distance;
				block_position.x = t_x;
				block_position.y = t_y;
			}
		}
	}

	if(min_dis == 999){
		// tail is inaccessible
		return -1;
	}

	Coord current = block_position;

	Coord next = point_map[current.x][current.y].father;
	while(!((next.x == snake_to_operate.coord_list[0].x) && (next.y == snake_to_operate.coord_list[0].y))){
		current = next;
		next = point_map[current.x][current.y].father;
	}

	return DestinationOrientateMove(current, snake_to_operate);
}

void GoRight(int x, int y,int root, const Context& ctx){
	// empty check
	if(EmptyPointCheck(x, y, ctx) == false){
		return;
	}

	if(point_map[x][y].root != -1){
		if(point_map[x][y].root != root){
			// set matrix
			int tmin = Min(root, point_map[x][y].root);
			int tmax = Max(root, point_map[x][y].root);

			DirectionSameMatrix[tmin][tmax] = true;
		}
		return;
	}

	point_map[x][y].root = root;

	GoRight(x + 1, y, root, ctx);
	GoUp(x, y + 1, root, ctx);
	GoDown(x, y - 1, root, ctx);

	return;
}
void GoLeft(int x, int y,int root, const Context& ctx){
	// empty check
	if(EmptyPointCheck(x, y, ctx) == false){
		return;
	}

	if(point_map[x][y].root != -1){
		if(point_map[x][y].root != root){
			// set matrix
			int tmin = Min(root, point_map[x][y].root);
			int tmax = Max(root, point_map[x][y].root);

			DirectionSameMatrix[tmin][tmax] = true;
		}
		return;
	}

	point_map[x][y].root = root;

	GoLeft(x - 1, y, root, ctx);
	GoUp(x, y + 1, root, ctx);
	GoDown(x, y - 1, root, ctx);

	return;
}
void GoUp(int x, int y,int root, const Context& ctx){
	// empty check
	if(EmptyPointCheck(x, y, ctx) == false){
		return;
	}

	if(point_map[x][y].root != -1){
		if(point_map[x][y].root != root){
			// set matrix
			int tmin = Min(root, point_map[x][y].root);
			int tmax = Max(root, point_map[x][y].root);

			DirectionSameMatrix[tmin][tmax] = true;
		}
		return;
	}

	point_map[x][y].root = root;

	GoUp(x, y + 1, root, ctx);
	GoLeft(x - 1, y, root, ctx);
	GoRight(x + 1, y, root, ctx);

	return;
}
void GoDown(int x, int y,int root, const Context& ctx){
	// empty check
	if(EmptyPointCheck(x, y, ctx) == false){
		return;
	}

	if(point_map[x][y].root != -1){
		if(point_map[x][y].root != root){
			// set matrix
			int tmin = Min(root, point_map[x][y].root);
			int tmax = Max(root, point_map[x][y].root);

			DirectionSameMatrix[tmin][tmax] = true;
		}
		return;
	}

	point_map[x][y].root = root;

	GoDown(x, y - 1, root, ctx);
	GoLeft(x - 1, y, root, ctx);
	GoRight(x + 1, y, root, ctx);

	return;
}
void RootSet(const Snake& snake_to_operate, const Context& ctx){
	// set DirectionSameMatrix
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			DirectionSameMatrix[i][j] = false;
		}
	}
	// set safe direction
	for(int i = 0; i < 4; i++){
		SafeDireciton[i] = false;
	}

	// start from 4 directions
	Coord head = snake_to_operate.coord_list[0];
	Coord target;
	// right
	target.x = head.x + dx[0];
	target.y = head.y + dy[0];
	if(point_map[target.x][target.y].root == -1){
		point_map[target.x][target.y].root = 0;
		GoRight(target.x, target.y, 0, ctx);
	}

	// up
	target.x = head.x + dx[1];
	target.y = head.y + dy[1];
	if(point_map[target.x][target.y].root == -1){
		point_map[target.x][target.y].root = 1;
		GoUp(target.x, target.y, 1, ctx);
	}

	// left
	target.x = head.x + dx[2];
	target.y = head.y + dy[2];
	if(point_map[target.x][target.y].root == -1){
		point_map[target.x][target.y].root = 2;
		GoLeft(target.x, target.y, 2, ctx);
	}

	// down
	target.x = head.x + dx[3];
	target.y = head.y + dy[3];
	if(point_map[target.x][target.y].root == -1){
		point_map[target.x][target.y].root = 3;
		GoDown(target.x, target.y, 3, ctx);
	}

	for(int i = 1; i < snake_to_operate.coord_list.size(); i++){
		Coord current = snake_to_operate.coord_list[i];
		for(int j = 0; j < 4; j++){
			Coord target;
			target.x = current.x + dx[j];
			target.y = current.y + dy[j];
			if(EmptyPointCheck(target.x, target.y, ctx)){
				int root = point_map[target.x][target.y].root;
				if(root != -1){
					SafeDireciton[root] = true;
				}
			}
		}
	}

	for(int i = 0; i < 4; i++){
		if(SafeDireciton[i] == true){
			for(int j = i + 1; j < 4; j++){
				if(DirectionSameMatrix[i][j] == true){
					SafeDireciton[j] = true;
				}
			}
		}
	}

	return;
}

int DestinationOrientateMove(Coord dest, const Snake& snake_to_operate){
	// 0 for right, 1 for up, 2 for left, 3 for down
	int snake_x = snake_to_operate.coord_list[0].x;
	int snake_y = snake_to_operate.coord_list[0].y;

	if(snake_x == dest.x){
		// up and down
		if(dest.y > snake_y){
			// up
			return 1;
		}
		if(dest.y < snake_y){
			return 3;
		}
	}

	if(snake_y == dest.y){
		if(dest.x > snake_x){
			return 0;
		}
		if(dest.x < snake_x){
			return 2;
		}
	}
}
int PropStratgy(const Snake& snake_to_operate, const Context& ctx){
	// return prop number, if not found retrun -1
	// find closest prop

	int ret_num = -1;
	int min_dis = 999;
	// find first valid prop
	int i = 0;
	for ( ; i < ctx.item_list().size(); i++ ){
		//道具已经消失
		if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() ){
			continue;
		}
		break;
	}

	for(; i <  ctx.item_list().size(); i++){
		// ignore eaten prop
		if(ctx.item_list()[i].eaten == true){
			continue;
		}

		// check in wall
		int prop_x = ctx.item_list()[i].x;
		int prop_y = ctx.item_list()[i].y;
		if(ctx.wall_map()[prop_x][prop_y] != -1){
			continue;
		}

		// check in snake
		if(ctx.snake_map()[prop_x][prop_y] != -1){
			continue;
		}

		int distance = point_map[prop_x][prop_y].distance;
		if ( ctx.item_list()[i].time <= ctx.current_round() + distance &&
				ctx.item_list()[i].time + 16 > ctx.current_round() + distance ){
					if(distance < min_dis){
						min_dis = distance;
						ret_num = i;
					}
				}
	}

	return ret_num;
}

bool EmptyPointCheck(int x, int y, const Context& ctx){
	// checkerboard check
    if(x < 0 || ctx.length() <= x || y < 0 || ctx.width() <= y){
		return false;
	}
	// wall check
	if ( ctx.wall_map()[x][y] != -1 ){
		return false;
	}
	// snake check
	if ( ctx.snake_map()[x][y] != -1 ){
		return false;
	}
	// all check pass
	return true;
}
void DjPath(const Snake& snake_to_operate, const Context& ctx){
	// init
	for(int i = 0; i < ctx.length(); i++){
		for(int j = 0; j < ctx.width(); j++){
			Dj_map[i][j].Set();
		}
	}

	// start point
    int s_x = snake_to_operate.coord_list[0].x;
	int s_y = snake_to_operate.coord_list[0].y;
    Dj_map[s_x][s_y].distance = 0;
	Dj_map[s_x][s_y].from.x = s_x;
	Dj_map[s_x][s_y].from.y = s_y;
    Dj_map[s_x][s_y].set = true;

	Dijkstra box;
	// put first 4 points
	for(int dir = 0; dir < 4; dir++){
        int t_x = s_x + dx[dir];
        int t_y = s_y + dy[dir];

        if(EmptyPointCheck(t_x, t_y, ctx) == false){
            continue;
        }

        Node temp;
        temp.position.x = t_x;
        temp.position.y = t_y;
        temp.distance = 1;
        box.push_back(temp);
		Dj_map[t_x][t_y].from.x = s_x;
		Dj_map[t_x][t_y].from.y = s_y;
        Dj_map[t_x][t_y].inBox = true;
        Dj_map[t_x][t_y].distance = 1;
    }

	while(box.empty() == false){
        int index = box.GetMin();
        int x = box[index].position.x;
        int y = box[index].position.y;
        Dj_map[x][y].set = true;
        Dj_map[x][y].inBox = false;
        // delete from box
        box.erase(index);
        // put relevants back to box
        for(int dir = 0; dir < 4; dir++){
            int t_x = x + dx[dir];
            int t_y = y + dy[dir];

            if(EmptyPointCheck(t_x, t_y, ctx) == false){
                continue;
            }

            if(Dj_map[t_x][t_y].set == true){
                continue;
            }

            if(Dj_map[x][y].distance + 1 < Dj_map[t_x][t_y].distance){
				Dj_map[t_x][t_y].from.x = x;
				Dj_map[t_x][t_y].from.y = y;
                if(Dj_map[t_x][t_y].inBox){
					// already in box, then update
                    Dj_map[t_x][t_y].distance = Dj_map[x][y].distance + 1;
                    
                    int _index = box.BoxFind(t_x, t_y);
                    box[_index].distance = Dj_map[x][y].distance + 1;
                }else{
					// do not in box, put it in box
                    Dj_map[t_x][t_y].distance = Dj_map[x][y].distance + 1;
                    Dj_map[t_x][t_y].inBox = true;

                    Node temp;
                    temp.position.x = t_x;
                    temp.position.y = t_y;
					temp.distance = Dj_map[x][y].distance + 1;
                    box.push_back(temp);
                }
            }
        }
    }

	// set point map
	for(int i = 0; i < ctx.length(); i++){
		for(int j = 0; j < ctx.width(); j++){
			if(Dj_map[i][j].distance < 999){
				// reachable
				point_map[i][j].reachable = true;
				point_map[i][j].distance = Dj_map[i][j].distance;
				point_map[i][j].father = Dj_map[i][j].from;
			}
		}
	}

	return;
}

void MoveSet(const Snake& snake_to_operate, const Context& ctx){
	// init move
	for(int i = 0; i < 4; i++){
		movement[i] = 0;
	}
	
	// -10 for illegal action, -1 for kill itself
	// 0 for normal move, 10 for solidation
	for ( int dir = 0; dir < 4; dir++ ){
		//蛇头到达位置
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];

		//超出边界
		if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )
		{
			movement[dir] = -1;
			continue;
		}

		//撞墙
		if ( ctx.wall_map()[t_x][t_y] != -1 )
		{
			movement[dir] = -1;
			continue;
		}

		//撞非本蛇
		if ( ctx.snake_map()[t_x][t_y] != -1 && ctx.snake_map()[t_x][t_y] != snake_to_operate.id )
		{
			movement[dir] = -1;
			continue;
		}

		//回头撞自己
		if ( ( snake_to_operate.length() > 2 ||
			   ( snake_to_operate.length() == 2 && snake_to_operate.length_bank > 0 ) ) &&
			 snake_to_operate[1].x == t_x && snake_to_operate[1].y == t_y )
		{
			movement[dir] = -10;
			continue;
		}

		//移动导致固化
		if ( ctx.snake_map()[t_x][t_y] == snake_to_operate.id )
		{
			movement[dir] = 10;
			continue;
		}
	}

	return;
}

bool SplitStrategy(const Snake& snake_to_operate, const Context& ctx){
	// priority split
	if ( snake_to_operate.length() > 1 )
	{
		// keep snake number 3, in case able to split when no way to go
		if ( ctx.my_snakes().size() < 3 )
			return true;
	}

	return false;
}

int GetDirection(const Snake& snake_to_operate){
	// Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
	// 0 for right, 1 for up, 2 for left, 3 for down

	Coord first = snake_to_operate.coord_list[0];
	Coord second = snake_to_operate.coord_list[1];

	if(first.x == second.x){
		// vertical
		if(first.y > second.y){
			// up
			return 1;
		}
		if(first.y < second.y){
			// down
			return 3;
		}
	}

	if(first.y == second.y){
		// horizontal
		if(first.x > second.x){
			// right
			return 0;
		}
		if(first.x < second.x){
			// left
			return 2;
		}
	}
}
bool MeltStrategy(const Snake& snake_to_operate, const Context& ctx){
	if (snake_to_operate.railgun_item.id < 0){
		// do not have railgun
		return false;
	}
	if(snake_to_operate.length() < 2){
		// melt can only be used when length greater than or equal to 2
		return false;
	}

	int direction = GetDirection(snake_to_operate);
	Coord position = snake_to_operate.coord_list[0];
	int blocksCount = 0;
	// Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
	// 0 for right, 1 for up, 2 for left, 3 for down
	switch(direction){
		case 0:
		// right
		for(int i = position.x; i < ctx.length(); i++){
			if(ctx.wall_map()[i][position.y] == -1){
				continue;
			}else if(ctx.wall_map()[i][position.y] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 1:
		// up
		for(int j = position.y; j < ctx.width(); j++){
			if(ctx.wall_map()[position.x][j] == -1){
				continue;
			}else if(ctx.wall_map()[position.x][j] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 2:
		// left
		for(int i = 0; i < position.x; i++){
			if(ctx.wall_map()[i][position.y] == -1){
				continue;
			}else if(ctx.wall_map()[i][position.y] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 3:
		// down
		for(int j = 0; j < position.y; j++){
			if(ctx.wall_map()[position.x][j] == -1){
				continue;
			}else if(ctx.wall_map()[position.x][j] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
	}

	if(blocksCount > 0){
		return true;
	}else{
		return false;
	}
}


from adk import *

import numpy as np

# written by hlh

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
MAX_SNAKE_NUM = 4
# constants

FIRE = 5
SPLIT = 6

class Strategy:
    def __init__(self):
        self.key = ""
        self.ops = []
        self.act = [[], []]
        self.score = 0
        self.priority = 1e5


class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """
    def __init__(self, player_id):
        self.player_id = player_id

        self.ctx = None
        self.snake = None
        self.map = None
        self.auto_grow = True

        # 一定的随机性
        self.random_behaviour = 0.1

        # 策略的一贯性
        self.pre_score_bonus = lambda x:x+0.5

        # 蛇群智慧，分配任务给每个蛇
        self.group_work = dict()
        # 单蛇智慧
        self.strategy_pool = []
        self.dist_map = None

        self.hold_map = dict()

        self.snake_act = dict()
        self.snake_ops = dict()
        self.snake_targets = dict()
        self.pre_dist_map = dict()

        import platform
        self.log_bool = "Windows" in platform.platform()
        self.log_num = 0
        self.max_log_num = 500
        if self.log_bool:
            fh = logging.FileHandler('./output/player-{}-debug.log'.format(self.player_id))
            fh.setLevel(logging.ERROR)
            logging.root.addHandler(fh)
        self.plot_bool = "Windows" in platform.platform()

    def log(self, info, log_bool = None):
        if log_bool == None:
            log_bool = self.log_bool
        if log_bool and self.log_num < self.max_log_num:
            logging.error("Turn {}, Player {}, Snake {}: ".format(
                self.ctx.turn, self.player_id, self.snake.id))
            logging.error(info)
            self.log_num = self.log_num + 1
    
    def matplotlib_plot(self, array, fig_name):
        if self.plot_bool:
            array = np.array(array).T
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(16,12))
            im = ax.imshow(array)
            for x in range(array.shape[1]):
                for y in range(array.shape[0]):
                    ax.text(x,y,str(array[y][x]),va="center",ha="center")
            ax.invert_yaxis()
            fig.colorbar(im)
            if ".jpg" not in fig_name:
                fig_name = fig_name + ".jpg"
            plt.savefig("./output/" + fig_name)
            plt.close()

    def check(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        # check wall and out of bounds
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        # check turn back
        if (x == self.snake.coor_list[-1][0]
        and y == self.snake.coor_list[-1][1]
        and self.snake.length_bank == 0
        and not self.auto_grow):
            return True
        # loop and zero length_bank will not solidify
        if self.ctx.game_map.snake_map[x][y] != -1:
            return False
        # check other snake
        return True

    def check_self(self, op):
        """
        :param op: the direction
        :return: True if this move is legal, could possibly result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
            return False
        return True
    
    def closest_food_strategy(self):
        """
        Search for the closest food and to go that direction, if legal.

        :return: ops
        """

        start_min, score, ops_min, act_min, item_min = float("inf"), 0, None, None, None

        dist_map = self.dist_map

        for item in self.ctx.game_map.item_list:
            target_pos = (item.x, item.y)
            # no search for gotten ones
            if item.gotten_time != -1:
                continue

            # search food only
            if len(self.snake.item_list) > 0 and item.type != 0:
                continue
            
            start = self.ctx.turn + dist_map[item.x][item.y]
            end = start + self.snake.get_len() - 1 + self.snake.length_bank  + self.auto_grow

            if start != float("inf"):
                start = int(start)
            if end != float("inf"):
                end = int(end)

            # 别扎堆
            targeted_count = 0
            occupied = False
            for snake_id, (item_id, that_start) in self.snake_targets.items():
                if (item_id == item.id and snake_id != self.snake.id
                and self.ctx.get_snake(snake_id) in self.ctx.snake_list
                and that_start <= start
                ):
                    targeted_count = targeted_count + 1
                    if (self.snake.priority > self.ctx.get_snake(snake_id).priority):
                        occupied = True
            if occupied:
                continue
            
            # search food that can be occupied
            # 赶不上或者到早了就算了, 但可以早到5回合先占着
            if (item.time + 15 < start or end + 5 < item.time):
                continue
            
            # 没融化器，就别找墙里面的
            if (self.map.wall_map[item.x][item.y] != -1
            and len(self.snake.item_list) == 0):
                continue

            hold_time = [h[0] for h in self.hold_map[target_pos] if not (item.time + 15 < h[0] or h[1] < item.time)]
            if len(hold_time) == 0:
                early_hold_start = float("inf")
            else:
                early_hold_start = min(hold_time)

            if start < start_min and start < early_hold_start:
                ops, act = self.find_path(
                    dist_map=dist_map, target_pos=target_pos,init_turn=self.ctx.turn,
                    hold_period = self.snake.get_len() - 1 + self.snake.length_bank  + self.auto_grow
                )
                if len(ops) == 0:
                    continue
                if act is None:
                    continue

                x = self.snake.coor_list[0][0] + dx[ops[0]-1]
                y = self.snake.coor_list[0][1] + dy[ops[0]-1]
                melt_score = 0
                # 被墙挡住了，立即开火
                if self.map.wall_map[x][y] != -1:
                    melt_score = self.fire_calc(self.snake.coor_list) - 0.5
                    ops.insert(0, FIRE)

                start_min = start
                ops_min = ops
                act_min = act
                item_min = item
                score = item.param + melt_score
                self.snake_targets.update(
                    {self.snake.id:(item.id, start)}
                )
        
        if score not in [1,2,3,4,5]:
            score = 0.5
        # fire is 0.5 score

        if item_min is not None:
            start = self.ctx.turn + dist_map[item_min.x][item_min.y]
            end = start + self.snake.get_len() - 1 + self.snake.length_bank  + self.auto_grow

            if start != float("inf"):
                start = int(start)
            if end != float("inf"):
                end = int(end)
            if end < item_min.time or item_min.time + 15 < start:
                score = score * 1e-2

        return ops_min, act_min, score
    
    def release_mem(self, dict_to_do):
        for dictionary in dict_to_do:
            pop_snake_id = [
                snake_id for snake_id in dictionary
                if self.ctx.get_snake(snake_id) not in self.ctx.snake_list
            ]
            for s in pop_snake_id:
                dictionary.pop(s)

    def judge(self, snake, ctx):
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        """
        self.ctx = ctx
        self.snake = snake
        self.map = ctx.get_map()
        self.auto_grow = self.ctx.turn <= self.ctx.auto_growth_round

        self.release_mem(
            [self.snake_act, self.snake_ops, self.snake_targets]
        )

        self.update_snake_priority()

        self.calc_hold_period()

        dist_map = self.calc_dist_map(
            init_pos=self.snake.coor_list[0],
            init_turn=self.ctx.turn,
            hold_map=self.hold_map
        )
        self.dist_map = dist_map

        self.propose_strategy()

        return self.deploy_strategy()

    def propose_strategy(self):
        pool = []
        self.strategy_pool = pool

        my_snake_num = self.ctx.get_snake_count(self.player_id)
        coor = self.snake.coor_list

        # default strategy (avoid no reply)
        # 只要不回头，怎么都好说
        this_stra = Strategy()
        this_stra.key = "default"
        this_stra.score = float("-inf")
        this_stra.priority = float("-inf")
        if (self.snake.get_len() > 1
        and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0]
        and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]
        ):
            this_stra.ops = [2]
        else:
            this_stra.ops = [1]
        pool.append(this_stra)

        # use someting, otherwise must die
        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0:
            self.log("Dying...", log_bool=True)
            for i in range(4):
                if self.check_self(i):
                    valid.append(i)
            for direction in valid:
                this_stra = Strategy()
                this_stra.key = "must solidify"
                score = self.solidificaiton_calc(self.snake.id, coor, direction)
                if score:
                    this_stra.score = score + 1
                    this_stra.ops = [direction+1]
                    pool.append(this_stra)
                else:
                    continue
            if (# basic requirements
                self.snake.get_len() > 1
            and my_snake_num < MAX_SNAKE_NUM
            ):
                this_stra = Strategy()
                this_stra.key = "must split"
                score = 0
                this_stra.score = score
                this_stra.ops = [SPLIT]
                pool.append(this_stra)
            if len(self.snake.item_list) > 0 and self.snake.get_len() > 1:
                this_stra = Strategy()
                this_stra.key = "must fire"
                score = self.fire_calc(coor)
                this_stra.score = (score - 0.5)
                this_stra.ops = [FIRE]
                pool.append(this_stra)
            return

        # # previous strategy
        # if self.snake.id in self.snake_ops:
        #     previous_stra = self.snake_ops[self.snake.id]
        #     if len(previous_stra.ops) > 0:
        #         previous_stra.score = self.pre_score_bonus(previous_stra.score)
        #         if "previous " not in previous_stra.key:
        #             previous_stra.key = "previous " + previous_stra.key
        #         if previous_stra.ops[0] in [1, 2, 3, 4]:
        #             if self.check_self(previous_stra.ops[0]-1):
        #                 pool.append(previous_stra)
        #         else:
        #             pool.append(previous_stra)

        # split
        if (# basic requirements
            self.snake.get_len() > 1
        and my_snake_num < MAX_SNAKE_NUM
            # strategy requirements
        and self.ctx.turn > self.ctx.auto_growth_round
        and my_snake_num < 3
        ):
            this_stra = Strategy()
            this_stra.key = "split"
            if self.snake.priority == 0 and self.ctx.get_snake_count(self.player_id) > 1:
                this_stra.score = float("-inf")
            else:
                this_stra.score = 0
                this_stra.priority = 1e10
            this_stra.ops = [SPLIT]
            pool.append(this_stra)
        
        # fire
        if len(self.snake.item_list) > 0 and self.snake.get_len() > 1:
            this_stra = Strategy()
            this_stra.key = "fire"
            score = self.fire_calc(coor)
            this_stra.score = score
            if score > 0:
                this_stra.priority = 1e6
            if score <= 0:
                this_stra.priority = float("-inf")
            this_stra.ops = [FIRE]
            pool.append(this_stra)

        # get closest food
        if True:
            this_stra = Strategy()
            ops, act, score = self.closest_food_strategy()
            if ops is not None:
                this_stra.key = "get closest food"
                this_stra.ops = ops
                this_stra.act = act
                this_stra.score = score
                pool.append(this_stra)

        # 瞎逛策略
        if True:
            for i in range(4):
                if self.check(i):
                    this_stra = Strategy()
                    this_stra.key = "wander"
                    this_stra.score = 0
                    this_stra.priority = 0
                    this_stra.ops = [i+1]
                    pool.append(this_stra)
                # elif self.check_self(i):
                #     this_stra = Strategy()
                #     this_stra.key = "solidify"
                #     score = self.solidificaiton_calc(self.snake.id, coor, i)
                #     if score:
                #         this_stra.score = score
                #         this_stra.ops = [i+1]
                #         pool.append(this_stra)
                #     else:
                #         continue
        
        # 核心策略，大蛇环
        if((self.snake.priority == 0 and  self.snake.get_len() + self.snake.length_bank >= 20
        or  self.snake.priority == 1 and  self.snake.get_len() + self.snake.length_bank >= 10
        or  self.snake.priority == 2 and  self.snake.get_len() + self.snake.length_bank >= 10
        or  self.snake.priority == 3 and  self.snake.get_len() + self.snake.length_bank >= 5)
        and my_snake_num > 2):

            for idx in range(len(self.snake.coor_list)):
                if idx == 0:
                    continue
                cur = self.snake.coor_list[idx]
                ops = []
                assumed_snake = []
                for i in range(4):
                    x = cur[0] - dx[i]
                    y = cur[1] - dy[i]
                    if (0 <= x < 16 and 0 <= y < 16
                    and self.map.snake_map[x][y] == -1
                    and self.map.wall_map[x][y] == -1
                    ):
                        ops, act = self.find_path(
                            dist_map=self.dist_map, target_pos=(x, y), init_turn=self.ctx.turn,
                            hold_period = self.snake.get_len() - 1 + self.snake.length_bank  + self.auto_grow
                        )
                        if act is not None:
                            assumed_snake = act[0]
                            this_stra = Strategy()
                            this_stra.key = "form a loop for {}".format(idx)
                            assumed_coor = self.snake.coor_list[:idx+1] + assumed_snake
                            score = self.solidificaiton_calc(self.snake.id, assumed_coor, ops[0]-1, visual_bank=True)
                            this_stra.score = 2 + score
                            this_stra.ops = ops
                            if self.snake.get_len() + self.snake.length_bank > 30:
                                this_stra.priority = 1e9
                            if this_stra.score > 10:
                                this_stra.priority = 1e7
                            pool.append(this_stra)
    
    def deploy_strategy(self):
        sorted_pool = sorted(
            self.strategy_pool,
            key=lambda x: x.score + x.priority + self.random_behaviour * random.uniform(-1.0, 1.0),
            reverse=True
        )

        max_dist = dict()
        for stra in sorted_pool:
            this_op = stra.ops[0]    
            if this_op in [1,2,3,4]:
                this_direction = this_op - 1
                if self.check(this_direction):
                    x = self.snake.coor_list[0][0] + dx[this_direction]
                    y = self.snake.coor_list[0][1] + dy[this_direction]
                    new_dist_map = self.calc_dist_map(
                        init_pos=(x,y),
                        init_turn=self.ctx.turn+1,
                        hold_map=self.hold_map
                    )
                    max_dist.update({stra:new_dist_map.max()})

        max_stra = None
        for stra in sorted_pool:
            if self.check_stra(stra):
                this_op = stra.ops[0]
                if (this_op in [1,2,3,4] and self.check(this_op - 1)
                and max(max_dist.values()) > 5 and max_dist[stra] <= 5
                and "solidify" not in stra.key
                ):
                    continue
                max_stra = stra
                max_score = stra.score
                break

        if max_stra is None:
            for stra in sorted_pool:
                if self.check_stra(stra):
                    max_stra = stra
                    max_score = stra.score
                    break
        
        this_op = max_stra.ops[0]
        self.snake_act.update({
            self.snake.id:max_stra.act
        })

        self.matplotlib_plot(self.dist_map, "player{}-turn{}-snake{}".format(self.player_id, self.ctx.turn, self.snake.id))
    
        self.log("score:{}, priority: {}, key: {}, ops:{}, {}".format(
            max_stra.score, max_stra.priority, max_stra.key, this_op, max_stra.ops[:4]))
        return this_op
    
    def update_snake_priority(self):
        for snake in self.ctx.snake_list:
            if snake.camp == self.player_id:
                len_no = sum([
                    snake.get_len() < x.get_len()
                    for x in self.ctx.snake_list if x.camp == self.player_id
                ])
                snake.priority = len_no
    
    def calc_hold_period(self):
        wall_map = np.array(self.map.wall_map)
        snake_map = np.array(self.map.snake_map)
        item_map = np.array(self.map.item_map)
        for x in range(self.map.length):
            for y in range(self.map.width):
                self.hold_map.update({
                    (x,y):[]
                })

        if len(self.snake.item_list) == 0:
        # 没道具， 就别想着穿墙
            for x in range(self.map.length):
                for y in range(self.map.width):
                    if wall_map[x][y] != -1:
                        self.hold_map[(x,y)].append(
                            [float("-inf"), float("inf")]
                        )

        # 别穿蛇
        for snake in self.ctx.snake_list:
            # 这里自己也别咬自己， 别处再考虑
            if snake.camp == self.player_id:
                for idx, pos in enumerate(snake.coor_list):
                    start = self.ctx.turn
                    # 长度银行为空, 蛇尾处，snake.get_len() - (idx + 1) = 0, end = start, 下一回合让出
                    end = start + snake.get_len() - (idx + 1) + snake.length_bank  + self.auto_grow
                    self.hold_map[pos].append([start, end])
            else:
                for idx, pos in enumerate(snake.coor_list):
                    start = self.ctx.turn
                    # 长度银行为空, 蛇尾处，snake.get_len() - (idx + 1) = 0, end = start, 下一回合让出
                    end = start + snake.get_len() - (idx + 1) + snake.length_bank  + self.auto_grow
                    self.hold_map[pos].append([start, end]) 
        
        # 预判蛇
        for snake in self.ctx.snake_list:
            if snake.camp == self.player_id:
                # 优先级更低的己方蛇应该让路, 数字越小，优先级越高
                if self.snake.priority < snake.priority:
                    pass
                # 不必给自己让路了
                elif self.snake.id == snake.id:
                    pass
                else:
                    if snake.id in self.snake_act:
                        act = self.snake_act[snake.id]
                        for pos, hold in zip(act[0], act[1]):
                            self.hold_map[pos].append(hold)
            else:
                # 预判敌方蛇的行为
                if snake.id in self.pre_dist_map:
                    head = snake.coor_list[0]
                    if snake.id in self.snake_act and head in self.snake_act[snake.id]:
                    # 上次判断过，且正确
                        pass
                    else:
                    # 重新判断
                        pre_dist_map = self.pre_dist_map[snake.id]
                        hold_keys = ["snake", "wall"]
                        dist_map = self.calc_dist_map(
                            head, self.ctx.turn,
                            hold_keys = hold_keys
                        )
                        target = []
                        for item in self.map.item_list:
                            item_loc = (item.x, item.y)
                            if dist_map[item_loc] < pre_dist_map[item_loc]:
                                target.append(item)
                        if len(target) == 0:
                            pass
                        else:
                            min_time = min([t.time for t in target])
                            min_target = [t for t in target if t.time==min_time][0]
                            min_pos = (min_target.x, min_target.y)
                            ops, act = self.find_path(
                                dist_map=dist_map, target_pos=min_pos, init_turn=self.ctx.turn,
                                hold_period=snake.get_len() - 1 + snake.length_bank + self.auto_grow
                            )
                            if act is not None:
                                self.snake_act.update({
                                    snake.id:act
                                })
                        self.pre_dist_map.update({snake.id:dist_map})
                    if snake.id in self.snake_act:
                        act = self.snake_act[snake.id]
                        for pos, hold in zip(act[0], act[1]):
                            self.hold_map[pos].append(hold)
                else:
                # 新蛇就不管了
                    head = snake.coor_list[0]
                    dist_map = self.calc_dist_map(
                        head, self.ctx.turn,
                    )
                    self.pre_dist_map.update({snake.id:dist_map})
                    pass

    def calc_dist_map(self, init_pos, init_turn, hold_map = None,
                        hold_keys = ["snake", "wall"]):
        if hold_map is None:
            hold_map = dict()
            for x in range(self.map.length):
                for y in range(self.map.width):
                    hold_map.update({
                        (x,y):[]
                    })
                    if "wall" in hold_keys and self.map.wall_map[x][y] != -1:
                        hold_map[(x,y)] = [[float("-inf"), float("inf")]]
            if "snake" in hold_keys:
                for snake in self.ctx.snake_list:
                    # 这里自己也别咬自己， 别处再考虑
                    for idx, pos in enumerate(snake.coor_list):
                        start = init_turn
                        # 长度银行为空, 蛇尾处，snake.get_len() - (idx + 1) = 0, end = start, 下一回合让出
                        end = init_turn + snake.get_len() - (idx + 1) + snake.length_bank + self.auto_grow
                        self.hold_map[pos].append([start, end])
        prev_que = [None]
        que = [init_pos]
        head = 0
        tail = 0
        dist_map = np.ones((self.map.length, self.map.width)) * float("inf")
        dist_map[init_pos] = 0
        break_wall_time = 0
        while(head <= tail):
            cur = que[head]
            prev = prev_que[head]
            head += 1
            for i in range(4):
                x = cur[0] + dx[i]
                y = cur[1] + dy[i]
                new = (x, y)
                this_turn = init_turn + dist_map[cur]
                if (new not in que
                and 0 <= x < 16 and 0 <= y < 16
                and sum([h[0] <= this_turn <= h[1] for h in hold_map[new]]) == 0
                ):
                    if self.map.wall_map[x][y] != -1:
                        if prev is not None:
                            prev_dx = cur[0] - prev[0]
                            prev_dy = cur[1] - prev[1]
                            # 朝向正确，可以开火，但方向要正确欧
                            if (prev_dx == dx[i] and prev_dy == dy[i] and break_wall_time == 0):
                                break_wall_time = break_wall_time + 1
                                pass
                            else:
                                continue
                        else:
                            continue
                    dist_map[new] = dist_map[cur] + 1
                    tail += 1
                    que.append(new)
                    prev_que.append(cur)
        return dist_map
    
    def find_path(self, dist_map, target_pos, init_turn, hold_period = 0):
        ops = []
        act = [[], []]
        cur = (target_pos[0], target_pos[1])
        if dist_map[cur[0]][cur[1]] == float("inf"):
            return None, None
        while int(dist_map[cur[0]][cur[1]]) != 0:
            act[0].append(cur)
            act[1].append([
                int(init_turn+dist_map[cur[0]][cur[1]]),
                int(init_turn+dist_map[cur[0]][cur[1]]) + hold_period,
            ])
            directions =[i for i in range(4)]
            random.shuffle(directions)
            this_step_done = False
            for i in directions:
                if not this_step_done:
                    x = cur[0] - dx[i]
                    y = cur[1] - dy[i]
                    if (0 <= x < 16 and 0 <= y < 16
                    and dist_map[x][y] < float("inf")
                    and (int(dist_map[x][y]) + 1) == int(dist_map[cur[0]][cur[1]])
                    ):
                        ops.insert(0,i+1)
                        cur = (x, y)
                        this_step_done = True
        return ops, act
    
    def solidificaiton_calc(self, snake_id, coor, direction, visual_bank=False):
        snake = self.ctx.get_snake(snake_id)
        x, y = coor[0][0] + dx[direction], coor[0][1] + dy[direction]
        if len(coor) == 1:
            new_coor = [(x, y)]
        else:
            new_coor = [(x, y)] + coor[:-1]
        if self.auto_grow or snake.length_bank or visual_bank:
            new_coor = new_coor + [coor[-1]]
        
        dead_snake = None
        for i in range(len(new_coor)):
            if i == 0:
                continue
            if x == new_coor[i][0] and y == new_coor[i][1]:
                dead_snake = [snake_id]
                solid_coor = new_coor[:i]
                g = Graph(solid_coor, self.map.length, self.map.width)
                extra_solid = g.calc()
                for coor in new_coor[i:]:
                    if coor in extra_solid:
                        solid_coor.append(coor)
                        extra_solid.remove(coor)
                tmp_solid = extra_solid.copy()
                for coor in tmp_solid:
                    if self.map.snake_map[coor[0]][coor[1]] != -1:
                        dead_snake.append(self.map.snake_map[coor[0]][coor[1]])
        if dead_snake:
            score = 0
            enemy_count = 0
            for snake_id in dead_snake:
                this_snake = self.ctx.get_snake(snake_id)
                if this_snake.camp == self.player_id:
                    score = score - this_snake.get_len()
                else:
                    score = score + this_snake.get_len()
                    enemy_count = enemy_count + 1
            score = score + len(extra_solid) + len(solid_coor) + self.snake.get_len() + self.snake.length_bank - len(coor)
            if (enemy_count == self.ctx.get_snake_count(1-self.player_id)
            and self.ctx.get_snake_count(1-self.player_id) != 0
            and self.snake.get_len() + self.snake.length_bank + 2 >= len(coor)
            ):
            # 能全歼敌方，还不开心？
                self.log("killing all, exciting? !!", log_bool= True)
                score = float("inf")
            return score
        else:
            return None
    
    def fire_calc(self, coor):
        if len(coor) <= 1:
            return float("-inf")
        x1, y1 = coor[0]
        x2, y2 = coor[1]
        delta_x, delta_y = x1 - x2, y1 - y2
        walls = []

        while self.map.length > x1 + delta_x >= 0 and self.map.width > y1 + delta_y >= 0:
            x1, y1 = (x1 + delta_x, y1 + delta_y)
            walls = [(x1, y1)] + walls
        
        score = 0
        for w in walls:
            x, y = w
            if self.map.wall_map[x][y] == self.player_id:
                score = score -1
            elif self.map.wall_map[x][y] == -1:
                score = score
            else:
                score = score + 1
        return score
    
    def check_stra(self, stra):
        this_op = stra.ops[0]
        if this_op in [1,2,3,4]:
            this_direction = this_op - 1
            x = self.snake.coor_list[0][0] + dx[this_direction]
            y = self.snake.coor_list[0][1] + dy[this_direction]
            if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
                return True
            if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
                return False
            if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
                return True
            return True
        elif this_op == 5:
            return len(self.snake.item_list) > 0 and self.snake.get_len() > 1
        elif this_op == 6:
            my_snake_num = self.ctx.get_snake_count(self.player_id)
            return self.snake.get_len() > 1 and my_snake_num < MAX_SNAKE_NUM
        else:
            return False


def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    # game config
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0

    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI(player)
    while playing:
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
                logging.debug(str(op))
                if not controller.apply(op):
                    raise RuntimeError("Illegal Action!!! " + str(op))
                c.send_data(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:
        pass

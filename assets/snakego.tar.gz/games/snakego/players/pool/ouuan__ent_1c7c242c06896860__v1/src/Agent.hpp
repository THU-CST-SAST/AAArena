#pragma once

#include "Channel.hpp"
#include "Logic.hpp"

class Agent
{
   public:
    explicit Agent(int argc, char **argv);
    ~Agent();
    void run();

   protected:
    virtual Operation nextMove(const Logic *o) = 0;

   private:
    int readShort();
    int readInt();
    std::pair<vector<Item>, vector<int>> readItemList();
    void handleGameover();
    void crash();

   private:
    Channel *ch;
    Logic *logic;
    Player player;
};

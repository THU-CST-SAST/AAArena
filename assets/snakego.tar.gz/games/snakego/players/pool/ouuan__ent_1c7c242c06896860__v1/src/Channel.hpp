#pragma once

#include <string>

class Channel
{
   public:
    virtual ~Channel() = default;
    virtual bool send(char *msg, size_t len) = 0;
    virtual bool recv(char *buf, size_t len) = 0;
};

Channel *socket_channel(const std::string &host, unsigned int port);
Channel *stdio_channel();

#if defined(__unix__) || (defined(__APPLE__) && defined(__MACH__)) || defined(__CYGWIN__)
#define ADK_POSIX
#elif defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#define ADK_WIN
#endif

#ifdef ADK_POSIX

class PosixSocket : public Channel
{
   public:
    explicit PosixSocket(int internal_socket);
    ~PosixSocket() override;
    bool send(char *msg, size_t len) override;
    bool recv(char *buf, size_t len) override;

   private:
    int internal_socket;
};

#endif  // ADK_POSIX

#ifdef ADK_WIN

#pragma comment(lib, "ws2_32.lib")

#include <WS2tcpip.h>
#include <WinSock2.h>

class WindowsSocket : public Channel
{
   public:
    WindowsSocket(SOCKET internal_socket);
    virtual ~WindowsSocket();
    virtual bool send(char *msg, size_t len) override;
    virtual bool recv(char *buf, size_t len) override;

   private:
    SOCKET internal_socket;
};

#endif  // ADK_WIN

class StdIO : public Channel
{
   public:
    ~StdIO() override;
    bool send(char *msg, size_t len) override;
    bool recv(char *buf, size_t maxlen) override;
};

#pragma once

#include <chrono>
#include <cmath>

#include "Agent.hpp"

static const double MCTS_C = 1.4;
static const int MCTS_DEPTH = 50;

struct MctsNode
{
    Player first;
    Operation op = MoveUp;
    MctsNode* parent = nullptr;
    int visit = 0;
    double totalOffensiveWin = 0;
    bool isEnd = false;
    double selfOffensiveWin = 0;
    vector<MctsNode*> children = {};

    ~MctsNode()
    {
        for (auto& ch : children)
            delete ch;
    }

    void update(double offensiveWin)
    {
        totalOffensiveWin += offensiveWin;
        ++visit;
    }

    double uct(Player player)
    {
        double win = player == Offensive ? totalOffensiveWin : visit - totalOffensiveWin;
        return win / visit + MCTS_C * std::sqrt(std::log(parent->visit) / visit);
    }
};

class Mcts : public Agent
{
   public:
    explicit Mcts(int argc, char** argv);

   private:
    Operation nextMove(const Logic* o) override;

    bool timeout() const;

    double search(MctsNode* u, int depth = MCTS_DEPTH);

   private:
    std::chrono::time_point<std::chrono::steady_clock> start;

    Logic* logic = nullptr;
};

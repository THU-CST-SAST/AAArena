#include "Random.hpp"

#include <algorithm>
#include <chrono>
#include <random>

static std::mt19937 rng(std::chrono::steady_clock::now().time_since_epoch().count());

Operation Random::nextMove(const Logic *o)
{
    auto moves = o->validMoves();
    std::shuffle(moves.begin(), moves.end(), rng);
    return moves.front();
}

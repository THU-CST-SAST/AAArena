#include "Stupid.hpp"

Operation Stupid::nextMove(const Logic *o)
{
    return o->validMoves().front();
}

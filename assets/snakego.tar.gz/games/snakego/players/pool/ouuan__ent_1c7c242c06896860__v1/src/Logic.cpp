#include "Logic.hpp"

#include <algorithm>
#include <cassert>
#include <chrono>
#include <cmath>
#include <functional>
#include <iostream>
#include <random>

static const int GROW_ROUNDS = 8;
static const int MELT_PARAM = 512;
static const int MAX_SNAKE = 4;
static const int ITEM_LIFE = 16;

static std::mt19937 rng(std::chrono::steady_clock::now().time_since_epoch().count());

#ifdef DEBUG
void funcName(const char *name)
{
    std::cerr << std::chrono::steady_clock::now().time_since_epoch().count() << " " << name
              << std::endl;
}
#define FUNCNAME  // funcName(__func__)
#else
#define FUNCNAME
#endif

/*
 * @returns if the coordinate c is out of board
 */
bool isOut(Coor c)
{
    return c.x < 0 || c.x >= SIZE || c.y < 0 || c.y >= SIZE;
}

Logic::Logic(const vector<Item> &itemList, const vector<int> &itemTimeList)
{
    FUNCNAME;
    for (int i = 0; i < (int)itemList.size(); ++i)
    {
        const Item item = itemList[i];
        const int time = itemTimeList[i];
        itemAppear[time].push_back(item);
        if (time + ITEM_LIFE < MAX_ROUND)
            itemDisappear[time + ITEM_LIFE].push_back(item.coordinate);
    }

    for (int player = 0; player < 2; ++player)
    {
        auto *node = new ListNode(player ? Coor{SIZE - 1, 0} : Coor{0, SIZE - 1}, false);
        listNodePool.push_back(node);
        auto *snake =
            new Snake{-1, (Player)player, node, node, player ? Up : Down, 1, 0, false, false, true};
        snakePool.push_back(snake);
        snakes[player].push_back(snake);
        coverType[node->c().x][node->c().y] = CoverType::Snake;
        coverSnake[node->c().x][node->c().y] = snake;
        snakeTotalLength[player] = 1;
    }

    currentSnake = snakes[0].front();
}

Logic::Logic(const Logic &o)
    : itemAppear(o.itemAppear),
      itemDisappear(o.itemDisappear),
      itemParam(o.itemParam),
      coverType(o.coverType),
      wallCount(o.wallCount),
      snakeTotalLength(o.snakeTotalLength),
      currentRound(o.currentRound),
      currentPlayer(o.currentPlayer)
{
    FUNCNAME;
    for (int player = 0; player < 2; ++player)
    {
        for (auto snake : o.snakes[player])
        {
            auto *newSnake = new Snake(*snake);
            snakePool.push_back(newSnake);
            snakes[player].push_back(newSnake);

            auto *newTail = new ListNode(snake->tail->c(), snake->reverse);
            listNodePool.push_back(newTail);
            newSnake->tail = newSnake->head = newTail;
            coverSnake[snake->tail->c().x][snake->tail->c().y] = newSnake;

            if (snake == o.currentSnake)
                currentSnake = newSnake;

            for (auto u = snake->tail; u != snake->head; u = u->next(snake->reverse))
            {
                auto *newNode =
                    new ListNode(u->next(snake->reverse)->c(), snake->reverse, newSnake->head);
                listNodePool.push_back(newNode);
                coverSnake[newNode->c().x][newNode->c().y] = newSnake;
                newSnake->head->setNext(newNode, snake->reverse);
                newSnake->head = newNode;
            }
        }
    }
}

Logic::~Logic()
{
    FUNCNAME;
    for (auto &snake : snakePool)
        delete snake;
    for (auto &listNode : listNodePool)
        delete listNode;
}

vector<Operation> Logic::validMoves() const
{
    FUNCNAME;
    vector<std::pair<int, Operation>> weightedOps;

    for (int d = 0; d < 4; ++d)
    {
        const auto result = moveResult(currentSnake, Direction(d));

        const auto op = Operation(d + 1);

        switch (result)
        {
            case MoveResult::Success:
                weightedOps.emplace_back(20, op);
                if (d == currentSnake->direction)
                    weightedOps.back().first += 1;
                if (currentSnake->isInitial && currentRound < GROW_ROUNDS)
                    weightedOps.back().first += 3;
                else if (currentSnake->bank)
                    weightedOps.back().first += 2;
                break;
            case MoveResult::Dead:
                weightedOps.emplace_back(0, op);
                break;
            case MoveResult::Lose:
                break;
            case MoveResult::Solidify:
                weightedOps.emplace_back(10 + 2 * snakes[currentPlayer].size(), op);
                break;
        }
    }

    const int melt = meltResult(currentSnake);
    if (melt != MELT_INVALID)
        weightedOps.emplace_back(16 + melt, Melt);

    if (canSplit(currentSnake))
        weightedOps.emplace_back(20 - snakes[currentPlayer].size(), Split);

    std::shuffle(weightedOps.begin(), weightedOps.end(), rng);
    std::sort(weightedOps.begin(), weightedOps.end());

    vector<Operation> result;
    for (auto [weight, op] : weightedOps)
        result.push_back(op);
    std::reverse(result.begin(), result.end());
    return result;
}

void Logic::handleMove(Operation op)
{
    FUNCNAME;
    currentSnake->lastMovedRound = currentRound;

    switch (op)
    {
        case MoveRight:
        case MoveUp:
        case MoveLeft:
        case MoveDown:
        {
            const auto result = moveResult(currentSnake, Direction(op - 1));
            switch (result)
            {
                case MoveResult::Success:
                case MoveResult::Solidify:
                    move(currentSnake, Direction(op - 1));
                    break;
                case MoveResult::Dead:
                    die(currentSnake);
                    break;
                case MoveResult::Lose:
                    throw "Invalid move";
            }
            break;
        }
        case Melt:
            melt(currentSnake);
            break;
        case Split:
            split(currentSnake);
            break;
    }

    if (snakes[0].empty() && snakes[1].empty())
    {
        currentRound = MAX_ROUND;
        return;
    }

    for (auto snake : snakes[currentPlayer])
    {
        if (snake->lastMovedRound < currentRound)
        {
            currentSnake = snake;
            return;
        }
    }

    if (snakes[currentPlayer ^ 1].empty())
    {
        newRound();
        currentSnake = snakes[currentPlayer].front();
    }
    else
    {
        if (currentPlayer == Defensive)
            newRound();
        currentPlayer = Player(currentPlayer ^ 1);
        currentSnake = snakes[currentPlayer].front();
    }
}

Winner Logic::winner() const
{
    FUNCNAME;
    if (currentRound == MAX_ROUND || (snakeCount(Offensive) == 0 && snakeCount(Defensive) == 0))
    {
        const int offensiveTotal = wallCount[Offensive] + snakeTotalLength[Offensive];
        const int defensiveTotal = wallCount[Defensive] + snakeTotalLength[Defensive];

        if (offensiveTotal > defensiveTotal)
            return Winner::Offensive;
        if (defensiveTotal > offensiveTotal)
            return Winner::Defensive;
        return Winner::Tie;
    }

    if (snakeCount(Offensive) == 0 && wallCount[Offensive] < wallCount[Defensive])
        return Winner::Defensive;
    if (snakeCount(Defensive) == 0 && wallCount[Defensive] < wallCount[Offensive])
        return Winner::Offensive;
    return Winner::Playing;
}

Player Logic::player() const
{
    FUNCNAME;
    return currentPlayer;
}

int Logic::snakeCount(Player player) const
{
    FUNCNAME;
    return snakes[player].size();
}

bool Logic::isEnd() const
{
    FUNCNAME;
    return currentRound == MAX_ROUND;
}

int Logic::currentRoundNumber() const
{
    FUNCNAME;
    return currentRound;
}

int Logic::totalWall(Player player) const
{
    return wallCount[player];
}

int Logic::totalSnake(Player player) const
{
    return snakeTotalLength[player];
}

MoveResult Logic::moveResult(const Snake *snake, Direction direction) const
{
    FUNCNAME;
    if (std::abs(snake->direction - direction) == 2)  // U-turn
    {
        if (snake->length + (snake->bank || (snake->isInitial && currentRound < GROW_ROUNDS)) > 2)
            return MoveResult::Lose;
    }

    const auto newHeadCoor = snake->head->c() + DIRECTION_COOR[direction];

    if (isOut(newHeadCoor))
        return MoveResult::Dead;

    switch (coverType[newHeadCoor.x][newHeadCoor.y])
    {
        case CoverType::OffensiveWall:
        case CoverType::DefensiveWall:
            return MoveResult::Dead;
        case CoverType::Snake:
            if (coverSnake[newHeadCoor.x][newHeadCoor.y] != snake)
                return MoveResult::Dead;
            if (newHeadCoor == snake->tail->c() && snake->length == 0)
                return MoveResult::Success;
            return MoveResult::Solidify;
        case CoverType::None:
            return MoveResult::Success;
    }

    throw "Incomplete switch in Logic::moveResult";
}

void Logic::move(Snake *snake, Direction direction)
{
    FUNCNAME;

    const auto newHeadCoor = snake->head->c() + DIRECTION_COOR[direction];

    // bank could be modified by the new item
    const bool hasBank = snake->bank;

    int &ateItem = itemParam[newHeadCoor.x][newHeadCoor.y];
    switch (ateItem)
    {
        case 0:
            break;
        case MELT_PARAM:
            snake->melt = true;
            break;
        default:
            snake->bank += ateItem;
            break;
    }
    ateItem = 0;

    snake->direction = direction;

    const bool initialGrow = snake->isInitial && currentRound < GROW_ROUNDS;

    if (snake->length == 1 && !hasBank && !initialGrow)
    {
        coverType[snake->head->c().x][snake->head->c().y] = CoverType::None;
        snake->head->setCoor(newHeadCoor);
        coverType[newHeadCoor.x][newHeadCoor.y] = CoverType::Snake;
        coverSnake[newHeadCoor.x][newHeadCoor.y] = snake;
        return;
    }

    if (initialGrow)
    {
        ++snake->length;
        ++snakeTotalLength[snake->player];
    }
    else
    {
        if (hasBank)
        {
            --snake->bank;
            ++snake->length;
            ++snakeTotalLength[snake->player];
        }
        else
        {
            coverType[snake->tail->c().x][snake->tail->c().y] = CoverType::None;
            snake->tail = snake->tail->next(snake->reverse);
        }
    }

    auto *newHead = new ListNode(newHeadCoor, snake->reverse, snake->head);
    listNodePool.push_back(newHead);
    snake->head->setNext(newHead, snake->reverse);
    snake->head = newHead;

    if (coverType[newHeadCoor.x][newHeadCoor.y] == CoverType::Snake)
        solidify(snake);
    else
    {
        coverType[newHeadCoor.x][newHeadCoor.y] = CoverType::Snake;
        coverSnake[newHeadCoor.x][newHeadCoor.y] = snake;
    }
}

void Logic::die(Snake *snake)
{
    for (auto node = snake->tail;; node = node->next(snake->reverse))
    {
        coverType[node->c().x][node->c().y] = CoverType::None;
        if (node == snake->head)
            break;
    }

    snakeTotalLength[snake->player] -= snake->length;

    auto &snakesVector = snakes[snake->player];
    snakesVector.erase(find(snakesVector.begin(), snakesVector.end(), snake));
}

void Logic::solidify(Snake *snake)
{
    FUNCNAME;
    int minX = SIZE, minY = SIZE, maxX = 0, maxY = 0;

    vector<ListNode *> edge;
    for (auto node = snake->head; node == snake->head || node->c() != snake->head->c();
         node = node->prev(snake->reverse))
        edge.push_back(node);

    for (auto node : edge)
    {
        minX = std::min(minX, node->c().x);
        maxX = std::max(maxX, node->c().x);
        minY = std::min(minY, node->c().y);
        maxY = std::max(maxY, node->c().y);
    }

    enum class DfsType
    {
        Undetermined,
        Edge,
        Clockwise,
        Anticlockwise,
    };

    vector<vector<DfsType>> dfsType(maxX - minX + 3,
                                    vector<DfsType>(maxY - minY + 3, DfsType::Undetermined));

    for (auto node : edge)
        dfsType[node->c().x - minX + 1][node->c().y - minY + 1] = DfsType::Edge;

    const std::function<void(Coor, DfsType)> dfs = [&](Coor u, DfsType type) {
        if (u.x < 0 || u.y < 0 || u.x >= (int)dfsType.size() || u.y >= (int)dfsType.front().size())
            return;
        if (dfsType[u.x][u.y] != DfsType::Undetermined)
            return;
        dfsType[u.x][u.y] = type;
        for (int d = 0; d < 4; ++d)
            dfs(u + DIRECTION_COOR[d], type);
    };

    const Coor delta{1 - minX, 1 - minY};

    for (auto node : edge)
    {
        const auto dir = node->prevDirection(snake->reverse);
        const auto dirAnticlockwise = Direction((dir + 1) % 4);
        const auto dirClockwise = Direction((dir + 3) % 4);

        if (dfsType[0][0] != DfsType::Anticlockwise)
            dfs(node->c() + delta + DIRECTION_COOR[dirAnticlockwise], DfsType::Anticlockwise);
        if (dfsType[0][0] != DfsType::Clockwise)
            dfs(node->c() + delta + DIRECTION_COOR[dirClockwise], DfsType::Clockwise);
    }

    const auto wallType =
        snake->player == Offensive ? CoverType::OffensiveWall : CoverType::DefensiveWall;
    const auto wallDfsType =
        dfsType[0][0] == DfsType::Clockwise ? DfsType::Anticlockwise : DfsType::Clockwise;

    die(snake);

    for (int x = minX; x <= maxX; ++x)
    {
        for (int y = minY; y <= maxY; ++y)
        {
            if (dfsType[x - minX + 1][y - minY + 1] == wallDfsType)
            {
                switch (coverType[x][y])
                {
                    case CoverType::None:
                        break;
                    case CoverType::OffensiveWall:
                        --wallCount[Offensive];
                        break;
                    case CoverType::DefensiveWall:
                        --wallCount[Defensive];
                        break;
                    case CoverType::Snake:
                        die(coverSnake[x][y]);
                        break;
                }

                coverType[x][y] = wallType;
                ++wallCount[snake->player];
            }
        }
    }

    for (auto node : edge)
    {
        coverType[node->c().x][node->c().y] = wallType;
        ++wallCount[snake->player];
    }
}

int Logic::meltResult(const Snake *snake) const
{
    FUNCNAME;
    if (!snake->melt || snake->length == 1)
        return MELT_INVALID;

    const auto dc = DIRECTION_COOR[snake->direction];

    int result = 0;

    for (Coor u = snake->head->c() + dc; !isOut(u); u += dc)
    {
        if (coverType[u.x][u.y] == CoverType::OffensiveWall)
        {
            if (snake->player == Offensive)
                --result;
            else
                ++result;
        }
        else if (coverType[u.x][u.y] == CoverType::DefensiveWall)
        {
            if (snake->player == Defensive)
                --result;
            else
                ++result;
        }
    }

    return result;
}

void Logic::melt(Snake *snake)
{
    FUNCNAME;
    const auto dc = DIRECTION_COOR[snake->direction];

    for (Coor u = snake->head->c() + dc; !isOut(u); u += dc)
    {
        auto &ct = coverType[u.x][u.y];
        if (ct == CoverType::OffensiveWall)
        {
            ct = CoverType::None;
            --wallCount[Offensive];
        }
        else if (ct == CoverType::DefensiveWall)
        {
            ct = CoverType::None;
            --wallCount[Defensive];
        }
    }

    snake->melt = false;
}

bool Logic::canSplit(const Snake *snake) const
{
    FUNCNAME;
    return snake->length > 1 && snakeCount(snake->player) < MAX_SNAKE;
}

void Logic::split(Snake *snake)
{
    FUNCNAME;
    auto *oldSnakeNewTail = snake->tail;
    for (int i = 0; i < snake->length / 2; ++i)
        oldSnakeNewTail = oldSnakeNewTail->next(snake->reverse);

    auto *newSnake = new Snake{currentRound,
                               snake->player,
                               snake->tail,
                               oldSnakeNewTail->prev(snake->reverse),
                               snake->tail->next(snake->reverse)->prevDirection(snake->reverse),
                               snake->length / 2,
                               snake->bank,
                               false,
                               !snake->reverse};
    snakePool.push_back(newSnake);

    snake->length = (snake->length + 1) / 2;
    snake->bank = 0;
    snake->tail = oldSnakeNewTail;

    for (auto *node = newSnake->head; node != snake->tail; node = node->prev(newSnake->reverse))
        coverSnake[node->c().x][node->c().y] = newSnake;

    auto &snakesVector = snakes[snake->player];
    snakesVector.insert(std::next(std::find(snakesVector.begin(), snakesVector.end(), snake)),
                        newSnake);

    currentSnake = newSnake;
}

void Logic::newRound()
{
    FUNCNAME;

    ++currentRound;

    // disappear should be handled first to avoid newly added item being removed immediately
    for (const auto &c : itemDisappear[currentRound])
        itemParam[c.x][c.y] = 0;

    for (const auto &item : itemAppear[currentRound])
    {
        if (coverType[item.coordinate.x][item.coordinate.y] == CoverType::Snake)
        {
            if (item.param == MELT_PARAM)
                coverSnake[item.coordinate.x][item.coordinate.y]->melt = true;
            else
                coverSnake[item.coordinate.x][item.coordinate.y]->bank += item.param;
        }
        else
            itemParam[item.coordinate.x][item.coordinate.y] = item.param;
    }
}

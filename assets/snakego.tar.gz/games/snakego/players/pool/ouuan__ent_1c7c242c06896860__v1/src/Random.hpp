#pragma once

#include "Agent.hpp"

class Random : public Agent
{
   public:
    explicit Random(int argc, char **argv) : Agent(argc, argv)
    {}

   private:
    Operation nextMove(const Logic *o) override;
};

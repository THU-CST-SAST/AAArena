#include "Mcts.hpp"

#include <algorithm>
#include <iostream>

static const int TIME_LIMIT = 950;

Mcts::Mcts(int argc, char** argv) : Agent(argc, argv)
{}

Operation Mcts::nextMove(const Logic* o)
{
    start = std::chrono::steady_clock::now();

    auto* root = new MctsNode{o->player()};

    while (!timeout())
    {
        if (logic)
            delete logic;
        logic = new Logic(*o);
        search(root);
    }

    std::cerr << "Round #" << logic->currentRoundNumber() << std::endl;
    for (auto ch : root->children)
        std::cerr << OPERATION_NAME[ch->op] << ": " << ch->totalOffensiveWin << "/" << ch->visit
                  << std::endl;
    std::cerr << "----------" << std::endl;

    const Operation result = (*std::max_element(root->children.begin(), root->children.end(),
                                                [](MctsNode* lhs, MctsNode* rhs) {
                                                    return lhs->visit < rhs->visit;
                                                }))
                                 ->op;

    delete root;

    return result;
}

bool Mcts::timeout() const
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now() - start).count() > TIME_LIMIT;
}

double Mcts::search(MctsNode* u, int depth)
{
    if (u->visit == 0)
    {
        const auto winner = logic->winner();
        switch (winner)
        {
            case Winner::Playing:
                break;
            case Winner::Tie:
                u->selfOffensiveWin = 0.5;
                break;
            case Winner::Offensive:
                u->selfOffensiveWin = 1;
                break;
            case Winner::Defensive:
                u->selfOffensiveWin = 0;
                break;
        }
        if (winner != Winner::Playing)
            u->isEnd = true;
        else if (depth == 0)
        {
            u->isEnd = true;
            int offensiveScore = logic->totalWall(Offensive) + logic->totalSnake(Offensive) * 2;
            if (logic->snakeCount(Offensive) == 0)
                offensiveScore /= 10;
            int defensiveScore = logic->totalWall(Defensive) + logic->totalSnake(Defensive) * 2;
            if (logic->snakeCount(Defensive) == 0)
                defensiveScore /= 10;
            u->selfOffensiveWin = (double)offensiveScore / (offensiveScore + defensiveScore);
        }
        else
        {
            const auto ops = logic->validMoves();
            u->children.reserve(ops.size());
            for (auto op : ops)
            {
                auto* v = new MctsNode{Player(logic->player() ^ 1), op, u};
                u->children.push_back(v);
            }
        }
    }

    if (u->isEnd)
    {
        u->update(u->selfOffensiveWin);
        return u->selfOffensiveWin;
    }

    double mx = -1;
    MctsNode* choose = nullptr;

    for (auto v : u->children)
    {
        if (!v->visit)
        {
            choose = v;
            break;
        }
        if (v->uct(u->first) > mx)
        {
            mx = v->uct(u->first);
            choose = v;
        }
    }

    logic->handleMove(choose->op);
    double res = search(choose, depth - 1);
    u->update(res);

    return res;
}

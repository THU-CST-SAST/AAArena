#pragma once

#include <array>
#include <string>
#include <vector>

using std::array;
using std::vector;

static const int SIZE = 16;
static const int MAX_ROUND = 512;
static const int MELT_INVALID = 114514;

struct Coor
{
    int x, y;

    Coor operator+(const Coor &rhs) const
    {
        return {x + rhs.x, y + rhs.y};
    }

    Coor operator-(const Coor &rhs) const
    {
        return {x - rhs.x, y - rhs.y};
    }

    Coor operator*(int rhs) const
    {
        return {x * rhs, y * rhs};
    }

    Coor &operator+=(const Coor &rhs)
    {
        x += rhs.x;
        y += rhs.y;
        return *this;
    }

    bool operator==(const Coor &rhs) const
    {
        return x == rhs.x && y == rhs.y;
    }

    bool operator!=(const Coor &rhs) const
    {
        return !this->operator==(rhs);
    }

    friend Coor operator*(int lhs, const Coor &rhs)
    {
        return {lhs * rhs.x, lhs * rhs.y};
    }
};

static const Coor DIRECTION_COOR[4] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};

struct Item
{
    Coor coordinate;
    int param;
};

enum Direction
{
    Right = 0,
    Up = 1,
    Left = 2,
    Down = 3,
};

class ListNode
{
   public:
    ListNode(Coor c, bool reverse, ListNode *prev = nullptr, ListNode *next = nullptr)
        : coordinate(c)
    {
        if (prev)
            setPrev(prev, reverse);
        if (next)
            setNext(next, reverse);
    }

    Coor c() const
    {
        return coordinate;
    }

    /*
     * @notes a non-null prev doesn't necessarily mean the tail, check snake->tail instead
     */
    ListNode *prev(bool reverse) const
    {
        return reverse ? nextNode : prevNode;
    }

    /*
     * @notes a non-null next doesn't necessarily mean the head, check snake->head instead
     */
    ListNode *next(bool reverse) const
    {
        return reverse ? prevNode : nextNode;
    }

    /*
     * @notes the result is undefined when prev() is nullptr
     */
    Direction prevDirection(bool reverse) const
    {
        return reverse ? nextDir : prevDir;
    }

    /*
     * @notes the result is undefined when next() is nullptr
     */
    Direction nextDirection(bool reverse) const
    {
        return reverse ? prevDir : nextDir;
    }

    /*
     * @notes *node* shouldn't be nullptr
     */
    void setPrev(ListNode *node, bool reverse)
    {
        if (reverse)
        {
            nextNode = node;
            nextDir = calcDirection(node->coordinate);
        }
        else
        {
            prevNode = node;
            prevDir = calcDirection(node->coordinate);
        }
    }

    /*
     * @notes *node* shouldn't be nullptr
     */
    void setNext(ListNode *node, bool reverse)
    {
        if (reverse)
        {
            prevNode = node;
            prevDir = calcDirection(node->coordinate);
        }
        else
        {
            nextNode = node;
            nextDir = calcDirection(node->coordinate);
        }
    }

    void setCoor(Coor c)
    {
        coordinate = c;
    }

   private:
    Direction calcDirection(Coor toCoordinate) const
    {
        const auto delta = toCoordinate - coordinate;
        for (int i = 0; i < 4; ++i)
        {
            if (delta == DIRECTION_COOR[i])
            {
                return (Direction)i;
            }
        }
        throw "ListNode::calcDirection received a toCoordinate that is in none of the four directions.";
    }

   private:
    Coor coordinate;
    ListNode *prevNode;
    ListNode *nextNode;
    Direction prevDir;
    Direction nextDir;
};

enum Player
{
    Offensive = 0,
    Defensive = 1,
};

struct Snake
{
    int lastMovedRound;
    Player player;
    ListNode *head;
    ListNode *tail;
    Direction direction;
    int length;
    int bank;
    bool melt;
    bool reverse;
    bool isInitial = false;
};

enum class CoverType
{
    None,
    OffensiveWall,
    DefensiveWall,
    Snake,
};

enum class Winner
{
    Offensive,
    Defensive,
    Tie,
    Playing,
};

enum class MoveResult
{
    Success,
    Dead,
    Solidify,
    Lose,
};

enum Operation
{
    MoveRight = 1,
    MoveUp = 2,
    MoveLeft = 3,
    MoveDown = 4,
    Melt = 5,
    Split = 6,
};

static const std::string OPERATION_NAME[7] = {"",         "MoveRight", "MoveUp", "MoveLeft",
                                              "MoveDown", "Melt",      "Split"};

class Logic
{
   public:
    explicit Logic(const vector<Item> &itemList, const vector<int> &itemTimeList);

    Logic(const Logic &o);

    virtual ~Logic();

    vector<Operation> validMoves() const;

    void handleMove(Operation op);

    Winner winner() const;

    Player player() const;

    int snakeCount(Player player) const;

    bool isEnd() const;

    int currentRoundNumber() const;

    int totalWall(Player player) const;

    int totalSnake(Player player) const;

   private:
    /*
     * @param snake the snake to move
     * @param dir the direction of the move
     * @returns the result of the move
     */
    MoveResult moveResult(const Snake *snake, Direction direction) const;

    /*
     * @param snake the snake to move
     * @param dir the direction of the move
     * @notes it's assumed that the move result is either Success or Solidify
     */
    void move(Snake *snake, Direction direction);

    /*
     * @param the snake to die
     * @notes the coverType of the nodes' coordinates will be set to NoCover
     */
    void die(Snake *snake);

    /*
     * @param snake the snake which encloses the solidified area
     * @notes this kills all snakes in the solified area including *snake* itself
     * @notes the snake's head should overlap with another node of it
     */
    void solidify(Snake *snake);

    /*
     * @param snake the snake to use the melt item
     * @returns *MELT_INVALID* when invalid to melt; <oppMelted> - <selfMelted> instead
     */
    int meltResult(const Snake *snake) const;

    /*
     * @param snake the snake to use the melt item
     * @notes it's assumed that the melt is valid
     */
    void melt(Snake *snake);

    /*
     * @param snake the snake to be split
     * @returns whether it's valid to split
     */
    bool canSplit(const Snake *snake) const;

    /*
     * @param snake the snake to be split
     * @notes it's assumed that the split is valid
     */
    void split(Snake *snake);

    /*
     * @brief go to the next round, i.e. update currentRound & generate/remove items
     */
    void newRound();

   private:
    // itemAppear[time] contains items that appear at *time*
    array<vector<Item>, MAX_ROUND> itemAppear;
    // itemDisappear[time] contians coordinates of items that disappear at *time*
    array<vector<Coor>, MAX_ROUND> itemDisappear;

    // itemParam[x][y] is the param (0 for no item) of the item currently at (x, y)
    array<array<int, SIZE>, SIZE> itemParam;

    // snakes[player] contains the snakes of *player*
    array<vector<Snake *>, 2> snakes;

    // coverType[x][y] is the type of the thing covering (x, y)
    array<array<CoverType, SIZE>, SIZE> coverType;

    // coverSnake[x][y] is the snake covering (x, y) when coverType[x][y] is SnakeCover
    // it can be anything when coverSnake[x][y] is not SnakeCover
    array<array<Snake *, SIZE>, SIZE> coverSnake;

    // wallCount[player] is the number of walls owned by *player*
    array<int, 2> wallCount;
    array<int, 2> snakeTotalLength;

    int currentRound;  // starts from 0
    Player currentPlayer;
    Snake *currentSnake;

    // WARN: remember to add new snakes and new nodes to the pools!
    vector<Snake *> snakePool;
    vector<ListNode *> listNodePool;
};

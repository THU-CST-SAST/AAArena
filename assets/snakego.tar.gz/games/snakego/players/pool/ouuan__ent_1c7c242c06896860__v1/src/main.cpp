#include "Mcts.hpp"
#include "Random.hpp"
#include "Stupid.hpp"

int main(int argc, char **argv)
{
    Random  //
        agent(argc, argv);
    agent.run();
}

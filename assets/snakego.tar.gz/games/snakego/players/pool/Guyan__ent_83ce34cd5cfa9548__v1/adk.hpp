#pragma once

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <set>
#include <string>
#include <vector>
#include <cstring>
#define DEBUG

/*   Channel API Begins   */

class Channel
{
public:
	virtual ~Channel() = default;
	virtual bool send( char* msg, size_t len ) = 0;
	virtual bool recv( char* buf, size_t len ) = 0;
};

Channel* socket_channel( const std::string& host, unsigned int port );
Channel* stdio_channel();

#if defined( __unix__ ) || ( defined( __APPLE__ ) && defined( __MACH__ ) ) || defined( __CYGWIN__ )
#define ADK_POSIX
#elif defined( WIN32 ) || defined( _WIN32 ) || defined( __WIN32__ ) || defined( __NT__ )
#define ADK_WIN
#endif

/*   Channel API Ends   */

/*   Posix TCP Socket Channel Impl Begins   */

#ifdef ADK_POSIX

#include <arpa/inet.h>
#include <cstdio>
#include <cstdlib>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

class PosixSocket : public Channel
{
public:
	explicit PosixSocket( int internal_socket );
	~PosixSocket() override;
	bool send( char* msg, size_t len ) override;
	bool recv( char* buf, size_t len ) override;

private:
	int internal_socket;
};

inline PosixSocket::PosixSocket( int internal_socket ) : internal_socket( internal_socket ) {}

inline PosixSocket::~PosixSocket() { close( internal_socket ); }

inline bool PosixSocket::send( char* msg, size_t len ) { return ::send( internal_socket, msg, len, 0 ) != -1; }

inline bool PosixSocket::recv( char* buf, size_t len ) { return ::recv( internal_socket, buf, len, 0 ) == len; }

inline Channel* socket_channel( const std::string& host, unsigned int port )
{
	int sock = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	if ( sock == -1 )
		return nullptr;

	struct sockaddr_in addr = { 0 };
	addr.sin_family = AF_INET;
	addr.sin_port = htons( port );
	addr.sin_addr.s_addr = inet_addr( host.c_str() );
	if ( connect( sock, (struct sockaddr*) &addr, sizeof( addr ) ) == -1 )
		return nullptr;

	return new PosixSocket( sock );
}

#endif // ADK_POSIX

/*   Posix TCP Socket Channel Impl Ends   */

/*   Winsock2 Channel Impl Begins   */

#ifdef ADK_WIN

#pragma comment( lib, "ws2_32.lib" )

#include <WS2tcpip.h>
#include <WinSock2.h>

class WindowsSocket : public Channel
{
public:
	WindowsSocket( SOCKET internal_socket );
	virtual ~WindowsSocket();
	virtual bool send( char* msg, size_t len ) override;
	virtual bool recv( char* buf, size_t len ) override;

private:
	SOCKET internal_socket;
};

inline WindowsSocket::WindowsSocket( SOCKET internal_socket ) : internal_socket( internal_socket ) {}

inline WindowsSocket::~WindowsSocket()
{
	shutdown( internal_socket, SD_SEND );
	closesocket( internal_socket );
	WSACleanup();
}

inline bool WindowsSocket::send( char* msg, size_t len )
{
	return ::send( internal_socket, msg, len, 0 ) != SOCKET_ERROR;
}

inline bool WindowsSocket::recv( char* buf, size_t len ) { return ::recv( internal_socket, buf, len, 0 ) == len; }

inline Channel* socket_channel( const std::string& host, unsigned int port )
{
	WSADATA wsaData;
	int iResult;

	SOCKET ConnectSocket = INVALID_SOCKET;
	struct sockaddr_in clientService;

	iResult = WSAStartup( MAKEWORD( 2, 2 ), &wsaData );
	if ( iResult != NO_ERROR )
	{
		fprintf( stderr, "WSAStartup failed: %d\n", iResult );
		return nullptr;
	}

	ConnectSocket = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	if ( ConnectSocket == INVALID_SOCKET )
	{
		fprintf( stderr, "Error at socket(): %ld\n", WSAGetLastError() );
		WSACleanup();
		return nullptr;
	}

	clientService.sin_family = AF_INET;
	clientService.sin_addr.s_addr = inet_addr( host.c_str() );
	clientService.sin_port = htons( port );

	iResult = connect( ConnectSocket, (SOCKADDR*) &clientService, sizeof( clientService ) );
	if ( iResult == SOCKET_ERROR )
	{
		closesocket( ConnectSocket );
		fprintf( stderr, "Unable to connect to server: %ld\n", WSAGetLastError() );
		WSACleanup();
		return nullptr;
	}

	return new WindowsSocket( ConnectSocket );
}

#endif // ADK_WIN

/*   Winsock2 Channel Impl Ends   */

/*   StdIO Channel Impl Begins   */

class StdIO : public Channel
{
public:
	~StdIO() override;
	bool send( char* msg, size_t len ) override;
	bool recv( char* buf, size_t maxlen ) override;
};

inline StdIO::~StdIO() = default;

inline bool StdIO::send( char* msg, size_t len )
{
	for ( size_t i = 0; i < len; i++ )
	{
		putchar( msg[i] );
	}
	fflush( stdout );
	return true;
}

inline bool StdIO::recv( char* buf, size_t len )
{
	size_t cnt = 0;
	while ( cnt < len )
	{
		int c = getchar();
		if ( c == EOF )
		{
			return false;
		}
		buf[cnt++] = (char) c;
	}
	return true;
}

inline Channel* stdio_channel() { return new StdIO(); }

/*   StdIO Channel Impl Ends   */


struct Operation
{
	int type;
};

const Operation OP_RIGHT { 1 };
const Operation OP_UP { 2 };
const Operation OP_LEFT { 3 };
const Operation OP_DOWN { 4 };
const Operation OP_RAILGUN { 5 };
const Operation OP_SPLIT { 6 };

#define PROPERTY( TYPE_NAME, NAME )                   \
public:                                               \
	const TYPE_NAME& NAME() const { return _##NAME; } \
                                                      \
private:                                              \
	TYPE_NAME _##NAME

using std::vector;

struct Item {
	int x , y , id , time , type , param;
	bool eaten , expired;
	bool operator < ( const Item & rhs ) const {
		return time < rhs.time;
	}
} item_list[520];
int item_cnt;

struct Point {
	int x , y;
	Point(){}
	Point( int a , int b ):x( a ) , y( b ) {}
	bool operator == ( const Point & rhs ) const {
		return x == rhs.x && y == rhs.y;
	}
};

struct Snake {
	int length_bank , railgun;
	bool _spc;
	vector<Point> body;
	const Point & operator []( const int & idx ) const {
		return body[idx];
	}
	inline void clear( void ) { _spc = length_bank = railgun = 0; body.clear(); }
	Snake() { length_bank = railgun = 0; body.clear(); _spc = 0; }
};

const int MAX_ROUND = 512;
const int GOOD_ROUND = 8;
const int NUM_LIMIT = 4;
const int _dir[4][2] = { { 1 , 0 } , { 0 , 1 } , { -1 , 0 } , { 0 , -1 } };
const int _opposite_dir[5] = { 2 , 3 , 0 , 1 , 4 };

inline bool INMAP( const int& x , const int& y ) {
	return x >= 0 && y >= 0 && x < 16 && y < 16;
}
inline bool INMAP( const Point & p ) {
	return p.x >= 0 && p.y >= 0 && p.x < 16 && p.y < 16;
}
inline int getdir( const Snake & s ) {
	if( s.body.size() < 2 ) return -1;
	static Point a , b;
	a = s.body[0];
	b = s.body[1];
	for( int i = 0 ; i < 4 ; ++i )
		if( a.x == b.x + _dir[i][0] && a.y == b.y + _dir[i][1] )
			return i;
	fprintf( stderr , "Wrong getdir!\n");
	abort();
}

struct Context {
	Snake S[8];
	bool S_use[8];
	int s[2][4] , s_cnt[2] , s_cur[2];
	int now_round , now_player , wall[16][16] , now_snake_id;
	int item_id[16] , item_id_cnt , item_list_cur;
	void print( void ) {
		#ifdef DEBUG
		fprintf(stderr,"now_round = %d now_player = %d now_snake_id = %d\n",now_round,now_player,now_snake_id);
		fprintf(stderr,"camp 0: %d\n",s_cnt[0]);
		for( int i = 0 ; i < s_cnt[0] ; ++i ) {
			Snake & snk = S[s[0][i]];
			fprintf( stderr , "lb = %d rg = %d id = %d",snk.length_bank,int(snk.railgun),s[0][i]);
			for( const Point & p : snk.body )
				fprintf( stderr , "(%d,%d) ",p.x,p.y);
			fprintf( stderr , "\n" );
		}
		fprintf( stderr , "\n" );
		fprintf(stderr,"camp 1: %d\n",s_cnt[1]);
		for( int i = 0 ; i < s_cnt[1] ; ++i ) {
			Snake & snk = S[s[1][i]];
			fprintf( stderr , "lb = %d rg = %d id = %d",snk.length_bank,int(snk.railgun),s[1][i]);
			for( const Point & p : snk.body )
				fprintf( stderr , "(%d,%d) ",p.x,p.y);
			fprintf( stderr , "\n" );
		}
		for( int i = 0 ; i < 16 ; ++i ) {
			for( int j = 0 ; j < 16 ; ++j )
				fprintf(stderr,"%c",".#"[wall[i][j]>=0]);
			fprintf(stderr,"\n");
		}
		fprintf( stderr , "\n" );
		fprintf( stderr , "\n" );
		#endif
	}
	Context() {
		item_list_cur = 0;
		item_id_cnt = 0;
		memset( S_use , 0 , sizeof S_use );
		for( int i = 0 ; i < 4 ; ++i ) 
			s[0][i] = s[1][i] = 0;
		s_cnt[0] = s_cnt[1] = s_cur[0] = s_cur[1] = 0;
		for( int i = 0 ; i < 8 ; ++i ) 
			S[i].clear() , S_use[i] = 0;
		now_round = 0 , now_player = 0 , now_snake_id = 0;
		for( int i = 0 ; i < 16 ; ++i )
			for( int j = 0 ; j < 16 ; ++j )
				wall[i][j] = -1;
	}
	inline void init( void ) {
		now_round = 0 , now_player = 1 , now_snake_id = 1;
		S_use[0] = S_use[1] = 1;
		S[0].body.push_back( Point( 0 , 15 ) );
		S[1].body.push_back( Point( 15 , 0 ) );
		S[0]._spc = S[1]._spc = 1;
		s[0][0] = 0 , s[1][0] = 1;
		s_cnt[0] = s_cnt[1] = 1;
		s_cur[0] = s_cur[1] = 0;
	}
	void DEAD( const int & id ) {
		S_use[id] = 0;
	}
	int get_new_snake( void ) {
		int res = -1;
		for( int i = 0 ; i < 8 ; ++i )
			if( !S_use[i] ) {
				S[i].clear();
				res = i;
				S_use[i] = 1;
				break;
			}
		if( res == -1 ) {
			fprintf(stderr,"Wrong Context get_new_snake!\n");
			abort();
		}
		return res;
	}
	bool process( void ) {
		static int snake_map[16][16] , _item_id_cnt , _item_id[16];
		static bool eat[16] , _flag;
		if( s_cnt[0] + s_cnt[1] == 0 ) return false;
		memset( eat , 0 , sizeof eat ) , _flag = 0;
		for( int i = 0 ; i < 16 ; ++i )
			for( int j = 0 ; j < 16 ; ++j )
				snake_map[i][j] = -1;
		for( int i = 0 ; i < 8 ; ++i )
			if( S_use[i] ) 
				for( const Point & p : S[i].body )
					snake_map[p.x][p.y] = i;

		// process D
		for( int i = 0 ; i < item_id_cnt ; ++i ) {
			Item & it = item_list[item_id[i]];
			if( snake_map[it.x][it.y] >= 0 ) {
				eat[i] = 1 , _flag = 1;
				if( it.type == 0 ) S[snake_map[it.x][it.y]].length_bank += it.param;
				else if( it.type == 2 ) S[snake_map[it.x][it.y]].railgun = 1;
				else {
					fprintf(stderr,"Wrong Context Process!\n");
					abort();
				}
			}
		}
		if( _flag ) {
			_item_id_cnt = 0;
			for( int i = 0 ; i < item_id_cnt ; ++i )
				if( !eat[i] )
					_item_id[_item_id_cnt++] = item_id[i];
			memcpy( item_id , _item_id , sizeof( int ) * _item_id_cnt );
			item_id_cnt = _item_id_cnt;
		}

		// process AB
		++now_round;
		if( s_cnt[0] == 0 ) {
			now_player = 1;
			s_cur[0] = -1;
			s_cur[1] = 0;
			now_snake_id = s[1][0];
		} else {
			now_player = 0;
			s_cur[1] = -1;
			s_cur[0] = 0;
			now_snake_id = s[0][0];
		}
		

		_item_id_cnt = 0;
		for( int i = 0 ; i < item_id_cnt ; ++i )
			if( item_list[item_id[i]].time + 15 >= now_round )
				_item_id[_item_id_cnt++] = item_id[i];
		memcpy( item_id , _item_id , sizeof( int ) * _item_id_cnt );
		item_id_cnt = _item_id_cnt;
		while( item_list_cur < item_cnt ) {
			if( item_list[item_list_cur].time > now_round ) break;
			if( item_list[item_list_cur].time <= now_round ) {
				Item & it = item_list[item_list_cur];
				if( snake_map[it.x][it.y] >= 0 ) {
					if( it.type == 0 ) S[snake_map[it.x][it.y]].length_bank += it.param;
					else if( it.type == 2 ) S[snake_map[it.x][it.y]].railgun = 1;
					else {
						fprintf(stderr,"Wrong Context Process!\n");
						abort();
					}
				} else 
					item_id[item_id_cnt++] = item_list_cur;
			} else {
				fprintf( stderr , "Wrong Context Process!2\n");
				abort();
			}
			++item_list_cur;
		}

		return true;

	}
	bool get_next_snake( void ) {
		if( s_cur[now_player] >= s_cnt[now_player] - 1 ) {
			if( now_player == 0 ) {
				now_player = 1;
				if( s_cnt[1] == 0 ) 	return false;
				s_cur[1] = -1;
			} else 
				return false;
		}
		now_snake_id = s[now_player][++s_cur[now_player]];
		return true;
	}
	bool split( void ) {
		Snake & snk = S[now_snake_id];
		if( snk.body.size() < 2 ) {
			return false;
		}
		if( s_cnt[now_player] > 3 ) {
			return false;
		}
		int new_snake_id = get_new_snake();
		Snake & nsnk = S[new_snake_id];
		++s_cnt[now_player];
		for( int i = s_cnt[now_player] - 1 ; i > s_cur[now_player] + 1 ; --i )
			s[now_player][i] = s[now_player][i - 1];
		s[now_player][s_cur[now_player] + 1] = new_snake_id;
		int mid = ( snk.body.size() + 1 ) / 2;
		for( int i = snk.body.size() - 1 ; i >= mid ; --i ) {
			nsnk.body.push_back( snk[i] );
			snk.body.pop_back();
		}
		nsnk.length_bank = snk.length_bank;
		snk.length_bank = 0;
		now_snake_id = new_snake_id;
		++s_cur[now_player];
		return true;
	}
	bool railgun( void ) {
		Snake & snk = S[now_snake_id];
		if( snk.body.size() < 2 ) {
			return false;
		}
		if( snk.railgun == 0 ) {
			return false;
		}
		snk.railgun = 0;
		int dir = getdir( snk );
		static Point hd , tmp;
		hd = snk[0];
		tmp = Point( hd.x + _dir[dir][0] , hd.y + _dir[dir][1] );
		while( INMAP( hd ) ) {
			wall[hd.x][hd.y] = -1;
			hd.x += _dir[dir][0];
			hd.y += _dir[dir][1];
		}
		return true;
	}
	void bfs( int map[][16] , int x , int y , int v , bool ok[] ) {
		static Point que[1005] , p;
		static int he , ta;
		he = ta = 1 , que[1] = Point( x , y );
		while( he <= ta ) {
			p = que[he++];
			if( !INMAP( p ) ) {
				ok[v] = 0;
				break;
			}
			if( map[p.x][p.y] > 0 ) continue;
			map[p.x][p.y] = v;
			for( int i = 0 ; i < 4 ; ++i ) {
				x = p.x + _dir[i][0];
				y = p.y + _dir[i][1];
				que[++ta] = Point( x , y );
			}
		}
	}
	bool move( int dir ) {
		static int _tmp_snake_list[4] , _tmp_snake_cnt , _tmp_wall[16][16] , dir1 , dir2;
		static Point nhd;
		static bool ok[4]; 
		Snake & snk = S[now_snake_id];
		int now_dir = getdir( snk );
		if( now_dir >= 0 && dir == _opposite_dir[now_dir] && snk.body.size() > 2 ) {
			return false;
		}
		if( !snk._spc || now_round > 8 ) {
			if( snk.length_bank > 0 ) 
				--snk.length_bank;
			else 
				snk.body.pop_back();
		}
		
		nhd.x = snk[0].x + _dir[dir][0];
		nhd.y = snk[0].y + _dir[dir][1];
		// bewall
		static int _r;
		_r = -1;
		for( int i = snk.body.size() - 1 ; i > 0 ; --i ) 
			if( nhd == snk[i] ) {
				_r = i;
				break;
			}
		if( _r >= 0 ) {
			memset( _tmp_wall , 0 , sizeof _tmp_wall );
			ok[0] = 0 , ok[1] = ok[2] = ok[3] = 1;
			for( int i = 0 , x , y , a , b ; i <= _r ; ++i ) {
				if( i < _r ) 
				    x = snk[i].x , y = snk[i].y , a = snk[i + 1].x , b = snk[i + 1].y;
				else 
					x = snk[i].x , y = snk[i].y , a = snk[0].x , b = snk[0].y;

				_tmp_wall[x][y] = 3;
				if( x == a ) {
					if( b > y ) dir1 = 0;
					else dir1 = 2;
				} else {
					if( a > x ) dir1 = 3;
					else dir1 = 1;
				}
				dir2 = _opposite_dir[dir1];
				bfs( _tmp_wall , x + _dir[dir1][0] , y + _dir[dir1][1] , 1 , ok );
				bfs( _tmp_wall , x + _dir[dir2][0] , y + _dir[dir2][1] , 2 , ok );
			}
			for( int i = 0 ; i < 16 ; ++i )
				for( int j = 0 ; j < 16 ; ++j )
					if( ok[_tmp_wall[i][j]] )
						wall[i][j] = now_player;

			_tmp_snake_cnt = 0;
			for( int i = 0 ; i < s_cnt[now_player] ; ++i ) {
				int snk_id = s[now_player][i];
				nhd = S[snk_id][0];
				if( wall[nhd.x][nhd.y] >= 0 ) {
					DEAD( snk_id );
					if( i <= s_cur[now_player] )
						--s_cur[now_player];
				} else {
					_tmp_snake_list[_tmp_snake_cnt++] = snk_id;
				}
			}
			memcpy( s[now_player] , _tmp_snake_list , sizeof( int ) * _tmp_snake_cnt );
			s_cnt[now_player] = _tmp_snake_cnt;

			_tmp_snake_cnt = 0;
			for( int i = 0 ; i < s_cnt[now_player^1] ; ++i ) {
				nhd = S[s[now_player^1][i]][0];
				if( wall[nhd.x][nhd.y] >= 0 ) 
					DEAD( s[now_player^1][i] );
				else 
					_tmp_snake_list[_tmp_snake_cnt++] = s[now_player^1][i];
			}
			memcpy( s[now_player^1] , _tmp_snake_list , sizeof( int ) * _tmp_snake_cnt );

			return true;
		} 
		// dead
		bool dead_flag = 0;
		if( !INMAP( nhd ) ) dead_flag = 1;
		else {
			if( wall[nhd.x][nhd.y] >= 0 ) dead_flag = 1;
			if( !dead_flag ) {
				for( int i = 0 ; i < 8 ; ++i ) 
					if( S_use[i] ) {
						for( const Point & p : S[i].body )
							if( p == nhd ) {
								dead_flag = 1;
								break;
							}
						if( dead_flag ) break;
					}
			}
		}
		if( dead_flag ) {
			DEAD( now_snake_id );
			_tmp_snake_cnt = 0;
			for( int i = s_cur[now_player] ; i < s_cnt[now_player] - 1 ; ++i ) {
				s[now_player][i] = s[now_player][i + 1];				
			}
			--s_cur[now_player] , --s_cnt[now_player];
			return true;
		}
		// just go
		snk.body.insert( snk.body.begin() , nhd );
		return true;
	}
	inline const Snake & NOWSNAKE( void ) {
		return S[now_snake_id];
	}
	inline bool do_operation( Operation op ) {
		if( op.type == 5 ) {
			if( !railgun() ) 
				return false;
		} else if( op.type == 6 ) {
			if( !split() ) 
				return false;
		} else if( op.type >= 1 && op.type <= 4 ) {
			if( !move( op.type - 1 ) )
				return false;
		} else return false;
		return get_next_snake() || process();
	}
	inline int get_val( int T ) const {
		int a = 0 , b = 0;
		for( int i = 0 ; i < s_cnt[T] ; ++i )
			a += S[s[T][i]].body.size();
		for( int i = 0 ; i < s_cnt[T^1] ; ++i )
			b += S[s[T^1][i]].body.size();
		for( int i = 0 ; i < 16 ; ++i )
			for( int j = 0 ; j < 16 ; ++j ) {
				a += ( wall[i][j] == T );
				b += ( wall[i][j] == ( T ^ 1 ) );
			}
		return a - b;
	}
	bool judge_operation( int op ) {
		static bool d[4] , flag , bloc[16][16];
		static int now_dir;
		Snake & snk = S[now_snake_id];
		static Point hd;
		if( op >= 1 && op <= 4 ) {
			d[0] = d[1] = d[2] = d[3] = 1;
			now_dir = getdir( snk );
			if( now_dir == -1 ) now_dir = 4;
			if( op - 1 == _opposite_dir[now_dir] ) return false;
			memset( bloc , 0 , sizeof bloc );
			for( int i = 0 ; i < 16 ; ++i )
				for( int j = 0 ; j < 16 ; ++j )
					if( wall[i][j] >= 0 )
						bloc[i][j] = 1;
			for( int i = 0 ; i < 8 ; ++i )
				if( S_use[i] )
					for( const Point & v : S[i].body )
						bloc[v.x][v.y] = 1;
			hd = snk[0];
			for( int i = 0 , tx , ty ; i < 4 ; ++i ) {
				if( i == _opposite_dir[now_dir] ) {
					d[i] = 0;
					continue;
				}
				tx = hd.x + _dir[i][0] , ty = hd.y + _dir[i][1];
				if( !INMAP( tx , ty ) ) {
					d[i] = 0;
					continue;
				}
				if( bloc[tx][ty] ) {
					d[i] = 0;
					continue;
				}
			}
			flag = 0;
			for( int i = 0 ; i < 4 ; ++i ) flag |= d[i];
			if( flag ) {
				if( d[op-1] ) return true;
				return false;
			} else return true;
		}
		else if( op == 6 ) {
			if( S[now_snake_id].body.size() < 2 || s_cnt[now_player] == 4 ) return false;
		} else if( op == 5 ) {
			if( S[now_snake_id].railgun == 0 || S[now_snake_id].body.size() < 2 ) return false;
			now_dir = getdir( snk );
			hd = S[now_snake_id].body[0];
			bool _flag = 0;
			while( INMAP( hd ) ) {
				if( wall[hd.x][hd.y] == ( now_player ^ 1 ) ) {
					_flag = 1;
					break;
				}
				hd.x += _dir[now_dir][0];
				hd.y += _dir[now_dir][1];
			}
			if( _flag == 0 ) return false;
		} else abort();
		return true;
	}
};

/*   AI-defined Interface Begins   */

using OpHistory = std::vector<std::vector<Operation>>;

Operation make_your_decision( const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_history );

void game_over( int gameover_type, int winner, int p0_score, int p1_score );

namespace SnakeGoAI {

	Channel* ch;
	OpHistory op_history;

	int read_short();
	int read_int();
	void read_item_list();
	void append_op( Operation op );
	[[noreturn]] void handle_gameover();
	static void crash();
	Context ctx;
	int _player;

	void SnakeGoAI( int argc, char** argv ) 
	{
		if ( argc == 1 )
		{
			ch = stdio_channel();
		}
		else if ( argc == 3 )
		{
			ch = socket_channel( argv[1], atoi( argv[2] ) );
		}
		if ( ch == nullptr )
		{
			fprintf( stderr, "Failed to init channel\n" );
			crash();
		}

		int length = read_short(), width = read_short(), max_round = read_int(), player = read_short();
		_player = player;
		read_item_list();
		ctx.init(); ctx.process();
		while ( true )
		{

			if ( player == ctx.now_player )
			{
				Operation op = make_your_decision( ctx.NOWSNAKE(), ctx, op_history );
				append_op( op );
				ctx.do_operation( op );
				char msg[] = { 0, 0, 0, 1, (char) op.type };
				bool send_ok = ch->send( msg, 5 );
				int ack_type = read_short();
				if ( ack_type == 0x11 )
				{
					handle_gameover();
				}
				else if ( !send_ok || ack_type != op.type )
				{
					crash();
				}
			}
			else
			{
				int type = read_short();
				if ( type >= 1 && type <= 6 )
				{
					Operation op { type };
					append_op( op );
					ctx.do_operation( op );
				}
				else if ( type == 0x11 )
				{
					handle_gameover();
				}
				else
				{
					crash();
				}
			}
		}
	}


	inline int read_short()
	{
		static char c = 0;
		if ( !ch->recv( &c, 1 ) )
			crash();
		return c;
	}

	#define BIG_ENDIAN_INT( C1, C2 ) \
		( ( ( static_cast<unsigned char>( C1 ) << 8 ) | ( static_cast<unsigned char>( C2 ) ) ) & 0xFFFF )

	inline int read_int()
	{
		static char c[] = { 0, 0 };
		if ( !ch->recv( c, 2 ) )
			crash();
		return BIG_ENDIAN_INT( c[0], c[1] );
	}

	void read_item_list()
	{
		if ( read_short() != 0x10 )
			crash();

		int item_count = read_int();
		if ( item_count <= 0 )
			crash();
		char* buf = new char[7 * item_count];
		if ( !ch->recv( buf, 7 * item_count ) )
			crash();
		item_cnt = item_count;

		for ( int i = 0; i < item_count; i++ )
		{
			auto& item = item_list[i];
			item.x = buf[7 * i];
			item.y = buf[7 * i + 1];
			item.id = i;
			item.type = buf[7 * i + 2];
			item.time = BIG_ENDIAN_INT( buf[7 * i + 3], buf[7 * i + 4] );
			item.param = BIG_ENDIAN_INT( buf[7 * i + 5], buf[7 * i + 6] );
			item.eaten = false;
			item.expired = false;
		}
		std::sort( item_list , item_list + item_cnt );
		delete[] buf;
		return;
	}

	void append_op( Operation op )
	{
		int op_history_idx = 2 * ( ctx.now_round - 1 ) + ctx.now_player;
		while ( op_history.size() <= op_history_idx )
		{
			op_history.emplace_back();
		}
		op_history[op_history_idx].push_back( op );
	}
	inline void handle_gameover()
	{
		static char dummy[] = { 0, 0, 0, 1, 1 };	
		int gameover_type = read_short(), winner = read_short(), p0_score = read_int(), p1_score = read_int();
		game_over( gameover_type, winner, p0_score, p1_score );
		while( 1 ) {}
	}
	inline void crash() { ::exit( -1 ); }
}


/*   AI Controller Ends   */
#include "adk.hpp"
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <vector>
#include <cstring>

using namespace std;

const int N = 1e5 + 5;
const double K = 1.5;
const double INF = 1e9 + 10;

struct NODE {
	Context ctx;
	int n , v , op;
	vector<int> ch;
	NODE() { n = v = op = 0 , ch.clear() , op = 0; }
	inline void clear( void ) {n = v = 0 , ch.clear() , op = 0;}
} node[N];
int nd_cnt , rt , mycamp; 
inline int get_new_node( Context ctx , int op ) {
	node[nd_cnt].clear();
	node[nd_cnt].ctx = ctx;
	node[nd_cnt].op = op;
	return nd_cnt++;
}
double calc( int u , int p ) {
	if( node[u].n == 0 ) return INF;
	return double( node[u].v ) / node[u].n
	+ K * sqrt( log( node[p].n ) / node[u].n );
}

int getval( const Context & ctx ) {
	return ctx.get_val( mycamp );
}

bool judge_end( const Context & ctx ) {
	if( ctx.now_round >= 512 ) return true;
	if( abs( getval( ctx ) ) >= 25 ) return true;
	if( ctx.s_cnt[0] + ctx.s_cnt[1] == 0 ) return true;
	return false;
}

Operation
sample_ai_make_your_decision( const Snake &snake_to_operate, const Context &ctx , int DEBUG_flag = 0 )
{
	static int snake_map[16][16];
	for( int i = 0 ; i < 16 ; ++i )
		for( int j = 0 ; j < 16 ; ++j )
			snake_map[i][j] = -1;
	for( int i = 0 ; i < 8 ; ++i )
		if( ctx.S_use[i] ) 
			for( const Point & p : ctx.S[i].body )
				snake_map[p.x][p.y] = i;
	//若该蛇有道具，执行融化射线操作
	if ( snake_to_operate.railgun  && snake_to_operate.body.size() >= 2 )
	{
		return OP_RAILGUN;
	}

	//若为该玩家操控的首条蛇且长度超过10且蛇数少于4则分裂
	if( ctx.now_snake_id == ctx.s[ctx.now_player][0] ) {
		if( snake_to_operate.body.size() >= 10 ) {
			if( ctx.s_cnt[ctx.now_player] < 4 )
				return OP_SPLIT;
		}
	}

	Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };

	int dx[4] = { 1, 0, -1, 0 };
	int dy[4] = { 0, 1, 0, -1 };
	//确定合法移动方向
	//-1代表移动非法，0代表正常移动，1代表移动触发固化
	int move[4] = { 0, 0, 0, 0 };
	for ( int dir = 0; dir < 4; dir++ )
	{
		//蛇头到达位置
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];

		//超出边界
		if ( t_x >= 16 || t_x < 0 || t_y >= 16 || t_y < 0 )
		{
			move[dir] = -1;
			continue;
		}

		//撞墙
		if ( ctx.wall[t_x][t_y] != -1 )
		{
			move[dir] = -1;
			continue;
		}

		//撞非本蛇
		if ( snake_map[t_x][t_y] != -1 &&
			 snake_map[t_x][t_y] != ctx.now_snake_id )
		{
			move[dir] = -1;
			continue;
		}

		//回头撞自己
		if ( snake_to_operate.body.size() > 2 &&
			 snake_to_operate[1].x == t_x &&
			 snake_to_operate[1].y == t_y )
		{
			move[dir] = -1;
			continue;
		}

		//移动导致固化
		if ( snake_map[t_x][t_y] == ctx.now_snake_id )
		{
			move[dir] = 1;
			continue;
		}
	}

	//玩家操控的首条蛇朝向道具移动
	if( ctx.now_snake_id == ctx.s[ctx.now_player][0] || snake_to_operate.body.size() <= 4 )
	{
		for ( int i = 0; i < item_cnt; i++ )
		{
			//道具已经消失
			if ( item_list[i].time + 15 < ctx.now_round )
				continue;

			//计算蛇头与道具的距离
			int distance = abs( item_list[i].x - snake_to_operate[0].x ) +
						   abs( item_list[i].y - snake_to_operate[0].y );

			//忽略其他因素理论上能吃到该道具
			if ( item_list[i].time <= ctx.now_round + distance &&
				 item_list[i].time + 16 > ctx.now_round + distance )
			{
				for ( int dir = 0; dir < 4; dir++ )
				{
					//移动不合法或固化
					if ( move[dir] != 0 )
						continue;

					//朝向道具方向移动
					int t_x = snake_to_operate[0].x + dx[dir];
					int t_y = snake_to_operate[0].y + dy[dir];
					int dis = abs( item_list[i].x - t_x ) + abs( item_list[i].y - t_y );
					if ( dis <= distance )
					{
						return direction[dir];
					}
				}
			}
		}
	}

	//其他蛇优先固化，或朝向蛇尾方向移动
	else
	{
		//计算蛇头与蛇尾的距离
		int distance = abs( snake_to_operate.body.back().x - snake_to_operate.body[0].x ) +
					   abs( snake_to_operate.body.back().y - snake_to_operate.body[0].y );
		for ( int dir = 0; dir < 4; dir++ )
		{
			//移动不合法或固化
			if ( move[dir] == -1 )
				continue;

			if ( move[dir] == 1 )
			{
				return direction[dir];
			}

			//朝向蛇尾方向移动
			int t_x = snake_to_operate.body[0].x + dx[dir];
			int t_y = snake_to_operate.body[0].y + dy[dir];
			int dis = abs( snake_to_operate.body.back().x - t_x ) +
					  abs( snake_to_operate.body.back().y - t_y );
			if ( dis <= distance )
			{
				return direction[dir];
			}
		}
	}

	//以上操作均未正常执行，则以如下优先顺序执行该蛇移动方向
	//向空地方向移动>向固化方向移动>向右移动

	int now_dir = getdir( snake_to_operate );
	if( now_dir == -1 ) now_dir = 4;
	if( DEBUG_flag ) {
		fprintf( stderr , "now_dir = %d _opposite_dir[dir] = %d\n" , now_dir , _opposite_dir[now_dir]);
	}
	for ( int dir = 0; dir < 4; dir++ )
	{
		if ( move[dir] == 0 && dir != _opposite_dir[now_dir] )
		{
			return direction[dir];
		}
	}
	for ( int dir = 0; dir < 4; dir++ )
	{
		if ( move[dir] == 1 && dir!= _opposite_dir[now_dir] )
		{
			return direction[dir];
		}
	}
	for( int dir = 0 ; dir < 4 ; ++dir )
		if( now_dir != _opposite_dir[dir] ) 
			return direction[dir];
	fprintf(stderr,"NO!\n");
	return OP_RIGHT;
}

void rollout( int u ) {
	Context ctx = node[u].ctx;
	Snake nowS;
	Operation op;
	int _cnt = 125;
	while( !judge_end( ctx ) && _cnt ) {
		op.type = rand() % 6 + 1;
		ctx.do_operation( op );
		--_cnt;
	}
	node[u].v += getval( ctx );
	++node[u].n;
}

void dfs( int u , int p ) {
	int cht;
	Context ctx = node[u].ctx ;
	if( node[u].ch.empty() ) {
		if( node[u].n == 0 && p >= 0 ) rollout( u );
		else {
			for( int i = 1 ; i <= 6 ; ++i ) {
				Context tmp( ctx );
				if( tmp.judge_operation( i ) ) {
					tmp.do_operation( Operation{ i } );
					cht = get_new_node( tmp , i );
					node[u].ch.push_back( cht );
				}
			}
			int tc = node[u].ch[0];
			dfs( node[u].ch[0] , u );
			node[u].v += node[tc].v;
			++node[u].n;
		}
	} else {
		double mx = -1e9 , tc;
		int num = -1;
		for( const int & v : node[u].ch ) {
			tc = calc( v , u );
			if( mx < tc ) mx = tc , num = v;
		}
		node[u].v -= node[num].v;
		dfs( num , u );
		node[u].v += node[num].v;
		++node[u].n;
	}
}

Operation MCTS( Snake nowS , Context ctx ) {
	rt = get_new_node( ctx , 0 );
	int _c = 1000;
	while( _c-- ) {  
		dfs( rt , -1 );
	}
	static pair<double,int> res[11];
	static int res_cnt;
	res_cnt = 0;
	for( const auto & v : node[rt].ch ) {
		++res_cnt;
		res[res_cnt].first = calc( v , rt );
		res[res_cnt].second = node[v].op;
	}
	sort( res + 1 , res + 1 + res_cnt , 
		[]( const pair<double,int> & a , const pair< double , int > & b ) {
			return a.first > b.first;
		}
	);
	return Operation{ res[1].second };
}

Operation
make_your_decision( const Snake &snake_to_operate, const Context &ctx , const OpHistory& tt ) {
	nd_cnt = 0; mycamp = SnakeGoAI::_player;
	if( ctx.s_cnt[mycamp] <= 0 ) return OP_RIGHT;
	Operation res = MCTS( snake_to_operate , ctx );
	return res;
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score ) {
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc , char ** argv ) {
	srand( time( 0 ) );
	SnakeGoAI::SnakeGoAI( argc , argv );
	return 0;
}

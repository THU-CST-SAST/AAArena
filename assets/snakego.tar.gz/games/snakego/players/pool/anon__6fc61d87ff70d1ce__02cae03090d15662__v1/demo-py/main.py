# coding = UTF-8
import sampleAI

if __name__ == '__main__':
    sampleAI.run()

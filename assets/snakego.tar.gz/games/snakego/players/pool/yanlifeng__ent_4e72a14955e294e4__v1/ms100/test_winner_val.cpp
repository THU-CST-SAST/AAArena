#include "snakego_env.h"
#include "cmcts.h"

SnakeGoEnv env;
CMCTS cmcts;
ActPair act_pairs;
vector<int> sug_actions;

using namespace std;

int main(){
    string file_name = "save_envs/213-142-26-12-13-0-0.json";
    // string file_name = "save_envs/66-247-30-174-17-1-0.json";
    env.load_from_json(file_name);
    cmcts.get_action(sug_actions, act_pairs, env);
    cout<<env.get_winner_value()<<endl;
    return 0;
}
#include "snakego_env.h"

vector<Pos> open_list;
int open_ptr;
bool open_map[BOARD_SIZE][BOARD_SIZE];
int dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int tail_dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int (*map_ptr)[2][4][BOARD_SIZE][BOARD_SIZE];
int lock_map[BOARD_SIZE][BOARD_SIZE];

inline void src_spfa(Pos & src, int camp, int i_snake, bool is_tail){
    open_list.clear();
    open_list.push_back(src);
    int init_val;
    if (!is_tail){
        map_ptr = &dis_map;
        init_val = 0;
    } else {
        map_ptr = &tail_dis_map;
        init_val = 1;
    }
    auto & res_map = *map_ptr;
    for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
        res_map[camp][i_snake][x][y]=999;
        open_map[x][y]=false;
    }
    res_map[camp][i_snake][src.x][src.y]=init_val;
    open_map[src.x][src.y]=true;
    open_ptr=0;
    int newx, newy;
    int dis1;
    // fprintf(stderr,"%d\n",res_map[camp][i_snake][6][10]);
    while (open_ptr<int(open_list.size())){
        Pos pos = open_list[open_ptr];
        // fprintf(stderr,"%d %d\n",pos.x,pos.y);
        dis1 = res_map[camp][i_snake][pos.x][pos.y]+1;
        for (int idir=0;idir<4;idir++){
            newx = pos.x+dxs[idir];
            newy = pos.y+dys[idir];
            if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
            if (dis1<lock_map[newx][newy]){continue;}
            // fprintf(stderr,"In");
            // fprintf(stderr,"%d %d %d %d %b\n",newx,newy,dis1, res_map[camp][i_snake][newx][newy], open_map[newx][newy]);
            
            if (dis1<res_map[camp][i_snake][newx][newy]){
                res_map[camp][i_snake][newx][newy] = dis1;
                if (!open_map[newx][newy]){
                    open_map[newx][newy] = true;
                    open_list.push_back(Pos(newx,newy));
                }
            }
        }
        open_map[pos.x][pos.y]=false;
        open_ptr++;
    }
    // fprintf(stderr, "spfa_vol:%d\n", open_ptr);
    // exit(0);
}

void get_dis_map(SnakeGoEnv & env){
    //init
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            lock_map[x][y]=0;
            if (env.blocks[x][y]!=0){
                lock_map[x][y]=999;
            }
        }
    }
    // set body lock map
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            // assign lock map
            auto & snake=env.snakes[camp][i_snake];
            auto & body = snake.body;
            int len_body=int(body.size());
            for (int i_body=0;i_body<len_body;i_body++){
                lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
            }
        }
    }
    // for each snake spfa get dis_map & tail_dis_map
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            auto & snake=env.snakes[camp][i_snake];
            Pos & head = snake.body[0];
            src_spfa(head, camp, i_snake, false);
            int tail_ind = int(snake.body.size())-1;
            if (tail_ind>=0){
                Pos & tail =snake.body[tail_ind];
                src_spfa(tail, camp, i_snake, true);
            }
        }
    }
}

void print_board(int camp, int i_snake){
    fprintf(stderr,"******\n");
    for (int y=0;y<BOARD_SIZE;y++){
        for (int x=0;x<BOARD_SIZE;x++){
            fprintf(stderr,"%d\t",dis_map[camp][i_snake][x][y]);
        }
        fprintf(stderr,"\n");
    }
}

int num_req = 0;
struct SnakeAnchor{
    int x, y, camp;
    double adj;
    SnakeAnchor(int px, int py, int pcamp, double padj){
        x = px;
        y = py;
        camp = pcamp;
        adj = padj;
    }
};
vector<SnakeAnchor> snake_anchors;

double hit_map[BOARD_SIZE][BOARD_SIZE];
int remain[BOARD_SIZE][BOARD_SIZE];

inline void rev_hit_spfa(Pos & src, int & res_camp, double & res_hit_dis, SnakeGoEnv&env){
    for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
        hit_map[x][y] = 999.0;
        remain[x][y] = 0;
        open_map[x][y]=false;
    }
    open_list.clear();
    open_list.push_back(src);
    hit_map[src.x][src.y]=0.0;
    open_map[src.x][src.y]=true;
    open_ptr = 0;
    int newx, newy;
    double dis1, dis_dx, remain1, adj_dis;
    Pos pos;
    int hit_camp=-1;
    double hit_dis = 999;
    // if fall in body?
    for (int camp=0;camp<2;camp++){
        for (auto &snake:env.snakes[camp]){
            auto &body = snake.body;
            for (auto &p:body){
                if (src.x==p.x&&src.y==p.y){
                    hit_camp=camp;
                    hit_dis=0.0;
                    break;
                }
            }
        }
    }
    // fprintf(stderr,"---\n");
    if (hit_camp==-1){
        while (open_ptr<int(open_list.size())){
            pos = open_list[open_ptr];
            dis1 = hit_map[pos.x][pos.y]+1.0;
            if (dis1<hit_dis+1){
                for (int idir=0;idir<4;idir++){
                    dis_dx = dis1;
                    newx = pos.x+dxs[idir];
                    newy = pos.y+dys[idir];
                    if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
                    // check hit
                    for (auto & snake_anchor:snake_anchors){
                        if (newx==snake_anchor.x&&newy==snake_anchor.y){
                            double tmp_hit_dis = dis_dx+snake_anchor.adj;
                            if (tmp_hit_dis<hit_dis){
                                hit_dis = tmp_hit_dis;
                                hit_camp = snake_anchor.camp;
                                // fprintf(stderr,"upd %d %d %lf %d\n", newx, newy, hit_dis, hit_camp);
                            }
                        }
                    }
                    if (lock_map[newx][newy]>0){
                        dis_dx+=double(lock_map[newx][newy]);
                    }
                    // fprintf(stderr,"%d %d %lf %d\n",newx, newy, dis1, lock_map[newx][newy]);
                    if (dis_dx<hit_map[newx][newy]){
                        hit_map[newx][newy]=dis_dx;
                        if (!open_map[newx][newy]){
                            open_map[newx][newy] = true;
                            open_list.push_back(Pos(newx,newy));
                        }
                    }
                }
            }
            open_map[pos.x][pos.y]=false;
            open_ptr++;
        }
    }
    // exit(0);
    res_camp = hit_camp;
    res_hit_dis = hit_dis;
}

vector<int> item_inds;

vector<MyItem> score_items;
vector<MyItem> remain_items;
namespace brain{
    void get_unsolved_item_inds(vector<int>& item_inds, SnakeGoEnv& env, int consider_item_num){
        item_inds.clear();
        int i_item=0;
        int len_items = int(env.item_list.size());
        for (int i_item=0;i_item<len_items;i_item++){
            auto & item = env.item_list[i_item];
            auto & x=item.x;
            auto & y=item.y;
            if (env.blocks[x][y]!=0){continue;}
            if (env.item_map[x][y]==1){
                item_inds.push_back(i_item);
            }
            else if (item.time>env.cur_round){
                item_inds.push_back(i_item);
            }
            if (int(item_inds.size())>=consider_item_num){break;}
        }
    }
    void calc_dis_map(SnakeGoEnv & env){
        // bfs get dis_map
        get_dis_map(env);
    }
    void req_inference(SnakeGoEnv & env, vector<double> & mcts_probvs, bool debug){
        num_req+=1;
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        // get winner value
        double winner_value = env.get_winner_value();
        
        // and calc expect item score(mind own perspection)
        double exp_item_score = 0.0;
        score_items.clear();

        // item_on_map
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                if (env.item_map[x][y]!=1){continue;}
                if (env.blocks[x][y]!=0){continue;}
                // for (int i_item=0;i_item<50;i_item++){
                //     if (
                //     env.item_list[i_item].x==x&&\
                //     env.item_list[i_item].y==y){
                //         fprintf(stderr,"%d\n",i_item);
                //         break;
                //     }
                // }
                // exit(0);
                score_items.push_back(
                    MyItem(-1,x,y,env.item_time_map[x][y]-16+env.cur_round,1,env.item_param_map[x][y])
                );
            }
        }
        // item_in_50_round
        for (auto & item:env.item_list){
            if (env.blocks[item.x][item.y]!=0){continue;}
            if (item.time>env.cur_round){
                score_items.push_back(item);
            }
        }
        // pick item
        int min_camp;
        double min_dis, adj_dis;
        int num_item = 0;
        for (auto & score_item:score_items){
            auto & x = score_item.x;
            auto & y = score_item.y;
            min_camp=-1;
            min_dis = 999;
            if (lock_map[x][y]==0||lock_map[x][y]<score_item.time-env.cur_round){
                for (int camp=0;camp<2;camp++){
                    int len_snakes = int(env.snakes[camp].size());
                    for (int i_snake=0;i_snake<len_snakes;i_snake++){
                        // fprintf(stderr,"%d\n",dis_map[camp][i_snake][x][y]);
                        double adj;
                        if (camp==env.cur_side){
                            if (i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp]){
                                adj=-0.5;
                            } else {
                                adj= 0.0;
                            }
                        } else {
                            adj = -0.25;
                        }
                        double adj_dis=double(dis_map[camp][i_snake][x][y])+adj;
                        if ((adj_dis<min_dis)&&(adj_dis<double(score_item.time-env.cur_round+15))){
                            min_dis = adj_dis;
                            min_camp = camp;
                        }
                        if (len_snakes<4&&int(env.snakes[camp][i_snake].body.size())>1){//consider tail
                            adj_dis = double(tail_dis_map[camp][i_snake][x][y])+adj;
                            if ((adj_dis<min_dis)&&(adj_dis<double(score_item.time-env.cur_round+15))){
                                min_dis = adj_dis;
                                min_camp = camp;
                            }
                        }
                    }
                }
            }
            else{ // item is lock, find the lock snake
                if (debug){
                    fprintf(stderr,"itemfall:%d %d %d %d\n",x,y,lock_map[x][y],score_item.time-env.cur_round);    
                }
                for (int camp=0;camp<2;camp++){
                    int len_snakes = int(env.snakes[camp].size());
                    for (int i_snake=0;i_snake<len_snakes;i_snake++){
                        auto & body = env.snakes[camp][i_snake].body;
                        for (auto & p:body){
                            if (p.x==x&&p.y==y){
                                min_camp=camp;
                                break;
                            }
                        }
                    }
                }
            }
            if (debug){
                fprintf(stderr,"%d %d %d %lf %d\n",x,y,min_camp,min_dis,score_item.param);
            }
            num_item+=1;
            if (num_req<2&&num_item<9){
                fprintf(stderr,"%d %d %d %lf %d\n",x,y,min_camp,min_dis,score_item.param);
            }
            if (min_camp!=-1){
                int due =(score_item.time-env.cur_round);
                double decay;
                if (due<=0){
                    decay=1.0;
                } else if (due<10){
                    decay = 0.5;
                } else if (due<25){
                    decay = 0.25;
                } else if (due<50){
                    decay = 0.1;
                } else {
                    decay = 0.01;
                }
                exp_item_score += decay * double(score_item.param)*(min_camp==0?1.0:-1.0);
            }
        }
        if (env.cur_side==1){
            exp_item_score*=-1.0;
        }
        winner_value+=(exp_item_score/SCORE_SHRINK);
        //punish length 1 snake
        double len1_punish_score=0;
        for (int camp=0;camp<2;camp++){
            int len_snakes=int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                auto & snake = env.snakes[camp][i_snake];
                if (int(snake.body.size())+snake.length_bank==1){
                    if (camp==0){
                        len1_punish_score-=2.5;
                    } else{
                        len1_punish_score+=2.5;
                    }
                }
            }
        }
        if (env.cur_side==1){len1_punish_score*=-1;}
        winner_value+=(len1_punish_score/SCORE_SHRINK);
        mcts_probvs.push_back(winner_value);
        // exit(0);
    }

    void get_item_belong_score(SnakeGoEnv & env, int consider_item_num, 
        vector<double> & mcts_probvs,bool debug){
        double score = 0;
        double winner_value = env.get_winner_value();
        score+=winner_value;
        get_unsolved_item_inds(item_inds, env, consider_item_num);
        double belong_score=0.0;
        // init lock map
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                lock_map[x][y]=0;
                if (env.blocks[x][y]!=0){
                    lock_map[x][y]=999;
                }
            }
        }
        // set body lock map
        for (int camp=0;camp<2;camp++) {
            int len_snakes=int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                // assign lock map
                auto & snake=env.snakes[camp][i_snake];
                auto & body = snake.body;
                int len_body=int(body.size());
                for (int i_body=0;i_body<len_body;i_body++){
                    lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
                }
            }
        }
        // make snake target and camp
        snake_anchors.clear();
        for (int camp=0;camp<2;camp++){
            int len_snakes = int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                double adj;
                auto & body = env.snakes[camp][i_snake].body;
                int tail_ind = int(body.size())-1;
                Pos head = body[0];
                Pos tail = body[tail_ind];
                if (camp==env.cur_side){
                    if (i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp]){
                        adj=-0.5;
                    } else {
                        adj= 0.0;
                    }
                } else {
                    adj = -0.25;
                }
                if (int(env.snakes[camp][i_snake].body.size())>1){
                    snake_anchors.push_back(SnakeAnchor(
                        head.x, head.y, camp, adj
                    ));
                }
                if (len_snakes<4&&int(env.snakes[camp][i_snake].body.size())>1){//consider tail
                    snake_anchors.push_back(SnakeAnchor(
                        tail.x, tail.y, camp, adj+1
                    )); 
                }    
            }
        }
        //
        for (auto & i_item:item_inds){
            auto & item = env.item_list[i_item];
            Pos pos = Pos(item.x,item.y);
            int hit_camp;
            double hit_dis;
            rev_hit_spfa(pos, hit_camp, hit_dis, env);
            if (debug){
                fprintf(stderr, "%d %d %d %lf\n", item.x, item.y, hit_camp, hit_dis);
            }
            bool get_flag;
            get_flag = (hit_dis<=item.time-env.cur_round+15);
            if (get_flag){
                if (hit_camp==0){
                    belong_score+=double(item.param);
                } else if (hit_camp==1){
                    belong_score-=double(item.param);
                }
            }
        }
        score+=belong_score;

        // warzone punishment
        double warzone_punish=0.0;
        double center_dis;
        for (int camp=0;camp<2;camp++){
            int len_snakes = int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                auto & body = env.snakes[camp][i_snake].body;
                auto & head = body[0];
                center_dis = fabs(double(head.x-7.5))+fabs(double(head.y-7.5));
                if (camp==0){
                    warzone_punish-=center_dis;
                } else {
                    warzone_punish+=center_dis;
                }
            }
        }
        score+= 0.025 * warzone_punish;
        // double sum=0.0;
        // for (int i=0;i<256;i++){sum+=1;}

        // adjust score
        if (env.cur_side==1){
            score*=-1;
        }
        score/=SCORE_SHRINK;

        if (debug){
            fprintf(stderr,"wv:%.4lf\tbs:%.4lf\twarz:%.4lf\tall:%.4lf\n",winner_value, belong_score, warzone_punish, score);
        }

        //
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(score);
    }
};
#include "adk.hpp"
#include "aaa.cpp"
#include <cmath>
#include <ctime>
OpHistory oplist;
double time_current;
int self_colour;
int wall_alerm;
int unvanish_item;int unperceived_item;
int making[5] = {0,1,2,3,4};
int self_target[4] = {-1,-1,-1,-1};
int opponent_target[4] = {-1,-1,-1,-1};
int opponent_length[4] = {-1,-1,-1,-1}; 
int waitlist[10005];int operate_snake;
Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
int dx[4] = { 1, 0, -1, 0 };
int dy[4] = { 0, 1, 0, -1 };//sample�ճ� 
inline void updatemap(const Context &ctx){
	for(int i = 0; i < 16; i ++)
	for(int j = 0; j < 16; j ++)
	{
		if(ctx.wall_map()[i][j] != -1)qp[i][j] = 1;
		else if(ctx.snake_map()[i][j] != -1)qp[i][j] = 1;
		else qp[i][j] = 0;
	}
}
inline Operation snake_front(const Snake& snake_to_operate){
	if(snake_to_operate[0].x == snake_to_operate[1].x){
		if(snake_to_operate[0].y < snake_to_operate[1].y)return OP_DOWN;
		else return OP_UP;
	}
	else{
		if(snake_to_operate[0].x < snake_to_operate[1].x)return OP_LEFT;
		else return OP_RIGHT;
	}
}
inline int point_at(const Snake& snake_to_operate){
	if(snake_to_operate[0].x == snake_to_operate[1].x){
		if(snake_to_operate[0].y < snake_to_operate[1].y)return 0;
		else return 1;
	}
	else{
		if(snake_to_operate[0].x < snake_to_operate[1].x)return 2;
		else return 3;
	}
}//��Ӧ�ģ��ߵĳ��� 
inline Operation snake_left(const Snake& snake_to_operate){
	if(snake_to_operate[0].x == snake_to_operate[1].x){
		if(snake_to_operate[0].y < snake_to_operate[1].y)return OP_RIGHT;
		else return OP_LEFT;
	}
	else{
		if(snake_to_operate[0].x < snake_to_operate[1].x)return OP_DOWN;
		else return OP_UP;
	}
}
inline Operation snake_right(const Snake& snake_to_operate){
	if(snake_to_operate[0].x == snake_to_operate[1].x){
		if(snake_to_operate[0].y < snake_to_operate[1].y)return OP_LEFT;
		else return OP_RIGHT;
	}
	else{
		if(snake_to_operate[0].x < snake_to_operate[1].x)return OP_UP;
		else return OP_DOWN;
	}
}
inline int manhatten_length(const Snake& snake_now, const Item& to_get){
	return abs(snake_now[0].x - to_get.x)+abs(snake_now[0].y-to_get.y);
}
inline int point_of_item(const Item& to_get){
	if(to_get.type == 2)return 11;
	else return to_get.param * 4;
}
bool safe_p(int t_x, int t_y, const Snake &snake_to_operate,const Context& ctx){
	//�����߽�
	if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )return false;
	//ײǽ
	if ( ctx.wall_map()[t_x][t_y] != -1 )return false;
	//ײ�Ǳ���
	if ( ctx.snake_map()[t_x][t_y] != -1 && ctx.snake_map()[t_x][t_y] != snake_to_operate.id )return false;
	//��ͷײ�Լ�
	if ( snake_to_operate.length() > 2 && snake_to_operate[1].x == t_x && snake_to_operate[1].y == t_y )return false;
	for(int i = 0; i < ctx.opponents_snakes().size(); i ++)
	{
		if(Manhuattan(t_x,t_y,ctx.opponents_snakes()[i][0].x,ctx.opponents_snakes()[i][0].y) <= 2)return false;
	}
	return true;
}
bool safe_q(int t_x, int t_y, const Snake &snake_to_operate,const Context& ctx, int n){
	//�����߽�
	if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )return false;
	//ײǽ
	if ( ctx.wall_map()[t_x][t_y] != -1 )return false;
	//ײ�Ǳ���
	if ( ctx.snake_map()[t_x][t_y] != -1 && ctx.snake_map()[t_x][t_y] != snake_to_operate.id )return false;
	//��ͷײ�Լ�
	if ( snake_to_operate.length() > 2 && snake_to_operate[1].x == t_x && snake_to_operate[1].y == t_y )return false;
	return true;
}
bool safe(const Snake &snake_to_operate, const Context &ctx,int going_x, int going_y, int direction){
	//2��֮��ȷ�������� �������Ż� 
	if(direction == 1)//����
	{
		if(!safe_p(going_x-1,going_y,snake_to_operate,ctx) && !safe_p(going_x+1,going_y,snake_to_operate,ctx) 
		&& !safe_p(going_x,going_y+1,snake_to_operate,ctx))//һ������ 
		{
			return false;
		}else{
			if(!safe_p(going_x-1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x-1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x-2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x+2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y+2,snake_to_operate,ctx))//version1,����ʲô�߶��㿪
			return false;
			else return true;
		}
	}
	else if(direction == 3)//����
	{
		if(!safe_p(going_x-1,going_y,snake_to_operate,ctx) && !safe_p(going_x+1,going_y,snake_to_operate,ctx) 
		&& !safe_p(going_x,going_y-1,snake_to_operate,ctx))//һ������ 
		{
			return false;
		}else{
			if(!safe_p(going_x-1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x-1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x-2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x+2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y-2,snake_to_operate,ctx))//version1,����ʲô�߶��㿪
			return false;
			else return true;
		};
	}
	else if(direction == 2)//���� 
	{
		if(!safe_p(going_x-1,going_y,snake_to_operate,ctx) && !safe_p(going_x,going_y-1,snake_to_operate,ctx) 
		&& !safe_p(going_x,going_y+1,snake_to_operate,ctx))//һ������ 
		{	
			return false;
		}else{
			if(!safe_p(going_x-1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x-1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x-2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y-2,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y+2,snake_to_operate,ctx))//version1,����ʲô�߶��㿪
			return false;
			else return true;
		}
	}
	else//����
	{
		if(!safe_p(going_x+1,going_y,snake_to_operate,ctx) && !safe_p(going_x,going_y-1,snake_to_operate,ctx) 
		&& !safe_p(going_x,going_y+1,snake_to_operate,ctx))//һ������ 
		{	
			return false;
		}else{
			if(!safe_p(going_x-1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x-1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y-1,snake_to_operate,ctx)
			&& !safe_p(going_x+1,going_y+1,snake_to_operate,ctx)
			&& !safe_p(going_x+2,going_y,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y-2,snake_to_operate,ctx)
			&& !safe_p(going_x,going_y+2,snake_to_operate,ctx))//version1,����ʲô�߶��㿪
			return false;else return true;
		}
	}
	return true;
}//ȷ�������˼����İ�ȫ 
bool safe_to_others(const Snake &snake_to_operate, const Context &ctx,int going)
{
	//������Լ���
	return true; 
}
bool use_railgun(const Snake &snake_to_operate, const Context &ctx, int* move){
	int selff = 0;int otherr = 0;
	if(point_at(snake_to_operate) == 0){
		for(int i = snake_to_operate[0].y + 1; i < 16;i ++)
		{
			if(ctx.wall_map()[snake_to_operate[0].x][i] == -1);
			else if(ctx.wall_map()[snake_to_operate[0].x][i] == self_colour)selff ++;
			else otherr++;
		}
		if(selff <= otherr)return true;
	}
	else if(point_at(snake_to_operate) == 1){
		for(int i = snake_to_operate[0].y - 1; i >= 16;i --)
		{
			if(ctx.wall_map()[snake_to_operate[0].x][i] == -1);
			else if(ctx.wall_map()[snake_to_operate[0].x][i] == self_colour)selff ++;
			else otherr++;
		}
		if(selff <= otherr)return true;
	}
	else if(point_at(snake_to_operate) == 2){
		for(int i = snake_to_operate[0].x - 1; i >= 0;i --)
		{
			if(ctx.wall_map()[i][snake_to_operate[0].y] == -1);
			else if(ctx.wall_map()[i][snake_to_operate[0].y] == self_colour)selff ++;
			else otherr++;
		}
		if(selff <= otherr)return true;
	}
	else{
		for(int i = snake_to_operate[0].x + 1; i < 16;i ++)
		{
			if(ctx.wall_map()[i][snake_to_operate[0].y] == -1);
			else if(ctx.wall_map()[i][snake_to_operate[0].y] == self_colour)selff ++;
			else otherr++;
		}
		if(selff <= otherr)return true;
	}
	return false;
}
Operation ordinary_move(const Snake &snake_to_operate, const Context &ctx, int* move){
	if ( snake_to_operate.railgun_item.id != -1 && snake_to_operate.length() >= 2 )
	{
		if(use_railgun(snake_to_operate,ctx,move))return OP_RAILGUN;
		if(!safe_q(snake_to_operate[0].x+1,snake_to_operate[0].y,snake_to_operate,ctx,0)&&
		!safe_q(snake_to_operate[0].x-1,snake_to_operate[0].y,snake_to_operate,ctx,0)&&
		!safe_q(snake_to_operate[0].x,snake_to_operate[0].y+1,snake_to_operate,ctx,0)&&
		!safe_q(snake_to_operate[0].x,snake_to_operate[0].y-1,snake_to_operate,ctx,0))return OP_RAILGUN; 
	}//���磬���Ż� 
	updatemap(ctx);
	for(int j = 0; j < ctx.opponents_snakes().size(); j ++)
	{
	for(int i = unvanish_item; i <= unperceived_item; i++ )
	{
		waitlist[i] = Manhuattan(ctx.opponents_snakes()[j][0].x,ctx.opponents_snakes()[j][0].y,ctx.item_list()[i].x,ctx.item_list()[i].y);
	}
	int choose = -6,now = 257;
	for(int i = unvanish_item; i <= unperceived_item; i++ )
	{
		if(waitlist[i] < now ){
			//Ĭ��˫�߲���һ�� �������Ż� 
			//for(int jj = 0; jj < j; jj ++)
			//if(opponent_target[jj] == i)continue;
			choose = i;now = waitlist[i];
		}
	}
	opponent_target[j] = choose;
	opponent_length[j] = now;
	}//����һ�����ֵ���������ĸ� 
	for(int i = unvanish_item; i <= unperceived_item; i++ )
	{
		waitlist[i] = Manhuattan(snake_to_operate[0].x,snake_to_operate[0].y,ctx.item_list()[i].x,ctx.item_list()[i].y);
	}
	int choose = -6,now = 257;
	for(int i = unvanish_item; i <= unperceived_item; i++ )
	{
		for(int m = 0; m < operate_snake; m ++){
			if(self_target[m] == i)goto nexter;//��Ҫ�����ﶷ 
		}
		if(waitlist[i] < now ){
			for(int iii = 0; iii < ctx.opponents_snakes().size(); iii ++){
				if(opponent_target[iii] == i)
				{
					if(opponent_length[iii] <= waitlist[i])
					{
						choose = i;now = waitlist[i];goto nexter;
					}
					else goto nexter;
				}
			}
			choose = i;now = waitlist[i];
		}
		nexter:
			continue;
	}
	self_target[operate_snake] = choose;//Ȼ�����Լ��ģ���������̿����������Ļ��ӳ����� 
	if(self_target[operate_snake] == -1) 
	for(int i = -1; i >= -1 * ctx.opponents_snakes().size(); i-- )
	{
		if(Manhuattan(snake_to_operate[0].x,snake_to_operate[0].y,ctx.opponents_snakes()[-i][0].x,ctx.opponents_snakes()[-i][0].y) < now )
		{
			choose = i;
			now = Manhuattan(snake_to_operate[0].x,snake_to_operate[0].y,ctx.opponents_snakes()[-i][0].x,ctx.opponents_snakes()[-i][0].y);
		}
	}//�������� 
	self_target[operate_snake] = choose;
	
	if(self_target[operate_snake] < 0 && self_target[operate_snake] != -6) 
	for ( int dir = 0; dir < 4; dir++ )
	{
		//�ƶ����Ϸ���̻�
		int distance = abs( ctx.opponents_snakes()[-self_target[operate_snake]][0].x - snake_to_operate[0].x ) +
			abs( ctx.opponents_snakes()[-self_target[operate_snake]][0].y - snake_to_operate[0].y );
		if ( move[dir] != 0 )
			continue;

	//������߷����ƶ�
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];
		int dis = abs( ctx.opponents_snakes()[-self_target[operate_snake]][0].x - t_x ) + abs( ctx.opponents_snakes()[-self_target[operate_snake]][0].y - t_y );
		if ( dis <= distance )
		{
			return direction[dir];
		}
	}//�ճ���ֱ���� 
	else if(self_target[operate_snake] >= 0)
	for ( int dir = 0; dir < 4; dir++ )
	{
		//�ƶ����Ϸ���̻�
		int distance = abs( ctx.item_list()[self_target[operate_snake]].x - snake_to_operate[0].x ) +
			abs( ctx.item_list()[self_target[operate_snake]].y - snake_to_operate[0].y );
		if ( move[dir] != 0 )
			continue;

	//������߷����ƶ�
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];
		int dis = abs( ctx.item_list()[self_target[operate_snake]].x - t_x ) + abs( ctx.item_list()[self_target[operate_snake]].y - t_y );
		if ( dis <= distance )
		{
			return direction[dir];
		}
	}
	int distance = abs( 8 - snake_to_operate[0].x ) +
			abs( 8 - snake_to_operate[0].y );
	for ( int dir = 0; dir < 4; dir++ )
	{
		if ( move[dir] == 0 )
		{
			int t_x = snake_to_operate[0].x + dx[dir];
			int t_y = snake_to_operate[0].y + dy[dir];
			int dis = abs(8 - t_x ) + abs(8 - t_y );
			if(dis <= distance)
			return direction[dir];
		}
	}//�������� 
	for ( int dir = 0; dir < 4; dir++ )
	{
		if ( move[dir] == 0 )
		{
			return direction[dir];
		}
	}
	for ( int dir = 0; dir < 4; dir++ )
	{
		if ( move[dir] == 1 )
		{
			return direction[dir];
		}
	}//ʵ�ڲ��о͹̻� 
	return snake_front(snake_to_operate);
}//��ͨ���߷���ע���������û�з��� 
Operation make_your_decision( const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_list )
{
	for(int m = 0; ctx.my_snakes()[m] != snake_to_operate; m ++){
		operate_snake = m;
	}
	int move[4] = { 0, 0, 0, 0 };
	for ( int dir = 0; dir < 4; dir++ ){
		if(!safe(snake_to_operate,ctx,snake_to_operate[0].x+dx[dir],snake_to_operate[0].y+dy[dir],dir)) 
		move[dir] = -1;
	}
	for ( int dir = 0; dir < 4; dir++ )
	{
		//��ͷ����λ��
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];

		//�����߽�
		if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )
		{
			move[dir] = -1;
			continue;
		}

		//ײǽ
		if ( ctx.wall_map()[t_x][t_y] != -1 )
		{
			move[dir] = -1;
			continue;
		}

		//ײ�Ǳ���
		if ( ctx.snake_map()[t_x][t_y] != -1 &&
			 ctx.snake_map()[t_x][t_y] != snake_to_operate.id )
		{
			move[dir] = -1;
			continue;
		}

		//��ͷײ�Լ�
		if ( snake_to_operate.length() > 2 &&
			 snake_to_operate[1].x == t_x &&
			 snake_to_operate[1].y == t_y )
		{
			move[dir] = -1;
			continue;
		}

		//�ƶ����¹̻�
		if ( ctx.snake_map()[t_x][t_y] == snake_to_operate.id )
		{
			move[dir] = 1;
			continue;
		}
	}//ֱ���ճ�sample
	int ii = unvanish_item;
	for(int i = ii; i < 10000; i ++){
		if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() )
		unvanish_item ++;
		else break;
	}
	ii = unperceived_item;
	for(int i = ii; i < 10000; i ++){
		if ( ctx.item_list()[i].time <= ctx.current_round()+6)//��Ԥ֪�ĵ���Ҳ�� 
		unperceived_item ++;
		else break;
	}
	//���µ�����Ч�� 
	if(ctx.current_round() == 1){
		if(snake_to_operate.camp == 0) self_colour = 0;
		else self_colour = 1;
	}//�����ж���ɫ 
	if(ctx.current_round() <= 8){
		if(self_colour == 0){
			if(ctx.current_round() % 2 != 0)return OP_RIGHT;
			else return OP_DOWN;
		}
		else{
			if(ctx.current_round() % 2 != 0)return OP_UP;
			else return OP_LEFT;
		}
	}//��ʼ�˲��������Ŀ����ƶ�
	else if(ctx.current_round() <= 120){
		if ( snake_to_operate == ctx.my_snakes()[0] )
		{
		//�����߳��ȳ���10
		if ( snake_to_operate.length() >= 10 )
		{
			//���ߵ���������4
			if ( ctx.my_snakes().size() < 4 )
				return OP_SPLIT;
		}
		}
		else if ( snake_to_operate == ctx.my_snakes()[1] )
		{
		//�����߳��ȳ���7
		if ( snake_to_operate.length() >= 7 )
		{
			//���ߵ���������4
			if ( ctx.my_snakes().size() < 4 )
				return OP_SPLIT;
		}
		}
		else if ( snake_to_operate == ctx.my_snakes()[2] )
		{
		//�����߳��ȳ���6
		if ( snake_to_operate.length() >= 6 )
		{
			//���ߵ���������4
			if ( ctx.my_snakes().size() < 4 )
				return OP_SPLIT;
		}
		}//���˵�һ�����ߣ�Ѹ�ٷ��� 
		return ordinary_move(snake_to_operate,ctx,move);
	}//ǰ�ڣ����Ĵ��ս&��Ҫ�̻� 
	else{
		if ( snake_to_operate.length() >= 10 )
		{
			//���ߵ���������4
			if ( ctx.my_snakes().size() < 4 )
				return OP_SPLIT;
			else wall_alerm = 3;//���Ż� 
		}//���ֶ��߳��ȣ���ֹ��������ʧ̫��
		else if(wall_alerm != -1)
		{
			if(snake_to_operate == ctx.my_snakes()[wall_alerm]){
			//������ͷ����β�ľ���
			int distance = abs( snake_to_operate.coord_list.back().x - snake_to_operate.coord_list[0].x ) +
					   	abs( snake_to_operate.coord_list.back().y - snake_to_operate.coord_list[0].y );
			for ( int dir = 0; dir < 4; dir++ )
			{
			//�ƶ����Ϸ���̻�
			if ( move[dir] == -1 )
				continue;

			if ( move[dir] == 1 )
			{
				wall_alerm = -1;
				return direction[dir];
			}

			//������β�����ƶ�
			int t_x = snake_to_operate.coord_list[0].x + dx[dir];
			int t_y = snake_to_operate.coord_list[0].y + dy[dir];
			int dis = abs( snake_to_operate.coord_list.back().x - t_x ) +
					  abs( snake_to_operate.coord_list.back().y - t_y );
			if ( dis <= distance )
			{
				return direction[dir];
			}
			}
			}//ѡ��һ���ߣ�ר�������̻� 
			else{
				return ordinary_move(snake_to_operate,ctx,move);
			}
		}
		else{
			return ordinary_move(snake_to_operate,ctx,move);
		}
	}//�Դˣ����Կ�ʼ�̻���ǽ 
	return snake_front(snake_to_operate);//��ֹ����,��ʵûɶ�� 
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score);
}

int main( int argc, char **argv )
{
	time_current = 0;wall_alerm = -1;unvanish_item = 0;unperceived_item = 0;
	SnakeGoAI start( argc, argv );
}

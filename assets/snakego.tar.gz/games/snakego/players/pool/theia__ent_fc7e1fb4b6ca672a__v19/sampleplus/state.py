from copy import deepcopy
from typing import Dict
from adk import *
class State:
    ctx: Context
    snake: Snake
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()
        self.adv_solidify_target = dict()

def construct_dependent_state(cur_ctx, cur_snake, cur_order, cur_ast): #use only in checking 
    ret = State()
    ret.ctx = cur_ctx
    ret.snake = cur_snake
    ret.order = cur_order
    ret.adv_solidify_target = cur_ast
    return ret

def construct_independent_state(cur_ctx, cur_snake, cur_order, cur_ast):
    ret = State()
    ret.ctx = deepcopy(cur_ctx)
    ret.snake = deepcopy(cur_snake)
    ret.order = deepcopy(cur_order)
    ret.adv_solidify_target = deepcopy(cur_ast)
    return ret

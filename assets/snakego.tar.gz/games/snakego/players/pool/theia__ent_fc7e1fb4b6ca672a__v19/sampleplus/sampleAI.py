from pickle import TUPLE
from random import randint
from adk import *
from queue import Queue
from constants import *
from check import *
from kill import *
from food_stg import *
from melt import *
from solidify import *
from state import State
# written by lbr




class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """
    def __init__(self):
        self.state = State()
            

    def active_strategy(self, avoid_list):
        """
        Strategy for the active snake. Split whenever limit is reached.
        Fire whenever possible. Otherwise search for food.
        """
        if self.state.snake.id in self.state.order:
            self.state.order.pop(self.state.snake.id)
        if self.state.snake.id in self.state.adv_solidify_target:
            self.state.adv_solidify_target.pop(self.state.snake.id)
        if len(self.state.snake.coor_list) >= SPLIT_LIMIT and self.count_my_snakes() < 4:
            return 6
        elif len(self.state.snake.item_list) > 0 and len(self.state.snake.coor_list) > 1 and melt_is_useful(self.state):
            return 5
        else:
            return closest_food_strategy(self.state, avoid_list) + 1
    

    def solidify_strategy(self, avoid_list): #modify from 2*2 to 2*(len/2) or at least avoid illegal actions
        ret = -1
        if self.state.snake.get_len() > ADV_SOLIDIFY_THRESHOLD:
            candidate_op = adv_solidify(self.state, avoid_list)
            if candidate_op == -1:
                sys.stderr.write("sol\n")
                sys.stderr.flush()
                ret = solidify(self.state, avoid_list)
            else:
                if self.state.snake.id in self.state.order:
                    self.state.order.pop(self.state.snake.id)
                sys.stderr.write("adv_sol\n")
                sys.stderr.flush()
                ret = candidate_op
        else:
            ret = solidify(self.state, avoid_list)
        return ret
    
    def passive_strategy(self, avoid_list):
        """
        Strategy for other snake. Always solidify.
        """
        ret = self.solidify_strategy(avoid_list) + 1
        if ret != 0:
            return ret
        else:
            return self.active_strategy(avoid_list)

    def kill_strategy(self, kill_list): #kill randomly
        if self.state.snake.id in self.state.order:
            self.state.order.pop(self.state.snake.id)
        if self.state.snake.id in self.state.adv_solidify_target:
            self.state.adv_solidify_target.pop(self.state.snake.id)
        return kill_list[random.randint(0, len(kill_list) - 1)][0] + 1

    def death_strategy(self):
        valid = []
        for coor_itr in self.state.snake.coor_list:
            op = -1
            if manhattan(coor_itr[0], coor_itr[1], self.state.snake.coor_list[0][0], self.state.snake.coor_list[0][1]) == 1:
                delta_x = coor_itr[0] - self.state.snake.coor_list[0][0]
                delta_y = coor_itr[1] - self.state.snake.coor_list[0][1]
                if delta_x == 1:
                    op = 0
                elif delta_x == -1:
                    op = 2
                elif delta_y == 1:
                    op = 1
                else:
                    op = 3
            if op != -1 and check_self(self.state, op):
                valid = [op]
        # for i in range(4):
        #     if(check_self(self.state, i)):
        #         valid.append(i)
        if len(valid) > 0 and self.count_my_snakes() > 1: #solidify
            return valid[0] + 1
        elif self.count_my_snakes() < 4 and len(self.state.snake.coor_list) > 1: #split
            return 6
        elif len(self.state.snake.item_list) > 0 and melt_is_useful(self.state) and len(self.state.snake.coor_list) > 1: #melt my way out
            return 5
        else:
            if self.state.snake.get_len() == 1: 
                return 1
            else:
                if self.state.snake.coor_list[0][0] - self.state.snake.coor_list[1][0] != -1:
                    return 1
                else:
                    return 2

    def count_my_snakes(self):
        mySnakeCnt = 0
        for snake_iter in self.state.ctx.snake_list:
            if snake_iter.camp == self.state.snake.camp:
                mySnakeCnt = mySnakeCnt + 1
        return mySnakeCnt

    def judge(self, cur_snake, cur_ctx):
        #sys.stderr.write("hi\n")
        #sys.stderr.flush()
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        """
        self.state.ctx = cur_ctx
        self.state.snake = cur_snake
        isLast = True
        mySnakeCnt = self.count_my_snakes()

        for snake_iter in self.state.ctx.snake_list:
            if snake_iter.id == self.state.snake.id or snake_iter.camp != self.state.snake.camp:
                continue
            if snake_iter.id > self.state.snake.id:
                isLast = False
                break
        
        deathlist = can_kill(self.state)
        kill_list = []
        avoid_list = []
        for kill_info in deathlist:
            if(kill_info[2] == self.state.snake.camp):
                avoid_list.append(kill_info)
            else:
                kill_list.append(kill_info)

        if certain_death(self.state):
            #sys.stderr.write(str(self.ctx.turn) + " " + str(self.snake.id) + " ds\n")
            #sys.stderr.flush()
            return self.death_strategy()
        elif len(kill_list) > 0:
            sys.stderr.write("kill list for id " + str(self.state.snake.id) + " at turn " + str(self.state.ctx.turn) + ": " + str(kill_list) + "\n")
            sys.stderr.flush()
            #sys.stderr.write(str(self.ctx.turn) + " " + str(self.snake.id) + " ks\n")
            #sys.stderr.flush()
            return self.kill_strategy(kill_list)
        elif isLast == False or mySnakeCnt <= 3 or self.state.snake.get_len() < 5:
            #sys.stderr.write(str(self.ctx.turn) + " " + str(self.snake.id) + " as\n")
            #sys.stderr.flush()
            return self.active_strategy(avoid_list)
        else:
            #sys.stderr.write(str(self.ctx.turn) + " " + str(self.snake.id) + " ps\n")
            #sys.stderr.flush()
            if self.state.snake.get_len() >= 5:
                return self.passive_strategy(avoid_list)
            else:
                return self.active_strategy(avoid_list)


def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    # game config
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0

    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI()
    while playing:
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
                logging.debug(str(op))
                c.send_data(op)
                controller.apply(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:
        pass

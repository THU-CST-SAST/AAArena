import os
import json
import cv2
import numpy as np

dxs=[1,0,-1,0]
dys=[0,1,0,-1]
SCALE=40
SHIFT=40
RADIUS=20
COLORS=[
    [25,255,200],
    [255,50,50]
]
WHITE=[120,120,120]
CENTER_COLOR = [153,142,255]
center = [[7,7],[7,8],[8,7],[8,8]]

def get_trans_pos(pos):
    return  [pos[0]*SCALE+SHIFT,pos[1]*SCALE+SHIFT]

def draw_board(img):
    for i in range(16):
        for j in range(16):
            trans_pos = get_trans_pos((i,j))
            if [i,j] in center:
                color = CENTER_COLOR
                r = 2
            else:
                color = WHITE
                r = 1
            cv2.circle(img,trans_pos,r,color,thickness=-1)

def draw_circle(img, pos, camp=0, radius=RADIUS, thickness=3, color=None):
    if color is None:
        color = COLORS[camp]
    trans_pos = get_trans_pos(pos)
    cv2.circle(img, trans_pos, radius, color,thickness=thickness)

def draw_body(img,from_pos, to_pos, camp=0, thickness=3):
    # cv2.polylines(img,[Pts],True,(0,255,255),33)
    # img:图像,顶点集，是否闭合，颜色，线宽度
    trans_from_pos = get_trans_pos(from_pos)
    trans_to_pos = get_trans_pos(to_pos)
    d_ortho = [int(trans_to_pos[1]-trans_from_pos[1]), int(trans_from_pos[0]-trans_to_pos[0])]
    pos0 =[int(trans_from_pos[0]+d_ortho[0]/3),int(trans_from_pos[1]+d_ortho[1]/3)]
    pos1 =[int(trans_from_pos[0]-d_ortho[0]/3),int(trans_from_pos[1]-d_ortho[1]/3)]
    pts = [[pos0,trans_to_pos,pos1]]
    pts = np.array(pts,dtype=np.int32)
    cv2.polylines(img,pts,True,COLORS[camp],thickness)


font = cv2.FONT_HERSHEY_SIMPLEX
def draw_item(img, x,y,due,item_cls, item_param):
    trans_pos = get_trans_pos((x,y))
    #cv2.putText(img, str(i), (123,456)), font, 2, (0,255,0), 3)
    #各参数依次是：图片，添加的文字，左上角坐标，字体，字体大小，颜色，字体粗细
    if (item_cls==0):
        color=(50,255,50)
    else:
        color=(50,50,255)
    cv2.putText(img, str(due), (trans_pos[0]+4,trans_pos[1]), font, 0.5, color,1)
    cv2.putText(img, str(item_param), (trans_pos[0]+4,trans_pos[1]+12), font, 0.5, color, 1)

def vis_ndarray(np_info, path):
    img = np.zeros((800,800,3),dtype=np.uint8)
    draw_board(img)
    # draw snake
    for camp in range(2):
        for i_snake in range(4):
            # draw head of snake
            mark_layer = camp*20+i_snake*5
            head_info = np.where(np_info[:,:,mark_layer]>0)
            if len(head_info[0])==0:continue
            x = int(head_info[0][0])
            y = int(head_info[1][0])
            draw_circle(img, (x,y), camp)
            # draw body @ draw_body(img,from_pos, to_pos, camp=0, thickness=-1)
            for i in range(16):
                for j in range(16):
                    for k in range(4):
                        layer = mark_layer+k+1
                        if np_info[i,j,layer]>0:
                            # print(i,j,layer,np_info[x,y,layer])
                            from_pos = (i,j)
                            to_pos = (i+dxs[k],j+dys[k])
                            draw_body(img, from_pos, to_pos, camp)
                        elif np_info[i,j,layer]<0:
                            # tail info
                            if layer-mark_layer==2:
                                draw_circle(img, (i,j), radius=RADIUS+10, 
                                thickness=2, color=(100,100,200))
    # draw block
    for layer in range(48,50):
        if layer==48:camp=0
        else:camp=1
        xs, ys = np.where(np_info[:,:,layer]>0)
        for x,y in zip(xs,ys):
            draw_circle(img, (x,y), camp, thickness=-1)
    # draw item
    item_due_layer = 40
    item_0_layer = 41
    item_1_layer = 42
    item_param_layer=43
    xs, ys = np.where(np_info[:,:,item_due_layer]>-0.5)
    for x,y in zip(xs,ys):
        due = int(np_info[x,y,item_due_layer]*512.0)
        if (np_info[x,y,item_0_layer]>0):
            item_cls = 0
        elif (np_info[x,y,item_1_layer]>0):
            item_cls=1
        else:
            raise
        item_param = int(np_info[x,y,item_param_layer]*5.0)
        draw_item(img, x,y,due,item_cls, item_param)
    cv2.imwrite(path, img)

def vis_nonarray_info(info, path):
    img = np.zeros((800,800,3),dtype=np.uint8)
    draw_board(img)
    # draw snake
    for camp in range(2):
        len_snakes = len(info["snakes"][camp])
        for i_snake in range(len_snakes):
            # draw head of snake
            snake_info = info["snakes"][camp][i_snake]
            body = snake_info["body"]
            xhead = body[0]
            yhead = body[1]
            draw_circle(img, (xhead,yhead), camp)
            # @ draw_circle(img, pos, camp=0, radius=RADIUS, thickness=3, color=None):
            if snake_info["melt"]==1:
                draw_circle(img, (xhead,yhead), camp, RADIUS-10, thickness=-1,color=[50,50,255])
            # draw body @ draw_body(img,from_pos, to_pos, camp=0, thickness=-1)
            q = 2
            len_body = len(body)
            while (q<len_body):
                from_pos = (body[q-2],body[q-1])
                to_pos = (body[q],body[q+1])            
                draw_body(img, from_pos, to_pos, camp)
                q+=2
            if (info["cur_side"]==camp) and (info["cur_snake"]==i_snake):
                anchor = (body[-2],body[-1])
                draw_circle(img, anchor, radius=RADIUS+10, 
                    thickness=2, color=(100,100,200))
    # draw block
    blocks = info["blocks"]
    for x in range(16):
        for y in range(16):
            loc = x*16+y
            if blocks[loc]!=0:
                camp = 0 if blocks[loc]==1 else 1
                draw_circle(img, (x,y), camp, thickness=-1)
    # draw item map
    item_flags = np.zeros((16,16))
    item_map = info["item_map"]
    item_param_map = info["item_param_map"]
    item_time_map = info["item_time_map"]
    for x in range(16):
        for y in range(16):
            loc = x*16+y
            if item_map[loc]!=0:
                due = item_time_map[loc]-16
                item_cls = item_map[loc]-1
                item_param = item_param_map[loc]
                if (item_flags[x,y]==0):
                    draw_item(img, x,y,due,item_cls, item_param)
                    item_flags[x,y]=1
    # draw item list
    cur_round = info["cur_round"]
    loc = 0
    item_list = info["item_list"]
    len_item = len(item_list)
    while (loc<len_item):
        x = item_list[loc]
        y = item_list[loc+1]
        item_time = item_list[loc+2]
        due = item_time-cur_round
        item_type = item_list[loc+3]-1
        param = item_list[loc+4]
        if (cur_round<item_time):
            if (item_flags[x,y]==0):
                draw_item(img, x,y, due,item_type,param)
                item_flags[x,y]=1
        loc+=5
    cv2.imwrite(path, img)

def nonarray_json_vis(json_dir):
    names = os.listdir(json_dir)
    os.system("rm watch/*")
    # os.system("mkdir -p watch")
    for name in names:
        fp = os.path.join(json_dir, name)
        # file_ind = int(name.split(".json")[0])
        with open(fp,"r") as fin:
            js = json.load(fin)
        info=js
        op = os.path.join("watch", name.replace(".json",".jpg"))
        vis_nonarray_info(info, op)
        print("done %s"%op)

def json_vis(json_dir):
    names = os.listdir(json_dir)
    os.system("rm watch/*")
    os.system("mkdir -p watch")
    for name in names:
        fp = os.path.join(json_dir, name)
        # file_ind = int(name.split(".json")[0])
        with open(fp,"r") as fin:
            js = json.load(fin)
        js_img = js[0]["img"]
        np_info=np.zeros((16,16,50),dtype=np.float32) 
        np_info[:,:,40]=-1
        np_info[:,:,44]=-1
        len_info = len(js_img)
        len_q = len_info-4
        q = 0
        while(q<=len_q):
            x,y,l,v = js_img[q:q+4]
            np_info[x,y,l]=v
            q+=4
        op = os.path.join("watch", name.replace(".json",".jpg"))
        vis_ndarray(np_info, op)

def array_vis():
    pass

if __name__=="__main__":
    # json_vis("save_envs")
    nonarray_json_vis("save_envs")
    # array_vis()
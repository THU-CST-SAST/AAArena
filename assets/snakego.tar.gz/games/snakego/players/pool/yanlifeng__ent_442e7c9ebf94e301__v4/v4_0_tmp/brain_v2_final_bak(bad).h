#include "snakego_env.h"

vector<Pos> open_list;
int open_ptr;
bool open_map[BOARD_SIZE][BOARD_SIZE];
int lock_map[BOARD_SIZE][BOARD_SIZE];

void print_board(int board[BOARD_SIZE][BOARD_SIZE]){
    fprintf(stderr,"******\n");
    for (int y=0;y<BOARD_SIZE;y++){
        for (int x=0;x<BOARD_SIZE;x++){
            if (board[x][y]>0){
                fprintf(stderr,"x ");}
            else if (board[x][y]==0) {fprintf(stderr,"o ");}
            else {fprintf(stderr,"- ");}
        }
        fprintf(stderr,"\n");
    }
}

int camp_taken_map[BOARD_SIZE][BOARD_SIZE];
int item_taken_map[BOARD_SIZE][BOARD_SIZE];
int i_snake_taken_map[BOARD_SIZE][BOARD_SIZE];
int dis_map[BOARD_SIZE][BOARD_SIZE];
bool snake_open_map[8][BOARD_SIZE][BOARD_SIZE];

struct LayerPos{
    Pos pos;
    int layer;
    LayerPos(Pos pos, int layer):pos(pos),layer(layer){}
};
vector<LayerPos> snake_open_lists[8];
int iopens[8];
int max_return[8];
bool search_end[8];
bool need_search[8];

double get_danger_score(SnakeGoEnv & env, double & belong_score, vector<int> danger_snake_inds, 
    vector<int> item_inds, bool debug){
    vector<vector<int>> contact_inds; //
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            camp_taken_map[x][y]=-1;
            item_taken_map[x][y]=-1;
            dis_map[x][y]=999;
            for (int i=0;i<8;i++){
                snake_open_map[i][x][y]=false;
            }
        }
    }
    for (int snake_ind=0;snake_ind<8;snake_ind++){
        snake_open_lists[snake_ind].clear();
        iopens[snake_ind]=0;
        max_return[snake_ind]=0;
        search_end[snake_ind]=false;
        need_search[snake_ind]=false;
    }
    // init
    for (int camp=0;camp<2;camp++){
        int len_snakes = env.snakes[camp].size();
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            auto & snake=env.snakes[camp][i_snake];
            int snake_ind = camp*4+i_snake;
            if (int(snake.body.size())>=10){
                need_search[snake_ind]=true;
            }
            auto & head = snake.body[0];
            snake_open_lists[snake_ind].push_back(LayerPos(
                head, 0));
            snake_open_map[snake_ind][head.x][head.y]=true;
            camp_taken_map[head.x][head.y]=camp;
            item_taken_map[head.x][head.y]=camp;
        }
    }
    //
    int start_side = env.cur_side;
    int start_snake = env.cur_snake;
    int exp_side = env.cur_side;
    int exp_snake = env.cur_snake;
    int now_layer = 0;
    int now_dis = 0;
    bool updated = false;
    int newx, newy;
    while (true){
        // if (now_layer>1) {break;}
        // fprintf(stderr,"%d exp %d %d\n",now_layer, exp_side,exp_snake);
        int snake_ind = exp_side*4+exp_snake;
        auto & iopen = iopens[snake_ind];
        auto & snake_open_list = snake_open_lists[snake_ind];
        auto & snake=env.snakes[exp_side][exp_snake];
        // fprintf(stderr,"%d %d %d\n",snake_ind, iopen, snake_open_list[iopen].layer);
        while (now_layer>=snake_open_list[iopen].layer){
            // fprintf(stderr,"@ %d",snake_open_list.size());
            if (iopen>=int(snake_open_list.size())){
                search_end[snake_ind]=true;
                break;
            }
            auto & from_pos = snake_open_list[iopen].pos;
            int dis1 = snake_open_list[iopen].layer+1;
            for (int idir=0;idir<4;idir++){
                newx = from_pos.x+dxs[idir];
                newy = from_pos.y+dys[idir];
                // fprintf(stderr, "newxy:%d %d\n", newx, newy);
                if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
                if (lock_map[newx][newy]>0&&need_search[snake_ind]&&(!search_end[snake_ind])&&lock_map[newx][newy]>dis1){
                    //check body return
                    bool self_body=false;
                    auto & body = env.snakes[exp_side][exp_snake].body;
                    int hit_len=0;
                    for (auto &p:body){
                        hit_len+=1;
                        if (p.x==newx&&p.y==newy){
                            self_body=true;
                            break;
                        }
                    }
                    if (self_body){
                        // fprintf(stderr,"\nreturninfo\n");
                        // fprintf(stderr,"%d %d %d %d\n", newx, newy, dis1, hit_len);
                        int tmp_return = dis1+hit_len;
                        if (tmp_return>max_return[snake_ind]){
                            max_return[snake_ind] = tmp_return;
                        }
                    }
                }
                // if (exp_side==0&&exp_snake==2){
                //     fprintf(stderr,"%d %d lockmap:%d dis1:%d ",newx,newy,lock_map[newx][newy],dis1);
                //     fprintf(stderr,"camptaken:%d |",camp_taken_map[newx][newy]);
                // }
                if (lock_map[newx][newy]>dis1) continue;
                if (camp_taken_map[newx][newy]==1-exp_side) continue;
                if (!snake_open_map[snake_ind][newx][newy]){//expand search
                    snake_open_map[snake_ind][newx][newy]=true;
                    snake_open_list.push_back(LayerPos(Pos(newx,newy),dis1));
                    camp_taken_map[newx][newy] = exp_side;
                    int len_body = int(snake.body.size());
                    if (len_body!=1&&len_body!=3){
                        item_taken_map[newx][newy]=exp_side;
                        dis_map[newx][newy] = now_dis+1;
                    }
                    updated=true;
                }
            }
            // fprintf(stderr,"\n");
            iopen+=1;
        }

        // next
        exp_snake+=1;
        if (exp_snake>=env.snake_nums[exp_side]){
            exp_side = 1-exp_side;
            exp_snake=0; 
            now_dis+=1;
        }
        if (exp_snake==start_snake&&exp_side==start_side){
            if (!updated){break;}
            now_layer+=1;
            updated=false;
        }
    }
    // stat item
    belong_score = 0.0;
    for (auto & i_item:item_inds){
        auto & item = env.item_list[i_item];
        Pos item_pos = Pos(item.x,item.y);
        bool get_flag;
        int hit_dis = dis_map[item.x][item.y];
        get_flag = (hit_dis<=item.time-env.cur_round+15);
        double discount=1.0;
        if (item.time>env.cur_round){
            discount=pow(0.995,item.time-env.cur_round);
        }
        double item_value=1.0;
        if (item.type==1){
            item_value = double(item.param);
        }
        int hit_camp = item_taken_map[item.x][item.y];
        if (debug){
            fprintf(stderr,"item:%d %d camp:%d\n",item.x,item.y,hit_camp);
        }
        if (get_flag){
            if (hit_camp==0){
                belong_score+=item_value*discount;
            } else if (hit_camp==1){
                belong_score-=item_value*discount;
            }
        }
    }

    // stat score
    double danger_score = 0.0;
    int min_snakes_len[2] = {999,999};
    for (int camp=0;camp<2;camp++){
        for (auto & snake:env.snakes[camp]){
            if (int(snake.body.size())<min_snakes_len[camp]){
                min_snakes_len[camp] = int(snake.body.size());
            }
        }
    }
    for (int i=0;i<8;i++){
        if (need_search[i]){
            int camp, i_snake;
            if (i<4){
                camp=0;
                i_snake=i;
            } else{
                camp=1;
                i_snake=i-4;
            }
            auto & snake = env.snakes[camp][i_snake];
            int len_body = int(snake.body.size());
            double loss0 = double(len_body - max_return[i]);
            double loss1 = double(len_body)/2.0-max_return[i] + double(min_snakes_len[camp]);
            double min_loss;
            if (loss0>loss1){min_loss=loss1;} else {min_loss=loss0;}
            if (min_loss>0){
                if (camp==0){
                    danger_score-=min_loss;
                } else {
                    danger_score+=min_loss;
                }
            }
        }
    }
    //watch
    // fprintf(stderr,"max_return:\n");
    // for (int i=0;i<8;i++){
    //     fprintf(stderr,"%d ",max_return[i]);
    // }
    // fprintf(stderr,"\n");
    // fprintf(stderr,"iopens:\n");
    // for (int i=0;i<8;i++){
    //     fprintf(stderr,"%d ",iopens[i]);
    // }
    // fprintf(stderr,"\n");
    // if (debug){
    //     print_board(item_taken_map);
    // }
    // exit(0);
    return danger_score;
}

vector<int> item_inds;

vector<MyItem> score_items;
vector<MyItem> remain_items;
namespace brain{
    void get_skip_probvs(vector<double> & mcts_probvs){
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.0); // score, mod outside
    }
    void get_unsolved_item_inds(vector<int>& item_inds, SnakeGoEnv& env, int consider_item_num){
        item_inds.clear();
        int i_item=0;
        int len_items = int(env.item_list.size());
        for (int i_item=0;i_item<len_items;i_item++){
            auto & item = env.item_list[i_item];
            auto & x=item.x;
            auto & y=item.y;
            if (env.blocks[x][y]!=0){continue;}
            if (env.item_map[x][y]==1){
                item_inds.push_back(i_item);
            }
            else if (item.time>env.cur_round){
                item_inds.push_back(i_item);
            }
            if (int(item_inds.size())>=consider_item_num){break;}
        }
    }
    void get_item_belong_score(SnakeGoEnv & env, int consider_item_num, 
        vector<double> & mcts_probvs,bool debug){
        double score = 0;
        double downgrade_score;
        double winner_value = env.get_winner_value(downgrade_score);
        score+=downgrade_score;
        // init lock map
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                lock_map[x][y]=0;
                if (env.blocks[x][y]!=0){
                    lock_map[x][y]=999;
                }
            }
        }
        // set body lock map
        for (int camp=0;camp<2;camp++) {
            int len_snakes=int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                // assign lock map
                auto & snake=env.snakes[camp][i_snake];
                auto & body = snake.body;
                int len_body=int(body.size());
                for (int i_body=0;i_body<len_body;i_body++){
                    lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
                }
            }
        }
        
        get_unsolved_item_inds(item_inds, env, 16);
        // snake danger score && calc item belong by the way
        double belong_score=0.0;
        double danger_score = 0.0;
        vector<int> danger_snake_inds;danger_snake_inds.clear();
        bool need_calc=false;
        for (int camp=0;camp<2;camp++){
            int len_snakes = int(env.snakes[camp].size());
            if (len_snakes>2){
                for (int i_snake=0;i_snake<len_snakes;i_snake++){
                    if(int(env.snakes[camp][i_snake].body.size())>=10){
                        danger_snake_inds.push_back(int(camp*4+i_snake));
                    }
                }
            }
        }
        danger_score = get_danger_score(env, belong_score, danger_snake_inds, item_inds, debug);
        score+=belong_score+danger_score;

        // melt on snake score
        double melt_score = 0.0;
        for (int camp=0;camp<2;camp++){
            for (auto & snake:env.snakes[camp]){
                // if (debug){
                //     fprintf(stderr,"%d %d\n",camp,snake.melt);
                // }
                if (snake.melt>0){
                    melt_score+=(camp==0)?1.5:-1.5;
                }
            }
        }
        score+=melt_score;

        // warzone punishment
        double warzone_punish=0.0;
        double center_dis;
        for (int camp=0;camp<2;camp++){
            int len_snakes = int(env.snakes[camp].size());
            if (len_snakes<4){
                if (camp==0){
                    warzone_punish-=7.5*(4-len_snakes);
                } else {
                    warzone_punish+=7.5*(4-len_snakes);
                }

            }
            
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                auto & body = env.snakes[camp][i_snake].body;
                auto & head = body[0];
                center_dis = fabs(double(head.x-7.5))+fabs(double(head.y-7.5));
                if (camp==0){
                    warzone_punish-=center_dis;
                } else {
                    warzone_punish+=center_dis;
                }
            }
        }
        score+= 0.05 * warzone_punish;
        
        // adjust score
        if (env.cur_side==1){
            score*=-1;
        }
        score/=SCORE_SHRINK;

        if (debug){
            fprintf(stderr,"env:%.4lf\tbs:%.4lf\twarz:%.4lf\tdanger:%.4lf\tmelt:%.4lf\tall:%.4lf\n",
                downgrade_score, belong_score, warzone_punish, danger_score, melt_score, score);
        }

        //
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(score);
    }
};
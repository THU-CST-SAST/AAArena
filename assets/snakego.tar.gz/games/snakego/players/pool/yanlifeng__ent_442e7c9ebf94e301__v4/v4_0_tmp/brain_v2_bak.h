#include "snakego_env.h"

vector<Pos> open_list;
int open_ptr;
bool open_map[BOARD_SIZE][BOARD_SIZE];
int dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int lock_map[BOARD_SIZE][BOARD_SIZE];

void get_dis_map(SnakeGoEnv & env){
    //init
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            lock_map[x][y]=0;
        }
    }
    // for each snake
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            // assign lock map
            auto & snake=env.snakes[camp][i_snake];
            auto & body = snake.body;
            int len_body=int(body.size());
            for (int i_body=0;i_body<len_body;i_body++){
                lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
            }
            //
            for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
                dis_map[camp][i_snake][x][y]=999;
                open_map[x][y]=false;
                if (env.blocks[x][y]!=0){
                    lock_map[x][y]=999;
                }
            }
            open_list.clear();
            open_list.push_back(body[0]);
            dis_map[camp][i_snake][body[0].x][body[0].y]=0;
            open_ptr=0;
            //search
            int newx, newy;
            int dis1;
            while (open_ptr<int(open_list.size())){
                Pos pos = open_list[open_ptr];
                dis1 = dis_map[camp][i_snake][pos.x][pos.y]+1;
                for (int idir=0;idir<4;idir++){
                    newx = pos.x+dxs[idir];
                    newy = pos.y+dys[idir];
                    if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
                    if (dis1<lock_map[newx][newy]){continue;}
                    if (dis1<dis_map[camp][i_snake][newx][newy]){
                        dis_map[camp][i_snake][newx][newy] = dis1;
                        if (!open_map[newx][newy]){
                            open_map[newx][newy] = true;
                            open_list.push_back(Pos(newx,newy));
                        }
                    }
                }
                open_map[pos.x][pos.y]=false;
                open_ptr++;
            }
        }
    }
}

void print_board(int camp, int i_snake){
    fprintf(stderr,"******\n");
    for (int y=0;y<BOARD_SIZE;y++){
        for (int x=0;x<BOARD_SIZE;x++){
            fprintf(stderr,"%d\t",dis_map[camp][i_snake][x][y]);
        }
        fprintf(stderr,"\n");
    }

}

int num_brain = 0;
int num_camp0 = 0;
int num_camp1 = 0;

vector<MyItem> score_items;
vector<MyItem> remain_items;
namespace brain{
    void req_inference(SnakeGoEnv & env, vector<double> & mcts_probvs, bool debug){
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        // get winner value
        double winner_value = env.get_winner_value();

        // bfs get dis_map
        // clock_t start=clock();
        get_dis_map(env);
        // and calc expect item score(mind own perspection)
        double exp_item_score = 0.0;
        score_items.clear();

        // item_on_map
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                if (env.item_map[x][y]!=1){continue;}
                if (env.blocks[x][y]!=0){continue;}
                score_items.push_back(
                    MyItem(-1,x,y,env.item_time_map[x][y]-16+env.cur_round,1,env.item_param_map[x][y])
                );
            }
        }
        // item_in_50_round
        for (auto & item:env.item_list){
            if (env.blocks[item.x][item.y]!=0){continue;}
            if (item.time>env.cur_round){
                score_items.push_back(item);
            }
        }
        // pick item
        int min_camp;
        double min_dis, adj_dis;
        for (auto & score_item:score_items){
            auto & x = score_item.x;
            auto & y = score_item.y;
            min_camp=-1;
            min_dis = 999;
            if (lock_map[x][y]==0||lock_map[x][y]<score_item.time-env.cur_round){
                for (int camp=0;camp<2;camp++){
                    int len_snakes = int(env.snakes[camp].size());
                    for (int i_snake=0;i_snake<len_snakes;i_snake++){
                        // fprintf(stderr,"%d\n",dis_map[camp][i_snake][x][y]);
                        double base=double(dis_map[camp][i_snake][x][y]);
                        if (camp==env.cur_side){
                            if (i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp]){
                                adj_dis = base-0.5;
                            } else {
                                adj_dis = base;
                            }
                        } else {
                            adj_dis = base-0.25;
                        }
                        // adj_dis = double(dis_map[camp][i_snake][x][y])-\
                        //     ((camp==env.cur_side&&i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp])?0.5:0.0);
                        // fprintf(stderr,"%d\n",score_item.time);
                        // fprintf(stderr,"in item:%d %d %lf %lf \n",x,y,adj_dis, double(score_item.time-env.cur_round+15));
                        if ((adj_dis<min_dis)&&(adj_dis<double(score_item.time-env.cur_round+15))){
                            min_dis = adj_dis;
                            min_camp = camp;
                        }
                    }
                }
            }
            else{ // item is lock, find the lock snake
                if (debug){
                    fprintf(stderr,"itemfall:%d %d %d %d\n",x,y,lock_map[x][y],score_item.time-env.cur_round);    
                }
                for (int camp=0;camp<2;camp++){
                    int len_snakes = int(env.snakes[camp].size());
                    for (int i_snake=0;i_snake<len_snakes;i_snake++){
                        auto & body = env.snakes[camp][i_snake].body;
                        for (auto & p:body){
                            if (p.x==x&&p.y==y){
                                min_camp=camp;
                                break;
                            }
                        }
                    }
                }
            }
            if (debug){
                fprintf(stderr,"%d %d %d %lf %d\n",x,y,min_camp,min_dis,score_item.param);
            }
            num_brain+=1;
            if (num_brain==10000){
                fprintf(stderr,"%d %d \n",num_camp0, num_camp1);
            }
            if (min_camp!=-1){
                int due =(score_item.time-env.cur_round);
                if (min_camp==0){
                    num_camp0+=1;
                } else{
                    num_camp1+=1;
                }
                double decay;
                if (due<=0){
                    decay=1.0;
                } else if (due<10){
                    decay = 0.5;
                } else if (due<25){
                    decay = 0.25;
                } else if (due<50){
                    decay = 0.1;
                } else {
                    decay = 0.01;
                }
                exp_item_score += decay * double(score_item.param)*(min_camp==0?1.0:-1.0);
            }
        }
        if (env.cur_side==1){
            exp_item_score*=-1.0;
        }
        winner_value+=(exp_item_score/SCORE_SHRINK);
        //punish length 1 snake
        double len1_punish_score=0;
        for (int camp=0;camp<2;camp++){
            int len_snakes=int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                auto & snake = env.snakes[camp][i_snake];
                if (int(snake.body.size())+snake.length_bank==1){
                    if (camp==0){
                        len1_punish_score-=2.5;
                    } else{
                        len1_punish_score+=2.5;
                    }
                }
            }
        }
        if (env.cur_side==1){len1_punish_score*=-1;}
        winner_value+=(len1_punish_score/SCORE_SHRINK);
        
        // fprintf(stderr, "v:%lf item:%lf\n", winner_value, exp_item_score);
        // clock_t end=clock();
        // fprintf(stderr,"%lf\n",double(end-start)/double(CLOCKS_PER_SEC));
        // print_board(0,0);
        // print_board(1,0);
        // exit(0);
        mcts_probvs.push_back(winner_value);
    }
};
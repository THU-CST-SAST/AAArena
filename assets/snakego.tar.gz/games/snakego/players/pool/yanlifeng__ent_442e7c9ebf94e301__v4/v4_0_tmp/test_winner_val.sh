g++ test_winner_val.cpp -o test_winner_val.out
./test_winner_val.out
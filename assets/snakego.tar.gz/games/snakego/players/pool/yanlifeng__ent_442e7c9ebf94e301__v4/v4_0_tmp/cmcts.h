#include "snakego_env.h"
#include "brain.h"

#define MAX_GAME_LENGTH 3000
#define N_EXPANDS 300000
#define N_NODES 2000000
#define C_PUCT 10.0

class ActPair{
public:
    vector<int> acts;
    vector<double> probs;
    void clear(){acts.clear(); probs.clear();}
    void push_back(int act, double prob){
        acts.push_back(act);
        probs.push_back(prob);
    }
};

class Node{
public:
    int father=-1;
    int ind_in_father=-1;
    vector<int> son_actions;
    vector<int> sons;
    vector<double> son_qs;
    int nv, cur_side;
    double q, u, p;
    void init(int p_father, double prior_p, int p_cur_side, int p_ind_in_father){
        father = p_father;
        ind_in_father = p_ind_in_father;
        cur_side = p_cur_side;
        son_actions.clear();
        sons.clear();
        son_qs.clear();
        nv=q=u=0;
        p=prior_p;
    }
    bool is_leaf(){return (int(sons.size())==0);}
    bool update_q(double v, int i_son, bool upd_flag, bool sure_update){
        bool feed_father = false;
        double old_q;
        nv+=1;
        // if (v>6){
        //     fprintf(stderr,"%d %d father-%d hi\n",upd_flag, i_son, father);
        // }
        if (upd_flag){
            if (i_son==-1){ // leaf_value
                // if (v>6){fprintf(stderr,"hi1\n");}
                feed_father=true;
                q=v;
            } else {
                son_qs[i_son] = v;
                if (sure_update){
                    int len_sons = int(sons.size());
                    old_q = q;
                    q = -9999;
                    for (int i_son=0;i_son<len_sons;i_son++){
                        if (son_qs[i_son]>q){q=son_qs[i_son];}
                    }
                    if (old_q!=q){
                        feed_father=true;
                    }
                } else{
                    double avg;
                    avg = (q*double(nv-1)+v)/double(nv);
                    q = avg;
                    feed_father = true;
                }
            }
        }
        return feed_father;
    }
};

// static memory
static Node nodes[N_NODES];
static SnakeGoEnv sim_env;
int max_round=0;

using namespace std;

void print_vec(vector<int> v){
    for (auto &x:v){fprintf(stderr, "%d ",x);}
    fprintf(stderr, "\n");
}

void print_vec_double(vector<double> v){
    for (auto &x:v){fprintf(stderr, "%lf ",x);}
    fprintf(stderr, "\n");
}

void select(int & action, int & son, int node_ptr){
    auto & node =nodes[node_ptr];
    int len_sons = node.sons.size();
    double maxv=-99999;
    double v, q, u;
    int son_ptr;
    // bool debug;
    // if (node_ptr==0){debug=true;fprintf(stderr,"---\n");} else {debug=false;}
    for (int i_son=0;i_son<len_sons;i_son++){
        son_ptr = node.sons[i_son];
        auto & node_son=nodes[son_ptr];
        //inline get_value
        u = C_PUCT * node_son.p * sqrt(node.nv) / (1.0+node_son.nv);
        q = node.son_qs[i_son];
        v = q+u;
        // if (debug){
        //     fprintf(stderr,"%.3lf %.3lf \n", q, u);
        // }
        if (v>maxv) {
            maxv = v;
            action = node.son_actions[i_son];
            son = son_ptr;    
        }
    }
}
void recur_update(int node_ptr, double winner_value){
    int cur_node = node_ptr;
    bool feed_father=true;
    bool sure_update=false;
    int feed_ind=-1;
    double feed_q = winner_value;
    while ((cur_node!=-1)){
        auto & node=nodes[cur_node];
        sure_update = (node.nv>4096);
        if (cur_node==node_ptr){
            feed_father = node.update_q(feed_q, -1, feed_father, sure_update);
        } else {
            feed_father = node.update_q(feed_q, feed_ind, feed_father, sure_update);
        }
        // fprintf(stderr, "upd node:%d node side:%d v:%lf afterupd v:%lf\n",cur_node,node.cur_side, winner_value,node.q);
        // fprintf(stderr, "curnode-%d q-%lf\n",cur_node,node.q);
        feed_q = node.q;
        feed_ind = node.ind_in_father;
        cur_node = node.father;
        auto & father = nodes[cur_node];
        if (father.cur_side!=node.cur_side){
            feed_q*=-1;
        }
    }
    // if (node_ptr==43878){exit(0);} 
}
inline int get_expand_env(SnakeGoEnv & origin_env, SnakeGoEnv & sim_env,
    int & env_node_ptr, double baseline){
    int action;
    int son_ptr;
    int node_ptr;
    int exp_layer = 0;
    sim_env=origin_env;
    // fprintf(stderr, "??");
    if (!origin_env.end){
        node_ptr=0;
        while (true){
            auto & node = nodes[node_ptr];
            if (node.cur_side==-1) {node.cur_side=sim_env.cur_side;}
            // fprintf(stderr, "?");
            if (node.is_leaf()){break;}
            action=-1; son_ptr=-1;
            select(action, son_ptr, node_ptr);
            // assert(action!=-1); assert(son_ptr!=-1);
            // fprintf(stderr, "%d\n",sim_env.cur_round);
            sim_env.step(action);
            exp_layer+=1;
            // fprintf(stderr, "%d\n",sim_env.cur_round);
            // fprintf(stderr, "from:%d act:%d to node:%d\n", node_ptr, action, son_ptr);
            node_ptr = son_ptr;
        }
    }
    if (sim_env.cur_round>max_round) {max_round=sim_env.cur_round;}
    if (!sim_env.end){
        env_node_ptr=node_ptr;
    } else {
        // get winner and update recursively.
        env_node_ptr=-1;
        double tmp;
        double winner_value = sim_env.get_winner_value(tmp)-baseline;
        // fprintf(stderr,"start recur\n");
        recur_update(node_ptr, winner_value);
        // fprintf(stderr,"end recur\n");
    }
    return exp_layer;
}

class CMCTS{
public:
    int node_vol;
    double baseline=0;
    // manager pointer system on static memory.
    CMCTS(){}
    CMCTS(SnakeGoEnv & origin_env){
        _reset(origin_env);}
    void _reset(SnakeGoEnv & origin_env){
        auto & env = origin_env;
        node_vol=0;
        nodes[node_vol].init(-1,1.0,env.cur_side,-1);
        node_vol+=1;
        double tmp;
        baseline=origin_env.get_winner_value(tmp);
    }
    void get_action(vector<int> & sug_actions, ActPair & act_pairs, SnakeGoEnv & origin_env,
        int skip_layer_num){// func start
        int skip_mod = skip_layer_num+1;
        sug_actions.clear();
        if (origin_env.cur_round<10){
            if (origin_env.cur_side==0){
                sug_actions.push_back((origin_env.cur_round%2==0)?0:3);
            }
            if (origin_env.cur_side==1){
                sug_actions.push_back((origin_env.cur_round%2==0)?1:2);
            }
            return;
        }
        _reset(origin_env);
        vector<double> mcts_probvs;
        clock_t start=clock();
        int i_expand;
        int exp_layer;
        bool open_game;
        int num_blocks=0;
        for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
            if (origin_env.blocks[x][y]!=0){
                num_blocks+=1;
            }
        }
        open_game=(num_blocks<40);
        fprintf(stderr,"%d is game open:%d\n",num_blocks, open_game);
        for (i_expand=0;i_expand<N_EXPANDS;i_expand++)
        { // only loop expand, end_update embbeded in get_expand_envs.
            int env_node_ptr;
            exp_layer = get_expand_env(origin_env, sim_env, env_node_ptr, baseline);
            auto & env=sim_env;
            if (env_node_ptr!=-1){ //expand
                bool debug=false;
                // if (env_node_ptr==1||env_node_ptr==3||env_node_ptr==26056){
                //     fprintf(stderr,"---node%d debug---\n",env_node_ptr);
                //     debug=true;
                //     // double tmp;
                //     // fprintf(stderr,"snake num %d wv %lf \n",env.snake_nums[1],env.get_winner_value(tmp));
                //     // for (int i=0;i<4;i++){
                //     //     fprintf(stderr,"%d \n",env.snakes[0][i].body.size());
                //     // }
                // }
                bool skip = (exp_layer+1)%skip_mod!=0;
                // fprintf(stderr, "%d %d\n", exp_layer, skip);
                if (!skip){
                    brain::get_item_belong_score(env, 12, mcts_probvs, debug, baseline, open_game);}
                else{
                    brain::get_skip_probvs(env, mcts_probvs);
                    auto & env_node = nodes[env_node_ptr];
                    if (env_node.father!=-1){
                        auto & father = nodes[env_node.father];
                        if (father.cur_side==env_node.cur_side){
                            mcts_probvs[6] = father.q;
                        } else {
                            mcts_probvs[6] = -father.q;
                        }
                    } else {
                        mcts_probvs[6]=0.0;
                    }
                }
                // if (i_expand>1&&i_expand<10){
                //     fprintf(stderr, "(%.4lf \t%.4lf)\n", nodes[0].son_qs[0], nodes[1].q);
                // }
                // if (i_expand>10){break;}
                // if (env_node_ptr==2){exit(0);}
                vector<double> probs;
                double value;
                double winner_value;
                int node_ptr,exp_ptr;
                node_ptr = env_node_ptr;
                probs.clear();
                for (int k=0;k<6;k++){
                    probs.push_back(mcts_probvs[k]);}
                value = mcts_probvs[6];
                // fprintf(stderr,"recur upd:%d %lf\n", node_ptr, value);
                if (!skip){
                    recur_update(node_ptr, value);
                }
                auto & node = nodes[node_ptr];
                vector<int> valid_acts; valid_acts.clear();
                vector<double> valid_probs; valid_probs.clear();
                for (int action=0;action<6;action++){
                    if (!env.valid_action(action)) {continue;}
                    valid_acts.push_back(action);
                    valid_probs.push_back(probs[action]);
                }
                norm_vec(valid_probs);
                int len_valid_acts=valid_acts.size();
                // cout<<"son action len:"<<int(node.son_actions.size())<<endl;
                for (int i_act=0;i_act<len_valid_acts;i_act++){
                    node.son_actions.push_back(valid_acts[i_act]);
                    exp_ptr = node_vol;
                    node.sons.push_back(exp_ptr);
                    node.son_qs.push_back(value);
                    // if (node_ptr==0){fprintf(stderr,"%.2lf\n",valid_probs[i_act]);}
                    nodes[exp_ptr].init(node_ptr, valid_probs[i_act], -1, i_act);
                    node_vol+=1;
                }
            }
            
            clock_t tmp_t=clock();
            if (double(tmp_t-start)/double(CLOCKS_PER_SEC)>0.05){ // TLE defend
            // if (double(tmp_t-start)/double(CLOCKS_PER_SEC)>5.0){ // TLE defend
                break;
            }
        } //end loop expands

        // make sug_actions
        int act_node_ptr = 0;
        int & move_side = nodes[act_node_ptr].cur_side;
        int len_sons,sug_action, sug_son;
        int snake_num=origin_env.act_snake_nums[move_side];
        int act_snake_num = snake_num;
        int maxval;
        double maxq, tmp_val;
        fprintf(stderr, "baseline %.4lf\n", baseline);
        while ((nodes[act_node_ptr].cur_side==move_side)&&(int(sug_actions.size())<act_snake_num)){
            auto & act_node = nodes[act_node_ptr];
            len_sons = int(act_node.sons.size());
            maxq = -9999.9;
            maxval = -1;
            sug_action = -1;
            sug_son = -1;
            for (int i_son=0;i_son<len_sons;i_son++){
                auto & son_ind = act_node.sons[i_son];
                auto & son_node = nodes[son_ind];
                auto & son_action = act_node.son_actions[i_son];
                double tmp_q = (son_node.cur_side==act_node.cur_side)?son_node.q:-son_node.q;
                tmp_val = son_node.nv;
                if (son_action==4){
                    tmp_val*=(double(snake_num)/double(snake_num+1));
                }
                if (tmp_val>maxval){
                    sug_action = son_action;
                    sug_son = son_ind;
                    maxval = tmp_val;
                    maxq = tmp_q;
                }
                // fprintf(stderr, "(%d,%d,%d,%d,\t%.4lf)\n", act_node_ptr, son_ind, son_action, son_node.nv, tmp_q);
            }
            if (sug_action==4){snake_num+=1;}
            sug_actions.push_back(sug_action);
            act_node_ptr = sug_son;
        }
        clock_t end=clock();
        // fprintf(stderr,"expand_num:%d nodevol:%d\n", i_expand, node_vol);
        // fprintf(stderr, "max_push_round:%d mcts_time %lf\n",max_round-origin_env.cur_round, double(end-start)/double(CLOCKS_PER_SEC));

        // for (int i_node=0;i_node<node_vol;i_node++){
        //     if (nodes[i_node].q<-10){
        //         fprintf(stderr,"%d %lf\n",i_node, nodes[i_node].q);
        //     }
        // }
        
        // int watch_node;
        // watch_node=25478;
        // fprintf(stderr,"--- %d ---\n",watch_node);
        // print_vec(nodes[watch_node].sons);
        // print_vec(nodes[watch_node].son_actions);
        // print_vec_double(nodes[watch_node].son_qs);
        // fprintf(stderr,"nv:%d\n",nodes[watch_node].nv);
        // watch_node=25501;
        // fprintf(stderr,"--- %d ---\n",watch_node);
        // print_vec(nodes[watch_node].sons);
        // print_vec(nodes[watch_node].son_actions);
        // print_vec_double(nodes[watch_node].son_qs);
        // fprintf(stderr,"nv:%d\n",nodes[watch_node].nv);
        // watch_node=25991;
        // fprintf(stderr,"--- %d ---\n",watch_node);
        // print_vec(nodes[watch_node].sons);
        // print_vec(nodes[watch_node].son_actions);
        // print_vec_double(nodes[watch_node].son_qs);
        // fprintf(stderr,"nv:%d\n",nodes[watch_node].nv);
        // watch_node=25994;
        // fprintf(stderr,"--- %d ---\n",watch_node);
        // print_vec(nodes[watch_node].sons);
        // print_vec(nodes[watch_node].son_actions);
        // print_vec_double(nodes[watch_node].son_qs);
        // fprintf(stderr,"nv:%d\n",nodes[watch_node].nv);
        // watch_node=26000;
        // fprintf(stderr,"--- %d ---\n",watch_node);
        // print_vec(nodes[watch_node].sons);
        // print_vec(nodes[watch_node].son_actions);
        // print_vec_double(nodes[watch_node].son_qs);
        // fprintf(stderr,"nv:%d\n",nodes[watch_node].nv);
    }
};
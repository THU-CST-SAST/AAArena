g++ call_mcts.cpp -o call_mcts.out -O2 -I. -std=c++11 -lws2_32
./call_mcts.out
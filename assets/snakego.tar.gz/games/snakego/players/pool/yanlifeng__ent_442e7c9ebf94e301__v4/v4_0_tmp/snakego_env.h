#ifndef _SNAKE_GO_ENV_H
#define _SNAKE_GO_ENV_H

#include "my_math.h"
#include "units.h"
#include <iostream>
#include <fstream>
#include <assert.h>
#include "rapidjson/document.h"

#define NUM_ACTIONS 6
#define SCORE_SHRINK 1.28

using namespace std;
using namespace rapidjson;

int dxs[4]={1,0,-1,0};
int dys[4]={0,1,0,-1};

inline void get_next_pos(Pos & pos0,int action,Pos & pos1){
    pos1.x = pos0.x+dxs[action];
    pos1.y = pos0.y+dys[action];
}

class SnakeGoEnv{
public:
    vector<MyItem> item_list;
    int item_ptr;
    vector<MySnake> snakes[2];
    int cur_round;
    int cur_side;
    int cur_snake;
    int act_snake_nums[2];
    int snake_nums[2];
    int blocks[BOARD_SIZE][BOARD_SIZE];
    int item_map[BOARD_SIZE][BOARD_SIZE];
    int item_param_map[BOARD_SIZE][BOARD_SIZE];
    int item_time_map[BOARD_SIZE][BOARD_SIZE];
    bool end;
    int ip[4];
    // void cpy(SnakeGoEnv& env){
    //     item_list = env.item_list;
    //     item_ptr = env.item_ptr;
    //     snakes[0] = env.snakes[0];
    //     snakes[1] = env.snakes[1];
    //     cur_round = env.cur_round;
    //     cur_side = env.cur_side;
    //     cur_snake = env.cur_snake;
    //     act_snake_nums[0] = act_snake_nums[0];
    //     act_snake_nums[1] = act_snake_nums[1];
    //     snake_nums[0]=snake_nums[0];
    //     snake_nums[1]=snake_nums[1];
    //     for (int i=0;i<BOARD_SIZE;i++) for (int j=0;j<BOARD_SIZE;j++){
    //         blocks[i][j]=env.blocks[i][j];
    //         item_map[i][j]=env.item_map[i][j];
    //         if (item_map[i][j]==0){continue;}
    //         item_param_map[i][j]=env.item_param_map[i][j];
    //         item_time_map[i][j]=env.item_time_map[i][j];
    //     }
    //     end = env.end;
    // }
    SnakeGoEnv(){
        // gen id
        for (int i=0;i<4;i++){
            ip[i]=randint(0,250);
        }
        //
        generate_items(item_list);
        item_ptr=0;
        for (int i=0;i<2;i++){
            snakes[i].clear();
            vector<Pos> init_body;
            init_body.clear();
            if (i==0){init_body.push_back(Pos(0,15));}
            else{init_body.push_back(Pos(15,0));}
            MySnake snake=MySnake(
                init_body, 8, 0, i
            );
            snakes[i].push_back(snake);
        }
        cur_round=1;
        cur_side = 0;
        cur_snake = 0;
        snake_nums[0]=1;
        snake_nums[1]=1;
        act_snake_nums[0]=1;
        act_snake_nums[1]=1;
        for (int i=0;i<BOARD_SIZE;i++){
            for (int j=0;j<BOARD_SIZE;j++){
                blocks[i][j]=0;
                item_map[i][j]=0;
            }
        }
        end = false;
    };
    void load_from_json(string path){
        ifstream t(path);
        string str((istreambuf_iterator<char>(t)),
            istreambuf_iterator<char>());
        Document document;
        document.Parse(str.c_str());
        // read item
        item_list.clear();
        auto & p_item_list = document["item_list"];
        int loc=0;
        int len_item = int(p_item_list.Size());
        while(loc<len_item){
            item_list.push_back(MyItem(
                loc/5, 
                p_item_list[loc].GetInt(),
                p_item_list[loc+1].GetInt(),
                p_item_list[loc+2].GetInt(),
                p_item_list[loc+3].GetInt(),
                p_item_list[loc+4].GetInt()
            ));
            loc+=5;
        }
        // read attr
        cur_round = document["cur_round"].GetInt();
        cur_side = document["cur_side"].GetInt();
        cur_snake = document["cur_snake"].GetInt();
        item_ptr = document["item_ptr"].GetInt();
        act_snake_nums[0] = document["act_snake_nums_0"].GetInt();
        act_snake_nums[1] = document["act_snake_nums_1"].GetInt();
        snake_nums[0] = document["snake_nums_0"].GetInt();
        snake_nums[1] = document["snake_nums_1"].GetInt();
        // read snakes
        snakes[0].clear();
        snakes[1].clear();
        auto & p_snakes = document["snakes"];
        for (int camp=0;camp<2;camp++){
            for (int i_snake=0;i_snake<snake_nums[camp];i_snake++){
                auto & snake_info = p_snakes[camp][i_snake];
                auto & body = snake_info["body"];
                MySnake snake;
                snake.body.clear();
                int q = 0;
                while (q<int(body.Size())){
                    snake.body.push_back(Pos(body[q].GetInt(),body[q+1].GetInt()));
                    q+=2;
                }
                snake.length_bank = snake_info["length_bank"].GetInt();
                snake.melt = snake_info["melt"].GetInt();
                snakes[camp].push_back(snake);
            }
        }
        // read all maps
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                loc = x*BOARD_SIZE+y;
                blocks[x][y] = document["blocks"][loc].GetInt();
                item_map[x][y] = document["item_map"][loc].GetInt();
                item_param_map[x][y] = document["item_param_map"][loc].GetInt();
                item_time_map[x][y] = document["item_time_map"][loc].GetInt();
            }
        }
        // read other
        end = document["end"].GetBool();
        for (int i=0;i<4;i++){
            ip[i]=document["ip"][i].GetInt();
        }
    }
    void load_env();
    void add_item_reward(double & reward, int item_param, int camp){
        double item_rew = double(item_param)*0.026;
        if (camp!=cur_side) {item_rew*=-1;}
        reward+=item_rew;
    }
    double step(int action){ // return reward
        assert(valid_action(action));
        double reward=0.0;
        // gen_item first // item:id,x,y,time,type,param;
        int len_item = item_list.size();
        if (item_ptr<len_item){
            auto & item=item_list[item_ptr];
            if (cur_round==item.time) {
                //check directly fall
                bool item_fall=false;
                for (int camp=0;camp<2;camp++){
                    for (int i_snake=0;i_snake<snake_nums[camp];i_snake++){
                        auto & snake = snakes[camp][i_snake];
                        auto & body = snake.body;
                        for (auto & pos:body){
                            if (item.x==pos.x&&item.y==pos.y){
                                snake.add_item(item.type, item.param);
                                item_fall=true;
                                // get item reward
                                add_item_reward(reward, item.param, camp);
                                break;
                            }
                        }
                    }
                }
                if (!item_fall){
                    item_map[item.x][item.y]=item.type; // item.type 1,2; env.item_map 1,2;
                    item_param_map[item.x][item.y]=item.param;
                    item_time_map[item.x][item.y] = 16;
                }
                item_ptr+=1;
            }
        }
        //
        auto & snake = snakes[cur_side][cur_snake];
        auto & body = snake.body;
        if (action<4) {// move
            auto & head_pos = body[0];
            Pos new_pos;
            get_next_pos(head_pos, action, new_pos);
            bool collision=check_collision(new_pos);
            if (collision){
                // cout<<"collision-"<<endl;
                // die punishment
                double die_pun = double(int(snake.body.size())+snake.length_bank)*0.026;
                reward-=die_pun;
                delete_snake(cur_side, cur_snake);
            }else{
                // cout<<"not collision-"<<endl;
                auto & body=snake.body;
                body.insert(body.begin(),new_pos);
                // cout<<"add pos : "<<body[0].x<<","<<body[0].y<<body[1].x<<","<<body[1].y<<endl;
                if (snake.length_bank>0){
                    // cout<<"has length bank"<<endl;
                    snake.length_bank-=1;
                }else{
                    // cout<<"without length bank"<<endl;
                    body.pop_back();
                }
                bool solidify_flag = check_solidify(new_pos);
                if (solidify_flag) {
                    // cout<<"solidify"<<endl;
                    // for (auto & pos:body){
                    //     cout<<pos.x<<","<<pos.y<<endl;
                    // }
                    body_to_blocks(body);
                    delete_snake(cur_side, cur_snake);
                } else if (item_map[new_pos.x][new_pos.y]!=0) { // get item 
                    // cout<<"get_item"<<endl;
                    snake.add_item(item_map[new_pos.x][new_pos.y], item_param_map[new_pos.x][new_pos.y]);
                    // get item reward
                    add_item_reward(reward, item_param_map[new_pos.x][new_pos.y], cur_side);
                    item_map[new_pos.x][new_pos.y]=0;
                }
            }
        } else if (action==4){ // split
            // cout<<"in split"<<endl;
            bool init_round;
            init_round = (cur_round<=8&&snake.length_bank>0);
            if (init_round) {snake.length_bank-=1;}
            vector<Pos> tail_body; tail_body.clear();
            int len_body = int(body.size());
            int len_tail = int(len_body/2);
            int len_head = len_body-len_tail;
            int tail_length_bank;
            for (int i=0;i<len_tail;i++){
                tail_body.push_back(body.back());
                body.pop_back();
            }
            if (init_round){
                tail_length_bank=0;
            } else {
                tail_length_bank = snake.length_bank;
                snake.length_bank=0;
            }
            MySnake tail_snake=MySnake(tail_body, tail_length_bank, 0, cur_side);
            snakes[cur_side].push_back(tail_snake);
            snake_nums[cur_side]+=1;
        } else if (action==5){ // melt
            int dx,dy;
            dx = body[0].x-body[1].x;
            dy = body[0].y-body[1].y;
            int mx,my;
            mx = body[0].x + dx;
            my=body[0].y + dy;
            while (mx>=0&&mx<BOARD_SIZE&&my>=0&&my<BOARD_SIZE){
                if (blocks[mx][my]!=0){
                    blocks[mx][my]=0;
                }
                mx+=dx;
                my+=dy;
            }
            snake.melt=0;
        }
        // push process
        cur_snake+=1;
        // cout<<"cursnake/act_snake:"<<cur_snake<<"/"<<act_snake_nums[cur_side]<<endl;
        if (cur_snake>=act_snake_nums[cur_side]){
            // situation that one side 0 snake?
            bool skip_round=false;
            cur_snake=0;
            int other_side = 1-cur_side;
            if (other_side==0){skip_round=true;}
            if (act_snake_nums[other_side]!=0){
                cur_side=1-cur_side;
            } else {
                skip_round=true;
            }
            if (skip_round) {
                // item_process and disappear
                for (int i=0;i<BOARD_SIZE;i++){
                    for (int j=0;j<BOARD_SIZE;j++){
                        if (item_map[i][j]==0) {continue;}
                        item_time_map[i][j]-=1;
                        if (item_time_map[i][j]==0){
                            item_map[i][j]=0;
                        }
                    }
                }
                cur_round+=1;
                act_snake_nums[0]=snake_nums[0];
                act_snake_nums[1]=snake_nums[1];
            }
        }
        // check end and score
        if (act_snake_nums[0]==0&&act_snake_nums[1]==0){end=true;}
        if (cur_round>512) {end=true;}
        // cout<<"---------- "<<cur_round<<" ------------"<<endl;
        return reward;
    }
    bool valid_action(int action){
        //cout<<"curside&snake:"<<cur_side<<"/"<<cur_snake<<endl;
        auto & snake = snakes[cur_side][cur_snake];
        int len_snake = int(snake.body.size());
        if (action<4) {
            auto & head_pos = snake.body[0];
            Pos new_pos;
            get_next_pos(head_pos, action, new_pos);
            // in board
            if (new_pos.x<0||new_pos.x>15||new_pos.y<0||new_pos.y>15){
                return false;
            }
            if ((len_snake>2)||(len_snake==2&&snake.length_bank>0)){
                Pos & pos1 = snake.body[1];
                if (new_pos.x==pos1.x&&new_pos.y==pos1.y){
                    return false;
                }
            }
        }
        if (action==4){ //split
            if (len_snake<2){return false;}
            int num_snake = snakes[cur_side].size();
            if (num_snake>=4){return false;}
        }
        if (action==5){ //melt
            if (snake.melt==0){return false;}
            if (len_snake<2){return false;}
        }
        return true;
    }
    bool check_collision(Pos & pos){
        // check collide with other snakes
        for (int camp=0;camp<2;camp++){
            for (int i_snake=0;i_snake<snake_nums[camp];i_snake++){
                if (camp==cur_side&&i_snake==cur_snake) {continue;}
                auto & body=snakes[camp][i_snake].body;
                for (auto & check_pos:body){
                    if (pos.x==check_pos.x&&pos.y==check_pos.y){
                        return true;
                    }
                }
            }
        }
        // check collide with block
        if (blocks[pos.x][pos.y]!=0) {return true;}
        return false;
    }
    bool check_solidify(Pos & pos){
        auto & body = snakes[cur_side][cur_snake].body;
        int len_body = int(body.size());
        if (len_body<5) {return false;}
        for (int i=1;i<len_body;i++){
            if (pos.x==body[i].x&&pos.y==body[i].y){
                return true;
            }
        }
        return false;
    }
    void delete_snake(int camp, int i_snake){
        auto & camp_snakes = snakes[camp];
        camp_snakes.erase(camp_snakes.begin()+i_snake);
        if (camp==cur_side) {cur_snake-=1;}
        act_snake_nums[camp]-=1;
        snake_nums[camp]-=1;
    }
    void body_to_blocks(vector<Pos> & body){
        // get solid length & solidify body
        int solid_tail=-1;
        int body_len = int(body.size());
        int xmin=99; int ymin=99; int xmax=0; int ymax=0;
        auto & head = body[0];
        for (int i=1;i<body_len;i++){
            if (solid_tail==-1&&head.x==body[i].x&&head.y==body[i].y){
                solid_tail=i;
            }
            if (body[i].x<xmin) {xmin=body[i].x;}
            if (body[i].x>xmax) {xmax=body[i].x;}
            if (body[i].y<ymin) {xmin=body[i].y;}
            if (body[i].y>ymax) {ymax=body[i].y;}
        }
        assert(solid_tail!=-1);
        int solid_flag = (cur_side==0)?1:-1;
        for (int i=0;i<solid_tail;i++){
            auto & pos=body[i];
            blocks[pos.x][pos.y]=solid_flag;
        }
        //calc inside solidify
        // cout<<"!"<<endl;
        bool on_body;
        int cnt_cross;
        bool cont_flag;
        for (int i=xmin;i<=xmax;i++){
            for (int j=ymin;j<=ymax;j++){
                on_body=false;
                for (auto & pos:body){
                    if (pos.x==i&&pos.y==j){
                        on_body=true; break;
                    }
                }
                if (on_body) {continue;}
                cnt_cross = 0;
                cont_flag = false;
                for (int i_pos=0;i_pos<solid_tail;i_pos++){
                    auto & pos = body[i_pos];
                    if (pos.x!=i){
                        if (cont_flag){
                            cnt_cross+=1;
                            cont_flag=false;
                        }
                        continue;
                    } else{
                        if (pos.y<=j) {continue;}
                        // cross
                        if (cont_flag){continue;}
                        else {
                            cnt_cross+=1;
                            cont_flag=true;
                        }
                    }
                }
                if (cnt_cross%2==1){
                    blocks[i][j]=solid_flag;
                }
            }
        }
        // cout<<"?"<<endl;
        // check snakes killed by blocks. (checking head is enough.)
        for (int camp=0;camp<2;camp++){
            for (int i_snake=0;i_snake<snake_nums[camp];i_snake++){
                if (camp==cur_side&&cur_snake==i_snake){continue;}
                auto & head=snakes[camp][i_snake].body[0];
                if (blocks[head.x][head.y]!=0){
                    delete_snake(camp, i_snake);
                    i_snake-=1;
                }
            }
        }
    }
    double get_winner_value(double & downgrade_block_score){
        // positive as cur_side
        double score = 0.0;
        downgrade_block_score = 0.0;
        for (int i=0;i<BOARD_SIZE;i++){
            for (int j=0;j<BOARD_SIZE;j++){
                if (blocks[i][j]==1){
                    score+=1.0;
                } else if (blocks[i][j]==-1){
                    score-=1.0;
                }
            }
        }
        downgrade_block_score+=score*0.5;
        double snake_score;
        for (int camp=0; camp<2;camp++){
            for (int i_snake=0;i_snake<snake_nums[camp];i_snake++){
                auto & snake = snakes[camp][i_snake];
                snake_score = int(snake.body.size())+snake.length_bank;
                // fprintf(stderr,"camp:%d i:%d length:%d\n",
                //     camp, i_snake, int(snake.body.size())+snake.length_bank
                // );
                if (camp==1) {
                    snake_score*=-1;
                }
                score+=snake_score;
                downgrade_block_score+=snake_score;
            }
        }
        // norm by 1/12.8
        return score;
    }
};

#endif

// int main(){
//     FILE * pfile;
//     pfile = fopen("test.txt","r");
//     bool flag = bool(pfile);
//     cout<<flag<<endl;
//     return 0;
// }
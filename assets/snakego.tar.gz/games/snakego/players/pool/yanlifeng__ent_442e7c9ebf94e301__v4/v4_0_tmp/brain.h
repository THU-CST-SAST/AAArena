#include "snakego_env.h"

vector<Pos> open_list;
int open_ptr;
bool open_map[BOARD_SIZE][BOARD_SIZE];
int dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int tail_dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int (*map_ptr)[2][4][BOARD_SIZE][BOARD_SIZE];
int lock_map[BOARD_SIZE][BOARD_SIZE];

inline void src_spfa(Pos & src, int camp, int i_snake, bool is_tail){
    open_list.clear();
    open_list.push_back(src);
    int init_val;
    if (!is_tail){
        map_ptr = &dis_map;
        init_val = 0;
    } else {
        map_ptr = &tail_dis_map;
        init_val = 1;
    }
    auto & res_map = *map_ptr;
    for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
        res_map[camp][i_snake][x][y]=999;
        open_map[x][y]=false;
    }
    res_map[camp][i_snake][src.x][src.y]=init_val;
    open_map[src.x][src.y]=true;
    open_ptr=0;
    int newx, newy;
    int dis1;
    // fprintf(stderr,"%d\n",res_map[camp][i_snake][6][10]);
    while (open_ptr<int(open_list.size())){
        Pos pos = open_list[open_ptr];
        // fprintf(stderr,"%d %d\n",pos.x,pos.y);
        dis1 = res_map[camp][i_snake][pos.x][pos.y]+1;
        for (int idir=0;idir<4;idir++){
            newx = pos.x+dxs[idir];
            newy = pos.y+dys[idir];
            if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
            if (dis1<lock_map[newx][newy]){continue;}
            // fprintf(stderr,"In");
            // fprintf(stderr,"%d %d %d %d %b\n",newx,newy,dis1, res_map[camp][i_snake][newx][newy], open_map[newx][newy]);
            
            if (dis1<res_map[camp][i_snake][newx][newy]){
                res_map[camp][i_snake][newx][newy] = dis1;
                if (!open_map[newx][newy]){
                    open_map[newx][newy] = true;
                    open_list.push_back(Pos(newx,newy));
                }
            }
        }
        open_map[pos.x][pos.y]=false;
        open_ptr++;
    }
    // fprintf(stderr, "spfa_vol:%d\n", open_ptr);
    // exit(0);
}

inline void get_dis_map(SnakeGoEnv & env){
    //init
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            lock_map[x][y]=0;
            if (env.blocks[x][y]!=0){
                lock_map[x][y]=999;
            }
        }
    }
    // set body lock map
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            // assign lock map
            auto & snake=env.snakes[camp][i_snake];
            auto & body = snake.body;
            int len_body=int(body.size());
            for (int i_body=0;i_body<len_body;i_body++){
                lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
            }
        }
    }
    // for each snake spfa get dis_map & tail_dis_map
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            auto & snake=env.snakes[camp][i_snake];
            Pos & head = snake.body[0];
            src_spfa(head, camp, i_snake, false);
            int tail_ind = int(snake.body.size())-1;
            if (tail_ind>=0){
                Pos & tail =snake.body[tail_ind];
                src_spfa(tail, camp, i_snake, true);
            }
        }
    }
}

inline int check_pos_camp(SnakeGoEnv & env, Pos & pos){
    int pos_camp = -1;
    for (int camp=0;camp<2;camp++) {
        for (auto & snake:env.snakes[camp]){
            for (auto &p:snake.body){
                if (p.x==pos.x&&p.y==pos.y){
                    pos_camp = camp;
                    break;
                }
            }
        }
        if (pos_camp!=-1){break;}
    }
    return pos_camp;
}

int num_req = 0;
struct SnakeAnchor{
    int x, y, camp;
    double adj;
    SnakeAnchor(int px, int py, int pcamp, double padj){
        x = px;
        y = py;
        camp = pcamp;
        adj = padj;
    }
};
vector<SnakeAnchor> snake_anchors;

double hit_map[BOARD_SIZE][BOARD_SIZE];

inline void rev_hit_spfa(MyItem & item, int & res_camp, double & res_hit_dis, double & fall_bonus, 
    SnakeGoEnv&env, bool debug){
    for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
        hit_map[x][y] = 999.0;
        open_map[x][y]=false;
    }
    // if (debug){
    //     fprintf(stderr,"item %d %d >>>\n", item.x, item.y);
    //     for (auto & anchor: snake_anchors){
    //         fprintf(stderr,"%d %d %d %.2lf | ",anchor.x,anchor.y,anchor.camp,anchor.adj);
    //     }
    //     fprintf(stderr,"\n");
    // }
    Pos src = Pos(item.x,item.y);
    open_list.clear();
    open_list.push_back(src);
    hit_map[src.x][src.y]=0.0;
    open_map[src.x][src.y]=true;
    open_ptr = 0;
    int newx, newy;
    double dis1, dis_dx, remain1, adj_dis;
    Pos pos;
    int hit_camp=-1;
    double hit_dis = 999;
    // if fall in body?
    // if ((lock_map[src.x][src.y]>0)&&(item.time-env.cur_round<lock_map[src.x][src.y])){
    //     hit_camp = check_pos_camp(env, pos);
    //     hit_dis = 0.0;
    // }
    fall_bonus=1.0;
    for (int camp=0;camp<2;camp++){
        for (auto &snake:env.snakes[camp]){
            auto &body = snake.body;
            for (auto &p:body){
                if (src.x==p.x&&src.y==p.y){
                    hit_camp=camp;
                    if (lock_map[p.x][p.y]>item.time-env.cur_round){
                        fall_bonus=1.2;
                    }
                    hit_dis=0.0;
                    break;
                }
            }
        }
    }
    // fprintf(stderr,"---\n");
    if (hit_camp==-1){
        while (open_ptr<int(open_list.size())){
            pos = open_list[open_ptr];
            dis1 = hit_map[pos.x][pos.y]+1.0;
            if (dis1<hit_dis+1){
                for (int idir=0;idir<4;idir++){
                    dis_dx = dis1;
                    newx = pos.x+dxs[idir];
                    newy = pos.y+dys[idir];
                    if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
                    // check hit
                    for (auto & snake_anchor:snake_anchors){
                        if (newx==snake_anchor.x&&newy==snake_anchor.y){
                            double tmp_hit_dis = dis_dx+snake_anchor.adj;
                            if (tmp_hit_dis<hit_dis){
                                hit_dis = tmp_hit_dis;
                                hit_camp = snake_anchor.camp;
                                // fprintf(stderr,"upd %d %d %lf %d\n", newx, newy, hit_dis, hit_camp);
                            }
                        }
                    }
                    if (lock_map[newx][newy]>0){
                        dis_dx+=double(lock_map[newx][newy]);
                    }
                    // fprintf(stderr,"%d %d %lf %d\n",newx, newy, dis1, lock_map[newx][newy]);
                    if (dis_dx<hit_map[newx][newy]){
                        hit_map[newx][newy]=dis_dx;
                        if (!open_map[newx][newy]){
                            open_map[newx][newy] = true;
                            open_list.push_back(Pos(newx,newy));
                        }
                    }
                }
            }
            open_map[pos.x][pos.y]=false;
            open_ptr++;
        }
    }
    // exit(0);
    res_camp = hit_camp;
    res_hit_dis = hit_dis;
}

inline bool in_bound(Pos & pos){
    return (pos.x>=0&&pos.x<BOARD_SIZE&&pos.y>=0&&pos.y<BOARD_SIZE);
}

inline bool pos_is_head(SnakeGoEnv & env, Pos & pos){
    bool is_head=false;
    for (int camp=0;camp<2;camp++) {
        for (auto & snake:env.snakes[camp]){
            auto & p=snake.body[0];
            if (p.x==pos.x&&p.y==pos.y){
                is_head=true;
                break;
            }
        }
    }
    return is_head;
}

int min_snakes_len[2];
inline double get_snake_kill_score(SnakeGoEnv & env, bool debug){
    double kill_score = 0.0;
    min_snakes_len[0]=999;
    min_snakes_len[1]=999;
    for (int camp=0;camp<2;camp++){
        for (auto & snake:env.snakes[camp]){
            if (int(snake.body.size())<min_snakes_len[camp]){
                min_snakes_len[camp] = int(snake.body.size());
            }
        }
    }

    Pos direct;
    Pos left, right;
    int left_block_time, right_block_time;
    int min_block;
    bool killed;
    for (int camp=0;camp<2;camp++){
        int len_snakes=env.snakes[camp].size();
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            auto & snake = env.snakes[camp][i_snake];
            auto & body = snake.body;
            auto & head = body[0];
            // fprintf(stderr,"?\n");
            if (int(snake.body.size())<=2) {continue;}
            direct = Pos(body[0].x-body[1].x, body[0].y-body[1].y);
            left = Pos(head.x+direct.y, head.y-direct.x);
            right = Pos(head.x-direct.y, head.y+direct.x);
            // if (debug){
            //     fprintf(stderr,"%d %d\n", direct.x, direct.y);
            //     fprintf(stderr,"%d %d\n", left.x, left.y);
            //     fprintf(stderr,"%d %d\n", right.x, right.y);
            //     fprintf(stderr,"%d %d\n", lock_map[left.x][left.y], in_bound(left));
            // }
            // calc left block time
            left_block_time=0;
            if (!in_bound(left)){
                left_block_time = 999;
            } else {
                if (lock_map[left.x][left.y]>0){
                    if (lock_map[left.x][left.y]>900){ // is block
                        Pos left_exp; left_exp = left;
                        int tmp_block_time=0;
                        while (in_bound(left_exp)&&(lock_map[left_exp.x][left_exp.y]>900)){
                            left_exp = Pos(left_exp.x+direct.x, left_exp.y+direct.y);
                            tmp_block_time+=1;
                        }
                        left_block_time=tmp_block_time;
                    }
                    else {
                        Pos left_exp=Pos(left.x+direct.x,left.y+direct.y);
                        if (!in_bound(left_exp)){
                            left_block_time=1;
                        } else {
                            if ((lock_map[left_exp.x][left_exp.y]>lock_map[left.x][left.y])||pos_is_head(env, left)){
                                if (check_pos_camp(env, left)!=camp){
                                    left_block_time=999;
                                } else {
                                    left_block_time=1;
                                }
                            } else {
                                left_block_time = 1;
                            }
                        }
                    }
                }
            }
            // calc right block time
            right_block_time=0;
            if (!in_bound(right)){
                right_block_time = 999;
            } else {
                if (lock_map[right.x][right.y]>0){
                    if (lock_map[right.x][right.y]>900){ // is block
                        Pos right_exp; right_exp = right;
                        int tmp_block_time=0;
                        while (in_bound(right_exp)&&(lock_map[right_exp.x][right_exp.y]>900)){
                            right_exp = Pos(right_exp.x+direct.x, right_exp.y+direct.y);
                            tmp_block_time+=1;
                        }
                        right_block_time=tmp_block_time;
                    }
                    else {
                        Pos right_exp=Pos(right.x+direct.x,right.y+direct.y);
                        if (!in_bound(right_exp)){
                            right_block_time=1;
                        } else {
                            // if (debug){
                            //     fprintf(stderr,"right lockinfo %d %d\n",
                            //         lock_map[right_exp.x][right_exp.y],
                            //         lock_map[right.x][right.y]);
                            // }
                            if ((lock_map[right_exp.x][right_exp.y]>lock_map[right.x][right.y])||pos_is_head(env, right)){
                                if (check_pos_camp(env, right)!=camp){
                                    right_block_time=999;
                                } else {
                                    right_block_time=1;
                                }
                            } else {
                                right_block_time = 1;
                            }
                        }
                    }
                }
            }
            // if (debug){
            //     fprintf(stderr,"l/r block time:%d %d\n",
            //         left_block_time,right_block_time);
            // }
            min_block = (left_block_time<right_block_time)?left_block_time:right_block_time;
            killed = false;
            if (min_block>BOARD_SIZE){
                killed=true;
            } else {
                Pos exp_pos = head;
                for (int iexp=0;iexp<min_block;iexp++){
                    exp_pos = Pos(exp_pos.x+direct.x,exp_pos.y+direct.y);
                    if (!in_bound(exp_pos)){killed=true; break;}
                    if (lock_map[exp_pos.x][exp_pos.y]>iexp){
                        killed=true;
                        break;
                    }
                }
            }

            if (killed){
                int len_body = int(body.size());
                double loss0 = double(len_body);
                double loss1 = double(len_body)/2.0 + double(min_snakes_len[camp]);
                double min_loss;
                if (loss0>loss1){min_loss=loss1;} else {min_loss=loss0;}
                if (min_loss>0){
                    if (camp==0){
                        kill_score-=min_loss;
                    } else {
                        kill_score+=min_loss;
                    }
                }
                // fprintf(stderr,"killed %d %d\n",camp,i_snake);
            }
        }
    }
    return kill_score;
}

void print_board(int board[BOARD_SIZE][BOARD_SIZE]){
    fprintf(stderr,"******\n");
    for (int y=0;y<BOARD_SIZE;y++){
        for (int x=0;x<BOARD_SIZE;x++){
            if (board[x][y]>0){
                fprintf(stderr,"x ");}
            else if (board[x][y]==0) {fprintf(stderr,"o ");}
            else {fprintf(stderr,"- ");}
        }
        fprintf(stderr,"\n");
    }
}


vector<Pos> snake_open_lists[8];
int iopens[8];
bool flags[BOARD_SIZE][BOARD_SIZE];
int camp_taken_map[BOARD_SIZE][BOARD_SIZE];
int camp_dis_map[BOARD_SIZE][BOARD_SIZE];
int linear_lock_map[BOARD_SIZE][BOARD_SIZE];

inline void add_item_belong_score(double & bs, SnakeGoEnv & env, int item_ind, bool discount_flag, bool debug){
    auto & item = env.item_list[item_ind];
    Pos pos = Pos(item.x,item.y);
    int hit_camp, hit_dis;
    bool get_flag=false;
    hit_camp = camp_taken_map[item.x][item.y];
    hit_dis = camp_dis_map[item.x][item.y];
    // if (debug){
    //     fprintf(stderr, "%d %d %d %d\n", item.x, item.y, hit_camp, hit_dis);
    // }
    double fall_bonus;
    if ((lock_map[item.x][item.y]>0)&&(item.time-env.cur_round<lock_map[item.x][item.y])){
        // fall
        hit_camp = check_pos_camp(env, pos);
        get_flag=true;
        fall_bonus=1.2;
    } else {
        if (debug){
            fprintf(stderr, "%d %d %d %d\n", item.x, item.y, hit_dis, item.time-env.cur_round+15);
        }
        get_flag = (hit_dis<item.time-env.cur_round+15);
        fall_bonus=1.0;
    }

    

    if (get_flag){
        double item_value;
        if (item.type==1){
            item_value =  double(item.param);
        } else{
            item_value = 1.2;
        }
        item_value*=fall_bonus;
        double discount;
        if (!discount_flag){
            discount=1.0;
        } else {
            if (item.time<=env.cur_round+32){
                discount=1.0;
            }else{
                discount=1.0 * pow(0.975, float(item.time-env.cur_round-32));
            }
        }
        // item block discount
        Pos new_pos;
        int num_item_blocks = 0;
        for (int idir=0;idir<4;idir++){
            new_pos = Pos(item.x+dxs[idir],item.y+dys[idir]);
            if (!in_bound(new_pos)||env.blocks[new_pos.x][new_pos.y]!=0){
                num_item_blocks+=1;
            }
        }
        if (num_item_blocks==3){discount*=0.1;}
        else if (num_item_blocks==2) {discount*=0.65;}
        else if (num_item_blocks==1) {discount*=0.85;}
        //
        item_value*=discount;        
        if (hit_camp==0){
            bs+=item_value;
        } else if (hit_camp==1){
            bs-=item_value;
        }
        if (debug){
            fprintf(stderr,"%d %d %d %.3lf %d %.3lf\n",item.x, item.y, hit_camp, item_value, hit_dis, bs);
        }
    }
}

inline double multi_spfa_belong(SnakeGoEnv & env, vector<int> & item_inds,bool debug){
    double bs=0;
    memset(camp_taken_map,0,sizeof(camp_taken_map));
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            flags[x][y]=false;
            camp_dis_map[x][y]=999;
        }
    }
    for (int snake_ind=0;snake_ind<8;snake_ind++){
        snake_open_lists[snake_ind].clear();
        iopens[snake_ind]=0;
    }
    // init each snake
    for (int camp=0;camp<2;camp++){
        int len_snakes = env.snakes[camp].size();
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            auto & snake=env.snakes[camp][i_snake];
            int snake_ind = camp*4+i_snake;
            auto & head = snake.body[0];
            snake_open_lists[snake_ind].push_back(head);
            flags[head.x][head.y]=true;
            camp_taken_map[head.x][head.y]=camp;
        }
    }
    //
    int start_side = env.cur_side;
    int start_snake = env.cur_snake;
    int exp_side = env.cur_side;
    int exp_snake = env.cur_snake;
    Pos new_pos;
    int new_intpos;
    bool updated = false;
    int now_dis=0;
    while (true){
        int snake_ind = exp_side*4+exp_snake;
        auto & snake_open_list = snake_open_lists[snake_ind];
        auto & snake=env.snakes[exp_side][exp_snake];
        if (int(snake.body.size())>1){
            int end_seq=int(snake_open_list.size());
            for (int iopen=iopens[snake_ind];iopen<end_seq;iopen++){
                auto & from_pos = snake_open_list[iopen];
                for (int i=0;i<4;i++){
                    new_pos = Pos(from_pos.x+dxs[i], from_pos.y+dys[i]);
                    if (!in_bound(new_pos)){continue;}
                    if (lock_map[new_pos.x][new_pos.y]>now_dis+1){continue;}
                    if (flags[new_pos.x][new_pos.y]){continue;}
                    flags[new_pos.x][new_pos.y]=true;
                    snake_open_list.push_back(new_pos);
                    camp_taken_map[new_pos.x][new_pos.y]=exp_side;
                    camp_dis_map[new_pos.x][new_pos.y]=now_dis+1;
                    // if (debug){
                    //     fprintf(stderr,"%d %d %d | ",new_pos.x, new_pos.y, now_dis);
                    // }
                    updated=true;
                }
            }
        }
        // next
        exp_snake+=1;
        if (exp_snake>=env.snake_nums[exp_side]){
            exp_side = 1-exp_side;
            exp_snake=0;
        }
        if (exp_snake==start_snake&&exp_side==start_side){
            if (!updated){break;}
            now_dis+=1;
            updated=false;
        }
    }
    
    int tmp;
    for (auto & i_item:item_inds){
        add_item_belong_score(bs, env, i_item, false, debug);
        tmp = i_item;
    }
    // for (int i_item=tmp;i_item<tmp+2;i_item++){
    //     add_item_belong_score(bs, env, i_item, true, debug);
    // }
    return bs;
}

vector<int> item_inds;
vector<MyItem> score_items;
vector<MyItem> remain_items;
int randseed=0;

namespace brain{
    inline void make_probvs(SnakeGoEnv& env, vector<double> & mcts_probvs, double score){
        mcts_probvs.clear();
        if (randseed==3){
            randseed=0;
        } else{
            randseed+=1;
        }
        // double act_p;
        for (int i=0;i<4;i++){
            mcts_probvs.push_back((randseed==i)?0.2015:0.1995);
        }
        mcts_probvs[1]+=0.2;
        auto & snake=env.snakes[env.cur_side][env.cur_snake];
        int len_snake = int(snake.body.size());
        if (len_snake==5||len_snake==6||len_snake==7){
            mcts_probvs.push_back(0.01);
        } else{
            mcts_probvs.push_back(0.1);
        }
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(score);
    }
    inline void get_skip_probvs(SnakeGoEnv& env, vector<double> & mcts_probvs){
        make_probvs(env, mcts_probvs, 0.0);
    }
    inline void get_unsolved_item_inds(vector<int>& item_inds, SnakeGoEnv& env, int consider_item_num){
        item_inds.clear();
        int i_item=0;
        int len_items = int(env.item_list.size());
        for (int i_item=0;i_item<len_items;i_item++){
            auto & item = env.item_list[i_item];
            if (item.time-env.cur_round+16<=0){continue;}
            auto & x=item.x;
            auto & y=item.y;
            if (env.blocks[x][y]!=0){continue;}
            if (env.cur_round<415){
                if (env.item_map[x][y]==1){
                    if (item.time-env.cur_round+16==env.item_time_map[x][y]){
                        item_inds.push_back(i_item);
                    }
                }
                else if (item.time>env.cur_round&&item.type==1){
                    item_inds.push_back(i_item);
                }
            }
            else{
                if (env.item_map[x][y]==1||env.item_map[x][y]==2){
                    item_inds.push_back(i_item);
                } else if (item.time>env.cur_round){
                    item_inds.push_back(i_item);
                }
            }
            if (int(item_inds.size())>=consider_item_num){break;}
        }
    }
    inline void calc_dis_map(SnakeGoEnv & env){
        // bfs get dis_map
        get_dis_map(env);
    }
    
    inline void get_item_belong_score(SnakeGoEnv & env, int consider_item_num, 
        vector<double> & mcts_probvs,bool debug, double baseline, bool open_game){
        double score = 0;
        double downgrad_block_score=0.0;
        double winner_value = env.get_winner_value(downgrad_block_score);
        score+=1.5*downgrad_block_score;
        // if (env.cur_round<450){
        //     score += 1.5 * downgrad_block_score;
        // } else {
        //     score += 1.5 * winner_value; 
        // }
        get_unsolved_item_inds(item_inds, env, consider_item_num);
        double belong_score=0.0;
        // init lock map
        for (int x=0;x<BOARD_SIZE;x++){
            for (int y=0;y<BOARD_SIZE;y++){
                lock_map[x][y]=0;
                if (env.blocks[x][y]!=0){
                    lock_map[x][y]=999;
                }
            }
        }
        // set body lock map
        for (int camp=0;camp<2;camp++) {
            int len_snakes=int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                // assign lock map
                auto & snake=env.snakes[camp][i_snake];
                auto & body = snake.body;
                int len_body=int(body.size());
                for (int i_body=0;i_body<len_body;i_body++){
                    lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
                }
            }
        }
        // make snake target and camp
        snake_anchors.clear();
        for (int camp=0;camp<2;camp++){
            int len_snakes = int(env.snakes[camp].size());
            for (int i_snake=0;i_snake<len_snakes;i_snake++){
                double adj;
                auto & body = env.snakes[camp][i_snake].body;
                int tail_ind = int(body.size())-1;
                Pos head = body[0];
                Pos tail = body[tail_ind];
                if (camp==env.cur_side){
                    if (i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp]){
                        adj=-0.5;
                    } else {
                        adj= 0.0;
                    }
                } else {
                    adj = -0.25;
                }
                if (int(env.snakes[camp][i_snake].body.size())>1){
                    snake_anchors.push_back(SnakeAnchor(
                        head.x, head.y, camp, adj
                    ));
                }
                if (len_snakes<4&&int(env.snakes[camp][i_snake].body.size())>1){//consider tail
                    snake_anchors.push_back(SnakeAnchor(
                        tail.x, tail.y, camp, adj+1
                    )); 
                }    
            }
        }

        // honey pot item score bonus
        int end_i_item = item_inds.back();
        int len_items = int(item_inds.size());
        vector<double> item_bonus; item_bonus.clear();
        for (auto & i_item:item_inds) {item_bonus.push_back(0.0);}
        for (int i_item=end_i_item+1;i_item<end_i_item+3;i_item++){
            if (i_item>=int(env.item_list.size())) {continue;}
            auto & honey_item = env.item_list[i_item];
            int min_arrive_time=999;
            int arrive_time;
            int i_min=-1;
            for (int i=0;i<len_items;i++){
                auto & from_item=env.item_list[item_inds[i]];
                arrive_time = (from_item.time)+abs(honey_item.x-from_item.x)+\
                    abs(honey_item.y-from_item.y);
                if (arrive_time<min_arrive_time){
                    min_arrive_time = arrive_time;
                    i_min = i;
                }
            }
            if (i_min!=-1){
                if (honey_item.type==2){
                    item_bonus[i_min]+= 1.0;
                } else {
                    item_bonus[i_min]+= 0.5*double(honey_item.param);
                }
            }
        }

        if (false){
            // belong score
            for (int i=0;i<len_items;i++){
                auto & i_item = item_inds[i];
                auto & item = env.item_list[i_item];
                Pos pos = Pos(item.x,item.y);
                int hit_camp;
                double hit_dis;
                double fall_bonus;
                rev_hit_spfa(item, hit_camp, hit_dis, fall_bonus, env, debug);
                if (debug){
                    fprintf(stderr, "%d %d %d %d %lf\n", item.x, item.y, hit_camp, item.time-env.cur_round, hit_dis);
                }
                bool get_flag;
                get_flag = (hit_dis<=item.time-env.cur_round+15);
                if (get_flag){
                    double item_value = (double(item.param)+item_bonus[i])*fall_bonus;
                    if (hit_camp==0){
                        belong_score+=item_value;
                    } else if (hit_camp==1){
                        belong_score-=item_value;
                    }
                }
            }
        } else {
            // all_map belong score
            belong_score= multi_spfa_belong(env, item_inds, debug);
        }
        score+=belong_score;
        //
        // fprintf(stderr,"%.2lf, %.2lf\n",belong_score, bs);
        // exit(0);

        // melt on snake score && punish 3len+ punish no snake
        double punish3=0.0;
        double melt_score = 0.0;
        for (int camp=0;camp<2;camp++){
            if ((int(env.snakes[camp].size())==0)&&(env.cur_round<450)){
                if (camp==0){
                    punish3-=30.0;
                } else {
                    punish3+=30.0;
                }
            }
            for (auto & snake:env.snakes[camp]){
                // if (debug){
                //     fprintf(stderr,"%d %d\n",camp,int(snake.body.size()));
                // }
                if (snake.melt>0){
                    melt_score+=(camp==0)?0.8:-0.8;
                }
                if (int(snake.body.size())==3||int(snake.body.size())==1){
                    if (camp==0){
                        punish3-=0.4;
                    } else {
                        punish3+=0.4;
                    }
                }
            }
        }
        double melt_weight;
        if (env.cur_round>256){
            melt_weight=2.0;
        } else{
            melt_weight=2.0 * double(env.cur_round)/256.0;
        }
        melt_score*=melt_weight;
        score+=melt_score;
        score+=punish3;

        // warzone punishment
        double warzone_punish=0.0;
        double center_dis;
        if (open_game) {
            for (int camp=0;camp<2;camp++){
                int len_snakes = int(env.snakes[camp].size());
                for (int i_snake=0;i_snake<len_snakes;i_snake++){
                    auto & body = env.snakes[camp][i_snake].body;
                    auto & head = body[0];
                    center_dis = fabs(double(head.x-7.5))+fabs(double(head.y-7.5));
                    if (camp==0){
                        warzone_punish-=center_dis;
                    } else {
                        warzone_punish+=center_dis;
                    }
                    if (debug){
                        fprintf(stderr,"%d %d %.2lf \n",camp, i_snake, warzone_punish);
                    }
                }
            }
            score+= 0.0110 * warzone_punish;
        }
        
        // simple snake killed
        double kill_score=0.0;
        kill_score = get_snake_kill_score(env, debug);
        score+=kill_score;

        score-=baseline;
        // adjust score
        if (env.cur_side==1){
            score*=-1;
        }
        score/=SCORE_SHRINK;

        if (debug){
            fprintf(stderr,"base:%.4lf\tbs:%.4lf\twarz:%.4lf\tmelt:%.4lf\tp3:%.4lf\tkill:%.4lf\tall:%.4lf\n",
                downgrad_block_score, belong_score, warzone_punish, melt_score, punish3, kill_score, score);
        }

        //
        make_probvs(env, mcts_probvs, score);
    }
};
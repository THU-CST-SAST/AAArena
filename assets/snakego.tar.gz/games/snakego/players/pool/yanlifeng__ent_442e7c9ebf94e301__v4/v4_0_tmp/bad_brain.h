// 这是不好的尝试，由于每条蛇只能选一个，导致一开始倾向于分裂去“锁定”多的资源。
// 结果反而很差。

#include "snakego_env.h"

vector<Pos> open_list;
int open_ptr;
bool open_map[BOARD_SIZE][BOARD_SIZE];
int dis_map[2][4][BOARD_SIZE][BOARD_SIZE];
int lock_map[BOARD_SIZE][BOARD_SIZE];

struct SnakeVal{
    int camp,i_snake;
    double val;
    SnakeVal(int p_camp, int p_i_snake, double p_val){
        camp=p_camp;
        i_snake = p_i_snake;
        val = p_val;
    }
};

int manh_dis(Pos & p0, Pos & p1){
    int res = 0;
    if (p0.x>p1.x){
        res+=p0.x-p1.x;
    } else {
        res+=p1.x-p0.x;
    }
    if (p0.y>p1.y){
        res+=p0.y-p1.y;
    } else {
        res+=p1.y-p0.y;
    }
    return res;
}

void bubble_idxsort_snakeval(vector<SnakeVal> & snake_vals,vector<int> & res){
    int len = int(snake_vals.size());
    int tmp;
    res.clear();
    for (int x=0;x<len;x++){
        res.push_back(x);
    }
    for (int i=0;i<len;i++) for (int j=0; j<len-i-1;j++){
        if (snake_vals[res[j]].val>snake_vals[res[j+1]].val){
            // small to big.
            tmp = res[j];
            res[j] = res[j+1];
            res[j+1] = tmp;
        }
    }
}

void get_dis_map(SnakeGoEnv & env){
    //init
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            lock_map[x][y]=0;
        }
    }
    // for each snake
    for (int camp=0;camp<2;camp++) {
        int len_snakes=int(env.snakes[camp].size());
        for (int i_snake=0;i_snake<len_snakes;i_snake++){
            // assign lock map
            auto & snake=env.snakes[camp][i_snake];
            auto & body = snake.body;
            int len_body=int(body.size());
            for (int i_body=0;i_body<len_body;i_body++){
                lock_map[body[i_body].x][body[i_body].y]=len_body-i_body+snake.length_bank;
            }
            //
            for (int x=0;x<BOARD_SIZE;x++) for (int y=0;y<BOARD_SIZE;y++){
                dis_map[camp][i_snake][x][y]=999;
                open_map[x][y]=false;
                if (env.blocks[x][y]!=0){
                    lock_map[x][y]=999;
                }
            }
            open_list.clear();
            open_list.push_back(body[0]);
            dis_map[camp][i_snake][body[0].x][body[0].y]=0;
            open_ptr=0;
            //search
            int newx, newy;
            int dis1;
            while (open_ptr<int(open_list.size())){
                auto & pos = open_list[open_ptr];
                dis1 = dis_map[camp][i_snake][pos.x][pos.y]+1;
                for (int idir=0;idir<4;idir++){
                    newx = pos.x+dxs[idir];
                    newy = pos.y+dys[idir];
                    if (newx<0||newx>=BOARD_SIZE||newy<0||newy>=BOARD_SIZE){continue;}
                    if (dis1<lock_map[newx][newy]){continue;}
                    if (dis1<dis_map[camp][i_snake][newx][newy]){
                        dis_map[camp][i_snake][newx][newy] = dis1;
                        if (!open_map[newx][newy]){
                            open_map[newx][newy] = true;
                            open_list.push_back(Pos(newx,newy));
                        }
                    }
                }
                open_map[pos.x][pos.y]=false;
                open_ptr++;
            }
        }
    }
}

void print_board(int camp, int i_snake){
    fprintf(stderr,"******\n");
    for (int y=0;y<BOARD_SIZE;y++){
        for (int x=0;x<BOARD_SIZE;x++){
            fprintf(stderr,"%d\t",dis_map[camp][i_snake][x][y]);
        }
        fprintf(stderr,"\n");
    }

}

vector<MyItem> score_items;
namespace brain{
    void req_inference(SnakeGoEnv & env, vector<double> & mcts_probvs, bool debug){
        mcts_probvs.clear();
        for (int i=0;i<4;i++){mcts_probvs.push_back(0.2);}
        mcts_probvs.push_back(0.1);
        mcts_probvs.push_back(0.1);
        // get winner value
        double winner_value = env.get_winner_value();

        // bfs get dis_map
        // clock_t start=clock();
        get_dis_map(env);
        // and calc expect item score(mind own perspection)
        double exp_item_score = 0.0;
        score_items.clear();
        // item_on_map
        // for (int x=0;x<BOARD_SIZE;x++){
        //     for (int y=0;y<BOARD_SIZE;y++){
        //         if (env.item_map[x][y]!=1){continue;}
        //         if (env.blocks[x][y]!=0){continue;}
        //         score_items.push_back(
        //             MyItem(-1,x,y,env.item_time_map[x][y]-16+env.cur_round,1,env.item_param_map[x][y])
        //         );
        //     }
        // }
        // item_in_50_round (include item on map)
        for (auto & item:env.item_list){
            auto &x =item.x; auto &y=item.y;
            if (env.blocks[x][y]!=0){continue;}
            if (item.time<=env.cur_round){
                if (env.item_map[x][y]==1&&env.blocks[x][y]==0){
                    score_items.push_back(
                        MyItem(-1,x,y,env.item_time_map[x][y]-16+env.cur_round,1,env.item_param_map[x][y])
                    );
                }
            }
            else if (item.time<env.cur_round+50){
                score_items.push_back(item);
            }
        }
        // pick item
        int min_camp;
        double min_dis, adj_dis;
        bool snake_lock[2][4];
        for (int i=0;i<2;i++)for (int j=0;j<4;j++){
            snake_lock[i][j]=false;
        }
        // first watch the res of sort
        int len_items = int(score_items.size());
        vector<vector<SnakeVal>> snake_item_dises_list;
        snake_item_dises_list.clear();
        for (int i_item=0;i_item<len_items;i_item++){
            auto & score_item = score_items[i_item];
            auto & x = score_item.x;
            auto & y = score_item.y;
            vector<SnakeVal> snake_item_dises;
            snake_item_dises.clear();
            for (int camp=0;camp<2;camp++){
                int len_snakes = int(env.snakes[camp].size());
                for (int i_snake=0;i_snake<len_snakes;i_snake++){
                    double val = double(dis_map[camp][i_snake][score_item.x][score_item.y]);
                    if (camp==env.cur_side){
                        if (i_snake>=env.cur_snake&&i_snake<env.act_snake_nums[camp]){
                            val -= 0.5;
                        }
                    } else {
                        val-=0.25;
                    }
                    snake_item_dises.push_back(SnakeVal(camp, i_snake,
                        val));
                    // fprintf(stderr,"%lf ", val);
                }
            }
            snake_item_dises_list.push_back(snake_item_dises);
        }

        for (int i_item=0;i_item<len_items;i_item++){
            // fprintf(stderr,"--- %d %d \n",snake_item_dises_list.size(),i_item);
            auto & snake_item_dises = snake_item_dises_list[i_item];
            vector<int> res;
            bubble_idxsort_snakeval(snake_item_dises, res);
            // for (auto &k:res){fprintf(stderr,"%d ", k);}
            // fprintf(stderr,"sorted \n");
            int q=0;
            while (true){
                if (q>=int(res.size())){break;}
                auto & camp=snake_item_dises[res[q]].camp;
                auto & i_snake=snake_item_dises[res[q]].i_snake;
                auto & val = snake_item_dises[res[q]].val;
                if (snake_lock[camp][i_snake]){
                    q+=1;continue;
                }
                bool choose=true;
                if (i_item<len_items-1){
                    auto & next_snake_item_dises = snake_item_dises_list[i_item+1];
                    MyItem & this_item = score_items[i_item];
                    MyItem & next_item = score_items[i_item+1];
                    Pos p0 = Pos(this_item.x,this_item.y);
                    Pos p1 = Pos(next_item.x,next_item.y);
                    if (next_item.param>this_item.param){
                        int mdis = manh_dis(p0, p1);
                        bool next_first = false;
                        bool cant_eat_next = false;
                        bool friend_first = false;
                        double op_dis=999;
                        for (auto & snake_val:snake_item_dises){
                            if (snake_val.camp==camp&&snake_val.i_snake==i_snake){
                                next_first=true;
                            }
                            if (snake_val.camp==camp&&(!snake_lock[snake_val.camp][snake_val.i_snake])){
                                friend_first=true;
                                break;
                            }
                            if (snake_val.camp!=camp&&(!snake_lock[snake_val.camp][snake_val.i_snake])){ // the first oppnent dis
                                op_dis = snake_val.val;
                                if (!next_first){
                                    cant_eat_next=true;
                                }
                                break;
                            }
                        }
                        // cant eat next flag
                        if (next_first&&!friend_first){
                            if (val+mdis>op_dis){cant_eat_next=true;}
                            // skip
                            choose=false;
                        }
                    }
                }
                // fprintf(stderr,"?\n");
                if (choose){
                    // fprintf(stderr,"%d %d\n",res.size(),q);
                    // fprintf(stderr,"%d %d\n",score_items.size(),i_item);
                    // fprintf(stderr,"campsnake:%d %d %d picks:%d\n",res[q],camp,i_snake,i_item);
                    snake_lock[camp][i_snake]=true;
                    if (camp==0){
                        exp_item_score+=score_items[i_item].param;
                    } else {
                        exp_item_score-=score_items[i_item].param;
                    }
                    break;
                }
                // fprintf(stderr,"?+1\n");
                q+=1;
            }
            // fprintf(stderr,"?+2\n");
        }
        // fprintf(stderr,"??\n");
        // exit(0);
        if (env.cur_side==1){
            exp_item_score*=-1.0;
        }
        // fprintf(stderr, "w:%lf\n", winner_value);
        winner_value+=(exp_item_score/SCORE_SHRINK);
        // fprintf(stderr, "v:%lf item:%lf\n", winner_value, exp_item_score);
        // clock_t end=clock();
        // fprintf(stderr,"%lf\n",double(end-start)/double(CLOCKS_PER_SEC));
        // print_board(0,0);
        // print_board(1,0);
        // exit(0);
        mcts_probvs.push_back(winner_value);
    }
};
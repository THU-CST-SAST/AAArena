#ifndef _UNITS_H
#define _UNITS_H

#include "my_math.h"

#define MAX_ROUND 512
#define BOARD_SIZE 16
#define ITEM_EXPIRE_TIME 16

using namespace std;

double spawn_config[9][5]={
    {.25, 6, 9, 5, 1},
    {.25, 5, 10, 5, 1},
    {.25, 4, 11, 5, 1},
    {.25, 3, 12, 5, 1},
    {.25, 3, 12, 5, 2},
    {.25, 2, 13, 5, 2},
    {.25, 1, 14, 5, 2},
    {.25, 0, 15, 5, 2},
    {.25, 0, 15, 4, 3}
};

int stage_anchor[10] = {1,21,41,61,65,81,101,121,385,512};
int item_cnt = 0;

class MyItem{
public:
    int id,x,y,time,type,param;
    MyItem(){}
    MyItem(int id, int x, int y, int time, int type, int param){
        this->id = id;
        this->x = x;
        this->y = y;
        this->time = time;
        this->type = type;
        this->param = param;
    }
};

inline void random_pos(int coormin, int coormax, int & x, int & y){
    x = randint(coormin,coormax+1);
    y = randint(coormin,coormax+1);
}

inline MyItem generate_one_item(int round, int stage, int coormin, int coormax, int item_map[BOARD_SIZE][BOARD_SIZE]){
    int x,y;
    random_pos(coormin, coormax, x,y);
    while (item_map[x][y]+ITEM_EXPIRE_TIME>=round){
        random_pos(coormin, coormax, x, y);
    }
    item_map[x][y]=round;
    vector<double> p_vec;
    p_vec.clear();
    double p0 = double(spawn_config[stage][3]);
    double p1 = double(spawn_config[stage][4]);
    double sum = p0+p1;
    p0/=sum;
    p_vec.push_back(p0);
    p1/=sum;
    p_vec.push_back(p1);
    int choose_item = random_sample(p_vec); //0-length, 1-melt, item_type should + 1
    item_cnt+=1;
    if (choose_item==0){
        return MyItem(item_cnt,x,y,round,choose_item+1,randint(1,6));
    }else{
        return MyItem(item_cnt,x,y,round,choose_item+1,0.0);}
}

inline void generate_items(vector<MyItem> & item_list){
    item_list.clear();
    int item_map[BOARD_SIZE][BOARD_SIZE];
    for (int i=0;i<BOARD_SIZE;i++) {
        for (int j=0;j<BOARD_SIZE;j++){
            item_map[i][j]=-1024;
        }
    }
    int current_round=1;
    double r;
    int coormin, coormax;
    for (int stage=0;stage<9;stage++){
        int start_round=stage_anchor[stage];
        int end_round=stage_anchor[stage+1]-1;
        coormin = spawn_config[stage][1];
        coormax = spawn_config[stage][2];
        while (current_round>=start_round&&current_round<=end_round){
            r = rand_01();
            if (r<=spawn_config[stage][0]){
                item_list.push_back(
                    generate_one_item(current_round, stage, coormin, coormax, item_map));
            }
            current_round+=1;
        }
    }
}

class Pos
{
public:
    int x,y;
    Pos(){x=0;y=0;}
    Pos(int px, int py){
        x = px;
        y = py;
    }
};

class MySnake{
public:
    vector<Pos> body;
    int length_bank=0;
    int melt=0;
    int camp;
    MySnake(){}
    MySnake(vector<Pos> body, int length_bank, int melt, int camp){
        this->body=body;
        this->length_bank=length_bank;
        this->melt=melt;
        this->camp=camp;
    }
    void add_item(int item_type, int item_param){
        if (item_type==1){
            length_bank+=item_param;
        }else{
            if (melt==0) {
                melt=1;
            }
        }
    }
};

#endif
#include "snakego_env.h"
#include "rapidjson/document.h"
#include "rapidjson/writer.h"

using namespace rapidjson;
using namespace std;

int get_direction_ind(Pos & p0, Pos & p1){
    if (p0.x<p1.x){
        return 0;
    } else if (p0.y<p1.y){
        return 1;
    } else if (p0.x>p1.x){
        return 2;
    } else {return 3;}
}

void env_to_nonarray_json(SnakeGoEnv& env, int sug_action, string str_file_name){
    Document d;d.SetObject();auto & allocator=d.GetAllocator();
    d.AddMember("sug_action",sug_action,allocator);
    d.AddMember("cur_round",env.cur_round,allocator);
    d.AddMember("cur_side",env.cur_side,allocator);
    d.AddMember("cur_snake",env.cur_snake,allocator);
    d.AddMember("item_ptr",env.item_ptr,allocator);
    d.AddMember("act_snake_nums_0",env.act_snake_nums[0],allocator);
    d.AddMember("act_snake_nums_1",env.act_snake_nums[1],allocator);
    d.AddMember("snake_nums_0",env.snake_nums[0],allocator);
    d.AddMember("snake_nums_1",env.snake_nums[1],allocator);
    Value all_snakes; all_snakes.SetArray();
    for (int camp=0;camp<2;camp++){
        Value snakes; snakes.SetArray();
        for (int i_snake=0;i_snake<env.snake_nums[camp];i_snake++){
            Value snake; snake.SetObject();
            Value body; body.SetArray();
            auto & env_snake = env.snakes[camp][i_snake];
            auto & env_body = env_snake.body;
            for (auto &p:env_body){
                body.PushBack(p.x,allocator);
                body.PushBack(p.y,allocator);
            }
            snake.AddMember("body", body, allocator);
            snake.AddMember("length_bank", env_snake.length_bank, allocator);
            snake.AddMember("melt", env_snake.melt, allocator);
            snakes.PushBack(snake, allocator);
        }
        all_snakes.PushBack(snakes, allocator);
    }
    d.AddMember("snakes", all_snakes, allocator);
    Value blocks; blocks.SetArray();
    Value item_map; item_map.SetArray();
    Value item_param_map; item_param_map.SetArray();
    Value item_time_map; item_time_map.SetArray();
    for (int x=0;x<BOARD_SIZE;x++){
        for (int y=0;y<BOARD_SIZE;y++){
            blocks.PushBack(env.blocks[x][y], allocator);
            item_map.PushBack(env.item_map[x][y], allocator);
            item_param_map.PushBack(env.item_param_map[x][y], allocator);
            item_time_map.PushBack(env.item_time_map[x][y], allocator);
        }
    }
    d.AddMember("blocks", blocks, allocator);
    d.AddMember("item_map", item_map, allocator);
    d.AddMember("item_param_map", item_param_map, allocator);
    d.AddMember("item_time_map", item_time_map, allocator);
    d.AddMember("end", env.end, allocator);
    Value ip; ip.SetArray();
    for (int i=0;i<4;i++){
        ip.PushBack(env.ip[i],allocator);
    }
    d.AddMember("ip", ip, allocator);
    Value item_list; item_list.SetArray();
    for (auto & item:env.item_list){
        item_list.PushBack(item.x,allocator);
        item_list.PushBack(item.y,allocator);
        item_list.PushBack(item.time,allocator);
        item_list.PushBack(item.type,allocator);
        item_list.PushBack(item.param,allocator);
    }
    d.AddMember("item_list", item_list, allocator);

    const char* file_name = str_file_name.c_str();
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    d.Accept(writer);
    FILE * p_file = fopen(file_name,"w");
    const char * str=buffer.GetString();
    fwrite(str,sizeof(char),strlen(str),p_file);
    fclose(p_file);
}

void env_to_json(vector<SnakeGoEnv> & envs,vector<int> sug_actions, string str_file_name){
    const char* file_name = str_file_name.c_str();
    Document d;
    // d.SetObject();
    d.SetArray();
    auto & allocator = d.GetAllocator();
    for (int i_env=0;i_env<1;i_env++){ 
        if (i_env>0){break;}
        // auto & env = envs[i_env];
        auto & env = envs[0];
        auto & sug_action = sug_actions[0];
        // cout<<"in env to json cur_round:"<<env.cur_round<<endl;
        Value env_info;
        env_info.SetObject();
        {
            Value img; img.SetArray();
            // set snake info
            for (int i_side=0; i_side<2; i_side++){ // i_side==1:cur_side
                int camp = i_side==0?env.cur_side:1-env.cur_side;
                int camp_layer_shift = i_side * 20;
                for (int i_snake=0; i_snake<env.snake_nums[camp]; i_snake++){
                    auto & snake=env.snakes[camp][i_snake];
                    auto & body = snake.body;
                    int layer = camp_layer_shift + i_snake*5;
                    auto & head = body[0];
                    auto & tail = body.back();
                    img.PushBack(head.x,allocator);
                    img.PushBack(head.y,allocator);
                    img.PushBack(layer,allocator);
                    img.PushBack((snake.melt>0)?1.5:1.0,allocator);
                    if (snake.length_bank!=0){
                        img.PushBack(tail.x,allocator);
                        img.PushBack(tail.y,allocator);
                        img.PushBack(layer+1,allocator);
                        img.PushBack(-float(snake.length_bank)/5.0,allocator);
                    }
                    // active snake
                    if (env.cur_side==camp&&env.cur_snake==i_snake){
                        img.PushBack(tail.x,allocator);
                        img.PushBack(tail.y,allocator);
                        img.PushBack(layer+2,allocator);
                        img.PushBack(-1.0,allocator);
                    }
                    int len_body=int(body.size());
                    int know=0; int knext=1;
                    int direction_ind;
                    while (knext<len_body){
                        auto & pnow = body[know];
                        auto & pnext = body[knext];
                        direction_ind = get_direction_ind(pnow, pnext);
                        img.PushBack(pnow.x,allocator);
                        img.PushBack(pnow.y,allocator);
                        img.PushBack(layer+1+direction_ind,allocator);
                        img.PushBack(1.0,allocator);
                        know+=1;
                        knext+=1;
                    }
                }
            }
            // set item info
            bool first_item_taken[BOARD_SIZE][BOARD_SIZE];
            bool second_item_taken[BOARD_SIZE][BOARD_SIZE];
            for (int i=0;i<BOARD_SIZE;i++){
                for (int j=0;j<BOARD_SIZE;j++){
                    first_item_taken[i][j]=false;
                    second_item_taken[i][j]=false;
                }
            }
            int item_layer_shift=40;
            int layer;
            auto & item_map=env.item_map;
            //from board, now existing item
            for (int i=0;i<BOARD_SIZE;i++){
                for (int j=0;j<BOARD_SIZE;j++){
                    if (item_map[i][j]==0) {continue;}
                    if (first_item_taken[i][j]&&second_item_taken[i][j]) {continue;}
                    int param = env.item_param_map[i][j];
                    int due_time = env.item_time_map[i][j];
                    if (!first_item_taken[i][j]){
                        first_item_taken[i][j]=true;
                        layer = item_layer_shift;
                    } else{
                        second_item_taken[i][j]=true;
                        layer = item_layer_shift+4;
                    }
                    // cout<<i<<","<<j<<","<<layer<<","<<due_time<<endl;
                    img.PushBack(i, allocator);
                    img.PushBack(j, allocator);
                    img.PushBack(layer, allocator);
                    img.PushBack(float(due_time-16)/512.0, allocator);
                    img.PushBack(i, allocator);
                    img.PushBack(j, allocator);
                    img.PushBack(layer+((item_map[i][j]==1)?1:2), allocator);
                    img.PushBack(1.0, allocator);
                    img.PushBack(i, allocator);
                    img.PushBack(j, allocator);
                    img.PushBack(layer+3, allocator);
                    img.PushBack(float(env.item_param_map[i][j])/5.0, allocator);
                }
            }
            // from list, anticipate items.
            auto & item_list = env.item_list;
            int cur_round = env.cur_round;
            // bool first=false;
            for (auto & item:item_list){
                // if (!first) {first=true; cout<<"check first:"<<item.time<<" "<<cur_round<<endl;
                //     cout<<item.x<<","<<item.y<<endl;
                // }
                if (item.time<cur_round) {continue;}
                float emer_time = float(item.time-cur_round+1)/512.0;
                int & x = item.x;
                int & y = item.y;
                if (first_item_taken[x][y]&&second_item_taken[x][y]) {continue;}
                if (!first_item_taken[x][y]){
                    first_item_taken[x][y]=true;
                    layer = item_layer_shift;
                } else{
                    second_item_taken[x][y]=true;
                    layer = item_layer_shift+4;
                }
                // cout<<x<<","<<y<<","<<layer<<","<<emer_time<<endl;
                img.PushBack(x, allocator);
                img.PushBack(y, allocator);
                img.PushBack(layer, allocator);
                img.PushBack(emer_time, allocator);
                img.PushBack(x, allocator);
                img.PushBack(y, allocator);
                img.PushBack(layer+((item.type==1)?1:2), allocator);
                img.PushBack(1.0, allocator);
                img.PushBack(x, allocator);
                img.PushBack(y, allocator);
                img.PushBack(layer+3, allocator);
                img.PushBack(float(item.param)/5.0, allocator);
            }
            // total 48 layers, 0-47
            // output blocks.. write.. and seems like 48 layer is not right? check it tomorrow
            int cur_block = (env.cur_side==0)?1:-1;
            auto & blocks = env.blocks;
            int block_layer;
            for (int i=0;i<BOARD_SIZE;i++){
                for (int j=0;j<BOARD_SIZE;j++){
                    if (blocks[i][j]==0){continue;}
                    if (blocks[i][j]==cur_block) {block_layer=48;}
                    else {block_layer=49;}
                    img.PushBack(i, allocator);
                    img.PushBack(j, allocator);
                    img.PushBack(block_layer, allocator);
                    img.PushBack(1.0, allocator);
                }
            }
            Value global; global.SetArray();
            global.PushBack(float(env.cur_round)/512.0,allocator);
            global.PushBack(sug_action, allocator);
            for (int j=0;j<4;j++){global.PushBack(0,allocator);}
            env_info.AddMember("img", img , allocator);
            env_info.AddMember("global", global, allocator);
        }
        d.PushBack(env_info,allocator);
    }

    // write to file
    StringBuffer buffer;
    Writer<StringBuffer> writer(buffer);
    d.Accept(writer);
    FILE * p_file = fopen(file_name,"w");
    const char * str=buffer.GetString();
    fwrite(str,sizeof(char),strlen(str),p_file);
    fclose(p_file);
}
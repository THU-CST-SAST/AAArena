#include "snakego_env.h"
#include "cmcts.h"

SnakeGoEnv env;
CMCTS cmcts;
ActPair act_pairs;
vector<int> sug_actions;

using namespace std;

int main(){
    string file_name = "save_envs/62-187-10-47-9-1-0.json";
    // string file_name = "save_envs/66-247-30-174-17-1-0.json";
    env.load_from_json(file_name);
    cmcts.get_action(sug_actions, act_pairs, env, 1);
    double tmp;
    // cout<<env.get_winner_value(tmp)<<endl;
    for (auto &a:sug_actions){
        cout<<a<<" ";
    }
    cout<<endl;
    return 0;
}
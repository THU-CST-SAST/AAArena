#include "snakego_env.h"
#include "cmcts.h"

int main(){
    ActPair ap;
    SnakeGoEnv env;
    CMCTS cmcts;
    cmcts.get_action(ap, env);
    return 0;
}
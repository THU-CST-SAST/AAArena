#include "adk.hpp"
#include "snakego_env.h"
#include "cmcts.h"
#include "env_serializer.h"
#include <cmath>
#include <sstream>

#define SKIP_LAYER_NUM 1

void translate_env(SnakeGoEnv& env, const Snake& snake_to_operate, const Context& ctx){
	// fprintf( stderr, "%d", ctx.current_round());
	env.cur_round = ctx.current_round();
	// read item
	auto & item_list = ctx.item_list();
	env.item_list.clear();
	MyItem my_item;
	for (auto & item:item_list){
		my_item.id = item.id;
		my_item.x = item.x;
		my_item.y = item.y;
		my_item.time = item.time;
		// offl env type = 0 or 2
		// my env type = 1 or 2
		my_item.type = (item.type==2)?2:1;
		my_item.param = (item.type==2)?0:item.param;
		env.item_list.push_back(my_item);
	}
	int len_item = int(env.item_list.size());
	int item_ptr=0;
	while (env.item_list[item_ptr].time<env.cur_round&&item_ptr<len_item){
		item_ptr+=1;
	}
	// read snakes
	env.cur_side = ctx.current_player();
	int my_side = env.cur_side;
	int op_side = 1-env.cur_side;
	auto raw_my_snakes = ctx.my_snakes();
	int cur_snake = -1;
	int cur_snake_id = ctx._current_snake_id;
	for (int i_snake=0;i_snake<raw_my_snakes.size();i_snake++){
		auto & raw_snake=raw_my_snakes[i_snake];
		if (raw_snake.id==cur_snake_id){
			cur_snake=i_snake;
			break;
		}
	}
	env.cur_snake = cur_snake;
	env.snakes[0].clear();
	env.snakes[1].clear();
	//my snakes
	for (auto & raw_snake: raw_my_snakes){
		vector<Pos> body;
		MySnake snake;
		body.clear();
		for  (auto & coord:raw_snake.coord_list){
			body.push_back(Pos(coord.x,coord.y));
		}
		snake.body=body;
		snake.length_bank = raw_snake.length_bank;
		snake.melt = (int(raw_snake.railgun_item.id)==-1)?0:1;
		env.snakes[my_side].push_back(snake);
	}
	// op snakes
	auto raw_op_snakes = ctx.opponents_snakes();
	for (auto & raw_snake: raw_op_snakes){
		vector<Pos> body;
		MySnake snake;
		body.clear();
		for  (auto & coord:raw_snake.coord_list){
			body.push_back(Pos(coord.x,coord.y));
		}
		snake.body=body;
		snake.length_bank = raw_snake.length_bank;
		snake.melt = (int(raw_snake.railgun_item.id)==-1)?0:1;
		env.snakes[op_side].push_back(snake);
	}
	// read blocks
	auto wall_map = ctx.wall_map();
	for (int x=0; x<BOARD_SIZE; x++){
		for (int y=0;y<BOARD_SIZE;y++){
			if (wall_map[x][y]==-1){
				env.blocks[x][y]=0;
			}
			else if (wall_map[x][y]==0){
				env.blocks[x][y]=1;
			}
			else if (wall_map[x][y]==1){
				env.blocks[x][y]=-1;
			}
		}
	}
	// read item on map
	auto item_map = ctx.item_map();
	for (int x=0; x<BOARD_SIZE; x++){
		for (int y=0;y<BOARD_SIZE;y++){
			int item_id = item_map[x][y];
			if (item_id!=-1){
				auto item=ctx.find_item(item_id);
				env.item_map[x][y]=(item.type==0)?1:2; // item.type 1,2; env.item_map 1,2;
				env.item_param_map[x][y]=(item.type==0)?item.param:0;
				env.item_time_map[x][y] = (item.time - env.cur_round)+16;
			} else {
				env.item_map[x][y]=0; // item.type 1,2; env.item_map 1,2;
				env.item_param_map[x][y]=0;
				env.item_time_map[x][y]=0;
			}
		}
	}
	for (int i=0;i<2;i++){
		env.snake_nums[i] = int(env.snakes[i].size());
		env.act_snake_nums[i] = int(env.snakes[i].size());
	}
	env.end=false;
}

void save_env(SnakeGoEnv& env, int sug_action, int act_num){
	ostringstream oss;	oss.str("");
	oss<<"save_envs/";
	for (auto & x:env.ip){oss<<x<<"-";}
	oss<<env.cur_round<<"-"<<env.cur_side<<"-"<<act_num<<".json";
    string s_file_name = oss.str();
	env_to_nonarray_json(env, sug_action, s_file_name);
}

SnakeGoEnv env;
CMCTS cmcts;
ActPair act_pairs;
vector<int> sug_actions;
int global_cur_round = -1;
int act_num = 0;
Operation ops[6]={OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN, OP_SPLIT, OP_RAILGUN};
// watch direction at py_vis should be: right, down, left, up

Operation make_your_decision(const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_list )
{
	clock_t start = clock();
	translate_env(env, snake_to_operate, ctx);
	if (env.cur_round!=global_cur_round){
		global_cur_round = env.cur_round;
		act_num = 0;
	} else{
		act_num+=1;
	}
	if (act_num==0){
		cmcts.get_action(sug_actions, act_pairs, env, SKIP_LAYER_NUM);
	}
	clock_t end=clock();
	auto & sug_action = sug_actions[act_num];
	// fprintf(stderr,"%d\n",sug_action);
	// save_env(env, sug_action, act_num);
	return ops[sug_action];
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char** argv ) { SnakeGoAI start( argc, argv ); }
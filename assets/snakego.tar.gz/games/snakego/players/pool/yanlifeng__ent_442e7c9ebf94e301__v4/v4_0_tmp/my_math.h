#ifndef _MY_MATH_H
#define _MY_MATH_H

#include <vector>
#include <random>
#include <chrono>

using namespace std;

inline bool double_eq(double a, double b){
    double eps = 1e-8;
    return a>b-eps && a<b+eps;
}

double rand_01(){
    std::mt19937_64 rng;
    uint64_t timeSeed = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    std::seed_seq ss{uint32_t(timeSeed & 0xffffffff), uint32_t(timeSeed>>32)};
    rng.seed(ss);
    std::uniform_real_distribution<double> unif(0, 1);
    double currentRandomNumber = unif(rng);
    return currentRandomNumber;
}

int randint(int lb, int rb){
    //writing
    double r=rand_01();
    return int(double(rb-lb)*r+double(lb));
}

void norm_vec(vector<double> & vec){
    double sum=0.0;
    for (auto & v:vec){sum+=v;}
    for (auto & v:vec){v/=sum;}
}

int random_sample(vector<double>  distribution)
{
    double sum = 0.0;
    int size = distribution.size();
    for (int i=0; i<size; i++){
        sum += distribution[i];
    }
    if (double_eq(sum,1.0)) {
        double rnum = rand_01();
        for (int i=0; i<size; i++){
            if (rnum < distribution[i]) return i;
            else{
                rnum -= distribution[i];
            }
        }
    }else return -1;
    return -1;
}

int random_sample_with_mask(vector<double> distribution, bool mask[]){
    return -1;
}

#endif
#include "adk.hpp"
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#define rep(i, a, b) for (int i = (a); i <= (b); i ++)
#define per(i, a, b) for (int i = (a); i >= (b); i --)
#define REP(i, n) for (int i = 0; i < (n);i ++)
#define SZ(x) ((int)(x).size())
using namespace std;

const int N = 16, M = 512;
const int dx[4] = {0, 1, 0, -1};
const int dy[4] = {1, 0, -1, 0};
const double limit = 0.15;
const double damping = 1.0;
const double smooth = 2.0;

//当前的蛇 / 起始操作 / 时间 / 坐标 x / 坐标 y / 朝向
double dp[4][4][M][N][N][4];
double p[M][N][N], q[M][N][N][4];
int ban[4][4];

void cmax(double &a, double b) {
	a = (b > a ? b : a);
}

int valid(const Context &e, int x, int y) {
	return 0 <= x && x < N && 0 <= y && y < N && e.wall_map()[x][y] == -1;
}

Operation encode(int dir) {
	if (dir == 0) return OP_RIGHT;
	if (dir == 1) return OP_DOWN;
	if (dir == 2) return OP_LEFT;
	return OP_UP;
}

int getdir(int x, int y) {
	REP (k, 4) {
		if (x == dx[k] && y == dy[k]) {
			return k;
		}
	}
	return 0;
}

void add(int x, int y, int l, int r, double val) {
	p[l][x][y] += val;
	if (r + 1 < M) {
		p[r + 1][x][y] -= val;
	}
}

void push(const Context &e, const Snake &cur) {
	memset(q, 0, sizeof q);
	int d = (cur.length() == 1 ? 0 : getdir(cur[0].x - cur[1].x, cur[0].y - cur[1].y));
	q[0][cur[0].x][cur[0].y][d] = 1;
	rep (t, 1, M - 1) REP (i, N) REP (j, N) REP (k, 4) {
		double val = q[t - 1][i][j][k];
		if (val) {
			add(i, j, t - 1, t + cur.length() - 2, val);
			double sum = 0;
			rep (l, -1, 1) {
				int d = (k + 4 + l) % 4;
				int nx = i + dx[d], ny = j + dy[d];
				if (valid(e, nx, ny)) {
					sum += (l == 0 ? smooth : 1);
				}
			}
			if (sum) {
				val /= sum;
				rep (l, -1, 1) {
					int d = (k + 4 + l) % 4;
					int nx = i + dx[d], ny = j + dy[d];
					if (valid(e, nx, ny)) {
						q[t][nx][ny][d] += val * (l == 0 ? smooth : 1);
					}
				}
			}
		}
	}
	rep (i, 1, cur.length() - 1) {
		add(cur[i].x, cur[i].y, 0, cur.length() - 1 - i, 1);
	}
}

int DP(const Context &e, const Snake &cur, int d, double dp[M][N][N][4]) {
	int nx = cur[0].x + dx[d];
	int ny = cur[0].y + dy[d];
	if (cur.length() >= 2 && nx == cur[1].x && ny == cur[1].y) {
		if (cur.length() + cur.length_bank >= 3) {
			return 1;
		}
	}
	if (!valid(e, nx, ny)) {
		return 1;
	}
	if (e.snake_map()[nx][ny] != -1 && e.snake_map()[nx][ny] != cur.id) {
		return 1;
	}
	memset(p, 0, sizeof p);
	for (auto i : e.my_snakes()) {
		if (i != cur) {
			push(e, i);
		}
	}
	for (auto i : e.opponents_snakes()) {
		push(e, i);
	}
	rep (t, 1, M - 1) REP (i, N) REP (j, N) {
		p[t][i][j] += p[t - 1][i][j];
	}
	REP (t, M) REP (i, N) REP (j, N) {
		p[t][i][j] = 1 - pow(min(p[t][i][j], 1.0), damping * t);
	}
	dp[0][nx][ny][d] = 1;
	rep (t, 1, M - 1) REP (i, N) REP (j, N) REP (k, 4) {
		double val = dp[t - 1][i][j][k];
		if (val) {
			rep (l, -1, 1) {
				int d = (k + 4 + l) % 4;
				int nx = i + dx[d], ny = j + dy[d];
				if (valid(e, nx, ny)) {
					cmax(dp[t][nx][ny][d], val * p[t][nx][ny]);
				}
			}
		}
	}
	REP (t, M) REP (i, N) REP (j, N) rep (k, 1, 3) {
		cmax(dp[t][i][j][0], dp[t][i][j][k]);
	}
	return 0;
}

map <int, int> selected;
int T = -1;

struct Info {
	Item it;
	int tim[4], fir[4], mn, cur;
	Info (Item _it) {
		it = _it;
		fill(tim, tim + 4, M);
		fill(fir, fir + 4, 0);
	}
	void upd() {
		mn = M;
		REP (k, 4) {
			if (tim[k] < mn) {
				mn = tim[k];
				cur = k;
			}
		}
	}
};

Operation make_your_decision(const Snake& s, const Context& e, const OpHistory& history) {
	if (e.current_round() != T) {
		selected.clear();
		T = e.current_round();
	}
	int fi = 0, la = SZ(e.my_snakes()) - 1;
	for (; e.my_snakes()[fi] != s; fi ++);
	memset(dp, 0, sizeof dp);
	rep (i, fi, la) REP(d, 4) {
		ban[i][d] = DP(e, e.my_snakes()[i], d, dp[i][d]);
	}
	vector<Info> rem;
	for (auto it : e.item_list()) {
		int flag = 0;
		Info tmp(it);
		rep (i, fi, la) {
			int l = max(0, it.time - T - ((int)(e.my_snakes()[i].length()) - 1));
			int r = min(M, it.time - T + 15);
			rep (j, l, r) {
				double mx = 0;
				int fir = 0;
				REP (k, 4) {
					if (dp[i][k][j][it.x][it.y][0] > mx) {
						mx = dp[i][k][j][it.x][it.y][0];
						fir = k;
					}
				}
				if (mx > 1 - limit) {
					tmp.tim[i] = j;
					tmp.fir[i] = fir;
					flag = 1;
					break;
				}
			}
		}
		if (flag) {
			tmp.upd();
			rem.push_back(tmp);
		}
	}
	map <int, int> vis;
	for ( ; !rem.empty(); ) {
		sort(rem.begin(), rem.end(), [&](Info a, Info b){
			return a.mn > b.mn || a.mn == b.mn && a.cur > b.cur;
		});
		Info tmp = rem.back();
		rem.pop_back();
		if (vis[tmp.cur]) {
			tmp.tim[tmp.cur] = M;
			tmp.upd();
			if (tmp.mn < M) {
				rem.push_back(tmp);
			}
			continue;
		}
		vis[tmp.cur] = 1;
		if (tmp.cur == fi) {
			return encode(tmp.fir[fi]);
		}
	}
	if (SZ(e.my_snakes()) < 4) {
		return OP_SPLIT;
	}
	vector <int> choice;
	REP (k, 4) if (!ban[fi][k]) {
		choice.push_back(k);
	}
	if (choice.empty()) {
		if (s.railgun_item.id >= 0) {
			return OP_RAILGUN;
		}
		return OP_RIGHT;
	}
	return encode(choice[rand() % SZ(choice)]);
}

void game_over(int gameover_type, int winner, int p0_score, int p1_score) {
	fprintf(stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score);
}

int main(int argc, char** argv) {
	SnakeGoAI start(argc, argv);
}
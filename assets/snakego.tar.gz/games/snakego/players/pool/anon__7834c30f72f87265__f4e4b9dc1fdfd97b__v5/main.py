from adk import *
import ai

c = Client()
# game config
(length, width, max_round, player) = c.fetch_data()
config = GameConfig(width=width, length=length, max_round=max_round)
ctx = Context(config=config)
current_player = 0

logging.info('Assigned player %d', player)
item_list = c.fetch_data()
ctx.game_map = Map(item_list, config=config)
controller = Controller(ctx)
playing = True
while playing:
    if controller.ctx.turn > max_round:
        res = c.fetch_data()
        sys.stderr.write(str(res[1:]))
        break
    if current_player == 0:
        controller.round_preprocess()
    controller.round_init()
    if player == current_player:  # Your Turn
        while controller.next_snake != -1:
            current_snake = controller.current_snake_list[controller.next_snake][0]
            op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
            logging.debug(str(op))
            if not controller.apply(op):
                raise RuntimeError("Illegal Action!!! " + str(op))
            c.send_data(op)
            res = c.fetch_data()
            if res[0] == -1:
                playing = False
                sys.stderr.write(str(res[1:]))
                break
        controller.next_player()
    else:
        while True:
            if controller.next_snake == -1:
                controller.next_player()
                break
            op = c.fetch_data()
            if op[0] == -1:
                playing = False
                sys.stderr.write(str(op[1:]))
                break
            controller.apply(op[0])
    current_player = 1 - current_player
while True:
    pass

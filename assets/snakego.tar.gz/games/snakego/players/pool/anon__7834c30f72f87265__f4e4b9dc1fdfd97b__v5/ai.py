from adk import *


XPLUS = 1
XMINUS = 3
YPLUS = 2
YMINUS = 4
RAY = 5
SPLIT = 6


def judge(snake, ctx):
    return XPLUS



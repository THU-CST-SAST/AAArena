import logging
import math
import random
import sys
import copy

from adk import Item, Snake, Map, Context, GameConfig, Controller, Graph, ITEM_EXPIRE_TIME
import adk as adk

sys.setrecursionlimit(3000)

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
round_count = 0
width = 0
height = 0
action = {}  # 0: None, 1: eat 2: solidify 3: kill
item_used = {}
lastdir = 0
warning = []
moves = []
controller = None
disable = [0, 0, 0, 0]

def DEBUG(msg):
    pass
    # sys.stderr.write(msg + '\n')
    # sys.stderr.flush()


def _DEBUG(msg):
    pass
    # sys.stderr.write(msg + '\n')
    # sys.stderr.flush()


def __DEBUG(msg):
    pass
    # sys.stderr.write(msg + '\n')
    # sys.stderr.flush()


def convert_dir(u, v):
    x = u[0] - v[0]
    y = u[1] - v[1]
    if x == 1:
        return 2
    if x == -1:
        return 0
    if y == 1:
        return 3
    if y == -1:
        return 1


def judge(snake, ctx, cnt):
    def check(op, flag=False):
        _DEBUG("check: " + str(op))
        if op == -1:
            return False
        if disable[op] == 1:
            return False
        x = snake.coor_list[0][0] + dx[op]
        y = snake.coor_list[0][1] + dy[op]
        _DEBUG(str(x) + ' ' + str(y))
        if x < 0 or y < 0 or x >= width or y >= height or ctx.game_map.wall_map[x][y] != -1:
            return False
        if (snake.get_len() > 2 or (snake.get_len() == 2 and snake.length_bank > 0)) and x == snake.coor_list[1][0] and y == snake.coor_list[1][1]:
            return False
        if ctx.game_map.snake_map[x][y] != -1:
            if (not flag) and ctx.game_map.snake_map[x][y] == snake.id and (snake.length_bank > 0 or x != snake.coor_list[-1][0] or y != snake.coor_list[-1][1]) and (snake.id not in action or action[snake.id][0] != 2 or (action[snake.id][0] == 2 and len(action[snake.id][1]) > 1)):
                return False
            if ctx.game_map.snake_map[x][y] != snake.id:
                return False
        return True

    def other_check(snake, op):
        _DEBUG("check: " + str(op))
        if op == -1:
            return False
        x = snake.coor_list[0][0] + dx[op]
        y = snake.coor_list[0][1] + dy[op]
        _DEBUG(str(x) + ' ' + str(y))
        if x < 0 or y < 0 or x >= width or y >= height or ctx.game_map.wall_map[x][y] != -1:
            return False
        if (snake.get_len() > 2 or (snake.get_len() == 2 and snake.length_bank > 0)) and x == snake.coor_list[1][0] and y == snake.coor_list[1][1]:
            return False
        if ctx.game_map.snake_map[x][y] != -1:
            if ctx.game_map.snake_map[x][y] == snake.id and snake.length_bank == 0 and x == snake.coor_list[-1][0] and y == snake.coor_list[-1][1]:
                return True
            return False
        return True

    def move_assess(dir, el=0):
        class dfs:
            def __init__(self, coors, used, lb):
                self.coors = coors
                self.used = used
                self.lb = lb

            def calc(self, x, y, cnt):
                if cnt == 8:
                    return 1
                ans = 0
                for i in range(4):
                    xx, yy = x + dx[i], y + dy[i]
                    if xx < 0 or yy < 0 or xx >= width or yy >= height or ctx.game_map.wall_map[xx][yy] != -1:
                        continue
                    if self.used[xx][yy] != -1 and (self.lb > 0 or xx != self.coors[-1][0] or yy != self.coors[-1][1]):
                        continue
                    flag = 0
                    tmp = (0, 0)
                    if self.lb > 0:
                        self.lb -= 1
                        flag = 1
                        self.coors = [(xx, yy)] + self.coors
                    else:
                        self.used[self.coors[-1][0]][self.coors[-1][1]] = -1
                        tmp = self.coors[-1]
                        self.coors = [(xx, yy)] + self.coors[:-1]
                    self.used[xx][yy] = snake.id
                    ans += self.calc(xx, yy, cnt + 1)
                    self.used[xx][yy] = -1
                    if flag == 1:
                        self.lb += 1
                        self.coors = self.coors[1:]
                    else:
                        self.coors = self.coors[1:] + [tmp]
                        self.used[tmp[0]][tmp[1]] = snake.id

                return ans
        __DEBUG("move assess " + str(dir))
        coors = copy.deepcopy(snake.coor_list)
        lb = snake.length_bank
        used = copy.deepcopy(ctx.game_map.snake_map)
        x, y = snake.coor_list[0]
        for d in dir:
            if not check(d):
                return 0
            x, y = x + dx[d], y + dy[d]
            if lb > 0:
                lb -= 1
                coors = [(x, y)] + coors
            else:
                used[coors[-1][0]][coors[-1][1]] = -1
                coors = [(x, y)] + coors[:-1]
            used[x][y] = snake.id
        Dfs = dfs(coors, used, lb + el)
        chance = Dfs.calc(x, y, 0)
        __DEBUG(str(chance))
        return chance

    def wall_check(l, d, param):
        x, y = snake.coor_list[0]
        path = []
        tot = 0
        for t in range(4):
            for i in range(l - 1):
                x = x + dx[d]
                y = y + dy[d]
                tot += 1
                if x < 0 or y < 0 or x >= width or y >= height or ctx.game_map.wall_map[x][y] != -1:
                    return [-1]
                if snake.get_len() > 1 and x == snake.coor_list[1][0] and y == snake.coor_list[1][1]:
                    return [-1]
                if ctx.game_map.snake_map[x][y] != -1 and ctx.get_snake(ctx.game_map.snake_map[x][y]).camp != snake.camp:
                    return [-1]
                if ctx.game_map.snake_map[x][y] != -1 and (x != snake.coor_list[0][0] or y != snake.coor_list[0][1]):
                    extra = 0
                    snk = ctx.get_snake(ctx.game_map.snake_map[x][y])
                    for _ in range(0, len(ctx.snake_list)):
                        if ctx.snake_list[_].id == snake.id:
                            for __ in range(_ + 1, len(ctx.snake_list)):
                                if ctx.snake_list[__].id == snk.id:
                                    extra = 1
                                    break
                            break
                    for idx in range(1, snk.get_len() + 1):
                        if snk.coor_list[snk.get_len() - idx][0] == x and snk.coor_list[snk.get_len() - idx][1] == y:
                            if idx + snk.length_bank + extra > tot:
                                return [-1]
            path.extend([d] * (l - 1))
            d = (d + param + 4) % 4
        if not path:
            path = [-1]
        return path

    def search(u, v):
        u = (u[0], u[1])
        v = (v[0], v[1])
        open_list = [u]
        close_list = []
        dis = {}
        father = {}
        dis[u] = 0
        father[u] = -1
        while len(open_list) > 0:
            current = open_list.pop(0)
            if current == v:
                break
            close_list.append(current)
            for dir in range(4):
                x, y = (current[0] + dx[dir], current[1] + dy[dir])
                if x < 0 or y < 0 or x >= width or y >= height or ctx.game_map.wall_map[x][y] != -1 or ctx.game_map.snake_map[x][y] != -1:
                    continue
                if (x, y) in close_list:
                    continue
                if (x, y) in open_list:
                    if dis[(x, y)] > dis[current] + 1:
                        dis[(x, y)] = dis[current] + 1
                        father[(x, y)] = dir
                else:
                    open_list.append((x, y))
                    dis[(x, y)] = dis[current] + 1
                    father[(x, y)] = dir
        if v == (-1, -1):
            return dis, father
        if v in dis:
            path = []
            tmp = v
            while tmp != u:
                path.insert(0, father[tmp])
                tmp = (tmp[0] - dx[father[tmp]], tmp[1] - dy[father[tmp]])
            return dis[v], path
        else:
            return width * height + 1, [-1]

    global disable
    disable = [0, 0, 0, 0]
    if snake.id not in action:
        action[snake.id] = [0]
    _DEBUG(str(width) + ' ' + str(height))
    __DEBUG("Snake" + str(snake.id))
    __DEBUG("Status " + str(action[snake.id]))
    # Kill Begin
    _DEBUG("Kill Begin.")
    kd = -1
    for killdir in range(4):
        if not check(killdir):
            continue
        x = snake.coor_list[0][0] + dx[killdir]
        y = snake.coor_list[0][1] + dy[killdir]
        for d in range(4):
            xx = x + dx[d]
            yy = y + dy[d]
            if xx < 0 or yy < 0 or xx >= width or yy >= height or ctx.game_map.wall_map[xx][yy] != -1:
                continue
            if ctx.game_map.snake_map[xx][yy] == -1:
                continue
            target = ctx.get_snake(ctx.game_map.snake_map[xx][yy])
            cnt = 0
            for dir in range(4):
                if not other_check(target, dir):
                    cnt += 1
            if cnt == 4:
                if target.camp == snake.camp:
                    disable[killdir] = 1
                else:
                    return killdir + 1

    for killdir in range(4):
        if not check(killdir):
            continue
        sss = copy.deepcopy(snake)
        x = snake.coor_list[0][0] + dx[killdir]
        y = snake.coor_list[0][1] + dy[killdir]
        tmmp = (-1, -1)
        if sss.length_bank > 0:
            sss.coor_list = [(x, y)] + sss.coor_list
            sss.length_bank -= 1
        else:
            sss.coor_list = [(x, y)] + sss.coor_list[:-1]
        for d in range(4):
            xx = x + dx[d]
            yy = y + dy[d]
            if xx < 0 or yy < 0 or xx >= width or yy >= height or ctx.game_map.wall_map[xx][yy] != -1:
                continue
            for dd in range(4):
                xxx = xx + dx[dd]
                yyy = yy + dy[dd]
                if xxx < 0 or yyy < 0 or xxx >= width or yyy >= height or ctx.game_map.wall_map[xxx][yyy] != -1:
                    continue
                if ctx.game_map.snake_map[xxx][yyy] == -1:
                    continue
                target = ctx.get_snake(ctx.game_map.snake_map[xxx][yyy])
                if target.camp == snake.camp:
                    continue
                cnt = 0
                for dir in range(4):
                    if not other_check(sss, dir):
                        cnt += 1
                if cnt == 3:
                    disable[killdir] = 1
    _DEBUG("Kill End.")
    # Kill End

    # Fire Begin

    _DEBUG("Fire Begin.")
    for item in snake.item_list:
        if item.type == 2:
            if snake.get_len() > 1:
                x1, y1 = snake.coor_list[0]
                x2, y2 = snake.coor_list[1]
                _dx, _dy = x1 - x2, y1 - y2
                res = 0
                while width > x1 + _dx >= 0 and height > y1 + _dy >= 0:
                    x1 = x1 + _dx
                    y1 = y1 + _dy
                    if ctx.game_map.wall_map[x1][y1] == snake.camp:
                        res -= 1
                    elif ctx.game_map.wall_map[x1][y1] == 1 - snake.camp:
                        res += 1
                if res >= 1:
                    return 5
    _DEBUG("Fire End.")

    # Fire End

    # Unsolved Action
    _DEBUG("Unsolved Action Begin.")

    if action[snake.id][0] != 0:

        # Action1: Get Item

        if action[snake.id][0] == 1:
            item = ctx.game_map.get_map_item(action[snake.id][1])
            if item is None:
                action[snake.id] = [0]
            else:
                dis = search(snake.coor_list[0], [item.x, item.y])
                if dis[0] > action[snake.id][2] + 8 or dis[1] == []:
                    item_used[item.id] = 0
                    action[snake.id] = [0]
                else:
                    op = [1, dis[1][0]]
                    if check(op[1]) and move_assess(dis[1], item.param if item.type == 0 else 0) > 1:
                        if dis[0] == 1:
                            action[snake.id] = [0]
                        else:
                            action[snake.id] = [1, item.id, dis[0] - 1]
                        return op[1] + 1
                    else:
                        item_used[item.id] = 0
                        action[snake.id] = [0]

        # Action1 End

        # Action2: Solidify

        elif action[snake.id][0] == 2:
            (x, y) = snake.coor_list[0]
            _path = []
            for dir in action[snake.id][1]:
                (x, y) = (x + dx[dir], y + dy[dir])
                if ctx.game_map.snake_map[x][y] != -1 and ctx.game_map.snake_map[x][y] != snake.id:
                    break
                if ctx.game_map.wall_map[x][y] != -1:
                    break
                _path.append(dir)
            if len(_path) == 0:
                action[snake.id] = [0]
            else:
                op = [1, _path[0]]
                if check(op[1]):
                    if len(_path) == 1:
                        (x, y) = snake.coor_list[0]
                        if x + dx[op[1]] == snake.coor_list[-1][0] and y + dy[op[1]] == snake.coor_list[-1][1]:
                            action[snake.id] = [2, [convert_dir(snake.coor_list[-1], snake.coor_list[-2])]]
                        else:
                            action[snake.id] = [0]
                    else:
                        action[snake.id] = [2, _path[1:]]
                    return op[1] + 1
                else:
                    action[snake.id] = [0]

        # Action2 End

        # Action3: Block
        elif action[snake.id][0] == 3:
            pass

        # Action3 End
    _DEBUG("Unsolved Action End.")

    # Unsolved Action End

    # Get Item Begin

    _DEBUG("Get Item Begin.")
    ops = []
    min_dis = []
    paths = []
    target = -1
    flag1 = 0
    flag2 = 0
    for item in snake.item_list:
        if item.type == 1:
            flag1 = 1
        else:
            flag2 = 1
    if snake.get_len() > 16 and ctx.get_snake_count(snake.camp) < 4 and ctx.get_snake_count(1 - snake.camp) > 0:
        chance = [1]
        if ctx.turn <= ctx.max_round // 4:
            chance.extend([0])
        else:
            if snake.get_len() > 24:
                chance.extend([0, 0, 0])
            else:
                chance.extend([0, 0, 0, 0, 0, 0, 0, 0, 0])
        _ = chance[random.randint(0, len(chance) - 1)]
        if _ == 1:
            return 6
    dist, father = search(snake.coor_list[0], [-1, -1])
    for item in ctx.game_map.item_list:
        if item.time > ctx.turn + 32:
            break
        if item.type == 1 or (item.type == 2 and flag2):
            continue
        if item.type == 2 and ctx.turn < ctx.max_round // 4:
            continue
        # DEBUG(str(item) + '\n')
        if (item.x, item.y) not in dist:
            continue
        dis = dist[(item.x, item.y)]
        # DEBUG(str(dis) + '\n')
        if dis + ctx.turn >= item.time + 16:
            continue
        if dis + ctx.turn < item.time - max(snake.get_len(), 4):
            continue
        if ctx.game_map.snake_map[item.x][item.y] == snake.id:
            continue
        if item.id in item_used and item_used[item.id] == 1:
            continue
        min_dis.append((dis - (item.param // 2 if item.type == 0 else 0), item.id))
    # DEBUG(str(min_dis) + '\n')
    min_dis = sorted(min_dis)
    lastdis = 1000000
    cnt = 6
    for (dis, target) in min_dis:
        if cnt < 0:
            break
        if dis > lastdis + 6:
            break
        v = (ctx.game_map.get_map_item(target).x, ctx.game_map.get_map_item(target).y)
        path = []
        while v != (snake.coor_list[0][0], snake.coor_list[0][1]):
            path.insert(0, father[v])
            v = (v[0] - dx[father[v]], v[1] - dy[father[v]])
        if path == []:
            continue
        paths.append(path)
        if check(paths[-1][0]):
            for _ in range(cnt):
                ops.append([1, paths[-1][0], dis, target])
            cnt -= 4
        lastdis = dis
    _DEBUG("Get Item End.")

    # Get Item End

    # Solidify Begin

    _DEBUG("Solidify Begin")
    if (snake.get_len() + snake.length_bank >= 28 and ctx.get_snake_count(snake.camp) > 1) or (ctx.get_snake_count(1 - snake.camp) == 0 and ctx.turn > ctx.max_round // 4 * 3):
        sum_len = snake.get_len() + snake.length_bank
        bst = (sum_len + 4) // 4
        for l in range(bst, int(math.sqrt(sum_len - 1)), -1):
            flag = 0
            paths = []
            for d in range(4):
                path1 = wall_check(l, d, -1)
                path2 = wall_check(l, d, 1)
                if path1[0] != -1:
                    flag = 1
                    paths.append(path1)
                if path2[0] != -1:
                    flag = 1
                    paths.append(path2)
            if flag:
                cnt = l // len(paths) + 1
                if ctx.get_snake_count(snake.camp) == 1 and ctx.get_snake_count(1 - snake.camp) > 1:
                    chs = [1] * l
                    chs.extend([0] * 8)
                    cnt = chs[random.randint(0, len(chs) - 1)]
                if ctx.get_snake_count(snake.camp) == 1 and ctx.get_snake_count(1 - snake.camp) == 0:
                    if l < 8:
                        cnt = -1
                if cnt == 0:
                    ops.append([2, paths[0][0], paths[0]])
                for path in paths:
                    for _ in range(cnt):
                        ops.append([2, path[0], path])
                    _DEBUG(str(path))
                break
    _DEBUG("Solid End.")

    # Solidify End

    # Block Begin

    DEBUG("Kill Begin")

    # Block End

    # Choice Begin

    choice = [-1, -1]
    _DEBUG("Choice begin")
    for i in range(len(ops)):
        if ops[i][0] == 1:
            choice.extend([i])
        elif ops[i][1] == 2:
            if ctx.get_snake_count(1 - snake.camp) == 0 and ctx.turn > ctx.max_round // 4 * 3:
                choice.extend([i, i])
            else:
                choice.extend([i])
        else:
            choice.extend([i])
    d = -1
    if len(choice) > 0:
        index = choice[random.randint(0, len(choice) - 1)]
        if index != -1:
            if ops[index][0] == 1:
                if ops[index][2] > 1:
                    action[snake.id] = [1, ops[index][3], ops[index][2] - 1]
                    item_used[ops[index][3]] = 1
                d = ops[index][1]
            elif ops[index][0] == 2:
                if len(ops[index][2]) > 1:
                    action[snake.id] = [2, ops[index][2][1:]]
                _DEBUG(str(action[snake.id][1]))
                d = ops[index][1]
            else:
                if ops[index][2] > 1:
                    action[snake.id] = [3, ops[index][3]]
                d = ops[index][1]
    _DEBUG("Choice end")

    # Choice End

    # Empty State

    if d != -1:
        if (not check(d)) or (action[snake.id][0] != 2 and move_assess([d]) < 2):
            d = -1
            action[snake.id] = [0]
    if d != -1:
        return d + 1

    _DEBUG("Solidify Myself")
    # Solidify Myself

    maxarea = -100
    for dd in range(4):
        x = snake.coor_list[0][0] + dx[dd]
        y = snake.coor_list[0][1] + dy[dd]
        if x < 0 or y < 0 or x >= width or y >= height or ctx.game_map.wall_map[x][y] != -1:
            continue
        if ctx.game_map.snake_map[x][y] != snake.id:
            continue
        if x == snake.coor_list[1][0] and y == snake.coor_list[1][1]:
            continue
        if x == snake.coor_list[-1][0] and y == snake.coor_list[-1][1] and snake.length_bank == 0:
            continue
        flag = 0
        bound = []
        for coor in snake.coor_list:
            bound.append(coor)
            if x == coor[0] and y == coor[1]:
                flag = 1
                break
        if flag == 0:
            continue
        bound = [(coord[0], coord[1]) for coord in bound]
        g = Graph(bound=bound, w=width, l=height)
        area = len(g.calc()) + len(bound)
        if area > maxarea:
            maxarea = area
            d = dd

    if maxarea > (snake.get_len() + snake.length_bank) // 4 * 3 and ctx.get_snake_count(snake.camp) > 1 and ctx.turn > round_count // 4:
        if snake.get_len() < 8 and ctx.get_snake_count(snake.camp) >= 3:
            return d + 1
        elif ctx.get_snake_count(snake.camp) >= 3:
            choice = random.randint(1, 5 - ctx.get_snake_count(snake.camp))
            if choice == 1:
                return d + 1
    if maxarea > snake.get_len() * 2 and ctx.get_snake_count(1 - snake.camp) == 0:
        return d + 1

    d_solid = d


    _DEBUG("Find Legal Move Direction")
    # Find Legal Move Direction

    dir = lastdir
    maxchance = -1
    dd = 0
    for d in range(dir, dir + 4):
        if check(d % 4):
            c = move_assess([d % 4])
            if c > maxchance:
                maxchance = c
                dd = d
    d = dd % 4
    if not check(d) or maxchance == 0:
        if len(snake.item_list) > 0:
            if snake.get_len() > 1:
                x1, y1 = snake.coor_list[0]
                x2, y2 = snake.coor_list[1]
                _dx, _dy = x1 - x2, y1 - y2
                res = 0
                while width > x1 + _dx >= 0 and height > y1 + _dy >= 0:
                    x1 = x1 + _dx
                    y1 = y1 + _dy
                    if ctx.game_map.wall_map[x1][y1] == snake.camp:
                        res -= 1
                    elif ctx.game_map.wall_map[x1][y1] == 1 - snake.camp:
                        res += 1
                x1, y1 = snake.coor_list[0]
                if width > x1 + _dx >= 0 and height > y1 + _dy >= 0:
                    if res + snake.get_len() // 2 > 0 and ctx.game_map.wall_map[x1 + _dx][y1 + _dy] != -1:
                        return 5
        if maxarea < snake.get_len() and ctx.get_snake_count(snake.camp) < 4 and snake.get_len() > 2:
            return 6
        d = d_solid
    if not check(d, True):
        for i in range(4):
            if check(i):
                return i + 1

    if (len(snake.coor_list) > 2 or (len(snake.coor_list) == 2 and snake.length_bank > 0)) and snake.coor_list[0][0] + dx[d] == snake.coor_list[1][0] and snake.coor_list[0][1] + dy[d] == snake.coor_list[1][1]:
        d = (d + 1) % 4
    return d % 4 + 1

def run():
    global moves
    c = adk.Client()
    global width
    global height
    global lastdir
    global round_count
    # game config
    (width, height, round_count, player) = c.fetch_data()
    current_player = 0
    logging.info('Assigned player %d', player)
    # read items
    item_list = c.fetch_data()
    config = GameConfig(width=height, length=width, max_round=round_count)
    ctx = Context(config=config)
    ctx.game_map = Map(item_list, config=config)
    global controller
    controller = Controller(ctx)
    # read & write operations
    playing = True
    while playing:
        if controller.ctx.turn > round_count:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        _DEBUG(str(controller.ctx.turn) + ' ' + str(current_player) + '\n')
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:
            cnt = 0
            _DEBUG("My Turn Begin.")
            while controller.next_snake != -1:
                cnt += 1
                op = judge(controller.current_snake_list[controller.next_snake][0], controller.ctx, cnt)
                _DEBUG(str(op))
                logging.debug(str(op))
                c.send_data(op)
                if op <= 4:
                    lastdir = op - 1
                ff = controller.apply(op)
                _DEBUG(str(ff))
                _DEBUG("APPLY!")
                res = c.fetch_data()
                _DEBUG(str(res))
                _DEBUG(str(controller.ctx))
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:  # Wait to reap
        pass

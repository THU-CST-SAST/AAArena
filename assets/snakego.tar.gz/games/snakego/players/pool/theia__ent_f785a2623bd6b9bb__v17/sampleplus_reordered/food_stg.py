from adk import *
from state import State
from check import *
from constants import *
from kill import *
from distance import *


def closest_food_strategy(state: State, avoid_list):
    """
    Search for the closest food and to go that direction, if legal.

    :return: the chosen direction
    """
    bfs_data_for_all = dict()
    for snake_itr in state.ctx.snake_list:
        bfs_data_for_all[snake_itr.id] = get_bfs_dist(construct_dependent_state(state.ctx, snake_itr, state.order))


    bfs_dist, prev = get_bfs_dist(state)
    valid = []
    for i in range(4):
        if check(state, i):
            valid.append(i)
    if len(valid) == 0:
        if state.snake.get_len() > 1 and state.snake.coor_list[0][0] + dx[0] == state.snake.coor_list[1][0] and state.snake.coor_list[0][1] + dy[0] == state.snake.coor_list[1][1]:
            return 1
        return 0
    # calculate the legal moves without concerning the food

    coor = state.snake.coor_list
    dist, val = INF, []
    target_food = -1
    backup_dist_A, backup_val_A = INF, []
    for item in state.ctx.game_map.item_list:
        if item.type != 0:
            continue
        # search food only

        if item.time > state.ctx.turn + SEARCH_LIMIT or item.time + 15 < state.ctx.turn:
            continue
        # search valid food only

        d, pos = calc_dist(state, item.x, item.y, coor[0][0], coor[0][1], bfs_dist, prev)
        pos = [i for i in pos if i in valid]
        # use legal move only

        if len(pos) > 0 and d < dist and (d + state.ctx.turn <= item.time + 15 and item.time <= d + state.ctx.turn + state.snake.get_len()):
            if no_infighting_over(state, item.id, bfs_data_for_all):
                dist, val = d, pos
                backup_dist_A, backup_val_A = d, pos
                target_food = item.id
            else:
                backup_dist_A, backup_val_A = d, pos
        # search reachable food only
        # not that the span of a snake is at least SPLIT_LIMIT / 2
    
    #if len(val) > 0:
        #sys.stdout.write("At turn " + str(state.ctx.turn) + ", target_food: " + str(target_food) + " at dist: " + str(dist) + "\n")
    # chose the closest reachable food and use legal move
    #sys.stderr.write("Target food id and distance: " + str(target_food) + " " + str(dist) + "\n\n")
    
    #backup plan B: if there are no optimal length items (that is, ones without triggering infighting), we may as well go for melt items
    backup_dist_B, backup_val_B = INF, []
    for item in state.ctx.game_map.item_list:
        if item.type != 2:
            continue
        if item.time > state.ctx.turn + SEARCH_LIMIT or item.time + 15 < state.ctx.turn:
            continue
        d, pos = calc_dist(state, item.x, item.y, coor[0][0], coor[0][1], bfs_dist, prev)
        pos = [i for i in pos if i in valid]
        if len(pos) > 0 and d < backup_dist_B and (d + state.ctx.turn <= item.time + 15 and item.time <= d + state.ctx.turn + state.snake.get_len()):
            backup_dist_B, backup_val_B = d, pos

    if len(val) == 0:
        if len(backup_val_A) == 0:
            if(len(backup_val_B) == 0):
                val = valid #both backup plans unavailable
            else:
                val = backup_val_B #only plan B available. Apply it
        else:
            if(len(backup_val_B) == 0):
                val = backup_val_A #only plan A available. Apply it
            else:
                if(random.randint(0, 3) == 0): #both plans available. Apply according to the holy randint generator!!!
                    val = backup_val_A 
                else:
                    val = backup_val_B
    
    avoid = dict()
    if len(avoid_list) > 0:
        sys.stderr.write("avoid list for snake " + str(state.snake.id) +" at turn " + str(state.ctx.turn) + ": " + str(avoid_list) + "\n")
        sys.stderr.flush()
    for avoid_list_item in avoid_list:
        avoid[avoid_list_item[0]] = True

    optimal = []
    safe = []
    for i in range(len(val)):
        if no_deathtrap(state, val[i]) and not(val[i] in avoid) and cannot_be_killed(state, val[i]):
            optimal.append(val[i])
    for i in range(len(valid)):
        if no_deathtrap(state, valid[i]) and cannot_be_killed(state, valid[i]):
            safe.append(valid[i])
    #sys.stderr.write("Analyzed moves at turn " + str(state.ctx.turn) + "\noptimal: " + str(optimal) + "\nsafe: " + str(safe) + "\nvalid: " + str(valid) + "\nval: " + str(val) + "\n\n")
    if len(optimal) > 0:
        randindex = random.randint(0, len(optimal) - 1)
        ret = optimal[randindex]
    elif len(safe) > 0:
        randindex = random.randint(0, len(safe) - 1)
        ret = safe[randindex]
    else:
        randindex = random.randint(0, len(val) - 1)
        ret = val[randindex]
    # randomly choose one if multiple available

    return ret

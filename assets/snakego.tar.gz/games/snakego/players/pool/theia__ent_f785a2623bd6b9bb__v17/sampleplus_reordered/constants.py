dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
INF = 1000
RIGHT = [1, 0]
DOWN = [0, -1]
LEFT = [-1, 0]
UP = [0, 1]
UNREACHABLE_PENALTY = 2
dxy = [RIGHT, UP, DOWN, LEFT]
# constants

SPLIT_LIMIT = 15
SEARCH_LIMIT = 100
# tunable parameters
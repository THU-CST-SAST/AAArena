from copy import deepcopy
from typing import Dict
from adk import *
class State:
    ctx: Context
    snake: Snake
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()

def construct_dependent_state(cur_ctx, cur_snake, cur_order): #use only in checking 
    ret = State()
    ret.ctx = cur_ctx
    ret.snake = cur_snake
    ret.order = cur_order
    return ret

def construct_independent_state(cur_ctx, cur_snake, cur_order):
    ret = State()
    ret.ctx = deepcopy(cur_ctx)
    ret.snake = deepcopy(cur_snake)
    ret.order = deepcopy(cur_order)
    return ret

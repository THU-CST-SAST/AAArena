from adk import *
from constants import *
from state import *
from distance import *

def check(state: State, op):
    """
    :param op: the direction
    :return: True if this move is legal and will not result in solidification.
                False otherwise.
    """
    x = state.snake.coor_list[0][0] + dx[op]
    y = state.snake.coor_list[0][1] + dy[op]
    if x < 0 or y < 0 or x >= 16 or y >= 16 or state.ctx.game_map.wall_map[x][y] != -1:
        return False
    # check wall and out of bounds
    if not(state.snake.get_len() == 1 or (state.snake.get_len() == 2 and state.snake.length_bank == 0 and not((state.snake.id == 0 or state.snake.id == 1) and state.ctx.turn <= 8)))\
        and x == state.snake.coor_list[1][0] and y == state.snake.coor_list[1][1]:
        return False
    # check turn back
    if state.ctx.game_map.snake_map[x][y] != -1 and not(x == state.snake.coor_list[state.snake.get_len() - 1][0] and y == state.snake.coor_list[state.snake.get_len() - 1][1] and state.snake.length_bank == 0):
        return False
    # check other snake
    return True

def check_self(state: State, op):
    """
    :param op: the direction
    :return: True if this move is legal, could possibly result in solidification.
                False otherwise.
    """
    x = state.snake.coor_list[0][0] + dx[op]
    y = state.snake.coor_list[0][1] + dy[op]
    if x < 0 or y < 0 or x >= 16 or y >= 16 or state.ctx.game_map.wall_map[x][y] != -1:
        return False
    if not(state.snake.get_len() == 1 or (state.snake.get_len() == 2 and state.snake.length_bank == 0 and not((state.snake.id == 0 or state.snake.id == 1) and state.ctx.turn <= 8)))\
        and x == state.snake.coor_list[1][0] and y == state.snake.coor_list[1][1]:
        return False
    if state.ctx.game_map.snake_map[x][y] != -1 and state.ctx.game_map.snake_map[x][y] != state.snake.id:
        return False
    return True

def check_for(state: State, another_snake: Snake, op):
    """
    :param op: the direction
    :return: True if this move is legal and will not result in solidification.
                False otherwise.
    """
    x = another_snake.coor_list[0][0] + dx[op]
    y = another_snake.coor_list[0][1] + dy[op]
    if x < 0 or y < 0 or x >= 16 or y >= 16 or state.ctx.game_map.wall_map[x][y] != -1:
        return False
    # check wall and out of bounds
    if another_snake.get_len() > 2 and x == another_snake.coor_list[1][0] and y == another_snake.coor_list[1][1]:
        return False
    # check turn back
    if state.ctx.game_map.snake_map[x][y] != -1 and not(x == another_snake.coor_list[another_snake.get_len() - 1][0] and y == another_snake.coor_list[another_snake.get_len() - 1][1] and another_snake.length_bank == 0):
        return False
    # check other snakes
    return True

def no_infighting_over(state: State, target_item_id, bfs_data_for_all):

    def manhattan(x1, y1, x2, y2):
        return abs(x1 - x2) + abs(y1 - y2)
    
    target_coor = [-1, -1]

    for item_itr in state.ctx.game_map.item_list:
        if item_itr.id == target_item_id:
            target_coor[0] = item_itr.x
            target_coor[1] = item_itr.y
            break
    if target_coor[0] == -1:
        sys.stderr.write("item id: " + str(target_item_id) + " not found!\n")
        return False
    
    for snake_itr in state.ctx.snake_list:
        if snake_itr.camp != state.snake.camp or snake_itr.id == state.snake.id:
            continue
        else:
            itr_state = construct_dependent_state(state.ctx, snake_itr, state.order)
            #itr_dist_table, itr_dist_prev = get_bfs_dist(itr_state)
            #self_dist_table, self_dist_prev = get_bfs_dist(state)
            itr_dist_table, itr_dist_prev = bfs_data_for_all[snake_itr.id]
            self_dist_table, self_dist_prev = bfs_data_for_all[state.snake.id]
            itr_dist, itr_pos = calc_dist(itr_state, target_coor[0], target_coor[1], snake_itr.coor_list[0][0], snake_itr.coor_list[0][1], itr_dist_table, itr_dist_prev)
            self_dist, self_pos = calc_dist(state, target_coor[0], target_coor[1], state.snake.coor_list[0][0], state.snake.coor_list[0][1], self_dist_table, self_dist_prev)
            if itr_dist < self_dist:
                return False
    return True




def enum_option(state: State, tmp_snake):
    options = []
    #sys.stderr.write("tmp_snake: " + str(tmp_snake) + "\n")
    for i in range(4):
        tmp_coor = [tmp_snake[0][0] + dx[i], tmp_snake[0][1] + dy[i]]
        #sys.stderr.write("    tmp_coor: " + str(tmp_coor) + "\n")
        self_collision_flag = False
        for j in range(len(tmp_snake)):
            if tmp_snake[j][0] == tmp_coor[0] and tmp_snake[j][1] == tmp_coor[1]:
                self_collision_flag = True
                break
        if self_collision_flag:
            continue
        if (tmp_coor[0] >= 0 and tmp_coor[0] <= 15 and tmp_coor[1] >= 0 and tmp_coor[1] <= 15)\
            and (state.ctx.get_map().snake_map[tmp_coor[0]][tmp_coor[1]] == -1 or (state.ctx.get_map().snake_map[tmp_coor[0]][tmp_coor[1]] == state.snake.id))\
            and (state.ctx.get_map().wall_map[tmp_coor[0]][tmp_coor[1]] == -1):
            options.append(i)
    return options

def no_deathtrap(state: State, op):

    #sys.stderr.write("Round: " + str(state.ctx.turn) + "\nProbing at: " + str(state.snake.coor_list[0]) + "\n")

    dx = [1, 0, -1, 0]
    dy = [0, 1, 0, -1]
    vis = dict()
    cur_coor = [state.snake.coor_list[0][0], state.snake.coor_list[0][1]]
    tmp_snake = []
    for i in range(0, len(state.snake.coor_list)):
        tmp_snake.append([state.snake.coor_list[i][0], state.snake.coor_list[i][1]])
    

    cur_coor[0] += dx[op]
    cur_coor[1] += dy[op]
    for i in range(len(tmp_snake) - 1, 0, -1): #do not account for length bank
        tmp_snake[i][0] = tmp_snake[i - 1][0]
        tmp_snake[i][1] = tmp_snake[i - 1][1]
    tmp_snake[0][0] = cur_coor[0]
    tmp_snake[0][1] = cur_coor[1]
    vis[cur_coor[0] * 16 + cur_coor[1]] = True
    #sys.stderr.write("cur_coor: " + str(cur_coor) + "\n")
    opt = enum_option(state, tmp_snake)
    #sys.stderr.write("options: " + str(opt) + "\n")

    while(len(opt) <= 1):
        if len(opt) < 1:
            #sys.stderr.write("Dead End \n\n")
            del tmp_snake
            return False
        elif len(opt) == 1:
            cur_coor[0] += dx[opt[0]]
            cur_coor[1] += dy[opt[0]]
            if (cur_coor[0] * 16 + cur_coor[1]) in vis:
                #sys.stderr.write("Dead End \n\n")
                del tmp_snake
                return False
            #sys.stderr.write("cur_coor: " + str(cur_coor) + "\n")
            for i in range(len(tmp_snake) - 1, 0, -1): #do not account for length bank
                tmp_snake[i][0] = tmp_snake[i - 1][0]
                tmp_snake[i][1] = tmp_snake[i - 1][1]
            tmp_snake[0][0] = cur_coor[0]
            tmp_snake[0][1] = cur_coor[1]
            vis[cur_coor[0] * 16 + cur_coor[1]] = True
            opt = enum_option(state,tmp_snake)
            #sys.stderr.write("options: " + str(opt) + "\n")
        else:
            #sys.stderr.write("Good Choice \n\n")
            del tmp_snake
            return True
    
    del tmp_snake
    #sys.stderr.write("Good Choice \n\n")
    return True
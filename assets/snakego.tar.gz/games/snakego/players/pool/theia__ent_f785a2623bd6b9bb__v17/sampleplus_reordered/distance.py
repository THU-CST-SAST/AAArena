from adk import *
from state import State
from queue import Queue
from constants import *

def dist_from_tail(state: State, snake_id, coor):
    for snake_it in state.ctx.snake_list:
        if snake_it.id == snake_id:
            ret = 0
            for i in range(len(snake_it.coor_list) - 1, -1, -1):
                if snake_it.coor_list[i][0] == coor[0] and snake_it.coor_list[i][1] == coor[1]:
                    return ret
                ret += 1
    sys.stderr.write("dist_from_tail error!\n")
    sys.stderr.flush()
    return -1
    
def get_bfs_dist(state: State):
    DIST_FACTOR = 0.8
    cur_coor = (state.snake.coor_list[0][0], state.snake.coor_list[0][1])
    q = Queue()
    vis = dict()
    prev = dict()
    q.put(cur_coor)
    vis[cur_coor[0] * 16 + cur_coor[1]] = True
    prev[cur_coor[0] * 16 + cur_coor[1]] = -1
    dist = []
    for i in range(16):
        tmp_list = []
        for j in range(16):
            if i == cur_coor[0] and j == cur_coor[1]:
                tmp_list.append(0)
            else:
                tmp_list.append(INF)
        dist.append(tmp_list)
    
    while(not(q.empty())):
        cur_coor = q.get()
        dirs = [0, 1, 2, 3]
        random.shuffle(dirs)
        for op in dirs:
            next_coor = (cur_coor[0] + dx[op], cur_coor[1] + dy[op])
            if next_coor[0] > 15 or next_coor[0] < 0 or next_coor[1] > 15 or next_coor[1] < 0:
                continue
            if next_coor[0] * 16 + next_coor[1] in vis:
                continue
            if state.ctx.game_map.wall_map[next_coor[0]][next_coor[1]] != -1:
                continue
            if state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]] != -1:
                snake_id = state.ctx.game_map.snake_map[next_coor[0]][next_coor[1]]
                if (snake_id != state.snake.id and dist_from_tail(state, snake_id, next_coor) + 1 >= dist[cur_coor[0]][cur_coor[1]] * DIST_FACTOR) or snake_id == state.snake.id:
                    continue
            dist[next_coor[0]][next_coor[1]] = dist[cur_coor[0]][cur_coor[1]] + 1
            vis[next_coor[0] * 16 + next_coor[1]] = 16
            prev[next_coor[0] * 16 + next_coor[1]] = cur_coor[0] * 16 + cur_coor[1]
            q.put(next_coor)

    #sys.stdout.write("At turn " + str(state.ctx.turn) + ", for snake " + str(state.snake.id) + ": \n")
    #for y in range(15, -1, -1):
    #    for x in range(16):
    #        sys.stdout.write(str(dist[x][y]) + " ")
    #        sys.stdout.flush()
    #    sys.stdout.write("\n")
    
    return dist, prev

def manhattan(x1, y1, x2, y2):
    return abs(x1 - x2) + abs(y1 - y2)

def calc_dist(state: State, x1, y1, x2, y2, bfs_dist: List[List[int]], prev: List[int]): #item(x1,y1), snake(x2,y2)
    """
    Calculate the Manhattan distance between snake head and item.
    And find the possible direction to the item, at most 2.

    :return: (dist, possible_direction)
    """
    MANHATTAN_LIMIT = 5
    if(manhattan(x1, y1, x2, y2) < MANHATTAN_LIMIT):
        pos = []
        if x1 > x2:
            pos.append(0)
        if x1 < x2:
            pos.append(2)
        if y1 > y2:
            pos.append(1)
        if y1 < y2:
            pos.append(3)
        return abs(x1 - x2) + abs(y1 - y2), pos
    else:
        if bfs_dist[x1][y1] == INF:
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return (abs(x1 - x2) + abs(y1 - y2)) * UNREACHABLE_PENALTY, pos
        pos = []
        pos_elem = prev[x1 * 16 + y1]
        while prev[prev[pos_elem]] != -1:
            pos_elem = prev[pos_elem]
        head = prev[pos_elem]
        if(head != state.snake.coor_list[0][0] * 16 + state.snake.coor_list[0][1]):
            sys.stderr.write("prev head parse error\n")
        if pos_elem - head == 16:
            pos.append(0)
        elif pos_elem - head == -16:
            pos.append(2)
        elif pos_elem - head == 1:
            pos.append(1)
        elif pos_elem - head == -1:
            pos.append(3)
        return bfs_dist[x1][y1], pos
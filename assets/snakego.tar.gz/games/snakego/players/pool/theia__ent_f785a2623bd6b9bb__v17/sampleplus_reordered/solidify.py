from adk import *
from state import State
from check import *



def solidify(state: State, avoid_list):
    """
    Try to solidify self by forming a 2 * 2 area.
    It requires at most 4 move to solidify.

    :return: direction to move
    """
    if state.snake.id in state.order:
        valid = []
        optimal = dict()
        optimal_list = []
        avoid = dict()
        for avoid_list_item in avoid_list:
            avoid[avoid_list_item[2]] = True
        for op in range(4):
            if check_self(state, op):
                valid.append(op)
                if not(op in avoid):
                    optimal[op] = True
                    optimal_list.append(op)
        rk, order = state.order[state.snake.id]
        state.order[state.snake.id] = rk + 1, order
        if order[rk] % 4 in optimal:  # not the first move, follow the previous move
            return order[rk] % 4 
        else: #following previous move is not an optimal strategy
            state.order.pop(state.snake.id) #re-enter the solidify process next turn
            if len(optimal_list) > 0:
                return optimal_list[random.randint(0, len(optimal_list) - 1)] #don't harm teammates
            elif len(valid) > 0:
                return optimal_list[random.randint(0, len(valid) - 1)] #then at least don't die by suicide
            else:
                return state.death_strategy() #go die...
    else:
        for i in range(4):
            if check_self(state, i):
                order = [i, i + 1, i + 2, i + 3]
                state.order.update({state.snake.id: (1, order)})
                return i % 4
        # the first move, choose a legal direction at store it in self.order
        return 0
#include "adk.hpp"
#include <cmath>
// #include<vector>

const int dx[4] = { 1, 0, -1, 0 };
const int dy[4] = { 0, 1, 0, -1 };

// for Dj shortest path
struct Node{
    Coord position;
    int distance;
    Node(){
        position.x = -1;
        position.y = -1;
        distance = 999;
    }
};
class Point{
	public:
    int distance;
    bool set;
    bool inBox;
	Coord from;
    Point(){
        distance = 999;
        set = false;
        inBox = false;
		from.x = -1;
		from.y = -1;
    }
	void Set(){
		distance = 999;
        set = false;
        inBox = false;
		from.x = -1;
		from.y = -1;
	}
};
Point point_map[50][50];

class Djvector{
	public:
	Node _data[500];
	int tnode;
	Djvector(){
		tnode = 0;
	}
	void push_back(Node temp){
		_data[tnode] = temp;
		tnode++;
	}
	void erase(int index){
		for(int i = index + 1; i < tnode; i++){
			_data[i - 1] = _data[i];
		}
		tnode--;
	}
    bool empty(){
        if(tnode == 0){
            return true;
        }else{
            return false;
        }
    }
    int GetMin(){
        int index = 0;
        int min_dis = 999;
        for(int i = 0; i < tnode; i++){
            if(_data[i].distance < min_dis){
                min_dis = _data[i].distance;
                index = i;
            }
        }
        return index;
    }
    int BoxFind(int x, int y){
        int i = 0;
        for(; i < tnode; i++){
            if((_data[i].position.x == x) && (_data[i].position.y == y)){
                return i;
            }
        }
        return i;
    }
    Node& operator[](int index){
        return _data[index];
    }
} box;
bool PositionLegalCheck(int x, int y, const Context& ctx){
	// checkerboard check
    if(x < 0 || ctx.length() <= x || y < 0 || ctx.width() <= y){
		return false;
	}
	// wall check
	if ( ctx.wall_map()[x][y] != -1 ){
		return false;
	}
	// snake check
	if ( ctx.snake_map()[x][y] != -1 ){
		return false;
	}
	// all check pass
	return true;
}

// general strategies
int GetDirection(const Snake& snake_to_operate){
	// Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
	// 0 for right, 1 for up, 2 for left, 3 for down

	Coord first = snake_to_operate.coord_list[0];
	Coord second = snake_to_operate.coord_list[1];

	if(first.x == second.x){
		// vertical
		if(first.y > second.y){
			// up
			return 1;
		}
		if(first.y < second.y){
			// down
			return 3;
		}
	}

	if(first.y == second.y){
		// horizontal
		if(first.x > second.x){
			// right
			return 0;
		}
		if(first.x < second.x){
			// left
			return 2;
		}
	}
}
bool MeltStrategy(const Snake& snake_to_operate, const Context& ctx){
	if (snake_to_operate.railgun_item.id < 0){
		return false;
	}
	if(snake_to_operate.length() < 2){
		// melt can only be used when length greater than or equal to 2
		return false;
	}

	int direction = GetDirection(snake_to_operate);
	Coord position = snake_to_operate.coord_list[0];
	int blocksCount = 0;
	// Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
	// 0 for right, 1 for up, 2 for left, 3 for down
	switch(direction){
		case 0:
		// right
		for(int i = position.x; i < ctx.length(); i++){
			if(ctx.wall_map()[i][position.y] == -1){
				continue;
			}else if(ctx.wall_map()[i][position.y] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 1:
		// up
		for(int j = position.y; j < ctx.width(); j++){
			if(ctx.wall_map()[position.x][j] == -1){
				continue;
			}else if(ctx.wall_map()[position.x][j] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 2:
		// left
		for(int i = 0; i < position.x; i++){
			if(ctx.wall_map()[i][position.y] == -1){
				continue;
			}else if(ctx.wall_map()[i][position.y] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
		case 3:
		// down
		for(int j = 0; j < position.y; j++){
			if(ctx.wall_map()[position.x][j] == -1){
				continue;
			}else if(ctx.wall_map()[position.x][j] == ctx.current_player()){
				// ally
				blocksCount--;
			}else{
				// enemy
				blocksCount++;
			}
		}
		break;
	}

	if(blocksCount > 0){
		return true;
	}else{
		return false;
	}
}
bool SplitStrategy(const Snake& snake_to_operate, const Context& ctx){
	// priority split
	if ( snake_to_operate.length() > 1 )
	{
		// keep snake number 3, in case able to split when no way to go
		if ( ctx.my_snakes().size() < 3 )
			return true;
	}

	return false;
}
void SetPointMap(const Snake& snake_to_operate, const Context& ctx){
	// set the point map
	for(int i = 0; i < ctx.length(); i++){
		for(int j = 0; j < ctx.width(); j++){
			point_map[i][j].Set();
		}
	}

	// start point
    int s_x = snake_to_operate.coord_list[0].x;
	int s_y = snake_to_operate.coord_list[0].y;
    point_map[s_x][s_y].distance = 0;
	point_map[s_x][s_y].from.x = s_x;
	point_map[s_x][s_y].from.y = s_y;
    point_map[s_x][s_y].set = true;

    for(int dir = 0; dir < 4; dir++){
        int t_x = s_x + dx[dir];
        int t_y = s_y + dy[dir];

        if(PositionLegalCheck(t_x, t_y, ctx) == false){
            continue;
        }

        Node temp;
        temp.position.x = t_x;
        temp.position.y = t_y;
        temp.distance = 1;
        box.push_back(temp);
		point_map[t_x][t_y].from.x = s_x;
		point_map[t_x][t_y].from.y = s_y;
        point_map[t_x][t_y].inBox = true;
        point_map[t_x][t_y].distance = 1;
    }

    while(box.empty() == false){
        int index = box.GetMin();
        int x = box[index].position.x;
        int y = box[index].position.y;
        point_map[x][y].set = true;
        point_map[x][y].inBox = false;
        // delete from box
        box.erase(index);
        // put relevants back to box
        for(int dir = 0; dir < 4; dir++){
            int t_x = x + dx[dir];
            int t_y = y + dy[dir];

            if(PositionLegalCheck(t_x, t_y, ctx) == false){
                continue;
            }

            if(point_map[t_x][t_y].set == true){
                continue;
            }

            if(point_map[x][y].distance + 1 < point_map[t_x][t_y].distance){
				point_map[t_x][t_y].from.x = x;
				point_map[t_x][t_y].from.y = y;
                if(point_map[t_x][t_y].inBox){
                    point_map[t_x][t_y].distance = point_map[x][y].distance + 1;
                    
                    int _index = box.BoxFind(t_x, t_y);
                    box[_index].distance = point_map[x][y].distance + 1;
                }else{
                    point_map[t_x][t_y].distance = point_map[x][y].distance + 1;
                    point_map[t_x][t_y].inBox = true;

                    Node temp;
                    temp.position.x = t_x;
                    temp.position.y = t_y;
					temp.distance = point_map[x][y].distance + 1;
                    box.push_back(temp);
                }
            }
        }
    }
}
int PropStratgy(const Snake& snake_to_operate, const Context& ctx){
	// return prop number, if not found retrun -1
	// find closest prop

	int ret_num = -1;
	int min_dis = 999;
	// find first valid prop
	int i = 0;
	for ( ; i < ctx.item_list().size(); i++ ){
		//道具已经消失
		if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() ){
			continue;
		}
		break;
	}

	for(; i <  ctx.item_list().size(); i++){
		// ignore eaten prop
		if(ctx.item_list()[i].eaten == true){
			continue;
		}

		// check in wall
		int prop_x = ctx.item_list()[i].x;
		int prop_y = ctx.item_list()[i].y;
		if(ctx.wall_map()[prop_x][prop_y] != -1){
			continue;
		}

		int distance = point_map[prop_x][prop_y].distance;
		if ( ctx.item_list()[i].time <= ctx.current_round() + distance &&
				ctx.item_list()[i].time + 16 > ctx.current_round() + distance ){
					if(distance < min_dis){
						min_dis = distance;
						ret_num = i;
					}
				}
	}

	return ret_num;
}

int DestinationOrientateMove(Coord dest, const Snake& snake_to_operate){
	// 0 for right, 1 for up, 2 for left, 3 for down
	int snake_x = snake_to_operate.coord_list[0].x;
	int snake_y = snake_to_operate.coord_list[0].y;

	if(snake_x == dest.x){
		// up and down
		if(dest.y > snake_y){
			// up
			return 1;
		}
		if(dest.y < snake_y){
			return 3;
		}
	}

	if(snake_y == dest.y){
		if(dest.x > snake_x){
			return 0;
		}
		if(dest.x < snake_x){
			return 2;
		}
	}
}

int TailStrategy(const Snake& snake_to_operate, const Context& ctx){
	// solid when length >= 15
	if(snake_to_operate.length() < 16){
		return -1;
	}

	fprintf( stderr, "%s %s %d\n", "tail strategy", "snake id", snake_to_operate.id );

	int head_to_tail = abs( snake_to_operate.coord_list.back().x - snake_to_operate.coord_list[0].x ) +
					abs( snake_to_operate.coord_list.back().y - snake_to_operate.coord_list[0].y );
	if(head_to_tail == 1){
		Coord target;
		target.x = snake_to_operate.coord_list.back().x;
		target.y = snake_to_operate.coord_list.back().y;
		return DestinationOrientateMove(target, snake_to_operate);
	}

	int tail_x = snake_to_operate.coord_list.back().x;
	int tail_y = snake_to_operate.coord_list.back().y;
	
	// find a cloesest block
	Coord block_position;
	int min_dis = 999;
	for(int dir = 0; dir < 4; dir++){
		int t_x = tail_x + dx[dir];
		int t_y = tail_y + dy[dir];
		if(PositionLegalCheck(t_x, t_y, ctx)){
			if(point_map[t_x][t_y].distance < min_dis){
				min_dis = point_map[t_x][t_y].distance;
				block_position.x = t_x;
				block_position.y = t_y;
			}
		}
	}

	if(min_dis == 999){
		// tail is inaccessible
		return -1;
	}

	Coord current = block_position;

	fprintf( stderr, "%s %d %d\n", "find path:", current.x, current.y );
	Coord next = point_map[current.x][current.y].from;
	while(!((next.x == snake_to_operate.coord_list[0].x) && (next.y == snake_to_operate.coord_list[0].y))){
		fprintf( stderr, "%s %d %d\n", "current:", current.x, current.y );
		current = next;
		next = point_map[current.x][current.y].from;
	}

	return DestinationOrientateMove(current, snake_to_operate);
}

Operation make_your_decision( const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_list ){
	// melt check
	if(MeltStrategy(snake_to_operate, ctx)){
		return OP_RAILGUN;
	}

	// split check
	if(SplitStrategy(snake_to_operate, ctx)){
		return OP_SPLIT;
	}

	Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };

	//确定合法移动方向
	//-1代表移动非法，0代表正常移动，1代表移动触发固化
	int move[4] = { 0, 0, 0, 0 };
	for ( int dir = 0; dir < 4; dir++ ){
		//蛇头到达位置
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];

		//超出边界
		if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )
		{
			move[dir] = -1;
			continue;
		}

		//撞墙
		if ( ctx.wall_map()[t_x][t_y] != -1 )
		{
			move[dir] = -1;
			continue;
		}

		//撞非本蛇
		if ( ctx.snake_map()[t_x][t_y] != -1 && ctx.snake_map()[t_x][t_y] != snake_to_operate.id )
		{
			move[dir] = -1;
			continue;
		}

		//回头撞自己
		if ( ( snake_to_operate.length() > 2 ||
			   ( snake_to_operate.length() == 2 && snake_to_operate.length_bank > 0 ) ) &&
			 snake_to_operate[1].x == t_x && snake_to_operate[1].y == t_y )
		{
			move[dir] = -1;
			continue;
		}

		//移动导致固化
		if ( ctx.snake_map()[t_x][t_y] == snake_to_operate.id )
		{
			move[dir] = 1;
			continue;
		}
	}

	// set point map
	SetPointMap(snake_to_operate, ctx);

	// if length equal or more than 15, go to its tail
	int tail_startegy = TailStrategy(snake_to_operate, ctx);
	if(tail_startegy != -1){
		// tail trategy ok
		return direction[tail_startegy];
	}
	
	// prop strategy
	int prop_num = PropStratgy(snake_to_operate, ctx);
	int distance;
	if(prop_num != -1){
		Coord current;
		current.x = ctx.item_list()[prop_num].x;
		current.y = ctx.item_list()[prop_num].y;
		Coord next = point_map[ctx.item_list()[prop_num].x][ctx.item_list()[prop_num].y].from;
		while(!((next.x == snake_to_operate.coord_list[0].x) && (next.y == snake_to_operate.coord_list[0].y))){
			current = next;
			next = point_map[current.x][current.y].from;
		}

		int dir = DestinationOrientateMove(current, snake_to_operate);
		return direction[dir];
	}

	// prior move
	for(int dir = 0; dir < 4; dir++){
		if(move[dir] == 0){
			return direction[dir];
		}
	}

	// solid when have to
	for(int dir = 0; dir < 4; dir++){
		if(move[dir] == 1){
			return direction[dir];
		}
	}

	// no way to go
	if(ctx.my_snakes().size() < 4 && snake_to_operate.length() > 1){
		// check split conditions
		return OP_SPLIT;
	}

	// can not split have to die, find a legal direction
	for(int dir = 0; dir < 4; dir++){
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];
		
		if ( ( snake_to_operate.length() > 2 ||
			   ( snake_to_operate.length() == 2 && snake_to_operate.length_bank > 0 ) ) &&
			 snake_to_operate[1].x == t_x && snake_to_operate[1].y == t_y )
		{
			continue;
		}

		return direction[dir];
	}
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
	// fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char** argv ) { SnakeGoAI start( argc, argv ); }
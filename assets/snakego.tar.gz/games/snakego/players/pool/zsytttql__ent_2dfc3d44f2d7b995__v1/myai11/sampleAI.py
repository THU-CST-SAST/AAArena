from adk import *
import numpy as np
import time
import copy
import sys


dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
INF = 1e9
# constants

MAX_length = 6
SPLIT_LIMIT = 15
SEARCH_LIMIT = 16
# tunable parameters
# center_list = {}
class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()
        self.enemy_id = -1
        self.player = -1
        self.current_player = -1
        self.controller = None
        self.use_old = False
        self.max_round = 6
        self.item_target = {} # item_id:[snake_id, distance]

    def check(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        if self.use_old:
            x = self.snake.coor_list[0][0] + dx[op]
            y = self.snake.coor_list[0][1] + dy[op]
            if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
                return False
            # check wall and out of bounds
            if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
                return False
            # check turn back
            if self.ctx.game_map.snake_map[x][y] != -1:
                return False
            # check other snake
            return True
        else:
            res = search_op1(self.current_player, self.player, copy.deepcopy(self.controller), op + 1, self.max_round)
            # print(res)
            return res

    def check_self(self, op):
        """
        :param op: the direction
        :return: True if this move is legal, could possibly result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
            return False
        return True

    def closest_food_strategy(self, set_dist=INF):
        """
        Search for the closest food and to go that direction, if legal.

        :return: the chosen direction
        """
        def calc_dist(x1, y1, x2, y2):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return abs(x1 - x2) + abs(y1 - y2), pos

        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0:
            return self.alive()
        # calculate the legal moves without concerning the food

        coor = self.snake.coor_list
        dist, val = set_dist, []
        hit_flag = 0
        for item in self.ctx.game_map.item_list:
            if item.id in self.item_target.keys():
                # print(self.item_target)
                if self.item_target[item.id][0] != self.snake.id:
                    continue
                else:
                    hit_flag = 1
            if item.type != 0 and (item.type == 2 and len(self.snake.item_list) > 0):
                continue
            # search food only

            snake_map = self.ctx.get_map().snake_map
            wall_map = self.ctx.get_map().wall_map
            if wall_map[item.x][item.y] != -1 or (snake_map[item.x][item.y] != -1 and snake_map[item.x][item.y] != self.snake.id):
                continue

            if item.time > self.ctx.turn + SEARCH_LIMIT or item.time + 16 < self.ctx.turn:
                continue
            # search valid food only

            d, pos = calc_dist(item.x, item.y, coor[0][0], coor[0][1])
            pos = [i for i in pos if i in valid]
            # use legal move only

            if len(pos) > 0 and d < dist and \
                    d + self.ctx.turn <= item.time + 16:
                dist, val = d, pos
            if hit_flag:
                break
            # search reachable food only
            # not that the span of a snake is at least SPLIT_LIMIT / 2

        # chose the closest reachable food and use legal move

        if len(val) == 0:
            # print('没有食物！')
            val = valid
            # return self.disturb()
        i = random.randint(0, len(val) - 1)
        # randomly chose one if multiple available

        return val[i]

    def closest_food_new(self, set_dist=6):
        """
        Search for the closest food and to go that direction, if legal.

        :return: the chosen direction
        """
        def calc_dist(x1, y1, x2, y2):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return abs(x1 - x2) + abs(y1 - y2), pos

        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0:
            return self.alive()
        # calculate the legal moves without concerning the food


        coor = self.snake.coor_list
        dist, val = set_dist, []
        hit_flag = 0
        for item in self.ctx.game_map.item_list:
            if item.id in self.item_target.keys():
                if self.item_target[item.id][0] != self.snake.id:
                    continue
                else:
                    hit_flag = 1
            if item.type != 0 and not (item.type == 2 and len(self.snake.item_list) > 0):
                continue
            # search food only

            if item.time > self.ctx.turn + SEARCH_LIMIT or item.time + 16 < self.ctx.turn:
                continue
            # search valid food only

            d, pos = calc_dist(item.x, item.y, coor[0][0], coor[0][1])
            pos = [i for i in pos if i in valid]
            # use legal move only

            if len(pos) > 0 and d < dist and \
                    d + self.ctx.turn <= item.time + 16:
                dist, val = d, pos
            # search reachable food only
            # not that the span of a snake is at least SPLIT_LIMIT / 2
            if hit_flag:
                break

        # chose the closest reachable food and use legal move

        if len(val) == 0:
            # print('没有食物！')
            return self.disturb()
        i = random.randint(0, len(val) - 1)
        # randomly chose one if multiple available

        return val[i]

    def active_strategy(self, set_dist=INF):
        """
        Strategy for the active snake. Split whenever limit is reached.
        Fire whenever possible. Otherwise search for food.
        """
        if self.fire(): # 判断是否使用熔化射线
            # print(6)
            return 5
        elif self.split(): # 判断是否使用分裂道具
            return 6
        else:
            return self.closest_food_strategy(set_dist) + 1

    def split(self):# 判断是否分裂
        if len(self.snake.coor_list) >= SPLIT_LIMIT and self.ctx.get_snake_count(self.snake.camp) < 4:
            return True
        if self.ctx.get_snake_count(self.snake.camp) < 4 and len(self.snake.coor_list) >= 2:
            die_flag = 1
            for k in range(4):
                if self.check_self(k):
                    die_flag = 0
                    break
            if die_flag:
                return True
        return False

    def fire(self): # 判断是否使用熔化射线
        if len(self.snake.item_list) > 0 and len(self.snake.coor_list) > 1:
            # 如果没路走了，用熔化射线
            die_flag = 1
            for k in range(4):
                if self.check_self(k):
                    die_flag = 0
                    break
            if die_flag:
                return True
            # 如果熔化射线可以带来收益，使用熔化射线
            head = self.snake.coor_list[0]
            neck = self.snake.coor_list[1]
            wall_map = self.ctx.get_map().wall_map
            x = head[0]
            y = head[1]
            my_wall = 0
            enemy_wall = 0
            if head[0] == neck[0]:
                y = y + head[1] - neck[1]
                while y >= 0 and y <= 15:
                    if wall_map[x][y] == self.snake.camp: # 自己的墙
                        my_wall += 1
                    elif wall_map[x][y] == 1 - self.snake.camp: # 对手的墙
                        enemy_wall += 1
                    y = y + head[1] - neck[1]
            elif head[1] == neck[1]:
                x = x + head[0] - neck[0]
                while x >= 0 and x <= 15:
                    if wall_map[x][y] == self.snake.camp: # 自己的墙
                        my_wall += 1
                    elif wall_map[x][y] == 1 - self.snake.camp: # 对手的墙
                        enemy_wall += 1
                    x = x + head[0] - neck[0]
            # 判断收益
            if enemy_wall - my_wall >= 2:
                return True
            elif my_wall == 0 and enemy_wall > 0:
                return True

        return False

    def alive(self, use_old=False):
        # 如果没路走了，通过分裂或熔化射线生存
        # print(use_old)
        if len(self.snake.item_list) > 0 and len(self.snake.coor_list) > 1: # 熔化射线
            return 5 - 1
        elif len(self.snake.coor_list) > 1 and self.ctx.get_snake_count(self.snake.camp) < 4: # 分裂
            return 6 - 1
        else:
            valid = []
            for i in range(4):
                if self.check_self(i):
                    valid.append(i)
            if len(valid) > 0:
                i = random.randint(0, len(valid) - 1)
                return valid[i]
            else:
                # if use_old:
                if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                    return 1
                return 0
                # else:
                    # self.snake.mode = 2 # TEST!!!!!!
                    # return self.solidify_strategy(use_old=True)

    def solidify_strategy(self, use_old=False):
        """
        Try to solidify self by forming a 2 * 2 area.
        It requires at most 4 move to solidify.

        :return: direction to move
        """
        # if self.snake.id in self.order:
        #     rk, order = self.order[self.snake.id]
        #     self.order[self.snake.id] = (rk + 1)%4, order
        #     return order[rk] % 4
        #     # not the first move, follow the previous move
        # else:
        #     for i in range(4):
        #         if self.check_self(i):
        #             order = [i, i + 1, i + 2, i + 3]
        #             self.order.update({self.snake.id: (1, order)})
        #             return i % 4
            # the first move, choose a legal direction at store it in self.order
            # return 0
        def calc_dist(pos1, pos2):
            return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])
        self.use_old = True
        head = self.snake.coor_list[0]
        end = self.snake.coor_list[self.snake.get_len() - 1]
        dis = calc_dist(head, end)
        if dis > 5:
            return self.go_to(self.snake.coor_list[self.snake.get_len() - 4], use_old=use_old)
        elif dis > 3:
            return self.go_to(self.snake.coor_list[self.snake.get_len() - 3], use_old=use_old)
        else:
            return self.go_to(self.snake.coor_list[self.snake.get_len() - 2], solidify = True, use_old=use_old)

    def go_to(self, des, solidify = False, use_old=False):
        def calc_dist(pos1, pos2, use_old):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            x1, y1 = pos1[0], pos1[1]
            x2, y2 = pos2[0], pos2[1]
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            # if use_old:
            return abs(x1 - x2) + abs(y1 - y2), pos
            # else:
            #     return calculate_distance(self.current_player, self.player, copy.deepcopy(self.controller), pos2), pos

        valid = []
        for i in range(4):
            if not solidify:
                if self.check(i):
                    valid.append(i)
            else:
                if self.check_self(i):
                    valid.append(i)
        if len(valid) == 0:
            return self.alive(use_old=use_old)

        dis, pos = calc_dist(des, self.snake.coor_list[0], use_old)
        direction = [i for i in pos if i in valid]
        if len(direction) == 0:
            direction = valid
        i = random.randint(0, len(direction)-1)
        return direction[i]

    def update_item_target(self):
        """
        Search for the closest food and to go that direction, if legal.

        :return: the chosen direction
        """
        def calc_dist(x1, y1, x2, y2):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return abs(x1 - x2) + abs(y1 - y2), pos

        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        # calculate the legal moves without concerning the food
        exist_flag = 0
        exist_key = -1
        dist, val = INF, []
        for key in self.item_target.keys():
            if self.item_target[key][0] == self.snake.id: # 已有道具
                dist = self.item_target[key][1]
                exist_flag = 1
                exist_key = key
        coor = self.snake.coor_list
        
        target_id = -1
        # hit_flag = 0
        for item in self.ctx.game_map.item_list:
            # print(SEARCH_LIMIT)
            # print(item.time)
            # print(self.ctx.turn)
            if item.type != 0 and (item.type == 2 and len(self.snake.item_list) > 0):
                continue
            # search food only

            if item.time > self.ctx.turn + SEARCH_LIMIT or item.time + 16 < self.ctx.turn:
                # print('111')
                continue
            # search valid food only

            snake_map = self.ctx.get_map().snake_map
            wall_map = self.ctx.get_map().wall_map
            if (snake_map[item.x][item.y] != -1 and snake_map[item.x][item.y] != self.snake.id) or wall_map[item.x][item.y] != -1: # search reachable food only
                # print('222')
                continue

            d, pos = calc_dist(item.x, item.y, coor[0][0], coor[0][1])
            pos = [i for i in pos if i in valid]
            # use legal move only
            # print(dist)
            if len(pos) > 0 and d < dist and \
                    d + self.ctx.turn <= item.time + 16:
                if item.id in self.item_target.keys() and d >= self.item_target[item.id][1]:
                    pass
                else:
                    dist, val = d, pos
                    target_id = item.id
            # search reachable food only
            # not that the span of a snake is at least SPLIT_LIMIT / 2

        # chose the closest reachable food and use legal move

        if target_id >= 0:
            self.item_target[target_id] = [self.snake.id, dist]
            if exist_flag and exist_key != target_id:
                self.item_target.pop(exist_key)

    def passive_strategy(self):
        """
        Strategy for other snake. Always solidify.
        """
        return self.solidify_strategy() + 1

    def disturb(self): # 干扰敌方蛇，向着敌方蛇的蛇头不断移动
        def calc_dist(pos1, pos2):
            """
            Calculate the Manhattan distance between snake head and item.
            And find the possible direction to the item, at most 2.

            :return: (dist, possible_direction)
            """
            x1, y1 = pos1[0], pos1[1]
            x2, y2 = pos2[0], pos2[1]
            pos = []
            if x1 > x2:
                pos.append(0)
            if x1 < x2:
                pos.append(2)
            if y1 > y2:
                pos.append(1)
            if y1 < y2:
                pos.append(3)
            return abs(x1 - x2) + abs(y1 - y2), pos

        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0:
            return self.alive()
        # calculate the legal moves without concerning the enemy
        # 更新敌人信息
        if self.enemy_id >= 0 and self.ctx.get_snake(self.enemy_id) is None:
            self.enemy_id = -1
        coor = self.snake.coor_list
        dist, val, enemy_id = INF, [], self.enemy_id
        if enemy_id >= 0:
            head = self.ctx.get_snake(enemy_id).coor_list[0]
            d, pos = calc_dist(head, coor[0])
            val = [i for i in pos if i in valid]
        else:
            enemy_list = self.ctx.get_player_snake(1 - self.snake.camp)
            # enemy_head = []
            for enemy in enemy_list:
                head = enemy.coor_list[0]
                d, pos = calc_dist(head, coor[0])
                pos = [i for i in pos if i in valid]
                # use legal move only

                if len(pos) > 0 and d < dist:
                    dist, val = d, pos
                    self.enemy_id = enemy.id
                # search reachable food only
                # not that the span of a snake is at least SPLIT_LIMIT / 2

            # chose the closest reachable food and use legal move
        # print(valid)
        if len(val) == 0:
            # print(valid)
            val = valid
        i = random.randint(0, len(val) - 1)
        # print('op: ' + str(val[i]))
        # randomly chose one if multiple available

        return val[i]


    def judge(self, current_player, player, controller, use_old=False):
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        """
        self.ctx = controller.ctx
        self.controller = controller
        self.current_player = current_player
        self.player = player
        self.use_old = use_old
        self.snake = controller.current_snake_list[controller.next_snake][0]
        if self.ctx.get_snake_count(1 - self.snake.camp) == 0: # 如果对手无了
            mode_list = [2, 0, 2] # 两条蛇吃东西，两条蛇固化
        elif self.ctx.turn < 384:
            mode_list = [3, 0, 1] # 两条蛇使用mode0，一条蛇使用mode1，一条蛇使用mode2
        else:
            mode_list = [3, 0, 1]
        if self.snake.mode == -1 or self.snake.get_len() <= MAX_length:
            self.snake.mode = 0
        if self.snake.mode == 0 and self.snake.get_len() > MAX_length:
            snakelist = self.ctx.get_player_snake(self.snake.camp)
            for other_snake in snakelist:
                if other_snake.id != self.snake.id and other_snake.mode >= 0:
                    mode_list[other_snake.mode] -= 1
            for k in range(3):
                if mode_list[k] > 0:
                    self.snake.mode = k
                    break
        if self.snake.mode == 1 and self.snake.get_len() > MAX_length + 5:
            self.snake.mode = 2
        
        if self.snake.mode == 1: # 干扰对手
            op = self.closest_food_new() + 1
        elif self.snake.mode == 0:
            op = self.active_strategy() # 寻找食物
        else: # self.snake.mode == 2:
            op = self.passive_strategy()
        return op, self.snake.mode
    
    def enemy_judge(self, current_player, player, controller, use_old=False):
        self.ctx = controller.ctx
        self.controller = controller
        self.current_player = current_player
        self.player = player
        self.snake = controller.current_snake_list[controller.next_snake][0]
        self.use_old = use_old
        op = self.active_strategy()
        return op

def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0
    # print(player)
    global SEARCH_LIMIT
    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI()
    enemy_die = 1
    while playing:
        if controller.ctx.turn < 100:
            SEARCH_LIMIT = 16
        elif controller.ctx.turn < 200:
            SEARCH_LIMIT = 16
        else:
            SEARCH_LIMIT = 32
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            if enemy_die and controller.ctx.get_snake_count(1 - player) == 0: # 敌方无了
                for k in range(len(controller.ctx.snake_list)):
                    if controller.ctx.snake_list[k].camp == player:
                        if controller.ctx.snake_list[k].mode == 1:
                            controller.ctx.snake_list[k].mode = 2
                enemy_die = 0
            ai.ctx = controller.ctx
            ai.player = player
            ai.current_player = player
            ai.controller = controller
            key_list = list(ai.item_target.keys())
            snake_map = controller.ctx.get_map().snake_map
            wall_map = controller.ctx.get_map().wall_map
            if len(key_list) > 0:
                for key in key_list:
                    # 判断道具是否失效或被捡起
                    item = controller.ctx.get_map().get_map_item(key)
                    if item == None or item.gotten_time != -1 or item.time > controller.ctx.turn + SEARCH_LIMIT \
                            or item.time + 16 < controller.ctx.turn or controller.ctx.get_snake(ai.item_target[key][0]) == None\
                                or snake_map[item.x][item.y] != -1 or wall_map[item.x][item.y] != -1:
                        ai.item_target.pop(key)
                 
                    
            for k in range(2):
                snake_list = controller.ctx.get_player_snake(player)
                for snake in snake_list:
                    if snake.mode <= 1:
                        ai.snake = snake
                        ai.update_item_target()
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op, mode = ai.judge(current_player, player, controller)  # TODO: Complete the Judge Function
                # print(op)
                # print(ai.item_target)
                controller.current_snake_list[controller.next_snake][0].mode = mode
                logging.debug(str(op))
                if not controller.apply(op):
                    sys.stderr.write(str(op))
                    raise RuntimeError("Illegal Action!!! " + str(op))
                c.send_data(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player

    # while True:
    #     pass



def search(current_player, player, controller, max_round):
    score = np.zeros(36)
    rd = np.zeros(36)
    op = -1
    score_max = -1000
    round_max = 1000
    if controller.ctx.get_snake_count(player) < 3:
        for k in range(36):
            op1 = k % 6 + 1
            op2 = int((k - op1)/ 6) + 1
            score[k], rd[k] = search_op(copy.deepcopy(current_player), copy.deepcopy(player), copy.deepcopy(controller), op1, op2, max_round)
            if score[k] > score_max:
                op = op1
                score_max = score[k]
                round_max = rd[k]
            elif score[k] == score_max and rd[k] < round_max:
                op = op1
                score_max = score[k]
                round_max = rd[k]
            else:
                pass
    else:
        for k in range(6):
            score[k], rd[k] = search_op1(copy.deepcopy(current_player), copy.deepcopy(player), copy.deepcopy(controller), k+1, max_round)
            if score[k] > score_max:
                op = k + 1
                score_max = score[k]
                round_max = rd[k]
            elif score[k] == score_max and rd[k] < round_max:
                op = k + 1
                score_max = score[k]
                round_max = rd[k]
            else:
                pass
    return op


def search_op(current_player, player, controller, op_m, op_m2, max_round):
    ai = AI()
    score = 0
    flag = 1
    flag1 = 1
    flag_die = 0
    score_max = -500
    round_max = -1
    now_id = -1
    for djaidj in range(max_round):
        score = 0
        if current_player == 0 and not flag:
            controller.round_preprocess()
        if not flag:
            controller.round_init()
        
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                if flag:
                    mymap = controller.ctx.get_map()
                    enemy_wall_before = np.sum(np.sum(np.array(mymap.wall_map) == 1 - player))
                    my_wall_before = np.sum(np.sum(np.array(mymap.wall_map) == player))
                current_snake = controller.current_snake_list[controller.next_snake][0]
                # print(current_snake)
                # op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
                
                # print(str(op_m) + ': ' + str(op))
                if flag:
                    op = op_m
                    now_id = current_snake.id
                    head_x = current_snake.coor_list[0][0]
                    head_y = current_snake.coor_list[0][1]
                    # wall_map = 
                    if op == 1:
                        head_x += 1
                    elif op == 2:
                        head_y += 1
                    elif op == 3:
                        head_x -= 1
                    elif op == 4:
                        head_y -= 1
                    else:
                        pass
                    notuesed = ai.judge(current_player, player, controller)
                    if op <= 4 and not ai.check_self(op-1) and len(current_snake.coor_list) > 4:
                        score = score - 200
                elif flag1:
                    op = op_m2
                    flag1 = 0
                else:
                    op = ai.judge(current_player, player, controller)  # TODO: Complete the Judge Function
                    # print(op)
                # logging.debug(str(op))
                # print(op)

                if not controller.apply(op):
                    if flag or flag1:
                        score = score - 1000
                        score_max = score
                        round_max = djaidj
                        flag_die = 1
                    # print('Illegal Action!!!' + str(op))
                    flag = 0
                    break
                else:
                    if flag and op == 6:
                        if len(current_snake.coor_list) > MAX_length and controller.ctx.turn > 100:
                            score = score + 100
                mymap = controller.ctx.get_map()
                enemy_wall_end = np.sum(np.sum(np.array(mymap.wall_map) == 1 - player))
                my_wall_end = np.sum(np.sum(np.array(mymap.wall_map) == player))
                if flag and op == 5:

                    score += (my_wall_end - my_wall_before + enemy_wall_before - enemy_wall_end) * 10
                else:
                    score += (my_wall_end - my_wall_before + enemy_wall_before - enemy_wall_end) * 0.05


                flag = 0
            controller.next_player()

        
        else:
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op, mode = ai.judge(current_player, player, controller)  # TODO: Complete the Judge Function
                controller.current_snake_list[controller.next_snake][0].mode = mode
                # logging.debug(str(op))
                # print(op)
                if not controller.apply(op):
                    break
                    # pass

            controller.next_player()
        if flag_die:
            break
        
        current_player = 1 - current_player
        if controller.snake_num == 0:
            break
        
        # print(5)
        mymap = controller.ctx.get_map()
        
        snake_list = controller.ctx.get_player_snake(player)
        for snake in snake_list:
            snake_length = np.sum(np.sum(np.array(mymap.snake_map) == snake.id))
            if snake.id == now_id:
                score = score  + 1.5 * (snake_length + snake.length_bank)
                # if snake_length > 16:
                #     score -= 100
                score = score + len(snake.item_list)
            else:
                # pass
                score = score  + 0.8 * (snake_length + snake.length_bank)
        # print(mymap.snake_map)
        # print(my_wall)
        score = score - 0.001*djaidj
        score -= 0.0001 * (head_x - 8) * (head_x - 8) + 0.0001 * (head_y - 8) * (head_y - 8)
        # print(score)
        if score > score_max:
            score_max = score
            round_max = djaidj
    # controller.search_end()
    # print(score)
    return score_max, round_max


def search_op1(current_player, player, controller, op_m, max_round):
    ai = AI()
    flag = 1
    solid_flag = 0
    flag_die = 0
    # print(op_m)
    for djaidj in range(max_round):
        if current_player == 0 and not flag:
            controller.round_preprocess()
        if not flag:
            controller.round_init()
        
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                if flag:
                    op = op_m
                    now_id = current_snake.id
                else:
                    op, mode = ai.judge(current_player, player, controller, use_old=True)  # TODO: Complete the Judge Function
                    controller.current_snake_list[controller.next_snake][0].mode = mode
                if current_snake.id == now_id:
                    headx = current_snake.coor_list[0][0]
                    heady = current_snake.coor_list[0][1]
                if not controller.apply(op):
                    if flag:
                        flag_die = 1
                    flag = 0
                    break
                elif current_snake.id == now_id and controller.ctx.get_map().wall_map[headx][heady] == player:
                    solid_flag = 1
                flag = 0
            controller.next_player()
        else:
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op = ai.enemy_judge(current_player, player, controller, use_old=True)  # TODO: Complete the Judge Function
                if not controller.apply(op):
                    break
            controller.next_player()
        if flag_die:
            break
        current_player = 1 - current_player
        if controller.snake_num == 0:
            break
    # if solid_flag:
    #     # print(solid_flag)
    #     return True
    # else:   
    return not (controller.ctx.get_snake(now_id) == None or flag_die)

def calculate_distance(current_player, player, controller, end):
    ai = AI()
    ai.use_old = True
    current_snake = controller.current_snake_list[controller.next_snake][0]
    ai.player = current_snake.camp
    ai.current_player = ai.player
    cnt = 0
    while abs(current_snake.coor_list[0][0] - end[0]) + abs(current_snake.coor_list[0][1] - end[1]) > 1:
        ai.ctx = controller.ctx
        ai.snake = current_snake
        # self.order = dict()
        ai.enemy_id = -1
        ai.controller = controller
        op = ai.go_to(end, use_old=True) + 1
        controller.apply(op)
        current_snake = controller.current_snake_list[controller.next_snake][0]
        cnt += 1
        if cnt > 32:
            break
    return cnt
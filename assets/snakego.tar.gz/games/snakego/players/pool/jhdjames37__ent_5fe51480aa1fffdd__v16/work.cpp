#include "adk.hpp"



Operation
work( const Snake &snake_to_operate, const Context &ctx );

#include "adk.hpp"
#include <cmath>
#include <cstdio>

#define debug(...) fprintf(stderr, __VA_ARGS__)

/* 
 * Partially copied from demo
 * delete comments to make it tight
 * Invalid move => -1
 * Dead move => 0
 * Valid move => 1
 * Seal move => 2
 */
void check_valid_move(const Snake &snake_to_operate,
                      const Context &ctx,
                      int* move) {
  if ( snake_to_operate.railgun_item.id != -1
       && snake_to_operate.length() > 1) {
    move[5] = 1;
  } else {
    move[5] = -1;
  }
  
  if (snake_to_operate.length() > 1 &&
      ctx.my_snakes().size() < 4) {
    move[4] = 1;
  } else {
    move[4] = -1;
  }
  
  int dx[4] = { 1, 0, -1, 0 };
  int dy[4] = { 0, 1, 0, -1 };
  for ( int dir = 0; dir < 4; dir++ ) {
    int tx = snake_to_operate[0].x + dx[dir];
    int ty = snake_to_operate[0].y + dy[dir];    
    if ( tx >= ctx.length() || tx < 0 ||
         ty >= ctx.width() || ty < 0 ) {
      move[dir] = 0;
      continue;
    }
    if ( ctx.wall_map()[tx][ty] != -1 ) {
      move[dir] = 0;
      continue;
    }
    if ( ctx.snake_map()[tx][ty] != -1 &&
         ctx.snake_map()[tx][ty] != snake_to_operate.id ) {
      move[dir] = 0;
      continue;
    }
    
    if ( (snake_to_operate.length() > 2
          || (snake_to_operate.length() == 2 &&
              snake_to_operate.length_bank > 0)) &&
         snake_to_operate[1].x == tx &&
         snake_to_operate[1].y == ty ) {
      move[dir] = -1;
      continue;
    }
    if ( ctx.snake_map()[tx][ty] == snake_to_operate.id &&
         (snake_to_operate.coord_list.back() != (Coord){tx, ty} ||
          (snake_to_operate.coord_list.back() == (Coord){tx, ty} &&
           snake_to_operate.length_bank > 0))) {
      move[dir] = 2;
      continue;
    }
    move[dir] = 1;
  }
}

Operation
work( const Snake &snake, const Context &ctx ) {
  const Operation direction[6] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN, OP_SPLIT, OP_RAILGUN};
  const int dx[4] = { 1, 0, -1, 0 };
  const int dy[4] = { 0, 1, 0, -1 };

  int move[6];
  check_valid_move(snake, ctx, move);
  /*
  fprintf(stderr, "Snake: id = %d, len = %lu\nCoords: ", snake.id, snake.length());
  for (const auto &i : snake.coord_list) {
    fprintf(stderr, "(%d, %d) ", i.x, i.y);
  }
  fprintf(stderr, "\n");
  */
  //fprintf(stderr, "Move: %d %d %d %d %d %d\n", move[0], move[1], move[2], move[3], move[4], move[5]);
  if (move[5] == 1) return direction[5];
  
  if ( snake == ctx.my_snakes()[0] ) {
    if ( snake.length() >= 10 ) {
      if (move[4] == 1) 
        return OP_SPLIT;
    }
  }
  
  //玩家操控的首条蛇朝向道具移动
  if ( snake == ctx.my_snakes()[0] ) {
    for ( int i = 0; i < ctx.item_list().size(); i++ ) {
      //道具已经消失
      if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() )
        continue;

      //计算蛇头与道具的距离
      int distance = abs( ctx.item_list()[i].x - snake[0].x ) +
        abs( ctx.item_list()[i].y - snake[0].y );

      //忽略其他因素理论上能吃到该道具
      if ( ctx.item_list()[i].time <= ctx.current_round() + distance &&
           ctx.item_list()[i].time + 16 > ctx.current_round() + distance ) {
        for ( int dir = 0; dir < 4; dir++ ) {
          //移动不合法或固化
          if ( move[dir] != 1 )
            continue;
                  
          //朝向道具方向移动
          int t_x = snake[0].x + dx[dir];
          int t_y = snake[0].y + dy[dir];
          int dis = abs( ctx.item_list()[i].x - t_x ) + abs( ctx.item_list()[i].y - t_y );
          if ( dis <= distance ) {
            return direction[dir];
          }
        }
      }
    }
  }
  
  //其他蛇优先固化，或朝向蛇尾方向移动
  else {

    int distance = abs( snake.coord_list.back().x - snake.coord_list[0].x ) +
      abs( snake.coord_list.back().y - snake.coord_list[0].y );
    for ( int dir = 0; dir < 4; dir++ ) {
      if ( move[dir] == -1 || move[dir] == 0 )
        continue;

      if ( move[dir] == 2 ) {
        return direction[dir];
      }
      int t_x = snake.coord_list[0].x + dx[dir];
      int t_y = snake.coord_list[0].y + dy[dir];
      int dis = abs( snake.coord_list.back().x - t_x ) +
        abs( snake.coord_list.back().y - t_y );
      if ( dis <= distance ) {
        return direction[dir];
      }
    }
  }
  
  for ( int dir = 0; dir < 6; dir++ ) {
    if ( move[dir] == 1 ) {
      return direction[dir];
    }
  }
  for (int dir = 0; dir < 4; dir++) {
    if (move[dir] == 2) return direction[dir];
  }
  for ( int dir = 0; dir < 6; dir++ ) {
    if ( move[dir] == 0 ) {
      return direction[dir];
    }
  }
  return OP_RIGHT;
}

Operation make_your_decision( const Snake &snake_to_operate, const Context &ctx ) {
  static int round = 0;
  ++round;
  //fprintf(stderr, "Operation %d Started\n", round);

  auto res = work(snake_to_operate, ctx);
  
  const char* type[] = {
    "",
    "RI",
    "UP",
    "LE",
    "DO",
    "RA",
    "SP"
  };
  
  //fprintf(stderr, "Round %d, operation %d Ended, snake id = %d, made decision %s\n", ctx.current_round(), round, snake_to_operate.id, type[res.type]);
  fprintf(stderr, "%d-%d, %s\n", ctx.current_round(), snake_to_operate.id, type[res.type]);

  return res;
}


void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
  fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char **argv )
{
  SnakeGoAI start( argc, argv );
}

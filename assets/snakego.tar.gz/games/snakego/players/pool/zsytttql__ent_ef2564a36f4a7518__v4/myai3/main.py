import sampleAI

if __name__ == '__main__':
    sampleAI.run()


# cmd1 = "judger_cli --port 53024 --playerCount 2 --output /mnt/d/学习/SnakeGo/output --logicPath /mnt/d/学习/SnakeGo/logic-dist/logic-linux/main/main"
# cmd2 = "python /mnt/d/学习/SnakeGo/ai/myai3/main.py 127.0.0.1 53024"
# cmd3 = "python /mnt/d/学习/SnakeGo/ai/myai2/main.py 127.0.0.1 53024"
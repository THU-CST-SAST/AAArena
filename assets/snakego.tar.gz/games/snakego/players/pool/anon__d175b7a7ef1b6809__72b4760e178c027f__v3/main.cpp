#include "adk.hpp"
#include <cmath>
#include<vector>
#include<queue>
#include<string.h>
using namespace std;

const int dx[4] = { 1, 0, -1, 0 };
const int dy[4] = { 0, 1, 0, -1 };
const Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
int movement[4];

// debug
Coord aim;
int snake_num;
int round_num;

class Info{
	public:

	int prop_map[50][50];
	int dis_map[50][50];
	bool visit[50][50];
	Coord from[50][50];

	
	void Init();
	void PropMapInit(const Snake& snake_to_operate, const Context& ctx);
	void DisMapInit(const Snake& snake_to_operate, const Context& ctx);
	int NearestProp(const Snake& snake_to_operate, const Context& ctx);
	int PorpOrientate(int index, const Snake& snake_to_operate, const Context& ctx);
} info;

void InfoInit(const Snake& snake_to_operate, const Context& ctx);
void MovemetnSet(const Snake& snake_to_operate, const Context& ctx);
bool GrowCheck(const Snake& snake_to_operate, const Context& ctx);
bool BoundaryCheck(int x, int y, const Context& ctx);
bool EmptyCheck(int x, int y, const Context& ctx);
bool MeltStrategy(const Snake& snake_to_operate, const Context& ctx);
bool SplitStrategy(const Snake& snake_to_operate, const Context& ctx);


Operation make_your_decision( const Snake& snake_to_operate, const Context& ctx, const OpHistory& op_list ){
	snake_num = snake_to_operate.id;
	round_num = ctx.current_round();

	// init part
	MovemetnSet(snake_to_operate, ctx);
	InfoInit(snake_to_operate, ctx);

	// strategy part
	if(MeltStrategy(snake_to_operate, ctx)){
		return OP_RAILGUN;
	}
	if(SplitStrategy(snake_to_operate, ctx)){
		return OP_SPLIT;
	}

	int prop_ret = info.NearestProp(snake_to_operate, ctx);
	if(prop_ret != -1){
		aim.x = ctx.item_list()[prop_ret].x;
		aim.y = ctx.item_list()[prop_ret].y;
		return direction[info.PorpOrientate(prop_ret, snake_to_operate, ctx)];
	}

	for(int i = 0; i < 4; i++){
		if(movement[i] == 0){
			return direction[i];
		}
	}

	for(int i = 0; i < 4; i++){
		if(movement[i] == 1){
			return direction[i];
		}
	}

	for(int i = 0; i < 4; i++){
		if(movement[i] == -1){
			return direction[i];
		}
	}


}

void game_over( int gameover_type, int winner, int p0_score, int p1_score ){
	// fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
	fprintf( stderr, "%s %d", "round:", round_num );
	fprintf( stderr, "%s %d", "snake:", snake_num );

	for(int i = 0; i < 16; i++){
		for(int j = 0; j < 16; j++){
			int temp = info.dis_map[i][j];
			if(temp > 99){
				fprintf( stderr, "%d ", temp );
			}else if(temp > 9){
				fprintf( stderr, " %d ", temp );
			}else{
				fprintf( stderr, "  %d ", temp );
			}
		}
		fprintf( stderr, "\n" );
	}
}

int main( int argc, char** argv ) { SnakeGoAI start( argc, argv ); }


void InfoInit(const Snake& snake_to_operate, const Context& ctx){
	info.Init();
	info.PropMapInit(snake_to_operate, ctx);
	info.DisMapInit(snake_to_operate, ctx);
}
void MovemetnSet(const Snake& snake_to_operate, const Context& ctx){
	for(int i = 0; i < 4; i++){
		movement[i] = 0;
	}
	
	// we claim that
	//-2 for illegal action, -1 for kill itself
	// 0 for normal move, 1 for solidation
	Coord head = snake_to_operate[0];
	for(int i = 0; i < 4; i++){
		Coord target;
		target.x = head.x + dx[i];
		target.y = head.y + dy[i];

		// dash against boundary
		if(BoundaryCheck(target.x, target.y, ctx) == false){
			movement[i] = -1;
			continue;
		}

		// empty place
		if(EmptyCheck(target.x, target.y, ctx)){
			movement[i] = 0;
			continue;
		}

		// dash agianst wall
		if(ctx.wall_map()[target.x][target.y] != -1){
			movement[i] = -1;
			continue;
		}

		// dash agianst other snake
		if(ctx.snake_map()[target.x][target.y] != -1 && ctx.snake_map()[target.x][target.y] != snake_to_operate.id){
			movement[i] = -1;
			continue;
		}

		// dash aginast itself
		if(ctx.snake_map()[target.x][target.y] != -1 && ctx.snake_map()[target.x][target.y] != snake_to_operate.id){
			if(snake_to_operate.length() > 2){
				movement[i] = -2;
				continue;
			}
			if(snake_to_operate.length() == 2 && GrowCheck(snake_to_operate, ctx)){
				movement[i] = -2;
				continue;
			}
		}

	}
}
bool GrowCheck(const Snake& snake_to_operate, const Context& ctx){
	if(snake_to_operate.length_bank > 0){
		return true;
	}
	if(ctx.current_round() <= 8){
		return true;
	}
	return false;
}
bool BoundaryCheck(int x, int y, const Context& ctx){
	if(x < 0 || x >= ctx.length() || y < 0 || y >= ctx.width()){
		return false;
	}
	return true;
}
bool EmptyCheck(int x, int y, const Context& ctx){
	if(x < 0 || x >= ctx.length() || y < 0 || y >= ctx.width()){
		return false;
	}
	if(ctx.wall_map()[x][y] != -1){
		return false;
	}
	if(ctx.snake_map()[x][y] != -1){
		return false;
	}
	return true;
}
bool MeltStrategy(const Snake& snake_to_operate, const Context& ctx){
	if(snake_to_operate.railgun_item.id == 1 || snake_to_operate.length() < 2){
		return false;
	}

	Coord head = snake_to_operate[0];
	Coord neck = snake_to_operate[1];

	int dir = 0;
	int counter = 0;

	if(head.x == neck.x){
		dir = head.y - neck.y;
		for(int i = head.y; 0 <= i && i < ctx.width(); i += dir){
			if(ctx.wall_map()[head.x][i] == -1){
				continue;
			}else if(ctx.wall_map()[head.x][i] == ctx.current_player()){
				// ally
				counter--;
			}else{
				// enemy
				counter++;
			}
		}
		if(counter > 0){
			return true;
		}else{
			return false;
		}
	}

	if(head.y == neck.y){
		dir = head.x - neck.x;
		for(int i = head.x; 0 <= i && i < ctx.length(); i += dir){
			if(ctx.wall_map()[i][head.y] == -1){
				continue;
			}else if(ctx.wall_map()[i][head.y] == ctx.current_player()){
				// ally
				counter--;
			}else{
				// enemy
				counter++;
			}
		}
		if(counter > 0){
			return true;
		}else{
			return false;
		}
	}
}
bool SplitStrategy(const Snake& snake_to_operate, const Context& ctx){
	if(snake_to_operate.length() > 10 && ctx.my_snakes().size() < 4){
		return true;
	}
	return false;
}

void Info::Init(){
	memset(prop_map, -1, sizeof(prop_map));
	for(int i = 0; i < 50; i++){
		for(int j = 0; j < 50; j++){
			dis_map[i][j] = 999;
		}
	}
	memset(visit, 0, sizeof(visit));
	
	for(int i = 0; i < 50; i++){
		for(int j = 0; j < 50; j++){
			from[i][j].x = -1;
			from[i][j].y = -1;
		}
	}

}
void Info::PropMapInit(const Snake& snake_to_operate, const Context& ctx){
	for ( int i = 0; i < ctx.item_list().size(); i++ ){
		//道具已经消失
		if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() ){
			continue;
		}

		Coord prop;
		prop.x = ctx.item_list()[i].x;
		prop.y = ctx.item_list()[i].y;

		if(EmptyCheck(prop.x, prop.y, ctx) == false){
			continue;
		}

		//计算蛇头与道具的距离
		int distance = abs( ctx.item_list()[i].x - snake_to_operate[0].x ) +
						abs( ctx.item_list()[i].y - snake_to_operate[0].y );

		//忽略其他因素理论上能吃到该道具
		if ( ctx.item_list()[i].time <= ctx.current_round() + distance &&
				ctx.item_list()[i].time + 16 > ctx.current_round() + distance ){
			prop_map[prop.x][prop.y] = i;
		}

	}

}

void Info::DisMapInit(const Snake& snake_to_operate, const Context& ctx){
	Coord head = snake_to_operate[0];

	queue<Coord> q;
	q.push(head);
	dis_map[head.x][head.y] = 0;

	while(!q.empty()){
		Coord current = q.front();
		q.pop();

		for(int i = 0; i < 4; i++){
			Coord target;
			target.x = current.x + dx[i];
			target.y = current.y + dy[i];

			if(EmptyCheck(target.x, target.y, ctx) && dis_map[target.x][target.y] == 999){
				q.push(target);
				dis_map[target.x][target.y] = dis_map[current.x][current.y] + 1;
				from[target.x][target.y] = current;
				visit[target.x][target.y] = true;
			}
		}
	}

}

int Info::NearestProp(const Snake& snake_to_operate, const Context& ctx){
	int min_num = 0;
	int min_dis = 999;
	for(int i = 0; i < ctx.length(); i++){
		for(int j = 0; j < ctx.width(); j++){
			if(prop_map[i][j] == -1){
				continue;
			}

			if(visit[i][j] == false){
				continue;
			}

			if(dis_map[i][j] < min_dis){
				min_dis = dis_map[i][j];
				min_num = prop_map[i][j];
			}
		}
	}
	if(min_dis == 999){
		return -1;
	}

	visit[ctx.item_list()[min_num].x][ctx.item_list()[min_num].y] = false;
	return min_num;
}

int Info::PorpOrientate(int index, const Snake& snake_to_operate, const Context& ctx){
	Coord head = snake_to_operate[0];

	Coord prop;
	prop.x = ctx.item_list()[index].x;
	prop.y = ctx.item_list()[index].y;

	Coord current = prop;
	Coord next = from[current.x][current.y];

	while(!(next == head)){
		current = next;
		next = from[current.x][current.y];
	}

	if(current.x == head.x){
		if(current.y > head.y){
			// go up
			return 1;
		}
		if(current.y < head.y){
			// down
			return 3;
		}
	}

	if(current.y == head.y){
		if(current.x > head.x){
			// right
			return 0;
		}
		if(current.x < head.x){
			// left
			return 2;
		}
	}
	
}

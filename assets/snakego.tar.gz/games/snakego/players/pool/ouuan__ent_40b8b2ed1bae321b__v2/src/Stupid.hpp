#pragma once

#include "Agent.hpp"

class Stupid : public Agent
{
   public:
    explicit Stupid(int argc, char **argv) : Agent(argc, argv)
    {}

   private:
    Operation nextMove(const Logic *o) const override;
};

#include "Channel.hpp"

#ifdef ADK_POSIX

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>

PosixSocket::PosixSocket(int internal_socket) : internal_socket(internal_socket)
{}

PosixSocket::~PosixSocket()
{
    close(internal_socket);
}

bool PosixSocket::send(char *msg, size_t len)
{
    return ::send(internal_socket, msg, len, 0) != -1;
}

bool PosixSocket::recv(char *buf, size_t len)
{
    return ::recv(internal_socket, buf, len, 0) == len;
}

Channel *socket_channel(const std::string &host, unsigned int port)
{
    int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == -1)
        return nullptr;

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(host.c_str());
    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == -1)
        return nullptr;

    return new PosixSocket(sock);
}

#endif

#ifdef ADK_WIN

WindowsSocket::WindowsSocket(SOCKET internal_socket) : internal_socket(internal_socket)
{}

WindowsSocket::~WindowsSocket()
{
    shutdown(internal_socket, SD_SEND);
    closesocket(internal_socket);
    WSACleanup();
}

bool WindowsSocket::send(char *msg, size_t len)
{
    return ::send(internal_socket, msg, len, 0) != SOCKET_ERROR;
}

bool WindowsSocket::recv(char *buf, size_t len)
{
    return ::recv(internal_socket, buf, len, 0) == len;
}

Channel *socket_channel(const std::string &host, unsigned int port)
{
    WSADATA wsaData;
    int iResult;

    SOCKET ConnectSocket = INVALID_SOCKET;
    struct sockaddr_in clientService;

    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != NO_ERROR)
    {
        fprintf(stderr, "WSAStartup failed: %d\n", iResult);
        return nullptr;
    }

    ConnectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (ConnectSocket == INVALID_SOCKET)
    {
        fprintf(stderr, "Error at socket(): %ld\n", WSAGetLastError());
        WSACleanup();
        return nullptr;
    }

    clientService.sin_family = AF_INET;
    clientService.sin_addr.s_addr = inet_addr(host.c_str());
    clientService.sin_port = htons(port);

    iResult = connect(ConnectSocket, (SOCKADDR *)&clientService, sizeof(clientService));
    if (iResult == SOCKET_ERROR)
    {
        closesocket(ConnectSocket);
        fprintf(stderr, "Unable to connect to server: %ld\n", WSAGetLastError());
        WSACleanup();
        return nullptr;
    }

    return new WindowsSocket(ConnectSocket);
}

#endif

StdIO::~StdIO() = default;

bool StdIO::send(char *msg, size_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        putchar(msg[i]);
    }
    fflush(stdout);
    return true;
}

bool StdIO::recv(char *buf, size_t len)
{
    size_t cnt = 0;
    while (cnt < len)
    {
        int c = getchar();
        if (c == EOF)
        {
            return false;
        }
        buf[cnt++] = (char)c;
    }
    return true;
}

Channel *stdio_channel()
{
    return new StdIO();
}

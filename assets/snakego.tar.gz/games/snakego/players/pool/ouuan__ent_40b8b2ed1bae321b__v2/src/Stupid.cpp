#include "Stupid.hpp"

Operation Stupid::nextMove(const Logic *o) const
{
    return o->validMoves().front();
}

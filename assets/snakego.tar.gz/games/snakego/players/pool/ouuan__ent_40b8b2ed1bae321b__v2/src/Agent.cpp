#include "Agent.hpp"

#include <cassert>
#include <iostream>

Agent::Agent(int argc, char **argv)
{
    if (argc == 1)
        ch = stdio_channel();
    else if (argc == 3)
        ch = socket_channel(argv[1], atoi(argv[2]));

    if (ch == nullptr)
    {
        fprintf(stderr, "Failed to init channel\n");
        crash();
    }

    int length = readShort(), width = readShort(), maxRound = readInt();
    player = (Player)readShort();

    assert(length == SIZE);
    assert(width == SIZE);
    assert(maxRound == MAX_ROUND);

    const auto [itemList, itemTimeList] = readItemList();
    logic = new Logic(itemList, itemTimeList);
}

void Agent::run()
{
    while (true)
    {
        if (player == logic->player())
        {
            Operation op = nextMove(logic);
            logic->handleMove(op);
            char msg[] = {0, 0, 0, 1, (char)op};
            bool send_ok = ch->send(msg, 5);
            int ack_type = readShort();
            if (ack_type == 0x11)
                handleGameover();
            else if (!send_ok || ack_type != op)
                crash();
        }
        else
        {
            int type = readShort();
            if (type >= 1 && type <= 6)
                logic->handleMove(Operation(type));
            else if (type == 0x11)
                handleGameover();
            else
                crash();
        }
    }
}

Agent::~Agent()
{
    delete ch;
    delete logic;
}

int Agent::readShort()
{
    static char c = 0;
    if (!ch->recv(&c, 1))
        crash();
    return c;
}

#define BIG_ENDIAN_INT(C1, C2) \
    (((static_cast<unsigned char>(C1) << 8) | (static_cast<unsigned char>(C2))) & 0xFFFF)

int Agent::readInt()
{
    static char c[] = {0, 0};
    if (!ch->recv(c, 2))
        crash();
    return BIG_ENDIAN_INT(c[0], c[1]);
}

std::pair<vector<Item>, vector<int>> Agent::readItemList()
{
    if (readShort() != 0x10)
        crash();

    int itemCount = readInt();
    if (itemCount <= 0)
        crash();
    char *buf = new char[7 * itemCount];
    if (!ch->recv(buf, 7 * itemCount))
        crash();

    vector<Item> itemList(itemCount);
    vector<int> itemTimeList(itemCount);

    for (int i = 0; i < itemCount; i++)
    {
        auto &item = itemList[i];
        item.coordinate.x = buf[7 * i];
        item.coordinate.y = buf[7 * i + 1];
        itemTimeList[i] = BIG_ENDIAN_INT(buf[7 * i + 3], buf[7 * i + 4]);
        item.param = BIG_ENDIAN_INT(buf[7 * i + 5], buf[7 * i + 6]);
    }

    return {itemList, itemTimeList};
}

void Agent::handleGameover()
{
    static char dummy[] = {0, 0, 0, 1, 1};
    int gameover_type = readShort(), winner = readShort(), p0_score = readInt(),
        p1_score = readInt();
    ch->send(dummy, 5);  // wait for connection broke
    ::exit(0);
}

void Agent::crash()
{
    ::exit(-1);
}

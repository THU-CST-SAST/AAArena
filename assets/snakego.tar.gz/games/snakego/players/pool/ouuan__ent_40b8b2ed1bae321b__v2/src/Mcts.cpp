#include "Mcts.hpp"

static const int TIME_LIMIT = 950;

Operation Mcts::nextMove(const Logic* o) const
{
    return Operation();
}

bool Mcts::timeout() const
{
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now() - start).count() > TIME_LIMIT;
}

double Mcts::search(MctsNode* u)
{
    return 0;
}

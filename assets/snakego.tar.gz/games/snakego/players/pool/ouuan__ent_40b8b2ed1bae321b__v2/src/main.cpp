#include "Mcts.hpp"
#include "Stupid.hpp"

int main(int argc, char **argv)
{
    Stupid  //
        agent(argc, argv);
    agent.run();
}

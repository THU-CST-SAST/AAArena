#pragma once

#include <chrono>
#include <cmath>

#include "Agent.hpp"

static const double MCTS_C = 1.4;

struct MctsNode
{
    int visit;
    double totalOffensiveWin;
    Player first;
    MctsNode* parent = nullptr;
    Operation op;
    bool isEnd;
    double selfOffensiveWin;
    vector<MctsNode*> children;

    void update(double offensiveWin)
    {
        totalOffensiveWin += offensiveWin;
        ++visit;
    }

    double uct(Player player)
    {
        double win = player == Offensive ? totalOffensiveWin : visit - totalOffensiveWin;
        return win / visit + MCTS_C * std::sqrt(std::log(parent->visit) / visit);
    }
};

class Mcts : public Agent
{
   public:
    explicit Mcts(int argc, char** argv) : Agent(argc, argv)
    {}

   private:
    Operation nextMove(const Logic* o) const override;

    bool timeout() const;

    double search(MctsNode* u);

   private:
    std::chrono::time_point<std::chrono::steady_clock> start;
};

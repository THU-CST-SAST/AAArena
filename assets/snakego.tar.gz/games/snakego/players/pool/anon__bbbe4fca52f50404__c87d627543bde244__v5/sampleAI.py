from adk import *
import numpy as np

# written by lbr

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
INF = 1e9
# constants

SPLIT_LIMIT = 10
SEARCH_LIMIT = 100
SNAKE_LIMIT = 3
# tunable parameters

def mdis(x1, y1, x2, y2):
    return abs(x1-x2)+abs(y1-y2)

class AI:
    """
    This AI proceeds according to following rules:

    The first snake is active, all other snakes split by the first snake are passive.

    An active snake will act according to self.active_strategy.

    A passive snake will act according to self.passive_strategy.

    Check those functions for detail.
    """
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()

    ######################
    # condition checkers #
    ######################
    
    def check(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        # check wall and out of bounds
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        # check turn back
        if self.ctx.game_map.snake_map[x][y] != -1:
            return False
        # check other snake
        return True

    def check_legal(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16:
            return False
        # check out of bounds
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        # check turn back
        return True
    
    def check_self(self, op):
        """
        :param op: the direction
        :return: True if this move is legal, could possibly result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
            return False
        return True
    
    def check_blocks(self):# If it is worthy to fire
        Map = self.ctx.get_map()
        Maplen = Map.length
        Mapwid = Map.width
        wall = np.array(Map.wall_map)
        me = self.snake.camp
        my_wall = (wall == me).astype('int')
        opponent_wall = (wall == 1 - me).astype('int')
        x_head, y_head = self.snake.coor_list[0]
        x_neck, y_neck = self.snake.coor_list[1]
        """
        sys.stderr.write(f'Maplen={Maplen}, Mapwid={Mapwid}')
        sys.stderr.write(f'my_wall={my_wall}')
        sys.stderr.write(f'x_head={x_head}, y_head={y_head}')
        """
        if x_neck < x_head < Maplen and opponent_wall[x_head+1:, y_head].sum() != 0:
            return opponent_wall[x_head+1:, y_head].sum() - my_wall[x_head+1:, y_head].sum()
        if y_neck < y_head < Mapwid and opponent_wall[x_head, y_head+1:].sum() != 0:
            return opponent_wall[x_head, y_head+1:].sum() - my_wall[x_head, y_head+1:].sum()
        if x_neck > x_head > 0 and opponent_wall[:x_head, y_head].sum() != 0:
            return opponent_wall[:x_head, y_head].sum() - my_wall[:x_head, y_head].sum()
        if y_neck > y_head > 0 and opponent_wall[x_head, :y_head].sum() != 0:
            return opponent_wall[x_head, :y_head].sum() - my_wall[x_head, :y_head].sum()
        return -INF
    
    def check_longest(self):
        """
        return: whether I'm the longest snake with the smallest id
        """
        me = self.snake.camp
        length = len(self.snake.coor_list)
        for snake in self.ctx.snake_list:
            if snake.camp == me:
                if length < snake.get_len() or (length == snake.get_len() and snake.id < self.snake.id):
                    return False
        return True
    
    ####################
    # Helper functions #
    ####################
    
    def calc_dist(self, x1, y1, x2, y2):
        """
        Calculate the Manhattan distance between snake head and item.
        And find the possible direction to the item, at most 2.

        :return: (dist, possible_direction)
        """
        pos = []
        if x1 > x2:
            pos.append(0)
        if x1 < x2:
            pos.append(2)
        if y1 > y2:
            pos.append(1)
        if y1 < y2:
            pos.append(3)
        return abs(x1 - x2) + abs(y1 - y2), pos
    
    def head_direction(self):
        """
        OUTPUT: The direction of head.
        """
        x_head, y_head = self.snake.coor_list[0]
        x_neck, y_neck = self.snake.coor_list[1]
        if x_neck < x_head:
            return 0
        if y_neck < y_head:
            return 1
        if x_neck > x_head:
            return 2
        if y_neck > y_head:
            return 3
    
    ###################################
    #  The followings are strategies  #
    ###################################
    
    def escape_strategy(self):
        """
        Called when the snake has no place to go. 
        Consider solidify and fire first. 
        Then think about split.
        Otherwise, wasted.
        """
        if self.snake.get_len() == 1:
            for i in range(4):
                if self.check_legal(i):
                    return i
        #Whether we can fire
        dir = self.head_direction()
        length = len(self.snake.coor_list)
        x_head, y_head = self.snake.coor_list[0]
        for d in range(4):
            if self.check(d) == False and self.check_self(d) == True:# can solidify
                return d
        if len(self.snake.item_list) > 0 and 0 <= x_head+dx[dir] < 16 and 0 <= y_head+dy[dir] < 16 and self.ctx.get_map().wall_map[x_head+dx[dir]][y_head+dy[dir]] != -1 and self.check_blocks() + (length // 2) >= 0:
                return 4
        elif  length > 1 and self.ctx.get_snake_count(self.snake.camp) < 4: #can split
            return 5
        else:# wasted
            if self.snake.get_len() > 1 and self.snake.coor_list[0][0] + dx[0] == self.snake.coor_list[1][0] and self.snake.coor_list[0][1] + dy[0] == self.snake.coor_list[1][1]:
                return 1
            return 0
    
    def closest_food_strategy(self):
        """
        Search for the closest food or item and to go that direction, if legal.

        :return: the chosen direction
        """
        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0: # the snake has no place to go
            return self.escape_strategy()
        # calculate the legal moves without concerning the food

        coor = self.snake.coor_list
        dist, val = INF, []
        for item in self.ctx.game_map.item_list:
            if item.type == 2 and len(self.snake.item_list) > 0:
                continue
            # don't need fire if we already have one

            d, pos = self.calc_dist(item.x, item.y, coor[0][0], coor[0][1])
            pos = [i for i in pos if i in valid]
            # use legal move only
            
            if item.time > self.ctx.turn + SEARCH_LIMIT or item.time + 15 < self.ctx.turn + d:
                continue
            # search valid food only
            
            if self.ctx.game_map.wall_map[item.x][item.y] != -1:
                continue
            # search food that is not in the wall

            if len(pos) > 0 and d < dist and item.time + 15 <= d + self.ctx.turn + SPLIT_LIMIT / 2:
                dist, val = d, pos
            # search reachable food only
            # not that the span of a snake is at least SPLIT_LIMIT / 2

        # chose the closest reachable food and use legal move

        if len(val) == 0:
            val = valid
        i = random.randint(0, len(val) - 1)
        # randomly chose one if multiple available

        return val[i]
        
    def active_strategy(self):
        """
        Strategy for the active snake. Split when limit is reached and snakes are not enough.
        Fire if it is worthy. 
        Otherwise search for food.
        """
        if len(self.snake.coor_list) >= SPLIT_LIMIT and self.ctx.get_snake_count(self.snake.camp) < SNAKE_LIMIT:
            return 6
        elif len(self.snake.item_list) > 0 and len(self.snake.coor_list) > 1 and self.check_blocks() >= 0:
            return 5
        else:
            return self.closest_food_strategy() + 1

    def solidify_strategy(self):
        """
        Try to move towards tail (where it should be when we arrive).

        :return: direction to move
        """
        ############################################
        # TODO: Optimize the random choice of step #
        ############################################
        
        x_head, y_head = self.snake.coor_list[0]
        x_tail, y_tail = self.snake.coor_list[-2]
        res_len = self.snake.length_bank
        length = len(self.snake.coor_list)
        d, pos = self.calc_dist(x_tail, y_tail, x_head, y_head)
        if res_len < d:
            mid = (length + res_len) // 2
            best_d, bestdiff, bestdir, goal, goal_x, goal_y = 0, INF, None, 0, 0, 0
            for i in range(mid, length):
                x_goal, y_goal = self.snake.coor_list[i]
                d, pos = self.calc_dist(x_goal, y_goal, x_head, y_head)
                res = length - i + res_len
                if bestdiff > abs(d - res):
                    bestdiff = abs(d - res)
                    bestdir = pos
                    best_d = d
                    goal = i
                    goal_x, goal_y = x_goal, y_goal
            pos = bestdir
        else:
            goal, goal_x, goal_y = length-1, x_tail, y_tail
            _, pos = self.calc_dist(x_tail, y_tail, x_head, y_head)
        
        dir = self.head_direction()
        valid = []
        for i in range(4):
            if self.check(i):
                valid.append(i)
        if len(valid) == 0:
            return self.escape_strategy()
        pos = [i for i in pos if i in valid]
        if len(pos) == 0:
            pos = valid
            i = random.randint(0, len(pos) - 1)
            return pos[i]
        elif len(pos) == 1:
            return pos[0]
        else: # len(pos) == 2
            coor = self.snake.coor_list
            mid = goal // 2
            dist0 = mdis(x_head + dx[pos[0]], y_head + dy[pos[0]], goal_x, goal_y)
            dist1 = mdis(x_head + dx[pos[1]], y_head + dy[pos[1]], goal_x, goal_y)
            return pos[0] if dist0 > dist1 else pos[1]

    def passive_strategy(self):
        """
        Strategy for other snake. Always solidify.
        """
        return self.solidify_strategy() + 1

    def judge(self, snake, ctx):
        """
        :param snake: current snake
        :param ctx: current context
        :return: the decision
        
        Strategy:
            Keep 3 snakes. The longest passive, others active.
            If less, split when exceed limit(f)
            
            active strategy:
            fire if worthy
            get the food if no one can get earlier
            
            passive strategy:
            find the tail as soon as possible. 
        """
        ###################################################################
        # TODO: search several steps and evaluate surviving possibilities #
        ###################################################################
        self.ctx = ctx
        self.snake = snake
        
        if self.ctx.max_round - self.ctx.turn < 3 * self.snake.get_len() and self.snake.get_len() >= 4:
            return self.passive_strategy()
        me = self.snake.camp
        if self.ctx.get_snake_count(me) > 2 and self.check_longest() and self.snake.get_len() >= 4:
            return self.passive_strategy()
        else:
            return self.active_strategy()

def run():
    """
    This function maintains the context, i.e. simulating the game.
    It is not necessary to understand this function for you to write an AI.
    """
    c = Client()
    # game config
    (length, width, max_round, player) = c.fetch_data()
    config = GameConfig(width=width, length=length, max_round=max_round)
    ctx = Context(config=config)
    current_player = 0

    logging.info('Assigned player %d', player)

    # read items
    item_list = c.fetch_data()
    ctx.game_map = Map(item_list, config=config)
    controller = Controller(ctx)
    # read & write operations
    playing = True
    ai = AI()
    while playing:
        if controller.ctx.turn > max_round:
            res = c.fetch_data()
            sys.stderr.write(str(res[1:]))
            break
        if current_player == 0:
            controller.round_preprocess()
        controller.round_init()
        if player == current_player:  # Your Turn
            while controller.next_snake != -1:
                current_snake = controller.current_snake_list[controller.next_snake][0]
                op = ai.judge(current_snake, controller.ctx)  # TODO: Complete the Judge Function
                logging.debug(str(op))
                if not controller.apply(op):
                    raise RuntimeError("Illegal Action!!! " + str(op))
                c.send_data(op)
                res = c.fetch_data()
                if res[0] == -1:
                    playing = False
                    sys.stderr.write(str(res[1:]))
                    break
            controller.next_player()
        else:
            while True:
                if controller.next_snake == -1:
                    controller.next_player()
                    break
                op = c.fetch_data()
                if op[0] == -1:
                    playing = False
                    sys.stderr.write(str(op[1:]))
                    break
                controller.apply(op[0])
        current_player = 1 - current_player
    while True:
        pass

#include "adk.hpp"
#include <cmath>

Operation
make_your_decision( const Snake &snake_to_operate, const Context &ctx )
{
	return OP_UP;
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char **argv )
{
	SnakeGoAI start( argc, argv );
}
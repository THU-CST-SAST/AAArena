import sampleAI
import sys

if __name__ == '__main__':
    sys.stderr.write("start")
    sampleAI.run()

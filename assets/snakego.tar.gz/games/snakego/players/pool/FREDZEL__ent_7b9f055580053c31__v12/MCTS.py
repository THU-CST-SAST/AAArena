import sys

from adk import *
from basic import *
import math
import time
import copy

CHOICES = [0, 1, 2, 3]  # 四个方向，有一个方向不合法
CHOICE_NUMBER = len(CHOICES)


@dataclass
class TreeNode:
    player: int  # 该节点的玩家
    profit: int  # 总收益值
    expandableNumber: int  #
    visitTime: int  # 访问次数
    isTerminal: int  # 是否是叶结点
    ctx: Context
    snake_cnt: int  # 本方蛇的数量
    last_op: List[int]  # 从父结点到本节点的操作
    snakes: Tuple[Snake, Snake, Snake, Snake]

    def __init__(self, ctx_: Context, now_player: int, op: List[int]):
        self.player = now_player
        self.ctx = ctx_
        self.father = None
        self.children = []
        self.snake_cnt = self.ctx.get_snake_count(self.player)
        self.last_op = op
        self.visitTime = 0
        self.profit = 0

    def is_all_expand(self):

        """
        是否已经扩展完成
        :return: 1-完成，0-未完成，-1-蛇数量已清零
        """
        sum = 0
        controller = Controller(copy.deepcopy(self.ctx))
        controller.player = self.ctx.current_player
        controller.round_preprocess()
        controller.round_init()
        ai = BasicAI()
        while controller.next_snake != -1:
            ai.setup(self.ctx, controller.current_snake_list[controller.next_snake][0])
            cnt = 0
            for op in CHOICES:
                if ai.check_self(op):  # 保证：当前局面下，该条蛇进行该操作不会非法
                    cnt+=1
            controller.find_next_snake()
            if cnt == 0:
                sum = 0
                break
            if sum == 0:
                sum = cnt
            else:
                sum *= cnt
        if sum==0:
            return -1
        if len(self.children) == sum:  # k为蛇数，选择数为4的k次方
            return True
        else:
            return False

    def add_child(self, node):
        """
        增加孩子
        """
        self.children.append(node)
        node.father = self


def MCTS_sample(node: TreeNode):
    """
    搜索主函数
    :return: 最佳的子节点TreeNode
    """
    sys.stderr.write("start3")
    t1 = time.time()
    while time.time() - t1 < 0.9:
        sys.stderr.write(str(time.time()-t1)+"\n")
        expand_node = tree_policy(node)
        result = default_policy(expand_node)
        back_propagation(expand_node, result)
        sys.stderr.write("sample")
    best_next_move = best_child(node, False)
    return best_next_move


def cal_profit(ctx: Context, player: int):
    """
    计算该局面的收益：结局的我方墙-对方墙+我方蛇长-对方蛇长
    """
    reward = 0
    for snake in ctx.snake_list:
        if snake.camp == player:
            reward += snake.get_len()
        else:
            reward -= snake.get_len()
    for x in ctx.game_map.wall_map:
        for y in x:
            if y == player:
                reward += 1
            elif y == 1 - player:
                reward -= 1
    return reward


def random_operation(ctx: Context):
    """
    对当前局面模拟进行一个操作
    :return: (操作后的context，操作的元组)
    """
    controller = Controller(copy.deepcopy(ctx))
    controller.player = ctx.current_player
    controller.round_preprocess()
    controller.round_init()
    ai = BasicAI()
    final_op = []
    while controller.next_snake != -1:
        ai.setup(ctx, controller.current_snake_list[controller.next_snake][0])
        for j in range(100):
            op = random.choice(CHOICES)
            if ai.check_self(op):       # 保证：当前局面下，该条蛇进行该操作不会非法
                break
        controller.apply(op+1)
        final_op.append(op)
    controller.next_player()
    return controller.ctx, final_op


def expand(node: TreeNode):
    """
    扩展该节点，尝试一个新的选择
    """
    tried_op = [sub_node.last_op for sub_node in node.children]
    while True:
        new_ctx, op = random_operation(node.ctx)
        if op not in tried_op:
            break
    sys.stderr.write(str(op))
    sub_node = TreeNode(new_ctx, 1 - node.player, op)
    node.add_child(sub_node)
    return sub_node


def best_child(node: TreeNode, is_explored: bool):
    """
    找UCB最大的子节点
    """
    best_node = None
    max_UCB = -INF
    for child in node.children:
        if child.visitTime == 0:
            sys.stderr.write(str(child.profit)+" "+str(child.last_op))
            # continue
        if is_explored:
            c = 1 / math.sqrt(2.0)
        else:
            c = 0
        mean = child.profit / child.visitTime
        explore = 2 * math.log(node.visitTime) / child.visitTime
        UCB = mean + c * math.sqrt(explore)
        if UCB >= max_UCB:
            max_UCB = UCB
            best_node = child
    if(best_node==None):
        return node
    return best_node


def tree_policy(node: TreeNode):
    """
    选择下一个叶结点
    """
    result = node.is_all_expand()
    if result == 1:  # 已经扩展完成
        node = best_child(node, True)  # 选UCB最大的孩子
        if node == None:
            sys.stderr.write("no")
        node = tree_policy(node)
    elif result == -1:          # 孩子=0且无蛇
        node.ctx.current_player = 1 - node.ctx.current_player
        node.ctx.turn += 1       # 跳过该玩家的环节
        sub_node = expand(node)  # 扩展该节点
        return sub_node
    else:   # 未扩展完成
        sub_node = expand(node)  # 扩展该节点
        return sub_node
    return node


def back_propagation(node: TreeNode, reward: int):
    """
    回溯更新结果
    """
    current_player = node.player  # 叶子节点是对方还是己方
    current_profit = reward
    while node != None:
        node.visitTime += 1
        if node.player == current_player:  # 给同方增加胜利
            node.profit += current_profit
        else:
            node.profit -= current_profit
        node = node.father


def default_policy(node: TreeNode):
    """
    模拟到结束
    :return: 最终模拟的结局的收益
    """
    new_ctx = copy.deepcopy(node.ctx)
    player = node.player
    t1 = time.time()
    while new_ctx.turn < new_ctx.max_round:
        new_ctx = random_operation(new_ctx)[0]
        if new_ctx.get_snake_count(player) == 0:
            break
        if time.time() - t1 > 0.5:
            break
    return cal_profit(new_ctx, player)

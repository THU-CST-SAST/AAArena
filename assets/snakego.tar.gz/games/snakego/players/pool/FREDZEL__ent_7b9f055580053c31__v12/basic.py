from adk import *

dx = [1, 0, -1, 0]
dy = [0, 1, 0, -1]
INF = 1e9
# constants

SPLIT_LIMIT = 10
SEARCH_LIMIT = 100
# tunable parameters


@dataclass
class SnakeHead:
    position: Tuple[int,int]    # 蛇头位置
    direction: int          # 蛇头朝向

    def __init__(self, snake:Snake):
        coor_1 = snake.coor_list[0]
        coor_2 = snake.coor_list[1]
        if coor_1[0] == coor_2[0]:  # 蛇头沿y轴方向
            if coor_1[1] < coor_2[1]:  # 蛇头朝下
                self.direction = 3
            else:  # 蛇头朝上
                self.direction = 1
        else:
            if coor_1[0] < coor_2[0]:  # 蛇头朝左
                self.direction = 2
            else:  # 蛇头朝右
                self.direction = 0
        self.position = coor_1

        # dfs若干步看是否会被围住


def calc_dist(x1, y1, x2, y2):
    """
    Calculate the Manhattan distance between snake head and item.
    And find the possible direction to the item, at most 2.

    :return: (dist, possible_direction)
    """
    pos = []
    if x1 > x2:
        pos.append(0)
    if x1 < x2:
        pos.append(2)
    if y1 > y2:
        pos.append(1)
    if y1 < y2:
        pos.append(3)
    return abs(x1 - x2) + abs(y1 - y2), pos


def dfs_surrounded(snake:Snake):
    """
    dfs若干步看是否会被围住
    """


class BasicAI:
    def __init__(self):
        self.ctx = None
        self.snake = None
        self.order = dict()

    # ====================================检验部分==========================================
    # 检查是否不会固化、合法
    def check(self, op):
        """
        :param op: the direction
        :return: True if this move is legal and will not result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        # check wall and out of bounds
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        # check turn back
        if self.ctx.game_map.snake_map[x][y] != -1:
            return False
        # check other snake
        return True

    # 检查是否合法
    def check_self(self, op):
        """
        :param op: the direction
        :return: True if this move is legal, could possibly result in solidification.
                 False otherwise.
        """
        x = self.snake.coor_list[0][0] + dx[op]
        y = self.snake.coor_list[0][1] + dy[op]
        if x < 0 or y < 0 or x >= 16 or y >= 16 or self.ctx.game_map.wall_map[x][y] != -1:
            return False
        if self.snake.get_len() > 1 and x == self.snake.coor_list[1][0] and y == self.snake.coor_list[1][1]:
            return False
        if self.ctx.game_map.snake_map[x][y] != -1 and self.ctx.game_map.snake_map[x][y] != self.snake.id:
            return False
        return True

    # 检查融化射线发射是否去掉更多的对方墙壁
    def check_fire_benefit(self):
        """
        检查融化射线发射是否去掉更多的对方墙壁

        :return: 对方墙个数-己方墙个数
        """
        coor_1 = self.snake.coor_list[0]
        coor_2 = self.snake.coor_list[1]
        cnt = 0
        if coor_1[0] == coor_2[0]:  # 蛇头沿y轴方向
            if coor_1[1] < coor_2[1]:  # 蛇头朝下
                for i in range(0, coor_1[1]):
                    if self.ctx.game_map.wall_map[coor_1[0]][i] == self.ctx.current_player:
                        cnt -= 1
                    elif self.ctx.game_map.wall_map[coor_1[0]][i] == 1 - self.ctx.current_player:
                        cnt += 1
            else:  # 蛇头朝上
                for i in range(coor_1[1], len(self.ctx.game_map.wall_map)):
                    if self.ctx.game_map.wall_map[coor_1[0]][i] == self.ctx.current_player:
                        cnt -= 1
                    elif self.ctx.game_map.wall_map[coor_1[0]][i] == 1 - self.ctx.current_player:
                        cnt += 1
        else:
            if coor_1[0] < coor_2[0]:  # 蛇头朝左
                for i in range(0, coor_1[0]):
                    if self.ctx.game_map.wall_map[i][coor_1[1]] == self.ctx.current_player:
                        cnt -= 1
                    elif self.ctx.game_map.wall_map[i][coor_1[1]] == 1 - self.ctx.current_player:
                        cnt += 1
            else:  # 蛇头朝右
                for i in range(coor_1[0], len(self.ctx.game_map.wall_map)):
                    if self.ctx.game_map.wall_map[i][coor_1[1]] == self.ctx.current_player:
                        cnt -= 1
                    elif self.ctx.game_map.wall_map[i][coor_1[1]] == 1 - self.ctx.current_player:
                        cnt += 1
        return cnt

    # 检查是否可能被围
    def check_surrounded(self):
        """

        """

    # 是否是最近的一条蛇
    def check_is_nearest(self, x: int, y: int):
        """
        是否是最近的一条蛇
        :return: 1/0, 是/否
        """
        min_distance = INF
        min_one_id = 0
        for snake in self.ctx.snake_list:
            if calc_dist(x, y, snake.coor_list[0][0], snake.coor_list[0][1])[0] < min_distance:
                min_distance = calc_dist(x, y, snake.coor_list[0][0], snake.coor_list[0][1])[0]
                min_one_id = snake.id
        if min_one_id == self.snake.id:
            return True
        else:
            return False

    def setup(self, ctx, snake):
        """
        :param ctx: current context
        :return: the decision
        """
        self.ctx = ctx
        self.snake = snake
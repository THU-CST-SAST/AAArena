#include "adk.hpp"
#include <cmath>
int breathbox[16][16];
int barriarbox[16][16];
int move_profit[4];


Operation make_your_decision( const Snake &snake_to_operate, const Context &ctx , const OpHistory& op_list)
{
//	fprintf(stderr,"%d: ",ctx.current_round());
	//初始化面积计算盒子
	int checkbox[16][16];
	for(int i=0; i <= 15; i++)
		for(int j=0; j <= 15; j++)
		{
			checkbox[i][j]=0;
		}
	//初始化蛇头盒子
	int headbox[16][16];
	for(int i=0;i<=15;i++)
		for(int j=0;j<=15;j++)
		{
			headbox[i][j]=0;
		}
	for(int i=0;i<ctx.my_snakes().size();i++)
	{
		headbox[ctx.my_snakes()[i][0].x][ctx.my_snakes()[i][0].y]=1;
	}
	//初始化障碍盒子
	for(int i=0;i<=15;i++)
		for(int j=0;j<=15;j++)
		{
			if(ctx.wall_map()[i][j]!=-1||ctx.snake_map()[i][j]!=-1)
				barriarbox[i][j]=1;
			else 
				barriarbox[i][j]=0;
		}
	
	//若该蛇有道具，执行融化射线操作
	//head_dir 0左，1上，2右，3下
	//融化射线参数
	int profit=0;
	if( (snake_to_operate.length()>=2 )&&( snake_to_operate.railgun_item.id >= 0) )
	{  
		int head_dir=0;//判断蛇头方向
		if( snake_to_operate[0].x == snake_to_operate[1].x)
		{
			if(snake_to_operate[0].y > snake_to_operate[1].y )
				head_dir = 1;
			else head_dir = 3;
		}
		else 
		{
			if(( snake_to_operate[0].x > snake_to_operate[1].x ))
				head_dir=2;
			else head_dir=0;
		}
		
		if(head_dir==1)
		for(int i=snake_to_operate[0].y+1;i<=15;i++)
		{
			if(ctx.wall_map()[snake_to_operate[0].x][i]==1-ctx.current_player())profit++;
			if(ctx.wall_map()[snake_to_operate[0].x][i]==ctx.current_player())profit--;
		}
		if(head_dir==2)
		for(int i=snake_to_operate[0].x+1;i<=15;i++)
		{
			if(ctx.wall_map()[i][snake_to_operate[0].y]==(1-ctx.current_player()))profit++;
			if(ctx.wall_map()[i][snake_to_operate[0].y]==ctx.current_player())profit--;
		}
		if(head_dir==3)
		for(int i=snake_to_operate[0].y-1;i>=0;i--)
		{
			if(ctx.wall_map()[snake_to_operate[0].x][i]==1-ctx.current_player())profit++;
			if(ctx.wall_map()[snake_to_operate[0].x][i]==ctx.current_player())profit--;
		}
		if(head_dir==0)
		for(int i=snake_to_operate[0].x-1;i>=0;i--)
		{
			if(ctx.wall_map()[i][snake_to_operate[0].y]==1-ctx.current_player())profit++;
			if(ctx.wall_map()[i][snake_to_operate[0].y]==ctx.current_player())profit--;
		}
		if (profit>0)
		{
			return OP_RAILGUN;
		}
	}


	

	Operation direction[4] = { OP_RIGHT, OP_UP, OP_LEFT, OP_DOWN };
	int dx[4] = { 1, 0, -1, 0 };
	int dy[4] = { 0, 1, 0, -1 };
	//结块参数
	int dirpromax=-1;
	int dirpro=-1;
	//确定合法移动方向
	//-1代表移动非法，0代表正常移动，1代表移动触发固化
	int move[4] = { 0, 0, 0, 0 };
	int move_profit[4]={-1,-1,-1,-1};
	for ( int dir = 0; dir < 4; dir++ )
	{
		//蛇头到达位置
		int t_x = snake_to_operate[0].x + dx[dir];
		int t_y = snake_to_operate[0].y + dy[dir];
		
		//超出边界
		if ( t_x >= ctx.length() || t_x < 0 || t_y >= ctx.width() || t_y < 0 )
		{
			move[dir] = -1;
			continue;
		}

		//撞墙
		if ( ctx.wall_map()[t_x][t_y] != -1 )
		{
			move[dir] = -1;
			continue;
		}

		//撞非本蛇
		if ( ctx.snake_map()[t_x][t_y] != -1 &&
			 ctx.snake_map()[t_x][t_y] != snake_to_operate.id )
		{
			move[dir] = -1;
			continue;
		}

		//回头撞自己
		if ( ( snake_to_operate.length() > 2 || ( snake_to_operate.length() == 2 && snake_to_operate.length_bank > 0 ) ) &&
			 snake_to_operate[1].x == t_x &&
			 snake_to_operate[1].y == t_y )
		{
			move[dir] = -1;
			continue;
		}

		//移动导致固化
		
		if ( ctx.snake_map()[t_x][t_y] == snake_to_operate.id && snake_to_operate.length() > 3)
		{
			move[dir] = 1;
			int bein=0;
			for(int i=0;i<snake_to_operate.length()-1;i++)
			{
				if(snake_to_operate[i].x==t_x&&snake_to_operate[i].y==t_y)
				{
					bein=i;
					break;
				}
			}
			for(int i = 0 ;i <= bein; i++)
			{
				checkbox[snake_to_operate[i].x][snake_to_operate[i].y]=1;
			}
			int ans = 0;
			int colans = 0;
			for(int i = 0; i <= 15; i++)
			{
				int stack = 0;
				colans = 0;
				for(int j = 0;j <= 15; j++)
				{
					if(checkbox[i][j]==1&&stack==0&&j!=0&&checkbox[i][j-1]==1)
					{
						stack=0;
						colans++;
						continue;
					}
					if(checkbox[i][j]==1&&stack==0)
					{
						stack=1;
						colans++;
						continue;
					}
					if(checkbox[i][j]==0&&stack==1)
					{
						colans++;
						continue;
					}
					if(checkbox[i][j]==1&&stack==1)
					{
						stack=0;
						colans++;
						continue;
					}
				}
				if(stack==1)colans=0;
				ans+=colans;
			}
			if(ans>dirpromax)
			{
				dirpromax=ans;
				dirpro=dir;
			}
//			fprintf(stderr,"%d\n",ans);	
			if(4*ans >= 3*snake_to_operate.length()&&ctx.my_snakes().size() >= 3&&ans>=9)
			{
//				fprintf(stderr,"%d\n",ans);	
				return direction[dir];
			}
			continue;
		}
		//移动导致杀队友
		for(int i=0;i<=15;i++)
			for(int j=0;j<=15;j++)
			{
				breathbox[i][j]=0;
				for ( int ddir = 0; ddir < 4; ddir++ )
				{
					int tt_x = i + dx[ddir];
					int tt_y = j + dy[ddir];
					if ( tt_x >= ctx.length() || tt_x < 0 || tt_y >= ctx.width() || tt_y < 0 )continue;
					if(barriarbox[tt_x][tt_y]==0)
					breathbox[i][j]++;
				}
			}
			int breathsnake[4]={0,0,0,0};
		for(int i=0;i<ctx.my_snakes().size();i++)
		{
			breathsnake[i]=breathbox[ctx.my_snakes()[i][0].x][ctx.my_snakes()[i][0].y];
		//	fprintf(stderr,"%d ",breathsnake[i]);
		}
		//fprintf(stderr,"\n");

		if(snake_to_operate.length_bank>0)
			barriarbox[t_x][t_y]=1;
		else
		{
			barriarbox[snake_to_operate[snake_to_operate.length()-1].x][snake_to_operate[snake_to_operate.length()-1].y]=0;
			barriarbox[t_x][t_y]=1;
		}
	//	fprintf(stderr,"*%d %d %d \n",ctx.current_round(),snake_to_operate.id,dir);
		for(int i=0;i<=15;i++)
		{
			for(int j=0;j<=15;j++)
			{
				breathbox[i][j]=0;
				for ( int ddir = 0; ddir < 4; ddir++ )
				{
					int tt_x = i + dx[ddir];
					int tt_y = j + dy[ddir];
					if ( tt_x >= ctx.length() || tt_x < 0 || tt_y >= ctx.width() || tt_y < 0 )continue;
					if(barriarbox[tt_x][tt_y]==0)
					breathbox[i][j]++;
				}
			}
		}
/*		for(int i=15;i>=0;i--)
		{
			for(int j=0;j<=15;j++)
			{
				fprintf(stderr,"%d",breathbox[j][i]);
			}
			fprintf(stderr,"\n");
		}	
*/		
		for(int i=0;i<ctx.my_snakes().size();i++)
		{
			if(breathbox[ctx.my_snakes()[i][0].x][ctx.my_snakes()[i][0].y]==0&&breathsnake[i]>0&&(ctx.my_snakes()[i].id!=snake_to_operate.id))
				if(ctx.my_snakes()[i].length()>snake_to_operate.length())
				move[dir] = -1;
		}
		if(move[dir]==-1)
		move_profit[dir]=-1;
		else 
		move_profit[dir]=breathbox[t_x][t_y];

		barriarbox[t_x][t_y]=0;
		barriarbox[snake_to_operate[snake_to_operate.length()-1].x][snake_to_operate[snake_to_operate.length()-1].y]=1;	
	}
	if ( snake_to_operate.length() >= 12 ||(snake_to_operate.length() >= 2&&ctx.my_snakes().size()<=2&&ctx.current_round()>=20))
	{
		//若蛇的数量少于4
		if ( ctx.my_snakes().size() < 4 )
			return OP_SPLIT;
	}

	//计算吃最近的道具的步数
	int mindis=999;
	int mindir=0;
	for ( int i = ctx.item_list().size()-1; i >=0 ; i-- )
	{
		//道具已经消失
		if ( ctx.item_list()[i].time + ITEM_EXPIRE_LIMIT < ctx.current_round() || (ctx.wall_map()[ctx.item_list()[i].x][ctx.item_list()[i].y]!=-1))
			continue;
		if((snake_to_operate.railgun_item.id >= 0)&&(ctx.item_list()[i].type==2))continue;
		//计算蛇头与道具的距离
		int distance = abs( ctx.item_list()[i].x - snake_to_operate[0].x ) +
					   abs( ctx.item_list()[i].y - snake_to_operate[0].y );
		int flag=0;
		for(int j=0;j<ctx.my_snakes().size();j++)
		{
			if(distance> abs( ctx.item_list()[i].x - ctx.my_snakes()[j][0].x ) + abs( ctx.item_list()[i].y - ctx.my_snakes()[j][0].y )&&(ctx.my_snakes()[j].id!=snake_to_operate.id))
				flag=1;
		}
		if(flag==1)continue;
			//忽略其他因素理论上能吃到该道具ctx.item_list()[i].time <= ctx.current_round() + distance &&
		if ( 
			 ctx.item_list()[i].time + 16 > ctx.current_round() + distance )
		{
			for ( int dir = 0; dir < 4; dir++ )
			{
				//移动不合法或固化
				if ( move[dir] != 0 )
					continue;
					//朝向道具方向移动
				int t_x = snake_to_operate[0].x + dx[dir];
				int t_y = snake_to_operate[0].y + dy[dir];
				int dis = abs( ctx.item_list()[i].x - t_x ) + abs( ctx.item_list()[i].y - t_y );
				if ( dis <= distance )
				{
					if(distance<mindis)
					{
						mindis=distance;
						mindir=dir;
					}	
				}
			}
		}
	}

	int high_pro_dir=-1;
	int high_profit=-1; 


	for(int dir=0;dir<4;dir++)
	{

		if(move_profit[dir]>high_profit)
		{
			high_pro_dir=dir;
			high_profit=move_profit[dir];
		}
	}
	
	//如果前往道具且安全
	if(mindis!=999&&move_profit[mindir]>0)
	{
		fprintf(stderr,"*%d %d",ctx.current_round(),snake_to_operate.id);
		fprintf(stderr,"A\n");
		return direction[mindir];
	}
		

	if(high_profit>=0&&move[high_pro_dir]!=-1)
	{
//		fprintf(stderr,"B\n");
		return direction[high_pro_dir];
	}//空地
	else
	{
//		fprintf(stderr,"***** %d %d %d %d %d\n",ctx.current_round(),snake_to_operate.id,high_profit,high_pro_dir,move[high_pro_dir]);
		for(int dir=0;dir<4;dir++)
		{
//			fprintf(stderr,"(%d,%d)",move[dir],move_profit[dir]);
		}
//		fprintf(stderr,"\n");
	}
/*	else
	{
		for(int dir=0;dir<4;dir++)
		{
			int t_x = snake_to_operate[0].x + 2*dx[dir];
			int t_y = snake_to_operate[0].y + 2*dy[dir];
			if(move_profit[dir]==0&&((t_x>=0&&t_x<=15)&&(t_y>=0&&t_y<=15)))
				if(ctx.snake_map()[t_x][t_y] == snake_to_operate.id)
					return direction[dir];
		}
	}*/

	if(dirpromax>=0)return direction[dirpro];//结块

	if ( ctx.my_snakes().size() < 4 && snake_to_operate.length() >= 2)
		return OP_SPLIT;
	if (profit==0&&snake_to_operate.railgun_item.id >= 0&&snake_to_operate.length()>=2)
	{
		return OP_RAILGUN;
	}
	
	if ( ( snake_to_operate.length() > 2 || ( snake_to_operate.length() == 2 && snake_to_operate.length_bank > 0 ) ) &&
		snake_to_operate[1].x == snake_to_operate[0].x + dx[0] &&
		snake_to_operate[1].y == snake_to_operate[0].y + dy[0] ) 
		return OP_LEFT;
	else
		return OP_RIGHT;
}

void game_over( int gameover_type, int winner, int p0_score, int p1_score )
{
	fprintf( stderr, "%d %d %d %d", gameover_type, winner, p0_score, p1_score );
}

int main( int argc, char **argv )
{
	SnakeGoAI start( argc, argv );
}
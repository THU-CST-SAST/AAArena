# 26_snakego

- 届次：第 26 届 SnakeGo / 贪吃蛇围棋
- 类型：双人回合制围地与路径规划
- 内容：archives 保存原始包；logic 保存解包后的后端、SDK、server 或样例 AI；SHA256SUMS 保存原始包校验值。
- 来源：Saiblo Game.code；saiblo-judge-dev database zip

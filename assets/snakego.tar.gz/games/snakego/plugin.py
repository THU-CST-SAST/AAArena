"""SnakeGo 游戏插件声明 —— 被框架 Core 的注册表发现。

框架通过本文件顶层的 `PLUGIN` 发现 snakego，无需修改框架源码。

可运行对战器落在本目录同级的 `evaluator/`（游戏资产，属 A）：定位官方 **Python**
后端 `games/snakego/backend/logic/gamecode_logic/`，用官方长度前缀
stdio 判题协议与统一选手池 `games/snakego/players/pool/` 的人类池对战，解析回放后
返回契约要求的 `EvaluateResult`。B/C 通过 A 的统一入口 `evaluate("snakego", ...)`
复用它。
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from aa_arena.core import Evaluator, GamePlugin


def _load_evaluator_module():
    """把本目录的 `evaluator/` 作为独立包加载（plugin.py 非包上下文，无法相对 import）。"""

    evaluator_dir = Path(__file__).resolve().parent / "evaluator"
    package_name = "aa_arena_games_snakego_evaluator"
    spec = importlib.util.spec_from_file_location(
        package_name,
        evaluator_dir / "__init__.py",
        submodule_search_locations=[str(evaluator_dir)],
    )
    if spec is None or spec.loader is None:  # pragma: no cover - defensive
        raise ImportError(f"cannot load snakego evaluator from {evaluator_dir}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)
    return module


def _make_evaluator(game_dir: Path) -> Evaluator:
    module = _load_evaluator_module()
    return module.make_evaluator(game_dir)


PLUGIN = GamePlugin(
    name="snakego",
    evaluator_factory=_make_evaluator,
    display_name="SnakeGo / 贪吃蛇棋",
    roles=("P0", "P1"),
    roles_symmetric=False,  # 两条蛇出生位置/顺序不同，需 side-balanced 评测
)

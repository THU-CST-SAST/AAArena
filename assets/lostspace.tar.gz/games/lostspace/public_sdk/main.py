"""Deterministic LostSpace player launcher; customize ``AI.play``."""

from lostspace_sdk import Action, Client, TurnState


class AI(Client):
    def play(self, state: TurnState) -> tuple[Action, ...]:
        return (Action.finish(),)


if __name__ == "__main__":
    AI().run()

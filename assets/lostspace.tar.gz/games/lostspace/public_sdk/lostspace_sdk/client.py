"""Typed actions and synchronous player client for LostSpace."""

from __future__ import annotations

import sys
from collections.abc import Mapping
from dataclasses import dataclass
from typing import BinaryIO

from .models import PlayerStatus, Position, TurnState
from .protocol import decode_message, encode_message


def _coordinate(position: Position) -> Position:
    return int(position[0]), int(position[1]), int(position[2])


def _wire_value(value: object) -> object:
    return list(value) if isinstance(value, tuple) else value


@dataclass(frozen=True, slots=True)
class Action:
    """One exact player-to-referee action."""

    operation: str | None
    arguments: tuple[object, ...] = ()

    @classmethod
    def move(cls, position: Position) -> Action:
        return cls("move", (_coordinate(position),))

    @classmethod
    def attack(cls, position: Position, player_id: int) -> Action:
        return cls("attack", (_coordinate(position), int(player_id)))

    @classmethod
    def interact(cls, interprop: str) -> Action:
        return cls("interact", (str(interprop),))

    @classmethod
    def escape(cls, to_escape: bool) -> Action:
        return cls("interact", ("EscapeCapsule", bool(to_escape)))

    @classmethod
    def collect(cls, interprop: str, item: str) -> Action:
        return cls("interact", (str(interprop), str(item)))

    @classmethod
    def trap(cls, trap_type: str) -> Action:
        return cls("trap", (str(trap_type),))

    @classmethod
    def tool(cls, tool_type: str, position: Position | None = None) -> Action:
        arguments: tuple[object, ...] = (str(tool_type),)
        if position is not None:
            arguments += (_coordinate(position),)
        return cls("tool", arguments)

    @classmethod
    def detect(cls, position: Position) -> Action:
        return cls("detect", (_coordinate(position),))

    @classmethod
    def finish(cls) -> Action:
        return cls(None)

    @property
    def is_finish(self) -> bool:
        return self.operation is None

    def as_message(self) -> dict[str, object]:
        if self.is_finish:
            return {"type": "finish"}
        return {
            "type": "action",
            "action": [self.operation, *(_wire_value(item) for item in self.arguments)],
        }


class Client:
    """Read referee messages and execute actions returned by ``play`` in order."""

    def __init__(
        self,
        input_stream: BinaryIO | None = None,
        output_stream: BinaryIO | None = None,
    ) -> None:
        self.input_stream = input_stream if input_stream is not None else sys.stdin.buffer
        self.output_stream = output_stream if output_stream is not None else sys.stdout.buffer
        self.player_id: int | None = None
        self.spawn: Position | None = None

    def play(self, state: TurnState) -> tuple[Action, ...]:
        """Return this turn's ordered actions; the last one must be ``finish``."""
        return (Action.finish(),)

    def on_event(self, message: Mapping[str, object]) -> None:
        """Observe an off-round or intermediate event without mutating turn state."""

    def on_action_response(
        self,
        action: Action,
        response: Mapping[str, object],
    ) -> None:
        """Observe the referee response to a non-finish action."""

    def run(self) -> None:
        while True:
            try:
                message = decode_message(self.input_stream)
            except EOFError:
                return

            message_type = message.get("type")
            if message_type == "id":
                self._accept_identity(message)
            elif message_type == "offround":
                self.on_event(message)
            elif message_type == "roundbegin":
                if self._play_turn(message):
                    return
            elif message_type in {"escaped", "ai_error"}:
                return
            else:
                self.on_event(message)

    def _accept_identity(self, message: Mapping[str, object]) -> None:
        self.player_id = int(message["id"])
        birth = message.get("birth_pos")
        if not isinstance(birth, (list, tuple)) or len(birth) not in {2, 3}:
            raise ValueError("LostSpace id message has an invalid birth_pos")
        coordinates = [int(item) for item in birth]
        if len(coordinates) == 2:
            coordinates.append(1)
        self.spawn = coordinates[0], coordinates[1], coordinates[2]

    def _play_turn(self, message: Mapping[str, object]) -> bool:
        if self.player_id is None or self.spawn is None:
            raise RuntimeError("LostSpace roundbegin received before id")
        if int(message.get("inturn", -1)) != self.player_id:
            return False

        state = TurnState.from_message(
            player_id=self.player_id,
            spawn=self.spawn,
            message=message,
        )
        if state.status in {PlayerStatus.ESCAPED, PlayerStatus.ERROR}:
            return True
        if state.status is PlayerStatus.WAITING_ESCAPE:
            self._send(Action.finish())
            return False
        if state.status is not PlayerStatus.ALIVE:
            return False

        actions = tuple(self.play(state))
        if not actions or not actions[-1].is_finish:
            raise ValueError("LostSpace play() must end every turn with Action.finish()")
        for action in actions:
            self._send(action)
            if not action.is_finish:
                response = self._read_action_response()
                self.on_action_response(action, response)
        return False

    def _send(self, action: Action) -> None:
        self.output_stream.write(encode_message(action.as_message()))
        self.output_stream.flush()

    def _read_action_response(self) -> dict[str, object]:
        while True:
            response = decode_message(self.input_stream)
            response_type = response.get("type")
            if response_type in {"action", "format error", "ai_error"}:
                return response
            self.on_event(response)

"""LostSpace player-side JSON framing helpers."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import BinaryIO

MAX_FRAME_BYTES = 64 * 1024 * 1024


def _read_exact(stream: BinaryIO, size: int) -> bytes:
    data = bytearray()
    while len(data) < size:
        chunk = stream.read(size - len(data))
        if not chunk:
            raise EOFError(f"expected {size} bytes, received {len(data)}")
        data.extend(chunk)
    return bytes(data)


def encode_message(payload: Mapping[str, object]) -> bytes:
    """Encode an outbound message with a signed four-byte big-endian header."""
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_FRAME_BYTES:
        raise ValueError("LostSpace outbound frame exceeds 64 MiB")
    return len(body).to_bytes(4, byteorder="big", signed=True) + body


def decode_message(stream: BinaryIO) -> dict[str, object]:
    """Decode an inbound message with a four-digit ASCII byte-length header."""
    header = _read_exact(stream, 4)
    if not header.isdigit():
        raise ValueError("LostSpace inbound frame length must be four ASCII digits")
    size = int(header)
    if size > MAX_FRAME_BYTES:
        raise ValueError("LostSpace inbound frame exceeds 64 MiB")
    payload = json.loads(_read_exact(stream, size).decode("utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("LostSpace inbound frame must contain a JSON object")
    return payload

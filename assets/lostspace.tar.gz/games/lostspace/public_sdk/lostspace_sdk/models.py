"""Immutable models for information visible to a LostSpace player."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import IntEnum
from typing import TypeAlias

Position: TypeAlias = tuple[int, int, int]


class PlayerStatus(IntEnum):
    ALIVE = 0
    DEAD = 1
    ESCAPED = 2
    SKIPPED = 3
    WAITING_ESCAPE = 4
    ERROR = 5


def _position(value: object, *, fallback: Position = (-1, -1, -1)) -> Position:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != 3:
        return fallback
    return int(value[0]), int(value[1]), int(value[2])


def _sequence(value: object) -> Sequence[object]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return value
    return ()


def _mapping(value: object) -> Mapping[str, object]:
    return value if isinstance(value, Mapping) else {}


@dataclass(frozen=True, slots=True)
class Inventory:
    landmines_available: int
    landmines_placed: int
    landmine_positions: tuple[Position, ...]
    sticky_available: int
    sticky_placed: int
    sticky_positions: tuple[Position, ...]
    kits: int
    transports: int

    @classmethod
    def from_message(cls, value: object) -> Inventory:
        tools = _mapping(value)
        landmines = _sequence(tools.get("LandMine"))
        sticky = _sequence(tools.get("Sticky"))
        return cls(
            landmines_available=int(landmines[0]) if len(landmines) > 0 else 0,
            landmines_placed=int(landmines[1]) if len(landmines) > 1 else 0,
            landmine_positions=tuple(_position(item) for item in landmines[2:]),
            sticky_available=int(sticky[0]) if len(sticky) > 0 else 0,
            sticky_placed=int(sticky[1]) if len(sticky) > 1 else 0,
            sticky_positions=tuple(_position(item) for item in sticky[2:]),
            kits=int(tools.get("Kit", 0)),
            transports=int(tools.get("Transport", 0)),
        )


@dataclass(frozen=True, slots=True)
class Opponent:
    player_id: int
    status: PlayerStatus
    hp: int
    keys: tuple[int, ...]

    @classmethod
    def from_message(cls, value: object) -> Opponent:
        message = _mapping(value)
        return cls(
            player_id=int(message.get("player_id", -1)),
            status=PlayerStatus(int(message.get("status", PlayerStatus.ERROR))),
            hp=int(message.get("hp", 0)),
            keys=tuple(int(item) for item in _sequence(message.get("keys"))),
        )


@dataclass(frozen=True, slots=True)
class VisibleNode:
    position: Position
    interprops: tuple[str, ...]
    player_ids: tuple[int, ...]

    @classmethod
    def from_message(cls, value: object) -> VisibleNode:
        node = _sequence(value)
        contents = node[1] if len(node) > 1 else ()
        if isinstance(contents, bool):
            interprops = ("Box",) if contents else ()
        else:
            interprops = tuple(str(item) for item in _sequence(contents))

        visible_players = node[2] if len(node) > 2 else ()
        if isinstance(visible_players, int):
            player_ids = (visible_players,)
        else:
            player_ids = tuple(int(item) for item in _sequence(visible_players))
        return cls(
            position=_position(node[0] if node else None),
            interprops=interprops,
            player_ids=player_ids,
        )


@dataclass(frozen=True, slots=True)
class TurnState:
    player_id: int
    spawn: Position
    round_number: int
    inturn: int
    status: PlayerStatus
    hp: int
    keys: tuple[int, ...]
    position: Position
    inventory: Inventory
    opponents: tuple[Opponent, ...]
    visible_nodes: tuple[VisibleNode, ...]

    @classmethod
    def from_message(
        cls,
        *,
        player_id: int,
        spawn: Position,
        message: Mapping[str, object],
    ) -> TurnState:
        return cls(
            player_id=player_id,
            spawn=tuple(spawn),
            round_number=int(message.get("state", -1)),
            inturn=int(message.get("inturn", -1)),
            status=PlayerStatus(int(message.get("status", PlayerStatus.ERROR))),
            hp=int(message.get("hp", 0)),
            keys=tuple(int(item) for item in _sequence(message.get("keys"))),
            position=_position(message.get("pos"), fallback=spawn),
            inventory=Inventory.from_message(message.get("tools")),
            opponents=tuple(
                Opponent.from_message(item) for item in _sequence(message.get("others"))
            ),
            visible_nodes=tuple(
                VisibleNode.from_message(item) for item in _sequence(message.get("view"))
            ),
        )

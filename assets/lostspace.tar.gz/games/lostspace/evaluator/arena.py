"""LostSpace N-player process preparation and ranking interpretation."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

from .runtime import PreparedPlayer

MatchStatus = Literal["complete", "incomplete"]


class LostSpaceMatchError(RuntimeError):
    """The LostSpace terminal ranking is malformed."""


@dataclass(frozen=True)
class MatchResult:
    status: MatchStatus
    ranking: tuple[int, ...] | None
    winner_player: int | None
    rounds: int | None
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.ranking is None or self.winner_player is None or self.rounds is None:
                raise ValueError("complete match requires ranking/winner/rounds")
        elif self.status == "incomplete":
            if not self.error:
                raise ValueError("incomplete match requires an error")
        else:
            raise ValueError(f"unknown match status: {self.status}")


def run_saiblo_match(
    *,
    backend: ProcessSpec,
    players: Sequence[ProcessSpec],
    backend_env: Mapping[str, str],
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    backend_spec = ProcessSpec(
        backend.argv,
        backend.cwd,
        {**dict(backend.env), **dict(backend_env)},
    )
    judged = run_stdio_match(
        backend=backend_spec,
        players=players,
        config={},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    raw = judged.end_message.get("end_info")
    try:
        end_info = json.loads(raw) if isinstance(raw, str) else raw
    except json.JSONDecodeError as exc:
        raise LostSpaceMatchError("invalid terminal end_info JSON") from exc
    if not isinstance(end_info, Mapping):
        raise LostSpaceMatchError("terminal end_info is not an object")
    return _result_from_end_info(
        end_info,
        player_count=len(players),
        replay_path=replay_path,
        events_path=events_path,
    )


def _result_from_end_info(
    end_info: Mapping[str, Any],
    *,
    player_count: int,
    replay_path: Path,
    events_path: Path,
) -> MatchResult:
    try:
        ranking = tuple(float(end_info[str(index)]) for index in range(player_count))
    except (KeyError, TypeError, ValueError) as exc:
        raise LostSpaceMatchError(f"invalid end_info: {end_info!r}") from exc
    winner_player = max(range(player_count), key=lambda index: ranking[index])
    return MatchResult(
        status="complete",
        ranking=tuple(int(value) for value in ranking),
        winner_player=int(winner_player),
        rounds=_rounds_from_replay(replay_path),
        replay_path=replay_path,
        events_path=events_path,
    )


def _rounds_from_replay(replay_path: Path) -> int:
    try:
        data = json.loads(replay_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0
    if not isinstance(data, list) or len(data) < 2:
        return 0
    return sum(isinstance(element, list) for element in data[1:-1])


class LostSpaceArena:
    def __init__(
        self,
        *,
        backend: ProcessSpec,
        backend_env: Mapping[str, str],
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
    ) -> None:
        self.backend = backend
        self.backend_env = dict(backend_env)
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)

    def run_match(
        self,
        *,
        match_id: str,
        seed: int,
        prepared_players: Sequence[PreparedPlayer],
    ) -> MatchResult:
        root = self.artifact_root / match_id / f"seed-{seed}"
        specs = [ProcessSpec(player.argv, player.cwd) for player in prepared_players]
        try:
            return run_saiblo_match(
                backend=self.backend,
                players=specs,
                backend_env=self.backend_env,
                replay_path=root / "replay.json",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            LostSpaceMatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                status="incomplete",
                ranking=None,
                winner_player=None,
                rounds=None,
                error=str(exc),
            )

"""LostSpace 回放 → 自然语言。

LostSpace（第 25 届）在 8 个游戏里是唯一的**四人局**（``P0..P3``），而且是不完全信息
的探索/逃脱游戏：找钥匙 → 开门 → 逃出去，中途可以互相攻击、放地雷、放粘液。

回放形状特殊，容易读错，先说清：

    [ birth_positions, round_1, round_2, ..., score_dic ]

* 首元素是 4 个出生点；
* **末元素是名次分字典** ``{"0":4, "1":2, ...}``（4=第一名，逐级递减）——
  它不是"分数"，是**名次**，越大越好；
* 中间每个元素是一个大回合，形状是"按玩家索引的四个列表"，每个列表是该玩家在这一
  大回合里的动作记录（``move`` / ``attack`` / ``detect`` / ``getkey`` / ``escaped`` …）。

四人局对叙述的影响很大：胜负不是"你赢了/输了"，而是**名次**。所以叙述必须回答
"我第几名、谁逃掉了、我是被谁拖住的"，而不是二元胜负。
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, budget_lines, render_events

from . import replay as replay_decoder

#: 动作类型 → 人话。取自 replay_format.md 与后端 `src/replay.py`。
_ACTIONS: dict[str, str] = {
    "move": "移动",
    "attack": "攻击",
    "detect": "探测",
    "inspect": "查看/交互",
    "interact": "交互",
    "getkey": "拿到密钥",
    "keymachine": "开启钥匙机",
    "escape_capsule": "进入逃生舱",
    "died": "死亡",
    "escaped": "成功逃脱",
    "map_update": "地图信息更新",
    "tool_update": "道具更新",
    "hp_update": "生命值变化",
    "trap_triggered": "触发陷阱",
    "see": "看到其他玩家",
    "ai_error": "AI 错误",
}


def _describe(record: Mapping[str, object]) -> str:
    kind = str(record.get("type", "?"))
    name = _ACTIONS.get(kind, f"未识别动作 {kind}")
    position = record.get("pos") or record.get("tar_pos")
    detail = name
    if isinstance(position, list):
        detail += f" → {position}"
    if kind == "attack" and record.get("target") is not None:
        detail += f"（目标 P{record.get('target')}）"
    if kind == "getkey":
        detail += f"（密钥 {record.get('keyid')}）"
    if kind == "inspect" and record.get("interprops"):
        detail += f"（对象：{record.get('interprops')}）"
    if kind == "tool_update" and isinstance(record.get("tools"), Mapping):
        held = {
            key: value
            for key, value in record["tools"].items()  # type: ignore[union-attr]
            if value not in (0, [0, 0], None)
        }
        detail += f"（持有：{held or '空'}）"
    if kind == "hp_update":
        detail += f"（HP={record.get('hp')}）"
    return detail


def _ranking(report: replay_decoder.ReplayReport, context: NarrationContext) -> list[str]:
    """把名次分讲成名次。这是四人局唯一有意义的"结果"。"""

    scores = report.score_dic
    if not scores:
        return ["- 回放里没有名次信息。"]
    ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    lines = ["- 最终名次（名次分越大越靠前）："]
    for place, (player, score) in enumerate(ordered, start=1):
        role = f"P{player}"
        marker = " ← **你**" if context.perspective == role else ""
        lines.append(f"  {place}. {context.label(role)}（名次分 {score}）{marker}")
    if context.perspective is not None:
        own = scores.get(context.perspective.removeprefix("P"))
        if own is not None:
            place = [player for player, _ in ordered].index(
                context.perspective.removeprefix("P")
            ) + 1
            lines.append(
                f"- **你排第 {place} / {len(ordered)} 名**。"
            )
    return lines


def _escape_and_death(
    rounds: Sequence[object], context: NarrationContext
) -> list[str]:
    """谁逃掉了、谁死了、在第几回合 —— 决定名次的直接事件。"""

    lines: list[str] = []
    keys: dict[str, list[int]] = {}
    for round_index, big_round in enumerate(rounds, start=1):
        if not isinstance(big_round, list):
            continue
        for per_player in big_round:
            if not isinstance(per_player, list):
                continue
            for record in per_player:
                if not isinstance(record, Mapping):
                    continue
                kind = record.get("type")
                player = record.get("playerid")
                if not isinstance(player, int):
                    continue
                role = f"P{player}"
                if kind == "escaped":
                    lines.append(
                        f"- 第 {round_index} 回合：{context.label(role)} **成功逃脱**（锁定名次）"
                    )
                elif kind == "died":
                    lines.append(f"- 第 {round_index} 回合：{context.label(role)} **死亡**")
                elif kind == "getkey":
                    keys.setdefault(role, []).append(round_index)
    for role, when in sorted(keys.items()):
        lines.append(
            f"- {context.label(role)} 共拿到 {len(when)} 次密钥，"
            f"首次在第 {when[0]} 回合。"
        )
    return lines or ["- 回放没有记录逃脱、死亡或密钥事件。"]


def _state_deltas(rounds: Sequence[object], context: NarrationContext) -> list[str]:
    lines: list[str] = []
    previous_hp: dict[str, float] = {}
    for round_index, big_round in enumerate(rounds, start=1):
        if not isinstance(big_round, list):
            continue
        for per_player in big_round:
            if not isinstance(per_player, list):
                continue
            for record in per_player:
                if not isinstance(record, Mapping) or record.get("type") != "hp_update":
                    continue
                player = record.get("playerid")
                hp = record.get("hp")
                if not isinstance(player, int) or not isinstance(hp, (int, float)):
                    continue
                role = f"P{player}"
                current = float(hp)
                if role in previous_hp and previous_hp[role] != current:
                    old = previous_hp[role]
                    lines.append(
                        f"- 第 {round_index} 回合：{context.label(role)} HP "
                        f"{old:g}→{current:g}（{current - old:+g}）。"
                    )
                previous_hp[role] = current
    return lines or ["- 回放未记录可计算的相邻 HP 数值变化。"]


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    report = replay_decoder.decode_replay(replay_path)
    document = json.loads(replay_path.read_text(encoding="utf-8"))
    body = document[1:-1] if isinstance(document, list) and len(document) >= 2 else []

    verdict: list[str] = []
    winner = context.official_winner
    if winner is None and report.winner_player is not None:
        winner = f"P{report.winner_player}"
    verdict.append(f"- 第一名：{context.label(winner) if winner else '未知'}。")
    verdict.append(
        f"- 出生点：{[list(pos) for pos in report.birth_positions]}"
        "（四人分居四角，开局距离是对称的）。"
    )
    verdict.append(f"- 共 {report.rounds} 个大回合 / {report.turns} 个小回合。")
    if context.diagnostic:
        verdict.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")

    events: list[Event] = []
    for round_index, big_round in enumerate(body, start=1):
        if not isinstance(big_round, list):
            continue
        for per_player in big_round:
            if not isinstance(per_player, list):
                continue
            for record in per_player:
                if not isinstance(record, Mapping):
                    continue
                player = record.get("playerid")
                role = f"P{player}" if isinstance(player, int) else "?"
                kind = str(record.get("type", ""))
                events.append(
                    Event(
                        round=round_index,
                        actor=context.label(role),
                        text=_describe(record),
                        ref=f"r{round_index:04d}:p{player}",
                        # 单纯走位会连成长串；拿钥匙/攻击/死亡/逃脱永不折叠。
                        fold_key=f"move-{role}" if kind in {"move", "detect"} else "",
                        fold_label="移动/探测（无交互）",
                    )
                )

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"LostSpace 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"四人局，共 {report.rounds} 大回合 / {len(events)} 条动作。"
            "由 A 仓 `aa_arena.replay` 从官方回放翻译。"
            "名次、逃脱、死亡、密钥与 HP 均按公开记录陈述。"
        ),
    )
    doc.section("终局事实", verdict + _ranking(report, context) + _escape_and_death(body, context))
    state_lines = _state_deltas(body, context)
    if context.detail != "full":
        state_lines = budget_lines(state_lines, 160)
    doc.section("状态变化与数值增量", state_lines)
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=240)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=240。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="lostspace",
        match_id=context.match_id,
        text=doc.render(),
        rounds=context.official_rounds or report.rounds,
        winner=winner,
        highlights={
            "score_dic": dict(report.score_dic),
            "turns": report.turns,
            "actions": len(events),
        },
    )

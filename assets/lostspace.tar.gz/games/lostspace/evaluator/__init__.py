"""LostSpace（失落深空 / 25 届）对战器 —— 满足 `aa_arena.core.Evaluator` 协议。

LostSpace 是四人对抗对战（Saiblo Game.code）。本包对外暴露 `LostSpaceEvaluator`，
其 `evaluate(players, roles, seed) -> EvaluateResult`：

- 定位官方 Python 后端并做**依赖预检**（已安装的 antlr4 运行时 + typing.io
  兼容 shim），在现代解释器上真跑；预检失败时**诚实返回 infra_error**；
- 按 Saiblo judge 协议（N 人异步双向泵）驱动后端与四名选手完成一局；
- 从终局名次分（4=第一名递减）裁决胜负，返回可复现结果；
- 三态：后端/选手池/依赖准备失败 = `infra_error`；选手崩溃/超时/后端异常 =
  `game_error`；正常终局 = `complete`。
"""

from __future__ import annotations

import sys
from pathlib import Path

from aa_arena.core.buildcache import backend_run_dir
from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError
from aa_arena.core.player_entry import find_python_entry
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    LostSpaceArena,
    LostSpaceMatchError,
    MatchResult,
    ProcessSpec,
    run_saiblo_match,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    LostSpaceLayout,
    LostSpaceRuntimeError,
    Opponent,
    PreparedPlayer,
    audit_human_pool,
    backend_environment,
    prepare_player,
    tree_sha256,
)

__all__ = [
    "LostSpaceArena",
    "LostSpaceEvaluator",
    "LostSpaceLayout",
    "LostSpaceMatchError",
    "LostSpaceRuntimeError",
    "MatchResult",
    "Opponent",
    "PreparedPlayer",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "backend_environment",
    "decode_replay",
    "make_evaluator",
    "prepare_player",
    "run_saiblo_match",
    "tree_sha256",
]

_EXPECTED_PLAYERS = 4
_EXPECTED_ROLES = ("P0", "P1", "P2", "P3")


class LostSpaceEvaluator:
    """LostSpace 对战器：四名选手一局，返回名次感知的契约结果。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "lostspace-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "lostspace-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != _EXPECTED_PLAYERS or len(roles) != _EXPECTED_PLAYERS:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=(
                    f"lostspace requires exactly {_EXPECTED_PLAYERS} players/roles, "
                    f"got {len(players)}/{len(roles)}"
                ),
            )
        if list(roles) != list(_EXPECTED_ROLES):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"lostspace roles must be {list(_EXPECTED_ROLES)}, got {roles}",
            )

        layout = LostSpaceLayout.from_game_dir(self.game_dir, self._build_root)

        # 后端定位 + 依赖预检 + 选手池审计 + 选手准备：失败均属基础设施故障。
        try:
            layout.validate()
            backend_env = backend_environment(self._build_root)
            pool = audit_human_pool(layout)
            map_file = layout.backend_source_root / "src" / "mapconf2.map"
            prepared = [
                self._resolve_player(
                    player, pool=pool, build_root=self._build_root, map_file=map_file
                )
                for player in players
            ]
        except (
            LostSpaceRuntimeError,
            LostSpaceMatchError,
            PlayerEnvironmentError,
            FileNotFoundError,
            OSError,
        ) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool/dependency preparation failed: {exc}",
            )

        match_id = "-".join(player.player_id for player in players)
        # 后端必须在**可写、每局独占**的目录里跑，绝不能直接用 A 仓源码树。
        # 理由与 generals 的事故完全一样（后端往 cwd 写文件失败会被翻译成
        # "选手非法操作"），详见 aa_arena.core.buildcache.backend_run_dir。
        try:
            with backend_run_dir(
                layout.backend_source_root, parent=self._build_root, tag="lostspace-backend"
            ) as backend_cwd:
                backend_spec = ProcessSpec((sys.executable, "main.py"), backend_cwd)
                arena = LostSpaceArena(
                    backend=backend_spec,
                    backend_env=backend_env,
                    artifact_root=self._artifact_root,
                    timeout_s=self.timeout_s,
                )
                result = arena.run_match(
                    match_id=match_id, seed=seed, prepared_players=prepared
                )
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend run dir preparation failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        return self._to_evaluate_result(result, roles)

    # -- helpers -----------------------------------------------------------

    def _resolve_player(
        self,
        player: PlayerRef,
        *,
        pool: tuple[Opponent, ...],
        build_root: Path,
        map_file: Path | None = None,
    ) -> PreparedPlayer:
        if player.code_path is not None:
            root = Path(player.code_path).resolve()
            opponent = Opponent(
                opponent_id=player.player_id,
                rank=0,
                username=None,
                score=None,
                lang="python" if find_python_entry(root) is not None else "make",
                package_root=root,
                runnable=True,
                exclusion_diagnostic=None,
            )
            prepared = prepare_player(opponent, build_root=build_root, map_file=map_file)
            return PreparedPlayer(player.player_id, prepared.argv, prepared.cwd)
        for opponent in pool:
            if opponent.opponent_id == player.player_id and opponent.runnable:
                prepared = prepare_player(opponent, build_root=build_root, map_file=map_file)
                return PreparedPlayer(player.player_id, prepared.argv, prepared.cwd)
        raise LostSpaceMatchError(
            f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
        )

    def _to_evaluate_result(
        self,
        result: MatchResult,
        roles: list[str],
    ) -> EvaluateResult:
        ranking = result.ranking
        if ranking is None or len(ranking) != len(roles):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing ranking payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        # players[i] 映射 roles[i]；名次分 4=第一名。
        scores = {roles[i]: float(ranking[i]) for i in range(len(roles))}
        winner = roles[int(result.winner_player)] if result.winner_player is not None else None
        return EvaluateResult(
            status=EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
        )


def make_evaluator(game_dir: Path) -> LostSpaceEvaluator:
    """插件工厂：供 `games/lostspace/plugin.py` 装配对战器。"""

    return LostSpaceEvaluator(game_dir)

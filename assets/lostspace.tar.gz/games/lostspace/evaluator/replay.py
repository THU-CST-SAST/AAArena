"""LostSpace 回放解码 —— 后端产出的 JSON 回放解析为结构化报告。

回放是一个 JSON 数组 `lines`（后端 `src/replay.py`）：

    [ birth_positions, round_1, round_2, ..., score_dic ]

- `birth_positions`：长度 4 的列表，每项为 `[x-3, y-3, 1]`（回放坐标系）；
- 每个 `round_k`：一个大回合，是若干“小回合”的列表，每个小回合又是该回合内
  各玩家动作记录（move/attack/detect/died/getkey/map_update/... 见 `replay_format.md`）；
- 末元素 `score_dic`：`{"0":名次分, "1":..., "2":..., "3":...}`，4=第一名递减。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ReplayReport:
    birth_positions: tuple[tuple[int, int, int], ...]
    rounds: int
    turns: int
    score_dic: dict[str, int]
    winner_player: int | None


def decode_replay(path: str | Path) -> ReplayReport:
    data: Any = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, list) or len(data) < 2:
        raise ValueError("replay must be a JSON array with header and score_dic")

    header = data[0]
    birth = tuple(
        tuple(int(v) for v in pos) for pos in header if isinstance(pos, (list, tuple))
    )

    score_dic_raw = data[-1]
    if not isinstance(score_dic_raw, dict):
        raise TypeError("replay tail is not a score_dic object")
    score_dic = {str(k): int(v) for k, v in score_dic_raw.items()}

    rounds = 0
    turns = 0
    for element in data[1:-1]:
        if isinstance(element, list):
            rounds += 1
            turns += sum(1 for turn in element if isinstance(turn, list))

    winner_player: int | None = None
    if score_dic:
        winner_player = int(max(score_dic, key=lambda k: score_dic[k]))

    return ReplayReport(
        birth_positions=birth,
        rounds=rounds,
        turns=turns,
        score_dic=score_dic,
        winner_player=winner_player,
    )

"""LostSpace（失落深空 / 25 届）后端资源定位、依赖预检与选手准备。

LostSpace 是四人对抗对战（Saiblo Game.code）。本模块不依赖框架层，负责：

- 定位本 GamePack 内的官方 Python 后端 `backend/`；
- 审计冻结的人类天梯选手池 `games/lostspace/players/pool/`；
- 把选手准备为可运行进程规格（Python 直接跑 `main.py`；`make`/C++ 编译）；
- **后端依赖预检**：后端用 ANTLR 解析地图配置生成星图，需要
  ``antlr4-python3-runtime==4.9.1``；且其生成代码使用 ``from typing.io import TextIO``，
  在现代 Python 中已移除。本模块检查已安装的运行时并生成一个
  ``sitecustomize``/``typing.io`` 兼容 shim，供后端进程通过 ``PYTHONPATH`` 加载。
"""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import shutil
import textwrap
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.buildcache import published_build_dir
from aa_arena.core.cpp_build import (
    CppBuildError,
    build_cpp_player,
    has_cpp_build,
    native_build_root,
)
from aa_arena.core.player_environment import player_command
from aa_arena.core.player_entry import find_build_dir, find_python_entry


class LostSpaceRuntimeError(RuntimeError):
    """冻结运行时资源未通过完整性/准备要求。"""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)
_GAME_DIR = Path(__file__).resolve().parents[1]


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise LostSpaceRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class LostSpaceLayout:
    aa_arena_root: Path
    build_root: Path
    backend_source_root: Path
    human_manifest: Path
    human_pool_root: Path

    @classmethod
    def from_game_dir(
        cls, game_dir: str | Path, build_root: str | Path
    ) -> LostSpaceLayout:
        game = Path(game_dir).resolve()
        players = game / "players"
        return cls(
            aa_arena_root=game.parents[1],
            build_root=Path(build_root).resolve(),
            backend_source_root=game / "backend",
            human_manifest=players / "manifest.tsv",
            human_pool_root=players / "pool",
        )

    @classmethod
    def from_root(cls, aa_arena_root: str | Path, build_root: str | Path) -> LostSpaceLayout:
        return cls.from_game_dir(Path(aa_arena_root) / "games" / "lostspace", build_root)

    def validate(self) -> None:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        if not (self.backend_source_root / "main.py").is_file():
            raise FileNotFoundError(self.backend_source_root / "main.py")
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_pool_root.is_dir():
            raise FileNotFoundError(self.human_pool_root)


@dataclass(frozen=True)
class PreparedPlayer:
    player_id: str
    argv: tuple[str, ...]
    cwd: Path


@dataclass(frozen=True)
class Opponent:
    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    lang: str
    package_root: Path
    runnable: bool
    exclusion_diagnostic: str | None


def audit_human_pool(layout: LostSpaceLayout) -> tuple[Opponent, ...]:
    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            packages = tuple(sorted(layout.human_pool_root.glob(f"rank{rank:02d}__*")))
            if not packages:
                continue
            package = packages[0]
            lang = (row.get("lang") or "").strip().lower()
            runnable, diagnostic = _classify_runnable(package)
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    lang=lang,
                    package_root=package,
                    runnable=runnable,
                    exclusion_diagnostic=diagnostic,
                )
            )
    pool.sort(key=lambda item: item.rank)
    return tuple(pool)


def _find_python_entry(package: Path) -> Path | None:
    """定位 Python 选手入口所在目录（含 main.py 的目录，作为 cwd）。

    - 顶层含 main.py：直接用顶层；
    - `python_zip` 打包：源码在唯一子目录里（子目录含 main.py），用该子目录
      （选手常用同目录相对 import，故 cwd 必须落在 main.py 所在目录）。
    """

    return find_python_entry(package)


def _classify_runnable(package: Path) -> tuple[bool, str | None]:
    if _find_python_entry(package) is not None:
        return True, None
    if has_cpp_build(package):
        return True, None
    return False, "no runnable entry (main.py / makefile) found"


def prepare_player(
    opponent: Opponent,
    *,
    build_root: Path,
    map_file: Path | None = None,
) -> PreparedPlayer:
    """把选手准备为可运行进程规格。

    LostSpace 选手（尤其 C++ SDK）会在运行目录读取地图文件 ``mapconf2.map``
    （见 ai_client.cpp::_read_map），因此本函数把选手源码拷入 gitignore 的
    ``build_root`` 可写运行目录，并放入后端使用的同一份 ``mapconf2.map``：
    - Python：在运行目录内 ``python main.py``；
    - make/C++：在运行目录 ``make`` 出可执行 ``main`` 并运行。
    构建/布置按目录树哈希缓存，pool 目录保持只读。
    """

    package = opponent.package_root
    native_entry = find_build_dir(package, allow_cmake=False)
    is_native = opponent.lang in {"make", "cpp", "c++"} or has_cpp_build(package)
    entry_dir = _find_python_entry(package)
    if not is_native and entry_dir is None:
        raise LostSpaceRuntimeError(
            f"player {opponent.opponent_id} is not runnable: {opponent.exclusion_diagnostic}"
        )

    relative = (
        native_entry.relative_to(package)
        if is_native and native_entry is not None
        else entry_dir.relative_to(package)
        if entry_dir is not None
        else Path(".")
    )
    if is_native:
        runtime_files = (
            {(relative / "mapconf2.map").as_posix(): map_file}
            if map_file is not None and map_file.is_file()
            else None
        )
        try:
            executable = build_cpp_player(
                player_dir=package,
                game_dir=_GAME_DIR,
                cache_root=build_root / "players",
                runtime_files=runtime_files,
            )
        except CppBuildError as exc:
            raise LostSpaceRuntimeError(
                f"native player {opponent.opponent_id} build_error: {exc}"
            ) from exc
        run_dir = native_build_root(executable) / relative
        return PreparedPlayer(
            opponent.opponent_id, (str(executable),), run_dir
        )

    fingerprint = tree_sha256(package)
    root = build_root / "players" / f"{opponent.opponent_id}-{fingerprint[:16]}"

    # 并发安全：评分时同一个选手会同时出现在多局里，原来的 `.ready` 标记挡不住
    # 竞态——两个 worker 都看到"没准备好"，一起 rmtree + copytree + make，
    # 实测打出 `make: getcwd: No such file or directory`（工作目录在 make 运行中
    # 被删），lostspace 798 局里 101 局因此作废。改成"先建后换"。
    #
    # 地图文件也必须在**发布前**放进暂存目录：发布后再 copyfile 会有多个 worker
    # 同时写同一个文件的窗口，选手可能读到被截断的地图。
    with published_build_dir(
        root,
        source=package,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    ) as (work, reused):
        if not reused:
            if map_file is not None and map_file.is_file():
                destination = work / relative / "mapconf2.map"
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not destination.is_file():
                    shutil.copyfile(map_file, destination)

    run_dir = root / relative
    return PreparedPlayer(opponent.opponent_id, player_command(), run_dir)


def _has_makefile(package: Path) -> bool:
    return has_cpp_build(package)


# ---------------------------------------------------------------------------
# 后端依赖预检：antlr4 运行时 + typing.io shim
# ---------------------------------------------------------------------------

def backend_environment(build_root: Path) -> dict[str, str]:
    """Validate the installed ANTLR runtime and return the compatibility path."""

    if importlib.util.find_spec("antlr4") is None:
        raise LostSpaceRuntimeError(
            "LostSpace requires antlr4-python3-runtime==4.9.1; "
            "install it with: pip install -e '.[lostspace]'"
        )
    shim_dir = build_root / "backend-deps" / "shim"
    _write_typing_io_shim(shim_dir)
    return {"PYTHONPATH": str(shim_dir)}


def _write_typing_io_shim(shim_dir: Path) -> None:
    """生成一个 sitecustomize，运行时把 ``typing.io`` 注册为 typing 的别名模块。

    ANTLR 生成代码顶层 ``from typing.io import TextIO``；``typing.io`` 在
    Python 3.12 起被移除。sitecustomize 在解释器启动早期自动导入，我们在其中把
    一个提供 TextIO/BinaryIO/IO 的模块注册进 ``sys.modules['typing.io']``。
    """

    shim_dir.mkdir(parents=True, exist_ok=True)
    (shim_dir / "sitecustomize.py").write_text(
        textwrap.dedent(
            """
            # Auto-generated by LostSpace evaluator runtime.
            # Restore the removed ``typing.io`` submodule for legacy ANTLR codegen.
            import sys
            import types
            import typing

            if "typing.io" not in sys.modules:
                module = types.ModuleType("typing.io")
                module.IO = typing.IO
                module.TextIO = typing.TextIO
                module.BinaryIO = typing.BinaryIO
                sys.modules["typing.io"] = module
                try:
                    typing.io = module  # type: ignore[attr-defined]
                except Exception:
                    pass
            """
        ).strip()
        + "\n",
        encoding="utf-8",
    )

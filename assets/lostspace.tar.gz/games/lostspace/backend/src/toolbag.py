'''
update 2020.11.27 考虑到目前只有Kit一种道具，将其合并在此
update 2020.1.25 修复了nums_dict忘了返回的bug
update 2020.1.25 修复了未从放置位置删除陷阱的bug
update 2021.3.6  由于tolist和to_tuple函数完全一致，删除了tolist函数
update 2021.3.21 修改了use_tool，使返回值个数正确
'''
from .traps import *
from .tools import *
from .config import *

class ToolBag:
    def __init__(self, player):
        self.placed = {trap: [] for trap in TrapList}
        self.has = {trap: 0 for trap in TrapList}
        self.player = player
        self.tools = {'Kit': Kit(self.player), 'Transport': Transport(self.player)}
        self.init ={'LandMine': LandMine, 'Sticky': Sticky,}

    def nums_dict(self) -> dict:
        dic = self.has.copy()
        dic.update({ self.tools[key].num() for key in self.tools })
        return dic

    def place(self, type: str) -> bool:
        if self.has[type] == 0:
            return False
        trap = self.init[type](self.player, self.player.pos)
        if not self.player.gamecontroller.map.place_trap(self.player.pos, trap):
            del trap
            return False
        self.placed[type].append(trap)
        self.has[type] -= 1
        return True

    def use_tool(self, type:str, pos:list=None):
        if type == "Kit":
            return self.tools[type].use()
        else:
            return self.tools[type].use(pos)

    def disable(self, type, pos):
        trap_id = self.find_trap(type, pos)
        node =self.player.gamecontroller.map.get_node_by_position(pos)
        node.delete_trap()
        assert trap_id != -1
        return self.placed[type].pop(trap_id)

    def inandout(self, content:dict):
        for key in self.tools:
            if key in content:
                taken = content[key] if self.tools[key].num() + content[key] <= self.tools[key].MAX_CARRY \
                    else self.tools[key].MAX_CARRY - self.tools[key].num()
                if not self.tools[key].add(taken):
                    raise RuntimeError('tool num Error: '+key)
                content.pop(key)

        for key in content.keys():
            taken = MaxCarry[key] - self.has[key] if self.has[key] + content[key] > MaxCarry[key] \
                                                    else content[key]
            self.has[key] += taken

        #replay 记录道具变化
        self.player.gamecontroller.replay.tool_update(self.player.id, self.todict())
        return True

    def todict(self) -> dict:
        dic = { trap: [] for trap in TrapList }
        for key in dic.keys():
            dic[key].append(self.has[key])
            dic[key].append(len(self.placed[key]))
            dic[key] += [trap.pos.to_tuple() for trap in self.placed[key]]
        for key in self.tools:
            dic[key] = self.tools[key].num()
        return dic

    def find_trap(self, type, pos):
        list = self.placed[type]
        l = len(list)
        for i in range(l):
            if list[i].pos == pos:
                return i
        return -1

    def clear(self):
        for key in self.has.keys():
            self.has[key] = 0
        for tool in self.tools:
            self.tools[tool].clear()
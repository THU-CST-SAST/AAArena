'''
Update 2021.3.6  由于tolist和to_tuple函数完全一致，删除了tolist函数
Update 2021.3.19 根据策划案修改了interact、get_view函数和Node的deathdrop函数；禁用了门，但部分Door相关代码未删除
Update 2021.3.21 修改了interact的返回值为False和True；添加interact中非法交互的判断
Update 2021.3.26 增加了楼下的钥匙机的初始化
'''
from typing import Any, List, Dict, Tuple, Union
from copy import copy

from .interactive_props import *
from .config import *
from .position import Position

class Node:
    def __init__(self, position: Position) -> None:
        self.position = copy(position)

        # 已经将self.tools 修改为 self.interprops 并新添self.box
        self.interprop: Union[None, InterProps] = None  # 场景交互道具
        self.box: Union[None, Box] = None  # 掉落池
        self.trap = None  # 陷阱，最多只有一个
        self.edges: List['Edge'] = []  # 物理可达边
        self.able: bool = True  # 缩圈（是否可达）
        self.players = []  # 玩家数组
        self.visible: bool = True  # 指示有没有被控制台屏蔽


    def __str__(self) -> str:
        return 'Node in ' + str(self.position.to_tuple())

    def todict(self) -> Dict[str, Union[List[int], List[str]]]:
        dic: Dict[str, Union[List[int], List[str]]] = {
            "pos": self.position.to_tuple(),
            "interprops": [],
            "player": [player.id for player in self.players]
        }
        if self.interprop is not None:
            dic['interprops'].append(self.interprop.name)
        if self.box is not None:
            dic['interprops'].append(self.box.name)
        return dic

    def find_edge_to(self, point: 'Node') -> Union['Edge', None]:
        if point is self:
            return None
        for edge in self.edges:
            if edge.contain(point):
                return edge

    def add_edge(self, edge: 'Edge') -> None:
        self.edges += [edge]

    def add_trap(self, trap) -> bool:
        if self.trap is not None:
            return False
        if (self.position.x, self.position.y) in ELEVATOR:
            return False
        if self.interprop is not None:
            if self.interprop.name in ['KeyMachine', 'EscapeCapsule']:
                return False
        self.trap = trap
        return True

    def add_player(self, player) -> bool:
        if player in self.players:
            return False

        self.players.append(player)
        if self.trap:
            self.trap.trigger(player)
        return True

    def delete_trap(self) -> bool:
        if self.trap is not None:
            self.trap = None
            return True

        return False

    def delete_player(self, player) -> bool:
        if player in self.players:
            self.players.remove(player)
            return True
        return False

    # 已经修改
    def add_interprop(self, interprop: InterProps) -> bool:
        if self.interprop is None:
            self.interprop = interprop
            return True
        return False

    def delete_interprop(self) -> bool:
        if self.interprop is None:
            return False
        self.interprop = None
        return True

    def death_drop(self, keyids: list) -> bool:  # 掉包，返回值为是否添加了新box
        newbox = False
        if self.box is None:
            self.box = Box(set(keyids), self)
            newbox = True
        else:
            self.box.add_keys(keyids)
        return newbox

    def shrink(self) -> None:
        self.able = False
        for player in self.players:
            player.died()

    # 仅用于map的get_view，其他同学不用理会
    def to_view(self) -> List[Union[Tuple[int, ...], Tuple[str, ...]]]:
        return_list = [
            self.position.to_tuple(),
            self.box is not None
        ]

        if len(self.players) > 0:
            return_list += [tuple(player.id for player in self.players)]

        return return_list


class Edge:
    def __init__(self, start_node: Node, end_node: Node) -> None:
        self.start_node = start_node
        self.end_node = end_node
        self.door = None

    def tolist(self) -> List[Union[List[int], bool]]:
        return_list: List[Union[List[int], bool]] = [self.start_node.position.to_tuple(), self.end_node.position.to_tuple(), self.door is not None]
        if self.door is not None:
            return_list.append(self.door.open)
        return return_list

    def contain(self, node: Node) -> bool:
        return self.start_node is node or self.end_node is node

    def usable(self) -> bool:
        return self.door.is_open() if self.door is not None else True

    def direction(self) -> Position:
        return self.end_node.position - self.start_node.position

    # 按照从左下到右上的规则存储的区域块，仅在map的shrink部分代码里面用到，其他同学不用理会


class Block:
    def __init__(self, position_1: Position, position_2: Position) -> None:
        assert (position_1.z == position_2.z)

        self.x: Tuple[int, int] = tuple(sorted((position_1.x, position_2.x)))
        self.y: Tuple[int, int] = tuple(sorted((position_1.y, position_2.y)))

        self.z = position_2.z


class Map:
    def __init__(self, _: Any = None) -> None:
        self.length = MAP_LENGTH
        self.width = MAP_WIDTH
        self.height = MAP_HEIGHT

        self.all_players = []

        # 地图初始化，注意一开始都是空点，需要进行读入
        self.map_nodes: List[List[List[Union[None, Node]]]] = [[[None for z in range(self.height)] for y in range(self.width)] for x in range(self.length)]

        self.shrink_info: Dict[int, List[Block]] = dict()

    def login_shrink_info(self, time: int, block: Block) -> None:
        if time not in self.shrink_info:
            self.shrink_info[time] = []

        self.shrink_info[time] += [block]

    def add_node(self, position: Position) -> Union[Node, None]:
        if not self.position_in_map(position):
            return None

        new_node = Node(position)
        self.map_nodes[position.x][position.y][position.z] = new_node

        return new_node

    def add_edge(self, node_1: Union[Node, None], node_2: Union[Node, None], has_door: bool = False) -> Union[Edge, None]:
        if node_1 is None or node_2 is None:
            return None

        if node_1.find_edge_to(node_2) is not None:
            return None

        new_edge = Edge(node_1, node_2)
        node_1.add_edge(new_edge)
        node_2.add_edge(new_edge)

        return new_edge

    def add_material(self, position: Position, is_super: bool = False) -> None:
        node = self.get_node_by_position(position)
        if node is not None:
            node.add_interprop(Materials())

    def add_hmaterial(self, position: Position) -> None:
        self.add_material(position, True)

    def add_elevator(self, x: int, y: int) -> None:
        pass

    def add_door(self, node_1: Node, node_2: Node) -> None:
        raise DeprecationWarning('Interprop Door already deleted! ')

    def login_players(self, players) -> None:
        self.all_players = players

        for i in range(4):
            player = self.all_players[i]
            node = self.get_node_by_position(player.pos)
            assert (node is not None)
            node.add_player(player)
            node.add_interprop(KeyMachine(i))
            down_stair_key_machine = self.get_node_by_position(Position(player.pos.x, player.pos.y, 2))
            assert down_stair_key_machine is not None
            down_stair_key_machine.add_interprop(KeyMachine(i))


    def add_esacpe_capsule(self):
        # 添加逃生舱
        EscapeCapsuleNode = self.get_node_by_position(
            Position(EscapeCapsulePos[0], EscapeCapsulePos[1], EscapeCapsulePos[2]))
        EscapeCapsuleNode.interprop = EscapeCapsule()
        return EscapeCapsuleNode.interprop

    def position_in_map(self, position: Position) -> bool:
        return 0 <= position.x < self.length and 0 <= position.y < self.width and 0 <= position.z < self.height

    def get_node_by_position(self, position: Position) -> Union[None, Node]:
        if self.position_in_map(position):
            return self.map_nodes[position.x][position.y][position.z]

    def get_node_in_region(self, region: list) -> list:
        assert len(region) == 5
        region[1] += 1
        region[3] += 1
        z = region[4]
        nodelist = []
        for x in range(region[0], region[1]):
            for y in range(region[2], region[3]):
                node = self.get_node_by_position(Position(x, y, z))
                if node is not None:
                    nodelist.append(node)
        return nodelist

    # 非法返回-1，合法返回经过的边数（因为现在每次玩家只移动一格，所以就是返回1）
    # 没有调用player的函数，只更新map中点的信息
    # 为了方便判断，将该部分拆成两部分，玩家位置信息更新单独位于 update_player_pos(...)，并将函数更名
    def move_distance(self, player, destination: Position) -> int:
        pos = self.get_node_by_position(player.pos)
        if pos is None or player not in pos.players:
            raise AssertionError('player pos register error!')

        des_node = self.get_node_by_position(destination)
        if des_node is None:
            return -1

        if player.pos.z != destination.z:
            if player.pos.x != destination.x or player.pos.y != destination.y or (destination.x, destination.y) not in ELEVATOR:
                return -1
            else:
                return 1

        edge = pos.find_edge_to(des_node)

        if edge is None or not edge.usable():
            return -1
        return 1

    def update_player_pos(self, player, destination: Position) -> None:
        pos = self.get_node_by_position(player.pos)
        player.pos = destination  # 添加了 更新player内部存储的位置值
        dest = self.get_node_by_position(player.pos)
        assert (pos is not None)
        pos.delete_player(player)
        # 在add_player中添加陷阱触发，因为可能恰好复活在了陷阱上
        assert (dest is not None)
        dest.add_player(player)

    # 判断两个点是否相邻
    def next_to(self, pos1: Position, pos2: Position) -> Union[bool, int]:
        node1 = self.get_node_by_position(pos1)
        node2 = self.get_node_by_position(pos2)
        if node2 is None or node1 is None:
            return -1
        edge = node1.find_edge_to(node2)
        if edge is None:
            return False
        return edge.usable()

    # 判断 pos1处能否看到pos2处
    def can_see(self, pos1: Position, pos2: Position) -> int:
        node1 = self.get_node_by_position(pos1)
        node2 = self.get_node_by_position(pos2)
        if node2 is None or node1 is None:
            return -1

        # 改为仅提供同层视野，但同层视野都可见
        return int(pos1.z == pos2.z)

    def place_trap(self, pos: Position, trap) -> bool:
        node = self.get_node_by_position(pos)
        assert (node is not None)
        return node.add_trap(trap)

    def shrink_by_block(self, block: Block) -> None:
        for x in range(block.x[0], block.x[1] + 1):
            for y in range(block.y[0], block.y[1] + 1):
                possible_node = self.get_node_by_position(Position(x, y, block.z))

                if possible_node is not None:
                    possible_node.shrink()

    def shrink(self, time_now: int) -> None:
        for time, blocks in self.shrink_info.items():
            if time > time_now:
                continue

            for block in blocks:
                self.shrink_by_block(block)

    # 建议写的同学修改一下，重构一下逻辑并加上更详尽的标注使之通过mypy检查
    def interact(self, comdict: dict, cmd: list, player) -> bool:
        # 与场景交互道具交互
        node = self.get_node_by_position(player.pos)
        if node is None:
            return False
        if cmd[1] == 'Materials' or cmd[1] == 'EscapeCapsule':
            assert len(cmd) == 3
            if cmd[1] == 'EscapeCapsule':
                assert cmd[2] in [True, False]
            else:
                assert cmd[2] in ToolList
            if node.interprop is None:
                return False
            if node.interprop.name != cmd[1]:
                return False
            success = node.interprop.interact_2(player, cmd[2])
        elif cmd[1] == 'KeyMachine':
            if node.interprop is None:
                return False
            if node.interprop.name != cmd[1]:
                return False
            success = node.interprop.interact(player)
        else:   # Box
            box = node.box
            if box is None:
                return False
            success = box.interact(player)
        return success != -1

    # 这个函数是用来供电梯换层之后的全层视野更新使用的
    # 使用爆搜算法，所以请控制调用次数
    def get_view(self, z: int) -> Dict[str, List[List[Union[Tuple[int, ...], Tuple[str, ...], bool]]]]:
        assert (0 <= z < self.height)
        nodes = []

        # 这是找到一个点后找与之相关的边的方向
        # 这样规定的话既不会漏边，也不会重复查询同一条边

        for x in range(self.length):
            for y in range(self.width):
                node = self.get_node_by_position(Position(x, y, z))
                if node is None:
                    continue

                nodes += [node.to_view()]

        return nodes
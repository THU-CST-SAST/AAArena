"""
医疗包
update 2020.11.27 修改了add函数，使其支持批量增加；添加了num()函数返回持有量；修改了use()
update 2021.2.10  将Kit的回复血量改为40
update 2021.3.19  添加了闪现的replay记录部分
update 2021.3.21  修改了Transport的use函数，使返回值的个数正确，并使非法使用不再减少Transport的数量
"""


from typing import Union
from .config import HpMax, KitRecovery, MaxCarry
from .position import Position


class Kit:
    """
    医疗包类
    可堆叠，相当于物品栏，多个医疗包逻辑上属于一个 Kit 对象，内部有计数器
    """
    MAX_CARRY = MaxCarry['Kit']  # 最大携带量
    RECOVERY = KitRecovery  # 恢复的血量

    def __init__(self, player) -> None:
        """
        :param player: 拥有者
        """
        self.__player = player
        self.__count: int = 0  # 计数器

    def use(self) -> (bool, Union[None, dict]):
        """
        尝试使用一个医疗包

        :return: 当数量不足时，不进行任何操作并返回 False，否则返回True
        """
        if self.__count == 0:
            return False, None
        else:
            self.__count -= 1
            self.__player.hp = self.__player.hp + Kit.RECOVERY
            self.__player.hp = self.__player.hp if self.__player.hp < HpMax else HpMax
            # replay记录使用kit
            self.__player.gamecontroller.replay.use_kit(self.__player.id, self.__player.hp)
            return True,  self.__player.hp

    def add(self, num) -> bool:
        """
        尝试添加一个医疗包 #改为可添加多个

        :return: 当持有数已经达到最大持有量时，不进行任何操作并返回 False，否则返回 True
        """
        if self.__count + num > Kit.MAX_CARRY:
            return False
        else:
            self.__count += num
            return True

    def clear(self) -> None:
        """
        清空医疗包
        """
        self.__count = 0

    def num(self) -> int:
        return self.__count


class Transport:
    MAX_CARRY = MaxCarry['Transport']  # 最大携带量

    def __init__(self,  player):
        self._player = player
        self._count: int = 0  # 计数器

    def use(self, pos:list) -> (bool, Union[None, dict], Union[None, dict]):
        """
        :return: 当数量不足时，不进行任何操作并返回 False，否则返回True
        """
        if self._count == 0:
            return False, None, None
        if self._player.pos.z != pos[2]:  # 不允许跨层闪现
            return False, None, None
        _pos = Position(pos[0], pos[1], pos[2])
        if self._player.can_move(_pos, False):
            self._player.gamecontroller.replay.flink(self._player.id, self._player.pos.to_tuple())
        success, view, media_extra = self._player.move(pos, use_sp=False)
        if success:
            self._count -= 1
        return success, view, media_extra

    def add(self, num) -> bool:
        """
        :return: 当持有数已经达到最大持有量时，不进行任何操作并返回 False，否则返回 True
        """
        if self._count + num > Transport.MAX_CARRY:
            return False
        else:
            self._count += num
            return True

    def clear(self) -> None:
        """
        清空
        """
        self._count = 0

    def num(self) -> int:
        return self._count
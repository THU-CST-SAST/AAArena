"""
陷阱
update 2020.11.27 Trap的owner不能触发陷阱，添加了判断信息；修改了Sticky的apply(...)；完成了通知拥有者的部分
update 2021.1.25  修复了Trap trigger里，通知部分的传参类型错误
update 2021.1.27  添加了陷阱摧毁时通知使用者的部分
update 2021.1.28  修复了trap触发时的消息发送顺序
update 2021.3.6   由于tolist和to_tuple函数完全一致，删除了tolist函数；添加了replay记录Trap destroy的部分
update 2021.3.23  完成了Sticky停两回合的修改
"""


# from __future__ import annotations

from inspect import signature
from abc import abstractmethod
from typing import List, Optional, Type

from .map import Position
from .config import *


class Trap:
    """
    陷阱道具的接口类
    子类需要实现 typeid, apply 方法
    """

    Types = [] #: List[Type[Trap]]  # 陷阱的类型列表
    TYPE_COUNT: int  # 陷阱的种类数

    def __init__(self, player, pos: Position) -> None:
        """
        :param player: 拥有者
        :param pos: 陷阱的位置
        """
        self.__player = player
        self.pos: Position = pos  #改为public 因为Alert中要使用
        self.__disabled: bool = False

    @staticmethod
    @abstractmethod
    def typeid() -> int:
        """
        :return: 陷阱的类型编号
        """

    @staticmethod
    def is_valid_typeid(typeid: int) -> bool:
        """
        :param: 需要验证的陷阱类型编号

        :return: 若参数是合法的陷阱编号，返回 True，否则返回 False
        """
        return typeid in range(Trap.TYPE_COUNT)

    @staticmethod
    def validate_typeid(typeids: List[str] = ["typeid"]):
        """
        生成一个装饰器，检查给定参数列表是否均为合法的陷阱类型编号

        :param typeids: 给定的参数列表，默认为 ["typeid"]

        例如：
            @validate_typeid(["a", "b"])
            def func(a, b, c):
                pass
        将会检查 a 和 b
        """
        def decorator(func):
            def wrapper(*args, **kwargs):
                argv = signature(func).bind_partial(*args, **kwargs).arguments
                assert(all(Trap.is_valid_typeid(
                    argv[typeid]) for typeid in typeids))
                return func(*args, **kwargs)
            return wrapper
        return decorator

    @abstractmethod
    def apply(self, player) -> None:
        """
        接口函数，表示应用一次陷阱效果

        :param player: 陷阱的应用对象
        """

    def is_disabled(self) -> bool:
        """
        :return: 如果陷阱失效，返回 True，否则返回 False
        """
        return self.__disabled

    def owner(self):
        """
        :return: 陷阱的所有者 （对象）
        """
        return self.__player

    def disable(self) -> None:
        """
        将陷阱置为失效，例如地雷被触发后、陷阱被摧毁后
        """
        self.__disabled = True
        self.owner().tools.disable(TrapList[self.typeid()], self.pos) # 在此处添加从放置位置删除的功能
        game = self.owner().gamecontroller
        game.io.send_trap_destroyed(game.round, game.curid, TrapList[self.typeid()], self.pos.to_tuple(), self.owner().id)
        game.replay.trap_destroy(self.pos.to_tuple(), TrapList[self.typeid()]) # replay记录trap被destroy

    def trigger(self, player) -> None:
        """
        触发陷阱

        :param player: 触发者
        """
        if player == self.owner():
            return
        game = self.owner().gamecontroller
        game.io.send_trap_triggered(game.round, game.curid, TrapList[self.typeid()], self.pos.to_tuple(), self.owner().id)
        game.replay.trap_trigger(self.pos.to_tuple(), TrapList[self.typeid()])  # replay记录trap触发
        self.apply(player)

    def destroy(self) -> None:
        """
        摧毁陷阱

        :param player: 摧毁者
        """
        self.disable()


class LandMine(Trap):
    """
    地雷
    """

    __TYPEID: int = len(Trap.__subclasses__())
    HARM: int = LandMineHarm  # 伤害值

    @staticmethod
    def typeid() -> int:
        return LandMine.__TYPEID

    def apply(self, player) -> None:
        if player == self.owner():
            return
        player.harmed(LandMine.HARM)
        self.disable()


class Sticky(Trap):
    """
    粘弹
    """

    __TYPEID: int = len(Trap.__subclasses__())

    @staticmethod
    def typeid() -> int:
        return Sticky.__TYPEID

    def recover_player_status(self, player):
        # 仅当player的状态未发生改变时，才重设player状态
        if player.status == PlayerStatus.Skip:
            player.status = PlayerStatus.Alive

    def apply(self, player) -> None:
        if player == self.owner():
            return
        player.status = PlayerStatus.Skip
        self.disable()
        player.gamecontroller.addevent({
                'round': [player.gamecontroller.round + 2],
                'func': lambda : self.recover_player_status(player)
            })


Trap.Types = Trap.__subclasses__()
Trap.TYPE_COUNT = len(Trap.Types)
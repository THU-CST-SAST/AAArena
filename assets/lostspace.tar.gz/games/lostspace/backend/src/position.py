'''
Update 2021.3.6 由于tolist和to_tuple函数完全一致，删除了tolist函数
'''
from typing import *

class Position:
    def __init__(self, x: int, y: int, z: int) -> None:
        self.x = x
        self.y = y
        self.z = z

    def __add__(self, other: 'Position') -> 'Position':
        return Position(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other: 'Position') -> 'Position':
        return Position(self.x - other.x, self.y - other.y, self.z - other.z)

    def __eq__(self, other: object) -> bool:
        assert(isinstance(other, Position))  # 这么写是为了通过mypy的类型检查
        return self.x == other.x and self.y == other.y and self.z == other.z

    def __iadd__(self, other: 'Position') -> None:
        self.x += other.x
        self.y += other.y
        self.z += other.z

    def to_tuple(self) -> Tuple[int, int, int]:
        return (self.x, self.y, self.z)

    def __str__(self) -> str:
        return 'Position(%d, %d, %d)' % (self.x, self.y, self.z)
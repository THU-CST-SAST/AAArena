from enum import Enum
PropList = ['Materials',  'EscapeCapsule', 'KeyMachine', 'Box']
ToolList = ['LandMine', 'Sticky', 'Transport', 'Kit']
TrapList = ToolList[:2]

HpMax = 200
SpMax = 1
RoundMax = 100  # 大回合上限数

PropSpCost = [1, 1, 1, 1]
AttackCost = 1
KitRecovery = 100
LandMineHarm = 120
AttackHarm = 70
RefreshInterval = 8 # 物资刷新时间间隔

IFINITY = 10000
MaxCarry = {'LandMine': 3, 'Sticky': 3, 'Transport': 2, 'Kit': 2}

MAP_LENGTH = 7
MAP_WIDTH = 7
MAP_HEIGHT = 3
BirthPos = [(0, 0), (6, 0), (6, 6), (0, 6)]  #玩家出生位置
ELEVATOR = [(3, 0), (5, 3), (3, 6), (1, 3)]  #电梯位置
EscapeCapsulePos = (3, 3, 0)
ShrinkTime = [40, 50, 60, 70, 80]  # 缩圈时间

# 给播放器的点八个方向的顺序，门对应的四个方向为DirectionSeqence[:4]
DirectionSeqence = [(0,1,0), (0,-1,0), (1,0,0), (-1,0,0), (1,-1,0), (-1,1,0), (1,1,0), (-1,-1,0)]


class PlayDevice(Enum):
    MediaPlayer = 2
    SDK = 1


class PlayerStatus(Enum):
    Alive = 0
    Died = 1
    Escaped = 2
    Skip = 3
    WaitForEsacape = 4
    Error = 5
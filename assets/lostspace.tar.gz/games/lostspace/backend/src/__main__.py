from .GameController import GameController
from .map import Map
from .MapGen.MapGen import MapGen
import sys
from antlr4 import FileStream, CommonTokenStream, ParseTreeWalker
from .MapGen.MapLexer import MapLexer
from .MapGen.MapParser import MapParser

def main():
    '''
    主函数
    '''
    map = Map()

    istream = FileStream('src/mapconf2.map', encoding='utf8')
    lexer = MapLexer(istream)
    stream = CommonTokenStream(lexer)
    parser = MapParser(stream)
    tree = parser.prog()

    walker = ParseTreeWalker()
    walker.walk(MapGen(map), tree)

    game = GameController(map)
    game.start()


if __name__ == '__main__':
    main()

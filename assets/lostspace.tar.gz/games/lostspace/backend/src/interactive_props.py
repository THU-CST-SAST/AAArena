'''
场景交互道具，如物资点、掉落物等
0   ->  物资点 Materials
1   ->  逃生舱 EscapeCapsule
2   ->  密钥机 KeyMachine
3   ->  掉落物 Box

Update 2021.1.25 修复了Materials Inspect返回值未深拷贝的bug
Update 2021.1.26 修复了删除Alert之后，Material刷新时 list index out of range 的错误
Update 2021.1.28 修复了掉包的问题；添加了钥匙机不跟其所有者互动的部分
Update 2021.2.24 改为仅有开门消耗行动力，关门不消耗行动力
Update 2021.3.6  由于tolist和to_tuple函数完全一致，删除了tolist函数
Update 2021.3.12 修改了钥匙机的interact，如果已经持有，则不再允许与该钥匙机交互
Update 2021.3.12 删除了门；逃生舱改为3回合后触发，添加放弃逃生功能
Update 2021.3.12 修改了物资点和掉落物的交互机制
Update 2021.3.19 添加了replay文件记录交互的部分
Update 2021.3.21 修复了Materials交互时point忘记-1的问题
Update 2021.3.23 添加了box消失时的通讯部分
Update 2021.3.27 将KeyMachine改为交互结束后强制终止回合
'''
from .config import PropList, IFINITY, RefreshInterval, PropSpCost, PlayerStatus

class InterProps:
    def __init__(self, id):
        '''
        所有子类都应当含有interact(player)接口，当为非法动作时返回-1
        '''
        self.name = PropList[id]
        self.spcost = PropSpCost[id]

    def interact(self, player):
        return player.use_sp(self.spcost)


class Materials(InterProps):
    def __init__(self):
        super().__init__(0)
        self.points = 2

    def refresh(self, gamecontroller) -> None:
        self.points += 1
        assert self.points <= 2, 'Material points overflow!'
        if self.points < 2:    # 若未回满，则继续回
            gamecontroller.addevent(
                {
                    'round': [gamecontroller.round + RefreshInterval],
                    'func': lambda: self.refresh(gamecontroller)
                })

    def interact_2(self, player, type:str):
        '''
        player: Player类对象
        type: LandMine, Sticky, Transport, Kit
        return: True，操作成功；-1，操作失败
        '''
        if self.points <= 0 or not super(Materials, self).interact(player):
            return -1
        player.gamecontroller.replay.inspect_tools(player.id, player.pos.to_tuple(), 'Materials')
        if not player.tools.inandout({type: 1}):
            player.sp += 1
            return -1
        self.points -= 1
        if self.points == 1:
            player.gamecontroller.addevent(
                {
                    'round': [player.gamecontroller.round+RefreshInterval],
                    'func': lambda: self.refresh(player.gamecontroller)
                })
        return True


class Box(InterProps):
    def __init__(self, keypool:set, node):
        super().__init__(3)
        self.keypool = keypool
        self.node = node

    def add_keys(self, keyids:list):
        self.keypool.union(keyids)

    def interact(self, player):
        '''
        :return: 成功则返回True，否则返回-1
        '''
        if not super().interact(player):
            return -1

        pos = self.node.position.to_tuple()
        player.gamecontroller.replay.inspect_tools(player.id, pos, 'Box')
        player.get_key(self.keypool)

        self.node.box = None
        player.gamecontroller.replay.box_disappear(pos)
        gc = player.gamecontroller
        witness = gc.witness(self.node.position, player)  # 给死亡玩家也发box出现消息
        gc.io.send_witness(gc.round, gc.curid,
                        ["interprops_status_update", pos, "Box", "disappear"],
                        witness)
        gc.io.respond(gc.round, gc.curid, 'box_disappear', {"pos": pos})
        return True


class EscapeCapsule(InterProps):
    def __init__(self):
        super().__init__(1)
        self.escape_round = [IFINITY for i in range(4)]

    def interact_2(self, player, to_escape:bool):
        '''
        player: Player类object
        to_escape: 是要逃生，还是要放弃逃生
        '''
        if to_escape and (not player.can_escaped() or player.status == PlayerStatus.WaitForEsacape):
            return -1
        if not to_escape and player.status != PlayerStatus.WaitForEsacape:
            return -1
        if not super().interact(player):
            return -1
        if to_escape:
            self.escape_round[player.id] = 3
            player.status = PlayerStatus.WaitForEsacape
        else:
            self.escape_round[player.id] = IFINITY
            if player.status == PlayerStatus.WaitForEsacape:
                player.status = PlayerStatus.Alive
        player.gamecontroller.replay.interact_with_escapecapsule(player.id, to_escape)
        return True

    def ready_to_escape(self, playerid) -> bool:
        self.escape_round[playerid] -= 1
        return self.escape_round[playerid] == 0


class KeyMachine(InterProps):
    def __init__(self, playerid):
        super().__init__(2)
        self.owner = playerid

    def recover_player_status(self, player):
        # 仅当player的状态未发生改变时，才重设player状态
        if player.status == PlayerStatus.Skip:
            player.status = PlayerStatus.Alive

    def interact(self, player):
        if self.owner in player.key:
            return -1
        if not super().interact(player):
            return -1
        player.gamecontroller.ready_to_get[player.id] = self.owner
        # replay记录与KeyMachine的互动
        player.gamecontroller.replay.open_keymachine(player.id, player.pos.to_tuple())
        player.status = PlayerStatus.Skip
        player.gamecontroller.addevent({
            'round': [player.gamecontroller.round + 1],
            'func': lambda: self.recover_player_status(player)
        })
        return True
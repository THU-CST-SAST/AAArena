'''
update 2020.11.27 修改了reset()、died()、get_key(int)、attack(...)，添加了用于通讯的字典化函数
update 2020.12.12 探查技能剩余冷却回合 初始化应为0
update 2021.1.25  更新了出生点位置注册信息
update 2021.1.27  修正了attack时的消息发送顺序
update 2021.1.27  根据策划案，添加了探查后废弃陷阱的功能
update 2021.1.28  修复了复活时出生点位置错误的问题，修复了死亡掉包的问题
update 2021.2.3   添加了在自己回合死去时的信息发送
update 2021.2.6   添加了回合开始消息中发送他人hp值的部分
update 2021.2.10  添加了不使用医疗包治疗的部分
update 2021.3.6   由于tolist和to_tuple函数完全一致，删除了tolist函数
update 2021.3.6   添加了给使用播放器的玩家发送每回合合法行动的部分；添加了上下楼时的视野更新部分；添加了积分机制
update 2021.3.6   添加了detect的replay记录部分
update 2021.3.12  删除了不使用医疗包治疗的部分
update 2021.3.19  删除了初始化信息中与门有关的部分
update 2021.3.21  修复了生成初始信息时status未转int的问题;修复了move的视野更新部分的bug
update 2021.3.23  修复了get_key中的参数类型问题;增加了移动到逃生舱层对其他玩家发送提示消息的部分
update 2021.3.26  根据策划案，玩家舔包无论一次得到多少密钥，都只加1分，因此更改了get_key
'''
from .toolbag import ToolBag
from .map import Position
from .config import *

class Player:
    def __init__(self, id, game):
        self.status = PlayerStatus.Alive  # 0活着，1挂了，2逃了，3下一回合跳过，4逃生等待中
        self.hp = HpMax  # 玩家生命值
        self.sp = SpMax  # 玩家行动力
        self.id = id  # 玩家编号
        self.respawn = 0  # 离复活的轮数
        self.gamecontroller = game

        # pos应该是Position类型
        self.pos = Position(BirthPos[id][0], BirthPos[id][1], 1)  # 2021.1.25，这里应为id而非id-1
        self.key = {id}
        self.tools = ToolBag(self)  # 所有道具，包括陷阱道具和其他道具
        self.detect_cooling = 0  # 探查的技能冷却

        self.score = 0

    def get_key(self, keyids: set):  # 获得钥匙
        picked = keyids.difference(self.key)
        self.key.update(keyids)

        if len(picked) != 0:
            self.score += 1  # 拾取钥匙加1分
            self.gamecontroller.io.get_key(self.gamecontroller.round, self.gamecontroller.curid, list(picked))
            self.gamecontroller.replay.get_key(self.id, list(picked))

    def has_key(self, id: int):
        return id in self.key

    def use_sp(self, spcost: int):  # 消耗能量接口
        if self.sp < spcost:
            return False
        self.sp -= spcost
        return True

    def attack(self, pos: list, tar: 'Player'):  # 攻击成功返回True,否则返回False
        pos = Position(pos[0], pos[1], pos[2])
        point = self.gamecontroller.map.get_node_by_position(pos)
        if point is None or tar not in point.players or tar.status in [PlayerStatus.Died, PlayerStatus.Error, PlayerStatus.Escaped]:
            return False
        if not pos == self.pos and not self.gamecontroller.map.next_to(self.pos, pos):
            return False
        if not self.use_sp(1):  # 消耗1点行动力
            return False
        # replay文件记录
        self.gamecontroller.replay.attack(self.id, self.pos.to_tuple(), pos.to_tuple())
        witness = self.gamecontroller.witness(self.pos, self)
        self.gamecontroller.io.send_witness(self.gamecontroller.round, self.id, ["attacking", self.pos.to_tuple()],
                                            witness)

        tar.harmed(AttackHarm)
        # 打死别人加2分
        if tar.hp == 0:
            self.score += 2
        return True

    def get_keynum(self):
        return len(self.key)

    def can_escaped(self) -> bool:  # 判断该玩家是否（能否）成功逃脱
        return self.get_keynum() == 4

    def can_move(self, pos:Position, use_sp:bool=True):
        spcost = self.gamecontroller.map.move_distance(self, pos)
        if spcost == -1:
            return False
        if use_sp and not self.use_sp(spcost):
            return False
        return True

    def move(self, pos: list, use_sp:bool = True):
        pos = Position(pos[0], pos[1], pos[2])
        if not self.can_move(pos, use_sp):
            return False, None, None

        newlayer = pos.z != self.pos.z

        witness_pre = self.gamecontroller.witness(self.pos, self)
        witness_aft = self.gamecontroller.witness(pos, self)

        # 发送其他玩家的视野变化信息，要先发位置变化，再处理走到陷阱上，否则那人就先死了后走了一格，事件顺序就不对了
        self.gamecontroller.io.send_witness(self.gamecontroller.round, self.id,
                                            ["pos_update", pos.to_tuple(), self.id], witness_aft)
        disapear = []
        for p in witness_pre:
            if p not in witness_aft:
                disapear.append(p)
        self.gamecontroller.io.send_witness(self.gamecontroller.round, self.id, ["pos_update", [-1, -1, -1], self.id],
                                            disapear)

        # 已经添加走到陷阱上的情况
        self.gamecontroller.map.update_player_pos(self, pos)

        view, media_extra = None, None
        if newlayer and self.hp > 0:
            view = self.gamecontroller.map.get_view(pos.z)

        if self.gamecontroller.player_property[self.id] == PlayDevice.MediaPlayer.value:
            media_extra = self.get_legal_actions()

        # 到达逃生舱所在层，向所有玩家（除了自己）发送warning
        if self.pos.z == 0 and newlayer:
            self.gamecontroller.io.third_layer_warning(self.gamecontroller.round, self.id)

        # replay文件中记录移动
        self.gamecontroller.replay.move(self.id, self.pos.to_tuple())
        return True, view, media_extra

    def place_trap(self, type):
        success = self.tools.place(type)
        if success:
            self.gamecontroller.replay.place_trap(self.id, self.pos.to_tuple(), type)
        return success

    def harmed(self, hp):  # 玩家血量减少事件，死亡返回False，否则返回True
        if self.hp <= hp:
            self.hp = 0
            #  在died()中将hp清0
            stillalive = False
        else:
            self.hp -= hp
            stillalive = True

        self.gamecontroller.replay.hp_update(self.id, self.hp)

        if self.gamecontroller.curid != self.id:  # 仅在回合外发送hp更新消息
            self.gamecontroller.io.send_hp_update_offround(self.gamecontroller.round,
                                                      self.gamecontroller.curid,
                                                      self.id, self.hp)
        if not stillalive:
            self.died()
        return stillalive

    def died(self):  # 清空所有密匙、工具、陷阱
        self.score -= 3  # 死亡扣3分
        self.gamecontroller.player_died(self.id)  # 广播
        self.hp = 0
        node = self.gamecontroller.map.get_node_by_position(self.pos)
        myround = self.gamecontroller.curid == self.id  # 是否是在自己的回合死亡的
        box = node.death_drop(self.key) # 返回值为是否掉包

        if box:  # 该函数返回值为True，则地图上多了一个箱子，发送视野更新消息
            witness = self.gamecontroller.witness(self.pos, None if not myround else self)  # 给死亡玩家也发box出现消息
            self.gamecontroller.io.send_witness(self.gamecontroller.round, self.gamecontroller.curid,
                                                ["interprops_status_update", self.pos.to_tuple(), "Box", "appear"],
                                                witness)

        self.gamecontroller.replay.player_died(self.id, self.pos.to_tuple() if box else None)
        if myround:
            self.gamecontroller.io.respond(self.gamecontroller.round, self.gamecontroller.curid, 'death',
                                           {"box": box})

        self.key.clear()
        self.tools.clear()
        # 更新map中自己的位置信息
        node = self.gamecontroller.map.get_node_by_position(self.pos)
        node.delete_player(self)

        self.status = PlayerStatus.Died  # 变更自己的状态
        self.respawn = 5  # 5轮后复活，对于不再复活的情况，在GameController里处理了

    def reset(self):  # 复活，HP、SP回满
        self.hp = HpMax
        self.sp = SpMax
        self.key = {self.id}  # 要把自己的密钥加上
        self.status = PlayerStatus.Alive  # 变更自己的状态

        # 如果已经进入缩圈，复活点的选择应该有所不同，但这要看map是怎么写的 #ans: 出生点不会被缩圈
        self.pos = Position(BirthPos[self.id][0], BirthPos[self.id][1], 1)

        # 更新map中自己的位置信息
        node = self.gamecontroller.map.get_node_by_position(self.pos)
        node.add_player(self)

        self.gamecontroller.replay.regenerate(self.id, self.pos.to_tuple())

    def detect(self, pos: list) -> list:
        '''
        return: 返回值为 [<bool:操作是否合法>, <bool:是否有陷阱>]
        '''
        if self.detect_cooling > 0:
            return [False]
        curnode = self.gamecontroller.map.get_node_by_position(self.pos)
        tarnode = self.gamecontroller.map.get_node_by_position(Position(pos[0], pos[1], pos[2]))
        if tarnode is None or curnode.find_edge_to(tarnode) is None:
            return [False]
        self.detect_cooling = 5
        has_trap = tarnode.trap is not None
        if has_trap and tarnode.trap.owner() != self:
            tarnode.trap.disable()

        self.gamecontroller.replay.detect(self.id, pos) # replay文件记录detect信息
        return [True, has_trap]

    def detailed_dict(self) -> dict:
        ret = {
            "status": self.status.value,
            "hp": self.hp,
            "tools": self.tools.todict(),
            "keys": list(self.key),
            "pos": self.pos.to_tuple()
        }
        if self.gamecontroller.player_property[self.id] == PlayDevice.MediaPlayer.value:
            ret.update(self.get_legal_actions())
        return ret

    def get_legal_actions(self) -> dict:
        '''
        给播放器的接口，返回一个包含整个回合可以进行的行为的dict
        dict的格式：
        {
            'attack': [0, 1]   // 可以attack的玩家序列
            'move':   [True, False, False, True, True, False, True, False]  // 八个方向上的点是否可达
            'detect': True  // 是否可以进行detect
            'interprops': ['Box', 'Keymachine']   // 当前节点上的交互道具列表
        }
        '''
        if self.status != PlayerStatus.Alive:  # 该回合跳过
            return {}

        ATTACK = []
        player_list = self.gamecontroller.players
        for player in player_list:
            if player.id == self.id or player.status in [PlayerStatus.Escaped, PlayerStatus.Died, PlayerStatus.Error]:  # 该玩家逃了或者死了或者是自己
                continue
            point = self.gamecontroller.map.get_node_by_position(player.pos)
            if point is None:
                continue
            if self.gamecontroller.map.next_to(self.pos, player.pos) or self.pos == player.pos:
                ATTACK.append(player.id)

        INTERPROPS, MOVE = self.get_cur_pos_info()

        return {
            'attack': ATTACK,
            'move': MOVE,
            'detect': self.detect_cooling <= 0,
            'interprops': INTERPROPS
        }

    def get_cur_pos_info(self):
        '''
        返回当前位置邻接点、门和交互道具的信息，仅用于给播放器，格式见get_legal_actions
        '''
        cur_node = self.gamecontroller.map.get_node_by_position(self.pos)
        INTERPROPS = cur_node.todict()['interprops']
        if (self.pos.x, self.pos.y) in ELEVATOR:
            INTERPROPS.append('Elevator')
        MOVE = [False for i in range(8)]
        for i, direction in enumerate(DirectionSeqence):
            tarpos = self.pos + Position(direction[0], direction[1], direction[2])
            tar_node = self.gamecontroller.map.get_node_by_position(tarpos)
            edge = cur_node.find_edge_to(tar_node)
            MOVE[i] = edge is not None
        return INTERPROPS, MOVE

    def brief_dict(self) -> dict:
        ret = {
            "player_id": self.id,
            "status": self.status.value,
            "keys": list(self.key),
            "hp": self.hp
        }
        return ret

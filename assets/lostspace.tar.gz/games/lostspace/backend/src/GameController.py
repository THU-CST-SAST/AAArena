"""
游戏核心逻辑

Update 2021.1.26 修复了回合跳过情况的问题 （更改了round_start的返回值，并再turn中添加了清除sticky状态的内容）
Update 2021.1.28 修复了通过钥匙机获得密钥的信息发送的bug，调整了replay文件新回合注册的位置
Update 2021.2.10 添加了不使用医疗包治疗的部分
Update 2021.2.24 修复了gameover中的bug
Update 2021.2.28 修复了ai超时处理的bug，修复了replay文件无法生成的问题
Update 2021.3.6  添加了给使用播放器的玩家发送每回合合法行动的部分，添加了上下楼时的视野更新部分(根据player.move)的更改调整了slove
Update 2021.3.6  添加了积分机制，添加了100回合强制终止机制
Update 2021.3.6  添加了ai_error的replay记录部分；添加了游戏开始消息中提供出生点位置的部分
Update 2021.3.19 根据通讯协议修改了通讯部分，修复了score_dic的问题
Update 2021.3.21 修复了Transport调用参数个数不正确的问题，修复了Player.status未转int的问题
Update 2021.3.23 修复了一些参数类型错误的问题；完成了Sticky停两回合的修改
Update 2021.3.26 更改solve函数，添加了信息没有type键的处理，并更改solve的返回部分，使得玩家死亡或进入逃生倒计时等情况下自动结束回合
"""
from .player import Player
from .map import Map
from .communicate import Communicate
from .config import *
from .replay import Replay

win_players = []
lose_players = []


class GameController:  # 全局通知管理以及回合初始化
    def __init__(self, map):
        self.smallround = 0
        self.round = 0
        self.players = [Player(i, self) for i in range(4)]  # 创建4个玩家对象
        self.map = map  # 初始化地图

        # 目前只处理追踪器和物资点刷新，格式为 {"round": <list of int:将在哪些回合调用>, "func": 被调用函数地址}
        self.event_list = []

        self.ready_to_get = [-1, -1, -1, -1]  # 玩家即将获得的密钥编号
        # self.ready_to_escape = [0, 0, 0, 0]  # 玩家是否处于准备逃离状态
        self.curid = 0  # 当前行动的玩家id
        self.curplayer = self.players[0]  # 本回合，或者下回合的player
        self.overtime = 0  # 加时赛
        self.io = Communicate(self)

        self.map.login_players(self.players)
        self.escape_capsule = self.map.add_esacpe_capsule()

        self.replay_path = ''
        self.player_property = []  # 存储player是ai还是播放器

    def start(self):
        initdic, init_error_player = self.io.game_init(BirthPos)
        assert initdic['player_num'] == 4  # 断言有4名玩家加入游戏
        self.player_property = initdic['player_list']
        self.replay = Replay(initdic['replay'], BirthPos)
        for id, error_log in init_error_player:
            self.player_error(id)
            self.replay.ai_error(id, error_log)
        for i, status in enumerate(initdic['player_list']):
            if status == 0:
                self.player_error(i)
        if len(lose_players) == 4:  # 所有玩家均为成功进入
            self.gameover()
        self.io.send_init_mes(BirthPos)
        while True:
            self.big_round()

    def big_round_start(self):
        '''
        大回合开始
        似乎player初始化时会自行带上秘钥，这里没有进行这个操作
        :return:
        '''
        self.curid = 0
        self.curplayer = self.players[0]  # 当前行动玩家恢复
        self.round += 1  # 大回合数加一

        if self.round > RoundMax:
            self.gameover()

        # 处理追踪器的广播任务和物资点的刷新任务
        topop = []
        l = len(self.event_list)
        for i in range(l):
            mission = self.event_list[i]
            if self.round == mission['round'][0]:
                mission['func']()
                mission['round'].pop(0)
                if len(mission['round']) == 0:
                    topop.append(i)
        l = len(topop) + 1
        for i in range(1, l):
            self.event_list.pop(topop[-i])

        # 把探查技能的冷却回合数 -1
        for player in self.players:
            player.detect_cooling -= 1

        # 向replay写入新大回合
        self.replay.new_round()

    def big_round(self):
        self.big_round_start()
        for i in range(4):
            self.turn()
        self.big_round_end()

    def big_round_end(self):
        '''
        大回合结束
        :return:
        '''
        # 检查缩圈
        self.map.shrink(self.round)
        # 判断加时赛阶段
        if self.round >= ShrinkTime[-1]:
            self.overtime = 1  # 加时赛阶段

    def turn(self):
        # 回合内行动
        # 依次向4人中存活且未逃离的人发送信息，并提醒行动
        self.curplayer.sp = SpMax
        status = self.round_start()
        assert status != -1

        self.smallround += 1
        self.io.new_small_round()

        # 发送回合开始消息
        state_dic = self.curplayer.detailed_dict()
        others = [player.brief_dict() for player in self.players]
        others.pop(self.curid)
        state_dic.update({
            "others": others
        })
        self.io.send_roundstart_mes(self.round, self.curid, state_dic)

        if status == PlayerStatus.Alive.value or status == PlayerStatus.WaitForEsacape.value:  # 回合不需要跳过的情况
            self.inround()
        self.round_end()

    def inround(self):
        while True:
            try:
                movement, playerid = self.io.recieve_data()
                if movement.get('error') is not None:
                    assert playerid == -1
                    assert movement.get('player') is not None
                    playerid = movement['player']
                    self.player_error(playerid)
                    self.replay.ai_error(playerid, movement['error_log'])
                    if playerid == self.curid:
                        break
                if playerid != self.curid:
                    continue
                if self.solve(movement):
                    break
            except AssertionError:
                self.io.send_formate_error(self.round, self.curid)

    def player_error(self, playerid):
        if playerid in win_players or playerid in lose_players:  # 忽略已赢或者已输玩家的error
            return
        self.players[playerid].status = PlayerStatus.Error
        self.players[playerid].hp = 0
        self.players[playerid].respawn = IFINITY
        lose_players.append(playerid)
        self.io.boardcast(self.round, self.curid, 'ai_error', [playerid])
        if playerid == self.curid:
            self.io.respond(self.round, playerid, 'ai_error', {})
        else:
            self.io.send_status_update(state=self.round, curplayer=self.curid, type='ai_error', args=[playerid])

    def solve(self, message: dict) -> bool:
        # 先进行信息格式检查，再解释信息
        # 若为回合结束消息则返回True，否则返回False
        assert message.get('type') is not None
        if message.get('state') and message['state'] != self.round:
            if message['type'] != 'finish':
                self.io.respond_action(self.round, self.curid, False)
            return self.curplayer.status != PlayerStatus.Alive and self.curplayer.status != PlayerStatus.WaitForEsacape

        if message['type'] == 'finish':
            return True

        if message['type'] == 'action':
            assert message.get('action') is not None
            content = message['action']
            assert type(content) == type(list())

            if self.curplayer.status == PlayerStatus.WaitForEsacape:  # 逃生等待状态单独处理
                # 只允许与逃生舱交互
                try:
                    assert len(content) == 3
                    assert content[0] == 'interact' and content[1] == 'EscapeCapsule' and content[2] == False
                    success = self.map.interact(message, content, self.curplayer)
                except AssertionError:
                    success = False
                self.io.respond_action(self.round, self.curid, success)
                return self.curplayer.status != PlayerStatus.Alive and self.curplayer.status != PlayerStatus.WaitForEsacape

            if content[0] == 'interact':
                assert len(content) >= 2
                assert content[1] in PropList
                if content[1] == 'Box':
                    assert len(content) == 2
                    success = self.map.interact(message, content, self.curplayer)
                    self.io.box_response(self.round, self.curid, success, list(self.curplayer.key))
                else:
                    if content[1] == 'Materials':
                        assert len(content) == 3
                        assert content[2] in ToolList
                    else:
                        assert content[1] == 'EscapeCapsule' or content[1] == 'KeyMachine'
                    success = self.map.interact(message, content, self.curplayer)
                    self.io.respond_action(self.round, self.curid, success)
            elif content[0] == 'trap':
                assert len(content) == 2
                assert content[1] in TrapList
                success = self.curplayer.place_trap(content[1])
                self.io.respond_action(self.round, self.curid, success)
            elif content[0] == "move":
                assert len(content) == 2
                assert len(content[1]) == 3
                success, view, media_extra = self.curplayer.move(content[1])
                self.io.move_response(self.round, self.curid, success, self.curplayer.hp, self.curplayer.status.value,
                                      view, media_extra)
            elif content[0] == "attack":
                assert len(content) == 3
                assert len(content[1]) == 3
                assert content[2] >= 0 and content[2] <= 3 and content[2] != self.curid
                success = self.curplayer.attack(content[1], self.players[content[2]])
                self.io.respond_action(self.round, self.curid, success)
            elif content[0] == "tool":
                assert len(content) >= 1
                if content[1] == "Kit":
                    assert len(content) == 2
                    success, hp = self.curplayer.tools.use_tool(content[1])
                    self.io.kit_reponse(self.round, self.curid, success, hp)
                elif content[1] == "Transport":
                    assert len(content) == 3
                    assert len(content[2]) == 3
                    success, view, media_extra = self.curplayer.tools.use_tool(content[1], content[2])
                    self.io.move_response(self.round, self.curid, success, self.curplayer.hp,
                                          self.curplayer.status.value, view, media_extra)
                else:
                    raise AssertionError
            elif content[0] == "detect":
                assert len(content) == 2
                assert len(content[1]) == 3
                r = self.curplayer.detect(content[1])
                success = r[0]
                has_trap = r[1] if r[0] else None
                self.io.detect_response(self.round, self.curid, success, has_trap)
            else:
                raise AssertionError
        else:
            raise AssertionError
        return self.curplayer.status != PlayerStatus.Alive and self.curplayer.status != PlayerStatus.WaitForEsacape

    def addevent(self, event):
        self.event_list.append(event)

    def witness(self, pos, player: Player):
        '''
        arg: pos是发生的位置，player是正在做出此行动的玩家
        return: 可以看到此行为的玩家的序号的列表
        '''
        ret = []
        for p in self.players:
            if p == player:
                continue
            if self.map.can_see(p.pos, pos):
                ret.append(p.id)
        return ret

    def round_start(self):
        '''
        小回合开始
        :return:-1 表示该回合不能开始，所有玩家已经全部逃脱
        0 表示该回合玩家处于死亡待复活状态，可以直接调用回合结束
        1 表示该回合玩家已经逃脱，可以直接调用回合结束
        2 表示该回合成功开始

        改为0成功开始，1死了，2逃了
        '''
        # 回合开始阶段
        # 确定游戏是否能继续
        if len(win_players) == 4:
            return -1  # 正常情况不会执行这句

        # 向replay写入新的小回合
        self.replay.new_turn()
        if self.curplayer.status == PlayerStatus.Escaped:
            return self.curplayer.status.value

        # 复活时间减一
        if self.curplayer.hp <= 0:  # 当前行动的玩家处于等待复活状态
            self.curplayer.respawn -= 1  # 复活时间减一
            if self.curplayer.respawn <= 0 and self.curid not in lose_players:  # 可以复活
                # 玩家复活
                self.player_regenerate(self.curid)
            else:
                return self.curplayer.status.value

        # 获得钥匙
        # 这里我不太清楚玩家处于搜集密钥状态和准备逃离状态怎么体现，自己开了两个数组存
        if self.ready_to_get[self.curid] != -1:
            key_num = self.ready_to_get[self.curid]
            #  向所有人广播,这里不检查是否与已有密钥重复
            self.curplayer.get_key({key_num})
            self.ready_to_get[self.curid] = -1
        # 逃生
        # if self.ready_to_escape[self.curid] == 1:
        # self.ready_to_escape[self.curid] = 0
        if self.escape_capsule.ready_to_escape(self.curid):
            if self.curplayer.status != PlayerStatus.WaitForEsacape:
                self.escape_capsule.escape_round[self.curid] = IFINITY
            else:
                self.player_escape(self.curid)
        if len(win_players) + len(lose_players) == 4:  # 游戏结束
            self.gameover()

        return self.curplayer.status.value

    def round_end(self):
        # 处理小回合结束事件
        if len(win_players) + len(lose_players) == 4:  # 游戏结束
            self.gameover()
        self.curid = (self.curid + 1) % 4
        self.curplayer = self.players[self.curid]

    def player_died(self, playerid):
        # 处理玩家死亡事件
        # 主要是掉包，广播
        # 然后如果是加时赛（不会再复活了）就记一下死亡的回合数
        if self.overtime:  # 加时赛阶段
            assert playerid not in lose_players and playerid not in win_players
            lose_players.append(playerid)  # 游戏失败
            self.players[playerid].respawn = IFINITY  # 不再复活
        self.io.boardcast(self.round, self.curid, 'died', [playerid])
        if self.curid != playerid:
            self.io.respond(self.round, self.curid, 'other_death', {"playerid": playerid})

    def player_regenerate(self, playerid):
        # 玩家复活事件
        self.players[playerid].reset()
        witness = self.witness(self.players[playerid].pos, self.players[playerid])
        self.io.send_witness(self.round, self.curid, ['regenerate', self.players[playerid].pos.to_tuple(), playerid],
                             witness)

    def player_escape(self, playerid):
        # 玩家逃离事件
        assert playerid not in win_players and playerid not in lose_players
        win_players.append(playerid)
        self.players[playerid].status = PlayerStatus.Escaped  # 变更玩家状态
        self.replay.escape(playerid)  # replay记录逃脱
        self.io.boardcast(self.round, playerid, 'escaped', [])  # 广播消息
        self.io.respond(self.round, playerid, 'escaped', {})

    def gameover(self):
        '''
        游戏结算
        ':return:玩家的排名顺序'
        改为发送玩家的排名信息，因为再round_start()里是调用该函数直接处理游戏结束事件的
        '''
        player_order = []
        for player_id in win_players:
            player_order.append(player_id)

        if len(win_players) + len(lose_players) != 4:
            scoring_players = []
            for player_id in range(4):
                if player_id not in win_players and player_id not in lose_players:
                    scoring_players.append(player_id)
            scoring_players.reverse()
            # scores 里，后手在前，先手在后
            scores = [(self.players[player_id].score, player_id) for player_id in scoring_players]
            scores.sort(key=lambda x: x[0], reverse=True)  # 按分数排序，由稳定性，后手在前
            player_order += [pair[1] for pair in scores]

        lose_players.reverse()
        for player_id in lose_players:
            player_order.append(player_id)
        # 发送游戏结束消息
        score_dic = {}
        for i, player_id in enumerate(player_order):
            score_dic[str(player_id)] = 4 - i
        self.replay.dump_score_dic(score_dic)
        self.replay.save()  # replay文件保存
        self.io.send_end_info(score_dic)

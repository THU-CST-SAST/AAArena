'''
update 2021.2.10  添加了不使用医疗包治疗的部分
update 2021.3.6   添加了detect、ai_error、摧毁陷阱的replay记录部分
update 2021.3.19  根据策划案更新了replay格式
'''
import json


class Replay:
    def __init__(self, filepath:str, birthplaces:list):
        '''
        filepath: replay文件路径
        birthplaces: list of 三元组，长度为4，一次为0号玩家到3号玩家的出生点
        '''
        self.filepath = filepath
        self.lines = []
        self.lines.append([self.__get_pos__([p[0], p[1], 1]) for p in birthplaces])

    def dump_score_dic(self, score_dic):
        self.lines.append(score_dic)

    def save(self):
        file = open(self.filepath, 'w')
        json.dump(self.lines, file)
        file.close()

    def __get_pos__(self, pos:list):
        '''
        replay格式规定的坐标位置跟通讯格式中规定的坐标有区别
        '''
        return [pos[0]-3,pos[1]-3,pos[2]]

    def new_round(self):
        self.lines.append([])

    def new_turn(self):
        self.lines[-1].append([])

    def __player_action__(self, playerid:int, type:str, **kwargs):
        dic = {
            "type": type,
            "playerid": playerid,
            **kwargs
        }
        self.lines[-1][-1].append(dic)

    def move(self, playerid:int, pos:list):
        '''
        pos传通讯格式中规定的坐标就成，下同
        '''
        self.__player_action__(playerid, "move", pos=self.__get_pos__(pos))

    def flink(self, playerid:int, pos:list):
        self.__player_action__(playerid, "flink", pos=self.__get_pos__(pos))

    def interact_with_escapecapsule(self, playerid:int, to_escape):
        self.__player_action__(playerid, 'escape_capsule', to_escape=to_escape)

    def detect(self, playerid:int, tar_pos:list):
        self.__player_action__(playerid, "detect",tar_pos=self.__get_pos__(tar_pos))

    def ai_error(self, playerid:int, error_type:str):
        self.__player_action__(playerid, "ai_error", error_log=error_type)

    def hp_update(self, playerid:int, hp:int):
        self.__player_action__(playerid, "hp_update", hp=hp)

    def cure(self, playerid:int, hp:int):
        self.__player_action__(playerid, "cure", hp=hp)

    def attack(self,playerid:int, startpos:list, edpos:list):
        self.__player_action__(playerid,"attack", attack=[self.__get_pos__(startpos), self.__get_pos__(edpos)])

    def tool_update(self, playerid:int, toolsdic:dict):
        self.__player_action__(playerid, "tool_update", tools=toolsdic)

    def place_trap(self, playerid:int, pos:list, trap_type:str):
        self.__player_action__(playerid, "place_trap", pos=self.__get_pos__(pos), trap_type=trap_type)

    def use_kit(self, playerid:int, hp:int):
        self.__player_action__(playerid, "kit", hp=hp)

    def player_died(self, playerid:int, boxplace:list=None):
        if boxplace is not None:
            self.__player_action__(playerid, "died", box=self.__get_pos__(boxplace))
        else:
            self.__player_action__(playerid, "died")

    def regenerate(self, playerid:int, pos:list):
        self.__player_action__(playerid, "regenerate", pos=self.__get_pos__(pos))

    def open_keymachine(self, playerid:int, pos:list):
        self.__player_action__(playerid, "keymachine", pos=self.__get_pos__(pos))

    def get_key(self, playerid:int, keyids:list):
        self.__player_action__(playerid, "getkey", keyid=keyids)

    def escape(self, playerid):
        self.__player_action__(playerid, "escaped")

    def __map_update__(self, **kwargs):
        dic = {
            "type": "map_update",
            **kwargs
        }
        self.lines[-1][-1].append(dic)

    def box_disappear(self, pos:list):
        self.__map_update__(args=["box_disappear", self.__get_pos__(pos)])

    def door(self, doorstatus:bool, stpos:list, edpos:list):
        '''
        doorstatus: 门开着为true，关着为false
        '''
        self.__map_update__(args=["door", self.__get_pos__(stpos), self.__get_pos__(edpos), doorstatus])

    def trap_trigger(self, pos:list, traptype:str):
        self.__map_update__(args=["trap_trigger", self.__get_pos__(pos), traptype])

    def trap_destroy(self, pos:list, traptype:str):
        self.__map_update__(args=["trap_destroy", self.__get_pos__(pos), traptype])

    def inspect_tools(self, playerid:int, pos:list, interprops_type:str):
        dic = {
            "type": "inspect",
            "playerid": playerid,
            "pos": self.__get_pos__(pos),
            "interprops": interprops_type,
        }
        self.lines[-1][-1].append(dic)
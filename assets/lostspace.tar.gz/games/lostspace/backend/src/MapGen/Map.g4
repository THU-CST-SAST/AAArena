// 使用命令：java org.antlr.v4.Tool -Dlanguage=Python3 Map.g4
// antlr4-python3-runtime == 4.9.1 (推荐4.7.1)

grammar Map;

COMMENT  : ' '* ':' .*? ('\n' | EOF) -> skip;           // 注释部分跳掉
prog : (nodes_info | edges_info | materials_info | blocks_info | elevators_info | hmaterials_info | doors_info)* EOF;
nodes_info : ' '* '[Node]' ' '* '\r'? '\n' node_info*;
edges_info : ' '* '[Edge]' ' '* '\r'? '\n' edge_info*;
node_info : ' '* INT ' '+ INT ' '+ INT ' '* '\r'? '\n'?;
INT : [0-9]+;
bind_edge : (node_info__edge_1 | node_info__edge_2);
edge_info : bind_edge '-' bind_edge edge_door? '\r'? '\n'?;
edge_door : ' '* ('-door' | '-d') ' '*;
node_info__edge_1 : ' '* INT ' '+ INT ' '+ INT ' '*;
node_info__edge_2 : ' '* INT ' '*;
materials_info : ' '* '[Material]' ' '* '\r'? '\n' material_info*;
material_info : ' '* INT ' '+ INT ' '+ INT ' '* '\r'? '\n'?;
hmaterials_info : ' '* '[HMaterial]' ' '* '\r'? '\n' hmaterial_info*;
hmaterial_info : ' '* INT ' '+ INT ' '+ INT ' '* '\r'? '\n'?;
doors_info : ' '* '[Door]' ' '* '\r'? '\n' door_info*;
door_info : bind_edge '-' bind_edge '\r'? '\n'?;
elevators_info : ' '* '[Elevator]' ' '* '\r'? '\n' elevator_info*;
elevator_info : ' '* INT ' '+ INT ' '* '\r'? '\n'?;
blocks_info : ' '* '[Block]' ' '* '\r'? '\n' block_info*;
block_info : ' '* INT ' '+ node_info__block ' '* '-' ' '* node_info__block ' '* '\r'? '\n'?;
node_info__block : INT ' '+ INT ' '+ INT;

# Generated from Map.g4 by ANTLR 4.7.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\21")
        buf.write("\u01d1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\3\2\3\2\3\2\3\2\3\2\3\2\3\2\7\2\62")
        buf.write("\n\2\f\2\16\2\65\13\2\3\2\3\2\3\3\7\3:\n\3\f\3\16\3=\13")
        buf.write("\3\3\3\3\3\7\3A\n\3\f\3\16\3D\13\3\3\3\5\3G\n\3\3\3\3")
        buf.write("\3\7\3K\n\3\f\3\16\3N\13\3\3\4\7\4Q\n\4\f\4\16\4T\13\4")
        buf.write("\3\4\3\4\7\4X\n\4\f\4\16\4[\13\4\3\4\5\4^\n\4\3\4\3\4")
        buf.write("\7\4b\n\4\f\4\16\4e\13\4\3\5\7\5h\n\5\f\5\16\5k\13\5\3")
        buf.write("\5\3\5\6\5o\n\5\r\5\16\5p\3\5\3\5\6\5u\n\5\r\5\16\5v\3")
        buf.write("\5\3\5\7\5{\n\5\f\5\16\5~\13\5\3\5\5\5\u0081\n\5\3\5\5")
        buf.write("\5\u0084\n\5\3\6\3\6\5\6\u0088\n\6\3\7\3\7\3\7\3\7\5\7")
        buf.write("\u008e\n\7\3\7\5\7\u0091\n\7\3\7\5\7\u0094\n\7\3\b\7\b")
        buf.write("\u0097\n\b\f\b\16\b\u009a\13\b\3\b\3\b\7\b\u009e\n\b\f")
        buf.write("\b\16\b\u00a1\13\b\3\t\7\t\u00a4\n\t\f\t\16\t\u00a7\13")
        buf.write("\t\3\t\3\t\6\t\u00ab\n\t\r\t\16\t\u00ac\3\t\3\t\6\t\u00b1")
        buf.write("\n\t\r\t\16\t\u00b2\3\t\3\t\7\t\u00b7\n\t\f\t\16\t\u00ba")
        buf.write("\13\t\3\n\7\n\u00bd\n\n\f\n\16\n\u00c0\13\n\3\n\3\n\7")
        buf.write("\n\u00c4\n\n\f\n\16\n\u00c7\13\n\3\13\7\13\u00ca\n\13")
        buf.write("\f\13\16\13\u00cd\13\13\3\13\3\13\7\13\u00d1\n\13\f\13")
        buf.write("\16\13\u00d4\13\13\3\13\5\13\u00d7\n\13\3\13\3\13\7\13")
        buf.write("\u00db\n\13\f\13\16\13\u00de\13\13\3\f\7\f\u00e1\n\f\f")
        buf.write("\f\16\f\u00e4\13\f\3\f\3\f\6\f\u00e8\n\f\r\f\16\f\u00e9")
        buf.write("\3\f\3\f\6\f\u00ee\n\f\r\f\16\f\u00ef\3\f\3\f\7\f\u00f4")
        buf.write("\n\f\f\f\16\f\u00f7\13\f\3\f\5\f\u00fa\n\f\3\f\5\f\u00fd")
        buf.write("\n\f\3\r\7\r\u0100\n\r\f\r\16\r\u0103\13\r\3\r\3\r\7\r")
        buf.write("\u0107\n\r\f\r\16\r\u010a\13\r\3\r\5\r\u010d\n\r\3\r\3")
        buf.write("\r\7\r\u0111\n\r\f\r\16\r\u0114\13\r\3\16\7\16\u0117\n")
        buf.write("\16\f\16\16\16\u011a\13\16\3\16\3\16\6\16\u011e\n\16\r")
        buf.write("\16\16\16\u011f\3\16\3\16\6\16\u0124\n\16\r\16\16\16\u0125")
        buf.write("\3\16\3\16\7\16\u012a\n\16\f\16\16\16\u012d\13\16\3\16")
        buf.write("\5\16\u0130\n\16\3\16\5\16\u0133\n\16\3\17\7\17\u0136")
        buf.write("\n\17\f\17\16\17\u0139\13\17\3\17\3\17\7\17\u013d\n\17")
        buf.write("\f\17\16\17\u0140\13\17\3\17\5\17\u0143\n\17\3\17\3\17")
        buf.write("\7\17\u0147\n\17\f\17\16\17\u014a\13\17\3\20\3\20\3\20")
        buf.write("\3\20\5\20\u0150\n\20\3\20\5\20\u0153\n\20\3\21\7\21\u0156")
        buf.write("\n\21\f\21\16\21\u0159\13\21\3\21\3\21\7\21\u015d\n\21")
        buf.write("\f\21\16\21\u0160\13\21\3\21\5\21\u0163\n\21\3\21\3\21")
        buf.write("\7\21\u0167\n\21\f\21\16\21\u016a\13\21\3\22\7\22\u016d")
        buf.write("\n\22\f\22\16\22\u0170\13\22\3\22\3\22\6\22\u0174\n\22")
        buf.write("\r\22\16\22\u0175\3\22\3\22\7\22\u017a\n\22\f\22\16\22")
        buf.write("\u017d\13\22\3\22\5\22\u0180\n\22\3\22\5\22\u0183\n\22")
        buf.write("\3\23\7\23\u0186\n\23\f\23\16\23\u0189\13\23\3\23\3\23")
        buf.write("\7\23\u018d\n\23\f\23\16\23\u0190\13\23\3\23\5\23\u0193")
        buf.write("\n\23\3\23\3\23\7\23\u0197\n\23\f\23\16\23\u019a\13\23")
        buf.write("\3\24\7\24\u019d\n\24\f\24\16\24\u01a0\13\24\3\24\3\24")
        buf.write("\6\24\u01a4\n\24\r\24\16\24\u01a5\3\24\3\24\7\24\u01aa")
        buf.write("\n\24\f\24\16\24\u01ad\13\24\3\24\3\24\7\24\u01b1\n\24")
        buf.write("\f\24\16\24\u01b4\13\24\3\24\3\24\7\24\u01b8\n\24\f\24")
        buf.write("\16\24\u01bb\13\24\3\24\5\24\u01be\n\24\3\24\5\24\u01c1")
        buf.write("\n\24\3\25\3\25\6\25\u01c5\n\25\r\25\16\25\u01c6\3\25")
        buf.write("\3\25\6\25\u01cb\n\25\r\25\16\25\u01cc\3\25\3\25\3\25")
        buf.write("\2\2\26\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(\2")
        buf.write("\3\3\2\t\n\2\u020d\2\63\3\2\2\2\4;\3\2\2\2\6R\3\2\2\2")
        buf.write("\bi\3\2\2\2\n\u0087\3\2\2\2\f\u0089\3\2\2\2\16\u0098\3")
        buf.write("\2\2\2\20\u00a5\3\2\2\2\22\u00be\3\2\2\2\24\u00cb\3\2")
        buf.write("\2\2\26\u00e2\3\2\2\2\30\u0101\3\2\2\2\32\u0118\3\2\2")
        buf.write("\2\34\u0137\3\2\2\2\36\u014b\3\2\2\2 \u0157\3\2\2\2\"")
        buf.write("\u016e\3\2\2\2$\u0187\3\2\2\2&\u019e\3\2\2\2(\u01c2\3")
        buf.write("\2\2\2*\62\5\4\3\2+\62\5\6\4\2,\62\5\24\13\2-\62\5$\23")
        buf.write("\2.\62\5 \21\2/\62\5\30\r\2\60\62\5\34\17\2\61*\3\2\2")
        buf.write("\2\61+\3\2\2\2\61,\3\2\2\2\61-\3\2\2\2\61.\3\2\2\2\61")
        buf.write("/\3\2\2\2\61\60\3\2\2\2\62\65\3\2\2\2\63\61\3\2\2\2\63")
        buf.write("\64\3\2\2\2\64\66\3\2\2\2\65\63\3\2\2\2\66\67\7\2\2\3")
        buf.write("\67\3\3\2\2\28:\7\3\2\298\3\2\2\2:=\3\2\2\2;9\3\2\2\2")
        buf.write(";<\3\2\2\2<>\3\2\2\2=;\3\2\2\2>B\7\4\2\2?A\7\3\2\2@?\3")
        buf.write("\2\2\2AD\3\2\2\2B@\3\2\2\2BC\3\2\2\2CF\3\2\2\2DB\3\2\2")
        buf.write("\2EG\7\5\2\2FE\3\2\2\2FG\3\2\2\2GH\3\2\2\2HL\7\6\2\2I")
        buf.write("K\5\b\5\2JI\3\2\2\2KN\3\2\2\2LJ\3\2\2\2LM\3\2\2\2M\5\3")
        buf.write("\2\2\2NL\3\2\2\2OQ\7\3\2\2PO\3\2\2\2QT\3\2\2\2RP\3\2\2")
        buf.write("\2RS\3\2\2\2SU\3\2\2\2TR\3\2\2\2UY\7\7\2\2VX\7\3\2\2W")
        buf.write("V\3\2\2\2X[\3\2\2\2YW\3\2\2\2YZ\3\2\2\2Z]\3\2\2\2[Y\3")
        buf.write("\2\2\2\\^\7\5\2\2]\\\3\2\2\2]^\3\2\2\2^_\3\2\2\2_c\7\6")
        buf.write("\2\2`b\5\f\7\2a`\3\2\2\2be\3\2\2\2ca\3\2\2\2cd\3\2\2\2")
        buf.write("d\7\3\2\2\2ec\3\2\2\2fh\7\3\2\2gf\3\2\2\2hk\3\2\2\2ig")
        buf.write("\3\2\2\2ij\3\2\2\2jl\3\2\2\2ki\3\2\2\2ln\7\21\2\2mo\7")
        buf.write("\3\2\2nm\3\2\2\2op\3\2\2\2pn\3\2\2\2pq\3\2\2\2qr\3\2\2")
        buf.write("\2rt\7\21\2\2su\7\3\2\2ts\3\2\2\2uv\3\2\2\2vt\3\2\2\2")
        buf.write("vw\3\2\2\2wx\3\2\2\2x|\7\21\2\2y{\7\3\2\2zy\3\2\2\2{~")
        buf.write("\3\2\2\2|z\3\2\2\2|}\3\2\2\2}\u0080\3\2\2\2~|\3\2\2\2")
        buf.write("\177\u0081\7\5\2\2\u0080\177\3\2\2\2\u0080\u0081\3\2\2")
        buf.write("\2\u0081\u0083\3\2\2\2\u0082\u0084\7\6\2\2\u0083\u0082")
        buf.write("\3\2\2\2\u0083\u0084\3\2\2\2\u0084\t\3\2\2\2\u0085\u0088")
        buf.write("\5\20\t\2\u0086\u0088\5\22\n\2\u0087\u0085\3\2\2\2\u0087")
        buf.write("\u0086\3\2\2\2\u0088\13\3\2\2\2\u0089\u008a\5\n\6\2\u008a")
        buf.write("\u008b\7\b\2\2\u008b\u008d\5\n\6\2\u008c\u008e\5\16\b")
        buf.write("\2\u008d\u008c\3\2\2\2\u008d\u008e\3\2\2\2\u008e\u0090")
        buf.write("\3\2\2\2\u008f\u0091\7\5\2\2\u0090\u008f\3\2\2\2\u0090")
        buf.write("\u0091\3\2\2\2\u0091\u0093\3\2\2\2\u0092\u0094\7\6\2\2")
        buf.write("\u0093\u0092\3\2\2\2\u0093\u0094\3\2\2\2\u0094\r\3\2\2")
        buf.write("\2\u0095\u0097\7\3\2\2\u0096\u0095\3\2\2\2\u0097\u009a")
        buf.write("\3\2\2\2\u0098\u0096\3\2\2\2\u0098\u0099\3\2\2\2\u0099")
        buf.write("\u009b\3\2\2\2\u009a\u0098\3\2\2\2\u009b\u009f\t\2\2\2")
        buf.write("\u009c\u009e\7\3\2\2\u009d\u009c\3\2\2\2\u009e\u00a1\3")
        buf.write("\2\2\2\u009f\u009d\3\2\2\2\u009f\u00a0\3\2\2\2\u00a0\17")
        buf.write("\3\2\2\2\u00a1\u009f\3\2\2\2\u00a2\u00a4\7\3\2\2\u00a3")
        buf.write("\u00a2\3\2\2\2\u00a4\u00a7\3\2\2\2\u00a5\u00a3\3\2\2\2")
        buf.write("\u00a5\u00a6\3\2\2\2\u00a6\u00a8\3\2\2\2\u00a7\u00a5\3")
        buf.write("\2\2\2\u00a8\u00aa\7\21\2\2\u00a9\u00ab\7\3\2\2\u00aa")
        buf.write("\u00a9\3\2\2\2\u00ab\u00ac\3\2\2\2\u00ac\u00aa\3\2\2\2")
        buf.write("\u00ac\u00ad\3\2\2\2\u00ad\u00ae\3\2\2\2\u00ae\u00b0\7")
        buf.write("\21\2\2\u00af\u00b1\7\3\2\2\u00b0\u00af\3\2\2\2\u00b1")
        buf.write("\u00b2\3\2\2\2\u00b2\u00b0\3\2\2\2\u00b2\u00b3\3\2\2\2")
        buf.write("\u00b3\u00b4\3\2\2\2\u00b4\u00b8\7\21\2\2\u00b5\u00b7")
        buf.write("\7\3\2\2\u00b6\u00b5\3\2\2\2\u00b7\u00ba\3\2\2\2\u00b8")
        buf.write("\u00b6\3\2\2\2\u00b8\u00b9\3\2\2\2\u00b9\21\3\2\2\2\u00ba")
        buf.write("\u00b8\3\2\2\2\u00bb\u00bd\7\3\2\2\u00bc\u00bb\3\2\2\2")
        buf.write("\u00bd\u00c0\3\2\2\2\u00be\u00bc\3\2\2\2\u00be\u00bf\3")
        buf.write("\2\2\2\u00bf\u00c1\3\2\2\2\u00c0\u00be\3\2\2\2\u00c1\u00c5")
        buf.write("\7\21\2\2\u00c2\u00c4\7\3\2\2\u00c3\u00c2\3\2\2\2\u00c4")
        buf.write("\u00c7\3\2\2\2\u00c5\u00c3\3\2\2\2\u00c5\u00c6\3\2\2\2")
        buf.write("\u00c6\23\3\2\2\2\u00c7\u00c5\3\2\2\2\u00c8\u00ca\7\3")
        buf.write("\2\2\u00c9\u00c8\3\2\2\2\u00ca\u00cd\3\2\2\2\u00cb\u00c9")
        buf.write("\3\2\2\2\u00cb\u00cc\3\2\2\2\u00cc\u00ce\3\2\2\2\u00cd")
        buf.write("\u00cb\3\2\2\2\u00ce\u00d2\7\13\2\2\u00cf\u00d1\7\3\2")
        buf.write("\2\u00d0\u00cf\3\2\2\2\u00d1\u00d4\3\2\2\2\u00d2\u00d0")
        buf.write("\3\2\2\2\u00d2\u00d3\3\2\2\2\u00d3\u00d6\3\2\2\2\u00d4")
        buf.write("\u00d2\3\2\2\2\u00d5\u00d7\7\5\2\2\u00d6\u00d5\3\2\2\2")
        buf.write("\u00d6\u00d7\3\2\2\2\u00d7\u00d8\3\2\2\2\u00d8\u00dc\7")
        buf.write("\6\2\2\u00d9\u00db\5\26\f\2\u00da\u00d9\3\2\2\2\u00db")
        buf.write("\u00de\3\2\2\2\u00dc\u00da\3\2\2\2\u00dc\u00dd\3\2\2\2")
        buf.write("\u00dd\25\3\2\2\2\u00de\u00dc\3\2\2\2\u00df\u00e1\7\3")
        buf.write("\2\2\u00e0\u00df\3\2\2\2\u00e1\u00e4\3\2\2\2\u00e2\u00e0")
        buf.write("\3\2\2\2\u00e2\u00e3\3\2\2\2\u00e3\u00e5\3\2\2\2\u00e4")
        buf.write("\u00e2\3\2\2\2\u00e5\u00e7\7\21\2\2\u00e6\u00e8\7\3\2")
        buf.write("\2\u00e7\u00e6\3\2\2\2\u00e8\u00e9\3\2\2\2\u00e9\u00e7")
        buf.write("\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb")
        buf.write("\u00ed\7\21\2\2\u00ec\u00ee\7\3\2\2\u00ed\u00ec\3\2\2")
        buf.write("\2\u00ee\u00ef\3\2\2\2\u00ef\u00ed\3\2\2\2\u00ef\u00f0")
        buf.write("\3\2\2\2\u00f0\u00f1\3\2\2\2\u00f1\u00f5\7\21\2\2\u00f2")
        buf.write("\u00f4\7\3\2\2\u00f3\u00f2\3\2\2\2\u00f4\u00f7\3\2\2\2")
        buf.write("\u00f5\u00f3\3\2\2\2\u00f5\u00f6\3\2\2\2\u00f6\u00f9\3")
        buf.write("\2\2\2\u00f7\u00f5\3\2\2\2\u00f8\u00fa\7\5\2\2\u00f9\u00f8")
        buf.write("\3\2\2\2\u00f9\u00fa\3\2\2\2\u00fa\u00fc\3\2\2\2\u00fb")
        buf.write("\u00fd\7\6\2\2\u00fc\u00fb\3\2\2\2\u00fc\u00fd\3\2\2\2")
        buf.write("\u00fd\27\3\2\2\2\u00fe\u0100\7\3\2\2\u00ff\u00fe\3\2")
        buf.write("\2\2\u0100\u0103\3\2\2\2\u0101\u00ff\3\2\2\2\u0101\u0102")
        buf.write("\3\2\2\2\u0102\u0104\3\2\2\2\u0103\u0101\3\2\2\2\u0104")
        buf.write("\u0108\7\f\2\2\u0105\u0107\7\3\2\2\u0106\u0105\3\2\2\2")
        buf.write("\u0107\u010a\3\2\2\2\u0108\u0106\3\2\2\2\u0108\u0109\3")
        buf.write("\2\2\2\u0109\u010c\3\2\2\2\u010a\u0108\3\2\2\2\u010b\u010d")
        buf.write("\7\5\2\2\u010c\u010b\3\2\2\2\u010c\u010d\3\2\2\2\u010d")
        buf.write("\u010e\3\2\2\2\u010e\u0112\7\6\2\2\u010f\u0111\5\32\16")
        buf.write("\2\u0110\u010f\3\2\2\2\u0111\u0114\3\2\2\2\u0112\u0110")
        buf.write("\3\2\2\2\u0112\u0113\3\2\2\2\u0113\31\3\2\2\2\u0114\u0112")
        buf.write("\3\2\2\2\u0115\u0117\7\3\2\2\u0116\u0115\3\2\2\2\u0117")
        buf.write("\u011a\3\2\2\2\u0118\u0116\3\2\2\2\u0118\u0119\3\2\2\2")
        buf.write("\u0119\u011b\3\2\2\2\u011a\u0118\3\2\2\2\u011b\u011d\7")
        buf.write("\21\2\2\u011c\u011e\7\3\2\2\u011d\u011c\3\2\2\2\u011e")
        buf.write("\u011f\3\2\2\2\u011f\u011d\3\2\2\2\u011f\u0120\3\2\2\2")
        buf.write("\u0120\u0121\3\2\2\2\u0121\u0123\7\21\2\2\u0122\u0124")
        buf.write("\7\3\2\2\u0123\u0122\3\2\2\2\u0124\u0125\3\2\2\2\u0125")
        buf.write("\u0123\3\2\2\2\u0125\u0126\3\2\2\2\u0126\u0127\3\2\2\2")
        buf.write("\u0127\u012b\7\21\2\2\u0128\u012a\7\3\2\2\u0129\u0128")
        buf.write("\3\2\2\2\u012a\u012d\3\2\2\2\u012b\u0129\3\2\2\2\u012b")
        buf.write("\u012c\3\2\2\2\u012c\u012f\3\2\2\2\u012d\u012b\3\2\2\2")
        buf.write("\u012e\u0130\7\5\2\2\u012f\u012e\3\2\2\2\u012f\u0130\3")
        buf.write("\2\2\2\u0130\u0132\3\2\2\2\u0131\u0133\7\6\2\2\u0132\u0131")
        buf.write("\3\2\2\2\u0132\u0133\3\2\2\2\u0133\33\3\2\2\2\u0134\u0136")
        buf.write("\7\3\2\2\u0135\u0134\3\2\2\2\u0136\u0139\3\2\2\2\u0137")
        buf.write("\u0135\3\2\2\2\u0137\u0138\3\2\2\2\u0138\u013a\3\2\2\2")
        buf.write("\u0139\u0137\3\2\2\2\u013a\u013e\7\r\2\2\u013b\u013d\7")
        buf.write("\3\2\2\u013c\u013b\3\2\2\2\u013d\u0140\3\2\2\2\u013e\u013c")
        buf.write("\3\2\2\2\u013e\u013f\3\2\2\2\u013f\u0142\3\2\2\2\u0140")
        buf.write("\u013e\3\2\2\2\u0141\u0143\7\5\2\2\u0142\u0141\3\2\2\2")
        buf.write("\u0142\u0143\3\2\2\2\u0143\u0144\3\2\2\2\u0144\u0148\7")
        buf.write("\6\2\2\u0145\u0147\5\36\20\2\u0146\u0145\3\2\2\2\u0147")
        buf.write("\u014a\3\2\2\2\u0148\u0146\3\2\2\2\u0148\u0149\3\2\2\2")
        buf.write("\u0149\35\3\2\2\2\u014a\u0148\3\2\2\2\u014b\u014c\5\n")
        buf.write("\6\2\u014c\u014d\7\b\2\2\u014d\u014f\5\n\6\2\u014e\u0150")
        buf.write("\7\5\2\2\u014f\u014e\3\2\2\2\u014f\u0150\3\2\2\2\u0150")
        buf.write("\u0152\3\2\2\2\u0151\u0153\7\6\2\2\u0152\u0151\3\2\2\2")
        buf.write("\u0152\u0153\3\2\2\2\u0153\37\3\2\2\2\u0154\u0156\7\3")
        buf.write("\2\2\u0155\u0154\3\2\2\2\u0156\u0159\3\2\2\2\u0157\u0155")
        buf.write("\3\2\2\2\u0157\u0158\3\2\2\2\u0158\u015a\3\2\2\2\u0159")
        buf.write("\u0157\3\2\2\2\u015a\u015e\7\16\2\2\u015b\u015d\7\3\2")
        buf.write("\2\u015c\u015b\3\2\2\2\u015d\u0160\3\2\2\2\u015e\u015c")
        buf.write("\3\2\2\2\u015e\u015f\3\2\2\2\u015f\u0162\3\2\2\2\u0160")
        buf.write("\u015e\3\2\2\2\u0161\u0163\7\5\2\2\u0162\u0161\3\2\2\2")
        buf.write("\u0162\u0163\3\2\2\2\u0163\u0164\3\2\2\2\u0164\u0168\7")
        buf.write("\6\2\2\u0165\u0167\5\"\22\2\u0166\u0165\3\2\2\2\u0167")
        buf.write("\u016a\3\2\2\2\u0168\u0166\3\2\2\2\u0168\u0169\3\2\2\2")
        buf.write("\u0169!\3\2\2\2\u016a\u0168\3\2\2\2\u016b\u016d\7\3\2")
        buf.write("\2\u016c\u016b\3\2\2\2\u016d\u0170\3\2\2\2\u016e\u016c")
        buf.write("\3\2\2\2\u016e\u016f\3\2\2\2\u016f\u0171\3\2\2\2\u0170")
        buf.write("\u016e\3\2\2\2\u0171\u0173\7\21\2\2\u0172\u0174\7\3\2")
        buf.write("\2\u0173\u0172\3\2\2\2\u0174\u0175\3\2\2\2\u0175\u0173")
        buf.write("\3\2\2\2\u0175\u0176\3\2\2\2\u0176\u0177\3\2\2\2\u0177")
        buf.write("\u017b\7\21\2\2\u0178\u017a\7\3\2\2\u0179\u0178\3\2\2")
        buf.write("\2\u017a\u017d\3\2\2\2\u017b\u0179\3\2\2\2\u017b\u017c")
        buf.write("\3\2\2\2\u017c\u017f\3\2\2\2\u017d\u017b\3\2\2\2\u017e")
        buf.write("\u0180\7\5\2\2\u017f\u017e\3\2\2\2\u017f\u0180\3\2\2\2")
        buf.write("\u0180\u0182\3\2\2\2\u0181\u0183\7\6\2\2\u0182\u0181\3")
        buf.write("\2\2\2\u0182\u0183\3\2\2\2\u0183#\3\2\2\2\u0184\u0186")
        buf.write("\7\3\2\2\u0185\u0184\3\2\2\2\u0186\u0189\3\2\2\2\u0187")
        buf.write("\u0185\3\2\2\2\u0187\u0188\3\2\2\2\u0188\u018a\3\2\2\2")
        buf.write("\u0189\u0187\3\2\2\2\u018a\u018e\7\17\2\2\u018b\u018d")
        buf.write("\7\3\2\2\u018c\u018b\3\2\2\2\u018d\u0190\3\2\2\2\u018e")
        buf.write("\u018c\3\2\2\2\u018e\u018f\3\2\2\2\u018f\u0192\3\2\2\2")
        buf.write("\u0190\u018e\3\2\2\2\u0191\u0193\7\5\2\2\u0192\u0191\3")
        buf.write("\2\2\2\u0192\u0193\3\2\2\2\u0193\u0194\3\2\2\2\u0194\u0198")
        buf.write("\7\6\2\2\u0195\u0197\5&\24\2\u0196\u0195\3\2\2\2\u0197")
        buf.write("\u019a\3\2\2\2\u0198\u0196\3\2\2\2\u0198\u0199\3\2\2\2")
        buf.write("\u0199%\3\2\2\2\u019a\u0198\3\2\2\2\u019b\u019d\7\3\2")
        buf.write("\2\u019c\u019b\3\2\2\2\u019d\u01a0\3\2\2\2\u019e\u019c")
        buf.write("\3\2\2\2\u019e\u019f\3\2\2\2\u019f\u01a1\3\2\2\2\u01a0")
        buf.write("\u019e\3\2\2\2\u01a1\u01a3\7\21\2\2\u01a2\u01a4\7\3\2")
        buf.write("\2\u01a3\u01a2\3\2\2\2\u01a4\u01a5\3\2\2\2\u01a5\u01a3")
        buf.write("\3\2\2\2\u01a5\u01a6\3\2\2\2\u01a6\u01a7\3\2\2\2\u01a7")
        buf.write("\u01ab\5(\25\2\u01a8\u01aa\7\3\2\2\u01a9\u01a8\3\2\2\2")
        buf.write("\u01aa\u01ad\3\2\2\2\u01ab\u01a9\3\2\2\2\u01ab\u01ac\3")
        buf.write("\2\2\2\u01ac\u01ae\3\2\2\2\u01ad\u01ab\3\2\2\2\u01ae\u01b2")
        buf.write("\7\b\2\2\u01af\u01b1\7\3\2\2\u01b0\u01af\3\2\2\2\u01b1")
        buf.write("\u01b4\3\2\2\2\u01b2\u01b0\3\2\2\2\u01b2\u01b3\3\2\2\2")
        buf.write("\u01b3\u01b5\3\2\2\2\u01b4\u01b2\3\2\2\2\u01b5\u01b9\5")
        buf.write("(\25\2\u01b6\u01b8\7\3\2\2\u01b7\u01b6\3\2\2\2\u01b8\u01bb")
        buf.write("\3\2\2\2\u01b9\u01b7\3\2\2\2\u01b9\u01ba\3\2\2\2\u01ba")
        buf.write("\u01bd\3\2\2\2\u01bb\u01b9\3\2\2\2\u01bc\u01be\7\5\2\2")
        buf.write("\u01bd\u01bc\3\2\2\2\u01bd\u01be\3\2\2\2\u01be\u01c0\3")
        buf.write("\2\2\2\u01bf\u01c1\7\6\2\2\u01c0\u01bf\3\2\2\2\u01c0\u01c1")
        buf.write("\3\2\2\2\u01c1\'\3\2\2\2\u01c2\u01c4\7\21\2\2\u01c3\u01c5")
        buf.write("\7\3\2\2\u01c4\u01c3\3\2\2\2\u01c5\u01c6\3\2\2\2\u01c6")
        buf.write("\u01c4\3\2\2\2\u01c6\u01c7\3\2\2\2\u01c7\u01c8\3\2\2\2")
        buf.write("\u01c8\u01ca\7\21\2\2\u01c9\u01cb\7\3\2\2\u01ca\u01c9")
        buf.write("\3\2\2\2\u01cb\u01cc\3\2\2\2\u01cc\u01ca\3\2\2\2\u01cc")
        buf.write("\u01cd\3\2\2\2\u01cd\u01ce\3\2\2\2\u01ce\u01cf\7\21\2")
        buf.write("\2\u01cf)\3\2\2\2N\61\63;BFLRY]cipv|\u0080\u0083\u0087")
        buf.write("\u008d\u0090\u0093\u0098\u009f\u00a5\u00ac\u00b2\u00b8")
        buf.write("\u00be\u00c5\u00cb\u00d2\u00d6\u00dc\u00e2\u00e9\u00ef")
        buf.write("\u00f5\u00f9\u00fc\u0101\u0108\u010c\u0112\u0118\u011f")
        buf.write("\u0125\u012b\u012f\u0132\u0137\u013e\u0142\u0148\u014f")
        buf.write("\u0152\u0157\u015e\u0162\u0168\u016e\u0175\u017b\u017f")
        buf.write("\u0182\u0187\u018e\u0192\u0198\u019e\u01a5\u01ab\u01b2")
        buf.write("\u01b9\u01bd\u01c0\u01c6\u01cc")
        return buf.getvalue()


class MapParser ( Parser ):

    grammarFileName = "Map.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "' '", "'[Node]'", "'\r'", "'\n'", "'[Edge]'", 
                     "'-'", "'-door'", "'-d'", "'[Material]'", "'[HMaterial]'", 
                     "'[Door]'", "'[Elevator]'", "'[Block]'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "COMMENT", "INT" ]

    RULE_prog = 0
    RULE_nodes_info = 1
    RULE_edges_info = 2
    RULE_node_info = 3
    RULE_bind_edge = 4
    RULE_edge_info = 5
    RULE_edge_door = 6
    RULE_node_info__edge_1 = 7
    RULE_node_info__edge_2 = 8
    RULE_materials_info = 9
    RULE_material_info = 10
    RULE_hmaterials_info = 11
    RULE_hmaterial_info = 12
    RULE_doors_info = 13
    RULE_door_info = 14
    RULE_elevators_info = 15
    RULE_elevator_info = 16
    RULE_blocks_info = 17
    RULE_block_info = 18
    RULE_node_info__block = 19

    ruleNames =  [ "prog", "nodes_info", "edges_info", "node_info", "bind_edge", 
                   "edge_info", "edge_door", "node_info__edge_1", "node_info__edge_2", 
                   "materials_info", "material_info", "hmaterials_info", 
                   "hmaterial_info", "doors_info", "door_info", "elevators_info", 
                   "elevator_info", "blocks_info", "block_info", "node_info__block" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    COMMENT=14
    INT=15

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(MapParser.EOF, 0)

        def nodes_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Nodes_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Nodes_infoContext,i)


        def edges_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Edges_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Edges_infoContext,i)


        def materials_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Materials_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Materials_infoContext,i)


        def blocks_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Blocks_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Blocks_infoContext,i)


        def elevators_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Elevators_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Elevators_infoContext,i)


        def hmaterials_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Hmaterials_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Hmaterials_infoContext,i)


        def doors_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Doors_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Doors_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)




    def prog(self):

        localctx = MapParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MapParser.T__0) | (1 << MapParser.T__1) | (1 << MapParser.T__4) | (1 << MapParser.T__8) | (1 << MapParser.T__9) | (1 << MapParser.T__10) | (1 << MapParser.T__11) | (1 << MapParser.T__12))) != 0):
                self.state = 47
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 40
                    self.nodes_info()
                    pass

                elif la_ == 2:
                    self.state = 41
                    self.edges_info()
                    pass

                elif la_ == 3:
                    self.state = 42
                    self.materials_info()
                    pass

                elif la_ == 4:
                    self.state = 43
                    self.blocks_info()
                    pass

                elif la_ == 5:
                    self.state = 44
                    self.elevators_info()
                    pass

                elif la_ == 6:
                    self.state = 45
                    self.hmaterials_info()
                    pass

                elif la_ == 7:
                    self.state = 46
                    self.doors_info()
                    pass


                self.state = 51
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 52
            self.match(MapParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Nodes_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def node_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Node_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Node_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_nodes_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNodes_info" ):
                listener.enterNodes_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNodes_info" ):
                listener.exitNodes_info(self)




    def nodes_info(self):

        localctx = MapParser.Nodes_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_nodes_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 54
                self.match(MapParser.T__0)
                self.state = 59
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 60
            self.match(MapParser.T__1)
            self.state = 64
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 61
                self.match(MapParser.T__0)
                self.state = 66
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 68
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 67
                self.match(MapParser.T__2)


            self.state = 70
            self.match(MapParser.T__3)
            self.state = 74
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 71
                    self.node_info() 
                self.state = 76
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Edges_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def edge_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Edge_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Edge_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_edges_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEdges_info" ):
                listener.enterEdges_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEdges_info" ):
                listener.exitEdges_info(self)




    def edges_info(self):

        localctx = MapParser.Edges_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_edges_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 77
                self.match(MapParser.T__0)
                self.state = 82
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 83
            self.match(MapParser.T__4)
            self.state = 87
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 84
                self.match(MapParser.T__0)
                self.state = 89
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 91
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 90
                self.match(MapParser.T__2)


            self.state = 93
            self.match(MapParser.T__3)
            self.state = 97
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 94
                    self.edge_info() 
                self.state = 99
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Node_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_node_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_info" ):
                listener.enterNode_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_info" ):
                listener.exitNode_info(self)




    def node_info(self):

        localctx = MapParser.Node_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_node_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 100
                self.match(MapParser.T__0)
                self.state = 105
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 106
            self.match(MapParser.INT)
            self.state = 108 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 107
                self.match(MapParser.T__0)
                self.state = 110 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 112
            self.match(MapParser.INT)
            self.state = 114 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 113
                self.match(MapParser.T__0)
                self.state = 116 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 118
            self.match(MapParser.INT)
            self.state = 122
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 119
                    self.match(MapParser.T__0) 
                self.state = 124
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

            self.state = 126
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 125
                self.match(MapParser.T__2)


            self.state = 129
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 128
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Bind_edgeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def node_info__edge_1(self):
            return self.getTypedRuleContext(MapParser.Node_info__edge_1Context,0)


        def node_info__edge_2(self):
            return self.getTypedRuleContext(MapParser.Node_info__edge_2Context,0)


        def getRuleIndex(self):
            return MapParser.RULE_bind_edge

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBind_edge" ):
                listener.enterBind_edge(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBind_edge" ):
                listener.exitBind_edge(self)




    def bind_edge(self):

        localctx = MapParser.Bind_edgeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_bind_edge)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.state = 131
                self.node_info__edge_1()
                pass

            elif la_ == 2:
                self.state = 132
                self.node_info__edge_2()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Edge_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bind_edge(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Bind_edgeContext)
            else:
                return self.getTypedRuleContext(MapParser.Bind_edgeContext,i)


        def edge_door(self):
            return self.getTypedRuleContext(MapParser.Edge_doorContext,0)


        def getRuleIndex(self):
            return MapParser.RULE_edge_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEdge_info" ):
                listener.enterEdge_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEdge_info" ):
                listener.exitEdge_info(self)




    def edge_info(self):

        localctx = MapParser.Edge_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_edge_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self.bind_edge()
            self.state = 136
            self.match(MapParser.T__5)
            self.state = 137
            self.bind_edge()
            self.state = 139
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 138
                self.edge_door()


            self.state = 142
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 141
                self.match(MapParser.T__2)


            self.state = 145
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 144
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Edge_doorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return MapParser.RULE_edge_door

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEdge_door" ):
                listener.enterEdge_door(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEdge_door" ):
                listener.exitEdge_door(self)




    def edge_door(self):

        localctx = MapParser.Edge_doorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_edge_door)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 147
                self.match(MapParser.T__0)
                self.state = 152
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 153
            _la = self._input.LA(1)
            if not(_la==MapParser.T__6 or _la==MapParser.T__7):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 157
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,21,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 154
                    self.match(MapParser.T__0) 
                self.state = 159
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,21,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Node_info__edge_1Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_node_info__edge_1

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_info__edge_1" ):
                listener.enterNode_info__edge_1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_info__edge_1" ):
                listener.exitNode_info__edge_1(self)




    def node_info__edge_1(self):

        localctx = MapParser.Node_info__edge_1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_node_info__edge_1)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 160
                self.match(MapParser.T__0)
                self.state = 165
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 166
            self.match(MapParser.INT)
            self.state = 168 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 167
                self.match(MapParser.T__0)
                self.state = 170 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 172
            self.match(MapParser.INT)
            self.state = 174 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 173
                self.match(MapParser.T__0)
                self.state = 176 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 178
            self.match(MapParser.INT)
            self.state = 182
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,25,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 179
                    self.match(MapParser.T__0) 
                self.state = 184
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,25,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Node_info__edge_2Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(MapParser.INT, 0)

        def getRuleIndex(self):
            return MapParser.RULE_node_info__edge_2

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_info__edge_2" ):
                listener.enterNode_info__edge_2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_info__edge_2" ):
                listener.exitNode_info__edge_2(self)




    def node_info__edge_2(self):

        localctx = MapParser.Node_info__edge_2Context(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_node_info__edge_2)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 185
                self.match(MapParser.T__0)
                self.state = 190
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 191
            self.match(MapParser.INT)
            self.state = 195
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,27,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 192
                    self.match(MapParser.T__0) 
                self.state = 197
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,27,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Materials_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def material_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Material_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Material_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_materials_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMaterials_info" ):
                listener.enterMaterials_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMaterials_info" ):
                listener.exitMaterials_info(self)




    def materials_info(self):

        localctx = MapParser.Materials_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_materials_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 201
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 198
                self.match(MapParser.T__0)
                self.state = 203
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 204
            self.match(MapParser.T__8)
            self.state = 208
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 205
                self.match(MapParser.T__0)
                self.state = 210
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 212
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 211
                self.match(MapParser.T__2)


            self.state = 214
            self.match(MapParser.T__3)
            self.state = 218
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,31,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 215
                    self.material_info() 
                self.state = 220
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,31,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Material_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_material_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMaterial_info" ):
                listener.enterMaterial_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMaterial_info" ):
                listener.exitMaterial_info(self)




    def material_info(self):

        localctx = MapParser.Material_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_material_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 221
                self.match(MapParser.T__0)
                self.state = 226
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 227
            self.match(MapParser.INT)
            self.state = 229 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 228
                self.match(MapParser.T__0)
                self.state = 231 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 233
            self.match(MapParser.INT)
            self.state = 235 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 234
                self.match(MapParser.T__0)
                self.state = 237 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 239
            self.match(MapParser.INT)
            self.state = 243
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,35,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 240
                    self.match(MapParser.T__0) 
                self.state = 245
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,35,self._ctx)

            self.state = 247
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 246
                self.match(MapParser.T__2)


            self.state = 250
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 249
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Hmaterials_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def hmaterial_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Hmaterial_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Hmaterial_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_hmaterials_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHmaterials_info" ):
                listener.enterHmaterials_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHmaterials_info" ):
                listener.exitHmaterials_info(self)




    def hmaterials_info(self):

        localctx = MapParser.Hmaterials_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_hmaterials_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 252
                self.match(MapParser.T__0)
                self.state = 257
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 258
            self.match(MapParser.T__9)
            self.state = 262
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 259
                self.match(MapParser.T__0)
                self.state = 264
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 266
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 265
                self.match(MapParser.T__2)


            self.state = 268
            self.match(MapParser.T__3)
            self.state = 272
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,41,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 269
                    self.hmaterial_info() 
                self.state = 274
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Hmaterial_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_hmaterial_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterHmaterial_info" ):
                listener.enterHmaterial_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitHmaterial_info" ):
                listener.exitHmaterial_info(self)




    def hmaterial_info(self):

        localctx = MapParser.Hmaterial_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_hmaterial_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 278
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 275
                self.match(MapParser.T__0)
                self.state = 280
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 281
            self.match(MapParser.INT)
            self.state = 283 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 282
                self.match(MapParser.T__0)
                self.state = 285 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 287
            self.match(MapParser.INT)
            self.state = 289 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 288
                self.match(MapParser.T__0)
                self.state = 291 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 293
            self.match(MapParser.INT)
            self.state = 297
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,45,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 294
                    self.match(MapParser.T__0) 
                self.state = 299
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,45,self._ctx)

            self.state = 301
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 300
                self.match(MapParser.T__2)


            self.state = 304
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 303
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Doors_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def door_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Door_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Door_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_doors_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDoors_info" ):
                listener.enterDoors_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDoors_info" ):
                listener.exitDoors_info(self)




    def doors_info(self):

        localctx = MapParser.Doors_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_doors_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 306
                self.match(MapParser.T__0)
                self.state = 311
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 312
            self.match(MapParser.T__10)
            self.state = 316
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 313
                self.match(MapParser.T__0)
                self.state = 318
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 320
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 319
                self.match(MapParser.T__2)


            self.state = 322
            self.match(MapParser.T__3)
            self.state = 326
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,51,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 323
                    self.door_info() 
                self.state = 328
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,51,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Door_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bind_edge(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Bind_edgeContext)
            else:
                return self.getTypedRuleContext(MapParser.Bind_edgeContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_door_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDoor_info" ):
                listener.enterDoor_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDoor_info" ):
                listener.exitDoor_info(self)




    def door_info(self):

        localctx = MapParser.Door_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_door_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 329
            self.bind_edge()
            self.state = 330
            self.match(MapParser.T__5)
            self.state = 331
            self.bind_edge()
            self.state = 333
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 332
                self.match(MapParser.T__2)


            self.state = 336
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 335
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Elevators_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def elevator_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Elevator_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Elevator_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_elevators_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElevators_info" ):
                listener.enterElevators_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElevators_info" ):
                listener.exitElevators_info(self)




    def elevators_info(self):

        localctx = MapParser.Elevators_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_elevators_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 341
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 338
                self.match(MapParser.T__0)
                self.state = 343
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 344
            self.match(MapParser.T__11)
            self.state = 348
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 345
                self.match(MapParser.T__0)
                self.state = 350
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 352
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 351
                self.match(MapParser.T__2)


            self.state = 354
            self.match(MapParser.T__3)
            self.state = 358
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,57,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 355
                    self.elevator_info() 
                self.state = 360
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,57,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Elevator_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_elevator_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElevator_info" ):
                listener.enterElevator_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElevator_info" ):
                listener.exitElevator_info(self)




    def elevator_info(self):

        localctx = MapParser.Elevator_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_elevator_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 364
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 361
                self.match(MapParser.T__0)
                self.state = 366
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 367
            self.match(MapParser.INT)
            self.state = 369 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 368
                self.match(MapParser.T__0)
                self.state = 371 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 373
            self.match(MapParser.INT)
            self.state = 377
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,60,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 374
                    self.match(MapParser.T__0) 
                self.state = 379
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,60,self._ctx)

            self.state = 381
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 380
                self.match(MapParser.T__2)


            self.state = 384
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 383
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Blocks_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block_info(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Block_infoContext)
            else:
                return self.getTypedRuleContext(MapParser.Block_infoContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_blocks_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlocks_info" ):
                listener.enterBlocks_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlocks_info" ):
                listener.exitBlocks_info(self)




    def blocks_info(self):

        localctx = MapParser.Blocks_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_blocks_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 389
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 386
                self.match(MapParser.T__0)
                self.state = 391
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 392
            self.match(MapParser.T__12)
            self.state = 396
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 393
                self.match(MapParser.T__0)
                self.state = 398
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 400
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 399
                self.match(MapParser.T__2)


            self.state = 402
            self.match(MapParser.T__3)
            self.state = 406
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,66,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 403
                    self.block_info() 
                self.state = 408
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,66,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Block_infoContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(MapParser.INT, 0)

        def node_info__block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MapParser.Node_info__blockContext)
            else:
                return self.getTypedRuleContext(MapParser.Node_info__blockContext,i)


        def getRuleIndex(self):
            return MapParser.RULE_block_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock_info" ):
                listener.enterBlock_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock_info" ):
                listener.exitBlock_info(self)




    def block_info(self):

        localctx = MapParser.Block_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_block_info)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 412
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 409
                self.match(MapParser.T__0)
                self.state = 414
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 415
            self.match(MapParser.INT)
            self.state = 417 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 416
                self.match(MapParser.T__0)
                self.state = 419 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 421
            self.node_info__block()
            self.state = 425
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 422
                self.match(MapParser.T__0)
                self.state = 427
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 428
            self.match(MapParser.T__5)
            self.state = 432
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==MapParser.T__0:
                self.state = 429
                self.match(MapParser.T__0)
                self.state = 434
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 435
            self.node_info__block()
            self.state = 439
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,71,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 436
                    self.match(MapParser.T__0) 
                self.state = 441
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,71,self._ctx)

            self.state = 443
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__2:
                self.state = 442
                self.match(MapParser.T__2)


            self.state = 446
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MapParser.T__3:
                self.state = 445
                self.match(MapParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Node_info__blockContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self, i:int=None):
            if i is None:
                return self.getTokens(MapParser.INT)
            else:
                return self.getToken(MapParser.INT, i)

        def getRuleIndex(self):
            return MapParser.RULE_node_info__block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_info__block" ):
                listener.enterNode_info__block(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_info__block" ):
                listener.exitNode_info__block(self)




    def node_info__block(self):

        localctx = MapParser.Node_info__blockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_node_info__block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.match(MapParser.INT)
            self.state = 450 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 449
                self.match(MapParser.T__0)
                self.state = 452 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 454
            self.match(MapParser.INT)
            self.state = 456 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 455
                self.match(MapParser.T__0)
                self.state = 458 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==MapParser.T__0):
                    break

            self.state = 460
            self.match(MapParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx






from .MapListener import MapListener
from .MapParser import MapParser
from ..position import Position
from ..map import Block, Map

class MapGen(MapListener):
    def __init__(self, map : 'Map', flash_rand_seed: bool = False, rand_seed: int = 0) -> None:
        super().__init__()
        self.map = map

        self.node_positions = []

        if flash_rand_seed:
            from random import seed

            seed(rand_seed)

    def _get_position(self, ints) -> Position:
        return Position(int(ints[1].getText()), int(ints[2].getText()), int(ints[0].getText()))

    def _get_bind_node_position(self, bind_edge) -> Position:
        try:
            raw_position = self._get_position(bind_edge.node_info__edge_1().INT())
            assert(raw_position is not None)
            return raw_position
        except:
            index = int(bind_edge.node_info__edge_2().INT().getText())
            if index >= len(self.node_positions):
                print('error in node index', bind_edge)
                exit(0)
            return self.node_positions[index]

    def enterNode_info(self, ctx: MapParser.Node_infoContext) -> None:
        new_position = self._get_position(ctx.INT())
        self.node_positions += [new_position]

        self.map.add_node(new_position)

    def enterEdge_info(self, ctx: MapParser.Edge_infoContext) -> None:
        position_1, position_2 = tuple(ctx.bind_edge())
        position_1, position_2 = self._get_bind_node_position(position_1), self._get_bind_node_position(position_2)
        node_1, node_2 = self.map.get_node_by_position(position_1), self.map.get_node_by_position(position_2)
        
        if ctx.edge_door() is not None and ctx.edge_door().getText() != '':
            self.map.add_edge(node_1, node_2, True)
        else:
            self.map.add_edge(node_1, node_2)

    def enterMaterial_info(self, ctx: MapParser.Material_infoContext) -> None:
        position = self._get_position(ctx.INT())

        self.map.add_material(position)
        
    def enterHmaterial_info(self, ctx: MapParser.Material_infoContext) -> None:
        position = self._get_position(ctx.INT())
        
        self.map.add_hmaterial(position)

    def enterDoor_info(self, ctx: MapParser.Door_infoContext) -> None:
        position_1, position_2 = tuple(ctx.bind_edge())
        position_1, position_2 = self._get_bind_node_position(position_1), self._get_bind_node_position(position_2)
        node_1, node_2 = self.map.get_node_by_position(position_1), self.map.get_node_by_position(position_2)
        
        self.map.add_door(node_1, node_2)

    def enterElevator_info(self, ctx: MapParser.Elevator_infoContext) -> None:
        ints = ctx.INT()
        x, y = ints[0].getText(), ints[1].getText()
        self.map.add_elevator(int(x), int(y))

    def enterBlock_info(self, ctx: MapParser.Block_infoContext) -> None:
        time = int(ctx.INT().getText())

        position_1, position_2 = tuple(ctx.node_info__block())
        position_1, position_2 = self._get_position(position_1.INT()), self._get_position(position_2.INT())

        self.map.login_shrink_info(time, Block(position_1, position_2))

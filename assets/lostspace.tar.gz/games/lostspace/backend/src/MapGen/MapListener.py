# Generated from Map.g4 by ANTLR 4.7.1
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .MapParser import MapParser
else:
    from MapParser import MapParser

# This class defines a complete listener for a parse tree produced by MapParser.
class MapListener(ParseTreeListener):

    # Enter a parse tree produced by MapParser#prog.
    def enterProg(self, ctx:MapParser.ProgContext):
        pass

    # Exit a parse tree produced by MapParser#prog.
    def exitProg(self, ctx:MapParser.ProgContext):
        pass


    # Enter a parse tree produced by MapParser#nodes_info.
    def enterNodes_info(self, ctx:MapParser.Nodes_infoContext):
        pass

    # Exit a parse tree produced by MapParser#nodes_info.
    def exitNodes_info(self, ctx:MapParser.Nodes_infoContext):
        pass


    # Enter a parse tree produced by MapParser#edges_info.
    def enterEdges_info(self, ctx:MapParser.Edges_infoContext):
        pass

    # Exit a parse tree produced by MapParser#edges_info.
    def exitEdges_info(self, ctx:MapParser.Edges_infoContext):
        pass


    # Enter a parse tree produced by MapParser#node_info.
    def enterNode_info(self, ctx:MapParser.Node_infoContext):
        pass

    # Exit a parse tree produced by MapParser#node_info.
    def exitNode_info(self, ctx:MapParser.Node_infoContext):
        pass


    # Enter a parse tree produced by MapParser#bind_edge.
    def enterBind_edge(self, ctx:MapParser.Bind_edgeContext):
        pass

    # Exit a parse tree produced by MapParser#bind_edge.
    def exitBind_edge(self, ctx:MapParser.Bind_edgeContext):
        pass


    # Enter a parse tree produced by MapParser#edge_info.
    def enterEdge_info(self, ctx:MapParser.Edge_infoContext):
        pass

    # Exit a parse tree produced by MapParser#edge_info.
    def exitEdge_info(self, ctx:MapParser.Edge_infoContext):
        pass


    # Enter a parse tree produced by MapParser#edge_door.
    def enterEdge_door(self, ctx:MapParser.Edge_doorContext):
        pass

    # Exit a parse tree produced by MapParser#edge_door.
    def exitEdge_door(self, ctx:MapParser.Edge_doorContext):
        pass


    # Enter a parse tree produced by MapParser#node_info__edge_1.
    def enterNode_info__edge_1(self, ctx:MapParser.Node_info__edge_1Context):
        pass

    # Exit a parse tree produced by MapParser#node_info__edge_1.
    def exitNode_info__edge_1(self, ctx:MapParser.Node_info__edge_1Context):
        pass


    # Enter a parse tree produced by MapParser#node_info__edge_2.
    def enterNode_info__edge_2(self, ctx:MapParser.Node_info__edge_2Context):
        pass

    # Exit a parse tree produced by MapParser#node_info__edge_2.
    def exitNode_info__edge_2(self, ctx:MapParser.Node_info__edge_2Context):
        pass


    # Enter a parse tree produced by MapParser#materials_info.
    def enterMaterials_info(self, ctx:MapParser.Materials_infoContext):
        pass

    # Exit a parse tree produced by MapParser#materials_info.
    def exitMaterials_info(self, ctx:MapParser.Materials_infoContext):
        pass


    # Enter a parse tree produced by MapParser#material_info.
    def enterMaterial_info(self, ctx:MapParser.Material_infoContext):
        pass

    # Exit a parse tree produced by MapParser#material_info.
    def exitMaterial_info(self, ctx:MapParser.Material_infoContext):
        pass


    # Enter a parse tree produced by MapParser#hmaterials_info.
    def enterHmaterials_info(self, ctx:MapParser.Hmaterials_infoContext):
        pass

    # Exit a parse tree produced by MapParser#hmaterials_info.
    def exitHmaterials_info(self, ctx:MapParser.Hmaterials_infoContext):
        pass


    # Enter a parse tree produced by MapParser#hmaterial_info.
    def enterHmaterial_info(self, ctx:MapParser.Hmaterial_infoContext):
        pass

    # Exit a parse tree produced by MapParser#hmaterial_info.
    def exitHmaterial_info(self, ctx:MapParser.Hmaterial_infoContext):
        pass


    # Enter a parse tree produced by MapParser#doors_info.
    def enterDoors_info(self, ctx:MapParser.Doors_infoContext):
        pass

    # Exit a parse tree produced by MapParser#doors_info.
    def exitDoors_info(self, ctx:MapParser.Doors_infoContext):
        pass


    # Enter a parse tree produced by MapParser#door_info.
    def enterDoor_info(self, ctx:MapParser.Door_infoContext):
        pass

    # Exit a parse tree produced by MapParser#door_info.
    def exitDoor_info(self, ctx:MapParser.Door_infoContext):
        pass


    # Enter a parse tree produced by MapParser#elevators_info.
    def enterElevators_info(self, ctx:MapParser.Elevators_infoContext):
        pass

    # Exit a parse tree produced by MapParser#elevators_info.
    def exitElevators_info(self, ctx:MapParser.Elevators_infoContext):
        pass


    # Enter a parse tree produced by MapParser#elevator_info.
    def enterElevator_info(self, ctx:MapParser.Elevator_infoContext):
        pass

    # Exit a parse tree produced by MapParser#elevator_info.
    def exitElevator_info(self, ctx:MapParser.Elevator_infoContext):
        pass


    # Enter a parse tree produced by MapParser#blocks_info.
    def enterBlocks_info(self, ctx:MapParser.Blocks_infoContext):
        pass

    # Exit a parse tree produced by MapParser#blocks_info.
    def exitBlocks_info(self, ctx:MapParser.Blocks_infoContext):
        pass


    # Enter a parse tree produced by MapParser#block_info.
    def enterBlock_info(self, ctx:MapParser.Block_infoContext):
        pass

    # Exit a parse tree produced by MapParser#block_info.
    def exitBlock_info(self, ctx:MapParser.Block_infoContext):
        pass


    # Enter a parse tree produced by MapParser#node_info__block.
    def enterNode_info__block(self, ctx:MapParser.Node_info__blockContext):
        pass

    # Exit a parse tree produced by MapParser#node_info__block.
    def exitNode_info__block(self, ctx:MapParser.Node_info__blockContext):
        pass



# LostSpace C++ submission interface

- Build the complete package with `make`; the executable is `main` and requires C++17.
- Keep `main.cpp`, `lostspace_client.*`, `Makefile`, and `jsoncpp/` together.
- Implement `std::vector<Json::Value> strategy(const Json::Value &state)`. Each action is
  `lostspace::action(...)`; every turn must end with `lostspace::finish()`.
- The client handles the four-digit ASCII input frame, signed four-byte big-endian output frame,
  player identity, off-round messages, and action responses. Standard output is protocol-only.

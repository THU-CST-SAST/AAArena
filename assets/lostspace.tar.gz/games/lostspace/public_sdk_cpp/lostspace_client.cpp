#include "lostspace_client.hpp"

#include <array>
#include <cstdint>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

namespace lostspace {
namespace {

bool read_exact(char *destination, std::size_t size) {
    std::cin.read(destination, static_cast<std::streamsize>(size));
    return static_cast<std::size_t>(std::cin.gcount()) == size;
}

bool read_message(Json::Value &message) {
    std::array<char, 4> header{};
    if (!read_exact(header.data(), header.size())) {
        return false;
    }
    for (char value : header) {
        if (value < '0' || value > '9') {
            throw std::runtime_error("LostSpace input header is not four ASCII digits");
        }
    }
    const std::size_t size = static_cast<std::size_t>(std::stoul(std::string(header.data(), 4)));
    std::string body(size, '\0');
    if (!read_exact(body.data(), body.size())) {
        throw std::runtime_error("LostSpace input frame ended early");
    }
    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    std::string errors;
    if (!reader->parse(body.data(), body.data() + body.size(), &message, &errors)) {
        throw std::runtime_error("LostSpace input JSON is invalid: " + errors);
    }
    return true;
}

void send_message(const Json::Value &message) {
    Json::StreamWriterBuilder builder;
    builder["indentation"] = "";
    const std::string body = Json::writeString(builder, message);
    if (body.size() > static_cast<std::size_t>(INT32_MAX)) {
        throw std::runtime_error("LostSpace output frame is too large");
    }
    const std::uint32_t size = static_cast<std::uint32_t>(body.size());
    const std::array<char, 4> header = {
        static_cast<char>((size >> 24) & 0xff),
        static_cast<char>((size >> 16) & 0xff),
        static_cast<char>((size >> 8) & 0xff),
        static_cast<char>(size & 0xff),
    };
    std::cout.write(header.data(), static_cast<std::streamsize>(header.size()));
    std::cout.write(body.data(), static_cast<std::streamsize>(body.size()));
    std::cout.flush();
}

void read_action_response() {
    Json::Value response;
    while (read_message(response)) {
        const std::string type = response.get("type", "").asString();
        if (type == "action" || type == "format error" || type == "ai_error") {
            return;
        }
    }
}

}  // namespace

Json::Value finish() {
    Json::Value message;
    message["type"] = "finish";
    return message;
}

Json::Value action(const Json::Value &arguments) {
    Json::Value message;
    message["type"] = "action";
    message["action"] = arguments;
    return message;
}

int run(const Strategy &strategy) {
    int player_id = -1;
    Json::Value message;
    while (read_message(message)) {
        const std::string type = message.get("type", "").asString();
        if (type == "id") {
            player_id = message["id"].asInt();
            continue;
        }
        if (type == "escaped" || type == "ai_error") {
            return 0;
        }
        if (type != "roundbegin" || message.get("inturn", -1).asInt() != player_id) {
            continue;
        }
        const std::vector<Json::Value> actions = strategy(message);
        if (actions.empty() || actions.back().get("type", "").asString() != "finish") {
            throw std::runtime_error("LostSpace strategy must end every turn with finish()");
        }
        for (const Json::Value &operation : actions) {
            send_message(operation);
            if (operation.get("type", "").asString() != "finish") {
                read_action_response();
            }
        }
    }
    return 0;
}

}  // namespace lostspace

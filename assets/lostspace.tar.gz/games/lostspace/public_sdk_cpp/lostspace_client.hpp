#pragma once

#include <functional>
#include <vector>

#include "json/json.h"

namespace lostspace {

using Strategy = std::function<std::vector<Json::Value>(const Json::Value &state)>;

Json::Value finish();
Json::Value action(const Json::Value &arguments);
int run(const Strategy &strategy);

}  // namespace lostspace

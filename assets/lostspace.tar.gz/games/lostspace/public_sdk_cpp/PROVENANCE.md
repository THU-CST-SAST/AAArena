# LostSpace recovered jsoncpp SDK

The `jsoncpp/` tree is a byte-for-byte copy from
`games/lostspace/players/pool/Steaunk__ent_8be6b8e4550b0b7f__v1/jsoncpp`.
All three files were identical in 98 audited player packages. The canonical
tree SHA-256 is
`81dc2bb60521b5dbeeac456b2844784aed1398e5d3f0449efd67bdd9bd2d93ba`.

The selection was audited on 2026-08-31. Player packages remain immutable.

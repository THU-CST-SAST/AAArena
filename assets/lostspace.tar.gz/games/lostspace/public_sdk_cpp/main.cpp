#include "lostspace_client.hpp"

#include <vector>

std::vector<Json::Value> strategy(const Json::Value &state) {
    (void)state;
    // Legal no-op starter. Replace this callback and keep finish() last.
    return {lostspace::finish()};
}

int main() {
    return lostspace::run(strategy);
}

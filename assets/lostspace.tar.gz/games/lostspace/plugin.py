"""LostSpace（失落深空 / 25 届）游戏插件声明 —— 被框架 Core 的注册表发现。

框架通过本文件顶层的 `PLUGIN` 发现 lostspace，无需修改框架源码。

可运行对战器落在同级 `evaluator/`：定位本 GamePack 的官方 Python 后端
`backend/`，隔离引导其依赖
（antlr4 运行时 + typing.io shim），按 Saiblo judge 协议（四人异步双向泵）驱动它与
统一选手池 `games/lostspace/players/pool/` 的四名选手对战，从终局名次分裁决后返回
契约要求的 `EvaluateResult`。
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from aa_arena.core import Evaluator, GamePlugin


def _load_evaluator_module():
    evaluator_dir = Path(__file__).resolve().parent / "evaluator"
    package_name = "aa_arena_games_lostspace_evaluator"
    spec = importlib.util.spec_from_file_location(
        package_name,
        evaluator_dir / "__init__.py",
        submodule_search_locations=[str(evaluator_dir)],
    )
    if spec is None or spec.loader is None:  # pragma: no cover - defensive
        raise ImportError(f"cannot load lostspace evaluator from {evaluator_dir}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)
    return module


def _make_evaluator(game_dir: Path) -> Evaluator:
    module = _load_evaluator_module()
    return module.make_evaluator(game_dir)


PLUGIN = GamePlugin(
    name="lostspace",
    evaluator_factory=_make_evaluator,
    display_name="LostSpace / 失落深空",
    roles=("P0", "P1", "P2", "P3"),
    roles_symmetric=True,
)

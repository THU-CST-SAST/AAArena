import json

def load_json(path):
    with open(path,"r") as fin:
        js = json.load(fin)
    return js

def dump_json(path, js):
    with open(path,"w") as fout:
        json.dump(js, fout)
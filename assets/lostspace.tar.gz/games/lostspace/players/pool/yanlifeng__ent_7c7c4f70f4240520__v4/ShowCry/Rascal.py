import enum
import sys
import json
import copy
from enum import Enum
from showcry_sdk import AIClient


class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        self.my_pos = [-1,-1,-1]
        self.distance_dict = {}
        self.next_dict = {}
        self.strength_list = [0 for _ in range(4)] # arrange by playerid
        self.mat_willing = {}
        self.escaping=False
        self.at_escape_pos = False

    def play(self):
        my_pos = self.get_my_pos()
        self.my_pos = my_pos
        my_id = self.get_my_num()
        at_escape_pos = False
        if my_pos[0]!=3 or my_pos[1]!=3 or my_pos[2]!=0:
            self.escaping=False
        else:
            at_escape_pos = True
        if self.escaping:
            return
        self.print_line("round %d player %d"%(self.state,self.get_my_num()))
        self.print_line("my pos: "+str(my_pos))
        # get strength
        self.strength_list[self.get_my_num()] = self.player.tools.transport

        all_players = [self.player] + self.others
        player_q = 0
        all_distance_dict = []
        all_next_dict = []
        for i, player in enumerate(all_players):
            blocks = []
            for j, other in enumerate(all_players):
                if j==i:continue
                other_pos = other.pos
                if other_pos[0]!=-1:
                    blocks.append(other_pos)
                    other_neighbors = self.get_neighbors(other_pos)
                    for p in other_neighbors:
                        blocks.append(p)
            if player.pos[0]==-1:
                distance_dict = {}
                next_dict = {}
            else:
                distance_dict, next_dict = self.get_distance_dict(blocks, pos=player.pos)
            # self.print_line("distance dict %d"%i)
            # self.print_line(distance_dict)
            all_distance_dict.append(distance_dict)
            all_next_dict.append(next_dict)
            if player.id==my_id:
                self.distance_dict = distance_dict
                self.next_dict = next_dict
        self.all_distance_dict = all_distance_dict
        self.all_next_dict = all_next_dict

        # get_resource_willing
        self.mat_willing = {}
        for i, other in enumerate(all_players):
            remaining_willing = 100
            if i==my_id:continue
            distance_dict = all_distance_dict[i]
            mat_poses = self.get_neark_mat_poses(i, neark=3)
            for mat_pos in mat_poses:
                self.print_line(str(i)+" mat_pos:"+str(mat_pos))
                mat_pos_key = self.lt2key(mat_pos)
                mat_advantages = []
                for j, player in enumerate(all_players):
                    if j==i:continue
                    # self.print_line("dis i")
                    # self.print_line(all_distance_dict[i].get(mat_pos_key,99))
                    # self.print_line("dis j")
                    # self.print_line(all_distance_dict[j].get(mat_pos_key,99))
                    mat_advantage = all_distance_dict[j].get(mat_pos_key,99) - all_distance_dict[i].get(mat_pos_key,99) +\
                        (self.strength_list[i]>=1) - (self.strength_list[j]>=1)
                    mat_advantages.append(mat_advantage)
                # self.print_line(mat_advantages)
                min_adv = min(mat_advantages)
                if not mat_pos_key in self.mat_willing:
                    self.mat_willing[mat_pos_key]=0.0
                # self.print_line("adv_info %d %s"%(i,str(player.pos)))
                # self.print_line(mat_advantages)
                if min_adv>=2:
                    self.mat_willing[mat_pos_key]+=remaining_willing*0.8
                    remaining_willing*=0.0
                elif min_adv<=-2:
                    self.mat_willing[mat_pos_key]+=remaining_willing*0.1
                    remaining_willing*=0.9
                else:
                    self.mat_willing[mat_pos_key]+=remaining_willing*0.5
                    remaining_willing*=0.5
        self.print_line(self.mat_willing)

        # select a target mat
        mat_target = None
        max_score = -1e8
        mat_poses = self.get_neark_mat_poses(my_id, neark=3)
        
        # # mat_score = 100 - mat_willing - 10 * distance
        # self.print_line(self.distance_dict)
        for mat_pos in mat_poses:
            pos_key = self.lt2key(mat_pos)
            pos_willing = self.mat_willing.get(pos_key, 0)
            if pos_willing>120:continue
            pos_score = 100 - pos_willing - 10 * self.distance_dict.get(pos_key,99)
            if pos_score>max_score:
                mat_target = self.key2lt(pos_key)
                max_score = pos_score
        self.print_line("mat_target:"+str(mat_target))

        if at_escape_pos:
            if self.interact("EscapeCapsule",1)["success"]:
                self.escaping=True
                return
        if mat_target is None: # 先不写所有目标都不能去的情况。
            return 
        self.make_move_pos(mat_target) # to implement
        return 
    
    def get_neark_mat_poses(self, pid, neark=3):
        mat_poses = copy.deepcopy(self.map.material_poses)
        # mat_poses = [pos for pos in mat_poses if not self.valid_material[self.lt2key(pos)]]
        mat_poses = sorted(mat_poses, key=lambda x:self.all_distance_dict[pid].get(self.lt2key(x),99))
        mat_poses = mat_poses[:neark]
        return mat_poses

    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        pos_key = self.lt2key(src_pos)
        dis_dict[pos_key] = 0
        lopen = [src_pos]
        q = 0
        while q<len(lopen):
            # self.print_line('bfs in %d'%q)
            now_pos = lopen[q]
            now_pos_key = self.lt2key(now_pos)
            d = dis_dict[now_pos_key]
            neighbors = self.get_neighbors(now_pos)
            # self.print_line(now_pos)
            # self.print_line('neighbors')
            # self.print_line(neighbors)
            for p in neighbors:
                p_key = self.lt2key(p)
                # self.print_line(p_key)
                if p_key in dis_dict:continue
                if p in blocks:continue
                if now_pos_key in next_dict:
                    next_dict[p_key] = next_dict[now_pos_key]
                else:
                    next_dict[p_key] = p
                dis_dict[p_key] = d+1
                lopen.append(p)
            # self.print_line(lopen)
            q+=1
            # self.print_line(q)
        return dis_dict, next_dict
    
    def lt2key(self, lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
    def key2lt(self, key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)

    def make_move_pos(self,pos):
        next_p = self.next_dict.get(self.lt2key(pos),None)
        if not next_p is None:
            self.move(next_p)
        return 

    def make_move(self):
        # 区域类型，0为普通区域，1为物资点, 2为密钥机，3为电梯，4为逃生舱
        max_value = -1e8
        next_p = None
        
        has_key_list = []
        keys = list(self.get_keys())
        for i in range(4):
            if i in keys:
                pos = self.get_spawn_pos(i)
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
                pos = (pos[0], pos[1], pos[2] - 1) # x,y,z
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
        
        for z in range(3):
            for x in range(7):
                for y in range(7):
                    pos = (x,y,z)
                    pos_key = self.lt2key(pos)
                    step = self.distance_dict.get(pos_key, 99)
                    if step<=0: continue
                    step_base = 1.0/float(step)
                    
                    value_base = 0.0
                    if self.map.type[z,y,x]==1:
                        value_base = 0.0
                    if self.map.type[z,y,x]==2 and (not pos_key in has_key_list):
                        value_base = 5.0
                    if self.map.type[z,y,x]==4:
                        if len(self.get_keys())==4:
                            value_base = 10.0
                    value = value_base * step_base
                    if value>max_value and (pos_key in self.next_dict):
                        max_value = value
                        next_p = self.next_dict[pos_key]
        if not next_p is None:
            self.move(next_p)
        return None

if __name__=="__main__":
    c = MyClient()
    c.run()
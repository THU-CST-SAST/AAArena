import numpy as np
import enum
import sys
import json
import copy
from enum import Enum
from showcry_sdk import AIClient

class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        self.my_pos = [-1,-1,-1]
        self.distance_dict = {}
        self.next_dict = {}
        self.strength_list = [0 for _ in range(4)] # arrange by playerid
        self.mat_willing = {}
        self.mat_num = {}
        self.mat_cd = {}
        self.init_mat()
        self.escaping=False
        self.at_escape_pos = False
        self.last_all_players = [None, None, None, None]
        self.all_players = [None, None, None, None]
        self.last_attack_flags = [False,False,False,False]
        self.anticipate_pos  = [[0,0,1],[0,0,1],[0,0,1],[0,0,1]]
        self.mat_poses_valid_keys = []

    def play(self):
        ## initialization
        self.my_pos = self.get_my_pos()
        my_pos = self.my_pos
        self.my_id = self.get_my_num()
        my_id = self.my_id
        at_escape_pos = False
        if my_pos[0]!=3 or my_pos[1]!=3 or my_pos[2]!=0:
            self.escaping=False
        else:
            at_escape_pos = True
        if self.escaping:
            return
        self.print_line("round %d player %d"%(self.state,self.get_my_num()))
        self.print_line("my pos: "+str(my_pos))
        # get strength
        self.strength_list[self.get_my_num()] = self.player.tools.transport
        
        # update all players
        self.last_all_players = copy.deepcopy(self.all_players)
        self.all_players[self.player.id] = self.player
        for other in self.others:
            self.all_players[other.id] = other
        
        # forward mat_state
        if self.state>1:
            self.forward_mat()

        all_players = self.all_players
        player_q = 0
        all_distance_dict = []
        all_next_dict = []
        for i, player in enumerate(all_players):
            blocks = []
            for j, other in enumerate(all_players):
                if j==i:continue
                other_pos = other.pos
                if other_pos[0]!=-1:
                    blocks.append(other_pos)
                    if self.player.hp<=140 or self.strength_list[j]>0:
                        other_neighbors = self.get_neighbors(other_pos)
                        for p in other_neighbors:
                            blocks.append(p)
            if player.pos[0]==-1:
                distance_dict = {}
                next_dict = {}
            else:
                distance_dict, next_dict = self.get_distance_dict(blocks, pos=player.pos)
            # self.print_line("distance dict %d"%i)
            # self.print_line(distance_dict)
            all_distance_dict.append(distance_dict)
            all_next_dict.append(next_dict)
            if player.id==my_id:
                self.distance_dict = distance_dict
                self.next_dict = next_dict
        self.all_distance_dict = all_distance_dict
        self.all_next_dict = all_next_dict
        
        # update self valid mat_poses (need all_distance_dict)
        self.mat_poses_valid_keys = self.get_mat_poses_valid_keys()
        
        # watch other players keys
        for i, player in enumerate(self.all_players):
            self.print_line('now_keys:'+str(i)+' '+str(player.keys))
        # update players anticipate keymachine
        # 有视野则更新， 若无视野则判断是否有钥匙更新。
        for i, other in enumerate(self.all_players):
            if i == self.my_id:continue
            if other is None or self.last_all_players[i] is None:continue
            get_key_pos = [-1,-1,-1]
            if other.pos[0]==-1:
                if len(other.keys)==4:
                    self.anticipate_pos[i] = [3,3,0]
                if len(other.keys)>len(self.last_all_players[i].keys):
                    last_key = self.last_key_get[i]
                    pos = self.get_spawn_pos(last_key)
                    get_key_poses = []
                    if self.player.pos[2]!=1:
                        get_key_poses.append(pos)
                    if self.player.pos[2]!=2:
                        get_key_poses.append([pos[0],pos[1],pos[2]+1])
                    if len(get_key_poses)==1:
                        get_key_pos = get_key_poses[0]
                    elif np.random.rand()<0.5:
                        get_key_pos = get_key_poses[0]
                    else:
                        get_key_pos = get_key_poses[1]
            else:
                get_key_pos = other.pos
            
            if get_key_pos[0]!=-1:
                get_key_distance_dict, _ = self.get_distance_dict(pos=get_key_pos)
                next_poses = []
                for j in range(4):
                    if not j in other.keys:
                        j_spawn_pos = self.get_spawn_pos(j)
                        next_poses.append(j_spawn_pos)
                        next_poses.append([j_spawn_pos[0],j_spawn_pos[1],j_spawn_pos[2]])
                if len(next_poses)==0:
                    self.anticipate_pos[i]=[3,3,0]
                else:
                    min_pos = min(next_poses,key=lambda x:get_key_distance_dict[self.lt2key(x)])
                    self.anticipate_pos[i] = min_pos
        # self.print_line("anticipate")
        # self.print_line(self.anticipate_pos)
        ## main decision
        self.print_line("watch_strength:"+str(self.strength_list))
        acted = False
        # act attack
        atk_rng = 1 + (self.strength_list[my_id]>0)
        for i in range(4):
            if i==my_id:continue
            atk_flag = False
            other = self.all_players[i]
            other_pos = other.pos
            if other_pos[0]==-1:continue
            other_pos_key = self.lt2key(other_pos)
            to_other_dis = self.distance_dict[other_pos_key]

            my_def_round = np.ceil(float(self.player.hp)/70.0)
            other_def_round = np.ceil(float(other.hp)/70.0)
            valid_atk_flag = my_def_round>=other_def_round
            if to_other_dis<=atk_rng and valid_atk_flag:
                atk_flag=True
                if to_other_dis <=1:
                    self.attack(other_pos, i)
                else:
                    blink_pos = self.next_dict[other_pos_key]
                    self.blink_attack(blink_pos, other_pos, i)
                acted = True
                self.print_line("attacked")

        # view box
        if acted:return
        my_pos_key = self.lt2key(my_pos)
        if my_pos_key in self.mat_poses_valid_keys and self.mat_num[my_pos_key]>0:
            full_bag = self.get_tools()
            if not full_bag:
                self.mat_num[my_pos_key]-=1
                acted=True
                self.print_line("view_boxed")

        # move to mat
        if acted:return
        # 这里改成如果资源不够优先资源，如果资源已够则预判第一名的走位并且挡在它将要去的路上。 （找到他下一个最短路的钥匙点）
        # 不用写太细，就闪现够两个直接找茬，不够就找资源。
        offensive_flag = False
        if self.player.tools.transport>=2:
           offensive_flag = True 

        mat_target = None
        if offensive_flag:
            others_id  = [i for i in range(4) if i!=self.my_id]
            atk_target = max(others_id,key=lambda x:len(self.all_players[x].keys))
            # self.print_line("atk_target %d"%atk_target)
            atk_pos = self.all_players[atk_target].pos
            if atk_pos[0]==-1:
                atk_pos = self.anticipate_pos[atk_target]
            mat_target = atk_pos
        else:
            mat_poses = self.get_neark_mat_poses(my_id, neark=3,use_valid=True)
            self.print_line("mat_poses:"+str(mat_poses))
            # select a target mat        
            for mat_pos in mat_poses:
                self.print_line(str(my_id)+" mat_pos:"+str(mat_pos))
                mat_pos_key = self.lt2key(mat_pos)
                mat_advantages = []
                for j, player in enumerate(all_players):
                    if j==my_id:continue
                    # self.print_line(all_distance_dict[j])
                    mat_advantage = all_distance_dict[j].get(mat_pos_key,99) - all_distance_dict[my_id].get(mat_pos_key,99) +\
                        (self.strength_list[my_id]>=1) - (self.strength_list[j]>=1)
                    mat_advantages.append(mat_advantage)
                min_adv = min(mat_advantages)
                # self.print_line(str(mat_pos)+" %d"%min_adv)
                if min_adv>=2:
                    mat_target = mat_pos
                    break
                if min_adv>=-1 and mat_target is None:
                    mat_target = mat_pos
                
        self.print_line("mat_target:"+str(mat_target))

        if at_escape_pos:
            if self.interact("EscapeCapsule",1)["success"]:
                self.escaping=True
                return
        if mat_target is None: # 先不写所有目标都不能去的情况。
            return 
        self.make_move_pos(mat_target) # to implement
        return 
    
    def get_mat_poses_valid_keys(self):
        keys = []
        mat_poses = copy.deepcopy(self.map.material_poses)
        for mat_pos in mat_poses:
            pos_key = self.lt2key(mat_pos)
            flag = True
            for i, player in enumerate(self.all_players):
                if i==self.my_id:continue
                atk_dis = 1+ (self.strength_list[i]>=1)
                if self.all_distance_dict[i].get(pos_key,99)<=atk_dis:
                    self.print_line("valid_info")
                    self.print_line(str(i)+' '+str(self.all_distance_dict[i][pos_key]))
                    self.print_line(pos_key)
                    self.print_line(atk_dis)
                    flag=False
                    break
            if flag:
                keys.append(pos_key)
        self.print_line("validkeys:"+str(keys))
        return keys
    
    def get_neark_mat_poses(self, pid, neark=3,use_valid=True):
        mat_poses = copy.deepcopy(self.map.material_poses)
        self.print_line(self.mat_poses_valid_keys)
        if use_valid:
            l = len(mat_poses)
            mat_poses = [mat_poses[i] for i in range(l) if self.lt2key(mat_poses[i]) in self.mat_poses_valid_keys]
        self.print_line("mat_poses_after_valid:"+str(mat_poses))
        mat_poses = [pos for pos in mat_poses if self.mat_num[self.lt2key(pos)]>=1]
        mat_poses = sorted(mat_poses, key=lambda x:self.all_distance_dict[pid].get(self.lt2key(x),99))
        mat_poses = mat_poses[:neark]
        return mat_poses

    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        pos_key = self.lt2key(src_pos)
        dis_dict[pos_key] = 0
        lopen = [src_pos]
        q = 0
        while q<len(lopen):
            now_pos = lopen[q]
            now_pos_key = self.lt2key(now_pos)
            d = dis_dict[now_pos_key]
            neighbors = self.get_neighbors(now_pos)
            for p in neighbors:
                p_key = self.lt2key(p)
                if p_key in dis_dict:continue
                if p in blocks:continue
                if now_pos_key in next_dict:
                    next_dict[p_key] = next_dict[now_pos_key]
                else:
                    next_dict[p_key] = p
                dis_dict[p_key] = d+1
                lopen.append(p)
            q+=1

        for x in range(7):
            for y in range(7):
                for z in range(3):
                    vpos = [x,y,z]
                    vpos_key = self.lt2key(vpos)
                    if not vpos_key in dis_dict:
                        dis_dict[vpos_key]=99
                        next_dict[vpos_key] = src_pos
        return dis_dict, next_dict
    
    def lt2key(self, lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
    def key2lt(self, key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)

    def make_move_pos(self,pos):
        move_dict, move_next_dict = self.get_distance_dict(pos=self.player.pos) # 不带block的move
        next_p = move_next_dict.get(self.lt2key(pos),None)
        if not next_p is None:
            self.move(next_p)
        return 

    def init_mat(self):
        for pos in self.map.material_poses:
            pos_key = self.lt2key(pos)
            self.mat_num[pos_key] = 2
            self.mat_cd[pos_key] = 8
    
    def forward_mat(self):
        # watch other player pick
        for i in range(4):
            if i==self.my_id:continue
            pos = self.all_players[i].pos
            last_pos = self.last_all_players[i].pos
            if pos!=last_pos or pos[0]==-1:continue
            # self.print_line('lastpossame:'+str(i)+' '+str(pos)+str(last_pos)+' '+str(pos!=last_pos))
            if not pos in self.map.material_poses:continue
            # self.print_line(str(pos)+' in '+str(self.map.material_poses))
            if self.last_attack_flags[i]:continue
            pos_key = self.lt2key(pos)
            if self.mat_num[pos_key]<1:continue
            self.strength_list[i]=min(2,self.strength_list[i]+1)
            self.mat_num[pos_key]-=1

        for pos in self.map.material_poses:
            pos_key = self.lt2key(pos)
            if self.mat_num[pos_key]<2:
                self.mat_cd[pos_key]-=1
                if self.mat_cd[pos_key]<=0:
                    self.mat_cd[pos_key] = 8
                    self.mat_num[pos_key] += 1

    def blink_attack(self, blink_pos, pos, player_id):
        self.use_tool("Transport",blink_pos)
        self.attack(pos, player_id)

    def get_tools(self):
        if self.player.tools.transport<2:
            self.view_box("Materials", "Transport")
        elif self.player.hp<200 and self.player.tools.kit<2:
            self.view_box("Materials","Kit")
        elif self.player.tools.landmine_number[0]<3:
            self.view_box("Materials","LandMine")
        elif self.player.tools.sticky_number[0]<3:
            self.view_box("Materials","Sticky")
        elif self.player.tools.kit<2:
            self.view_box("Materials","Kit")
        else:
            return True # full bag
        return False


if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
import numpy as np
import enum
import sys
import json
import copy
from enum import Enum
from showcry_sdk import *

class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        # public ai memory
        self.my_pos = [-1,-1,-1]
        self.distance_dict = {}
        self.next_dict = {}
        self.no_block_distance_dict = {}
        self.no_block_next_dict = {}
        self.strength_list = [0 for _ in range(4)] # arrange by playerid
        self.mat_num = {}
        self.mat_cd = {}
        self.init_mat()
        self.mat_poses_valid_keys = []
        self.escaping=False
        self.at_escape_pos = False
        self.last_all_players = [None, None, None, None]
        self.all_players = [None, None, None, None]
        self.last_attack_flags = [False,False,False,False]
        
        # unique ai memory

    def play(self):
        import time
        t0 = time.time()
        ## update info
        self.update_info() # public
        my_id = self.my_id
        my_pos = self.my_pos
        self.print_line("round %d ShowCry_v0 player %d"%(self.state,self.get_my_num()))
        self.print_line("my pos: "+str(my_pos))
        self.print_line("box_keys:"+str(self.view.box_keys))
        all_poses = []
        all_hps = []
        for player in self.all_players:
            if player is None:continue
            all_poses.append(player.pos)
            all_hps.append(player.hp)
        self.print_line(all_poses)
        self.print_line(all_hps)
        self.print_line([
            'trans',
            self.player.tools.transport
        ])
        # other update info
        # end other update
        
        ## main decision
        acted = False
        
        # act attack
        dead_status = [player.status for player in self.all_players]
        self.print_line('status:'+str(dead_status))
        atk_rng = 1 + (self.strength_list[my_id]>0)
        total_dmg = 0
        atk_target = None
        atk_hp = 9999
        for i in range(4):
            if i==my_id:continue
            atk_flag = False
            other = self.all_players[i]
            if other.status==1:continue
            other_pos = other.pos
            if other_pos[0]==-1:continue
            other_pos_key = self.lt2key(other_pos)
            to_other_dis = self.no_block_distance_dict[other_pos_key]
            self.print_line(['atkinfo i, to_other_dis',i,to_other_dis])
            if to_other_dis<=atk_rng:
                if other.hp<atk_hp:
                    atk_target = other
                    atk_hp = other.hp
                total_dmg+=70.0
            
        if total_dmg>0:
            dangerous=True
        else:
            dangerous=False
        
        self.print_line("total_dmg "+str(total_dmg))
        self.print_line("dangerous "+str(dangerous))
        
        if not atk_target is None:
            if atk_hp<=70 and self.player.hp>total_dmg-70.0:
                self.atk_func(atk_target)
                acted = True
                self.print_line("last hit attacked")
            else:
                my_def_round = self.get_n_suffer(self.player.hp, total_dmg)
                other_def_round = self.get_n_suffer(atk_target.hp)
                valid_atk_flag = my_def_round>=other_def_round
                if valid_atk_flag:
                    self.atk_func(atk_target)
                    acted = True
                    self.print_line("attacked")

        # try attack invisi
        if acted:return
        if not dangerous:
            neighbors = self.get_neighbors(self.my_pos)
            luankan_poses = [self.my_pos]+[list(p) for p in neighbors]
            # luankan_poses = [[4,2,0],[3,2,0],[2,2,0],[3,3,0],[4,4,0],[3,4,0],[2,4,0]]
            for i in range(4):
                if i==self.my_id:continue
                for pos in luankan_poses:
                    reply = self.attack(pos,i)
                    if reply["success"]:
                        acted=True
                        break
                if acted:
                    break
        self.print_line(time.time()-t0)

        # use kit
        if acted:return 
        if not dangerous:
            if self.player.hp<200 and self.player.tools.kit>=1:
                self.use_tool("Kit")
                acted=True
        
        # get box
        if acted:return
        if not dangerous and self.check_get_box():
            self.interact("Box")
            acted=True
        
        # get key
        if acted:return
        if not dangerous and self.check_get_key():
            self.use_keymachine()
            acted=True
        
        # 如果资源不足按优先（血量<200且无kit or 雷<1 or 闪现<1）
        mat_flag = False
        if self.player.hp<200 and self.player.tools.kit<1:
            mat_flag = True
        elif self.player.tools.landmine_number[0]<1 or \
            self.player.tools.transport<1:
            mat_flag = True
        elif dangerous:
            mat_flag=True
        self.print_line(mat_flag)
        
        # view box
        if acted:return
        my_pos_key = self.lt2key(my_pos)
        # self.print_line(self.mat_poses_valid_keys)
        self.print_line(self.mat_num)
        if not dangerous and my_pos_key in self.mat_poses_valid_keys and self.mat_num[my_pos_key]>0:
            if mat_flag:
                self.get_tools()
                self.mat_num[my_pos_key]-=1
                acted=True
                self.print_line("view_boxed")
        
        # escape
        if not dangerous and self.at_escape_pos:
            if self.interact("EscapeCapsule",1)["success"]:
                self.escaping=True
                return
        
        # move
        if acted:return
        if mat_flag:
            if dangerous:
                mat_target = self.find_mat_target(other_layer=True)
            else:
                mat_target = self.find_mat_target()
            self.print_line("mattarget:"+str(mat_target))
            if mat_target is None:
                return
            self.make_move_pos(mat_target)
        else:
            key_target = self.find_key_target()
            self.print_line("keytarget:"+str(key_target))
            if key_target is None:
                return
            self.make_move_pos(key_target)
        return

    def update_info(self):
        self.map.update_map(self.state)
        self.my_pos = self.get_my_pos()
        my_pos = self.my_pos
        self.my_id = self.get_my_num()
        my_id = self.my_id
        # escaping 怎么写呢？看后面情况。
        if self.pos_equal(my_pos,[3,3,0]):
            self.at_escape_pos = True
        else:
            self.at_escape_pos = False
            self.escaping = False
        #
        self.strength_list[self.get_my_num()] = self.player.tools.transport
        # update all players
        self.last_all_players = copy.deepcopy(self.all_players)
        self.all_players[self.player.id] = copy.deepcopy(self.player)
        for other in self.others:
            self.all_players[other.id] = copy.deepcopy(other)
        
        for i, player in enumerate(self.all_players):
            if player.pos[2]!=my_pos[2]:
                self.all_players[i].pos = [-1,-1,-1]
        # forward mat_state
        if self.state>1:
            self.forward_mat()
        # init distance dict
        all_players = self.all_players
        player_q = 0
        all_distance_dict = []
        all_next_dict = []
        # self.print_line(self.strength_list)
        for i, player in enumerate(all_players):
            blocks = []
            for j, other in enumerate(all_players):
                if j==i:continue
                if other.status==1:continue
                other_pos = other.pos
                if other_pos[0]!=-1:
                    player_n_suffer = self.get_n_suffer(player.hp)
                    other_n_suffer = self.get_n_suffer(other.hp)
                    if player_n_suffer<=other_n_suffer:
                        blocks.append(other_pos)
                        if self.player.hp<=140 or self.strength_list[j]>0:
                            other_neighbors = self.get_neighbors(other_pos)
                            for p in other_neighbors:
                                blocks.append(p)
            distance_dict, next_dict = self.get_distance_dict(blocks, pos=player.pos)
            # self.print_line("distance dict %d"%i)
            # self.print_line(distance_dict)
            all_distance_dict.append(distance_dict)
            all_next_dict.append(next_dict)
            if player.id==my_id:
                self.distance_dict = distance_dict
                self.next_dict = next_dict
                self.no_block_distance_dict, self.no_block_next_dict = self.get_distance_dict(pos=player.pos)
        self.all_distance_dict = all_distance_dict
        self.all_next_dict = all_next_dict
        # update self valid mat_poses (need all_distance_dict)
        self.mat_poses_valid_keys = self.get_mat_poses_valid_keys()

    def get_n_suffer(self,hp,dmg=70.0):
        return int(np.ceil(float(hp)/float(dmg)))        

    def init_mat(self):
        for pos in self.map.material_poses:
            pos_key = self.lt2key(pos)
            self.mat_num[pos_key] = 2
            self.mat_cd[pos_key] = 8

    def forward_mat(self):
        # watch other player pick
        for i in range(4):
            if i==self.my_id:continue
            pos = self.all_players[i].pos
            last_pos = self.last_all_players[i].pos
            if pos==last_pos or pos[0]==-1:continue
            # self.print_line('lastpossame:'+str(i)+' '+str(pos)+str(last_pos)+' '+str(pos!=last_pos))
            if not pos in self.map.material_poses:continue
            # self.print_line(str(pos)+' in '+str(self.map.material_poses))
            if self.last_attack_flags[i]:continue
            pos_key = self.lt2key(pos)
            if self.mat_num[pos_key]<1:continue
            # self.print_line(str(i)+' '+str(pos)+' '+str(last_pos))
            self.strength_list[i]=min(2,self.strength_list[i]+1)
            self.mat_num[pos_key]-=1
    
    def get_mat_poses_valid_keys(self):
        # 不会被攻击到的地方就是valid mat pos
        keys = []
        mat_poses = copy.deepcopy(self.map.material_poses)
        for mat_pos in mat_poses:
            pos_key = self.lt2key(mat_pos)
            flag = True
            for i, player in enumerate(self.all_players):
                if i==self.my_id:continue
                if player.status==1:continue
                atk_dis = 1+ (self.strength_list[i]>=1)
                
                if self.all_distance_dict[i].get(pos_key,99)<=atk_dis:
                    # self.print_line("valid_info")
                    # self.print_line(str(i)+' '+str(self.all_distance_dict[i][pos_key]))
                    # self.print_line(pos_key)
                    # self.print_line(atk_dis)
                    self.print_line(['validinfo',i,player.status,pos_key,self.all_distance_dict[i][pos_key]])
                    flag=False
                    break
            if flag:
                keys.append(pos_key)
        self.print_line("validkeys:"+str(keys))
        return keys

    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        if not src_pos[0]==-1:
            pos_key = self.lt2key(src_pos)
            dis_dict[pos_key] = 0
            lopen = [src_pos]
            q = 0
            while q<len(lopen):
                now_pos = lopen[q]
                now_pos_key = self.lt2key(now_pos)
                d = dis_dict[now_pos_key]
                neighbors = self.get_neighbors(now_pos)
                for p in neighbors:
                    p_key = self.lt2key(p)
                    if p_key in dis_dict:continue
                    if p in blocks:continue
                    if now_pos_key in next_dict:
                        next_dict[p_key] = next_dict[now_pos_key]
                    else:
                        next_dict[p_key] = p
                    dis_dict[p_key] = d+1
                    lopen.append(p)
                q+=1

        for x in range(7):
            for y in range(7):
                for z in range(3):
                    vpos = [x,y,z]
                    vpos_key = self.lt2key(vpos)
                    if not vpos_key in dis_dict:
                        dis_dict[vpos_key]=99
                        next_dict[vpos_key] = src_pos
        return dis_dict, next_dict

    def get_tools(self):
        if self.player.hp<200 and self.player.tools.kit<1:
            self.view_box("Materials","Kit")
        elif self.player.tools.landmine_number[0]<1:
            self.view_box("Materials","LandMine")
        else:
            self.view_box("Materials", "Transport")

    def get_neark_mat_poses(self, pid, neark=3,use_valid=True, other_layer=False):
        mat_poses = copy.deepcopy(self.map.material_poses)
        if other_layer:
            mat_poses = [mat_pos for mat_pos in mat_poses if mat_pos[2]!=self.my_pos[2]]
        # self.print_line(self.mat_poses_valid_keys)
        if use_valid:
            l = len(mat_poses)
            mat_poses = [mat_poses[i] for i in range(l) if self.lt2key(mat_poses[i]) in self.mat_poses_valid_keys]

        # self.print_line("mat_poses_after_valid:"+str(mat_poses))
        mat_poses = [pos for pos in mat_poses if self.mat_num[self.lt2key(pos)]>=1]
        mat_poses = sorted(mat_poses, key=lambda x:self.all_distance_dict[pid].get(self.lt2key(x),99))
        mat_poses = mat_poses[:neark]
        return mat_poses

    def find_mat_target(self, other_layer=False):
        mat_target = None
        my_id = self.my_id
        all_players = self.all_players
        all_distance_dict = self.all_distance_dict
        if self.player.hp>140:
            mat_poses = self.get_neark_mat_poses(my_id, neark=3, use_valid=False, other_layer=other_layer)
        else:
            mat_poses = self.get_neark_mat_poses(my_id, neark=3, use_valid=True, other_layer=other_layer)
        self.print_line("in find mat mat_poses:"+str(mat_poses))
        # select a target mat    
        self.print_line(all_distance_dict)
        for mat_pos in mat_poses:
            mat_pos_key = self.lt2key(mat_pos)
            mat_advantages = []
            for j, player in enumerate(all_players):
                if j==my_id:continue
                # self.print_line(all_distance_dict[j])
                mat_advantage = all_distance_dict[j].get(mat_pos_key,99) - all_distance_dict[my_id].get(mat_pos_key,99) +\
                    (self.strength_list[my_id]>=1) - (self.strength_list[j]>=1)
                mat_advantages.append(mat_advantage)
            self.print_line([mat_pos, mat_advantages])
            min_adv = min(mat_advantages)
            # self.print_line(str(mat_pos)+" "+str(min_adv))
            if min_adv>=2:
                mat_target = mat_pos
                break
            if min_adv>=-1 and mat_target is None:
                mat_target = mat_pos
        return mat_target
    
    def find_key_target(self):
        # key_target = None
        # get_all_key_poses
        all_key_poskeys = []
        keys = list(self.get_keys())
        if len(keys)==4:
            all_key_poskeys.append(self.lt2key([3,3,0]))
        else:
            for i in range(4):
                if not i in keys:
                    pos =  self.get_spawn_pos(i)
                    pos_key = self.lt2key(pos)
                    all_key_poskeys.append(pos_key)
                    pos = (pos[0], pos[1], pos[2] + 1)
                    pos_key = self.lt2key(pos)
                    all_key_poskeys.append(pos_key)
        
        min_poskey = min(all_key_poskeys, key=lambda x:self.distance_dict[x])
        key_target = self.key2lt(min_poskey)
        # key_target = self.next_dict.get(min_poskey,None)
        # self.print_line("all_poses:"+str(all_key_poskeys))
        # self.print_line("keytarget:"+str(key_target))
        return key_target

    def make_move_pos(self,pos):
        move_dict, move_next_dict = self.get_distance_dict(pos=self.player.pos) # 不带block的move
        next_p = move_next_dict.get(self.lt2key(pos),None)
        if not next_p is None:
            self.move(next_p)
        return
    
    def blink_attack(self, blink_pos, pos, player_id):
        self.use_tool("Transport",blink_pos)
        self.attack(pos, player_id)
        
    def atk_func(self, atk_target):
        i = atk_target.id
        move_distance_dict, move_next_dict = self.get_distance_dict(pos=self.player.pos) # 不带block的move
        target_pos = atk_target.pos
        target_pos_key = self.lt2key(target_pos)
        to_other_dis = move_distance_dict[target_pos_key]
        if to_other_dis <=1:
            self.attack(target_pos, i)
        else:
            blink_pos = move_next_dict[target_pos_key]
            self.blink_attack(blink_pos, target_pos, i)
    
    def check_get_box(self):
        my_pos = self.my_pos
        my_keys = list(self.get_keys())
        get_box_flag = False
        my_pos_key = self.lt2key(my_pos)
        if my_pos_key in self.view.box_keys:
            keys = self.view.box_keys[my_pos_key]
            for key in keys:
                if not key in my_keys:
                    get_box_flag = True
        else:
            get_box_flag=False
        return get_box_flag
    
    def check_get_key(self):
        my_pos = self.my_pos
        keys = list(self.get_keys())
        get_key_flag = False
        for i in range(4):
            if i in keys:continue
            pos = self.get_spawn_pos(i)
            if self.pos_equal(my_pos, pos):
                get_key_flag = True
                break
            pos = [pos[0],pos[1],pos[2]+1]
            if self.pos_equal(my_pos, pos):
                get_key_flag = True
                break
        return get_key_flag
    
    def use_keymachine(self):
        self.interact("KeyMachine")
    
    def pos_equal(self, pos0, pos1):
        return (pos0[0]==pos1[0]) and (pos0[1]==pos1[1]) and (pos0[2]==pos1[2])

if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
    
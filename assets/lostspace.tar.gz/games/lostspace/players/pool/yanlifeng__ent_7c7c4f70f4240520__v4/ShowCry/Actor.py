import os
import enum
import sys
import json
import copy
from enum import Enum

from showcry_sdk import AIClient
from qfuncs import *

class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        order_file = "orders.json"
        dirname = os.path.dirname(__file__)
        order_path = os.path.join(dirname, order_file)
        order_js = load_json(order_path)
        self.order_js = order_js
        self.qorder = 0
        
    def play(self):
        self.print_line([self.player.tools.landmine_number, self.player.tools.transport])
        # self.print_line(self.order_js)
        myid = self.get_my_num()
        order_js = self.order_js
        if order_js["format"] == "local":
            all_orders = order_js["orders"]
            all_orders = [order for order in all_orders if order[0]["playerid"]==myid]
            q = self.qorder
            if q>=len(all_orders):
                return
            orders = all_orders[q]
            for order in orders:
                if order["type"]=="move":
                    pos = order["pos"]
                    self.move(pos)
                elif order["type"]=="inspect":
                    interact_type = order["interprops"]
                    if interact_type in ["Transport","Kit","LandMine","Sticky"]:
                        interact = "Materials"
                    else:
                        interact = "KeyMachine"
                    self.view_box(interact, interact_type)
                elif order["type"]=="use_tool":
                    tool_type = order["tool_type"]
                    if tool_type=="Transport":
                        pos = order["pos"]
                        self.use_tool(tool_type,pos)
                    else:
                        self.use_tool(tool_type)
                elif order["type"]=="put_trap":
                    trap_type = order["trap_type"]
                    self.put_trap(trap_type)
                elif order["type"]=="attack":
                    self.attack(order["pos"], order["target"])
                elif order["type"]=="detect":
                    self.detect(order["pos"])
            self.qorder+=1
        return 
    
if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
        
# from KeyFirstAI import MyClient
from ShowCry_v1 import MyClient

if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
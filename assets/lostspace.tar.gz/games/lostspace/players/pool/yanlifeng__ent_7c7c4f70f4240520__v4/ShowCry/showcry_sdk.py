import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["USE_SIMPLE_THREADED_LEVEL3"] = "1"
import copy
import sys
from enum import Enum
import json
import numpy as np

class STATUS(Enum):
    ALIVE = 0
    DEAD = 1
    ESCAPED = 2
    SKIPPED = 3

import random
class Node:
    def __init__(self):
        self.trap = None
        self.drop = [] #掉落物
        self.edges = [] #其中元素为长度为2的数组，第一位为1-8，分别代表从上开始顺时针的八个方向，第二位无意义（本来是门）
        self.able = 1 # 缩圈，1可用，0不可用
        self.type = 0 # 区域类型，0为普通区域，1为物资点, 2为密钥机，3为电梯，4为逃生舱
        pass

class Map():
    def __init__(self, map_info_basename='map_info.npy'):
        dirname = os.path.dirname(__file__)
        self.type = np.load(os.path.join(dirname, "type.npy"))
        self.circle = np.load(os.path.join(dirname, "circle.npy"))
        self.connection = np.load(os.path.join(dirname, "connection.npy")) # 3,7,7,12
        self.forbid_round = np.load(os.path.join(dirname, "forbid_round.npy"))
        self.delta = np.load(os.path.join(dirname, "delta.npy"))
        self.material_poses = []

        for x in range(7):
            for y in range(7):
                for z in range(3):
                    if self.type[z,y,x]==1:
                        self.material_poses.append([x,y,z])
        
        self.key_machine_pos_dict = {
            0:[[0,0,1],[0,0,2]],
            1:[[6,0,1],[6,0,2]],
            2:[[6,6,1],[6,6,2]],
            3:[[0,6,1],[0,6,2]],
        }

    def update_map(self,state):
        len_delta = len(self.delta)
        delta = self.delta
        for z in range(3):
            for y in range(7):
                for x in range(7):
                    for idelta in range(len_delta):
                        if self.connection[z,y,x,idelta]==1:
                            xx = x + delta[idelta][0]
                            yy = y + delta[idelta][1]
                            zz = z + delta[idelta][2]
                            if state>=self.forbid_round[z,y,x] or state>=self.forbid_round[zz,yy,xx]-1:
                                self.connection[z,y,x,idelta]=0

class Tool:  # 工具类,存储工具信息,包括陷阱和医疗包
    def __init__(self) -> None:
        self.landmine_number = [0,0]  # 二元组,分别为未放置地雷个数、放置地雷个数
        self.landmine_pos = []  # 地雷的放置位置
        self.sticky_number = [0,0]
        self.sticky_pos = []
        self.kit = 0  # 医疗包个数
        self.transport = 0  #瞬移个数

class Player:  # 玩家类,存储该玩家的相关信息
    def __init__(self) -> None:
        self.id = -1  # 玩家id
        self.status = STATUS.ALIVE  # 玩家状态
        self.hp = 200  # 玩家血量
        self.keys = []  # 拿到的钥匙
        self.tools = Tool()  # 工具栏
        self.pos = [-1,-1,-1]   #玩家位置
        self.spawn_pos = []     #玩家出生点位置
        self.last_use_check = -5

class View:
    def __init__(self) -> None:
        self.nodes = []     #视野中的点集合
        self.box_keys = {} # 盒子所含钥匙 {pos_key: [keyid0,keyid1 ...]}

class AIClient(object):
    def __init__(self, print_flag=True):
        self.state = -1  # 大回合数
        self.player = Player()  # 玩家信息
        self.others = [Player() for _ in range(3)]  # 其他玩家信息
        self.view = View()  # 玩家视野
        self.map = Map()
        self.root = {}
        self.last_key_get = [
            {'state':0,'key':0},
            {'state':0,'key':1},
            {'state':0,'key':2},
            {'state':0,'key':3}]
        self.print_flag=print_flag
        # to remove in release
        self.log_path = './my_watch.out'
        self.refresh_log = True
        if self.refresh_log and self.print_flag:
            f = open(self.log_path, 'w')
            f.close()

    def print_line(self, text):
        if not self.print_flag:
            return
        out = str(text)
        with open(self.log_path, 'a+') as f:
            f.writelines(out)
            f.writelines('\n')
    
    def lt2key(self, lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
    def key2lt(self, key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)
    
    def receive_data(self):
        read_buffer = sys.stdin.buffer
        data_len = int(str(read_buffer.read(4), encoding = "utf-8"))
        data = read_buffer.read(data_len)
        self.root = json.loads(str(data, "utf-8"))
        self.print_line(self.root)

    def convert_to_bytes(self, data_str):
        """
        传输数据的时候加数据长度作为数据头
        """
        message_len = len(data_str)
        message = message_len.to_bytes(4, byteorder="big", signed=True)
        message += bytes(data_str, encoding="utf-8")
        return message

    def send_opt(self, data):
        """
        发送自己的操作，data为字典
        """
        sys.stdout.buffer.write(self.convert_to_bytes(json.dumps(data)))
        sys.stdout.flush()

    def init_game(self):
        self.player.id = self.root["id"]
        self.player.spawn_pos = self.root["birth_pos"]
        self.player.spawn_pos.append(1)
        self.player.pos = self.player.spawn_pos

    def start_turn(self):
        self.state = self.root["state"]
        if self.root["inturn"] != self.player.id:
            return
        self.player.status = self.root["status"]
        self.player.pos = self.root["pos"]
        self.player.hp = self.root["hp"]
        self.player.keys = self.root["keys"]
        self.player.tools.landmine_number = [
            self.root["tools"]["LandMine"][0],
            self.root["tools"]["LandMine"][1],
        ]
        self.player.tools.landmine_pos = self.root["tools"]["LandMine"][2:]
        self.player.tools.sticky_number = [
            self.root["tools"]["Sticky"][0],
            self.root["tools"]["Sticky"][1],
        ]
        self.player.tools.sticky_pos = self.root["tools"]["Sticky"][2:]
        self.player.tools.kit = self.root["tools"]["Kit"]
        self.player.tools.transport = self.root["tools"]["Transport"]
        self.root["others"].sort(key=lambda player:player["player_id"])
        for index in range(3):
            self.others[index].id = self.root["others"][index]["player_id"]
            self.others[index].status = self.root["others"][index]["status"]
            # self.others[index].pos = self.root["others"][index]["pos"]
            self.others[index].keys = self.root["others"][index]["keys"]
            self.others[index].hp = self.root["others"][index]["hp"]
        # self.print_line(self.player.status)
        if self.player.status != STATUS.ALIVE.value:
            self.end_turn()
            return
        else:
            self.play()         #选手进行操作
            self.end_turn()

    def end_turn(self):
        # self.print_line("sent_time_finish")
        self.send_opt({"type": "finish"})

    def in_turn(self):
        """
        本玩家回合内接收消息的处理
        """
        if self.root["type"] == "other_death":
            index = self.player_id_to_player_index(self.root["playerid"])
            other_pos = self.others[index].pos
            if other_pos[0]!=-1:
                other_pos_key = self.lt2key(other_pos)
                if not other_pos_key in self.view.box_keys:
                    self.view.box_keys[other_pos_key]=[]
                for key in self.others[index].keys:
                    if not key in self.view.box_keys[other_pos_key]:
                        self.view.box_keys[other_pos_key].append(key)
            self.others[index].hp = 0
            self.others[index].status = STATUS.DEAD
        elif self.root["type"] == "getkey":
            key = self.root["key"]
            if key not in self.player.keys:
                self.player.keys.append(key)
        elif self.root["type"] == "escaped":
            self.player.status = STATUS.ESCAPED
        elif self.root["type"] == "death":
            self.player.status = STATUS.DEAD
            self.player.hp = 0
            self.print_line("BOXINFO:"+str(self.root))
            # 这里注释掉是因为很大可能自己盒子被别人捡掉并且由于视野不更新造成bug。
            # 目前不确定judger中他人捡掉盒子自己这边有没有更新。
            # if self.root["box"]:
            #     self.view.boxes.append(self.player.pos)
            self.player.pos = self.player.spawn_pos     #玩家死亡，回到出生点待命
        elif self.root["type"] == "offround":
            if self.root['content'][0]=='see' and self.root['content'][1]=='interprops_status_update':
                if self.root['content'][3]=='Box':
                    if self.root['content'][4]=='disappear':
                        self.print_line('ERROR! 自己回合捡掉box之后系统会发来盒子disappear的更新')
                    pos = self.root['content'][2]
                    pos_key = self.lt2key(pos)
                    if not pos_key in self.view.box_keys:
                        self.view.box_keys[pos_key] = []
                else:
                    self.print_line("unknown inturn offround info:"+str(self.root))
            else:
                self.print_line("unknown inturn offround info:"+str(self.root))
        elif self.root["type"] =='box_disappear':
            dis_pos = self.root['pos']
            dis_pos_key = self.lt2key(dis_pos)
            if dis_pos_key in self.view.box_keys:
                self.view.box_keys.pop(dis_pos_key)

    def off_turn(self):
        """
        本玩家回合外接收消息的处理
        """
        if self.root["content"][0] == "died":
            player_index = self.player_id_to_player_index(self.root["content"][1])
            index = player_index
            other_pos = self.others[index].pos
            if other_pos[0]!=-1:
                other_pos_key = self.lt2key(other_pos)
                if not other_pos_key in self.view.box_keys:
                    self.view.box_keys[other_pos_key]=[]
                for key in self.others[index].keys:
                    if not key in self.view.box_keys[other_pos_key]:
                        self.view.box_keys[other_pos_key].append(key)
            self.others[player_index].hp = 0
            self.others[player_index].status = STATUS.DEAD
        elif self.root["content"][0] == "escaped":
            player_index = self.player_id_to_player_index(self.root["playerid"])
            self.others[player_index].status = STATUS.ESCAPED
        elif self.root["content"][0] == "see":
            if self.root["content"][1] == "pos_update":
                new_pos = self.root["content"][2]
                player_index = self.player_id_to_player_index(self.root["content"][3])
                self.others[player_index].pos = new_pos
            elif self.root["content"][1] == "attack":
                return  #不需要更新信息
            elif self.root["content"][1] == "regenerate":
                player_index = self.player_id_to_player_index(self.root["content"][3])
                self.others[player_index].status == STATUS.ALIVE
            elif self.root["content"][1] == "interprops_status_update":
                if self.root["content"][3] == "Door":
                # 这个Door是啥啊
                    edge_pos = self.root["content"][2]
                    # for index,edge in enumerate(self.view.edges):
                    #     if (edge.stpos == edge_pos[0] and edge.edpos == edge_pos[1]) or (edge.stpos == edge_pos[1] and edge.edpos == edge_pos[0]):
                    #         self.view.edges[index].is_open = True if self.root["content"][4] == "open" else False
                elif self.root["content"][3]=="Box":
                    #这里应该会有视野消失吧？
                    if self.root["content"][4]=='disappear':
                        pos = self.root['content'][2]
                        pos_key = self.lt2key(pos)
                        self.print_line("disappear poskey: "+pos_key)
                        if pos_key in self.view.box_keys:
                            self.view.box_keys.pop(pos_key)
                    # self.print_line("unknown not implemented offround box info:"+str(self.root))
        elif self.root["content"][0] == "getkey":
            # self.print_line("get_key_info:")
            # self.print_line(self.root)
            self.last_key_get[self.root["playerid"]] = copy.deepcopy({'state':self.root['state'], 'key':self.root['content'][1]})
            player_index = self.player_id_to_player_index(self.root["playerid"])
            for key in self.root["content"][1]:
                if key not in self.others[player_index].keys:
                    self.others[player_index].keys.append(key)
        elif self.root["content"][0] == "hp_update":
            self.player.hp = self.root["content"][1]
            # self.print_line("hp:"+str(self.player.hp))
        else:
            return

    def update_view(self, view):
        for i in self.others:
            i.pos = [-1,-1,-1]
        for node in view:
            if (len(node)>=3):
                player_index = self.player_id_to_player_index(node[2])
                self.others[player_index].pos = node[0]
        # self.view.nodes.clear()
        # for i in self.others:
        #     i.pos = [-1,-1,-1]
        # for node in view:
        #     temp_node = Node()
        #     temp_node.pos = node[0]
        #     temp_node.interprops = node[1]
        #     if(len(node) >= 3):
        #         player_index = self.player_id_to_player_index(node[2])
        #         self.others[player_index].pos = node[0]
        #         temp_node.player = node[2]
        #     self.view.nodes.append(temp_node)

    def pos_to_node_index(self, pos):
        for index,node in enumerate(self.view.nodes):
            if node.pos == pos:
                return index
        return -1

    def player_id_to_player_index(self, player_id):
        for index,player in enumerate(self.others):
            if player.id == player_id:
                return index
        return -1

    def get_my_num(self):
        """
        获得自己的编号，返回值为数字
        """
        return self.player.id

    def get_keys(self):
        """
        获得当前拿到的钥匙，返回值为数字列表
        """
        keys = copy.deepcopy(self.player.keys)
        return keys

    def get_check_cd(self):
        """
        获得探查技能的cd，返回值为数字
        """
        return max(self.player.last_use_check + 5 - self.state)
        pass

    def get_neighbors(self, pos):
        neighbors = []
        x,y,z = pos[0],pos[1],pos[2]
        connection = self.map.connection
        delta = self.map.delta
        len_delta = len(delta)
        for i in range(len_delta):
            if connection[z,y,x,i]==1:
                neighbors.append((
                    x+delta[i][0],
                    y+delta[i][1],
                    z+delta[i][2],
                ))
        return neighbors


    def move(self, pos):
        pos = [int(x) for x in pos]
        opt = {"type": "action", "action": ["move", pos]}
        self.send_opt(opt)
        self.print_line("send_move_opt:"+str(opt))
        while True:
            self.receive_data()
            if self.root["type"] != "action":   #不是本次移动消息的回复，属于局内消息
                self.in_turn()
            else:
                if not self.root["success"]:
                    return copy.deepcopy(self.root)
                else:
                    self.player.hp = self.root["hp"]
                    self.player.pos = pos
                    if self.root["view"]:
                        # self.print_line(["viewbug",self.root])
                        self.update_view(self.root["view"])
                    return copy.deepcopy(self.root)
                    

    def attack(self, pos, player_id):
        """
        攻击，pos为节点坐标三元组，player_id为攻击目标
        """
        pos = [int(pos[0]),int(pos[1]),int(pos[2])]
        self.send_opt({"type": "action", "action": ["attack", pos, player_id]})
        # self.print_line("attack opt sent")
        # self.print_line({"type": "action", "action": ["attack", pos, player_id]})
        while True:
            self.receive_data()
            # self.print_line("afterattack:"+str(self.root))
            if self.root["type"] != "action":
                self.in_turn()
            else:
                if self.root["success"]:
                    self.others[self.player_id_to_player_index(player_id)].hp -= 70
                return copy.deepcopy(self.root)

    def interact(self, tool_type, capsule=False):
        """
        与场景道具交互，tool_type为道具类型字符串，若tool_type为逃生舱，则capusule代表开始计时或暂停计时
        返回值参见通讯格式
        """
        if tool_type == "EscapeCapsule":
            opt = {"type": "action", "action":["interact", tool_type, capsule]}
            self.send_opt(opt)
        else:
            opt = {"type": "action", "action": ["interact", tool_type]}
            self.send_opt(opt)
        self.print_line("iteract:"+str(opt))
        while True:
            self.receive_data()
            if self.root["type"] != "action":
                self.in_turn()
            else:
                return copy.deepcopy(self.root)

    def view_box(self, box_type, tool_type):
        """
        检视箱子，box_type为掉落池/物资点字符串，tool_type为具体道具类型，返回值参见通讯格式
        """
        if box_type == "Materials":
            self.send_opt({"type": "action", "action":["interact", box_type, tool_type]})
        else:
            self.send_opt({"type": "action", "action":["interact", box_type]})
        while True:
            self.receive_data()
            if self.root["type"] != "action":
                self.in_turn()
            else:
                return copy.deepcopy(self.root)
                # if not self.root["success"]:
                #     return copy.deepcopy(self.root)
                # else:
                #     if tool_type == "key":
                #         self.player.keys = self.root["keys"]
                #     else:
                #         self.player.tools.landmine_number[0] = self.root["tools"]["LandMine"]
                #         self.player.tools.sticky_number[0] = self.root["tools"]["Sticky"]
                #         self.player.tools.transport = self.root["tools"]["Transport"]
                #         self.player.tools.kit = self.root["tools"]["Kit"]
                #     return copy.deepcopy(self.root)

    def put_trap(self, trap_type):
        """
        放置陷阱，trap_type为陷阱类型字符串
        """
        self.send_opt({"type": "action", "action": ["trap", trap_type]})
        # self.print_line("trap opt sent")
        # self.print_line({"type": "action", "action": ["trap", trap_type]})
        while True:
            self.receive_data()
            # self.print_line("after trap:"+str(self.root))
            if self.root["type"] != "action":
                self.in_turn()
            else:
                if self.root["success"]:
                    if trap_type == "LandMine":
                        self.player.tools.landmine_number[0] -= 1
                        self.player.tools.landmine_number[1] += 1
                        self.player.tools.landmine_pos.append(self.player.pos)
                    elif trap_type == "Sticky":
                        self.player.tools.sticky_number[0] -= 1
                        self.player.tools.sticky_number[1] += 1
                        self.player.tools.sticky_pos.append(self.player.pos)
                return copy.deepcopy(self.root)

    def use_tool(self, tool_type, transport_pos=None):
        """
        使用道具，tool_type为道具类型字符串
        如果使用瞬移，transport_pos是瞬移目的地
        """
        if not transport_pos is None:
            transport_pos = [int(transport_pos[0]),int(transport_pos[1]),int(transport_pos[2])]
        if tool_type == "Transport":
            self.send_opt({"type": "action", "action": ["tool", tool_type, transport_pos]})
        else:
            self.send_opt({"type":"action", "action": ["tool", tool_type]})
        # self.print_line("use_tool opt sent")
        # self.print_line({"type": "action", "action": ["tool", tool_type, transport_pos]})
        while True:
            self.receive_data()
            # self.print_line("after usetool:"+str(self.root))
            if self.root["type"] != "action":
                self.in_turn()
            else:
                if not self.root["success"]:
                    return copy.deepcopy(self.root)
                else:
                    if tool_type == "Kit":
                        self.player.hp = self.root["hp"]
                    elif tool_type == "Transport":
                        self.player.pos = transport_pos
                        self.player.hp = self.root["hp"]
                        if "view" in self.root and (not self.root["view"] is None):
                            self.update_view(self.root["view"])
                    return copy.deepcopy(self.root)


    def detect(self, detect_pos):
        self.send_opt({"type": "action", "action": ["detect", detect_pos]})
        while True:
            self.receive_data()
            # self.print_line("after detect:"+str(self.root))
            if self.root["type"] != "action":
                self.in_turn()
            else:
                if self.root["success"] == True:
                    self.player.last_use_check = self.state
                return copy.deepcopy(self.root)

    def get_spawn_pos(self,x):
        """
        获得出生点位置坐标，返回值为三元组
        """
        if x == 0:
            return[0,0,1]
        elif x == 1:
            return [6,0,1]
        elif x == 2:
            return [6,6,1]
        elif x == 3:
            return [0,6,1]
        

    def get_escape_pos(self):
        """
        获得撤离点位置坐标，返回值为三元组
        """
        return [3,3,0]

    def get_landmine_pos(self):
        """
        获得当前地雷位置坐标，返回值为三元组列表
        """
        landmine_pos = copy.deepcopy(self.player.tools.landmine_pos)
        return landmine_pos

    def get_sticky_pos(self):
        """
        获得当前粘弹位置坐标，返回值为三元组列表
        """
        sticky_pos = copy.deepcopy(self.player.tools.sticky_pos)
        return sticky_pos

    def get_my_pos(self):
        return copy.deepcopy(self.player.pos)

    def get_other_pos(self,player_id):
        player_index = self.player_id_to_player_index(player_id)
        return copy.deepcopy(self.others[player_index].pos)

    def get_my_hp(self):
        return copy.deepcopy(self.player.hp)
    
    def get_other_hp(self):
        player_index = self.player_id_to_player_index(player_id)
        return copy.deepcopy(self.others[player_index].hp)

    def get_n_suffer(self,hp,dmg=70.0):
        return int(np.ceil(float(hp)/float(dmg)))    

    def play(self):
        return

    def run(self):
        while True:
            if self.player.status == STATUS.ESCAPED:
                break
            self.receive_data()
            if self.root["type"] == "id":
                self.init_game()
            elif self.root["type"] == "roundbegin":
                self.start_turn()
            elif self.root["type"] == "offround":
                self.off_turn()
            else:
                self.in_turn()

    

if __name__=='__main__':
    amap = Map()
    print(amap.type)
    print(amap.circle)

# if __name__=="__main__":
#     c = AIClient()
#     c.run()

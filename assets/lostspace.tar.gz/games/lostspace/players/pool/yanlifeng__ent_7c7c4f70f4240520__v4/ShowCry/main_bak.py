import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["USE_SIMPLE_THREADED_LEVEL3"] = "1"

from AIClient import AIClient
from AIClient import Node, Map, Tool, Player

from qfuncs import *

class MyClient(AIClient):
    def __init__(self) -> None:
        # super(MyClient, self).__init__()
        super().__init__()
        self.round = 0
        self.atk_flag = False
        self.distance_dict = {}
        self.next_dict = {}

        # to remove in release
        self.log_path = './my_watch.out'
        self.refresh_log = True
        if self.refresh_log:
            f = open(self.log_path, 'w')
            f.close()
        # end

    def play(self):
        self.print_line(os.path.abspath("./"))
        self.print_line(os.getcwd())
        self.print_line(__file__)
        self.print_line(os.path.dirname(__file__))

        self.round+=1
        self.atk_flag = False
        self.print_line("round %d"%self.round)
        keys_txt = ""
        keys = self.get_keys()
        for key in keys:
            keys_txt += str(key)+' '
        # typetxt = str(type(keys[0]))
        self.print_line(keys_txt)

        pos = self.get_my_pos()
        self.my_pos = pos
        self.print_line(pos)

        neighbor = self.get_neighbors(self.get_my_pos())
        cnt = 0
        atk = -1
        blocks = []
        for i in range(4):
            if i == self.get_my_num():
                continue
            if self.get_my_pos() == self.get_other_pos(i) or self.get_other_pos in neighbor:
                cnt += 1
                atk = i
            other_pos = self.get_other_pos(i)
            if not other_pos[0]==-1:
                blocks.append(other_pos)
                neighbors = self.get_neighbors(other_pos)
                for p in neighbors:
                    blocks.append(p)
        self.print_line("blocks")
        self.print_line(blocks)
        if cnt == 1 and self.player.hp >= self.others[atk].hp:
            self.attack(self.get_other_pos(atk),atk)
            self.atk_flag = True


        if not self.atk_flag and cnt<=0:
            self.distance_dict, self.next_dict = self.get_distance_dict(blocks=blocks)
        else:
            self.distance_dict, self.next_dict = self.get_distance_dict(blocks=[])
        self.print_line(self.distance_dict)
        self.print_line(self.next_dict)

        self.print_line(list(self.root.keys()))
        if self.player.hp < 130:
            self.use_tool("Kit")
        self.print_line(list(self.root.keys()))
        if self.view_box("Box","Key")["success"]:
            return
        self.print_line(list(self.root.keys()))
        view_box_res = self.view_box("Materials","Kit")
        if self.view_box("Materials","Kit")["success"]:
            return
        # self.print_line(list(self.root.keys()))
        if self.interact("KeyMachine")["success"]:
            return
        if self.interact("EscapeCapsule",1)["success"]:
            return
        self.print_line("movegogo")
        # self.test_move()
        self.make_move()
        return None
    
    def print_line(self, text):
        out = str(text)
        # if isinstance(text, list):
        #     out = ''
        #     for item in text:
        #         out+=str(item)+' '
        # else:
        #     out = str(text)
        with open(self.log_path, 'a+') as f:
            f.writelines(out)
            f.writelines('\n')

    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        pos_key = self.lt2key(src_pos)
        dis_dict[pos_key] = 0
        lopen = [src_pos]
        q = 0
        while q<len(lopen):
            # self.print_line('bfs in %d'%q)
            now_pos = lopen[q]
            now_pos_key = self.lt2key(now_pos)
            d = dis_dict[now_pos_key]
            neighbors = self.get_neighbors(now_pos)
            # self.print_line(now_pos)
            # self.print_line('neighbors')
            # self.print_line(neighbors)
            for p in neighbors:
                p_key = self.lt2key(p)
                # self.print_line(p_key)
                if p_key in dis_dict:continue
                if p in blocks:continue
                if now_pos_key in next_dict:
                    next_dict[p_key] = next_dict[now_pos_key]
                else:
                    next_dict[p_key] = p
                dis_dict[p_key] = d+1
                lopen.append(p)
            # self.print_line(lopen)
            q+=1
            # self.print_line(q)
        return dis_dict, next_dict

    def lt2key(self, lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
    def key2lt(self, key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)
    
    def view_box(self, box_type, tool_type):
        """
        检视箱子，box_type为掉落池/物资点字符串，tool_type为具体道具类型，返回值参见通讯格式
        """
        if box_type == "Materials":
            self.__send_opt({"type": "action", "action":["interact", box_type, tool_type]})
        else:
            self.__send_opt({"type": "action", "action":["interact", box_type]})
        while True:
            self.__receive_data()
            if self.root["type"] != "action":
                self.__in_turn()
            else:
                if not self.root["success"]:
                    return copy.deepcopy(self.root)
                else:
                    if tool_type == "key":
                        self.__player.keys = self.root["keys"]
                    else:
                        pass
                    return copy.deepcopy(self.root)
        
    def make_move(self):
        # 区域类型，0为普通区域，1为物资点, 2为密钥机，3为电梯，4为逃生舱
        max_value = -1e8
        next_p = None
        
        has_key_list = []
        keys = list(self.get_keys())
        for i in range(4):
            if i in keys:
                pos = self.get_spawn_pos(i)
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
                pos = (pos[0], pos[1], pos[2] - 1)
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
        
        for z in range(3):
            for x in range(7):
                for y in range(7):
                    pos = (z,x,y)
                    pos_key = self.lt2key(pos)
                    step = self.distance_dict.get(pos_key, 99)
                    if step<=0: continue
                    step_base = 1.0/float(step)
                    
                    value_base = 0.0
                    if self.map.node[z][y][x].type == 1:
                        value_base = 0.2
                    if self.map.node[z][y][x].type == 2 and (not pos_key in has_key_list):
                        value_base = 5.0
                    if self.map.node[z][y][x].type == 4:
                        if len(self.get_keys()) == 4:
                            value_base = 10.0
                    value = value_base * step_base
                    if value>max_value and (pos_key in self.next_dict):
                        max_value = value
                        next_p = self.next_dict[pos_key]
        if not next_p is None:
            self.move(next_p)
        return None

if __name__=="__main__":
    c = MyClient()
    # print(c.player)
    c.run()

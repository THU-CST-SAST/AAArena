import enum
import sys
import json
import copy
from enum import Enum
from showcry_sdk import AIClient


class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        self.atk_flag = False
        self.escaping = False
        self.distance_dict = {}
        self.next_dict = {}

    def play(self):
        import time
        t000 = time.time()
        pos = self.get_my_pos()
        self.my_pos = pos
        at_escape_pos = False
        if self.my_pos[0]!=3 or self.my_pos[1]!=3 or self.my_pos[2]!=0:
            self.escaping=False
        else:
            at_escape_pos = True
        if self.escaping:
            return
        self.print_line("keyfirstv2 round %d"%self.state)
        self.print_line("my pos: "+str(self.my_pos))

        neighbors = self.get_neighbors(self.get_my_pos())
        cnt = 0
        atk = -1
        blocks = []
        for i in range(4):
            if i == self.get_my_num():
                continue
            if self.get_my_pos() == self.get_other_pos(i) or self.get_other_pos in neighbors:
                cnt += 1
                atk = self.player_id_to_player_index(i)
            other_pos = self.get_other_pos(i)
            if not other_pos[0]==-1:
                blocks.append(other_pos)
                other_neighbors = self.get_neighbors(other_pos)
                for p in other_neighbors:
                    blocks.append(p)
        # self.print_line("blocks")
        # self.print_line(blocks)
        # self.print_line('[cnt, atk]:'+str([cnt, atk]))
        # self.print_line(len(self.others))
        if cnt == 1 and self.player.hp >= self.others[atk].hp:
            self.attack(self.get_other_pos(atk),atk)
            self.atk_flag = True
        
        t00=time.time()
        if not self.atk_flag and cnt<=0:
            self.distance_dict, self.next_dict = self.get_distance_dict(blocks=blocks)
        else:
            self.distance_dict, self.next_dict = self.get_distance_dict(blocks=[])

        
        t0=time.time()
        if self.player.hp < 130:
            self.use_tool("Kit")
        # self.print_line(list(self.root.keys()))
        if self.view_box("Box","Key")["success"]:
            return
        # self.print_line(list(self.root.keys()))
        if self.view_box("Materials","Kit")["success"]:
            return
        # self.print_line(list(self.root.keys()))
        if self.interact("KeyMachine")["success"]:
            return
        t1=time.time()
        # self.print_line('time:'+str(t00-t000))
        # self.print_line('time:'+str(t0-t00))
        # self.print_line('time:'+str(t1-t0))

        if at_escape_pos:
            if self.interact("EscapeCapsule",1)["success"]:
                self.escaping=True
                return
        # self.print_line("movegogo")
        # self.test_move()
        self.make_move()
        t2 =time.time()
        self.print_line('time:'+str(t2-t1))
        return 
    
    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        pos_key = self.lt2key(src_pos)
        dis_dict[pos_key] = 0
        lopen = [src_pos]
        q = 0
        while q<len(lopen):
            # self.print_line('bfs in %d'%q)
            now_pos = lopen[q]
            now_pos_key = self.lt2key(now_pos)
            d = dis_dict[now_pos_key]
            neighbors = self.get_neighbors(now_pos)
            # self.print_line(now_pos)
            # self.print_line('neighbors')
            # self.print_line(neighbors)
            for p in neighbors:
                p_key = self.lt2key(p)
                # self.print_line(p_key)
                if p_key in dis_dict:continue
                if p in blocks:continue
                if now_pos_key in next_dict:
                    next_dict[p_key] = next_dict[now_pos_key]
                else:
                    next_dict[p_key] = p
                dis_dict[p_key] = d+1
                lopen.append(p)
            # self.print_line(lopen)
            q+=1
            # self.print_line(q)
        return dis_dict, next_dict
    
    def lt2key(self, lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
    def key2lt(self, key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)

    def make_move(self):
        # 区域类型，0为普通区域，1为物资点, 2为密钥机，3为电梯，4为逃生舱
        max_value = -1e8
        next_p = None
        
        has_key_list = []
        keys = list(self.get_keys())
        for i in range(4):
            if i in keys:
                pos = self.get_spawn_pos(i)
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
                pos = (pos[0], pos[1], pos[2] + 1) # x,y,z
                pos_key = self.lt2key(pos)
                has_key_list.append(pos_key)
        
        for z in range(3):
            for x in range(7):
                for y in range(7):
                    pos = (x,y,z)
                    pos_key = self.lt2key(pos)
                    step = self.distance_dict.get(pos_key, 99)
                    if step<=0: continue
                    step_base = 1.0/float(step)
                    
                    value_base = 0.0
                    if self.map.type[z,y,x]==1:
                        value_base = 0.0
                    if self.map.type[z,y,x]==2 and (not pos_key in has_key_list):
                        value_base = 5.0
                    if self.map.type[z,y,x]==4:
                        if len(self.get_keys())==4:
                            value_base = 10.0
                    value = value_base * step_base
                    if value>max_value and (pos_key in self.next_dict):
                        max_value = value
                        next_p = self.next_dict[pos_key]
        if not next_p is None:
            # self.print_line('nextp')
            # self.print_line(type(next_p[0]))
            # self.print_line(next_p)
            self.move(next_p)
        return None

if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
#ifndef _REROUTE_H
#define _REROUTE_H

using namespace std;

struct strategy
{
    int type=0,value1=0,value2=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

stack<strategy> strategyList;
void reroute(AI_Client&);

#endif

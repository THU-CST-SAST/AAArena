//#include"sdk_AI_Client.hpp"
#include"ai_client.h"
#include<stack>
#include<string>
#include<algorithm>
#include<fstream>
using namespace std;

void tst(Pos &x,AI_Client &client)
{
    string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);
    fout<<std::get<0>(x)<<' '<<std::get<1>(x)<<' '<<std::get<2>(x)<<' ';
    fout<<endl;
}

struct strategy
{
    int type=0,value1=0,value2=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

//typedef std::tuple<int, int, int> Pos;
//typedef std::map<std::string, std::vector<std::vector<int>>> Trapbag;
Pos curPos;
int myID;
Tool myInventory;
stack<strategy> strategyList;
vector<int> keys;  //???????????????????????????????????????????????????
int abort_strategy[10]={0};

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

int dis(Pos s,Pos t,AI_Client& client) // node, not edge
{
if(std::get<0>(t)<0 || std::get<0>(s) < 0) return 10000;
    return client.find_shortest_path(s,t).size();
}

int times_people_can_be_shot(int x) {
	return (x-1) / 70 + 1;
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1;
    double strategy_value[8];
    for(int i = 0; i < 8; i++) strategy_value[i] = -1e100;
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        j=dis(curPos,client.get_spawn_pos(i),client) - 1;
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
        // simple_check
        strategy_value[i] = (j == 0 ? 1e100 : 2.0 / (1 << j));
    }
    //consider approaching players carrying the key in need.
    for(int i = 0; i <= 3; i++) if(i != myID){
    	std::vector <int> k = client.get_others_keys(i);
    	int hp = client.get_others_hp(i);
    	// only check hp
    	double hp_value;
    	int dist = dis(curPos, client.get_others_pos(i), client) - 1;
    	
    	if(hp <= 70) hp_value = 1;
    	else if(hp <= 140) hp_value = 0.5;
    	else hp_value = 0.25;
    	if(client.get_player_hp() <= 140) hp_value /= 4;
    	if(client.get_player_hp() <= 70) hp_value /= 4;
    	int key_in_need = 0;
    	for(int j = 0; j < k.size(); j++) key_in_need += ((find(keys.begin(),keys.end(),k[j])!=keys.end()) == false);
    	std::cerr << "keys for " << i << ' ';
    	for(int i = 0; i < k.size(); i++) std::cerr << k[i] << ' ';
    	std::cerr << endl;
    	double key_value;
    	if(key_in_need == 0) key_value = 0.01;
    	else if(key_in_need == 1) key_value = 0.25;
    	else if(key_in_need == 2) key_value = 2;
    	else if(key_in_need == 3) key_value = 8;
    	double dist_value;
    	if(dist <= 1) dist_value = 1;
    	else if(dist <= 2) dist_value = 0.1; //???
    	else dist_value = 2.0 / (1 << dist);
    	strategy_value[4 + i] = hp_value * key_value * dist_value;
    }
    for(int i = 0; i < 8; i++) std::cerr << strategy_value[i] << ' ';
    std::cerr << endl;
    if(closestSpawn == -1)//已获得所有密钥，前往逃离位置
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_escape_pos();
    } else  {
    	double mx = strategy_value[0];
    	int mxv = 0;
    	for(int i = 1; i < 8; i++) if(strategy_value[i] > mx) mx = strategy_value[i], mxv = i;
    	if(mxv <= 3) {
       	 strategyList.push(0);
        	strategyList.top().dst=client.get_spawn_pos(closestSpawn);
    	} else {
                strategy tmp(1);
                int id = mxv - 4;
                tmp.value1=id;
                tmp.value2=2;
                tmp.dst=client.get_others_pos(id);
                strategyList.push(tmp);
    	} 
    }
}

string getFirstTrap()
{
    if(myInventory.trapbag["LandMine"][0][0])
        return "LandMine";
    if(myInventory.trapbag["Sticky"][0][0])
        return "Sticky";
    return "None";
}

string nextToInspect(Tool &inventory)
{
    if(inventory.blinks_num<2) //优先拿满闪现
        return "Transport";
    if(inventory.kits_num<2) //拿满医疗包
        return "Kit";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    return "Sticky";
}


bool no_need_key(int x,AI_Client& client) {
    	std::vector <int> k = client.get_others_keys(x);
    	for(int i = 0; i < k.size(); i++) if(find(keys.begin(),keys.end(),k[i])==keys.end()) return 0;
    	return 1;
}

void decideStrategy(AI_Client& client)//检查当前策略是否需要更换
{
	cerr << "start_decide" << endl;
    int i,j;
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/
	cerr << '1';
    if(curPos==client.get_escape_pos() && client.get_keys().size()==4)//已到达逃离位置且集齐密钥，可以撤离
    {
        strategyList.push(7);
        return;
    }

	cerr << '2';
    for(i=0;i<4;i++)
    {
        if(find(keys.begin(),keys.end(),i)==keys.end() && curPos==client.get_spawn_pos(i))
        {
            strategyList.push(6);
            return;
        }
    }

	cerr << '3';
    while(!strategyList.empty() && strategyList.top().type==0 && strategyList.top().dst==curPos)//已经到达目标地点，结束移动
        strategyList.pop();

	cerr << '4';
    if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
        return;
    }

	cerr << '5';
    if(strategyList.top().type==2)//当前策略为逃跑
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        if(std::get<0>(otherPos)<0 || dis( otherPos ,curPos,client)>2)
            //和敌人的距离足够远或失去敌人视野时停止
            strategyList.pop();
        else
            return;//继续
    }
    if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
        return;
    }

	cerr << '6';
    if(client.get_player_hp()<100 && myInventory.kits_num)//在低生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

	cerr << '7';
    if(strategyList.top().type==1)//当前策略为进攻
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        //tst(otherPos,client);
        if(std::get<0>(otherPos)<0 ||  dis( otherPos ,curPos,client)>2 
                || (strategyList.top().value2<0) || no_need_key(strategyList.top().value1,client))
            //和敌人的距离足够远、敌人离开视野或追击时间过长时停止
            strategyList.pop();
        else if(client.get_others_hp(strategyList.top().value1)>0)//追击目标存活，继续
        {
	cerr << '8';
            if(client.get_others_hp(strategyList.top().value1)>120)//若目标生命值较高，则减少追击权重
                strategyList.top().value2--;
            else if(client.get_others_hp(strategyList.top().value1)<=70)//若目标为残血，增加追击权重
                strategyList.top().value2++;
            strategyList.top().dst=otherPos;//更新敌人位置
            return;
        }
        else 
        {
	cerr << '9';
            strategyList.pop();
            if(strategyList.top().dst!=curPos)//目标已死亡，前去收集掉落物品
            {
	cerr << 'A';
                strategy tmp(0);
                tmp.dst=strategyList.top().dst;
                strategyList.pop();
                strategyList.push(tmp);
                return;
            }
        }
    }
    
    if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
        return;
    }
	cerr << 'B';
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0)
            continue;
        if(isConnected(otherPos ,curPos,client))
        {int my_kill_times = times_people_can_be_shot(client.get_player_hp());
        	int others_kill_times = times_people_can_be_shot(client.get_others_hp(i));
            if(my_kill_times>others_kill_times)//自身生命值更高，前去追击
            {
                strategy tmp(1);
                tmp.value1=i;
                tmp.value2=2;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return;
            }
            else if(others_kill_times>my_kill_times)//自身生命值更低，尝试逃跑
            {
                strategy tmp(2);
                tmp.value1=i;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return;
            }
        }
    }

	cerr << 'C';
    if(client.get_player_hp()<100 && myInventory.kits_num)//在损失生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos));
    if(val.first && !abort_strategy[5])//当前位置可以拾取物品
    {
        strategyList.push(strategy(5));
        strategyList.top().item=nextToInspect(myInventory);
        return;
    }
    abort_strategy[5]=0;
    string item=getFirstTrap();
    if(item!="None")//物品栏中有陷阱
    {
        if(client.get_neighbors(curPos).size()>2 && !abort_strategy[2])//若当前位置度数>2，则放置陷阱
        {
            strategy tmp(4);
            tmp.item=item;
            strategyList.push(tmp);
            return;
        }
    }
    abort_strategy[2]=0;

	cerr << 'D';
    if(strategyList.top().type==0 && dis( curPos,strategyList.top().dst,client )>5 
            && strategyList.top().dst!=client.get_escape_pos())//若当前策略为移动，且偏离路线过长，则重新规划路线
    {
        strategyList.pop();
        reroute(client);
        return;
    }
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos))//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
    return nullptr;
}

void debug_output(Pos x) {
	std::cerr << std::get<0>(x) << ' ' << std::get<1>(x) << ' ' << std::get<2>(x) << endl;
}
void debug_output(Edge* tar) {
	debug_output(tar->stpos);
	debug_output(tar->edpos);
}

void play(AI_Client &client)
{
        client.finish();
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/
    myID=client.get_id();
    curPos=client.get_player_pos();
    Node &curNode=client.pos2node(curPos);
    myInventory=client.get_tools();
    keys=client.get_keys();
    bool endTurn=false;
    decideStrategy(client);
    cerr << endl;
    /*fout<< "type" << strategyList.top().type <<' '<<strategyList.top().item<<std::endl;
    fout<<"keys:";
    for(int i:keys)
        fout<<i<<' ';
    fout<<endl;
    tst(strategyList.top().dst,client);
    tst(curPos,client);*/
    std::cerr << "type" << strategyList.top().type << std::endl;
    switch (strategyList.top().type)
    {
        case 0://移动
        {
            if(client.find_shortest_path(curPos,strategyList.top().dst).size() == 1) {
            	while(1);
            }
            Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
            Edge *tar=findEdge(curNode,nextPos);
            
            debug_output(tar);
            
            moveTo(tar,client);
            endTurn=true;
            break;
        }
        case 1://攻击
        {
            if(isConnected(curPos,client.get_others_pos(strategyList.top().value1),client))//能攻击到敌人
            {
            cerr << 'x' << endl;
                client.attack(client.get_others_pos(strategyList.top().value1),strategyList.top().value1);
            }
            else//不能攻击到敌人，尝试接近敌人
            {
            cerr << 'y' << endl;
                Pos nextPos=client.find_shortest_path(curPos,client.get_others_pos(strategyList.top().value1))[1];
                Edge *tar=findEdge(curNode,nextPos);
            debug_output(tar);
                moveTo(tar,client);
            }
            endTurn=true;
            break;
        }
        case 2://逃跑
        {
        	Pos otherspos = client.get_others_pos(strategyList.top().value1);
        	if(std::get<0>(otherspos) == -1) {
        		endTurn = true;
        		break;
        	}
            Pos banned=client.find_shortest_path(curPos,otherspos)[1];//不能向敌人的方向跑
            vector<Pos> neighbors=client.get_neighbors(curPos);
            for(Pos nextPos:neighbors)
            {
                if(nextPos!=banned)//向任意不会遭遇敌人的方向逃跑
                {
                    Edge *tar=findEdge(curNode,nextPos);
                    moveTo(tar,client);
            debug_output(tar);
                    break;
                }
            }
            endTurn=true;
            break;
        }
        case 3://治疗
        {
            client.use_kit();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 4://放置陷阱
        {
            if(!client.place_trap(strategyList.top().item))
                abort_strategy[2]=1;
            strategyList.pop();
            break;
        }
        case 5://拾取
        {
            if(!client.inspect_materials(strategyList.top().item))
                abort_strategy[5]=1;
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 6://获得密钥
        {

            client.get_key();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 7://逃离
        {
            client.escape(true);
            endTurn=true;
            break;
        }
    }
    if(endTurn)//若当前操作计入行动次数，则结束回合
    {
        //fout<<"finish"<<endl;
        client.finish();
    }
    else//若当前操作不计入行动次数，则可以继续行动
    {
        play(client);
    }
}


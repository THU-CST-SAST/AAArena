# actors and critics

def critic(state, player, ptcp_ids): # 以player为视角评价局面\
    # print(state['state'])
    value = 0
    for i in range(4):
        if not i in ptcp_ids:continue
        hp = float(state['instance']['players'][i]['hp'])
        mul = 1 if player==i else -1
        hc_mul = 1 if player==i else 1/(len(ptcp_ids)-1)
        hp_value = hp / 200.0 * float(hc_mul)
        # print('hpinfo',hc_mul, mul,hp_value)
        value += hp_value*mul
        danger_value = hp<70.0001
        value -= danger_value*float(hc_mul)*mul
        # 这里应该给别人hp除以人数，这样自己的血量就偏重要
        dead_value = float(state['instance']['players'][i]['dead_punish'])
        if player==i:
            value-=3*dead_value
        else:
            value+= dead_value
        
        atk_value = 70.0/200.0# 攻击一次的价值
        # kit_num = float(state['instance']['players'][i]['kit'])
        # if kit_num>0 and int((hp+100.0)/70.0) - int(hp/70.0)>1:
            # kit_value = atk_value/float(hc_mul)
            # value += kit_value*mul
        # trans_value = 0.1*atk_value*float(state['instance']['players'][i]['trans'])*mul
        # value+=trans_value
        # print(i, value)
    # print(player, state, value)
    return value
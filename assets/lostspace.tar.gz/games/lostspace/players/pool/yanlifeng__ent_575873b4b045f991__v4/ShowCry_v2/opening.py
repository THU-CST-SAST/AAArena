# from func_sdk import *

def opening(my_id, players, state):
    # input ???
    # output next_pos
    watch_pos_dict = {
        0:[0,1,1],
        1:[6,1,1],
        2:[6,5,1],
        3:[0,5,1],
    }
    watch_pos2_dict = {
        0:[1,1,1],
        1:[6,1,1],
        2:[6,5,1],
        3:[0,5,1],
    }
    if state==1:
        return watch_pos_dict[my_id]
    # if state!=0
    me = players[my_id]
    if state==2:
        if my_id==0:
            return [1,1,1]
        elif my_id==1:
            player0 = players[0]
            if player0.pos[0]>0:
                return [6,2,1]
            else:
                return [5,1,1]
        elif my_id==2:
            return [6,4,1]
        elif my_id==3:
            return [0,4,1]
            
def opening_v2(my_id, players, state):
    # input ???
    # output next_pos
    watch_pos_dict = {
        0:[0,1,1],
        1:[6,1,1],
        2:[6,5,1],
        3:[0,5,1],
    }
    watch_pos2_dict = {
        0:[1,1,1],
        1:[6,1,1],
        2:[6,5,1],
        3:[0,5,1],
    }
    if state==1:
        return watch_pos_dict[my_id]
    # if state!=0
    me = players[my_id]
    if state==2:
        if my_id==0:
            return [1,1,1]
        elif my_id==1:
            player0 = players[0]
            if player0.pos[0]>0:
                return [6,2,1]
            else:
                return [5,1,1]
        elif my_id==2:
            return [6,4,1]
        elif my_id==3:
            return [0,4,1]
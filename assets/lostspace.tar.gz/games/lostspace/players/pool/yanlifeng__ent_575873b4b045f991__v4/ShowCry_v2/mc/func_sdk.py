
def pos2key(lt):
        return "%d,%d,%d"%(lt[0],lt[1],lt[2])
    
def key2pos(key):
        nums = key.split(',')
        nums = [int(x) for x in nums]
        return tuple(nums)
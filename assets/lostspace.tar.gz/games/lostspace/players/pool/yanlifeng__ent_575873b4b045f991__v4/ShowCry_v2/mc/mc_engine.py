from copy import deepcopy as dcp
import numpy as np

from .env import *
from .anc import *
from .utils import *
from .func_sdk import *

PMIN=0.1

def check_be_attack(my_id, pos, can_move_list):
    for i in range(4):
        if i==my_id:continue
        if pos in can_move_list[i]:
            return True
    return False

def cnt_be_attack(my_id, pos, can_move_list):
    cnt = 0
    for i in range(4):
        if i==my_id:continue
        if pos in can_move_list[i]:
            cnt+=1
    return cnt

class Node():
    def __init__(self, state, maper, ptcp_ids, on_player=True, last_act=None):
        self.state = dcp(state)
        self.maper = dcp(maper)
        self.ptcp_ids = ptcp_ids
        self.valid_acts = []
        self.act_prefers = []
        self.act_probs = []
        self.pr = -1
        self.sons = []
        self.best_act = None
        self.on_player = on_player # 是当前玩家时on_player才是True\
        self.score = -9999 if on_player else 9999
        self.last_act = last_act
        self.is_leaf = True
        self.visit = 0
        self.son_sum_visit = 0.0
        self.son_sum_score = 0.0
        # init by state, calc valid acts, something
        connection = maper.connection
        delta = maper.delta
        my_id = state['player']
        my_pos = get_pos_by_id(state, my_id)
        my_t2born = get_t2born_by_id(state, my_id)
        can_move_list = [[],[],[],[]]
        for i in range(4):
            if (not i in ptcp_ids) or (get_t2born_by_id(state,i)>0):continue
            pos = get_pos_by_id(state, i)
            x,y,z = pos
            len_delta = connection.shape[3]
            for idelta in range(len_delta):
                if connection[z,y,x,idelta]!=1:continue
                xx = x + delta[idelta][0]
                yy = y + delta[idelta][1]
                zz = z + delta[idelta][2]
                can_move_list[i].append([xx,yy,zz])
        
        lock_act = False
        if my_t2born<=0:
            # gen valid acts
            for move_pos in can_move_list[my_id]:
                xx, yy, zz = move_pos
                # valid move
                if state['instance']['players'][my_id]['trans']>0 and \
                    (not check_be_attack(my_id, my_pos, can_move_list)) and \
                    check_be_attack(my_id, [xx,yy,zz], can_move_list):
                    pass
                # 如果跑了还是被两个攻击则不能跑，攻击任意。
                elif cnt_be_attack(my_id, [xx,yy,zz], can_move_list)>1:
                    pass
                else:
                    self.valid_acts.append({'id':my_id,'type':'move','pos':[xx,yy,zz]})
                # valid atk
                cnt_atked = cnt_be_attack(my_id, pos, can_move_list)
                for iop in range(4):
                    if (iop==my_id) or (not iop in ptcp_ids) or (get_t2born_by_id(state,iop)>0):continue
                    op_pos = get_pos_by_id(state,iop)
                    if pos_eq(op_pos,[xx,yy,zz]):
                        my_hp = state['instance']['players'][my_id]['hp']
                        op_hp = state['instance']['players'][iop]['hp']
                        if int(my_hp/70.0)>=int(op_hp/70.0) and cnt_atked<=1:
                            self.valid_acts = []
                            self.valid_acts.append({'id':my_id,'type':'attack','target':iop})
                            lock_act = True
                            break
                        else:
                            self.valid_acts.append({'id':my_id,'type':'attack','target':iop})
                        
                # valid blink atk
                if not lock_act:
                    for iop in range(4):
                        if (iop==my_id) or (not iop in ptcp_ids) or (get_t2born_by_id(state,iop)>0):continue
                        if state['instance']['players'][my_id]['trans']>0 and (move_pos in can_move_list[iop]):
                            my_hp = state['instance']['players'][my_id]['hp']
                            op_hp = state['instance']['players'][iop]['hp']
                            cnt_atked = cnt_be_attack(my_id, [xx,yy,zz], can_move_list)
                            if int(my_hp/70.0)>=int(op_hp/70.0) and cnt_atked<=1:
                                self.valid_acts = []
                                self.valid_acts.append({'id':my_id,'type':'blink_attack','blink_pos':[xx,yy,zz],'target':iop})
                                lock_act = True
                                break
                            else:
                                self.valid_acts.append({'id':my_id,'type':'blink_attack','blink_pos':[xx,yy,zz],'target':iop})
                # # valid blink move 就假设大家都不用blink move吧，减小搜索空间。\
            # kit    
            if not lock_act:
                my_hp = state['instance']['players'][my_id]['hp']
                cnt_atked = cnt_be_attack(my_id, my_pos, can_move_list)
                if state['instance']['players'][my_id]['kit']>0 and not ((cnt_atked==1 and my_hp>=100) or cnt_atked>1):
                    self.valid_acts.append({'id':my_id,'type':'use_kit'})
            # end gen valid_acts
            
        # end if I am alive    
        
        # pass
        if not lock_act:
            if (not check_be_attack(my_id,my_pos, can_move_list)) or len(self.valid_acts)==0:
                self.valid_acts.append({'id':my_id,'type':'pass'})
        self.sons = [-1 for _ in range(len(self.valid_acts))]
        
        # calc act prefers
        len_acts = len(self.valid_acts)
        self.act_prefers=[0.0 for _ in range(len_acts)]
        pavg = 1.0/float(len_acts)
        pmin = 1.0/float(len_acts)*PMIN
        pmax = 1.0 - float(len_acts-1)*pmin
        for i, act in enumerate(self.valid_acts):
            if act['type']=='move':
                pos = act['pos']
                for iop in range(4):
                    if iop==my_id:continue
                    if pos in can_move_list[iop]:
                        self.act_prefers[i]=-0.5
                        break
        self.act_probs = [pavg for _ in range(len_acts)]
        # print(len(self.valid_acts))
        # print(len(self.act_probs))
        # print('--')
        for i, prefer in enumerate(self.act_prefers):
            if prefer==0:continue
            for j in range(len_acts):
                if j==i:
                    self.act_probs[j]+=pavg*prefer
                else:
                    self.act_probs[j]-=pavg*prefer*float(len_acts-1)/float(len_acts)
        self.act_probs = np.array(self.act_probs)
        self.act_probs = np.clip(self.act_probs, pmin, pmax)
        self.act_probs = self.act_probs/np.sum(self.act_probs)
    

def mc_run(init_state, maper, node_num=120, ptcp_ids=[0,1,2,3]):
    '''
    state format: 包括instance和hidden， 以字典方式存储吧
       instance是该有的信息
       hidden 是一些额外的信息，就比如哪个人会多少回合后在哪里复生；box的情况；当前的行动玩家id（可能有也可能没有的意思）
    maper 地图类，跟游戏中同步，因为要跟随round更新。
    '''
    # search init
    self_player = init_state['player']
    init_score = critic(init_state, self_player, ptcp_ids)
    nodes = []
    # openlist = []
    init_node = Node(init_state, maper, ptcp_ids)
    nodes.append(dcp(init_node))
    # openlist.append(True)
    # random expand
    for imc in range(node_num):
        q = 0
        len_nodes = len(nodes)
        expanded = False
        # import time
        # t0=time.time()
        while not expanded:
            # print(q)
            pick_node = nodes[q]
            # print(pick_node.sons)
            nodes[q].visit+=1
            len_acts = len(pick_node.valid_acts)
            # print(pick_node.valid_acts)
            # print(pick_node.act_probs)
            # raise
            # print(q)
            if q==0:
                i_act_pick = np.random.randint(len_acts) # pure random
            else:
                # print(len_acts)
                # print(len(pick_node.valid_acts))
                # print(len(pick_node.act_probs))
                i_act_pick = np.random.choice(a=np.arange(len_acts), size=1, replace=True, p=pick_node.act_probs)[0]
                # raise
            # print(i_act_pick)
            # print(i_act_pick, pick_node.sons[i_act_pick])
            # unif = np.random.uniform(0, len_acts-1)
            # i_act_pick = int(np.round(unif))
            if pick_node.sons[i_act_pick]==-1:
                # expand             
                act = pick_node.valid_acts[i_act_pick]
                next_maper = dcp(maper)
                next_maper.update_map()
                next_state = dcp(pick_node.state)
                next_state = env_step(next_state, act, ptcp_ids)
                next_node = Node(next_state, next_maper, ptcp_ids, next_state['player']==self_player, last_act=act)
                nodes.append(dcp(next_node))
                # update connect
                nodes[q].is_leaf = False
                nodes[q].sons[i_act_pick] = len_nodes
                # print(len_nodes)
                nodes[-1].pr = q
                nodes[-1].visit+=1
                expanded = True
            q = nodes[q].sons[i_act_pick]
        # print(time.time()-t0)
        # if imc>2:raise
    # update score
    len_nodes = len(nodes)
    # print('len_nodes:', len_nodes)
    for i in range(len_nodes-1,0,-1): # 这里是跳过0的，0不用往上update
        node = nodes[i]
        ipr = node.pr
        if node.is_leaf:
            score = critic(node.state, self_player, ptcp_ids)
        else:
            # if node.on_player:
            # if ipr==0:
                # nodes[i].score = float(node.son_sum_score) / float(node.son_sum_visit)nodes[i].score = float(node.son_sum_score) / float(node.son_sum_visit)
                # score = node.score
            # else:
            nodes[i].score = float(node.son_sum_score) / float(node.son_sum_visit) # 为了看,to remove
            score = float(node.son_sum_score) / float(node.son_sum_visit)
        if ipr==-1:raise # impossible
        # print(i,score)
        # print(ipr, nodes[ipr].score)
        # if nodes[ipr].on_player:
        if ipr==0:
            if score>nodes[ipr].score:
                nodes[ipr].score = score
                nodes[ipr].best_act = nodes[i].last_act
        else:
            nodes[ipr].son_sum_score += node.visit * score
            nodes[ipr].son_sum_visit += node.visit
    # print(nodes[0].valid_acts)
    # print(nodes[0].sons)
    # print([nodes[son].visit for son in nodes[0].sons])
    # for son in nodes[0].sons:
        # print(nodes[son].last_act, nodes[son].score, nodes[son].pr)
    # print('init score ', init_score)
    return nodes[0].best_act, nodes[0].score - init_score - 1.0/float(node_num)
# 写完了先test，用一个map类和district限制活动范围



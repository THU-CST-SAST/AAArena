import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["USE_SIMPLE_THREADED_LEVEL3"] = "1"
# from KeyFirstAI import MyClient
from ShowCry_v2_3 import MyClient

if __name__=="__main__":
    c = MyClient(print_flag=False)
    c.run()
def cnt_be_attack(my_id, pos, can_move_list):
    cnt = 0
    atk_info = []
    for i in range(4):
        if i==my_id:continue
        self.print_line([i,pos,can_move_list[i]])
        if pos in can_move_list[i]:
            cnt+=1
            atk_info.append(i)
    self.print_line(atk_info)
    return cnt, atk_info
    
# def cnt_be_blink_attack(my_id, pos, can_move_list):
    # cnt = 0
    # atk_info = []
    # for pos
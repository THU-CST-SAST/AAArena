from showcry_sdk import Map
from mc.mc_engine import mc_run
import time

# 本地test，假装一个
if __name__=='__main__':
    maper = Map(num_round=10)
    init_state = {
        'state':8,
        'player':0,
        'instance':{
            'players':[
                {'id':0, 'pos':[5,1,1], 'hp':160 , 'kit':1, 'trans':1, 'keys':[0], 't2born':0, 'dead_punish':0},
                {'id':1, 'pos':[6,5,1], 'hp':0, 'kit':0, 'trans':0, 'keys':[1], 't2born':1, 'dead_punish':0},
                {'id':2, 'pos':[6,0,1], 'hp':130, 'kit':0, 'trans':0, 'keys':[2], 't2born':0, 'dead_punish':0},
                {},
            ]
        },
        'hidden':{},
    }
    
    t0 = time.time()
    result = mc_run(init_state, maper,ptcp_ids=[0,1,2])
    t1 = time.time()
    print(t1-t0)
    print(result)
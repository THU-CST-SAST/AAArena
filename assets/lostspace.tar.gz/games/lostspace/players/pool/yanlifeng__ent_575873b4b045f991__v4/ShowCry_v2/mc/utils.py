
def pos_eq(pos0,pos1):
    return (pos0[0]==pos1[0]) and (pos0[1]==pos1[1]) and (pos0[2]==pos1[2])

def get_pos_by_id(state, i):
    return state['instance']['players'][i]['pos']

def get_t2born_by_id(state,i):
    return state['instance']['players'][i]['t2born']
    
def get_spawn_pos(i):
    spawn_poses = [[0,0,1],[6,0,1],[6,6,1],[0,6,1]]
    return spawn_poses[i]
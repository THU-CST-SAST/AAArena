from copy import deepcopy as dcp
from .utils import *

def get_next_player(i):
    return i+1 if i!=3 else 0

def env_step(in_state, act, ptcp_ids):
    # print(in_state)
    # print(act)
    # raise
    state = dcp(in_state)
    state['state']+=1
    if act['type']=='move':
        state['instance']['players'][act['id']]['pos'] = act['pos']
    elif act['type']=='attack':
        target = act['target']
        state['instance']['players'][target]['hp'] -= 70
        if state['instance']['players'][target]['hp']<=0:
            state['instance']['players'][target]['t2born']=5
            state['instance']['players'][target]['dead_punish']+=1
    elif act['type']=='blink_attack':
        act_id = act['id']
        target = act['target']
        state['instance']['players'][act_id]['pos'] = act['blink_pos']
        state['instance']['players'][act_id]['trans'] -= 1
        state['instance']['players'][target]['hp'] -= 70
        if state['instance']['players'][target]['hp']<=0:
            state['instance']['players'][target]['t2born']=5
            state['instance']['players'][target]['dead_punish']+=1
    elif act['type']=='use_kit':
        act_id = act['id']
        state['instance']['players'][act_id]['hp'] = min(state['instance']['players'][act_id]['hp']+100,200)
    elif act['type']=='pass':
        pass
    else:
        # print(act)
        raise
    # 不要忘记更新state['player']到下一个
    player = get_next_player(state['player'])
    while not player in ptcp_ids:
        player = get_next_player(player)
    state['player'] = player
    # 模拟复活
    t2born = get_t2born_by_id(state, player)
    if t2born==1:
        state['instance']['players'][player]['pos'] = get_spawn_pos(player)
    if t2born>0:
        state['instance']['players'][player]['t2born']-=1
    return state
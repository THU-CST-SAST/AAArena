import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["USE_SIMPLE_THREADED_LEVEL3"] = "1"
import sys
import json
import copy
from enum import Enum
import numpy as np
from showcry_sdk import *
from func_sdk import *
from opening import *

# from mc.mc_engine import mc_run

class MyClient(AIClient):
    def __init__(self, print_flag=True):
        super().__init__(print_flag)
        # public ai memory
        self.my_pos = [-1,-1,-1]
        self.distance_dict = {}
        self.next_dict = {}
        self.no_block_distance_dict = {}
        self.no_block_next_dict = {}
        self.strength_list = [0 for _ in range(4)] # arrange by playerid
        self.mat_poses_valid_keys = []
        self.escaping=False
        self.at_escape_pos = False
        self.last_all_players = [None, None, None, None]
        self.all_players = [None, None, None, None]
        self.last_attack_flags = [False,False,False,False]
        self.unseen_cnt = [0, 0, 0, 0]
        self.one_op_adv = 0
        self.mine_poses = [[3,1,0],[3,5,0],[3,4,0],[3,2,0]]
        self.sticky_poses = [
            [4,2,0],[4,4,0],[2,4,0],[2,2,0],[3,2,0],[3,4,0]]
        self.now_sticky_pos = None
        
        # unique ai memory

    def play(self):
        # sys.stderr.write('hi')
        # import time
        # t0 = time.time()
        ## update info
        self.update_info() # public
        my_id = self.my_id
        my_pos = self.my_pos
        self.print_line("*** round %d ShowCry_v2_3 player %d ***"%(self.state,self.get_my_num()))
        self.print_line("my pos: "+str(my_pos))
        # self.print_line("box_keys:"+str(self.view.box_keys))
        all_poses = []
        all_hps = []
        all_keys = []
        for player in self.all_players:
            if player is None:continue
            all_poses.append(player.pos)
            all_hps.append(player.hp)
            all_keys.append(player.keys)
        self.print_line('allposes:'+str(all_poses))
        self.print_line('allhps:'+str(all_hps))
        self.print_line('all_keys:'+str(all_keys))
        self.print_line([
            'trans',
            self.player.tools.transport
        ])
        # other update info
        # end other update
        self.acted = False
        acts = self.opening()
        rascal_flag, emer_flag = self.judge_rascal()
        actor_mode = 'normal'
        if rascal_flag:
            if not emer_flag:
                actor_mode = 'rascal'
            else:
                actor_mode='emer_rascal'
        #
        if not self.acted:
            acts = self.pre_mc_actor(mode=actor_mode)
        if not self.acted:
            acts = self.vanilla_actor(mode=actor_mode)
        self.print_line("acts:"+str(acts))
        self.implement_action(acts)
        self.print_line("end_play")
        return
    
    def opening(self):
        acts = []
        my_id = self.my_id
        state = self.state
        if state<3:
            watch_pos_dict = {
                0:[0,1,1],
                1:[6,1,1],
                2:[6,5,1],
                3:[0,5,1],
            }
            watch_pos2_dict = {
                0:[0,2,1],
                1:[6,2,1],
                2:[6,4,1],
                3:[0,4,1],
            }
            if state==1:
                acts.append({'type':'move','pos':watch_pos_dict[my_id]})
                self.acted=True
                return acts
            elif state==2:
                acts.append({'type':'move','pos':watch_pos2_dict[self.my_id]})
                self.acted=True
                return acts
        else:
            if state==3:
                if my_id==0:
                    acts.append({'type':'move','pos':[0,3,1]})
                    self.acted=True
                elif my_id==1:
                    acts.append({'type':'move','pos':[6,3,1]})
                    self.acted=True
                return acts
            else:
                return acts
    
    def pre_mc_actor(self, mode='normal'):
        # calc_dangerous 
        my_pos = self.my_pos
        my_pos_key = self.lt2key(my_pos)
        dangerous = False
        for i in range(4):
            if i==self.my_id:continue
            if self.all_players[i].status==1 or self.all_players[i].status==4:continue
            if self.strength_list[i]>1:
                if self.all_noblock_distance_dict[i][my_pos_key]<=2:
                    dangerous=True
                    break
            else:
                if self.all_noblock_distance_dict[i][my_pos_key]<=1:
                    dangerous=True
                    break
        
        acts = []
        if not dangerous:
            if self.player.hp<190 and self.player.tools.kit>=1:
                acts.append({'type':'use_kit'})
                # self.use_tool("Kit")
                self.acted=True
        
        # get box
        if self.acted:return acts
        if not dangerous and self.check_get_box():
            acts.append({'type':'get_box'})
            # self.interact("Box")
            self.acted=True
        
        # get key
        if self.acted:return acts
        # self.print_line(["checkgetkey",self.check_get_key()])
        if not dangerous and self.check_get_key():
            acts.append({'type':'get_key'})
            # self.use_keymachine()
            self.acted=True
            self.print_line("get_keyed")
        
        # 如果资源不足按优先（血量<200且无kit or 雷<1 or 闪现<1）
        mat_flag = False
        use_mat_flag = False
        if mode!='normal':
            if self.player.tools.landmine_number[0]<2:
                use_mat_flag=True
            else:
                use_mat_flag = False
        else:
            # if self.player.hp<200 and self.player.tools.kit<1:
            if self.player.tools.kit<1:
                mat_flag = True
                use_mat_flag = True
            elif self.player.tools.transport<1:
                mat_flag = True
                use_mat_flag = True
            else:
                if dangerous:
                    mat_flag=True
                if self.player.tools.transport<2:
                    use_mat_flag = True
            # self.print_line([mat_flag, use_mat_flag])
        
        # view box
        if self.acted:return acts
        my_pos_key = self.lt2key(my_pos)
        if not dangerous and my_pos_key in self.mat_poses_valid_keys and self.mat_num[my_pos_key]>0:
            if use_mat_flag:
                if mode=='normal':
                    acts.append({'type':'get_mat'})
                else:
                    acts.append({'type':'get_rascal_mat'})
                # self.get_tools()
                self.mat_num[my_pos_key]-=1
                self.acted=True
                # self.print_line("view_boxed")
        
        # escape
        if not dangerous and self.at_escape_pos and len(self.player.keys)>=4:
            # if self.interact("EscapeCapsule",1)["success"]:
                # self.escaping=True
                # return acts
            acts.append({'type':'escape'})
            self.acted=True
            return acts
        self.acted = len(acts)>0
        return acts
        
    def get_ptcp_ids(self):
        ptcp_ids = []
        if self.player.status==1 or self.player.status==4:return False
        ptcp_ids.append(self.my_id)
        q = 0
        while q<len(ptcp_ids):
            self_id = ptcp_ids[q]
            self_pos = self.all_players[self_id].pos
            pos_key = self.lt2key(self_pos)
            for i in range(4):
                # self.print_line([i, self.all_noblock_distance_dict[i]])
                if i==self_id or i in ptcp_ids:continue
                if self.all_players[i].pos[0]==-1:continue
                if self.all_players[i].status==1 or self.all_players[i].status==4:continue
                dis_dict = self.all_noblock_distance_dict[i]
                if dis_dict[pos_key]<=3:
                    ptcp_ids.append(i)
            q+=1
        # self.print_line('ptcp_ids:'+str(ptcp_ids))
        arange_ptcp_ids = [i for i in range(4) if i in ptcp_ids]
        return arange_ptcp_ids
    
    def mc_actor(self, ptcp_ids):
        # make state
        init_state = self.get_state()
        self.print_line('ptcp:'+str(ptcp_ids))
        self.print_line('get state')
        self.print_line(init_state)
        # @ mc_run(init_state, maper, node_num=150, ptcp_ids=[0,1,2,3])
        act, score = mc_run(init_state, self.map, node_num=120, ptcp_ids=ptcp_ids)
        self.print_line(act)
        acts = [act]
        return acts
    
    def get_state(self):
        state = {
            'state':self.state,
            'player':self.my_id,
            'instance':{
                'players':[]
            },
            'hidden':{},
        }
        for i in range(4):
            pos = self.all_players[i].pos
            if pos[0]==-1:
                state['instance']['players'].append({})
            else:
                if i==self.my_id:
                    kit = self.player.tools.kit
                    trans = self.player.tools.transport
                else:
                    strength = self.strength_list[i]
                    if strength==0:
                        kit=0
                        trans=0
                    elif strength==1:
                        kit = 0
                        trans=1
                    elif strength==2:
                        kit = 1
                        trans=1
                    else:
                        kit=1
                        trans=2
                state['instance']['players'].append({
                    'id':i, 'pos':pos, 'hp':self.all_players[i].hp,
                    'kit':kit,
                    'trans':trans,
                    'keys':self.all_players[i].keys,
                    't2born':0,
                    'dead_punish':0,
                })
        return state
    
    def get_target_score(self, pos, target_dis_dict):
        my_pos = self.my_pos
        my_pos_key = self.lt2key(my_pos)
        pos_key = self.lt2key(pos)
        # self.print_line(['target_info',pos])
        # self.print_line(target_dis_dict)
        return float(target_dis_dict[my_pos_key] - target_dis_dict[pos_key])
    
    def get_atk_extra_score(self,pos):
        total_dmg, atk_info = self.get_total_dmg(pos)
        # 如果攻击到仅1人，且对方n_suffer小于我则有extra_score
        # = 0.5 (因为这个分数要小于1.0不然会一直追人)
        atk_extra_score = 0.0
        if len(atk_info)==1:
            iop = atk_info[0]
            ophp = self.all_players[iop].hp
            myhp = self.player.hp
            my_n_suffer = self.get_n_suffer(self.player.hp+100.0*self.player.tools.kit, 70.0)
            if my_n_suffer > self.get_n_suffer(ophp,70.0):
                atk_extra_score = 0.5
        return atk_extra_score
        
    def get_move_score(self, pos, move_target, target_dis_dict, atk_extrta_score):
        move_score = 0.0
        total_dmg, atk_info = self.get_total_dmg(pos) # 已计算闪A
        # 分数的基础单位是向目标走一步一分。
        if move_target is None:
            target_score = 0.0
        else:
            target_score = self.get_target_score(pos, target_dis_dict)
        # dmg score
        if atk_extrta_score>1e-8:
            dmg_score = 0.0
        else:
            # dmg_score必须<-1.0，否则会无视继续走
            dmg_score = -len(atk_info)*2.0
        return target_score + dmg_score
        
    def vanilla_actor(self, mode='normal'):
        # self.print_line(['033connection',self.map.connection[0,3,3]])
        # self.print_line('sticky_num:'+str(self.player.tools.sticky_number[0]))
        my_id = self.my_id
        my_pos = self.my_pos
        acts = []
        
        sys.stderr.write('round{}\n'.format(self.state))
        # 先算dangerous
        # 预先计算move_target，若3格内有人触发攻击计算。
        # 否则乱砍
        # 否则move
        
        # calc dangerous
        dead_status = [player.status for player in self.all_players]
        self.print_line('status:'+str(dead_status))
        total_dmg, _ = self.get_total_dmg(my_pos)
        if total_dmg>0:
            dangerous=True
        else:
            dangerous=False
        
        # 如果资源不足按优先（血量<200且无kit or 雷<1 or 闪现<1）
        mat_flag = False
        use_mat_flag = False
        if mode=='normal':
            # if self.player.hp<200 and self.player.tools.kit<1:
            if self.player.tools.kit<1:
                mat_flag = True
                use_mat_flag = True
            elif self.player.tools.transport<1:
                mat_flag = True
                use_mat_flag = True
            else:
                if dangerous:
                    mat_flag=True
                if self.player.tools.transport<2:
                    use_mat_flag = True
            # self.print_line([mat_flag, use_mat_flag])
        elif mode=='rascal':
            use_mat_flag=True
        
        move_target = None
        if mode=='normal':
            # normal move
            # 最好的 key target 如果小于距离2则优先key_target, 另外key_target更新box
            # v2_0更新，判断如果自己钥匙数大于2，则以较安全层为目标。
            # 安全的定义是本层其他人小于等于1则本层安全，否则另一层安全。
            if len(self.player.keys)<2:
                key_target = self.find_key_target(safe=False)
            else:
                key_target = self.find_key_target(safe=True)
            key_first_flag = False
            if not key_target is None:
                key_target_poskey = self.lt2key(key_target)
                if not dangerous and self.distance_dict[key_target_poskey]<=2:
                    key_first_flag = True
                else:
                    key_first_flag = False
            self.print_line('dangerous?'+str(dangerous))
            if dangerous:
                mat_target = self.find_mat_target(other_layer=True)
            else:
                mat_target = self.find_mat_target()
            if self.acted:return acts
            if mat_flag and (not mat_target is None)and (not key_first_flag):
                self.print_line("mattarget:"+str(mat_target))
                move_target = mat_target
                # self.make_move_pos(mat_target)
            else:
                # key_target = self.find_key_target()
                self.print_line("keytarget:"+str(key_target))
                # if key_target is None:
                    # return acts
                move_target = key_target
                # self.make_move_pos(key_target)
        elif mode=='rascal':
            if self.player.tools.landmine_number[0]>=2 or \
                self.player.tools.landmine_number[0]>=1 and self.player.pos[2]==0:
                # 去埋雷
                mine_poses = self.mine_poses
                for mine_pos in mine_poses:
                    if self.pos_equal(mine_pos, self.my_pos):
                        acts.append({'type':'put_mine'})
                # self.print_line('mine info >>')
                # self.print_line(self.player.tools.landmine_pos)
                if self.player.pos[2]==0:
                    mine_pos = self.select_mine_pos()
                    if not mine_pos is None:
                        move_target = mine_pos
                    else:
                        move_target = [3,3,0]
                else:
                    move_target=[3,3,0]
            else:                
                if dangerous:
                    mat_target = self.find_mat_target(other_layer=True)
                else:
                    mat_target = self.find_mat_target()
                move_target = mat_target
        elif mode=='emer_rascal':
            if not self.player.pos[2]==0:
                move_target=[3,3,0]
            else:
                # 在0层的操作
                # move_target=[3,3,0] #  to remove
                # self.print_line("mine info")
                # self.print_line(self.player.tools.landmine_pos)
                move_target = None
                mine_poses = self.mine_poses
                on_mine_pos = False
                for mine_pos in mine_poses:
                    if self.pos_equal(mine_pos, self.my_pos):
                        on_mine_pos = True
                put_mine_flag = False
                if on_mine_pos and \
                    self.player.tools.landmine_number[0]>0:
                        acts.append({'type':'put_mine'})
                        put_mine_flag = True
                
                if not put_mine_flag and not self.now_sticky_pos is None:
                    if self.pos_equal(self.my_pos, self.now_sticky_pos):
                        acts.append({'type':'put_sticky'})
                        put_mine_flag = True
                
                if not put_mine_flag:
                    if not dangerous:
                        sys.stderr.write('in layer0_ops\n')
                        sys.stderr.write('boxes:{}\n'.format(str(self.view.box_keys)))
                        key_target = self.find_key_target(only_zero=True)
                        sys.stderr.write('key_target:{}\n'.format(key_target))
                        if not key_target is None:
                            move_target = key_target
                    layer0_ops = [op.pos for op in self.others if op.pos[0]!=-1]
                    if len(layer0_ops)==0:
                    # 不需要判dangerous 因为收益很高，而且一般死的很近，不会放掉330
                        if not move_target is None:
                            mine_pos = self.select_mine_pos()
                            if not mine_pos is None:
                                move_target = mine_pos
                            elif self.now_sticky_pos is None:
                                move_target = self.now_sticky_pos
                            else:                                                                       
                                move_target = [3,3,0]
                    else:
                        move_target = [3,3,0]
                
                if move_target is None:
                    move_target = [3,3,0]# to remove
        
        # decide action
        ## make valid_acts and value
        valid_acts = []
        valid_scores = []
        neighbors = self.get_neighbors(my_pos)
        ATK_SCORE = 3.0
        if move_target is None:
            target_dis_dict = {}
        else:
            target_dis_dict, _ = self.get_distance_dict(pos=move_target)
        # valid_moves
        for pos in neighbors:
            # if self.pos_equal(pos, self.my_pos):continue (带有pass的)
            atk_extra_score = self.get_atk_extra_score(pos)# 攻击仅一人且我方优势时
            # move score包括了target_score和dmg_score
            move_score = self.get_move_score(pos, move_target,target_dis_dict,atk_extra_score)
            score = move_score + atk_extra_score
            valid_acts.append({'type':'move','pos':pos})
            valid_scores.append(score)
        
        # valid atk
        total_dmg, atk_info = self.get_total_dmg(my_pos,noblink=True,all_alive=True)
        if len(atk_info)>0:
            atk_extra_score = self.get_atk_extra_score(my_pos)
            stay_move_score = self.get_move_score(my_pos, move_target, target_dis_dict, atk_extra_score)
            
            for iop in atk_info:
                # 补刀有0.25分,攻击1.0分，加起来不要超过2.0分
                if self.all_players[iop].hp<70.001:
                    atk_score = 1.5
                else:
                    atk_score = 1.0
                score = atk_extra_score + stay_move_score + atk_score
                valid_acts.append({'type':'attack','target':iop})
                valid_scores.append(score)
        
        if self.player.tools.transport>0:
            # valid blink atk，使用blink 有1.1的减分，避免可以攻击也使用blink
            # 要保证 atk_score > -blink_score > target_score
            for pos in neighbors:
                if self.pos_equal(pos, self.my_pos):continue
                total_dmg, atk_info = self.get_total_dmg(pos, noblink=True, all_alive=True)
                self.print_line(['blinkattackcheck', pos, atk_info])
                if len(atk_info)>0:
                    atk_extra_score = self.get_atk_extra_score(pos)
                    move_score = self.get_move_score(pos, move_target,target_dis_dict,atk_extra_score)
                    for iop in atk_info:
                        # 补刀有0.25分,攻击1.0分，加起来不要超过2.0分
                        if self.all_players[iop].hp<70.001:
                            atk_score = 1.5
                        else:
                            atk_score = 1.0
                        score = atk_extra_score + move_score + atk_score
                        valid_acts.append({'type':'blink_attack','blink_pos':pos,'target':iop})
                        valid_scores.append(score)
                 
        # use_kit
        if mode=='emer_flag':
            hp_line = 140.01
        else:
            hp_line = 189.99
        if self.player.tools.kit>0 and self.player.hp<hp_line:
            # 医疗包使用要超过2.0覆盖一次攻击 ，又不能承受两次攻击
            #（如果n_suffer+2的话3.0分，如果+1就0.5分吧）
            atk_extra_score = self.get_atk_extra_score(my_pos)
            stay_move_score = self.get_move_score(my_pos, move_target,target_dis_dict,atk_extra_score)
            myhp = self.player.hp
            after_hp = min(200.0, myhp+100)
            kit_delta = self.get_n_suffer(after_hp, 70.0) - self.get_n_suffer(myhp)
            if kit_delta==0:
                suffer_score = 0.0
            elif kit_delta==1:
                suffer_score = 0.5
            elif kit_delta==2:
                suffer_score = 3.0
            kit_score = atk_extra_score+stay_move_score+suffer_score
            valid_acts.append({'type':'use_kit'})
            valid_scores.append(kit_score)
        
        # pick best act
        if len(valid_acts)==0:
            return acts
        irange = list(range(len(valid_acts)))
        ipick= max(irange, key=lambda x:valid_scores[x])
        acts.append(valid_acts[ipick])
        self.print_line('valid act info >>')
        self.print_line(valid_acts)
        self.print_line(valid_scores)
        
        # luankan
        # try attack invisi
        # if self.acted:return acts #这里不能先return，先乱砍先。
        if not dangerous and (not 2 in dead_status):
            # self.print_line('in')
            neighbors = self.get_neighbors(self.my_pos)
            # self.print_line(neighbors)
            luankan_poses = [self.my_pos]+[list(p) for p in neighbors]
            # luankan_poses = [[4,2,0],[3,2,0],[2,2,0],[3,3,0],[4,4,0],[3,4,0],[2,4,0]]
            # self.print_line(luankan_poses)
            for i in range(4):
                if i==self.my_id:continue
                # if self.all_players[i].status==1 or self.all_players[i].status==2:continue
                for pos in luankan_poses:
                    # self.print_line(pos)
                    reply = self.attack(pos,i)
                    # self.print_line(reply)
                    if reply["success"]:
                        self.acted=True
                        break
                if self.acted:
                    break
        # 
        # if not self.acted and not move_target is None:
            # acts.append({'type':'move','pos':move_target})
        return acts
    
    def pos_in_list(self, pos, l):
        for p in l:
            # self.print_line([pos, l])
            if self.pos_equal(pos, p):
                return True
        return False
    
    def cnt_be_attack(self, my_id, pos, can_move_list):
        cnt = 0
        atk_info = []
        for i in range(4):
            if i==my_id:continue
            # self.print_line([i,pos,can_move_list[i]])
            # if pos in can_move_list[i]:
            if self.pos_in_list(pos, can_move_list[i]):
                cnt+=1
                atk_info.append(i)
        # self.print_line(atk_info)
        return cnt, atk_info
    
    def get_total_dmg(self, pos, noblink=False, all_alive=False):
        # all_alive, 所有活着的状态，即排除1和2
        can_move_list = [[],[],[],[]]
        can_blink_move_list = [[],[],[],[]]
        connection = self.map.connection
        delta = self.map.delta
        atk_info = []
        for i, player in enumerate(self.all_players):
            if not all_alive:
                if (player.status>0):continue
            else:
                #if player.status>3:raise 4应该是开始跑
                self.print_line(player.status)
                if player.status==1 or player.status==2:continue
            op_pos = player.pos
            x,y,z = op_pos
            len_delta = connection.shape[3]
            for idelta in range(len_delta):
                if connection[z,y,x,idelta]!=1:continue
                xx = x + delta[idelta][0]
                yy = y + delta[idelta][1]
                zz = z + delta[idelta][2]
                can_move_list[i].append([xx,yy,zz])
                for idelta in range(len_delta):
                    if connection[zz,yy,xx,idelta]!=1:continue
                    xxx = xx + delta[idelta][0]
                    yyy = yy + delta[idelta][1]
                    zzz = zz + delta[idelta][2]
                    can_blink_move_list[i].append([xxx,yyy,zzz])
        
        # self.print_line(pos)
        # self.print_line(can_move_list)
        # self.print_line(can_blink_move_list)
        cnt_attacked, atk_info = self.cnt_be_attack(self.my_id, pos, can_move_list)
        # self.print_line(atk_info)
        cnt_blink_attacked, blink_atk_info = self.cnt_be_attack(self.my_id, pos, can_blink_move_list)
        # self.print_line(['atkinfo', atk_info])
        merge_atk_info = []
        for i in range(4):
            if i==self.my_id:continue
            if i in atk_info:
                merge_atk_info.append(i)
            if not noblink and self.strength_list[i]>0:
                if i in blink_atk_info:
                    merge_atk_info.append(i)
        # self.print_line(['cnt_be_attack',cnt_attacked,pos])
        # self.print_line(['merge_atkinfo', merge_atk_info])
        return 70.0*cnt_attacked, merge_atk_info
        
    
    def select_mine_pos(self):
        valid_mine_poses = []
        for mine_pos in self.mine_poses:
            put_flag = False
            for put_pos in self.player.tools.landmine_pos:
                if self.pos_equal(put_pos, mine_pos):
                    put_flag=True
                    break
            if not put_flag:
                valid_mine_poses.append(mine_pos)
        self.print_line('valid_mine_poses:'+str(valid_mine_poses))
        if len(valid_mine_poses)>0:
            return valid_mine_poses[0]
        else:
            return None
    
    def judge_close_key(self):
        key_target = self.find_key_target(safe=True)
        close_key = False
        if not key_target is None:
            key_pos_key = self.lt2key(key_target)
            close_key_dis = self.all_noblock_distance_dict[self.my_id][key_pos_key]
            if close_key_dis<=2:
                no_near_key=True
        return close_key
    
    def judge_rascal(self):
        rascal_flag = False
        emer_flag = False
        return_flag = False
        my_key_num = len(self.player.keys)
        self_all_key = my_key_num>=4
        cnt_op_adv = 0
        for i, player in enumerate(self.all_players):
            if i==self.my_id:continue
            op_key_num = len(player.keys)
            if op_key_num>=4 and not self_all_key and not self.judge_close_key():
                rascal_flag=True
                emer_flag=True
                self.print_line("in op all key rascal")
                return_flag = True
            if op_key_num>my_key_num:cnt_op_adv+=1
        if cnt_op_adv>0:
            self.one_op_adv+=1
        else:
            self.one_op_adv=0
        
        if not return_flag:
            if cnt_op_adv>1:
                close_key = self.judge_close_key() 
                if not close_key:
                    rascal_flag=True
                    emer_flag=False
                    self.print_line("close key:"+str(close_key))
                    self.print_line("in 有两人优势 rascal")
                    return_flag=True
        
        if not return_flag:
            if self.one_op_adv>4:
                rascal_flag=True
                emer_flag=False
                self.print_line("in 有人长时间领先 rascal")
        if emer_flag:
            self.print_line('emergent rascal!')
        return rascal_flag, emer_flag # to remove!
            
    def implement_action(self,acts):
        for act in acts:
            if act['type']=='move':
                pos = act['pos']
                self.make_move_pos(pos)
            elif act['type']=='attack':
                target = self.all_players[act['target']]
                self.atk_func(target)
            elif act['type']=='blink_attack': 
                # attack也可以blink，区别在于这个可以指定pos
                blink_pos = act['blink_pos']
                target = act['target']
                target_pos = self.all_players[target].pos
                self.blink_attack(blink_pos, target_pos, target)
            elif act['type']=='use_kit':
                self.use_tool("Kit")
            elif act['type']=='get_box':
                self.interact("Box")
            elif act['type']=='get_key':
                self.use_keymachine()
            elif act['type']=='get_mat':
                self.get_tools()
            elif act['type']=='get_rascal_mat':
                self.get_tools(rascal=True)
            elif act['type']=='escape':
                if self.interact("EscapeCapsule",1)["success"]:
                    self.escaping=True
            elif act['type']=='put_mine':
                self.print_line(self.player.tools.landmine_pos)
                self.put_trap('LandMine')
            elif act['type']=='put_sticky':
                self.print_line(self.player.tools.sticky_pos)
                self.put_trap('Sticky')
                
    def update_info(self):
        self.map.update_map(self.state)
        self.my_pos = self.get_my_pos()
        my_pos = self.my_pos
        self.my_id = self.get_my_num()
        my_id = self.my_id
        # update sticky pos
        if self.state>49:
            self.sticky_poses = [[3,2,0],[3,4,0]]
        valid_sticky_poses = [pos for pos in self.sticky_poses if not pos in self.player.tools.sticky_pos]
        if self.now_sticky_pos == None or not self.now_sticky_pos in valid_sticky_poses:
            len_valid = len(valid_sticky_poses)
            if len_valid>0:
                irand = np.random.randint(len_valid)
                self.now_sticky_pos = valid_sticky_poses[irand]
            else:
                self.now_sticky_pos = None
        # escaping 怎么写呢？看后面情况。
        if self.pos_equal(my_pos,[3,3,0]):
            self.at_escape_pos = True
        else:
            self.at_escape_pos = False
            self.escaping = False
        #
        self.strength_list[self.get_my_num()] = self.player.tools.transport
        # update all players
        self.last_all_players = copy.deepcopy(self.all_players)
        self.all_players[self.player.id] = copy.deepcopy(self.player)
        for other in self.others:
            self.all_players[other.id] = copy.deepcopy(other)
        
        for i, player in enumerate(self.all_players):
            if player.pos[2]!=my_pos[2]:
                self.all_players[i].pos = [-1,-1,-1]
                
        for i, player in enumerate(self.all_players):
            if player.pos[0]==-1:
                self.unseen_cnt[i]+=1
            else:
                self.unseen_cnt[i]=0
            if self.unseen_cnt[i]>5:
                self.strength_list[i]=1
                
        # forward mat_state
        if self.state>1:
            self.forward_mat()
        # detect item use
        self.print_line('This Round OffMsg >>>')
        self.print_line(self.off_msg_rec)
        # for 
        for pid in range(4):
            if pid==self.my_id:continue
            p_off_msgs = [msg for msg in self.off_msg_rec if msg["playerid"]==pid]
            move_msgs = [msg for msg in p_off_msgs if msg['content'][0]=='see' and msg['content'][1]=='pos_update']
            move_msgs = [msg for msg in move_msgs if msg['content'][2][0]!=-1]
            attack_msgs = [msg for msg in p_off_msgs if msg['content'][0]=='see' and msg['content'][1]=='attacking']
            if len(move_msgs)>1 or (len(move_msgs)>0 and len(attack_msgs)>0):
                self.strength_list[pid] = max(0, self.strength_list[pid]-1)
        
        if True in self.kit_used:
            self.print_line("use kit detected! "+str(self.kit_used))
            self.strength_list[pid] = max(0, self.strength_list[pid]-1)
        self.off_msg_rec = []
        self.kit_used = [False, False, False, False]
        
        # init distance dict
        all_players = self.all_players
        player_q = 0
        all_distance_dict = []
        all_next_dict = []
        all_noblock_distance_dict = []
        all_noblock_next_dict = []
        # self.print_line(self.strength_list)
        for i, player in enumerate(all_players):
            blocks = []
            for j, other in enumerate(all_players):
                if j==i:continue
                if other.status>0:continue
                other_pos = other.pos
                if other_pos[0]!=-1:
                    player_n_suffer = self.get_n_suffer(player.hp)
                    other_n_suffer = self.get_n_suffer(other.hp)
                    if player_n_suffer<=other_n_suffer:
                        blocks.append(other_pos)
                        if self.player.hp<=140 or self.strength_list[j]>0:
                            other_neighbors = self.get_neighbors(other_pos)
                            for p in other_neighbors:
                                blocks.append(p)
            distance_dict, next_dict = self.get_distance_dict(blocks, pos=player.pos)
            # self.print_line("distance dict %d"%i)
            # self.print_line(distance_dict)
            all_distance_dict.append(distance_dict)
            all_next_dict.append(next_dict)
            noblock_distance_dict, noblock_next_dict = self.get_distance_dict(pos=player.pos)
            all_noblock_distance_dict.append(noblock_distance_dict)
            all_noblock_next_dict.append(noblock_next_dict)
            if player.id==my_id:
                self.distance_dict = distance_dict
                self.next_dict = next_dict
                self.no_block_distance_dict, self.no_block_next_dict = self.get_distance_dict(pos=player.pos)
        self.all_distance_dict = all_distance_dict
        self.all_next_dict = all_next_dict
        self.all_noblock_distance_dict = all_noblock_distance_dict
        self.all_noblock_next_dict = all_noblock_next_dict 
        # update self valid mat_poses (need all_distance_dict)
        self.mat_poses_valid_keys = self.get_mat_poses_valid_keys()    
        
    def forward_mat(self):
        # watch other player pick
        for i in range(4):
            if i==self.my_id:continue
            if self.all_players[i].status==1:continue
            pos = self.all_players[i].pos
            last_pos = self.last_all_players[i].pos
            if (not self.pos_equal(pos, last_pos)) or pos[0]==-1:continue
            # self.print_line('lastpossame:'+str(i)+' '+str(pos)+str(last_pos)+' '+str(pos!=last_pos))
            if not pos in self.map.material_poses:continue
            # self.print_line(str(pos)+' in '+str(self.map.material_poses))
            if self.last_attack_flags[i]:continue
            pos_key = self.lt2key(pos)
            if self.mat_num[pos_key]<1:continue
            # self.print_line(str(i)+' '+str(pos)+' '+str(last_pos))
            self.strength_list[i]=min(2,self.strength_list[i]+1)
            self.mat_num[pos_key]-=1
        
        for pos in self.map.material_poses:
            pos_key = self.lt2key(pos)
            if self.mat_num[pos_key]<2:
                self.mat_cd[pos_key]-=1
                if self.mat_cd[pos_key]<0:
                    self.mat_num[pos_key]+=1
                    self.mat_cd[pos_key]=8
    
    def get_mat_poses_valid_keys(self):
        # 不会被攻击到的地方就是valid mat pos
        keys = []
        mat_poses = copy.deepcopy(self.map.material_poses)
        for mat_pos in mat_poses:
            pos_key = self.lt2key(mat_pos)
            flag = True
            for i, player in enumerate(self.all_players):
                if i==self.my_id:continue
                if player.status==1:continue
                atk_dis = 1+ (self.strength_list[i]>=1)
                
                if self.all_distance_dict[i].get(pos_key,99)<=atk_dis:
                    # self.print_line("valid_info")
                    # self.print_line(str(i)+' '+str(self.all_distance_dict[i][pos_key]))
                    # self.print_line(pos_key)
                    # self.print_line(atk_dis)
                    self.print_line(['validinfo',i,player.status,pos_key,self.all_distance_dict[i][pos_key]])
                    flag=False
                    break
            if flag:
                keys.append(pos_key)
        self.print_line("validkeys:"+str(keys))
        return keys

    def get_distance_dict(self, blocks=[], pos=None):
        if pos is None:
            src_pos = self.my_pos
        else:
            src_pos = pos
        dis_dict = {}
        next_dict = {}
        if not src_pos[0]==-1:
            pos_key = self.lt2key(src_pos)
            dis_dict[pos_key] = 0
            lopen = [src_pos]
            q = 0
            while q<len(lopen):
                now_pos = lopen[q]
                now_pos_key = self.lt2key(now_pos)
                d = dis_dict[now_pos_key]
                neighbors = self.get_neighbors(now_pos)
                for p in neighbors:
                    p_key = self.lt2key(p)
                    if p_key in dis_dict:continue
                    if p in blocks:continue
                    if now_pos_key in next_dict:
                        next_dict[p_key] = next_dict[now_pos_key]
                    else:
                        next_dict[p_key] = p
                    dis_dict[p_key] = d+1
                    lopen.append(p)
                q+=1

        for x in range(7):
            for y in range(7):
                for z in range(3):
                    vpos = [x,y,z]
                    vpos_key = self.lt2key(vpos)
                    if not vpos_key in dis_dict:
                        dis_dict[vpos_key]=99
                        next_dict[vpos_key] = src_pos
        return dis_dict, next_dict

    def get_tools(self, rascal=False):
        # if self.player.hp<200 and self.player.tools.kit<1:
        if self.player.tools.kit<1:
            self.view_box("Materials","Kit")
        # elif self.player.tools.transport<2:
        else:
            if rascal==False:
                if self.player.tools.transport<2:
                    self.view_box("Materials", "Transport")
            else:
                if self.player.tools.transport<1:
                    self.view_box("Materials", "Transport")
                elif self.player.tools.sticky_number[0]<2:
                    self.view_box("Materials", "Sticky")
                elif self.player.tools.landmine_number[0]<2:
                    self.view_box("Materials", "LandMine")
    
    def get_see_others(self):
        see_others = []
        for i, p in enumerate(self.all_players):
            if i==self.my_id:continue
            pos_key = self.lt2key(p.pos)
            if (p.pos[0]!=-1) and p.hp>140 and self.strength_list[i]>0 and self.all_noblock_distance_dict[self.my_id][pos_key]<=5:
                see_others.append(i)
        return see_others
    
    def get_neark_mat_poses(self, pid, neark=3,use_valid=True, other_layer=False):
        mat_poses = copy.deepcopy(self.map.material_poses)
        if other_layer:
            mat_poses = [mat_pos for mat_pos in mat_poses if mat_pos[2]!=self.my_pos[2]]
        else:
        # 这里默认就以安全的方式找资源。
            now_layer = self.player.pos[2]
            see_others = self.get_see_others()
            if len(see_others)>1:
                mat_poses = [mat_pos for mat_pos in mat_poses if mat_pos[2]!=self.my_pos[2]]
            else:
                mat_poses = [mat_pos for mat_pos in mat_poses if mat_pos[2]==self.my_pos[2]]
        # self.print_line(self.mat_poses_valid_keys)
        if use_valid:
            l = len(mat_poses)
            mat_poses = [mat_poses[i] for i in range(l) if self.lt2key(mat_poses[i]) in self.mat_poses_valid_keys]

        # self.print_line("mat_poses_after_valid:"+str(mat_poses))
        mat_poses = [pos for pos in mat_poses if self.mat_num[self.lt2key(pos)]>=1]
        mat_poses = sorted(mat_poses, key=lambda x:self.all_distance_dict[pid].get(self.lt2key(x),99))
        mat_poses = mat_poses[:neark]
        return mat_poses

    def find_mat_target(self, other_layer=False):
        mat_target = None
        my_id = self.my_id
        all_players = self.all_players
        all_distance_dict = self.all_distance_dict
        if self.player.hp>140:
            mat_poses = self.get_neark_mat_poses(my_id, neark=3, use_valid=False, other_layer=other_layer)
        else:
            mat_poses = self.get_neark_mat_poses(my_id, neark=3, use_valid=True, other_layer=other_layer)
        self.print_line("in find mat mat_poses:"+str(mat_poses))
        # select a target mat    
        # self.print_line(all_distance_dict)
        for mat_pos in mat_poses:
            mat_pos_key = self.lt2key(mat_pos)
            mat_advantages = []
            for j, player in enumerate(all_players):
                if j==my_id:continue
                # self.print_line(all_distance_dict[j])
                mat_advantage = all_distance_dict[j].get(mat_pos_key,99) - all_distance_dict[my_id].get(mat_pos_key,99) +\
                    (self.strength_list[my_id]>=1) - (self.strength_list[j]>=1)
                mat_advantages.append(mat_advantage)
            self.print_line([mat_pos, mat_advantages])
            min_adv = min(mat_advantages)
            # self.print_line(str(mat_pos)+" "+str(min_adv))
            if min_adv>=2:
                mat_target = mat_pos
                break
            if min_adv>=-1 and mat_target is None:
                mat_target = mat_pos
        return mat_target
    
    def find_key_target(self, safe=False, only_zero=False):
        all_key_poskeys = []
        key_scores = []
        keys = list(self.get_keys())
        
        if only_zero:
            valid_layer=[0]
        else:
            if safe:
                now_layer = self.player.pos[2]
                see_others = self.get_see_others()
                if len(see_others)>1:
                    valid_layer = [1 if now_layer==2 else 2]
                else:
                    valid_layer = [now_layer]
            else:
                valid_layer = [1,2]
        
        sys.stderr.write('{}\n'.format(valid_layer))
        if len(keys)==4:
            all_key_poskeys.append(self.lt2key([3,3,0]))
            key_scores.append(999.9)
        else:
            for i in range(4):
                if not i in keys:
                    pos =  self.get_spawn_pos(i)
                    if pos[2] in valid_layer:
                        pos_key = self.lt2key(pos)
                        all_key_poskeys.append(pos_key)
                        d = self.distance_dict[pos_key]
                        key_scores.append(1.0/max(d,0.1))
                    pos = (pos[0], pos[1], pos[2] + 1)
                    if pos[2] in valid_layer:
                        pos_key = self.lt2key(pos)
                        all_key_poskeys.append(pos_key)
                        d = self.distance_dict[pos_key]
                        key_scores.append(1.0/max(d,0.1))
            for pos_key, box_keys in self.view.box_keys.items():
                pos = self.key2lt(pos_key)
                
                if not pos in valid_layer:continue
                x,y,z=pos
                if self.map.forbid_round[z,y,x]<=self.state:continue
                base = 0.0
                for box_key in box_keys:
                    if not box_key in keys:
                        base+=1.0
                all_key_poskeys.append(pos_key)
                d = self.distance_dict[pos_key]
                key_scores.append(base/max(d,0.1))
        len_poskeys = len(all_key_poskeys)
        sys.stderr.write('{}\n'.format(all_key_poskeys))
        sys.stderr.write('{}\n'.format(key_scores))
        if len_poskeys==0:
            return None
        else:
            max_i = max(range(len_poskeys), key=lambda x:key_scores[x])
            key_target = self.key2lt(all_key_poskeys[max_i])
            return key_target

    def make_move_pos(self,pos):
        move_dict, move_next_dict = self.get_distance_dict(pos=self.player.pos) # 不带block的move
        next_p = move_next_dict.get(self.lt2key(pos),None)
        if not next_p is None:
            self.move(next_p)
        return
    
    def blink_attack(self, blink_pos, pos, player_id):
        self.use_tool("Transport",blink_pos)
        self.attack(pos, player_id)
        
    def atk_func(self, atk_target):
        i = atk_target.id
        move_distance_dict, move_next_dict = self.get_distance_dict(pos=self.player.pos) # 不带block的move
        target_pos = atk_target.pos
        target_pos_key = self.lt2key(target_pos)
        to_other_dis = move_distance_dict[target_pos_key]
        if to_other_dis <=1:
            # self.print_line('ping a:'+str([target_pos, i]))
            self.attack(target_pos, i)
        else:
            blink_pos = move_next_dict[target_pos_key]
            self.blink_attack(blink_pos, target_pos, i)
    
    def check_get_box(self):
        my_pos = self.my_pos
        my_keys = list(self.get_keys())
        get_box_flag = False
        my_pos_key = self.lt2key(my_pos)
        if my_pos_key in self.view.box_keys:
            keys = self.view.box_keys[my_pos_key]
            for key in keys:
                if not key in my_keys:
                    get_box_flag = True
        else:
            get_box_flag=False
        return get_box_flag
    
    def check_get_key(self):
        my_pos = self.my_pos
        keys = list(self.get_keys())
        get_key_flag = False
        for i in range(4):
            if i in keys:continue
            pos = self.get_spawn_pos(i)
            if self.pos_equal(my_pos, pos):
                get_key_flag = True
                break
            pos = [pos[0],pos[1],pos[2]+1]
            if self.pos_equal(my_pos, pos):
                get_key_flag = True
                break
        return get_key_flag
    
    def use_keymachine(self):
        self.interact("KeyMachine")
    
    def pos_equal(self, pos0, pos1):
        return (pos0[0]==pos1[0]) and (pos0[1]==pos1[1]) and (pos0[2]==pos1[2])

if __name__=="__main__":
    c = MyClient(print_flag=True)
    c.run()
    
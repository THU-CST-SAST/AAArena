//#include"sdk_AI_Client.hpp"
#include"ai_client.h"
#include<stack>
#include<string>
#include<cmath>
#include<algorithm>
#include<fstream>
using namespace std;

void tst(Pos &x,AI_Client &client)
{
    string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);
    fout<<std::get<0>(x)<<' '<<std::get<1>(x)<<' '<<std::get<2>(x)<<' ';
    fout<<endl;
}

struct strategy
{
    int type=0,value1=0,value2=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离 8:捡箱子
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

/*bool opeartor!=(const Pos &a,const Pos &b){
    return std::get<0>(a)!=std::get<0>(b)||std::get<1>(a)!=std::get<1>(b)||std::get<2>(a)!=std::get<2>(b);
}*/

//typedef std::tuple<int, int, int> Pos;
//typedef std::map<std::string, std::vector<std::vector<int>>> Trapbag;
Pos curPos;
int myID,T,escaped[133];
Tool myInventory;
stack<strategy> strategyList;
vector<int> keys;
int abort_strategy[10]={0};
vector<Pos> temp[133];

int qryT(AI_Client& client, Pos x)
{
    return client.pos2node(x).block_turn;
}

bool btx(AI_Client& client, Pos x){
    if(T>=qryT(client,x))return 1;
    if(T+1==qryT(client,x)){
        vector<Pos> neighbors=client.get_neighbors(x);
        for(int i=0;i<neighbors.size();i++)
            if(qryT(client,neighbors[i])>T+1)return 0;
        return 1;
    }
    return 0;
}

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

int dis(Pos s,Pos t,AI_Client& client)
{
    auto tmp=client.find_shortest_path(s,t);
    return tmp.empty()?0:tmp.size()-1;
}

pair<int,int> getnearest(Pos curPos, AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1;
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        Pos tar=client.get_spawn_pos(i);
        j=dis(curPos,tar,client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
        std::get<2>(tar)++;
        j=dis(curPos,tar,client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    for(Pos tar:temp[T]){
        j=dis(curPos,tar,client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=1e9;//掉落物
        }
    }
    if(closestSpawn==-1)//已获得所有密钥
    {
        minDis=dis(curPos,client.get_escape_pos(),client);
    }
    int res=0;
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0||client.get_player_copy(i).status!=ALIVE&&client.get_player_copy(i).status!=SKIP)
            continue;
        bool slash=client.get_others_hp(i)-client.get_player_hp()>0||client.get_player_hp()<=70;
        //bool slash=ceil(client.get_others_hp(i)/70.0)>=ceil(client.get_player_hp()/70.0);
        slash|=std::get<2>(curPos)==0&&ceil(client.get_others_hp(i)/70.0)>=ceil(client.get_player_hp()/70.0);
        if((isConnected(otherPos ,curPos,client)||client.get_player_copy(i).toolbag.blinks_num&&dis(curPos,otherPos,client)<=2)&&slash)
            res++;
        if(otherPos==curPos&&slash)//重合也太自闭了吧！
            res++;
    }
    return make_pair(res,minDis*100-client.get_neighbors(curPos,1).size());
}//边上会被几个人打；离目标最短距离；度数（越大越好）

void reroute(AI_Client& client)//决定下一步前进的方向
{
    pair<int,int> res=getnearest(curPos,client);
    Pos tmp=curPos;
    if(btx(client,curPos))res=make_pair(1e9,1e9);
    vector<Pos> neighbors=client.get_neighbors(curPos,1);
    cerr<<"------------------------------------\n";
    cerr<<res.first<<' '<<res.second<<endl;
    for(auto x:neighbors)if(!btx(client,x)){
        if(!btx(client,x)&&getnearest(x,client)<=res)
            res=getnearest(x,client),tmp=x;
        auto tmpp=getnearest(x,client);
        cerr<<std::get<0>(x)<<' '<<std::get<1>(x)<<' '<<std::get<2>(x)<<' '<<tmpp.first<<' '<<tmpp.second<<endl;
    }
    strategyList.push(0);
    strategyList.top().dst=tmp;
}

string getFirstTrap()
{
    if(myInventory.trapbag["LandMine"][0][0])
        return "LandMine";
    if(myInventory.trapbag["Sticky"][0][0])
        return "Sticky";
    return "None";
}

string nextToInspect(Tool &inventory)
{
    if(inventory.kits_num<2) //拿满医疗包
        return "Kit";
    if(inventory.blinks_num<2) //优先拿满闪现
        return "Transport";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    return "Sticky";
}

map<Pos,int>Map;

void decideStrategy(AI_Client& client)//检查当前策略是否需要更换
{
    int i,j;
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/

    /*if(T==qryT(client,curPos)){
        vector<Pos> neighbors=client.get_neighbors(curPos);
        for(int i=0;i<neighbors.size();i++)
            if(qryT(client,neighbors[i])>T){
                strategyList.push(strategy(0));
                strategyList.top().dst=neighbors[i];
            }
        return;
    }*/
    if(escaped[T-1]){//我别无选择！
        strategyList.push(7);
        return;
    }

    int cnt=0;
    vector<int> nei;
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0||client.get_player_copy(i).status!=ALIVE&&client.get_player_copy(i).status!=SKIP)
            continue;
        if(isConnected(otherPos ,curPos,client)||client.get_player_copy(i).toolbag.blinks_num&&dis(curPos,otherPos,client)<=2)
            cnt++,nei.push_back(i);
    }

    if(cnt){
        if(cnt==1&&ceil(client.get_others_hp(nei[0])/70.0)<=ceil(client.get_player_hp()/70.0)&&(client.get_others_hp(nei[0])<=140||!client.get_player_copy(nei[0]).toolbag.kits_num)){
            strategy tmp(1);
            tmp.value1=nei[0];
            tmp.dst=client.get_others_pos(nei[0]);
            strategyList.push(tmp);
            if(client.get_others_hp(nei[0])<=70&&find(keys.begin(),keys.end(),nei[0])==keys.end()){
                temp[T+1].push_back(tmp.dst);
                temp[T+2].push_back(tmp.dst);
            }
            return;
        }
        if(cnt==1&&myInventory.kits_num&&!client.get_player_copy(nei[0]).toolbag.kits_num&&ceil(client.get_others_hp(nei[0])/70.0)<=ceil((min(client.get_player_hp()+100,200)-70)/70.0)){//补血，干他！
            strategyList.push(strategy(3));
            return;
        }
        reroute(client);
        return;
    }

    if(curPos==client.get_escape_pos() && client.get_keys().size()==4)//已到达逃离位置且集齐密钥，可以撤离
    {
        if(client.get_player_hp()<=100 && myInventory.kits_num && !escaped[T-1])//在低生命值时治疗自己
        {
            strategyList.push(strategy(3));
            return;
        }
        if(!(client.get_player_hp()<=140 && !escaped[T-1] && cnt)){//有可能很虚啊，再看看。（逃离/开枪？）
            strategyList.push(7);
            return;
        }
    }

    

    if(client.get_player_hp()<=70 && myInventory.kits_num)//在生命值太低时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

    for(i=0;i<4;i++)
    {
        Pos tar=client.get_spawn_pos(i);
        Pos tar2=tar;std::get<2>(tar2)++;
        if(find(keys.begin(),keys.end(),i)==keys.end() && (curPos==tar||curPos==tar2))
        {
            strategyList.push(6);
            return;
        }
    }
    
    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos));
    if(val.first&&(val.second[0]=="Box"||val.second.size()==2&&val.second[1]=="Box"))//当前位置可以拾取箱子
    {
        strategyList.push(strategy(8));
        return;
    }

    /*if(!strategyList.empty() && strategyList.top().type==0 && strategyList.top().dst==curPos)//已经到达目标地点，结束移动
        {while(!strategyList.empty())strategyList.pop();decideStrategy(client);return;}

    if(!strategyList.empty() && strategyList.top().type==2)//当前策略为逃跑
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        if(std::get<0>(otherPos)<0 || dis( otherPos ,curPos,client)>2 || client.get_player_copy(strategyList.top().value1).status!=ALIVE)
            //和敌人的距离足够远或失去敌人视野时停止
            {while(!strategyList.empty())strategyList.pop();decideStrategy(client);return;}
        else
            return;//继续
    }*/

    if(client.get_player_hp()<=100 && myInventory.kits_num)//在低生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

    /*if(!strategyList.empty() && strategyList.top().type==1)//当前策略为进攻
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        //tst(otherPos,client);
        if(std::get<0>(otherPos)<0 ||  dis( otherPos ,curPos,client)>2 
                || (strategyList.top().value2<0))
            //和敌人的距离足够远、敌人离开视野或追击时间过长时停止
            {while(!strategyList.empty())strategyList.pop();decideStrategy(client);return;}
        else if(client.get_others_hp(strategyList.top().value1)>0)//追击目标存活，继续
        {
            if(client.get_others_hp(strategyList.top().value1)>120)//若目标生命值较高，则减少追击权重
                strategyList.top().value2--;
            else if(client.get_others_hp(strategyList.top().value1)<=70)//若目标为残血，增加追击权重
                strategyList.top().value2++;
            strategyList.top().dst=otherPos;//更新敌人位置
            return;
        }
        else 
        { //目标已死亡，前去收集掉落物品
            strategyList.pop();
            if(curPos!=otherPos){
                strategy tmp(0);
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return;
            }
            decideStrategy(client);return;
            //strategyList.pop();
        }
    }
    
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0||client.get_player_copy(i).status!=ALIVE)
            continue;
        if(isConnected(otherPos ,curPos,client))
        {
            if(client.get_player_hp()-client.get_others_hp(i)>70&&find(keys.begin(),keys.end(),i)==keys.end())//自身生命值更高，前去追击
            {
                strategy tmp(1);
                tmp.value1=i;
                tmp.value2=2;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return;
            }
            else if(client.get_others_hp(i)-client.get_player_hp()>50||client.get_player_hp()<=70)//自身生命值更低，尝试逃跑
            {
                strategy tmp(2);
                tmp.value1=i;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return;
            }
        }
    }

    if(client.get_player_hp()<=100 && myInventory.kits_num)//在损失生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }*/

    if((client.get_player_hp()<200||client.get_tools().kits_num<2)&&val.first&&val.second[0]=="Materials"&&(!Map[curPos]||Map[curPos]<=T-8)&&client.get_tools().kits_num<2)//当前位置可以拾取物品
    {
        strategyList.push(strategy(5));
        strategyList.top().item=nextToInspect(myInventory);
        return;
    }

    /*string item=getFirstTrap();
    if(item!="None")//物品栏中有陷阱
    {
        if(client.get_neighbors(curPos).size()>2 && !abort_strategy[2])//若当前位置度数>2，则放置陷阱
        {
            strategy tmp(4);
            tmp.item=item;
            strategyList.push(tmp);
            return;
        }
    }
    abort_strategy[2]=0;*/

    reroute(client);return; //无论如何，都从头再来吧。
    
    /*if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
        return;
    }

    if(strategyList.top().type==0 && dis( curPos,strategyList.top().dst,client )>5 
            && strategyList.top().dst!=client.get_escape_pos())//若当前策略为移动，且偏离路线过长，则重新规划路线
    {
        strategyList.pop();
        reroute(client);
        return;
    }*/
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos))//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
    return nullptr;
}

void play(AI_Client &client)
{
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/
    T=client.get_state();
    myID=client.get_id();
    curPos=client.get_player_pos();
    Node &curNode=client.pos2node(curPos);
    myInventory=client.get_tools();
    keys=client.get_keys();
    bool endTurn=false;
    decideStrategy(client);
    /*fout<< "type" << strategyList.top().type <<' '<<strategyList.top().item<<std::endl;
    fout<<"keys:";
    for(int i:keys)
        fout<<i<<' ';
    fout<<endl;
    tst(strategyList.top().dst,client);
    tst(curPos,client);*/
    //std::cerr << "type" << strategyList.top().type << ' ' <<  << std::endl;
    auto tmpp=getnearest(curPos,client);
    fprintf(stderr,"cur%d %d, type%d: %d %d %d %d %d %d | %d %d %d\n",T,myID,strategyList.top().type,std::get<0>(curPos),std::get<1>(curPos),std::get<2>(curPos),keys.size(),client.get_player_hp(),client.get_tools().kits_num,client.get_neighbors(curPos,1).size(),tmpp.first,tmpp.second);
    bool notyet=false;
    escaped[T]=0;
    switch (strategyList.top().type)
    {
        case 0://移动
        {
            Pos nextPos=strategyList.top().dst;//=client.find_shortest_path(curPos,strategyList.top().dst)[1];
            if(btx(client,nextPos)){notyet=1;break;}
            if(curPos!=nextPos){//可能不走
                Edge *tar=findEdge(curNode,nextPos);
                moveTo(tar,client);
            }
            endTurn=true;
            break;
        }
        case 1://攻击
        {
            if(isConnected(curPos,strategyList.top().dst,client))//能攻击到敌人
            {
                if(btx(client,curPos)){notyet=1;break;}
                client.attack(strategyList.top().dst,strategyList.top().value1);
            }
            else//不能攻击到敌人，尝试接近敌人
            {
                Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
                if(btx(client,nextPos)){notyet=1;break;}
                Edge *tar=findEdge(curNode,nextPos);
                moveTo(tar,client);
            }
            endTurn=true;
            break;
        }
        case 2://逃跑
        {
            //Pos banned=client.find_shortest_path(curPos,strategyList.top().dst)[1];//不能向敌人的方向跑
            vector<Pos> neighbors=client.get_neighbors(curPos);
            random_shuffle(neighbors.begin(),neighbors.end());
            bool ok=0;
            for(Pos nextPos:neighbors)
            {
                if(client.get_neighbors(nextPos).size()>1&&dis(curPos,strategyList.top().dst,client)<dis(nextPos,strategyList.top().dst,client)&&!btx(client,nextPos))//向任意不会遭遇敌人的方向逃跑
                {
                    Edge *tar=findEdge(curNode,nextPos);
                    moveTo(tar,client);
                    ok=1;
                    break;
                }
            }
            if(!ok){notyet=1;break;}
            endTurn=true;
            break;
        }
        case 3://治疗
        {
            if(btx(client,curPos)){notyet=1;break;}
            client.use_kit();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 4://放置陷阱
        {
            if(btx(client,curPos)){notyet=1;break;}
            if(!client.place_trap(strategyList.top().item))
                abort_strategy[2]=1;
            strategyList.pop();
            break;
        }
        case 5://拾取
        {
            if(btx(client,curPos)){notyet=1;break;}
            Map[curPos]=T;
            client.inspect_materials(strategyList.top().item);
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 6://获得密钥
        {
            if(btx(client,curPos)){notyet=1;break;}
            client.get_key();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 7://逃离
        {
            client.escape(true);
            endTurn=true;
            escaped[T]=1;
            break;
        }
        case 8://捡箱子
        {
            if(btx(client,curPos)){notyet=1;break;}
            client.inspect_box();
            strategyList.pop();
            endTurn=true;
            break;
        }
    }
    if(notyet){
        vector<Pos> neighbors=client.get_neighbors(curPos,1);
        sort(neighbors.begin(),neighbors.end(),[&](Pos a, Pos b){return getnearest(a,client)<getnearest(b,client);});
        for(int i=0;i<neighbors.size();i++)
            if(!btx(client,neighbors[i]))
            {
                Edge *tar=findEdge(curNode,neighbors[i]);
                moveTo(tar,client);
                endTurn=1;
                break;
            }
        endTurn=1; //不走！
    }
    if(endTurn)//若当前操作计入行动次数，则结束回合
    {
        //fout<<"finish"<<endl;
        client.finish();
    }
    else//若当前操作不计入行动次数，则可以继续行动
    {
        play(client);
    }
}


#include"ai_client.h"
#include<string>
#include<algorithm>
#include<fstream>
#include <utility>
#include <vector>
#include <cstring>
using namespace std;

vector<int> attack_ban;
bool stop = false;
bool abortStrategy[10];
int materials_used[7][7][7];
vector<Pos> toPick;


struct strategy
{
    int type=0,value1=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6:获得密钥 7:逃离 8:捡钥匙 9:不动
    Pos dst;
    string item;
    explicit strategy(int t):type(t){
        assert(t == 9 || t == 8 || t == 7 || t == 6 || t == 3);
    }
    strategy(int t, int value1):type(t), value1(value1){
        assert(t == 1 || t == 2);
    }
    strategy(int t, Pos dst):type(t), dst(std::move(dst)){
        assert(t == 0);
    }
    strategy(int t, string item):type(t), item(std::move(item)){
        assert(t == 5 || t == 4);
    }
} currentStrategy(9);

Pos curPos;
int myID;
Tool myInventory;
vector<int> keys;

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}


void deleteToPick(const Pos& pos){
    for (auto it = toPick.begin(); it != toPick.end();) {
        if (*it == pos) {
            it = toPick.erase(it);
        } else {
            ++it;
        }
    }
}

Pos LastPOS = Pos(-1, -1, -1);

void reroute(AI_Client& client)//决定下一步前进的方向
{
    cerr << "reroute start\n";

    Pos destination;
    int minDis=99,closestSpawn=-1;
    for(int i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        int j=dis(curPos,client.get_spawn_pos(i),client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        destination = client.get_spawn_pos(closestSpawn);

        if(!toPick.empty()){
            for(auto pos: toPick){
                if(dis(curPos, pos, client) <= 2){
                    destination = pos;
                    break;
                }
            }
        }
    }
    else//已获得所有密钥，前往逃离位置
    {
        destination = client.get_escape_pos();
    }

    
    vector<Pos> neighbors = client.get_neighbors(curPos, true);
    neighbors.push_back(curPos);
    typedef pair<double, Pos> pa;
    //分值越小越好 3 * dis(destination) + 1 * dis(materials) + aiLevel
    vector<pa> vec;

    for (auto pos : neighbors) {
        double score = 3 * dis(pos, destination, client) + 1 * dis(pos, client.get_closest_materials(pos), client);
        if(pos == LastPOS)score += 5;

        int aiScore = 0;
        for(int i = 0; i < 4; i++){
            if(i == client.get_id())continue;
            int d = dis(pos, client.get_others_pos(i), client);
            if(d < 2 || (d == 2 && client._player(i).aiLevel >= 7)){
                if(aiScore){
                    aiScore = 1000;
                    break;
                }

                if(d < 2 && client.get_attack_value(i) < 1){
                    aiScore = client._player(i).aiLevel;
                }
                else if(d == 2 && client._player(i).toolNum > 0 && client.get_attack_value(i) < 1){
                    aiScore = client._player(i).aiLevel * 2 / 3;
                }
            }
        }
        if(aiScore)aiScore = 3 * (aiScore - 4) * (aiScore - 3);
        vec.emplace_back(score + aiScore, pos);

        cerrPos(pos);
        cerr << score + aiScore << endl;
    }

    sort(vec.begin(), vec.end());
    currentStrategy = strategy(0, vec[0].second);


    cerr << "reroute end\n";
}


string getFirstTrap()
{
    if(myInventory.trapbag["LandMine"][0][0])
        return "LandMine";
    if(myInventory.trapbag["Sticky"][0][0])
        return "Sticky";
    return "None";
}

string nextToInspect(Tool &inventory)
{
    if(inventory.blinks_num<1)
        return "Transport";
    if(inventory.kits_num<1)
        return "Kit";
    if(inventory.blinks_num<2) //优先拿满闪现
        return "Transport";
    if(inventory.kits_num<2) //拿满医疗包
        return "Kit";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    return "Sticky";
}

void decideStrategy(AI_Client& client)
{
    cerr << "decideStrategy start\n";
    int i, tot = client.get_id_and_dis();
    
    if(currentStrategy.type==1)//当前策略为进攻
    {
        int enemy_id = currentStrategy.value1;
        Pos otherPos = client.get_others_pos(enemy_id);

        if (std::get<0>(otherPos) < 0 || dis(otherPos, curPos, client) > 2 || client.get_attack_value(enemy_id) < 0 ||
            client._player(enemy_id).status != ALIVE){
            //和敌人的距离足够远、敌人离开视野或打不过时停止
        }
        else if(dis(otherPos, curPos, client) == 2 && myInventory.blinks_num < (client.get_others_hp(enemy_id) - 1) / 70 + 1){
            //闪现不够 不追了
        }
        else if(dis(otherPos, curPos, client) == 2 && !client.worthAttack(enemy_id)){
            //不值得追 不追了
        }
        else if(client.get_others_hp(enemy_id)>0)//追击目标存活，继续
        {
            return;
        }
        else{
            cerr << "I dont know what happened." << endl;
        }
    }
    else if(currentStrategy.type==2)//当前策略为逃跑
    {
        int enemy_id = currentStrategy.value1;
        Pos otherPos=client.get_others_pos(enemy_id);

        if(std::get<0>(otherPos)<0 || dis( otherPos ,curPos,client) >= 2){
            //和敌人的距离足够远或失去敌人视野时停止
        }
        else if(client.get_others_hp(enemy_id)>0) //对面还活着，接着跑
        {
            return;
        }
        else{
            cerr << "I dont know what happened again." << endl;
        }
    }


    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        if(client._player(i).status != ALIVE)continue;

        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0)
            continue;

        if(isConnected(otherPos ,curPos,client))
        {
            if(client.get_attack_value(i) >= 0)//对拼能赢
            {
                currentStrategy = strategy(1, i);
                return ;
            }
            else
            {   //快跑
                currentStrategy = strategy(2, i);
                return;
            }
        }
    }

    if(client.get_player_hp()<=70 && myInventory.kits_num)//在损失生命值时治疗自己
    {
        currentStrategy = strategy(3);
        return;
    }


    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos));

    if(val.first)//当前位置可以拾取物品
    {
        for(const auto& x: val.second){
            if(x == InterpropsType.Box){
                currentStrategy = strategy(8);
                return;
            }
        }

        if(myInventory.blinks_num + myInventory.kits_num <= 2){
            for(const auto& x: val.second){
                if(x == InterpropsType.Materials  && client.pos2node(curPos).materials_cd >= 8){
                    currentStrategy = strategy(5, nextToInspect(myInventory));
                    return;
                }
            }
        }

    }
    else{
        deleteToPick(curPos);
    }

    for(i=0;i<4;i++)
    {
        if(find(keys.begin(),keys.end(),i)==keys.end() && curPos==client.get_spawn_pos(i))
        {
            currentStrategy = strategy(6);
            return;
        }
    }
    


    if(curPos==client.get_escape_pos() && client.get_keys().size()==4)//已到达逃离位置且集齐密钥，可以撤离
    {
        if(client.id_and_dis[0].second == 2 && client.get_player_hp() <= 140 && myInventory.kits_num){
            currentStrategy = strategy(3);
        }
        else{
            currentStrategy = strategy(7);
        }
        return;
    }

    string item=getFirstTrap();

    if(item!="None" && !abortStrategy[4])//物品栏中有陷阱
    {
        if(client.get_neighbors(curPos).size()>2)//若当前位置度数>2，则放置陷阱
        {
            currentStrategy = strategy(4, item);
            return;
        }
    }

    reroute(client);
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos))//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
    return nullptr;
}


void init(){
    memset(abortStrategy, 0, sizeof(abortStrategy));
}

void play(AI_Client &client)
{
    cerr << "\n\nround:" <<  client.get_state() << " id = " << client.get_id() << endl;
    init();
    client.analyze();

    cerr << "play start\n";
    myID=client.get_id();
    curPos=client.get_player_pos();
    Node &curNode=client.pos2node(curPos);
    myInventory=client.get_tools();
    keys=client.get_keys();
    
    cerrPos(curPos);

    int tot = client.get_id_and_dis();
    for(int i = 0 ; i < tot; i++){
        cerr << client.id_and_dis[i].first << " dis = " << client.id_and_dis[i].second << endl;
    }

    bool endTurn=false;

    while(!endTurn){
        decideStrategy(client);
        LastPOS = client.get_player_pos();
        std::cerr << "type" << currentStrategy.type << std::endl;

        switch (currentStrategy.type)
        {
            case 0://移动
            {
                cerrPos(currentStrategy.dst);

                if(curPos != currentStrategy.dst){
                    Edge *tar=findEdge(curNode, currentStrategy.dst);
                    if(tar)moveTo(tar,client);
                }
                endTurn=true;
                break;
            }
            case 1://攻击
            {
                currentStrategy.dst = client.get_others_pos(currentStrategy.value1);
                cerrPos(currentStrategy.dst);
                cerr << "enemy = " << currentStrategy.value1 << "\n";
                cerr << "dis = " << dis(curPos, currentStrategy.dst, client) << "\n";
                cerr << "blink = " << myInventory.blinks_num << "\n";
                if(isConnected(curPos,currentStrategy.dst,client))//能攻击到敌人
                {
                    cerr << "attack1\n";
                    client.attack(currentStrategy.dst,currentStrategy.value1);
                }
                else//闪现跟上
                {
                    cerr << "attack2\n";
                    Pos nextPos=client.find_shortest_path(curPos,currentStrategy.dst)[1];
                    cerrPos(nextPos);
                    client.blink(nextPos);
                    client.attack(currentStrategy.dst,currentStrategy.value1);
                }

                if(client._player(currentStrategy.value1).status == DEAD)//目标已死亡，前去收集掉落物品
                {
                    toPick.push_back(currentStrategy.dst);
                }
                endTurn=true;
                break;
            }
            case 2://逃跑
            {
                currentStrategy.dst = client.get_others_pos(currentStrategy.value1);
                cerrPos(currentStrategy.dst);
                Pos banned=curPos;
                if(dis(curPos, currentStrategy.dst, client) >= 1)
                    banned=client.find_shortest_path(curPos,currentStrategy.dst)[1];//不能向敌人的方向跑
                vector<Pos> neighbors=client.get_neighbors(curPos);
                for(Pos nextPos:neighbors)
                {
                    if(nextPos!=banned)//向任意不会遭遇敌人的方向逃跑
                    {
                        Edge *tar=findEdge(curNode,nextPos);
                        moveTo(tar,client);
                        break;
                    }
                }
                endTurn=true;
                break;
            }
            case 3://治疗
            {
                client.use_kit();
                endTurn=true;
                break;
            }
            case 4://放置陷阱
            {
                if(!client.place_trap(currentStrategy.item))
                    abortStrategy[4] = true;
                break;
            }
            case 5://拾取
            {
                if(!client.inspect_materials(currentStrategy.item))
                    client.pos2node(curPos).materials_cd = 0;
                endTurn=true;
                break;
            }
            case 6://获得密钥
            {
                client.get_key();
                endTurn=true;
                break;
            }
            case 7://逃离
            {
                client.escape(true);
                endTurn=true;
                break;
            }
            case 8://舔包
            {
                client.inspect_box();
                deleteToPick(curPos);
                endTurn=true;
                break;
            }
        }
    }


    cerr << "play end\n";
    client.finish();
}

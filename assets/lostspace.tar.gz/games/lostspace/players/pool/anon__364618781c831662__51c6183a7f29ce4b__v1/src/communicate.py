'''
update 2020.12.12 修改了__send__函数，保证仅当有发送对象不为空时才发送
update 2021.1.26  修正了boardcast函数中调用__send__时的参数问题，修正了send_witness函数messagelist错误的问题
update 2021.1.27  添加了陷阱摧毁时通知使用者的部分
update 2021.2.28  修复了游戏结束信息的发送问题，将timeout时间更改为60s
update 2021.3.6   添加了游戏开始消息中提供出生点位置的部分
update 2021.3.19  根据策划案修改了通讯格式
'''
import sys
import json
from .config import PlayDevice

def convert_byte(data_str):
    '''
    传输数据的时候加数据长度作为数据头
    '''
    message_len = len(data_str)
    message = message_len.to_bytes(4, byteorder='big', signed=True)
    message += bytes(data_str, encoding="utf8")
    return message


def convert_byte_str_for_ai(data_str):
    data_len = len(data_str)
    data_len_str = str(data_len)
    data_len_str = '0' * (4-len(data_len_str)) + data_len_str
    return data_len_str + data_str


def logic_convert_byte(data_str, send_goal):
    '''
    传输数据的时候加数据长度作为数据头
    '''
    message_len = len(data_str)
    message = message_len.to_bytes(4, byteorder='big', signed=True)
    message += send_goal.to_bytes(4, byteorder='big', signed=True)
    message += bytes(data_str, encoding="utf8")
    return message


def send_init(time, length):
    '''
    发送初始化信息
    '''
    init_dict = {"time": time, "length": length, "state": 0}
    sys.stdout.buffer.write(logic_convert_byte(json.dumps(init_dict), -1))
    sys.stdout.flush()


def send_message_goal(message_str, send_goal):
    '''
    发送二进制流
    '''
    sys.stdout.buffer.write(logic_convert_byte(message_str, send_goal))
    sys.stdout.flush()


class Communicate:
    small_round = 0
    def __init__(self, game_controller):
        self.game = game_controller

    def new_small_round(self):
        self.small_round += 1

    def recieve_data(self):
        #接收消息
        read_buffer = sys.stdin.buffer
        data_len = int.from_bytes(read_buffer.read(4), byteorder='big', signed=True)
        data = json.loads(read_buffer.read(data_len).decode())
        try:
            return json.loads(data['content']), data['player']
        except:
            raise AssertionError('format not compatible with json format!')

    def game_init(self, birth_pos:list):
        read_buffer = sys.stdin.buffer
        init_error_player = []
        while True:
            data_len = int.from_bytes(read_buffer.read(4), byteorder='big', signed=True)
            players = json.loads(read_buffer.read(data_len).decode())  # 接收初始化信息
            if players.get('player_num') is None:
                try:
                    movement, id = json.loads(players['content']), players['player']
                    if movement.get('error') is not None:
                        assert id == -1
                        assert movement.get('player') is not None
                        init_error_player.append((movement['player'], movement['error_log']))
                except:
                    pass
            else:
                break
        send_init(3, 2048)         #向judger发送config信息
        # self.send_init_mes(birth_pos)       #向AI发送的初始化消息，移至gamecontroller的start中
        return players, init_error_player

    def send_init_mes(self, birth_pos:list):
        #告知AI自己的编号
        self.small_round = 100000
        self.__send__([], list(range(4)), [{"type": "id", "id": i, "birth_pos": birth_pos[i]} for i in range(4)])
        self.small_round = 0

    def send_roundstart_mes(self, state, curplayer, statedic):
        #发送回合初始消息
        notround_mes = {
            "type": "roundbegin",
            "state": state,
            "inturn": curplayer
        }
        inround_mes = {
            "type": "roundbegin",
            "state": state,
            "inturn": curplayer,
        }
        inround_mes.update(statedic)
        self.__send__([curplayer], list(range(4)),
                      [ notround_mes if i != curplayer else inround_mes for i in range(4)])

    def boardcast(self, state, curplayer, type:str, args:list=[]):
        #广播消息（不向处在回合内的玩家发送消息）
        send = {
            "type": "offround",
            "state": state,
            "playerid": curplayer,
            "content": [type] + args
        }
        tarplayer = list(range(4))
        tarplayer.pop(curplayer)
        self.__send__([curplayer], tarplayer, [send for i in range(3)])

    def third_layer_warning(self, state:int, curplayer:int):
        self.boardcast(state, curplayer, "player_enter_top_layer")

    def get_key(self, state:int, curplayer:int, keys:list):
        self.boardcast(state, curplayer, 'getkey', [keys])

    def send_status_update(self, state:int, curplayer, type:str, args:list):
        send = {
            "type": type,
            "state": state,
            "content": args
        }
        self.__send__([curplayer], [curplayer], [send])

    def send_hp_update_offround(self, state:int, curplayer, tarplayer, hp:int):
        send = {
            "type": "offround",
            "state": state,
            "playerid": curplayer,
            "content": ["hp_update", hp]
        }
        self.__send__([curplayer], [tarplayer], [send])

    def send_witness(self, state:int, curplayer:int, content:list, tarplayer:list):
        send = {
            "type": "offround",
            "state": state,
            "playerid": curplayer,
            "content": ['see'] + content
        }
        self.__send__([curplayer], tarplayer, [send]*len(tarplayer))

    def send_trap_triggered(self, state:int, playerid:int, type:str, pos:list, tarplayer:int):
        send = {
            "type": "offround",
            "state": state,
            "playerid": playerid,
            "content": ["trap_triggered", type, pos]
        }
        self.__send__([playerid], [tarplayer], [send])

    def send_trap_destroyed(self, state:int, playerid:int, type:str, pos:list, tarplayer:int):
        send = {
            "type": "offround",
            "state": state,
            "playerid": playerid,
            "content": ["trap_destroyed", type, pos]
        }
        self.__send__([playerid], [tarplayer], [send])

    def respond(self, state, curplayer,type:str, content:dict):
        #单独向在回合内的玩家发送消息
        send = {
            "type": type
        }
        send.update(content)
        self.__send__([curplayer], [curplayer], [send])

    def respond_action(self, state:int, curplayer:int, success:bool, **kwargs):
        content = { **kwargs } if success else {}
        content['success'] = success
        self.respond(state, curplayer, 'action', content)

    def kit_reponse(self, state:int, curplayer:int, success:bool, hp:int=None):
        self.respond_action(state, curplayer, success, hp=hp)

    def move_response(self, state:int, curplayer:int, success:bool, hp:int=None, status:int=None,
                      view:dict=None, media_extra:dict=None):
        self.respond_action(state, curplayer, success, hp=hp, status=status, view=view, pos_info=media_extra)

    def box_response(self, state:int, curplayer:int, success:bool, keys:list):
        self.respond_action(state, curplayer, success, keys=keys)

    def material_response(self, state:int, curplayer:int, success:bool, tools:dict):
        self.respond_action(state, curplayer, success, tools=tools)

    def detect_response(self, state:int, curplayer:int, success:bool, has_trap:bool):
        self.respond_action(state, curplayer, success, has_trap=has_trap)

    def send_formate_error(self, state, curplayer):
        send = {
            "type": "format error"
        }
        self.__send__([curplayer], [curplayer], [send])

    def __send__(self, listen: list, playerlist: list, messagelist: list):
        if len(playerlist) == 0:
            return
        send = {
            "state": self.small_round,
            "listen": listen,
            "player": playerlist,
            "content": [ json.dumps(messagelist[i]) \
                         if self.game.player_property[playerlist[i]] == PlayDevice.MediaPlayer.value \
                         else convert_byte_str_for_ai(json.dumps(messagelist[i]))
                         for i in range(len(playerlist))]
        }
        send_message_goal(json.dumps(send), -1)

    def send_end_info(self, end_info):
        '''
        发送终局信息
        '''
        end_dict = {}
        end_dict['state'] = -1
        end_dict['end_info'] = json.dumps(end_info)
        sys.stdout.buffer.write(logic_convert_byte(json.dumps(end_dict), -1))
        sys.stdout.flush()
        sys.exit()

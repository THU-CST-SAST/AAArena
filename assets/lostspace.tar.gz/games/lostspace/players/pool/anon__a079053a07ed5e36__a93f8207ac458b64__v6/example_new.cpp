//#include"sdk_AI_Client.hpp"
#include"ai_client.h"
#include<stack>
#include<string>
#include<algorithm>
#include<fstream>
using namespace std;

void tst(Pos &x,AI_Client &client)
{
    string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);
    fout<<std::get<0>(x)<<' '<<std::get<1>(x)<<' '<<std::get<2>(x)<<' ';
    fout<<endl;
}

struct strategy
{
    int type=0,value1=0,value2=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离 8:不动
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

//typedef std::tuple<int, int, int> Pos;
//typedef std::map<std::string, std::vector<std::vector<int>>> Trapbag;
Pos curPos;
int myID;
Tool myInventory;
stack<strategy> strategyList;
vector<int> keys;
int abort_strategy[10]={0};

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

int dis(Pos s,Pos t,AI_Client& client)
{
    return client.find_shortest_path(s,t).size();
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1;
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        j=dis(curPos,client.get_spawn_pos(i),client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_spawn_pos(closestSpawn);
    }
    else//已获得所有密钥，前往逃离位置
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_escape_pos();
    }
}

string getFirstTrap()
{
    if(myInventory.trapbag["LandMine"][0][0])
        return "LandMine";
    if(myInventory.trapbag["Sticky"][0][0])
        return "Sticky";
    return "None";
}

string nextToInspect(Tool &inventory)
{
    if(inventory.blinks_num<2) //优先拿满闪现
        return "Transport";
    if(inventory.kits_num<2) //拿满医疗包
        return "Kit";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    return "Sticky";
}

void decideStrategy(AI_Client& client)//检查当前策略是否需要更换
{
    int i,j;
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/

    if(curPos==client.get_escape_pos() && client.get_keys().size()==4)//已到达逃离位置且集齐密钥，可以撤离
    {
        strategyList.push(7);
        return;
    }

    for(i=0;i<4;i++)
    {
        if(find(keys.begin(),keys.end(),i)==keys.end() && curPos==client.get_spawn_pos(i))
        {
            strategyList.push(6);
            return;
        }
    }

    while(!strategyList.empty() && strategyList.top().type==0 && strategyList.top().dst==curPos)//已经到达目标地点，结束移动
        strategyList.pop();

    if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
        return;
    }

    if(strategyList.top().type==2)//当前策略为逃跑
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        if(std::get<0>(otherPos) < 0 || dis( otherPos , curPos, client) > 2)
            //和敌人的距离足够远或失去敌人视野时停止
            strategyList.pop();
        else{
            strategyList.top().dst = otherPos;
            return;//继续
        }
    }

    if(client.get_player_hp()<100 && myInventory.kits_num)//在低生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

    if(strategyList.top().type==1)//当前策略为进攻
    {
        Pos otherPos=client.get_others_pos(strategyList.top().value1);
        //tst(otherPos,client);
        if(std::get<0>(otherPos) < 0 ||  dis( otherPos ,curPos,client) > 2 
                || (strategyList.top().value2 < 0))
            //和敌人的距离足够远、敌人离开视野或追击时间过长时停止
            strategyList.pop();
        else if(client.get_others_hp(strategyList.top().value1) > 0)//追击目标存活，继续
        {
            // if(client.get_others_hp(strategyList.top().value1) > 140)//若目标生命值较高，则减少追击权重
            strategyList.top().value2--;
            // else if(client.get_others_hp(strategyList.top().value1)< 70)//若目标为残血，增加追击权重
            //     strategyList.top().value2++;
            strategyList.top().dst = otherPos;//更新敌人位置
            return;
        }
        else 
        {
            strategyList.pop();
            if(strategyList.top().dst!=curPos)//目标已死亡，前去收集掉落物品
            {
                strategy tmp(0);
                tmp.dst=strategyList.top().dst;
                strategyList.pop();
                strategyList.push(tmp);
                return;
            }
        }
    }
    
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人  如果多个敌人相邻怎么办？？
    {
        if(i==myID)
            continue;
        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos) < 0)  //不在同一层
            continue;
        if(curPos == otherPos){              //可供改进：如果血量太少且有电梯，可以考虑逃跑
            strategy tmp(1);
            tmp.value1 = i;
            tmp.value2 = 2;
            tmp.dst = otherPos;
            strategyList.push(tmp);
            return;
        }
        if(isConnected(otherPos ,curPos,client))
        {
            if(client.get_player_hp() / 70 - client.get_others_hp(i) / 70 >= 0 ){ //自身生命值较高，前去追击
                strategy tmp(1);
                tmp.value1 = i;
                tmp.value2 = 2;
                tmp.dst = otherPos;
                strategyList.push(tmp);
                return; 
            }
            else{                                                        //自身生命值更低，尝试逃跑
                strategy tmp(2);
                tmp.value1 = i;
                tmp.dst = otherPos;
                strategyList.push(tmp);
                return;
            }
        }
    //    if(dis(curPos,otherPos,client) == 3)  //和敌人距离为2，不主动靠近
    //    {
    //        strategy tmp(8);
    //        return;
    //    }

    }

    if(client.get_player_hp()<100 && myInventory.kits_num)//在损失生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return;
    }

    // for(i=0;i<4;i++)
    // {
    //     if(find(keys.begin(),keys.end(),i)==keys.end() && curPos==client.get_spawn_pos(i))
    //     {
    //         strategyList.push(6);
    //         return;
    //     }
    // }

    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos));
    if(val.first && !abort_strategy[5])//当前位置可以拾取物品
    {
        strategyList.push(strategy(5));
        strategyList.top().item=nextToInspect(myInventory);
        return;
    }
    abort_strategy[5]=0;
    string item=getFirstTrap();
    if(item!="None")//物品栏中有陷阱
    {
        if(client.get_neighbors(curPos).size()>2 && !abort_strategy[2])//若当前位置度数>2，则放置陷阱
        {
            strategy tmp(4);
            tmp.item=item;
            strategyList.push(tmp);
            return;
        }
    }
    abort_strategy[2]=0;

    if(strategyList.top().type==0 && dis( curPos,strategyList.top().dst,client )>5 
            && strategyList.top().dst!=client.get_escape_pos())//若当前策略为移动，且偏离路线过长，则重新规划路线
    {
        strategyList.pop();
        reroute(client);
        return;
    }
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos) && client.get_state() >= 10)//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

bool blinkTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos) && client.get_state() >= 10)//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.blink(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
    return nullptr;
}

void play(AI_Client &client)
{
    /*string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);*/
    myID=client.get_id();
    curPos=client.get_player_pos();
    Node &curNode=client.pos2node(curPos);
    myInventory=client.get_tools();
    keys=client.get_keys();
    bool endTurn=false;
    decideStrategy(client);
    /*fout<< "type" << strategyList.top().type <<' '<<strategyList.top().item<<std::endl;
    fout<<"keys:";
    for(int i:keys)
        fout<<i<<' ';
    fout<<endl;
    tst(strategyList.top().dst,client);
    tst(curPos,client);*/
    std::cerr << "type" << strategyList.top().type << std::endl;
    switch (strategyList.top().type)
    {
        case 0://移动
        {
            Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
            Edge *tar=findEdge(curNode,nextPos);
            moveTo(tar,client);
            endTurn=true;
            break;
        }
        case 1://攻击
        {
            if(isConnected(curPos,strategyList.top().dst,client))//能攻击到敌人
            {
                client.attack(strategyList.top().dst,strategyList.top().value1);
                endTurn=true;
            }
            else//不能攻击到敌人，尝试接近敌人
            {
                Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
                Edge *tar=findEdge(curNode,nextPos);
                if(myInventory.blinks_num > 0)
                    blinkTo(tar,client);
                else{
                    moveTo(tar,client);
                    endTurn=true;
                }
            }
    
            break;
        }
        case 2://逃跑
        {
            Pos banned=client.find_shortest_path(curPos,strategyList.top().dst)[1];//不能向敌人的方向跑
            vector<Pos> neighbors=client.get_neighbors(curPos);
            for(Pos nextPos:neighbors)
            {
                if(nextPos != banned)//向任意不会遭遇敌人的方向逃跑
                {
                    Edge *tar=findEdge(curNode,nextPos);
                    if(myInventory.blinks_num > 0)
                        blinkTo(tar,client);
                    else{
                        moveTo(tar,client);
                        endTurn=true;
                    }
                    break;
                }
            }
            break;
        }
        case 3://治疗
        {
            client.use_kit();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 4://放置陷阱
        {
            if(!client.place_trap(strategyList.top().item))
                abort_strategy[2]=1;
            strategyList.pop();
            break;
        }
        case 5://拾取
        {
            if(!client.inspect_materials(strategyList.top().item))
                abort_strategy[5]=1;
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 6://获得密钥
        {

            client.get_key();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 7://逃离
        {
            client.escape(true);
            endTurn=true;
            break;
        }
        case 8: //不动
        {
            endTurn = true;
            break;
        }
    }
    if(endTurn)//若当前操作计入行动次数，则结束回合
    {
        //fout<<"finish"<<endl;
        client.finish();
    }
    else//若当前操作不计入行动次数，则可以继续行动
    {
        play(client);
    }
}


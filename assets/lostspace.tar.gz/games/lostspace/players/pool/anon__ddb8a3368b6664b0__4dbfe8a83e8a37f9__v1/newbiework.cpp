#include<iostream>
#include<string>
#include<vector>
#include"ai_client.h"
#include<array>
class player{
public:
    short id;
    int hp;
    Pos currentpos;
    short currentlayer;
    player(short id): id(id){};
};
using std::vector;
using std::string;
using std::array;
Tool inventory;//物品栏
int round;//进行实践
vector<int>keys;//自己持有的钥匙
vector<Pos>codeMachine = {Pos(0,0,0),Pos(0,0,6),Pos(0,6,0),Pos(0,6,6),Pos(1,0,0),Pos(1,6,0),Pos(1,0,6),Pos(1,6,6)};//密码机位置
array<Pos,10> elevators = {Pos(0,3,0),Pos(0,3,6),Pos(0,1,3),Pos(0,5,3),Pos(1,1,3),Pos(1,5,3),Pos(2,3,6),Pos(2,3,0),Pos(2,5,3),Pos(2,1,3)};//电梯位置
array<Pos,12> supplies = {Pos(0,3,0),Pos(0,3,6),Pos(0,1,3),Pos(0,5,3),Pos(1,1,3),Pos(1,5,3),Pos(2,3,6),Pos(2,3,0),Pos(2,5,3),Pos(2,1,3)};//物资列表
array<player,4> players = {player(0),player(1),player(2),player(3)};//玩家列表
int tarhp;
int tarid;
int id = -1;
int hp;
Pos mypos;

int dis(Pos s,Pos t,AI_Client& client)
{
    return client.find_shortest_path(s,t).size();
}

void moveTo(Pos tar,AI_Client& cli){
    vector<Pos> path = cli.find_shortest_path(tar,cli.get_player_pos());
    cli.move(path[1]);
}

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

void chaseNatk(int id,AI_Client& cli){
    Pos tar = cli.get_others_pos(id);
    Pos slf = cli.get_player_pos();
    if(inventory.blinks_num >= 1 && isConnected(tar,slf,cli) && tar != slf){//使用闪现切脸
        cli.blink(cli.find_shortest_path(slf,tar)[1]);
    }

    if(isConnected(slf,tar,cli)){
        cli.attack(tar,id);
        cli.finish();
    }
    else 
        cli.move(cli.find_shortest_path(slf,tar)[1]);
        cli.finish();
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1;
    for(i=0;i<=7;i++)
    {
        if(find(keys.begin(),keys.end(),i/2)!=keys.end())
            continue;
        j=dis(client.get_player_pos(),codeMachine[i],client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        if(client.get_player_pos() == codeMachine[i]){
            client.get_key();
        }
        client.move(client.find_shortest_path(client.get_player_pos(),codeMachine[i])[1]);
        client.finish();
    }
    else//已获得所有密钥，前往逃离位置
    {  
        if(client.get_player_pos() == client.get_escape_pos()){
            client.escape(true);
        }
        client.move(client.find_shortest_path(client.get_player_pos(),client.get_escape_pos())[1]);
        client.finish();
    }
}

int nearestEnemy(AI_Client &cli){
    for(int i = 0;i<3;i++){
        if(dis(cli.get_others_pos(i),cli.get_player_pos(),cli)==1){
            return i;
        }
    }
}

bool isSafe(Pos slf,AI_Client& cli){//位置附近是否有敌人
    for(auto i : cli.get_neighbors(slf,true)){
        for(int j = 0;j<4;j++){
            if(i == cli.get_others_pos(j))
                return false;
        }
    }
    return true;
}
//更新状态
void update(AI_Client& cli){
    if(id == -1){
        id = cli.get_id();
    }
    inventory = cli.get_tools();
    round = cli.get_state();
    keys = cli.get_keys();
    hp = cli.get_player_hp();
    mypos = cli.get_player_pos();
    for(auto i: players){
        if(i.id == cli.get_id())
            continue;
        else
            i.hp = cli.get_others_hp(i.id);
            if(1);
    }
}

void play(AI_Client& cli){
    update(cli);
    if(!isSafe(mypos,cli)){
        chaseNatk(nearestEnemy(cli),cli);
    }
    else
        reroute(cli);
}


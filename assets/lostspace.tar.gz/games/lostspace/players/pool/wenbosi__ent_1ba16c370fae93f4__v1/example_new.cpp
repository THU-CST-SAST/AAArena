//#include"sdk_AI_Client.hpp"
#include "ai_client.h"
#include <stack>
#include <string>
#include <algorithm>
#include <fstream>
using namespace std;

void tst(Pos &x,AI_Client &client)
{
    string name="0.txt";
    name[0]+=client.get_id();
    ofstream fout(name,ios::app);
    fout<<std::get<0>(x)<<' '<<std::get<1>(x)<<' '<<std::get<2>(x)<<' ';
    fout<<endl;
}

struct strategy
{
    int type=0,value1=0,value2=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

Pos curPos;
int myID;
int hp;
Tool myInventory;
stack<strategy> strategyList;
vector<int> keys;
int abort_strategy=-1;

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

int dis(Pos s,Pos t,AI_Client& client)
{
    return client.find_shortest_path(s,t).size();
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1;
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        j=dis(curPos,client.get_spawn_pos(i),client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_spawn_pos(closestSpawn);
    }
    else//已获得所有密钥，前往逃离位置
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_escape_pos();
    }
}

string nextToInspect(Tool &inventory) {
    if(inventory.kits_num<2) //优先拿满医疗包
        return "Kit";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    if(inventory.blinks_num<2) //拿满闪现
        return "Transport";
    return "Sticky";
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size() > 2 && client.get_check_cd() == 0 && std::get<2>(dst) == std::get<2>(curPos)) //若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
}

Pos NextPos(AI_Client &client) {
    Pos x;
    x = Pos(get<0>(curPos) - 3,get<1>(curPos) - 3,get<2>(curPos));
    Pos ans;
    if(myID == 0) {
        Pos PosList[29] = {Pos(-3,-3,1),Pos(-3,-2,1),Pos(-2,-2,1),Pos(-2,-1,1),Pos(-2,0,1),Pos(-2,0,2),Pos(-3,0,2),Pos(-3,1,2),
        Pos(-2,2,2),Pos(-3,3,2),Pos(-2,2,2),Pos(-1,3,2),Pos(0,3,2),Pos(1,3,2),Pos(2,2,2),Pos(3,3,2),Pos(2,2,2),Pos(3,1,2),Pos(3,0,2),
        Pos(3,-1,2),Pos(2,-2,2),Pos(3,-3,2),Pos(3,-2,2),Pos(2,-1,2),Pos(3,0,2),Pos(2,0,2),Pos(2,0,0),Pos(1,1,0),Pos(0,0,0)};
        for(int i=0;i<28;i++)
            if(x == PosList[i])
                ans = PosList[i+1];
        if(x == Pos(-2,2,2)) {
            if(client.get_keys().size() == 2)
                ans = Pos(-1,3,2);
            else
                ans = Pos(-3,3,2);
        }
        if(x == Pos(2,2,2)) {
            if(client.get_keys().size() == 3)
                ans = Pos(3,1,2);
            else
                ans = Pos(3,3,2);
        }
        if(x == Pos(3,0,2)) {
            if(client.get_keys().size() == 4)
                ans = Pos(2,0,2);
            else
                ans = Pos(3,-1,2);
        }

    }
    if(myID == 1) {
        Pos PosList[29] = {Pos(3,-3,1),Pos(3,-2,1),Pos(2,-2,1),Pos(2,-1,1),Pos(2,0,1),Pos(2,0,2),Pos(3,0,2),Pos(3,1,2),
        Pos(2,2,2),Pos(3,3,2),Pos(2,2,2),Pos(1,3,2),Pos(0,3,2),Pos(-1,3,2),Pos(-2,2,2),Pos(-3,3,2),Pos(-2,2,2),Pos(-3,1,2),Pos(-3,0,2),
        Pos(-3,-1,2),Pos(-2,-2,2),Pos(-3,-3,2),Pos(-3,-2,2),Pos(-2,-1,2),Pos(-3,0,2),Pos(-2,0,2),Pos(-2,0,0),Pos(-1,1,0),Pos(0,0,0)};
        for(int i=0;i<28;i++)
            if(x == PosList[i])
                ans = PosList[i+1];
        if(x == Pos(2,2,2)) {
            if(client.get_keys().size() == 2)
                ans = Pos(1,3,2);
            else
                ans = Pos(3,3,2);
        }
        if(x == Pos(-2,2,2)) {
            if(client.get_keys().size() == 3)
                ans = Pos(-3,1,2);
            else
                ans = Pos(-3,3,2);
        }
        if(x == Pos(-3,0,2)) {
            if(client.get_keys().size() == 4)
                ans = Pos(-2,0,2);
            else
                ans = Pos(-3,-1,2);
        }
    }
    if(myID == 2) {
        Pos PosList[29] = {Pos(3,3,1),Pos(3,2,1),Pos(2,2,1),Pos(2,1,1),Pos(2,0,1),Pos(2,0,2),Pos(3,0,2),Pos(3,-1,2),
        Pos(2,-2,2),Pos(3,-3,2),Pos(2,-2,2),Pos(1,-3,2),Pos(0,-3,2),Pos(-1,-3,2),Pos(-2,-2,2),Pos(-3,-3,2),Pos(-2,-2,2),Pos(-3,-1,2),Pos(-3,0,2),
        Pos(-3,1,2),Pos(-2,2,2),Pos(-3,3,2),Pos(-3,2,2),Pos(-2,1,2),Pos(-3,0,2),Pos(-2,0,2),Pos(-2,0,0),Pos(-1,-1,0),Pos(0,0,0)};
        for(int i=0;i<28;i++)
            if(x == PosList[i])
                ans = PosList[i+1];
        if(x == Pos(2,-2,2)) {
            if(client.get_keys().size() == 2)
                ans = Pos(1,-3,2);
            else
                ans = Pos(3,-3,2);
        }
        if(x == Pos(-2,-2,2)) {
            if(client.get_keys().size() == 3)
                ans = Pos(-3,-1,2);
            else
                ans = Pos(-3,-3,2);
        }
        if(x == Pos(-3,0,2)) {
            if(client.get_keys().size() == 4)
                ans = Pos(-2,0,2);
            else
                ans = Pos(-3,1,2);
        }
    }
    if(myID == 3) {
        Pos PosList[29] = {Pos(-3,3,1),Pos(-3,2,1),Pos(-2,2,1),Pos(-2,1,1),Pos(-2,0,1),Pos(-2,0,2),Pos(-3,0,2),Pos(-3,-1,2),
        Pos(-2,-2,2),Pos(-3,-3,2),Pos(-2,-2,2),Pos(-1,-3,2),Pos(0,-3,2),Pos(1,-3,2),Pos(2,-2,2),Pos(3,-3,2),Pos(2,-2,2),Pos(3,-1,2),Pos(3,0,2),
        Pos(3,1,2),Pos(2,2,2),Pos(3,3,2),Pos(3,2,2),Pos(2,1,2),Pos(3,0,2),Pos(2,0,2),Pos(2,0,0),Pos(1,-1,0),Pos(0,0,0)};
        for(int i=0;i<28;i++)
            if(x == PosList[i])
                ans = PosList[i+1];
        if(x == Pos(-2,-2,2)) {
            if(client.get_keys().size() == 2)
                ans = Pos(-1,-3,2);
            else
                ans = Pos(-3,-3,2);
        }
        if(x == Pos(2,-2,2)) {
            if(client.get_keys().size() == 3)
                ans = Pos(3,-1,2);
            else
                ans = Pos(3,-3,2);
        }
        if(x == Pos(3,0,2)) {
            if(client.get_keys().size() == 4)
                ans = Pos(2,0,2);
            else
                ans = Pos(3,1,2);
        }
    }
    ans = Pos(get<0>(ans) + 3,get<1>(ans) + 3,get<2>(ans));
    return ans;
}

void play(AI_Client &client)
{
    myID = client.get_id();
    curPos = client.get_player_pos();
    Node &curNode = client.pos2node(curPos);
    myInventory = client.get_tools();
    keys = client.get_keys();
    hp = client.get_player_hp();
    bool endTurn = false;
    abort_strategy = -1;
    if(!endTurn  && hp < 100 && myInventory.kits_num) { //在战斗中使用医疗包
        client.use_kit();
        endTurn = true;
    }
    if(!endTurn  && hp < 200 && get<2>(curPos) == 2 && myInventory.kits_num) { //在血量非满时使用医疗包
        client.use_kit();
        endTurn = true;
    }
    //if(!endTurn && get<2>(curPos) == 0) {    //在第三层攻击
    if(!endTurn) {
        cerr<<myID<<" "<<client.get_player_hp()<<endl;
        for(int i = 0;i < 4;i++) {
            if(i == myID) continue;
            Pos otherPos = client.get_others_pos(i);
            if(client.get_others_hp(i) <= 0) {
                cerr<<"Dead!!!"<<endl;
                continue;
            }
            if(get<0>(otherPos) < 0) continue;
            if(isConnected(curPos,otherPos,client)) { //能攻击到敌人
                client.attack(otherPos,i);
                endTurn = true;
                break;
            }
        }
    }
    if(!endTurn && curPos==client.get_escape_pos() && client.get_keys().size() == 4) {
        client.escape(true);
        endTurn = true;
    }
    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos)); //拾取物品
    if(!endTurn && (!myInventory.kits_num || hp < 200) && val.first && abort_strategy != 5) {
        string item = nextToInspect(myInventory);
        if(!client.inspect_materials(item))
                abort_strategy = 5;
        endTurn = true;
    }
    for(int i = 0; i < 4; i++) { //拾取密匙
        Pos now = client.get_spawn_pos(i);
        if(!endTurn && find(keys.begin(),keys.end(),i) == keys.end() && get<0>(curPos) == get<0>(now) && get<1>(curPos) == get<1>(now)) {
            client.get_key();
            endTurn = true;
            break;
        }
    }
    if(!endTurn) {
        Pos nextPos = NextPos(client);
        Edge *tar = findEdge(curNode,nextPos);
        moveTo(tar,client);
        endTurn = true;
    }
    if(endTurn || client.get_player_copy(client.get_id()).status == WAIT_FOR_ESCAPE) { //若当前操作计入行动次数，则结束回合
        client.finish();
    }
    else { //若当前操作不计入行动次数，则可以继续行动
        play(client);
    }
}
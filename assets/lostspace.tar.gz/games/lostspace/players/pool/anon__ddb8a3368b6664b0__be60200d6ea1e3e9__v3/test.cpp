#include<iostream>
#include<string>
#include<vector>
#include"ai_client.h"
#include<array>
#include<fstream>
#include<algorithm>
using namespace std;
Tool inventory;//物品栏
int rounds;//进行时间
vector<int>keys;//自己持有的钥匙
array<array<Pos,2>,4> codeMachine;//密码机位置
array<Pos,10> elevators {Pos(1,3,0),Pos(3,0,0),Pos(3,6,0),Pos(5,3,0),Pos(1,3,1),Pos(5,3,1),Pos(1,3,2),Pos(3,0,2),Pos(3,6,2),Pos(5,3,2)};//电梯位置
array<Pos,12> supplies {Pos(0,3,1),Pos(3,2,1),Pos(3,4,1),Pos(6,3,1),Pos(0,3,2),Pos(2,2,2),Pos(2,4,2),Pos(3,2,2),Pos(3,4,2),Pos(4,2,2),Pos(4,4,2),Pos(6,3,2)};//物资列表
array<Player,4> Players;//玩家列表
int tarhp;
int tarid;
int id = -1;
int hp;
Pos mypos;

void sendlog(AI_Client cli){//生成日志
    cerr <<"round: "<<cli.get_state()<<" position: "<<get<0>(mypos) <<','<<get<1>(mypos)<<','<<get<2>(mypos) << endl;
}

int dis(Pos s,Pos t,AI_Client& client)
{
    return client.find_shortest_path(s,t).size();
}

void moveTo(Pos tar,AI_Client& cli){
    vector<Pos> path = cli.find_shortest_path(mypos,tar);
    cli.move(path[1]);
}

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

void chaseNatk(int id,AI_Client& cli){
    Pos tar = cli.get_others_pos(id);
    if(inventory.blinks_num >= 1 && isConnected(tar,mypos,cli) && tar != mypos){//使用闪现切脸
        cli.blink(cli.find_shortest_path(mypos,tar)[1]);
    }
    if(isConnected(mypos,tar,cli)){
        cli.attack(tar,id);
        cli.finish();
    }
    else 
        cli.move(cli.find_shortest_path(mypos,tar)[1]);
        cli.finish();
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    int i,j,minDis=99,closestSpawn=-1,currentlayer=get<2>(mypos);
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        j=dis(mypos,codeMachine[i][currentlayer-1],client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        if(mypos == client.get_spawn_pos(closestSpawn)){
            client.get_key();
        }
        else{
            client.move(client.find_shortest_path(mypos,codeMachine[closestSpawn][currentlayer-1])[1]);
            client.finish();
        }
    }
    else//已获得所有密钥，前往逃离位置
    {  
        if(mypos == client.get_escape_pos())
            client.escape(true);
        else
            client.move(client.find_shortest_path(mypos,client.get_escape_pos())[1]);
        client.finish();
    }
}

int nearestEnemy(AI_Client &cli){
    for(int i = 0;i<3;i++){
        if(i == cli.get_id())
            continue;
        if(dis(cli.get_others_pos(i),mypos,cli)==1){
            return i;
        }
    }

}

bool isSafe(const Pos& slf,AI_Client& cli){//位置附近是否有敌人
    vector<Pos> neigh = cli.get_neighbors(slf,true);
    for(auto i : neigh){
        for(int j = 0;j<4;j++){
            if(j == cli.get_id())
                continue;
            if(i == cli.get_others_pos(j)){
                return false;
            }
        }
    }
    return true;
}

void update(AI_Client& cli){//更新状态
    if(id == -1){
        id = cli.get_id();
        codeMachine[0]={Pos(0,0,1),Pos(0,0,2)};
        codeMachine[1]={Pos(6,0,1),Pos(6,0,2)};
        codeMachine[2]={Pos(6,6,1),Pos(6,6,2)};
        codeMachine[3]={Pos(0,6,1),Pos(0,6,2)};
        cerr <<"id: "<< id << endl;
    }
    inventory = cli.get_tools();
    keys = cli.get_keys();
    hp = cli.get_player_hp();
    mypos = cli.get_player_pos();
    rounds = cli.get_state();
    // for(auto i: Players){
    //     if(i.id == cli.get_id())
    //         continue;
    //     else
    //         i.hp = cli.get_others_hp(i.id);
    //         if(1);
    // }
}

void play(AI_Client& cli){
    update(cli);
    sendlog(cli);
    if(cli.get_player_copy(cli.get_id()).status == WAIT_FOR_ESCAPE){
        cli.finish();
        return;
    }
    if(cli.get_player_copy(cli.get_id()).status == DEAD)
        return;
    if(cli.get_player_copy(cli.get_id()).status == ESCAPED)
        return;
    // if(!isSafe(mypos,cli)){
    //     chaseNatk(nearestEnemy(cli),cli);
    // }
    // else
    if(rounds < 6){
        if(id == 0 ||id == 3){
            moveTo(Pos(1,3,2),cli);
            cli.finish();
            return;
        }
        else{
            moveTo(Pos(5,3,2),cli);
            cli.finish();
            return;
        }
    }
    else if(!isSafe(mypos,cli)){
        cli.attack(cli.get_others_pos(nearestEnemy(cli)),nearestEnemy(cli));
        cli.finish();
    }
    else
        reroute(cli);
}
目前逻辑：



距离为0/1 则进攻/逃跑 

距离为2 考虑闪现杀人



判断是否进攻/逃跑

吃口药

判断是否走到结束位置

舔包->拿物资->拿钥匙机  注意abort_strategy[5]

如果策略为空则生成路径

判断是否追击/接着跑

逃离

放陷阱

重新规划路线

![image-20210501212536508](C:\Users\86134\AppData\Roaming\Typora\typora-user-images\image-20210501212536508.png)
//#include"sdk_AI_Client.hpp"
#include"ai_client.h"
#include<stack>
#include<string>
#include<algorithm>
#include<fstream>
#include <vector>
using namespace std;

vector<int> attack_ban;
bool stop = false;
int materials_used[7][7][7];

struct strategy
{
    int type=0,value1=0;
    //表示策略的类型
    //0:移动到指定位置 1:攻击并追击敌人 2:逃跑 3:治疗自己 4:放置陷阱 5:收集物资 6：获得密钥 7:逃离
    Pos dst;
    string item;
    strategy(int t):type(t)
    {}
};

//typedef std::tuple<int, int, int> Pos;
//typedef std::map<std::string, std::vector<std::vector<int>>> Trapbag;
Pos curPos;
int myID;
Tool myInventory;
stack<strategy> strategyList;
vector<int> keys;
int abort_strategy[10]={0};

bool isConnected(Pos a,Pos b,AI_Client& client)
{
    if(a==b)
        return true;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return true;
    return false;
}

int dis(Pos s,Pos t,AI_Client& client)
{
    return client.find_shortest_path(s,t).size() - 1;
}

void reroute(AI_Client& client)//决定下一步前进的方向
{
    cerr << "reroute start\n";
    int i,j,minDis=99,closestSpawn=-1;
    for(i=0;i<=3;i++)
    {
        if(find(keys.begin(),keys.end(),i)!=keys.end())
            continue;
        j=dis(curPos,client.get_spawn_pos(i),client);
        if(j<minDis)
        {
            minDis=j;
            closestSpawn=i;
        }
    }
    if(closestSpawn!=-1)//朝着尚未获得密钥且最近的密钥机移动
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_spawn_pos(closestSpawn);
    }
    else//已获得所有密钥，前往逃离位置
    {
        strategyList.push(0);
        strategyList.top().dst=client.get_escape_pos();
    }
    cerr << "reroute end\n";
}

string getFirstTrap()
{
    if(myInventory.trapbag["LandMine"][0][0])
        return "LandMine";
    if(myInventory.trapbag["Sticky"][0][0])
        return "Sticky";
    return "None";
}

string nextToInspect(Tool &inventory)
{
    if(inventory.blinks_num<2) //优先拿满闪现
        return "Transport";
    if(inventory.kits_num<2) //拿满医疗包
        return "Kit";
    if(inventory.trapbag["LandMine"][0][0]<2) //拿取两个地雷
        return "LandMine";
    return "Sticky";
}

bool decideStrategy(AI_Client& client)//检查当前策略是否需要更换 如果决定好了策略则返回true
{
    cerr << "decideStrategy start\n";
    int i, tot = client.get_id_and_dis();
    for(i=0;i<4;i++)//检查相邻位置是否存在敌人
    {
        if(i==myID)
            continue;
        if(client.get_player_copy(i).status != ALIVE)continue;

        Pos otherPos=client.get_others_pos(i);
        if(std::get<0>(otherPos)<0)
            continue;

        if(isConnected(otherPos ,curPos,client))
        {
            if(client.get_attack_value(i) >= 0)//对拼能赢
            {
                strategy tmp(1);
                tmp.value1=i;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return true;
            }
            else
            {   //快跑
                strategy tmp(2);
                tmp.value1=i;
                tmp.dst=otherPos;
                strategyList.push(tmp);
                return true;
            }
        }
    }

    if(client.get_player_hp()<=70 && myInventory.kits_num)//在损失生命值时治疗自己
    {
        strategyList.push(strategy(3));
        return true;
    }

    while(!strategyList.empty() && strategyList.top().type==0 && strategyList.top().dst==curPos)//已经到达目标地点，结束移动
        strategyList.pop();

    std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(curPos));

    if(val.first)//当前位置可以拾取物品
    {
        for(const auto& x: val.second){
            if(x == InterpropsType.Box){
                strategyList.push(strategy(8));
                return true;
            }
        }

        for(const auto& x: val.second){
            if(x == InterpropsType.Materials  && materials_used[get<0>(curPos)][get<1>(curPos)][get<2>(curPos)] < 2){
                strategyList.push(strategy(5));
                strategyList.top().item=nextToInspect(myInventory);
                return true;
            }
        }
    }

    for(i=0;i<4;i++)
    {
        if(find(keys.begin(),keys.end(),i)==keys.end() && curPos==client.get_spawn_pos(i))
        {
            strategyList.push(6);
            return true;
        }
    }

    if(strategyList.empty())//当前策略为空，则生成一条路径
    {
        reroute(client);
    }

    if(strategyList.top().type==1)//当前策略为进攻
    {
        int enemy_id = strategyList.top().value1;
        Pos otherPos=client.get_others_pos(enemy_id);

       if(std::get<0>(otherPos) < 0 ||  dis( otherPos ,curPos,client) > 2 || client.get_attack_value(enemy_id) < 0 || client.get_player_copy(enemy_id).status != ALIVE)
            //和敌人的距离足够远、敌人离开视野或打不过时停止
            strategyList.pop();
        else if(dis(otherPos, curPos, client) == 2 && myInventory.blinks_num < (client.get_others_hp(enemy_id) - 1) / 70 + 1){
            //闪现不够 不追了
            strategyList.pop();
        }
        else if(dis(otherPos, curPos, client) == 2 && !client.worthAttack(enemy_id)){
            //不值得追 不追了
            strategyList.pop();
        }
        else if(client.get_others_hp(enemy_id)>0)//追击目标存活，继续
        {
            strategyList.top().dst=otherPos;//更新敌人位置
            return true;
        }
        else{
            cerr << "I dont know what happened." << endl;
            reroute(client);
        }
    }
    else if(strategyList.top().type==2)//当前策略为逃跑
    {
        int enemy_id = strategyList.top().value1;
        Pos otherPos=client.get_others_pos(enemy_id);

        if(std::get<0>(otherPos)<0 || dis( otherPos ,curPos,client) >= 2)
            //和敌人的距离足够远或失去敌人视野时停止
            strategyList.pop();
        else if(client.get_others_hp(enemy_id)>0) //对面还活着，接着跑
        {
            strategyList.top().dst=otherPos;//更新敌人位置
            return true;
        }
        else{
            cerr << "I dont know what happened again." << endl;
            reroute(client);
        }
    }

    if(curPos==client.get_escape_pos() && client.get_keys().size()==4)//已到达逃离位置且集齐密钥，可以撤离
    {
        if(client.id_and_dis[0].second == 2 && client.get_player_hp() <= 140 && myInventory.kits_num){
            //敌人太近了 可能被打死 吃个药
            strategyList.push(strategy(3));
        }
        else{
            //逃离
            strategyList.push(strategy(7));
        }
        return true;
    }

    string item=getFirstTrap();

    if(item!="None")//物品栏中有陷阱
    {
        if(client.get_neighbors(curPos).size()>2 && !abort_strategy[2])//若当前位置度数>2，则放置陷阱
        {
            strategy tmp(4);
            tmp.item=item;
            strategyList.push(tmp);
            return true;
        }
    }
    abort_strategy[2]=0;

    while(!strategyList.empty() && strategyList.top().type==0 && strategyList.top().dst==curPos)//已经到达目标地点，结束移动
        strategyList.pop();
    //若当前策略为移动并且比较远则重新规划路线
    if(strategyList.empty() ||
            (strategyList.top().type==0 && !client.pos2node(strategyList.top().dst).able) ||
            (strategyList.top().type==0 && dis(curPos, strategyList.top().dst, client) >= 3)){
        reroute(client);
        return true;
    }

    if(strategyList.top().type==0)return true;
    return false;
}

bool moveTo(Edge* e,AI_Client& client)//执行移动指令
{
    Pos dst=(e->stpos==curPos)?e->edpos:e->stpos;
    if(client.get_neighbors(dst).size()>2 && client.get_check_cd()==0 && std::get<2>(dst)==std::get<2>(curPos))//若将要进入的位置邻边较多，则使用探查
    {
        client.detect(dst);
    }
    return client.move(dst);
}

Edge* findEdge(Node& s,Pos t)//返回对应的边
{
    for(Edge* edge:s.edges)
    {
        Pos other=(edge->stpos==curPos)?edge->edpos:edge->stpos;
        if (other==t)
            return edge;
    }
    return nullptr;
}

void cerrPos(std::tuple<int, int, int> pos){
    cerr << get<0>(pos) << " " <<  get<1>(pos) << " " << get<2>(pos) << endl;
}

void play(AI_Client &client)
{

    cerr << "\n\nround:" <<  client.get_state() << " id = " << client.get_id() << endl;
    cerr << "play start\n";
    myID=client.get_id();
    curPos=client.get_player_pos();
    Node &curNode=client.pos2node(curPos);
    myInventory=client.get_tools();
    keys=client.get_keys();


    cerrPos(curPos);

    bool endTurn=false;
    while(!decideStrategy(client)||(strategyList.top().type == 0 && !client.pos2node(strategyList.top().dst).able));


    cerr << "decideStrategy end\n";


    int tot = client.get_id_and_dis();
    for(int i = 0 ; i < tot; i++){
        cerr << client.id_and_dis[i].first << " dis = " << client.id_and_dis[i].second << endl;
    }
    std::cerr << "type" << strategyList.top().type << std::endl;

    switch (strategyList.top().type)
    {
        case 0://移动
        {
            cerrPos(strategyList.top().dst);
            Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
            cerrPos(nextPos);

            client.get_id_and_dis();
            if(client.id_and_dis[0].second == 2){
                client.player.pos = nextPos;
                tot = client.get_id_and_dis();
                for(int i = 0 ; i < tot; i++){
                    cerr << client.id_and_dis[i].first << " dis = " << client.id_and_dis[i].second << endl;
                }
                client.player.pos = curPos;
                cerr << client.get_attack_value(client.id_and_dis[0].first) << "\n";
                if(client.id_and_dis[0].second == 1 && client.get_attack_value(client.id_and_dis[0].first) < 1){
                    if(stop){
                        if(myInventory.blinks_num && client.get_attack_value(client.id_and_dis[0].first) >= 0){
                            client.blink(nextPos);
                            client.attack(client.get_others_pos(client.id_and_dis[0].first), client.id_and_dis[0].first);
                        }
                        else{
                            Pos banned=nextPos;
                            vector<Pos> neighbors=client.get_neighbors(curPos);
                            for(Pos nxtPos:neighbors)
                            {
                                if(nxtPos!=banned)//向任意不会遭遇敌人的方向逃跑
                                {
                                    Edge *tar=findEdge(curNode,nxtPos);
                                    moveTo(tar,client);
                                    break;
                                }
                            }
                        }
                        stop = false;
                    }
                    else{
                        //上去就挨打 不如不动~
                        stop = true;
                        cerr << "I stop\n";
                    }
                    endTurn=true;
                    break;
                }
            }

            Edge *tar=findEdge(curNode,nextPos);
            moveTo(tar,client);
            endTurn=true;
            break;
        }
        case 1://攻击
        {
            cerrPos(strategyList.top().dst);
            cerr << "enemy = " << strategyList.top().value1 << "\n";
            cerr << "dis = " << dis(curPos, strategyList.top().dst, client) << "\n";
            cerr << "blink = " << myInventory.blinks_num << "\n";
            if(isConnected(curPos,strategyList.top().dst,client))//能攻击到敌人
            {
                cerr << "attack1\n";
                client.attack(strategyList.top().dst,strategyList.top().value1);
            }
            else//闪现跟上
            {
                cerr << "attack2\n";
                Pos nextPos=client.find_shortest_path(curPos,strategyList.top().dst)[1];
                cerrPos(nextPos);
                client.blink(nextPos);
                client.attack(strategyList.top().dst,strategyList.top().value1);
            }

            if(client.get_player_copy(strategyList.top().value1).status == DEAD)//目标已死亡，前去收集掉落物品
            {
                strategy tmp(0);
                tmp.dst=strategyList.top().dst;
                strategyList.pop();
                strategyList.push(tmp);
            }
            endTurn=true;
            break;
        }
        case 2://逃跑
        {
            cerrPos(strategyList.top().dst);
            Pos banned=curPos;
            if(dis(curPos, strategyList.top().dst, client) >= 1)
                banned=client.find_shortest_path(curPos,strategyList.top().dst)[1];//不能向敌人的方向跑
            vector<Pos> neighbors=client.get_neighbors(curPos);
            for(Pos nextPos:neighbors)
            {
                if(nextPos!=banned)//向任意不会遭遇敌人的方向逃跑
                {
                    Edge *tar=findEdge(curNode,nextPos);
                    moveTo(tar,client);
                    break;
                }
            }
            endTurn=true;
            break;
        }
        case 3://治疗
        {
            client.use_kit();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 4://放置陷阱
        {
            if(!client.place_trap(strategyList.top().item))
                abort_strategy[2]=1;
            strategyList.pop();
            break;
        }
        case 5://拾取
        {
            if(!client.inspect_materials(strategyList.top().item))
                materials_used[get<0>(curPos)][get<1>(curPos)][get<2>(curPos)] = 2;
            else {
                materials_used[get<0>(curPos)][get<1>(curPos)][get<2>(curPos)] ++;
            }
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 6://获得密钥
        {

            client.get_key();
            strategyList.pop();
            endTurn=true;
            break;
        }
        case 7://逃离
        {
            client.escape(true);
            endTurn=true;
            break;
        }
        case 8://舔包
        {
            client.inspect_box();
            strategyList.pop();
            endTurn=true;
            break;
        }
    }
    cerr << "typeEnd\n";
    if(endTurn)//若当前操作计入行动次数，则结束回合
    {
        client.finish();
    }
    else//若当前操作不计入行动次数，则可以继续行动
    {
        play(client);
    }
}


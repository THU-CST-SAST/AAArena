//#include"sdk_AI_Client.hpp"
#include"ai_client.h"
#include<stack>
#include<string>
#include<algorithm>
#include<fstream>

using namespace std;

#include <iostream>
#include <chrono>


/*void output(int num);
void output(double num);
void output(string str);
void output(Pos pos);
void output(vector<int> key);*/

/*class Timer
{
public:
    Timer()
        : t1(res::zero())
        , t2(res::zero())
    {
        tic();
    }

    ~Timer()
    {}

    void tic()
    {
        t1 = clock::now();
    }

    void toc()
    {
        t2 = clock::now();
        output("time:");
        output((double)std::chrono::duration_cast<res>(t2 - t1).count() / 1e3);
    }

private:
    typedef std::chrono::high_resolution_clock clock;
    typedef std::chrono::microseconds res;

    clock::time_point t1;
    clock::time_point t2;
};*/



struct player_data
{
    Pos    pos_last;
    int    see_last_turn;
    Pos    pos_cur; 
    int    hp;
    int    hp_old;
    int    living_turns;
    int    relive_turns;
    vector<int> keys;
};


struct player_data players[4];
int turn;
Pos my_Pos;
int my_ID;
int my_hp;
vector<int> my_keys;
Tool my_Inventory;
vector<Pos> pos_nearby;
vector<pair<int, Pos>> items_on_map; 
vector<pair<int, Pos>> keys_on_map;  //int = 4,未知类型
vector<int> keys_wanted;
vector<pair<int, Pos>> keys_on_map0;
bool flag_init = true;
int escape_turns = -1;
int target;//0~3对应钥匙
int number = 0;
bool flag_key_curpos = false;//遗物
bool flag_key0_curpos = false;//密码机
bool flag_item_curpos = false;

//Timer timer;
/****************************************************************************************************************/


int dis(const Pos& s, const Pos& t,AI_Client& client)
{
    return (client.find_shortest_path(s,t).size() - 1);
}

//钥匙机初始化
void keys_on_map0_init(AI_Client &client);

//检测是否为所求的钥匙
bool check_key(int key);

//检测当前位置是否有可拾取物
void check_current_position(AI_Client &client);

//判断a,b是否相邻      相同 2  相邻 1  不相邻 0
int isConnected(Pos a,Pos b, AI_Client& client);

//获取敌军信息
void check_enemy(AI_Client& client);

//计算需要的keys
int check_keys(AI_Client& client);

//获得所在层的所有可拾取物与可拾取KEY的位置，分别存在vector中
void check_map(const Pos& pos, AI_Client& client);

//根据情况选择拾取的道具 truw 有拾取
bool get_prop(AI_Client& client);

//计算一个位置在turns_later后相邻的敌人数（假设敌人不动）
int num_enemy_nearby(Pos a,int turns_later, AI_Client& client);

//计算下一位移目标
Pos calculate_next_pos(AI_Client& client);

//有自己设雷时返回3，粘弹2，不确定是否有敌人的雷返回1，检测为安全返回0
//int detect_pos(Pos a, AI_Client& client);

/****************************************************************************************************************/
void play(AI_Client &client)
{
    //timer.tic();
    if (flag_init)
    {
        my_ID=client.get_id();
        keys_on_map0_init(client);
        
        flag_init = false;
    }
    
    turn = client.get_state();    
    my_Pos=client.get_player_pos();
    my_hp = client.get_player_hp();
    my_Inventory=client.get_tools();
    my_keys=client.get_keys();
    pos_nearby = client.get_neighbors(my_Pos);
    flag_key_curpos = false;
    flag_key0_curpos = false;
    flag_item_curpos = false;

    //output(client.get_state());
  

    check_enemy(client);
    
    
    check_map(my_Pos, client);
    
    /****************************************************************************************************************/
    //信息处理
    int number_enemy_around = num_enemy_nearby(my_Pos, 0, client);
    check_current_position(client);
    check_keys(client);
    if(escape_turns > 0)
    {
        escape_turns--;
    }
    if (my_hp <= 0)
    {
        escape_turns = -1;
    }

    /****************************************************************************************************************/
    //是否完成主要行动
    bool flag_0 = true;
    
    //最高攻击与逃跑的优先指令
    int i = 0;
    while (flag_0 && (i < 4) && (i != my_ID))
    {
        struct player_data& player_temp = players[i];

        if(isConnected(my_Pos, players[i].pos_cur, client) > 0)
        {
            if ((player_temp.hp <= 70) && (player_temp.hp > 0) && (escape_turns < 0))
                {
                    client.attack(player_temp.pos_cur, i);
                    flag_0 = false;
                }
            else if ((my_hp <= (70 * number_enemy_around)) && (escape_turns < 0))
            {
                int num_enemy_around_temp0 = number_enemy_around;
                int num_enemy_around_temp1;
                Pos pos_temp(-1, -1, -1);
                for(int j = 0; j < pos_nearby.size(); j++)
                {
                    num_enemy_around_temp1 = num_enemy_nearby(pos_nearby[j], 1, client);

                    if(num_enemy_around_temp0 > num_enemy_around_temp1)
                    {
                        num_enemy_around_temp0 = num_enemy_around_temp1;
                        pos_temp = pos_nearby[j];
                    }
                }

                if (get<0>(pos_temp) >= 0)
                {
                    if (my_Inventory.blinks_num > 0)
                    {
                        client.blink(pos_temp);
                        play(client);
                    }
                    else
                    {
                        client.move(pos_temp);
                    }
                    flag_0 = false;
                }
            }
            else if ((my_hp <= (70 * number_enemy_around)) && (escape_turns > 1))
            {
                client.escape(false);
                escape_turns = -1;

                if (my_Inventory.blinks_num > 0)
                {
                    int num_enemy_around_temp0 = number_enemy_around;
                    int num_enemy_around_temp1;
                    Pos pos_temp;
                    for (int j = 0; j < pos_nearby.size(); j++)
                    {
                        num_enemy_around_temp1 = num_enemy_nearby(pos_nearby[j], 1, client);

                        if (num_enemy_around_temp0 > num_enemy_around_temp1)
                        {
                            num_enemy_around_temp0 = num_enemy_around_temp1;
                            pos_temp = pos_nearby[j];
                        }
                        client.blink(pos_temp);
                    }
                }
            }
            else if((my_hp >= (player_temp.hp - 70)) && (player_temp.hp > 0) && (escape_turns < 0))
            {
                client.attack(player_temp.pos_cur, i);
                flag_0 = false;
            }
        }

        i++;
    };

    //escape相关
    if(flag_0 && (my_keys.size() == 4))
    {
        Pos pos_temp = client.get_escape_pos();
        if(my_Pos != pos_temp)
        {
            Pos next_pos = client.find_shortest_path(my_Pos, pos_temp)[1];
            client.move(next_pos);
            flag_0 = false;
        }
        else if (escape_turns == -1)
        {
            escape_turns = 3;
            client.escape(true);
            flag_0 = false;
        }
        else if (escape_turns == 0)
        {
            flag_0 = false;
        }
        else if (escape_turns > 0)
        {
            flag_0 = false;
        }
    }

    //捡key
    if (flag_0)
    {
        if (flag_key0_curpos)
        {
            client.get_key();
            flag_0 = false;      
            //output("get_key()");
        }
        else if (flag_key_curpos)
        {
            client.inspect_box();
            flag_0 = false;
            //output("inspect_box()");
        }
    }
    //else output("get key--false");

    //heal
    if(flag_0)
    {
        if ((my_hp <= 120) && (my_Inventory.kits_num > 0))
        {
            client.use_kit();
            flag_0 = false;
        }
    }

    //move
    if(flag_0)
    {
        Pos next_pos = calculate_next_pos(client);
        if ((turn > 5) && (client.get_check_cd() <= 0))
        {
            client.detect(next_pos);
        }

        if (my_Inventory.blinks_num == 2)
        {
            client.blink(next_pos);
            play(client);
        }
        else 
        {
            client.move(next_pos);
        }
        flag_0 = false;
    }
    //else output("move--false");

    client.finish();
}


/****************************************************************************************************************/

//检测是否为所求的钥匙
bool check_key(int key)
{
    
    bool flag = true;
    int i = 0;

    while (flag && (i < my_keys.size()))
    {
        if (key == my_keys[i])
        {
            flag = false;
        }

        i++;
    }

    return (flag);
}

//钥匙机初始化
void keys_on_map0_init(AI_Client &client)
{
    Pos pos_temp;
    pair<int, Pos> tmp;
    for (int i = 0; i < 4; i++)
    {

        pos_temp = client.get_spawn_pos(i);
        tmp = pair<int, Pos>(i, pos_temp);
        keys_on_map0.push_back(tmp);

        get<2>(tmp.second) = 2;
        keys_on_map0.push_back(tmp);
    }
}

//检测当前位置是否有可拾取物
void check_current_position(AI_Client &client)
{
    for(int i = 0; i < 8; i++)
    {
        if((my_Pos == keys_on_map0[i].second) && (check_key(keys_on_map0[i].first)))
        {
            flag_key0_curpos = true;
            break;
        }
    }

    {
        std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(my_Pos));
        if (val.first)
        {
            if (val.second.size() == 2)
            {
                flag_key_curpos = true;
                flag_item_curpos = true;
            }
            else if (val.second[0] == "Materials")
                flag_item_curpos = true;
            else
                flag_key_curpos = true;

        }
    }
}

//判断a,b是否相邻      相同 2  相邻 1  不相邻 0
int isConnected(Pos a,Pos b, AI_Client& client)
{
    if(a==b)
        return 2;
    vector<Pos> neighbors=client.get_neighbors(a);
    for(int i=0;i<neighbors.size();i++)
        if(neighbors[i]==b)
            return 1;
    return 0;
}

//获取敌军信息
void check_enemy(AI_Client& client)
{
    for(int i = 0; i < 4; i++)
    {
        if(i == my_ID)
            continue;
        
        players[i].pos_cur = client.get_others_pos(i);
        
        if(std::get<2>(players[i].pos_cur) >= 0)
        {
            players[i].pos_last = players[i].pos_cur;
            players[i].see_last_turn = turn;
            players[i].hp = client.get_others_hp(i);
        }

        if(players[i].hp <= 0)
        {
            players[i].pos_cur = client.get_spawn_pos(i);
            players[i].see_last_turn = turn;

            if(players[i].hp_old > 0)
                players[i].relive_turns = 6;
        }

        if(players[i].relive_turns > 0)
            players[i].relive_turns--;
        
        players[i].hp_old = players[i].hp;
    }
}

//计算需要的keys
int check_keys(AI_Client& client)
{
    keys_wanted.clear();

    bool flag = true;
    int j;
    for(int i = 0; i < 4; i++)
    {
        flag = true;//未在my_keys中出现

        j = 0;
        while(flag && (j < my_keys.size()))
        {
            if(my_keys[j] == i)
            {
                flag = false;
            }

            j++;
        }

        if(flag)
            keys_wanted.push_back(i);
    }

    return (keys_wanted.size());
}

//根据情况选择拾取的道具
bool get_prop(AI_Client& client)
{
    bool result = true;
    if((my_hp + my_Inventory.kits_num * 100) <= 140)
    {
        client.inspect_materials("Kit");
    }
    else if (my_Inventory.blinks_num < 2)
    {
        client.inspect_materials("Transport");
    }
    else if (my_Inventory.kits_num < 2)
    {
        client.inspect_materials("Kits");
    }
    else if(my_Inventory.trapbag["LandMine"][0][0] < 3)
    {
        client.inspect_materials("LandMine");
    }
    else if(my_Inventory.trapbag["Sticky"][0][0] < 3)
    {
        client.inspect_materials("LandMine");
    }
    else 
    {
        result = false;
    }

    return (result);
}

//计算一个位置在turns_later后相邻的敌人数（假设敌人不动）
int num_enemy_nearby(Pos a,int turns_later, AI_Client& client)
{
    int number = 0;
    for(int i = 0; i <= 4; i++)
    {
        if((i != my_ID) && (players[i].relive_turns <= turns_later) && (isConnected(a, players[i].pos_cur, client) > 0))
        {
            number++;
        }
    }

    return(number);
}

//获得所在层的所有可拾取物与可拾取KEY的位置，分别存在vector中,
void check_map(const Pos& pos, AI_Client& client)
{
    items_on_map.clear();
    keys_on_map.clear();


    vector<Pos> nodes = client.get_neighbors(my_Pos);
    //output((int)nodes.size());

    for (int i = 0; i < nodes.size(); i++)
    {
        /*
        output("x");
        output((int)get<0>(nodes[i]));
        output("y");
        output((int)get<1>(nodes[i]));
        output("z");
        output((int)get<2>(nodes[i]));
        */
        std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(nodes[i]));

        //output(i);

        if (val.first)
        {
            pair<int, Pos> tmp = pair<int, Pos>(4, nodes[i]);

            //output(val.second[0]);

            if (val.second.size() == 2)
            {
                keys_on_map.push_back(tmp);
                items_on_map.push_back(tmp);

                //output(val.second[1]);
            }
            else if (val.second[0] == "Materials")
                items_on_map.push_back(tmp);
            else
                items_on_map.push_back(tmp);
        }
    }

    //output("end");
    /*
    for(int i = 0; i <= 6; i++)
    {
        std::get<0>(pos_temp) = i;
        for(int j = 0; j <= 6; j++)
        {                   
            timer.tic();
            std::get<1>(pos_temp) = j;
            output(std::get<0>(pos_temp));
            output(std::get<1>(pos_temp));
            output(std::get<2>(pos_temp));

            
            
            std::pair<bool, std::vector< std::string> > val=client.judge_if_can_pick(client.pos2node(pos_temp));
            output("val");
            output((int)val.first);

     

            timer.toc();
            if (val.first)
            {
                pair<int, Pos> tmp = pair<int, Pos>(4, pos_temp);

                output(val.second[0]);

                if(val.second.size() == 2)
                {
                    keys_on_map.push_back(tmp);
                    items_on_map.push_back(tmp);
                                
                    output(val.second[1]);
                }
                else if (val.second[0] == "Materials")
                    items_on_map.push_back(tmp);
                else items_on_map.push_back(tmp);
            }
            timer.toc();
        }
    }*/

    
}

//计算下一位移目标
Pos calculate_next_pos(AI_Client& client)
{
    Pos next_pos;
    int max = keys_on_map.size();
    int distance_temp0 = 100;
    int distance_temp1;
    int i;

    /*output("calculate_next_pos");
    timer.toc();
    output("max");
    output(max);*/
    /*
    output("----turns----");
    output(turn);
    output(my_keys);

    output("current pos");
    output(my_Pos);
    */
    for(i = 0; i < max; i++)
    {
        /*output("i");
        output(i);
        output("calculate_next_pos");
        timer.toc();*/
        
        /*output("keys_on_map[i].first");
        output((int)keys_on_map[i].first);
        output(keys_on_map0[i].second);
        output("bool");
        output((int)check_key(keys_on_map[i].first));*/
        if(check_key(keys_on_map[i].first))
        {
            /*output("start");
            timer.toc();*/
            vector<Pos> path = client.find_shortest_path(my_Pos, keys_on_map[i].second);
            //output((int)path.size());
            distance_temp1 = path.size()-1;

            if(distance_temp1 < distance_temp0)
            {
                distance_temp0 = distance_temp1;
                next_pos = path[1];
            }
        }
    }

    /*output("second for");
    timer.toc();*/
    for(i = 0; i < 8; i++)
    {
        /*output("i");
        output(i);
        timer.toc();
        output(keys_on_map0[i].first);*/

        /*output("keys_on_map0[i].first");
        output((int)keys_on_map0[i].first);
        output(keys_on_map0[i].second);
        output("bool");
        output((int)check_key(keys_on_map0[i].first));*/

        if(check_key(keys_on_map0[i].first))
        {
            vector<Pos> path = client.find_shortest_path(my_Pos, keys_on_map0[i].second);
            distance_temp1 = path.size()-1;

            if(distance_temp1 < distance_temp0)
            {
                distance_temp0 = distance_temp1;
                next_pos = path[1];
            }
        }        
    }
    
    /*output("next_pos");
    output(next_pos);*/
    return (next_pos);
}

/************************************************************************************************************/
/*void output(int num)
{
    ofstream out;
    out.open("text.txt", ios::app|ios::out);
    out << "record: " <<num<< endl;
};
void output(double num)
{
    ofstream out;
    out.open("text.txt", ios::app|ios::out);
    out << "record: " <<num<< endl;
};
void output(string str)
{
    ofstream out;
    out.open("text.txt", ios::app|ios::out);
    out << "record: " <<str<< endl;
};
void output(Pos pos)
{
    ofstream out;
    out.open("text.txt", ios::app|ios::out);
    out << "Pos: " <<get<0>(pos)<<", "<<get<1>(pos)<<", "<<get<2>(pos)<<", "<< endl;
};
void output(vector<int> key)
{
    ofstream out;
    out.open("text.txt", ios::app|ios::out);
    out << "key: ";
    for (int i = 0; i < key.size(); i++)
        out << key[i] << " , " << endl;
};*/
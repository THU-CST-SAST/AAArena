"""AquaWar process placement and replay-based result interpretation."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or not self.role:
            raise ValueError("match role must be a non-empty string")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise ValueError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    points: float | None
    score_margin: float | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.points is None:
                raise ValueError("complete match requires an outcome")
            if self.rounds is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or self.points is not None:
                raise ValueError("incomplete match cannot be scored")
            if not self.error:
                raise ValueError("incomplete match requires an error")
        else:
            raise ValueError(f"unknown match status: {self.status}")


class AquaWarMatchError(RuntimeError):
    """The AquaWar replay does not contain a valid scored terminal state."""


def _load_replay_array(path: Path) -> list[dict[str, Any]]:
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise AquaWarMatchError(f"cannot read replay {path}: {exc}") from exc
    if not raw:
        raise AquaWarMatchError("replay file is empty")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        # A historical AquaWar backend can append a second renderer document
        # after the complete replay array.  Decode the first JSON value and
        # discard the trailing private/debug stream.
        try:
            value, _ = json.JSONDecoder().raw_decode(raw.lstrip())
        except json.JSONDecodeError:
            raise AquaWarMatchError(f"cannot parse replay {path}: {exc}") from exc
    if not isinstance(value, list) or not value:
        raise AquaWarMatchError("replay must be a non-empty JSON array")
    return [record for record in value if isinstance(record, dict)]


def match_result_from_replay(
    replay_path: str | Path,
    *,
    candidate_id: str,
    opponent_id: str,
    role: str,
    seed: int,
    events_path: str | Path | None = None,
    process_returncodes: tuple[int, int, int] | None = None,
) -> MatchResult:
    case = MatchCase(candidate_id, opponent_id, role, seed)
    source = Path(replay_path).resolve()
    records = _load_replay_array(source)
    terminal = next((record for record in reversed(records) if "score" in record), None)
    if terminal is None:
        raise AquaWarMatchError("replay has no scored terminal state")
    raw_score = terminal.get("score")
    if isinstance(raw_score, bool) or not isinstance(raw_score, (int, float)):
        raise AquaWarMatchError("replay terminal score is not numeric")
    score = float(raw_score)
    rounds = terminal.get("rounds")
    if isinstance(rounds, bool) or not isinstance(rounds, int):
        rounds = len(records)
    winner_player = 0 if score > 0 else 1 if score < 0 else None
    candidate_player = 0 if role == "P0" else 1
    if winner_player is None:
        outcome: Outcome = "draw"
        points = 0.5
    elif winner_player == candidate_player:
        outcome = "win"
        points = 1.0
    else:
        outcome = "loss"
        points = 0.0
    return MatchResult(
        case=case,
        status="complete",
        result=outcome,
        points=points,
        score_margin=score if candidate_player == 0 else -score,
        rounds=int(rounds),
        payload={
            "score": score,
            "winner_player": winner_player,
            "replay_player_errors": [
                {"role": f"P{error['player']}", "type": error.get("type")}
                for record in records
                for error in record.get("errors", [])
                if isinstance(error, dict)
                and type(error.get("player")) is int
                and error["player"] in (0, 1)
            ],
        },
        replay_path=source,
        events_path=None if events_path is None else Path(events_path).resolve(),
        process_returncodes=process_returncodes,
    )


def run_native_match(
    *,
    game: ProcessSpec,
    candidate_process: ProcessSpec,
    opponent_process: ProcessSpec,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    candidate_player = 0 if case.role == "P0" else 1
    players = (
        (candidate_process, opponent_process)
        if candidate_player == 0
        else (opponent_process, candidate_process)
    )
    judged = run_stdio_match(
        backend=game,
        players=players,
        config={},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    raw_end = judged.end_message.get("end_info")
    try:
        end_info = json.loads(raw_end) if isinstance(raw_end, str) else raw_end
        official_scores = (float(end_info["0"]), float(end_info["1"]))
    except (TypeError, KeyError, ValueError) as exc:
        raise AquaWarMatchError("invalid official terminal end_info") from exc
    import math
    if not all(math.isfinite(score) for score in official_scores):
        raise AquaWarMatchError("non-finite official terminal score")
    adjudicated = _adjudicated_replay(replay_path, official_scores)
    result = match_result_from_replay(
        adjudicated,
        candidate_id=case.candidate_id,
        opponent_id=case.opponent_id,
        role=case.role,
        seed=case.seed,
        events_path=events_path,
        process_returncodes=tuple(judged.process_returncodes[:3]),
    )
    return replace(result, payload={**result.payload,
        "official_terminal_scores": official_scores,
        "official_draw": official_scores[0] == official_scores[1]})


def _adjudicated_replay(source: Path, official_scores: tuple[float, float]) -> Path:
    """Preserve raw evidence; publish corrected terminal evidence on disagreement.

    The backend may end a forfeit before updating the replay's ordinary score.
    Its terminal end_info is authoritative, including a zero-round forfeit.
    """
    records = _load_replay_array(source)
    terminal = next((r for r in reversed(records) if "score" in r), None)
    if terminal is None:
        raise AquaWarMatchError("replay has no scored terminal state")
    raw_score = terminal["score"]
    if isinstance(raw_score, bool) or not isinstance(raw_score, (int, float)):
        raise AquaWarMatchError("replay terminal score is not numeric")
    margin = official_scores[0] - official_scores[1]
    if (raw_score > 0) - (raw_score < 0) == (margin > 0) - (margin < 0):
        return source
    terminal.update(replay_score=raw_score, score=margin,
                    official_scores=list(official_scores),
                    adjudication_source="official_end_info", over=True)
    corrected = source.with_name(source.stem + ".adjudicated.json")
    corrected.write_text(json.dumps(records, ensure_ascii=False) + "\n", encoding="utf-8")
    return corrected


Runner = Callable[..., MatchResult]


class AquaWarArena:
    def __init__(
        self,
        *,
        game: ProcessSpec,
        candidate: ProcessSpec,
        opponent: ProcessSpec,
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
        runner: Runner = run_native_match,
    ) -> None:
        self.game = game
        self.candidate = candidate
        self.opponent = opponent
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)
        self.runner = runner

    def run_case(self, case: MatchCase) -> MatchResult:
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role.lower()
            / f"seed-{case.seed}"
        )
        try:
            return self.runner(
                game=self.game,
                candidate_process=self.candidate,
                opponent_process=self.opponent,
                case=case,
                replay_path=root / "replay.json",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            AquaWarMatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                points=None,
                score_margin=None,
                rounds=None,
                error=str(exc),
            )

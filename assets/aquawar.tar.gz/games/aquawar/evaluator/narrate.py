"""AquaWar 回放 → 自然语言。

AquaWar（第 25 届）的回放是一个 JSON 数组，每元素是一次**状态快照**（不是"一回合"）：
选卡（Pick）、断言（Assert）、行动（Action）都各占一帧，字段有 ``gamestate`` /
``operation`` / ``players`` / ``winner``。

这个游戏的核心是**隐藏信息**：双方各选 4 条鱼但鱼种对对手不可见，靠 Assert（断言
某个位置是哪种鱼）来揭示。所以叙述里最值钱的两件事是：

1. **断言的对与错** —— 断言对了会暴露对手的鱼，断言错了自己扣血。这是唯一的
   信息博弈通道，也是最容易看出对手风格的地方（激进猜 vs 从不猜）；
2. **鱼的死亡顺序** —— 谁先被集火、集火了几轮，直接决定阵型的成败。
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, budget_lines, render_events

_ROLES = ("P0", "P1")

#: `gamestate` 语义（后端 GameState 枚举）。
_GAMESTATE = {0: "未开始", 1: "选鱼", 2: "行动", 3: "断言", 4: "结算"}


def _load(path: Path) -> Sequence[Mapping[str, object]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, list) or not document:
        raise ValueError("aquawar 回放应当是非空 JSON 数组（每元素一帧状态快照）")
    return [frame for frame in document if isinstance(frame, Mapping)]


def _fish_label(fish: Mapping[str, object]) -> str:
    identity = fish.get("id")
    hp = fish.get("hp")
    atk = fish.get("atk")
    exposed = fish.get("is_expose")
    alive = "" if (isinstance(hp, (int, float)) and hp > 0) else "（已死）"
    flag = "，已暴露" if exposed else ""
    return f"鱼#{identity} hp={hp} atk={atk}{flag}{alive}"


def _describe_operation(operation: Mapping[str, object], context: NarrationContext) -> str:
    action = str(operation.get("Action", "?"))
    if action == "Pick":
        fishes = operation.get("Fish")
        if isinstance(fishes, list):
            ids = [item.get("id") for item in fishes if isinstance(item, Mapping)]
            return f"选鱼：{ids}"
        return "选鱼"
    if action == "Assert":
        return f"断言：敌方位置 {operation.get('Pos')} 是鱼种 {operation.get('ID')}"
    if action == "Null":
        return "放弃断言"
    if action == "Action":
        kind = operation.get("Type")
        if kind == 0:
            return f"普通攻击：我方 {operation.get('MyPos')} → 敌方 {operation.get('EnemyPos')}"
        return (
            f"释放技能：我方 {operation.get('MyPos')}"
            f"（友方目标 {operation.get('MyList')} / 敌方目标 {operation.get('EnemyList')}）"
        )
    if action == "Finish":
        return "小局结束回执"
    return f"未识别动作 {action}"


def _assert_ledger(frames: Sequence[Mapping[str, object]], context: NarrationContext) -> list[str]:
    """把断言的成败统计出来 —— 这是本游戏唯一的信息博弈维度。

    判定方式：断言之后若目标鱼的 ``is_expose`` 变成 True，说明断中了。
    这样判定的好处是**只用公开字段**，不需要偷看后端内部的隐藏鱼种。
    """

    attempts: dict[str, int] = {role: 0 for role in _ROLES}
    hits: dict[str, int] = {role: 0 for role in _ROLES}
    passes: dict[str, int] = {role: 0 for role in _ROLES}
    for index, frame in enumerate(frames):
        operations = frame.get("operation")
        if not isinstance(operations, list):
            continue
        turn = frame.get("cur_turn")
        role = f"P{turn}" if turn in {0, 1} else None
        for operation in operations:
            if not isinstance(operation, Mapping):
                continue
            action = operation.get("Action")
            if role is None:
                continue
            if action == "Null":
                passes[role] += 1
                continue
            if action != "Assert":
                continue
            attempts[role] += 1
            position = operation.get("Pos")
            after = frames[index + 1] if index + 1 < len(frames) else None
            if after is None or not isinstance(position, int):
                continue
            players = after.get("players")
            if not isinstance(players, list):
                continue
            enemy_index = 1 - int(turn)  # type: ignore[arg-type]
            if enemy_index >= len(players) or not isinstance(players[enemy_index], Mapping):
                continue
            enemy_fish = players[enemy_index].get("fight_fish")
            if isinstance(enemy_fish, list) and position < len(enemy_fish):
                target = enemy_fish[position]
                if isinstance(target, Mapping) and target.get("is_expose"):
                    hits[role] += 1
    lines: list[str] = []
    for role in _ROLES:
        if attempts[role] == 0 and passes[role] == 0:
            continue
        rate = f"{hits[role]}/{attempts[role]}" if attempts[role] else "0/0"
        lines.append(
            f"- {context.label(role)} 断言 {attempts[role]} 次、命中 {rate}，"
            f"另有 {passes[role]} 次主动放弃断言。"
        )
    if not lines:
        return ["- 双方整局都没有做过断言（信息博弈通道完全没被使用）。"]
    return lines


def _death_order(frames: Sequence[Mapping[str, object]], context: NarrationContext) -> list[str]:
    """鱼的死亡顺序 —— 阵型成败的直接证据。"""

    dead: list[str] = []
    seen: set[tuple[int, object]] = set()
    for index, frame in enumerate(frames):
        players = frame.get("players")
        if not isinstance(players, list):
            continue
        for side, player in enumerate(players):
            if not isinstance(player, Mapping):
                continue
            fishes = player.get("fight_fish")
            if not isinstance(fishes, list):
                continue
            for fish in fishes:
                if not isinstance(fish, Mapping):
                    continue
                hp = fish.get("hp")
                identity = fish.get("id")
                if not isinstance(hp, (int, float)) or hp > 0:
                    continue
                key = (side, identity)
                if key in seen:
                    continue
                seen.add(key)
                dead.append(
                    f"- 第 {index} 帧：{context.label(f'P{side}')} 的鱼#{identity} 阵亡"
                )
    return dead or ["- 回放没有记录鱼阵亡。"]


def _state_deltas(
    frames: Sequence[Mapping[str, object]], context: NarrationContext
) -> list[str]:
    lines: list[str] = []
    for index, (before, after) in enumerate(zip(frames, frames[1:], strict=False), start=1):
        before_players = before.get("players")
        after_players = after.get("players")
        if not isinstance(before_players, list) or not isinstance(after_players, list):
            continue
        for side in range(min(len(before_players), len(after_players))):
            old_player, new_player = before_players[side], after_players[side]
            if not isinstance(old_player, Mapping) or not isinstance(new_player, Mapping):
                continue
            old_fish = old_player.get("fight_fish")
            new_fish = new_player.get("fight_fish")
            if not isinstance(old_fish, list) or not isinstance(new_fish, list):
                continue
            old_hp = {
                fish.get("id"): float(fish["hp"])
                for fish in old_fish
                if isinstance(fish, Mapping) and isinstance(fish.get("hp"), (int, float))
            }
            for fish in new_fish:
                if not isinstance(fish, Mapping) or fish.get("id") not in old_hp:
                    continue
                hp = fish.get("hp")
                if not isinstance(hp, (int, float)):
                    continue
                previous = old_hp[fish.get("id")]
                current = float(hp)
                if previous != current:
                    lines.append(
                        f"- 第 {index} 帧：{context.label(f'P{side}')} 鱼#{fish.get('id')} HP "
                        f"{previous:g}→{current:g}（{current - previous:+g}）。"
                    )
    return lines or ["- 相邻状态帧中的鱼 HP 均未变化。"]


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    frames = _load(replay_path)
    final = frames[-1]
    raw_winner = final.get("winner")
    winner = f"P{raw_winner}" if raw_winner in {0, 1} else None
    winner = context.official_winner or winner
    rounds = context.official_rounds
    if rounds is None:
        raw_rounds = final.get("rounds")
        rounds = int(raw_rounds) if isinstance(raw_rounds, int) else len(frames)

    verdict: list[str] = []
    if winner is None:
        verdict.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        verdict.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        verdict.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        verdict.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    verdict.append(f"- 回放共 {len(frames)} 帧状态快照，官方回合数 {rounds}。")
    players = final.get("players")
    if isinstance(players, list):
        for side, player in enumerate(players):
            if not isinstance(player, Mapping):
                continue
            fishes = player.get("fight_fish") or player.get("my_fish")
            if isinstance(fishes, list) and fishes:
                detail = "；".join(
                    _fish_label(fish) for fish in fishes if isinstance(fish, Mapping)
                )
                verdict.append(f"- {context.label(f'P{side}')} 终局阵容：{detail}。")
    if context.diagnostic:
        verdict.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")

    events: list[Event] = []
    for index, frame in enumerate(frames):
        operations = frame.get("operation")
        if not isinstance(operations, list) or not operations:
            continue
        turn = frame.get("cur_turn")
        actor = context.label(f"P{turn}") if turn in {0, 1} else "系统"
        phase = _GAMESTATE.get(frame.get("gamestate"), "?")  # type: ignore[arg-type]
        for operation in operations:
            if not isinstance(operation, Mapping):
                continue
            text = _describe_operation(operation, context)
            signature = json.dumps(
                operation,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            events.append(
                Event(
                    round=index,
                    actor=actor,
                    text=f"[{phase}] {text}",
                    ref=f"frame{index:04d}",
                    # digest 只折叠同一玩家完全相同的动作参数；跨度和次数仍会保留。
                    fold_key=f"repeat:{signature}",
                    fold_label=f"重复动作：[{phase}] {text}",
                )
            )

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"AquaWar 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"共 {len(frames)} 帧 / {len(events)} 条动作。"
            "由 A 仓 `aa_arena.replay` 从官方回放翻译。"
            "动作和状态数值均来自回放中的公开字段。"
        ),
    )
    doc.section("终局事实", verdict + _death_order(frames, context))
    state_lines = _assert_ledger(frames, context) + _state_deltas(frames, context)
    if context.detail != "full":
        state_lines = budget_lines(state_lines, 120)
    doc.section("状态变化与数值增量", state_lines)
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=160)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=160。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="aquawar",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights={"frames": len(frames), "actions": len(events)},
    )

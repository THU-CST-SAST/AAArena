"""Frozen AquaWar (25th) resources, builds, and human-pool audit.

AquaWar 的对战器内核（游戏资产），属仓库 A。负责：
- 从后端**源码目录**编译官方 C++ 后端（可复现于全新 checkout）；
- 编译人类天梯选手（AquaWar 选手为 C++，各自带 Makefile，需逐个编译）；
- 审计冻结的人类天梯选手池（players/manifest.tsv 中带 rank 的选手）。

协议与 antwar2 同属 Saiblo C++（4 字节大端长度前缀 + 4 字节 object_id 的 stdio
帧），但 AquaWar 的终局标志是 ``{"state": -1, ...}`` 而非 ``end_state`` 键，且
init 消息不含随机种子（AquaWar 先手固定、确定性）。

本模块**不依赖任何框架**，可被 A 的 evaluator 直接调用，也可被 B/C 通过 A 复用。
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.buildcache import published_build_dir
from aa_arena.core.cpp_build import (
    CppBuildError,
    build_cpp_player,
    has_cpp_build as common_has_cpp_build,
)


class AquaWarRuntimeError(RuntimeError):
    """A frozen runtime resource failed an integrity requirement."""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)
_GAME_DIR = Path(__file__).resolve().parents[1]


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_sha256(root: Path) -> str:
    """Content hash of a directory tree (ignores __pycache__/*.pyc/built binaries)."""

    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise AquaWarRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        # 跳过构建产物，保证从干净 checkout 复现（可执行 main 无扩展名）。
        if path.name in {"main", "main.exe"} and os.access(path, os.X_OK):
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class AquaWarLayout:
    aa_arena_root: Path
    build_root: Path
    backend_source_root: Path
    human_manifest: Path
    human_extracted_root: Path

    @classmethod
    def from_root(cls, aa_arena_root: str | Path, build_root: str | Path) -> AquaWarLayout:
        aa_arena = Path(aa_arena_root).resolve()
        players = aa_arena / "games/aquawar/players"
        pool = players / "pool"
        backend = aa_arena / "games/aquawar/backend"
        return cls(
            aa_arena_root=aa_arena,
            build_root=Path(build_root).resolve(),
            backend_source_root=(backend / "logic/gamecode_logic"),
            human_manifest=players / "manifest.tsv",
            human_extracted_root=pool,
        )

    def backend_fingerprint(self) -> str:
        if self.backend_source_root.is_dir():
            return tree_sha256(self.backend_source_root)
        raise FileNotFoundError(self.backend_source_root)

    def validate(self) -> None:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_extracted_root.is_dir():
            raise FileNotFoundError(self.human_extracted_root)


# ---------------------------------------------------------------------------
# C++ 编译（后端与选手共用）
# ---------------------------------------------------------------------------

_EXE = "main.exe" if sys.platform == "win32" else "main"
_MAKEFILE_NAMES = ("Makefile", "makefile", "GNUmakefile")


def _looks_like_cpp_makefile(makefile: Path) -> bool:
    """判断这个 Makefile 是否真的在编译 C++。

    选手包里常常带着**文档**的 Makefile（Sphinx 的 ``make help/html``）。
    只按"最浅"挑选会挑到 ``docs/Makefile``，于是 make 报
    ``sphinx-build: not found``，一个能正常编译的选手被误判为"编译失败"。
    """

    try:
        text = makefile.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    lowered = text.lower()
    if "sphinx" in lowered or "sphinx-build" in lowered:
        return False
    return any(
        marker in text
        for marker in ("g++", "clang++", "CXX", "CXXFLAGS", ".cpp", ".cc", ".cxx")
    )


def _find_makefile_dir(root: Path) -> Path:
    """在选手/后端包中定位**编译 C++** 的 Makefile 所在目录（可能嵌一层子目录）。"""

    for name in _MAKEFILE_NAMES:
        direct = root / name
        if direct.is_file() and _looks_like_cpp_makefile(direct):
            return root
    candidates = [
        path
        for name in _MAKEFILE_NAMES
        for path in sorted(root.rglob(name))
        if _looks_like_cpp_makefile(path)
    ]
    if not candidates:
        raise AquaWarRuntimeError(f"no C++ Makefile found under {root}")
    # 多个真实构建入口时取最浅、再按路径字典序；文档 Makefile 已在上面剔除。
    candidates.sort(
        key=lambda item: (
            len(item.relative_to(root).parts),
            item.as_posix(),
        )
    )
    return candidates[0].parent


def _makefile_in(directory: Path) -> Path | None:
    for name in _MAKEFILE_NAMES:
        path = directory / name
        if path.is_file() and _looks_like_cpp_makefile(path):
            return path
    return None


def _parse_makefile_gpp(makefile: Path) -> list[str] | None:
    """从 Makefile 的默认目标提取 g++ 编译命令的参数（用于跨平台回退编译）。

    仅解析形如 ``g++ <sources...> -o main -std=... ...`` 的简单命令，返回参数列表
    （不含 g++ 本身，且移除 -o main 目标，由调用方统一指定输出）。返回 None 表示
    无法安全解析。
    """

    text = makefile.read_text(encoding="utf-8", errors="replace")
    # 取第一条 g++ 命令行（第一个规则的配方）。
    match = re.search(r"^\s*(g\+\+|clang\+\+)\s+(.*)$", text, re.MULTILINE)
    if match is None:
        return None
    return match.group(2).split()


def _compile_with_makefile(build_dir: Path, timeout: float = 300.0) -> subprocess.CompletedProcess:
    make_dir = _find_makefile_dir(build_dir)
    return subprocess.run(
        ("make", "-C", str(make_dir), f"-j{max(1, min(os.cpu_count() or 1, 8))}"),
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout,
    ), make_dir


_COMPAT_SHIM = Path(__file__).resolve().parent / "compat_shim.h"


def _strip_std_and_output(args: list[str]) -> list[str]:
    """去掉原 ``-o <target>`` 与 ``-std=...``（回退时由调用方统一指定）。"""

    cleaned: list[str] = []
    skip_next = False
    for tok in args:
        if skip_next:
            skip_next = False
            continue
        if tok == "-o":
            skip_next = True
            continue
        if tok.startswith("-std="):
            continue
        cleaned.append(tok)
    return cleaned


def _compile_fallback(make_dir: Path, timeout: float = 300.0) -> subprocess.CompletedProcess | None:
    """跨平台回退：用从 Makefile 解析出的 g++ 命令自行编译。

    这些 Saiblo 选手为 Linux GNU g++/libstdc++ 编写；在 Apple clang/libc++ 上可能因
    ``std::reduce`` 名字冲突或已被 C++17 移除的 ``std::random_shuffle`` 而失败。
    先用多个标准版本原样编译。只有编译器明确报告 ``random_shuffle`` 缺失时才注入
    兼容垫片；GNU libstdc++ 仍提供该符号，无条件注入会产生 redefinition，并把真正的
    第一条编译错误覆盖掉。失败时返回包含全部尝试输出的结果，供审计定位根因。
    """

    makefile = _makefile_in(make_dir)
    if makefile is None:
        return None
    args = _parse_makefile_gpp(makefile)
    if args is None:
        return None
    base = _strip_std_and_output(args)
    attempts: list[subprocess.CompletedProcess] = []
    for std in ("-std=c++17", "-std=c++14", "-std=gnu++17"):
        cmd = ["g++", std, *base, "-o", _EXE]
        completed = subprocess.run(
            cmd, cwd=make_dir, capture_output=True, text=True, check=False, timeout=timeout
        )
        attempts.append(completed)
        if completed.returncode == 0 and (make_dir / _EXE).is_file():
            return completed

    missing_random_shuffle = any(
        re.search(
            r"(?:random_shuffle.{0,120}(?:not (?:a member|declared)|no member|undeclared)"
            r"|(?:no member(?: named)?|not (?:a member|declared)|undeclared)"
            r".{0,120}random_shuffle)",
            attempt.stderr or attempt.stdout,
            re.IGNORECASE,
        )
        is not None
        for attempt in attempts
    )
    if missing_random_shuffle and _COMPAT_SHIM.is_file():
        for std in ("-std=c++17", "-std=gnu++17"):
            cmd = ["g++", std, "-include", str(_COMPAT_SHIM), *base, "-o", _EXE]
            completed = subprocess.run(
                cmd, cwd=make_dir, capture_output=True, text=True, check=False, timeout=timeout
            )
            attempts.append(completed)
            if completed.returncode == 0 and (make_dir / _EXE).is_file():
                return completed

    last = attempts[-1]
    stdout = "\n".join(
        f"[{attempt.args!r}]\n{attempt.stdout}" for attempt in attempts if attempt.stdout
    )
    stderr = "\n".join(
        f"[{attempt.args!r}]\n{attempt.stderr}" for attempt in attempts if attempt.stderr
    )
    return subprocess.CompletedProcess(last.args, last.returncode, stdout, stderr)


def _built_executable(make_dir: Path) -> Path | None:
    exe = make_dir / _EXE
    if exe.is_file() and os.access(exe, os.X_OK):
        return exe
    # 有的 Makefile 把产物放进子目录（例如 antwar 后端 `OUTPUT := output` →
    # `output/main`）。此前这里只留了注释直接返回 None，导致 make 明明成功、
    # 却因为"找不到可执行文件"被判成编译失败——antwar 全池审计 0 通过就是这个原因。
    # 策略：找同名可执行文件，优先层级最浅、其次修改时间最新（本次构建产物）。
    candidates = [
        item
        for item in make_dir.rglob(_EXE)
        if item.is_file() and os.access(item, os.X_OK)
    ]
    if not candidates:
        return None
    candidates.sort(
        key=lambda item: (len(item.relative_to(make_dir).parts), -item.stat().st_mtime)
    )
    return candidates[0]


def compile_cpp_package(source_root: Path, build_dir: Path, *, timeout: float = 300.0) -> Path:
    """把 C++ 包（后端或选手）编译到 ``build_dir``，返回可执行文件路径。

    **并发安全**，用的是仓内统一的"先建后换"原语
    :func:`aa_arena.core.buildcache.published_build_dir`。

    为什么必须这样
    --------------
    ``build_dir`` 是**按源码内容哈希**命名的（见 :func:`build_player`），所以
    同一个选手的多局对局会落在**同一个目录**上。原来的写法是
    ``rmtree`` + ``copytree`` + ``make``，并行下会互相破坏：一个进程正在删目录，
    另一个进程的 ``g++`` 正在读同一份源码，于是报

        cc1plus: fatal error: Action.cpp: No such file or directory

    编译失败 → 那一局起不来 → 被记成 **0 回合对局**，而 0 回合局在上层会算成
    一个正常结果（判负/平局），既污染胜率又让人以为是选手代码写错了。

    实测（本机 8 线程同时编译同一个选手包）：无锁写法 **1/8 成功**，
    错误正是 ``No such file or directory`` 与 ``File exists``；换成本原语后 8/8。
    对局层面的表现：``s8k4-aquawar`` 16 局废了 8 局。

    miracle / lostspace / generals 早就迁到这个原语了（那次事故 527 局作废，
    见 buildcache 模块的详注），**只有 aquawar 与 antwar 漏了**——这次补上。
    """

    ignore = shutil.ignore_patterns("__pycache__", "*.pyc")
    with published_build_dir(build_dir, source=source_root, ignore=ignore) as (work, reused):
        if reused:
            # 别人已经发布好了同一内容哈希的产物，直接用，绝不重编译。
            exe = _built_executable(work)
            if exe is not None:
                return exe
            # 发布目录里没有可执行文件：这只可能是历史遗留的坏缓存
            # （旧写法留下的目录恰好带了完成标记）。报错而不是静默返回，
            # 否则上层会拿一个不存在的路径去起进程，错误指向对局而不是缓存。
            raise AquaWarRuntimeError(
                f"published build has no executable: {work}（删掉该目录后重跑即可）"
            )
        built = _compile_staged(source_root, work, timeout=timeout)
        # 产物路径要换算成**发布后**的位置：with 体内在暂存目录里，
        # 退出时会被原子 rename 到 build_dir 下的同名相对路径。
        relative = built.relative_to(work)
    exe = build_dir / relative
    if not exe.is_file():
        raise AquaWarRuntimeError(f"published build lost its executable: {exe}")
    return exe


def _compile_staged(source_root: Path, work: Path, *, timeout: float = 300.0) -> Path:
    """在**独占的暂存目录**里编译，返回暂存目录内的可执行文件路径。"""

    completed, make_dir = _compile_with_makefile(work, timeout=timeout)
    exe = _built_executable(make_dir)
    if completed.returncode == 0 and exe is not None:
        return exe
    # 回退到自解析编译（跨工具链兼容）。
    fallback = _compile_fallback(make_dir, timeout=timeout)
    exe = _built_executable(make_dir)
    if fallback is not None and fallback.returncode == 0 and exe is not None:
        return exe
    diag = (completed.stderr or completed.stdout)[-4000:]
    fb_diag = ""
    if fallback is not None:
        fb_diag = (fallback.stderr or fallback.stdout)[-4000:]
    raise AquaWarRuntimeError(
        f"C++ build failed for {source_root.name}:\n[make]\n{diag}\n[fallback]\n{fb_diag}"
    )


@dataclass(frozen=True)
class FrozenBackend:
    executable: Path
    source_sha256: str
    executable_sha256: str
    manifest_path: Path


def _load_manifest(manifest_path: Path) -> dict | None:
    if not manifest_path.is_file():
        return None
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def build_backend(layout: AquaWarLayout) -> FrozenBackend:
    layout.validate()
    source_hash = layout.backend_fingerprint()
    root = layout.build_root / f"backend-{source_hash[:16]}"
    manifest_path = root / "build-manifest.json"
    exe = root / "game" / _EXE
    cached = _load_manifest(manifest_path)
    if (
        cached is not None
        and cached.get("source_sha256") == source_hash
        and exe.is_file()
        and cached.get("executable_sha256") == sha256_file(exe)
    ):
        return FrozenBackend(exe, source_hash, str(cached["executable_sha256"]), manifest_path)
    game_dir = root / "game"
    built = compile_cpp_package(layout.backend_source_root, game_dir)
    exe = built
    exe_hash = sha256_file(exe)
    compiler = subprocess.run(
        ("g++", "--version"), capture_output=True, text=True, check=False, timeout=10
    )
    manifest = {
        "schema_version": "1.0",
        "source": str(layout.backend_source_root),
        "source_sha256": source_hash,
        "executable": str(exe),
        "executable_sha256": exe_hash,
        "platform": platform.platform(),
        "python": sys.version,
        "compiler": (compiler.stdout or compiler.stderr).splitlines()[0] if (compiler.stdout or compiler.stderr) else "unknown",
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return FrozenBackend(exe, source_hash, exe_hash, manifest_path)


@dataclass(frozen=True)
class Opponent:
    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    package_root: Path
    package_sha256: str
    runnable: bool
    exclusion_diagnostic: str | None


def audit_human_pool(layout: AquaWarLayout) -> tuple[Opponent, ...]:
    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            packages = tuple(sorted(layout.human_extracted_root.glob(f"rank{rank:02d}__*")))
            if len(packages) != 1:
                raise AquaWarRuntimeError(f"rank{rank:02d} maps to {len(packages)} pool packages")
            package = packages[0]
            # 语言分派：C++ 提交要能定位到真正编译 C++ 的 Makefile；
            # Python 提交（``main.py``，Saiblo 直接 ``python main.py``）同样可运行。
            # 此前这里只认 Makefile，于是所有 Python 提交都被记成"不可运行"。
            if has_cpp_build(package):
                runnable = True
                diag = None
            elif _python_entry(package) is not None:
                runnable = True
                diag = None
            else:
                runnable = False
                diag = "neither a C++ build nor main.py"
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    package_root=package,
                    package_sha256=tree_sha256(package),
                    runnable=runnable,
                    exclusion_diagnostic=diag,
                )
            )
    pool.sort(key=lambda item: item.rank)
    publication = layout.human_manifest.parent / "publication.json"
    if publication.is_file():
        allowed = json.loads(publication.read_text(encoding="utf-8"))["published_players"]
        declared = {row["player_id"] for row in allowed}
        if any(int(row["rank"]) <= 8 or int(row["rank"]) % 2 for row in allowed):
            raise AquaWarRuntimeError("invalid public player selection")
        actual = {path.name for path in layout.human_extracted_root.iterdir() if path.is_dir()}
        if actual != declared:
            raise AquaWarRuntimeError("public pool differs from publication manifest")
    elif [item.rank for item in pool] != list(range(1, len(pool) + 1)):
        raise AquaWarRuntimeError("human ranks must be contiguous from rank01")
    return tuple(pool)


def has_cpp_build(package_root: Path) -> bool:
    """这个选手包是不是 **C++ 提交**（需要编译）。

    Saiblo 的同一个赛道里既有 C++ 提交（Make/CMake 或 source-only），也有
    Python 提交。原生入口识别统一委托给公共构建器。
    """

    return common_has_cpp_build(package_root)


def player_entry_root(package_root: Path) -> Path | None:
    """**Python 提交**的入口目录（最浅的 ``main.py`` 所在处），没有则返回 ``None``。

    为什么不能只看包根：选手包解压后常常多套一层目录，官方 Python SDK 的示例就在
    ``AI_SDK/Python/main.py``。只认包根的 ``main.py`` 会把这些提交误判成"没有入口"。
    """

    best: tuple[int, Path] | None = None
    for entry in package_root.rglob("main.py"):
        if any(part in {"__pycache__", ".git"} for part in entry.relative_to(package_root).parts):
            continue
        depth = len(entry.relative_to(package_root).parts)
        if best is None or depth < best[0]:
            best = (depth, entry.parent)
    return best[1] if best else None


def _python_entry(package_root: Path) -> Path | None:
    return player_entry_root(package_root)


def build_player(source_root: Path, build_root: Path) -> Path:
    """用公共 SDK 感知构建器编译一个不可变 AquaWar 选手包。"""

    try:
        return build_cpp_player(
            player_dir=source_root,
            game_dir=_GAME_DIR,
            cache_root=build_root,
        )
    except CppBuildError as exc:
        raise AquaWarRuntimeError(f"native player build_error: {exc}") from exc

// AquaWar 选手跨平台编译兼容垫片。
//
// 这些 Saiblo 选手为 Linux GNU g++/libstdc++ + -std=c++17 编写。在 Apple
// clang/libc++ 上，回退编译时用 -include 强制引入本头，补齐已被 C++17 移除但
// libstdc++ 仍作为扩展保留的符号（如 std::random_shuffle），从而在其它工具链上
// 尽量复现原始编译语义。仅用于回退路径，正常 CI（Linux）走选手自带 Makefile。
#pragma once

#include <algorithm>
#include <random>
#include <iterator>

#if !defined(AQUAWAR_COMPAT_RANDOM_SHUFFLE) && (__cplusplus >= 201703L)
#define AQUAWAR_COMPAT_RANDOM_SHUFFLE
namespace std {
// C++17 移除了 std::random_shuffle；用 std::shuffle 提供等价实现。
template <class RandomIt>
inline void random_shuffle(RandomIt first, RandomIt last) {
    static thread_local std::mt19937 gen{std::random_device{}()};
    typename std::iterator_traits<RandomIt>::difference_type i, n;
    n = last - first;
    for (i = n - 1; i > 0; --i) {
        std::uniform_int_distribution<decltype(i)> dist(0, i);
        std::swap(first[i], first[dist(gen)]);
    }
}
template <class RandomIt, class RandomFunc>
inline void random_shuffle(RandomIt first, RandomIt last, RandomFunc&& r) {
    typename std::iterator_traits<RandomIt>::difference_type i, n;
    n = last - first;
    for (i = n - 1; i > 0; --i) {
        std::swap(first[i], first[r(i + 1)]);
    }
}
}  // namespace std
#endif

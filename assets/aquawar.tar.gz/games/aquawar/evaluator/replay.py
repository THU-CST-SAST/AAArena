"""Decode AquaWar (25th) replay JSON into public-state semantics.

AquaWar 回放解码器（游戏资产），属仓库 A。把官方后端产出的回放 JSON（一个 styled
JSON 数组，每元素是一回合的 game 局面快照）解码为角色感知的胜负、小局数与逐帧摘要。
**不依赖任何框架**，可被 A 的 evaluator 使用，也可被 B（回放技能翻译）复用。

回放数组每个记录（``game.to_json()``）含：
- ``winner``：整场当前胜者玩家 id（-1 未定）；
- ``score``：比分（>0 → P0 领先/胜，<0 → P1，绝对值为小局净胜）；
- ``rounds``：已结束的小局数（三局两胜，最多 3）；
- ``state`` / ``gamestate`` / ``cur_turn``：内部阶段游标；
- ``players``：两名玩家的鱼阵与存活状态；
- ``operation``：本回合被接受的操作（可选）。
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class ReplayReport:
    match_id: str
    winner: str | None            # "P0" / "P1" / None（平局）
    score: float                  # >0 → P0 领先
    rounds: int                   # 已结束小局数
    frame_count: int              # 回放记录数（含阶段快照）
    round_wins: tuple[int, ...]   # 每个小局的胜者玩家 id 序列


def _scored_records(replay: Sequence[Mapping[str, object]]) -> list[Mapping[str, object]]:
    return [record for record in replay if isinstance(record, Mapping) and "score" in record]


def decode_replay(
    replay: Sequence[Mapping[str, object]],
    *,
    match_id: str,
) -> ReplayReport:
    if not match_id.strip() or "/" in match_id or ".." in match_id:
        raise ValueError("match_id must be a safe non-empty identifier")
    if not replay:
        raise ValueError("replay cannot be empty")
    scored = _scored_records(replay)
    if not scored:
        raise ValueError("replay has no scored records")
    terminal = scored[-1]
    raw_score = terminal.get("score")
    if isinstance(raw_score, bool) or not isinstance(raw_score, (int, float)):
        raise ValueError("replay terminal score is not numeric")
    score = float(raw_score)
    raw_rounds = terminal.get("rounds")
    rounds = raw_rounds if isinstance(raw_rounds, int) and not isinstance(raw_rounds, bool) else 0

    if score > 0:
        winner: str | None = "P0"
    elif score < 0:
        winner = "P1"
    else:
        winner = None

    # 追踪每小局胜者：score 每变化 ±1 记一小局胜者。
    round_wins: list[int] = []
    previous = 0
    for record in scored:
        value = record.get("score")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        current = int(value)
        if current > previous:
            round_wins.append(0)
        elif current < previous:
            round_wins.append(1)
        previous = current

    return ReplayReport(
        match_id=match_id,
        winner=winner,
        score=score,
        rounds=int(rounds),
        frame_count=len(replay),
        round_wins=tuple(round_wins),
    )

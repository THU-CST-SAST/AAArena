"""AquaWar (25th) 对战器 —— 满足 `aa_arena.core.Evaluator` 协议的可运行实现。

AquaWar 的游戏语义（编译 C++ 后端与 C++ 选手、跑三局两胜对局、解码回放、裁决胜负）
是仓库 A 的资产。本包对外暴露 `AquaWarEvaluator`，其
`evaluate(players, roles, seed) -> EvaluateResult` 遵循 `docs/evaluator-contract.md`：

- 从已提交的后端源码树编译官方 C++ 后端（可复现于全新 checkout）；
- 编译两名 C++ 选手（AquaWar 选手各自带 Makefile；编译失败即诚实标记）；
- 用 4 字节长度前缀 + object_id 的 stdio 协议驱动后端与两名选手完成一局；
- 解析回放 score 判胜，返回可解析、可复现的 `EvaluateResult`；
- 严格区分三态：编译/后端进程故障 = `infra_error`；选手超时/非法/崩溃 =
  `game_error`；正常终局 = `complete`。

B (HL) / C (RL) 通过 A 的统一入口 `evaluate("aquawar", ...)` 复用本实现。
"""

from __future__ import annotations

from pathlib import Path
from aa_arena.saiblo.player_errors import transport_player_errors

from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError, player_command
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    AquaWarArena,
    AquaWarMatchError,
    MatchCase,
    MatchResult,
    ProcessSpec,
    match_result_from_replay,
    run_native_match,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    AquaWarLayout,
    AquaWarRuntimeError,
    FrozenBackend,
    Opponent,
    audit_human_pool,
    build_backend,
    build_player,
    compile_cpp_package,
    has_cpp_build,
    player_entry_root,
    sha256_file,
    tree_sha256,
)

__all__ = [
    "AquaWarArena",
    "AquaWarEvaluator",
    "AquaWarLayout",
    "AquaWarMatchError",
    "AquaWarRuntimeError",
    "FrozenBackend",
    "MatchCase",
    "MatchResult",
    "Opponent",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "build_backend",
    "build_player",
    "compile_cpp_package",
    "decode_replay",
    "has_cpp_build",
    "make_evaluator",
    "match_result_from_replay",
    "player_entry_root",
    "run_native_match",
    "sha256_file",
    "tree_sha256",
]


def _resolve_player_package(
    player: PlayerRef,
    *,
    pool: tuple[Opponent, ...],
) -> Path:
    """把 PlayerRef 解析为一个可编译的 C++ 选手包目录。"""

    if player.code_path is not None:
        root = Path(player.code_path).resolve()
        if not root.is_dir():
            raise AquaWarMatchError(f"player code path is not a directory: {root}")
        return root
    for opponent in pool:
        if opponent.opponent_id == player.player_id and opponent.runnable:
            return opponent.package_root
    raise AquaWarMatchError(
        f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
    )


def _player_process_spec(package_root: Path, build_root: Path) -> ProcessSpec:
    """按提交类型决定怎么起这个选手进程。

    AquaWar 的人类选手池里 194 个通过审计的**全是 C++**，一度让人以为这个赛道
    只有 C++ 提交。实际原因是这里此前**无条件**走 C++ 编译：任何不带 Makefile
    的包都会被判成"编译失败"，Python 提交（含我们的候选脚手架）根本没机会跑。
    官方 Python SDK 又是个 pybind11 C++ 扩展，更强化了这个误解。

    Saiblo 侧对 Python 提交的启动方式就是 ``python main.py``，走同一套长度前缀
    stdio 协议，所以这里按语言分派即可。判据 ``has_cpp_build`` 见 ``runtime``。
    """

    if has_cpp_build(package_root):
        exe = build_player(package_root, build_root)
        return ProcessSpec((str(exe),), exe.parent)
    entry_root = player_entry_root(package_root)
    if entry_root is not None:
        return ProcessSpec(player_command(), entry_root)
    raise AquaWarRuntimeError(
        f"player package has neither a C++ build nor main.py: {package_root}"
    )


def _other_role(role: str) -> str:
    return "P1" if role == "P0" else "P0"


class AquaWarEvaluator:
    """AquaWar 的对战器：给定两名选手、角色与种子，跑一局并返回契约结果。

    `game_dir` 指向 `games/aquawar/`，据此定位 A 仓库根（后端源码与人类池所在）
    以及产物构建目录。AquaWar 是确定性对局（先手固定），`seed` 仅用于产物分目录，
    不改变对局逻辑；相同选手对必然产出一致结果。
    """

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "aquawar-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "aquawar-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"aquawar requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"aquawar roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = AquaWarLayout.from_root(self.aa_arena_root, self._build_root)

        # 编译后端 + 审计人类池：任何失败都是基础设施故障，不惩罚选手。
        try:
            layout.validate()
            backend = build_backend(layout)
            pool = audit_human_pool(layout)
        except (AquaWarRuntimeError, FileNotFoundError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        # 解析并编译两名选手。选手包解析失败 = infra；编译失败 = 该选手不可用
        # （视为选手侧问题，按 game_error 处理，判对方胜）。
        try:
            candidate_pkg = _resolve_player_package(players[0], pool=pool)
            opponent_pkg = _resolve_player_package(players[1], pool=pool)
        except AquaWarMatchError as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))

        candidate_role = roles[0]
        try:
            candidate_spec = _player_process_spec(candidate_pkg, self._build_root)
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )
        except AquaWarRuntimeError as exc:
            # 候选选手无法编译/没有入口：判对手胜（game_error）。
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=_other_role(candidate_role),
                diagnostic=f"candidate build failed: {exc}",
            )
        try:
            opponent_spec = _player_process_spec(opponent_pkg, self._build_root)
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )
        except AquaWarRuntimeError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=candidate_role,
                diagnostic=f"opponent build failed: {exc}",
            )

        arena = AquaWarArena(
            game=ProcessSpec((str(backend.executable),), backend.executable.parent),
            candidate=candidate_spec,
            opponent=opponent_spec,
            artifact_root=self._artifact_root,
            timeout_s=self.timeout_s,
        )
        case = MatchCase(players[0].player_id, players[1].player_id, candidate_role, seed)
        try:
            result = arena.run_case(case)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )

        return self._to_evaluate_result(result, candidate_role)

    def _to_evaluate_result(
        self,
        result: MatchResult,
        candidate_role: str,
    ) -> EvaluateResult:
        """把 arena 的候选视角 MatchResult 映射为角色绝对的 EvaluateResult。"""

        winner_player = result.payload.get("winner_player")
        score = float(result.payload.get("score", 0.0))
        # 绝对角色胜者。
        if winner_player == 0:
            winner: str | None = "P0"
        elif winner_player == 1:
            winner = "P1"
        else:
            winner = None  # 平局

        # scores：以后端 score 的角色净胜表示（P0 视角为 +score）。
        scores = {"P0": score, "P1": -score}
        if winner is None and result.payload.get("official_draw"):
            scores = {"P0": 0.5, "P1": 0.5}
        failed_roles, diagnostic = transport_player_errors(result.events_path)
        # Illegal actions can be adjudicated inside the game without an ai_error
        # transport event. Preserve their actor alongside transport failures.
        rule_errors = result.payload.get("replay_player_errors", [])
        failed_roles = sorted(set(failed_roles) | {error["role"] for error in rule_errors})
        rule_diagnostic = "; ".join(
            dict.fromkeys(f"{error['role']}: game rule error {error['type']}" for error in rule_errors)
        )
        diagnostic = "; ".join(part for part in (diagnostic, rule_diagnostic) if part) or None
        return EvaluateResult(
            status=EvaluationStatus.GAME_ERROR if failed_roles else EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
            diagnostic=diagnostic,
            payload={"failed_roles": failed_roles,
                     "official_draw": bool(result.payload.get("official_draw"))},
        )


def make_evaluator(game_dir: Path) -> AquaWarEvaluator:
    """插件工厂：供 `games/aquawar/plugin.py` 装配对战器。"""

    return AquaWarEvaluator(game_dir)

# AquaWar (25th) Evaluator

AquaWar 对战器（游戏资产，属仓库 A）。满足 `docs/evaluator-contract.md` 的
`Evaluator` 协议：`evaluate(players, roles, seed) -> EvaluateResult`。

## 模块

- `runtime.py`：编译官方 C++ 后端（从 `games/aquawar/backend/logic/
  gamecode_logic`）与 C++ 选手（`players/pool/*`，各自带 Makefile，可能嵌一层子
  目录）；按内容哈希缓存构建产物；审计带 rank 的人类池。编译策略为
  **优先选手 Makefile → 失败回退兼容编译（解析 Makefile 的 g++ 命令并注入兼容参数）
  → 再失败诚实抛错**。
- `arena.py`：用 4 字节大端长度前缀 + 4 字节 object_id 的 stdio 协议驱动后端与两名
  选手完成一局；init 消息不含随机种子（AquaWar 确定性）；终局以后端广播
  `{"state": -1, ...}` 标志；从回放 `score` 判胜。
- `replay.py`：把回放 JSON 解码为角色感知的胜负、小局数与每小局胜者序列（供 B/C 复用）。
- `__init__.py`：`AquaWarEvaluator` 装配上述模块，返回契约 `EvaluateResult`；
  严格三态：编译/后端故障=`infra_error`，选手编译失败/超时/非法/崩溃=`game_error`，
  正常终局=`complete`。

## 三态归因

- `infra_error`：后端编译失败、人类池审计失败、选手包无法解析、传输层自身异常。
- `game_error`：某选手无法编译、超时、崩溃或非法（判对手胜）。
- `complete`：产出有效终局，填 `winner`/`scores`/`rounds`/`replay_path`。

## 跨平台编译说明

pool 选手为 Linux GNU g++/libstdc++ + `-std=c++17` 目标环境。CI（Linux）可直接用
选手 Makefile 编译；在 Apple clang/libc++ 下部分选手因 `std::reduce` 名字冲突或已
移除的 `std::random_shuffle` 而失败，此时回退编译或诚实标记该选手不可用。后端本身
跨平台可编译。

## 产物

构建缓存与对局产物落在仓库根的 `data/aquawar-build/`、`data/aquawar-matches/`
（gitignore）。

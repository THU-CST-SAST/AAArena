# 25_aquawar

- 届次：第 25 届贺岁赛 AquaWar / 鱼洋陷役
- 类型：双人三轮隐匿信息 SRPG
- 内容：archives 保存原始包；logic 保存解包后的后端、SDK、server 或样例 AI；SHA256SUMS 保存原始包校验值。
- 来源：Saiblo Game.code；saiblo-judge-dev database zip

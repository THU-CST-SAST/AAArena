#include "Action.hpp"

#include <algorithm>
#include <fstream>

std::vector<int> AI::Pick(Game game) {
  std::vector<int> remain_fishes = get_my_remain_fishes();
  std::vector<int> pickfish;
  pickfish.clear();
  if (remain_fishes.size() == 12) {
    pickfish.push_back(8), pickfish.push_back(6), pickfish.push_back(10),
        pickfish.push_back(3);
  }
  if (remain_fishes.size() == 8) {
    pickfish.push_back(5), pickfish.push_back(7), pickfish.push_back(1),
        pickfish.push_back(4);
  }
  if (remain_fishes.size() == 4) {
    pickfish.push_back(9), pickfish.push_back(19), pickfish.push_back(2),
        pickfish.push_back(11);
  }
  return pickfish;
}

std::pair<int, int> AI::Assert(Game game) { return std::make_pair(-1, -1); }

Action AI::Act(Game game) {
  Action action(game);
  if (game.round == 1) {
    if (!get_skill_used(3)) {
      action.set_action_type(1);
      action.set_action_fish(3);
      action.set_enemy_target(-2);
      return action;
    }
    if (get_my_hp(2)) {
      action.set_action_type(1);
      action.set_action_fish(2);
      action.set_enemy_target(get_lowest_health_enemy());
      return action;
    }
    if (get_my_hp(3)) {
      action.set_action_type(1);
      action.set_action_fish(3);
      action.set_enemy_target(-2);
      return action;
    }
    int my_pos = (get_my_living_fishes())[0];
    action.set_action_fish(my_pos);
    int my_atk = get_my_atk(my_pos);
    int lowest_health_enemy = get_lowest_health_enemy();
    if (my_atk >= get_enemy_hp(lowest_health_enemy) * 2 ||
        get_my_living_ally(my_pos).size() == 0) {
      action.set_action_type(0);
      action.set_enemy_target(lowest_health_enemy);
    } else if (my_atk >= get_enemy_hp(game.enemy_action.action_fish)) {
      action.set_action_type(0);
      if (get_enemy_hp(game.enemy_action.action_fish))
        action.set_enemy_target(game.enemy_action.action_fish);
      else
        action.set_enemy_target(lowest_health_enemy);
    } else {
      action.set_action_type(1);
      action.set_friend_target(my_pos);
    }
    return action;
  }
  if (game.round == 2) {
    if (!get_skill_used(2)) {
      action.set_action_type(1);
      action.set_action_fish(2);
      action.set_enemy_target(-2);
      return action;
    }
    int my_hp = get_my_hp(3);
    if (my_hp <= 0) {
      if (get_my_hp(0)) {
        action.set_action_type(1);
        action.set_action_fish(0);
        action.set_enemy_target(get_lowest_health_enemy());
        return action;
      }
      int my_pos = (get_my_living_fishes())[0];
      action.set_action_fish(my_pos);
      auto_valid_action(my_pos, &action);
      return action;
    }
    int my_atk = get_my_atk(3);
    int lowest_health_enemy = get_lowest_health_enemy();
    std::vector<int> my_living_ally = get_my_living_ally(3);
    if (my_atk >= get_enemy_hp(lowest_health_enemy) * 2 ||
        my_living_ally.size() == 0) {
      action.set_action_type(0);
      action.set_action_fish(3);
      action.set_enemy_target(lowest_health_enemy);
    } else if (my_atk >= get_enemy_hp(game.enemy_action.action_fish)) {
      action.set_action_type(0);
      action.set_action_fish(3);
      if (get_enemy_hp(game.enemy_action.action_fish))
        action.set_enemy_target(game.enemy_action.action_fish);
      else
        action.set_enemy_target(lowest_health_enemy);
    } else {
      action.set_action_type(1);
      action.set_action_fish(3);
      int friend_target = my_living_ally[0];
      for (auto i : my_living_ally) {
        if (i == 1) {
          friend_target = 1;
          break;
        }
      }
      action.set_friend_target(friend_target);
    }
    return action;
  }
  if (game.round == 3) {
    if (!get_skill_used(3)) {
      action.set_action_type(1);
      action.set_action_fish(3);
      action.set_enemy_target(-2);
      action.set_friend_target(2);
      return action;
    }
    int my_hp = get_my_hp(2);
    if (my_hp <= 0) {
      if (get_my_hp(0)) {
        action.set_action_type(1);
        action.set_action_fish(0);
        action.set_enemy_target(get_lowest_health_enemy());
        return action;
      }
      int my_pos = (get_my_living_fishes())[0];
      action.set_action_fish(my_pos);
      auto_valid_action(my_pos, &action);
      return action;
    }
    int my_atk = get_my_atk(2);
    int lowest_health_enemy = get_lowest_health_enemy();
    std::vector<int> my_living_ally = get_my_living_ally(2);
    if (my_atk >= get_enemy_hp(lowest_health_enemy) * 2 ||
        my_living_ally.size() == 0) {
      action.set_action_type(0);
      action.set_action_fish(2);
      action.set_enemy_target(lowest_health_enemy);
    } else if (my_atk >= get_enemy_hp(game.enemy_action.action_fish)) {
      action.set_action_type(0);
      action.set_action_fish(2);
      if (get_enemy_hp(game.enemy_action.action_fish))
        action.set_enemy_target(game.enemy_action.action_fish);
      else
        action.set_enemy_target(lowest_health_enemy);
    } else {
      action.set_action_type(1);
      action.set_action_fish(2);
      int friend_target = my_living_ally[0];
      for (auto i : my_living_ally) {
        if (i == 1) {
          friend_target = 1;
          break;
        }
      }
      action.set_friend_target(friend_target);
    }
    return action;
  }
  return action;
}

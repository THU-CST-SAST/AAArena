#pragma once

#include "sdk/ai_client.hpp"
#include <set>
#include <iostream>

#include "core/Solver.h"
#include "cnf.h"

enum frame_type_t {fdamage, fcounter, fdeflect, freduce, fheal, fexplode};
enum owner_t {ally, enemy};

struct frame_t
{
    frame_type_t frame_type;
    owner_t owner;
    int pos;
    int value;
    double reduce_value;
    bool traceable;
    frame_t(){}
    frame_t(frame_type_t t, owner_t o, int p, int v, double r, bool trace):
        frame_type(t), owner(o), pos(p), value(v), reduce_value(r), traceable(trace){}

    friend std::ostream& operator<<(std::ostream& out, frame_t& frame)
    {
        out << (frame.owner == owner_t::ally ? "Ally": "Enemy") << " ";
        out << frame.pos << " ";
        switch(frame.frame_type)
        {
        case frame_type_t::fcounter:
            out << "triggers counter\n";
            break;
        case frame_type_t::fdamage:
            out << "takes " << frame.value << " damage\n";
            break;
        case frame_type_t::fdeflect:
            out << "deflects\n";
            break;
        case frame_type_t::fexplode:
            out << " booms!\n";
            break;
        case frame_type_t::fheal:
            out << " heals 20 hp\n";
            break;
        case frame_type_t::freduce:
            out << " reduces its damage to " << frame.reduce_value << "\n";
            break;
        default:
            out << "sucks! " << frame.frame_type << "\n";
        }
        return out;
    }
};

struct status_t
{
    //skill usage
    int use_num;
    skill_type first;
    skill_type last;

    bool attacked; //is it attacked?
    int damage_taken; //how many damage has it taken?

    int damage_num; //the time of damage
    int dodge_num; //the time of 100% reduce

    status_t() : use_num(0), damage_taken(0), attacked(false), damage_num(0), dodge_num(0) {}
    void record(skill_type t)
    {
        last = t;
        if(use_num == 0)
            first = t;
        use_num++;
    }
};

struct step_t
{
    int mover;
    int effect;
    int ally;
    int enemy; //-1 = no, -2 = all
    bool is_skill;
    step_t(int _mover, int _effect, int _ally, int _enemy, int _is_skill) :
        mover(_mover), effect(_effect), ally(_ally), enemy(_enemy), is_skill(_is_skill) {}
};

struct hp_t
{
    std::vector<int> friend_hp;
    std::vector<int> enemy_hp;

    hp_t()
    {
        friend_hp = std::vector<int>({0, 0, 0, 0});
        enemy_hp = std::vector<int>({0, 0, 0, 0});
    }

    hp_t(int friend0, int friend1, int friend2, int friend3, int enemy0, int enemy1, int enemy2, int enemy3)
    {
        friend_hp = std::vector<int>({friend0, friend1, friend2, friend3});
        enemy_hp = std::vector<int>({enemy0, enemy1, enemy2, enemy3});
    }

    hp_t operator+(hp_t right)
    {
        return hp_t(friend_hp[0] + right.friend_hp[0], friend_hp[1] + right.friend_hp[1],
            friend_hp[2] + right.friend_hp[2], friend_hp[3] + right.friend_hp[3],
            enemy_hp[0] + right.enemy_hp[0], enemy_hp[1] + right.enemy_hp[1],
            enemy_hp[2] + right.enemy_hp[2], enemy_hp[3] + right.enemy_hp[3]
        );
    }

    void operator+=(hp_t right)
    {
        friend_hp[0] += right.friend_hp[0];
        friend_hp[1] += right.friend_hp[1];
        friend_hp[2] += right.friend_hp[2];
        friend_hp[3] += right.friend_hp[3];
        enemy_hp[0] += right.enemy_hp[0];
        enemy_hp[1] += right.enemy_hp[1];
        enemy_hp[2] += right.enemy_hp[2];
        enemy_hp[3] += right.enemy_hp[3];
    }

    hp_t operator*(float right)
    {
        return hp_t(friend_hp[0] * right, friend_hp[1] * right, friend_hp[2] * right, friend_hp[3] * right,
            enemy_hp[0] * right, enemy_hp[1] * right, enemy_hp[2] * right, enemy_hp[3] * right);
    }

    int& get_hp(bool is_enemy, int pos)
    {
        if(is_enemy)
            return enemy_hp[pos];
        else
            return friend_hp[pos];
    }

    friend std::ostream& operator<<(std::ostream& out, hp_t hps)
    {
        out << "friend: " << hps.friend_hp[0] << " " << hps.friend_hp[1] << " " << hps.friend_hp[2] << " " << hps.friend_hp[3] << "\n";
        out << "enemy: " << hps.enemy_hp[0] << " " << hps.enemy_hp[1] << " " << hps.enemy_hp[2] << " " << hps.enemy_hp[3] << "\n";
        return out;
    }

    int effect(bool is_enemy)
    {
        int ret = friend_hp[0] + friend_hp[1] + friend_hp[2] + friend_hp[3] - enemy_hp[0] - enemy_hp[1] - enemy_hp[2] - enemy_hp[3];
        if(is_enemy)
            ret = -ret;
        return ret;
    }
};

struct attack_up_t
{
    std::vector<int> friend_atk;
    std::vector<int> enemy_atk;

    attack_up_t()
    {
        friend_atk = std::vector<int>({0, 0, 0, 0});
        enemy_atk = std::vector<int>({0, 0, 0, 0});
    }

    int& get_atk(bool is_enemy, int pos)
    {
        if(is_enemy)
            return enemy_atk[pos];
        else
            return friend_atk[pos];
    }

    friend std::ostream& operator<<(std::ostream& out, attack_up_t attack_up)
    {
        out << "friend: " << attack_up.friend_atk[0] << " " << attack_up.friend_atk[1] << " " << attack_up.friend_atk[2] << " " << attack_up.friend_atk[3] << "\n";
        out << "enemy: " << attack_up.enemy_atk[0] << " " << attack_up.enemy_atk[1] << " " << attack_up.enemy_atk[2] << " " << attack_up.enemy_atk[3] << "\n";
        return out;
    }
};

class AI : public AIClient
{

private:
    bool attacked;
    int try_type;
    int try_pos;
    bool is_inited = false;
    bool *is_exposed;
    int *pickfish;

    hp_t last_turn_hps;
    status_t enemy_status[4];

    Minisat::Solver solver;

    std::map<int, float> enemy_possible_rate[4];

    int friend_reduce_num[4];
    int enemy_reduce_num;

public:
    AI()
    {
        is_exposed = new bool[12];
        pickfish = new int[4];

        init_solver();
    }
    ~AI()
    {
        delete[] is_exposed;
        delete[] pickfish;
    }

    cnf solver_enemy_equal(int total_enemy_id1, int total_enemy_id2);
    cnf solver_enemy_is(int total_enemy_id, int enemy_is);
    cnf solver_enemy_is(Game& game, int enemy_id, int enemy_is);
    cnf solver_enemy_is_not(Game& game, int enemy_id, int enemy_is_not);

    void init_solver();
    void add_cnf(cnf a);
    void add_clause(clause& a);

    void solver_exclude(Game& game, int enemy_id, int remove);
    bool exclude(Game& game, int enemy_id, int remove);
    bool exclude(Game& game, int enemy_id, int remove1, int remove2);
    bool exclude(Game& game, int enemy_id, int remove1, int remove2, int remove3);
    bool only(Game& game, int enemy_id, int maintain);
    bool only(Game& game, int enemy_id, int maintain1, int maintain2);
    bool only(Game& game, int enemy_id, int maintain1, int maintain2, int maintain3);
    void confirm(Game& game, int enemy_id, int type);

    //used in passive deduction
    bool clownfish_used(int enemy_id);
    int turtle_used_num(int enemy_id);

    //passive deduction
    bool must_counter(Game& game, int enemy_id, int attacked_enemy_id);
    bool cannot_counter(Game& game, int enemy_id, int attacked_enemy_id);

    void about_counter(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);
    void about_deflect(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);
    void about_reduce(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);
    void about_heal(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);
    void about_explode(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);

    void extract_friend_timestamp(Game& game, hp_t initial_hps, std::vector<frame_t>& frames, std::vector<hp_t>& all_hps);
    void extract_enemy_timestamp(Game& game, hp_t initial_hps, std::vector<frame_t>& frames, std::vector<hp_t>& all_hps);

    void about_attack(Game& game);
    void about_aoe(Game& game);
    void about_infight(Game& game);
    void about_crit(Game& game, hp_t before_hps);
    void about_subtle(Game& game);
    void note_skill(Game& game);

    void analyze_previous_assert(Game& game);
    void analyze_my_action(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames);
    void analyze_enemy_action(Game& game, hp_t hps_mid);
    void analyze(Game& game);

    bool like_turtle(int enemy_pos)
    {
        int damage_num = enemy_status[enemy_pos].damage_num;
        int dodge_num = enemy_status[enemy_pos].dodge_num;
        if(damage_num == 0) return false;
        if(damage_num <= 3) return dodge_num == damage_num;
        return dodge_num >= 3;
    }

    std::pair<int, int> do_assertion(Game& game);

    active_skill type_to_active(int type);
    passive_skill type_to_passive(int type);

    int get_friend_type(Game& game, int friend_pos);

    //action
    void calc_enemy_possible_rate(std::map<int, int> divided_situation_num[4], int all_situation_num);

    bool is_safe(Game& game, step_t& step);

    int skill_damage(Game& game, int ally_id);

    float calc_enemy_counter_prob(Game& game, int enemy_pos);

    hp_t attack_consequence_all(Game& game, hp_t initial_hps, bool is_toward_enemy, int attacker_pos, int defender_pos, int damage)
    {
        if(is_toward_enemy)
            return attack_enemy_consequence_all(game, initial_hps, attacker_pos, defender_pos, damage);
        else
            return attack_friend_consequence_all(game, initial_hps, attacker_pos, defender_pos, damage);
    }

    hp_t attack_enemy_consequence_all(Game& game, hp_t initial_hps, int attacker_pos, int defender_pos, int damage);
    hp_t attack_friend_consequence_all(Game& game, hp_t initial_hps, int attacker_pos, int defender_pos, int damage);
    hp_t attack_consequence(Game& game, hp_t initial_hps, bool is_toward_enemy, int attacker_pos, int defender_pos, int damage, active_skill attacker_active, passive_skill defender_passive);

    hp_t damage_enemy_consequence_all(Game& game, hp_t initial_hps, int enemy_pos, int damage);
    hp_t damage_consequence(Game& game, hp_t initial_hps, bool is_enemy, int pos, int damage, passive_skill passive);

    int unit_threat(Game& game, hp_t initial_hps, bool is_enemy, int unit_pos, fish_type unit_type, attack_up_t attack_up);
    int enemy_threat_all(Game& game, hp_t initial_hps, int enemy_pos, attack_up_t attack_up);

    int unit_threat_specified(Game& game, hp_t initial_hps, bool is_enemy, int unit_pos, fish_type unit_type, int defender_pos);

    int enemy_max_single_attack(Game& game, hp_t initial_hps, int friend_pos);

    int evaluate_board(Game& game, hp_t hps, attack_up_t attack_up);

    void best_motion(Game& game, Action& action);

    hp_t get_hps(Game& game);

    void init_round();

    std::vector<int> Pick(Game game);
    std::pair<int, int> Assert(Game game);
    Action Act(Game game);
};
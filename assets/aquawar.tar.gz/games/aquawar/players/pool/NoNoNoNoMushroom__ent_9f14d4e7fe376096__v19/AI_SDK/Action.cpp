#include "Action.hpp"
#include "sdk/ai_client.hpp"
#include <algorithm>
#include <set>
#include <random>
#include <ctime>
#include <fstream>

//global info
std::set<int> not_exist_type;

inline bool not_exist(int query)
{
    return not_exist_type.find(query) != not_exist_type.end();
}

//round info
bool fish_possible_type[4][13];
int expected_fish_type[4];
std::set<int> exist_type;

bool new_round;

hp_t both_full(400, 400, 400, 400, 400, 400, 400, 400);
hp_t both_zero(0, 0, 0, 0, 0, 0, 0, 0);

void AI::init_round()
{
    not_exist_type.insert(exist_type.begin(), exist_type.end());
    exist_type.clear();

    for(int i = 0; i < 4; i++)
    {
        for(int j = 1; j < 13; j++)
            fish_possible_type[i][j] = true;
    
        //for(auto excluded: not_exist_type)
        //    fish_possible_type[i][excluded] = false;

        enemy_status[i] = status_t();
        expected_fish_type[i] = -1;
        friend_reduce_num[i] = 0;
    }
    enemy_reduce_num = 0;
}

void check_only(int enemy_id)
{
    int possibility = 0;
    int possible = -1;
    for(int i = 1; i <= 11; i++)
    {
        if(fish_possible_type[enemy_id][i])
        {
            possibility++;
            possible = i;
        }
    }
    if(possibility == 1)
        expected_fish_type[enemy_id] = possible;
}

int get_total_id(Game& game, int enemy_id)
{
    int round = game.round;
    return enemy_id + (round - 1) * 4;
}

cnf AI::solver_enemy_equal(int total_enemy_id1, int total_enemy_id2)
{
    cnf ret;

    for(int i = 0; i < 4; i++)
    {
        int no1 = total_enemy_id1 * 4 + i;
        int no2 = total_enemy_id2 * 4 + i;
        literal no1_true(no1, true);
        literal no1_false(no1, false);
        literal no2_true(no2, true);
        literal no2_false(no2, false);

        //a == b : (a -> b) & (b -> a)
        ret.clauses.push_back(clause(no1_true, no2_false));
        ret.clauses.push_back(clause(no1_false, no2_true));
    }

    return ret;
}

//0~11 means 12 enemy, 12 means enemy_avatar(does not consider imitator itself)
cnf AI::solver_enemy_is(int total_enemy_id, int enemy_is)
{
    cnf ret;

    for(int i = 0; i < 4; i++)
    {
        bool is_true = ((enemy_is >> i) & 1);
        int no = total_enemy_id * 4 + i;
        literal lit(no, is_true);
        ret.clauses.push_back(clause(lit));
    }
    
    return ret;
}

cnf AI::solver_enemy_is(Game& game, int enemy_id, int enemy_is)
{
    int total_enemy_id = get_total_id(game, enemy_id);
    return solver_enemy_is(total_enemy_id, enemy_is);
}

cnf AI::solver_enemy_is_not(Game& game, int enemy_id, int enemy_is_not)
{
    return cnf_not(solver_enemy_is(game, enemy_id, enemy_is_not));
}

void AI::init_solver()
{
    for(int enemy_id = 0; enemy_id < 12; enemy_id++) //include enemy_avatar
    {
        add_cnf(cnf_not(solver_enemy_is(enemy_id, 0)));
        add_cnf(cnf_not(solver_enemy_is(enemy_id, 13)));
        add_cnf(cnf_not(solver_enemy_is(enemy_id, 14)));
        add_cnf(cnf_not(solver_enemy_is(enemy_id, 15)));
    }

    for(int enemy_id1 = 0; enemy_id1 < 12; enemy_id1++)
        for(int enemy_id2 = enemy_id1 + 1; enemy_id2 < 12; enemy_id2++)
            add_cnf(cnf_not(solver_enemy_equal(enemy_id1, enemy_id2)));
}

void AI::add_cnf(cnf a)
{
    for(auto& clause: a.clauses)
        add_clause(clause);
}

void AI::add_clause(clause& a)
{
    Minisat::vec<Minisat::Lit> standard_clause;
    for(auto lit: a.literals)
    {
        auto standard_lit = Minisat::mkLit(lit.no, !lit.is_true);
        standard_clause.push(standard_lit);

        while (lit.no >= solver.nVars())
            solver.newVar();
    }
    solver.addClause_(standard_clause);
}

void AI::solver_exclude(Game& game, int enemy_id, int remove)
{
    //std::cerr << "add that " << enemy_id << " cannot be " << remove << "\n";
    auto formula = solver_enemy_is_not(game, enemy_id, remove);
    add_cnf(formula);
}

bool AI::exclude(Game& game, int enemy_id, int remove)
{
    bool success = false;
    if(fish_possible_type[enemy_id][remove])
    {
        fish_possible_type[enemy_id][remove] = false;
        solver_exclude(game, enemy_id, remove);
        success = true;
    }
    check_only(enemy_id);
    return success;
}

bool AI::exclude(Game& game, int enemy_id, int remove1, int remove2)
{
    bool success = false;
    if(fish_possible_type[enemy_id][remove1])
    {
        fish_possible_type[enemy_id][remove1] = false;
        solver_exclude(game, enemy_id, remove1);
        success = true;
    }
    if(fish_possible_type[enemy_id][remove2])
    {
        fish_possible_type[enemy_id][remove2] = false;
        solver_exclude(game, enemy_id, remove2);
        success = true;
    }
    check_only(enemy_id);
    return success;
}

bool AI::exclude(Game& game, int enemy_id, int remove1, int remove2, int remove3)
{
    bool success = false;
    if(fish_possible_type[enemy_id][remove1])
    {
        fish_possible_type[enemy_id][remove1] = false;
        solver_exclude(game, enemy_id, remove1);
        success = true;
    }
    if(fish_possible_type[enemy_id][remove2])
    {
        fish_possible_type[enemy_id][remove2] = false;
        solver_exclude(game, enemy_id, remove2);
        success = true;
    }
    if(fish_possible_type[enemy_id][remove3])
    {
        fish_possible_type[enemy_id][remove3] = false;
        solver_exclude(game, enemy_id, remove3);
        success = true;
    }
    check_only(enemy_id);
    return success;
}

bool AI::only(Game& game, int enemy_id, int maintain)
{
    bool success = false;
    for(int i = 1; i <= 11; i++)
        if(i != maintain && fish_possible_type[enemy_id][i])
        {
            fish_possible_type[enemy_id][i] = false;
            solver_exclude(game, enemy_id, i);
            success = true;
        }
    check_only(enemy_id);
    return success;
}

bool AI::only(Game& game, int enemy_id, int maintain1, int maintain2)
{
    bool success = false;
    for(int i = 1; i <= 11; i++)
        if(i != maintain1 && i != maintain2 && fish_possible_type[enemy_id][i])
        {
            fish_possible_type[enemy_id][i] = false;
            solver_exclude(game, enemy_id, i);
            success = true;
        }
    check_only(enemy_id);
    return success;
}

bool AI::only(Game& game, int enemy_id, int maintain1, int maintain2, int maintain3)
{
    bool success = false;
    for(int i = 1; i <= 11; i++)
        if(i != maintain1 && i != maintain2 && i != maintain3 && fish_possible_type[enemy_id][i])
        {
            fish_possible_type[enemy_id][i] = false;
            solver_exclude(game, enemy_id, i);
            success = true;
        }

    check_only(enemy_id);
    return success;
}

void AI::confirm(Game& game, int enemy_id, int type)
{
    exist_type.insert(type);

    cnf enemy_is = solver_enemy_is(game, enemy_id, type);
    add_cnf(enemy_is);

    //std::cerr << "confirm that " << enemy_id << " is " << type << ": " << enemy_is << "\n";

    if(type != 12)
    {
        for(int other_type = 1; other_type <= 11; other_type++)
            if(other_type != type)
                fish_possible_type[enemy_id][other_type] = false;
    }

    //for(int i = 0; i < 4; i++)
    //    if(i != enemy_id)
    //        exclude(game, i, type);
}

const int COUNTER_LINE = 120;

void output(int enemy_id)
{
    for(int i = 1; i < 12; i++)
        if(fish_possible_type[enemy_id][i])
            std::cerr << i << " ";
    std::cerr << "\n";
}

bool AI::clownfish_used(int enemy_id)
{
    if(not_exist(clownfish) && not_exist(imitator))
        return false;

    for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
    {
        if(other_enemy_id == enemy_id)
            continue;

        auto& usage = enemy_status[other_enemy_id];

        if(usage.use_num == 0)
            continue;

        if(usage.use_num <= 3)
        {
            if(usage.first == skill_type::aoe)
                return true;
        }
        else
        {
            if(usage.first == skill_type::aoe && usage.last == skill_type::subtle)
                return true;
        }
    }
    return false;
}

int AI::turtle_used_num(int enemy_id)
{
    if(not_exist(turtle) && not_exist(imitator))
        return 0;

    int num = 0;
    for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
    {
        if(other_enemy_id == enemy_id)
            continue;
        
        auto& usage = enemy_status[other_enemy_id];

        if(usage.use_num == 0)
            continue;

        if(usage.use_num <= 3)
        {
            if(usage.first == skill_type::crit)
                num += usage.use_num;
        }
        else
        {
            if(usage.first == skill_type::crit && usage.last == skill_type::subtle)
                num += usage.use_num;
        }
    }
    return num;
}

bool AI::must_counter(Game& game, int enemy_pos, int attacked_enemy_pos)
{
    bool self = (enemy_pos == attacked_enemy_pos);

    if(game.enemy_fish[enemy_pos].id != -1 && game.enemy_fish[enemy_pos].id != 12)
    {
        int concrete = game.enemy_fish[enemy_pos].id;
        return self ? (concrete == clownfish) : (concrete == spray || concrete == flame);
    }
    
    if(self)
    {
        for(int i = 1; i <= 11; i++)
            if(i != clownfish && fish_possible_type[enemy_pos][i])
                return false;
        return true;
    }
    else
    {
        for(int i = 1; i <= 11; i++)
            if(i != spray && i != flame && fish_possible_type[enemy_pos][i])
                return false;
        return true;
    }
}

bool AI::cannot_counter(Game& game, int enemy_pos, int attacked_enemy_pos)
{
    bool self = (enemy_pos == attacked_enemy_pos);

    if(game.enemy_fish[enemy_pos].id != -1 && game.enemy_fish[enemy_pos].id != 12)
    {
        int concrete = game.enemy_fish[enemy_pos].id;
        return self ? (concrete != clownfish) : (concrete != spray && concrete != flame);
    }
    
    if(self)
        return !fish_possible_type[enemy_pos][clownfish];
    else
        return !(fish_possible_type[enemy_pos][spray] || fish_possible_type[enemy_pos][flame]);
}

void AI::about_counter(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.enemy_hp[enemy_id] <= 0) //already dead
            continue;

        bool danger_attacked = false;
        int trigger_counter = 0;

        for(int i = 0; i < frames.size(); i++)
        {
            auto& frame = frames[i];

            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;

            if(frame.frame_type == fdamage && frame.traceable)
            {
                int after_hp = hps_vector[i + 1].enemy_hp[enemy_id];
                for(int j = i + 1; j < frames.size(); j++)
                {
                    auto& next_frame = frames[j];
                    if(next_frame.owner == enemy && next_frame.pos == enemy_id && next_frame.frame_type == frame_type_t::fheal)
                    {
                        after_hp = hps_vector[j + 1].enemy_hp[enemy_id];
                    }
                    else
                    {
                        break;
                    }
                }
                if(after_hp < 120)
                    danger_attacked = true;             
            }
                
            if(frame.frame_type == fcounter)
                trigger_counter++;
        }

        if(danger_attacked)
        {
            // if(trigger_counter == 0)
            // {
            //     if(exclude(game, enemy_id, clownfish))
            //     {
            //         std::cerr << "for enemy " << enemy_id << " triggers no counter when danger attacked: ";
            //         output(enemy_id);
            //     }

            //     for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
            //         if(other_enemy_id != enemy_id)
            //         {
            //             if(exclude(game, other_enemy_id, spray, flame))
            //             {
            //                 std::cerr << "for enemy " << other_enemy_id << " do not help " << enemy_id << " trigger counter: ";
            //                 output(other_enemy_id);
            //             }
            //         }
            // }
            // else
            {
                std::cerr << "enemy " << enemy_id << " counter " << trigger_counter << " times:\n";

                std::set<int> living_enemies;
                for(int i = 0; i < 4; i++)
                    if(initial_hps.enemy_hp[i] > 0)
                        living_enemies.insert(i);

                int num_must_counter = 0;
                int num_cannot_counter = 0;
                std::set<int> unknown_enemies;

                for(auto living_enemy: living_enemies)
                {
                    if(must_counter(game, living_enemy, enemy_id))
                    {
                        //std::cerr << living_enemy << " must counter\n";
                        num_must_counter++;
                    }
                    else if(cannot_counter(game, living_enemy, enemy_id))
                    {
                        //std::cerr << living_enemy << " cannot counter\n";
                        num_cannot_counter++;
                    }
                    else
                    {
                        //std::cerr << living_enemy << " is unknown\n";
                        unknown_enemies.insert(living_enemy);
                    }
                }

                int num_unknown_counter = trigger_counter - num_must_counter;
                std::cerr << "trigger unknown counter num: " << num_unknown_counter << "\n";
                if(num_unknown_counter == 0)
                {
                    for(auto unknown_enemy: unknown_enemies)
                    {
                        if(unknown_enemy == enemy_id)
                        {
                            if(exclude(game, unknown_enemy, clownfish))
                            {
                                std::cerr << "for enemy " << unknown_enemy << " triggers no counter when danger attacked: ";
                                output(unknown_enemy);
                            }
                        }
                        else
                        {
                            if(exclude(game, unknown_enemy, spray, flame))
                            {
                                std::cerr << "for enemy " << unknown_enemy << " not help " << enemy_id << " trigger counter: ";
                                output(unknown_enemy);
                            }
                        }
                    }
                }
                else if(num_unknown_counter == unknown_enemies.size())
                {
                    for(auto unknown_enemy: unknown_enemies)
                    {
                        if(unknown_enemy == enemy_id)
                        {
                            if(only(game, unknown_enemy, clownfish))
                            {
                                std::cerr << "for enemy " << unknown_enemy << " triggers counter when danger attacked: ";
                                output(unknown_enemy);
                            }
                        }
                        else
                        {
                            if(only(game, unknown_enemy, spray, flame))
                            {
                                std::cerr << "for enemy " << unknown_enemy << " helps " << enemy_id << " trigger counter: ";
                                output(unknown_enemy);
                            }
                        }
                    }
                }
                else
                {
                    //todo
                }
            }
            
        }
    }
}

void AI::about_deflect(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    int num_living_enemies = 0;
    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
        if(initial_hps.enemy_hp[enemy_id] > 0)
            num_living_enemies++;

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.enemy_hp[enemy_id] <= 0) //already dead
            continue;

        bool attacked = false;
        bool trigger_deflect = false;
        bool clownfish_useskill = clownfish_used(enemy_id);

        for(auto& frame: frames)
        {
            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;

            if(frame.frame_type == fdamage && frame.traceable)
                attacked = true;
            
            if(frame.frame_type == fdeflect)
                trigger_deflect = true;
        }

        if(attacked && !trigger_deflect && num_living_enemies > 1)
        {
            if(exclude(game, enemy_id, eel, sunfish))
            {
                std::cerr << "for enemy " << enemy_id << " triggers no deflect when attacked: ";
                output(enemy_id);
            }
        }
        if(attacked && trigger_deflect && !clownfish_useskill)
        {
            if(only(game, enemy_id, eel, sunfish))
            {
                std::cerr << "for enemy " << enemy_id << " is attacked, triggers deflect and no clownfish: ";
                output(enemy_id);
            }
        }
    }
}

void AI::about_reduce(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int friend_pos = 0; friend_pos < 4; friend_pos++)
    {
        for(auto& frame: frames)
        {
            if(frame.owner == ally && frame.pos == friend_pos && frame.frame_type == freduce && 
                frame.reduce_value < 0.31 && frame.reduce_value > 0.29)
                friend_reduce_num[friend_pos]--;
        }
    }

    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        if(initial_hps.enemy_hp[enemy_pos] <= 0) //already dead
            continue;

        bool trigger_dodge = false;
        bool damaged = false;

        for(auto& frame: frames)
        {
            if(frame.owner != enemy || frame.pos != enemy_pos)
                continue;
            
            if(frame.frame_type == fdamage)
            {
                damaged = true;
                enemy_status[enemy_pos].damage_num++;
            }

            if(frame.frame_type == freduce && frame.reduce_value < 0.01)
            {
                trigger_dodge = true;
                enemy_status[enemy_pos].dodge_num++;
            }

            if(frame.frame_type == freduce && frame.reduce_value < 0.31 && frame.reduce_value > 0.29)
            {
                enemy_reduce_num--;
            }
        }

        if(trigger_dodge)
        {
            if(only(game, enemy_pos, barracuda, mobula, turtle))
            {
                std::cerr << "for enemy " << enemy_pos << " triggers 100% dodge: ";
                output(enemy_pos);
            }
        }

        int damage_num = enemy_status[enemy_pos].damage_num;
        int dodge_num = enemy_status[enemy_pos].dodge_num;

        if(damaged && !trigger_dodge && damage_num <= 3)
        {
            if(exclude(game, enemy_pos, turtle))
            {
                std::cerr << "for enemy " << enemy_pos << " does not dodge in " << damage_num << "th damage: ";
                output(enemy_pos);
            }
        }

        if(damage_num > 0 && damage_num <= 3 && dodge_num != damage_num)
        {
            if(exclude(game, enemy_pos, turtle))
            {
                std::cerr << "for enemy " << enemy_pos << " dodge " << dodge_num << " out of " << damage_num << ": ";
                output(enemy_pos);
            }
        }

        if(damage_num > 3 && dodge_num < 3)
        {
            if(exclude(game, enemy_pos, turtle))
            {
                std::cerr << "for enemy " << enemy_pos << " dodge " << dodge_num << " out of " << damage_num << ": ";
                output(enemy_pos);
            }
        }
    }
}

void AI::about_heal(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.enemy_hp[enemy_id] <= 0) //already dead
            continue;

        int survive_attacks = 0;
        int survive_damages = 0;
        int heals = 0;
        int turtle_num = turtle_used_num(enemy_id);

        for(int i = 0; i < frames.size(); i++)
        {
            auto& frame = frames[i];
            auto& after_hps = hps_vector[i + 1];

            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;
            
            if(frame.frame_type == fheal)
                heals++;
            
            if(frame.frame_type == fdamage && after_hps.enemy_hp[enemy_id] > 0 && frame.value > 0)
            {
                survive_damages++;
                if(frame.traceable)
                    survive_attacks++;
            }
        }

        if(survive_attacks == 0 || (survive_attacks == 1 && turtle_num == 0))
        {
            if(heals < survive_damages)
            {
                if(exclude(game, enemy_id, whiteshark, octopus))
                {
                    std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages but heals " << heals << "times:";
                    output(enemy_id);
                }
            }
            if(heals == survive_damages && survive_damages > 0)
            {
                if(only(game, enemy_id, whiteshark, octopus))
                {
                    std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages and heals " << heals << "times:";
                    output(enemy_id);
                }
            }
        }
        else
        {
            if(heals < survive_damages)
            {
                if(exclude(game, enemy_id, whiteshark, octopus))
                {
                    std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages but heals " << heals << "times:";
                    output(enemy_id);
                }
            }
            else
            {
                int min_self_heals = heals - turtle_num;
                if(min_self_heals > 0)
                {
                    if(only(game, enemy_id, whiteshark, octopus))
                    {
                        std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages and heals at least " << min_self_heals << "times by self:";
                        output(enemy_id);
                    }
                }
                else
                {
                    //todo
                }
            }
        }
    }
}

void AI::about_explode(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.enemy_hp[enemy_id] <= 0) //already dead
            continue;

        bool deadly_attacked = false;
        bool trigger_explode = false;

        for(int i = 0; i < frames.size(); i++)
        {
            auto& frame = frames[i];
            auto& after_hps = hps_vector[i + 1];

            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;

            if(frame.frame_type == fdamage && frame.traceable && after_hps.enemy_hp[enemy_id] <= 0)
                deadly_attacked = true;
            
            if(frame.frame_type == fexplode)
                trigger_explode = true;
        }

        if(deadly_attacked && !trigger_explode)
        {
            if(exclude(game, enemy_id, hammerhead))
            {
                std::cerr << "for enemy " << enemy_id << " does not boom when attacked to death: ";
                output(enemy_id);
            }
        }
        if(trigger_explode)
        {
            if(only(game, enemy_id, hammerhead))
            {
                std::cerr << "for enemy " << enemy_id << " booms: ";
                output(enemy_id);
            }
        }
    }
}

frame_type_t passive_to_frame_type(passive_type p)
{
    switch(p)
    {
    case passive_type::counter:
        return frame_type_t::fcounter;
    case passive_type::deflect:
        return frame_type_t::fdeflect;
    case passive_type::explode:
        return frame_type_t::fexplode;
    case passive_type::heal:
        return frame_type_t::fheal;
    case passive_type::reduce:
        return frame_type_t::freduce;
    default:
        std::cerr << "shit! wrong passive_type " << p << "\n";
        return frame_type_t::fdamage;
    }
}

void AI::extract_friend_timestamp(Game& game, hp_t initial_hps, std::vector<frame_t>& frames, std::vector<hp_t>& all_hps)
{
    const auto& my_action = game.my_action;

    for(int i = 0; i < my_action.num_enemy_injury; i++)
    {
        int time = my_action.enemy_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);
        
        int pos = my_action.enemy_injury_id[i];
        int value = my_action.enemy_injury[i];
        bool traceable = my_action.enemy_injury_traceable[i];

        enemy_status[pos].damage_taken += value;

        frames[time] = frame_t(frame_type_t::fdamage, owner_t::enemy, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < my_action.num_friend_injury; i++)
    {
        int time = my_action.friend_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.friend_injury_id[i];
        int value = my_action.friend_injury[i];
        bool traceable = my_action.enemy_injury_traceable[i];

        frames[time] = frame_t(frame_type_t::fdamage, owner_t::ally, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < my_action.num_enemy_passives; i++)
    {
        int time = my_action.enemy_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.enemy_passives_id[i];
        auto type = my_action.enemy_types[i];
        double reduce_rate = (type == reduce ? my_action.enemy_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::enemy, pos, 0, reduce_rate, false);

        //if(passive_to_frame_type(type) == fcounter)
        //    std::cerr << "a counter happens at enemy " << pos << "!\n";
    }

    for(int i = 0; i < my_action.num_friend_passives; i++)
    {
        int time = my_action.friend_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.friend_passives_id[i];
        auto type = my_action.friend_types[i];
        double reduce_rate = (type == reduce ? my_action.friend_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::ally, pos, 0, reduce_rate, false);
    }

    for(int i = 0; i < my_action.num_enemy_targets; i++)
    {
        int enemy_pos = my_action.enemy_targets[i];
        enemy_status[enemy_pos].attacked = true;
    }

    all_hps.push_back(initial_hps);

    for(int event = 0; event < frames.size(); event++)
    {
        auto& frame = frames[event];
        auto pos = frame.pos;

        hp_t after_hps = all_hps[event];
        
        switch(frame.frame_type)
        {
        case frame_type_t::fdamage:
            if(frame.owner == owner_t::ally)
            {
                after_hps.friend_hp[pos] -= frame.value;
            }
            else
            {
                after_hps.enemy_hp[pos] -= frame.value;
            }
            break;
        case frame_type_t::fheal:
            if(frame.owner == owner_t::ally)
            {
                after_hps.friend_hp[pos] += 20;
                if(after_hps.friend_hp[pos] > 400)
                    after_hps.friend_hp[pos] = 400;
            }
            else
            {
                after_hps.enemy_hp[pos] += 20;
                if(after_hps.enemy_hp[pos] > 400)
                    after_hps.enemy_hp[pos] = 400;
            }
            break;
        default:
            break;
        }
        all_hps.push_back(after_hps);
    }

    int assertPos = game.enemy_assert.assertPos;
    int assertContent = game.enemy_assert.assertContent;
    bool result = game.enemy_assert.assertResult;

    if(!(assertPos >= 0 && assertPos < 4))
        return;
    if(!(assertContent >= 1 && assertContent <= 12))
        return;

    std::cerr << "\n\nenemy assert is " << assertPos << " " << assertContent << " result is " << result << "\n\n\n";

    hp_t assert_hps = all_hps.back();
    if(result)
    {
        for(int i = 0; i < 4; i++)
            assert_hps.friend_hp[i] -= 50;
    }
    else
    {
        for(int i = 0; i < 4; i++)
            assert_hps.enemy_hp[i] -= 50;
    }
    all_hps.push_back(assert_hps);
}

void AI::extract_enemy_timestamp(Game& game, hp_t initial_hps, std::vector<frame_t>& frames, std::vector<hp_t>& all_hps)
{
    const auto& enemy_action = game.enemy_action;

    for(int i = 0; i < enemy_action.num_enemy_injury; i++)
    {
        int time = enemy_action.enemy_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);
        
        int pos = enemy_action.enemy_injury_id[i];
        int value = enemy_action.enemy_injury[i];
        bool traceable = enemy_action.enemy_injury_traceable[i];
        frames[time] = frame_t(frame_type_t::fdamage, owner_t::ally, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < enemy_action.num_friend_injury; i++)
    {
        int time = enemy_action.friend_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = enemy_action.friend_injury_id[i];
        int value = enemy_action.friend_injury[i];
        bool traceable = enemy_action.friend_injury_traceable[i];

        enemy_status[pos].damage_taken += value;

        frames[time] = frame_t(frame_type_t::fdamage, owner_t::enemy, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < enemy_action.num_enemy_passives; i++)
    {
        int time = enemy_action.enemy_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = enemy_action.enemy_passives_id[i];
        auto type = enemy_action.enemy_types[i];
        double reduce_rate = (type == reduce ? enemy_action.enemy_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::ally, pos, 0, reduce_rate, false);
    }

    for(int i = 0; i < enemy_action.num_friend_passives; i++)
    {
        int time = enemy_action.friend_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = enemy_action.friend_passives_id[i];
        auto type = enemy_action.friend_types[i];
        double reduce_rate = (type == reduce ? enemy_action.friend_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::enemy, pos, 0, reduce_rate, false);
    }

    all_hps.push_back(initial_hps);

    for(int event = 0; event < frames.size(); event++)
    {
        auto& frame = frames[event];
        auto pos = frame.pos;

        hp_t after_hps = all_hps[event];
        
        switch(frame.frame_type)
        {
        case frame_type_t::fdamage:
            if(frame.owner == owner_t::ally)
            {
                after_hps.friend_hp[pos] -= frame.value;
            }
            else
            {
                after_hps.enemy_hp[pos] -= frame.value;
            }
            break;
        case frame_type_t::fheal:
            if(frame.owner == owner_t::ally)
            {
                after_hps.friend_hp[pos] += 20;
                if(after_hps.friend_hp[pos] > 400)
                    after_hps.friend_hp[pos] = 400;
            }
            else
            {
                after_hps.enemy_hp[pos] += 20;
                if(after_hps.enemy_hp[pos] > 400)
                    after_hps.enemy_hp[pos] = 400;
            }
            break;
        default:
            break;
        }
        all_hps.push_back(after_hps);
    }
}

void AI::analyze_my_action(Game& game, std::vector<hp_t>& hps_vector, std::vector<frame_t>& frames)
{
    extract_friend_timestamp(game, last_turn_hps, frames, hps_vector);

    // std::cerr << "start outputing timeline\n";
    // for(auto frame: frames)
    //     std::cerr << frame;
    // std::cerr << "end outputing timeline\n";
    // auto& hps_mid = hps_vector.back();
    // std::cerr << "our hp: " << hps_mid.friend_hp[0] << " " << hps_mid.friend_hp[1] << " " << hps_mid.friend_hp[2] << " " << hps_mid.friend_hp[3] << "\n";
    // std::cerr << "enemy hp: " << hps_mid.enemy_hp[0] << " " << hps_mid.enemy_hp[1] << " " << hps_mid.enemy_hp[2] << " " << hps_mid.enemy_hp[3] << "\n";

    about_counter(game, hps_vector, frames);
    about_deflect(game, hps_vector, frames);
    about_reduce(game, hps_vector, frames);
    about_explode(game, hps_vector, frames);
    about_heal(game, hps_vector, frames);
}

void AI::about_attack(Game& game) //todo
{
    //evaluate attack
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(enemy_action.is_skill)
        return;

    int damage = 0;

    //std::cerr << "enemy attacks, targeting " << enemy_action.num_enemy_targets << "\n";

    for(int i = 0; i < enemy_action.num_enemy_targets; i++)
    {
        //std::cerr << "enemy " << enemy_id << " attacks, dealing damage to ally " << enemy_action.enemy_targets[i] << " with " << enemy_action.enemy_expected_injury[i] << "\n";
        damage += enemy_action.enemy_expected_injury[i];
    }

    int enemy_attack = damage * 2;

    //std::cerr << "enemy " << enemy_id << " attacks, dealing damage to " << enemy_action.num_enemy_targets << " fishes with " << damage << "\n";

    if(enemy_attack < 100)
        return;

    if(enemy_attack > 100)
    {
        bool success = false;
        if(exclude(game, enemy_id, spray, barracuda)) success = true;
        if(exclude(game, enemy_id, turtle, whiteshark, clownfish)) success = true;
        if(success)
        {
            std::cerr << "for enemy " << enemy_id << " has more attack than 100, its possibility: ";
            output(enemy_id);
        }
    }

    if(enemy_attack >= 112 && enemy_attack <= 118) //hammerhead
    {
        if(only(game, enemy_id, hammerhead))
        {
            std::cerr << "for enemy " << enemy_id << " has attack " << enemy_attack << ", its possibility: ";
            output(enemy_id);
        }
    }

    auto& usage = enemy_status[enemy_id];

    int attack_infight = usage.first == infight ? usage.use_num * 70 : 0;

    int attack_skill_20 = usage.use_num * 20;
    int attack_large_damage = (usage.damage_taken / 200) * 20;

    int add = enemy_attack - 100 - attack_infight;

    //passive attack up of eel and sunfish need to rewrite

    if(add != attack_skill_20)
    {
        if(exclude(game, enemy_id, mobula, octopus))
        {
            std::cerr << "for enemy " << enemy_id << " use attack up number not match attack " << enemy_attack << ", its possibility: ";
            output(enemy_id);
        }
    }
    if(add != attack_large_damage)
    {
        if(exclude(game, enemy_id, eel, sunfish))
        {
            std::cerr << "for enemy " << enemy_id << " take large damage number not match attack " << enemy_attack << ", its possibility: ";
            //std::cerr << "damage taken: " << usage.damage_taken << " should add damage " << attack_large_damage << " add " << add << "\n";
            output(enemy_id);
        }
    }
}

void AI::about_aoe(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::aoe)
        return;

    bool success = false;
    if(exclude(game, enemy_id, flame, sunfish)) success = true;
    if(exclude(game, enemy_id, barracuda, mobula)) success = true;
    if(exclude(game, enemy_id, turtle, octopus)) success = true;
    if(exclude(game, enemy_id, whiteshark, hammerhead)) success = true;
    if(success)
    {
        std::cerr << "for enemy " << enemy_id << " uses aoe, its possibility: ";
        output(enemy_id);
    }

    if(enemy_status[enemy_id].use_num >= 4)
    {
        if(exclude(game, enemy_id, clownfish))
        {
            std::cerr << "for enemy " << enemy_id << " uses aoe for " << enemy_status[enemy_id].use_num << " times, its possibility: ";
            output(enemy_id);
        }
    }

    int damage = enemy_action.enemy_expected_injury[0];
    if(damage > 35)
        if(only(game, enemy_id, eel))
        {
            std::cerr << "for enemy " << enemy_id << " use aoe, dealing damage to ally " << enemy_action.enemy_targets[0] << " with " << enemy_action.enemy_expected_injury[0] << ", its possibility: ";
            output(enemy_id);
        }

    if(damage == 35)
    {
        //todo
    }
}

void AI::about_infight(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::infight)
        return;

    if(only(game, enemy_id, flame, sunfish))
    {
        std::cerr << "for enemy " << enemy_id << " uses infight, its possibility: ";
        output(enemy_id);
    }
}

void AI::about_crit(Game& game, hp_t before_hps)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::crit)
        return;

    bool success = false;
    if(exclude(game, enemy_id, spray, flame, eel)) success = true;
    if(exclude(game, enemy_id, sunfish, mobula, octopus)) success = true;
    if(exclude(game, enemy_id, clownfish)) success = true;

    int target = -1;
    for(int i = 0; i < enemy_action.num_enemy_targets; i++)
    {
        //std::cerr << "enemy critical aims " << enemy_action.enemy_targets[i] << "\n";
        target = enemy_action.enemy_targets[i];
    }

    int damage = enemy_action.enemy_excepted_injury[0];
    int attacker_hp = before_hps.enemy_hp[enemy_id];

    if(success)
    {
        std::cerr << "for enemy " << enemy_id << "(" << attacker_hp << ") uses crit with damage " << damage << " to target " << target << " its possibility: ";
        output(enemy_id);
    }

    if(damage > 120)
    {
        if(exclude(game, enemy_id, barracuda, turtle))
        {
            std::cerr << "for enemy " << enemy_id << " does crit damage more than 120, its possibility: ";
            output(enemy_id);
        }

        if(damage % 10 != 0)
        {
            if(only(game, enemy_id, hammerhead))
            {
                std::cerr << "for enemy " << enemy_id << " does crit damage that is not times of 10, its possibility: ";
                output(enemy_id);
            }
        }
        else //140
        {
            if(attacker_hp < 80)
            {
                if(only(game, enemy_id, whiteshark))
                {
                    std::cerr << "for enemy " << enemy_id << " does damage 140 when hp lower than 80, its possibility: ";
                    output(enemy_id);
                }
            }
        }
    }
    else
    {
        if(attacker_hp < 80)
        {
            if(exclude(game, enemy_id, hammerhead))
            {
                std::cerr << "for enemy " << enemy_id << " does damage 120 when hp lower than 80, its possibility: ";
                output(enemy_id);
            }
        }
        
        if(target < 0 || target > 3)
            std::cerr << "shit! target of crit is " << target << "\n";

        auto& my_fish_hp_before = before_hps.friend_hp;

        bool target_hp_minimal = true;
        for(int i = 0; i < 4; i++)
            if(i != target && my_fish_hp_before[i] > 0 && my_fish_hp_before[i] < my_fish_hp_before[target])
                target_hp_minimal = false;
        
        if(!target_hp_minimal)
        {
            if(exclude(game, enemy_id, whiteshark, hammerhead))
            {
                //std::cerr << my_fish_hp_before[0] << " " << my_fish_hp_before[1] << " " << my_fish_hp_before[2] << " " << my_fish_hp_before[3] << "\n";
                std::cerr << "for enemy " << enemy_id << " does damage 120 to not minimal hp, its possibility: ";
                output(enemy_id);
            }
        }

        if(my_fish_hp_before[target] < 160)
        {
            if(exclude(game, enemy_id, whiteshark, hammerhead))
            {
                std::cerr << "for enemy " << enemy_id << " does damage 120 to hp less than 160, its possibility: ";
                output(enemy_id);
            }
        }
    }
}

void AI::about_subtle(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;
    
    if(!enemy_action.is_skill || enemy_action.type != skill_type::subtle)
        return;

    auto& usage = enemy_status[enemy_id];

    if(usage.first == crit)
    {
        if(only(game, enemy_id, turtle))
        {
            std::cerr << "for enemy " << enemy_id << " uses subtle (previously crit), its possibility: ";
            output(enemy_id);
        }
    }
    else if(usage.first == aoe)
    {
        if(only(game, enemy_id, clownfish))
        {
            std::cerr << "for enemy " << enemy_id << " uses subtle (previously aoe), its possibility: ";
            output(enemy_id);
        }
    }
    else if(usage.first == subtle)
    {
        if(only(game, enemy_id, mobula, octopus))
        {
            std::cerr << "for enemy " << enemy_id << " uses subtle (previously subtle), its possibility: ";
            output(enemy_id);
        }
        enemy_reduce_num++;
    }
}

void AI::note_skill(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill)
        return;

    auto skill = enemy_action.type;

    enemy_status[enemy_id].record(skill);
}

void AI::analyze_enemy_action(Game& game, hp_t hps_mid)
{
    // std::cerr << "before enemy action: \n";
    // std::cerr << "our hp: " << hps_mid.friend_hp[0] << " " << hps_mid.friend_hp[1] << " " << hps_mid.friend_hp[2] << " " << hps_mid.friend_hp[3] << "\n"; 
    // std::cerr << "enemy hp: " << hps_mid.enemy_hp[0] << " " << hps_mid.enemy_hp[1] << " " << hps_mid.enemy_hp[2] << " " << hps_mid.enemy_hp[3] << "\n";
    // std::cerr << "enemy damage taken: " << enemy_status[0].damage_taken << " " << enemy_status[1].damage_taken << " " << enemy_status[2].damage_taken << " " << enemy_status[3].damage_taken << "\n";

    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    std::vector<hp_t> hps_vector;
    std::vector<frame_t> frames;

    note_skill(game);
    about_attack(game);
    about_aoe(game);
    about_infight(game);
    about_crit(game, hps_mid);
    about_subtle(game);

    extract_enemy_timestamp(game, hps_mid, frames, hps_vector);
    about_reduce(game, hps_vector, frames);
    about_heal(game, hps_vector, frames);
}

void AI::analyze_previous_assert(Game& game)
{
    int assertPos = game.my_assert.assertPos;
    int assertContent = game.my_assert.assertContent;
    bool result = game.my_assert.assertResult;

    if(!(assertPos >= 0 && assertPos < 4))
        return;

    if(!(assertContent >= 1 && assertContent <= 12))
        return;

    std::cerr << "\n\nlast assert is " << assertPos << " " << assertContent << " result is " << result << "\n\n\n";

    if(result)
    {
        confirm(game, assertPos, assertContent);
    }
    else
    {
        solver_exclude(game, assertPos, assertContent);
        //exclude(game, assertPos, assertContent);
    }
}

void AI::analyze(Game& game)
{
    if(new_round)
    {
        new_round = false;

        if(get_first_mover())
        {
            std::cerr << "the first turn, we go first\n";
            return;
        }
        else
        {
            std::cerr << "the first turn, we go second\n";

            analyze_enemy_action(game, both_full);
            return;
        }
    }

    analyze_previous_assert(game);

    std::vector<hp_t> hps_vector;
    std::vector<frame_t> frames;
    analyze_my_action(game, hps_vector, frames);

    if(hps_vector.empty())
        std::cerr << "shit! hps_vector is empty\n";

    analyze_enemy_action(game, hps_vector.back());
}

const double THRESHOLD = 0.4;

std::pair<int, int> AI::do_assertion(Game& game)
{
    if(!solver.solve())
    {
        std::cerr << "shit! the problem itself is unsat\n";
    }

    std::set<int> possible_fish[4];

    std::vector<int> need_assert_pos;
    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        if(game.enemy_fish[enemy_pos].id != -1) //already exposed
            continue;

        if(game.enemy_fish[enemy_pos].hp <= 0) //dead
            continue;

        //if(giveup[enemy_pos]) //todo: eliminate this compromise
        //    continue;

        need_assert_pos.push_back(enemy_pos);
    }

    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        if(game.enemy_fish[enemy_pos].id != -1) //already exposed
        {
            possible_fish[enemy_pos].insert(game.enemy_fish[enemy_pos].id);
            continue;
        }

        int total_enemy_pos = get_total_id(game, enemy_pos);

        for(int fish_id = 1; fish_id <= 12; fish_id++)
        {
            if(fish_id <= 11 && !fish_possible_type[enemy_pos][fish_id])
                continue;
            
            Minisat::vec<Minisat::Lit> assumptions;

            cnf enemy_is = solver_enemy_is(total_enemy_pos, fish_id);
            for(auto& clause: enemy_is.clauses)
            {
                if(clause.literals.size() != 1)
                    std::cerr << "shit! wrong size\n";
                auto lit = clause.literals[0];
                assumptions.push(Minisat::mkLit(lit.no, !lit.is_true));
            }

            if(solver.solve(assumptions))
            {
                //std::cerr << "solver says " << enemy_pos << " can be " << fish_id << "\n";
                possible_fish[enemy_pos].insert(fish_id);
            }
            else
            {
                //std::cerr << "solver says " << enemy_pos << " cannot be " << fish_id << "\n";
                //exclude(game, enemy_pos, fish_id);
            }
        }

        std::cerr << "Enemy " << enemy_pos << "'s possibility: ";
        for(auto p : possible_fish[enemy_pos])
            std::cerr << p << " ";
        std::cerr << "\n";

        if(possible_fish[enemy_pos].size() == 0)
        {
            std::cerr << "shit! enemy " << enemy_pos << " is impossible\n";
            std::exit(0);
        }
    }

    std::vector<literal> all_assumptions[4][13];

    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
        for(int type = 1; type <= 12; type++)
        {
            cnf enemy_is = solver_enemy_is(game, enemy_pos, type);
            std::vector<literal> enemy_is_vec{enemy_is.clauses[0].literals[0], enemy_is.clauses[1].literals[0], enemy_is.clauses[2].literals[0], enemy_is.clauses[3].literals[0]};
            all_assumptions[enemy_pos][type] = enemy_is_vec;
        }

    std::map<int, int> divided_situation_num[4];
    int situation_num = 0;
    for(auto type0 : possible_fish[0])
        for(auto type1 : possible_fish[1])
            for(auto type2 : possible_fish[2])
                for(auto type3 : possible_fish[3])
                {
                    auto& assumption0 = all_assumptions[0][type0];
                    auto& assumption1 = all_assumptions[1][type1];
                    auto& assumption2 = all_assumptions[2][type2];
                    auto& assumption3 = all_assumptions[3][type3];
                    Minisat::vec<Minisat::Lit> assumption;
                    for(auto lit : assumption0)
                        assumption.push(Minisat::mkLit(lit.no, !lit.is_true));
                    for(auto lit : assumption1)
                        assumption.push(Minisat::mkLit(lit.no, !lit.is_true));
                    for(auto lit : assumption2)
                        assumption.push(Minisat::mkLit(lit.no, !lit.is_true));
                    for(auto lit : assumption3)
                        assumption.push(Minisat::mkLit(lit.no, !lit.is_true));

                    if(solver.solve(assumption))
                    {
                        situation_num++;
                        divided_situation_num[0][type0]++;
                        divided_situation_num[1][type1]++;
                        divided_situation_num[2][type2]++;
                        divided_situation_num[3][type3]++;
                    }
                }
    
    calc_enemy_possible_rate(divided_situation_num, situation_num);

    double chosen_rate = 0;
    int chosen_enemy_pos;
    int chosen_type;

    for(auto enemy_pos : need_assert_pos)
    {
        for(auto type_pair : divided_situation_num[enemy_pos])
        {
            int type = type_pair.first;
            double rate = double(type_pair.second) / situation_num;

            if(like_turtle(enemy_pos) && type == turtle)
            {
                std::cerr << "enemy " << enemy_pos << " like turtle\n";
                rate = 0.9;
            }

            if(like_turtle(enemy_pos) && type == imitator && fish_possible_type[enemy_pos][turtle])
            {
                std::cerr << "enemy " << enemy_pos << " like imitator(turtle)\n";
                rate = 0.9;
            }

            //std::cerr << "enemy " << enemy_pos << " is " << type_pair.first << ": " << type_pair.second << "\n";
            //std::cerr << "rate is " << rate << "\n";

            if(rate > chosen_rate)
            {
                chosen_enemy_pos = enemy_pos;
                chosen_type = type;
                chosen_rate = rate;
            }
        }
    }

    if(chosen_rate > THRESHOLD)
    {
        std::cerr << "we choose " << chosen_enemy_pos << " to be " << chosen_type << "\n";
        return std::make_pair(chosen_enemy_pos, chosen_type);
    }

    std::cerr << "we choose nothing\n";
    return std::make_pair(-1, -1);
}

std::vector<int> party1 = {turtle, barracuda, spray, flame};
std::vector<int> party2 = {sunfish, hammerhead, imitator + barracuda, eel};
std::vector<int> party3 = {clownfish, whiteshark, octopus, mobula};
std::vector<std::vector<int>> parties = {party1, party2, party3};

std::vector<int> AI::Pick(Game game)
{
    init_round();

    new_round = true;

    using seed_t = std::default_random_engine::result_type;
    std::default_random_engine eng{static_cast<seed_t>(time(0))};
	std::shuffle(parties.begin(), parties.end(), eng);
    
    std::vector<int> pickfish = parties.back();
    parties.pop_back();
    std::shuffle(pickfish.begin(), pickfish.end(), eng);

    return pickfish;
}

hp_t AI::get_hps(Game& game)
{
    return hp_t(game.my_fish[0].hp, game.my_fish[1].hp, game.my_fish[2].hp, game.my_fish[3].hp, 
        game.enemy_fish[0].hp, game.enemy_fish[1].hp, game.enemy_fish[2].hp, game.enemy_fish[3].hp);
}

std::pair<int, int> AI::Assert(Game game)
{
    analyze(game);
    return do_assertion(game);
}

void AI::calc_enemy_possible_rate(std::map<int, int> divided_situation_num[4], int all_situation_num)
{
    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        std::vector<int> imitator_avatar;
        for(int type = 1; type <= 11; type++)
            if(fish_possible_type[enemy_pos][type])
                imitator_avatar.push_back(type);

        if(imitator_avatar.empty())
            std::cerr << "shit! no imitator_avatar\n";

        enemy_possible_rate[enemy_pos] = std::map<int, float>();
        for(auto situation_pair: divided_situation_num[enemy_pos])
        {
            int type = situation_pair.first;
            int num = situation_pair.second;

            if(type != 12)
            {
                enemy_possible_rate[enemy_pos][type] += float(num) / float(all_situation_num);
            }
            else
            {
                float distributed_rate = float(num) / float(all_situation_num) / imitator_avatar.size();
                for(auto avatar_type: imitator_avatar)
                    enemy_possible_rate[enemy_pos][avatar_type] += distributed_rate;
            }
        }
    }
}

active_skill AI::type_to_active(int type)
{
    if(type == 12)
        std::cerr << "shit! type_to_active 12\n";

    switch(type)
    {
    case spray:
    case eel:
        return range_attack;
    case flame:
    case sunfish:
        return friend_attack;
    case barracuda:
        return critical_attack;
    case mobula:
    case octopus:
        return reduce_injury;
    case turtle:
        return limit_critical;
    case whiteshark:
    case hammerhead:
        return weak_critical;
    case clownfish:
    default:
        return injury_tansfer;
    }
}

passive_skill AI::type_to_passive(int type)
{
    if(type == 12)
        std::cerr << "shit! type_to_passive 12\n";

    switch(type)
    {
    case spray:
    case flame:
        return injury_back;
    case eel:
    case sunfish:
        return friend_injury_transfer;
    case barracuda:
    case mobula:
        return avoid_injury;
    case turtle:
        return shield;
    case octopus:
    case whiteshark:
        return limit_heal;
    case hammerhead:
        return dead_boom;
    case clownfish:
    default:
        return injury_transfer;
    }
}

int AI::get_friend_type(Game& game, int friend_pos)
{
    int type = game.my_fish[friend_pos].id;
	if (type < 0) type = -type;
	if (type == 12) type = game.avatar_id;
	return type;
}

int AI::skill_damage(Game& game, int friend_pos)
{
    auto active = type_to_active(get_friend_type(game, friend_pos));
    auto skill_used = get_skill_used(friend_pos);
    auto atk = get_my_atk(friend_pos);

    bool self = get_my_living_ally(friend_pos).empty();

    switch(active)
    {
    case active_skill::critical_attack:
        return 120;
    case active_skill::friend_attack:
        return 0;
    case active_skill::injury_tansfer:
        if(self) return 0;
        return skill_used < 3 ? (atk * 0.35) : 0;
    case active_skill::limit_critical:
        if(self) return 0;
        return skill_used < 3 ? 120 : 0;
    case active_skill::range_attack:
    {
        return atk * 0.35;
    }
    case active_skill::reduce_injury:
        return 0;
    case active_skill::weak_critical:
    {
        int enemy_id = get_lowest_health_enemy();
        int lowest_hp = get_enemy_hp(enemy_id);
        return lowest_hp < 160 ? atk * 1.4 : atk * 1.2;
    }
    default:
        return 0;
    }
}

inline int sqr(int n) {return n * n;}

std::vector<int> get_lowest_health_friends(Game& game, std::vector<int> friend_poss)
{
    std::vector<int> ret;
    int min_health = 114514;
    for(auto friend_pos: friend_poss)
    {
        if(game.my_fish[friend_pos].hp == min_health)
        {
            ret.push_back(friend_pos);
        }
        else if(game.my_fish[friend_pos].hp < min_health)
        {
            ret.clear();
            ret.push_back(friend_pos);
            min_health = game.my_fish[friend_pos].hp;
        }
    }
    return ret;
}

int AI::unit_threat(Game& game, hp_t initial_hps, bool is_enemy, int unit_pos, fish_type unit_type, attack_up_t attack_up)
{
    std::vector<int> threats;

    int skill_used = is_enemy ? enemy_status[unit_pos].use_num : get_skill_used(unit_pos);

    int attack = 0;
    if(is_enemy)
    {
        int damage_200_taken = enemy_status[unit_pos].damage_taken / 200;
        switch(unit_type)
        {
        case spray:
        case barracuda:
        case turtle:
        case whiteshark:
        case clownfish:
            attack = 100;
            break;
        case flame:
            attack = 100 + skill_used * 70;
            break;
        case eel:
            attack = 100 + damage_200_taken * 20;
            break;
        case sunfish:
            attack = 100 + skill_used * 70 + damage_200_taken * 20;
            break;
        case mobula:
        case octopus:
            attack = 100 + skill_used * 20;
            break;
        case hammerhead:
            attack = 100 + (get_enemy_hp(unit_pos) < 80 ? 15 : 0);
            break;
        default:
            std::cerr << "shit! attack wrong\n";
            break;
        }
    }
    else
    {
        attack = get_my_atk(unit_pos);
    }

    attack += is_enemy ? attack_up.enemy_atk[unit_pos] : attack_up.friend_atk[unit_pos];

    auto defenders = is_enemy ? get_my_living_fishes() : get_enemy_living_fishes();
    std::sort(defenders.begin(), defenders.end());
    int defender_num = defenders.size();

    //attack threat
    for(auto defender_pos: defenders)
    {
        hp_t hps_change = attack_consequence_all(game, initial_hps, !is_enemy, unit_pos, defender_pos, attack / 2);
        int threat = hps_change.effect(is_enemy);
        threats.push_back(threat);
    }

    //skill threat
    switch(unit_type)
    {
    case spray:
    case eel:
    {
        hp_t hps_change = both_zero;
        for(auto defender_pos: defenders)
            hps_change += attack_consequence_all(game, initial_hps + hps_change, !is_enemy, unit_pos, defender_pos, attack * 0.35);
        int threat = hps_change.effect(is_enemy);
        threats.push_back(threat);
        break;
    }
    case clownfish:
    {
        if(skill_used < 3)
        {
            hp_t hps_change = both_zero;
            for(auto defender_pos: defenders)
                hps_change += attack_consequence_all(game, initial_hps + hps_change, !is_enemy, unit_pos, defender_pos, attack * 0.35);
            int threat = hps_change.effect(is_enemy);
            threats.push_back(threat);
        }
        break;
    }
    case barracuda:
    {
        for(auto defender_pos: defenders)
        {
            hp_t hps_change = attack_consequence_all(game, initial_hps, !is_enemy, unit_pos, defender_pos, 120);
            int threat = hps_change.effect(is_enemy);
            threats.push_back(threat);
        }
        break;
    }
    case turtle:
    {
        if(skill_used < 3)
        {
            for(auto defender_pos: defenders)
            {
                hp_t hps_change = attack_consequence_all(game, initial_hps, !is_enemy, unit_pos, defender_pos, 120);
                int threat = hps_change.effect(is_enemy);
                threats.push_back(threat);
            }
        }
        break;
    }
    case whiteshark:
    case hammerhead:
    {
        auto lowest_hp_defenders = is_enemy ? get_lowest_health_friends(game, defenders) : get_lowest_health_enemies();
        int min_hp = get_my_hp(lowest_hp_defenders[0]);
        int skill_damage = min_hp < 160 ? attack * 1.4 : attack * 1.2;

        for(auto defender_pos: lowest_hp_defenders)
        {
            hp_t hps_change = attack_consequence_all(game, initial_hps, !is_enemy, unit_pos, defender_pos, skill_damage);
            int threat = hps_change.effect(is_enemy);
            threats.push_back(threat);
        }
        break;
    }
    case flame:
    case sunfish:
    case mobula:
    case octopus:
        break;
    default:
        std::cerr << "shit! skill wrong\n";
        break;
    }

    auto max_threat = *std::max_element(threats.begin(), threats.end());
    return max_threat;
}


int AI::unit_threat_specified(Game& game, hp_t initial_hps, bool is_enemy, int unit_pos, fish_type unit_type, int defender_pos)
{
    std::vector<int> threats;

    int skill_used = is_enemy ? enemy_status[unit_pos].use_num : get_skill_used(unit_pos);

    int attack = 0;
    if(is_enemy)
    {
        int damage_200_taken = enemy_status[unit_pos].damage_taken / 200;
        switch(unit_type)
        {
        case spray:
        case barracuda:
        case turtle:
        case whiteshark:
        case clownfish:
            attack = 100;
            break;
        case flame:
            attack = 100 + skill_used * 70;
            break;
        case eel:
            attack = 100 + damage_200_taken * 20;
            break;
        case sunfish:
            attack = 100 + skill_used * 70 + damage_200_taken * 20;
            break;
        case mobula:
        case octopus:
            attack = 100 + skill_used * 20;
            break;
        case hammerhead:
            attack = 100 + (get_enemy_hp(unit_pos) < 80 ? 15 : 0);
            break;
        default:
            std::cerr << "shit! attack wrong\n";
            break;
        }
    }
    else
    {
        attack = get_my_atk(unit_pos);
    }

    auto defenders = is_enemy ? get_my_living_fishes() : get_enemy_living_fishes();
    std::sort(defenders.begin(), defenders.end());
    int defender_num = defenders.size();

    //attack threat
    threats.push_back(attack / 2);

    //skill threat
    switch(unit_type)
    {
    case spray:
    case eel:
    {
        threats.push_back(attack * 0.35);
        break;
    }
    case clownfish:
    {
        if(skill_used < 3)
            threats.push_back(attack * 0.35);
        break;
    }
    case barracuda:
    {
        threats.push_back(120);
        break;
    }
    case turtle:
    {
        if(skill_used < 3)
            threats.push_back(120);
        break;
    }
    case whiteshark:
    case hammerhead:
    {
        auto lowest_hp_defenders = is_enemy ? get_lowest_health_friends(game, defenders) : get_lowest_health_enemies();
        int min_hp = get_my_hp(lowest_hp_defenders[0]);
        int skill_damage = min_hp < 160 ? attack * 1.4 : attack * 1.2;

        if(std::find(lowest_hp_defenders.begin(), lowest_hp_defenders.end(), defender_pos) != lowest_hp_defenders.end())
            threats.push_back(skill_damage);

        break;
    }
    case flame:
    case sunfish:
    case mobula:
    case octopus:
        break;
    default:
        std::cerr << "shit! skill wrong\n";
        break;
    }

    auto max_threat = *std::max_element(threats.begin(), threats.end());
    return max_threat;
}

float AI::calc_enemy_counter_prob(Game& game, int enemy_pos)
{
    return enemy_possible_rate[enemy_pos][spray] + enemy_possible_rate[enemy_pos][flame];
}

const double REDUCE_RATE = 0.5;

hp_t AI::damage_consequence(Game& game, hp_t initial_hps, bool is_enemy, int pos, int damage, passive_skill passive)
{
    hp_t hps_change = both_zero;

    switch(passive)
    {
        case injury_back: //nothing happens
        case friend_injury_transfer:
        case dead_boom:
        case injury_transfer:
            hps_change.get_hp(is_enemy, pos) -= damage;
            break;
        case avoid_injury: //todo
        case shield: //todo
            hps_change.get_hp(is_enemy, pos) -= damage * REDUCE_RATE;
            break;
        case limit_heal:
            hps_change.get_hp(is_enemy, pos) -= damage;
            if(hps_change.get_hp(is_enemy, pos) > 0)
                hps_change.get_hp(is_enemy, pos) += 20;
            break;
        default:
            std::cerr << "shit! damage_friend_consequence unreachable\n";
    }
    return hps_change;
}

hp_t AI::damage_enemy_consequence_all(Game& game, hp_t initial_hps, int enemy_pos, int damage)
{
    hp_t total_hps_change = both_zero;

    for(auto possible_pair: enemy_possible_rate[enemy_pos])
    {
        int type = possible_pair.first;
        float rate = possible_pair.second;

        passive_skill passive = type_to_passive(type);
        hp_t hps_change = damage_consequence(game, initial_hps, true, enemy_pos, damage, passive);
        total_hps_change += hps_change * rate;
    }
    return total_hps_change;
}

hp_t AI::attack_consequence(Game& game, hp_t initial_hps, bool is_toward_enemy, int attacker_pos, int defender_pos, int damage, active_skill attacker_active, passive_skill defender_passive)
{
    hp_t hps_change = both_zero;

    std::vector<int> defender_living_allies = is_toward_enemy ? get_enemy_living_allies(defender_pos) : get_my_living_ally(defender_pos);
    passive_skill attacker_passive = type_to_passive(get_friend_type(game, attacker_pos)); //todo

    switch(defender_passive)
    {
        case injury_back: //nothing happens
            hps_change.get_hp(is_toward_enemy, defender_pos) -= damage;
            break;
        case friend_injury_transfer:
        {
            if(defender_living_allies.size() == 0)
            {
                hps_change.get_hp(is_toward_enemy, defender_pos) -= damage;
            }
            else
            {
                int self_damage = damage * 0.7;
                int other_damage =  damage * 0.3 / defender_living_allies.size();
                for(int other_defender_pos: defender_living_allies)
                {
                    if(is_toward_enemy)
                        hps_change += damage_enemy_consequence_all(game, initial_hps + hps_change, other_defender_pos, other_damage);
                    else
                    {
                        passive_skill other_defender_passive = type_to_passive(get_friend_type(game, other_defender_pos));
                        hps_change += damage_consequence(game, initial_hps + hps_change, false, defender_pos, other_damage, other_defender_passive);
                    }
                }
                hps_change.get_hp(is_toward_enemy, defender_pos) -= self_damage;
            }
            break;
        }
        case avoid_injury: //todo
        case shield: //todo
            hps_change.get_hp(is_toward_enemy, defender_pos) -= damage * 0.7;
            break;
        case limit_heal:
            hps_change.get_hp(is_toward_enemy, defender_pos) -= damage;
            if(hps_change.get_hp(is_toward_enemy, defender_pos) > 0)
                hps_change.get_hp(is_toward_enemy, defender_pos) += 20;
            break;
        case dead_boom:
        {
            hps_change.get_hp(is_toward_enemy, defender_pos) -= damage;
            auto new_hps = initial_hps + hps_change;
            if(new_hps.get_hp(is_toward_enemy, defender_pos) <= 0)
            {
                if(is_toward_enemy)
                    hps_change += damage_consequence(game, initial_hps + hps_change, false, attacker_pos, 40, attacker_passive);
                else
                    hps_change += damage_enemy_consequence_all(game, initial_hps + hps_change, attacker_pos, 40);
            }
            break;
        }
        case injury_transfer:
        {
            hps_change.get_hp(is_toward_enemy, defender_pos) -= damage;
            auto new_hps = initial_hps + hps_change;
            if(new_hps.get_hp(is_toward_enemy, defender_pos) < 120)
            {
                if(is_toward_enemy)
                    hps_change += damage_consequence(game, initial_hps + hps_change, false, attacker_pos, 30, attacker_passive);
                else
                    hps_change += damage_enemy_consequence_all(game, initial_hps + hps_change, attacker_pos, 30);
            }
            break;
        }
        default:
            std::cerr << "shit! attack_enemy_consequence unreachable\n";
    }

    auto new_hps = initial_hps + hps_change;
    if(new_hps.get_hp(is_toward_enemy, defender_pos) < 120) //others counter
    {
        if(is_toward_enemy)
        {
            auto counter_hps_change = damage_consequence(game, new_hps, false, attacker_pos, 30, attacker_passive);
            float counter_rate = 0.0f;
            for(auto other_defender_pos: defender_living_allies)
                counter_rate += calc_enemy_counter_prob(game, other_defender_pos);
            hps_change += counter_hps_change * counter_rate;
        }
        else
        {
            auto counter_hps_change = damage_enemy_consequence_all(game, new_hps, attacker_pos, 30);
            float counter_rate = 0.0f;
            for(auto other_defender_pos: defender_living_allies)
                if(type_to_passive(get_friend_type(game, other_defender_pos)) == injury_back)
                    counter_rate += 1.0f;
            hps_change += counter_hps_change * counter_rate;
        }
    }

    //if(hps_change.get_hp(!is_toward_enemy, attacker_pos) < 0)
    //    std::cerr << "if enemy " << defender_pos << " has passive " << defender_passive << ", attacker takes damage\n";

    return hps_change;
}

hp_t AI::attack_enemy_consequence_all(Game& game, hp_t initial_hps, int attacker_pos, int defender_pos, int damage)
{
    hp_t total_hps_change = both_zero;

    for(auto possible_pair: enemy_possible_rate[defender_pos])
    {
        int type = possible_pair.first;
        float rate = possible_pair.second;

        active_skill attacker_active = type_to_active(get_friend_type(game, attacker_pos));
        passive_skill defender_passive = type_to_passive(type);
        hp_t hps_change = attack_consequence(game, initial_hps, true, attacker_pos, defender_pos, damage, attacker_active, defender_passive);
        total_hps_change += hps_change * rate;
    }
    return total_hps_change;
}

hp_t AI::attack_friend_consequence_all(Game& game, hp_t initial_hps, int attacker_pos, int defender_pos, int damage)
{
    hp_t total_hps_change = both_zero;

    for(auto possible_pair: enemy_possible_rate[defender_pos])
    {
        int type = possible_pair.first;
        float rate = possible_pair.second;

        active_skill attacker_active = type_to_active(type);
        passive_skill defender_passive = type_to_passive(get_friend_type(game, defender_pos));
        hp_t hps_change = attack_consequence(game, initial_hps, false, attacker_pos, defender_pos, damage, attacker_active, defender_passive);
        total_hps_change += hps_change * rate;
    }
    return total_hps_change;
}

int AI::enemy_max_single_attack(Game& game, hp_t initial_hps, int friend_pos)
{
    int ret = -1;

    for(auto enemy_pos : get_enemy_living_fishes())
    {
        int enemy_threat = 0;
        for(auto possible_pair: enemy_possible_rate[enemy_pos])
        {
            int type = possible_pair.first;
            float rate = possible_pair.second;

            int threat = unit_threat_specified(game, initial_hps, true, enemy_pos, fish_type(type), friend_pos);
            //std::cerr << "enemy " << enemy_pos << " is " << type << ": " << rate << "; threat: " << threat << "\n";

            enemy_threat += threat * rate;
        }
        if(enemy_threat >= ret)
            ret = enemy_threat;
    }

    return ret;
}

const int DEAD_BONUS = 1000000;

int AI::evaluate_board(Game& game, hp_t hps, attack_up_t attack_up = attack_up_t())
{
    int evaluate = 0;
    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        if(hps.enemy_hp[enemy_pos] > 0)
            evaluate -= enemy_threat_all(game, hps, enemy_pos, attack_up) * hps.enemy_hp[enemy_pos];
        else
            evaluate += DEAD_BONUS;
    }
    for(int friend_pos = 0; friend_pos < 4; friend_pos++)
    {
        if(hps.friend_hp[friend_pos] > 0)
            evaluate += unit_threat(game, hps, false, friend_pos, fish_type(get_friend_type(game, friend_pos)), attack_up) * hps.friend_hp[friend_pos];
        else
            evaluate -= DEAD_BONUS;
    }
    return evaluate;
}

int AI::enemy_threat_all(Game& game, hp_t initial_hps, int enemy_pos, attack_up_t attack_up)
{
    float ret = 0.0f;

    for(auto possible_pair: enemy_possible_rate[enemy_pos])
    {
        int type = possible_pair.first;
        float rate = possible_pair.second;

        int threat = unit_threat(game, initial_hps, true, enemy_pos, fish_type(type), attack_up);
        //std::cerr << "enemy " << enemy_pos << " is " << type << ": " << rate << "; threat: " << threat << "\n";

        ret += threat * rate;
    }

    return int(ret);
}

bool AI::is_safe(Game& game, step_t& step)
{
    if(get_my_id(step.mover) < 0) //exposed
        return true;

    if(!step.is_skill)
        return true;
    
    auto active = type_to_active(get_friend_type(game, step.mover));
    int used = get_skill_used(step.mover);
    switch(active)
    {
    case active_skill::friend_attack:
    case active_skill::reduce_injury:
    default:
        return used > 0;
    case active_skill::range_attack:
    case active_skill::weak_critical:
    case active_skill::critical_attack:
    case active_skill::injury_tansfer:
    case active_skill::limit_critical:
        return used > 0 && used != 3;
    }
}

const int FIRST_ATTACK_BONUS = 3;
const int HEAL_EFFECT = 20;
const int REDUCE_EFFECT = 35; //?
const int ATTACKUP_EFFECT = 10; //half of 20

void AI::best_motion(Game& game, Action& action)
{
    std::cerr << "best motion:\n";

    auto living_friends = get_my_living_fishes();
    auto living_enemies = get_enemy_living_fishes();
    std::sort(living_enemies.begin(), living_enemies.end());

    hp_t initial_hps = get_hps(game);
    int initial_evaluate = evaluate_board(game, initial_hps);

    std::map<int, int> enemy_threat;
    for(auto enemy_pos: living_enemies)
    {
        enemy_threat[enemy_pos] = enemy_threat_all(game, initial_hps, enemy_pos, attack_up_t());
        std::cerr << "enemy " << enemy_pos << "'s threat:" << enemy_threat[enemy_pos] << "\n";
    }

    std::map<int, int> friend_threat;
    for(auto friend_pos: living_friends)
    {
        friend_threat[friend_pos] = unit_threat(game, initial_hps, false, friend_pos, fish_type(get_friend_type(game, friend_pos)), attack_up_t());
        std::cerr << "friend " << friend_pos << "'s threat:" << friend_threat[friend_pos] << "\n";
    }

    std::vector<step_t> available_steps;

    for(auto friend_pos: living_friends)
    {
        const auto& ally = game.my_fish[friend_pos];
        auto friend_attack_damage = ally.atk / 2;

        for(auto enemy_target: living_enemies)
        {
            hp_t hps_change = attack_enemy_consequence_all(game, initial_hps, friend_pos, enemy_target, friend_attack_damage);
            int evaluate = evaluate_board(game, initial_hps + hps_change);
            int effect = (evaluate - initial_evaluate) * (enemy_status[enemy_target].attacked ? 1 : FIRST_ATTACK_BONUS);

            //std::cerr << friend_pos << " attacks: " << enemy_target << ":\n" << hps_change << "effect is " << effect << "\n";

            available_steps.push_back(step_t(friend_pos, effect, -1, enemy_target, false));
        }

        auto ally_skill_damage = skill_damage(game, friend_pos);
        std::cerr << "skill_damage of " << friend_pos << " is " << ally_skill_damage << "\n";

        auto friend_active = type_to_active(get_friend_type(game, friend_pos));
        switch(friend_active)
        {
        case active_skill::limit_critical:
            if(get_skill_used(friend_pos) < 3)
            {
                for(auto ally_target : get_my_living_ally(friend_pos))
                    for(auto enemy_target : living_enemies)
                    {
                        hp_t hps_change = attack_enemy_consequence_all(game, initial_hps, friend_pos, enemy_target, 120);
                        hps_change.friend_hp[ally_target] += 20;
                        int evaluate = evaluate_board(game, initial_hps + hps_change);
                        int effect = (evaluate - initial_evaluate) * (enemy_status[enemy_target].attacked ? 1 : FIRST_ATTACK_BONUS);

                        //std::cerr << friend_pos << " critical attacks: " << enemy_target << ":\n" << hps_change << "effect is " << effect << "\n";

                        available_steps.push_back(step_t(friend_pos, effect, ally_target, enemy_target, true));
                    }
            }
            else
            {
                for(auto ally_target : get_my_living_ally(friend_pos))
                {
                    hp_t hps_change = both_zero;
                    hps_change.friend_hp[ally_target] += 20;
                    int evaluate = evaluate_board(game, initial_hps + hps_change);
                    int effect = evaluate - initial_evaluate;
                    available_steps.push_back(step_t(friend_pos, effect, ally_target, -1, true));
                }
            }
            break;
        case active_skill::critical_attack:
            for(auto enemy_target : living_enemies)
            {
                hp_t hps_change = attack_enemy_consequence_all(game, initial_hps, friend_pos, enemy_target, 120);
                int evaluate = evaluate_board(game, initial_hps + hps_change);
                int effect = (evaluate - initial_evaluate) * (enemy_status[enemy_target].attacked ? 1 : FIRST_ATTACK_BONUS);

                //std::cerr << friend_pos << "critical attacks: " << enemy_target << ":\n" << hps_change << "effect is " << effect << "\n";

                available_steps.push_back(step_t(friend_pos, effect, -1, enemy_target, true));
            }
            break;
        case active_skill::injury_tansfer:
            if(get_skill_used(friend_pos) < 3)
            {
                hp_t hps_change = both_zero;
                for(auto enemy_target: living_enemies)
                    hps_change += attack_enemy_consequence_all(game, initial_hps + hps_change, friend_pos, enemy_target, ally.atk * 0.35);

                int evaluate = evaluate_board(game, initial_hps + hps_change);
                int effect = evaluate - initial_evaluate;

                for(auto enemy_target: living_enemies)
                     if(!enemy_status[enemy_target].attacked)
                         effect *= FIRST_ATTACK_BONUS;

                //std::cerr << friend_pos << " limit aoe:\n" << hps_change << "effect is " << effect << "\n";

                for(auto ally_target : get_my_living_ally(friend_pos))
                {
                    int new_effect = effect + friend_threat[ally_target]; // deflect to most aggressive ally
                    available_steps.push_back(step_t(friend_pos, new_effect, ally_target, -2, true));
                }
            }
            break;
        case active_skill::range_attack:
        {
            hp_t hps_change = both_zero;
            for(auto enemy_target: living_enemies)
                hps_change += attack_enemy_consequence_all(game, initial_hps + hps_change, friend_pos, enemy_target, ally.atk * 0.35);

            int evaluate = evaluate_board(game, initial_hps + hps_change);
            int effect = evaluate - initial_evaluate;

            for(auto enemy_target: living_enemies)
                if(!enemy_status[enemy_target].attacked)
                    effect *= FIRST_ATTACK_BONUS;

            //std::cerr << friend_pos << " aoe:\n" << hps_change << "effect is " << effect << "\n";

            available_steps.push_back(step_t(friend_pos, effect, -1, -2, true));
            break;
        }
        case active_skill::reduce_injury:
        {
            attack_up_t attack_up;
            attack_up.friend_atk[friend_pos] += 20;

            for(auto ally_target : living_friends)
            {
                hp_t hps_change = both_zero;

                int max_strike = enemy_max_single_attack(game, initial_hps, ally_target);
                int already_reduce_num = friend_reduce_num[ally_target];

                int previous_damage = max_strike;
                for(int i = 0; i < already_reduce_num; i++)
                    previous_damage *= 0.3;
                int after_damage = previous_damage * 0.3;

                std::cerr << "friend " << ally_target << " takes most " << max_strike << " damage, has " << already_reduce_num << "reduce buff already, ";
                std::cerr << "if add buff, hp increases " << (previous_damage - after_damage) << "\n";

                hps_change.friend_hp[ally_target] += (previous_damage - after_damage);
                int evaluate = evaluate_board(game, initial_hps + hps_change, attack_up);
                int effect = evaluate - initial_evaluate;

                std::cerr << "effect is " << effect << "\n";

                available_steps.push_back(step_t(friend_pos, effect, ally_target, -1, true));
            }
            break;
        }
        case active_skill::weak_critical:
        {
            auto enemy_targets = get_lowest_health_enemies();
            for(auto enemy_target : enemy_targets)
            {
                hp_t hps_change = attack_enemy_consequence_all(game, initial_hps, friend_pos, enemy_target, ally_skill_damage);
                int evaluate = evaluate_board(game, initial_hps + hps_change);
                int effect = (evaluate - initial_evaluate) * (enemy_status[enemy_target].attacked ? 1 : FIRST_ATTACK_BONUS);

                //std::cerr << friend_pos << " weak critical " << enemy_target << ":\n" << hps_change << "effect is " << effect << "\n";

                available_steps.push_back(step_t(friend_pos, effect, -1, enemy_target, true));
            }
            break;
        }
        }
    }

    if(available_steps.empty())
        std::cerr << "shit! no available steps\n";

    for(auto& step : available_steps)
    {
        if(is_safe(game, step))
            step.effect *= 3;

        if(!step.is_skill)
            step.effect *= 0.5;
    }

    int max_effect = INT32_MIN;
    step_t* chosen_step = nullptr;
    for(auto& step : available_steps)
    {
        if(step.effect > max_effect)
        {
            max_effect = step.effect;
            chosen_step = &step;
        }
    }

    if(!chosen_step)
    {
        std::cerr << "shit! no step chosen\n";
        std::cerr << "steps are:\n";
        for(auto& step: available_steps)
            std::cerr << step.mover << " uses " << step.is_skill << " to friend " << step.ally << " and enemy " << step.enemy << " effect is " << step.effect << "\n";
        std::exit(0);
    }

    if(chosen_step->is_skill)
        std::cerr << "Choose " << chosen_step->mover << "(" << get_friend_type(game, chosen_step->mover) << "), skill\n";
    else
        std::cerr << "Choose " << chosen_step->mover << "(" << get_friend_type(game, chosen_step->mover) << "), attack\n";

    action.set_action_fish(chosen_step->mover);
    action.set_action_type(chosen_step->is_skill ? 1 : 0);

    if(chosen_step->enemy != -1)
    {
        std::cerr << "Choose enemy " << chosen_step->enemy << "\n";
        action.set_enemy_target(chosen_step->enemy);
    }

    if(chosen_step->ally != -1)
    {
        std::cerr << "Choose ally " << chosen_step->ally << "\n";
        action.set_friend_target(chosen_step->ally);
    }

    //update reduce
    if(chosen_step->is_skill && type_to_active(get_friend_type(game, chosen_step->mover)) == reduce_injury)
    {
        friend_reduce_num[chosen_step->ally]++;
    }
}

Action AI::Act(Game game)
{
    last_turn_hps = get_hps(game);

    Action action(game);
    best_motion(game, action);
    return action;
}
#include "cnf.h"

#include <iostream>
#include <algorithm>

cnf cnf_and(cnf a, cnf b)
{
    cnf ret;
    for(auto& clause: a.clauses)
        ret.clauses.push_back(clause);
    
    for(auto& clause: b.clauses)
        ret.clauses.push_back(clause);
    
    return ret;
}

cnf cnf_or(cnf a, cnf b)
{
    cnf ret;

    for(auto& clause1: a.clauses)
        for(auto& clause2: b.clauses)
        {
            clause clause12;

            for(auto& literal1: clause1.literals)
                clause12.literals.push_back(literal1);

            for(auto& literal2: clause2.literals)
                clause12.literals.push_back(literal2);

            ret.clauses.push_back(clause12);
        }
    
    return ret;
}

cnf cnf_not(clause& a)
{
    cnf ret;
    for(auto l: a.literals)
        ret.clauses.push_back(clause(~l));
    return ret;
}



cnf cnf_not(cnf a)
{
    if(a.clauses.empty())
        std::cerr << "shit! cnf_not's a.clauses is empty\n";

    std::vector<cnf> cnfs;
    for(auto& clause: a.clauses)
        cnfs.push_back(cnf_not(clause));

    if(cnfs.empty())
        std::cerr << "shit! cnf_not's cnfs is empty\n";

    cnf ret = cnfs[0];
    for(int i = 1; i < cnfs.size(); i++)
        ret = cnf_or(ret, cnfs[i]);
    
    simplify(ret);

    return ret;
}

void simplify(cnf& a)
{
    for(auto cit = a.clauses.begin(); cit != a.clauses.end();)
    {
        auto& clause = *cit;
        std::sort(clause.literals.begin(), clause.literals.end());

        bool trivial = false;
        for(int i = 0; i < clause.literals.size() - 1; i++)
        {
            auto& l1 = clause.literals[i];
            auto& l2 = clause.literals[i + 1];
            if(l1.no == l2.no && l1.is_true != l2.is_true)
            {
                trivial = true;
                break;
            }
        }
        if(trivial)
            cit = a.clauses.erase(cit);
        else
            cit++;
    }
}
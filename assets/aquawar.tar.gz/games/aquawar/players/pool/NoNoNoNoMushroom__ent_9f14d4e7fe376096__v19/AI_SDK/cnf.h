#include <vector>
#include <iostream>

struct literal
{
    int no;
    bool is_true;
    literal(int _no, bool _is_true): no(_no), is_true(_is_true) {}
    literal operator~() {return literal(no, !is_true);}

    friend std::ostream& operator<<(std::ostream& out, literal& l) 
    {
        if(l.is_true)
            out << l.no;
        else
            out << "not-" << l.no;
        return out;
    }

    bool operator<(const literal& right) const
    {
        if(no != right.no)  return no < right.no;
        return is_true < right.is_true;
    }
};

struct clause
{
    std::vector<literal> literals;
    clause() {}
    clause(literal l) {literals.push_back(l);}
    clause(literal l1, literal l2) {literals.push_back(l1); literals.push_back(l2);}
    clause(std::vector<literal> ls) : literals(ls) {}

    friend std::ostream& operator<<(std::ostream& out, clause& c)
    {
        out << "(";
        for(auto l: c.literals)
            out << l << " ";
        out << ")";
        return out;
    }
};

struct cnf
{
    std::vector<clause> clauses;
    cnf() {}

    friend std::ostream& operator<<(std::ostream& out, cnf c)
    {
        out << "[";
        for(auto l: c.clauses)
            out << l << " ";
        out << "]";
        return out;
    }
};

cnf cnf_and(cnf a, cnf b);
cnf cnf_or(cnf a, cnf b);
cnf cnf_not(cnf a);
void simplify(cnf& a);
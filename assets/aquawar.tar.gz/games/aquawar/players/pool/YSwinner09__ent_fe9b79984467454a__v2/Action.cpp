#include "Action.hpp"
#include <algorithm>
#include <ctime>
#include <cmath>
#include <sys/timeb.h>

int assert_result[13] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, last_assert_num = -1,
        crit_choice = -1, fish_in_round[13] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}, num_round[3] = {0};
bool must_be_true = false, is_counter[3] = {false, false, false}, counter_assert = false, heal_assert = false,
        deflect_assert = false, flee_assert = false;
skill_type last_assert_type = aoe;

struct Fish_For_Assert
{
    bool is_aoe = false;
    bool is_inflight = false;
    bool is_crit = false;
    bool is_subtle = false;
    bool is_flee = false;
    bool is_heal = false;
    bool is_deflect = false;
    bool is_injury = false;
    bool is_invincible = false;
    int max_aoe = 0;
    int max_crit = 0;
    int max_normalattack = 0;
    int max_heal = 0;
    int max_deflect = 0;
    int total_injury = false;
    int total_heal = 0;
    int total_deflect = 0;
    int total_flee = 0;
    int total_target = 0;
}assert_fish[12];

std::vector<int> AI::Pick(Game game)
{
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
    pickfish.clear();
    int remain = remain_fishes.size();
    if (remain == 12)
    {
        pickfish.push_back(7);
        pickfish.push_back(1);
        pickfish.push_back(10);
        pickfish.push_back(17);
    }
    else if (remain == 8)
    {
        pickfish.push_back(9);
        pickfish.push_back(3);
        pickfish.push_back(8);
        pickfish.push_back(5);
    }
    else
    {
        pickfish.push_back(2);
        pickfish.push_back(11);
        pickfish.push_back(4);
        pickfish.push_back(6);
    }
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    int k = game.round - 1;
    num_round[k]++;
    if (game.my_assert.assertResult)
    {
        flee_assert = false;
        heal_assert = false;
        deflect_assert = false;
        counter_assert = false;
        crit_choice = -1;
        must_be_true = false;
        last_assert_type = aoe;
        last_assert_num = -1;
        assert_result[game.my_assert.assertContent] = 0;
        fish_in_round[game.my_assert.assertContent] = game.round;
    }
    else if (!game.my_assert.assertResult && get_enemy_hp(game.my_assert.assertPos) == 0)
    {
        flee_assert = false;
        heal_assert = false;
        deflect_assert = false;
        counter_assert = false;
        crit_choice = -1;
        must_be_true = false;
        last_assert_type = aoe;
        last_assert_num = -1;
    }
    if (!get_first_mover() || (get_first_mover() && num_round[k] >= 2))
    {
        if (game.enemy_action.type == aoe)
        {
            assert_fish[game.enemy_action.action_fish + 4 * k].is_aoe = true;
            if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_aoe)
                assert_fish[game.enemy_action.action_fish + 4 * k].max_aoe = game.enemy_action.enemy_expected_injury[0];
        }
        else if (game.enemy_action.type == infight)
        {
            assert_fish[game.enemy_action.action_fish + 4 * k].is_inflight = true;
        }
        else if (game.enemy_action.type == crit)
        {
            assert_fish[game.enemy_action.action_fish + 4 * k].is_crit = true;
            if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_crit)
                assert_fish[game.enemy_action.action_fish + 4 * k].max_crit = game.enemy_action.enemy_expected_injury[0];
        }
        else if (game.enemy_action.type == subtle)
            assert_fish[game.enemy_action.action_fish + 4 * k].is_subtle = true;
        else if (game.enemy_action.type == normalattack)
        {
            if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_normalattack)
                assert_fish[game.enemy_action.action_fish + 4 * k].max_normalattack = game.enemy_action.enemy_expected_injury[0];
        }
        for (int i = 0; i < game.my_action.num_enemy_injury; i++)
        {
            assert_fish[game.my_action.enemy_injury_id[i] + 4 * k].is_injury = true;
            assert_fish[game.my_action.enemy_injury_id[i] + 4 * k].total_injury++;
        }
        for (int i = 0; i < game.my_action.num_enemy_targets; i++)
            assert_fish[game.my_action.enemy_targets[i] + 4 * k].total_target++;
        int cur_heal[4] = {0}, cur_deflect[4] = {0};
        for (int i = 0; i < game.my_action.num_enemy_passives; i++)
        {
            if (game.my_action.enemy_types[i] == counter)
                is_counter[k] = true;
            else if (game.my_action.enemy_types[i] == deflect && assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].total_deflect != -2)
            {
                assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].is_deflect = true;
                assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].total_deflect++;
                cur_deflect[game.my_action.enemy_passives_id[i]]++;
            }
            else if (game.my_action.enemy_types[i] == reduce)
            {
                if (game.my_action.enemy_passive_value[i] == 0)
                {
                    assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].is_flee = true;
                    assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].total_flee++;
                }
            }
            else if (game.my_action.enemy_types[i] == heal && assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].total_heal != -2)
            {
                assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].is_heal = true;
                assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].total_heal++;
                cur_heal[game.my_action.enemy_passives_id[i]]++;
            }
        }
        for (int i = 0; i < 4; i++)
        {
            if (assert_fish[4 * k + i].total_target == 3 && assert_fish[4 * k + i].total_flee == 3)
                assert_fish[4 * k + i].is_invincible = true;
            if (cur_heal[i] > assert_fish[4 * k + i].max_heal)
                assert_fish[4 * k + i].max_heal = cur_heal[i];
            if (cur_deflect[i] > assert_fish[4 * k + i].max_deflect)
                assert_fish[4 * k + i].max_deflect = cur_deflect[i];
            if (assert_fish[4 * k + i].total_deflect < assert_fish[4 * k + i].total_target)
            {
                assert_fish[4 * k + i].is_deflect = false;
                assert_fish[4 * k + i].total_deflect = -2;
            }
            if (assert_fish[4 * k + i].total_heal < assert_fish[4 * k + i].total_injury)
            {
                assert_fish[4 * k + i].is_heal = false;
                assert_fish[4 * k + i].total_heal = -2;
            }
        }
    }
    int assert_aoe_nodeflect[12] = {0}, assert_inflight[12] = {0}, assert_subtle[12] = {0},
            assert_normal[12] = {0}, assert_crit_flee[12] = {0}, assert_crit_not_flee[12] = {0},
            assert_counter[12] = {0}, assert_heal[12] = {0}, assert_deflect[12] = {0}, assert_flee[12] = {0};
    int num_aoe_nodeflect = 0, num_inflight = 0, num_subtle = 0, num_normal = 0, num_crit_flee = 0,
            num_crit_not_flee = 0, num_counter = 0, num_heal = 0, num_deflect = 0, num_flee = 0;
    for (int i = 1; i <= 12; i++)
    {
        if (assert_result[i] == 1)
        {
            if (i == 1 || i == 11 || i == 12)
                assert_aoe_nodeflect[num_aoe_nodeflect++] = i;
            if (i == 2 || i == 4 || i == 12)
                assert_inflight[num_inflight++] = i;
            if (i == 6 || i == 8 || i == 12)
                assert_subtle[num_subtle++] = i;
            if (i == 3 || i == 4 || i == 12)
                assert_normal[num_normal++] = i;
            if (i == 5 || i == 7 || i == 12)
                assert_crit_flee[num_crit_flee++] = i;
            if (i == 5 || i == 10 || i == 12)
                assert_crit_not_flee[num_crit_not_flee++] = i;
            if (i == 1 || i == 2 || i == 11 || i == 12)
                assert_counter[num_counter++] = i;
            if (i == 3 || i == 4 || i == 12)
                assert_deflect[num_deflect++] = i;
            if (i == 8 || i == 9 || i == 12)
                assert_heal[num_heal++] = i;
            if (i == 5 || i == 6 || i == 7 || i == 12)
                assert_flee[num_flee++] = i;
        }
    }
    if (num_round[k] >= 2 && must_be_true && !game.my_assert.assertResult && game.my_assert.assertContent != 0 &&
        get_enemy_hp(game.my_assert.assertPos) > 0)
    {
        must_be_true = false;
        return std::make_pair(game.my_assert.assertPos, 12);
    }
    else if (num_round[k] >= 2 && !must_be_true && !game.my_assert.assertResult && game.my_assert.assertContent != 0 &&
             last_assert_num != -1 && get_enemy_hp(game.my_assert.assertPos) > 0)
    {
        if (!counter_assert && !heal_assert && !deflect_assert && !flee_assert)
        {
            if (last_assert_type == aoe && assert_aoe_nodeflect[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_aoe_nodeflect[++last_assert_num]);
            else if (last_assert_type == infight && assert_inflight[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_inflight[++last_assert_num]);
            else if (last_assert_type == crit && crit_choice == 0 && assert_crit_flee[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_crit_flee[++last_assert_num]);
            else if (last_assert_type == crit && crit_choice == 1 && assert_crit_not_flee[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_crit_not_flee[++last_assert_num]);
            else if (last_assert_type == subtle && assert_subtle[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_subtle[++last_assert_num]);
            else if (last_assert_type == normalattack && assert_normal[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_normal[++last_assert_num]);
        }
        if (heal_assert && assert_heal[last_assert_num + 1] != 0)
            return std::make_pair(game.my_assert.assertPos, assert_heal[++last_assert_num]);
        if (deflect_assert && assert_deflect[last_assert_num + 1] != 0)
            return std::make_pair(game.my_assert.assertPos, assert_deflect[++last_assert_num]);
        if (counter_assert && assert_counter[last_assert_num + 1] != 0)
            return std::make_pair(game.my_assert.assertPos, assert_counter[++last_assert_num]);
        if (flee_assert && assert_flee[last_assert_num + 1] != 0)
            return std::make_pair(game.my_assert.assertPos, assert_flee[++last_assert_num]);
    }
    int min_assert_time = 12, min_assert_type = -1, min_assert_pos = -1, counter_pos = -1, num_not_assert = 0;
    for (int i = 0; i < 4; i++)
    {
        if (get_enemy_id(i) == -1)
        {
            num_not_assert++;
            counter_pos = i;
            if (num_round[k] >= 2 && get_enemy_hp(i) > 0)
            {
                if (assert_fish[4 * k + i].is_invincible)
                {
                    must_be_true = true;
                    return std::make_pair(i, 7);
                }
                if (assert_fish[4 * k + i].is_aoe)
                {
                    if (assert_fish[4 * k + i].max_aoe == 42)
                    {
                        must_be_true = true;
                        return std::make_pair(i, 3);
                    }
                    if (assert_fish[4 * k + i].is_deflect)
                    {
                        must_be_true = true;
                        return std::make_pair(i, 3);
                    }
                    if (!assert_fish[4 * k + i].is_deflect && num_aoe_nodeflect < min_assert_time)
                    {
                        min_assert_time = num_aoe_nodeflect;
                        min_assert_type = 0;
                        min_assert_pos = i;
                    }
                }
                if (assert_fish[4 * k + i].is_inflight)
                {
                    if (num_inflight < min_assert_time)
                    {
                        min_assert_type = num_inflight;
                        min_assert_type = 1;
                        min_assert_pos = i;
                    }
                }
                if (assert_fish[4 * k + i].is_crit)
                {
                    if (assert_fish[4 * k + i].max_crit == 138 || assert_fish[4 * k + i].max_crit == 161)
                    {
                        must_be_true = true;
                        return std::make_pair(i, 10);
                    }
                    if (assert_fish[4 * k + i].is_flee)
                    {
                        if (num_crit_flee < min_assert_time)
                        {
                            min_assert_time = num_crit_flee;
                            min_assert_type = 2;
                            min_assert_pos = i;
                        }
                    }
                    if (assert_fish[4 * k + i].is_injury && !assert_fish[4 * k + i].is_heal && !assert_fish[4 * k + i].is_flee)
                    {
                        if (num_crit_not_flee < min_assert_time)
                        {
                            min_assert_time = num_crit_not_flee;
                            min_assert_type = 3;
                            min_assert_pos = i;
                        }
                    }
                }
                if (assert_fish[4 * k + i].is_subtle)
                {
                    if (!assert_fish[4 * k + i].is_crit && !assert_fish[4 * k + i].is_aoe)
                    {
                        if (num_subtle < min_assert_time)
                        {
                            min_assert_time = num_subtle;
                            min_assert_type = 4;
                            min_assert_pos = i;
                        }
                    }
                    if (assert_fish[4 * k + i].is_crit && !assert_fish[4 * k + i].is_aoe)
                    {
                        must_be_true = true;
                        return std::make_pair(i, 7);
                    }
                    if (!assert_fish[4 * k + i].is_crit && assert_fish[4 * k + i].is_aoe)
                    {
                        must_be_true = true;
                        return std::make_pair(i, 11);
                    }
                }
                if (assert_fish[4 * k + i].is_flee)
                {
                    if (num_flee < min_assert_time)
                    {
                        min_assert_time = num_flee;
                        min_assert_type = 5;
                        min_assert_pos = i;
                    }
                }
                if (assert_fish[4 * k + i].max_heal >= 2 ||
                    (assert_fish[4 * k + i].total_injury >= 4 && assert_fish[4 * k + i].is_heal))
                {
                    if (num_heal < min_assert_time)
                    {
                        min_assert_time = num_heal;
                        min_assert_type = 6;
                        min_assert_pos = i;
                    }
                }
                if (assert_fish[4 * k + i].max_deflect >= 2 ||
                    (assert_fish[4 * k + i].total_target >= 4 && assert_fish[4 * k + i].is_deflect))
                {
                    if (num_deflect < min_assert_time)
                    {
                        min_assert_time = num_deflect;
                        min_assert_type = 7;
                        min_assert_pos = i;
                    }
                }
                if (assert_fish[4 * k + i].max_normalattack == 60 && !assert_fish[4 * k + i].is_subtle)
                {
                    if (num_normal < min_assert_time)
                    {
                        min_assert_time = num_normal;
                        min_assert_type = 8;
                        min_assert_pos = i;
                    }
                }
            }
        }
    }
    if (min_assert_time <= 3 && num_round[k] >= 2)
    {
        last_assert_num = 0;
        if (min_assert_type == 0)
        {
            last_assert_type = aoe;
            return std::make_pair(min_assert_pos, assert_aoe_nodeflect[last_assert_num]);
        }
        else if (min_assert_type == 1)
        {
            last_assert_type = infight;
            return std::make_pair(min_assert_pos, assert_inflight[last_assert_num]);
        }
        else if (min_assert_type == 2)
        {
            crit_choice = 0;
            last_assert_type = crit;
            return std::make_pair(min_assert_pos, assert_crit_flee[last_assert_num]);
        }
        else if (min_assert_type == 3)
        {
            crit_choice = 1;
            last_assert_type = crit;
            return std::make_pair(min_assert_pos, assert_crit_not_flee[last_assert_num]);
        }
        else if (min_assert_type == 4)
        {
            last_assert_type = subtle;
            return std::make_pair(min_assert_pos, assert_subtle[last_assert_num]);
        }
        else if (min_assert_type == 5)
        {
            flee_assert = true;
            return std::make_pair(min_assert_pos, assert_flee[last_assert_num]);
        }
        else if (min_assert_type == 6)
        {
            heal_assert = true;
            return std::make_pair(min_assert_pos, assert_heal[last_assert_num]);
        }
        else if (min_assert_type == 7)
        {
            deflect_assert = true;
            return std::make_pair(min_assert_pos, assert_deflect[last_assert_num]);
        }
        else if (min_assert_type == 8)
        {
            last_assert_type = normalattack;
            return std::make_pair(min_assert_pos, assert_normal[last_assert_num]);
        }
    }
    if (num_not_assert == 1 && get_enemy_hp(counter_pos) > 0 && is_counter[k])
    {
        bool must_be_counter = true;
        for (int i = 0; i < 4; i++)
        {
            if (get_enemy_id(i) == 1 || get_enemy_id(i) == 2 || get_enemy_id(i) == 11 || get_enemy_id(i) == 12)
                must_be_counter = false;
        }
        if (must_be_counter)
        {
            counter_assert = true;
            last_assert_num = 0;
            return std::make_pair(counter_pos, assert_counter[last_assert_num]);
        }
    }
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    Action action(game);
    srand(time(NULL));
    struct timeb timeSeed;
    ftime(&timeSeed);
    srand(timeSeed.time * 1000 + timeSeed.millitm);
    std::vector<int> my_living_fishes = get_my_living_fishes();
    int enemy_target_prime = -1;
    if ((game.enemy_action.type == infight || game.enemy_action.enemy_expected_injury[0] >= 80) &&
        get_enemy_hp(game.enemy_action.action_fish) > 0)
        enemy_target_prime = game.enemy_action.action_fish;
    if (game.round == 1)
    {
        int my_pos = my_living_fishes[0];
        bool flag_turtle = false, flag_spray = false, flag_hammerhead = false, flag_barracuda = false;
        int min_hp = 500, min_pos = -1;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_turtle = true;
            else if (my_living_fishes[i] == 1)
                flag_spray = true;
            else if (my_living_fishes[i] == 2)
                flag_hammerhead = true;
            else if (my_living_fishes[i] == 3)
                flag_barracuda = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (flag_spray && (min_hp >= 250 || get_skill_used(1) < 3))
            my_pos = 1;
        else
        {
            if (flag_turtle && get_skill_used(0) < 3)
                my_pos = 0;
            else if (flag_barracuda)
                my_pos = 3;
        }
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 1)
        {
            if (get_enemy_living_fishes().size() > 1)
            {
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 7)
        {
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            if (my_living_ally.size() > 0)
            {
                int random_choice = rand() % my_living_ally.size();
                ally_pos = my_living_ally[random_choice];
            }
            int tmp_choice = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            if (get_skill_used(1) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                action.set_enemy_target(enemy_pos);
            }
            else
            {
                action.set_action_type(0);
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 10)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(0);
            action.set_enemy_target(enemy_pos);
        }
        else
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(1);
            action.set_enemy_target(enemy_pos);
        }
    }
    else if (game.round == 2)
    {
        int my_pos = my_living_fishes[0];
        bool flag_whiteshark = false, flag_octopus = false, flag_eel = false, flag_barracuda = false;
        int min_hp = 500, min_pos = -1;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_whiteshark = true;
            else if (my_living_fishes[i] == 1)
                flag_octopus = true;
            else if (my_living_fishes[i] == 2)
                flag_eel = true;
            else if (my_living_fishes[i] == 3)
                flag_barracuda = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (game.enemy_action.type == infight && flag_barracuda)
            my_pos = 3;
        else if (flag_eel && get_skill_used(2) < 3)
            my_pos = 2;
        else if (flag_octopus && ((min_hp <= 250 && min_pos != 1) || min_pos == 1))
            my_pos = 1;
        else if (flag_barracuda)
            my_pos = 3;
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 3)
        {
            if (get_enemy_living_fishes().size() > 1)
            {
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 5)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(1);
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 8)
        {
            int ally_pos = min_pos;
            if (game.my_action.friend_targets[0] == ally_pos && game.enemy_action.enemy_targets[0] != ally_pos) {
                int random_choice = rand() % my_living_fishes.size();
                ally_pos = my_living_fishes[random_choice];
            }
            if (get_my_hp(my_pos) <= 250)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) < 260 || (game.enemy_action.type == subtle &&
                                             get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (get_my_hp(my_pos) < 50 ||
                    (rand() % 2 == 0 && get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
                else
                {
                    std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
                    int tmp_choice = rand() % enemy_living_fishes.size();
                    int enemy_pos = enemy_living_fishes[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_action_type(0);
                    action.set_enemy_target(enemy_pos);
                }
            }
        }
        else if (abs(get_my_id(my_pos)) == 9)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(0);
            action.set_enemy_target(enemy_pos);
        }
    }
    else if (game.round == 3)
    {
        int my_pos = my_living_fishes[0];
        int min_hp = 500, min_pos = -1;
        bool flag_flame = false, flag_clownfish = false, flag_sunfish = false, flag_mobula = false;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_flame = true;
            else if (my_living_fishes[i] == 1)
                flag_clownfish = true;
            else if (my_living_fishes[i] == 2)
                flag_sunfish = true;
            else if (my_living_fishes[i] == 3)
                flag_mobula = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (flag_clownfish && get_skill_used(1) < 3)
            my_pos = 1;
        else if (min_hp <= 280 && flag_mobula)
            my_pos = 3;
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 11)
        {
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            if (my_living_ally.size() > 0)
            {
                int random_choice = rand() % my_living_ally.size();
                ally_pos = my_living_ally[random_choice];
            }
            if (get_skill_used(my_pos) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 2)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(0);
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 4)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(0);
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 6)
        {
            int ally_pos = min_pos;
            if (game.my_action.friend_targets[0] == ally_pos && game.enemy_action.enemy_targets[0] != ally_pos) {
                int random_choice = rand() % my_living_fishes.size();
                ally_pos = my_living_fishes[random_choice];
            }
            if (get_my_hp(my_pos) <= 280)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) < 260 || (game.enemy_action.type == subtle &&
                                             get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (get_my_hp(my_pos) < 50 ||
                    (rand() % 2 == 0 && get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
                else
                {
                    std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
                    int tmp_choice = rand() % enemy_living_fishes.size();
                    int enemy_pos = enemy_living_fishes[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_action_type(0);
                    action.set_enemy_target(enemy_pos);
                }
            }
        }
    }
    return action;
}
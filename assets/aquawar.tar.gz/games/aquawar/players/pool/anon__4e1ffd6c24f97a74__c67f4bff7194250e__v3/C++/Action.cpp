/*
 * bot0 by Tom
 * programs a single-round bot with the following team:
 * round 1 for testing
 * 2. 喷火鱼
 * 3. 电鳗
 * 5. 海狼鱼
 * 8. 章鱼
 */

#include "Action.hpp" // SDK
#include <limits> // numeric_limits

// Store "global variables" using class + namespace
namespace data
{
    struct Round1
    {
        // round3-specific counters
        int clown_count = 0;
        int turtle_count = 0;
        int cycle = 0; // [0, 2]
        const int cycle_max = 5;
        int atk_counter = 3;
        const int atk_max = 3;
        enum fish_positions : int
        {
            atk_pos = 0,
            splash_pos,
            crit_pos,
            defense_pos
        };
        const std::vector<int> priority = {
            defense_action,
            atk_action_friend,
            atk_action_enemy,
            splash_action,
            crit_action
        };
        enum priority_actions : int
        {
            atk_action_friend = 1,
            atk_action_enemy,
            defense_action,
            crit_action,
            splash_action
        };
        class HP_Comp
        {
        public:
            HP_Comp() : game_ptr(nullptr) {}
            bool operator () (int a, int b)
            {
                return game_ptr->my_fish[a].atk > game_ptr->my_fish[b].atk;
            }
            const Game* game_ptr;
        };
        HP_Comp hp_comp;
        bool use_atk_action_friend(Action& action, const Game& game, const std::vector<int>& my_living_ally);
        bool use_atk_action_enemy(Action& action, const Game& game, int lowest_health_enemy);
        bool use_defense_action(Action& action, const Game& game, const std::vector<int>& my_living_ally,
            int lowest_health_enemy);
        bool use_splash_action(Action& action, const Game& game, const std::vector<int>& my_living_ally);
        bool use_crit_action(Action& action, const Game& game, int lowest_health_enemy);
        bool destroy_enemy(Action& action, const Game* const game_ptr, std::vector<int> my_living_fishes,
            int lowest_health_enemy);
        std::vector<int>* build_priority(int fish_action);
    };

    Round1 r1;
}

std::vector<int> AI::Pick(Game game)
{
    data::Round1& current_round = data::r1;
    std::vector<int> team(4);
	if (game.round == 1)
    {
        team[current_round.atk_pos] = flame; // 喷火鱼
        team[current_round.splash_pos] = eel; // 电鳗
        team[current_round.crit_pos] = barracuda; // 海狼鱼
        team[current_round.defense_pos] = octopus; // 章鱼
        return team;
	}
    else if (game.round == 2)
    {
        team[current_round.atk_pos] = sunfish; // 翻车鱼
        team[current_round.splash_pos] = spray; // 射水鱼
        team[current_round.crit_pos] = whiteshark; // 大白鲨
        team[current_round.defense_pos] = mobula; // 蝠鲼
        return team;
    }
    else // game.round == 3
    {
        team[current_round.atk_pos] = hammerhead; // 垂头鲨
        team[current_round.splash_pos] = clownfish; // 小丑鱼
        team[current_round.crit_pos] = imitator + barracuda; // 你太与（海狼鱼）
        team[current_round.defense_pos] = turtle; // 海龟
        return team;
    }
}

std::pair<int, int> AI::Assert(Game game)
{
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    Action action(game);
    int lowest_health_enemy = get_lowest_health_enemy();
    if (game.round == 1)
    {
        data::Round1& current_round = data::r1;
        // 首选使用喷火鱼的技能3次
        if (current_round.atk_counter < current_round.atk_max &&
            current_round.use_atk_action_friend(action, game, get_my_living_fishes()))
        {
            current_round.atk_counter++;
            return action;
        }

        // 试图消灭敌人（根据攻击力排序）
        if (current_round.destroy_enemy(action, &game, get_my_living_fishes(), lowest_health_enemy))
            return action;

        // 开始正常循环
        std::vector<int>* tasks;
        switch (current_round.cycle)
        {
            case 0:
            tasks = current_round.build_priority(current_round.defense_action);
            break;

            case 1:
            tasks = current_round.build_priority(current_round.atk_action_enemy);
            break;

            case 2:
            tasks = current_round.build_priority(current_round.crit_action);
            break;

            case 3:
            tasks = current_round.build_priority(current_round.splash_action);
            break;

            default: // cycle == 4
            tasks = current_round.build_priority(current_round.atk_action_friend);
        }
        current_round.cycle = (current_round.cycle + 1) % current_round.cycle_max;

        for (std::size_t i = 0; i < tasks->size(); ++i)
        {
            bool action_complete = false;
            int t = (*tasks)[i];
            switch (t)
            {
                case current_round.defense_action:
                action_complete = current_round.use_defense_action(action, game,
                    get_my_living_ally(current_round.defense_pos), lowest_health_enemy);
                break;

                case current_round.atk_action_friend:
                action_complete =  current_round.use_atk_action_friend(action, game,
                    get_my_living_ally(current_round.atk_pos));
                break;

                case current_round.atk_action_enemy:
                action_complete = current_round.use_atk_action_enemy(action, game,
                    lowest_health_enemy);
                break;

                case current_round.splash_action:
                action_complete = current_round.use_splash_action(action, game,
                    get_my_living_ally(current_round.splash_pos));
                break;

                default: // crit action:
                action_complete = current_round.use_crit_action(action, game,
                    lowest_health_enemy);
            }
            if (action_complete)
            {
                delete tasks;
                return action;
            }
        }
        // 所有任务检查完，没能完成任何动作，进入下一环节
        delete tasks;
    }

    // 剩余存活鱼基本攻击（正常情况下应该是章鱼）
    action.set_action_fish(get_my_living_fishes()[0]);
    action.set_action_type(0);
    action.set_enemy_target(lowest_health_enemy);
    return action;
}

bool data::Round1::use_atk_action_friend(Action& action, const Game& game, const std::vector<int>& my_living_ally)
{
    if (game.round == 3) // 垂头鲨不能打队友
        return false;
    // 喷火或翻车鱼鱼打队友
    if (game.my_fish[atk_pos].hp > 0)
    {
        for (auto pos : my_living_ally)
        {
            if (game.my_fish[pos].hp > 350)
            {
                action.set_action_fish(atk_pos);
                action.set_action_type(1);
                action.set_friend_target(pos);
                return true;
            }
        }
    }
    return false;
}

bool data::Round1::use_atk_action_enemy(Action& action, const Game& game, int lowest_health_enemy)
{
    if (game.my_fish[atk_pos].hp > 0)
    {
        action.set_action_fish(r1.atk_pos);
        if (game.round == 3)
            action.set_action_type(1);
        else action.set_action_type(0);
        action.set_enemy_target(lowest_health_enemy);
        return true;
    }
    return false;
}

bool data::Round1::use_defense_action(Action& action, const Game& game, const std::vector<int>& my_living_ally,
    int lowest_health_enemy)
{
    // 章鱼保护 - 帮助生命值最低的队友（通过播放器测试，好像队友是可以包括自己的？）
    if (game.my_fish[defense_pos].hp > 0)
    {
        int min_hp = std::numeric_limits<int>::max();
        int min_pos = -1;
        for (auto pos : my_living_ally)
        {
            int current_hp = game.my_fish[pos].hp;
            if (current_hp < min_hp)
            {
                min_hp = current_hp;
                min_pos = pos;
            }
        }
        if (min_pos > 0)
        {
            action.set_action_fish(defense_pos);
            action.set_action_type(1);
            action.set_friend_target(min_pos);
            if (game.round == 3 && turtle_count < 3)
                action.set_enemy_target(lowest_health_enemy);
            ++turtle_count;
            return true;
        }
    }
    return false;
}

bool data::Round1::use_splash_action(Action& action, const Game& game, const std::vector<int>& my_living_ally)
{
    // 电鳗范围溅射伤害
    if (game.my_fish[splash_pos].hp > 0)
    {
        if (game.round == 3)
        {
            int min_hp_ally_pos = -1;
            int min_hp = std::numeric_limits<int>::max();
            for (int i = 0; i < my_living_ally.size(); ++i)
            {
                int ally_pos = my_living_ally[i];
                if (game.my_fish[ally_pos].hp < min_hp)
                {
                    min_hp = game.my_fish[ally_pos].hp;
                    min_hp_ally_pos = ally_pos;
                }
            }
            if (min_hp_ally_pos == -1)
                return false;
            action.set_action_fish(splash_pos);
            action.set_action_type(1);
            action.set_friend_target(min_hp_ally_pos);
            if (clown_count < 3)
                action.set_enemy_target(-2);
            ++clown_count;
        }
        else
        {
            action.set_action_fish(splash_pos);
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }
        return true;
    }
    return false;
}

bool data::Round1::use_crit_action(Action& action, const Game& game, int lowest_health_enemy)
{
    // 海狼鱼暴击
    if (game.my_fish[crit_pos].hp > 0)
    {
        action.set_action_fish(crit_pos);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return true;
    }
    return false;
}

bool data::Round1::destroy_enemy(Action& action, const Game* const game_ptr, std::vector<int> my_living_fishes, int lowest_health_enemy)
{
    hp_comp.game_ptr = game_ptr;
    std::sort(my_living_fishes.begin(), my_living_fishes.end(), r1.hp_comp);
    for (auto pos : my_living_fishes)
    {
        float atk = game_ptr->my_fish[pos].atk;
        bool use_critical = false;
        if (pos == crit_pos)
        {
            atk = 120;
            use_critical = true;
        }
        if (atk > game_ptr->enemy_fish[lowest_health_enemy].hp)
        {
            action.set_action_fish(pos);
            if (use_critical)
                action.set_action_type(1);
            else action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return true;
        }
    }
    return false;
}

std::vector<int>* data::Round1::build_priority(int fish_action)
{
   std::vector<int>* ret = new std::vector<int>();
   ret->reserve(priority.size());
   ret->push_back(fish_action);
   for (auto p : priority)
       if (p != fish_action)
           ret->push_back(p);
    return ret;
}

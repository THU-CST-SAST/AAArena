#include "Action.hpp"
#include <algorithm>
#include <ctime>
#include <cmath>
#include <sys/timeb.h>

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
    pickfish.clear();
    int remain = remain_fishes.size();
    if (remain == 12)
    {
        pickfish.push_back(17);
        pickfish.push_back(6);
        pickfish.push_back(8);
        pickfish.push_back(10);
    }
    else if (remain == 8)
    {
        pickfish.push_back(7);
        pickfish.push_back(11);
        pickfish.push_back(5);
        pickfish.push_back(4);
    }
    else
    {
        pickfish.push_back(1);
        pickfish.push_back(9);
        pickfish.push_back(2);
        pickfish.push_back(3);
    }
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    bool is_round1 = true;
    for (int i = 0; i < 4; i++)
    {
        if (get_my_hp(i) != 400 || get_enemy_hp(i) != 400)
        {
            is_round1 = false;
            break;
        }
    }
    if (!is_round1 && game.my_assert.assertPos != 0 &&
        game.my_assert.assertContent != 12 && !game.my_assert.assertResult)
        return std::make_pair(game.my_assert.assertPos, 12);
    int assert_pos = game.enemy_action.action_fish;
    if (get_enemy_id(assert_pos) != -1)
        return std::make_pair(-1, -1);
    if (game.enemy_action.is_skill)
    {
        if (game.enemy_action.type == aoe)
        {
            for (int i = 0; i < 12; i++)
            {
                if (game.my_action.enemy_passives_id[i] == assert_pos)
                {
                    if (game.my_action.enemy_types[i] == counter)
                    {
                        if (game.my_action.num_enemy_passives == 1)
                            return std::make_pair(assert_pos, 11);
                        else
                        {
                            bool flag = true;
                            for (int j = 0; j < 12; j++)
                            {
                                if (game.my_action.enemy_targets[j] == assert_pos)
                                {
                                    flag = false;
                                    break;
                                }
                            }
                            if (flag)
                            {
                                for (int j = 0; j < 12; j++)
                                {
                                    if (game.my_action.enemy_passives_id[j] != assert_pos
                                        && game.my_action.enemy_types[j] == counter)
                                        return std::make_pair(game.my_action.enemy_passives_id[j], 1);
                                }
                            }
                        }
                    }
                }
            }
        }
        else if (game.enemy_action.type == crit)
        {
            if (game.enemy_action.enemy_expected_injury[0] == 138 || game.enemy_action.enemy_expected_injury[0] == 161)
                return std::make_pair(assert_pos, 10);
            else if (game.enemy_action.enemy_expected_injury[0] == 140)
            {
                if (get_enemy_hp(assert_pos) <= 80)
                    return std::make_pair(assert_pos, 9);
                else
                {
                    bool flag = false;
                    for (int i = 0; i < 12; i++)
                    {
                        if (game.my_action.enemy_targets[i] == assert_pos)
                        {
                            flag = true;
                            break;
                        }
                    }
                    if (flag)
                    {
                        bool flag_hammerhead = true;
                        for (int i = 0; i < 12; i++)
                        {
                            if (game.my_action.enemy_passives_id[i] == assert_pos)
                                flag_hammerhead = false;
                        }
                        if (flag_hammerhead)
                            return std::make_pair(assert_pos, 10);
                    }
                }
            }
        }
    }
    else
    {
        if (game.enemy_action.enemy_expected_injury[0] >= 70)
        {
            int expected_injury = game.enemy_action.enemy_expected_injury[0];
            if (expected_injury % 10 != 5 && expected_injury != 120 && expected_injury != 130
                && expected_injury != 190 && expected_injury != 200 && expected_injury <= 240)
            {
                bool flag = false;
                for (int i = 0; i < 12; i++)
                {
                    if (game.my_action.enemy_targets[i] == assert_pos)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag)
                {
                    bool flag_octopus = false;
                    for (int i = 0; i < 12; i++)
                    {
                        if (game.my_action.enemy_passives_id[i] == assert_pos &&
                            game.my_action.enemy_types[i] == heal)
                        {
                            flag_octopus = true;
                            break;
                        }
                    }
                    if (!flag_octopus)
                        return std::make_pair(assert_pos, 6);
                    else
                        return std::make_pair(assert_pos, 8);
                }
            }
            else
            {
                if (expected_injury == 95 || expected_injury == 165 ||
                     expected_injury == 235 || expected_injury == 270)
                    return std::make_pair(assert_pos, 4);
                for (int i = 0; i < 12; i++)
                {
                    if (game.my_action.enemy_passives_id[i] == assert_pos)
                    {
                        if (game.my_action.enemy_types[i] == counter)
                            return std::make_pair(assert_pos, 2);
                    }
                }
            }
        }
    }
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    srand(time(NULL));
    struct timeb timeSeed;
    ftime(&timeSeed);
    srand(timeSeed.time * 1000 + timeSeed.millitm);
    std::vector<int> my_living_fishes = get_my_living_fishes();
    int enemy_target_prime = -1;
    if (game.enemy_action.type == infight)
        enemy_target_prime = game.enemy_action.action_fish;
    if (game.round == 1)
    {
        int rand_num = rand() % my_living_fishes.size();
        int my_pos = my_living_fishes[rand_num];
        bool flag_barracuda = false, flag_mobula = false, flag_octopus = false, flag_hammerhead = false;
        int min_hp = 500;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_barracuda = true;
            else if (my_living_fishes[i] == 1)
            {
                flag_mobula = true;
                if (get_my_hp(my_living_fishes[i]) < min_hp)
                    min_hp = get_my_hp(my_living_fishes[i]);
            }
            else if (my_living_fishes[i] == 2)
            {
                flag_octopus = true;
                if (get_my_hp(my_living_fishes[i]) < min_hp)
                    min_hp = get_my_hp(my_living_fishes[i]);
            }
            else if (my_living_fishes[i] == 3)
                flag_hammerhead = true;
        }
        if (min_hp > 260)
        {
            if (flag_hammerhead && flag_barracuda)
            {
                if (get_my_hp(0) <= get_my_hp(3))
                    my_pos = 0;
                else
                    my_pos = 3;
            }
            else if (flag_barracuda && !flag_hammerhead)
                my_pos = 0;
            else if (flag_hammerhead && !flag_barracuda)
                my_pos = 3;
            else
            {
                if (flag_octopus && flag_mobula)
                {
                    if (get_my_hp(1) <= get_my_hp(2))
                        my_pos = 2;
                    else
                        my_pos = 1;
                }
                else
                    my_pos = flag_mobula ? 1 : 2;
            }
        }
        else
        {
            if (flag_octopus && flag_mobula)
            {
                if (get_my_hp(1) <= get_my_hp(2))
                    my_pos = 2;
                else
                    my_pos = 1;
            }
            else if (flag_octopus || flag_mobula)
                my_pos = flag_mobula ? 1 : 2;
        }
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 10)
        {
            action.set_action_type(1);
            int tmp_choice = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 8)
        {
            int min_hp = 400;
            int ally_pos = -1;
            for (int i = 0; i < my_living_fishes.size(); i++)
            {
                if (get_my_hp(my_living_fishes[i]) <= min_hp)
                {
                    min_hp = get_my_hp(my_living_fishes[i]);
                    ally_pos = my_living_fishes[i];
                }
            }
            if (get_my_hp(my_pos) <= 200)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) <= 240 && get_my_hp(my_pos) >= 180)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (rand() % 2 == 0)
                {
                    action.set_action_type(0);
                    int tmp_choice = rand() % (get_lowest_health_enemies().size());
                    int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_enemy_target(enemy_pos);
                }
                else
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
            }
        }
        else if (abs(get_my_id(my_pos)) == 6)
        {
            int min_hp = 400;
            int ally_pos = -1;
            for (int i = 0; i < my_living_fishes.size(); i++)
            {
                if (get_my_hp(my_living_fishes[i]) <= min_hp)
                {
                    min_hp = get_my_hp(my_living_fishes[i]);
                    ally_pos = my_living_fishes[i];
                }
            }
            if (get_my_hp(my_pos) <= 200)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) <= 240 && get_my_hp(my_pos) >= 180)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (rand() % 2 == 0)
                {
                    action.set_action_type(0);
                    int tmp_choice = rand() % (get_lowest_health_enemies().size());
                    int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_enemy_target(enemy_pos);
                }
                else
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
            }
        }
        else
        {
            action.set_action_type(1);
            int tmp_num = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_num];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_enemy_target(enemy_pos);
        }
    }
    else if (game.round == 2)
    {
        int rand_num = rand() % my_living_fishes.size();
        int my_pos = my_living_fishes[rand_num];
        bool flag_barracuda = false, flag_sunfish = false;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 2)
                flag_barracuda = true;
            else if (my_living_fishes[i] == 3)
                flag_sunfish = true;
        }
        if (flag_sunfish && flag_barracuda)
            my_pos = rand() % 2 == 0 ? 2 : 3;
        else if (flag_sunfish || flag_barracuda)
            my_pos = flag_sunfish ? 3 : 2;
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 4)
        {
            int ally_pos = -1;
            for (int i = 0; i < my_living_fishes.size(); i++)
            {
                if (abs(get_my_id(my_living_fishes[i])) == 7)
                {
                    ally_pos = my_living_fishes[i];
                    break;
                }
                else if (abs(get_my_id(my_living_fishes[i])) == 5)
                    ally_pos = my_living_fishes[i];
            }
            if (ally_pos != -1 && get_skill_used(my_pos) < 4 && get_my_hp(my_pos) >= 200)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                action.set_action_type(0);
                int tmp_num = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_num];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 5)
        {
            action.set_action_type(1);
            int tmp_num = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_num];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 11)
        {
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            int ally_pos = -1, min_hp = 400;
            for (int i = 0; i < my_living_ally.size(); i++)
            {
                if (get_my_hp(my_living_ally[i]) <= min_hp)
                {
                    min_hp = get_my_hp(my_living_ally[i]);
                    ally_pos = my_living_ally[i];
                }
            }
            if (get_skill_used(my_pos) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                action.set_friend_target(ally_pos);
                int tmp_num = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_num];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 7)
        {
            int min_hp = 400;
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            for (int i = 0; i < my_living_ally.size(); i++)
            {
                if (get_my_hp(my_living_ally[i]) <= min_hp)
                {
                    min_hp = get_my_hp(my_living_ally[i]);
                    ally_pos = my_living_ally[i];
                }
            }
            if (get_skill_used(my_pos) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                int tmp_choice = rand() % get_lowest_health_enemies().size();
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
            else
            {
                if ((rand() % 5 <= 2) && ally_pos != -1)
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
                else
                {
                    action.set_action_type(0);
                    int tmp_choice = rand() % get_lowest_health_enemies().size();
                    int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_enemy_target(enemy_pos);
                }
            }
        }
    }
    else if (game.round == 3)
    {
        int tmp_num = rand() % my_living_fishes.size();
        int my_pos = my_living_fishes[tmp_num];
        bool flag_flame = false, flag_whiteshark = false, flag_eel = false, flag_spray = false;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_spray = true;
            else if (my_living_fishes[i] == 1)
                flag_whiteshark = true;
            else if (my_living_fishes[i] == 2)
                flag_flame = true;
            else if (my_living_fishes[i] == 3)
                flag_eel = true;
        }
        if (flag_spray && flag_eel)
            my_pos = rand() % 2 == 0 ? 0 : 3;
        else if (flag_spray || flag_eel)
            my_pos = flag_spray ? 0 : 3;
        else
        {
            if (flag_whiteshark && flag_flame)
                my_pos = rand() % 2 == 0 ? 1 : 2;
            else if (flag_whiteshark || flag_flame)
                my_pos = flag_flame ? 2 : 1;
        }
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 9)
        {
            action.set_action_type(1);
            int tmp_choice = rand() % get_lowest_health_enemies().size();
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 2)
        {
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            int ally_pos = -1, max_hp = 0;
            for (int i = 0; i < my_living_ally.size(); i++)
            {
                if (get_my_hp(my_living_ally[i]) > max_hp)
                {
                    max_hp = get_my_hp(my_living_ally[i]);
                    ally_pos = my_living_ally[i];
                }
            }
            if (get_skill_used(my_pos) < 4 && ally_pos != -1 && get_my_hp(my_pos) >= 250)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % get_lowest_health_enemies().size();
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 1)
        {
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }
        else if (abs(get_my_id(my_pos)) == 3)
        {
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }
    }
    return action;
}
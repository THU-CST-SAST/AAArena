#include "Action.hpp"
#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <queue>

#define wait1 6
#define dying 400

using namespace std;

int last_target;
int times = 0;
int times1 = 0;
int times2 = 0;
int turtletime = 0;
bool shouge;
bool effect;
bool defense;
bool has_protect[4];
bool has_protect1[4];
bool safe;
bool danger;
bool safe1;
bool danger1;


const int fish_table[][2] = {
    {0,0},
    {aoe,counter},
    {infight,counter},
    {aoe,deflect},
    {infight,deflect},
    {crit,reduce},
    {subtle,reduce},
    {crit,reduce},
    {subtle,heal},
    {crit,heal},
    {crit,explode},
    {aoe,counter},
    {0,0}
};
//

//
bool asserted[13];
bool counter_found = 0;
int ally[4];


struct Fish_data {

    int pos;

    int active = -1;
    int action_count = 0;//if action count>3 and it does not use active, it's active might be subtle
    int inaction_count = 0;
    bool need_spj = false;
    int passive = -1;
    bool passive_changed = false;

    bool tried[13] = { 1,0,0,0,0,0,0,0,0,0,0,0,0 };
    bool revealed = false;
    int identity = 0;
    int ava_identity = 0;

    int attacked_count = 0;
    int active_count = 0;
    int escape_count = 0;
    bool haigui = false;
    int direct_tiggled = -1;

    std::set<int> passive_histoy;
    std::set<int> fake_passive;

    //上一次主动攻击最大伤害
    int last_hurt = 0;


    void update_active(Game game)
    {
        //refresh last assert info
        if (game.my_assert.assertContent != 0)
        {


            if (game.my_assert.assertPos == pos)
            {
            std::cerr << endl << game.my_assert.assertPos << "is" << game.my_assert.assertContent;
            if (game.my_assert.assertResult)
                std::cerr << ",TRUE";
            else
                std::cerr << ",FALSE";

                if (game.my_assert.assertResult == true)
                {
                    identity = game.my_assert.assertContent;
                    revealed = true;
                    asserted[identity] = true;
                    if (active == -1&&identity!=12)
                        active = fish_table[0][identity];
                    else if (active == -1 && identity == 12)
                    {
                        active = fish_table[0][ava_identity];
                    }

                    if (passive == -1 && identity != 12)
                        passive = fish_table[1][identity];
                    else if (passive == -1 && identity == 12)
                    {
                        passive = fish_table[1][ava_identity];
                    }


                    return;
                }
                else
                {
                    ava_identity = game.my_assert.assertContent;
                    tried[game.my_assert.assertContent] = true;
                }

            }
        }
        //refresh enemy active skill
        if (game.enemy_action.action_fish == pos)
        {
            action_count++;
            if (game.enemy_action.is_skill)
            {
                inaction_count = 0;
                if (active == -1)
                    active = game.enemy_action.type;
                else if (game.enemy_action.type != active)
                    //need_spj = true;
                    ;

                active_count++;
            }
            else
            {
                inaction_count++;
            }
            //TODO does "friend" in "enemy_action" refere to myself?
            //refresh enemy atk
            last_hurt = 0;
            std::array<int, 12> atk = game.enemy_action.enemy_excepted_injury;
            if (game.enemy_action.action_fish == pos)
                for (int i = 0; i < 4; i++)
                {
                    if (last_hurt < atk[i])
                        last_hurt = atk[i];
                    //TODO: atk count still not correct
                    /*
                    int delta = ally[i] - game.my_fish[i].hp;
                    if (game.my_assert.assertResult == false)
                        last_hurt = (last_hurt > delta-50) ? last_hurt : delta-50;
                    else
                        last_hurt = (last_hurt > delta) ? last_hurt : delta;*/

                }

        }
        else
        {
            inaction_count++;
        }



    }
    void debug()
    {
        std::cerr << pos << ">>>";
        if (active == aoe)
            std::cerr << "aoe  ";
        if (active == crit)
            std::cerr << "crit ";
        if (active == infight)
            std::cerr << "infi ";
        if (active == subtle)
            std::cerr << "sub  ";

        if (passive == heal)
            std::cerr << "heal ";
        if (passive == counter)
            std::cerr << "coun ";
        if (passive == reduce)
            std::cerr << "redu ";
        if (passive == deflect)
            std::cerr << "defl ";
        if (passive == explode)
            std::cerr << "expl ";


        std::cerr << endl << " a.c:" << attacked_count << "  e.c:" << escape_count << " hg:" << haigui << endl;
    }
    //reset data each round
    void reset()
    {
        active = -1;
        need_spj = false;
        passive = -1;

        memset(tried, 0, sizeof(tried));
        tried[0] = true;
        revealed = false;

        active_count = 0;
        escape_count = 0;
        attacked_count = 0;
        haigui = false;
        direct_tiggled = -1;

        ava_identity = 0;


        last_hurt = 0;

        action_count = 0;
        inaction_count = 0;

        passive_histoy.clear();
        fake_passive.clear();
    }

};


Fish_data enemy[4];
int last_hp[4];
int now_hp[4];

std::vector<int> AI::Pick(Game game)
{
    if (game.round == 1) {
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(2);
        pickfish.push_back(4);
        pickfish.push_back(1);
        pickfish.push_back(8);
        return pickfish;
    }
    if (game.round == 2) {
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(6);
        pickfish.push_back(11);
        pickfish.push_back(7);
        pickfish.push_back(10);
        return pickfish;
    }
    std::vector<int> pickfish;
    pickfish.clear();
    pickfish.push_back(3);
    pickfish.push_back(17);
    pickfish.push_back(9);
    pickfish.push_back(5);
    return pickfish;
}
// <assert_block>
void debug_in(int line)
{
    std::cerr << endl << ">> >> >>running: " << line << endl;
}
void debug_out()
{
    std::cerr << ">> >> >>this line didn't return" << endl;
}

bool ridiculous(Fish_data fish, int suspect_passive)
{
    if (suspect_passive == -1||fish.active==-1)
        return false;


    int id = fish.pos;
    if (fish.fake_passive.find(suspect_passive) != fish.fake_passive.end())
        {return true;}

    if (suspect_passive == heal)
    {
        if (fish.active == aoe || fish.active == infight)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    if (suspect_passive == deflect)
    {
        if (fish.active == crit || fish.active == subtle)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    if (suspect_passive == counter)
    {
        if (fish.active == crit || fish.active == subtle)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    if (suspect_passive == counter)
    {
        if (fish.active != aoe && fish.active != -1)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    if (suspect_passive == counter)
    {
        if (fish.active == crit || fish.active == subtle)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    if (suspect_passive == counter)
    {
        if (fish.active != crit && fish.active != -1)
            {enemy[id].fake_passive.insert(suspect_passive); return true;}
    }
    return false;
}
// <assert_block>


int Round = 0;
int action_time = 0;
void debug()
{
    action_time++; std::cerr << "-----------" << Round << "," << action_time << "-------------" << endl;
    std::cerr << "l.t>" << last_target << endl;
    for (int i = 0; i < 4; i++)
    {
        enemy[i].debug();
    }
}
Fish_data fish;
bool single_possible(int id)
{
    if (fish.tried[id] == false && asserted[id] == false)
        return true;

    return false;
}
//TODO: add if(mult_possible) to every mult_assert
bool mult_possible(int* id)
{
    int i = 0;
    while (id[i])
    {
        if (fish.tried[id[i]] == false && asserted[id[i]] == false)
            return true;

        i++;
    }
    return false;
}
std::pair<int, int> single_assert(int id)
{
    if (fish.tried[id] == false && asserted[id] == false)
        return make_pair(fish.pos, id);
}

std::pair<int, int> mult_assert(int* id)
{
    int i = 0;
    while (id[i])
    {
        if (fish.tried[id[i]] == false && asserted[id[i]] == false)
            return make_pair(fish.pos, id[i]);

        i++;
    }
    return make_pair(-1, -1);
}
std::pair<int, int> try_avatar()
{
    int p[] = { 12,0 };
    if (mult_possible(p))
        return mult_assert(p);
}

bool is_first_mover = false;
bool no_doubt = false;
std::pair<int, int> AI::Assert(Game game)
{
    
    //see if this is first move of a new round.if so,reset enemy info
    if (game.round != Round)
    {
        //is_first_move = true;
        is_first_mover = get_first_mover() ? true : false;
        no_doubt = false;
        action_time = 0;
        Round = game.round;
        counter_found = false;
        for (int i = 0; i <= 3; i++)
        {
            enemy[i].reset();
            last_hp[i] = get_enemy_hp(i);
        }

        return make_pair(-1, -1);
    }

    //update enemy info first
    //////////////////////////////////////////////////////////////////////////////////////////
    if (last_target == -2)
    {
        for (int i = 0; i < 4; i++)
        {
            enemy[i].attacked_count++;
        }
    }
    else if (last_target != -3)//friend
    {
        enemy[last_target].attacked_count++;

        if (last_target >= 0)
            enemy[last_target].direct_tiggled = true;
        else
            enemy[last_target].direct_tiggled = false;
    }

    //////////////////////////////////////////////////////////////////////////////////////////

    for (int i = 0; i < 4; i++)
    {
        now_hp[i] = get_enemy_hp(i);
        enemy[i].update_active(game);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    int p_num = game.my_action.num_enemy_passives;
    std::array<int, 24> p_id = game.my_action.enemy_passives_id;
    std::array<passive_type, 24> p_type = game.my_action.enemy_types;
    bool passive_acted = false;
    
    std::cerr << endl << "____________________" << endl;
    for (int i = 0; i < p_num; i++)
    {
        std::cerr << p_id[i] << ' ' ;
    }
    std::cerr << endl;
    for (int i = 0; i < p_num; i++)
    {
        std::cerr << p_type[i] << ' ' ;
    }

    std::cerr << endl << "____________________" << endl;

    for (int i = 0; i < 4; i++)
    if (ridiculous(enemy[i], enemy[i].passive))
    {
        enemy[i].fake_passive.insert(enemy[i].passive);

        enemy[i].passive_histoy.erase(enemy[i].passive);
        //return make_pair(-1, -1);

        if (!ridiculous(enemy[i], reduce) && enemy[i].passive_histoy.find(reduce) != enemy[i].passive_histoy.end())
        {
            enemy[i].passive = reduce;
            std::cerr << "<><><>changed to reduce" << endl;
        }
        else if (!ridiculous(enemy[i], deflect) && enemy[i].passive_histoy.find(deflect) != enemy[i].passive_histoy.end())
        {
            enemy[i].passive = deflect;
            std::cerr << "<><><>changed to deflect" << endl;
        }
        else if (!ridiculous(enemy[i], heal) && enemy[i].passive_histoy.find(heal) != enemy[i].passive_histoy.end())
        {
            enemy[i].passive = heal;
            std::cerr << "<><><>changed to heal" << endl;
        }
        else {
            enemy[i].passive = -1;
            std::cerr << "<><><>changed to -1" << endl;
        }
    }

    if (is_first_mover&&!no_doubt)
    {
        no_doubt = true;
        for (int i = 0; i < p_num; i++)
        {
            int id = p_id[i];
            enemy[id].passive = p_type[i];
            enemy[id].passive_histoy.insert(p_type[i]);

            if (p_type[i] == reduce)
            {
                //if(last_hp[i]==get_enemy_hp(id))
                enemy[id].escape_count++;
            }
        }
    }
    else
    {
        for (int i = 0; i < p_num; i++)
        {

            int id = p_id[i];
            passive_acted = true;


            if (enemy[id].passive != p_type[i] && no_doubt)
                goto again;

            if(fish.active==-1)


            if (enemy[id].passive == -1)
            {
                //avoid zhangyu and xiaochou mess up info
                if (p_type[i] == heal)
                {
                    if ((fish.passive)!=p_type[i]&&enemy[id].attacked_count > 1)
                    {
                        enemy[id].fake_passive.insert(p_type[i]);

                    }
                    else if (game.enemy_action.type != subtle && !ridiculous(enemy[id], heal))
                    {
                        enemy[id].passive = p_type[i];
                        enemy[id].passive_histoy.insert(p_type[i]);
                    }

                }

                if(p_type[i]==deflect)
                    if ((fish.passive)!=p_type[i]&&enemy[id].attacked_count > 1)
                    {
                        enemy[id].fake_passive.insert(p_type[i]);

                    }
                else if (!ridiculous(enemy[id], p_type[i]) && !no_doubt)
                {
                    enemy[id].passive = p_type[i];
                    enemy[id].passive_histoy.insert(p_type[i]);
                }
            }
            if (p_type[i] != enemy[id].passive && !no_doubt)
            {
                if (enemy[id].passive == heal && p_type[i] != counter && !ridiculous(enemy[id], p_type[i]))
                {
                    enemy[id].passive_histoy.insert(p_type[i]);
                    enemy[id].passive = p_type[i];
                }
            }
            if (p_type[i] == deflect)
            {
                for (int j = 0; j < 4; j++)
                    enemy[j].attacked_count++;
            }
            again:
            //send message to outside
            if (p_type[i] == reduce)
            {
                if(!ridiculous(fish,reduce))
                enemy[id].passive = reduce;
                //if(last_hp[i]==get_enemy_hp(id))
                enemy[id].escape_count++;
            }
            if (enemy[id].attacked_count == 3)
            {
                if (enemy[id].escape_count >= 3)
                    enemy[id].haigui = true;
            }

            if (p_type[i] == counter)
            {
                counter_found = true;//counter shall be marked on the low hp enemy
                 //not the fish with counter passive
            }

            //refresh if enemy was attacked and if it was direct attacked
        }

    }

    memcpy(last_hp, now_hp, sizeof(last_hp));
    //////////////////////////////////////////////////////////////////////////////////////////


    debug();
    //return make_pair(-1, -1);
    //see if we can assert one fish

    //by active
    for (int i = 0; i < 4; i++)
    {
        if (enemy[i].revealed == false && game.enemy_fish[i].hp > 0)
        {
            fish = enemy[i];
            // judge from aoe
            if (fish.active == aoe)
            {
                //xiaochou change active type
                if (fish.need_spj)
                {
                    int p[] = { 11,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(1);
                        return mult_assert(p);
                        debug_out();
                    }
                }
                //dianman deflect
                if (fish.passive == deflect)
                {
                    int p[] = { 3,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(2);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                if (fish.passive == -1 || fish.passive == heal)
                {
                    if (fish.attacked_count > 0)
                    {
                        int p[] = { 1,11,12,0 };
                        if (mult_possible(p))
                        {
                            debug_in(3);
                            return mult_assert(p);
                            debug_out();
                        }
                    }
                }

                //sheshui counter for all while xiaochou counter only for itself
                for (int j = 0; j < 4; j++)
                {
                    if (game.enemy_fish[j].hp < 120 && enemy[j].direct_tiggled == true)
                    {
                        if (fish.passive == counter)
                        {
                            int p[] = { 1,12,0 };
                            if (mult_possible(p))
                            {
                                debug_in(4);
                                return mult_assert(p);
                                debug_out();
                            }

                            if (fish.pos == j && (asserted[1] || fish.tried[1]) && single_possible(11))
                            {
                                debug_in(5);
                                return single_assert(11);
                                debug_out();
                            }

                        }
                    }
                }
                if (single_possible(12) && fish.tried[1] == true && fish.tried[11] == true)
                    return try_avatar();
                //pai chu fa
                if (asserted[1] && asserted[11])
                {
                    int p[] = { 3,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(6);
                        return mult_assert(p);
                        debug_out();
                    }
                }
                if (asserted[3] && asserted[11])
                {
                    int p[] = { 1,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(7);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                if (asserted[1] && asserted[3])
                {
                    int p[] = { 11,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(8);
                        return mult_assert(p);
                        debug_out();
                    }
                }
            }

            else if (fish.active == crit)
            {
                //haigui is the only crit unit that may change skill type
                if (fish.need_spj)
                {
                    if (single_possible(7))
                        fish.haigui = true;

                    int p[] = { 7,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(9);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                if (fish.passive == heal)
                {
                    int p[] = { 9,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(10);
                        return mult_assert(p);
                        debug_out();
                    }
                }
                //only shark have 140atk crit
                if (fish.last_hurt == 140)
                {
                    int p[] = { 10,9,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(11);
                        return mult_assert(p);
                        debug_out();
                    }
                }
                //only chuitou have atk enhance passive

                if ((fish.last_hurt == 138 || fish.last_hurt == 172) && game.enemy_fish[i].skill_used == true)
                {
                    int p[] = { 10,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(12);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                //TODO :must be something wrong with haigui
                if (fish.attacked_count == 3)
                {
                    if (fish.escape_count >= 3)
                    {
                        if (single_possible(7))
                            fish.haigui = true;
                    }
                }
                if (fish.attacked_count >= 3)
                {
                    //escaped but not always.
                    if (fish.haigui)
                    {
                        int p[] = { 7,12,5,0 };
                        if (mult_possible(p))
                        {
                            debug_in(13);
                            return mult_assert(p);
                            debug_out();
                        }
                    }
                    if (fish.escape_count > 0 && fish.escape_count < fish.attacked_count)
                    {
                        int p[] = { 5,12,0 };
                        if (mult_possible(p))
                        {
                            debug_in(14);
                            return mult_assert(p);
                            debug_out();
                        }
                    }
                    //never escaped, chuitou>hailang
                    else if (fish.escape_count == 0)
                    {
                        int p[] = { 10,5,0 };
                        if (mult_possible(p))
                        {
                            debug_in(15);
                            return mult_assert(p);
                            debug_out();
                        }
                    }
                    else if (fish.escape_count == fish.attacked_count)
                    {
                        int p[] = { 5,0 };
                        if (mult_possible(p))
                        {
                            debug_in(16);
                            return mult_assert(p);
                            debug_out();
                        }

                        if (single_possible(12) && fish.tried[7])
                            return try_avatar();
                    }
                }

                if (asserted[5] && asserted[9] && asserted[10])
                {
                    int p[] = { 7,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(17);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                if (asserted[5] && asserted[7] && asserted[10])
                    if (single_possible(9))
                    {
                        debug_in(18);
                        return single_assert(9);
                        debug_out();
                    }
                if (asserted[7] && asserted[9] && asserted[10])
                {
                    if (single_possible(5))
                    {
                        debug_in(19);
                        return single_assert(5);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }
                if (asserted[5] && asserted[9] && asserted[7] && asserted[12])
                    if (single_possible(10))
                    {
                        debug_in(20);
                        return single_assert(10);
                        debug_out();
                    }
            }

            else if (fish.active == infight)
            {
                //only fanche has deflect among infight
                if (fish.passive == deflect)
                {
                    if (single_possible(4))
                    {
                        debug_in(21);
                        return single_assert(4);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }
                //only penhuo have counter\directly attacked but no respond,penhuo
                if ((fish.passive == counter) || (fish.direct_tiggled && fish.passive != deflect) || (asserted[4]))
                {
                    if (single_possible(2))
                    {
                        debug_in(22);
                        return single_assert(2);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }
                if (asserted[2])
                {
                    if (single_possible(4))
                    {
                        debug_in(23);
                        return single_assert(4);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }
            }

            else if (fish.active == subtle )
            {
                //judging from if it change active skill

                if (fish.passive != heal)
                {
                    if (single_possible(6))
                    {
                        debug_in(24);
                        return single_assert(6);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }

                if (fish.passive == heal)
                {
                    if (single_possible(8))
                    {
                        debug_in(25);
                        return single_assert(8);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }

                if (asserted[8])
                {
                    if (single_possible(6))
                    {
                        debug_in(26);
                        return single_assert(6);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }

                if (asserted[6])
                {
                    if (single_possible(8))
                    {
                        debug_in(27);
                        return single_assert(8);
                        debug_out();
                    }
                    if (single_possible(12))
                        return try_avatar();
                }

            }
        }

        if (enemy[i].passive == explode)
        {
            asserted[10] = true;
        }
    }

    //by passive

    for (int i = 0; i < 4; i++)
    {
        fish = enemy[i];
        if (enemy[i].revealed == false && game.enemy_fish[i].hp > 0)
        {
            Fish_data fish = enemy[i];
            if (fish.passive == -1 && fish.inaction_count >= wait1)
            {
                if (fish.active == crit)
                {
                    int p[] = { 10,12,0 };
                    if (mult_possible(p))
                    {
                        debug_in(271);
                        return mult_assert(p);
                        debug_out();
                    }
                }

                //less often used fish is penhuo
                //if(Round!=1)
                if (fish.inaction_count >= wait1&&game.enemy_fish[fish.pos].hp<200)
                {
                    int p[] = { 2,0 };
                    if (mult_possible(p))
                    {
                        debug_in(28);
                        return mult_assert(p);
                        debug_out();
                    }
                }
                if (asserted[1] && asserted[11])
                {
                    if (!(fish.active != -1 && fish.active != infight))
                        if (single_possible(2))
                        {
                            debug_in(29);
                            return single_assert(2);
                            debug_out();
                        }
                }

                if (asserted[1] && asserted[2])
                {
                    if (fish.active != crit&& single_possible(11))
                        if (single_possible(11))
                        {
                            debug_in(30);
                            return single_assert(11);
                            debug_out();
                        }

                }
                if (asserted[2] && asserted[11])
                {
                    if (single_possible(1))
                        if (!(fish.active != -1 && fish.active != aoe))
                        {
                            debug_in(31);
                            return single_assert(1);
                            debug_out();
                        }

                }
                if (asserted[1] && asserted[11] && asserted[2])
                {
                    if (single_possible(12))
                    {
                        debug_in(32);
                        return single_assert(12);
                        debug_out();
                    }

                }
            }
            if (fish.passive == deflect)
            {
                //less often used fish is fanche
                if (fish.inaction_count >= wait1 && game.enemy_fish[fish.pos].hp < dying)
                {
                    if (single_possible(4))
                    {
                        debug_in(33);
                        return single_assert(4);
                        debug_out();
                    }
                }
                if (asserted[3])
                {
                    if (single_possible(4) && !(fish.active != -1 && fish.active != infight))
                    {
                        debug_in(34);
                        return single_assert(4);
                        debug_out();
                    }

                }
                if (asserted[4])
                {
                    if (single_possible(3) && !(fish.active != -1 && fish.active != aoe))
                    {
                        debug_in(35);
                        return single_assert(3);
                        debug_out();
                    }

                    if (single_possible(11) && !(fish.active != -1 && fish.active != aoe))
                    {
                        debug_in(36);
                        return single_assert(11);
                        debug_out();
                    }

                }
                if (asserted[3] && asserted[4])
                {
                    if (single_possible(12))
                    {
                        debug_in(37);
                        return single_assert(12);
                        debug_out();
                    }

                }
            }

            if (fish.passive == reduce)
            {
                if (fish.inaction_count >= wait1 && game.enemy_fish[fish.pos].hp < dying)
                {
                    if (fish.attacked_count == 3 && fish.escape_count >= 3||fish.haigui)
                    {
                        if (single_possible(7))
                        {
                        debug_in(381);
                        return single_assert(7);
                        debug_out();
                        }
                    }
                }
                

                //less often used fish is fufen
                if (fish.inaction_count >= wait1 && game.enemy_fish[fish.pos].hp < dying&&!fish.haigui)
                {
                    if (single_possible(6))
                    {
                        debug_in(38);
                        return single_assert(6);
                        debug_out();
                    }
                }

                if (asserted[7] && fish.inaction_count >= wait1 && game.enemy_fish[fish.pos].hp < dying)
                {
                    if (single_possible(6))
                    {
                        debug_in(38);
                        return single_assert(6);
                        debug_out();
                    }
                }

                if (asserted[5] && asserted[6])
                {
                    if (single_possible(7) && !(fish.active != -1 && fish.active != crit))
                    {
                        debug_in(39);
                        return single_assert(7);
                        debug_out();
                    }

                }
                if (asserted[5] && asserted[7])
                {
                    if (single_possible(6) && !(fish.active != -1 && fish.active != subtle))
                    {
                        debug_in(40);
                        return single_assert(6);
                        debug_out();
                    }

                }
                if (asserted[6] && asserted[7])
                {
                    if (single_possible(5) && !(fish.active != -1 && fish.active != crit))
                    {
                        int p[] = { 5,12,0 };
                        if(mult_possible(p))
                        {
                            debug_in(41);
                            return mult_assert(p);
                        }
                        debug_out();
                    }
                }
                if (asserted[5] && asserted[6] && asserted[7])
                {
                    if (single_possible(12))
                    {
                        debug_in(42);
                        return single_assert(12);
                        debug_out();
                    }
                }
            }

            if (fish.passive == heal)
            {
                if (fish.inaction_count >= wait1 && game.enemy_fish[fish.pos].hp < dying)
                {
                    int p[] = { 8,9,12,0 };
                    if(mult_possible(p))
                    {
                        debug_in(421);
                        return single_assert(8);
                    }
                    debug_out();
                }
                if (asserted[8])
                {
                    if (single_possible(9) && !(fish.active != -1 && fish.active != crit))
                    {
                        debug_in(43);
                        return single_assert(9);
                        debug_out();
                    }
                }
                if (asserted[9])
                {
                    if (single_possible(8) && !(fish.active != -1 && fish.active != subtle))
                    {
                        debug_in(44);
                        return single_assert(8);
                        debug_out();
                    }
                }
                if (asserted[9] && asserted[8])
                {
                    if (single_possible(12))
                    {
                        debug_in(45);
                        return single_assert(12);
                        debug_out();
                    }
                }
            }
        }

        if (enemy[i].passive == explode)
        {
            if (asserted[12])
                asserted[10] = true;
        }
    }

    for (int i = 0; i < 4; i++)
    {
        ally[i] = game.my_fish[i].hp;
    }

    return make_pair(-1, -1);

}



Action normal_(int attacker, int friend_target, int enemy_target, Game game) {
    Action action(game);
    action.set_action_fish(attacker);
    action.set_action_type(0);
    if (friend_target != -1) {
        action.set_friend_target(friend_target);
        last_target = -3;
    }
    if (enemy_target != -1) {
        action.set_enemy_target(enemy_target);
        last_target = enemy_target;
    }
    return action;
}

Action aoe_(int attacker, int friend_target, int enemy_target, Game game) {
    Action action(game);
    action.set_action_fish(attacker);
    action.set_action_type(1);
    if (friend_target != -1) {
        action.set_friend_target(friend_target);
        last_target = -3;
    }
    if (enemy_target != -1) {
        action.set_enemy_target(-2);
        last_target = -2;
    }
    return action;
}

Action infight_(int attacker, int friend_target, int enemy_target, Game game) {
    Action action(game);
    action.set_action_fish(attacker);
    action.set_action_type(1);
    if (friend_target != -1) {
        action.set_friend_target(friend_target);
        last_target = -3;
    }
    if (enemy_target != -1) {
        action.set_enemy_target(enemy_target);
        last_target = enemy_target;
    }
    return action;
}

Action crit_(int attacker, int friend_target, int enemy_target, Game game) {
    Action action(game);
    action.set_action_fish(attacker);
    action.set_action_type(1);
    if (friend_target != -1) {
        action.set_friend_target(friend_target);
        last_target = -3;
    }
    if (enemy_target != -1) {
        action.set_enemy_target(enemy_target);
        last_target = enemy_target;
    }
    return action;
}

Action subtle_(int attacker, int friend_target, int enemy_target, Game game) {
    Action action(game);
    action.set_action_fish(attacker);
    action.set_action_type(1);
    if (friend_target != -1) {
        action.set_friend_target(friend_target);
        last_target = -3;
    }
    if (enemy_target != -1) {
        action.set_enemy_target(enemy_target);
        last_target = enemy_target;
    }
    return action;
}


Action AI::Act(Game game)
{
    if (game.round == 1) {
        Action action(game);
        int my_hp = get_my_hp(2);
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp<=35&&hp>0&&my_hp>0)
                return aoe_(2,-1,-2,game);
        }
        if (times < 4 && my_hp>0) {
            times++;
            return aoe_(2,-1,-2,game);
        }
        
        int my_atk = get_my_atk(3);
        int enemy_hp[4] = { 0 };
        int min = 400;
        int k = 0;
        for (int i = 0; i < 4; i++) {
            enemy_hp[i] = get_enemy_hp(i);
            if (enemy_hp[i] < min && enemy_hp[i]>0) {
                min = enemy_hp[i];
                k = i;
            }
        }
        
        my_hp = get_my_hp(3);
        if (my_hp > 0) {
            for(int i=0;i<4;i++){
                int hp=get_enemy_hp(i);
                if(enemy[i].active==crit&&enemy[i].identity!=7&&hp>0){
                    if(my_atk>=min*2){
                        return normal_(3,-1,k,game);
                    }
                    return subtle_(3,3,-1,game);
                }
            }
            if (my_atk >= min * 2 && enemy[k].passive!=deflect) {
                return normal_(3,-1,k,game);
            }
            if (my_atk*0.7 >= min * 2 && enemy[k].passive==deflect) {
                return normal_(3,-1,k,game);
            }
            if (game.enemy_action.is_skill) {
                int skill = game.enemy_action.type;
                if (skill == crit) {
                    int target = game.enemy_action.enemy_targets[0];
                    int hp=get_my_hp(target);
                    if(hp>0) return subtle_(3,target,-1,game);
                    else return subtle_(3,3,-1,game);
                }
            }
            if (!game.enemy_action.is_skill) {
                int target = game.enemy_action.enemy_targets[0];
                int hp=get_my_hp(target);
                if(hp>0) return subtle_(3,target,-1,game);
                else return subtle_(3,3,-1,game);
            }
            
            return subtle_(3,3,-1,game);
        }
        
        for(int i=0;i<=3;i++){
            my_hp = get_my_hp(i);
            if (my_hp > 0) {
                for(int j=0;j<4;j++){
                    if (enemy[j].active == crit&&enemy[j].identity!=7) {
                        int hp=get_enemy_hp(j);
                        if(hp>0)
                            return normal_(i,-1,j,game);
                    }
                    if (enemy[j].active == infight&&game.enemy_action.action_fish==j) {
                        int hp=get_enemy_hp(j);
                        if(hp>0)
                            return normal_(i,-1,j,game);
                    }
                }
                int lowest_health_enemy = get_lowest_health_enemy();
                return normal_(i,-1,lowest_health_enemy,game);
            }
        }
    }
    
    if (game.round == 2) {
        Action action(game);
        
        int my_hp = get_my_hp(1);
        if (times1 < 3 && my_hp>0) {
            times1++;
            if(times1==1){
                my_hp=get_my_hp(0);
                if(my_hp>0) return aoe_(1,0,-2,game);
            }
            else if(times1==2){
                my_hp=get_my_hp(0);
                if(my_hp>0) return aoe_(1,2,-2,game);
            }
            else if(times1==3){
                my_hp=get_my_hp(0);
                if(my_hp>0) return aoe_(1,3,-2,game);
            }
            for(int i=0;i<4;i++){
                my_hp=get_my_hp(i);
                if(my_hp>0&&i!=1) return aoe_(1,i,-2,game);
            }
        }
        
        my_hp=get_my_hp(2);
        if(my_hp>0){
            turtletime=get_skill_used(2);
            if(turtletime<3){
                int friend1=0;
                if(turtletime==0)
                    friend1=0;
                if(turtletime==1)
                    friend1=1;
                if(turtletime==2)
                    friend1=3;
                for(int i=0;i<4;i++){
                    int hp=get_enemy_hp(i);
                    if(hp<=12&&hp>0){
                        for(int j=0;j<4;j++){
                            int hp1=get_enemy_hp(j);
                            if(enemy[j].passive==deflect&&hp1>0&&i!=j){
                                int hp2=get_my_hp(friend1);
                                if(hp2>0)
                                return subtle_(2,friend1,j,game);
                                else{
                                    for(int k=0;k<4;j++){
                                        hp1=get_my_hp(k);
                                        if(hp1>0&&k!=2) return subtle_(2,k,j,game);
                                    }
                                }
                            }
                        }
                    }
                }
                for(int i=0;i<4;i++) {
                    if(enemy[i].active==crit&&enemy[i].identity!=7){
                    int hp=get_enemy_hp(i);
                    int hp1=get_my_hp(friend1);
                    if(hp>0){
                        if(hp1>0)
                        return subtle_(2,friend1,i,game);
                        else{
                            for(int j=0;j<4;j++){
                                hp1=get_my_hp(j);
                                if(hp1>0&&j!=2) return subtle_(2,j,i,game);
                            }
                        }
                    }
                  }
                }
                for(int i=0;i<4;i++){
                    if(enemy[i].active==infight&&game.enemy_action.action_fish==i){
                    int hp=get_enemy_hp(i);
                    int hp1=get_my_hp(friend1);
                    if(hp>0){
                        if(hp1>0)
                        return subtle_(2,friend1,i,game);
                        else{
                            for(int j=0;j<4;j++){
                                hp1=get_my_hp(j);
                                if(hp1>0&&j!=2) return subtle_(2,j,i,game);
                            }
                        }
                    }
                  }
                    for(int i=0;i<4;i++){
                        if(enemy[i].passive==reduce&&enemy[i].identity!=7){
                        int hp=get_enemy_hp(i);
                        int hp1=get_my_hp(friend1);
                        if(hp>0){
                            if(hp1>0)
                            return subtle_(2,friend1,i,game);
                            else{
                                for(int j=0;j<4;j++){
                                    hp1=get_my_hp(j);
                                    if(hp1>0&&j!=2) return subtle_(2,j,i,game);
                                }
                            }
                        }
                      }
                    }
                    for(int i=0;i<4;i++){
                        if(enemy[i].passive==heal){
                        int hp=get_enemy_hp(i);
                        int hp1=get_my_hp(friend1);
                        if(hp>0){
                            if(hp1>0)
                            return subtle_(2,friend1,i,game);
                            else{
                                for(int j=0;j<4;j++){
                                    hp1=get_my_hp(j);
                                    if(hp1>0&&j!=2) return subtle_(2,j,i,game);
                                }
                            }
                        }
                      }
                    }
                    int enemy_hp[4] = { 0 };
                    int max=0;
                    int k = 0;
                    for (int i = 0; i < 4; i++) {
                        enemy_hp[i] = get_enemy_hp(i);
                        if (enemy_hp[i] >max) {
                            max = enemy_hp[i];
                            k = i;
                        }
                    }
                    int hp1=get_my_hp(friend1);
                    if(hp1>0)
                    return subtle_(2,friend1,i,game);
                    else{
                        for(int j=0;j<4;j++){
                            hp1=get_my_hp(j);
                            if(hp1>0&&j!=2) return subtle_(2,j,i,game);
                        }
                    }
                }
            }
        }
        
        my_hp = get_my_hp(3);
        if(my_hp>0){
            std::vector<int> lowest_health_enemies = get_lowest_health_enemies();
            for(int i=0;i<lowest_health_enemies.size();i++){
                if(enemy[lowest_health_enemies[i]].active==crit)
                    return crit_(3,-1,lowest_health_enemies[i],game);
            }
            for(int i=0;i<lowest_health_enemies.size();i++){
                if(enemy[lowest_health_enemies[i]].active==infight
                   &&game.enemy_action.action_fish==lowest_health_enemies[i])
                    return crit_(3,-1,lowest_health_enemies[i],game);
            }
            for(int i=0;i<lowest_health_enemies.size();i++){
                if(enemy[lowest_health_enemies[i]].passive==reduce)
                    return crit_(3,-1,lowest_health_enemies[i],game);
            }
            for(int i=0;i<lowest_health_enemies.size();i++){
                if(enemy[lowest_health_enemies[i]].passive==heal)
                    return crit_(3,-1,lowest_health_enemies[i],game);
            }
            int lowest_health_enemy = get_lowest_health_enemy();
            return crit_(3,-1,lowest_health_enemy,game);
        }
        
       
        
        for(int i=0;i<=3;i++){
            my_hp = get_my_hp(i);
            if (my_hp > 0) {
                for(int j=0;j<4;j++){
                    if (enemy[j].active == crit&&enemy[j].identity!=7) {
                        int hp=get_enemy_hp(j);
                        if(hp>0)
                            return normal_(i,-1,j,game);
                    }
                    if (enemy[j].active == infight&&game.enemy_action.action_fish==j) {
                        int hp=get_enemy_hp(j);
                        if(hp>0)
                            return normal_(i,-1,j,game);
                    }
                }
                int lowest_health_enemy = get_lowest_health_enemy();
                return normal_(i,-1,lowest_health_enemy,game);
            }
        }
  }

    Action action(game);
    int my_hp = get_my_hp(0);
    for(int i=0;i<4;i++){
        int hp=get_enemy_hp(i);
        if(hp<=35&&hp>0&&my_hp>0)
            return aoe_(0,-1,-2,game);
    }
    if (times2 < 4 && my_hp>0) {
        times2++;
        return aoe_(0,-1,-2,game);
    }
    
    my_hp=get_my_hp(1);
    if(my_hp>0){
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp<=12&&hp>0){
                for(int j=0;j<4;j++){
                    int hp1=get_enemy_hp(j);
                    if(enemy[j].passive==deflect&&hp1>0&&i!=j){
                        return crit_(1, -1, j, game);
                    }
                }
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].active==crit&&enemy[i].identity!=7)
                    return crit_(1,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].active==infight&&game.enemy_action.action_fish==i)
                    return crit_(1,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].passive==reduce&&enemy[i].identity!=7)
                    return crit_(1,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].passive==heal)
                    return crit_(1,-1,i,game);
            }
        }
        int enemy_hp[4] = { 0 };
        int max=0;
        int k = 0;
        for (int i = 0; i < 4; i++) {
            enemy_hp[i] = get_enemy_hp(i);
            if (enemy_hp[i] >max) {
                max = enemy_hp[i];
                k = i;
            }
        }
        return crit_(1,-1,k,game);
    }
    
    my_hp = get_my_hp(2);
    if(my_hp>0){
        std::vector<int> lowest_health_enemies = get_lowest_health_enemies();
        for(int i=0;i<lowest_health_enemies.size();i++){
            if(enemy[lowest_health_enemies[i]].active==crit)
                return crit_(2,-1,lowest_health_enemies[i],game);
        }
        for(int i=0;i<lowest_health_enemies.size();i++){
            if(enemy[lowest_health_enemies[i]].active==infight
               &&game.enemy_action.action_fish==lowest_health_enemies[i])
                return crit_(2,-1,lowest_health_enemies[i],game);
        }
        for(int i=0;i<lowest_health_enemies.size();i++){
            if(enemy[lowest_health_enemies[i]].passive==reduce)
                return crit_(2,-1,lowest_health_enemies[i],game);
        }
        for(int i=0;i<lowest_health_enemies.size();i++){
            if(enemy[lowest_health_enemies[i]].passive==heal)
                return crit_(2,-1,lowest_health_enemies[i],game);
        }
        int lowest_health_enemy = get_lowest_health_enemy();
        return crit_(2,-1,lowest_health_enemy,game);
    }
    
    my_hp=get_my_hp(3);
    if(my_hp>0){
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp<=12&&hp>0){
                for(int j=0;j<4;j++){
                    int hp1=get_enemy_hp(j);
                    if(enemy[j].passive==deflect&&hp1>0&&i!=j){
                        return crit_(3, -1, j, game);
                    }
                }
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].active==crit&&enemy[i].identity!=7)
                    return crit_(3,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].active==infight&&game.enemy_action.action_fish==i)
                    return crit_(3,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].passive==reduce&&enemy[i].identity!=7)
                    return crit_(3,-1,i,game);
            }
        }
        for(int i=0;i<4;i++){
            int hp=get_enemy_hp(i);
            if(hp>0){
                if(enemy[i].passive==heal)
                    return crit_(3,-1,i,game);
            }
        }
        int enemy_hp[4] = { 0 };
        int max=0;
        int k = 0;
        for (int i = 0; i < 4; i++) {
            enemy_hp[i] = get_enemy_hp(i);
            if (enemy_hp[i] >max) {
                max = enemy_hp[i];
                k = i;
            }
        }
        return crit_(3,-1,k,game);
    }


    for(int i=0;i<=3;i++){
        my_hp = get_my_hp(i);
        if (my_hp > 0) {
            for(int j=0;j<4;j++){
                if (enemy[j].active == crit&&enemy[j].identity!=7) {
                    int hp=get_enemy_hp(j);
                    if(hp>0)
                        return normal_(i,-1,j,game);
                }
                if (enemy[j].active == infight) {
                    int hp=get_enemy_hp(j);
                    if(hp>0)
                        return normal_(i,-1,j,game);
                }
            }
            int lowest_health_enemy = get_lowest_health_enemy();
            return normal_(i,-1,lowest_health_enemy,game);
        }
    }
}


int main()
{

    for (int i = 0; i <= 3; i++)
        enemy[i].pos = i;

    AI* myAI = new AI();
    myAI->run();
    delete (myAI);
    return 0;
}

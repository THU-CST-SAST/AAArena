#include "Action.hpp"
#include <algorithm>


std::vector<int> AI::Pick(Game game)
{
    std::vector<int> remain_fishes = get_my_remain_fishes();
    int number = remain_fishes.size();
    std::vector<int> pickfish;
    pickfish.clear();
    if(number == 12){
        pickfish.push_back(1);
        pickfish.push_back(5);
        pickfish.push_back(7);
        pickfish.push_back(10);
    }
    else if(number == 8){
        pickfish.push_back(3);
        pickfish.push_back(9);
        pickfish.push_back(8);
        pickfish.push_back(21);
    }
    else if(number == 4){
        pickfish.push_back(2);
        pickfish.push_back(4);
        pickfish.push_back(6);
        pickfish.push_back(11);
    }
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    Action action(game);
    std::vector<int> pos = get_my_living_fishes();
    if(game.my_fish[0].skill_used < 2 || pos.size() == 1)
        action.set_action_fish(pos[0]);
    else
        action.set_action_fish(pos[1]);
    auto_valid_action(pos[0], &action);
    return action;
}
#include "Action.hpp"
#include <algorithm>
#include <cstring>
#define ma game.my_action 
#define ea game.enemy_action
using namespace std;

/*
class fishPro {
public:
    int st1 = -1; // skill type 1
    int pt1 = -1; // passive type 1
    int st2 = -1; // skill type 2
    bool isAssert = false;
};

fishPro table[] = {
    fishPro {}, // ��0
    fishPro {aoe, counter}, // ��ˮ��1 
    fishPro {infight, counter}, // �����2 
    fishPro {aoe, deflect}, // ����3
    fishPro {infight, deflect}, // ������4
    fishPro {crit, passive_type::reduce}, //������5
    fishPro {subtle, passive_type::reduce}, // ����6 
    fishPro {crit, passive_type::reduce, subtle}, // ����7 
    fishPro {subtle, heal}, // ����8 
    fishPro {crit, heal}, // �����9
    fishPro {crit, explode}, // ��ͷ��10
    fishPro {aoe, counter, subtle}, // С����11
    fishPro {} // ��̬��12
};

*/

//skill
vector<int> aoeEx = { 2,4,5,6,7,8,9,10 };
vector<int> infightEx = { 1,3,5,6,7,8,9,10,11 };
vector<int> critEx = { 1,2,3,4,6,8,11 };
vector<int> subtleEx = { 1,2,3,4,5,9,10 };
vector<int> highCritEx = { 5, 7 };
vector<int> critNOLEx = { 9, 10 };

//passive
vector<int> LLCounterEx = { 3,4,5,6,7,8,9,10,11 };
vector<int> LLNotCounterEx = { 1, 2 };
vector<int> LLSelfCounter = { 1,2,3,4,5,6,7,8,9,10 };
vector<int> LLNotSelfCounter = { 11 };
vector<int> explodeEx = { 1,2,3,4,5,6,7,8,9,11 };
vector<int> reduceAllEx = { 1,2,3,4,8,9,10,11 };
vector<int> notReduceAllEx = { 7 };
vector<int> FHDeflectEx = { 1,2,5,6,7,8,9,10,11 };
vector<int> deflectEx = { 1,2,5,6,7,8,9,10,11 };
vector<int> notDeflectEx = { 3, 4 };
vector<int> FHHealEx = { 1,2,3,4,5,6,7,10,11 };
vector<int> healEx = { 1,2,3,4,5,6,7,10,11 };
vector<int> notHealEx = { 8, 9 };
vector<int> reduceAll3TEx = { 1,2,3,4,5,6,8,9,10,11 };
vector<int> notReduceAll3TEx = { 7 };

class fish {
public:
    int atk = 100;
    int hp = 400;
    int hp1 = 400; // ǰһ�غ�Ѫ��
    bool live = true;
    int skill_cnt = 0;
    int passive_cnt[10];
    int beenAttackTime = 0;
    int beenDmgTime = 0;
    int asserted = -1;
};

int roundCnt = 1; // �غ��� 
int turn = -1; // ����
fish ally[4]; // �Ѿ�
fish enem[4]; // �з�

bool easyGuess[13] = {
    false, // 0
    false, // 1
    false, // 2
    true, // 3
    false, // 4
    true, // 5
    false, // 6
    true, // 7
    false, // 8
    true, // 9
    false, // 10
    false, // 11
    false, // 12
};

int group[3][4] = {
    {19, 1, 10, 7},
    {5, 8, 9, 3},
    {11, 2 , 6, 4}
};

int pre[4][13]; // prediction
int assertFish[13]; // ��Ԥ�����¼

void ex(vector<int>& f, int pos) { // �ų�
    for (int i = 0; i < f.size(); ++i) {
        pre[pos][f[i]] = 1;
    }
}


void AI::exclude(Game& game) {
    //����
    if (roundCnt > 1) { // �ǵ�һ�غ�
        for (int i = 0; i < ma.num_enemy_passives; ++i) {
            passive_type pt = ma.enemy_types[i];
            int id = ma.enemy_passives_id[i];
            if (pt == explode) {
                assertFish[10] = turn + 1;
                //debug_msg("explodeEx " + to_string(id));
            }
            if (pt == passive_type::reduce && ma.enemy_passive_value[i] == 0) {
                ex(reduceAllEx, id);
                //debug_msg("reduceAllEx " + to_string(id));
            }
            if (game.first_mover && pt == deflect && roundCnt == 2) {
                ex(FHDeflectEx, id);
                //debug_msg("FHDeflectEx " + to_string(id));
            }
            if (pt == deflect && assertFish[11] > 0 && assertFish[11] < turn + 1) {
                ex(deflectEx, id);
                //debug_msg("deflectEx " + to_string(id));
            }
            if (pt == deflect && enem[id].beenAttackTime >= 3 && enem[id].beenAttackTime <= enem[id].passive_cnt[deflect]) {
                ex(deflectEx, id);
                //debug_msg("deflectEx " + to_string(id));
            }
            if (game.first_mover && pt == heal && roundCnt == 2) {
                ex(FHHealEx, id);
                //debug_msg("FHHealEx " + to_string(id));
            }
            if (pt == heal && assertFish[7] > 0 && assertFish[7] < turn + 1) {
                ex(healEx, id);
                //debug_msg("healEx " + to_string(id));
            }
            if (pt == heal && enem[id].beenDmgTime >= 2 && enem[id].beenDmgTime <= enem[id].passive_cnt[heal]) {
                ex(healEx, id);
                //debug_msg("healEx " + to_string(id));
            }
            if (pt == passive_type::reduce && ma.enemy_passive_value[i] == 0 && enem[id].beenDmgTime >= 3 && enem[id].beenDmgTime <= enem[id].passive_cnt[passive_type::reduce]) {
                ex(reduceAll3TEx, id);
                //debug_msg("reduceAll3TEx " + to_string(id));
            }
            if (pt == counter && assertFish[11] != 0 && game.enemy_fish[id].id != 11) {
                int cnt = 0;
                int f;
                for (int j = 0; j < 4; ++j) {
                    if (j == id) continue;
                    if (game.enemy_fish[id].id == -1) {
                        ++cnt;
                        f = j;
                    }
                }
                if (cnt == 1) {
                    ex(LLCounterEx, f);
                    //debug_msg("LLCounterEx " + to_string(f));
                }
            }
            if (pt == counter && assertFish[1] != 0 && assertFish[2] != 0) {
                bool isClown = true;
                for (int j = 0; j < 4; ++j) {
                    if (enem[j].hp <= 0) continue;
                    int identity = game.enemy_fish[j].id;
                    if (identity == 1 || identity == 2) {
                        isClown = false;
                        break;
                    }
                }
                if (isClown) {
                    ex(LLSelfCounter, id);
                    //debug_msg("LLSelfCounter " + to_string(id));
                }
            }
        }

        for (int i = 0; i < ma.num_enemy_targets; ++i) {
            int id = ma.enemy_targets[i];
            if (enem[id].passive_cnt[deflect] < enem[id].beenAttackTime) {
                ex(notDeflectEx, id);
                //debug_msg("notDeflectEx " + to_string(id));
            }
            if (enem[id].passive_cnt[heal] < enem[id].beenDmgTime && enem[id].hp > 0) {
                ex(notHealEx, id);
                //debug_msg("notHealEx " + to_string(id));
            }
            if (enem[id].beenDmgTime <= 3 && enem[id].passive_cnt[passive_type::reduce] < enem[id].beenDmgTime) {
                ex(notReduceAll3TEx, id);
                //debug_msg("notReduceAll3TEx " + to_string(id));
            }
            if (enem[id].hp1 < 120) {
                bool hasCounter = false;
                for (int j = 0; j < ma.num_enemy_passives; ++j) {
                    if (ma.enemy_types[j] == counter) {
                        hasCounter = true;
                        break;
                    }
                }
                if (!hasCounter) {
                    for (int j = 0; j < 4; ++j) {
                        if (j == id) {
                            ex(LLNotSelfCounter, j);
                            //debug_msg("LLNotSelfCounter " + to_string(j));
                        }
                        else {
                            ex(LLNotCounterEx, j);
                            //debug_msg("LLNotCounterEx " + to_string(j));
                        }
                    }
                }
            }
        }
    }

    if (!game.first_mover || roundCnt > 1) { // ���� or �ǵ�һ�غ�
        for (int i = 0; i < ea.num_friend_passives; ++i) {
            passive_type pt = ea.friend_types[i];
            int id = ea.friend_passives_id[i];
            if (pt == explode) {
                assertFish[10] = turn + 1;
                //debug_msg("explodeEx " + to_string(id));
            }
            if (pt == passive_type::reduce && ea.friend_passive_value[i] == 0) {
                ex(reduceAllEx, id);
                //debug_msg("reduceAllEx " + to_string(id));
            }
            if (pt == deflect && assertFish[11] > 0 && assertFish[11] < turn + 1) {
                ex(deflectEx, id);
                //debug_msg("deflectEx " + to_string(id));
            }
            if (pt == deflect && enem[id].beenAttackTime >= 3 && enem[id].beenAttackTime <= enem[id].passive_cnt[deflect]) {
                ex(deflectEx, id);
                //debug_msg("deflectEx " + to_string(id));
            }
            if (pt == heal && assertFish[7] > 0 && assertFish[7] < turn + 1) {
                ex(healEx, id);
                //debug_msg("healEx " + to_string(id));
            }
            if (pt == heal && enem[id].beenDmgTime >= 2 && enem[id].beenDmgTime <= enem[id].passive_cnt[heal]) {
                ex(healEx, id);
                //debug_msg("healEx " + to_string(id));
            }
            if (pt == passive_type::reduce && ea.friend_passive_value[i] == 0 && enem[id].beenDmgTime >= 3 && enem[id].beenDmgTime <= enem[id].passive_cnt[passive_type::reduce]) {
                ex(reduceAll3TEx, id);
                //debug_msg("reduceAll3TEx " + to_string(id));
            }
            if (pt == counter && assertFish[11] != 0 && game.enemy_fish[id].id != 11) {
                int cnt = 0;
                int f;
                for (int j = 0; j < 4; ++j) {
                    if (j == id) continue;
                    if (game.enemy_fish[id].id == -1) {
                        ++cnt;
                        f = j;
                    }
                }
                if (cnt == 1) {
                    ex(LLCounterEx, f);
                    //debug_msg("LLCounterEx " + to_string(f));
                }
            }
            if (pt == counter && assertFish[1] != 0 && assertFish[2] != 0) {
                bool isClown = true;
                for (int j = 0; j < 4; ++j) {
                    if (enem[j].hp <= 0) continue;
                    int identity = game.enemy_fish[j].id;
                    if (identity == 1 || identity == 2) {
                        isClown = false;
                        break;
                    }
                }
                if (isClown) {
                    ex(LLSelfCounter, id);
                    //debug_msg("LLSelfCounter " + to_string(id));
                }
            }
        }
        
        // ����
        int id = ea.action_fish;
        if (id >= 0 && ea.is_skill) {
            skill_type st = ea.type;
            if (st == aoe) {
                ex(aoeEx, id);
                //debug_msg("aoeEx " + to_string(id));
            }
            if (st == infight) {
                ex(infightEx, id);
                //debug_msg("infightEx " + to_string(id));
            }
            if (st == crit) {
                ex(critEx, id);
                //debug_msg("critEx " + to_string(id));
            }
            if (st == subtle) {
                ex(subtleEx, id);
                //debug_msg("subtleEx " + to_string(id));
            }
            for (int i = 0; i < ea.num_enemy_targets; ++i) {
                int expectDmg = ea.enemy_expected_injury[i];
                if (st == crit && expectDmg >= 140) {
                    ex(highCritEx, id);
                    //debug_msg("highCritEx " + to_string(id));
                }
                if (st == crit && expectDmg >= 120) { //�����Ѫ������
                    int tgt = ea.enemy_targets[i];
                    bool nol = false;
                    for (int j = 0; j < 4; ++j) {
                        if (ally[j].hp1 < ally[tgt].hp1 && ally[j].hp1 > 0) {
                            nol = true;
                        }
                    }
                    if (nol) {
                        ex(critNOLEx, id);
                        //debug_msg("critNOLEx " + to_string(id));
                    }
                }
            }
            
        }
    }

    //�Ѷ��Գɹ�
    for (int i = 1; i <= 12; ++i) {
        if (assertFish[i] != 0) {
            for (int j = 0; j < 4; ++j) {
                pre[j][i] = 1;
            }
        }
    }
}

std::pair<int, int> AI::predict(Game& game) {
    exclude(game);
    //debug_msg("�֣�" + to_string(turn) + "\n");
    //debug_msg("�غϣ�" + to_string(roundCnt) + "\n");
    string s;
    for (int i = 0; i < 4; ++i) {
        for (int j = 1; j <= 12; ++j) {
            s += to_string(pre[i][j]) + " ";
        }
        //debug_msg(s);
        s.clear();
        //debug_msg("\n");
    }
    for (int i = 0; i < 4; ++i) {
        if (enem[i].hp == 0 || enem[i].asserted != -1) continue;
        int ansCnt = 0;
        int easy = 0;
        int rc = 0;
        for (int j = 1; j <= 11; ++j) {
            if (pre[i][j] == 0) {
                if (easyGuess[j]) {
                    ++easy;
                }
                ++ansCnt;
                rc = j;
            }
        }
        if (ansCnt <= 2 && easy < 2 && ansCnt > 0) {
            return std::pair<int, int>{i, rc};
        }
        if (ansCnt == 0) {
            if (pre[i][12] == 0) {
                return std::pair<int, int>{i, 12};
            }
        }
    }
    return std::pair<int, int>{-1, -1};
}

std::pair<int, int> AI::guess(Game& game) {
    exclude(game);
    for (int i = 0; i < 4; ++i) {
        if (enem[i].hp == 0 || enem[i].asserted != -1) continue;
        int ansCnt = 0;
        int easy = 0;
        int rc = 0;
        for (int j = 1; j <= 11; ++j) {
            if (pre[i][j] == 0) {
                if (easyGuess[j]) {
                    ++easy;
                }
                ++ansCnt;
                rc = j;
            }
        }
        if (ansCnt <= 3 && easy < 3 && ansCnt > 0) {
            return std::pair<int, int>{i, rc};
        }
        if (ansCnt == 0) {
            if (pre[i][12] == 0) {
                return std::pair<int, int>{i, 12};
            }
        }
    }
    return std::pair<int, int>{-1, -1};
}




void refresh() {
    for (int i = 0; i < 4; ++i) {
        ally[i].atk = 100;
        ally[i].hp = ally[i].hp1 = 400;
        ally[i].live = true;
        ally[i].skill_cnt = 0;
        memset(ally[i].passive_cnt, 0, sizeof(ally[i].passive_cnt));
        ally[i].beenAttackTime = 0;
        ally[i].beenDmgTime = 0;
        ally[i].asserted = -1;

        enem[i].atk = 0;
        enem[i].hp = enem[i].hp1 = 400;
        enem[i].live = true;
        enem[i].skill_cnt = 0;
        memset(enem[i].passive_cnt, 0, sizeof(enem[i].passive_cnt));
        enem[i].beenAttackTime = 0;
        enem[i].beenDmgTime = 0;
        enem[i].asserted = -1;
    }
    if (turn == -1) {
        memset(assertFish, 0, sizeof(assertFish));
    }
    memset(pre, 0, sizeof(pre));
    roundCnt = 1;
}

void AI::update(Game& game) {
    for (int i = 0; i < 4; ++i) {
        ally[i].hp = get_my_hp(i);
        if (ally[i].hp == 0) ally[i].live = false;
        ally[i].atk = get_my_atk(i);
        enem[i].hp = get_enemy_hp(i);
        if (enem[i].hp == 0) enem[i].live = false;
        ally[i].skill_cnt = get_skill_used(i);
    }
    

    if (game.my_assert.assertResult) { // ���Գɹ�
        assertFish[game.my_assert.assertContent] = turn + 1;
        enem[game.my_assert.assertPos].asserted = game.my_assert.assertContent;
    }
    else if(game.my_assert.assertPos >= 0 && roundCnt > 1) { // ����ʧ��
        pre[game.my_assert.assertPos][game.my_assert.assertContent] = 1;
    }
}

void AI::updateOnce(Game& game) {
    for (int i = 0; i < 4; ++i) { // ����Ѫ��
        ally[i].hp1 = ally[i].hp;
        ally[i].hp = get_my_hp(i);

        enem[i].hp1 = enem[i].hp;
        enem[i].hp = get_enemy_hp(i);
    }

    if (ea.action_fish >= 0 && !ea.enemy_expected_injury.empty()) {
        enem[ea.action_fish].atk = ea.enemy_expected_injury.front(); // ���µз�������
    }

    if (roundCnt > 1) { // �ڶ��غ��Ժ�
        //���±������ܴ�������
        for (int i = 0; i < ma.num_enemy_passives; ++i) {
            ++enem[ma.enemy_passives_id[i]].passive_cnt[ma.enemy_types[i]];
        }

        //���µз��ܵ������˺�����
        for (int i = 0; i < ma.num_enemy_targets; ++i) {
            int id = ma.enemy_targets[i];
            ++enem[id].beenAttackTime;
        }

        //�����ҷ��ܵ������˺�����
        for (int i = 0; i < ma.num_friend_targets; ++i) {
            int id = ma.friend_targets[i];
            ++ally[id].beenAttackTime;
        }

        //���µз��ܵ�ʵ���˺�����
        for (int i = 0; i < ma.num_enemy_injury; ++i) {
            int id = ma.enemy_injury_id[i];
            ++enem[id].beenDmgTime;
        }

        //�����ҷ��ܵ�ʵ���˺�����
        for (int i = 0; i < ma.num_friend_injury; ++i) {
            int id = ma.friend_injury_id[i];
            ++ally[id].beenDmgTime;
        }
    }

    if (!game.first_mover || roundCnt > 1) { // ���� or �ڶ��غ��Ժ�
        //���±������ܴ�������
        for (int i = 0; i < ea.num_friend_passives; ++i) {
            ++enem[ea.friend_passives_id[i]].passive_cnt[ea.friend_types[i]];
        }

        //���µз��ܵ������˺�����
        for (int i = 0; i < ea.num_friend_targets; ++i) {
            int id = ea.friend_targets[i];
            ++enem[id].beenAttackTime;
        }

        //�����ҷ��ܵ������˺�����
        for (int i = 0; i < ea.num_enemy_targets; ++i) {
            int id = ea.enemy_targets[i];
            ++ally[id].beenAttackTime;
        }

        //���µз��ܵ�ʵ���˺�����
        for (int i = 0; i < ea.num_friend_injury; ++i) {
            int id = ea.friend_injury_id[i];
            ++enem[id].beenDmgTime;
        }

        //�����ҷ��ܵ������˺�����
        for (int i = 0; i < ea.num_enemy_injury; ++i) {
            int id = ea.enemy_injury_id[i];
            ++ally[id].beenDmgTime;
        }
    }
}

/*
int AI::getTarget(Game& game) {
    int rc = ea.action_fish;
    if (rc == -1 || enem[rc].hp <= 0) rc = get_enemy_living_fishes().back();
    for (int i = 0; i < 4; ++i) {
        if (enem[i].hp > 0 && (enem[i].asserted == 1 || enem[i].asserted == 2)) {
            rc = i;
        }
    }
    return rc;
}
*/

int AI::getTarget(Game& game) {
    int rc = ea.action_fish;
    if (ea.type == subtle || rc == -1 || enem[rc].hp <= 0) rc = get_enemy_living_fishes().back();

    for (int i = 0; i < 4; ++i) { // ȡ�˺����
        if (enem[i].hp > 0) {
            if (enem[i].atk > enem[rc].atk) {
                rc = i;
            }
        }
    }

    for (int i = 0; i < 4; ++i) { 
        if (enem[i].hp > 0 && (enem[i].asserted == 1 || enem[i].asserted == 2)) {
            rc = i;
        }
    }
    return rc;
}

Action AI::act1(Game& game) { // ��һ�ж�
    int target = getTarget(game);
    Action action(game);

    if ((game.first_mover && roundCnt == 2) || (!game.first_mover && roundCnt <= 3)) { //ɨ��
        int select = 1;
        action.set_action_fish(select);
        action.set_action_type(1);
        action.set_enemy_target(target);
        return action;
    }

    if (ally[0].hp > 0) { // ��̬��
        int select = 0;
        if (ally[select].skill_cnt < 3 && get_my_living_fishes().size() > 1) {
            action.set_action_fish(select);
            action.set_action_type(1);

            int fTarget = -1; // �ѷ�Ŀ��
            for (int j = 0; j < 4; ++j) {
                if (j == select) continue; // ������Լ�������
                if (ally[j].hp > 0 && (fTarget == -1 || ally[j].hp < ally[fTarget].hp)) {
                    fTarget = j;
                }
            }
            action.set_friend_target(fTarget);
            action.set_enemy_target(target);
            return action;
        }
    }
    if (ally[3].hp > 0) { // ����
        int select = 3;
        if (ally[select].skill_cnt < 3 && get_my_living_fishes().size() > 1) {
            action.set_action_fish(select);
            action.set_action_type(1);

            int fTarget = -1; // �ѷ�Ŀ��
            for (int j = 0; j < 4; ++j) {
                if (j == select) continue; // ������Լ�������
                if (ally[j].hp > 0 && (fTarget == -1 || ally[j].hp < ally[fTarget].hp)) {
                    fTarget = j;
                }
            }
            action.set_friend_target(fTarget);
            action.set_enemy_target(target);
            return action;
        }
    }
    if (ally[2].hp > 0) { // ��ͷ��
        int select = 2;
        action.set_action_fish(select);
        action.set_action_type(1);
        for (int j = 0; j < 4; ++j) {
            if (enem[j].hp > 0 && enem[j].hp < enem[target].hp) {
                target = j;
            }
        }
        action.set_enemy_target(target);
        return action;
    }
    if (ally[1].hp > 0) {// ��ˮ��
        int select = 1;
        if (get_enemy_living_fishes().size() > 1) {
            action.set_action_fish(select);
            action.set_action_type(1);
            action.set_enemy_target(target);
            return action;
        }
    }
    int order[4] = { 3, 0 ,2 , 1 }; // ��ͨ����˳��
    for (int i = 0; i < 4; ++i) { // ѡ��һ����ʹ����ͨ����
        if (ally[order[i]].hp > 0) {
            action.set_action_fish(order[i]);
            action.set_action_type(0);
            action.set_enemy_target(target);
            return action;
        }
    }
}

Action AI::act2(Game& game) { // �ڶ��ж�
    int target = getTarget(game);
    Action action(game);
    
    if ((game.first_mover && roundCnt == 2) || (!game.first_mover && roundCnt <= 3)) { //ɨ��
        int select = 3;
        action.set_action_fish(select);
        action.set_action_type(1);
        action.set_enemy_target(target);
        return action;
    }

    if (ally[0].hp > 0) { // ������
        int select = 0;
        action.set_action_fish(select);
        action.set_action_type(1);
        action.set_enemy_target(target);
        return action;
    }

    if (ally[2].hp > 0) { // �����
        int select = 2;
        action.set_action_fish(select);
        action.set_action_type(1);
        for (int j = 0; j < 4; ++j) {
            if (enem[j].hp > 0 && enem[j].hp < enem[target].hp) {
                target = j;
            }
        }
        action.set_enemy_target(target);
        return action;
    }

    if (ally[1].hp > 0) { // ����
        int select = 1;
        int est_atk = enem[target].atk == 0 ? 100 : enem[target].atk;
        if (get_enemy_living_fishes().size() == 1) { // �з�ʣһֻ
            if ((ally[select].hp > est_atk && ally[select].atk > enem[target].hp) || (ally[select].atk > enem[target].hp * 2)) { //����
                action.set_action_fish(select);
                action.set_action_type(0);
                action.set_enemy_target(target);
                return action;
            }
            else { // �ü���
                action.set_action_fish(select);
                action.set_action_type(1);
                action.set_friend_target(select);
                return action;
            }
        }
        else { // �з�ʣ��ֻ����
            if ((ally[select].hp > (est_atk) * 2 && ally[select].atk > enem[target].hp) || (ally[select].atk > enem[target].hp * 2)) { // ����
                action.set_action_fish(select);
                action.set_action_type(0);
                action.set_enemy_target(target);
                return action;
            }
            else { // �ü���
                action.set_action_fish(select);
                action.set_action_type(1);
                action.set_friend_target(select);
                return action;
            }
        }
    }

    if (ally[3].hp > 0) { // ��������
        int select = 3;
        if (get_enemy_living_fishes().size() > 2) {
            action.set_action_fish(select);
            action.set_action_type(1);
            action.set_enemy_target(target);
            return action;
        }
        else { // �����չ�
            action.set_action_fish(select);
            action.set_action_type(0);
            action.set_enemy_target(target);
            return action;
        }
    }
}

Action AI::act3(Game& game) { // �����ж�
    int target = getTarget(game);
    Action action(game);
    if (ally[0].hp > 0) { // С����
        int select = 0;
        action.set_action_fish(select);
        if (ally[select].skill_cnt < 3 && get_my_living_fishes().size() > 1) { // ʹ�ü���
            action.set_action_type(1);
            for (int i = 0; i < 4; ++i) {
                if (i != select && ally[i].hp > 0) {
                    action.set_friend_target(i);
                }
            }
            action.set_enemy_target(target);
            return action;
        }
    }
    for (int i = 0; i < 4; ++i) { // ѡ��һ����ʹ����ͨ����
        if (ally[i].hp > 0) {
            action.set_action_fish(i);
            action.set_action_type(0);
            action.set_enemy_target(target);
            return action;
        }
    }
}

std::vector<int> AI::Pick(Game game) {
    refresh();
    ++turn;
    std::vector<int> pick_fish;
    pick_fish.clear();
    int order[] = { 2, 1, 0 }; // ˳��
    for (int i = 0; i < 4; ++i) {
        pick_fish.push_back(group[order[turn]][i]);
    }
    return pick_fish;
}

std::pair<int, int> AI::Assert(Game game) {
    update(game);
    updateOnce(game);
    if (turn == 0) {
        return guess(game);
    }
    else {
        return predict(game);
    }
}

Action AI::Act(Game game) {
    update(game);
    ++roundCnt;
    if (turn == 0) return act3(game);
    else if (turn == 1) return act2(game);
    else return act1(game);
}





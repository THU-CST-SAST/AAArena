#include "Action.hpp"
#include <algorithm>

std::vector<int> r1 = {3, 5, 8, 2};
std::vector<int> r2 = {1, 9, 6, 4};
std::vector<int> r3 = {10, 7, 19, 11};

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> pickfish;
    //pickfish.clear();
    if(game.round == 1){
        pickfish = r1;
    }
    else if(game.round == 2){
        pickfish = r2;
    }
    else{
        pickfish = r3;
    }
    return pickfish;
}


std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    return std::make_pair(-1, -1);
}

int my_pos = 0;

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    
    while(game.my_fish[my_pos].hp <= 0)
        ++my_pos;
    action.set_action_fish(my_pos);
    auto_valid_action(my_pos, &action);
    return action;
}
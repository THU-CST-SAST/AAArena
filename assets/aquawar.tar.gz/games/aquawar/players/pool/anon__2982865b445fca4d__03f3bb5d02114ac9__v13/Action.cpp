
#include "Action.hpp"
#include <algorithm>
#include<iostream>
#include<string>
#define random(x) rand()%(x)
using namespace std;

int my_action_num = 0;
string out;

std::vector<int> AI::Pick(Game game)
{
	// TODO: fill your code
	// 


	std::vector<int> remain_fishes = get_my_remain_fishes();
	// 
	std::vector<int> pick_fish;
	pick_fish.clear();
	// 
	if (game.round == 1) {
		pick_fish.push_back(2);
		pick_fish.push_back(4);
		pick_fish.push_back(8);
		pick_fish.push_back(11);
	}
	else if (game.round == 2) {
		pick_fish.push_back(17);
		pick_fish.push_back(10);
		pick_fish.push_back(3);
		pick_fish.push_back(7);
	}
	else {
		pick_fish.push_back(5);
		pick_fish.push_back(9);
		pick_fish.push_back(1);
		pick_fish.push_back(6);
	}
	my_action_num = 0;

	return pick_fish;
}

std::pair<int, int> AI::Assert(Game game)
{
	// TODO: fill your code
	return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
	// TODO: fill your code
	// action

	Action action(game);
	/*
	//
	int my_pos = (get_my_living_fishes())[0];
	//
	action.set_action_fish(my_pos);
	//
	auto_valid_action(my_pos, &action);
	*/




	if (game.round == 1) {
		// 
		vector<int>my_livingfishes = get_my_living_fishes();
		int my_living_num = size(my_livingfishes);
		int laucher = random(my_living_num);

		vector<int>enemys = get_enemy_living_fishes();
		int aim_enemy_random = random(enemys.size());
		//int lowest_health_enemy = get_lowest_health_enemy();//get the most worthy enemy target

		action.set_action_fish(my_livingfishes[laucher]);
		action.set_action_type(0);
		action.set_enemy_target(enemys[aim_enemy_random]);
		return action;
		

	}
	else if (game.round == 2) {
		vector<int>my_livingfishes = get_my_living_fishes();
		int my_living_num = size(my_livingfishes);
		int laucher = random(my_living_num);
		int lowest_health_enemy = get_lowest_health_enemy();//get the most worthy enemy target

		int my_aoe = -1;
		int my_wolf_fake = -1;
		int my_head_shot = -1;
		int my_turtle = -1;
		for (int i = 0; i < 4; i++) {
			if (game.my_fish[i].hp > 0) {
				if (abs(get_my_id(i)) == 12)
					my_wolf_fake = i;
				else if (abs(get_my_id(i)) == 7)
					my_turtle = i;
				else if (abs(get_my_id(i)) == 10)
					my_head_shot = i;
				else
					my_aoe = i;
			}
		}
		if (my_action_num == 0) {//�����ȴ�һ��
			action.set_action_fish(my_aoe);
			action.set_action_type(1);
			action.set_enemy_target(-2);
			my_action_num++;
			return action;
		}
		if (game.enemy_fish[lowest_health_enemy].hp < 160 && my_head_shot != -1) {
			action.set_action_fish(my_head_shot);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		if (my_turtle != -1 && get_skill_used(my_turtle) < 3 && get_my_living_ally(my_turtle).size() > 0) {
			if (my_head_shot != -1) {
				if (get_skill_used(my_turtle) == 0 || game.my_fish[my_head_shot].hp < 400) {
					action.set_action_fish(my_turtle);
					action.set_action_type(1);
					action.set_friend_target(my_head_shot);
					action.set_enemy_target(lowest_health_enemy);
					my_action_num++;
					return action;
				}
				else {

					action.set_action_fish(my_turtle);
					action.set_action_type(1);
					action.set_friend_target(get_my_living_ally(my_turtle)[0]);
					action.set_enemy_target(lowest_health_enemy);
					my_action_num++;
					return action;
				}
			}
			else {
				action.set_action_fish(my_turtle);
				action.set_action_type(1);
				action.set_friend_target(get_my_living_ally(my_turtle)[0]);
				action.set_enemy_target(lowest_health_enemy);
				my_action_num++;
				return action;
			}
		}

		if (my_wolf_fake != -1)
		{
			action.set_action_fish(my_wolf_fake);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		else if (my_head_shot != -1) {
			action.set_action_fish(my_head_shot);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		else {
			action.set_action_fish(my_livingfishes[laucher]);
			action.set_action_type(0);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}

		//my_action_num++;
	}
	else {

		vector<int>my_livingfishes = get_my_living_fishes();
		int my_living_num = size(my_livingfishes);
		int laucher = random(my_living_num);
		int lowest_health_enemy = get_lowest_health_enemy();//get the most worthy enemy target

		int my_aoe = -1;
		int my_wolf_fake = -1;
		int my_head_shot = -1;
		int my_turtle = -1;
		for (int i = 0; i < 4; i++) {
			if (game.my_fish[i].hp > 0) {
				if (abs(get_my_id(i)) == 12)
					my_wolf_fake = i;
				else if (abs(get_my_id(i)) == 6)
					my_turtle = i;
				else if (abs(get_my_id(i)) == 9)
					my_head_shot = i;
				else
					my_aoe = i;
			}
		}
		if (my_action_num == 0) {//�����ȴ�һ��
			action.set_action_fish(my_aoe);
			action.set_action_type(1);
			action.set_enemy_target(-2);
			my_action_num++;
			return action;
		}
		if (game.enemy_fish[lowest_health_enemy].hp < 160 && my_head_shot != -1) {
			action.set_action_fish(my_head_shot);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		

		if (my_wolf_fake != -1)
		{
			action.set_action_fish(my_wolf_fake);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		else if (my_head_shot != -1) {
			action.set_action_fish(my_head_shot);
			action.set_action_type(1);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}
		else {
			action.set_action_fish(my_livingfishes[laucher]);
			action.set_action_type(0);
			action.set_enemy_target(lowest_health_enemy);
			my_action_num++;
			return action;
		}

		//my_action_num++;


	}
	// 
	return action;
}
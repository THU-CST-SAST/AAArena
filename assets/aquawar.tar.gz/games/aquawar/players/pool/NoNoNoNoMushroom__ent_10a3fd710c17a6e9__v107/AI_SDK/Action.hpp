#pragma once

#include "sdk/ai_client.hpp"
#include <set>
#include <iostream>

enum frame_type_t {fdamage, fcounter, fdeflect, freduce, fheal, fexplode};
enum owner_t {ally, enemy};

struct frame_t
{
    frame_type_t frame_type;
    owner_t owner;
    int pos;
    int value;
    double reduce_value;
    bool traceable;
    frame_t(){}
    frame_t(frame_type_t t, owner_t o, int p, int v, double r, bool trace):
        frame_type(t), owner(o), pos(p), value(v), reduce_value(r), traceable(trace){}

    friend std::ostream& operator<<(std::ostream& out, frame_t& frame)
    {
        out << (frame.owner == owner_t::ally ? "Ally": "Enemy") << " ";
        out << frame.pos << " ";
        switch(frame.frame_type)
        {
        case frame_type_t::fcounter:
            out << "triggers counter\n";
            break;
        case frame_type_t::fdamage:
            out << "takes " << frame.value << " damage\n";
            break;
        case frame_type_t::fdeflect:
            out << "deflects\n";
            break;
        case frame_type_t::fexplode:
            out << " booms!\n";
            break;
        case frame_type_t::fheal:
            out << " heals 20 hp\n";
            break;
        case frame_type_t::freduce:
            out << " reduces its damage to " << frame.reduce_value << "\n";
            break;
        default:
            out << "sucks! " << frame.frame_type << "\n";
        }
        return out;
    }
};

struct skill_usage_t
{
    int use_num;
    skill_type first;
    skill_type last;
    int damage_taken;
    skill_usage_t() : use_num(0), damage_taken(0) {}
    void record(skill_type t)
    {
        last = t;
        if(use_num == 0)
            first = t;
        use_num++;
    }
};

struct step_t
{
    int mover;
    int effect;
    int ally;
    int enemy; //-1 = no, -2 = all
    bool is_skill;
    step_t(int _mover, int _effect, int _ally, int _enemy, int _is_skill) :
        mover(_mover), effect(_effect), ally(_ally), enemy(_enemy), is_skill(_is_skill) {}
};

typedef std::pair<std::vector<int>, std::vector<int>> hps; //our 4 hp and enemy 4 hp

class AI : public AIClient
{

private:
    bool attacked;
    int try_type;
    int try_pos;
    bool is_inited = false;
    bool *is_exposed;
    int *pickfish;

    hps last_turn_hps;
    skill_usage_t enemy_skill_usage[4];

public:
    AI()
    {
        is_exposed = new bool[12];
        pickfish = new int[4];
    }
    ~AI()
    {
        delete[] is_exposed;
        delete[] pickfish;
    }

    //used in passive deduction
    bool clownfish_used(int enemy_id);
    int turtle_used_num(int enemy_id);

    //passive deduction
    bool must_counter(Game& game, int enemy_id, int attacked_enemy_id);
    bool cannot_counter(Game& game, int enemy_id, int attacked_enemy_id);

    void about_counter(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);
    void about_deflect(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);
    void about_reduce(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);
    void about_heal(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);
    void about_explode(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);

    void extract_timestamp(Game& game, hps initial_hps, std::vector<frame_t>& frames, std::vector<hps>& all_hps);

    void about_attack(Game& game);
    void about_aoe(Game& game);
    void about_infight(Game& game);
    void about_crit(Game& game, hps before_hps);
    void about_subtle(Game& game);
    void note_skill(Game& game);

    void analyze_previous_assert(Game& game);
    void analyze_my_action(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames);
    void analyze_enemy_action(Game& game, hps hps_mid);
    void analyze(Game& game);
    std::pair<int, int> do_assertion(Game& game);

    active_skill get_active(Game& game, int ally_id);

    //action
    bool is_safe(Game& game, step_t& step);

    int skill_damage(Game& game, int ally_id);
    std::vector<int> possible_type_to_vec(int enemy_id);
    int enemy_damage_modify(Game& game, int enemy_id, int original_damage);
    int enemy_damage_modify_type(Game& game, int enemy_id, fish_type type, int original_damage);
    int enemy_threat(Game& game, int enemy_id);
    int enemy_threat_type(Game& game, int enemy_id, fish_type type);
    int ally_threat(Game& game, int ally_id);
    void best_motion(Game& game, Action& action);

    hps get_hps(Game& game);

    void init_round();

    std::vector<int> Pick(Game game);
    std::pair<int, int> Assert(Game game);
    Action Act(Game game);
};
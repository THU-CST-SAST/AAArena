#include "Action.hpp"
#include "sdk/ai_client.hpp"
#include <algorithm>
#include <set>
#include <random>
#include <ctime>
#include <fstream>

//global info
std::set<int> not_exist_type;

inline bool not_exist(int query)
{
    return not_exist_type.find(query) != not_exist_type.end();
}

//round info
bool fish_possible_type[4][13];
int expected_fish_type[4];
bool giveup[4]; //shit! deduction failed
std::set<int> exist_type;

bool new_round;

std::vector<int> full_hp{400, 400, 400, 400};
hps both_full = std::make_pair(full_hp, full_hp);

void AI::init_round()
{
    not_exist_type.insert(exist_type.begin(), exist_type.end());
    exist_type.clear();

    for(int i = 0; i < 4; i++)
    {
        for(int j = 1; j < 13; j++)
            fish_possible_type[i][j] = true;
    
        for(auto excluded: not_exist_type)
            fish_possible_type[i][excluded] = false;

        enemy_skill_usage[i] = skill_usage_t();
        giveup[i] = false;
        expected_fish_type[i] = -1;
    }
}

void check_only(int enemy_id)
{
    int possibility = 0;
    int possible = -1;
    for(int i = 1; i <= 11; i++)
    {
        if(fish_possible_type[enemy_id][i])
        {
            possibility++;
            possible = i;
        }
    }
    if(possibility == 1)
        expected_fish_type[enemy_id] = possible;
}

void exclude(int enemy_id, int remove)
{
    fish_possible_type[enemy_id][remove] = false;
    check_only(enemy_id);
}

void exclude(int enemy_id, int remove1, int remove2)
{
    fish_possible_type[enemy_id][remove1] = false;
    fish_possible_type[enemy_id][remove2] = false;
    check_only(enemy_id);
}

void exclude(int enemy_id, int remove1, int remove2, int remove3)
{
    fish_possible_type[enemy_id][remove1] = false;
    fish_possible_type[enemy_id][remove2] = false;
    fish_possible_type[enemy_id][remove3] = false;
    check_only(enemy_id);
}

void only(int enemy_id, int maintain)
{
    for(int i = 1; i <= 11; i++)
        if(i != maintain)
            fish_possible_type[enemy_id][i] = false;
    check_only(enemy_id);
}

void only(int enemy_id, int maintain1, int maintain2)
{
    for(int i = 1; i <= 11; i++)
        if(i != maintain1 && i != maintain2)
            fish_possible_type[enemy_id][i] = false;
    check_only(enemy_id);
}

void only(int enemy_id, int maintain1, int maintain2, int maintain3)
{
    for(int i = 1; i <= 11; i++)
        if(i != maintain1 && i != maintain2 && i != maintain3)
            fish_possible_type[enemy_id][i] = false;
    check_only(enemy_id);
}

void confirm(int enemy_id, int type)
{
    exist_type.insert(type);
    for(int i = 0; i < 4; i++)
        if(i != enemy_id)
            fish_possible_type[i][type] = false;
}

const int COUNTER_LINE = 120;

void output(int enemy_id)
{
    for(int i = 1; i < 12; i++)
        if(fish_possible_type[enemy_id][i])
            std::cerr << i << " ";
    std::cerr << "\n";
}

bool AI::clownfish_used(int enemy_id)
{
    if(not_exist(clownfish) && not_exist(imitator))
        return false;

    for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
    {
        if(other_enemy_id == enemy_id)
            continue;

        auto& usage = enemy_skill_usage[other_enemy_id];

        if(usage.use_num == 0)
            continue;

        if(usage.use_num <= 3)
        {
            if(usage.first == skill_type::aoe)
                return true;
        }
        else
        {
            if(usage.first == skill_type::aoe && usage.last == skill_type::subtle)
                return true;
        }
    }
    return false;
}

int AI::turtle_used_num(int enemy_id)
{
    if(not_exist(turtle) && not_exist(imitator))
        return 0;

    int num = 0;
    for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
    {
        if(other_enemy_id == enemy_id)
            continue;
        
        auto& usage = enemy_skill_usage[other_enemy_id];

        if(usage.use_num == 0)
            continue;

        if(usage.use_num <= 3)
        {
            if(usage.first == skill_type::crit)
                num += usage.use_num;
        }
        else
        {
            if(usage.first == skill_type::crit && usage.last == skill_type::subtle)
                num += usage.use_num;
        }
    }
    return num;
}

bool AI::must_counter(Game& game, int enemy_id, int attacked_enemy_id)
{
    bool self = (enemy_id == attacked_enemy_id);

    int concrete = -1;

    if(game.enemy_fish[enemy_id].id != -1 && game.enemy_fish[enemy_id].id != 12)
        concrete = game.enemy_fish[enemy_id].id;

    if(expected_fish_type[enemy_id] != -1 && expected_fish_type[enemy_id] != 12)
        concrete = game.enemy_fish[enemy_id].id;

    if(concrete != -1)
        return self ? (concrete == clownfish) : (concrete == spray || concrete == flame);
    
    if(self)
    {
        for(int i = 1; i <= 11; i++)
            if(i != clownfish && fish_possible_type[enemy_id][i])
                return false;
        return true;
    }
    else
    {
        for(int i = 1; i <= 11; i++)
            if(i != spray && i != flame && fish_possible_type[enemy_id][i])
                return false;
        return true;
    }
}

bool AI::cannot_counter(Game& game, int enemy_id, int attacked_enemy_id)
{
    bool self = (enemy_id == attacked_enemy_id);

    int concrete = -1;

    if(game.enemy_fish[enemy_id].id != -1 && game.enemy_fish[enemy_id].id != 12)
        concrete = game.enemy_fish[enemy_id].id;

    if(expected_fish_type[enemy_id] != -1 && expected_fish_type[enemy_id] != 12)
        concrete = game.enemy_fish[enemy_id].id;

    if(concrete != -1)
        return self ? (concrete != clownfish) : (concrete != spray && concrete != flame);
    
    if(self)
        return !fish_possible_type[enemy_id][clownfish];
    else
        return !(fish_possible_type[enemy_id][spray] || fish_possible_type[enemy_id][flame]);
}

void AI::about_counter(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.second[enemy_id] <= 0) //already dead
            continue;

        bool danger_attacked = false;
        int trigger_counter = 0;

        for(int i = 0; i < frames.size(); i++)
        {
            auto& frame = frames[i];

            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;

            if(frame.frame_type == fdamage && frame.traceable)
            {
                int after_hp = hps_vector[i + 1].second[enemy_id];
                for(int j = i + 1; j < frames.size(); j++)
                {
                    auto& next_frame = frames[j];
                    if(next_frame.owner == enemy && next_frame.pos == enemy_id && next_frame.frame_type == frame_type_t::fheal)
                    {
                        after_hp = hps_vector[j + 1].second[enemy_id];
                    }
                    else
                    {
                        break;
                    }
                }
                if(after_hp < 120)
                    danger_attacked = true;
            }
                
            if(frame.frame_type == fcounter)
                trigger_counter++;
        }

        if(danger_attacked)
        {
            if(trigger_counter == 0)
            {
                exclude(enemy_id, clownfish);
                std::cerr << "for enemy " << enemy_id << " triggers no counter when danger attacked: ";
                output(enemy_id);

                for(int other_enemy_id = 0; other_enemy_id < 4; other_enemy_id++)
                    if(other_enemy_id != enemy_id)
                    {
                        exclude(other_enemy_id, spray, flame);

                        std::cerr << "for enemy " << other_enemy_id << " do not help " << enemy_id << " trigger counter: ";
                        output(other_enemy_id);
                    }
            }
            else
            {
                std::cerr << "enemy " << enemy_id << " triggers counter " << trigger_counter << " times:\n";

                std::set<int> living_enemies;
                for(int i = 0; i < 4; i++)
                    if(initial_hps.second[i] > 0)
                        living_enemies.insert(i);

                int num_must_counter = 0;
                int num_cannot_counter = 0;
                std::set<int> unknown_enemies;

                for(auto living_enemy: living_enemies)
                {
                    if(must_counter(game, living_enemy, enemy_id))
                    {
                        std::cerr << living_enemy << " must counter\n";
                        num_must_counter++;
                    }
                    else if(cannot_counter(game, living_enemy, enemy_id))
                    {
                        std::cerr << living_enemy << " cannot counter\n";
                        num_cannot_counter++;
                    }
                    else
                    {
                        std::cerr << living_enemy << " is unknown\n";
                        unknown_enemies.insert(living_enemy);
                    }
                }

                int num_unknown_counter = trigger_counter - num_must_counter;
                std::cerr << "trigger unknown counter num: " << num_unknown_counter << "\n";
                if(num_unknown_counter == 0)
                {
                    for(auto unknown_enemy: unknown_enemies)
                    {
                        if(unknown_enemy == enemy_id)
                        {
                            exclude(unknown_enemy, clownfish);
                            std::cerr << "for enemy " << unknown_enemy << " triggers no counter when danger attacked: ";
                            output(unknown_enemy);
                        }
                        else
                        {
                            exclude(unknown_enemy, spray, flame);
                            std::cerr << "for enemy " << unknown_enemy << " do not help " << enemy_id << " trigger counter: ";
                            output(unknown_enemy);
                        }
                    }
                }
                else if(num_unknown_counter == unknown_enemies.size())
                {
                    for(auto unknown_enemy: unknown_enemies)
                    {
                        if(unknown_enemy == enemy_id)
                        {
                            only(unknown_enemy, clownfish);
                            std::cerr << "for enemy " << unknown_enemy << " triggers counter when danger attacked: ";
                            output(unknown_enemy);
                        }
                        else
                        {
                            only(unknown_enemy, spray, flame);
                            std::cerr << "for enemy " << unknown_enemy << " helps " << enemy_id << " trigger counter: ";
                            output(unknown_enemy);
                        }
                    }
                }
                
            }
            
        }
    }
}

void AI::about_deflect(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.second[enemy_id] <= 0) //already dead
            continue;

        bool attacked = false;
        bool trigger_deflect = false;
        bool clownfish_useskill = clownfish_used(enemy_id);

        for(auto& frame: frames)
        {
            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;

            if(frame.frame_type == fdamage && frame.traceable)
                attacked = true;
            
            if(frame.frame_type == fdeflect)
                trigger_deflect = true;
        }

        if(attacked && !trigger_deflect)
        {
            exclude(enemy_id, eel, sunfish);

            std::cerr << "for enemy " << enemy_id << " triggers no deflect when attacked: ";
            output(enemy_id);
        }
        if(attacked && trigger_deflect && !clownfish_useskill)
        {
            only(enemy_id, eel, sunfish);

            std::cerr << "for enemy " << enemy_id << " is attacked, triggers deflect and no clownfish: ";
            output(enemy_id);
        }
    }
}

void AI::about_reduce(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.second[enemy_id] <= 0) //already dead
            continue;

        bool trigger_dodge = false;

        for(auto& frame: frames)
        {
            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;
            
            if(frame.frame_type == freduce && frame.reduce_value < 0.01)
                trigger_dodge = true;
        }

        if(trigger_dodge)
        {
            only(enemy_id, barracuda, mobula, turtle);

            std::cerr << "for enemy " << enemy_id << " triggers 100% dodge: ";
            output(enemy_id);
        }
    }
}

void AI::about_heal(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    auto& initial_hps = hps_vector[0];

    for(int enemy_id = 0; enemy_id < 4; enemy_id++)
    {
        if(initial_hps.second[enemy_id] <= 0) //already dead
            continue;

        int survive_attacks = 0;
        int survive_damages = 0;
        int heals = 0;
        int turtle_num = turtle_used_num(enemy_id);

        for(int i = 0; i < frames.size(); i++)
        {
            auto& frame = frames[i];
            auto& after_hps = hps_vector[i + 1];

            if(frame.owner != enemy || frame.pos != enemy_id)
                continue;
            
            if(frame.frame_type == fheal)
                heals++;
            
            if(frame.frame_type == fdamage && after_hps.second[enemy_id] > 0)
            {
                survive_damages++;
                if(frame.traceable)
                    survive_attacks++;
            }
        }

        if(survive_attacks == 0 || (survive_attacks == 1 && turtle_num == 0))
        {
            if(heals < survive_damages)
            {
                exclude(enemy_id, whiteshark, octopus);

                std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages but heals " << heals << "times:";
                output(enemy_id);
            }
            if(heals == survive_damages && survive_damages > 0)
            {
                only(enemy_id, whiteshark, octopus);

                std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages and heals " << heals << "times:";
                output(enemy_id);
            }
        }
        else
        {
            if(heals < survive_damages)
            {
                exclude(enemy_id, whiteshark, octopus);

                std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages but heals " << heals << "times:";
                output(enemy_id);
            }

            int min_self_heals = heals - turtle_num;
            if(min_self_heals > 0)
            {
                only(enemy_id, whiteshark, octopus);

                std::cerr << "for enemy " << enemy_id << " takes " << survive_damages << " damages and heals at least " << min_self_heals << "times by self:";
                output(enemy_id);
            }
        }
    }
}

void AI::about_explode(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    //todo
}

frame_type_t passive_to_frame_type(passive_type p)
{
    switch(p)
    {
    case passive_type::counter:
        return frame_type_t::fcounter;
    case passive_type::deflect:
        return frame_type_t::fdeflect;
    case passive_type::explode:
        return frame_type_t::fexplode;
    case passive_type::heal:
        return frame_type_t::fheal;
    case passive_type::reduce:
        return frame_type_t::freduce;
    default:
        std::cerr << "shit! wrong passive_type " << p << "\n";
        return frame_type_t::fdamage;
    }
}

void AI::extract_timestamp(Game& game, hps initial_hps, std::vector<frame_t>& frames, std::vector<hps>& all_hps)
{
    const auto& my_action = game.my_action;

    for(int i = 0; i < my_action.num_enemy_injury; i++)
    {
        int time = my_action.enemy_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);
        
        int pos = my_action.enemy_injury_id[i];
        int value = my_action.enemy_injury[i];
        bool traceable = my_action.enemy_injury_traceable[i];

        enemy_skill_usage[pos].damage_taken += value;

        frames[time] = frame_t(frame_type_t::fdamage, owner_t::enemy, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < my_action.num_friend_injury; i++)
    {
        int time = my_action.friend_injury_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.friend_injury_id[i];
        int value = my_action.friend_injury[i];
        bool traceable = my_action.enemy_injury_traceable[i];

        frames[time] = frame_t(frame_type_t::fdamage, owner_t::ally, pos, value, 1.0, traceable);
    }

    for(int i = 0; i < my_action.num_enemy_passives; i++)
    {
        int time = my_action.enemy_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.enemy_passives_id[i];
        auto type = my_action.enemy_types[i];
        double reduce_rate = (type == reduce ? my_action.enemy_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::enemy, pos, 0, reduce_rate, false);
    }

    for(int i = 0; i < my_action.num_friend_passives; i++)
    {
        int time = my_action.friend_passives_timestamp[i] - 1;
        if(frames.size() <= time)
            frames.resize(time + 1);

        int pos = my_action.friend_passives_id[i];
        auto type = my_action.friend_types[i];
        double reduce_rate = (type == reduce ? my_action.friend_passive_value[i] : 1.0);

        frames[time] = frame_t(passive_to_frame_type(type), owner_t::ally, pos, 0, reduce_rate, false);
    }

    all_hps.push_back(initial_hps);

    for(int event = 0; event < frames.size(); event++)
    {
        auto& frame = frames[event];
        auto pos = frame.pos;

        hps after_hps = all_hps[event];
        
        switch(frame.frame_type)
        {
        case frame_type_t::fdamage:
            if(frame.owner == owner_t::ally)
            {
                after_hps.first[pos] -= frame.value;
            }
            else
            {
                after_hps.second[pos] -= frame.value;
            }
            break;
        case frame_type_t::fheal:
            if(frame.owner == owner_t::ally)
            {
                after_hps.first[pos] += 20;
                if(after_hps.first[pos] > 400)
                    after_hps.first[pos] = 400;
            }
            else
            {
                after_hps.second[pos] += 20;
                if(after_hps.second[pos] > 400)
                    after_hps.second[pos] = 400;
            }
            break;
        default:
            break;
        }
        all_hps.push_back(after_hps);
    }

    int assertPos = game.enemy_assert.assertPos;
    int assertContent = game.enemy_assert.assertContent;
    bool result = game.enemy_assert.assertResult;

    if(!(assertPos >= 0 && assertPos < 4))
        return;
    if(!(assertContent >= 1 && assertContent <= 12))
        return;

    std::cerr << "\n\nenemy assert is " << assertPos << " " << assertContent << " result is " << result << "\n\n\n";

    hps assert_hps = all_hps.back();
    if(result)
    {
        for(int i = 0; i < 4; i++)
            assert_hps.first[i] -= 50;
    }
    else
    {
        for(int i = 0; i < 4; i++)
            assert_hps.second[i] -= 50;
    }
    all_hps.push_back(assert_hps);
}

void AI::analyze_my_action(Game& game, std::vector<hps>& hps_vector, std::vector<frame_t>& frames)
{
    extract_timestamp(game, last_turn_hps, frames, hps_vector);

    // std::cerr << "start outputing timeline\n";
    // for(auto frame: frames)
    //     std::cerr << frame;
    // std::cerr << "end outputing timeline\n";
    // auto& hps_mid = hps_vector.back();
    // std::cerr << "our hp: " << hps_mid.first[0] << " " << hps_mid.first[1] << " " << hps_mid.first[2] << " " << hps_mid.first[3] << "\n";
    // std::cerr << "enemy hp: " << hps_mid.second[0] << " " << hps_mid.second[1] << " " << hps_mid.second[2] << " " << hps_mid.second[3] << "\n";

    about_counter(game, hps_vector, frames);
    about_deflect(game, hps_vector, frames);
    about_reduce(game, hps_vector, frames);
    about_explode(game, hps_vector, frames);
    about_heal(game, hps_vector, frames);
}

void AI::about_attack(Game& game) //todo
{
    //evaluate attack
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(enemy_action.is_skill)
        return;

    int damage = 0;

    std::cerr << "enemy attacks, targeting " << enemy_action.num_enemy_targets << "\n";

    for(int i = 0; i < enemy_action.num_enemy_targets; i++)
    {
        std::cerr << "enemy " << enemy_id << " attacks, dealing damage to ally " << enemy_action.enemy_targets[i] << " with " << enemy_action.enemy_expected_injury[i] << "\n";
        damage += enemy_action.enemy_expected_injury[i];
    }

    int enemy_attack = damage * 2;

    std::cerr << "enemy " << enemy_id << " attacks, dealing damage to " << enemy_action.num_enemy_targets << " fishes with " << damage << "\n";

    if(enemy_attack < 100)
        return;

    if(enemy_attack > 100)
    {
        exclude(enemy_id, spray, barracuda);
        exclude(enemy_id, turtle, whiteshark, clownfish);

        std::cerr << "for enemy " << enemy_id << " has more attack than 100, its possibility: ";
        output(enemy_id);
    }

    if(enemy_attack >= 112 && enemy_attack <= 118) //hammerhead
    {
        only(enemy_id, hammerhead);

        std::cerr << "for enemy " << enemy_id << " has attack " << enemy_attack << ", its possibility: ";
        output(enemy_id);
    }

    auto& usage = enemy_skill_usage[enemy_id];

    int attack_infight = usage.first == infight ? usage.use_num * 70 : 0;

    int attack_skill_20 = usage.use_num * 20;
    int attack_large_damage = (usage.damage_taken / 200) * 20;

    int add = enemy_attack - 100 - attack_infight;

    //passive attack up of eel and sunfish need to rewrite

    if(add != attack_skill_20)
    {
        exclude(enemy_id, mobula, octopus);

        std::cerr << "for enemy " << enemy_id << " use attack up number not match attack " << enemy_attack << ", its possibility: ";
        output(enemy_id);
    }
    if(add != attack_large_damage)
    {
        exclude(enemy_id, eel, sunfish);

        std::cerr << "for enemy " << enemy_id << " take large damage number not match attack " << enemy_attack << ", its possibility: ";
        output(enemy_id);
    }
}

void AI::about_aoe(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::aoe)
        return;

    exclude(enemy_id, flame, sunfish);
    exclude(enemy_id, barracuda, mobula);
    exclude(enemy_id, turtle, octopus);
    exclude(enemy_id, whiteshark, hammerhead);

    std::cerr << "for enemy " << enemy_id << " uses aoe, its possibility: ";
    output(enemy_id);

    if(enemy_skill_usage[enemy_id].use_num >= 4)
    {
        exclude(enemy_id, clownfish);

        std::cerr << "for enemy " << enemy_id << " uses aoe for " << enemy_skill_usage[enemy_id].use_num << " times, its possibility: ";
        output(enemy_id);
    }
}

void AI::about_infight(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::infight)
        return;

    only(enemy_id, flame, sunfish);

    std::cerr << "for enemy " << enemy_id << " uses infight, its possibility: ";
    output(enemy_id);
}

void AI::about_crit(Game& game, hps before_hps)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill || enemy_action.type != skill_type::crit)
        return;

    exclude(enemy_id, spray, flame, eel);
    exclude(enemy_id, sunfish, mobula, octopus);
    exclude(enemy_id, clownfish);

    int target = -1;
    for(int i = 0; i < enemy_action.num_enemy_targets; i++)
    {
        std::cerr << "enemy critical aims " << enemy_action.enemy_targets[i] << "\n";
        target = enemy_action.enemy_targets[i];
    }

    int damage = enemy_action.enemy_excepted_injury[0];
    int attacker_hp = before_hps.second[enemy_id];

    std::cerr << "for enemy " << enemy_id << "(" << attacker_hp << ") uses crit with damage " << damage << " to target " << target << " its possibility: ";
    output(enemy_id);

    if(damage > 120)
    {
        exclude(enemy_id, barracuda, turtle);

        std::cerr << "for enemy " << enemy_id << " does crit damage more than 120, its possibility: ";
        output(enemy_id);

        if(damage % 10 != 0)
        {
            only(enemy_id, hammerhead);

            std::cerr << "for enemy " << enemy_id << " does crit damage that is not times of 10, its possibility: ";
            output(enemy_id);
        }
        else //140
        {
            if(attacker_hp < 80)
            {
                only(enemy_id, whiteshark);

                std::cerr << "for enemy " << enemy_id << " does damage 140 when hp lower than 80, its possibility: ";
                output(enemy_id);
            }
        }
    }
    else
    {
        if(attacker_hp < 80)
        {
            exclude(enemy_id, hammerhead);

            std::cerr << "for enemy " << enemy_id << " does damage 120 when hp lower than 80, its possibility: ";
            output(enemy_id);
        }
        
        if(target < 0 || target > 3)
            std::cerr << "shit! target of crit is " << target << "\n";

        auto& my_fish_hp_before = before_hps.first;

        bool target_hp_minimal = true;
        for(int i = 0; i < 4; i++)
            if(i != target && my_fish_hp_before[i] > 0 && my_fish_hp_before[i] < my_fish_hp_before[target])
                target_hp_minimal = false;
        
        if(!target_hp_minimal)
        {
            exclude(enemy_id, whiteshark, hammerhead);

            std::cerr << my_fish_hp_before[0] << " " << my_fish_hp_before[1] << " " << my_fish_hp_before[2] << " " << my_fish_hp_before[3] << "\n";

            std::cerr << "for enemy " << enemy_id << " does damage 120 to not minimal hp, its possibility: ";
            output(enemy_id);
        }

        if(my_fish_hp_before[target] < 160)
        {
            exclude(enemy_id, whiteshark, hammerhead);

            std::cerr << "for enemy " << enemy_id << " does damage 120 to hp less than 160, its possibility: ";
            output(enemy_id);
        }
    }
}

void AI::about_subtle(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;
    
    if(!enemy_action.is_skill || enemy_action.type != skill_type::subtle)
        return;

    auto& usage = enemy_skill_usage[enemy_id];

    if(usage.first == crit)
    {
        only(enemy_id, turtle);

        std::cerr << "for enemy " << enemy_id << " uses subtle (previously crit), its possibility: ";
        output(enemy_id);
    }
    else if(usage.first == aoe)
    {
        only(enemy_id, clownfish);

        std::cerr << "for enemy " << enemy_id << " uses subtle (previously aoe), its possibility: ";
        output(enemy_id);
    }
    else if(usage.first == subtle)
    {
        only(enemy_id, mobula, octopus);

        std::cerr << "for enemy " << enemy_id << " uses subtle (previously subtle), its possibility: ";
        output(enemy_id);
    }
}

void AI::note_skill(Game& game)
{
    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    if(!enemy_action.is_skill)
        return;

    auto skill = enemy_action.type;

    enemy_skill_usage[enemy_id].record(skill);
}

void AI::analyze_enemy_action(Game& game, hps hps_mid)
{
    std::cerr << "before enemy action: \n";
    std::cerr << "our hp: " << hps_mid.first[0] << " " << hps_mid.first[1] << " " << hps_mid.first[2] << " " << hps_mid.first[3] << "\n"; 
    std::cerr << "enemy hp: " << hps_mid.second[0] << " " << hps_mid.second[1] << " " << hps_mid.second[2] << " " << hps_mid.second[3] << "\n";

    auto& enemy_action = game.enemy_action;
    auto enemy_id = enemy_action.action_fish;

    note_skill(game);
    about_attack(game);
    about_aoe(game);
    about_infight(game);
    about_crit(game, hps_mid);
    about_subtle(game);
}

void AI::analyze_previous_assert(Game& game)
{
    int assertPos = game.my_assert.assertPos;
    int assertContent = game.my_assert.assertContent;
    bool result = game.my_assert.assertResult;

    if(!(assertPos >= 0 && assertPos < 4))
        return;

    if(!(assertContent >= 1 && assertContent <= 12))
        return;

    std::cerr << "\n\nlast assert is " << assertPos << " " << assertContent << " result is " << result << "\n\n\n";

    if(result)
    {
        confirm(assertPos, assertContent);
    }
    else
    {
        fish_possible_type[assertPos][assertContent] = false;

        if(assertContent == 12)
            giveup[assertPos] = true;
    }
}

void AI::analyze(Game& game)
{
    if(new_round)
    {
        new_round = false;

        if(get_first_mover())
        {
            std::cerr << "the first turn, we go first\n";
            return;
        }
        else
        {
            std::cerr << "the first turn, we go second\n";

            analyze_enemy_action(game, both_full);
            return;
        }
    }

    analyze_previous_assert(game);

    std::vector<hps> hps_vector;
    std::vector<frame_t> frames;
    analyze_my_action(game, hps_vector, frames);

    if(hps_vector.empty())
        std::cerr << "shit! hps_vector is empty\n";

    analyze_enemy_action(game, hps_vector.back());
}

std::pair<int, int> AI::do_assertion(Game& game)
{
    for(int enemy_pos = 0; enemy_pos < 4; enemy_pos++)
    {
        if(game.enemy_fish[enemy_pos].id != -1) //already exposed
            continue;

        if(game.enemy_fish[enemy_pos].hp <= 0) //dead
            continue;

        if(giveup[enemy_pos]) //todo: eliminate this compromise
            continue;

        int should_assert = 12;
        int possibility = 0;
        for(int fish = 1; fish < 12; fish++)
        {
            if(fish_possible_type[enemy_pos][fish])
            {
                should_assert = fish;
                possibility++;
            }
        }
        if(possibility == 1)
        {
            return std::make_pair(enemy_pos, should_assert);
        }
        if(possibility == 0)
        {
            if(exist_type.find(12) != exist_type.end())
                continue;

            if(not_exist_type.find(12) != not_exist_type.end())
                continue;

            return std::make_pair(enemy_pos, 12); //imitator
        }
    }
    return std::make_pair(-1, -1);
}

std::vector<int> party1 = {whiteshark, flame, imitator + turtle, eel};
std::vector<int> party2 = {barracuda, clownfish, octopus, sunfish};
std::vector<int> party3 = {hammerhead, spray , mobula, turtle};
std::vector<std::vector<int>> parties = {party1, party2, party3};

std::vector<int> AI::Pick(Game game)
{
    init_round();

    new_round = true;

    using seed_t = std::default_random_engine::result_type;
    std::default_random_engine eng{static_cast<seed_t>(time(0))};
	std::shuffle(parties.begin(), parties.end(), eng);
    
    std::vector<int> pickfish = parties.back();
    parties.pop_back();
    std::shuffle(pickfish.begin(), pickfish.end(), eng);

    return pickfish;
}

hps AI::get_hps(Game& game)
{
    std::vector<int> first{game.my_fish[0].hp, game.my_fish[1].hp, game.my_fish[2].hp, game.my_fish[3].hp};
    std::vector<int> second{game.enemy_fish[0].hp, game.enemy_fish[1].hp, game.enemy_fish[2].hp, game.enemy_fish[3].hp};
    return std::make_pair(first, second);
}

std::pair<int, int> AI::Assert(Game game)
{
    analyze(game);
    return do_assertion(game);
}

active_skill AI::get_active(Game& game, int ally_id)
{
    int id = game.my_fish[ally_id].id;
	if (id < 0) id = -id;
	if (id == 12) id = game.avatar_id;
	switch (id)
    {
        case spray:
        case eel:
            return range_attack;
        case flame:
        case sunfish:
            return friend_attack;
        case barracuda:
            return critical_attack;
        case mobula:
        case octopus:
            return reduce_injury;
        case turtle:
            return limit_critical;
        case whiteshark:
        case hammerhead:
            return weak_critical;
        case clownfish:
        default:
            return injury_tansfer;
    }
}

int AI::skill_damage(Game& game, int ally_id)
{
    auto active = get_active(game, ally_id);
    auto skill_used = get_skill_used(ally_id);
    auto atk = get_my_atk(ally_id);

    bool self = get_my_living_ally(ally_id).empty();

    std::cerr << "active of " << ally_id << " is " << active << "\n";
    switch(active)
    {
    case active_skill::critical_attack:
        return 120;
    case active_skill::friend_attack:
        return 0;
    case active_skill::injury_tansfer:
        if(self) return 0;
        return skill_used < 3 ? (atk * 0.35) : 0;
    case active_skill::limit_critical:
        if(self) return 0;
        return skill_used < 3 ? 120 : 0;
    case active_skill::range_attack:
    {
        return atk * 0.35;
    }
    case active_skill::reduce_injury:
        return 0;
    case active_skill::weak_critical:
    {
        int enemy_id = get_lowest_health_enemy();
        int lowest_hp = get_enemy_hp(enemy_id);
        return lowest_hp < 160 ? atk * 1.4 : atk * 1.2;
    }
    default:
        return 0;
    }
}

std::vector<int> AI::possible_type_to_vec(int enemy_id)
{
    std::vector<int> vec;

    if(get_enemy_id(enemy_id) >= 1 && get_enemy_id(enemy_id) <= 11)
    {
        vec.push_back(get_enemy_id(enemy_id));
        return vec;
    }

    for(int i = 1; i <= 11; i++)
        if(fish_possible_type[enemy_id][i])
            vec.push_back(i);
    
    if(!vec.empty())
        return vec;

    if(expected_fish_type[enemy_id] >= 1 && expected_fish_type[enemy_id] <= 11)
    {
        vec.push_back(expected_fish_type[enemy_id]);
        return vec;
    }

    std::cerr << "shit! consider all\n";
    return std::vector<int>({1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11});
}

int get_lowest_health_ally(Game& game, std::vector<int> ally_ids)
{
    int min_health = 114514;
    int chosen = -1;
    for(auto ally_id: ally_ids)
    {
        if(game.my_fish[ally_id].hp < min_health)
        {
            chosen = ally_id;
            min_health = game.my_fish[ally_id].hp;
        }
    }
    return chosen;
}

int AI::enemy_damage_modify_type(Game& game, int enemy_id, fish_type type, int original_damage)
{
    switch(type)
    {
    case spray:
    case flame:
    case eel: //todo
    case sunfish: //todo
    case hammerhead:
    case clownfish:
        return original_damage;
    case barracuda:
    case mobula:
    case turtle:
        return original_damage * 0.7;
    case octopus:
    case whiteshark:
        return original_damage - 20;
    default:
        std::cerr << "shit! damage modify wrong\n";
        return original_damage;
    }
}

int AI::enemy_threat_type(Game& game, int enemy_id, fish_type type)
{
    int skill_used = enemy_skill_usage[enemy_id].use_num;
    int damage_200_taken = enemy_skill_usage[enemy_id].damage_taken / 200;

    //attack threat
    int attack = 0;
    switch(type)
    {
    case spray:
    case barracuda:
    case turtle:
    case whiteshark:
    case clownfish:
        attack = 100;
        break;
    case flame:
        attack = 100 + skill_used * 70;
        break;
    case eel:
        attack = 100 + damage_200_taken * 20;
        break;
    case sunfish:
        attack = 100 + skill_used * 70 + damage_200_taken * 20;
        break;
    case mobula:
    case octopus:
        attack = 100 + skill_used * 20;
        break;
    case hammerhead:
        attack = 100 + (get_enemy_hp(enemy_id) < 80 ? 15 : 0);
        break;
    default:
        std::cerr << "shit! attack wrong\n";
        break;
    }
    int attack_threat = attack / 2;

    //skill threat
    int my_living = get_my_living_fishes().size();
    int skill_threat = 0;
    switch(type)
    {
    case spray:
    case eel:
        skill_threat = attack * 0.35 * my_living;
        break;
    case clownfish:
        skill_threat = skill_used < 3 ? attack * 0.35 * my_living : 0;
        break;
    case barracuda:
        skill_threat = 120;
        break;
    case turtle:
        skill_threat = skill_used < 3 ? 120 : 0;
        break;
    case whiteshark:
    case hammerhead:
    {
        int min_hp_ally = get_lowest_health_ally(game, get_my_living_fishes());
        int min_hp = get_my_hp(min_hp_ally);
        skill_threat = min_hp < 160 ? attack * 1.4 : attack * 1.2;
        break;
    }
    case flame:
    case sunfish:
    case mobula:
    case octopus:
        skill_threat = 0;
        break;
    default:
        std::cerr << "shit! skill wrong\n";
        break;
    }

    return std::max({attack_threat, skill_threat});
}

int AI::ally_threat(Game& game, int ally_id)
{
    int type = game.my_fish[ally_id].id;
	if (type < 0) type = -type;
	if (type == 12) type = game.avatar_id;

    int skill_used = get_skill_used(ally_id);

    //attack threat
    int attack = get_my_atk(ally_id);
    int attack_threat = attack / 2;

    //skill threat
    int enemy_living = get_enemy_living_fishes().size();
    int skill_threat = 0;
    switch(type)
    {
    case spray:
    case eel:
        skill_threat = attack * 0.35 * enemy_living;
        break;
    case clownfish:
        skill_threat = skill_used < 3 ? attack * 0.35 * enemy_living : 0;
        break;
    case barracuda:
        skill_threat = 120;
        break;
    case turtle:
        skill_threat = skill_used < 3 ? 120 : 0;
        break;
    case whiteshark:
    case hammerhead:
    {
        int min_hp_enemy = get_lowest_health_enemy();
        int min_hp = get_enemy_hp(min_hp_enemy);
        skill_threat = min_hp < 160 ? attack * 1.4 : attack * 1.2;
        break;
    }
    case flame:
    case sunfish:
    case mobula:
    case octopus:
        skill_threat = 0;
        break;
    default:
        std::cerr << "shit! skill wrong\n";
        break;
    }

    return std::max({attack_threat, skill_threat});
}

int AI::enemy_damage_modify(Game& game, int enemy_id, int original_damage)
{
    auto possible_types = possible_type_to_vec(enemy_id);
    int num_possible_types = possible_types.size();

    if(num_possible_types == 0)
        std::cerr << "shit! no possible types\n";

    int damage_sum = 0;

    for(auto possible_type : possible_types)
        damage_sum += enemy_damage_modify_type(game, enemy_id, fish_type(possible_type), original_damage);
    
    return damage_sum / num_possible_types;
}

int AI::enemy_threat(Game& game, int enemy_id)
{
    auto possible_types = possible_type_to_vec(enemy_id);
    int num_possible_types = possible_types.size();

    if(num_possible_types == 0)
        std::cerr << "shit! no possible types\n";

    int threat_sum = 0;

    for(auto possible_type : possible_types)
        threat_sum += enemy_threat_type(game, enemy_id, fish_type(possible_type));
    
    return threat_sum / num_possible_types;
}

bool AI::is_safe(Game& game, step_t& step)
{
    if(!step.is_skill)
        return true;
    
    auto active = get_active(game, step.mover);
    int used = get_skill_used(step.mover);
    switch(active)
    {
    case active_skill::critical_attack:
    case active_skill::friend_attack:
    case active_skill::range_attack:
    case active_skill::reduce_injury:
    case active_skill::weak_critical:
    default:
        return used > 0;
    case active_skill::injury_tansfer:
    case active_skill::limit_critical:
        return used > 0 && used != 3;
    }
}

const int HEAL_EFFECT = 20;
const int REDUCE_EFFECT = 35; //?
const int ATTACKUP_EFFECT = 10; //half of 20

void AI::best_motion(Game& game, Action& action)
{
    std::cerr << "best attack called\n";

    auto living_allies = get_my_living_fishes();
    auto living_enemies = get_enemy_living_fishes();

    int enemy_threats[4];
    for(auto enemy_id: living_enemies)
        enemy_threats[enemy_id] = enemy_threat(game, enemy_id);

    int ally_threats[4];
    for(auto ally_id: living_allies)
        ally_threats[ally_id] = ally_threat(game, ally_id);

    std::vector<step_t> available_steps;

    for(auto ally_id: living_allies)
    {
        const auto& ally = game.my_fish[ally_id];
        auto ally_attack_damage = ally.atk / 2;
        std::cerr << "attack of " << ally_id << " deals " << ally_attack_damage << "\n";

        for(auto enemy_target: living_enemies)
        {
            int modified_damage = enemy_damage_modify(game, enemy_target, ally_attack_damage);
            int attack_effect = enemy_threats[enemy_target] * modified_damage; //todo
            available_steps.push_back(step_t(ally_id, attack_effect, -1, enemy_target, false));
        }

        auto ally_skill_damage = skill_damage(game, ally_id);
        std::cerr << "skill" << game.my_fish[ally_id].active << " of " << ally_id << " deals " << ally_skill_damage << "\n";

        switch(get_active(game, ally_id))
        {
        case active_skill::limit_critical:
            if(get_skill_used(ally_id) < 3)
            {
                for(auto ally_target : get_my_living_ally(ally_id))
                    for(auto enemy_target : living_enemies)
                    {
                        int modified_damage = enemy_damage_modify(game, enemy_target, 120);
                        int effect = enemy_threats[enemy_target] * modified_damage + ally_threats[ally_target] * HEAL_EFFECT;
                        available_steps.push_back(step_t(ally_id, effect, ally_target, enemy_target, true));
                    }
            }
            else
            {
                for(auto ally_target : get_my_living_ally(ally_id))
                {
                    int effect = ally_threats[ally_target] * HEAL_EFFECT;
                    available_steps.push_back(step_t(ally_id, effect, ally_target, -1, true));
                }
            }
            break;
        case active_skill::critical_attack:
            for(auto enemy_target : living_enemies)
            {
                int modified_damage = enemy_damage_modify(game, enemy_target, 120);
                available_steps.push_back(step_t(ally_id, enemy_threats[enemy_target] * modified_damage, -1, enemy_target, true));
            }
            break;
        case active_skill::injury_tansfer:
            if(get_skill_used(ally_id) < 3)
            {
                int effect = 0;
                for(auto enemy_target: living_enemies)
                {
                    int modified_damage = enemy_damage_modify(game, enemy_target, ally.atk * 0.35);
                    effect += enemy_threats[enemy_target] * modified_damage;
                }
                
                for(auto ally_target : get_my_living_ally(ally_id))
                {
                    available_steps.push_back(step_t(ally_id, effect, ally_target, -2, true));
                }
            }
            break;
        case active_skill::range_attack:
        {
            int effect = 0;
            for(auto enemy_target: living_enemies)
            {
                int modified_damage = enemy_damage_modify(game, enemy_target, ally.atk * 0.35);
                effect += enemy_threats[enemy_target] * modified_damage;
            }
            available_steps.push_back(step_t(ally_id, effect, -1, -2, true));
            break;
        }
        case active_skill::reduce_injury:
        {
            int attackup_effect = get_my_hp(ally_id) * ATTACKUP_EFFECT;
            for(auto ally_target : living_allies)
            {
                int reduce_effect = ally_threats[ally_target] * REDUCE_EFFECT;
                available_steps.push_back(step_t(ally_id, attackup_effect + reduce_effect, ally_target, -1, true));
            }
            break;
        }
        case active_skill::weak_critical:
        {
            auto enemy_targets = get_lowest_health_enemies();
            for(auto enemy_target : enemy_targets)
            {
                int modified_damage = enemy_damage_modify(game, enemy_target, ally_skill_damage);
                int effect = enemy_threats[enemy_target] * modified_damage;
                available_steps.push_back(step_t(ally_id, effect, -1, enemy_target, true));
            }
            break;
        } 
        }
    }

    for(auto& step : available_steps)
    {
        if(is_safe(game, step))
            step.effect *= 1.5;
    }

    int max_effect = -1;
    step_t* chosen_step = nullptr;
    for(auto& step : available_steps)
    {
        if(step.effect > max_effect)
        {
            max_effect = step.effect;
            chosen_step = &step;
        }
    }

    if(chosen_step->is_skill)
        std::cerr << "we choose " << chosen_step->mover << " to use " << game.my_fish[chosen_step->mover].active << "\n";
    else
        std::cerr << "we choose " << chosen_step->mover << " to attack\n";

    action.set_action_fish(chosen_step->mover);
    action.set_action_type(chosen_step->is_skill ? 1 : 0);

    if(chosen_step->enemy != -1)
    {
        std::cerr << "we choose enemy " << chosen_step->enemy << "\n";
        action.set_enemy_target(chosen_step->enemy);
    }

    if(chosen_step->ally != -1)
    {
        std::cerr << "we choose ally " << chosen_step->enemy << "\n";
        action.set_friend_target(chosen_step->ally);
    }
}

Action AI::Act(Game game)
{
    last_turn_hps = get_hps(game);

    Action action(game);
    best_motion(game, action);
    return action;
}
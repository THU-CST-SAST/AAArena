#include "Action.hpp"
#include <algorithm>
#include <vector>
//#include "main.cpp"
using namespace std;


std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    if(game.round==1){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(8);
        pickfish.push_back(3);
        pickfish.push_back(10);
        pickfish.push_back(4);
        return pickfish;
    }
    if(game.round==2){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(17);
        pickfish.push_back(7);
        pickfish.push_back(6);
        pickfish.push_back(11);
        return pickfish;
    }
    std::vector<int> pickfish;
    pickfish.clear();
    pickfish.push_back(2);
    pickfish.push_back(5);
    pickfish.push_back(9);
    pickfish.push_back(1);
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    if(game.my_assert.assertResult){
        hasasserted[game.my_assert.assertContent]=true;
        hasuncover[game.my_assert.assertPos]=true;
        for(int i=0;i<4;i++){
            for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                    if (*iter == game.my_assert.assertContent){
                        iter = present[i].possible.erase(iter);
                        break;                   //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                }
            }
        }
    }
    for(int i=0;i<game.enemy_action.num_enemy_passives;i++){
        if(present[game.enemy_action.enemy_passives_id[i]].passivetimes<4)
        {
            present[game.enemy_action.enemy_passives_id[i]].passive_before
            [sum[game.enemy_action.enemy_passives_id[i]]]=
            game.enemy_action.enemy_types[num];
            sum[game.enemy_action.enemy_passives_id[i]]++;
            num++;
        }
        else{
            present[game.enemy_action.enemy_passives_id[i]].passive_after
            [sum[game.enemy_action.enemy_passives_id[i]]]=
            game.enemy_action.enemy_types[num];
            sum[game.enemy_action.enemy_passives_id[i]]++;
            num++;
        }
    }
    if(game.enemy_action.is_skill){
        if(present[game.enemy_action.action_fish].activetimes<4)
        present[game.enemy_action.action_fish].active_before=game.enemy_action.type;
        else present[game.enemy_action.action_fish].active_after=game.enemy_action.type;
    }
    for(int i=0;i<4;i++){
        if(hasuncover[i]==false){
            if(present[i].active_before==aoe){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 2||*iter == 4||*iter == 5||*iter == 6||*iter == 7||*iter == 8
                            ||*iter == 9||*iter == 10){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            if(present[i].active_before==infight){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 3||*iter == 5||*iter == 6||*iter == 7||*iter == 8
                            ||*iter == 9||*iter == 10||*iter == 11){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            if(present[i].active_before==crit){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 2||*iter == 3||*iter == 4||*iter == 7||*iter == 8
                            ||*iter == 6||*iter == 11){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            if(present[i].active_before==subtle){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 3||*iter == 5||*iter == 2||*iter == 4
                            ||*iter == 9||*iter == 10||*iter == 11){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            if(present[i].active_before==crit&&present[i].active_after==subtle){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 3||*iter == 5||*iter == 2||*iter == 4
                            ||*iter == 9||*iter == 10||*iter == 11||*iter == 6||*iter == 8){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            if(present[i].active_before==aoe&&present[i].active_after==subtle){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 3||*iter == 5||*iter == 2||*iter == 4
                            ||*iter == 9||*iter == 10||*iter == 7||*iter == 6||*iter == 8){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            bool findcounter=false;
            for(int j=0;j<present[i].passive_before.size();j++){
                if(present[i].passive_before[j]==counter){
                    findcounter=true;
                    break;
                }
            }
            if(findcounter){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 4||*iter == 3||*iter == 5||*iter == 6||*iter == 7||*iter == 8
                            ||*iter == 9||*iter == 10){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            bool finddeflect=false;
            for(int j=0;j<present[i].passive_before.size();j++){
                if(present[i].passive_before[j]==deflect){
                    finddeflect=true;
                    break;
                }
            }
            if(finddeflect){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 1||*iter == 2||*iter == 5||*iter == 6||*iter == 7||*iter == 8
                            ||*iter == 9||*iter == 10||*iter == 11){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            bool findreduce=false;
            for(int j=0;j<present[i].passive_before.size();j++){
                if(present[i].passive_before[j]==reduce){
                    findreduce=true;
                    break;
                }
            }
            if(findreduce){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 4||*iter == 3||*iter == 1||*iter == 2||*iter == 11||*iter == 8
                            ||*iter == 9||*iter == 10){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            bool findheal=false;
            for(int j=0;j<present[i].passive_before.size();j++){
                if(present[i].passive_before[j]==heal){
                    findheal=true;
                    break;
                }
            }
            if(findheal){
                for (vector<int>::iterator iter = present[i].possible.begin(); iter != present[i].possible.end();iter++) {
                        if (*iter == 4||*iter == 3||*iter == 5||*iter == 6||*iter == 7||*iter == 1
                            ||*iter == 2||*iter == 10||*iter == 11){
                            iter = present[i].possible.erase(iter);
                            iter--;                    //erase函数的返回指向当前被删除元素的下一个元素的迭代器
                    }
                }
            }
            bool findexplode=false;
            for(int j=0;j<present[i].passive_before.size();j++){
                if(present[i].passive_before[j]==explode){
                    findexplode=true;
                    break;
                }
            }
            if(findexplode){
                hasasserted[10]=true;
            }
        }
        if(present[i].possible.size()<=3){//此处可改
            for(int j=0;j<present[i].possible.size();j++){
                if(present[i].possible[j]!=0){
                int temp=present[i].possible[j];
                present[i].possible[j]=0;
                return make_pair(i, temp);
                }
            }
        }
    }
    return make_pair(-1,-1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    if(game.round == 1){
        Action action(game);
        int my_hp = get_my_hp(0);
        if(my_hp>350){
            action.set_action_fish(1);
            action.set_action_type(1);
            return action;
        }
        int my_atk = get_my_atk(0);
        int enemy_hp[4] = {0};
        int min=400;
        int k=0;
        for(int i=0;i<4;i++){
            enemy_hp[i]=get_enemy_hp(i);
            if(enemy_hp[i]<min && enemy_hp[i]> 0){
                min=enemy_hp[i];
                k=i;
            }
        }
        if(my_atk>=min*2){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
        action.set_action_fish(0);
        action.set_action_type(1);
        action.set_friend_target(0);
        return action;
    }
    
    if(game.round==2){
        Action action(game);
        int my_hp = get_my_hp(1);
        int skill_used_times = get_skill_used(1);
        if(my_hp>0 && skill_used_times<3){
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(k);
                return action;
            }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_friend_target(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        
        my_hp = get_my_hp(0);
        if(my_hp>0){
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        
        my_hp = get_my_hp(1);
        if(my_hp>0){
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(lowest_health_enemy);
                return action;
        }
        
        my_hp = get_my_hp(2);
        if(my_hp>0){
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(lowest_health_enemy);
                return action;
        }
        
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(lowest_health_enemy);
                return action;
    }
    
    Action action(game);
    int my_hp = get_my_hp(1);
    if(my_hp>0){
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }
        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(1);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }
    
    my_hp = get_my_hp(2);
    if(my_hp>0){
    int enemy_id = get_enemy_id(0);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(0);
        return action;
    }
    enemy_id = get_enemy_id(1);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(1);
        return action;
    }
    enemy_id = get_enemy_id(2);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(2);
        return action;
    }
    enemy_id = get_enemy_id(3);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(3);
        return action;
    }
    if(game.enemy_action.type==infight){
        int k=game.enemy_action.action_fish;
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(k);
        return action;
    }
        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }
    
    my_hp = get_my_hp(0);
    if(my_hp>0){
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
    }
    
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
}


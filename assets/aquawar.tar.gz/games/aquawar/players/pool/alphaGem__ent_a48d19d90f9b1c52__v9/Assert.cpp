#include"Game.cpp"

map<Game,double> cur,nxt;

bool asserted[4],discovered[15];

bool fm;

void DFSAssert(Game game, int pos, double p)
{
	if(pos==4)
	{
		if(!fm)game.swap_edge();
		cur[game]=p;
		return;
	}
	for(int i=1;i<=12;++i)
	{
		bool flag=true;
		if(discovered[i])flag=false;
		for(int j=0;j<pos;++j)if(game.sore.fish[j].real_id==i)flag=false;
		if(!flag)continue;
		if(i<=11)
		{
			game.sore.fish[pos]=CreateFishById(i);
			DFSAssert(game,pos+1,p);
		}
		else
		{
			for(int j=1;j<=11;++j)
			{
				game.sore.fish[pos]=CreateFishById(i+j);
				DFSAssert(game,pos+1,p/25.);
			}
		}
	}
}

int cr=1;
void InitAssert(vector<int> x,bool first_mover)
{
	fm=first_mover;
	cur.clear();
	nxt.clear();
	for(int i=0;i<4;++i)asserted[i]=false;
	Game game;
	for(int i=0;i<4;++i)
	{
		game.kore.fish[i]=CreateFishById(x[i]);
		////cerr << i << " ~-~ " << x[i] << endl;;
	}
	//QAQ
	/*if(cr==1)
	{
		for(int i=1;i<=4;++i)game.sore.fish[i-1]=CreateFishById(i);
		if(!fm)game.swap_edge();
		cur[game]=1;
	}
	else */
	DFSAssert(game,0,1);
	cerr << "Init size " << cur.size() << endl;
	++cr;
}

void SendAssertInfo(Json::Value json,int side)
{
	if(json["AssertPos"].isNull())return;
	
	int pos=json["AssertPos"].asInt();
    int que=json["AssertContent"].asInt();
   	bool suc=json["AssertResult"].asBool();
	if(side==0&&suc)asserted[pos]=true;
	Process proc;
	nxt.clear();
	for(auto g:cur)
	{
		if(proc.doAssertion(g.first,pos,que,suc))
			nxt[proc.game]+=g.second;
	}
	swap(cur,nxt);
	nxt.clear();
	cerr << "After Assert size " << cur.size() << endl;
}


Info pas[111],hit[111];

void SendActionInfo(Json::Value info,int Mtar,int Etar,int side)
{
	auto t0=clock();
	Process proc;
	proc.pas=pas;
	proc.hit=hit;
	int cpas=0,chit=0;
	//Json::StyledWriter wr;
	nxt.clear();
	for(auto&x:info["skill"]["targets"])
	{
		if(side)x["isEnemy"]=!(x["isEnemy"].asBool());
		x.removeMember("player");
		if(x["isEnemy"].asInt())Etar=x["pos"].asInt();
		else Mtar=x["pos"].asInt();
	}
	
	if(info.isMember("passive"))for(auto&x:info["passive"])
	{
		if(side)x["isEnemy"]=!(x["isEnemy"].asBool());
		x.removeMember("player");
		string type=x["type"].asString();
		
		pas[cpas++]=Info(type[0]^type[2],x["source"].asInt(),(x["isEnemy"].asBool()?'T':'F'),x["value"].asDouble(),x["time"].asInt());
	}
	if(info.isMember("hit"))for(auto&x:info["hit"])
	{	
		if(side)x["isEnemy"]=!(x["isEnemy"].asBool());
		x.removeMember("player");
		
		hit[chit++]=Info((x["traceable"].asBool()?'T':'F'),x["target"].asInt(),(x["isEnemy"].asBool()?'T':'F'),x["value"].asInt(),x["time"].asInt());
	}
	
	Json::StyledWriter wr;
	//cerr << "info" << wr.write(info) << endl;
	
	pas[cpas].type='E';
	hit[chit].type='E';
	
	int idd=0;
	for(auto g:cur)
	{
		++idd;
		if(idd%1000==0)cerr << "QAQ " << idd << ' ' << (clock()-t0)*1./CLOCKS_PER_SEC << endl;
		////cerr << "info:" << endl << wr.write(info) << endl;
		//x.log();
		
		auto lam=[&](int Mt,int Et,double mo) -> void
		{
			bool flg=proc.doAction(
				g.first,
				info["ActionFish"].asInt(),
				info["skill"]["isSkill"].asInt(),
				Mt,
				Et,
				0,	//det
				g.second);
			
			
			int cnt=proc.cnt;
			////cerr << "-------------cnt " << cnt << endl;
			//cerr << "proc:" << (flg?"Bon":"Mal") << endl << wr.write(proc.result_json) << endl;
			////cerr << "info:" << endl << wr.write(info) << endl;
			//if(cr>1)cerr << "possi" << g.second << " * " << proc.possi << " * " << mo << endl; 
			if(flg)
				if(proc.result_json["ActionFish"]==info["ActionFish"]&&proc.result_json["skill"]==info["skill"])
					nxt[proc.game]+=proc.possi*mo;
				
			/*for(int i=1;i<(1<<cnt);++i)
			{
				//////cerr << "-----------------------enum " <<  i << endl;
				proc.doAction(
					g.first,
					info["ActionFish"].asInt(),
					info["skill"]["isSkill"].asInt(),
					Mt,
					Et,
					i,	//det
					g.second);
					
				////cerr << "proc:" << endl << wr.write(proc.result_json) << endl;
				////cerr << "info:" << endl << wr.write(info) << endl;
				if(proc.result_json==info)
					nxt[proc.game]+=g.second*calc_possibility(cnt,i)*mo;
				
			}*/
		};
		
		if(info["skill"]["isSkill"].asInt())
		{
			auto game=g.first;
			int pos=info["ActionFish"].asInt();
			auto fish=game.kore.fish[pos];
			string type=info["skill"]["type"].asString();
			if(type=="aoe")
			{
				switch(fish.id)
				{
					case spray:
					case eel:
					case clownfish:
						break;
					default:
						goto heaven;
				}
			}
			if(type=="infight")
			{
				switch(fish.id)
				{
					case flame:
					case sunfish:
						break;
					default:
						goto heaven;
				}
			}
			if(type=="crit")
			{
				switch(fish.id)
				{
					case barracuda:
					case turtle:
						break;
					case whiteshark:
					case hammerhead:
					{
						int min_hp=2333;
						for(int i=0;i<4;++i)if(game.sore.fish[i].alive&&game.sore.fish[i].hp<min_hp)min_hp=game.sore.fish[i].hp;
						if(game.sore.fish[Etar].hp==min_hp)break;
						else goto heaven;
					}
					default:
						goto heaven;
				}
			}
			if(type=="subtle")
			{
				switch(fish.id)
				{
					case mobula:
					case turtle:
					case octopus:
					case clownfish:
						break;
					default:
						goto heaven;
				}
			}
			if(Mtar==-1)
			{
				if(fish.id==mobula||fish.id==octopus)
				{
					int cnt=0;
					for(int i=0;i<4;++i)
						if(game.kore.fish[i].alive)
							++cnt;
							
					for(int i=0;i<4;++i)
						if(game.kore.fish[i].alive)
							lam(i,Etar,1./cnt);
							
					goto heaven;
				}
				if(fish.id==turtle||fish.id==clownfish)
				{
					int cnt=0;
					for(int i=0;i<4;++i)
						if(i!=pos&&game.kore.fish[i].alive)
							++cnt;
							
					if(cnt)
					{
						for(int i=0;i<4;++i)
							if(i!=pos&&game.kore.fish[i].alive)
								lam(i,Etar,1./cnt);
					}
							
					goto heaven;
				}
			}
		}
		////cerr << "Meow!" << endl;
		lam(Mtar,Etar,1);
		heaven:;
	}
	swap(cur,nxt);
	nxt.clear();
	cerr << "After Action size " << cur.size() << endl;
	assert(cur.size());
}


int ccalc;
pair<int,int> CalcAssert()
{
	cerr.precision(3);
	++ccalc;
	int flg[4][15];
	double cnt[4][15];
	int bp=0,bq=0;
	cnt[bp][bq]=-1;
	for(int i=0;i<4;++i)
	{
		//cerr << i << " now time1 " << 1.*(clock()-t0)/CLOCKS_PER_SEC << endl;
		for(int j=1;j<=12;++j)
		{
			flg[i][j]=0;
			cnt[i][j]=0;
		}
		bool alive=false;
		for(auto g:cur)
		{
			auto&game=g.first;
			cnt[i][game.sore.fish[i].real_id]+=g.second;
			////cerr << i << " ~ " << (int)game.sore.fish[i].real_id << endl; 
			flg[i][game.sore.fish[i].real_id]=1;
			if(game.sore.fish[i].alive&&game.sore.fish[i].hp<250)alive=true;
		}
		//cerr << i << " now time2 " << 1.*(clock()-t0)/CLOCKS_PER_SEC << endl;
		int cf=0,la=0;
		double tot=0;
		for(int j=1;j<=12;++j)
		{
			tot+=cnt[i][j];
			if(flg[i][j])
			{
				++cf;
				la=j;
			}
		}
		assert(cf);
		if(cf==1)discovered[la]=true;
		////cerr << "asserted " << i << (asserted[i]?" True":" False") << endl;
		//cerr << i << " now time3 " << 1.*(clock()-t0)/CLOCKS_PER_SEC << endl;
		cerr << "Forecast on fish " << i << ":" << endl << flush;
		for(int j=1;j<=12;++j)
		{
			cerr << '(' << j << ',' << cnt[i][j] << '/' << tot << ')' << endl << flush;
			cnt[i][j]/=tot;
			assert(cnt[i][j]<1.1);
			if(!asserted[i]&&alive&&cnt[i][j]>cnt[bp][bq])
			{
				bp=i;
				bq=j;
			}
		}
	}
	if(cnt[bp][bq]>0.6)return make_pair(bp,bq);
	return make_pair(-1,-1);
}

#include<bits/stdc++.h>
#include"sdk/jsoncpp/json/json.h"
using namespace std;
enum FishType
{
	spray = 1,	//射水鱼
	flame,		//喷火鱼
	eel,		//电鳗
	sunfish,	//翻车鱼
	barracuda,	//梭子鱼
	mobula,		//蝠鲼
	turtle,		//海龟
	octopus,	//章鱼
	whiteshark, //大白鲨
	hammerhead, //锤头鲨
	clownfish,	//小丑鱼
	imitator	//拟态鱼
};
struct Fish
{
	char id=0,real_id=0,thorn=0,shell=0,skill_used=0;
	bool divide=0,armor=0,heal=0,alive=0;
	short hp=0,atk=0,damage_taken=0;
	void applyDamage(int damage)
	{
		hp-=damage;
		damage_taken+=damage;
		if((id==eel||id==sunfish)&&damage_taken>=200)
		{
			atk+=20;
			damage_taken%=200;
		}
		if(hp<0)hp=0;
	}
	int regen()
	{
		int hurt=400-hp;
		if(hp+20>400)hp=400;
		else
		{
			hp+=20;
			hurt=20;
		}
		return hurt;
	}
	void log()
	{
		fprintf(stderr,"Fish: type %d+%d, hp %d, atk %d\n",(int)id,(int)real_id,(int)hp,(int)atk);
		fflush(stderr);
	}
};
Fish CreateFishById(int id)
{
	Fish x;
	//cerr << (int)x.shell << "Create0QAQ" << endl;
	x.id=id%12;
	x.real_id=min(id,12);
	x.hp=400;
	x.atk=100;
	x.alive=true;
	if(x.id==turtle)x.shell=3;
	//cerr << (int)x.shell << "CreateQAQ" << endl;
	return x;
}

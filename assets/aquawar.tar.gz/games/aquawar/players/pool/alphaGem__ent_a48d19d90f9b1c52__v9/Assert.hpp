#include<bits/stdc++.h>
#include"sdk/jsoncpp/json/json.h"
using namespace std;

void InitAssert(vector<int> x,bool first_mover);
void SendAssertInfo(Json::Value json,int side);
void SendActionInfo(Json::Value info,int Mtar,int Etar,int side);
pair<int,int> CalcAssert();

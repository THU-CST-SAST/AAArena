#include"Fish.cpp"



struct Side
{
	Fish fish[4];
};

struct Game
{
	Side kore,sore;
	void swap_edge()
	{
		swap(kore,sore);
	}
	void log()
	{
		//cerr << endl << "log start" << endl;
		for(int i=0;i<4;++i)kore.fish[i].log();
		//cerr << "---" << endl;
		for(int i=0;i<4;++i)sore.fish[i].log();
		//cerr << "log end" << endl;
	}
};

bool operator<(const Game&a,const Game&b)
{
	return memcmp(&a,&b,sizeof(Game))<0;
}
	
struct Info
{
	
	short pos;
	short value,time;
	char type;//for passive: skill type; for hit: tracable
	char isEnemy;
	Info(){}
	Info(char T,int p,bool i,double v,int t)
	{
		type=T;
		pos=p;
		isEnemy=i?'T':'F';
		value=(short)(v+0.75);
		time=t;
	}
	void log()
	{
		//cerr << (int)type << ' ' << pos << ' ' << isEnemy << ' ' << value << ' ' << time << endl;
	}
};

bool operator==(Info a,Info b)
{
	//cerr << "Comparing: " << memcmp(&a,&b,sizeof(Info)) <<  endl;
	auto c=a;c.log();
	auto d=b;d.log();
	//cerr << endl;
	return memcmp(&a,&b,sizeof(Info))==0;
}
	


struct Process
{
	Game game;
	int tick;
	int det,cnt;
	double possi;
	Info *pas,*hit;
	int cpas,chit;
	Json::Value result_json;
	
	Json::Value skill_to_json(std::string type, std::vector<int> targets, bool side, int value, bool is_skill) {
		Json::Value json_skill, json_targets;
		json_skill["type"] = type;
		json_skill["isSkill"] = is_skill;
		for(auto i : targets) {
		    Json::Value json_target;
		    json_target["pos"] = i;
		    json_target["isEnemy"] = side;
		    json_target["value"] = value;
		    json_targets.append(json_target);
		}
		json_skill["targets"] = json_targets;
		return json_skill;
	}

	bool passive_to_json(std::string type, int source, bool side, float value) {
	
		/*Json::Value json;
		json["type"] = type;
		json["source"] = source;
		json["isEnemy"] = side;
		json["value"] = value;
		json["time"] = 1+tick;
		Json::StyledWriter wr;*/
		//cerr << "passive" << wr.write(json) << endl;
		//return json;
		
		if(pas[cpas]==Info(type[0]^type[2],source,(side?'T':'F'),value,++tick))
		{
			//cerr << "OK" << endl;
			++cpas;
			return true;
		}
		else return false;
		
		
	}

	Json::Value hit_to_json(int target, bool side, int value, bool traceable) {
	
		/*Json::Value json;
		json["target"] = target;
		json["isEnemy"] = side;
		json["value"] = value;
		json["traceable"] = traceable;
		json["time"] = 1+tick;
		Json::StyledWriter wr;*/
		//cerr << "hit" << wr.write(json) << endl;
		//return json;
	
		if(hit[chit]==Info((traceable?'T':'F'),target,(side?'T':'F'),value,++tick))
		{
			//cerr << "OK" << endl;
			++chit;
			return true;
		}
		else return false;
		
		
	}

	/*void add_json(Json::Value a, Json::Value b) {
		for(auto i : b["passive"]) {
		    a["passive"].append(i);
		}
		for(auto i : b["hit"]) {
		    a["hit"].append(i);
		}
	}*/
	
	bool take_damage(Json::Value&json,int side,int pos,int source,int dmg)
	{
		auto&fish=(side?game.sore:game.kore).fish[pos];
		//盾
		////cerr << (int)fish.shell << "QAQ" << endl;
		if(fish.shell)
		{
			--fish.shell;
			/*json["passive"].append*/if(!passive_to_json("reduce",pos,side,0))return false;
			/*json["hit"].append*/if(!hit_to_json(pos,side,0,(source!=-1)))return false;
			goto slippery;
		}
		//闪
		if(fish.id==barracuda||fish.id==mobula||fish.id==turtle)
		{
			if(det==-1)//randomly choose a result
			{
				//TODO: complete it
			}
			else
			{
				//int qwq=(det>>(cnt++))&1;
				//if(qwq)//闪开了
				//{
				//	/*json["passive"].append*/(passive_to_json("reduce",pos,side,0));
				//	/*json["hit"].append*/(hit_to_json(pos,side,0,(source!=-1)));
				//	goto slippery;
				//}
				
				int tcpas=cpas,tchit=chit,ttick=tick;
				if(passive_to_json("reduce",pos,side,0)&&hit_to_json(pos,side,0,(source!=-1)))
				{
					possi*=0.3;
					goto slippery;
				}
				possi*=0.7;
				cpas=tcpas;
				chit=tchit;
				tick=ttick;
				
			}
		}
		//被动承伤、印记前半段
		if(source!=-1)
		{
			assert(side);
			if(fish.id==eel||fish.id==sunfish)
			{
				int c=0;
				for(int i=0;i<4;++i)if(i!=pos&&game.sore.fish[i].alive)++c;
				if(c>0)//有队友
				{
					int grand=dmg*0.7;
					int petit=dmg*0.3;
					petit=petit/c;
					/*json["passive"].append*/if(!passive_to_json("deflect",pos,side,grand))return false;
					for(int i=0;i<4;++i)if(i!=pos&&game.sore.fish[i].alive)
					{
						if(!take_damage(json,side,i,-1,petit))return false;
					}
					dmg=grand;
				}
			}
			
			if(fish.armor)
			{
				fish.armor=false;
				dmg*=0.3;
				/*json["passive"].append*/if(!passive_to_json("reduce",pos,side,0.3))return false;
			}
			
			if(fish.divide)
			{
				int c=0;
				for(int i=0;i<4;++i)if(i!=pos&&game.sore.fish[i].alive)++c;
				if(c>0)//有队友
				{
					fish.divide=false;
					int grand=dmg*0.7;
					int petit=dmg*0.3;
					petit=petit/c;
					/*json["passive"].append*/if(!passive_to_json("deflect",pos,side,dmg))return false;
					for(int i=0;i<4;++i)if(i!=pos&&game.sore.fish[i].alive)
					{
						if(!take_damage(json,side,i,-1,petit))return false;
					}
					dmg=grand;
				}
			}
		}
	
		//造成伤害
		/*json["hit"].append*/if(!hit_to_json(pos,side,dmg,(source!=-1)))return false;
		fish.applyDamage(dmg);
		
		//回血印记，爆炸，主动反伤
		if(source!=-1)
		{
			assert(side);
			if(fish.heal&&fish.hp>0)
			{
				fish.heal=false;
				/*json["passive"].append*/if(!passive_to_json("heal",pos,side,fish.regen()))return false;
			}
			if(fish.id==hammerhead&&fish.hp<=0)
			{
				/*json["passive"].append*/if(!passive_to_json("explode",pos,side,40))return false;
				if(!take_damage(json,0,source,-1,40))return false;
			}
			
			if(fish.id==clownfish&&fish.hp<400*0.3)
			{
				/*json["passive"].append*/if(!passive_to_json("counter",pos,side,30))return false;
				if(!take_damage(json,0,source,-1,30))return false;
			}
		}
		//回血被动
		if((fish.id==octopus||fish.id==whiteshark)&&fish.hp>0)
		{
			/*json["passive"].append*/if(!passive_to_json("heal",pos,side,fish.regen()))return false;
		}
		
		slippery:;
		//被动反伤
		if(source!=-1&&fish.hp<400*0.3)
		{
			assert(side);
			for(int i=0;i<4;++i)if(i!=pos&&game.sore.fish[i].alive)
			{
				if(game.sore.fish[i].id==spray||game.sore.fish[i].id==flame)
				{
					/*json["passive"].append*/if(!passive_to_json("counter",pos,side,30))return false;
					if(!take_damage(json,0,source,-1,30))return false;
				}
			}
		}
		return true;
	}
	
	bool doAction(Game g,int pos,int is_skill,int Mtarget,int Etarget,int _det,double p)
	{
		game=g;
		tick=0;
		det=_det;
		cnt=0;
		possi=p;
		cpas=chit=0;
		Json::Value json;
		json["ActionFish"]=pos;
		auto&fish=game.kore.fish[pos];
		vector<int>target;
		target.clear();
		if(!is_skill)
		{
			int dmg;
			if(fish.id==hammerhead && fish.hp*5<400)dmg=(fish.atk+15)/2;
			else dmg=fish.atk/2;
			if(!take_damage(json,1,Etarget,pos,dmg))return false;
			target.push_back(Etarget);
			json["skill"]=skill_to_json("normalattack",target,1,dmg,0);
		}
		else
		{
			fish.skill_used++;
			////cerr << "ID " << (int)fish.id << endl;
			switch(fish.id)
			{
				case clownfish:
				{
					if(game.kore.fish[Mtarget].divide)
					{
						if(fish.skill_used>3)possi*=0.6;
						else possi*=0.9;
					}
					game.kore.fish[Mtarget].divide=true;
					if(fish.skill_used>3)
					{
						//assert(Etarget==-1);
						json["skill"]=skill_to_json("subtle",vector<int>(),0,0,1);
						break;
					}
					for(int i=0;i<4;++i)
					{
						if(game.sore.fish[i].alive)
						{
							target.push_back(i);
							if(!take_damage(json,1,i,pos,35))return false;
						}
					}
					json["skill"]=skill_to_json("aoe",target,1,35,1);
					break;
				}
					
				case spray:
				{
					assert(Mtarget==-1);
					//assert(Etarget==-2);
					vector<int>target;
					for(int i=0;i<4;++i)
					{
						if(game.sore.fish[i].alive)
						{
							target.push_back(i);
							if(!take_damage(json,1,i,pos,35))return false;
						}
					}
					json["skill"]=skill_to_json("aoe",target,1,35,1);
					break;
				}
					
				case eel:
				{
					assert(Mtarget==-1);
					//assert(Etarget==-2);
					int now_atk=fish.atk;
					for(int i=0;i<4;++i)
					{
						if(game.sore.fish[i].alive)
						{
							target.push_back(i);
							if(!take_damage(json,1,i,pos,now_atk*0.35))return false;
						}
					}
					now_atk=now_atk*0.35;
					json["skill"]=skill_to_json("aoe",target,1,now_atk,1);
					break;
				}
					
				case turtle:
					if(game.kore.fish[Mtarget].heal)
					{
						if(fish.skill_used>3)possi*=0.6;
						else possi*=0.9;
					}
					game.kore.fish[Mtarget].heal=true;
					if(fish.skill_used>3)
					{
						//assert(Etarget==-1);
						json["skill"]=skill_to_json("subtle",vector<int>(),0,0,1);
						break;
					}
				case barracuda:
					if(!take_damage(json,1,Etarget,pos,120))return false;
					target.push_back(Etarget);
					json["skill"]=skill_to_json("crit",target,1,120,1);
					break;
					
				case hammerhead:
				{
					int hit=0;
					if(fish.hp*5<400)hit=15;
					float addition=1.2;
					int now_atk=(fish.atk+hit)*1.2;
					if(game.sore.fish[Etarget].hp < 400*0.4)
					{
						addition=1.4;
						now_atk=(fish.atk+hit)*1.4;
					}
					if(!take_damage(json,1,Etarget,pos,now_atk))return false;
					target.push_back(Etarget);
					json["skill"]=skill_to_json("crit",target,1,now_atk,1);
					break;
				}
				
				case whiteshark:
				{
					float addition=1.2;
					int now_atk=fish.atk*1.2;
					if(game.sore.fish[Etarget].hp < 400*0.4)
					{
						addition=1.4;
						now_atk=fish.atk*1.4;
					}
					if(!take_damage(json,1,Etarget,pos,now_atk))return false;
					target.push_back(Etarget);
					json["skill"]=skill_to_json("crit",target,1,now_atk,1);
					break;
				}
				
				case flame:
				case sunfish:
				{
					if(!take_damage(json,0,Mtarget,-1,50))return false;
					fish.atk+=70;
					target.push_back(Mtarget);
					json["skill"]=skill_to_json("infight",target,0,50,1);
					break;
				}
				
				case mobula:
				case octopus:
				{
					game.kore.fish[Mtarget].armor=1;
					fish.atk+=20;
					json["skill"]=skill_to_json("subtle",vector<int>(),0,0,1);
					break;
				}
					
			}
		}
		if(pas[cpas].type!='E'||hit[chit].type!='E')return false;
		result_json=json;
		for(int i=0;i<4;++i)
		{
			if(game.kore.fish[i].hp<=0)game.kore.fish[i].alive=false;
			if(game.sore.fish[i].hp<=0)game.sore.fish[i].alive=false;
		}
		game.swap_edge();
		////cerr << "Grand Success" << endl;
		return true;
	}
	
	bool doAssertion(Game g,int pos,int que,bool success)
	{
		game=g;
		if(pos!=-1)
		{
			if(success)
			{
				if(game.sore.fish[pos].real_id!=que)return false;
				for(int i=0;i<4;++i)
				{
					game.sore.fish[i].hp-=50;
					if(game.sore.fish[i].hp<=0)
					{
						game.sore.fish[i].hp=0;
						game.sore.fish[i].alive=false;
					}
				}
			}
			else
			{
				if(game.sore.fish[pos].real_id==que)return false;
				for(int i=0;i<4;++i)
				{
					game.kore.fish[i].hp-=50;
					if(game.kore.fish[i].hp<=0)
					{
						game.kore.fish[i].hp=0;
						game.kore.fish[i].alive=false;
					}
				}
			}
		}
		return true;
	}
};
//int main(){}

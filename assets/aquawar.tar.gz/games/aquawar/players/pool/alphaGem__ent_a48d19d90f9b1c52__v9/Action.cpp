#include "Action.hpp"
#include "Assert.hpp"
#include <algorithm>

int cgame;
int cround;

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    
    ++cgame;
    std::vector<int> pickfish;
    
    if(cgame==1)
    {
    	pickfish.push_back(spray);
    	pickfish.push_back(hammerhead);
    	pickfish.push_back(imitator+barracuda);
    	pickfish.push_back(turtle);
	}
    if(cgame==2)
    {
    	pickfish.push_back(eel);
    	pickfish.push_back(whiteshark);
    	pickfish.push_back(octopus);
    	pickfish.push_back(barracuda);
    }
    if(cgame==3)
    {
    	pickfish.push_back(clownfish);
    	pickfish.push_back(flame);
    	pickfish.push_back(sunfish);
    	pickfish.push_back(mobula);
    }
    
    InitAssert(pickfish,game.first_mover);
    cround=0;
    return pickfish;
}


/*
void InitAssert(vector<int> x,int first_mover);
void SendAssertInfo(int pos,int que,bool suc,int side);
void SendActionInfo(Json::Value info,int Mini,int Eini);
pair<int,int> CalcAssert();
*/
int lam,lae;
std::pair<int, int> AI::Assert(Game game)
{
	auto t0=clock();
    // TODO: fill your code
    cerr << endl << endl << "ROUND: " << cround+1 << ' ' << game.first_mover << endl;
    
    if(cround)
    {
    	SendActionInfo(root["MyAction"],lam,lae,0);
    }
    if(cround||!game.first_mover)
    {
    	SendAssertInfo(root["EnemyAssert"],1);
    	SendActionInfo(root["EnemyAction"],-1,-1,1);
    }
    
    ++cround;
    auto qwq=CalcAssert();
    cerr << "TIME USED: " << 1.*(clock()-t0)/CLOCKS_PER_SEC << endl << flush;
    return qwq;
}

Action AI::Act(Game game)
{
    // TODO: fill your code
	SendAssertInfo(root["AssertReply"],0);

    lam=-1;
    lae=-1;
    Action action(game);
    int my_pos = (get_my_living_fishes())[0];
    action.set_action_fish(my_pos);
    if(cround<=3)
    {
    	action.set_action_fish(0);
    	action.set_action_type(1);
    	if(cgame==3)action.set_friend_target(1);
    	action.set_enemy_target(-2);
    }
    else auto_valid_action(my_pos, &action);
    lam = action.get_friend_target();
    lae = action.get_enemy_target();
    return action;
}

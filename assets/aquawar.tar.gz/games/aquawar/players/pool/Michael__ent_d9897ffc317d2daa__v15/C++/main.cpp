#include "Action.hpp"
#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <queue>

using namespace std;


int times=0;
//

//
bool asserted[13];
bool is_first_move;

int ally[4];


struct Fish_data {

    int pos;

    int active=-1;
    bool need_spj = false;
    int passive=-1;

    bool tried[13] = { 1,0,0,0,0,0,0,0,0,0,0,0,0 };
    bool revealed = false;
    int identity = 0;

    int active_count = 0;
    int escape_count = 0;
    int escape1_3[3] = { -1,-1,-1 };
    int attacked_count = 0;

    int direct_tiggled = -1;

    //上一次主动攻击最大伤害
    int last_hurt = 0;
    

    void update(Game game)
    {
        //refresh last assert info
        if (game.my_assert.assertContent!=0)
        {
            if (game.my_assert.assertPos == pos)
            {
                if (game.my_assert.assertResult == true)
                {
                    identity = game.my_assert.assertContent;
                    revealed = true;
                    asserted[identity] = true;
                    return;
                }
                else
                {
                    tried[game.my_assert.assertContent] = true;
                }

            }
        }
        //refresh enemy active skill
        if (game.enemy_action.action_fish == pos)
        {
            if (game.enemy_action.is_skill)
            {
                if (active == -1)
                    active = game.enemy_action.type;
                else if (game.enemy_action.type != active)
                    need_spj = true;

                active_count++;
            }
            //TODO does "friend" in "enemy_action" refere to myself?
            //refresh enemy atk
            last_hurt = 0;
            for (int i = 0; i < 4; i++)
            {
                int delta = ally[i] - game.my_fish[i].hp;
                last_hurt = (last_hurt > delta) ? last_hurt : delta;
            }

        }
        

        
        //refresh enemy passive/*

        int p_num = game.my_action.num_enemy_passives;
        std::array<int, 24> p_id = game.my_action.enemy_passives_id;
        std::array<passive_type, 24> p_type = game.my_action.enemy_types;
        for (int i = 0; i < p_num; i++)
        {
            if (p_id[i] == pos)
            {
                //if (passive == -1)
                    passive = p_type[i];

                if (passive == reduce)
                {
                    escape_count++;

                    if (attacked_count < 3)
                        escape1_3[attacked_count] = true;
                }
                else
                {
                    if (attacked_count < 3)
                        escape1_3[attacked_count] = false;
                }
            }
            //refresh if enemy was attacked and if it was direct attacked
            
            bool found = false;
            int tar_num = game.my_action.num_enemy_targets;
            std::array<int, 12> tar_id = game.my_action.enemy_targets;
            for (int i = 0; i < tar_num; i++)
            {
                if (tar_id[i] == pos)
                {
                    found = true;
                    //record times being attacked
                    attacked_count++;
                }
            }
            
            if (found == true && game.my_action.type != aoe&& game.my_action.type!=subtle)
            {
                direct_tiggled = true;
            }
            else
            {
                direct_tiggled = false;
            }
        }
        
    }

    void debug()
    {
        std::cerr << pos << ":";
        if (active == aoe)
            std::cerr << "aoe  ";
        if (active == crit)
            std::cerr << "crit ";
        if (active == infight)
            std::cerr << "infi ";
        if (active == subtle)
            std::cerr << "sub  ";

        if (passive == heal)
            std::cerr << "heal ";
        if (passive == counter)
            std::cerr << "coun ";
        if (passive == reduce)
            std::cerr << "redu ";
        if (passive == deflect)
            std::cerr << "defl ";
        if (passive == explode)
            std::cerr << "expl ";


        std::cerr <<endl<<"a_count "<< active_count << " e_count " << escape_count << "  " << escape1_3[0] << escape1_3[1] << escape1_3[2] << endl;
        std::cerr << "  " << attacked_count << " " << last_hurt << "  " << direct_tiggled << endl;
    }
    //reset data each round
    void reset()
    {
        active = -1;
        need_spj = false;
        passive = -1;

        memset(tried, 0, sizeof(tried));
        tried[0] = true;
        revealed = false;

        active_count = 0;
        escape_count = 0;
        escape1_3[0] = escape1_3[1] = escape1_3[2] = -1;
        attacked_count = 0;

        direct_tiggled = -1;

        
        last_hurt = 0;
    }
    
};


Fish_data enemy[4];


std::vector<int> AI::Pick(Game game)
{
    if(game.round==1){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(8);
        pickfish.push_back(3);
        pickfish.push_back(10);
        pickfish.push_back(4);
        return pickfish;
    }
    if(game.round==2){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(17);
        pickfish.push_back(7);
        pickfish.push_back(6);
        pickfish.push_back(11);
        return pickfish;
    }
    std::vector<int> pickfish;
    pickfish.clear();
    pickfish.push_back(2);
    pickfish.push_back(5);
    pickfish.push_back(9);
    pickfish.push_back(1);
    return pickfish;
}
// <assert_block>


int Round = 0;
int dbg_time = 0;


void debug()
{
    dbg_time++;std::cerr << "-----------" << Round <<","<<dbg_time<<"-------------"<< endl;
    for (int i = 0; i < 4; i++)
    {
        enemy[i].debug();
    }
}


std::pair<int, int> AI::Assert(Game game)
{
    return make_pair(-1,-1);
    //see if this is first move of a new round.if so,reset enemy info
    if (game.round != Round)
    {
        is_first_move == true;
        dbg_time = 0;
        Round = game.round;
        for (int i = 0; i <= 3; i++)
            enemy[i].reset();
    }
    debug();//这里可以优化


    //update enemy info first
    for (int i = 0; i < 4; i++)
    {
        if (is_first_move)
        {
            is_first_move = false;
            break;
        }

        enemy[i].update(game);

        ally[i] = game.my_fish[i].hp;
    }
    /*if (is_first_move)
    {
        is_first_move = false;
        return make_pair(-1, -1);
    }*/
    //see if we can assert one fish

    //by active
    for (int i = 0; i < 4; i++)
    {
        if (enemy[i].revealed == false && game.enemy_fish[i].hp > 0)
        {
            Fish_data fish = enemy[i];
            // judge from aoe
            if (fish.active == aoe)
            {
                //xiaochou change active type
                if (fish.need_spj)
                {
                    if (fish.tried[11] == false && asserted[11] == false)
                        return make_pair(i, 11);
                }
                //dianman atk+20 after hp-200
                if (fish.last_hurt >= 35 && fish.last_hurt <= 40 || fish.last_hurt >= 50 && fish.last_hurt <= 75)
                {
                    if (fish.tried[3] == false && asserted[3] == false)
                    {
                        return make_pair(i, 3);
                    }
                }
                //dianman deflect
                if (fish.passive == deflect)
                {
                    if (fish.tried[3] == false && asserted[3] == false)
                    {
                        return make_pair(i, 3);
                    }
                }
                //sheshui counter for all while xiaochou counter only for itself
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if (game.enemy_fish[j].hp < 120 && enemy[j].direct_tiggled == true)
                        {
                            if (fish.passive == counter)
                            {
                                if (fish.tried[1] == false && asserted[1] == false)
                                    return make_pair(i, 1);
                                if (fish.pos == j && (asserted[1] || fish.tried[1]))
                                {
                                    if (fish.tried[11] == false && asserted[11] == false)
                                        return make_pair(i, 11);
                                }
                            }
                        }
                    }
                }
                //pai chu fa
                if (asserted[1] && asserted[11])
                    return make_pair(i, 3);
                if (asserted[3] && asserted[11])
                    return make_pair(i, 1);
                if (asserted[1] && asserted[3])
                    return make_pair(i, 11);
                //unexpected:nitai

                /*
                if (fish.tried[12] == false && asserted[12] == false)
                {
                    return make_pair(i, 12);
                }*/
            }

            if (fish.active == crit)
            {
                //haigui is the only crit unit that may change skill type
                if (fish.need_spj)
                {
                    if (fish.tried[7] == false && asserted[7] == false)
                        return make_pair(i, 7);
                }

                if (fish.passive == heal)
                {
                    if (fish.tried[9] == false && asserted[9] == false)
                        return make_pair(i, 9);
                }
                //only shark have 140atk crit
                if (fish.last_hurt == 140)
                {
                    if (fish.tried[10] == false && asserted[10] == false)
                        return make_pair(i, 10);
                    if (fish.tried[9] == false && asserted[9] == false)
                        return make_pair(i, 9);
                }
                //only chuitou have atk enhance passive
                if (fish.last_hurt != 120 && fish.last_hurt != 140 && game.enemy_fish[i].skill_used == true)
                {
                    if (fish.tried[10] == false && asserted[10] == false)
                        return make_pair(i, 10);
                }

                //chuitou cant escape, and there is a little chance that hailang doesnt escape
                //haigui always escape before the forth atk, there is a little chance for hailang to behave the same
                if (fish.escape1_3[2] != -1)
                {
                    //escape 3 times,a great chance to be haigui,a small chance to be hailang
                    if (fish.escape_count == 3)
                    {
                        if (fish.tried[7] == false && asserted[7] == false)
                            return make_pair(i, 7);

                        if (fish.tried[5] == false && asserted[5] == false)
                            return make_pair(i, 5);
                    }
                    //escaped but not always. only hailang
                    else if (fish.escape_count > 0)
                    {
                        if (fish.tried[5] == false && asserted[5] == false)
                            return make_pair(i, 5);
                    }
                    //never escaped, chuitou>hailang
                    else if (fish.escape_count == 0)
                    {
                        if (fish.tried[10] == false && asserted[10] == false)
                            return make_pair(i, 10);
                        if (fish.tried[5] == false && asserted[5] == false)
                            return make_pair(i, 5);
                    }
                }

                if (asserted[5] && asserted[9] && asserted[10])
                    return make_pair(i, 7);
                if (asserted[5] && asserted[7] && asserted[10])
                    return make_pair(i, 9);
                if (asserted[7] && asserted[9] && asserted[10])
                    return make_pair(i, 5);
                if (asserted[5] && asserted[9] && asserted[7])
                    return make_pair(i, 10);

                //dabai is the only crit_heal

                //unexpected:nitai
                /*
                if (fish.tried[12] == false && asserted[12] == false)
                {
                    return make_pair(i, 12);
                }*/
            }

            if (fish.active == infight)
            {
                //only fanche has deflect among infight
                if (fish.passive == deflect)
                {
                    if (fish.tried[4] == false && asserted[4] == false)
                        return make_pair(i, 4);
                }
                //only penhuo have counter
                if (fish.passive == counter)
                {
                    if (fish.tried[2] == false && asserted[2] == false)
                        return make_pair(i, 2);
                }
                //directly attacked but no respond,penhuo
                if (fish.direct_tiggled && fish.passive != deflect)
                {
                    if (fish.tried[2] == false && asserted[2] == false)
                        return make_pair(i, 2);
                }

                if (asserted[4])
                    return make_pair(i, 2);
                if (asserted[2])
                    return make_pair(i, 4);

                //unexpected:nitai
                /*
                if (fish.tried[12] == false && asserted[12] == false)
                {
                    return make_pair(i, 12);
                }*/
            }

            if (fish.active == subtle)
            {
                //judging from if it change active skill

                if (fish.passive != heal)
                {
                    if (fish.tried[6] == false && asserted[6] == false)
                    {
                        return make_pair(i, 6);
                    }
                }

                if (fish.passive == heal)
                {
                    if (fish.tried[8] == false && asserted[8] == false)
                        return make_pair(i, 8);
                }

                if (asserted[8])
                    return make_pair(i, 6);
                if (asserted[6])
                    return make_pair(i, 8);

                //judging from if it escape
                //haigui and xiaochou are handled in need_spj.
                //unexpected:nitai
                /*
                if (fish.tried[12] == false && asserted[12] == false)
                {
                    return make_pair(i, 12);
                }*/
            }
        }
        if (enemy[i].passive == explode)
        {
            if (asserted[12])
                asserted[10] = true;
        }
    }

    //by passive

    for (int i = 0; i < 4; i++)
    {
        if (enemy[i].revealed == false && game.enemy_fish[i].hp > 0)
        {
            Fish_data fish = enemy[i];
            if (fish.passive == counter)
            {
                if (asserted[1] && asserted[11])
                    if (fish.tried[2] == false && asserted[2] == false)
                        return make_pair(i, 2);
                if (asserted[1] && asserted[2])
                    if (fish.tried[11] == false && asserted[11] == false)
                        return make_pair(i, 11);
                if (asserted[2] && asserted[11])
                    if (fish.tried[1] == false && asserted[1] == false)
                        return make_pair(i, 1);
                if (asserted[1] && asserted[11]&&asserted[2])
                    if (fish.tried[12] == false && asserted[12] == false)
                        return make_pair(i, 12);
            }

            if (fish.passive == deflect)
            {
                if (asserted[3])
                    if (fish.tried[4] == false && asserted[4] == false)
                        return make_pair(i, 4);
                if (asserted[4])
                    if (fish.tried[3] == false && asserted[3] == false)
                        return make_pair(i, 11);
                if (asserted[3] && asserted[4])
                    if (fish.tried[12] == false && asserted[12] == false)
                        return make_pair(i, 12);
            }

            if (fish.passive == reduce)
            {
                if (asserted[5] && asserted[6])
                    if (fish.tried[7] == false && asserted[7] == false)
                        return make_pair(i, 7);
                if (asserted[5] && asserted[7])
                    if (fish.tried[6] == false && asserted[6] == false)
                        return make_pair(i, 6);
                if (asserted[6] && asserted[7])
                    if (fish.tried[5] == false && asserted[5] == false)
                        return make_pair(i, 5);
                if (asserted[5] && asserted[6] && asserted[7])
                    if (fish.tried[12] == false && asserted[12] == false)
                        return make_pair(i, 12);
            }

            if (fish.passive == heal)
            {
                if (asserted[8])
                    if (fish.tried[9] == false && asserted[9] == false)
                        return make_pair(i, 9);
                if (asserted[9])
                    if (fish.tried[8] == false && asserted[8] == false)
                        return make_pair(i, 8);
                if (asserted[9] && asserted[8])
                    if (fish.tried[12] == false && asserted[12] == false)
                        return make_pair(i, 12);
            }
        }

        if (enemy[i].passive == explode)
        {
            if (asserted[12])
                asserted[10];
        }
    }

    for (int i = 0; i < 4; i++)
    {
        ally[i] = game.my_fish[i].hp;
    }

    return make_pair(-1, -1);

}



Action AI::Act(Game game)
{
    // TODO: fill your code
    if (game.round == 1) {
        Action action(game);
        if (times < 3) {
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
            times++;
            return action;
        }
        int my_atk = get_my_atk(0);
        int enemy_hp[4] = { 0 };
        int min = 400;
        int k = 0;
        for (int i = 0; i < 4; i++) {
            enemy_hp[i] = get_enemy_hp(i);
            if (enemy_hp[i] < min && enemy_hp[i]>0) {
                min = enemy_hp[i];
                k = i;
            }
        }
        int my_hp = get_my_hp(0);
        if (my_hp > 0) {
            if (my_atk >= min * 2) {
                action.set_action_fish(0);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
            if (game.enemy_action.is_skill) {
                int skill = game.enemy_action.type;
                if (skill == crit) {
                    int target = game.my_action.enemy_targets[0];
                    action.set_action_fish(0);
                    action.set_action_type(1);
                    action.set_friend_target(target);
                    return action;
                }
            }
            if (!game.enemy_action.is_skill) {
                int target = game.my_action.enemy_targets[0];
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_friend_target(target);
                return action;
            }
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_friend_target(0);
            return action;
        }

        my_hp = get_my_hp(1);
        if (my_hp > 0) {
            action.set_action_fish(1);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }

        my_hp = get_my_hp(2);
        if (my_hp > 0) {
            action.set_action_fish(2);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }

        my_hp = get_my_hp(3);
        if (my_hp > 0) {
            action.set_action_fish(3);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
    }

    if (game.round == 2) {
        Action action(game);
        int my_hp = get_my_hp(1);
        int skill_used_times = get_skill_used(1);
        if (my_hp > 0 && skill_used_times < 3) {
            if (game.enemy_action.type == crit) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(k);
                return action;
            }

            if (game.enemy_action.type == infight) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(k);
                return action;
            }

            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_friend_target(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }

        my_hp = get_my_hp(0);
        if (my_hp > 0) {
            if (game.enemy_action.type == crit) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(k);
                return action;
            }

            if (game.enemy_action.type == infight) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(k);
                return action;
            }

            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        
        my_hp = get_my_hp(1);
        if (my_hp > 0) {
            if (game.enemy_action.type == crit) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }

            if (game.enemy_action.type == infight) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }

            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(1);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }

        my_hp = get_my_hp(2);
        if (my_hp > 0) {
            if (game.enemy_action.type == crit) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }

            if (game.enemy_action.type == infight) {
                int k = game.enemy_action.action_fish;
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }

            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(2);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }

        if (game.enemy_action.type == crit) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }

        if (game.enemy_action.type == infight) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }

        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(3);
        action.set_action_type(0);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }

    Action action(game);
    int my_hp = get_my_hp(1);
    if (my_hp > 0) {
        if (game.enemy_action.type == crit) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }

        if (game.enemy_action.type == infight) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }

        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(1);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }

    my_hp = get_my_hp(2);
    if (my_hp > 0) {
        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }

    my_hp = get_my_hp(0);
    if (my_hp > 0) {
        if (game.enemy_action.type == crit) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }

        if (game.enemy_action.type == infight) {
            int k = game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }

        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(0);
        action.set_action_type(0);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }

    if (game.enemy_action.type == crit) {
        int k = game.enemy_action.action_fish;
        action.set_action_fish(3);
        action.set_action_type(0);
        action.set_enemy_target(k);
        return action;
    }

    if (game.enemy_action.type == infight) {
        int k = game.enemy_action.action_fish;
        action.set_action_fish(3);
        action.set_action_type(0);
        action.set_enemy_target(k);
        return action;
    }

    int lowest_health_enemy = get_lowest_health_enemy();
    action.set_action_fish(3);
    action.set_action_type(0);
    action.set_enemy_target(lowest_health_enemy);
    return action;
}




int main()
{
    
    for (int i = 0; i <= 3; i++)
        enemy[i].pos=i;

    AI *myAI = new AI();
    myAI->run();
    delete (myAI);
    return 0;
}

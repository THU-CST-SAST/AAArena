#include "Action.hpp"
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <cstring>

int tempp = 0;         //回合
int haiguiskill = 0;   //海龟技能数
int xiaochouskill = 0; //小丑鱼技能数
int pro1, pro2;
//被动------------
int chengshang[5];
int zhiliao[5];
int jianshang[5];
int wangyu[5];
int fanshang[5];
//---------------
bool dead[5][15];  //准确的判断
bool dead2[5][15]; //可能不准的判断
int numaoe[5];     //寻找小丑鱼
int numcrit[5];    //寻找海龟
int tot[5];        //准确判断数
int tot2[5];       //可能不准确判断数
bool is[15];       //是否已经出现了
bool targ[5];
//判断先手----
bool f1 = 0;
bool f2 = 0;
bool f3 = 0;
//------------
int tota = 0;                                       //查找反伤
int temp = 0;                                       //一个随机数
bool ski[5];                                        //是否发动技能
bool att[5];                                        //是否打过
bool bei[5];                                        //是否有用被动
int ph, fc, xc, fp, hl, ss, dm, hg, zy, db, ct, nt; //找到自己
int pos;                                            //行动鱼
int expo = -1;                                      //将要暴露的鱼
bool ff = 0;
bool ff2 = 0;
bool ff3 = 0;
bool fff1 = 0;
bool fff2 = 0;
bool fff3 = 0;
bool ffff1 = 0;
bool ffff2 = 0;
bool ffff3 = 0;
bool fffff1 = 0;
bool fffff2 = 0;
bool fffff3 = 0;

int die = -1;
std::vector<int> AI::Pick(Game game)
{
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
    pickfish.clear();
    if (tempp == 1)
    {
        memset(dead, 1, sizeof(dead));
        memset(dead2, 0, sizeof(dead2));

        for (int i = 1; i <= 12; i++)
        {
            if (is[i])
            {
                for (int j = 0; j <= 3; j++)
                {
                    dead[j][i] = 0;
                }
            }
        }
        memset(chengshang, 0, sizeof(chengshang));
        memset(zhiliao, 0, sizeof(zhiliao));
        memset(wangyu, 0, sizeof(wangyu));
        memset(jianshang, 0, sizeof(jianshang));
        memset(fanshang, 0, sizeof(fanshang));

        memset(numaoe, 0, sizeof(numaoe));
        memset(numcrit, 0, sizeof(numcrit));

        memset(ski, 0, sizeof(ski));
        memset(bei, 0, sizeof(bei));
        memset(att, 0, sizeof(att));
        expo = -1;
        memset(targ, 0, sizeof(targ));

        /*pickfish.push_back(7);
        pickfish.push_back(2);
        pickfish.push_back(6);
        pickfish.push_back(1);*/
        pickfish.push_back(22);
        pickfish.push_back(10);
        pickfish.push_back(11);
        pickfish.push_back(2);
        tempp = 2;
        tota = 0;
        return pickfish;
    }
    if (tempp == 2)
    {

        memset(dead, 1, sizeof(dead));
        memset(dead2, 0, sizeof(dead2));
        for (int i = 1; i <= 12; i++)
        {
            if (is[i])
            {
                for (int j = 0; j <= 3; j++)
                {
                    dead[j][i] = 0;
                }
            }
        }
        memset(chengshang, 0, sizeof(chengshang));
        memset(zhiliao, 0, sizeof(zhiliao));
        memset(wangyu, 0, sizeof(wangyu));
        memset(jianshang, 0, sizeof(jianshang));
        memset(fanshang, 0, sizeof(fanshang));

        memset(numaoe, 0, sizeof(numaoe));
        memset(numcrit, 0, sizeof(numcrit));

        memset(ski, 0, sizeof(ski));
        memset(bei, 0, sizeof(bei));
        memset(att, 0, sizeof(att));
        memset(targ, 0, sizeof(targ));

        pickfish.push_back(6);
        pickfish.push_back(7);
        pickfish.push_back(1);
        pickfish.push_back(5);
        expo = -1;
        tota = 0;
        return pickfish;
    }
    if (tempp == 0)
    {

        memset(dead, 1, sizeof(dead));
        memset(dead2, 0, sizeof(dead2));
        memset(is, 0, sizeof(is));
        for (int i = 1; i <= 12; i++)
        {
            if (is[i])
            {
                for (int j = 0; j <= 3; j++)
                {
                    dead[j][i] = 0;
                }
            }
        }
        memset(chengshang, 0, sizeof(chengshang));
        memset(zhiliao, 0, sizeof(zhiliao));
        memset(wangyu, 0, sizeof(wangyu));
        memset(jianshang, 0, sizeof(jianshang));
        memset(fanshang, 0, sizeof(fanshang));

        memset(numaoe, 0, sizeof(numaoe));
        memset(numcrit, 0, sizeof(numcrit));

        memset(ski, 0, sizeof(ski));
        memset(bei, 0, sizeof(bei));
        memset(att, 0, sizeof(att));
        memset(targ, 0, sizeof(targ));

        pickfish.push_back(4);
        pickfish.push_back(9);
        pickfish.push_back(3);
        pickfish.push_back(8);
        tempp = 1;
        expo = -1;
        tota = 0;
        return pickfish;
    }
}

std::pair<int, int> AI::Assert(Game game)
{
    if (game.first_mover && !f1 && game.round == 1)
    {
        f1 = 1;
        return std::make_pair(-1, -1);
    }
    if (game.first_mover && !f2 && game.round == 2)
    {
        f2 = 1;
        return std::make_pair(-1, -1);
    }
    if (game.first_mover && !f3 && game.round == 3)
    {
        f3 = 1;
        return std::make_pair(-1, -1);
    }

    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            is[get_enemy_id(i)] = 1;
            for (int j = 0; j <= 3; j++)
            {
                dead[j][get_enemy_id(i)] = 0;
            }
        }
    }

    AssertInfo as = game.my_assert;
    if (as.assertContent != 0)
    {
        if (!as.assertResult)
        {
            dead[as.assertPos][as.assertContent] = 0;
        }
        else
        {
            is[as.assertContent] = 1;
            std::cerr << as.assertContent << ' ';
            for (int i = 0; i <= 3; i++)
            {
                dead[i][as.assertContent] = 0;
            }
        }
    }
    AssertInfo ass = game.enemy_assert;
    if (ass.assertContent != 0)
    {
        if (!ass.assertResult)
        {
            expo = ass.assertPos;
        }
    }
    if (get_my_id(expo) < 0 && get_my_hp(expo) > 0)
    {
        expo = -1;
    }
    ActionInfo a = game.enemy_action;
    ActionInfo b = game.my_action;
    int target = a.action_fish;

    if (!a.is_skill)
    {
        if (a.enemy_excepted_injury[0] != 50)
        {
            dead[target][1] = dead[target][5] = dead[target][7] = dead[target][9] = dead[target][11] = 0;
        }
        if (a.enemy_excepted_injury[0] == 115)
        {
            dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][11] = 0;
        }
        if (a.enemy_excepted_injury[0] == 170 || a.enemy_excepted_injury[0] == 240 || a.enemy_excepted_injury[0] == 310 || a.enemy_excepted_injury[0] == 380 || a.enemy_excepted_injury[0] == 450)
        {
            dead[target][1] = dead[target][3] = dead[target][6] = dead[target][8] = dead[target][5] = dead[target][7] = dead[target][9] = dead[target][10] = dead[target][11] = 0;
        }
        if (a.enemy_excepted_injury[0] == 120 || a.enemy_excepted_injury[0] == 140 || a.enemy_excepted_injury[0] == 160 || a.enemy_excepted_injury[0] == 180 || a.enemy_excepted_injury[0] == 200)
        {
            dead[target][1] = dead[target][2] = dead[target][5] = dead[target][7] = dead[target][9] = dead[target][10] = dead[target][11] = 0;
        }
        if (a.enemy_excepted_injury[0] == 190 || a.enemy_excepted_injury[0] == 260 || a.enemy_excepted_injury[0] == 330 || a.enemy_excepted_injury[0] == 400 || a.enemy_excepted_injury[0] == 210 || a.enemy_excepted_injury[0] == 280)
        {
            dead[target][1] = dead[target][2] = dead[target][3] = dead[target][10] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][11] = 0;
        }
    }
    else
    {
        ski[target] = 1;
        if (a.type == aoe)
        {
            numaoe[target]++;
            dead[target][2] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][10] = 0;
        }
        if (a.type == infight)
        {
            dead[target][1] = dead[target][3] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][10] = dead[target][11] = 0;
        }
        if (a.type == crit)
        {
            targ[target] = 1;
            numcrit[target]++;
            if (a.enemy_excepted_injury[0] == 120)
            {
                dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][6] = dead[target][8] = dead[target][11] = 0;
            }
            if (a.enemy_excepted_injury[0] == 140)
            {
                dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][11] = 0;
            }
            if (a.enemy_excepted_injury[0] == 138 || a.enemy_excepted_injury[0] == 161)
            {
                dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][11] = 0;
            }
        }
        if (a.type == subtle)
        {
            if (numaoe[target] == 3)
            {
                dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][7] = dead[target][8] = dead[target][9] = dead[target][10] = 0;
            }
            if (numcrit[target] == 3)
            {
                dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][6] = dead[target][11] = dead[target][8] = dead[target][9] = dead[target][10] = 0;
            }
            dead[target][1] = dead[target][2] = dead[target][3] = dead[target][4] = dead[target][5] = dead[target][9] = dead[target][10] = 0;
        }
    }
    for (int i = 0; i < b.num_enemy_targets; i++)
    {
        bool flag = 0;
        if (zhiliao[b.enemy_targets[i]])
        {
            if (b.num_enemy_passives != 0)
            {
                for (int j = 0; j < b.num_enemy_passives; j++)
                {
                    if (b.enemy_passives_id[j] == b.enemy_targets[i] && b.enemy_types[j] == heal)
                    {
                        flag = 1;
                    }
                }
            }
            if (!flag)
            {
                dead[b.enemy_targets[i]][8] = dead[b.enemy_targets[i]][9] = 0;
            }
        }
    }
    for (int i = 0; i < b.num_enemy_targets; i++)
    {
        bool flag = 0;
        if (chengshang[b.enemy_targets[i]])
        {
            if (b.num_enemy_passives != 0)
            {
                for (int j = 0; j < b.num_enemy_passives; j++)
                {
                    if (b.enemy_passives_id[j] == b.enemy_targets[i] && b.enemy_types[j] == deflect)
                    {
                        flag = 1;
                    }
                }
            }
            if (!flag)
            {
                dead[b.enemy_targets[i]][3] = dead[b.enemy_targets[i]][4] = 0;
            }
        }
    }
    if (b.num_enemy_passives != 0)
    {
        for (int i = 0; i < b.num_enemy_passives; i++)
        {
            if (b.enemy_types[i] == heal)
            {
                bei[b.enemy_passives_id[i]] = 1;
                zhiliao[b.enemy_passives_id[i]] = 1;
            }
        }
        for (int i = 0; i < b.num_enemy_passives; i++)
        {
            if (b.enemy_types[i] == deflect)
            {
                bei[b.enemy_passives_id[i]] = 1;
                chengshang[b.enemy_passives_id[i]] = 1;
            }
        }
        for (int i = 0; i < b.num_enemy_passives; i++)
        {
            if (b.enemy_types[i] == explode)
            {
                bei[b.enemy_passives_id[i]] = 1;
                wangyu[b.enemy_passives_id[i]] = 1;
            }
        }
        for (int i = 0; i < b.num_enemy_passives; i++)
        {
            if (b.enemy_types[i] == reduce)
            {
                if (b.enemy_passive_value[i] == 0.3)
                {
                    att[b.enemy_passives_id[i]] = 1;
                    pro1 = 6;
                    pro2 = 8;
                }
                if (b.enemy_passive_value[i] == 0)
                {
                    bei[b.enemy_passives_id[i]] = 1;
                    jianshang[b.enemy_passives_id[i]] = 1;
                    dead[b.enemy_passives_id[i]][1] = dead[b.enemy_passives_id[i]][2] = dead[b.enemy_passives_id[i]][3] = dead[b.enemy_passives_id[i]][4] = dead[b.enemy_passives_id[i]][8] = dead[b.enemy_passives_id[i]][9] = dead[b.enemy_passives_id[i]][10] = dead[b.enemy_passives_id[i]][11] = 0;
                }
            }
        }
        for (int i = 0; i < b.num_enemy_passives; i++)
        {
            if (b.enemy_types[i] == counter)
            {
                bei[b.enemy_passives_id[i]] = 1;
                fanshang[b.enemy_passives_id[i]] = 1;
            }
        }
    }
    int huoyu = 0;
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_hp(i) > 0)
            huoyu++;
    }
    if (b.num_enemy_targets == huoyu)
    {
        for (int i = 0; i < b.num_enemy_targets; i++)
        {
            if (!bei[b.enemy_targets[i]])
            {
                dead[b.enemy_targets[i]][3] = dead[b.enemy_targets[i]][4] = dead[b.enemy_targets[i]][7] = dead[b.enemy_targets[i]][8] = dead[b.enemy_targets[i]][9] = 0;
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (ski[i] && !bei[i] && att[i])
        {
            dead[i][3] = dead[i][4] = dead[i][7] = dead[i][3] = dead[i][8] = dead[i][9] = 0;
            bei[i] = 1;
        }
    }
    /*
    for (int i = 0; i <= 3; i++)
    {
        if (wangyu[i])
        {
            if (is[12] && !is[10])
            {
                is[10] = 1;
            }
        }
    }*/
    //------------------------------------------------------------------------------------------------------------------
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        tot[i] = 0;
        for (int j = 1; j <= 12; j++)
        {
            if (dead[i][j])
            {
                tot[i]++;
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot[i] == 1)
        {
            int deadd;
            for (int j = 1; j <= 12; j++)
            {
                if (dead[i][j])
                {
                    deadd = j;
                }
            }
            if (!is[deadd] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
            {
                return std::make_pair(i, deadd);
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot[i] == 2)
        {
            for (int j = 1; j <= 12; j++)
            {
                if (dead[i][j])
                {
                    if (!is[j] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
                    {
                        return std::make_pair(i, j);
                    }
                }
            }
        }
    }
    int tmp = 0;
    for (int i = 0; i <= 3; i++)
    {
        if (fanshang[i])
        {
            tmp++;
        }
    }
    if (tmp == 1)
    {
        tota++;
        for (int i = 0; i <= 3; i++)
        {
            if (fanshang[i] && tota == 3 && get_enemy_hp(i) > 0 && get_enemy_id(i) == -1 && !is[11])
            {
                return std::make_pair(i, 11);
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot[i] == 3)
        {
            for (int j = 1; j <= 12; j++)
            {
                if (dead[i][j])
                {
                    if (!is[j] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
                    {
                        return std::make_pair(i, j);
                    }
                }
            }
        }
    }
    //------------------------------------------------------------------------------------------------------------------
    for (int i = 0; i <= 3; i++)
    {
        for (int j = 1; j <= 12; j++)
        {
            dead2[i][j] = dead[i][j];
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (chengshang[i])
        {
            dead2[i][1] = dead2[i][2] = dead2[i][5] = dead2[i][6] = dead2[i][7] = dead2[i][8] = dead2[i][9] = dead2[i][10] = dead2[i][11] = 0;
        }
    }
    /*
    for (int i = 0; i <= 3; i++)
    {
        if (jianshang[i])
        {
            dead2[i][1] = dead2[i][2] = dead2[i][3] = dead2[i][4] = dead2[i][8] = dead2[i][9] = dead2[i][10] = dead2[i][11] = 0;
        }
    }*/
    for (int i = 0; i <= 3; i++)
    {
        if (zhiliao[i])
        {
            dead2[i][1] = dead2[i][2] = dead2[i][3] = dead2[i][4] = dead2[i][5] = dead2[i][6] = dead2[i][7] = dead2[i][10] = dead2[i][11] = 0;
        }
    }

    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        tot2[i] = 0;
        for (int j = 1; j <= 12; j++)
        {
            if (dead2[i][j])
            {
                tot2[i]++;
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot2[i] == 1)
        {
            int deadd;
            for (int j = 1; j <= 12; j++)
            {
                if (dead2[i][j])
                {
                    deadd = j;
                }
            }
            if (!is[deadd] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
            {
                return std::make_pair(i, deadd);
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot2[i] == 2)
        {
            for (int j = 1; j <= 12; j++)
            {
                if (dead2[i][j])
                {
                    if (!is[j] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
                    {
                        return std::make_pair(i, j);
                    }
                }
            }
        }
    }
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_id(i) != -1)
        {
            continue;
        }
        if (tot2[i] == 3)
        {
            for (int j = 1; j <= 12; j++)
            {
                if (dead2[i][j])
                {
                    if (!is[j] && get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
                    {
                        return std::make_pair(i, j);
                    }
                }
            }
        }
    }

    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    Action action(game);
    srand((unsigned)time(NULL));
    temp += rand();
    temp %= 13;

    bool fla = 0;
    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_hp(i) <= 0)
        {
            continue;
        }
        if (targ[i])
        {
            die = i;
            fla = 1;
        }
    }
    if (!fla)
    {
        die = -1;
    }
    for (int i = 0; i <= 3; i++)
    {
        if (ski[i] && !bei[i] && att[i])
        {
            dead[i][3] = dead[i][4] = dead[i][7] = dead[i][3] = dead[i][8] = dead[i][9] = 0;
            bei[i] = 1;
        }
        if (ski[i] && !bei[i] && !att[i] && get_enemy_hp(i) > 0 && get_enemy_id(i) == -1)
        {
            att[i] = 1;
            action.set_action_fish(get_my_living_fishes()[0]);
            action.set_action_type(0);
            action.set_enemy_target(i);
            return action;
        }
    }
    pos = get_my_living_fishes()[temp % get_my_living_fishes().size()];
    if (game.round == 2)
    {
        if (!ff)
        {
            for (int i = 0; i <= 3; i++)
            {
                if (get_my_id(i) == 12)
                {
                    nt = i;
                    ff = 1;
                }
                if (get_my_id(i) == 10)
                {
                    ct = i;
                }
                if (get_my_id(i) == 2)
                {
                    ph = i;
                }
                if (abs(get_my_id(i)) == 11)
                {
                    xc = i;
                }
            }
        }
        if (get_my_hp(ct) > 0)
        {
            pos = ct;
        }
        if (get_my_hp(nt) > 0)
        {
            pos = nt;
        }
        if (get_my_hp(xc) > 0)
        {
            if (get_enemy_living_fishes().size() >= 3 && xiaochouskill <= 3)
                pos = xc;
        }
        for (int i = 0; i <= 3; i++)
        {
            if (get_enemy_hp(i) > 0 && get_enemy_hp(i) < 160)
            {
                if (get_my_hp(ct) > 0)
                {
                    pos = ct;
                }
                if (get_my_hp(nt) > 0)
                {
                    pos = nt;
                }
            }
        }
        if (pos == ph && get_my_hp(pos) > 0)
        {
            action.set_action_fish(pos);
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            return action;
        }
    }
    if (game.round == 3)
    {
        if (!ff2)
        {
            for (int i = 0; i <= 3; i++)
            {
                if (abs(get_my_id(i)) == 5)
                {
                    hl = i;
                    ff2 = 1;
                }
                if (abs(get_my_id(i)) == 6)
                {
                    fp = i;
                }
                if (abs(get_my_id(i)) == 7)
                {
                    hg = i;
                }

                if (abs(get_my_id(i)) == 1)
                {
                    ss = i;
                }
            }
        }
        if (get_my_hp(hg) > 0 && haiguiskill < 3)
        {
            pos = hg;
        }
        if (get_my_hp(ss) > 0 && get_enemy_living_fishes().size() >= 3)
        {
            pos = ss;
        }
    }
    if (tempp == 1)
    {
        if (!ff3)
        {
            for (int i = 0; i <= 3; i++)
            {
                if (abs(get_my_id(i)) == 3)
                {
                    dm = i;
                    ff3 = 1;
                }
                if (abs(get_my_id(i)) == 4)
                {
                    fc = i;
                }
                if (abs(get_my_id(i)) == 8)
                {
                    zy = i;
                }
                if (abs(get_my_id(i)) == 9)
                {
                    db = i;
                }
            }
        }
        if (get_my_hp(db) > 0)
        {
            pos = db;
        }
        if (pos == fc)
        {
            if (get_my_hp(dm) > 0)
                pos = dm;
            else if (get_my_hp(db) > 0)
                pos = db;
            else if (get_my_hp(zy) > 0)
                pos = zy;
            else
            {

                action.set_action_fish(pos);
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
                return action;
            }
        }
        if (get_my_hp(dm) > 0)
        {
            if (get_enemy_living_fishes().size() >= 3)
                pos = dm;
            else if (pos == dm)
            {
                if (get_my_hp(db) > 0)
                    pos = db;
            }
        }
        if (get_my_living_fishes().size() == 1 && get_my_hp(zy) > 0)
        {
            action.set_action_fish(zy);
            if (get_my_atk(zy) > (get_enemy_hp(get_lowest_health_enemy()) * 2))
            {
                action.set_action_type(0);
                action.set_enemy_target(get_lowest_health_enemy());
            }
            else
            {
                action.set_action_type(1);
                action.set_friend_target(zy);
            }
            return action;
        }
    }
    if (get_my_hp(pos) <= 0)
    {
        pos = get_my_living_fishes()[temp % get_my_living_fishes().size()];
    }
    action.set_action_fish(pos);
    switch (abs(get_my_id(pos)))
    {
    case 1:
    {
        if ((get_enemy_living_fishes()).size() >= 2)
        {
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }
        else
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
        }
        break;
    }
    case 2:
    {
        if (temp % 13 > 12)
        {
            if (get_my_atk(pos) >= 240)
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
                break;
            }
            std::vector<int> myally = get_my_living_ally(pos);
            if (myally.empty())
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
                break;
            }
            int maxx = 0;
            int target;
            for (int i = 0; i < myally.size(); i++)
            {
                if (get_my_hp(myally[i]) > maxx)
                {
                    maxx = get_my_hp(myally[i]);
                    target = myally[i];
                }
            }
            if (get_my_hp(target) >= 150)
            {
                action.set_action_type(1);
                action.set_friend_target(target);
            }
            else
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
            }
            break;
        }
        else
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            return action;
        }
    }
    case 3:
    {
        if ((get_enemy_living_fishes()).size() >= 2)
        {
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }
        else
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
        }
        break;
    }
    case 4:
    {
        if (temp % 13 > 12)
        {
            if (get_my_atk(pos) >= 240)
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
                break;
            }
            std::vector<int> myally = get_my_living_ally(pos);
            if (myally.empty())
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
                break;
            }
            bool flag = 0;
            for (int i = 0; i < myally.size(); i++)
            {
                if (get_my_id(myally[i]) == 3 && get_my_hp(myally[i]) >= 160)
                {
                    action.set_action_type(1);
                    action.set_friend_target(myally[i]);
                    flag = 1;
                    return action;
                    break;
                }
            }
            if (flag)
                break;
            int maxx = 0;
            int target;
            for (int i = 0; i < myally.size(); i++)
            {
                if (get_my_hp(myally[i]) > maxx)
                {
                    maxx = get_my_hp(myally[i]);
                    target = myally[i];
                }
            }
            if (get_my_hp(target) >= 150)
            {
                action.set_action_type(1);
                action.set_friend_target(target);
            }
            else
            {
                action.set_action_type(0);
                if (die == -1)
                    action.set_enemy_target(get_lowest_health_enemy());
                else
                    action.set_enemy_target(die);
            }
            break;
        }
        else
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            return action;
        }
    }
    case 5:
    {
        action.set_action_type(1);
        if (die == -1)
            action.set_enemy_target(get_lowest_health_enemy());
        else
            action.set_enemy_target(die);
        break;
    }
    case 6:
    {

        if (get_my_atk(pos) >= 200)
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            break;
        }
        action.set_action_type(1);
        std::vector<int> myally = get_my_living_fishes();
        int minn = 10000;
        int target;
        for (int i = 0; i < myally.size(); i++)
        {
            if (get_my_hp(myally[i]) < minn && get_my_hp(myally[i]) > 0)
            {
                minn = get_my_hp(myally[i]);
                target = myally[i];
            }
        }
        if (get_my_hp(expo) > 0)
            target = expo;
        action.set_friend_target(target);
        break;
    }
    case 7:
    {

        std::vector<int> myally = get_my_living_ally(pos);
        if (myally.empty())
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            break;
        }
        action.set_action_type(1);
        int minn = 10000;
        int targett;
        for (int i = 0; i < myally.size(); i++)
        {
            if (get_my_hp(myally[i]) < minn && get_my_hp(myally[i]) > 0)
            {
                minn = get_my_hp(myally[i]);
                targett = myally[i];
            }
        }
        if (get_my_hp(expo) > 0)
            targett = expo;
        if (!ffff1)
        {
            ffff1 = 1;
            if (get_my_hp(ss) > 0)
                targett = ss;
        }
        else if (!ffff2)
        {
            ffff2 = 1;
            if (get_my_hp(hl) > 0)
                targett = hl;
        }
        else if (!ffff3)
        {
            ffff3 = 1;
            if (get_my_hp(fp) > 0)
                targett = fp;
        }
        action.set_friend_target(targett);
        haiguiskill++;
        if (haiguiskill <= 3)
        {
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
        }
        break;
    }
    case 8:
    {
        if (get_my_atk(pos) >= 200)
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            break;
        }
        action.set_action_type(1);
        std::vector<int> myally = get_my_living_fishes();
        int minn = 10000;
        int targett;
        for (int i = 0; i < myally.size(); i++)
        {
            if (get_my_hp(myally[i]) < minn && get_my_hp(myally[i]) > 0)
            {
                minn = get_my_hp(myally[i]);
                targett = myally[i];
            }
        }
        if (get_my_hp(expo) > 0)
            targett = expo;
        if (!fffff1)
        {
            fffff1 = 1;

            if (get_my_hp(db) > 0)
                targett = db;
        }
        else if (!fffff2)
        {
            fffff2 = 1;
            if (get_my_hp(dm) > 0)
                targett = dm;
        }
        else if (!fffff3)
        {
            fffff3 = 1;
            if (get_my_hp(fc) > 0)
                targett = fc;
        }
        action.set_friend_target(targett);
        break;
    }

    case 9:
    {
        action.set_action_type(1);
        action.set_enemy_target(get_lowest_health_enemy());
        break;
    }
    case 10:
    {
        action.set_action_type(1);
        action.set_enemy_target(get_lowest_health_enemy());
        break;
    }
    case 11:
    {
        std::vector<int> myally = get_my_living_ally(pos);
        if (myally.empty())
        {
            action.set_action_type(0);
            if (die == -1)
                action.set_enemy_target(get_lowest_health_enemy());
            else
                action.set_enemy_target(die);
            break;
        }
        action.set_action_type(1);
        int minn = 10000;
        int targett;
        for (int i = 0; i < myally.size(); i++)
        {
            if (get_my_hp(myally[i]) < minn && get_my_hp(myally[i]) > 0)
            {
                minn = get_my_hp(myally[i]);
                targett = myally[i];
            }
        }
        if (get_my_hp(expo) > 0)
            targett = expo;
        if (!fff1)
        {
            fff1 = 1;
            if (get_my_hp(nt) > 0)
                targett = nt;
        }
        else if (!fff2)
        {
            fff2 = 1;
            if (get_my_hp(ct) > 0)
                targett = ct;
        }
        else if (!fff3)
        {
            fff3 = 1;
            if (get_my_hp(ph) > 0)
                targett = ph;
        }
        action.set_friend_target(targett);
        xiaochouskill++;
        if (xiaochouskill <= 3)
        {
            action.set_enemy_target(-2);
        }
        break;
    }
    case 12:
    {
        action.set_action_type(1);
        action.set_enemy_target(get_lowest_health_enemy());
        break;
    }
    }
    return action;
}
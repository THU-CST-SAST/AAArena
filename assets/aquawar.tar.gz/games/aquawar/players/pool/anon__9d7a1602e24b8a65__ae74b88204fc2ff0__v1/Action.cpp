#include "Action.hpp"
#include <algorithm>

using namespace std;

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
	default_random_engine f;
	uniform_int_distribution<int> u(1, 12);
	int fl[12] = {0};
	int pf;
	int j = 0;
	f.seed(time(0));
    pickfish.clear();
    while(j < 4)
	{
		pf = u(f);
		for(int i = 0;i < remain_fishes.size();i++)
		{
			if(remain_fishes[i] == pf && fl[pf] == 0)
			{
				pickfish.push_back(pf == 12 ? 15 : pf);
				fl[pf] == 1;
				j++;
				break;
			}
		}
	}
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    int my_pos = (get_my_living_fishes())[0];
    action.set_action_fish(my_pos);
    auto_valid_action(my_pos, &action);
    return action;
}
#include "Action.hpp"
#include <algorithm>

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code

    // 获取剩余的鱼
    std::vector<int> remain_fishes = get_my_remain_fishes();
    // 挑选的鱼的vector
    std::vector<int> pick_fish;
    pick_fish.clear();
    // 挑选前四条鱼
    for (int i = 0; i < 4; i++)
    {
        // 特殊处理一下拟态鱼
        int picked_fish_id = remain_fishes[i];
        // 固定拟态鱼模仿射水鱼
        if (picked_fish_id == 12)
            picked_fish_id = 13;
        // 将挑选的鱼放进vector里
        pick_fish.push_back(picked_fish_id);
    }
    return pick_fish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code

    // 创建Action类的实例action
    Action action(game);
    // 获取我能出战的鱼的位置
    int my_pos = (get_my_living_fishes())[0];
    // 设置我出战的鱼
    action.set_action_fish(my_pos);
    // 到我的回合了，自动行动！
    auto_valid_action(my_pos, &action);
    // 行动！
    return action;
}
#include "Action.hpp"
#include <algorithm>
#include <string.h>
#include <time.h>

using namespace std;

int guess[4];
int pickf[12] = {4, 7, 9, 10, 1, 2, 5, 6, 3, 8, 11, 10};

bool canpick(vector<int> r, int x)
{
	for(int i = 0;i < r.size();i++)
	{
		if(x == r[i]) return true;
	}
	return false;
}

std::vector<int> AI::Pick(Game game)
{
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
	memset(guess, 0, 4 * sizeof(int));
	srand(time(0));
    pickfish.clear();
	int start = (game.round - 1) * 4;
	if(game.round == 1)
	{
		if(rand() % 2 == 0) pickf[11] += 12;
		else pickf[3] += 12;
	}
	for(int i = 0;i < 4;i++)
	{
		if(canpick(remain_fishes, (pickf[i] % 12))) pickfish.push_back(pickf[i]);
		else if(canpick(remain_fishes, (pickf[i + 4] % 12))) pickfish.push_back(pickf[i + 4]);
		else if(canpick(remain_fishes, (pickf[i + 8] % 12))) pickfish.push_back(pickf[i + 8]);
	}
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    Action action(game);
    int my_pos = (get_my_living_fishes())[(get_my_living_fishes()).size() - 1];
    action.set_action_fish(my_pos);
    auto_valid_action(my_pos, &action);
    return action;
}
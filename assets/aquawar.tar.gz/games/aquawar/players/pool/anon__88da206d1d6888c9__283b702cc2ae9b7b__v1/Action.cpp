#include "Action.hpp"
#include <algorithm>
#include <cmath>
#include <list>

int PICKFISH[3][4] = {{19, 7, 8, 4}, {3, 5, 6, 9}, {11, 1, 2, 10}}, PICKUSED[3] = {0, 0, 0};
bool ENEMYUSE12 = false, BUFF[4];
std::list<int> PREDICT[4];
std::list<int> ENEMYUSED;

int get_buff(int pos, std::vector<int> &my_living_fishes)
{
    if (!BUFF[my_living_fishes.back()] && pos != my_living_fishes.back())
    {
        BUFF[my_living_fishes.back()] = true;
        return my_living_fishes.back();
    }
    else
    {
        for (auto pos : my_living_fishes)
            if (!BUFF[pos])
            {
                BUFF[pos] = true;
                return pos;
            }
    }
    return my_living_fishes.back();
}

void list_remove(std::list<int> a, std::list<int> &v)
{
    if (!v.size())
        return;
    for (auto i : a)
        v.remove(i);
}

void list_set(std::list<int> a, std::list<int> &v)
{
    if (!v.size())
        return;
    std::list<int> tmp;
    std::set_intersection(a.begin(), a.end(),
                          v.begin(), v.end(),
                          std::back_inserter(tmp));
    v.clear();
    for (auto i : tmp)
        v.push_back(i);
}

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    // std::vector<int> remain_fishes = get_my_remain_fishes();
    // std::vector<int> pickfish;
    // pickfish.clear();
    // for(int i = 0; i < 4; i ++) pickfish.push_back(remain_fishes[i] == 12 ? 13 : remain_fishes[i]);
    // return pickfish;
    for (int i = 0; i < 4; i++)
    {
        PREDICT[i].clear();
        for (int j = 1; j <= 11; j++)
            PREDICT[i].push_back(j);
        BUFF[i] = false;
    }
    int pick;
    std::vector<int> pickfish;
    pickfish.clear();
    if (game.round == 1 && get_first_mover())
        pick = 1;
    else
    {
        for (int i = 0; i < 3; i++)
            if (PICKUSED[i] == 0)
            {
                pick = i;
                break;
            }
    }
    for (int i = 0; i < 4; i++)
        pickfish.push_back(PICKFISH[pick][i]);
    PICKUSED[pick] = 1;
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    int enemy_pos = game.enemy_action.action_fish;
    if (enemy_pos != -1)
    {
        for (auto atk : game.enemy_action.enemy_expected_injury)
        {
            if (game.enemy_action.is_skill && (atk == 120))
            {
                list_remove({1, 3, 6, 8, 11}, PREDICT[enemy_pos]);
            }
            else if (game.enemy_action.is_skill && (atk == 138 || atk == 161 || atk == 156 || atk == 182))
                list_set({10}, PREDICT[enemy_pos]);
            else if (!game.enemy_action.is_skill && (atk >= 150))
                list_set({2, 4}, PREDICT[enemy_pos]);
        }
        for (int i = 0; i < game.enemy_action.num_friend_injury; i++)
        {
            if (game.enemy_action.friend_excepted_injury[i] == 50 && game.enemy_action.friend_injury_traceable[i] == true)
                list_set({2, 4}, PREDICT[enemy_pos]);
        }
    }
    if (game.my_action.action_fish != -1)
    {
        for (int i = 0; i < game.my_action.num_enemy_injury; i++)
            if (game.my_action.enemy_excepted_injury[i] > 0 && game.my_action.enemy_injury[i] == 0)
                list_set({5, 6, 7}, PREDICT[game.my_action.enemy_targets[i]]);
    }
    if (game.my_assert.assertResult == true && game.my_assert.assertContent != 0)
    {
        ENEMYUSED.push_back(game.my_assert.assertContent);
    }
    if (ENEMYUSED.size())
    {
        for (int i = 0; i < 4; i++)
            list_remove(ENEMYUSED, PREDICT[i]);
    }
    for (int i = 0; i < 4; i++)
        if (get_enemy_id(i) == -1 && get_enemy_hp(i) > 0 && PREDICT[i].size() <= 2 && PREDICT[i].size() > 0)
        {
            int predict_id = PREDICT[i].back();
            PREDICT[i].pop_back();
            // if (!ENEMYUSE12 && PREDICT[i - 1].size() == 0)
            //     PREDICT[i - 1].push_back(12);
            return std::make_pair(i, predict_id);
        }

    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    std::vector<int> my_living_fishes = get_my_living_fishes();
    std::vector<int> lowest_health_enemies = get_lowest_health_enemies();
    int lowest_enemy_hp = get_enemy_hp(lowest_health_enemies.front());
    int atk_enemy_pos = lowest_health_enemies.front();
    int highest_my_atk = 0, highest_my_atk_pos = -1;
    for (auto pos : my_living_fishes)
    {
        if (get_my_atk(pos) > highest_my_atk)
        {
            highest_my_atk = get_my_atk(pos);
            highest_my_atk_pos = pos;
        }
    }
    //第一轮：考虑我方单位能用AOE一次攻击击杀的单位
    float aoe_atk = 0;
    int aoe_pos = -1;
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == clownfish)
        {
            int target = get_buff(pos, my_living_fishes);
            if (target != pos && get_my_atk(pos) * 0.35 > lowest_enemy_hp && get_skill_used(pos) < 3)
            {
                action.set_action_fish(pos);
                action.set_action_type(1);
                action.set_friend_target(target);
                action.set_enemy_target(atk_enemy_pos);
                return action;
            }
            if (target == pos)
            {
                BUFF[target] = false;
            }
        }
        else if (id == spray || id == eel)
        {
            if (get_my_atk(pos) * 0.35 > aoe_atk)
            {
                aoe_atk = get_my_atk(pos) * 0.35;
                aoe_pos = pos;
            }
        }
    }
    if (aoe_atk >= lowest_enemy_hp)
    {
        action.set_action_fish(aoe_pos);
        action.set_action_type(1);
        action.set_enemy_target(atk_enemy_pos);
        return action;
    }
    //第二轮：考虑我方单位用主动技能击杀，优先考虑带增益效果的
    float single_atk = 0;
    int single_atk_pos = -1, single_atk_type = 1;
    if (lowest_enemy_hp <= 120)
    {
        for (auto pos : my_living_fishes)
        {
            int id = abs(get_my_id(pos));
            int target = get_buff(pos, my_living_fishes);
            if (target != pos && (id == turtle || id == imitator) && get_skill_used(pos) < 3)
            {
                action.set_action_fish(pos);
                action.set_action_type(1);
                action.set_friend_target(target);
                action.set_enemy_target(atk_enemy_pos);
                return action;
            }
            if (target == pos)
            {
                BUFF[target] = false;
            }
            else if (id == barracuda || id == whiteshark || id == hammerhead)
            {
                if (get_my_atk(pos) * 1.2 > single_atk)
                {
                    single_atk = get_my_atk(pos) * 1.2;
                    single_atk_pos = pos;
                    single_atk_type = 1;
                }
            }
        }
    }
    if (lowest_enemy_hp <= 160)
    {
        for (auto pos : my_living_fishes)
        {
            int id = abs(get_my_id(pos));
            if (id == whiteshark || id == hammerhead)
            {
                if (get_my_atk(pos) * 1.4 > single_atk)
                {
                    single_atk = get_my_atk(pos) * 1.4;
                    single_atk_pos = pos;
                    single_atk_type = 1;
                }
            }
        }
    }
    for (auto pos : my_living_fishes)
    {
        if (get_my_atk(pos) * 0.5 > single_atk && get_my_atk(pos) * 0.5 > lowest_enemy_hp)
        {
            single_atk = get_my_atk(pos) * 0.5;
            single_atk_pos = pos;
            single_atk_type = 0;
        }
    }
    if (single_atk > 0)
    {
        action.set_action_fish(single_atk_pos);
        action.set_action_type(single_atk_type);
        action.set_enemy_target(atk_enemy_pos);
        return action;
    }
    //第2.5轮，考虑献祭翻车鱼
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == sunfish && get_my_hp(pos) * 2 <= get_my_atk(pos))
        {
            action.set_action_fish(pos);
            action.set_action_type(0);
            action.set_enemy_target(atk_enemy_pos);
            return action;
        }
    }
    //第三轮：考虑回复我方单位中血量较少的
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == mobula || id == octopus)
        {
            for (auto friend_pos : my_living_fishes)
            {
                if (!BUFF[friend_pos] && (abs(get_my_id(friend_pos)) == sunfish || abs(get_my_id(friend_pos)) == whiteshark || abs(get_my_id(friend_pos)) == hammerhead) && get_my_hp(friend_pos) <= 200)
                {
                    BUFF[friend_pos] = true;
                    action.set_action_fish(pos);
                    action.set_action_type(1);
                    action.set_friend_target(friend_pos);
                    return action;
                }
            }
        }
    }
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == mobula || id == octopus)
        {
            for (auto friend_pos : my_living_fishes)
            {
                if (!BUFF[friend_pos] && get_my_hp(friend_pos) <= 140)
                {
                    BUFF[friend_pos] = true;
                    action.set_action_fish(pos);
                    action.set_action_type(1);
                    action.set_friend_target(friend_pos);
                    return action;
                }
            }
        }
    }
    //第四轮：考虑翻车鱼加伤害
    int highest_my_hp = 0, highest_my_hp_pos = -1;
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == sunfish && (get_skill_used(pos) <= 4 || random(0, 1) < 0.2) && get_my_atk(pos) <= 800)
        {
            for (auto friend_pos : my_living_fishes)
            {
                if (pos != friend_pos && get_my_hp(friend_pos) > highest_my_hp)
                {
                    highest_my_hp = get_my_hp(friend_pos);
                    highest_my_hp_pos = friend_pos;
                }
            }
            if (highest_my_hp >= 200)
            {
                BUFF[highest_my_hp_pos] = false;
                action.set_action_fish(pos);
                action.set_action_type(1);
                action.set_friend_target(highest_my_hp_pos);
                return action;
            }
        }
    }
    //第五轮：优先使用我方高攻的鱼攻击对方高攻的鱼
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == whiteshark || id == hammerhead)
        {
            action.set_action_fish(pos);
            action.set_action_type(1);
            action.set_enemy_target(atk_enemy_pos);
            return action;
        }
        else if (id == sunfish)
        {
            action.set_action_fish(pos);
            action.set_action_type(0);
            action.set_enemy_target(atk_enemy_pos);
            return action;
        }
    }
    for (auto pos : my_living_fishes)
    {
        int id = abs(get_my_id(pos));
        if (id == spray || id == eel || id == barracuda)
        {
            action.set_action_fish(pos);
            action.set_action_type(1);
            action.set_enemy_target(atk_enemy_pos);
            return action;
        }
    }
    action.set_action_fish(highest_my_atk_pos);
    action.set_action_type(0);
    action.set_enemy_target(atk_enemy_pos);
    return action;
}
#include "Action.hpp"
#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>

using namespace std;

bool hasasserted[13];
bool hasuncover[4];
int num;
int sum[4];
int times=0;

struct fish{
    vector<int> possible;
    skill_type active_before;
    skill_type active_after;
    std::array<passive_type, max_length> passive_before;
    std::array<passive_type, max_length> passive_after;
    int activetimes;
    int passivetimes;
}present[4];

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    if(game.round==1){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(8);
        pickfish.push_back(3);
        pickfish.push_back(10);
        pickfish.push_back(4);
        return pickfish;
    }
    if(game.round==2){
        std::vector<int> pickfish;
        pickfish.clear();
        pickfish.push_back(17);
        pickfish.push_back(7);
        pickfish.push_back(6);
        pickfish.push_back(11);
        return pickfish;
    }
    std::vector<int> pickfish;
    pickfish.clear();
    pickfish.push_back(2);
    pickfish.push_back(5);
    pickfish.push_back(9);
    pickfish.push_back(1);
    return pickfish;
}

struct Fish1 {

    int active = -1;
    int active1 = -1;

    int passive = -1;

    int block_num = -1;
    //’‚ «”√¿¥ø¥“ª∏ˆøÈ¿Ô√Ê”–º∏∏ˆø…ƒ‹…Ì∑›£¨»Áπ˚ «1ƒ«√¥catbe∑«-1æÕ «ƒ‚Ã¨£¨»Áπ˚ «2ƒ«√¥µ»µΩcantbe£®1£©∑«-1æÕ «ƒ‚Ã¨
    std::vector<int> suspect_id;
    int cant_be=-1;
    int cant_be1=-1;
    //0 «≥ı º◊¥Ã¨

    void update_active(int action)
    {
        if (active == -1)
        {
            active = action;
        }
        else if (active != action)
        {
            active1 = action;
        }
    }

    void update_passive(int action)
    {
        if (passive == -1)
        {
            passive = action;
        }
    }

    //∏¸–¬¥À”„◊¥Ã¨
};

// <assert_block>
struct identity {
    int id[2] = { 0 };
    int num;
};

//µ⁄“ªŒ¨ «÷˜∂Øººƒ‹£¨µ⁄∂˛Œ¨ «±ª∂Øººƒ‹
identity skill_map[5][5];

bool asserted_fish[12];
bool avator_found;

void set_skill_map()
{
    skill_map[aoe][counter].id[0] = 1;
    skill_map[aoe][counter].id[1] = 11;
    skill_map[aoe][counter].num = 2;

    skill_map[aoe][deflect].id[0] = 3;
    skill_map[aoe][deflect].num = 1;

    skill_map[infight][counter].id[0] = 2;
    skill_map[infight][counter].num = 1;

    skill_map[infight][deflect].id[0] = 4;
    skill_map[infight][deflect].num = 1;

    skill_map[crit][reduce].id[0]  = 5;
    skill_map[crit][reduce].id[1]  = 7;
    skill_map[crit][reduce].num = 2;

    skill_map[crit][heal].id[0]  = 9;
    skill_map[crit][heal].num = 1;

    //¥∏Õ∑µ√Ãÿ≈–œ¬£∫º»”–±©ª˜£¨”÷≤ªªÿ—™
    skill_map[crit][explode].id[0] = 10;
    skill_map[crit][explode].num = 1;

    skill_map[subtle][reduce].id[0]  = 6;
    skill_map[subtle][reduce].id[1]  = 7;
    skill_map[subtle][reduce].num = 2;

    skill_map[subtle][heal].id[0] = 8;
    skill_map[subtle][heal].num = 1;

    return;
}




void analysis_identity(Fish1* fish)
{
    identity temp;
    bool clear = false;

    //Ãÿ≈–Õı∞À°¢–°≥Û
    if (fish->active1 != -1 && fish->passive != -1)
    {
        if (fish->active == aoe)
        {
            fish->suspect_id.clear();
            if (asserted_fish[11] == false)
            fish->suspect_id.push_back(11);
        }

        if (fish->active == crit)
        {
            fish->suspect_id.clear();
            if (asserted_fish[7] == false)
            fish->suspect_id.push_back(7);
        }

        fish->block_num = 1;
        clear = true;
    }
    //∆‰À˚”„
    else if (fish->active != -1 && fish->passive != -1)
    {
        temp = skill_map[fish->active][fish->passive];
        clear = true;
        for (int i = 0; i < 2; i++)
        {
            //Œ¥±ª∂œ—‘π˝°¢¥À…Ì∑›Œ¥±ª≈≈≥˝π˝°¢≤ª «ø’…Ì∑›£®0£©
            if (asserted_fish[temp.id[i]] == false && temp.id[i] != fish->cant_be && temp.id[i])
            {
                fish->suspect_id.push_back(temp.id[i]);
                fish->block_num = temp.num;
            }
        }
    }
    return;
}


Fish1 enemy[4];

std::pair<int, int> AI::Assert(Game game)
{
    Action temp(game);

    //∏¸–¬…œªÿ∂œ—‘µƒΩ·π˚
    if (game.my_assert.assertResult == true)
    {
        int id = game.my_assert.assertContent;
        asserted_fish[id] = true;
    }

    else if (game.my_assert.assertResult == false && game.my_assert.assertContent != -1)
    {
        int pos = game.my_assert.assertPos;
        //œ»∏¸–¬cantbe
        if (enemy[pos].cant_be == -1)
        {
             enemy[pos].cant_be = game.my_assert.assertContent;
        }
        else if (enemy[pos].cant_be1 == -1)
        {
             enemy[pos].cant_be1 = game.my_assert.assertContent;
        }

        //ƒ‚Ã¨”„£¨block¿Ô”–“ª∏ˆø…ƒ‹…Ì∑›µƒ
        else if (enemy[pos].cant_be != -1 && enemy->block_num == 1 && avator_found == false)
        {
            avator_found = true;
            return make_pair(pos, 12);
        }
        //ƒ‚Ã¨”„£¨block¿Ô”–¡Ω∏ˆø…ƒ‹…Ì∑›µƒ
        else if (enemy[pos].cant_be1 != -1 && enemy->block_num == 2 && avator_found == false)
        {
            avator_found = true;
            return make_pair(pos, 12);
        }

    }

    //∏¸–¬÷˜∂Øººƒ‹
    int attacker = game.enemy_action.action_fish;
    if (game.enemy_action.is_skill)
    {
        int active = game.enemy_action.type;
        enemy[attacker].update_active(active);
    }

    //∏¸–¬±ª∂Øººƒ‹
    int passive_num = game.enemy_action.num_enemy_passives;
    std::array<int, 24> passive_id = game.enemy_action.enemy_passives_id;
    std::array<passive_type, 24> passive_type = game.enemy_action.enemy_types;
    for (int i = 1; i <= passive_num; i++)
    {
        int id = passive_id[i];
        int type = passive_type[i];
        enemy[id].update_passive(type);
    }

    //∑÷Œˆæ÷√Ê£¨≈–∂œ «∑Òø…“‘∂œ—‘

    for (int i = 0; i < 4; i++)
    {
        analysis_identity(&enemy[i]);
        if (enemy[i].suspect_id.size()!=0)
        {
            int id = enemy[i].suspect_id.front();
            return make_pair(i, id);
        }

    }

    return make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    if(game.round == 1){
        Action action(game);
        if(times<3){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
            times++;
            return action;
        }
        int my_atk = get_my_atk(0);
        int enemy_hp[4] = {0};
        int min=400;
        int k=0;
        for(int i=0;i<4;i++){
            enemy_hp[i]=get_enemy_hp(i);
            if(enemy_hp[i]<min && enemy_hp[i]>0){
                min=enemy_hp[i];
                k=i;
            }
        }
        if(my_atk>=min*2){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
        int my_hp=get_my_hp(0);
        if(my_hp>0){
        action.set_action_fish(0);
        action.set_action_type(1);
        action.set_friend_target(0);
        return action;
        }
        my_hp=get_my_hp(1);
        if(my_hp>0){
            action.set_action_fish(1);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        my_hp=get_my_hp(2);
        if(my_hp>0){
            action.set_action_fish(2);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        my_hp=get_my_hp(3);
        if(my_hp>0){
            action.set_action_fish(3);
            action.set_action_type(0);
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
    }
    
    if(game.round==2){
        Action action(game);
        int my_hp = get_my_hp(1);
        int skill_used_times = get_skill_used(1);
        if(my_hp>0 && skill_used_times<3){
            if(game.enemy_action.type==crit){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(k);
                return action;
            }
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(1);
                action.set_action_type(1);
                action.set_friend_target(0);
                action.set_enemy_target(k);
                return action;
            }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_friend_target(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
        }
        
        my_hp = get_my_hp(0);
        if(my_hp>0){
            if(game.enemy_action.type==crit){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(k);
                return action;
            }
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(0);
                action.set_action_type(1);
                action.set_enemy_target(lowest_health_enemy);
                return action;
        }
        
        my_hp = get_my_hp(2);
        if(my_hp>0){
            if(game.enemy_action.type==crit){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(2);
                action.set_action_type(0);
                action.set_enemy_target(lowest_health_enemy);
                return action;
        }
        
        if(game.enemy_action.type==crit){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
            int enemy_id = get_enemy_id(0);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(0);
                return action;
            }
            enemy_id = get_enemy_id(1);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(1);
                return action;
            }
            enemy_id = get_enemy_id(2);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(2);
                return action;
            }
            enemy_id = get_enemy_id(3);
            if(enemy_id==5 || enemy_id==7){
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(3);
                return action;
            }
            if(game.enemy_action.type==infight){
                int k=game.enemy_action.action_fish;
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(k);
                return action;
            }
                int lowest_health_enemy = get_lowest_health_enemy();
                action.set_action_fish(3);
                action.set_action_type(0);
                action.set_enemy_target(lowest_health_enemy);
                return action;
    }
    
    Action action(game);
    int my_hp = get_my_hp(1);
    if(my_hp>0){
        if(game.enemy_action.type==crit){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }
        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(1);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }
    
    my_hp = get_my_hp(2);
    if(my_hp>0){
        if(game.enemy_action.type==crit){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(2);
            action.set_action_type(1);
            action.set_enemy_target(k);
            return action;
        }
    int enemy_id = get_enemy_id(0);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(0);
        return action;
    }
    enemy_id = get_enemy_id(1);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(1);
        return action;
    }
    enemy_id = get_enemy_id(2);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(2);
        return action;
    }
    enemy_id = get_enemy_id(3);
    if(enemy_id==5 || enemy_id==7){
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(3);
        return action;
    }
    if(game.enemy_action.type==infight){
        int k=game.enemy_action.action_fish;
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(k);
        return action;
    }
        int lowest_health_enemy = get_lowest_health_enemy();
        action.set_action_fish(2);
        action.set_action_type(1);
        action.set_enemy_target(lowest_health_enemy);
        return action;
    }
    
    my_hp = get_my_hp(0);
    if(my_hp>0){
        if(game.enemy_action.type==crit){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
    }
    
        if(game.enemy_action.type==crit){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
        int enemy_id = get_enemy_id(0);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(0);
            return action;
        }
        enemy_id = get_enemy_id(1);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(1);
            return action;
        }
        enemy_id = get_enemy_id(2);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(2);
            return action;
        }
        enemy_id = get_enemy_id(3);
        if(enemy_id==5 || enemy_id==7){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(3);
            return action;
        }
        if(game.enemy_action.type==infight){
            int k=game.enemy_action.action_fish;
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(k);
            return action;
        }
            int lowest_health_enemy = get_lowest_health_enemy();
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(lowest_health_enemy);
            return action;
}





int main()
{
    memset(hasuncover,0,sizeof(hasuncover));
    
    set_skill_map();
    AI *myAI = new AI();
    myAI->run();
    delete (myAI);
    return 0;
}

#include "Action.hpp"
#include <algorithm>
#include <ctime>
#include <cmath>
#include <sys/timeb.h>

int assert_result[13] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    last_assert_num = -1, crit_choice = -1, counter_hp[4] = {0};
bool must_be_true = false, is_counter[4] = {false, false, false, false}, counter_assert = false;
skill_type last_assert_type = aoe;

struct Fish_For_Assert
{
    bool is_aoe = false;
    bool is_inflight = false;
    bool is_crit = false;
    bool is_subtle = false;
    bool is_flee = false;
    bool is_heal = false;
    bool is_injury = false;
    int max_aoe = 0;
    int max_crit = 0;
    int max_normalattack = 0;
}assert_fish[12];

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
    pickfish.clear();
    int remain = remain_fishes.size();
    if (remain == 12)
    {
        pickfish.push_back(1);
        pickfish.push_back(10);
        pickfish.push_back(17);
        pickfish.push_back(7);
    }
    else if (remain == 8)
    {
        pickfish.push_back(3);
        pickfish.push_back(9);
        pickfish.push_back(8);
        pickfish.push_back(5);
    }
    else
    {
        pickfish.push_back(11);
        pickfish.push_back(2);
        pickfish.push_back(4);
        pickfish.push_back(6);
    }
    return pickfish;
}

std::pair<int, int> AI::Assert(Game game)
{
    // TODO: fill your code
    bool is_round1 = true;
    for (int i = 0; i < 4; i++)
    {
        if (get_my_hp(i) != 400 || get_enemy_hp(i) != 400)
        {
            is_round1 = false;
            break;
        }
    }
    if (game.my_assert.assertResult)
    {
        counter_assert = false;
        crit_choice = -1;
        must_be_true = false;
        last_assert_type = aoe;
        last_assert_num = -1;
        assert_result[game.my_assert.assertContent] = 0;
    }
    int k = game.round - 1;
    if (game.enemy_action.type == aoe)
    {
        std::cerr << "1" << std::endl;
        assert_fish[game.enemy_action.action_fish + 4 * k].is_aoe = true;
        if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_aoe)
            assert_fish[game.enemy_action.action_fish + 4 * k].max_aoe = game.enemy_action.enemy_expected_injury[0];
    }
    else if (game.enemy_action.type == infight)
        assert_fish[game.enemy_action.action_fish + 4 * k].is_inflight = true;
    else if (game.enemy_action.type == crit)
    {
        assert_fish[game.enemy_action.action_fish + 4 * k].is_crit = true;
        if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_crit)
            assert_fish[game.enemy_action.action_fish + 4 * k].max_crit = game.enemy_action.enemy_expected_injury[0];
    }
    else if (game.enemy_action.type == subtle)
    {
        assert_fish[game.enemy_action.action_fish + 4 * k].is_subtle = true;
    }
    else if (game.enemy_action.type == normalattack)
    {
        std::cerr << "here" << std::endl;
        if (game.enemy_action.enemy_expected_injury[0] > assert_fish[game.enemy_action.action_fish + 4 * k].max_normalattack)
            assert_fish[game.enemy_action.action_fish + 4 * k].max_normalattack = game.enemy_action.enemy_expected_injury[0];
    }
    std::cerr << "there" << std::endl;
    for (int i = 0; i < game.my_action.num_enemy_injury; i++)
        assert_fish[game.my_action.enemy_injury[i] + 4 * k].is_injury = true;
    for (int i = 0; i < game.my_action.num_enemy_passives; i++)
    {
        if (game.my_action.enemy_types[i] == reduce && game.my_action.enemy_passive_value[i] == 0)
            assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].is_flee = true;
        else if (game.my_action.enemy_types[i] == heal)
            assert_fish[game.my_action.enemy_passives_id[i] + 4 * k].is_heal = true;
        else if (game.my_action.enemy_types[i] == counter)
        {
            is_counter[k] = true;
            counter_hp[k] = game.my_action.friend_excepted_injury[0];
        }
    }
    int assert_aoe[12] = {0}, assert_inflight[12] = {0}, assert_crit[12] = {0}, assert_subtle[12] = {0},
        assert_normal[12] = {0}, assert_crit_flee[12] = {0}, assert_counter[12] = {0};
    int num_aoe = 0, num_inflight = 0, num_crit = 0, num_subtle = 0, num_normal = 0, num_crit_flee = 0, num_counter = 0;
    for (int i = 1; i <= 12; i++)
    {
        if (assert_result[i] == 1)
        {
            if (i == 1 || i == 3 || i == 11 || i == 12)
                assert_aoe[num_aoe++] = i;
            if (i == 2 || i == 4 || i == 12)
                assert_inflight[num_inflight++] = i;
            if (i == 5 || i == 7 || i == 9 || i == 10 || i == 12)
                assert_crit[num_crit++] = i;
            if (i == 6 || i == 8 || i == 12)
                assert_subtle[num_subtle++] = i;
            if (i == 3 || i == 4 || i == 12)
                assert_normal[num_normal++] = i;
            if (i == 5 || i == 7 || i == 12)
                assert_crit_flee[num_crit_flee++] = i;
            if (i == 1 || i == 2 || i == 11 || i == 12)
                assert_counter[num_counter++] = i;
        }
    }
    if (!is_round1 && must_be_true && !game.my_assert.assertResult && game.my_assert.assertContent != 0 &&
            get_enemy_hp(game.my_assert.assertPos) > 0)
    {
        must_be_true = false;
        return std::make_pair(game.my_assert.assertPos, 12);
    }
    else if (!is_round1 && !must_be_true && !game.my_assert.assertResult && game.my_assert.assertContent != 0 &&
                last_assert_num != -1 && get_enemy_hp(game.my_assert.assertPos) > 0)
    {
        if (!counter_assert)
        {
            if (last_assert_type == aoe && assert_aoe[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_aoe[++last_assert_num]);
            else if (last_assert_type == infight && assert_inflight[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_inflight[++last_assert_num]);
            else if (last_assert_type == crit && crit_choice == 0 && assert_crit[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_crit_flee[++last_assert_num]);
            else if (last_assert_type == crit && crit_choice == 1 && assert_crit[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_crit[++last_assert_num]);
            else if (last_assert_type == subtle && assert_subtle[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_subtle[++last_assert_num]);
            else if (last_assert_type == normalattack && assert_normal[last_assert_num + 1] != 0)
                return std::make_pair(game.my_assert.assertPos, assert_normal[++last_assert_num]);
        }
        else if (counter_assert && assert_counter[last_assert_num + 1] != 0)
            return std::make_pair(game.my_assert.assertPos, assert_counter[++last_assert_num]);
    }
    int num_not_assert = 0;
    for (int i = 0; i < 4; i++)
    {
        if (get_enemy_id(i) == -1 && !is_round1 && get_enemy_hp(i) > 0)
        {
            if (assert_fish[4 * k + i].max_normalattack == 60 && !assert_fish[4 * k + i].is_subtle)
            {
                last_assert_num = 0;
                last_assert_type = normalattack;
                return std::make_pair(i, assert_normal[last_assert_num]);
            }
            if (assert_fish[4 * k + i].is_aoe)
            {
                if (assert_fish[4 * k + i].max_aoe == 42)
                {
                    must_be_true = true;
                    return std::make_pair(i, 3);
                }
            }
            else if (assert_fish[4 * k + i].is_inflight)
            {
                last_assert_type = infight;
                last_assert_num = 0;
                return std::make_pair(i, assert_inflight[last_assert_num]);
            }
            else if (assert_fish[4 * k + i].is_crit)
            {
                if (assert_fish[4 * k + i].max_crit == 138 || assert_fish[4 * k + i].max_crit == 161)
                {
                    must_be_true = true;
                    return std::make_pair(i, 10);
                }
                else if (get_enemy_hp(i) < 80 && assert_fish[4 * k + i].max_crit == 140)
                {
                    must_be_true = true;
                    return std::make_pair(i, 9);
                }
                else if (assert_fish[4 * k + i].is_injury && !assert_fish[4 * k + i].is_heal && !assert_fish[4 * k + i].is_flee)
                {
                    must_be_true = true;
                    return std::make_pair(i, 10);
                }
                else if (assert_fish[4 * k + i].is_flee)
                {
                    crit_choice = 0;
                    last_assert_num = 0;
                    last_assert_type = crit;
                    return std::make_pair(i, assert_crit_flee[last_assert_num]);
                }
            }
            else if (assert_fish[4 * k + i].is_subtle)
            {
                if (!assert_fish[4 * k + i].is_crit && !assert_fish[4 * k + i].is_aoe)
                {
                    last_assert_type = subtle;
                    last_assert_num = 0;
                    return std::make_pair(i, assert_subtle[last_assert_num]);
                }
                else if (assert_fish[4 * k + i].is_crit && !assert_fish[4 * k + i].is_aoe)
                {
                    must_be_true = true;
                    return std::make_pair(i, 7);
                }
                else if (!assert_fish[4 * k + i].is_crit && assert_fish[4 * k + i].is_aoe)
                {
                    must_be_true = true;
                    return std::make_pair(i, 11);
                }
            }
            num_not_assert++;
        }
    }
    if (is_counter[k] && num_not_assert == 1 && num_counter <= 3 && counter_hp[k] % 30 == 0 && !is_round1)
    {
        int counter_exist = 0;
        for (int i = 0; i < 4; i++)
        {
            if (get_enemy_id(i) == 1 || get_enemy_id(i) == 2 || get_enemy_id(i) == 11 || get_enemy_id(i) == 12)
                counter_exist++;
        }
        if (counter_exist < counter_hp[k] / 30)
        {
            for (int i = 0; i < 4; i++)
            {
                if (get_enemy_id(i) == -1 && get_enemy_hp(i) > 0)
                {
                    counter_assert = true;
                    last_assert_num = 0;
                    return std::make_pair(i, assert_counter[last_assert_num]);
                }
            }
        }
    }
    for (int i = 0; i < 4; i++)
    {
        if (get_enemy_id(i) == -1 && !is_round1 && get_enemy_hp(i) > 0)
        {
            if (assert_fish[4 * k + i].is_aoe)
            {
                if (num_aoe <= 3)
                {
                    last_assert_type = aoe;
                    last_assert_num = 0;
                    return std::make_pair(i, assert_aoe[last_assert_num]);
                }
            }
            else if (assert_fish[4 * k + i].is_crit)
            {
                if (num_crit <= 3)
                {
                    crit_choice = 1;
                    last_assert_num = 0;
                    last_assert_type = crit;
                    return std::make_pair(i, assert_crit[last_assert_num]);
                }
            }
            else if (assert_fish[4 * k + i].is_subtle)
            {
                if (num_subtle <= 3)
                {
                    last_assert_num = 0;
                    last_assert_type = subtle;
                    return std::make_pair(i, assert_subtle[last_assert_num]);
                }
            }
        }
    }
    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    srand(time(NULL));
    struct timeb timeSeed;
    ftime(&timeSeed);
    srand(timeSeed.time * 1000 + timeSeed.millitm);
    std::vector<int> my_living_fishes = get_my_living_fishes();
    int enemy_target_prime = -1;
    if ((game.enemy_action.type == infight || game.enemy_action.enemy_expected_injury[0] >= 80) &&
            get_enemy_hp(game.enemy_action.action_fish) > 0)
        enemy_target_prime = game.enemy_action.action_fish;
    if (game.round == 1)
    {
        int my_pos = my_living_fishes[0];
        bool flag_spray = false, flag_hammerhead = false, flag_barracuda = false, flag_turtle = false;
        int min_hp = 500, min_pos = -1;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_spray = true;
            else if (my_living_fishes[i] == 1)
                flag_hammerhead = true;
            else if (my_living_fishes[i] == 2)
                flag_barracuda = true;
            else if (my_living_fishes[i] == 3)
                flag_turtle = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (flag_spray && get_skill_used(0) < 3 && min_hp >= 200)
            my_pos = 0;
        else
        {
            if (rand() % 5 <= 1 && flag_spray)
                my_pos = 0;
            else
            {
                if (flag_turtle && get_skill_used(3) < 3)
                    my_pos = 3;
                else if (flag_barracuda)
                    my_pos = 2;
                else if (flag_hammerhead)
                    my_pos = 1;
            }
        }
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 1)
        {
            if (get_enemy_living_fishes().size() > 1)
            {
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 7)
        {
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            if (my_living_ally.size() > 0)
            {
                int random_choice = rand() % my_living_ally.size();
                ally_pos = my_living_ally[random_choice];
            }
            int tmp_choice = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            if (get_skill_used(3) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                action.set_enemy_target(enemy_pos);
            }
            else
            {
                action.set_action_type(0);
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 10)
        {
            action.set_action_type(1);
            int tmp_choice = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            action.set_enemy_target(enemy_pos);
        }
        else
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(1);
            action.set_enemy_target(enemy_pos);
        }
    }
    else if (game.round == 2)
    {
        int my_pos = my_living_fishes[0];
        bool flag_eel = false, flag_whiteshark = false, flag_octopus = false, flag_barracuda = false;
        int min_hp = 500, min_pos = -1;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_eel = true;
            else if (my_living_fishes[i] == 1)
                flag_whiteshark = true;
            else if (my_living_fishes[i] == 2)
                flag_octopus = true;
            else if (my_living_fishes[i] == 3)
                flag_barracuda = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (flag_eel && get_skill_used(0) < 3 && min_hp > 200)
            my_pos = 0;
        else
        {
            if (flag_eel && rand() % 5 <= 1)
                my_pos = 0;
            else
            {
                if (flag_barracuda)
                    my_pos = 3;
                else if (flag_whiteshark)
                    my_pos = 1;
                else
                    my_pos = 2;
            }
        }
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 3)
        {
            if (get_enemy_living_fishes().size() > 1)
            {
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 5)
        {
            std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
            int tmp_choice = rand() % enemy_living_fishes.size();
            int enemy_pos = enemy_living_fishes[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_action_type(1);
            action.set_enemy_target(enemy_pos);
        }
        else if (abs(get_my_id(my_pos)) == 8)
        {
            int ally_pos = min_pos;
            if (get_my_hp(my_pos) <= 200)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) < 280 || (game.enemy_action.type == subtle &&
                get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (rand() % 2 == 0 && get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish))
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
                else
                {
                    std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
                    int tmp_choice = rand() % enemy_living_fishes.size();
                    int enemy_pos = enemy_living_fishes[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_action_type(0);
                    action.set_enemy_target(enemy_pos);
                }
            }
        }
        else if (abs(get_my_id(my_pos)) == 9)
        {
            action.set_action_type(1);
            int tmp_choice = rand() % (get_lowest_health_enemies().size());
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            action.set_enemy_target(enemy_pos);
        }
    }
    else if (game.round == 3)
    {
        int my_pos = my_living_fishes[0];
        int min_hp = 500, min_pos = -1;
        bool flag_clownfish = false, flag_flame = false, flag_sunfish = false, flag_mobula = false;
        for (int i = 0; i < my_living_fishes.size(); i++)
        {
            if (my_living_fishes[i] == 0)
                flag_clownfish = true;
            else if (my_living_fishes[i] == 1)
                flag_flame = true;
            else if (my_living_fishes[i] == 2)
                flag_sunfish = true;
            else if (my_living_fishes[i] == 3)
                flag_mobula = true;
            if (get_my_hp(my_living_fishes[i]) < min_hp)
            {
                min_hp = get_my_hp(my_living_fishes[i]);
                min_pos = my_living_fishes[i];
            }
        }
        if (flag_clownfish && get_skill_used(0) < 3)
            my_pos = 0;
        else if (flag_mobula)
            my_pos = 3;
        action.set_action_fish(my_pos);
        if (abs(get_my_id(my_pos)) == 11)
        {
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            if (my_living_ally.size() > 0)
            {
                int random_choice = rand() % my_living_ally.size();
                ally_pos = my_living_ally[random_choice];
            }
            if (get_skill_used(0) < 3 && ally_pos != -1)
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
                action.set_enemy_target(-2);
            }
            else
            {
                action.set_action_type(0);
                int tmp_choice = rand() % (get_lowest_health_enemies().size());
                int enemy_pos = get_lowest_health_enemies()[tmp_choice];
                if (enemy_target_prime != -1)
                    enemy_pos = enemy_target_prime;
                action.set_enemy_target(enemy_pos);
            }
        }
        else if (abs(get_my_id(my_pos)) == 6)
        {
            int ally_pos = -1;
            std::vector<int> my_living_ally = get_my_living_ally(my_pos);
            if (my_living_ally.size() > 0)
            {
                int random_choice = rand() % my_living_ally.size();
                ally_pos = my_living_ally[random_choice];
            }
            if (get_my_hp(my_pos) <= 200)
                ally_pos = my_pos;
            if (get_my_atk(my_pos) < 280 || (game.enemy_action.type == subtle &&
                    get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish)))
            {
                action.set_action_type(1);
                action.set_friend_target(ally_pos);
            }
            else
            {
                if (rand() % 2 == 0 && get_my_atk(my_pos) < 2 * get_enemy_hp(game.enemy_action.action_fish))
                {
                    action.set_action_type(1);
                    action.set_friend_target(ally_pos);
                }
                else
                {
                    std::vector<int> enemy_living_fishes = get_enemy_living_fishes();
                    int tmp_choice = rand() % enemy_living_fishes.size();
                    int enemy_pos = enemy_living_fishes[tmp_choice];
                    if (enemy_target_prime != -1)
                        enemy_pos = enemy_target_prime;
                    action.set_action_type(0);
                    action.set_enemy_target(enemy_pos);
                }
            }
        }
        else
        {
            action.set_action_type(0);
            int tmp_choice = rand() % get_lowest_health_enemies().size();
            int enemy_pos = get_lowest_health_enemies()[tmp_choice];
            if (enemy_target_prime != -1)
                enemy_pos = enemy_target_prime;
            action.set_enemy_target(enemy_pos);
        }
    }
    return action;
}
#include "Action.hpp"
#include <algorithm>
#include <limits.h>
#include <memory.h>

std::ofstream wzadbg("wzadbga.txt");
void debug_msgg(std::string str){
    wzadbg << str << std::flush;
}

void bad(std::string str){
    wzadbg << str << "--BADBADBADBAD--" << std::flush;
    wzadbg.close();
    exit(-1);
}

struct MemoryUnit{
    int enemyATKhistory[4]={50,50,50,50};
    int enemyATKpotential[4];
    int myATKpotential[4];
    int skillcount[2]={0,0};
    int round_nb=0;
    int huihe=0;
    int num_my_living_fishes;
    int num_enemy_living_fishes;
}memoryUnit;

struct Intel{
    int passive_used[4][7];//attacked,counter,deflect,reduce70%,reduce100%,heal,explode
    bool inherent[4][7];//only deflect(2),reduce100%(4),heal(5),explode(6) can be inherent passive
    int skill_used[4][4];
    int masks[4];
    void init(){
        memset(passive_used,0,sizeof(passive_used));
        memset(inherent,0,sizeof(inherent));
        memset(skill_used,0,sizeof(skill_used));
        memset(masks,0,sizeof(masks));
    }
    void record_passive(int idp, passive_type type, int value){
        if(idp<0 || idp >= 4) bad("bad idp ");
        if(type==counter)passive_used[idp][1]++;
        if(type==deflect){passive_used[idp][2]++;if(masks[idp]==0)inherent[idp][2]=true;}
        if(type==reduce&&value>0.15)passive_used[idp][3]++;
        if(type==reduce&&value<0.15){passive_used[idp][4]++;inherent[idp][4]=true;}
        if(type==heal){passive_used[idp][5]++;if(masks[idp]==0)inherent[idp][5]=true;}
        if(type==explode){passive_used[idp][6]++;inherent[idp][6]=true;}
    }
    void analyze(Game game, bool partial=false){
        ActionInfo ma = game.my_action;
        ActionInfo ea = game.enemy_action;
        if(!partial){
        for(int i=0;i<ma.num_enemy_passives;i++){
            int idp = ma.enemy_passives_id[i];
            record_passive(idp,ma.enemy_types[i],ma.enemy_passive_value[i]);
        }
        for(int i=0;i<ma.num_enemy_targets;i++){
            int idt = ma.enemy_targets[i];
            if(idt<0||idt>=4)bad("bad idt ");
            masks[idt]=0;
            passive_used[idt][0]++;
        }
        }
        if(ea.is_skill){
            if(ea.action_fish<0||ea.action_fish>=4)bad("bad actionfish ");
            if(ea.type==aoe)skill_used[ea.action_fish][0]++;
            if(ea.type==infight){
                skill_used[ea.action_fish][1]++;
                if(ea.friend_targets[0]<0||ea.friend_targets[0]>=4)bad("bad friendtarget[0] ");
                masks[ea.friend_targets[0]]=0;
            }
            if(ea.type==crit)skill_used[ea.action_fish][2]++;
            if(ea.type==subtle){
                skill_used[ea.action_fish][3]++;
                for(int i=0;i<4;i++)masks[i]++;
            }
        }
    }
    void updateATK(Game game){
        int& nmlf = memoryUnit.num_my_living_fishes; nmlf = 0;
        for(int i=0;i<4;i++)if(game.my_fish[i].hp>0)nmlf++;
        int& nelf = memoryUnit.num_enemy_living_fishes; nelf = 0;
        for(int i=0;i<4;i++)if(game.enemy_fish[i].hp>0)nelf++;
        int total = 0; ActionInfo ea = game.enemy_action;
        for(int i=0;i<ea.num_enemy_injury;i++){
            total+=ea.enemy_injury[i];
        }
        if(memoryUnit.enemyATKhistory[ea.action_fish]<total)memoryUnit.enemyATKhistory[ea.action_fish]=total;
        for(int pos=0;pos<4;pos++){
            int maxP = 50;
            if(skill_used[pos][0]>0&&maxP<35*nmlf)maxP=35*nmlf;
            if(skill_used[pos][1]>0&&maxP<50+35*skill_used[pos][1])maxP=50+35*skill_used[pos][1];
            if(skill_used[pos][2]>0&&maxP<130)maxP=130;
            if(skill_used[pos][3]>0&&maxP<50+10*skill_used[pos][3])maxP=50+10*skill_used[pos][3];//prepared for octopus and mobula
            memoryUnit.enemyATKpotential[pos]=maxP;
        }
        for(int pos=0;pos<4;pos++){
            int maxP = game.my_fish[pos].atk/2;
            int fid = game.my_fish[pos].id;if(fid>12)fid-=12;
            if((fid==1||fid==3||(fid==11&&memoryUnit.skillcount[1]<=2))&&maxP<35*nelf)maxP=35*nelf;
            if((fid==5||fid==9||fid==10||(fid==7&&memoryUnit.skillcount[0]<=2))&&maxP<120)maxP = 120;
            memoryUnit.myATKpotential[pos]=maxP;
        }
    }
    void attack(int& enemyHP, int pos, float harm){
        if(enemyHP<=0)return;
        //does not consider 100%reduce
        //considers 70%reduce, which must come from a mask
        if(masks[pos]>0&&passive_used[pos][0]>0){
            float chance70 = passive_used[pos][3]/((float)(passive_used[pos][0]));
            harm = harm*chance70*0.3 + harm*(1-chance70);
        }
        //does not consider deflect
        //ATTACK
        enemyHP -= harm;
        if(enemyHP<0)enemyHP=0;
        //considers heal
        if(enemyHP>0&&inherent[pos][5]){
            enemyHP+=20;
        }
        else if(enemyHP>0&&masks[pos]>0&&passive_used[pos][0]>0){
            float chanceheal = passive_used[pos][5]/((float)passive_used[pos][0]);
            enemyHP+=20*chanceheal;
        }
    }
    std::string p2s(int i){
        if(i==0)return "attacked ";if(i==1)return "counter ";if(i==2)return "deflect ";
        if(i==3)return "redu70 ";if(i==4)return "redu100 "; if(i==5)return "heal ";if(i==6)return "explode ";
    }
    std::string a2s(int i){
        if(i==0)return "aoe "; if(i==1)return "infight ";
        if(i==2)return "crit ";if(i==3)return "subtle ";
    }
    std::string debugmsg(){
        std::string out;
        for(int i=0;i<4;i++){
            std::string part = "Pos "+std::to_string(i)+":\nPassive used:";
            for(int j=0;j<7;j++){
                if(passive_used[i][j]>0){
                    part = part + p2s(j) + " " + std::to_string(passive_used[i][j]) +"; ";
                }
            }
            part = part + "\nSkill used:";
            for(int j=0;j<4;j++){
                if(skill_used[i][j]>0){
                    part = part + a2s(j) + " " + std::to_string(skill_used[i][j]) +"; ";
                }
            }
            part = part + "\ninherent:";
            for(int j=0;j<7;j++){
                if(inherent[i][j]==true){
                    part = part + p2s(j);
                }
            }
            if(masks[i])part = part + ";" + std::to_string(masks[i]) + " masks";
            out =  out + part + "\n";
        }
        return out;
    }
}intel;

struct NotTable{
    bool T[12][13];//T[pos][id], id:1,2,...,12
    int count[12];
    bool exposed[12];//or dead
    std::pair<int,int> ast1;//1/1 success
    std::pair<int,int> ast2;//1/2 success
    std::pair<int,int> ast3;//1/3 success
    void init(){
        memset(T,true,sizeof(T));
        memset(exposed,false,sizeof(exposed));
    }
    int getpossible(int row){
        for(int i=1;i<=12;i++){
            if(T[row][i])return i;
        }
        return 12;
    }
    void only(int pos, std::vector<int> v){
        bool notrow[13];
        for(int i=0;i<13;i++)notrow[i]=true;
        for(int i=0;i<v.size();i++)notrow[v[i]]=false;
        int row = 4*(memoryUnit.round_nb-1)+pos;
        for(int i=1;i<12;i++)if(notrow[i])T[row][i]=false;//operate on index 1~11, 12 is Ni-Tai Yu
    }
    void update_enemy_living(std::vector<int> v){
        bool alive[4] = {false,false,false,false};
        for(int i=0;i<v.size();i++)alive[v[i]]=true;
        for(int i=0;i<4;i++)if(!alive[i])exposed[4*(memoryUnit.round_nb-1)+i]=true;
    }
    void update(){
        for(int pos=0;pos<4;pos++){
            if(intel.skill_used[pos][0]>0)only(pos,std::vector<int>{1,3,11});
            if(intel.skill_used[pos][1]>0)only(pos,std::vector<int>{2,4});
            if(intel.skill_used[pos][2]>0)only(pos,std::vector<int>{5,7,9,10});
            if(intel.skill_used[pos][3]>0)only(pos,std::vector<int>{6,7,8,11});
            if(intel.inherent[pos][2])only(pos,std::vector<int>{3,4});
            if(intel.inherent[pos][4])only(pos,std::vector<int>{5,6,7});
            if(intel.inherent[pos][5])only(pos,std::vector<int>{8,9});
            if(intel.inherent[pos][6])only(pos,std::vector<int>{10});
        }
    }
    void countrow(){
        for(int pos=0;pos<4;pos++){
            int row = 4*(memoryUnit.round_nb-1)+pos;
            count[row]=0;
            for(int j=1;j<=12;j++)if(T[row][j])count[row]++;//operate on index 1,2,...,12
        }
    }
    void assert(){
        ast1 = std::make_pair(-1,-1); ast2 = ast1; ast3 = ast1;
        for(int pos=0;pos<4;pos++){
            int row = 4*(memoryUnit.round_nb-1)+pos;
            if(exposed[row])continue;
            if(count[row]==1)ast1 = std::make_pair(pos,getpossible(row));
            if(count[row]==2)ast2 = std::make_pair(pos,getpossible(row));
            if(count[row]==3)ast3 = std::make_pair(pos,getpossible(row));
        }
    }
    void recordSuccess(int pos, int content){
        int row = 4*(memoryUnit.round_nb-1)+pos;
        exposed[row] = true;
        for(int i=1;i<=12;i++)if(i!=content)T[row][i]=false;
        for(int i=0;i<12;i++)if(i!=row)T[i][content]=false;
    }
    void recordFailure(int pos, int content){
        int row = 4*(memoryUnit.round_nb-1)+pos;
        T[row][content] = false;
    }
    std::string debug(){
        std::string message;
        int row = 4*(memoryUnit.round_nb-1);
        for(int i=0;i<4;i++){
            std::string part = std::to_string(i) + ":" + std::to_string(count[row+i]);
            for(int j=1;j<=12;j++){
                if(T[row+i][j])part = part + "o ";
                else part = part + "x ";
            }
            if(exposed[row+i]) part = part + "（不能断言）";
            message = message + part + "\n";
        }
        return message;
    }
}notTable;

std::vector<int> AI::Pick(Game game)
{
    srand((unsigned)time(NULL));
    std::vector<int> v = get_my_remain_fishes();
    std::vector<int> my_fish;
    my_fish.clear();
    for (int i = 0; i < 4; i++)
    {
        int index = rand() % v.size();
        int ch_fish = v[index];
        v.erase(v.begin()+index);
        if (ch_fish == 12)
            my_fish.push_back(13);
        else
            my_fish.push_back(ch_fish);
    }
    memoryUnit.round_nb++;
    memoryUnit.huihe = -1;
    for(int i=0;i<4;i++){memoryUnit.enemyATKhistory[i]=50;memoryUnit.enemyATKpotential[i]=50;}
    memoryUnit.skillcount[0]=0;memoryUnit.skillcount[1]=0;
    intel.init();
    if(memoryUnit.round_nb==1)notTable.init();
    //debug
    debug_msgg("\n============\n");
    debug_msgg("第"+std::to_string(memoryUnit.round_nb)+"场比赛\n选择的鱼:");
    for(int i=0;i<4;i++)debug_msgg(std::to_string(my_fish[i])+" ");
    debug_msgg("\n============\n");

    return my_fish;
}

std::pair<int, int> AI::Assert(Game game)
{
    //MemoryUnit & Debug
    if(memoryUnit.huihe==-1){
        if(game.first_mover)memoryUnit.huihe = 1;
        else memoryUnit.huihe = 2;
    }
    else memoryUnit.huihe += 2;
    debug_msgg("回合#"+std::to_string(memoryUnit.huihe)+",断言阶段\n");
    debug_msgg("我方血量");for(int i=0;i<4;i++)debug_msgg(std::to_string(game.my_fish[i].hp)+", ");debug_msgg("\n");
    debug_msgg("敌方血量");for(int i=0;i<4;i++)debug_msgg(std::to_string(game.enemy_fish[i].hp)+", ");debug_msgg("\n");
    debug_msgg("我方攻击");for(int i=0;i<4;i++)debug_msgg(std::to_string(game.my_fish[i].atk)+", ");debug_msgg("\n");
    // Last Assert
    if(memoryUnit.huihe>2 && game.my_assert.assertPos!=-1){
        if(game.my_assert.assertResult==true) notTable.recordSuccess(game.my_assert.assertPos,game.my_assert.assertContent);
        else notTable.recordFailure(game.my_assert.assertPos,game.my_assert.assertContent);
    } 
    // Intel
    if(memoryUnit.huihe==2)intel.analyze(game,true);
    if(memoryUnit.huihe>2)intel.analyze(game);
    intel.updateATK(game);
    debug_msgg("情报系统:\n" + intel.debugmsg() + "\n");
    // NotTable
    notTable.update_enemy_living(get_enemy_living_fishes());
    notTable.update();
    notTable.countrow();
    notTable.assert();
    debug_msgg("NotTable:\n" + notTable.debug() + "\n");
    // New Assert
    if(notTable.ast1.first!=-1){debug_msgg("断言：敌方"+std::to_string(notTable.ast1.first)+"号位置鱼id为"+std::to_string(notTable.ast1.second)+"\n");return notTable.ast1;}
    if(notTable.ast2.first!=-1){debug_msgg("断言：敌方"+std::to_string(notTable.ast2.first)+"号位置鱼id为"+std::to_string(notTable.ast2.second)+"\n");return notTable.ast2;}
    if(memoryUnit.round_nb!=3&&notTable.ast3.first!=-1){debug_msgg("断言：敌方"+std::to_string(notTable.ast3.first)+"号位置鱼id为"+std::to_string(notTable.ast3.second)+"\n");return notTable.ast3;}
    debug_msgg("放弃断言\n");
    return std::make_pair(-1,-1);
}

struct Game2
{
    Fish MyFish[4];
    Fish EnemyFish[4];
    int eval(){
        int score = 0;
        int yutou = memoryUnit.huihe;
        for(int i=0;i<4;i++){if(MyFish[i].hp>0)MyFish[i].hp+=yutou;if(EnemyFish[i].hp>0)EnemyFish[i].hp+=yutou;}
        for(int i=0;i<4;i++)score+=(MyFish[i].hp)*(100+memoryUnit.myATKpotential[i]);//-MyFish[i].atk*MyFish[i].atk/800
        for(int i=0;i<4;i++)score-=(EnemyFish[i].hp)*(100+EnemyFish[i].atk);
        return score;
    }
} startState;

struct ActionArguments{
    int fishpos;
    bool type;//if type is false, do not use skill, enemyT is target of normal attack
    int friendT;//if type is true, friendT and enemyT will be passed as argument if !=-1
    int enemyT;
    bool validate(){
        if(startState.MyFish[fishpos].hp<=0)return false;
        if(!type){
            if(friendT!=-1)return false;
            if(enemyT<0||enemyT>3||startState.EnemyFish[enemyT].hp<=0)return false;
            return true;
        }
        else{
            switch (startState.MyFish[fishpos].id)
            {
            case spray:
            case eel:
                if(friendT==-1&&enemyT==-2)return true;
                break;
            case flame:
            case sunfish:
                if(enemyT!=-1)return false;
                if(!(friendT>=0&&friendT<4&&startState.MyFish[friendT].hp>0&&friendT!=fishpos))return false;
                return true;
            case clownfish:
                if(memoryUnit.skillcount[1]<=2){
                    if(enemyT!=-2)return false;
                }
                else{
                    if(enemyT!=-1)return false;
                }
                if(!(friendT>=0&&friendT<4&&startState.MyFish[friendT].hp>0&&friendT!=fishpos))return false;
                return true;
            case mobula:
            case octopus:
                if(enemyT!=-1)return false;
                if(friendT>=0&&friendT<4&&startState.MyFish[friendT].hp>0)return true;
                break;
            case barracuda:
                if(friendT!=-1)return false;
                if(enemyT>=0&&enemyT<4&&startState.EnemyFish[enemyT].hp>0)return true;
                break;
            case whiteshark:
            case hammerhead:
                if(friendT!=-1)return false;
                if(enemyT<0||enemyT>3||startState.EnemyFish[enemyT].hp<=0)return false;
                for(int i=0;i<4;i++)if(startState.EnemyFish[i].hp>0&&startState.EnemyFish[i].hp<startState.EnemyFish[enemyT].hp)return false;
                return true;
            case turtle:
                if(friendT<0||friendT>3||friendT==fishpos||startState.MyFish[friendT].hp<0)return false;
                if(memoryUnit.skillcount[0]<=2){
                    if(enemyT<0||enemyT>3||startState.EnemyFish[enemyT].hp<=0)return false;
                }
                else{
                    if(enemyT!=-1)return false;
                }
                break;
            default:
                break;
            }
            return false;
        }
    }
    Game2 succState(){
        Game2 ret(startState);
        if(type) switch (startState.MyFish[fishpos].id)
        {
        case spray:
        case eel:
            for(int i=0;i<4;i++)intel.attack(ret.EnemyFish[i].hp,i,35);
            break;
        case flame:
        case sunfish:
            ret.MyFish[friendT].hp-=50;
            ret.MyFish[fishpos].atk+=35;
            break;
        case barracuda:
            intel.attack(ret.EnemyFish[enemyT].hp,enemyT,120);
            break;
        case mobula:
        case octopus:
        //  ret.MyFish[friendT].hp+=50;//estimate, need to remember my masks
            ret.MyFish[fishpos].atk+=10;
            break;
        case clownfish:
            if(memoryUnit.skillcount[1]<=3)for(int i=0;i<4;i++)intel.attack(ret.EnemyFish[i].hp,i,35);
            break;
        case turtle:
            if(memoryUnit.skillcount[0]<=3)intel.attack(ret.EnemyFish[enemyT].hp,enemyT,120);
            ret.MyFish[friendT].hp+=20;//estimate
            break;
        case whiteshark:
        case hammerhead:
            if(ret.EnemyFish[enemyT].hp<160)intel.attack(ret.EnemyFish[enemyT].hp,enemyT,(120*ret.MyFish[fishpos].atk)/100);
            else intel.attack(ret.EnemyFish[enemyT].hp,enemyT,(140*ret.MyFish[fishpos].atk)/100);
            break;
        default:
            break;
        }
        else{
            intel.attack(ret.EnemyFish[enemyT].hp,enemyT,ret.MyFish[fishpos].atk/2);
        }
        return ret;
    }
};

Action AI::Act(Game game)
{
    Action action(game);
    //update Game2 instance startState
    for(int i=0;i<4;i++){
        startState.MyFish[i]=game.my_fish[i];
        startState.MyFish[i].atk = game.my_fish[i].atk/2;
        if(startState.MyFish[i].id>12)startState.MyFish[i].id-=12;
        startState.EnemyFish[i]=game.enemy_fish[i];
        startState.EnemyFish[i].atk = (memoryUnit.enemyATKhistory[i]+memoryUnit.enemyATKpotential[i])/2;
    }

    //search
    ActionArguments act;
    ActionArguments bestAction;
    int bestScore=INT_MIN;
    int newScore;
    act.type = false; act.friendT = -1;
    for(int fishpos_ = 0; fishpos_<4; fishpos_++){
        if(startState.MyFish[fishpos_].hp<=0)continue;
        act.fishpos = fishpos_;
        for(int enemyT_=0; enemyT_<4; enemyT_++){
            if(startState.EnemyFish[enemyT_].hp<=0)continue;
            act.enemyT = enemyT_;
            if(act.validate()){
                newScore = act.succState().eval();
                if(newScore>bestScore){
                    bestScore=newScore;
                    bestAction = act;
                }
            }
        }
    }
    act.type = true;
    for(int fishpos_=0;fishpos_<4;fishpos_++){
        if(startState.MyFish[fishpos_].hp<=0)continue;
        int skillID = startState.MyFish[fishpos_].id;
        act.fishpos = fishpos_; 
        for(int enemyT_=-2;enemyT_<4;enemyT_++){
            act.enemyT=enemyT_; 
            for(int friendT_=-1;friendT_<4;friendT_++){
                if(friendT_!=-1 && skillID!=2 && skillID!=4 && skillID!=6 && skillID!=7 && skillID!=8 && skillID!=11)continue;
                act.friendT=friendT_;
                if(act.validate()){
                    newScore = act.succState().eval();
                    if(newScore>bestScore){
                        bestScore=newScore;
                        bestAction = act;
                    }
                }
            }
        }
    }
    //return
    if(bestAction.type==true){
        if(startState.MyFish[bestAction.fishpos].id==turtle)memoryUnit.skillcount[0]++;
        if(startState.MyFish[bestAction.fishpos].id==clownfish)memoryUnit.skillcount[1]++;
    }
    action.set_action_fish(bestAction.fishpos);
    action.set_action_type(bestAction.type);
    if(bestAction.friendT>=0)action.set_friend_target(bestAction.friendT);
    if(bestAction.enemyT!=-1)action.set_enemy_target(bestAction.enemyT);
    debug_msgg("回合#"+std::to_string(memoryUnit.huihe)+",行动阶段\n");
    debug_msgg(std::to_string(bestAction.fishpos)+", "+std::to_string(bestAction.type)+", "+std::to_string(bestAction.enemyT)+", "+std::to_string(bestAction.friendT)+"\n\n");
    return action;
}

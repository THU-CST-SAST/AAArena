#include "Action.hpp"
#include <algorithm>
#include <string.h>

std::vector<int> r1 = {19, 3, 9, 2};
std::vector<int> r2 = {7, 1, 10, 6};
std::vector<int> r3 = {11, 8, 5, 4};

std::vector<std::vector<int>> assertMatrix(8, std::vector<int>(6, 0));
bool successAssertImitator = false;


int* everAssert_arr = new int[4];
int* injury_count = new int[4];
bool isFirstAssert = true;
bool beforeAction = true;
int gotoAssert_count = 0;

void initAssertMatrix(){
    assertMatrix[0][4] = 1;
    assertMatrix[2][4] = 2;
    assertMatrix[0][0] = 3;
    assertMatrix[2][0] = 4;
    assertMatrix[3][3] = 5;
    assertMatrix[7][3] = 6;
    assertMatrix[6][2] = 7;
    assertMatrix[7][1] = 8;
    assertMatrix[4][1] = 9;
    assertMatrix[5][5] = 10;
    assertMatrix[1][4] = 11;
}

void UpdateMatrix(int i){
    switch (i)
    {
    case 1:
        assertMatrix[0][4] = 0;
        break;
    case 2:
        assertMatrix[2][4] = 0;
        break;
    case 3:
        assertMatrix[0][0] = 0;
        break;
    case 4:
        assertMatrix[2][0] = 0;
        break;
    case 5:
        assertMatrix[3][3] = 0;
        break;
    case 6:
        assertMatrix[7][3] = 0;
        break;
    case 7:
        assertMatrix[6][2] = 0;
        break;
    case 8:
        assertMatrix[7][1] = 0;
        break;
    case 9:
        assertMatrix[4][1] = 0;
        break;
    case 10:
        assertMatrix[5][5] = 0;
        break;
    case 11:
        assertMatrix[1][4] = 0;
        break;
    case 12:
        successAssertImitator = true;
        break;
    default:
        break;
    }
}

struct ActiveSkill{
    bool isUsed;
    skill_type mytype;
    int num;
    //bool isNotLowestCrit;
    int injuryBlood;
    int head, tail;
    void init(){
        isUsed = false;
        num = 0;
        //isNotLowestCrit = false;
        injuryBlood = 0;
        head = 0;
        tail = 7;
    }
};

struct PassiveSkill{
    bool isUsed;
    passive_type mytype; //承伤、回血不需要记录信息
    int num1, num2;
    int num;  //减伤类记录前三次成功次数
    int head, tail;
    void init(){
        isUsed = false;
        num1 = 0;
        num2 = 0;
        num = 0;
        head = 0;
        tail = 5;
    }
};

struct FishSkillVector{
    ActiveSkill active;
    PassiveSkill passive;
    void init(){
        active.init();
        passive.init();
    }
};

FishSkillVector* AllFish = new FishSkillVector[4];

void InitAllFish(){
    for(int i = 0; i < 4; i++){
        AllFish[i].init();
    }
}

std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> pickfish;
    //pickfish.clear();
    if(game.round == 1){
        pickfish = r1;
        initAssertMatrix();
    }
    else if(game.round == 2){
        pickfish = r2;
    }
    else{
        pickfish = r3;
    }
    InitAllFish();
    memset(everAssert_arr, 0, 4*sizeof(int));
    memset(injury_count, 0, 4*sizeof(int));
    isFirstAssert = true;
    beforeAction = true;
    gotoAssert_count = 0;
    return pickfish;
}

//断言

int backupFishID = 0;

int searchAssertMatrix(int i){
    /*
    if (AllFish[i].active.isUsed == false)
        return -1;
    */
    int activeHead = AllFish[i].active.head;
    int activeTail = AllFish[i].active.tail;
    int passiveHead = AllFish[i].passive.head;
    int passiveTail = AllFish[i].passive.tail;
    int count = 0;
    int res1 = 0, res2 = 0;

    for(int j = activeHead; j <= activeTail; j++){
        for(int k = passiveHead; k <= passiveTail; k++){
            if(assertMatrix[j][k] > 0){
                count++;
                res2 = res1;
                res1 = assertMatrix[j][k];
            }
        }
    }

    if(count == 1)
        return res1;
    //可能一上来就没搜到？就会一下子认为是拟态
    //改进为 猜过某种鱼后需要特殊标记 如果再搜到这条鱼就拟态
    /*
    else if(count == 0 && !successAssertImitator){
        return 12;
    }
    */
    else if(count == 2){
        backupFishID = res2;
        return res1 + 12;
    }
    else{
        return -1;
    }
}



std::pair<int, int> AI::Assert(Game game)
{
    gotoAssert_count++;
    if(game.first_mover == true && isFirstAssert){
        isFirstAssert = false;
        return std::make_pair(-1, -1);
    }
 
    int successAssertFishID = game.my_assert.assertContent; //一定不为12??
    int successAssertPos = game.my_assert.assertPos;
    if(successAssertFishID != 0)
    {
        if(game.my_assert.assertResult == true){
            backupFishID = 0;
            everAssert_arr[successAssertPos] = -1;
            UpdateMatrix(successAssertFishID);
        }
        else if(game.my_assert.assertResult == false){
            if(successAssertFishID >= 1 && successAssertFishID < 12){
                if(backupFishID != 0 && get_enemy_hp(successAssertPos) > 0){
                    int tmp = backupFishID;
                    backupFishID = 0;
                    return std::make_pair(successAssertPos, tmp);
                }
                else if(!successAssertImitator && get_enemy_hp(successAssertPos) > 0)
                    return std::make_pair(successAssertPos, 12); //预测拟态鱼
                else 
                    everAssert_arr[successAssertPos] = -1; //代码出错
            } 
            else 
                everAssert_arr[successAssertPos] = -1; //代码出错
        }
    }
    backupFishID = 0;
    // 主动技能
    skill_type lasttype = game.enemy_action.type;
    int actor_fish = game.enemy_action.action_fish;

    //主动技能，确定行
    if(game.enemy_action.is_skill && lasttype != normalattack){
        //AllFish[actor_fish].active.mytype = lasttype;
        //AllFish[actor_fish].active.isUsed = true;
        switch (lasttype)
        {
        case aoe:
            AllFish[actor_fish].active.mytype = lasttype;
            AllFish[actor_fish].active.num++;

            if(AllFish[actor_fish].passive.num1 >= 1){
                AllFish[actor_fish].passive.head = 0;
                AllFish[actor_fish].passive.tail = 0;
            }

            if(AllFish[actor_fish].active.num >= 4){
                AllFish[actor_fish].active.tail = 0;
            }
            else{
                AllFish[actor_fish].active.tail = 1;
            }
            break;
        case infight:
            AllFish[actor_fish].active.mytype = lasttype;
            AllFish[actor_fish].active.head = 2;
            AllFish[actor_fish].active.tail = 2;
            break;
        case crit:
            AllFish[actor_fish].active.mytype = lasttype;
            AllFish[actor_fish].active.num++;
            AllFish[actor_fish].active.head = 3;
            //是否是有限暴击
            if(AllFish[actor_fish].active.num >= 4){
                AllFish[actor_fish].active.tail = 5;
            }
            else{
                AllFish[actor_fish].active.tail = 6;
            }
            //不是易伤暴击
            if(game.enemy_action.enemy_expected_injury[0] == 140){
                AllFish[actor_fish].active.head = 4;
                AllFish[actor_fish].active.tail = 5;
            }

            //直接锁定锤头鲨
            if(game.enemy_action.enemy_expected_injury[0] == 138 
            || game.enemy_action.enemy_expected_injury[0] == 161){
                AllFish[actor_fish].active.head = 5;
                AllFish[actor_fish].active.tail = 5;
            }

            break;
        case subtle:
            if(AllFish[actor_fish].active.isUsed == true 
            && AllFish[actor_fish].active.mytype == aoe){
                AllFish[actor_fish].active.head = AllFish[actor_fish].active.tail = 1;
            }

            else if(AllFish[actor_fish].active.isUsed == true 
            && AllFish[actor_fish].active.mytype == crit){
                AllFish[actor_fish].active.head = AllFish[actor_fish].active.tail = 6;
            }

            else{
                AllFish[actor_fish].active.mytype = lasttype;
                AllFish[actor_fish].active.head = 7;
            }

            break;
        default:
            break;
        }
        AllFish[actor_fish].active.isUsed = true;
    }


    //被动技能
    if(!beforeAction){
        int pass_num = game.my_action.num_enemy_passives;
        int* heal_count = new int[4];
       

        for(int i = 0; i < game.my_action.num_enemy_injury; i++){
            int injury_fish = game.my_action.enemy_injury_id[i];
            injury_count[injury_fish]++;
        }

        for(int i = 0; i < pass_num; i++){
            int passer_fish = game.my_action.enemy_passives_id[i]; //位置
            passive_type lastpasstype = game.my_action.enemy_types[i];
            
            switch (lastpasstype)
            {
            case deflect:
                /* code */
                AllFish[passer_fish].passive.mytype = lastpasstype;
                AllFish[passer_fish].passive.num1++;
                if(AllFish[passer_fish].active.mytype == aoe && AllFish[passer_fish].active.isUsed){
                    AllFish[passer_fish].passive.head = 0;
                    AllFish[passer_fish].passive.tail = 0;

                }
                else if(AllFish[passer_fish].passive.num1 >= 3){
                    AllFish[passer_fish].passive.tail = 0;

                }
                AllFish[passer_fish].passive.isUsed = true;
                

                break;
            case heal:
                AllFish[passer_fish].passive.mytype = lastpasstype;
                heal_count[passer_fish]++;
                AllFish[passer_fish].passive.num2++;
                if(AllFish[passer_fish].passive.num2 >= 3 || heal_count[passer_fish] >= 2){
                    AllFish[passer_fish].passive.head = 1;
                    AllFish[passer_fish].passive.tail = 1;
                }
                AllFish[passer_fish].passive.isUsed = true;

                break;
            case reduce:
                AllFish[passer_fish].passive.mytype = lastpasstype;

                //减伤比 reduce
                if(game.my_action.enemy_passive_value[i] == 0){ 
                    AllFish[passer_fish].passive.head = 2;
                    AllFish[passer_fish].passive.tail = 3;
                    AllFish[passer_fish].passive.num++;
                    AllFish[passer_fish].passive.isUsed = true;
                }         
                //海龟和普通闪避区分 
                if((AllFish[passer_fish].passive.num == 1 || AllFish[passer_fish].passive.num == 2) && AllFish[passer_fish].passive.num < injury_count[passer_fish]){
                    AllFish[passer_fish].passive.head = 3;
                    AllFish[passer_fish].passive.tail = 3;
                }
                else if((injury_count[passer_fish] == 3 || injury_count[passer_fish] == 4) 
                && AllFish[passer_fish].passive.num >= 3){
                    AllFish[passer_fish].passive.head = 2;
                    AllFish[passer_fish].passive.tail = 2;
                }
                break;
            case counter:
                AllFish[passer_fish].passive.mytype = lastpasstype;
                break;
            case explode:
                AllFish[passer_fish].passive.mytype = lastpasstype;
                UpdateMatrix(10);
                break;
            
            default:
                break;
            }
        }

        if(gotoAssert_count == 2){
            for(int i = 0; i < 4; i++){
                if(AllFish[i].passive.isUsed == false){
                    AllFish[i].passive.head = 3;
                    AllFish[i].passive.tail = 5;
                }
            }
        }

        for(int i = 0; i < 4; i++){
            if(AllFish[i].passive.isUsed == false && injury_count[i] >= 8){
                AllFish[i].passive.head = 4;
                AllFish[i].passive.tail = 5;
            }
        }  
    }
    int tmpID = 0;
    int tmpPos = 0;
    for(int i = 0; i < 4; i++){
        if(get_enemy_hp(i) > 0 && everAssert_arr[i] != -1){
            int res = searchAssertMatrix(i);
            if(res >= 1 && res <= 12){
                return std::make_pair(i, res);
            }
            else if(res >= 13){
                tmpID = res;
                tmpPos = i;
            }
        }
        //对于已死的鱼 也search 并更新矩阵
    }

    if(tmpID >= 13 && gotoAssert_count >= 4){
        return std::make_pair(tmpPos, tmpID-12);
    }
    return std::make_pair(-1, -1);    
}

int get_lowest_health_myfish(int id, Game game)
{
	int fishpos = -1;
	for (int i = 0; i < 4; i++)
	{
		if (id != i && game.my_fish[i].hp > 0 && (fishpos == -1 || game.my_fish[i].hp < game.my_fish[fishpos].hp))
			fishpos = i;
	}
	return fishpos;
}


int my_pos = 0;
//int count = 0;
int pre_enemy_action_id = -1;
int enemy_action_id;



Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    enemy_action_id = game.enemy_action.action_fish;
    //enemy_action_id = (get_lowest_health_enemies())[0];

    if(get_enemy_hp(enemy_action_id) <= 0)
        enemy_action_id = (get_lowest_health_enemies())[0];

    if(game.round == 1){        
        
        int low3 = get_lowest_health_myfish(3, game); //除喷火
        int low0 = get_lowest_health_myfish(0, game); //除海龟

        if(get_skill_used(1) < 2){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }

        //卖队友
        else if(low3 != -1 && get_my_hp(low3) <= 140 
                && get_my_hp(3) > 200  && get_skill_used(3) < 3){
            action.set_action_fish(3);
            action.set_action_type(1);
            if(low3 != 2)
                action.set_friend_target(low3); //避开自己
            else{
                if(get_my_hp(0) > 0)
                    action.set_friend_target(0);
                else if(get_my_hp(1) > 0)
                    action.set_friend_target(1);
                else{
                    action.set_action_fish(2);
                    action.set_action_type(1);
                    action.set_enemy_target((get_lowest_health_enemies())[0]);
                }
            }
        }

        //若敌人血量<= 35 优先aoe
        else if(get_enemy_hp(enemy_action_id) <= 35 && get_my_hp(1) > 0){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }

        //优先喷火普攻
        else if(get_skill_used(3) >= 3 && get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //海龟暴击
        else if(low0 != -1 && get_skill_used(0) < 3 && pre_enemy_action_id != enemy_action_id && get_my_hp(0) > 0){
        //else if(get_skill_used(0) < 3 && get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_friend_target(low0);  
            action.set_enemy_target(enemy_action_id);
        }

        //大白鲨暴击
        else if(get_my_hp(2) > 0){
            action.set_action_fish(2);
            action.set_action_type(1);
            action.set_enemy_target((get_lowest_health_enemies())[0]);
        }

        //喷火鱼
        else if(get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //电鳗
        else if(get_my_hp(1) > 0){
            action.set_action_fish(1);

            if(get_enemy_living_fishes().size() >= 2){
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else{
                action.set_action_type(0);
                action.set_enemy_target(enemy_action_id);
            }
        }

        //海龟普通攻击
        else if(get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }
    }

    else if(game.round == 2){

        int low3 = get_lowest_health_myfish(3, game); //除蝠鲼
        int low0 = get_lowest_health_myfish(0, game); //除拟态海龟

        //射水鱼aoe
        if(get_skill_used(1) < 2){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }

        //蝠鲼发育
        else if(low3 != -1 && get_my_hp(2) < 200 && ((get_skill_used(2)+get_skill_used(3))&1)
                && get_my_hp(3) > 0 && get_skill_used(3) < 4){
            action.set_action_fish(3);
            action.set_action_type(1);
            if(get_my_hp(2) > 0)
                action.set_friend_target(2); //避开自己
            else 
                action.set_friend_target(low3); //避开自己
        }

        //若敌人血量<= 35 优先aoe
        else if(get_enemy_hp(enemy_action_id) <= 35 && get_my_hp(1) > 0){
            action.set_action_fish(1);
            action.set_action_type(1);
            action.set_enemy_target(-2);
        }

        //海龟暴击
        //else if(get_skill_used(0) <= 3 && pre_enemy_action_id != enemy_action_id && get_my_hp(0) > 0){
        else if(low0 != -1 && get_skill_used(0) < 3 && get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_friend_target(low0);  //避免自己
            action.set_enemy_target(enemy_action_id);
        }

        //锤头鲨暴击
        else if(get_my_hp(2) > 0){
            action.set_action_fish(2);
            action.set_action_type(1);
            action.set_enemy_target((get_lowest_health_enemies())[0]);
        }

        //优先翻车鱼   可改 基于敌方鱼的数量是否aoe
        else if(game.enemy_fish.size() <= 2 && get_skill_used(3) >= 3 && get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //射水鱼
        else if(get_my_hp(1) > 0){
            action.set_action_fish(1);

            if(game.enemy_fish.size() >= 2){
                action.set_action_type(1);
                action.set_enemy_target(-2);
            }
            else{
                action.set_action_type(0);
                action.set_enemy_target(enemy_action_id);
            }
        }

        //蝠鲼普攻
        else if(get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //拟态海龟普通攻击
        else if(get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

    }

    else{

        int low3 = get_lowest_health_myfish(3, game); //除翻车
        int low0 = get_lowest_health_myfish(0, game); //除小丑

        //小丑鱼aoe
        if(get_skill_used(0) < 2 && get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_friend_target(low0);
            action.set_enemy_target(-2);
        }

        //翻车鱼卖队友  尽量卖前两个
        //else if(get_lowest_health_myfish(3, game) != -1 && get_my_hp(get_lowest_health_myfish(3, game)) <= 140 
        //        && get_my_hp(3) > 200  && get_skill_used(3) < 3){
        else if(low3 != -1 && (get_my_hp(low3) <= 140 || get_my_hp(2) <= 250) 
                && get_my_hp(3) > 200  && get_skill_used(3) < 3){
            action.set_action_fish(3);
            action.set_action_type(1);

            if(low3 != 2 && get_my_hp(low3) <= 140)
                action.set_friend_target(low3); //避开自己
            else{
                if(get_my_hp(1) > 0)
                    action.set_friend_target(1); //优先卖章鱼
                else if(get_my_hp(0) > 0)
                    action.set_friend_target(0);
                else{
                    action.set_action_fish(2);
                    action.set_action_type(1);
                    action.set_enemy_target((get_lowest_health_enemies())[0]);
                }
            }
        }

        //若敌人血量<= 35 优先aoe
        else if(low0 != -1 && get_enemy_hp(enemy_action_id) <= 35 && get_skill_used(0) < 3 && get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(1);
            action.set_friend_target(low0);
            action.set_enemy_target(-2);
        }
        
        //优先翻车鱼普攻
        else if(get_skill_used(3) >= 3 && get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //海狼鱼暴击
        else if(get_my_hp(2) > 0){
            action.set_action_fish(2);
            action.set_action_type(1);
            action.set_enemy_target((get_lowest_health_enemies())[0]);
        }

        //翻车鱼普攻
        else if(get_my_hp(3) > 0){
            action.set_action_fish(3);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

        //章鱼普攻
        else if(get_my_hp(1) > 0){
            action.set_action_fish(1);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);

        }

        //小丑鱼普通攻击
        else if(get_my_hp(0) > 0){
            action.set_action_fish(0);
            action.set_action_type(0);
            action.set_enemy_target(enemy_action_id);
        }

    }

    pre_enemy_action_id = enemy_action_id;
    beforeAction = false;
    return action;

}
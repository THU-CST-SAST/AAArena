//
// Created by 安頔 on 2021/1/20.
//

#include "../include/client.h"

StateFish::StateFish(int _type, bool _imitate,
                     int _atk, int _hp,
                     int _passive_cnt, int _active_cnt,
                     bool _is_assert, bool _is_alive,
                     bool _has_reduce, bool _has_share, bool _has_heal) {
    type = _type; imitate = _imitate;
    atk = _atk; hp = _hp;
    passive_cnt = _passive_cnt; active_cnt = _active_cnt;
    is_assert = _is_assert; is_alive = _is_alive;
    has_reduce = _has_reduce;
    has_share = _has_share;
    has_heal = _has_heal;
}

int StateFish::get_attack() const {
    if(type == 6 && hp < 80)return atk + 15;
    return atk;
}

int State::randomInt(int st, int ed) {
    static std::default_random_engine e(time(nullptr));
    std::uniform_int_distribution<int> u(st, ed);
    return u(e);
}

void State::actionAssert(const Action &act) {
    assert(act.action_pos >= 0 && act.action_pos < 4);
    assert(!info[1-act.player][act.action_pos].is_assert);
    const StateFish& now_fish = info[1-act.player][act.action_pos];
    if((now_fish.type == act.assert_type && !now_fish.imitate)
        || (act.assert_type == 12 && now_fish.imitate)){
        for(int i = 0; i < 4; ++i){
            info[1-act.player][i].hp = std::max(0, info[1 - act.player][i].hp - kAssertDamage);
        }
    }else{
        for(int i = 0; i < 4; ++i){
            info[act.player][i].hp = std::max(0, info[act.player][i].hp - kAssertDamage);
        }
    }
}

void State::actionAttack(const Action &act) {
    assert(act.action_pos >= 0 && act.action_pos < 4);
    assert((int)act.enemy_goal.size() == 1);
    assert((int)act.my_goal.size() == 0);
    int goal = act.enemy_goal[0];
    assert(info[act.player][act.action_pos].hp > 0);
    assert(info[1-act.player][goal].hp > 0);
    int hurt = info[act.player][act.action_pos].get_attack();
    int live_fish = -1;
    for(int i = 0; i < 4; ++i){
        if(info[1-act.player][i].is_alive)live_fish++;
    }
    actionHurt(act.player, act.action_pos, goal, (int)(hurt/2), live_fish, true);
}

void State::actionActive(const Action &act) {
    assert(act.action_pos >= 0 && act.action_pos < 4);
    StateFish& action_fish = info[act.player][act.action_pos];
    assert(action_fish.hp > 0);
    int live_fish = -1;
    for(int i = 0; i < 4; ++i){
        if(info[1-act.player][i].is_alive)live_fish++;
    }
    if(action_fish.type == 1 || action_fish.type == 3){
        int hurt = action_fish.get_attack();
        hurt = (int) (hurt * 0.35);
        for (int i = 0; i < 4; ++i) {
            if (!info[1 - act.player][i].is_alive)continue;
            actionHurt(act.player, act.action_pos, i, hurt, live_fish, true);
        }
    }else if(action_fish.type == 2 || action_fish.type == 4){
        assert((int)(act.my_goal.size()) == 1);
        int goal = act.my_goal[0];
        assert(goal >= 0 && goal < 4);
        assert(goal != act.action_pos);
        assert(info[act.player][goal].hp > 0);
        actionHurt(1-act.player, -1, goal, 50, 0, false);
        action_fish.atk += 70;
    }else if(action_fish.type == 5){
        assert((int)(act.enemy_goal.size()) == 1);
        int goal = act.enemy_goal[0];
        assert(goal >= 0 && goal < 4);
        assert(info[1-act.player][goal].hp > 0);
        actionHurt(act.player, act.action_pos, goal, 120, live_fish, true);
    }else if(action_fish.type == 6 || action_fish.type == 8){
        assert((int)(act.my_goal.size()) == 1);
        int goal = act.my_goal[0];
        assert(goal >= 0 && goal < 4);
        assert(info[act.player][goal].hp > 0);
        info[act.player][goal].has_reduce = true;
        action_fish.atk += 20;
    }else if(action_fish.type == 7){
        assert((int)(act.my_goal.size()) == 1);
        int my_goal = act.my_goal[0];
        assert(my_goal != act.action_pos);
        assert(my_goal >= 0 && my_goal < 4);
        assert(info[act.player][my_goal].hp > 0);
        if(action_fish.active_cnt < 3){
            action_fish.active_cnt++;
            assert((int)(act.enemy_goal.size()) == 1);
            int enemy_goal = act.enemy_goal[0];
            assert(enemy_goal >= 0 && enemy_goal < 4);
            assert(info[1-act.player][enemy_goal].hp > 0);
            actionHurt(act.player, act.action_pos, enemy_goal, 120, live_fish, true);
        }
        info[act.player][my_goal].has_heal = true;
    }else if(action_fish.type == 9 || action_fish.type == 10){
        assert((int)(act.enemy_goal.size()) == 1);
        int goal = act.enemy_goal[0];
        assert(goal >= 0 && goal < 4);
        int lowest_hp = info[1-act.player][goal].hp;
        assert(lowest_hp > 0);
        for(int i = 0; i < 4; ++i){
            if(!info[1-act.player][i].is_alive)continue;
            assert(info[1-act.player][i].hp >= lowest_hp);
        }
        int hurt = action_fish.get_attack();
        if(lowest_hp < 160)hurt = (int)(hurt*1.4);
        else hurt = (int)(hurt*1.2);
        actionHurt(act.player, act.action_pos, goal, hurt, live_fish, true);
    }else if(action_fish.type == 11){
        assert((int)(act.my_goal.size()) == 1);
        int goal = act.my_goal[0];
        assert(goal >= 0 && goal < 4);
        assert(goal != act.action_pos);
        assert(info[act.player][goal].hp > 0);
        if(action_fish.active_cnt < 3){
            action_fish.active_cnt++;
            int hurt = action_fish.get_attack();
            hurt = (int)(hurt*0.35);
            for(int i = 0; i < 4; ++i){
                if(!info[1-act.player][i].is_alive)continue;
                actionHurt(act.player, act.action_pos, i, hurt, live_fish, true);
            }
        }
        info[act.player][goal].has_share = true;
    }
}

void State::actionHurtImmAfter(int act_player, int src, int dst) {
    StateFish& dst_fish = info[1-act_player][dst];
    StateFish& src_fish = info[act_player][src];
    if(dst_fish.type == 11 && dst_fish.hp < 120){
        actionHurt(1-act_player, -1, src, 30, 0, false);
    }
    if(dst_fish.type == 10 && dst_fish.hp <= 0){
        actionHurt(1-act_player, -1, src, 40, 0, false);
    }
    if(dst_fish.hp < 120) {
        int check_cnt = 0;
        for (int i = 0; i < 4; ++i) {
            if (i == dst)continue;
            if (!info[1 - act_player][i].is_alive)continue;
            int type = info[1 - act_player][i].type;
            if (type == 1 || type == 2)check_cnt++;
        }
        while (check_cnt--){
            actionHurt(1-act_player, -1, src, 30, 0, false);
        }
    }
}

void State::actionHurt(int act_player, int src, int dst, int value, int live_fish, bool imm) {
    StateFish& dst_fish = info[1-act_player][dst];
    //将要受到伤害时
    bool no_hurt = checkNoHurt(dst_fish);
    if(no_hurt){
        if(imm)actionHurtImmAfter(act_player, src, dst);
        return;
    }
    //被直接攻击时
    if(imm){
        if((dst_fish.type == 3 || dst_fish.type == 4) && live_fish > 0) {
            int share_value = (int) (value * 0.3);
            value = (int) (value * 0.7);
            int share_value_avg = (int) (share_value / live_fish);
            for (int i = 0; i < 4; ++i) {
                if (i == dst)continue;
                if (!info[1 - act_player][i].is_alive)continue;
                actionHurt(act_player, -1, i, share_value_avg, live_fish, false);
            }
        }
        if(dst_fish.has_reduce){
            value = (int)(value*0.3);
            dst_fish.has_reduce = false;
        }
        if(dst_fish.has_share && live_fish > 0){
            int share_value = (int)(value*0.3);
            value = (int)(value*0.7);
            int share_value_avg = (int)(share_value/live_fish);
            for(int i = 0; i < 4; ++i){
                if(i == dst)continue;
                if(!info[1-act_player][i].is_alive)continue;
                actionHurt(act_player, -1, i, share_value_avg, live_fish, false);
            }
            dst_fish.has_share = false;
        }
    }
    //受伤
    dst_fish.hp -= value;
    if(dst_fish.type == 3 || dst_fish.type == 4){
        dst_fish.passive_cnt += value;
        while(dst_fish.passive_cnt >= 200){
            dst_fish.atk += 20;
            dst_fish.passive_cnt -= 200;
        }
    }
    //受到伤害后
    if(imm && dst_fish.has_heal && dst_fish.hp > 0){
        dst_fish.hp += 20;
        dst_fish.has_heal = false;
    }
    if((dst_fish.type == 8 || dst_fish.type == 9) && dst_fish.hp > 0){
        dst_fish.hp += 20;
    }
    if(imm)actionHurtImmAfter(act_player, src, dst);
}

bool State::checkNoHurt(StateFish& fish){
    if(fish.type < 5 || fish.type > 7)return false;
    if(fish.type == 7){
        if(fish.passive_cnt){
            fish.passive_cnt++;
            return true;
        }else{
            int judge_num = randomInt(1, 10);
            if(judge_num < 4)return true;
        }
    }else{
        int judge_num = randomInt(1, 10);
        if(judge_num < 4)return true;
    }return false;
}

int State::nxtState(const Action &act) {
    assert(act.type == -1 || act.type == 0 || act.type == 1);
    assert(act.player == 0 || act.player == 1);
    switch(act.type){
        case -1:
            actionAssert(act);
            break;
        case 0:
            actionAttack(act);
            break;
        case 1:
            actionActive(act);
            break;
    }
    updateDeath(act);
    bool all_death_flag = true;
    for(int i = 0; i < 4; ++i){
        if(info[1-act.player][i].is_alive){
            all_death_flag = false;
            break;
        }
    }
    if(all_death_flag)return act.player;
    all_death_flag = true;
    for(int i = 0; i < 4; ++i){
        if(info[act.player][i].is_alive){
            all_death_flag = false;
            break;
        }
    }
    if(all_death_flag)return 1-act.player;
    return -1;
}

void State::updateDeath(const Action& act) {
    for(int i = 0; i < 4; ++i){
        if(info[1-act.player][i].hp <= 0){
            info[1-act.player][i].is_alive = false;
        }
    }
    if(info[act.player][act.action_pos].hp <= 0){
        info[act.player][act.action_pos].is_alive = false;
    }
}

[[noreturn]] void Client::run() {
    while(true){
        listenMessage();
        std::string now_action = root["Action"].asString();
        if(now_action == "Pick"){
            transPickMessage();
            pick_choice.clear();
            playerPick();
        }
        else if(now_action == "Assert"){
            transAssertMessage();
            assert_choice.first = assert_choice.second = -1;
            playerAssert();
        }
        else if(now_action == "Action"){
            transActionMessage();
            action_choice.clear();
            playerAction();
        }else if(now_action == "Finish"){
            //TODO
            root.clear();
        }
        sendMessage(now_action);
    }
}

void Client::listenMessage() {
    recv_msg = "";
    root.clear();
    char ch;
    while(true){
        ch = (char)(getchar());
        recv_msg += ch;
        if(ch == '}' && reader.parse(recv_msg, root))break;
    }
}

void Client::transPickMessage() {
    pick_msg.remain_fishes.clear();
    for(const auto& tmp: root["RemainFishs"]){
        pick_msg.remain_fishes.push_back(tmp.asInt());
    }
    int first_player = root["FirstMover"].asInt();
    if(first_player == 1)pick_msg.is_first = true;
    else pick_msg.is_first = false;
    root.clear();
}

void Client::transAssertMessage() {
    assert_msg.now_state.update(root["GameInfo"]);
    Json::Value assert_info = root["EnemyAssert"];
    if(assert_info == Json::nullValue)assert_msg.assert_pos = -1;
    else{
        assert_msg.assert_pos = assert_info["AssertPos"].asInt();
        assert_msg.assert_content = assert_info["AssertContent"].asInt();
        assert_msg.assert_result = assert_info["AssertResult"].asBool();
    }
    assert_msg.enemy_action.update(root["EnemyAction"]);
    assert_msg.my_action.update(root["MyAction"]);
    root.clear();
}

void Client::transActionMessage() {
    action_msg.now_state.update(root["GameInfo"]);
    Json::Value assert_info = root["AssertReply"];
    if(assert_info == Json::nullValue)action_msg.assert_pos = -1;
    else{
        action_msg.assert_pos = assert_info["AssertPos"].asInt();
        action_msg.assert_content = assert_info["AssertContent"].asInt();
        action_msg.assert_result = assert_info["AssertResult"].asBool();
    }root.clear();
}

void Client::sendLen(int len){
    unsigned char lenb[4];
    lenb[0] = (unsigned char)(len);
    lenb[1] = (unsigned char)(len >> 8);
    lenb[2] = (unsigned char)(len >> 16);
    lenb[3] = (unsigned char)(len >> 24);
    for (int i = 0; i < 4; i++)
        printf("%c", lenb[3 - i]);
}

void Client::sendMessage(const std::string& s){
    if(s == "Pick"){
        root["Action"] = "Pick";
        bool has_imitate = false;
        for(int i = 0; i < 4; ++i){
            int choose_fish = pick_choice[i];
            if(choose_fish == 12)has_imitate = true;
            root["ChooseFishs"].append(choose_fish);
        }
        if(has_imitate)root["ImitateFish"] = pick_choice[4];
    }else if(s == "Assert"){
        if(assert_choice.first == -1)root["Action"] = "Null";
        else{
            root["Action"] = "Assert";
            root["Pos"] = assert_choice.first;
            root["ID"] = assert_choice.second;
        }
    }else if(s == "Action"){
        root["Action"] = "Action";
        root["Type"] = action_choice.type;
        root["MyPos"] = action_choice.action_pos;
        if(action_choice.type == 0){
            root["EnemyPos"] = action_choice.enemy_goal[0];
        }else{
            for(auto tmp: action_choice.my_goal)root["MyList"].append(tmp);
            for(auto tmp:action_choice.enemy_goal)root["EnemyPos"].append(tmp);
        }
    }else if(s == "Finish")root["Action"] = "Finish";
    std::string send_msg = root.toStyledString();
    sendLen((int)(send_msg.length()));
    std::cout << send_msg;
    std::cout.flush();
}

void Client::playerAction() {
    std::vector<Action>action_set;
    GameInfo& game = action_msg.now_state;
    for(int i = 0; i < 4; ++i){
        int now_type = std::abs(game.my_fish[i]);
        int now_hp = game.my_hp[i];
        if(now_hp == 0)continue;
        for(int j = 0; j < 4; ++j){
            int enemy_hp = game.enemy_hp[j];
            if(enemy_hp == 0)continue;
            Action tmp_act = Action();
            tmp_act.clear();
            tmp_act.action_pos = i;
            tmp_act.type = 0;
            tmp_act.enemy_goal.push_back(j);
            action_set.push_back(tmp_act);
        }
    }
    int random_action = randomInt(0, (int)(action_set.size())-1);
    action_choice = action_set[random_action];
}

void Client::playerAssert() {

}

void Client::playerPick() {
    bool has_imitate = false;
    for(int i = 0; i < 4; ++i){
        pick_choice.push_back(pick_msg.remain_fishes[i]);
        if(pick_choice[i] == 12)has_imitate = true;
    }
    if(has_imitate)pick_choice.push_back(1);
}

int Client::randomInt(int st, int ed) {
    static std::default_random_engine e(time(nullptr));
    std::uniform_int_distribution<int> u(st, ed);
    return u(e);
}

void GameInfo::update(const Json::Value& game_info) {
    for(int i = 0; i < 4; ++i){
        enemy_fish[i] = game_info["EnemyFish"][i].asInt();
        enemy_hp[i] = game_info["EnemyHP"][i].asInt();
        my_fish[i] = game_info["MyFish"][i].asInt();
        my_hp[i] = game_info["MyHP"][i].asInt();
        my_atk[i] = game_info["MyATK"][i].asInt();
    }
}

void Skill::update(const Json::Value& skill_info, int p) {
    target_pos.clear();
    target_value.clear();
    pos = p;
    std::string tmp = skill_info["type"].asString();
    if(tmp == "aoe")type = 0;
    else if(tmp == "infight")type = 1;
    else if(tmp == "crit")type = 2;
    else if(tmp == "subtle")type = 3;
    else type = 4;
    for(const auto& target: skill_info["targets"]){
        target_pos.push_back(target["pos"].asInt());
        target_value.push_back(target["value"].asInt());
    }
}

void ActionInfo::update(const Json::Value &action_info) {
    hit_order.clear();
    passive_order.clear();
    skill.update(action_info["skill"], action_info["ActionFish"].asInt());
    for(const auto& tmp: action_info["hit"]){
        hit_order.emplace_back(tmp["target"].asInt(),
                            tmp["isEnemy"].isBool(),
                            tmp["value"].asInt(),
                            tmp["traceable"].asBool());
    }
    for(const auto& tmp: action_info["passive"]){
        passive_order.emplace_back(tmp["type"].asString(),
                                   tmp["src"].asInt(),
                                   tmp["isEnemy"].asBool(),
                                   tmp["value"].asFloat());
    }
}

Hit::Hit(int _pos, bool _is_enemy, int _value, bool _traceable) {
    pos = _pos;
    is_enemy = _is_enemy;
    value = _value;
    traceable = _traceable;
}

Passive::Passive(const std::string& _type, int _src, bool _is_enemy, float _value) {
    if(_type == "counter")type = 0;
    else if(_type == "deflect")type = 1;
    else if(_type == "reduce")type = 2;
    else if(_type == "heal")type = 3;
    else type = 4;
    src = _src;
    is_enemy = _is_enemy;
    value = _value;
}

void Action::clear() {
    enemy_goal.clear();
    my_goal.clear();
}

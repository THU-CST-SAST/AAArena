#include <iostream>
#include "include/client.h"

int main() {
    auto client = new Client();
    client->run();
    delete client;
    return 0;
}

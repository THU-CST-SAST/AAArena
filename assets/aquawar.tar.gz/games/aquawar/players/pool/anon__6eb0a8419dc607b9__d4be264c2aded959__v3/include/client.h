//
// Created by 安頔 on 2021/1/20.
//

#ifndef AI_SDK_CLIENT_H
#define AI_SDK_CLIENT_H

#include "json.h"
#include <random>
#include <iostream>
#include <cassert>

class StateFish{
public:
    int type, atk, hp;
    int passive_cnt, active_cnt;
    bool imitate;
    bool is_assert;
    bool is_alive;
    bool has_reduce;
    bool has_share;
    bool has_heal;
    explicit StateFish(int _type, bool _imitate = false,
                       int _atk = 100, int _hp = 400,
                       int _passive_cnt = 0, int _active_cnt = 0,
                       bool _is_assert = false, bool _is_alive = true,
                       bool _has_reduce = false,
                       bool _has_share = false,
                       bool _has_heal = false);

    int get_attack() const;
};

class Action{
public:
    int player, type;
    int action_pos, assert_type;
    std::vector<int> enemy_goal;
    std::vector<int> my_goal;
    void clear();
};

class State{
public:
    StateFish info[2][4];
    int nxtState(const Action& act);
private:
    const int kAssertDamage = 50;
    static int randomInt(int st, int ed);
    static bool checkNoHurt(StateFish& fish);
    void updateDeath(const Action& act);
    void actionAssert(const Action& act);
    void actionAttack(const Action& act);
    void actionActive(const Action& act);
    void actionHurt(int act_player, int src, int dst, int value, int live_fish, bool imm);
    void actionHurtImmAfter(int act_player, int src, int dst);
};

class PickMessage{
public:
    std::vector<int>remain_fishes;
    bool is_first;
};

class GameInfo{
public:
    int enemy_fish[4];
    int enemy_hp[4];
    int my_fish[4];
    int my_hp[4];
    int my_atk[4];
    void update(const Json::Value& game_info);
};

class Skill{
public:
    int type, pos;
    std::vector<int>target_pos;
    std::vector<int>target_value;
    void update(const Json::Value& skill_info, int p);
};

class Hit{
public:
    int pos;
    bool is_enemy;
    int value;
    bool traceable;
    Hit(int _pos, bool _is_enemy, int _value, bool _traceable);
};

class Passive{
public:
    int type, src;
    bool is_enemy;
    float value;
    Passive(const std::string& _type, int _src, bool _is_enemy, float _value);
};

class ActionInfo{
public:
    Skill skill;
    std::vector<Hit>hit_order;
    std::vector<Passive>passive_order;
    void update(const Json::Value& action_info);
};

class AssertMessage{
public:
    int assert_pos, assert_content;
    bool assert_result;

    ActionInfo enemy_action, my_action;
    GameInfo now_state;
};

class ActionMessage{
public:
    int assert_pos, assert_content;
    bool assert_result;

    GameInfo now_state;
};

class Client{
public:
    [[noreturn]] void run();
    void playerPick();
    void playerAssert();
    void playerAction();
    std::vector<int>pick_choice;
    std::pair<int, int>assert_choice;
    Action action_choice;

private:
    std::string recv_msg;
    Json::Reader reader;
    Json::FastWriter writer;
    Json::Value root;
    PickMessage pick_msg;
    AssertMessage assert_msg;
    ActionMessage action_msg;
    static void sendLen(int len);
    void listenMessage();
    void transPickMessage();
    void transAssertMessage();
    void transActionMessage();
    void sendMessage(const std::string& s);
    static int randomInt(int st, int ed);
};

#endif //AI_SDK_CLIENT_H

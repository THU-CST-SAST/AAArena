#include "Action.hpp"
#include <algorithm>
//assert

struct FISH_ASSERT {
    int passive;
    int active;
    bool asserted;
    bool really_asserted;
    int SkillUsed;
};
static FISH_ASSERT fishes_assert[4];
static bool first = true;
static int current_round = 1;



std::vector<int> AI::Pick(Game game)
{
    // TODO: fill your code
    std::vector<int> remain_fishes = get_my_remain_fishes();
    std::vector<int> pickfish;
    pickfish.clear();
    for(int i = 0; i < 4; i ++)
        pickfish.push_back(remain_fishes[i] == 12 ? 13 : remain_fishes[i]);
    return pickfish;
}


std::pair<int, int> AI::Assert(Game game)
{    
    int i, j;
    if (game.round != current_round)
    {
        first = true;
        current_round = game.round;
        std::cerr << "--------NEW TURN--------"<< std::endl;
    }
    if (game.my_assert.assertResult && first == false) //记录成功断言的信息
    {
        fishes_assert[game.my_assert.assertPos].really_asserted = true;
        std::cerr << "ASSERT SUCCEED !"<< std::endl;
    }
    if (game.enemy_assert.assertResult && first == false) //记录成功断言的信息
    {
        std::cerr << "!!ENEMY ASSERT SUCCEED :("<< std::endl
        << game.enemy_assert.assertPos << "->" << game.enemy_assert.assertContent << std::endl;
    }
    if (first) //第一回合特判
    {
        first = false;
        for (int i = 0; i <= 3; i++)
        {
            fishes_assert[i].passive = 0;
            fishes_assert[i].active = 0;
            fishes_assert[i].asserted = false;
            fishes_assert[i].SkillUsed = 0;
        }
        if (game.first_mover == false)
        {
            if (game.enemy_action.is_skill)
            {
                fishes_assert[game.enemy_action.action_fish].SkillUsed ++;
                switch(game.enemy_action.type)
                {
                    case aoe:
                    fishes_assert[game.enemy_action.action_fish].active = 1;
                    break;
                    case infight:
                    fishes_assert[game.enemy_action.action_fish].active = 2;
                    break;
                    case crit:
                    fishes_assert[game.enemy_action.action_fish].active = 3;
                    break;
                    case subtle:
                    if (fishes_assert[game.enemy_action.action_fish].active == 3)
                        break;
                    fishes_assert[game.enemy_action.action_fish].active = 4;
                    break;
                }
            }
        }
        return std::make_pair(-1, -1);
    }

    /*std::cerr << "before:"<< std::endl;
    for (j = 0; j <= 3; j++)
    {
        std::cerr << fishes_assert[j].passive << "/"
        << fishes_assert[j].active << std::endl;
    }*/

    //std::cerr << "enemy turn passives:" << game.enemy_action.num_friend_passives << std::endl;
    for (i = 0; i < game.enemy_action.num_friend_passives; i++)
    {
        switch(game.enemy_action.friend_types[i])
        {
            case counter:
            if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 3
                || fishes_assert[game.enemy_action.friend_passives_id[i]].active == 4)
                break;
            fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 1;
            break;
            case deflect:
            if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 3
                || fishes_assert[game.enemy_action.friend_passives_id[i]].active == 4)
                break;
            fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 2;
            break;
            case reduce:
            if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 1
                || fishes_assert[game.enemy_action.friend_passives_id[i]].active == 2)
                break;
            fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 3;
            break;
            case heal:
            if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 1
                || fishes_assert[game.enemy_action.friend_passives_id[i]].active == 2)
                break;
            fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 4;
            break;
            case explode:
            fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 6;
            break;
        }
    }
    //std::cerr << "enemy turn done"<< std::endl;

    //std::cerr << "my turn passives:" << game.my_action.num_enemy_passives << std::endl;
    for (i = 0; i < game.my_action.num_enemy_passives; i++)
    {
        switch(game.my_action.enemy_types[i])
        {
            case counter:
            if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 3
                || fishes_assert[game.my_action.enemy_passives_id[i]].active == 4)
                break;
            fishes_assert[game.my_action.enemy_passives_id[i]].passive = 1;
            break;

            case deflect:
            if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 3
                || fishes_assert[game.my_action.enemy_passives_id[i]].active == 4)
                break;
            fishes_assert[game.my_action.enemy_passives_id[i]].passive = 2;
            break;

            case reduce:
            if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 1
                || fishes_assert[game.my_action.enemy_passives_id[i]].active == 2)
                break;
            fishes_assert[game.my_action.enemy_passives_id[i]].passive = 3;
            break;

            case heal:
            if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 1
                || fishes_assert[game.my_action.enemy_passives_id[i]].active == 2)
                break;
            fishes_assert[game.my_action.enemy_passives_id[i]].passive = 4;
            break;

            case explode:
            fishes_assert[game.my_action.enemy_passives_id[i]].passive = 6;
            break;
        }
    }
    //std::cerr << "my turn done"<< std::endl;

    if (game.enemy_action.is_skill)
    {
        fishes_assert[game.enemy_action.action_fish].SkillUsed ++;
        switch(game.enemy_action.type)
        {
            case aoe:
            fishes_assert[game.enemy_action.action_fish].active = 1;
            break;
            case infight:
            fishes_assert[game.enemy_action.action_fish].active = 2;
            break;
            case crit:
            fishes_assert[game.enemy_action.action_fish].active = 3;
            break;
            case subtle:
            if (fishes_assert[game.enemy_action.action_fish].active == 3
                || fishes_assert[game.enemy_action.action_fish].active == 1)
                break;
            fishes_assert[game.enemy_action.action_fish].active = 4;
            break;
        }
    }

    std::cerr << "analyze done"<< std::endl;
    /*for (int j = 0; j <= 3; j++)
    {
        std::cerr << fishes_assert[j].passive << "/"
        << fishes_assert[j].active << std::endl;
        // 被动/主动
    }*/

    for (int i = 0; i <= 3; i++)
    {
        if (get_enemy_hp(i) > 0 && fishes_assert[i].really_asserted == false)
        {
            if (fishes_assert[i].asserted == true)
            {
                std::cerr << "found_imitator 12, OHHHHHHHHH!"<< std::endl;
                fishes_assert[i].really_asserted = true;
                return std::make_pair(i, 12);
            }

            if (fishes_assert[i].passive == 1 && fishes_assert[i].active == 1
                && game.enemy_action.action_fish == i
                && game.enemy_action.is_skill
                && game.enemy_action.type == aoe
                && fishes_assert[i].SkillUsed > 3)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_1, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 1);
            }

            if (fishes_assert[i].passive == 1 && fishes_assert[i].active == 2)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_2, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 2);
            }

            if (fishes_assert[i].passive == 2 && fishes_assert[i].active == 1)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_3, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 3);
            }

            if (fishes_assert[i].passive == 2 && fishes_assert[i].active == 2)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_4, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 4);
            }

            if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 3
                && game.enemy_action.action_fish == i
                && game.enemy_action.is_skill
                && game.enemy_action.type == crit
                && fishes_assert[i].SkillUsed > 3)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_5, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 5);
            }

            if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 4)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_6, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 6);
            }

            if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 3
                && game.enemy_action.action_fish == i
                && game.enemy_action.is_skill
                && game.enemy_action.type == subtle)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_7, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 7);
            }

            if (fishes_assert[i].passive == 4 && fishes_assert[i].active == 4)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_8, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 8);
            }

            if (fishes_assert[i].passive == 4 && fishes_assert[i].active == 3)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_9, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 9);
            }

            if ((game.enemy_action.action_fish == i
                && game.enemy_action.is_skill == false
                && game.enemy_action.enemy_expected_injury[0] == 57) ||
                (game.enemy_action.action_fish == i
                    && game.enemy_action.is_skill
                    && game.enemy_action.type == crit
                    && game.enemy_action.enemy_expected_injury[0] == 140) ||
                (game.enemy_action.action_fish == i
                    && game.enemy_action.is_skill
                    && game.enemy_action.type == crit
                    && game.enemy_action.enemy_expected_injury[0] == 161))
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_10, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 10);
            }

            if (fishes_assert[i].active == 1
                && game.enemy_action.action_fish == i
                && game.enemy_action.is_skill
                && game.enemy_action.type == subtle)
            {
                fishes_assert[i].asserted = true;
                std::cerr << "found_fish_11, OHHHHHHHHH!"<< std::endl;
                return std::make_pair(i, 11);
            }

            //std::cerr << i << "assert_not_found" << std::endl;
        }
    }

    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
    // TODO: fill your code
    Action action(game);
    int my_pos = (get_my_living_fishes())[0];
    action.set_action_fish(my_pos);
    auto_valid_action(my_pos, &action);
    return action;
}
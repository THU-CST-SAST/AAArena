#pragma once

#include "sdk/ai_client.hpp"
#include <algorithm>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <assert.h>
#include <iomanip>
#include <unordered_set>
#include <unordered_map>
#include <bitset>
#include <vector>
#include <set>
#include <map>
using namespace std;
//gcc-specific trick
#define perr(fmt, ...) do { fprintf(stderr, fmt, ##__VA_ARGS__); } while (0)
#define Clr(x) memset((x),0,sizeof (x))
#define Clr1(x) memset((x),-1,sizeof (x))
#define eb emplace_back
#define pb push_back
#define asserteq(a,b) assert_eq(__LINE__,a,b)
template<class T>
void assert_eq(int l,T a,T b) {
	if(a!=b) {
		cerr<<"ERROR! On Line "<<l<<" a="<<a<<" b="<<b<<"\n";
		exit(-1);
	}
}
typedef pair<int,int> pii;
#define fi first
#define se second

//only simulating ONE round
struct GameSim {
	int pl;
	bool ddinfo=false; //open this for deduce info!
	/*
	1: B, 7:3
	2: F, >0 => +20
	4: H, -70%
	*/
	int buff[2][4],u0[2][4],u1[2][4],tot[2][4];
	bool sim[2][4];
	int typ[2][4],hp[2][4],att[2][4];
	bool ex[2][4];
	double rng() {return rand()*1./RAND_MAX;}
	void switch_turn() {
		pl^=1;
		swap(buff[0],buff[1]);
		swap(u0[0],u0[1]);
		swap(u1[0],u1[1]);
		swap(typ[0],typ[1]);
		swap(hp[0],hp[1]);
		swap(att[0],att[1]);
		swap(ex[0],ex[1]);
		swap(sim[0],sim[1]);
		swap(tot[0],tot[1]);
	}
	void clr() {
		memset(this,0,sizeof(GameSim));
	}
	int old_winner=0;
	int winner() {
		if(old_winner) return old_winner-2;
		if(num_alive(1)==0) {old_winner=2+pl; return 0;}
		if(num_alive(0)==0) {old_winner=2+(!pl); return 1;}
		return -1;
	}
	void dust_to_dust() {
		for(int a=0;a<2;++a)
			for(int b=0;b<4;++b) {
				if(typ[a][b]>0&&hp[a][b]<=0) typ[a][b]=-1;
				hp[a][b]=min(hp[a][b],400);
			}
		winner();
	}
	AssertInfo ass(int a,int b) {
		if (a == -1 || b == -1) return AssertInfo();
		assert(!ex[1][a]&&typ[1][a]>0);
		bool succ=(b==(sim[1][a]?12:typ[1][a]));
		if(succ) {
			ex[1][a]=1;
			for(int u=0;u<4;++u) hp[1][u]-=50;
		}
		else {
			for(int u=0;u<4;++u) hp[0][u]-=50;
		}
		dust_to_dust();
		AssertInfo g;
		g.assertPos = a;
		g.assertContent = b;
		g.assertResult = succ;
		return g;
	}
	int num_alive(int t) {
		int u=0;
		for(int i=0;i<4;++i) u+=(typ[t][i]>0);
		return u;
	}
	void aoe_team(int t,int u,int st,int sx) {
		for(int i=0;i<4;++i)
			if(typ[t][i]>0) hit(t,i,u,1,st,sx);
	}
	void aoe_team(int t,int u) {
		for(int i=0;i<4;++i)
			if(typ[t][i]>0) hit(t,i,u,0);
	}
	void aoe_team_total(int t,int u) {
		aoe_team(t,u/num_alive(t));
	}
	int lowest_hp(int t) const {
		int h=1e9;
		for(int i=0;i<4;++i)
			if(typ[t][i]>0) h=min(h,hp[t][i]);
		return h;
	}
	int attack(int t,int x) {
		//data might be inaccurate
		return max(att[t][x]+15*(typ[t][x]==hammerhead&&hp[t][x]<80),100);
	}
	//note: only filling useful field for deduce
	ActionInfo mov(int a,bool t,int f,int e) {
		assert(typ[0][a] > 0); dt.clear(); dt_ct = 0;
		ActionInfo rt; rt.is_skill = t; rt.action_fish = a;
		rt.num_enemy_targets = rt.num_friend_targets = 0;
		if(t==0) {
			rt.type = normalattack;
			rt.enemy_excepted_injury[0] = attack(0, a) / 2;
			assert(typ[1][e]>0);
			hit(1,e,attack(0,a)/2,1,0,a); //~50
		}
		else {
			switch(typ[0][a]) {
				case spray: case eel:
					rt.type = aoe;
					rt.enemy_excepted_injury[0] = attack(0, a) * 35 / 100;
					aoe_team(1,attack(0,a)*35/100,0,a); break; //35 aoe
				case flame: case sunfish:
					assert(f!=a&&typ[0][f]>0);
					rt.type = infight;
					hit(0,f,50,1,0,a); att[0][a]+=70; break; //50f
				case barracuda: //crit
					rt.type = crit;
					rt.enemy_targets[0] = e;
					rt.enemy_excepted_injury[0] = 120;
					assert(typ[1][e]>0);
					hit(1,e,120,1,0,a); break; //120
				case mobula: case octopus:
					rt.type = subtle;
					assert(typ[0][f]>0);
					buff[0][f]|=4; att[0][a]+=20; break; //0
				case turtle:
					rt.type = subtle;
					assert(f!=a&&typ[0][f]>0);
					buff[0][f]|=2;
					if(u1[0][a]<3) {
						rt.type = crit;
						rt.enemy_targets[0] = e;
						rt.enemy_excepted_injury[0] = 120;
						++u1[0][a];
						assert(typ[1][e]>0);
						hit(1,e,120,1,0,a); //crit, 120
					}
					break;
				case whiteshark: case hammerhead:
					rt.type = crit;
					rt.enemy_targets[0] = e;
					rt.enemy_excepted_injury[0] = attack(0, a) * ((hp[1][e] < 160) ? 14 : 12) / 10;
					assert(typ[1][e]>0&&hp[1][e]==lowest_hp(1));
					hit(1,e,attack(0,a)*((hp[1][e]<160)?14:12)/10,1,0,a); //crit, ~120/~140
					break;
				case clownfish:
					rt.type = subtle;
					assert(f!=a&&typ[0][f]>0);
					buff[0][f]|=1;
					if(u1[0][a]<3) {
						rt.type = aoe;
						rt.enemy_excepted_injury[0] = attack(0, a) * 35 / 100;
						++u1[0][a];
						aoe_team(1,attack(0,a)*35/100,0,a); //35 aoe
					}
					break;
				default: assert(0);
			}
		}
		dust_to_dust();
		return rt;
	}
	void debug() {
		cout<<"Current player: "<<pl<<"\n";
		for(int s=0;s<2;++s)
		{
		cout<<"Player "<<(pl^s)<<"\n";
		for(int i=0;i<4;++i) {
			if(typ[s][i]>0)
			{
			cout<<" "<<setw(2)<<typ[s][i];
			if(sim[s][i]) cout<<"*"; else cout<<" ";
			cout<<"  HP "<<setw(3)<<hp[s][i]<<"  ATT "<<setw(3)<<att[s][i];
			cout<<"  BUFF"<<bool(buff[s][i]&1)<<bool(buff[s][i]&2)<<bool(buff[s][i]&4);
			if(typ[s][i]==turtle) cout<<"  SHIELD "<<3-u0[s][i];
			if(typ[s][i]==turtle||typ[s][i]==clownfish)
				cout<<"  ACT "<<3-u1[s][i];
			if(ex[s][i]) cout<<"  EXPOSED"; cout<<"\n";
			}
			else cout<<" DEAD\n";
		}
		}
	}
	void init_hpatt() {
		for(int a=0;a<2;++a)
			for(int b=0;b<4;++b)
				if(typ[a][b]>0) hp[a][b]=400, att[a][b]=100;
	}
	int dt_ct;
	vector<tuple<int, passive_type*, int, int, int, int>> dt;
	private:
	void hit(int t,int x,int h,bool d,int st=-1,int sx=-1) {
		if(d) assert(st!=-1);
		bool skip = 0;
		if(typ[t][x]==turtle) {
			if (u0[t][x] < 3) { ++u0[t][x]; h = 0; skip = 1; }
			else if(rng()<0.3) h=0, skip=1;
		}
		else if(typ[t][x]==barracuda||typ[t][x]==mobula) {
			if(rng()<0.3) h=0, skip=1;
		}
		if (skip&&ddinfo)
			dt.eb(++dt_ct,new passive_type(reduce),t,x,0,-1);
		if(h&&d) {
			if((typ[t][x]==eel||typ[t][x]==sunfish)&&num_alive(t)>1) {
				if(ddinfo)dt.eb(++dt_ct, new passive_type(deflect), t, x, -1, -1);
				int w=h*3/10;
				aoe_team_total(t,w);
				h=h*7/10;
			}
			if(buff[t][x]&4) {
				if (ddinfo)dt.eb(++dt_ct, new passive_type(reduce), t, x, 70, -1);
				h=h*3/10;
			}
			if((buff[t][x]&1)&&num_alive(t)>1) {
				dt.eb(++dt_ct, new passive_type(deflect), t, x, -1, -1);
				int w=h*3/10;
				aoe_team_total(t,w);
				h=h*7/10;
			}
			buff[t][x]&=~5;
		}
		hp[t][x]-=h;
		dt.eb(++dt_ct, (passive_type*)0, t, x, h, d);
		if(typ[t][x]==sunfish||typ[t][x]==eel) {
			att[t][x]-=20*(tot[t][x]/200);
			tot[t][x]+=h;
			att[t][x]+=20*(tot[t][x]/200);
		}
		if(h) {
			if(d) {
				if(buff[t][x]&1) {
					if (hp[t][x] > 0) {
						hp[t][x] = min(hp[t][x] + 20, 400);
						if (ddinfo) dt.eb(++dt_ct, new passive_type(heal), t, x, -1, -1);
					}
				}
				buff[t][x]&=~1;
			}
			if(typ[t][x]==octopus||typ[t][x]==whiteshark) {
				if (hp[t][x] > 0) {
					hp[t][x] = min(hp[t][x] + 20, 400);
					if (ddinfo) dt.eb(++dt_ct, new passive_type(heal), t, x, -1, -1);
				}
			}
		}
		if(d) {
			if (typ[t][x] == clownfish && hp[t][x] < 120) {
				if (ddinfo) dt.eb(++dt_ct, new passive_type(counter), t, x, -1, -1);
				hit(st, sx, 30, 0);
			}
			if (typ[t][x] == hammerhead && hp[t][x] < 0) {
				if (ddinfo) dt.eb(++dt_ct, new passive_type(explode), t, x, -1, -1);
				hit(st, sx, 40, 0);
			}
			for(int j=0;j<4;++j)
				if(j!=x)if(typ[t][j]==spray||typ[t][j]==flame)
					if (hp[t][x] < 120) {
						if (ddinfo) dt.eb(++dt_ct, new passive_type(counter), t, x, -1, -1);
						hit(st, sx, 30, 0);
					}
		}
	}
};


#define N 13900
vector<int> os[33333]; int on;
bitset<N> mt[4][12];
void init_os() {
	if (on) return;
	int p[4];
	for(p[0]=1;p[0]<=11;++p[0])
	for(p[1]=1;p[1]<=11;++p[1])
	for(p[2]=1;p[2]<=11;++p[2])
	for(p[3]=1;p[3]<=11;++p[3])
	{
		int eq=0;
		for(int x=0;x<4;++x)
			for(int y=x+1;y<4;++y) eq+=p[x]==p[y];
		if(eq>1) continue;
		os[++on]=(vector<int>{p[0],p[1],p[2],p[3]});
		for(int j=0;j<4;++j) mt[j][p[j]][on]=1;
	}
	assert(on<N-10);
}

#define shui spray
#define huo flame
#define dian eel
#define che sunfish
#define suo barracuda
#define pen mobula
#define gui turtle
#define zhang octopus
#define bai whiteshark
#define chui hammerhead
#define chou clownfish

struct Deducer
{
public:
	bool silent = false;
	bitset<N> pr[2];
	int tot_pick=0;
	double att_est[2][4];
	int cnt_skip[2][4];
	int cnt_crit[2][4];
	int cnt_aoe[2][4];
	int cur_hp[2][4];
	int cnt_round; //need to be manually updated!!
	int found[15];
private:
	bool ar[2][4][15];
	int last_skill[2][4];
	int last_deflect[2][4];
	int last_heal[2][4];
	int last_reduce[2][4];
//	int last_skip[2][4];
	int maybe[2][13],rst[2][13];
public:
	void init() { tot_pick = 0; }
	void new_pick() {
		if(!tot_pick) {
			init_os(); Clr(maybe);
			for(int i=0;i<=14;++i) found[i]=0;
		}
		else {
			for(int x=0;x<2;++x)
			for(int i=0;i<4;++i) {
				if(rst[x][i]) {
					maybe[x][rst[x][i]]=1;
					continue;
				}
				for(int j=1;j<=11;++j) {
					if(could_be(x,i,j)) maybe[x][j]=maybe[x][12]=1;
				}
			}
			if (!silent) {
				for(int x=0;x<2;++x)
				{
					for(int j=1;j<=12;++j) perr("%d",int(maybe[x][j]));
					perr("|");
				}
				perr("mb\n");
			}
		}
		Clr(last_heal); Clr(last_deflect);
		Clr1(last_skill); Clr(last_reduce);
		Clr(cnt_aoe); Clr(cnt_crit); Clr(cnt_skip);
		Clr(ar); Clr(found); Clr(rst);
		pr[0].reset(); pr[1].reset();
		for(int i=1;i<=on;++i) pr[0][i]=1,pr[1][i]=1;
		if (!silent) {
			perr("start picking %d...\n", tot_pick);
			perr("%d ", pr[0].count());
			for (int i = 0; i < 4; ++i)
				for (int j = 1; j <= 11; ++j) perr("%d ", mt[i][j].count()); perr("\n");
		}
		for(int i=0;i<2;++i)
			for(int j=0;j<4;++j)
				att_est[i][j]=100,cur_hp[i][j]=400;
		cnt_round=0;
		++tot_pick;
	}	
	void upd_att(int x,int y,double L,double R) {
		L-=2; R+=2; //eps
		if(L>100)
			pr[x]&=mt[y][huo]|mt[y][dian]|mt[y][che]|mt[y][pen]|mt[y][zhang]|mt[y][chui];
		att_est[x][y]=max((L+R)/2,100.);
	}	
	void upd_att(int x,int y,double v) {
		upd_att(x,y,v,v);
	}	
	bool could_be_(int x,int y,int z) {
		if(z==12) return 1;
		return could_be(x,y,z);
	}	
	inline bool found_bf(int x) {
		return found[x]&&found[x]<tot_pick;
	}	
	inline bool could_be(int x,int y,int z) {
		return (pr[x]&mt[y][z]).any()&&!((ar[x][y][z]||found_bf(z))&&(ar[x][y][12]||found_bf(12)));
	}	
	void refresh_pr() {
		for(int x=0;x<2;++x)
			for(int y=0;y<4;++y)
				for(int z=1;z<=11;++z)
					if((ar[x][y][z]||found_bf(z))&&(ar[x][y][12]||found_bf(12))) pr[x]&=~mt[y][z];
//		perr("could be..\n");
//		dump_dbginfo();
		if(tot_pick==3)
			for(int x=0;x<2;++x)
			for(int j=1;j<=4;++j)
			{
				bool upd=0;
				map<int,vector<int>> cb;
				map<int,int> cnt;
				for(int i=0;i<4;++i) {
					for(int j=1;j<=11;++j) {
						if(could_be(x,i,j)) {++cnt[i]; cb[j].pb(i); cb[12].pb(i);}
					}
				}
				for(int i=1;i<=11;++i)
					if(!maybe[x][i]&&cb[i].size()==1)
					{
						ar[x][cb[i].back()][12]=1;
						if(cnt[cb[i].back()]==1) continue;
						int g1=pr[x].count();
						pr[x]&=mt[cb[i].back()][i];
						int g2=pr[x].count();
						if(g1!=g2) {
							upd=1;
							if(!silent)
								perr("from maybe: %d#%d belongs to %d!\n",x,i,cb[i].back());
						}
					}
				if(!upd) break;
			}
	}	
	bool could_be(int x,int y,vector<int> z) {
		for(auto c:z) if(could_be(x,y,c)) return 1; return 0;
	}	
	void parse_skill(int t,ActionInfo w) {
		if (w.is_empty()) return;
		int af=w.action_fish;
		if(w.type!=normalattack) last_skill[t][af]=cnt_round;
		switch(w.type) {
			case aoe:
				++cnt_aoe[t][af];
				if(cnt_aoe[t][af]>3)
					pr[t]&=mt[af][shui]|mt[af][dian];
				else
					pr[t]&=mt[af][shui]|mt[af][dian]|mt[af][chou];
				upd_att(t,af,w.enemy_excepted_injury[0]/0.35);
				break;
			case infight:
				pr[t]&=mt[af][huo]|mt[af][che];
				att_est[t][af]+=70;
				break;
			case crit:
				{
				++cnt_crit[t][af];
				int lowest=1e9;
				for(int j=0;j<4;++j)
					if(cur_hp[!t][j]>0) lowest=min(lowest,cur_hp[!t][j]);
				bool is_lowest=lowest==cur_hp[!t][w.enemy_targets[0]];
				auto ps=mt[af][suo];
				if(is_lowest) ps|=mt[af][bai]|mt[af][chui];
				if(cnt_crit[t][af]<=3) ps|=mt[af][gui];
				pr[t]&=ps;
				if(is_lowest&&lowest<160) {
					if(could_be(t,af,{suo,gui}))
						upd_att(t,af,w.enemy_excepted_injury[0]/1.4,w.enemy_excepted_injury[0]/1.2);
					else upd_att(t,af,w.enemy_excepted_injury[0]/1.4);
				}
				else
					upd_att(t,af,w.enemy_excepted_injury[0]/1.2);
				}
				break;
			case subtle:
				if(cnt_aoe[t][af]>=3) pr[t]&=mt[af][chou];
				else if(cnt_crit[t][af]>=3) pr[t]&=mt[af][gui];
				else pr[t]&=mt[af][pen]|mt[af][zhang];
				break;
			case normalattack:
				upd_att(t,w.action_fish,w.enemy_excepted_injury[0]*2);
				break;
		}
	}	
	void parse_passive(vector<tuple<int,passive_type*,int,int,int,int>> dt) {
		vector<int> alive[2];
		for(int a=0;a<2;++a)
		for(int i=0;i<4;++i) if(cur_hp[a][i]>0) alive[a].pb(i);
		sort(dt.begin(),dt.end());
		set<pii> dh,df,hh,ct,ah,hl;
		for(const auto& d:dt) {
			passive_type*ty=get<1>(d);
			int team=get<2>(d),id=get<3>(d),dt=get<4>(d);
			if(ty==0) {
				if(!silent) perr("Hit %d,%d,%d  %d\n",team,id,dt,get<5>(d));
				cur_hp[team][id]-=dt;
				if(get<5>(d)) dh.insert(pii(team,id));
				if(cur_hp[team][id]>0) ah.insert(pii(team,id));
				if(cur_hp[team][id]<120&&get<5>(d)) hh.insert(pii(team,id));
			}
			else {
				if(*ty==heal) {
					int &p=cur_hp[team][id];
					p=min(p+20,400);
				}
				switch(*ty) {
					case counter:
						{
						ct.insert(pii(team,id));
						if(!silent) perr("Counter(%d) %d,%d.\n",cnt_round,team,id);
						auto mb=mt[id][chou];
						for(auto j:alive[team])
							if(j!=id) mb|=mt[j][shui]|mt[j][huo];
						pr[team]&=mb;
						}
						break;
					case deflect:
						{
						df.insert(pii(team,id));
						if (!silent) {
							perr("Deflect(%d) %d,%d(%d#,%d).\n", cnt_round, team, id, last_deflect[team][id], last_heal[team][id]);
							for (int j = 0; j < 4; ++j) perr("%d ", last_skill[team][j]); perr("\n");
						}
						auto mb=mt[id][dian]|mt[id][che];
						for(int j=0;j<4;++j)
							if(j!=id&&last_skill[team][j]>=last_deflect[team][id]) mb|=mt[j][chou];
						pr[team]&=mb;
						last_deflect[team][id]=cnt_round;
						}
						break;
					case reduce:
						if (!silent)
							perr("Reduce(%d) %d,%d. %d\n",cnt_round,team,id,dt);
						if(dt==0) //skipped
						{
							pr[team]&=mt[id][pen]|mt[id][suo]|mt[id][gui];
							++cnt_skip[team][id];
						}
						else {
							bitset<N> mb;
							for(int j=0;j<4;++j)
								if(last_skill[team][j]>=last_reduce[team][id])
									mb|=mt[j][pen]|mt[j][zhang];
							pr[team]&=mb;
							last_reduce[team][id]=cnt_round;
						}
						break;
					case heal:
						{
						hl.insert(pii(team,id));
						if(cur_hp[team][id]>=120) hh.erase(pii(team,id));
						if (!silent) {
							perr("Heal(%d) %d,%d(%d,%d#).\n",cnt_round,team,id,last_deflect[team][id],last_heal[team][id]);
							for(int j=0;j<4;++j) perr("%d ",last_skill[team][j]);perr("\n");
						}
						auto mb=mt[id][zhang]|mt[id][bai];
						for(int j=0;j<4;++j)
							if(j!=id&&last_skill[team][j]>=last_heal[team][id]) mb|=mt[j][gui];
						pr[team]&=mb;
						last_heal[team][id]=cnt_round;
						}
						break;
					case explode:
						{
						if(!silent) perr("Explode(%d) %d,%d.\n",cnt_round,team,id);
						pr[team]&=mt[id][chui];
						}
						break;
					default: assert(0);
				}
			}
		}
		for(pii p:dh) {
			int team=p.fi,id=p.se;
			if(!df.count(p)&&alive[team].size()>1)
				pr[team]&=~(mt[id][dian]|mt[id][che]);
		}
		for(pii p:hh) {
			int team=p.fi,id=p.se;
			if(!ct.count(p)) {
				auto nah=mt[id][chou];
				for(auto j:alive[team])
					if(j!=id) nah|=mt[j][shui]|mt[j][huo];
				pr[team]&=~nah;
			}
		}
		for(pii p:ah) {
			int team=p.fi,id=p.se;
			if(!hl.count(p)) pr[team]&=~(mt[id][zhang]|mt[id][bai]);
		}
	}	
	void parse_assertinfo(int t,AssertInfo w) {
		if(!w.is_empty()) {
			if(!silent) perr("Oh. An assert. Party %d, Target %d, Content %d, Result %d\n",t,w.assertPos,w.assertContent,w.assertResult);
			if(w.assertResult) {
				for(int j=1;j<=12;++j)
					if(j!=w.assertContent) ar[!t][w.assertPos][j]=1;
				for(int j=0;j<4;++j)
					if(j!=w.assertPos) ar[!t][j][w.assertContent]=1;
				for(int j=0;j<4;++j) cur_hp[!t][j]-=50;
				if(!t) found[w.assertPos]=tot_pick;
				rst[!t][w.assertPos]=w.assertContent;
			}
			else {
				ar[!t][w.assertPos][w.assertContent]=1;
				for(int j=0;j<4;++j) cur_hp[t][j]-=50;
			}
		}
		refresh_pr();
	}	
	int decision(int t,int u) {
		assert(t==1);
		if(rst[t][u]||cur_hp[t][u]<=0) return -1;
		int s=0,dd=0,oc1=1;
		for(int i=1;i<=11;++i) {
			if(could_be(t,u,i)) {
				int c0=!found[i]&&!ar[t][u][i];
				int c1=!found[12]&&!ar[t][u][12];
				if(c0||c1) {
					dd+=c0*i+c1*12; ++s; oc1&=!c0;
				}
			}
		}
		if(oc1) return 12;
		if(s>1) return -1;
		return dd;
	}	
	pii asserter()
	{
		vector<pii> nr,rk;
		for(int i=0;i<4;++i) {
			int ty=decision(1,i);
			if(ty==-1) continue;
			if(ty<=12) nr.pb(pii(i,ty));
			else rk.pb(pii(i,ty-12));
		}
		int lowest_hp=1000;
		for(int j=0,h;j<4;++j)
			if((h=cur_hp[0][j])>0)
				lowest_hp=min(lowest_hp,h);
		if(nr.empty()&&lowest_hp<50) return make_pair(-1,-1); //don't risk it!
		if (nr.size() || rk.size()) { if (!silent) perr("Assert here we go!!!\n"); }
		sort(nr.begin(),nr.end(),[&](pii a,pii b){
			return cur_hp[1][a.fi]<cur_hp[1][b.fi];
		});
		sort(rk.begin(),rk.end(),[&](pii a,pii b){
			return cur_hp[1][a.fi]<cur_hp[1][b.fi];
		});
		if(!nr.empty()) return pii(nr[0].fi,nr[0].se);
		if(!rk.empty()) return pii(rk[0].fi,rk[0].se);
		return make_pair(-1,-1);
	}
};

/*
How to use deducer?
Init: init();
Pick: new_pick()
Assert:
	if cnt_round: parse_gameinfo(0,my_action)
	if cnt_round or !first_mover:
		parse_assertinfo(1,enemy_assert)
		parse_gameinfo(1,enemy_action)
	return asserter()
Act:
	parse_assertinfo(0,my_assert)
	++cnt_round
*/

vector<tuple<int,bool,int,int>> possible_moves(const GameSim& s,bool silent=false) {
	vector<int> ev,fv;
	for(int j=0;j<4;++j) if(s.typ[1][j]>0) ev.pb(j);
	for(int j=0;j<4;++j) if(s.typ[0][j]>0) fv.pb(j);
	if (silent) {
		perr("pm: fv %d  ev %d",fv.size(),ev.size());
		for(int i=0;i<4;++i) perr("(%d,%d)",s.typ[0][i],s.hp[0][i]);perr("|");
		for(int i=0;i<4;++i) perr("(%d,%d)",s.typ[1][i],s.hp[1][i]);perr("\n");
	}
	vector<tuple<int,bool,int,int>> ans;
	//(a,t,f,e)
	for(int a=0;a<4;++a) if(s.typ[0][a]>0) {
		for(int e:ev) ans.eb(a,false,-1,e);
		switch(s.typ[0][a]) {
			case spray: case eel:
				ans.eb(a,true,-1,-2); break;
			case flame: case sunfish:
				for(auto f:fv) if(f!=a) ans.eb(a,true,f,-1); break;
			case barracuda:
				for(auto e:ev) ans.eb(a,true,-1,e); break;
			case mobula: case octopus:
				for(auto f:fv) ans.eb(a,true,f,-1); break;
			case turtle:
				if(s.u1[0][a]>=3) {
					for(auto f:fv) if(f!=a) ans.eb(a,true,f,-1);
				}
				else {
					for(auto e:ev)
						for(auto f:fv)
							if(f!=a) ans.eb(a,true,f,e);
				}
				break;
			case whiteshark: case hammerhead:
				{
				int w=s.lowest_hp(1);
				for(auto e:ev) if(s.hp[1][e]==w) ans.eb(a,true,-1,e);
				}
				break;
			case clownfish:
				for(auto f:fv) if(f!=a) ans.eb(a,true,f,(s.u1[0][a]<3)?(-2):(-1));
				break;
			default: assert(0);
		}
	}
	return ans;
}

vector<tuple<int, bool, int, int, int>> possible_moves2(const GameSim& s, bool silent = false) {
	vector<int> ev, fv;
	for (int j = 0; j < 4; ++j) if (s.typ[1][j] > 0) ev.pb(j);
	for (int j = 0; j < 4; ++j) if (s.typ[0][j] > 0) fv.pb(j);
	if (silent) {
		perr("pm: fv %d  ev %d", fv.size(), ev.size());
		for (int i = 0; i < 4; ++i) perr("(%d,%d)", s.typ[0][i], s.hp[0][i]); perr("|");
		for (int i = 0; i < 4; ++i) perr("(%d,%d)", s.typ[1][i], s.hp[1][i]); perr("\n");
	}
	vector<tuple<int, bool, int, int, int>> ans;
	//(a,t,f,e)
	for (int a = 0; a < 4; ++a) if (s.typ[0][a] > 0) {
#define EB(p,q,r,s,t) ans.eb(p,q,r,s,(t)*4+a)
		for (int e : ev) EB(a, false, -1, e, e);
		switch (s.typ[0][a]) {
		case spray: case eel:
			EB(a, true, -1, -2, 4); break;
		case flame: case sunfish:
			for (auto f : fv) if (f != a) EB(a, true, f, -1, 5 + f); break;
		case barracuda:
			for (auto e : ev) EB(a, true, -1, e, 9 + e); break;
		case mobula: case octopus:
			for (auto f : fv) EB(a, true, f, -1, 13 + f); break;
		case turtle:
			if (s.u1[0][a] >= 3) {
				for (auto f : fv) if (f != a) EB(a, true, f, -1, 17 + f);
			}
			else {
				for (auto e : ev)
					for (auto f : fv)
						if (f != a) EB(a, true, f, e, 21 + e * 4 + f);
			}
			break;
		case whiteshark: case hammerhead:
		{
			int w = s.lowest_hp(1);
			for (auto e : ev) if (s.hp[1][e] == w) EB(a, true, -1, e, 37 + e);
		}
		break;
		case clownfish:
			for (auto f : fv) if (f != a) EB(a, true, f, (s.u1[0][a] < 3) ? (-2) : (-1), 41 + a);
			break;
		default: assert(0);
		}
#undef EB
		//total: 45*4=180
	}
	return ans;
}

#include "net.hpp"

class AI : public AIClient
{

private:
    bool is_inited = false;
	Game* game_ptr;

public:
    AI()
    {
    }
    ~AI()
    {
    }
	Deducer d,de;
	GameSim u;
	int tr = 0;
	void dump_dbginfo() {
		perr("dbg info:\n");
		for(int a=0;a<2;++a)
		for(int b=0;b<4;++b)
		{
		perr("%d,%d: ",a,b);
		for(int i=1;i<=11;++i)
			perr("%d",d.could_be(a,b,i));
		perr("|");
		for (int i = 1; i <= 11; ++i)
			perr("%d", de.could_be(!a, b, i));
		perr(" H%d",((a==0)?game_ptr->my_fish:game_ptr->enemy_fish)[b].hp);
		perr(" A%d ",((a==0)?game_ptr->my_fish:game_ptr->enemy_fish)[b].atk);
		if(a==1) perr("*");
		perr("%d",((a==0)?game_ptr->my_fish:game_ptr->enemy_fish)[b].id);
		perr("\n");
		}
	}
	vector<double> output_info()
	{
		vector<double> op(200);
		int m = 0;
		op[m++] = !(game_ptr->first_mover);
		op[m++] = d.cnt_round;
		op[m++] = d.tot_pick;
		op[m++] = tr-1;
		for (int b = 0; b < 4; ++b)
			for (int i = 0; i < 3; ++i) op[m++] = (u.buff[0][b]>>i)&1;
		for (int b = 0; b < 4; ++b)
			for (int i = 1; i <= 11; ++i) op[m++] = app_id(b) == i;
		for (int b = 0; b < 4; ++b)
			for (int i = 1; i <= 11; ++i) op[m++] = d.could_be(0, b, i);
		for (int b = 0; b < 4; ++b)
			for (int i = 1; i <= 11; ++i) op[m++] = d.could_be(1, b, i);
		for (int b = 0; b < 4; ++b) op[m++] = max(d.cur_hp[0][b], 0);
		for (int b = 0; b < 4; ++b) op[m++] = max(d.cur_hp[1][b], 0);
		for (int b = 0; b < 4; ++b) op[m++] = (d.cur_hp[0][b] > 0);
		for (int b = 0; b < 4; ++b) op[m++] = (d.cur_hp[1][b] > 0);
		for (int b = 0; b < 4; ++b) op[m++] = (d.cur_hp[0][b] > 0) ? (game_ptr->my_fish[b].atk) : 0;
		for (int i = 1; i <= 12; ++i) op[m++] = d.found_bf(i);
		for (int i = 1; i <= 12; ++i) op[m++] = d.found[i] != 0;
		assert(m == 192);
		op.resize(m); return op;
	}
	vector<pii> g, h;
	int tp=0;
	std::vector<int> Pick(Game game)
	{
		tr=1; ++tp;
		game_ptr=&game;
		dump_dbginfo();
		d.new_pick();
		de.new_pick();
		u.clr();
		dump_dbginfo();
#if 0
	    std::vector<int> remain_fishes = get_my_remain_fishes();
	    random_shuffle(remain_fishes.begin(),remain_fishes.end());
	    std::vector<int> pickfish;
	    pickfish.clear();
	    for(int i = 0; i < 4; i ++)
			pickfish.push_back(remain_fishes[i] == 12 ? (13+rand()%11) : remain_fishes[i]);
	    return pickfish;
#else
		if (tp == 1) {
			g.clear(); h.clear();
			g.pb(pii(bai, huo));
			g.pb(pii(chui, pen));
			g.pb(pii(zhang, che));
			random_shuffle(g.begin(), g.end());
			int rg = rand() % 2;
			h.pb(pii(suo+rg*12, chou));
			h.pb(pii(suo+(!rg)*12, dian));
			h.pb(pii(gui, shui));
			random_shuffle(h.begin(), h.end());
		}
		perr("tp=%d  %d,%d ", tp, g.size(), h.size());
		vector<int> s;
		s.push_back(g[tp - 1].fi);
		s.push_back(g[tp - 1].se);
		s.push_back(h[tp - 1].fi);
		s.push_back(h[tp - 1].se);
		random_shuffle(s.begin(), s.end());
		perr("pick");
		for (auto u : s) perr("%d,", u); perr("\n");
		return s;
#endif
	}	
	vector<int> alive_fish(int t) {
		return t?get_enemy_living_fishes():get_my_living_fishes();
	}	
	void parse_skill(int t,ActionInfo w) {
		d.parse_skill(t,w);
		de.parse_skill(!t, w);
	}
	vector<tuple<int, passive_type*, int, int, int, int>> xorr(const vector<tuple<int, passive_type*, int, int, int, int>>& a, int b) {
		vector<tuple<int, passive_type*, int, int, int, int>> v;
		for (const auto& t : a) v.eb(get<0>(t), get<1>(t), b ^ get<2>(t), get<3>(t), get<4>(t), get<5>(t));
		return v;
	}

	void parse_passive(int t,ActionInfo w) {
		vector<tuple<int,passive_type*,int,int,int,int>> dt;
		for(int j=0;j<w.num_enemy_injury;++j)
			dt.eb(w.enemy_injury_timestamp[j],
			(passive_type*)0,!t,w.enemy_injury_id[j],
			w.enemy_injury[j],w.enemy_injury_traceable[j]);
		for(int j=0;j<w.num_friend_injury;++j)
			dt.eb(w.friend_injury_timestamp[j],
			(passive_type*)0,t,w.friend_injury_id[j],
			w.friend_injury[j],w.friend_injury_traceable[j]);
		for(int j=0;j<w.num_enemy_passives;++j)
			dt.eb(w.enemy_passives_timestamp[j],
			&w.enemy_types[j],!t,w.enemy_passives_id[j],
			int(w.enemy_passive_value[j]*100+0.5),0);
		for(int j=0;j<w.num_friend_passives;++j)
			dt.eb(w.friend_passives_timestamp[j],
			&w.friend_types[j],t,w.friend_passives_id[j],
			int(w.friend_passive_value[j]*100+0.5),0);
		d.parse_passive(dt);
		de.parse_passive(xorr(dt,1));
		for(const auto& d:dt) {
			passive_type*ty=get<1>(d);
			int team=get<2>(d),id=get<3>(d),dt=get<4>(d);
			if(ty==0) {
				u.tot[team][id]+=dt;
			}
			else {
				switch(*ty) {
					case deflect:
						u.buff[team][id]&=~1;
						break;
					case reduce:
						if(dt!=0) u.buff[team][id]&=~4;
						break;
					case heal:
						u.buff[team][id]&=~2;
						break;
				}
			}
		}
	}	
	void parse_gameinfo(int t,ActionInfo w) {
		if(w.is_empty()) return;
		assert(w.action_fish!=-1);
		parse_skill(t,w);
		parse_passive(t,w);
	}	
	void parse_assertinfo(int t,AssertInfo w) {
		d.parse_assertinfo(t,w);
		de.parse_assertinfo(!t, w);
	}	
	std::pair<int, int> Assert(Game game)
	{
		game_ptr=&game;
		if (d.cnt_round)
			parse_gameinfo(0, game.my_action), ++tr;
		if (d.cnt_round||(!game.first_mover))
			parse_assertinfo(1, game.enemy_assert),
			parse_gameinfo(1, game.enemy_action), tr+=2;
		return d.asserter();
	}
	int app_id(int i) {
		int x=abs(game_ptr->my_fish[i].id);
		if(x==12) x=get_avatar_id();
		return x;
	}
	Action find_act() {
		vector<double> w = output_info();
		w = feed(w);
		if (rand() % 10 == 0) {
			perr("DBG ");
			for (auto u : w)
				perr("%.0lf ", u); perr("\n");
		}
		assert(w.size() == 180);
		Clr(u.sim);
		for (int i = 0; i < 4; ++i) if (game_ptr->my_fish[i].hp > 0)
		{
			u.typ[0][i] = app_id(i);
			u.hp[0][i] = game_ptr->my_fish[i].hp;
			u.att[0][i] = game_ptr->my_fish[i].atk;
		}
		else u.typ[0][i] = -1, u.hp[0][i] = -1;
		for (int i = 0; i < 4; ++i) if (game_ptr->enemy_fish[i].hp > 0)
		{
			u.typ[1][i] = 1;
			u.hp[1][i] = game_ptr->enemy_fish[i].hp;
			u.att[1][i] = d.att_est[1][i];
		}
		else u.typ[1][i] = -1, u.hp[1][i] = -1;
		for (int i = 0; i < 2; ++i)
			for (int j = 0; j < 4; ++j)
				u.u0[i][j] = d.cnt_skip[i][j],
				u.u1[i][j] = d.cnt_crit[i][j] + d.cnt_aoe[i][j];
		auto g = possible_moves2(u);
		double mv = -1e10; tuple<int, bool, int, int, int> oo;
		for(auto t:g) {
			int id = get<4>(t);
			assert(id >= 0 && id < 180);
			double v = w[id];
			if (v > mv) { mv = v; oo = t; }
		}
		int a = get<0>(oo), t = get<1>(oo), f = get<2>(oo), e = get<3>(oo);
		Action action(*game_ptr);
		action.set_action_fish(a);
		action.set_action_type(t);
		if (f >= 0) action.set_friend_target(f);
		if (e >= 0) action.set_enemy_target(e);
		else if (e == -2) {
			perr("AOE");
			for (int j = 0; j < 4; ++j)
				if (game_ptr->enemy_fish[j].hp > 0) action.set_enemy_target(j);
		}
		perr("Action: a%d t%d e%d f%d  Score=%.2lf  GS=%d\n", action.actionType, action.actionFish, action.enemyTarget, action.friendTarget, mv, g.size());
		return action;
	}
	void deal_buff(Action act) {
		if(act.actionType!=1) return;
		int ty=app_id(act.actionFish),tg=act.friendTarget;
		if(ty==pen||ty==zhang)
			u.buff[0][tg]|=4;
		else if(ty==gui)
			u.buff[0][tg]|=2;
		else if(ty==chou)
			u.buff[0][tg]|=1;
	}
	Action Act(Game game)
	{
		game_ptr=&game;
		parse_assertinfo(0, game.my_assert); ++tr;
		++d.cnt_round;
		perr("Round %d Act[Start]\n",d.cnt_round);
		dump_dbginfo();
		for(int j=0;j<4;++j)
		{
			if(!d.could_be_(0,j,abs(game.my_fish[j].id))) {
				cerr<<"wrong prediction!! "<<0<<","<<j<<" "<<game.my_fish[j].id<<"\n";
				dump_dbginfo(); exit(-1);
			}
		}
		for(int j=0;j<4;++j)
		{
			if(!de.could_be_(1,j,abs(game.my_fish[j].id))) {
				cerr<<"wrong prediction?? "<<0<<","<<j<<" "<<game.my_fish[j].id<<"\n";
				dump_dbginfo(); exit(-1);
			}
		}
		for(int j=0;j<4;++j)
			asserteq(max(d.cur_hp[0][j],0),game.my_fish[j].hp);
		for(int j=0;j<4;++j)
			asserteq(max(d.cur_hp[1][j],0),game.enemy_fish[j].hp);
		for (int j = 0; j < 4; ++j)
			asserteq(max(de.cur_hp[1][j], 0), game.my_fish[j].hp);
		for (int j = 0; j < 4; ++j)
			asserteq(max(de.cur_hp[0][j], 0), game.enemy_fish[j].hp);
		Action act=find_act();
		deal_buff(act);
		perr("Round %d Act[End]\n",d.cnt_round);
		return act;
	}
};

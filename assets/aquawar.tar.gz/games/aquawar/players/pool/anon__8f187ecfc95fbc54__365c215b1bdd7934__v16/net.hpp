#include <vector>
#include <iostream>
#include <string.h>
#include <math.h>
#include <assert.h>
using namespace std;
#include "dump.hpp"
vector<double> feed(vector<double> x) {
    assert(x.size()==192);
    #define Declare_Linear(L,n,m,weight,bias) \
    auto L=[&](vector<double> s) {\
    	assert(s.size()==n);vector<double> w(m);\
    	for(int j=0;j<m;++j)w[j]=bias[j];\
    	for(int i=0;i<n;++i)for(int j=0;j<m;++j)w[j]+=s[i]*weight[j][i];\
    	return w;\
	};
    #define Declare_BatchNorm(L,n,mean,var,weight,bias) \
    auto L=[&](vector<double> s) {\
    	assert(s.size()==n);\
		for(int j=0;j<n;++j)\
			s[j]=(s[j]-mean[j])/sqrt(var[j]+1e-5)*weight[j]+bias[j];\
		return s;\
	};
	auto RELU=[&](vector<double> s) {
		for(auto&u:s) u=max(u,0.); return s;
	};
	auto ADD=[&](vector<double> a,vector<double> b) {
		assert(a.size()==b.size());
		for(int i=0;i<(int)a.size();++i)a[i]+=b[i];
		return a;
	};
	Declare_Linear(L1,192,200,l1_weight,l1_bias)
	Declare_Linear(L21,200,50,l21_weight,l21_bias)
	Declare_Linear(L22,50,200,l22_weight,l22_bias)
	Declare_Linear(L31,200,50,l31_weight,l31_bias)
	Declare_Linear(L32,50,200,l32_weight,l32_bias)
	Declare_Linear(L41,200,50,l41_weight,l41_bias)
	Declare_Linear(L42,50,200,l42_weight,l42_bias)
	Declare_Linear(L51,200,50,l51_weight,l51_bias)
	Declare_Linear(L52,50,200,l52_weight,l52_bias)
	Declare_Linear(L61,200,50,l61_weight,l61_bias)
	Declare_Linear(L62,50,200,l62_weight,l62_bias)
	Declare_Linear(L71,200,50,l71_weight,l71_bias)
	Declare_Linear(L72,50,200,l72_weight,l72_bias)
	Declare_Linear(L8,200,180,l8_weight,l8_bias)
	x=RELU(L1(x));
	x=RELU(ADD(L22(L21(x)),x));
	x=RELU(ADD(L32(L31(x)),x));
	x=RELU(ADD(L42(L41(x)),x));
	x=RELU(ADD(L52(L51(x)),x));
	x=RELU(ADD(L62(L61(x)),x));
	x=RELU(ADD(L72(L71(x)),x));
	return L8(x);
}

/*
class DQN(nn.Module):
    def __init__(self):
        super(DQN, self).__init__()
        self.l1=nn.Linear(192,200)
        self.l21=nn.Linear(200,50)
        self.l22=nn.Linear(50,200)
        self.l31=nn.Linear(200,50)
        self.l32=nn.Linear(50,200)
        self.l41=nn.Linear(200,50)
        self.l42=nn.Linear(50,200)
        self.l51=nn.Linear(200,50)
        self.l52=nn.Linear(50,200)
        self.l61=nn.Linear(200,50)
        self.l62=nn.Linear(50,200)
        self.l71=nn.Linear(200,50)
        self.l72=nn.Linear(50,200)
        self.l8=nn.Linear(200,180)

    def forward(self, x, y):
        x = F.relu(self.l1(x))
        x = F.relu(self.l22(self.l21(x))+x)
        x = F.relu(self.l32(self.l31(x))+x)
        x = F.relu(self.l42(self.l41(x))+x)
        x = F.relu(self.l52(self.l51(x))+x)
        x = F.relu(self.l62(self.l61(x))+x)
        x = F.relu(self.l72(self.l71(x))+x)
        return self.l8(x)-y*1000000
*/

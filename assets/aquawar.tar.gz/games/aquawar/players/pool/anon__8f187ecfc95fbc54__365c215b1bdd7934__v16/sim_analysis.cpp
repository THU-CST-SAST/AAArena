#include <iostream>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <string>
#include <bitset>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <sstream>
#include <stack>
#include <iomanip>
using namespace std;
#define pb push_back
#define mp make_pair
typedef pair<int,int> pii;
typedef long long ll;
typedef double ld;
typedef vector<int> vi;
#define fi first
#define se second
#define fe first
#define FO(x) {freopen(#x".in","r",stdin);freopen(#x".out","w",stdout);}
#define Edg int M=0,fst[SZ],vb[SZ],nxt[SZ];void ad_de(int a,int b){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;}void adde(int a,int b){ad_de(a,b);ad_de(b,a);}
#define Edgc int M=0,fst[SZ],vb[SZ],nxt[SZ],vc[SZ];void ad_de(int a,int b,int c){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;vc[M]=c;}void adde(int a,int b,int c){ad_de(a,b,c);ad_de(b,a,c);}
#define es(x,e) (int e=fst[x];e;e=nxt[e])
#define esb(x,e,b) (int e=fst[x],b=vb[e];e;e=nxt[e],b=vb[e])
vector<int> os[33333]; int on;
double wr[999][999],wrr[999];
int main()
{
	int p[4];
	for(p[0]=1;p[0]<=11;++p[0])
	for(p[1]=p[0];p[1]<=11;++p[1])
	for(p[2]=p[1];p[2]<=11;++p[2])
	for(p[3]=p[2];p[3]<=11;++p[3])
	{
		int eq=0;
		for(int x=0;x<4;++x)
			for(int y=x+1;y<4;++y) eq+=p[x]==p[y];
		if(eq>1) continue;
		os[++on]=(vector<int>{p[0],p[1],p[2],p[3]});
	}
	freopen("sim.txt","r",stdin);
	for(int i=1;i<=on;++i)
		for(int j=1;j<=on;++j) cin>>wr[i][j];
	vector<pair<double,int>> st;
	for(int i=1;i<=on;++i) {
		double avr=0;
		for(int j=1;j<=on;++j) avr+=wr[i][j]+1-wr[j][i];
		avr/=on*2; wrr[i]=avr;
	}
	int cnt=0;
	double mx=-1;
	int I,J,K;
	for(int i=1;i<=on;++i)
	{
		int cc[13];
		for(int j=i+1;j<=on;++j)
		{
			memset(cc,0,sizeof cc);
			{
			int tt=0;
			for(auto g:os[i]) tt+=(++cc[g])>=2;
			for(auto g:os[j]) tt+=(++cc[g])>=2;
			if(tt>1) continue;
			}
			for(int k=j+1;k<=on;++k)
			{
				memset(cc,0,sizeof cc);
				int tt=0;
				for(auto g:os[i]) tt+=(++cc[g])>=2;
				for(auto g:os[j]) tt+=(++cc[g])>=2;
				for(auto g:os[k]) tt+=(++cc[g])>=2;
				if(tt>1) continue;
				double su=wrr[i]+wrr[j]+wrr[k];
				if(su>mx) {mx=su;
				I=i,J=j,K=k;
				}
			}
		}
	}
	cout<<mx<<"\n";
	cout<<wrr[I]<<","<<wrr[J]<<","<<wrr[K]<<"\n";
	for(auto t:os[I]) cout<<t<<" ";cout<<"\n";
	for(auto t:os[J]) cout<<t<<" ";cout<<"\n";
	for(auto t:os[K]) cout<<t<<" ";cout<<"\n";
}


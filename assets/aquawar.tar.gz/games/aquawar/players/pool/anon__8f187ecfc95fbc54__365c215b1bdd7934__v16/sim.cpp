﻿#include "sdk/ai_client.hpp"
#include <bits/stdc++.h>
using namespace std;
//gcc-specific trick
#define perr(fmt, ...) do { fprintf(stderr, fmt, ##__VA_ARGS__); } while (0)
#define Clr(x) memset((x),0,sizeof (x))
#define Clr1(x) memset((x),-1,sizeof (x))
#define eb emplace_back
#define pb push_back
#define asserteq(a,b) assert_eq(__LINE__,a,b)
template<class T>
void assert_eq(int l,T a,T b) {
	if(a!=b) {
		cerr<<"ERROR! On Line "<<l<<" a="<<a<<" b="<<b<<"\n";
		exit(-1);
	}
}
typedef pair<int,int> pii;
#define fi first
#define se second

//only simulating ONE round
struct GameSim {
int pl;
/*
1: B, 7:3
2: F, >0 => +20
4: H, -70%
*/
int buff[2][4],u0[2][4],u1[2][4],tot[2][4];
bool sim[2][4];
int typ[2][4],hp[2][4],att[2][4];
bool ex[2][4];
double rng() {return rand()*1./RAND_MAX;}
void switch_turn() {
	pl^=1;
	swap(buff[0],buff[1]);
	swap(u0[0],u0[1]);
	swap(u1[0],u1[1]);
	swap(typ[0],typ[1]);
	swap(hp[0],hp[1]);
	swap(att[0],att[1]);
	swap(ex[0],ex[1]);
	swap(sim[0],sim[1]);
	swap(tot[0],tot[1]);
}
void clr() {
	memset(this,0,sizeof(GameSim));
}
int old_winner=0;
int winner() {
	if(old_winner) return old_winner-2;
	if(num_alive(1)==0) {old_winner=2; return 0;}
	if(num_alive(0)==0) {old_winner=3; return 1;}
	return -1;
}
void dust_to_dust() {
	for(int a=0;a<2;++a)
		for(int b=0;b<4;++b) {
			if(typ[a][b]>0&&hp[a][b]<=0) typ[a][b]=-1;
			hp[a][b]=min(hp[a][b],400);
		}
	winner();
}
bool ass(int a,int b) {
	assert(!ex[1][a]&&typ[1][a]>0);
	bool succ=(b==(sim[1][a]?12:typ[1][a]));
	if(succ) {
		ex[1][a]=1;
		for(int u=0;u<4;++u) hp[1][u]-=50;
	}
	else {
		for(int u=0;u<4;++u) hp[0][u]-=50;
	}
	dust_to_dust(); return succ;
}
int num_alive(int t) {
	int u=0;
	for(int i=0;i<4;++i) u+=(typ[t][i]>0);
	return u;
}
void aoe_team(int t,int u,int st,int sx) {
	for(int i=0;i<4;++i)
		if(typ[t][i]>0) hit(t,i,u,1,st,sx);
}
void aoe_team(int t,int u) {
	for(int i=0;i<4;++i)
		if(typ[t][i]>0) hit(t,i,u,0);
}
void aoe_team_total(int t,int u) {
	aoe_team(t,u/num_alive(t));
}
int lowest_hp(int t) const {
	int h=1e9;
	for(int i=0;i<4;++i)
		if(typ[t][i]>0) h=min(h,hp[t][i]);
	return h;
}
int attack(int t,int x) {
	//data might be inaccurate
	return max(att[t][x]+15*(typ[t][x]==hammerhead&&hp[t][x]<80),100);
}
void mov(int a,bool t,int f,int e) {
	assert(typ[0][a]>0);
	if(t==0) {
		assert(typ[1][e]>0);
		hit(1,e,attack(0,a)/2,1,0,a); //~50
	}
	else {
		switch(typ[0][a]) {
			case spray: case eel:
				aoe_team(1,attack(0,a)*35/100,0,a); break; //35 aoe
			case flame: case sunfish:
				assert(f!=a&&typ[0][f]>0);
				hit(0,f,50,1,0,a); att[0][a]+=70; break; //50f
			case barracuda: //crit
				assert(typ[1][e]>0);
				hit(1,e,120,1,0,a); break; //120
			case mobula: case octopus:
				assert(typ[0][f]>0);
				buff[0][f]|=4; att[0][a]+=20; break; //0
			case turtle:
				assert(f!=a&&typ[0][f]>0);
				buff[0][f]|=2;
				if(u1[0][a]<3) {
					++u1[0][a];
					assert(typ[1][e]>0);
					hit(1,e,120,1,0,a); //crit, 120
				}
				break;
			case whiteshark: case hammerhead:
				assert(typ[1][e]>0&&hp[1][e]==lowest_hp(1));
				hit(1,e,attack(0,a)*((hp[1][e]<160)?14:12)/10,1,0,a); //crit, ~120/~140
				break;
			case clownfish:
				assert(f!=a&&typ[0][f]>0);
				buff[0][f]|=1;
				if(u1[0][a]<3) {
					++u1[0][a];
					aoe_team(1,attack(0,a)*35/100,0,a); //35 aoe
				}
				break;
			default: assert(0);
		}
	}
	dust_to_dust();
}
void debug() {
	cout<<"Current player: "<<pl<<"\n";
	for(int s=0;s<2;++s)
	{
	cout<<"Player "<<(pl^s)<<"\n";
	for(int i=0;i<4;++i) {
		if(typ[s][i]>0)
		{
		cout<<" "<<setw(2)<<typ[s][i];
		if(sim[s][i]) cout<<"*"; else cout<<" ";
		cout<<"  HP "<<setw(3)<<hp[s][i]<<"  ATT "<<setw(3)<<att[s][i];
		cout<<"  BUFF"<<bool(buff[s][i]&1)<<bool(buff[s][i]&2)<<bool(buff[s][i]&4);
		if(typ[s][i]==turtle) cout<<"  SHIELD "<<3-u0[s][i];
		if(typ[s][i]==turtle||typ[s][i]==clownfish)
			cout<<"  ACT "<<3-u1[s][i];
		if(ex[s][i]) cout<<"  EXPOSED"; cout<<"\n";
		}
		else cout<<" DEAD\n";
	}
	}
}
void init_hpatt() {
	for(int a=0;a<2;++a)
		for(int b=0;b<4;++b)
			if(typ[a][b]>0) hp[a][b]=400, att[a][b]=100;
}
private:
void hit(int t,int x,int h,bool d,int st=-1,int sx=-1) {
	if(d) assert(st!=-1);
	if(typ[t][x]==turtle) {
		if(u0[t][x]<3) {++u0[t][x]; h=0;}
		else if(rng()<0.3) h=0;
	}
	else if(typ[t][x]==barracuda||typ[t][x]==mobula) {
		if(rng()<0.3) h=0;
	}
	if(h&&d) {
		if((typ[t][x]==eel||typ[t][x]==sunfish)&&num_alive(t)>1) {
			int w=h*3/10;
			aoe_team_total(t,w);
			h=h*7/10;
		}
		if(buff[t][x]&4) {
			h=h*3/10;
		}
		if((buff[t][x]&1)&&num_alive(t)>1) {
			int w=h*3/10;
			aoe_team_total(t,w);
			h=h*7/10;
		}
		buff[t][x]&=~5;
	}
	hp[t][x]-=h;
	if(typ[t][x]==sunfish||typ[t][x]==eel) {
		att[t][x]-=20*(tot[t][x]/200);
		tot[t][x]+=h;
		att[t][x]+=20*(tot[t][x]/200);
	}
	if(h) {
		if(d) {
			if(buff[t][x]&1) {
				if(hp[t][x]>0) hp[t][x]=min(hp[t][x]+20,400);
			}
			buff[t][x]&=~1;
		}
		if(typ[t][x]==octopus||typ[t][x]==whiteshark) {
			if(hp[t][x]>0) hp[t][x]=min(hp[t][x]+20,400);
		}
	}
	if(d) {
		if(typ[t][x]==clownfish&&hp[t][x]<120) hit(st,sx,30,0);
		if(typ[t][x]==hammerhead&&hp[t][x]<0) hit(st,sx,40,0);
		for(int j=0;j<4;++j)
			if(j!=x)if(typ[t][j]==spray||typ[t][j]==flame)
				if(hp[t][x]<120) hit(st,sx,30,0);
	}
}
};


vector<tuple<int,bool,int,int>> possible_moves(const GameSim& s) {
	vector<int> ev,fv;
	for(int j=0;j<4;++j) if(s.typ[1][j]>0) ev.pb(j);
	for(int j=0;j<4;++j) if(s.typ[0][j]>0) fv.pb(j);
//	perr("pm: fv %d  ev %d",fv.size(),ev.size());
//	for(int i=0;i<4;++i) perr("(%d,%d)",s.typ[0][i],s.hp[0][i]);perr("|");
//	for(int i=0;i<4;++i) perr("(%d,%d)",s.typ[1][i],s.hp[1][i]);perr("\n");
	vector<tuple<int,bool,int,int>> ans;
	//(a,t,f,e)
	for(int a=0;a<4;++a) if(s.typ[0][a]>0) {
		for(int e:ev) ans.eb(a,false,-1,e);
		switch(s.typ[0][a]) {
			case spray: case eel:
				ans.eb(a,true,-1,-2); break;
			case flame: case sunfish:
				for(auto f:fv) if(f!=a) ans.eb(a,true,f,-1); break;
			case barracuda:
				for(auto e:ev) ans.eb(a,true,-1,e); break;
			case mobula: case octopus:
				for(auto f:fv) ans.eb(a,true,f,-1); break;
			case turtle:
				if(s.u1[0][a]>=3) {
					for(auto f:fv) if(f!=a) ans.eb(a,true,f,-1);
				}
				else {
					for(auto e:ev)
						for(auto f:fv)
							if(f!=a) ans.eb(a,true,f,e);
				}
				break;
			case whiteshark: case hammerhead:
				{
				int w=s.lowest_hp(1);
				for(auto e:ev) if(s.hp[1][e]==w) ans.eb(a,true,-1,e);
				}
				break;
			case clownfish:
				for(auto f:fv) if(f!=a) ans.eb(a,true,f,(s.u1[0][a]<3)?(-2):(-1));
				break;
			default: assert(0);
		}
	}
	return ans;
}
	#define shui spray
	#define huo flame
	#define dian eel
	#define che sunfish
	#define suo barracuda
	#define pen mobula
	#define gui turtle
	#define zhang octopus
	#define bai whiteshark
	#define chui hammerhead
	#define chou clownfish
	
GameSim make_move(const GameSim& u) {
		auto moves=possible_moves(u);
		vector<double> tsc(moves.size());
		time_t t0=clock();
		int ran=0;
			for(int i=0;i<(int)moves.size();++i) {
				GameSim v=u;
				v.mov(get<0>(moves[i]),get<1>(moves[i]),get<2>(moves[i]),get<3>(moves[i]));
				double scr=0;
				for(int p=0;p<2;++p)
					for(int q=0;q<4;++q) if(u.hp[p][q]>0) {
						if(p==0) {
							int b=v.buff[p][q],ty=u.typ[p][q];
							if(b&1) scr+=3;
							if(b&2) scr+=15;
							if(b&4) scr+=60/(1+(ty==gui||ty==suo||ty==pen)*0.3);
							int da=v.att[p][q]-u.att[p][q];
							scr+=da*1.5;
						}
						bool dd=v.hp[p][q]<=0;
						int dt=u.hp[p][q]-max(v.hp[p][q],0);
						if(p==0) {
							if(dd) scr-=200;
							scr-=pow(abs(dt),1.02)*((dt>0)?1:(-1));
						}
						else {
							if(dd) scr+=150;
							scr+=pow(abs(dt),1.01)*((dt>0)?1:(-1));
						}
					}
				tsc[i]+=scr;
			}
		int mi=-1;
		for(int i=0;i<(int)moves.size();++i)
			if(mi==-1||tsc[i]>tsc[mi]) mi=i;
		auto mov=moves[mi];
		GameSim v=u;
		int a=get<0>(mov),t=get<1>(mov),f=get<2>(mov),e=get<3>(mov);
		v.mov(a,t,f,e);
		v.switch_turn();
		return v;
}
double run(vector<int> a,vector<int> b) {
	assert(a.size()==4&&b.size()==4);
	random_shuffle(a.begin(),a.end());
	random_shuffle(b.begin(),b.end());
	for(int r=1;r<=5;++r)
	{
		GameSim s; s.clr();
		for(int i=0;i<4;++i) s.typ[0][i]=a[i];
		for(int i=0;i<4;++i) s.typ[1][i]=b[i];
		s.init_hpatt();
		int cnt_rnd=0;
	//	s.debug();
		while(s.winner()==-1) {
			s=make_move(s);
			++cnt_rnd;
			if(cnt_rnd>200+(15<<r)) break;
		}
		if(s.winner()==-1) continue;
		return s.winner()==0;
	}
	return 0.5;
}
vector<int> os[33333]; int on;
double wr[999][999];
int main()
{
	int p[4];
	for(p[0]=1;p[0]<=11;++p[0])
	for(p[1]=p[0];p[1]<=11;++p[1])
	for(p[2]=p[1];p[2]<=11;++p[2])
	for(p[3]=p[2];p[3]<=11;++p[3])
	{
		int eq=0;
		for(int x=0;x<4;++x)
			for(int y=x+1;y<4;++y) eq+=p[x]==p[y];
		if(eq>1) continue;
		os[++on]=(vector<int>{p[0],p[1],p[2],p[3]});
	}
	freopen("sim.txt","w",stdout);
	for(int i=1;i<=on;++i)
	{
		cerr<<i<<"/"<<on<<"   "<<clock()*1./CLOCKS_PER_SEC/(i-1)*on<<"s\n";
		for(int j=1;j<=on;++j)
		{
			double c[7];
			#pragma omp parallel for
			for(int h=1;h<=5;++h)
			{
				c[h]=run(os[i],os[j]);
			}
			for(int h=1;h<=5;++h)
				wr[i][j]+=c[h];
			wr[i][j]/=5;
			printf("%.2lf ",wr[i][j]);
		}
		printf("\n");
	}
}


#include "Action.hpp"
int main()
{
    AI *myAI = new AI();
    myAI->run();
    delete (myAI);
    return 0;
}

/*
GameSim g;
Deducer d[2];
set<int> a[2];
struct Player {
virtual vector<int> pick(const Deducer& d,set<int> a) {
    vector<int> v;
    for (auto x : a) v.push_back(x);
    random_shuffle(v.begin(), v.end());
    v.resize(4);
    for (auto& x : v) if (x == 12) x += rand() % 11 + 1;
    return v;
}
virtual tuple<int, bool, int, int> move(const Deducer& d) {
    auto movs = possible_moves(g); //todo: modify
//    cout << "Find moves..." << movs.size()<<"\n";
    return movs[rand() % movs.size()];
}
};
Player *p[2];
vector<tuple<int, passive_type*, int, int, int, int>> xorr(const vector<tuple<int, passive_type*, int, int, int, int>>& a, int b) {
    vector<tuple<int, passive_type*, int, int, int, int>> v;
    for (const auto& t : a) v.eb(get<0>(t), get<1>(t), b ^ get<2>(t), get<3>(t), get<4>(t), get<5>(t));
    return v;
}
int run(int sp) {
    p[0] = new Player(); p[1] = new HPlayer();
    for (int i = 0; i < 2; ++i) {
        d[i].init(), d[i].silent = 1; a[i].clear();
        for (int j = 1; j <= 12; ++j) a[i].insert(j);
    }
    vector<int> winners;
    for (int i = 0; i < 3; ++i) {
        cerr << "Round " << i << "!! Starting with " << sp << "\n";
        vector<int> pl[2];
        for (int j = 0; j < 2; ++j)
            d[j].new_pick(),
            pl[j] = p[j]->pick(d[j], a[j]);
        g.clr();
        for (int i = 0; i < 2; ++i) {
            assert(pl[i].size() == 4);
            for (int j = 0; j < 4; ++j) {
                int x = pl[i][j];
                //cout << x << " ";
                assert(x >= 1 && x <= 12 + 11 && x != 12);
                a[i].erase(min(x, 12));
                int y = x; if (y >= 12) y -= 12;
                g.typ[i][j] = y;
                g.sim[i][j] = (x >= 12);
            }
            //if (i) cout << "\n";
            //else cout << "|";
        }
        g.pl = 0;
        if(sp) g.switch_turn();
        g.init_hpatt();
        int cp = sp;
        ActionInfo last_act0[2];
        vector<tuple<int, passive_type*, int, int, int, int>> last_act1[2];
        AssertInfo last_ass[2];
        int tr = 0;
        while (tr<64) {
            if (d[cp].cnt_round) {
                d[cp].parse_skill(0, last_act0[cp]);
                d[cp].parse_passive(0, last_act1[cp]);
            }
            if (d[cp].cnt_round || (cp != sp)) {
                d[cp].parse_assertinfo(1, last_ass[!cp]);
                d[cp].parse_skill(1, last_act0[!cp]);
                d[cp].parse_passive(1, xorr(last_act1[!cp], 1));
            }
            for (int j = 0; j < 4; ++j)
                assert(max(d[cp].cur_hp[0][j], 0) == max(g.hp[0][j], 0));
            for (int j = 0; j < 4; ++j)
                assert(max(d[cp].cur_hp[1][j], 0) == max(g.hp[1][j], 0));
            pii h = d[cp].asserter();
            last_ass[cp] = g.ass(h.first, h.second); ++tr;
            if (g.winner() == -1) {
                //if (h.first != -1)
                //    cout << tr << "* " << cp << "|a " << h.first << " " << h.second << "   rst"<<last_ass[cp].assertResult<<"\n";
                d[cp].parse_assertinfo(0, last_ass[cp]);
                for (int j = 0; j < 4; ++j)
                    assert(max(d[cp].cur_hp[0][j], 0) == max(g.hp[0][j], 0));
                for (int j = 0; j < 4; ++j)
                    assert(max(d[cp].cur_hp[1][j], 0) == max(g.hp[1][j], 0));
                ++d[cp].cnt_round;
                auto w = p[cp]->move(d[cp]);
                g.ddinfo = 1;
                last_act0[cp] = g.mov(get<0>(w), get<1>(w), get<2>(w), get<3>(w)); ++tr;
                last_act1[cp] = g.dt;
                //cout << tr << "* "<< cp<<"|m "<<(get<0>(w)) << " " << (get<1>(w)) << " " << (get<2>(w)) << " " << (get<3>(w))
                //    << "   typ"<<last_act0[cp].type <<" rst"<<last_act1[cp].size()<<"\n";
                //g.debug();
                /*
                for(int u=0;u<2;++u)
                {
                    cerr << "d[" << u << "] info:\n";
                    for (int a = 0; a < 2; ++a)
                        for (int b = 0; b < 4; ++b)
                        {
                            cerr << a << "," << b << ": ";
                            for (int i = 1; i <= 11; ++i) {
                                cerr << d[u].could_be(a, b, i);
                                cerr.flush();
                                if (i == g.typ[a ^ u^cp][b]) assert(d[u].could_be(a, b, i));
                            }
                            cerr << "  "<<g.typ[a^u^cp][b]<<"\n";
                        }*  /
                }
                if(rand()%50==0)
                for (int u = 0; u < 2; ++u)
                    for (int a = 0; a < 2; ++a)
                        for (int b = 0; b < 4; ++b)
                            for (int i = 1; i <= 11; ++i)
                                if (i == g.typ[a ^ u ^ cp][b]) assert(d[u].could_be(a, b, i));
            }
            if (g.winner() != -1) {
                int wn = g.winner();
                sp = !wn;
                winners.push_back(wn);
                cerr << "Winner: " << wn << " (turn " << tr << ")\n";
                break;
            }
            g.switch_turn();
            cp ^= 1;
        }
        if (g.winner() == -1) {
            if (g.pl) g.switch_turn();
            cout << "TL.\n";
            int t0 = 0, t1 = 0;
            for (int i = 0; i < 4; ++i) {
                if (g.hp[0][i] > 0) ++t0, t1 += g.hp[0][i];
                if (g.hp[1][i] > 0) --t0, t1 -= g.hp[1][i];
            }
            int wn = 0;
            if (t0 > 0) wn = 0;
            else if (t0 < 0) wn = 1;
            else if (t1 > 0) wn = 0;
            else if (t1 < 0) wn = 1;
            else {
                cout << "badidea.\n";
                wn = rand() % 2;
            }
            sp = !wn;
            winners.push_back(wn);
        }
    }
    sort(winners.begin(), winners.end());
    return winners[1];
}
int main() {
    int tot[2][2];
    memset(tot, 0, sizeof tot);
    for (int i = 1; i <= 1000; ++i) {
        if (i % 1 == 0) cout << "run " << i << "\n";
        int ww = run(i%2); ++tot[i%2][ww];
        cerr << "Overall: " << ww << "\n";
        if (i % 1 == 0) {
        cout << "start with 0: " << tot[0][0] << " " << tot[0][1] << "\n";
        cout << "start with 1: " << tot[1][0] << " " << tot[1][1] << "\n";
        }
    }
}
*/
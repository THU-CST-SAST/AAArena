struct HPlayer: Player {
    GameSim u;
    virtual vector<int> pick(const Deducer& d, set<int> a) {
        u.clr();
        vector<int> s;
        switch (d.tot_pick) {
            //borrowed
        case 1: s = { 1,7,10,6 }; break;
        case 2: s = { 8,11,5,4 }; break;
        case 3: s = { 2,7 + 12,9,3 }; break;
        }
        random_shuffle(s.begin(), s.end());
        return s;
    }
    vector<int> samples;
    int sample_enemy[4];
    const Deducer* dd;
    inline void gen_enemy() {
        int w = samples[rand() % samples.size()];
        for (int i = 0; i < 4; ++i) {
            if (dd->cur_hp[1][i] <= 0) sample_enemy[i] = -1;
            else sample_enemy[i] = os[w][i];
        }
    }
    void gen_enemy_init() {
        auto& s = dd->pr[1]; samples.clear();
#ifndef _MSC_VER
        for (int g = s._Find_first(); g < N; g = s._Find_next(g)) samples.pb(g);
#else
        for (int g = 0; g < N; ++g) if (s[g]) samples.pb(g);
#endif
        random_shuffle(samples.begin(), samples.end());
        unordered_set<int> pb;
        for (auto& w : samples)
        {
            int c = 0;
            for (int i = 0; i < 4; ++i)
                if (dd->cur_hp[1][i] > 0) c = c * 15 + os[w][i];
            pb.insert(c);
        }
        perr("%d enemy cases\n", (int)pb.size());
    }
    int app_id(int i) {
        return g.typ[0][i];
    }
    virtual tuple<int,bool,int,int> move(const Deducer& d) {
        dd = &d;
        perr("find_act");
        Clr(u.sim);
        for (int i = 0; i < 4; ++i) if (d.cur_hp[0][i] > 0)
        {
            u.typ[0][i] = app_id(i);
            u.hp[0][i] = d.cur_hp[0][i];
            u.att[0][i] = g.att[0][i]; //leak
        }
        else u.typ[0][i] = -1, u.hp[0][i] = -1;
        for (int i = 0; i < 4; ++i) if (d.cur_hp[1][i] > 0)
        {
            u.typ[1][i] = 1; //fill this afterwards!
            u.hp[1][i] = d.cur_hp[1][i];
            u.att[1][i] = d.att_est[1][i];
        }
        else u.typ[1][i] = -1, u.hp[1][i] = -1;
        for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 4; ++j)
                u.u0[i][j] = d.cnt_skip[i][j],
                u.u1[i][j] = d.cnt_crit[i][j] + d.cnt_aoe[i][j];
        perr(":");
        gen_enemy_init();
        perr(":");
        auto moves = possible_moves(u);
        perr("moves=%d\n", moves.size());
        for (int i = 0; i < 2; ++i)
        {
            for (int j = 0; j < 4; ++j)
                perr("%d(%d) ", u.typ[i][j], u.hp[i][j]);
            perr("\n");
        }
        perr("test gen_enemy...");
        gen_enemy(); perr("ok.\n");
        vector<double> tsc(moves.size());
        time_t t0 = clock();
        int ran = 0;
        while (clock() < t0 + .02 * CLOCKS_PER_SEC) { //todo: edit
            gen_enemy(); ++ran;
            for (int i = 0; i < 4; ++i)
                if (sample_enemy[i] >= 0)
                    u.typ[1][i] = sample_enemy[i];
                else assert(u.typ[1][i] == -1);
            for (int i = 0; i < (int)moves.size(); ++i) {
                GameSim v = u;
                v.mov(get<0>(moves[i]), get<1>(moves[i]), get<2>(moves[i]), get<3>(moves[i]));
                double scr = 0;
                for (int p = 0; p < 2; ++p)
                    for (int q = 0; q < 4; ++q) if (u.hp[p][q] > 0) {
                        if (p == 0) {
                            int b = v.buff[p][q], ty = u.typ[p][q];
                            if (b & 1) scr += 3;
                            if (b & 2) scr += 15;
                            if (b & 4) scr += 60 / (1 + (ty == gui || ty == suo || ty == pen) * 0.3);
                            int da = v.att[p][q] - u.att[p][q];
                            scr += da * 1.5;
                        }
                        bool dd = v.hp[p][q] <= 0;
                        int dt = u.hp[p][q] - max(v.hp[p][q], 0);
                        if (p == 0) {
                            if (dd) scr -= 200;
                            scr -= pow(abs(dt), 1.02) * ((dt > 0) ? 1 : (-1));
                        }
                        else {
                            if (dd) scr += 150;
                            scr += pow(abs(dt), 1.01) * ((dt > 0) ? 1 : (-1));
                        }
                    }
                tsc[i] += scr;
            }
        }
        perr("oh. nice. %d  %d runs\n",moves.size(),ran);
        int mi = -1;
        for (int i = 0; i < (int)moves.size(); ++i)
            if (mi == -1 || tsc[i] > tsc[mi]) mi = i;
        perr("%d\n", mi); fflush(stderr);
        auto mov = moves[mi];
        int a = get<0>(mov), t = get<1>(mov), f = get<2>(mov), e = get<3>(mov);
        perr("%d %d,%d,%d,%d.\n", mi, a, t, f, e); fflush(stderr);


        if (t == 1) {
            int ty = app_id(a), tg = f;
            if (ty == pen || ty == zhang)
                u.buff[0][tg] |= 4;
            else if (ty == gui)
                u.buff[0][tg] |= 2;
            else if (ty == chou)
                u.buff[0][tg] |= 1;
        }
        return { a, (bool)t, f, e };
    }
};
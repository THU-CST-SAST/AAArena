#include <fstream>
#include <cstdio>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <memory>
#include <utility>
#include <algorithm>
#include <ctime>
#include <random>
#include <optional>
#include <future>
#include "jsoncpp/json/json.h"
#include "game.h"

static std::string convert_to_byte(std::string msg){
    int len = msg.length();
    char lenb[4];
    for (int i = 0; i < 4; i ++)
        lenb[3 - i] = (unsigned char) (len >> (8 * i));
    std::string res(lenb);
    res += msg;
    return res;
}

class AquaWarSDK {
  private:
    enum class RoundEndFlag {Normal, SLE, TLE}; // 每轮结束的原因

    Json::Reader reader;
    Json::Value root;  // xwb: 目前没使用过
    Json::Value state; // szh:每一回合的状态以及动态操作
    Json::StreamWriterBuilder w_builder;
    std::unique_ptr<Json::StreamWriter> writer;
    Json::Value replay;  // 记录回放文件
    std::ofstream fout;  //  replay
    FILE* f;  // 运行时输出信息对应文件
    Game game;
    std::ostringstream os;
    std::string Msg;
    std::ofstream info;
    std::ofstream debugger;
    //std::optional<std::pair<int, int>> last_action;
    bool acted; //玩家是否已经行动过
    //std::optional<std::tuple<int, int, bool>> assert_info;   //断言后向玩家发送断言情况
    std::optional<Json::Value> action_info;   //玩家的行动信息(以及是否合法)
    Json::Value last_assert;                  //上一次的断言信息
    std::vector<Json::Value> last_action;     //上一次双方的行动信息

  public:
    AquaWarSDK() {
        game = Game();
        //f = fopen("data.out", "w+");
        writer = std::unique_ptr<Json::StreamWriter>
                            (w_builder.newStreamWriter());
        //info.open("info.txt", std::ios::out);                    
        //debugger.open("debug_info.txt", std::ios::out);
        //debugger << "======= Debug Info =======" << std::endl;
        //debugger.close();
        last_action.resize(2);
    }

    void debug_msg(std::string str){
        return;
        debugger.open("debug_info.txt", std::ios::out | std::ios::app);
        debugger << str << std::endl;
        debugger.close();
    }

    void info_msg(std::string str){
        return;
        info << str;
    }

    void data_msg(std::string str){
        return;
        fprintf(f, str.c_str());
    }

    /*
        sendMsg内发送消息前需要先发送长度
        调用该函数发送
    */
    void sendLen(size_t s){
        int len = s;
        unsigned char lenb[4];
        lenb[0] = (unsigned char)(len);
        lenb[1] = (unsigned char)(len >> 8);
        lenb[2] = (unsigned char)(len >> 16);
        lenb[3] = (unsigned char)(len >> 24);
        for (int i = 0; i < 4; i++)
            printf("%c", lenb[3 - i]);  // 发给Judger
    }

    /*
        向Judger发送消息
        需要在前面加上数据长度作为数据头
    */
    void sendMsg(std::string s){
        //  在包前加入数据头
        sendLen(s.length());
        sendLen((size_t) - 1);
        std::cout << s;
        std::cout.flush();
    }

    //  监听直到收到Judger的消息
    std::string listen(){
        char lenr[4];
        std::string msg;
        while (true){
            scanf("%4c", lenr);
            int len = (unsigned int)((((unsigned int)lenr[3]) & 255) |
                                    ((((unsigned int)lenr[2]) & 255) << 8) |
                                    ((((unsigned int)lenr[1]) & 255) << 16) |
                                    ((((unsigned int)lenr[0]) & 255) << 24));
            for (int i = 0; i < len; i ++)
                msg += getchar();
            break;
        }
        return msg;
    }

    /*
        交互开始时接收judger发来的初始信息
        通信格式: json
        通信内容: 启动的AI状态
                 0:启动失败 1:启动成功 2:播放器
                 AI的数量
                 replay的路径
        通信样例:
                {
                    "player_list": [1, 2]
                    "player_num": 2
                    "replay": "usr/bin/replay.json"
                }
    */
    void receive_player_list(){
        std::string msg = listen();
        Json::Value root;
        if (!reader.parse(msg, root)) {
            //fprintf(f, "fail to parse root\n");

            data_msg("fail to parse root\n");
            fclose(f);
            exit(0);
        }
        if (root["player_num"].asInt() != 2){
            /*fprintf(f, "The game should only have two players\n");
            fprintf(f, "found %d.", root["player_num"].asInt());*/

            data_msg("The game should only have two players\n");
            data_msg("found " + root["player_num"].asString() + ".");
            fclose(f);
            exit(0);
        }
        auto& ls = root["player_list"];
        fout.open(root["replay"].asString());
        this->game = Game();
        int n = ls.size();
        for (int i = 0; i < n; i++){
            if (ls[i] == 2)  // 如果是播放器
                game.players[i].type = 2;
        }
    }

    /*
        接收到Judger的初始化信息后，向Judger发送初始化信息
        通信格式: json
        通信内容: 回合时间限制
                 最大消息长度
        通信样例:
                {
                    "state": 0
                    "time": 3,
                    "length": 1024
                },
    */
    void write_limit(){
        Json::Value root;
        root["state"] = 0;
        root["time"] = 3;
        root["length"] = 1024;
        writer->write(root, &os);
        Msg = os.str();
        os.str("");  // 清空串流
        sendMsg(Msg);
        Msg = "";
    }

    //  游戏开始，先进行初始化交互
    void start(){
        receive_player_list();
        write_limit();
    }

    /*
        发送消息
        通信格式: json
        通信内容: 回合数
                 需要发送消息的选手id列表
                 按照上面的列表依次需要发送的数据包
                 本回合需要行动的选手id列表(judger只会转发其的消息)
        通信样例:
                {
                    "state": 233
                    "player": [0, 1]  // 0 to n-1
                    "content":
                    "
                        {   // 传给玩家1的
                            "Action": "Null",
                            "State": "Assert",
                            "fishs": [
                                        [
                                            {
                                                "hp": 100,
                                                "atk": 50,
                                                "def": 20,
                                                "type": 0,
                                                "id": 0,
                                            },
                                            ...
                                        ],
                                        [...],
                                     ],
                            ...
                        }
                    ",
                    "
                        {   // 传给玩家2的
                            "Action": "Assert",
                            "State": "Assert",
                            "fishs": ...
                            ...
                        }

                    ",
                    "listen": 1
                }

    */
    void action_info_modifier(Json::Value& action_info,int curturn){
        if (action_info.size() == 0) return;
        debug_msg("modifier start");
        // debug_msg(std::to_string(action_info.size()));
        if (action_info.isMember("skill")){
            debug_msg("skill modify start");
            for (int i=0;i<(int)action_info["skill"]["targets"].size();i++){
                int player = stoi(action_info["skill"]["targets"][i]["player"].asString());
                action_info["skill"]["targets"][i]["isEnemy"] = (player == curturn ? false : true);
            }
            debug_msg("skill modify end");
        }
        if (action_info.isMember("hit")){
            debug_msg("hit modify start");
            for (int i=0;i<(int)action_info["hit"].size();i++){
                int player = stoi(action_info["hit"][i]["player"].asString());
                action_info["hit"][i]["isEnemy"] = (player == curturn ? false : true);
            }
            debug_msg("hit modify end");
        }
        if (action_info.isMember("passive")){
            debug_msg("passive modify start");
            for (int i = 0; i < (int)action_info["passive"].size(); i++)
            {
                int player = stoi(action_info["passive"][i]["player"].asString());
                action_info["passive"][i]["isEnemy"] = (player == curturn ? false : true);
            }
            debug_msg("passive modify end");
        }
    }

    void write_json(){
        debug_msg("write start");
        debug_msg("now state: " + std::to_string(game.gamestate));
        Json::Value root;
        root["state"] = game.state;
        if (game.gamestate == Game::READY){    //todo:这一阶段应删去
            std::mt19937_64 rand_eng(std::random_device{}());
            int a[20];
            // for(int i = 0; i < 18; ++i) a[i] = i + 1;
            a[0] = 13;
            a[1] = 14;
            a[2] = 15;
            a[3] = 16;
            a[4] = 17;
            a[5] = 18;
            for(int i = 6; i < 18; ++i) a[i] = i - 5;
            // std::shuffle(a, a + 18, rand_eng);
            // std::shuffle(a + 1, a + 18, rand_eng);
            for(int i = 0; i < 2; ++i){
                //info << "玩家 " << i << " 被禁选了类型编号为：";
                info_msg("玩家 "+std::to_string(i)+" 被禁选了类型编号为：");
                for(int j = 0; j < 6; ++j){
                    game.players[i].remove(a[j]);
                    //info << a[j] << ", "[j == 5];
                    info_msg(std::to_string(a[j]));
                    if (j!=5)
                        info_msg(", ");
                }
                //info << "的鱼。\n";
                info_msg("的鱼。\n");
            }
            for(int j = 0; j < 2; j ++){
                root["listen"].append(j);
                root["player"].append(j);
                Json::Value player;
                player["Action"] = "Ban";
                player["ID"] = j;
                for(int i = 0; i < 6; i ++){
                    player["BanFishes"].append(a[i]);
                }
                root["content"].append(player.toStyledString());
            }
        }
        else if (game.gamestate == Game::NOTICE){
            for(int j = 0; j < 2; j ++){
                root["listen"].append(j);
                root["player"].append(j);
                Json::Value player;
                player["Action"] = "Notice";
                for(int k = 0; k < 2; k ++){
                    auto fishs = game.players[k].get_fishs();
                    debug_msg("Player: " + std::to_string(k));
                    debug_msg(std::to_string(fishs.size()));
                    assert(fishs.size() == 12);
                    for(int i = 0; i < 12; i ++){
                        player[std::to_string(k)].append(fishs[i]->id);
                    }
                }
                root["content"].append(player.toStyledString());
            }
        }
        else if (game.gamestate == Game::PICK){
            for(int j = 0; j < 2; j ++){
                root["listen"].append(j);
                root["player"].append(j);
                Json::Value player;
                player["Action"] = "Pick";
                game.players[j].fight_fish.clear();  //  清空上场战斗的鱼，准备新一场战斗
                auto fishs = game.players[j].get_fishs();
                for(auto fish : fishs)
                    player["RemainFishs"].append(fish->id);
                root["content"].append(player.toStyledString());
            }
        }
        else if (game.gamestate == Game::ASSERT){
            debug_msg("write assert start");
            root["listen"].append(game.cur_turn);
            root["player"].append(game.cur_turn);
            Json::Value player;
            player["Action"] = "Assert";
            player["EnemyAssert"] = last_assert;
            if (last_action.size() == 2){
                debug_msg("write assert enemy assert info start");
                for (int j=0;j<2;j++){
                    action_info_modifier(last_action[j], game.cur_turn);
                }
                debug_msg("write assert enemy assert info end");
                player["EnemyAction"] = last_action[game.cur_turn ^ 1];
                player["MyAction"] = last_action[game.cur_turn];
                debug_msg("write assert action info end");
            }
            Json::Value game_info;
            auto enemy_fishs = game.players[game.cur_turn ^ 1].fight_fish.get_fishs();
            for (auto fish : enemy_fishs)
            {
                if (fish->is_expose)
                    game_info["EnemyFish"].append(fish->id);
                else
                    game_info["EnemyFish"].append(-1);
                if (fish->state == Fish::DEAD)
                    game_info["EnemyHP"].append(0);
                else
                    game_info["EnemyHP"].append(fish->hp);
                /*if (fish->is_expose)
                    game_info["EnemyATK"].append(fish->atk);
                else
                    game_info["EnemyATK"].append(-1);*/
            }
            auto my_fishs = game.players[game.cur_turn].fight_fish.get_fishs();
            for (auto fish : my_fishs)
            {
                if (fish->is_expose)
                    game_info["MyFish"].append(-fish->id);
                else
                    game_info["MyFish"].append(fish->id);
                if (fish->state == Fish::DEAD)
                    game_info["MyHP"].append(0);
                else
                    game_info["MyHP"].append(fish->hp);
                game_info["MyATK"].append(fish->atk);
            }
            player["GameInfo"] = game_info;
            root["content"].append(player.toStyledString());
            debug_msg("write assert end");
        }
        else if (game.gamestate == Game::ACTION){
            debug_msg("write action start");
            acted = false;
            if (!acted)                   //玩家尚未操作,第一次发送信息
            {
                debug_msg("write action acted");
                root["listen"].append(game.cur_turn);
                root["player"].append(game.cur_turn);
                Json::Value player;
                player["Action"] = "Action";
                player["AssertReply"] = last_assert;
                Json::Value game_info;
                auto enemy_fishs = game.players[game.cur_turn ^ 1].fight_fish.get_fishs();
                for (auto fish : enemy_fishs)
                {
                    if (fish->is_expose)
                        game_info["EnemyFish"].append(fish->id);
                    else
                        game_info["EnemyFish"].append(-1);
                    if (fish->state == Fish::DEAD)
                        game_info["EnemyHP"].append(0);
                    else
                        game_info["EnemyHP"].append(fish->hp);
                    /*if (fish->is_expose)
                        game_info["EnemyATK"].append(fish->atk);
                    else
                        game_info["EnemyATK"].append(-1);*/
                }
                auto my_fishs = game.players[game.cur_turn].fight_fish.get_fishs();
                for (auto fish : my_fishs)
                {
                    if (fish->is_expose)
                        game_info["MyFish"].append(-fish->id);
                    else
                        game_info["MyFish"].append(fish->id);
                    if (fish->state == Fish::DEAD)
                        game_info["MyHP"].append(0);
                    else
                        game_info["MyHP"].append(fish->hp);
                    game_info["MyATK"].append(fish->atk);
                }
                player["GameInfo"] = game_info;
                root["content"].append(player.toStyledString());
            }
            /*else                              //玩家已经操作,第二次发送信息
            {
                // debug_msg("Act!");
                root["listen"].append(game.cur_turn);
                root["player"].append(game.cur_turn);
                Json::Value player;
                player["Action"] = (*acted ? "Success" : "Fail");
                root["content"].append(player.toStyledString());
            }*/
        }
        writer->write(root, &os);
        Msg = os.str();
        os.str("");  // 清空串流
        //fprintf(f, "MSG @ 218: %s\n", Msg.c_str());
        data_msg("MSG @ 218: " + Msg + "\n");
        sendMsg(Msg);
        Msg = "";
    }

    /*
        接收judger的消息
        因为一个回合可能会有多个选手做出相应,judger每接收一个选手的操作就会把消息转发给逻辑
        逻辑会接收多次消息
        逻辑需要对选手发过来的数据包做格式限制以便于解析,还需处理异常
        注意 : 统一给judger转发字符串类型
        通信格式: json
        通信内容: 回合数
                 选手id
                 数据包
        通信样例:
                {
                    "player": i,
                    "content":
                    "{
                        {
                            "state": 233,
                            "Action": "Assert",
                            "fish_pos": 1,
                            "assert_id": 3,
                        }
                    }"
                }
        异常样例:
                {
                    "player": -1,
                    "content":
                    "{
                        {
                            "player": 4,
                            "error": 0,   // 0 -> collapse ; 1, timeout
                        }
                    }"
    */
   /*
        接收消息后，将玩家的操作(ban,assert,action)记录在state中
   */
    bool read_json(){
        debug_msg("read start");
        game.cnt = 0;
        state["operation"].resize(0);
        bool flag = true;
        int msg_cnt = 0;
        game.errorai = 3;
        while (true){
            msg_cnt ++;
            std::string msg = listen();
            /*auto result = std::async([this]() { return this->listen(); });
            auto status = result.wait_for(std::chrono::seconds(game.time_limit()));
            std::string msg = result.get();*/
            Json::Value root;
            if (!reader.parse(msg, root)){
                //fprintf(f, "fail to parse root\n");
                data_msg("fail to parse root\n");
                continue;
            }
            //fprintf(f, "msg from judger: %s\n", msg.c_str());
            data_msg("msg from judger: " + msg + "\n");

            /*
                TODO: 完成通信逻辑
            */
            Json::Value content;
            std::string s_content = root["content"].asString();
            if (!reader.parse(s_content, content)) continue;
            int player_id = stoi(root["player"].asString());
            if (player_id == -1){
                debug_msg("AI error");
                //return false;
                flag = false;
                if (msg_cnt == 2) break;
                else continue;
            }
            else game.errorai -= (1 << player_id);
            /*info << "[ 回合 " << game.state << " ]：";
            info << Game::state_info(static_cast<Game::State>(game.gamestate)) << '\n';
            info << "\t玩家 " << player_id << ' ';*/
            info_msg("[ 回合 "+std::to_string(game.state)+" ]：");
            info_msg(Game::state_info(static_cast<Game::State>(game.gamestate)));
            info_msg("\n\t玩家 "+std::to_string(player_id)+" ");
            Json::Value op;
            if (game.gamestate == Game::READY){
                if (content["Action"] != "OK") continue;
                game.cnt += (1 << player_id);
                if (game.cnt == 3)
                {
                    replay.append(state);
                    break;
                } 
            }
            else if (game.gamestate == Game::NOTICE){
                //info << "未进行操作。\n";
                info_msg("未进行操作。\n");
                if (content["Action"] != "OK") continue;
                game.cnt += (1 << player_id);
                if (game.cnt == 3) 
                {
                    replay.append(state);
                    break;
                }
            }
            else if (game.gamestate == Game::PICK){
                if (content["Action"] != "Pick"){
                    //info << "未进行操作。\n";
                    info_msg("未进行操作。\n");
                    continue;
                }
                if (content["ChooseFishs"].size() != 4){
                    //info << "未进行操作。\n";
                    info_msg("未进行操作。\n");
                    continue;
                }
                //info << "挑选类型编号为：";
                info_msg("挑选类型编号为：");
                for(int i = 0; i < 4; i ++){
                    int id = stoi(content["ChooseFishs"][i].asString());
                    if (id == 12) game.imiid[player_id] = stoi(content["ImitateFish"].asString());
                    //info << id << ", "[i == 3];
                    info_msg(std::to_string(id));
                    if (i!=3)
                        info_msg(", ");
                    game.players[player_id].to_war(id);
                }
                //info << "的鱼出战。\n";
                info_msg("的鱼出战。\n");
                game.players[player_id].fight_fish.to_fight();  //  改变上场鱼的状态
                game.cnt += (1 << player_id);
                if (game.cnt == 3) 
                {
                    for(int id = 0; id <= 1; id++)
                        for(auto fish : game.players[id].fight_fish.get_fishs()){
                            fish->set_fishset(&(game.players[id].fight_fish), &(game.players[id^1].fight_fish));
                            if (fish->id == 12){
                                auto imifish = dynamic_cast<Imitator*>(fish);
                                imifish->imitate(game.imiid[id]);
                            }
                        }
                    op["Action"] = "Pick";
                    Json::Value fish;
                    fish.append(game.players[0].fight_fish.to_json());
                    fish.append(game.players[1].fight_fish.to_json());
                    op["Fish"] = fish;
                    state["operation"].append(op);
                    replay.append(state);
                    break;
                }
            }
            else if (game.gamestate == Game::ASSERT){
                debug_msg("read assert start");
                if (content["Action"] == "Null"){
                    //info << "未进行操作。\n";
                    info_msg("未进行操作。\n");
                    op["Action"] = "Null";
                    op["ID"] = player_id;
                    state["operation"].append(op);
                    replay.append(state);
                    last_assert["AssertPos"] = Json::nullValue;
                    last_assert["AssertContent"] = Json::nullValue;
                    last_assert["AssertResult"] = Json::nullValue;
                    break;
                }
                if (content["Action"] == "Assert"){
                    auto fishs = game.players[player_id ^ 1].fight_fish.get_fishs();
                    int pos = stoi(content["Pos"].asString());
                    int id = stoi(content["ID"].asString());
                    //info << "断言对方编号为 " << pos << " 的鱼类型是 " << id <<"，断言";
                    info_msg("断言对方编号为 "+std::to_string(pos)+" 的鱼类型是 "+std::to_string(id)+"，断言");
                    op["Action"] = "Assert";
                    op["ID"] = player_id;
                    op["Pos"] = pos;
                    op["id"] = id;
                    if (fishs[pos]->id == id){  //  断言成功
                        //info << "正确。\n";
                        info_msg("正确。\n");
                        fishs[pos]->is_expose = true;
                        // fishs[pos]->atk_debuff(0.8);
                        game.players[player_id ^ 1].fight_fish.hp_debuff(50);
                        last_assert["AssertPos"] = pos;
                        last_assert["AssertContent"] = id;
                        last_assert["AssertResult"] = true;
                    }
                    else{  //  断言失败
                        //info << "失败。\n";
                        info_msg("失败。\n");
                        game.players[player_id].fight_fish.hp_debuff(50);
                        last_assert["AssertPos"] = pos;
                        last_assert["AssertContent"] = id;
                        last_assert["AssertResult"] = false;
                    }
                    state["operation"].append(op);
                    replay.append(state);
                    break;
                }
                debug_msg("read assert end");
            }
            else if (game.gamestate == Game::ACTION){
                if (content["Action"] != "Action"){
                    //info << "未进行操作。\n";
                    info_msg("未进行操作。\n");
                    continue;
                }
                /*if (acted && *acted){
                    acted.reset();
                    break;
                }*/
                debug_msg("Action Start! (Player "+std::to_string(player_id)+")");
                auto my_fishs = game.players[player_id].fight_fish.get_fishs();
                auto enemy_fishs = game.players[player_id ^ 1].fight_fish.get_fishs();
                int type = content["Type"].asBool();
                int my_pos = content["MyPos"].asInt();
                //last_action = {type, my_pos};
                op["Action"] = "Action";
                op["ID"] = player_id;
                op["Type"] = type;
                op["MyPos"] = my_pos;
                debug_msg("Action Middle! (type = "+std::to_string(type)+")");
                if(type == 0){
                    int enemy_pos = content["EnemyPos"].asInt();
                    op["EnemyPos"] = enemy_pos;
                    debug_msg(std::to_string(my_fishs[my_pos]->id) + " normal attack " + std::to_string(enemy_fishs[enemy_pos]->id));
                    debug_msg("======= Normal Attack Before =======");
                    action_info = my_fishs[my_pos]->attack(enemy_fishs[enemy_pos]);
                    //my_fishs[my_pos]->attack(enemy_fishs[enemy_pos]);
                    debug_msg("======= Normal Attack After =======");
                    if (action_info){
                        debug_msg("action is valid");
                        acted = true;           //平A合法
                        (*action_info)["ActionFish"] = my_pos;
                        last_action[player_id] = *action_info;
                    }
                    else
                        acted = false;          //平A不合法
                    /*info << "编号为 " << my_pos << " 的鱼对敌方编号为 " << enemy_pos << " 的鱼发动攻击，";
                    info << "造成 " << my_fishs[my_pos]->atk << " 点伤害";*/
                    //if (*acted)
                    info_msg("编号为 "+std::to_string(my_pos)+" 的鱼对敌方编号为 "+std::to_string(enemy_pos)+" 的鱼发动攻击，"+"造成 "+std::to_string(my_fishs[my_pos]->atk)+" 点伤害");
                }
                else{
                    debug_msg("======= Skill Before =======");
                    op["MyList"] = content["MyList"];
                    op["EnemyList"] = content["EnemyList"];
                    auto to_vector = [](const Json::Value& json,
                                        const std::vector<Fish*>& fishs)
                        -> std::vector<Fish*> {
                        std::vector<Fish*> ret(json.size());
                        for (int i = 0; i < (int)json.size(); ++i)
                            ret[i] = fishs[json[i].asInt()];
                        return ret;
                    };
                    auto my_list = to_vector(content["MyList"], my_fishs);
                    auto enemy_list = to_vector(content["EnemyList"], enemy_fishs);

                    debug_msg(std::to_string(my_fishs[my_pos]->id) + " skill");
                    debug_msg("My_list:");
                    for(auto i:my_list)
                        debug_msg(std::to_string(i->id));
                    debug_msg("Enemy_list:");
                    for(auto i:enemy_list)
                        debug_msg(std::to_string(i->id));

                    //acted = my_fishs[my_pos]->skill(std::move(my_list), std::move(enemy_list));
                    debug_msg("action info before");
                    debug_msg((my_fishs[my_pos]->id == Fish::sunfish)?"fanbao!":"???");
                    action_info = my_fishs[my_pos]->skill(std::move(my_list), std::move(enemy_list));
                    debug_msg("action info after");
                    if (action_info){
                        debug_msg("action info valid");
                        acted = true;      //技能合法
                        (*action_info)["ActionFish"] = my_pos;
                        last_action[player_id] = *action_info;
                    }  
                    else
                        acted = false;     //技能不合法
                    //if (*acted)
                    //{
                        //info << "编号为 " << my_pos << " 的鱼发动了主动技能";
                    info_msg("编号为 "+std::to_string(my_pos)+" 的鱼发动了主动技能");
                    //}
                    debug_msg("acted = " + std::to_string(acted ? 1 : 0));
                    debug_msg("======= Skill After =======");
                }
                if (!acted){
                    game.errorai = (1 << player_id);
                    flag = false;
                }
                debug_msg("Action End!\n");

                auto fishs_0 = game.players[0].fight_fish.get_fishs();
                auto fishs_1 = game.players[1].fight_fish.get_fishs();
                debug_msg("Status:");
                debug_msg("Player 0:");
                for(auto i:fishs_0) {
                    std::string s="Fish ";
                    s = s + std::to_string(i->id);
                    s = s + ": hp " + std::to_string(i->hp) + "/" + std::to_string(i->max_hp) + ", ";
                    s = s + "atk " + std::to_string(i->atk) + ", ";
                    s = s + "buff " + std::to_string(i->buff);
                    debug_msg(s);
                }
                debug_msg("Player 1:");
                for(auto i:fishs_1) {
                    std::string s="Fish ";
                    s = s + std::to_string(i->id);
                    s = s + ": hp " + std::to_string(i->hp) + "/" + std::to_string(i->max_hp) + ", ";
                    s = s + "atk " + std::to_string(i->atk) + ", ";
                    s = s + "buff " + std::to_string(i->buff);
                    debug_msg(s);
                }

                // // op["IsKilled"] = false;
                // enemy_fishs[enemypos]->hp -= my_fishs[mypos]->atk;
                // if (enemy_fishs[enemypos]->hp <= 0){
                //     info << "，敌方死亡";
                //     enemy_fishs[enemypos]->hp = 0;
                //     enemy_fishs[enemypos]->state = Fish::DEAD;
                //     op["IsKilled"] = true;
                // }
                // info << "。\n";
                // info << "\t敌方状态：\n";
                // info << "\t\t编号\t HP \n";
                // for(auto fish : enemy_fishs){
                //     info << "\t\t" << std::setw(4) << (fish->is_expose ? fish->id : -1);
                //     info << '\t' << std::setw(4) << fish->hp <<'\n';
                // }
                /*if (*acted){
                    (*action_info)["ActionFish"] = my_pos;
                    if (action_info->isMember("skill")){         //使用主动技能
                        if ((*action_info)["skill"]["type"]=="aoe" || (*action_info)["skill"]["type"]=="critical"){
                            (*action_info)["skill"]["targetsplayer"] = player_id ^ 1;
                        }
                        else if((*action_info)["skill"]["type"]=="infight"){
                            (*action_info)["skill"]["targetsplayer"] = player_id;
                        }
                    }
                    state["operation"].append(op);
                    replay.append(state);
                }*/
                if (acted){
                    auto info = *action_info;
                    action_info_modifier(info, state["cur_turn"].asInt());
                    op["ActionInfo"] = info;
                    state["operation"].append(op);
                    replay.append(state);
                }
                break;
            }
        }
        debug_msg("read end");
        if (!flag){
            if (game.errorai == 3) game.cur_turn = -1;
            else if (game.errorai == 2) game.cur_turn = 1;
            else game.cur_turn = 0;
        }
        return flag; // success
    }

    /*
        保存当前场面，即 game.to_json()     //(szh:以及该回合玩家进行的操作)
        文件格式: json
        文件样例:
                {
                    "winner": winner,
                    "players": [
                        {
                            "id": id,
                            "type": type,
                            "my_fish": [ // my_fish
                                {
                                    "hp": hp,
                                    "atk": atk,
                                    "def": def,
                                    "type": type,
                                    "id": id,
                                    "state": state,
                                    "is_expose": is_expose
                                }
                                fish2,
                                fish3,
                                ...
                            ],
                            "fight_fish": fight_fish
                        },
                        player2,
                        player3,
                        ...
                    ],
                    "state": state,
                    "gamestate": gamestate,
                    "cur_turn": cur_turn,
                    "over": over,
                    "cnt": cnt,
                    "score": score,
                    "rounds": rounds
                    "operation":[
                        {
                            "ID":player_id,
                            ...
                        },
                        {
                            "ID":player_id,
                            ...
                        }
                    ]
                },
    */
    void save_json(){
        state = game.to_json();
        // replay.append(state); state还要记录具体操作，应该在read_json中把state加入replay
    }

    /*
    游戏结束，向judger传输结束信息，并完成replay保存
    1. 传给judger結束信息
        通信格式: json
        通信内容: 游戏结束标志符
                 选手id列表
                 按照上面的列表依次给出选手的天梯分数增
        通信样例:
                {
                    "state": -1,
                    "end_info":
                    {
                        "0": 100,
                        "1": 0,
                    }
                }
    2. 录播文件保存結局
            {
                'winner': '0',
                '0': 100,
                '1': 0,
            }
    */
    void end(){
        Json::Value end_replay;
        Json::Value root;
        root["state"] = -1;
        Json::Value end_info;
        /*
            TODO: 完成结束信息
        */
        //info << "游戏结束，玩家 " << (game.score < 0) << " 胜利！\n";
        info_msg("游戏结束，玩家 "+std::to_string((game.score < 0))+" 胜利！\n");
        if (game.score > 0){
            end_info[std::to_string(0)] = 100;
            end_info[std::to_string(1)] = 0;
        }
        else if (game.score < 0){
            end_info[std::to_string(0)] = 0;
            end_info[std::to_string(1)] = 100;
        }
        else{
            end_info[std::to_string(0)] = 0;
            end_info[std::to_string(1)] = 0;
        }
        /*
            TODO: 完成结局录像
        */
        replay.append(end_replay);
        fout << replay.toStyledString() << "\n\n\n";
        fout.close();
        root["end_info"] = end_info.toStyledString();
        writer->write(root, &os);
        Msg = os.str();
        os.str("");  // 清空串流
        sendMsg(Msg);
        Msg = "";
    }

    //  游戏回合制运行
    void run(){
        debug_msg("logic run");
        srand(time(0));
        while (!game.over){
            debug_msg("save start");
            save_json();  // 保存回合至录播文件
            debug_msg("save end");
            //do{
            write_json();  // 发送消息给judger
            if(!read_json()){ // 接收judger的讯息
                time_limit_exceeded();
                continue;
            }
            //}while(acted);
            /*
                TODO: 回合制逻辑
            */
           game.state ++;
           if(game.state - game.last_round_state > Game::STATE_LIMIT){
               state_limit_exceeded();
               continue;
           }
           if (game.gamestate == Game::READY) game.gamestate = Game::NOTICE;
           else if (game.gamestate == Game::NOTICE) game.gamestate = Game::PICK;
           else if (game.gamestate == Game::PICK){
               if (game.last_winner == -1) game.first_mover = rand() % 2;
               else game.first_mover = game.last_winner ^ 1;
               game.cur_turn = game.first_mover;
               game.gamestate = Game::ASSERT;
           }
           // else if (game.gamestate == Game::ASSERT) game.gamestate = Game::ACTION;
           else if (game.gamestate == Game::ASSERT){
               bool flag = false;
               int winner;
               for(int i = 0; i < 2; i ++){
                   if (game.players[i].fight_fish.is_all_dead()){
                       /*info << "\n\n第 " << game.rounds << " 轮结束，玩家 ";
                       info << (i^1) << " 胜利！\n";
                       info << "=========================\n\n";*/
                       info_msg("\n\n第 "+std::to_string(game.rounds)+" 轮结束，玩家 ");
                       info_msg(std::to_string((i^1))+" 胜利！\n");
                       info_msg("=========================\n\n");
                       winner = i ^ 1;
                       /*if (i == 0) game.score --;
                       else game.score ++;
                       if (game.rounds == 3) game.over = true;*/
                       flag = true;
                       break;
                   }
               }
               if (flag){
                   /*game.players[0].fight_fish.to_dead();
                   game.players[1].fight_fish.to_dead();
                   game.gamestate = Game::PICK;
                   Json::Value root;
                   root["state"] = game.state;
                   for (int j=0;j<2;j++){
                       root["listen"].append(j);
                       root["player"].append(j);
                       Json::Value player;
                       player["Action"] = "Finish";
                       player["Result"] = (winner == j ? "Win" : "Lose");
                       if (j == game.cur_turn){
                           player["AssertReply"] = last_assert;
                       }
                       else{
                           player["EnemyAssert"] = last_assert;
                           player["EnemyAction"] = Json::nullValue;
                           action_info_modifier(last_action[j],j);
                           player["MyAction"] = last_action[j];
                       }
                       root["content"].append(player.toStyledString());
                   }
                   writer->write(root, &os);
                   Msg = os.str();
                   os.str(""); // 清空串流
                   //fprintf(f, "MSG @ 218: %s\n", Msg.c_str());
                   data_msg("MSG @ 218: " + Msg + "\n");
                   sendMsg(Msg);
                   Msg = "";*/
                   round_end(winner, RoundEndFlag::Normal);
               }
               else{
                   game.gamestate = Game::ACTION;
               }
           }
           else if (game.gamestate == Game::ACTION){
               bool flag = false;
               int winner;
               for(int i = 0; i < 2; i ++){
                   if (game.players[i].fight_fish.is_all_dead()){
                       /*info << "\n\n第 " << game.rounds << " 轮结束，玩家 ";
                       info << (i^1) << " 胜利！\n";
                       info << "=========================\n\n";*/
                       info_msg("\n\n第 " + std::to_string(game.rounds) + " 轮结束，玩家 ");
                       info_msg(std::to_string((i ^ 1)) + " 胜利！\n");
                       info_msg("=========================\n\n");
                       winner = i ^ 1;
                       flag = true;
                       break;
                   }
               }
               if (flag){
                   round_end(winner, RoundEndFlag::Normal);
               }
               else{
                   game.gamestate = Game::ASSERT;
                   game.cur_turn ^= 1;
               }
           }
        }
        end();  // 返回局面结束信息
    }

    // 处理 AI 回复超时的情形
    void time_limit_exceeded() {
        if(game.cur_turn == 0) game.score = -3;
        else if (game.cur_turn == 1) game.score = 3;
        else game.score = 0;
        end();
        // round_end(game.cur_turn ^ 1, RoundEndFlag::TLE);
    }

    // 处理当前轮回合数超过限制的情形
    void state_limit_exceeded() {
        auto winner = [this]() -> int {
            auto compare = [this](int (FishSet::*pf)()const) ->int {
                int x0 = (game.players[0].fight_fish.*pf)();
                int x1 = (game.players[1].fight_fish.*pf)();
                if(x0 == x1) return -1;
                else return x1 > x0;
            };
            int ret;
            ret = compare(&FishSet::living_fish_count); // 活鱼多者胜
            if(ret != -1) return ret;
            ret = compare(&FishSet::hp_sum); // 总血量大者胜
            if(ret != -1) return ret;
            ret = compare(&FishSet::hp_max); // 最大血量大者胜
            if(ret != -1) return ret;
            return game.first_mover ^ 1; // 后手胜
        };
        round_end(winner(), RoundEndFlag::SLE);
    }

    // 当前轮结束
    void round_end(int winner, RoundEndFlag flag) {
        game.last_round_state = game.state;
        game.last_winner = winner;
        if (winner == 0) game.score ++;
        else game.score --;
        game.rounds ++;
        if (game.rounds == 3) game.over = true;
        game.players[0].fight_fish.to_dead();
        game.players[1].fight_fish.to_dead();
        game.gamestate = Game::PICK;
        Json::Value root;
        root["state"] = game.state;
        //root["isStateLimiteExceed"] = (flag == RoundEndFlag::SLE);
        for (int j=0;j<2;j++){
            root["listen"].append(j);
            root["player"].append(j);
            Json::Value player;
            player["Action"] = "Finish";
            player["Result"] = (winner==j ? "Win" : "Lose");
            player["isStateLimitExceed"] = (flag == RoundEndFlag::SLE);
            if (j == game.cur_turn){
                action_info_modifier(last_action[j],j);
                player["MyAction"] = last_action[j];
            }  
            else{
                player["EnemyAssert"] = last_assert;
                for (int k=0;k<2;k++){
                    action_info_modifier(last_action[k],j);
                }
                player["EnemyAction"] = last_action[j ^ 1];
                player["MyAction"] = last_action[j];
            } 
            root["content"].append(player.toStyledString());
        }
        writer->write(root, &os);
        Msg = os.str();
        os.str(""); // 清空串流
        //fprintf(f, "MSG @ 218: %s\n", Msg.c_str());
        data_msg("MSG @ 218: " + Msg + "\n");
        sendMsg(Msg);
        Msg = "";
        state = game.to_json();
        replay.append(state);
    }
};
#include "Action.hpp"
#include <algorithm>
struct FISH_ASSERT {
	int passive;
	int active;
	bool asserted;
	bool really_asserted;
	int SkillUsed;
};
static FISH_ASSERT fishes_assert[4];
static bool first = true;
static bool attack_first = true;
static int current_round = 1;


std::vector<int> AI::Pick(Game game)
{
	std::vector<int> pick_fish;
	pick_fish.clear();
	std::cerr << "CURRENT ROUND :" << game.round << std::endl;
	if(game.round == 1)
	{
		pick_fish.push_back(19);
		pick_fish.push_back(2); 
		pick_fish.push_back(11);
		pick_fish.push_back(5); 
		
	}

	if(game.round == 2)
	{
		pick_fish.push_back(7);
		pick_fish.push_back(4);
		pick_fish.push_back(1);
		pick_fish.push_back(10);
	}

	if(game.round == 3)
	{
		pick_fish.push_back(3);
		pick_fish.push_back(6);
		pick_fish.push_back(8);
		pick_fish.push_back(9);
	}
	using seed_t = std::default_random_engine::result_type;
	std::default_random_engine eng{static_cast<seed_t>(time(0))};
	std::shuffle(pick_fish.begin(), pick_fish.end(), eng);
	return pick_fish;
}

std::pair<int, int> AI::Assert(Game game)
{    
	int i, j;
	if (game.round != current_round)
	{
		first = true;
		attack_first = true;
		current_round = game.round;
		std::cerr << "--------NEW ROUND--------"<< std::endl;
	}
    if (game.my_assert.assertResult && first == false) //记录成功断言的信息
    {
    	fishes_assert[game.my_assert.assertPos].really_asserted = true;
    	std::cerr << "ASSERT SUCCEED !"<< std::endl;
    }
    if (game.enemy_assert.assertResult && first == false) //记录成功断言的信息
    {
    	std::cerr << "!!ENEMY ASSERT SUCCEED :("<< std::endl
    	<< game.enemy_assert.assertPos << "->" << game.enemy_assert.assertContent << std::endl;
    }
    if (first) //第一回合特判
    {
    	first = false;
    	for (int i = 0; i <= 3; i++)
    	{
    		fishes_assert[i].passive = 0;
    		fishes_assert[i].active = 0;
    		fishes_assert[i].asserted = false;
    		fishes_assert[i].SkillUsed = 0;
    	}
    	if (game.first_mover == false)
    	{
    		if (game.enemy_action.is_skill)
    		{
    			fishes_assert[game.enemy_action.action_fish].SkillUsed ++;
    			switch(game.enemy_action.type)
    			{
    				case aoe:
    				fishes_assert[game.enemy_action.action_fish].active = 1;
    				break;
    				case infight:
    				fishes_assert[game.enemy_action.action_fish].active = 2;
    				break;
    				case crit:
    				fishes_assert[game.enemy_action.action_fish].active = 3;
    				break;
    				case subtle:
    				if (fishes_assert[game.enemy_action.action_fish].active == 3)
    					break;
    				fishes_assert[game.enemy_action.action_fish].active = 4;
    				break;
    			}
    		}
    	}
    	return std::make_pair(-1, -1);
    }

    /*std::cerr << "before:"<< std::endl;
    for (j = 0; j <= 3; j++)
    {
        std::cerr << fishes_assert[j].passive << "/"
        << fishes_assert[j].active << std::endl;
    }*/

    //std::cerr << "enemy turn passives:" << game.enemy_action.num_friend_passives << std::endl;
    for (i = 0; i < game.enemy_action.num_friend_passives; i++)
    {
    	switch(game.enemy_action.friend_types[i])
    	{
    		case counter:
    		if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 3
    			|| fishes_assert[game.enemy_action.friend_passives_id[i]].active == 4)
    			break;
    		fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 1;
    		break;
    		case deflect:
    		if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 3
    			|| fishes_assert[game.enemy_action.friend_passives_id[i]].active == 4)
    			break;
    		fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 2;
    		break;
    		case reduce:
    		if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 1
    			|| fishes_assert[game.enemy_action.friend_passives_id[i]].active == 2)
    			break;
    		fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 3;
    		break;
    		case heal:
    		if (fishes_assert[game.enemy_action.friend_passives_id[i]].active == 1
    			|| fishes_assert[game.enemy_action.friend_passives_id[i]].active == 2)
    			break;
    		fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 4;
    		break;
    		case explode:
    		fishes_assert[game.enemy_action.friend_passives_id[i]].passive = 6;
    		break;
    	}
    }
    //std::cerr << "enemy turn done"<< std::endl;

    //std::cerr << "my turn passives:" << game.my_action.num_enemy_passives << std::endl;
    for (i = 0; i < game.my_action.num_enemy_passives; i++)
    {
    	switch(game.my_action.enemy_types[i])
    	{
    		case counter:
    		if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 3
    			|| fishes_assert[game.my_action.enemy_passives_id[i]].active == 4)
    			break;
    		fishes_assert[game.my_action.enemy_passives_id[i]].passive = 1;
    		break;

    		case deflect:
    		if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 3
    			|| fishes_assert[game.my_action.enemy_passives_id[i]].active == 4)
    			break;
    		fishes_assert[game.my_action.enemy_passives_id[i]].passive = 2;
    		break;

    		case reduce:
    		if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 1
    			|| fishes_assert[game.my_action.enemy_passives_id[i]].active == 2)
    			break;
    		fishes_assert[game.my_action.enemy_passives_id[i]].passive = 3;
    		break;

    		case heal:
    		if (fishes_assert[game.my_action.enemy_passives_id[i]].active == 1
    			|| fishes_assert[game.my_action.enemy_passives_id[i]].active == 2)
    			break;
    		fishes_assert[game.my_action.enemy_passives_id[i]].passive = 4;
    		break;

    		case explode:
    		fishes_assert[game.my_action.enemy_passives_id[i]].passive = 6;
    		break;
    	}
    }
    //std::cerr << "my turn done"<< std::endl;

    if (game.enemy_action.is_skill)
    {
    	fishes_assert[game.enemy_action.action_fish].SkillUsed ++;
    	switch(game.enemy_action.type)
    	{
    		case aoe:
    		fishes_assert[game.enemy_action.action_fish].active = 1;
    		break;
    		case infight:
    		fishes_assert[game.enemy_action.action_fish].active = 2;
    		break;
    		case crit:
    		fishes_assert[game.enemy_action.action_fish].active = 3;
    		break;
    		case subtle:
    		if (fishes_assert[game.enemy_action.action_fish].active == 3
    			|| fishes_assert[game.enemy_action.action_fish].active == 1)
    			break;
    		fishes_assert[game.enemy_action.action_fish].active = 4;
    		break;
    	}
    }

    std::cerr << "analyze done"<< std::endl;
    /*for (int j = 0; j <= 3; j++)
    {
        std::cerr << fishes_assert[j].passive << "/"
        << fishes_assert[j].active << std::endl;
        // 被动/主动
    }*/

    for (int i = 0; i <= 3; i++)
    {
    	if (get_enemy_hp(i) > 0 && fishes_assert[i].really_asserted == false)
    	{
    		if (fishes_assert[i].asserted == true)
    		{
    			std::cerr << "found_imitator 12, OHHHHHHHHH!"<< std::endl;
    			fishes_assert[i].really_asserted = true;
    			return std::make_pair(i, 12);
    		}

    		if (fishes_assert[i].passive == 1 && fishes_assert[i].active == 1
    			&& game.enemy_action.action_fish == i
    			&& game.enemy_action.is_skill
    			&& game.enemy_action.type == aoe
    			&& fishes_assert[i].SkillUsed > 3)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_1, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 1);
    		}

    		if ((fishes_assert[i].passive == 1 && fishes_assert[i].active == 2)
    			|| 
    			(fishes_assert[i].active == 2
    				&& game.enemy_action.action_fish == i
    				&& game.enemy_action.is_skill == false
    				&& game.enemy_action.enemy_expected_injury[0] > 100))
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_2, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 2);
    		}

    		if (fishes_assert[i].passive == 2 && fishes_assert[i].active == 1)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_3, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 3);
    		}

    		if ((fishes_assert[i].passive == 2 && fishes_assert[i].active == 2)
    			|| 
    			(fishes_assert[i].active == 2
    				&& game.enemy_action.action_fish == i
    				&& game.enemy_action.is_skill == false
    				&& game.enemy_action.enemy_expected_injury[0] > 100))
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_4, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 4);
    		}

    		if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 3
    			&& game.enemy_action.action_fish == i
    			&& game.enemy_action.is_skill
    			&& game.enemy_action.type == crit
    			&& fishes_assert[i].SkillUsed > 3)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_5, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 5);
    		}

    		if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 4)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_6, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 6);
    		}

    		if (fishes_assert[i].passive == 3 && fishes_assert[i].active == 3
    			&& game.enemy_action.action_fish == i
    			&& game.enemy_action.is_skill
    			&& game.enemy_action.type == subtle)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_7, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 7);
    		}

    		if (fishes_assert[i].passive == 4 && fishes_assert[i].active == 4)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_8, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 8);
    		}

    		if (fishes_assert[i].passive == 4 && fishes_assert[i].active == 3)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_9, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 9);
    		}

    		if ((game.enemy_action.action_fish == i
    			&& game.enemy_action.is_skill == false
    			&& game.enemy_action.enemy_expected_injury[0] == 57) ||
    			(game.enemy_action.action_fish == i
    				&& game.enemy_action.is_skill
    				&& game.enemy_action.type == crit
    				&& game.enemy_action.enemy_expected_injury[0] == 140) ||
    			(game.enemy_action.action_fish == i
    				&& game.enemy_action.is_skill
    				&& game.enemy_action.type == crit
    				&& game.enemy_action.enemy_expected_injury[0] == 161))
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_10, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 10);
    		}

    		if (fishes_assert[i].active == 1
    			&& game.enemy_action.action_fish == i
    			&& game.enemy_action.is_skill
    			&& game.enemy_action.type == subtle)
    		{
    			fishes_assert[i].asserted = true;
    			std::cerr << "found_fish_11, OHHHHHHHHH!"<< std::endl;
    			return std::make_pair(i, 11);
    		}

            //std::cerr << i << "assert_not_found" << std::endl;
    	}
    }

    return std::make_pair(-1, -1);
}

Action AI::Act(Game game)
{
	Action action(game);
	if (attack_first) //第一回合特判
	{
		attack_first = false;
		switch (game.round)
		{
			case 1:
			for (int i = 0; i <= 3; i ++)
			{
				if (get_my_id(i) == 11)
				{
					action.set_action_fish(i);
					action.set_action_type(1);
					for (int j = 0; j <= 3; j++)
					{
						if (get_my_id(j) == 2)
							action.set_friend_target(j);
					}
					action.set_enemy_target(-2);
					return action;
				}
			}
			case 2:
			case 3:
			for (int i = 0; i <= 3; i ++)
			{
				if (get_my_id(i) == 1 || get_my_id(i) == 3)
				{
					action.set_action_fish(i);
					action.set_action_type(1);
					action.set_enemy_target(-2);
					return action;
				}
			}
		}
	}

	/*int pos1;
	for (pos1 = 0; pos1 <= 3; pos1 ++) //找杀手:pos1
	{
		int tmp_pos;
		int id1 = get_my_id(pos1);
		if ((id1 == 2 || id1 == 4) && get_my_hp(pos1) > 0)
		{
			bool found = false;
			for (int pos2 = 0; pos2 <= 3; pos2 ++) //找祭品:pos2
			{
				int id2 = get_my_id(pos2);
				if (id2 == 12)
					id2 = get_avatar_id();
				if (id2 == 7 && get_my_hp(pos2) > 0)
				{
					found = true;
					tmp_pos = pos2;
					break;
				}
			}
			if (get_my_atk(pos1) < 450 && get_my_hp(pos1) > 200)
			{
				action.set_action_fish(pos1);
				action.set_action_type(1);
				if(found)
					action.set_friend_target(tmp_pos);
				else
					action.set_friend_target((get_my_living_ally(pos1))[0]);
				return action;
			}
			else
			{
				action.set_action_fish(pos1);
				action.set_action_type(0);

				//优先攻击对面高单体伤害的鱼
				if (game.enemy_action.num_enemy_targets == 1 && 
					game.enemy_action.enemy_expected_injury[0] >= 100 && 
					get_enemy_hp(game.enemy_action.action_fish) > 0)
				{
					action.set_enemy_target(game.enemy_action.action_fish);
					return action;
				}

				if(game.my_action.is_skill == false && 
					game.my_action.num_enemy_injury == 1 &&
					game.my_action.enemy_injury[0] == 0) //其次考虑对面的海龟&闪避鱼
				{
					std::cerr << "海龟&闪避鱼判断开始"<< std::endl;
					int k;
					for (k = 0; k < 4; k++)
					{
						if (get_enemy_hp(k) > 0 && k != game.my_action.enemy_targets[0])
							break;
					}
					switch (game.my_action.enemy_targets[0])
					{
						case 0:
						{
							std::cerr << "case 0"<< std::endl;
							k = 1;
							while (get_enemy_hp(k) == 0)
							{
								k++;
								if (k == 4)
									k = 1;
							}
							break;
						}
						case 1:
						{
							std::cerr << "case 1"<< std::endl;
							k = 2;
							while (get_enemy_hp(k) == 0)
							{
								k++;
								if (k == 4)
									k = 2;
							}
							break;
						}
						case 2:
						{
							std::cerr << "case 2"<< std::endl;
							k = 3;
							while (get_enemy_hp(k) == 0)
							{
								k++;
								if (k == 4)
									k = 0;
							}
							break;
						}
						case 3:
						{
							std::cerr << "case 3"<< std::endl;
							k = 0;
							while (get_enemy_hp(k) == 0)
								k++;
							break;
						}
					}
					action.set_enemy_target(k);
					std::cerr << "DONE!"<< std::endl;
					return action;
				}
				//action.set_enemy_target(get_lowest_health_enemy());
				action.set_enemy_target((get_enemy_living_fishes())[0]);
				return action;
			}
		}
	}*/




	int pos = game.my_action.action_fish;
	do
	{
		pos++;
		if (pos == 4)
			pos = 0;
	} while (game.my_fish[pos].hp <= 0);

	action.set_action_fish(pos);

	bool skilled = false;
	int id = get_my_id(pos);
	if (id == 12)
		id = get_avatar_id();
	/*
	if (random(0, 1) < 0.3)
	{
		action.set_action_type(0);
		action.set_enemy_target((get_enemy_living_fishes())[0]);
		return action;
	}
	*/
	switch (id)
	{
		case spray:
		case eel:
		{
			skilled = true;
			action.set_action_type(1);
			action.set_enemy_target(-2);
			break;
		}
		
		case flame:
		case sunfish:
		{
			if (random(0, 1) < 0.3)
			{
				auto living_ally = get_my_living_ally(pos);
				if (!living_ally.empty())
				{
					skilled = true;
					action.set_action_type(1);
					action.set_friend_target(living_ally[0]);
				}
				break;
			}
			break;
		}
		
		case barracuda:
		{
			skilled = true;
			action.set_action_type(1);
			if ((game.enemy_action.is_skill && game.enemy_action.type != subtle)
				|| game.enemy_action.is_skill == false)
			{
				if (get_enemy_hp(game.enemy_action.action_fish))
				{
					action.set_enemy_target(game.enemy_action.action_fish);
					break;
				}
			}
			action.set_enemy_target((get_enemy_living_fishes())[0]);
			break;
		}

		case mobula:
		case octopus:
		if (random(0, 1) < 0.5)
		{
			skilled = true;
			action.set_action_type(1);
			auto living_ally = get_my_living_ally(pos);
			if (!living_ally.empty())
			{
				action.set_friend_target((get_my_living_ally(pos))[0]);
				break;
			}
			action.set_friend_target(pos);
			break;
		}
		break;

		case turtle:
		{
			if (get_skill_used(pos) < 3)
			{
				auto living_ally = get_my_living_ally(pos);
				if (!living_ally.empty())
				{
					skilled = true;
					action.set_action_type(1);
					action.set_friend_target(living_ally[0]);
					action.set_enemy_target((get_enemy_living_fishes())[0]);
				}
			}
			break;
		}

		case whiteshark:
		case hammerhead:
		{
			skilled = true;
			action.set_action_type(1);
			action.set_enemy_target((get_lowest_health_enemies())[0]);
			break;
		}

		case clownfish:
		{
			if (get_skill_used(pos) < 3)
			{
				auto living_ally = get_my_living_ally(pos);
				if (!living_ally.empty())
				{
					skilled = true;
					action.set_action_type(1);
					action.set_friend_target(living_ally[0]);
					if (get_skill_used(pos) < 3)
						action.set_enemy_target(-2);
				}
			}
			break;
		}
	}
	if (!skilled)
	{
		action.set_action_type(0);
		action.set_enemy_target(get_lowest_health_enemy());
	}
	return action;
}
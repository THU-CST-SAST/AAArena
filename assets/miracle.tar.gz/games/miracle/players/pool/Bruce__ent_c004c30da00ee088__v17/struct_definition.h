//
// Created by pc on 2020/3/26.
//

#ifndef MY_AI_STRUCT_DEFINITION_H
#define MY_AI_STRUCT_DEFINITION_H

#include "gameunit.h"
#include <string>
#include <vector>

using std::string;
using std::vector;

using gameunit::Unit;

struct modification{
    Unit unit;
    bool add; //add为真表示修改为增加该unit，反之为去掉该unit
};

struct modifications{
    string info;
    vector<modification> mods;
};

#endif //MY_AI_STRUCT_DEFINITION_H

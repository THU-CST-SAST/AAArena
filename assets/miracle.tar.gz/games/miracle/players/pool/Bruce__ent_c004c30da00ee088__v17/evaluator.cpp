//
// Created by pc on 2020/3/26.
//

#include <vector>
#include <fstream>
#include <string>
#include <map>
#include <iostream>
#include "evaluator.h"
#include "calculator.h"
#include "gameunit.h"
#include "ai_client.h"

using std::vector;
//using std::map;
using std::ifstream;
using std::string;
using std::make_tuple;
using std::cerr;
using std::endl;

using gameunit::Pos;
using calculator::all_pos_in_map;

std::map<Pos, double> evaluator::weight_of_pos0;
std::map<Pos, double> evaluator::weight_of_pos1;
vector<Pos> evaluator::pos_order;
std::map<string, double> evaluator::weight_of_unit;
vector<string> evaluator::unit_order = {"Archer", "Swordsman", "BlackBat", "Priest", "VolcanoDragon", "Inferno"};
vector<Pos> evaluator::pos_bonus_order = {make_tuple(0, 5, -5), make_tuple(0, -5, 5), make_tuple(6, 6, -12), make_tuple(-6, -6, 12)};
std::map<Pos, double> evaluator::weight_of_pos_bonus;
bool evaluator::initialized = false;

void evaluator::init() {
    pos_order = all_pos_in_map();

    ifstream fin("weight_of_position0.txt");
    for(int i = 0; i < 281; i ++){
        double tmp;
        fin >> tmp;
        weight_of_pos0.insert(std::map<Pos, double>::value_type(pos_order[i], tmp));
    }
    fin.close();

    fin.open("weight_of_position1.txt");
    for(int i = 0; i < 281; i ++){
        double tmp;
        fin >> tmp;
        weight_of_pos1.insert(std::map<Pos, double>::value_type(pos_order[i], tmp));
    }
    fin.close();

    fin.open("weight_of_unit.txt");
    for(int i = 0; i < 6; i ++){
        double tmp;
        fin >> tmp;
        weight_of_unit.insert(std::map<string, double>::value_type(unit_order[i], tmp));
    }
    fin.close();

    fin.open("weight_of_pos_bonus.txt");
    for(int i = 0; i < 4; i ++){
        double tmp;
        fin >> tmp;
        weight_of_pos_bonus.insert(std::map<Pos, double>::value_type(pos_bonus_order[i], tmp));
    }
    fin.close();

    initialized = true;
}

evaluator::evaluator(const AiClient & ai):map(ai.map), players{ai.players[0], ai.players[1]},
                        round(ai.round), my_camp(ai.my_camp), my_artifacts(ai.my_artifacts), my_creatures(ai.my_creatures){}

double evaluator::evaluate(){
    double score = 0;
    bool pos_bonus_used[4] = {false};
    for(const auto & unit: map.units){
        //cerr << unit.type << unit.camp << unit.id << ' ';
        double delta_score;
        if(unit.camp == 0){
            delta_score = weight_of_unit[unit.type] * weight_of_pos0[unit.pos] * (double(unit.hp) / unit.max_hp);
        } else if(unit.camp == 1){
            delta_score = weight_of_unit[unit.type] * weight_of_pos1[unit.pos] * (double(unit.hp) / unit.max_hp);
        }

        for(int i = 0; i < 4; i ++){
            if(!pos_bonus_used[i] && unit.pos == pos_bonus_order[i]){
                delta_score += weight_of_pos_bonus[unit.pos];
                pos_bonus_used[i] = true;
            }
        }

        if(unit.camp == my_camp){
            score += delta_score;
        } else {
            score -= delta_score;
        }
    }

    score += map.miracles[my_camp].hp * 15;
    score -= map.miracles[my_camp^1].hp * 15;
    //cerr << score << endl;
    return score;
}

void evaluator::load(const modifications &changes) {
    for(const auto & change: changes.mods){
        if(!change.add){
            for(auto it = map.units.begin(); it != map.units.end(); it++){
                if(it->type == change.unit.type && it->pos == change.unit.pos){
                    map.units.erase(it);
                    break;
                }
            }
        }
    }
    for(const auto & change: changes.mods){
        if(change.add){
            map.units.push_back(change.unit);
        }
    }
    all_diff.push(changes);
}

void evaluator::pop() {
    auto changes = all_diff.top();
    for(const auto & change: changes.mods){
        if(change.add){
            for(auto it = map.units.begin(); it != map.units.end(); it++){
                if(it->type == change.unit.type && it->pos == change.unit.pos){
                    map.units.erase(it);
                    break;
                }
            }
        }
    }
    for(const auto & change: changes.mods){
        if(!change.add){
            map.units.push_back(change.unit);
        }
    }
    all_diff.pop();
}

vector<Unit> evaluator::get_units_can_attacked(const gameunit::Unit &attacker) {
    vector<Unit> ret;
    if(!attacker.can_atk){return ret;}
    auto enermies = getUnitsByCamp(attacker.camp ^ 1);
    for(auto & enermy: enermies){
        if(canAttack(attacker, enermy)){
            ret.push_back(std::move(enermy));
        }
    }
    return std::move(ret);
}

bool evaluator::can_attack(const gameunit::Unit &attacker, const gameunit::Miracle &miracle) const {
    if(attacker.camp == miracle.camp){return false;}
    if (attacker.atk <= 0){return false;}
    if(!attacker.can_atk){ return false;}
    //攻击范围
    int dist = calculator::cube_distance(attacker.pos, miracle.pos);
    if (dist < attacker.atk_range[0] || dist > attacker.atk_range[1])
        return false;
    return true;
}

//from ai_client.cpp

int evaluator::getDistanceOnGround(gameunit::Pos pos_a, gameunit::Pos pos_b, int camp)
{
    //地图边界
    std::vector<gameunit::Pos> obstacles_pos = calculator::MAPBORDER();
    //地面障碍
    for (auto p = map.ground_obstacles.begin(); p != map.ground_obstacles.end(); p++)
    {
        obstacles_pos.push_back(p->pos);
    }
    //敌方地面生物
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != camp && (!p->flying))
        {
            obstacles_pos.push_back(p->pos);
        }
    }
    return calculator::search_path(pos_a, pos_b, obstacles_pos, {}).size();
}

int evaluator::getDistanceInSky(gameunit::Pos pos_a, gameunit::Pos pos_b, int camp)
{
    //地图边界
    std::vector<gameunit::Pos> obstacles_pos = calculator::MAPBORDER();
    //飞行障碍
    for (auto p = map.flying_obstacles.begin(); p != map.flying_obstacles.end(); p++)
    {
        obstacles_pos.push_back(p->pos);
    }
    //敌方飞行生物
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != camp && p->flying)
        {
            obstacles_pos.push_back(p->pos);
        }
    }
    return calculator::search_path(pos_a, pos_b, obstacles_pos, {}).size();
}

int evaluator::checkBarrack(gameunit::Pos pos)
{
    for (auto barrack = map.barracks.begin(); barrack != map.barracks.end(); barrack++)
    {
        if (barrack->pos == pos)
            return barrack->camp;
    }
    return -2;
}

bool evaluator::canAttack(const gameunit::Unit & attacker, const gameunit::Unit & target) const
{
    //攻击力小于等于0的生物无法攻击
    if (attacker.atk <= 0)
        return false;
    //攻击范围
    int dist = calculator::cube_distance(attacker.pos, target.pos);
    if (dist < attacker.atk_range[0] || dist > attacker.atk_range[1])
        return false;
    //对空攻击
    if (target.flying && (!attacker.atk_flying))
        return false;
    return true;
}

bool evaluator::canUseArtifact(gameunit::Artifact artifact, gameunit::Pos pos, int camp)
{
    if (artifact.name == "HolyLight")
    {
        return calculator::in_map(pos);
    }
    else if (artifact.name == "InfernoFlame")
    {
        // 不处于障碍物上
        for (auto obstacle = map.obstacles.begin(); obstacle != map.obstacles.end(); obstacle++)
        {
            if (obstacle->pos == pos)
                return false;
        }
        // 无地面生物
        for (auto unit = map.units.begin(); unit != map.units.end(); unit++)
        {
            if ((unit->pos == pos) && (not unit->flying))
                return false;
        }
        // 距己方神迹范围<=7
        if (calculator::cube_distance(pos, map.miracles[camp].pos) <= 7)
            return true;
        // 距己方占领驻扎点范围<=5
        for (auto barrack = map.barracks.begin(); barrack != map.barracks.end(); barrack++)
        {
            if ((barrack->camp == camp) && (calculator::cube_distance(pos, barrack->pos) <= 5))
                return true;
        }
    }
    return false;
}

bool evaluator::canUseArtifact(gameunit::Artifact artifact, gameunit::Unit unit)
{
    if (artifact.name == "SalamanderShield")
    {
        // 己方生物
        return artifact.camp == unit.camp;
    }
    return false;
}

gameunit::Unit evaluator::getUnitByPos(gameunit::Pos pos, bool flying) const
{
    for (int i = 0; i < map.units.size(); ++i) {
        if (map.units[i].pos == pos && map.units[i].flying == flying)
            return map.units[i];
    }
    // 未找到时返回一个id为-1的Unit
    gameunit::Unit no_unit;
    no_unit.id = -1;
    return no_unit;
}

gameunit::Unit evaluator::getUnitById(int unit_id) const
{
    for (int i = 0; i < map.units.size(); ++i)
    {
        if (map.units[i].id == unit_id)
            return map.units[i];
    }
    // 未找到时返回一个id为-1的Unit
    gameunit::Unit no_unit;
    no_unit.id = -1;
    return no_unit;
}

std::vector<gameunit::Unit> evaluator::getUnitsByCamp(int unit_camp) const
{
    std::vector<gameunit::Unit> camp_units;
    for (int i = 0; i < map.units.size(); ++i)
    {
        if (map.units[i].camp == unit_camp)
            camp_units.push_back(map.units[i]);
    }
    return camp_units;
}

std::vector<gameunit::Pos> evaluator::getSummonPosByCamp(int camp) const
{
    std::vector<gameunit::Pos> summon_pos;
    for (auto miracle = map.miracles.begin(); miracle != map.miracles.end(); miracle++)
    {
        if (miracle->camp == camp)
            summon_pos.insert(summon_pos.end(), miracle->summon_pos_list.begin(), miracle->summon_pos_list.end());
    }
    for (auto barrack = map.barracks.begin(); barrack != map.barracks.end(); barrack++)
    {
        if (barrack->camp == camp)
            summon_pos.insert(summon_pos.end(), barrack->summon_pos_list.begin(), barrack->summon_pos_list.end());
    }
    return summon_pos;
}

//end from ai_client.cpp
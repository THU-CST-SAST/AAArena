#include <fstream>
#include <vector>
#include <map>
#include <stack>
#include <cstdlib>
#include <sstream>
#include <iostream>

#include "ai_client.h"
#include "card.hpp"
#include "evaluator.h"
#include "modify.h"
#include "calculator.h"
#include "struct_definition.h"
#include "gameunit.h"

using std::vector;
using std::stack;
using std::string;
using std::make_tuple;
using std::get;
using std::stringstream;
using std::cerr;
using std::endl;

using gameunit::Pos;
using gameunit::Unit;

using card::CARD_DICT;

class AI : public AiClient
{
public:
    void chooseCards();
    void play();

    void Summon(evaluator& sandbox);
    void Battle_or_March(evaluator& sandbox);
    void Use_artifact(evaluator& sandbox);
    Pos posShift(Pos pos, string direct);
};

void AI::chooseCards() {
    // artifacts和creatures可以修改
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "BlackBat", "VolcanoDragon"};
    init();
}

void AI::play() {
    if(!evaluator::initialized){
        evaluator::init();
    }
    evaluator sandbox{*this};

    if(round == 0 || round == 1){
        summon("Archer", 1, posShift(map.miracles[my_camp].pos, "SF"));
    }

    else if(round == 2 || round == 3){
        auto units = getUnitsByCamp(my_camp);
        auto target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (calculator::cube_distance(map.miracles[my_camp].pos, barrack.pos) < calculator::cube_distance(map.miracles[my_camp].pos, target_barrack))
                target_barrack = barrack.pos;
        }
        auto posss = calculator::reachable(units[0], map);
        int dis = 100;
        Pos best_pos = posss[1][0];
        for(auto poss: posss){
            for(auto pos: poss){
                if(calculator::cube_distance(pos, target_barrack) <= dis){
                    dis = calculator::cube_distance(pos, target_barrack);
                    best_pos = pos;
                }
            }
        }
        move(units[0].id, best_pos);
        summon("BlackBat", 2, posShift(map.miracles[my_camp].pos, "SF"));
    }

    else {

        Battle_or_March(sandbox);
        Use_artifact(sandbox);
        Summon(sandbox);

    }

    endRound();
}

void AI::Battle_or_March(evaluator &sandbox) {
    auto ally = sandbox.getUnitsByCamp(sandbox.my_camp);
    for(auto & unit: ally){
        double best_score = -50000;
        modifications best_modification{};
        auto pos_reachable = calculator::reachable(unit, sandbox.map);
        for(auto & pos_list: pos_reachable){
            for(auto & pos: pos_list){
                auto changes = modify::try_move(sandbox, unit, pos);
                sandbox.load(changes);
                double score = sandbox.evaluate();
                sandbox.pop();
                if(score > best_score){
                    best_score = score;
                    best_modification = changes;
                }
            }
        }
        if(unit.can_atk){
            auto enermies = sandbox.get_units_can_attacked(unit);
            for(auto & enermy: enermies){
                auto changes = modify::try_attack(sandbox, unit, enermy);
                sandbox.load(changes);
                double score = sandbox.evaluate();
                sandbox.pop();
                if(score > best_score){
                    best_score = score;
                    best_modification = changes;
                }
            }
            if(sandbox.can_attack(unit, sandbox.map.miracles[sandbox.my_camp ^ 1])){
                sandbox.map.miracles[sandbox.my_camp ^ 1].hp -= unit.atk;
                double score = sandbox.evaluate();
                sandbox.map.miracles[sandbox.my_camp ^ 1].hp += unit.atk;
                if(score > best_score){
                    attack(unit.id, sandbox.map.miracles[sandbox.my_camp^1].id);
                    sandbox.map.miracles[sandbox.my_camp ^ 1].hp -= unit.atk;
                    continue;
                }
            }
        }
        if(best_modification.info.empty()){ continue;}
        cerr << best_modification.info << endl;
        sandbox.load(best_modification);
        stringstream ss(best_modification.info);
        string command;
        ss >> command;
        if(command == "move"){
            int a, b, c, d;
            ss >> a >> b >> c >> d;
            move(a, b, c, d);
        } else if(command == "attack"){
            int a, b;
            ss >> a >> b;
            attack(a, b);
        }
    }
}

void AI::Use_artifact(evaluator &sandbox) {
    if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
        auto pos_list = calculator::all_pos_in_map();
        vector<Pos> valid_use_pos;
        for(const auto & pos: pos_list){
            if(canUseArtifact(players[my_camp].artifact[0], pos, my_camp)){
                valid_use_pos.push_back(pos);
            }
        }
        double best_score = 0;
        modifications best_modifications{};
        for(const auto & pos: valid_use_pos){
            auto changes = modify::try_use(sandbox, players[my_camp].artifact[0], pos, my_camp);
            sandbox.load(changes);
            double score = sandbox.evaluate();
            sandbox.pop();
            if(score > best_score){
                best_modifications = changes;
                best_score = score;
            }
        }
        if(best_modifications.info.empty()){return;}
        sandbox.load(best_modifications);
        stringstream ss(best_modifications.info);
        string command;
        ss >> command;
        assert(command == "use");
        int a, b, c, d;
        ss >> a >> b >> c >> d;
        use(a, b, c, d);
    }
}

void AI::Summon(evaluator &sandbox) {
    //最后进行召唤
    //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
    auto summon_pos_list = getSummonPosByCamp(my_camp);
    sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
        return calculator::cube_distance(_pos1, map.miracles[my_camp ^ 1].pos) < calculator::cube_distance(_pos2, map.miracles[my_camp ^ 1].pos);
    });
    vector<Pos> available_summon_pos_list;
    for (auto pos:summon_pos_list) {
        auto unit_on_pos_ground = getUnitByPos(pos, false);
        if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
    }

    //统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个剑士、1个弓箭手、1个火山龙的顺序召唤
    int mana = players[my_camp].mana;
    auto deck = players[my_camp].creature_capacity;
    ::map<string, int> available_count;
    for (const auto &card_unit:deck)
        available_count[card_unit.type] = card_unit.available_count;

    vector<string> summon_list;
    //剑士和弓箭手数量不足或者格子不足则召唤火山龙
    if ((available_summon_pos_list.size() == 1 || available_count["BlackBat"] + available_count["Archer"] < 2) &&
        mana >= CARD_DICT.at("VolcanoDragon")[1].cost && available_count["VolcanoDragon"] > 0) {
        summon_list.emplace_back("VolcanoDragon");
        mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
    }

    bool suc = true;
    while (mana >= 2 && suc) {
        suc = false;
        if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[1].cost) {
            summon_list.emplace_back("Archer");
            mana -= CARD_DICT.at("Archer")[1].cost;
            available_count["Archer"] -= 1;
            suc = true;
        }
        if (available_count["VolcanoDragon"] > 0 && mana >= CARD_DICT.at("VolcanoDragon")[1].cost) {
            summon_list.emplace_back("VolcanoDragon");
            mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
            available_count["VolcanoDragon"] -= 1;
            suc = true;
        }
        if (available_count["BlackBat"] > 0 && mana >= CARD_DICT.at("BlackBat")[1].cost) {
            summon_list.emplace_back("BlackBat");
            mana -= CARD_DICT.at("BlackBat")[1].cost;
            available_count["BlackBat"] -= 1;
            suc = true;
        }
    }

    int i = 0;
    for (auto pos:available_summon_pos_list) {
        if (i == summon_list.size()) break;
        summon(summon_list[i], 3, pos);
        ++i;
    }
}

Pos AI::posShift(Pos pos, string direct){
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

int main(){
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true)
    {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

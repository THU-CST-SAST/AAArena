//
// Created by pc on 2020/3/28.
//

#include "modify.h"
#include "calculator.h"
#include <cassert>

map<string, int> modify::type_to_int = {{"Archer", 0}, {"Swordsman", 1}, {"BlackBat", 2}, {"Priest", 3}, {"VolcanoDragon", 4}, {"Inferno", 5}};

modifications modify::try_sommon(const evaluator & ai, const string & type, int level, const Pos & position, int camp){
    Unit unit = std_unit[type_to_int[type]][level];
    unit.pos = position;
    unit.camp = camp;
    modification ret = {std::move(unit), true};
    string info = "sommon " + type + ' ' + to_string(level) + ' '
                            + to_string(get<0>(position)) + ' ' + to_string(get<1>(position)) + ' ' + to_string(get<2>(position));
    return {info, vector<modification>{std::move(ret)}};
}

modifications modify::try_move(const evaluator & ai, const Unit & mover, const Pos & position){
    Unit unit = mover;
    unit.pos = position;
    modification mod1 = {mover, false};
    modification mod2 = {std::move(unit), true};
    string info = "move " + to_string(mover.id) + ' '
                          + to_string(get<0>(position)) + ' ' + to_string(get<1>(position)) + ' ' + to_string(get<2>(position));
    return {info, vector<modification>{std::move(mod1), std::move(mod2)}};
}

modifications modify::try_attack(const evaluator & ai, const Unit & attacker, const Unit & target){
    vector<modification> ret;
    if(ai.canAttack(target, attacker)){
        modification mod1 = {attacker, false};
        ret.push_back(std::move(mod1));
        if(attacker.holy_shield){
            Unit unit = attacker;
            unit.holy_shield = false;
            modification mod2 = {std::move(unit), true};
            ret.push_back(std::move(mod2));
        } else if(attacker.hp > target.atk){
            Unit unit = attacker;
            unit.hp -= target.atk;
            modification mod2 = {std::move(unit), true};
            ret.push_back(std::move(mod2));
        }
    }
    if(attacker.type == "VolcanoDragon"){
        auto around = calculator::units_in_range(target.pos, 1, ai.map, ai.my_camp, false, true);
        for(Unit & unit: around){
            if(calculator::cube_distance(attacker.pos, unit.pos) == 2 && !unit.flying){
                modification mod1 = {unit, false};
                ret.push_back(std::move(mod1));
                if(unit.holy_shield){
                    unit.holy_shield = false;
                    modification mod2 = {std::move(unit), true};
                    ret.push_back(std::move(mod2));
                } else if(unit.hp > attacker.atk){
                    unit.hp -= attacker.atk;
                    modification mod2 = {std::move(unit), true};
                    ret.push_back(std::move(mod2));
                }
            }
        }
    }
    modification mod1 = {target, false};
    ret.push_back(std::move(mod1));
    if(target.holy_shield){
        Unit unit = target;
        unit.holy_shield = false;
        modification mod2 = {std::move(unit), true};
        ret.push_back(std::move(mod2));
    } else if(target.hp > attacker.atk){
        Unit unit = target;
        unit.hp -= attacker.atk;
        modification mod2 = {std::move(unit), true};
        ret.push_back(std::move(mod2));
    }
    string info = "attack " + to_string(attacker.id) + ' ' + to_string(target.id);
    return {info, ret};
}

modifications modify::try_use(const evaluator & ai, const gameunit::Artifact & artifact, const Unit & target){
    assert(artifact.name == "SalamanderShield");
    Unit unit = target;
    unit.max_hp += 3;
    unit.hp += 3;
    unit.level += 3;//通过等级+3标记处在神器影响之下
    unit.holy_shield = true;
    modification mod1 = {target, false};
    modification mod2 = {std::move(unit), true};
    string info = "use " + to_string(artifact.id) + ' ' + to_string(target.id);
    return {info, vector<modification>{std::move(mod1), std::move(mod2)}};
}

modifications modify::try_use(const evaluator & ai, const gameunit::Artifact & artifact, const Pos & target, int camp){
    vector<modification> ret;
    if(artifact.name == "HolyLight"){
        auto targets = calculator::units_in_range(target, 2, ai.map, camp);
        for(Unit & unit: targets){
            modification mod1 = {unit, false};
            ret.push_back(std::move(mod1));
            unit.hp = unit.max_hp;
            unit.atk += 2;
            unit.level += 6;//通过等级+6标记处在神器影响之下
            modification mod2 = {std::move(unit), true};
            ret.push_back(std::move(mod2));
        }
        string info = "use " + to_string(artifact.id) + ' '
                             + to_string(get<0>(target)) + ' ' + to_string(get<1>(target)) + ' ' + to_string(get<2>(target));
        return {info, ret};
    } else if(artifact.name == "InfernoFlame"){
        auto targets = calculator::units_in_range(target, 2, ai.map, camp ^ 1);
        for(Unit & unit: targets){
            modification mod1 = {unit, false};
            ret.push_back(std::move(mod1));
            if(unit.holy_shield){
                unit.holy_shield = false;
                modification mod2 = {std::move(unit), true};
                ret.push_back(std::move(mod2));
            } else if(unit.hp > 2){
                unit.hp -= 2;
                modification mod2 = {std::move(unit), true};
                ret.push_back(std::move(mod2));
            }
        }
        Unit unit = std_unit[type_to_int["Inferno"]][1];
        unit.camp = camp;
        unit.pos = target;
        modification mod2 = {std::move(unit), true};
        ret.push_back(std::move(mod2));
        string info = "use " + to_string(artifact.id) + ' '
                      + to_string(get<0>(target)) + ' ' + to_string(get<1>(target)) + ' ' + to_string(get<2>(target));
        return {info, ret};
    } else {
        assert(0);
        return {"", ret};
    }
}
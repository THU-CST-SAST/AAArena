  // Created by pc on 2020/3/26.
//

#ifndef MY_AI_EVALUATOR_H
#define MY_AI_EVALUATOR_H

#include <map>
#include <vector>
#include <string>
#include <stack>
#include "ai_client.h"
#include "gameunit.h"
#include "calculator.h"
#include "struct_definition.h"

using gameunit::Pos;
using gameunit::Unit;

//using std::map;
using std::vector;
using std::string;
using std::stack;

class evaluator {
public:
    static vector<Pos> pos_order;
    static std::map<Pos, double> weight_of_pos0;
    static std::map<Pos, double> weight_of_pos1;
    static vector<string> unit_order;
    static std::map<string, double> weight_of_unit;
    static vector<Pos> pos_bonus_order;
    static std::map<Pos, double> weight_of_pos_bonus;
    static bool initialized;
    //int my_score;
    //int enermy_score;
    gameunit::Map map;                                      // 地图
    gameunit::Player players[2];                            // 两名玩家的信息
    int round;                                              // 当前回合
    int my_camp;                                            // 己方阵营
    std::vector<std::string> my_artifacts;                  // 己方神器
    std::vector<std::string> my_creatures;                  // 己方生物
    stack<modifications> all_diff;
    //vector<Unit> my_units;
    //vector<Unit> enermy_units;
    //vector<Pos> my_summons;
    //vector<Pos> enermy_summons;

public:
    static void init();
    evaluator() = delete;
    explicit evaluator(const AiClient & ai);
    double evaluate();

    void load(const modifications & changes);
    void pop();

    vector<Unit> get_units_can_attacked(const gameunit::Unit& attacker);
    bool can_attack(const gameunit::Unit & attacker, const gameunit::Miracle & miracle) const;

    //from ai_client.h
    // 获取camp阵营生物从pos_a位置到pos_b位置的地面距离(不经过地面障碍或敌方地面生物)
    int getDistanceOnGround(gameunit::Pos pos_a, gameunit::Pos pos_b, int camp);

    // 获取camp阵营生物从pos_a位置到pos_b位置的飞行距离(不经过飞行障碍或敌方飞行生物)
    int getDistanceInSky(gameunit::Pos pos_a, gameunit::Pos pos_b, int camp);

    // 对于pos位置,判断其驻扎情况
    // 不是驻扎点返回-2,中立返回-1,否则返回占领该驻扎点的阵营(0或1)
    int checkBarrack(gameunit::Pos pos);

    // 判断attacker生物能否攻击到target生物(只考虑攻击力、攻击范围)
    bool canAttack(const gameunit::Unit & attacker, const gameunit::Unit & target) const;

    // 判断能否对pos位置使用artifact神器(不考虑消耗、冷却)
    bool canUseArtifact(gameunit::Artifact artifact, gameunit::Pos pos, int camp);

    // 判断能否对unit生物使用artifact神器(不考虑消耗、冷却)
    bool canUseArtifact(gameunit::Artifact artifact, gameunit::Unit unit);

    // 获取位置pos上的生物
    // 如果有,返回对应的Unit,否则返回一个id为-1的Unit
    gameunit::Unit getUnitByPos(gameunit::Pos pos, bool flying) const;

    // 获取id为unit_id的生物
    // 如果有,返回对应的Unit,否则返回一个id为-1的Unit
    gameunit::Unit getUnitById(int unit_id) const;

    // 获取所有阵营为unit_camp的生物
    // 返回阵营等于unit_camp的Unit列表(没有时返回空列表)
    std::vector<gameunit::Unit> getUnitsByCamp(int unit_camp) const;

    // 获取所有属于阵营camp的出兵点(初始出兵点+额外出兵点)
    std::vector<gameunit::Pos> getSummonPosByCamp(int camp) const;
    //end from ai_client.h
};


#endif //MY_AI_EVALUATOR_H

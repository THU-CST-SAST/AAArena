//
// Created by pc on 2020/3/28.
//

#ifndef MY_AI_MODIFY_H
#define MY_AI_MODIFY_H

#include "struct_definition.h"
#include "gameunit.h"
#include "ai_client.h"
#include "evaluator.h"
#include <string>
#include <vector>
#include <map>

using gameunit::Pos;
using gameunit::Unit;
using std::string;
using std::to_string;
using std::vector;
using std::map;
using std::get;

const Unit std_unit[6][4] = {
        {//Archer
                {0, 0, "Archer", 2, 1, 1, 1, vector<int>{3, 4}, 3, 4, {0, 0, 0}, 1, false, true, false, false, true, true},
                {0, 0, "Archer", 2, 1, 1, 1, vector<int>{3, 4}, 3, 4, {0, 0, 0}, 1, false, true, false, false, true, true},
                {0, 0, "Archer", 4, 2, 2, 2, vector<int>{3, 4}, 3, 4, {0, 0, 0}, 2, false, true, false, false, true, true},
                {0, 0, "Archer", 6, 3, 3, 3, vector<int>{3, 4}, 3, 4, {0, 0, 0}, 3, false, true, false, false, true, true}
        },
        {//Swordsman
                {0, 0, "Swordsman", 2, 2, 2, 2, vector<int>{1, 1}, 3, 3, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "Swordsman", 2, 2, 2, 2, vector<int>{1, 1}, 3, 3, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "Swordsman", 4, 4, 4, 4, vector<int>{1, 1}, 3, 3, {0, 0, 0}, 2, false, false, false, false, true, true},
                {0, 0, "Swordsman", 6, 6, 6, 6, vector<int>{1, 1}, 3, 3, {0, 0, 0}, 3, false, false, false, false, true, true}
        },
        {//BlackBat
                {0, 0, "BlackBat", 2, 1, 1, 1, vector<int>{0, 1}, 5, 2, {0, 0, 0}, 1, true, true, false, false, true, true},
                {0, 0, "BlackBat", 2, 1, 1, 1, vector<int>{0, 1}, 5, 2, {0, 0, 0}, 1, true, true, false, false, true, true},
                {0, 0, "BlackBat", 3, 3, 1, 1, vector<int>{0, 1}, 5, 2, {0, 0, 0}, 2, true, true, false, false, true, true},
                {0, 0, "BlackBat", 5, 5, 2, 2, vector<int>{0, 1}, 5, 2, {0, 0, 0}, 3, true, true, false, false, true, true}
        },
        {//Priest
                {0, 0, "Priest", 2, 0, 2, 2, vector<int>{0, 0}, 3, 4, {0, 0, 0}, 1, false, false, false, false, false, true},
                {0, 0, "Priest", 2, 0, 2, 2, vector<int>{0, 0}, 3, 4, {0, 0, 0}, 1, false, false, false, false, false, true},
                {0, 0, "Priest", 3, 0, 2, 2, vector<int>{0, 0}, 3, 4, {0, 0, 0}, 2, false, false, false, false, false, true},
                {0, 0, "Priest", 5, 0, 3, 3, vector<int>{0, 0}, 3, 5, {0, 0, 0}, 3, false, false, false, false, false, true}
        },
        {//VolcanoDragon
                {0, 0, "VolcanoDragon", 5, 3, 5, 5, vector<int>{1, 2}, 2, 5, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "VolcanoDragon", 5, 3, 5, 5, vector<int>{1, 2}, 2, 5, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "VolcanoDragon", 7, 4, 7, 7, vector<int>{1, 2}, 2, 5, {0, 0, 0}, 2, false, false, false, false, true, true},
                {0, 0, "VolcanoDragon", 9, 5, 9, 9, vector<int>{1, 2}, 2, 5, {0, 0, 0}, 3, false, false, false, false, true, true}
        },
        {//Inferno
                {0, 0, "Inferno", 8, 8, 12, 12, vector<int>{1, 1}, 3, 6, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "Inferno", 8, 8, 12, 12, vector<int>{1, 1}, 3, 6, {0, 0, 0}, 1, false, false, false, false, true, true},
                {0, 0, "Inferno", 8, 8, 12, 12, vector<int>{1, 1}, 3, 6, {0, 0, 0}, 2, false, false, false, false, true, true},
                {0, 0, "Inferno", 8, 8, 12, 12, vector<int>{1, 1}, 3, 6, {0, 0, 0}, 3, false, false, false, false, true, true}
        }
};

class modify {
public:
    static map<string, int> type_to_int;
    static modifications try_sommon(const evaluator & ai, const string & type, int level, const Pos & position, int camp);
    static modifications try_move(const evaluator & ai, const Unit & mover, const Pos & position);
    static modifications try_attack(const evaluator & ai, const Unit & attacker, const Unit & target);
    static modifications try_use(const evaluator & ai, const gameunit::Artifact & artifact, const Unit & target);
    static modifications try_use(const evaluator & ai, const gameunit::Artifact & artifact, const Pos & target, int camp);
};


#endif //MY_AI_MODIFY_H

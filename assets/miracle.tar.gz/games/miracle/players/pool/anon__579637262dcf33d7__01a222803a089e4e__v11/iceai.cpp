#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

class AI : public AiClient
{
private:
    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack;

    Pos posShift(Pos pos, string direct);

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动
};

void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * 选择弓箭手，蝙蝠，冰龙
     * 神器选择地狱召唤
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "BlackBat", "FrostDragon"};
    init();
}

void AI::play()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */
    if (round == 0 || round == 1) {
        //先确定自己的基地、对方的基地
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        // 在正中心偏右召唤一个弓箭手，用来抢占驻扎点
        summon("Archer", 1, posShift(miracle_pos, "SF"));
    } else {
        //神器能用就用，选择覆盖敌方单位数最多的地点
        //神器使用条件：神迹范围7或驻扎点范围5，无地面生物，非深渊
        //覆盖生物数量小于2则不使用
        if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
            auto pos_list = all_pos_in_map();
            for (auto i=pos_list.begin();i<pos_list.end();){//不能使用则删去此点
                if(pos_list.empty()){
                    break;
                }
                if(!canUseArtifact(players[my_camp].artifact[0],*i,my_camp)){
                    i=pos_list.erase(i);
                }else{
                    i++;
                }
            }
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp^1);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            if(max_benefit>=2){
                use(players[my_camp].artifact[0].id, best_pos);
            }
        }

        //之后先战斗，再移动
        battle();

        march();

        //最后进行召唤
        /*召唤原则：优先从前方基地召唤，当有敌方单位距离我方神迹距离小于5时从后方召唤弓箭手或冰龙
        *统计数量
        * 优先召唤高等级兵种
        * 召唤顺序为数量最少的最优先召唤，优先召唤高等级
        */
        //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
        auto enemy_list= getUnitsByCamp(my_camp^1);
        bool defend=0;
        for(auto e:enemy_list){
            if(cube_distance(e.pos,miracle_pos)<5){
                defend=1;
                break;
            }
        }
        auto summon_pos_list = getSummonPosByCamp(my_camp);
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);//前端取出召唤点表示攻击性召唤，后端取出表示防守性召唤
        });
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
        }

        //统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个冰龙、1个弓箭手、1个蝙蝠的顺序召唤
        int mana = players[my_camp].mana;
        auto deck = players[my_camp].creature_capacity;
        std::map<string, int> available_count;
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;

        vector<string> summon_list;
        vector<int> level_list;//记录召唤生物的等级
        if(!defend){//攻击性召唤
            bool suc = true;
            while (mana >= 2 && suc) {
                suc = false;
                if (available_count["FrostDragon"] > 0 && mana >= CARD_DICT.at("FrostDragon")[1].cost) {
                    summon_list.emplace_back("FrostDragon");
                    if(mana >= CARD_DICT.at("FrostDragon")[2].cost){
                        if(mana >= CARD_DICT.at("FrostDragon")[3].cost){
                            mana -= CARD_DICT.at("FrostDragon")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("FrostDragon")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("FrostDragon")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["FrostDragon"] -= 1;
                    suc = true;
                }
                
                if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[2].cost) {
                    summon_list.emplace_back("Archer");
                    if(mana >= CARD_DICT.at("Archer")[3].cost){
                        mana -= CARD_DICT.at("Archer")[3].cost;
                        level_list.emplace_back(3);
                    }else{
                        mana -= CARD_DICT.at("Archer")[2].cost;
                        level_list.emplace_back(2);
                    }
                    available_count["Archer"] -= 1;
                    suc = true;
                }
                if (available_count["BlackBat"] > 0 && mana >= CARD_DICT.at("BlackBat")[1].cost) {
                    summon_list.emplace_back("BlackBat");
                    if(mana >= CARD_DICT.at("BlackBat")[2].cost){
                        if(mana >= CARD_DICT.at("BlackBat")[3].cost){
                            mana -= CARD_DICT.at("BlackBat")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("BlackBat")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("BlackBat")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["BlackBat"] -= 1;
                    suc = true;
                }
            }
            int i = 0;
            for (auto pos:available_summon_pos_list) {
                if (i >= summon_list.size()) break;
                summon(summon_list[i], level_list[i], pos);
                ++i;
            }
        }else{//防守性召唤,在召唤点底部召唤冰龙和弓箭手，最后在前线召唤蝙蝠
            bool suc = true;
            while (mana >= 2 && suc) {
                suc = false;
                if (available_count["FrostDragon"] > 0 && mana >= CARD_DICT.at("FrostDragon")[1].cost) {
                    summon_list.emplace_back("FrostDragon");
                    if(mana >= CARD_DICT.at("FrostDragon")[2].cost){
                        if(mana >= CARD_DICT.at("FrostDragon")[3].cost){
                            mana -= CARD_DICT.at("FrostDragon")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("FrostDragon")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("FrostDragon")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["FrostDragon"] -= 1;
                    suc = true;
                }
                
                if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[1].cost) {
                    summon_list.emplace_back("Archer");
                    if(mana >= CARD_DICT.at("Archer")[2].cost){
                        if(mana >= CARD_DICT.at("Archer")[3].cost){
                            mana -= CARD_DICT.at("Archer")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("Archer")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("Archer")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["Archer"] -= 1;
                    suc = true;
                }
            }
            int i = summon_list.size()-1;
            for(int k=0;i>=0&&k<summon_list.size();k++){
                summon(summon_list[k],level_list[k],available_summon_pos_list[i]);
                --i;
            }
            suc=1;
            summon_list.clear();
            level_list.clear();
            while(mana>=2&&suc){
                suc=false;
                if (available_count["BlackBat"] > 0 && mana >= CARD_DICT.at("BlackBat")[1].cost) {
                    summon_list.emplace_back("BlackBat");
                    if(mana >= CARD_DICT.at("BlackBat")[2].cost){
                        if(mana >= CARD_DICT.at("BlackBat")[3].cost){
                            mana -= CARD_DICT.at("BlackBat")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("BlackBat")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("BlackBat")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["BlackBat"] -= 1;
                    suc = true;
                }
            }
            int j=0;
            for(int k=0;j<i&&k<summon_list.size();k++,j++){
                summon(summon_list[k],level_list[k],available_summon_pos_list[j]);
            }
        } 
    }
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 优先输出对方神迹
     * 冰龙：优先进攻牧师，蝙蝠，其次进攻离我方神迹近的
     * 弓箭手：优先进攻不能反击中攻击力最高的,特别地，弓箭手不进攻对方攻击大于己方生命的弓箭手
     * 蝙蝠：一般不进攻，尽量走位，进攻对方弓箭手或地面单位,不进攻对方蝙蝠和冰龙
     * 地狱：能进攻则进攻，优先进攻敌方的牧师或弓箭手
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */

    auto ally_list = getUnitsByCamp(my_camp);

    //首先攻击神迹
    for (auto ally : ally_list) {
        if (!ally.can_atk) continue;
        int dis = cube_distance(ally.pos, enemy_pos);//参照此模板修改判断攻击代码的写法
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }

    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//冰龙>弓箭手>蝙蝠
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "FrostDragon") return 0;
                else if (type_name == "Archer") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "FrostDragon" or unit1.type == "Archer")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };
    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);

    for (const auto &ally:ally_list) {
        if (!ally.can_atk) break;
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;
        for (const auto &enemy : enemy_list)//可以进攻则进入候选序列
            if (AiClient::canAttack(ally, enemy))
                target_list.push_back(enemy);
        if (target_list.empty()) continue;//没有可以进攻的对象

        if (ally.type == "FrostDragon") {
            Pos tmp=miracle_pos;
            auto cmp_frost=[tmp](const Unit& x1,const Unit& x2){
                if(x1.type!=x2.type){
                    auto import=[tmp](const string &type_name){
                        if(type_name=="BlackBat"){
                            return 0;
                        }
                        if(type_name=="Priest"){
                            return 1;
                        }
                        else return 2;
                    };
                    if(import(x1.type)!=import(x2.type)){
                        return import(x1.type)<import(x2.type);
                    }
                }
                int dis1=cube_distance(x1.pos,tmp);
                int dis2=cube_distance(x2.pos,tmp);
                return dis1<dis2;
            };
            sort(target_list.begin(),target_list.end(),cmp_frost);
            default_random_engine g(static_cast<unsigned int>(time(nullptr)));
            int tar = uniform_int_distribution<>(0, target_list.size() - 1)(g);
            attack(ally.id, target_list[tar].id);


        } else if (ally.type == "BlackBat") {
            for(auto i=target_list.begin();i<target_list.end();){//蝙蝠不进攻蝙蝠和冰龙
                if(i->type=="BlackBat"||i->type=="FrostDragon"){
                    i=target_list.erase(i);
                }else{
                    i++;
                }
            }
            if(target_list.empty()){
                continue;
            }
            sort(target_list.begin(),target_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "Archer") {
            sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list)
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue;
            else while(canAttack(target_list[0],ally)&&target_list[0].atk>=ally.hp){
                target_list.erase(target_list.begin());
                if(target_list.empty()){
                    break;
                }
            }
            if(target_list.empty()){
                continue;
            }
            attack(ally.id, target_list[0].id);
        } else if (ally.type=="Inferno") {
            auto cmp_infer=[](const Unit & x1,const Unit& x2){
                if(x1.type!=x2.type){
                    auto import=[](const Unit &a){
                        if(a.type=="Archer"){
                            return 1;
                        }
                        if(a.type=="Priest"){
                            return 2;
                        }
                        return 3;
                    };
                    return import(x1)<import(x2);
                }
                return x1.atk<x2.atk;
            };
            sort(target_list.begin(),target_list.end(),cmp_infer);
            attack(ally.id,target_list[0].id);
        }
    }
}

void AI::march()
{
    //处理生物的移动

    /*
     * 先动所有蝙蝠，尽可能向敌方神迹移动，同时躲避敌方弓箭手，同等情况下躲避牧师
     * 调用最初召唤的弓箭手占领目标驻扎点，放弃其余所有驻扎点
     * 冰龙分出属性，攻击属性尽可能向神迹移动，防守属性尽可能靠近己方弓箭手,距离弓箭手距离为1到3
     * 弓箭手躲避近身的敌人并优先进行防守，也可以考虑掩护我方攻击冰龙和蝙蝠
     * 【进阶】一味向敌方神迹移动并不一定是个好主意
     * 在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
     * 如果采用其他生物组合，可以考虑抢占更多驻扎点
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {
            if (type_name == "BlackBat") return 0;
            else if (type_name == "Archer") return 1;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });

    //获取敌方生物并进行针对性的分类
    auto enemy_list = getUnitsByCamp(my_camp^1);
    vector<Unit> archer_list;
    vector<Unit> fd_list;
    vector<Unit> bat_list;

    for(const auto &e_unit:enemy_list){
        if(e_unit.type=="Archer"){
            archer_list.push_back(e_unit);
        }else if(e_unit.type== "FrostDragon"){
            fd_list.push_back(e_unit);
        }else if(e_unit.type=="BlackBat"){
            bat_list.push_back(e_unit);
        }else continue;
    }

    for (const auto &ally : ally_list) {
        if (!ally.can_move) continue;//已经攻击过即不能再移动
        if (ally.type == "BlackBat") {
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
            //优先走到距离敌方神迹更近的位置,删去敌方冰龙和弓箭手可以攻击到的位置
            for(const auto e:archer_list){
                for(auto i=reach_pos_list.begin();i<reach_pos_list.end();){
                    int distance=cube_distance(e.pos,*i);
                    if((e.atk_range[0]<=distance)&&(distance<=e.atk_range[1])){
                       i=reach_pos_list.erase(i);
                    }else{
                        i++;
                    }
                }
            }
            for(const auto e:fd_list){
                for(auto i=reach_pos_list.begin();i<reach_pos_list.end();){
                    int distance=cube_distance(e.pos,*i);
                    if(e.atk_range[0]<=distance&&distance<=e.atk_range[1]){
                        i=reach_pos_list.erase(i);
                    }else{
                        i++;
                    }
                }
            }
            sort(reach_pos_list.begin(), reach_pos_list.end(),
                        [this](Pos _pos1, Pos _pos2) {
                            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                        });
            move(ally.id, reach_pos_list[0]);

        } else if (ally.type=="Archer"){
            //如果已经在兵营就不动了,更新后考虑到对手抢占驻扎点的操作对此部分代码不做修改
            bool on_barrack = false;
            for (const auto &barrack:map.barracks)
                if (ally.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }
            if (on_barrack) continue;

            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则向前推进,避免进入敌方单位的攻击区域
            //如果对方有单位进入可攻击到我方神迹的位置，走到可以攻击此单位的位置。
            if (getUnitByPos(target_barrack, false).id == -1) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                bool fight=0;
                for(const auto e:enemy_list){
                    int dis=cube_distance(e.pos,miracle_pos);
                    if(e.atk_range[0]<=dis&&dis<=e.atk_range[1]){//如果有敌方单位可以攻击到神迹，弓箭手准备前往清理
                        vector<Pos>target_pos;
                        for(auto tmp_pos:reach_pos_list){
                            int dis2=getDistanceOnGround(tmp_pos,e.pos,my_camp);
                            if(ally.atk_range[0]<=dis2&&dis2<=ally.atk_range[1]){
                                target_pos.push_back(tmp_pos);
                            }
                        }
                        if(target_pos.empty()){
                            continue;
                        }
                        nth_element(target_pos.begin(),target_pos.begin(),target_pos.end(),
                            [this](Pos x1,Pos x2){
                                int xx=units_in_range(x1,2,map,my_camp^1).size();
                                int yy=units_in_range(x2,2,map,my_camp^1).size();
                                return xx<yy;
                        });
                        fight=1;
                        move(ally.id, target_pos[0]);
                        break;
                    }
                }
                if(fight){
                    continue;
                }else
                for(const auto e:enemy_list){//不当靶子
                    if(e.type!="Archer")
                    for(auto i=reach_pos_list.begin();i<reach_pos_list.end();){
                        int dis=cube_distance(e.pos,*i);
                        if(e.atk_range[0]<=dis&&dis<=e.atk_range[1]){
                            i=reach_pos_list.erase(i);
                        }else{
                            i++;
                        }
                    }
                }
                if(reach_pos_list.empty()){
                    continue;
                }
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        }else if(ally.type=="FrostDragon"){
            int judge=0;
            std::tie(std::ignore,judge,std::ignore)=target_barrack;
            if(judge>0){//示意图中红线
                int tmp=0;
                std::tie(tmp,std::ignore,std::ignore)=ally.pos;
                //获取所有可到达的位置
                auto reach_pos_with_dis = reachable(ally, map);
                //压平
                vector<Pos> reach_pos_list;
                for (const auto &reach_pos : reach_pos_with_dis) {
                    for (auto pos : reach_pos)
                        reach_pos_list.push_back(pos);
                    }
                if (reach_pos_list.empty()) continue;
                if(tmp>0){//此冰龙属于进攻梯队，尽可能向神迹移动同时躲避弓箭手
                    for(const auto e:archer_list){
                        for(auto i=reach_pos_list.begin();i<reach_pos_list.end();){
                            int distance=cube_distance(e.pos,*i);
                            if(e.atk_range[0]<=distance&&distance<=e.atk_range[1]){
                            i=reach_pos_list.erase(i);
                            }else{
                                i++;
                            }
                        }
                    }
                    if(reach_pos_list.empty()) continue;
                    nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                    move(ally.id, reach_pos_list[0]);
                }else{//此冰龙属于防守梯队，尽可能靠近我方弓箭手
                    auto notbarrack=[](Pos x){
                        int a,b,c;
                        std::tie(a,b,c)=x;
                        if(a==0&&b==5&&c==-5){
                            return false;
                        }
                        return true;
                    };
                    Unit tar_archer;
                    bool sel=0;
                    for(auto tar:ally_list){
                        if(tar.type=="Archer"&&notbarrack(tar.pos)){
                            tar_archer=tar;
                            sel=1;
                            break;
                        }
                    }
                    if(!sel){//没有这样的弓箭手，向敌方靠近
                        nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this,tmp](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                        move(ally.id, reach_pos_list[0]);
                    }else{
                        nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this,tar_archer](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, tar_archer.pos) < cube_distance(_pos2, tar_archer.pos);
                            });
                        move(ally.id, reach_pos_list[0]);
                    }
                }
            }else if(judge<0){//示意图中蓝线
                int tmp=0;
                std::tie(tmp,std::ignore,std::ignore)=ally.pos;
                //获取所有可到达的位置
                auto reach_pos_with_dis = reachable(ally, map);
                //压平
                vector<Pos> reach_pos_list;
                for (const auto &reach_pos : reach_pos_with_dis) {
                    for (auto pos : reach_pos)
                        reach_pos_list.push_back(pos);
                    }
                if (reach_pos_list.empty()) continue;
                if(tmp<=0){//此冰龙属于进攻梯队，尽可能向神迹移动同时躲避弓箭手
                    for(const auto e:archer_list){
                        for(auto i=reach_pos_list.begin();i<reach_pos_list.end();){
                            int distance=cube_distance(e.pos,*i);
                            if(e.atk_range[0]<=distance&&distance<=e.atk_range[1]){
                            i=reach_pos_list.erase(i);
                            }else{
                                i++;
                            }
                        }
                    }
                    if(reach_pos_list.empty()) continue;
                    nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                    move(ally.id, reach_pos_list[0]);
                }else{//此冰龙属于防守梯队，尽可能靠近我方弓箭手
                    auto notbarrack=[](Pos x){
                        int a,b,c;
                        std::tie(a,b,c)=x;
                        if(a==0&&b==-5&&c==5){
                            return false;
                        }
                        return true;
                    };
                    Unit tar_archer;
                    bool sel=0;
                    for(auto tar:ally_list){
                        if(tar.type=="Archer"&&notbarrack(tar.pos)){
                            tar_archer=tar;
                            sel=1;
                            break;
                        }
                    }
                    if(!sel){//没有这样的弓箭手，向敌方靠近
                        nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this,tmp](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                        move(ally.id, reach_pos_list[0]);
                    }else{
                        nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this,tar_archer](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, tar_archer.pos) < cube_distance(_pos2, tar_archer.pos);
                            });
                        move(ally.id, reach_pos_list[0]);
                    }
                }
            }
        }else if(ally.type=="Inferno"){//召唤物，向前移动即可
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
            for (auto pos : reach_pos)
            reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
            nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),
                [this](Pos _pos1,Pos _pos2){
                    return cube_distance(_pos1,enemy_pos)<cube_distance(_pos2,enemy_pos);
                });
            move(ally.id,reach_pos_list[0]);
        }
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

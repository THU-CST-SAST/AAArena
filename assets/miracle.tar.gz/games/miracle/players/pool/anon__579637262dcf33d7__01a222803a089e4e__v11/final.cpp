#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>
#include <cmath>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
using std::pair;
class AI : public AiClient
{
private:
    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack;

    Pos posShift(Pos pos, string direct);

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动
};

void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * 选择弓箭手，牧师，冰龙
     * 神器选择地狱召唤
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "Priest", "FrostDragon"};
    init();
}

void AI::play()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */
    if (round == 0 || round == 1) {
        //先确定自己的基地、对方的基地
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        // 在正中心偏右召唤一个弓箭手，用来抢占驻扎点
        summon("Archer", 1, posShift(miracle_pos, "SF"));
    } else {
        //神器能用就用，选择覆盖敌方单位数最多的地点
        //神器使用条件：神迹范围7或驻扎点范围5，无地面生物，非深渊
        //覆盖生物数量小于2则不使用
        if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
            auto pos_list = all_pos_in_map();
            for (auto i=pos_list.begin();i<pos_list.end();){//不能使用则删去此点
                if(pos_list.empty()){
                    break;
                }
                if(!canUseArtifact(players[my_camp].artifact[0],*i,my_camp)){
                    i=pos_list.erase(i);
                }else{
                    i++;
                }
            }
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp^1);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            if(max_benefit>=2){
                use(players[my_camp].artifact[0].id, best_pos);
            }
        }

        //之后先战斗，再移动
        battle();
        
        march();
        
        //最后进行召唤  召唤顺序 冰龙>牧师>弓箭手，牧师召唤条件为场上至少有两个非牧师单位；
        /*召唤原则：优先从前方基地召唤，当有敌方单位距离我方神迹距离小于5时从后方召唤
        *统计数量
        * 优先召唤高等级兵种
        * 召唤顺序为数量最少的最优先召唤，优先召唤高等级
        */
        //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
        auto enemy_list= getUnitsByCamp(my_camp^1);
        bool defend=0;
        for(auto e:enemy_list){
            if(5>cube_distance(e.pos,miracle_pos)){
                defend=1;
                break;
            }
        }
        auto summon_pos_list = getSummonPosByCamp(my_camp);
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);//前端取出召唤点表示攻击性召唤，后端取出表示防守性召唤
        });
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) {
                available_summon_pos_list.push_back(pos);
            }
        }

        //统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个冰龙、1个牧师、1个弓箭手的顺序召唤
        //召唤牧师的前提是非牧师单位的数量大于等于2且比已有牧师单位多2
        int mana = players[my_camp].mana;
        auto deck = players[my_camp].creature_capacity;
        std::map<string, int> available_count;
        for (const auto &card_unit:deck){
            available_count[card_unit.type] = card_unit.available_count;
        }
        vector<string> summon_list;
        vector<int> level_list;//记录召唤生物的等级

            bool suc = true;
            while (mana >= 2 && suc) {
                suc = false;

                if (available_count["FrostDragon"] > 0 && mana >= CARD_DICT.at("FrostDragon")[1].cost) {
                    summon_list.emplace_back("FrostDragon");
                    if(mana >= CARD_DICT.at("FrostDragon")[2].cost){
                        if(mana >= CARD_DICT.at("FrostDragon")[3].cost){
                            mana -= CARD_DICT.at("FrostDragon")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("FrostDragon")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("FrostDragon")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["FrostDragon"] -= 1;
                    suc = true;
                }
                
                if (available_count["Priest"] > 0 && mana >= CARD_DICT.at("Priest")[1].cost) {
                    auto myunits=getUnitsByCamp(my_camp);
                    int cnt=0;
                    int pri_cnt=0;
                    for(auto e:myunits){
                        if(e.type!="Priest"){
                            cnt++;
                        }else{
                            pri_cnt++;
                        }
                    }
                    if((cnt>1)&&(cnt>pri_cnt+1)){
                        summon_list.emplace_back("Priest");
                        if(mana >= CARD_DICT.at("Priest")[2].cost){
                            if(mana >= CARD_DICT.at("Priest")[3].cost){
                                mana -= CARD_DICT.at("Priest")[3].cost;
                                level_list.emplace_back(3);
                            }else{
                                mana -= CARD_DICT.at("Priest")[2].cost;
                                level_list.emplace_back(2);
                            }
                        }else{
                            mana -= CARD_DICT.at("Priest")[1].cost;
                            level_list.emplace_back(1);
                        }
                        available_count["Priest"] -= 1;
                        suc = true;
                    }
                }

                if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[1].cost) {
                    summon_list.emplace_back("Archer");
                    if(mana >= CARD_DICT.at("Archer")[2].cost){
                        if(mana >= CARD_DICT.at("Archer")[3].cost){
                            mana -= CARD_DICT.at("Archer")[3].cost;
                            level_list.emplace_back(3);
                        }else{
                            mana -= CARD_DICT.at("Archer")[2].cost;
                            level_list.emplace_back(2);
                        }
                    }else{
                        mana -= CARD_DICT.at("Archer")[1].cost;
                        level_list.emplace_back(1);
                    }
                    available_count["Archer"] -= 1;
                    suc = true;
                }
            }
            if(!defend){
                int i = 0;
                for (auto pos:available_summon_pos_list) {
                    if (i >= summon_list.size()) break;
                    summon(summon_list[i], level_list[i], pos);
                    ++i;
                }
            }
            else{
                int i=0;
                for(auto e=available_summon_pos_list.end()-1;e>=available_summon_pos_list.begin();e--){
                    if(i>= summon_list.size()){
                        break;
                    }
                    summon(summon_list[i], level_list[i],*e);
                    ++i;
                }

            }
            
        
    }
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 优先输出对方神迹
     * 冰龙：优先进攻牧师，蝙蝠，其次进攻离我方神迹近的
     * 弓箭手：优先进攻不能反击中攻击力最高的,特别地，弓箭手不进攻对方攻击大于己方生命的弓箭手
     * 牧师：能进攻则进攻
     * 地狱：能进攻则进攻，优先进攻敌方的牧师或弓箭手
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */

    auto ally_list = getUnitsByCamp(my_camp);

    //首先攻击神迹
    for (auto ally : ally_list) {
        if (!ally.can_atk) continue;
        int dis = cube_distance(ally.pos, enemy_pos);//参照此模板修改判断攻击代码的写法
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }

    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//冰龙>弓箭手>牧师
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "FrostDragon") return 0;
                else if (type_name == "Archer") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "FrostDragon" or unit1.type == "Archer")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };
    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);

    for (const auto &ally:ally_list) {
        if (!ally.can_atk) break;
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;
        for (const auto &enemy : enemy_list){//可以进攻则进入候选序列
            if (AiClient::canAttack(ally, enemy)){
                target_list.push_back(enemy);
            }
        }
        if (target_list.empty()) continue;//没有可以进攻的对象

        if (ally.type == "FrostDragon") {
            Pos tmp=miracle_pos;
            auto cmp_frost=[tmp](const Unit& x1,const Unit& x2){
                if(x1.type!=x2.type){
                    auto import=[tmp](const string &type_name){
                        if(type_name=="BlackBat"){
                            return 0;
                        }
                        if(type_name=="Priest"){
                            return 1;
                        }
                        else return 2;
                    };
                    if(import(x1.type)!=import(x2.type)){
                        return import(x1.type)<import(x2.type);
                    }
                }
                int dis1=cube_distance(x1.pos,tmp);
                int dis2=cube_distance(x2.pos,tmp);
                return dis1<dis2;
            };
            sort(target_list.begin(),target_list.end(),cmp_frost);
            attack(ally.id, target_list[0].id);


        } else if (ally.type == "Priest") {//牧师随意进攻
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "Archer") {
            sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list){
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            }
            if (suc) {
                continue;
            }
            while(canAttack(target_list[0],ally)&&(target_list[0].atk>=ally.hp)){
                target_list.erase(target_list.begin());
                if(target_list.empty()){
                    break;
                }
            }
            if(target_list.empty()){
                continue;
            }
            attack(ally.id, target_list[0].id);

        } else if (ally.type=="Inferno") {
            auto cmp_infer=[](const Unit & x1,const Unit& x2){
                if(x1.type!=x2.type){
                    auto import=[](string a){
                        if(a=="Archer"){
                            return 1;
                        }
                        if(a=="Priest"){
                            return 2;
                        }
                        return 3;
                    };
                    return import(x1.type)<import(x2.type);
                }
                return x1.atk<x2.atk;
            };
            sort(target_list.begin(),target_list.end(),cmp_infer);
            attack(ally.id,target_list[0].id);
        }
    }
}

void AI::march()
{
    //处理生物的移动

    /*
     * 先动所有牧师，尽可能向敌方神迹移动，牧师的移动单独处理，相互之间距离不超过3
     * 调用最初召唤的弓箭手占领目标驻扎点，放弃其余所有驻扎点
     * 冰龙分出属性，攻击属性尽可能向神迹移动，防守属性尽可能靠近己方弓箭手,有牧师的情况下优先向牧师靠拢
     * 弓箭手躲避近身的敌人并优先进行防守，也可以考虑掩护我方攻击冰龙和蝙蝠，有牧师的情况下优先向牧师靠拢
     * 【进阶】一味向敌方神迹移动并不一定是个好主意
     * 在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
     * 如果采用其他生物组合，可以考虑抢占更多驻扎点
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {
            if (type_name == "Priest") return 0;
            else if (type_name == "Archer") return 1;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
    vector<Unit>my_priest;
    for(auto e:ally_list){
        if(e.type=="Priest"){
            my_priest.push_back(e);
        }
    }
    //获取敌方生物并进行针对性的分类
    auto enemy_list = getUnitsByCamp(my_camp^1);

    //先处理牧师的移动,目标地点满足：1.可以覆盖至少1个非牧师己方单位；2.尽可能靠近对方神迹；3.相互之间的距离不超过3
    for(const auto &ally : my_priest){
        auto reach_pos_with_dis = reachable(ally,map);
        vector<pair<Pos,int>> reach_pos_list;
        for(const auto &reach_pos : reach_pos_with_dis){
            for( auto pos:reach_pos){
                int tmp=0;
                auto units_list=units_in_range(pos,5,map,my_camp);
                for(auto x:units_list){
                    if(x.type!="Priest"&&x.can_move){
                        tmp++;
                    }
                    if((!x.can_move)&&(cube_distance(x.pos,pos)<=(ally.level>=2?3:2))){
                        tmp++;
                    }
                }
                pair<Pos,int>t(pos,tmp);
                reach_pos_list.push_back(t);
            }
        }
        if(reach_pos_list.empty()){
            continue;
        }
        auto cmp_pri=[this](const pair<Pos,int>& x1,const pair<Pos,int> &x2){
            if(x1.second==0){
                return false;
            }else if(x2.second==0){
                return true;
            }
            int dis1=cube_distance(x1.first,enemy_pos);
            int dis2=cube_distance(x2.first,enemy_pos);
            if(dis1!=dis2){
                return abs(dis1-3)<abs(dis2-3);
            }
            if(x1.second!=x2.second){
                return x1.second>x2.second;
            }
            return false;
        };
        sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_pri);
        move(ally.id,reach_pos_list[0].first);
    }

    for (const auto &ally : ally_list) {
        if (!ally.can_move){
            continue;//已经攻击过即不能再移动
        }
        if (ally.type=="Archer"){
            
            bool on_barrack = false;
            for (const auto &barrack:map.barracks)
                if (ally.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }
            if (on_barrack) continue;

            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则向前推进,避免进入敌方单位的攻击区域
            //如果对方有单位进入可攻击到我方神迹的位置，走到可以攻击此单位的位置。
            if (getUnitByPos(target_barrack, false).id == -1) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                bool fight=0;
                for(const auto& e:enemy_list){
                    int dis=cube_distance(e.pos,miracle_pos);
                    if(e.atk_range[0]<=dis&&dis<=e.atk_range[1]){//如果有敌方单位可以攻击到神迹，弓箭手准备前往清理
                        vector<Pos>target_pos;
                        for(auto tmp_pos:reach_pos_list){
                            int dis2=getDistanceOnGround(tmp_pos,e.pos,my_camp);
                            if(ally.atk_range[0]<=dis2&&dis2<=ally.atk_range[1]){
                                target_pos.push_back(tmp_pos);
                            }
                        }
                        if(target_pos.empty()){
                            continue;
                        }
                        nth_element(target_pos.begin(),target_pos.begin(),target_pos.end(),
                            [this](Pos& x1,Pos& x2){
                                int xx=units_in_range(x1,2,map,my_camp^1).size();
                                int yy=units_in_range(x2,2,map,my_camp^1).size();
                                return xx<yy;
                        });
                        fight=1;
                        move(ally.id, target_pos[0]);
                        break;
                    }
                }
                if(fight){
                    continue;
                }else{
                    if(reach_pos_list.empty()){
                        continue;
                    }
                    //弓箭手原则，1.被牧师覆盖，2.尽可能靠近对方神迹(距离3-4)
                    auto cmp_ar=[this](const Pos& x1,const Pos& x2){
                        auto list1=units_in_range(x1,3,map,my_camp);
                        auto list2=units_in_range(x2,3,map,my_camp);
                        bool num1=0,num2=0;
                        for(auto e:list1){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num1=1;
                                    break;
                                }
                                else if(cube_distance(x1,e.pos)<=2){
                                    num1=1;
                                    break;
                                }
                            }
                        }
                        for(auto e:list2){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num2=1;
                                    break;
                                }else if(cube_distance(x2,e.pos)<=2){
                                    num2=1;
                                    break;
                                }
                            }
                        }
                        if(num1!=num2){
                            return num1>num2;
                        }
                        int dis1=cube_distance(x1,enemy_pos);
                        int dis2=cube_distance(x2,enemy_pos);
                        return abs(dis1-3) < abs(dis2-3);
                    };
                    sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_ar);
                    move(ally.id, reach_pos_list[0]);
                }
            }
        }else if(ally.type=="FrostDragon"){
            int judge=0;
            std::tie(std::ignore,judge,std::ignore)=target_barrack;
            if(judge>0){//示意图中红线
                int tmp=0;
                std::tie(tmp,std::ignore,std::ignore)=ally.pos;
                //获取所有可到达的位置
                auto reach_pos_with_dis = reachable(ally, map);
                //压平
                vector<Pos> reach_pos_list;
                for (const auto &reach_pos : reach_pos_with_dis) {
                    for (auto pos : reach_pos){
                        reach_pos_list.push_back(pos);
                    }
                }
                if (reach_pos_list.empty()) continue;
                if(tmp>=0){//此冰龙属于进攻梯队，尽可能向神迹移动同时躲避弓箭手,寻求牧师的庇护
                    auto cmp_fd=[this](const Pos& x1,const Pos& x2){
                        auto list1=units_in_range(x1,3,map,my_camp);
                        auto list2=units_in_range(x2,3,map,my_camp);
                        bool num1=0,num2=0;
                        for(auto e:list1){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num1=1;
                                    break;
                                }
                                else if(cube_distance(x1,e.pos)<=2){
                                    num1=1;
                                    break;
                                }
                            }
                        }
                        for(auto e:list2){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num2=1;
                                    break;
                                }else if(cube_distance(x2,e.pos)<=2){
                                    num2=1;
                                    break;
                                }
                            }
                        }
                        if(num1!=num2){
                            return num1>num2;
                        }
                        int dis1=cube_distance(x1,enemy_pos);
                        int dis2=cube_distance(x2,enemy_pos);
                        return dis1<dis2;
                    };
                    sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_fd);
                    move(ally.id, reach_pos_list[0]);
                }else{//此冰龙属于防守梯队，在有牧师的情况下尽可能靠近离神迹近的敌人
                    int mind=20;
                    Pos target;
                    for(auto tar:enemy_list){
                        if(cube_distance(tar.pos,miracle_pos)<mind){
                            target=tar.pos;
                            mind=cube_distance(tar.pos,miracle_pos);
                        }
                    }
                        
                    auto cmp_fd2=[this,target](const Pos&x1,const Pos&x2){
                        auto units1=units_in_range(x1,3,map,my_camp);
                        auto units2=units_in_range(x2,3,map,my_camp);
                        bool num1=0,num2=0;
                        for(auto e:units1){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num1=1;
                                    break;
                                }
                                else if(cube_distance(x1,e.pos)<=2){
                                    num1=1;
                                    break;
                                }
                            }
                        }
                        for(auto e:units2){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num2=1;
                                    break;
                                }else if(cube_distance(x2,e.pos)<=2){
                                    num2=1;
                                    break;
                                }
                            }
                        }
                        if(num1!=num2){
                            return num1>num2;
                        }
                        return cube_distance(target,x1)<cube_distance(x2,target);
                    };
                    sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_fd2);
                    move(ally.id,reach_pos_list[0]);
                }
            }else if(judge<0){//示意图中蓝线
                int tmp=0;
                std::tie(tmp,std::ignore,std::ignore)=ally.pos;
                //获取所有可到达的位置
                auto reach_pos_with_dis = reachable(ally, map);
                //压平
                vector<Pos> reach_pos_list;
                for (const auto &reach_pos : reach_pos_with_dis) {
                    for (auto pos : reach_pos){
                        reach_pos_list.push_back(pos);
                    }
                }
                if (reach_pos_list.empty()){
                    continue;
                }
                if(tmp<=0){//此冰龙属于进攻梯队，尽可能向神迹移动同时躲避弓箭手
                    auto cmp_fd=[this](const Pos& x1,const Pos& x2){
                        auto list1=units_in_range(x1,3,map,my_camp);
                        auto list2=units_in_range(x2,3,map,my_camp);
                        bool num1=0,num2=0;
                        for(auto e:list1){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num1=1;
                                    break;
                                }
                                else if(cube_distance(x1,e.pos)<=2){
                                    num1=1;
                                    break;
                                }
                            }
                        }
                        for(auto e:list2){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num2=1;
                                    break;
                                }else if(cube_distance(x2,e.pos)<=2){
                                    num2=1;
                                    break;
                                }
                            }
                        }
                        if(num1!=num2){
                            return num1>num2;
                        }
                        int dis1=cube_distance(x1,enemy_pos);
                        int dis2=cube_distance(x2,enemy_pos);
                        return dis1<dis2;
                    };
                    sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_fd);
                    move(ally.id, reach_pos_list[0]);
                }else{//此冰龙属于防守梯队
                    int mind=20;
                    Pos target;
                    for(auto tar:enemy_list){
                        if(cube_distance(tar.pos,miracle_pos)<mind){
                            target=tar.pos;
                            mind=cube_distance(tar.pos,miracle_pos);
                        }
                    }
                        
                    auto cmp_fd2=[this,target](const Pos&x1,const Pos&x2){
                        auto units1=units_in_range(x1,3,map,my_camp);
                        auto units2=units_in_range(x2,3,map,my_camp);
                        bool num1=0,num2=0;
                        for(auto e:units1){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num1=1;
                                    break;
                                }
                                else if(cube_distance(x1,e.pos)<=2){
                                    num1=1;
                                    break;
                                }
                            }
                        }
                        for(auto e:units2){
                            if(e.type=="Priest"){
                                if(e.level>=2){
                                    num2=1;
                                    break;
                                }else if(cube_distance(x2,e.pos)<=2){
                                    num2=1;
                                    break;
                                }
                            }
                        }
                        if(num1!=num2){
                            return num1>num2;
                        }
                        return cube_distance(target,x1)<cube_distance(x2,target);
                    };
                    sort(reach_pos_list.begin(),reach_pos_list.end(),cmp_fd2);
                    move(ally.id,reach_pos_list[0]);
                }
            }
        }else if(ally.type=="Inferno"){//召唤物，向最近的敌方单位移动
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos){
                    reach_pos_list.push_back(pos);
                }
            }
            if (reach_pos_list.empty()) continue;

            int mind=20;
            Pos target=ally.pos;
            for(auto e:enemy_list){
                if(cube_distance(ally.pos,e.pos)<mind){
                    mind=cube_distance(ally.pos,e.pos);
                    target=e.pos;
                }
            }

            if(mind>=5){
                nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),
                [this](Pos _pos1,Pos _pos2){
                    return cube_distance(_pos1,enemy_pos)<cube_distance(_pos2,enemy_pos);
                });
                move(ally.id,reach_pos_list[0]);
            }else{
                nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),
                [this,target](Pos _pos1,Pos _pos2){
                    return cube_distance(_pos1,target)<cube_distance(_pos2,target);
                });
                move(ally.id,reach_pos_list[0]);
            }

            
        }
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

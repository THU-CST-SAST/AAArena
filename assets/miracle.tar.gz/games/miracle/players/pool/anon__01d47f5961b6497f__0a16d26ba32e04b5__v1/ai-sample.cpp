#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"


#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;


using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

std::ofstream fout("Xtian_debug.txt");

//用于计算价值时返回的策略信息 
struct My_option
{
    //0表示移动，1表示移动
    bool attack = 0;

    //表示不进行操作
    bool no_action = 1;

    //该策略的价值
    double value = 0;

    //敌人id
    int enemy_id = -1;

    //移动的目的坐标
    Pos tar_move = std::make_tuple(-1, -1, -1);

    Unit ally;

    My_option(bool Atk,bool No_action,double Value,int Enemy_id)
    {
        attack = Atk;
        no_action = No_action;
        value = Value;
        enemy_id = Enemy_id;
    }
    My_option(bool Atk,bool No_action,double Value,Pos Tar_move)
    {
        attack = Atk;
        no_action = No_action;
        value = Value;
        tar_move = Tar_move;
    }
    My_option(bool Atk,bool No_action,double Value)
    {
        attack = Atk;
        no_action = No_action;
        value = Value;
    }


    //如果策略1的价值大于策略2的价值，则为真
    static bool cmp(const My_option &opt1,const My_option &opt2)
    {
        return opt1.value > opt2.value;
    }

    // //命令执行顺序排序，
    // static bool cmp2(const My_option &opt1,const My_option &opt2)
    // {
    //     //优先处理攻击，再处理移动，同时优先处理攻击 蝙蝠>飞龙>弓箭手>else(地狱召唤物)
    //     if(opt1.attack && !opt2.attack)
    //     {
    //         return true;
    //     }
    //     else if(!opt1.attack && opt2.attack)
    //     {
    //         return false;
    //     }

    //     if (opt1.ally.type != opt2.ally.type) 
    //     {
            
    //         auto type_id_gen = [](const string &type_name) 
    //         {
    //             if (type_name == "BlackBat") return 0;
    //             else if (type_name == "Archer") return 1;
    //             else if (type_name == "VolcanoDragon") return 2;
    //             else return 3;
    //         };
    //         return (type_id_gen(opt1.ally.type) < type_id_gen(opt2.ally.type));
    //     } 

    //     //同种兵种比较，优先操作价值大的操作
    //     else 
    //     {
    //         return opt1.value < opt2.value;
    //     }

    //     /*
    //         my_artifacts = {"InfernoFlame"};
    //        my_creatures = {"Archer", "BlackBat", "VolcanoDragon"};
    //     */

    // }
};

void print_pos(std::ofstream &fout,std::tuple<int, int, int> mytuple)
{
    fout << "(" << std::get<0>(mytuple) << "," << std::get<1>(mytuple) << "," << std::get<2>(mytuple) << ")" ;
}
class AI : public AiClient
{
private:
    Pos miracle_pos;

    //敌人神殿的位置
    Pos enemy_pos;
    
    //目标驻扎点位置
    Pos target_barrack;

    Pos tar;

    Pos posShift(Pos pos, string direct);

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动

    void step1();

    void step2();

    void step3();


    //造兵策略函数，传入步骤以及可选项
    void buildman(int step, int opt);

    //移动策略函数，传入步骤以及可选项
    void moveman(int step, int opt);

    //攻击策略函数，传入步骤以及可选项
    void attackman(int step, int opt);

    //行动函数，判断攻击以及移动的value并调用相应的策略。
    void actionman(int step, int opt);

    void try_use_arti();

    //检查所处尖端函数，返回值为所处的阶段
    int check_stage();

    My_option value_evaluation(Unit ally);

    My_option battle__evaluation(Unit ally,Pos p);

    My_option move__evaluation(Unit ally,Pos p);

    void play_ori();
};


void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * artifacts和creatures可以修改
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "BlackBat", "VolcanoDragon"};
    init();
}

My_option AI::value_evaluation(Unit ally)
{
        /*
        评价该目标的行动：

        对敌方单位的攻击行动：
            1.如果能够攻击并击杀敌方目标，则价值加上对方的cost
            2.若能够攻击但不能击杀，则加上对方星级*对方损失生命力/对方目前生命值。
            3.若对方能够反击，导致己方会死亡，则减去己方cost，若受伤，则减去己方cost*对方攻击力/己方目前生命值
            4.*若敌方攻击范围内有无法反击的友方英雄，并且能够击杀友方，则加上友方cost。
            5.若敌方攻击若敌方攻击范围内有无法反击的友方英雄，但不能击杀友方，则加上友方cost*敌方攻击力/友方血量
            6.若敌方为牧师，并且周围有喷火龙，剑士或者召唤物，则加上2*牧师光环范围内的对方该三种兵种的数量
            7.攻击神殿的value为己方攻击力。
        进行移动：
            1.如果在对方射程但己方无法反击，但移动之后不在攻击范围，则加上己方cost。
            2.如果在对方射程但己方无法反击，但移动之后受到的每一个攻击均可以反击，则加上该位置攻击行动的value。
            3.如果移动之后与target的距离更近了，则加上距离的缩短量*0.2，远离则减去。
        */

        //生成初始的策略vector

        if(!ally.can_atk)
        {
            return move__evaluation(ally,ally.pos);
        }
        else
        {
            My_option a = battle__evaluation(ally, ally.pos);
            My_option b = move__evaluation(ally, ally.pos);
            if(a.value > b.value)
            {
                return a;

            }
            else
            {
                return b;
            }
        }

};

My_option AI::battle__evaluation(Unit ally,Pos p)
{
        /*评价该目标的行动：
        对敌方单位的攻击行动：
        0.如果存在能够攻击自己但无法反击的敌人val-己方cost，若不死则减去己方cost*对方攻击力/己方目前生命值
        1.如果能够攻击并击杀敌方目标，则价值加上对方的cost
        2.若能够攻击但不能击杀，则加上对方星级*对我方攻击力/对方目前生命值。若有圣盾，则加上对方攻击力/对方目前生命值。
        3.若对方能够反击，导致己方会死亡，则减去己方cost，若受伤，则减去己方cost*对方攻击力/己方目前生命值
        4.*若敌方攻击范围内有无法反击的友方英雄，并且能够击杀友方，则加上友方cost。
        5.*若敌方攻击范围内有无法反击的友方英雄，但不能击杀友方，则加上友方cost*敌方攻击力/友方血量
        6.若敌方为牧师，并且周围有喷火龙，剑士或者召唤物，则加上2*牧师光环范围内的对方该三种兵种的数量
        7.攻击神殿的value为己方攻击力。
        */


        //利用Pos重建ally
        ally.pos = p;

        //得到对方单位列表与己方的单位列表
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        auto ally_list = getUnitsByCamp(my_camp);

        //生成初始的策略vector
        vector<My_option> opt_list;

        double init_val = 0;

        //0.如果存在能够攻击自己但无法反击的敌人，则下调初始的估价val
        for (const auto &enemy : enemy_list)
        {
            if (AiClient::canAttack(enemy, ally) && !AiClient::canAttack(ally, enemy))
            {
                //若对方的攻击能导致己方死亡
                if(enemy.atk > ally.hp && !ally.holy_shield)
                {
                    init_val = init_val - ally.cost;
                }   
                //如果己方不会死亡
                else if(!enemy.holy_shield)
                {
                    init_val = init_val - ally.cost * enemy.atk / ally.hp;
                }
            }
        }


        //遍历对方单位
        for (const auto &enemy : enemy_list)
        {
            double tem_val = init_val;

            //如果能够被我方攻击到
            if (AiClient::canAttack(ally, enemy))
            {
                

                //1.如果能够击杀
                if(ally.atk >= enemy.hp && !enemy.holy_shield)
                {
                    tem_val = tem_val + enemy.cost;
                }
                //如果没有圣盾但不能击杀
                else if(!enemy.holy_shield)
                {
                    tem_val = tem_val + enemy.cost * ally.atk / enemy.hp;
                }
                //如果有圣盾
                else
                {
                    tem_val = tem_val + enemy.atk / enemy.hp;
                }



                //2.如果对方能够反击
                if(AiClient::canAttack(enemy,ally))
                {
                    //若反击能导致己方死亡
                    if(enemy.atk > ally.hp && !ally.holy_shield)
                    {
                        tem_val = tem_val - ally.cost;
                    }
                    //如果己方没有圣盾但不能被反击击杀,有圣盾的情况下val不减少
                    else if(!enemy.holy_shield)
                    {
                        tem_val = tem_val - ally.cost * enemy.atk / ally.hp;
                    }
                }
                

                //3.如果对方攻击范围内有无法反击的友方其他单位
                for (const auto &a : ally_list)
                {
                    if (AiClient::canAttack(enemy, a) && !AiClient::canAttack(a, enemy))
                    {
                        //若对方的攻击能导致己方死亡
                        if(enemy.atk > a.hp && !a.holy_shield)
                        {
                            tem_val = tem_val + a.cost;
                        }   
                        //如果己方不会死亡
                        else if(!enemy.holy_shield)
                        {
                            tem_val = tem_val + a.cost * enemy.atk / a.hp;
                        }
                    }
                }


                //4.如果对方是牧师,则val加上牧师光环范围内三种肉兵种的数量*2
                if(enemy.type == "Priest")
                {
                    int cnt = 0;
                    for (const auto &e : enemy_list)
                    {
                        if(e.type == "VolcanoDragon" ||  e.type == "Inferno" || e.type == "Swordsman")
                        {
                            if(cube_distance(e.pos, enemy.pos) <= 2)
                            {
                                cnt++;
                            }
                        }
                    }
                    tem_val = tem_val + 2 * cnt;
                }

                //将策略加入策略队列
                opt_list.push_back(My_option(true, false, tem_val, enemy.id));

            }

        }

        if(opt_list.empty())
        {
            fout << ally.type << " id:" << ally.id << "can't atk" << std::endl;

            //将不行动的策略返回
            return My_option(false, true, init_val);
        }

        //价值大的排在前面
        sort(opt_list.begin(), opt_list.end(), My_option::cmp);

        fout << ally.type << " id:" << ally.id << "best atk tar is id:" <<opt_list[0].enemy_id<<getUnitById(opt_list[0].enemy_id).type<< std::endl;
        fout << "val is " << opt_list[0].value << std::endl;

        return opt_list[0];
}

My_option AI::move__evaluation(Unit ally_ori,Pos p)
{
    /*
    进行移动：
        1.如果在对方射程但己方无法反击，但移动之后不在攻击范围，则加上己方cost。
        2.如果在对方射程但己方无法反击，但移动之后受到的每一个攻击均可以反击，则加上该位置攻击行动的value。
        3.如果移动之后与target的距离更近了，则加上距离的缩短量*0.2，远离则减去。
    */

    Unit ally = ally_ori;

    //对于该士兵进行阶段校验，阶段1则进攻驻扎点，阶段2则进攻神殿。
    int stage = check_stage();

    fout <<"stage is :"<< stage << std::endl;

    //rate越大，越倾向于前往能够攻击更多人的地方而不是进行攻击
    double rate_dis = 0.08;

    //记录原始的与目标兵营的位置    
    int ori_dis = cube_distance(ally.pos, target_barrack);
    //记录原始点与目标神殿的最佳攻击位置
    int ori_dis_2 = abs(cube_distance(ally.pos, enemy_pos) - ally.atk_range[0]);

    //储存待比较的指令
    vector<My_option> opt_list;

    //得到对方单位列表与己方的单位列表
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    auto ally_list = getUnitsByCamp(my_camp);

    

    //如果不能动直接返回
    if(!ally.can_move)
    {
        return My_option(false, true, 0);
    }

    double init_val = 0;

    //对不进行移动的价值进行计算
    for (const auto &enemy : enemy_list)
    {
        if (AiClient::canAttack(enemy, ally) && !AiClient::canAttack(ally, enemy))
        {
            //若对方的攻击能导致己方死亡
            if(enemy.atk > ally.hp && !ally.holy_shield)
            {
                init_val = init_val - ally.cost;
            }   
            //如果己方不会死亡
            else if(!enemy.holy_shield)
            {
                init_val = init_val - ally.cost * enemy.atk / ally.hp;
            }
        }
    }
    opt_list.push_back(My_option(false, true, init_val));



    auto reach_pos_with_dis = calculator::reachable(ally, map);
    //得到压平的可达路径reach_pos_list
    vector<Pos> reach_pos_list;
    for(const auto & reach_pos : reach_pos_with_dis)
    {
        for(const auto & pos: reach_pos)
        {
            reach_pos_list.push_back(pos);
        }
    }
    //对所有可达点进行遍历
    for(const auto & pos : reach_pos_list)
    {
        //跳过非法位置
        if(pos == enemy_pos )
        {
            continue;
        }
        double tem_val = 0;
        int min_hp = ally.hp;

        //假设位置
        ally.pos = pos;

        //对所有敌人遍历
        for(const auto & enemy : enemy_list)
        {


            //如果我能达打到但是对方打不到，则加对方cost
            if(AiClient::canAttack(ally, enemy) && !AiClient::canAttack(enemy, ally))
            {
                //蝙蝠不尝试寻找优势攻击位置
                if(!ally.flying)
                {
                    tem_val += rate_dis * enemy.cost;

                }     
            }

            //如果对方打得到我但是我打不到对方
            if(!AiClient::canAttack(ally, enemy) && AiClient::canAttack(enemy, ally))
            {
                tem_val -= (ally.cost * enemy.atk / ally.hp);
                min_hp -= enemy.atk;

                //若会阵亡，则直接返回
                if(min_hp <= 0)
                {
                    // fout << "trig!!!!!!!!will dead" << std::endl;
                    tem_val = -ally.cost;
                    break;

                    // return My_option(false, false, 0 - ally.cost, pos);

                }
            }

            //如果互相能够打到
            if(AiClient::canAttack(ally, enemy) && AiClient::canAttack(enemy, ally))
            {
                //如果能打死
                if(ally.atk >= enemy.hp && !enemy.holy_shield )
                {
                    tem_val += rate_dis * enemy.cost;
                }
                //如果不能打死
                else
                {
                    tem_val += (rate_dis * enemy.cost * ally.atk / enemy.hp);
                }

                //如果能被打死
                if(enemy.atk >= ally.hp && !ally.holy_shield )
                {
                    tem_val -=  ally.cost;
                }
                //如果不能被打死
                else
                {
                    tem_val -= (ally.cost * enemy.atk / ally.hp);
                }

            }

            
        }

        if(stage == 1 && !ally.flying)
        {
            //地面兵种优先级更高
            //加上与目标点之间距离缩短量*1
            tem_val += 1*(ori_dis - cube_distance(ally.pos, target_barrack));


            fout << "ground unit move tar val is " << 1 * (ori_dis - cube_distance(ally.pos, target_barrack)) << std::endl;
        }
        else if(stage == 1 && ally.flying)
        {
            //空中兵种阶段1如果驻扎点有人则优先攻击驻扎点，否则优先攻击神殿
            if(getUnitByPos(target_barrack,false).id!=-1 && getUnitByPos(target_barrack,false).camp == my_camp ^1)
            {
                // fout << "tar_bar!!!!" << std::endl;
                tem_val += 1 * (ori_dis - cube_distance(ally.pos, target_barrack));
            }
            else
            {
                tem_val += 0.3*(ori_dis_2 - abs(cube_distance(ally.pos, enemy_pos)-ally.atk_range[0]));
            }
            
        }
        else if(stage == 2)
        {
    
            //阶段2的情况下，尽可能攻击神殿
            if(ally.flying)
            {
                tem_val += 0.3*(ori_dis_2 - abs(cube_distance(ally.pos, enemy_pos)-ally.atk_range[0]));

            }
            
            else
            {
                tem_val += 0.3*(ori_dis_2 - abs(cube_distance(ally.pos, enemy_pos)-ally.atk_range[0]));

            }
            if(ally.flying)
            {
                // fout << "蝙蝠第二阶段的优先移动值" << 0.3 * (ori_dis_2 - abs(cube_distance(ally.pos, enemy_pos) - ally.atk_range[0])) << std::endl;
                // fout << "蝙蝠第二阶段的总val为" << tem_val << std::endl;
                // fout << "蝙蝠第二阶段的tar和神殿位置为";
                // print_pos(fout,ally.pos);
                // print_pos(fout,enemy_pos);
                // fout << std::endl<<std::endl;
            }
        }
        
        //尽可能保持占领，将所有的移动价值降低
        if(cube_distance(ally_ori.pos, target_barrack) == 0 && !ally.flying)
        {
            tem_val -= ally.cost*0.99;
        }

        // fout << "dis_val is" << 3 * (ori_dis - cube_distance(ally.pos, target_barrack)) << std::endl;

        
        opt_list.push_back(My_option(false, false, tem_val, pos));

    }
    if(opt_list.empty())
    {
        return My_option(false, true, 0);
    }
    else
    {
        //价值大的排在前面
        sort(opt_list.begin(), opt_list.end(), My_option::cmp);

        // fout << ally.type << " id:" << ally.id << "  best move tar is :";
        // print_pos(fout, opt_list[0].tar_move);
        // fout << "  val is " << opt_list[0].value << std::endl;

        return opt_list[0];
    }

}


void AI::try_use_arti()
{
    //神器能用就用
    if (players[my_camp].mana >= players[my_camp].artifact[0].cost && players[my_camp].artifact[0].state == "Ready") {
        auto pos_list = all_pos_in_map();
        auto best_pos = pos_list[0];
        int best_val = -9999;
        for (auto pos:pos_list) 
        {
            int tem_val = 0;
            if (!(cube_distance(pos, miracle_pos) <= 7 || cube_distance(pos, target_barrack) <= 5))
            {
                continue;
            }
            auto unit_list = units_in_range(pos, 2, map, my_camp ^1);
            for(const auto & enm:unit_list)
            {
                if(enm.hp <= 2)
                {
                    tem_val += enm.cost;
                }
            }
            //减去与对方的距离*2 (步长为3)
            tem_val -= (6*((cube_distance(enemy_pos, pos)+1)/3));
            fout << "dis_val_arti = " << (3 * ((cube_distance(enemy_pos, pos) + 1) / 3)) << std::endl;
            if (tem_val > best_val)
            {
                best_val = tem_val;
                best_pos = pos;
            }


        }
        fout << "best_val = " << best_val << std::endl;

        //使用神器的阈值
        if(best_val >= (0-6))
        {
            use(players[my_camp].artifact[0].id, best_pos);
        }
        
    }
}
void AI::actionman(int step,int opt)
{

    //攻击神殿的val阈值，
    double threshold = 0.5;




    //得到操作的单元列表
    auto ally_list = getUnitsByCamp(my_camp);

    //优先处理攻击，再处理移动，同时优先处理攻击 蝙蝠>飞龙>弓箭手>else(地狱召唤物)
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.type != unit2.type) 
        {
            //火山龙>剑士>弓箭手
            auto type_id_gen = [](const string &type_name) 
            {
                if (type_name == "BlackBat") return 0;
                else if (type_name == "VolcanoDragon") return 1;
                else if (type_name == "Archer") return 2;
                else return 3;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } 

        //同种兵种比较，优先操作低攻击力兵种？
        else if (unit1.type == "Archer" or unit1.type == "VolcanoDragon")
        {
            return unit2.atk < unit1.atk;
        }
            
        else 
        {
            return unit1.atk < unit2.atk;
        }
    };

    

    //储存准备移动的单位列表
    auto ally_list_move = getUnitsByCamp(my_camp);

    //按顺序排列好单位，依次行动
    sort(ally_list.begin(), ally_list.end(), cmp);



    //一轮迭代对攻击列表处理
    for (const auto &ally : ally_list)
    {
        My_option fin_option = value_evaluation(ally);

        //如果不攻击的话则稍后在处理
        if(!fin_option.attack)
        {
            ally_list_move.push_back(ally);

            continue;
        }


        if(fin_option.attack)
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            attack(ally.id, fin_option.enemy_id);
            fout << "my" << ally.type << " id:" << ally.id << " option is :" << "atk"  << std::endl;
        }
        else if(!fin_option.no_action)
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            move(ally.id, fin_option.tar_move);

        }
        else
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            fout << "my" << ally.type << " id:" << ally.id << " option is :" << "stay"  << std::endl;
        }

    }


    //对移动列表再处理
    sort(ally_list_move.begin(), ally_list_move.end(), cmp);
    for (const auto &ally : ally_list_move)
    {
        My_option fin_option = value_evaluation(ally);

        if(fin_option.attack)
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            attack(ally.id, fin_option.enemy_id);
            fout << "my" << ally.type << " id:" << ally.id << " option is :" << "atk"  << std::endl;
        }
        else if(!fin_option.no_action)
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            move(ally.id, fin_option.tar_move);
            fout << "my" << ally.type << " id:" << ally.id << " option is :" << "move"  << std::endl;
            fout << "蝙蝠第二阶段的tar为";
            print_pos(fout, fin_option.tar_move);
            fout << std::endl;
        }
        else
        {
            int dis = cube_distance(ally.pos, enemy_pos);
            //判断小于0.5就攻击神殿
            if (fin_option.value <= threshold && ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            {
                attack(ally.id,my_camp ^ 1);
                fout << "my" << ally.type << " id:" << ally.id << " option is :" << "攻击神殿"  << std::endl;
                continue;
            }
            fout << "my" << ally.type << " id:" << ally.id << " option is :" << "stay"  << std::endl;
        }

    }
    return;

}
void AI::buildman(int step,int opt)
{
    // fout << "come in to the buildman" << std::endl;
    //第一阶段
    if(step == 1)
    {
        // fout << "step1" << std::endl;
        //先手第一回合，召唤弓箭手
        if(opt == 0)
        {
            fout << "opt =0" << std::endl;
            //用于储存于目标最近的空闲出兵点
            auto B_list = getSummonPosByCamp(my_camp);
            auto tem_barrack = B_list[0];
            for(const auto &Pos_barrack:B_list)
            {
                if (cube_distance(enemy_pos, Pos_barrack) <
                cube_distance(enemy_pos, tem_barrack))

                //确定地面无人
                if(getUnitByPos(Pos_barrack, false).id == -1)
                {
                    tem_barrack = Pos_barrack;
                }  
            }
            //派出一星弓兵
            summon("Archer", 1,tem_barrack);   
            fout << "summon Archer 1" << std::endl;

        }
        //后手第一回合，或者先手第二回合，召唤大蝙蝠
        if(opt == 1 || opt ==2)
        {
            // fout << "opt =1 or 2" << std::endl;
            //用于储存于目标最近的空闲出兵点
            

            auto B_list = getSummonPosByCamp(my_camp);
            auto tem_barrack = B_list[0];
            fout << "B_list length :" <<B_list.size()<< std::endl;

            print_pos(fout,posShift(miracle_pos, "IF"));
            //中间三个是兵营
            print_pos(fout,posShift(miracle_pos, "SF"));
            print_pos(fout,posShift(miracle_pos, "FF"));
            print_pos(fout,posShift(miracle_pos, "SB"));
            //
            print_pos(fout,posShift(miracle_pos, "IB"));




            // fout << "init_dis is  :" <<cube_distance(enemy_pos, tem_barrack)<< std::endl;
            // fout << "tar is  " ;
            // print_pos(fout,posShift(miracle_pos, "IF"));
            // fout << std::endl;
            // fout << "init is  " ;
            // print_pos(fout,tem_barrack);
            // fout << std::endl;


            for(const auto &Pos_barrack:B_list)
            {
                // fout << "for loop pos is "<<std::endl ;
                print_pos(fout,Pos_barrack);
                // fout << "loop dis is   :" <<cube_distance(enemy_pos, Pos_barrack)<< std::endl;

                fout<<checkBarrack(Pos_barrack)<<std::endl;

                if (cube_distance(enemy_pos, Pos_barrack) <
                cube_distance(enemy_pos, tem_barrack))
                {
                    fout << std::endl;
                    //  << "come to if " <<std::endl;

                    //确定空中无人
                    if(getUnitByPos(Pos_barrack, true).id == -1)
                    {
                        // fout << "now is " ;
                        // print_pos(fout,tem_barrack);
                        // fout << std::endl;

                        tem_barrack = Pos_barrack;

                        // fout << "now change to " ;
                        // print_pos(fout,tem_barrack);
                        // fout << std::endl;

                        // fout << "tar is  " ;
                        // print_pos(fout,posShift(miracle_pos, "IF"));
                        // fout << std::endl;

                    }  
                }

                
            }
            print_pos(fout,tem_barrack);
            print_pos(fout, posShift(miracle_pos, "SB"));
            //派出二星蝙蝠
            summon("BlackBat", 2, tem_barrack);   
            fout << "summon BlackBat 2" << std::endl;

        }
        //后手第二回合，召唤二星弓箭兵
        if(opt == 3)
        {
            // fout << "opt =3" << std::endl;
            //用于储存于目标最近的空闲出兵点
            auto B_list = getSummonPosByCamp(my_camp);
            auto tem_barrack = B_list[0];
            for(const auto &Pos_barrack:B_list)
            {
                if (cube_distance(enemy_pos, Pos_barrack) <
                cube_distance(enemy_pos, tem_barrack))

                //确定地面无人
                if(getUnitByPos(Pos_barrack, false).id == -1)
                {
                    tem_barrack = Pos_barrack;
                }  
            }
            //派出二星弓箭兵
            summon("Archer", 2, tem_barrack);   
            fout << "summon Archer 2" << std::endl;

        }
        if(opt == 4)
        {
            // fout << "opt =3" << std::endl;
            //用于储存于目标最近的空闲出兵点
            auto B_list = getSummonPosByCamp(my_camp);
            auto tem_barrack = B_list[0];
            for(const auto &Pos_barrack:B_list)
            {
                if (cube_distance(enemy_pos, Pos_barrack) <
                cube_distance(enemy_pos, tem_barrack))

                //确定地面无人
                if(getUnitByPos(Pos_barrack, false).id == -1)
                {
                    tem_barrack = Pos_barrack;
                }  
            }
            //能派啥就派啥Archer, BlackBat, VolcanoDragon
            summon("VolcanoDragon", 3, tem_barrack);
            summon("BlackBat", 3, tem_barrack);
            summon("Archer", 3, tem_barrack);
            summon("VolcanoDragon", 2, tem_barrack);
            summon("BlackBat", 2, tem_barrack);
            summon("Archer", 2, tem_barrack);
            summon("VolcanoDragon", 1, tem_barrack);
            summon("BlackBat", 1, tem_barrack);
            summon("Archer", 1, tem_barrack); 
            // fout << "summon Archer 2" << std::endl;

        }
    }
}

void AI::moveman(int step,int opt)
{
    fout << "come into move man" << std::endl;
    if(step == 1)
    {
        fout << "step1" << std::endl;
        if(opt == 0)
        {
            fout << "opt1" << std::endl;
            //获得所有可以操作的单位
            auto ally_list = getUnitsByCamp(my_camp);
            for(const auto &my_man:ally_list)
            {
                if(my_man.can_move)
                {
                    auto reach_pos_with_dis = calculator::reachable(my_man, map);
                    //得到压平的可达路径
                    vector<Pos> reach_pos_list;
                    for(const auto & reach_pos : reach_pos_with_dis)
                    {
                        for(const auto & pos: reach_pos)
                        {
                            reach_pos_list.push_back(pos);
                        }
                    }
                    if(reach_pos_list.size()>0)
                    {
                        Pos tar_move = reach_pos_list[0];
                        //得到与目标兵营最近的可达点
                        for(const auto & pos : reach_pos_list)
                        {
                            if (cube_distance(target_barrack, pos) <
                            cube_distance(target_barrack, tar_move))
                            tar_move = pos;
                        }
                        fout << "move" << std::endl;
                        print_pos(fout, tar_move);
                        fout << std::endl;
                        move(my_man.id, tar_move);
                    }

                    
                }
            }
        }

    }

}
void AI::step1()
{
    // fout << "come in to the step1 fuc" << std::endl;
    if (round == 0 || round == 1) {
        //先确定自己的基地、对方的基地
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;


        //设定目标驻扎点为对方最近的驻扎点
        target_barrack = map.barracks[0].pos;
        //确定离对方基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) 
        {
            if (cube_distance(enemy_pos, barrack.pos) <
                cube_distance(enemy_pos, target_barrack))
                {
                    target_barrack = barrack.pos;
                    //tar保留为出兵点
                    tar = barrack.pos;

                }
                
        }

        //如果先手
        if(my_camp == 0)
        {
            fout << "Pre and ready to call buildman " << std::endl;
            buildman(1, 0);
        }
        //如果后手
        else
        {
            fout << "Post and ready to call buildman " << std::endl;
            buildman(1, 1);
        }
    }
    if (round == 2 || round == 3) 
    {
        //如果先手
        if(my_camp == 0)
        {
            buildman(1, 2);
        }
        //如果后手
        else
        {
            buildman(1, 3);
        }
        actionman(1, 0);

    }

    else
    {
        try_use_arti();
        buildman(1, 4);
        actionman(1, 0);

    }
    return;
}

int AI::check_stage()
{
    //如果目标驻扎点上有我方单位，则进入阶段2，否则则停留在阶段1
    if(getUnitByPos(target_barrack,false).id!=-1 && getUnitByPos(target_barrack,false).camp == my_camp)
    {
        fout << "come into the stage 2??" << std::endl;
        return 2;
    }
    else
    {
        return 1;
    }
}
void AI::play()
{
   //采用分步骤法不断按照既定步骤完成，校验目前所处的步骤并进行相应的决定。
   //op1:先进攻劣势路的对方兵营，使用蝙蝠取得制空权，再使用弓兵压制并占领。
   /*
   大致步骤：
   1.根据先后手判断，在第一第二回合召唤2费弓箭兵与3费蝙蝠或者三费蝙蝠与4费弓箭兵。
   2.判断目标出兵点是否被占领，未被占领则出兵占领。若已占领则进入下一步。
   3.压制对方神殿出兵点并攻击神殿
   */

   fout << "come into AI logic " << std::endl;
   step1();
   fout << "end my turn " << std::endl;

   endRound();
}


void AI::play_ori()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    在费用较低时尽可能召唤星级为1的兵，优先度剑士>弓箭手>火山龙
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */
    if (round == 0 || round == 1) {
        //先确定自己的基地、对方的基地
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        // 在正中心偏右召唤一个弓箭手，用来抢占驻扎点
        summon("Archer", 1, posShift(miracle_pos, "SF"));
    } else {
        //神器能用就用，选择覆盖单位数最多的地点
        if (players[my_camp].mana >= 6 && players[my_camp].artifact[0].state == "Ready") {
            auto pos_list = all_pos_in_map();
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            use(players[my_camp].artifact[0].id, best_pos);
        }

        //之后先战斗，再移动
        battle();

        march();

        //最后进行召唤
        //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
        auto summon_pos_list = getSummonPosByCamp(my_camp);
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
        });
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
        }

        //统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个剑士、1个弓箭手、1个火山龙的顺序召唤
        int mana = players[my_camp].mana;
        auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;

        vector<string> summon_list;
        //剑士和弓箭手数量不足或者格子不足则召唤火山龙
        if ((available_summon_pos_list.size() == 1 || available_count["Swordsman"] + available_count["Archer"] < 2) &&
            mana >= CARD_DICT.at("VolcanoDragon")[1].cost && available_count["VolcanoDragon"] > 0) {
            summon_list.emplace_back("VolcanoDragon");
            mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
        }

        bool suc = true;
        while (mana >= 2 && suc) {
            suc = false;
            if (available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[1].cost) {
                summon_list.emplace_back("Swordsman");
                mana -= CARD_DICT.at("Swordsman")[1].cost;
                available_count["Swordsman"] -= 1;
                suc = true;
            }
            if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[1].cost) {
                summon_list.emplace_back("Archer");
                mana -= CARD_DICT.at("Archer")[1].cost;
                available_count["Archer"] -= 1;
                suc = true;
            }
            if (available_count["VolcanoDragon"] > 0 && mana >= CARD_DICT.at("VolcanoDragon")[1].cost) {
                summon_list.emplace_back("VolcanoDragon");
                mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
                available_count["VolcanoDragon"] -= 1;
                suc = true;
            }
        }

        int i = 0;
        for (auto pos:available_summon_pos_list) {
            if (i == summon_list.size()) break;
            summon(summon_list[i], 1, pos);
            ++i;
        }
    }
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 火山龙：攻击高>低 （大AOE输出），随机攻击
     * 剑士：攻击低>高 打消耗，优先打攻击力低的
     * 弓箭手：攻击高>低 优先打不能反击的攻击力最高的，其次打能反击的攻击力最低的
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 例如占领着驻扎点的敌方生物具有极高的价值，优先摧毁可以使敌方下回合损失很多可用出兵点
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */

    auto ally_list = getUnitsByCamp(my_camp);

    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//火山龙>剑士>弓箭手
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "VolcanoDragon") return 0;
                else if (type_name == "Swordsman") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "VolcanoDragon" or unit1.type == "Archer")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };
    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (const auto &ally:ally_list) {
        if (!ally.can_atk) break;
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;
        for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(ally, enemy))
                target_list.push_back(enemy);
        if (target_list.empty()) continue;
        if (ally.type == "VolcanoDragon") {
            default_random_engine g(static_cast<unsigned int>(time(nullptr)));
            int tar = uniform_int_distribution<>(0, target_list.size() - 1)(g);
            attack(ally.id, target_list[tar].id);
        } else if (ally.type == "Swordsman") {
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "Archer") {
            sort(enemy_list.begin(), enemy_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list)
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue;
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        }
    }
    //最后攻击神迹
    ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (auto ally : ally_list) {
        if (!ally.can_atk) break;
        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }
}

void AI::march()
{
    //处理生物的移动

    /*
     * 先动所有剑士，尽可能向敌方神迹移动
     * 若目标驻扎点上没有地面单位，则让弓箭手向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 然后若目标驻扎点上没有地面单位，则让火山之龙向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 【进阶】一味向敌方神迹移动并不一定是个好主意
     * 在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
     * 如果采用其他生物组合，可以考虑抢占更多驻扎点
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {
            if (type_name == "Swordsman") return 0;
            else if (type_name == "Archer") return 1;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
    for (const auto &ally : ally_list) {
        if (!ally.can_move) continue;
        if (ally.type == "Swordsman") {
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
            //优先走到距离敌方神迹更近的位置
            nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                        [this](Pos _pos1, Pos _pos2) {
                            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                        });
            move(ally.id, reach_pos_list[0]);
        } else {
            //如果已经在兵营就不动了
            bool on_barrack = false;
            for (const auto &barrack:map.barracks)
                if (ally.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }
            if (on_barrack) continue;

            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则走到
            if (getUnitByPos(target_barrack, false).id == -1) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        }
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

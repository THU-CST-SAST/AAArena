#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"
#include "evaluator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

//#define MEW

#ifdef MEW
#define trace(x) std::cerr << #x" = " << x << std::endl
#else
#define trace(x) 0
#endif

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;
using calculator::cube_point_reachable;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
using std::pair;
using std::make_pair;

Evaluator e, _e;

class map_array
{
public:
	int cache[40][40], tag[40][40] = {0}, tim = 1;
	map_array(){};
	void clear()
	{
		tim++;
	}
	int get(Pos p)
	{
		if(tag[std::get<0>(p)+20][std::get<1>(p)+20]==tim)
			return cache[std::get<0>(p)+20][std::get<1>(p)+20];
		return 0;
	}
	inline void addEq(int x,int y,int v)
	{
		if(tag[x][y]!=tim)
		{
			tag[x][y] = tim;
			cache[x][y] = 0;
		}
		cache[x][y] += v;
	}
	void rangeAdd(Pos p,int r,int v)
	{
		const static int dx[] = {-1,-1, 0,+1,+1, 0};
		const static int dy[] = {+1, 0,-1,-1, 0,+1};
		int x = std::get<0>(p)+20+r;
		int y = std::get<1>(p)+20;
		if(r==0)
		{
			addEq(x,y,v);
			return;
		}
		for(int d=0;d<6;d++) for(int k=1;k<=r;k++)
		{
			addEq(x,y,v);
			x += dx[d];
			y += dy[d];
		}
	}
};

class AI : public AiClient
{
private:
	Pos miracle_pos;
	Pos enemy_pos;
	Pos target_barrack[2];
	Pos central[2];
	Pos posShift(Pos pos, string direct, int x=1);
	map_array damage_suffer_array1, damage_suffer_array2, heal_received_array, barrack_array;

	double unit_eval(const Unit &u)
	{
		double s = 1.0;
		int r = u.atk_range[1];
		if(u.type[0]=='P') r = 3;
		if(u.type[0]=='A') r = 4;
		if(u.camp==my_camp&&u.type[0]=='A'&&u.level<3&&players[my_camp].max_mana>=6) s *= 0.1;
		if(u.camp==my_camp&&u.type[0]=='S'&&u.level==1&&players[my_camp].max_mana>=4) s *= 0.1;
		s *= u.cool_down*0.33;
		s *= u.hp>0?0.8+u.hp*0.2/u.max_hp:0;
		if(cube_distance(u.pos,map.miracles[u.camp^1].pos)<=u.atk_range[1]+u.max_move)
			s *= 1.2;
		if(cube_distance(u.pos,map.miracles[u.camp^1].pos)<=u.atk_range[1])
			s *= 1.5;
		s *= 0.99+0.01*(1.6
			-std::ceil(std::abs(cube_distance(u.pos,map.miracles[u.camp^1].pos)-r)/(double)u.max_move)*0.4/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp^1])/(double)u.max_move)*0.03/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp])/(double)u.max_move)*0.04/5
			-std::log(1+std::ceil(cube_distance(u.pos,central[u.camp^1])/(double)r)*r/15.0)*0.2
			);
		return s;
	}
	double unit_eval2(const Unit &u)
	{
		double s = 1.0;
		s *= (3+u.atk)*0.1;
		if(cube_distance(u.pos,map.miracles[u.camp^1].pos)<=u.atk_range[1]+u.max_move)
			s *= 1.2;
		if(cube_distance(u.pos,map.miracles[u.camp^1].pos)<=u.atk_range[1])
			s *= 1.5;
		s *= 1.4
			-std::ceil(std::abs(cube_distance(u.pos,map.miracles[u.camp^1].pos)-u.atk_range[1])/(double)u.max_move)*1.2/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp^1])/(double)u.max_move)*0.03/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp])/(double)u.max_move)*0.04/5;
		return s;
	}
	double unit_eval3(const Unit &u)
	{
		double s = 1.0;
		s *= u.cool_down*0.33;
		s *= u.hp>0?0.8+u.hp*0.2/u.max_hp:0;
		s *= 0.99+0.01*(1.6
			-std::ceil(std::abs(cube_distance(u.pos,map.miracles[u.camp^1].pos)-u.atk_range[1])/(double)u.max_move)*0.2/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp^1])/(double)u.max_move)*0.03/5
			-std::ceil(cube_distance(u.pos,target_barrack[u.camp])/(double)u.max_move)*0.04/5
			-(cube_distance(u.pos,central[u.camp])/(double)u.max_move)*0.2/5
			);
		return s*2;
	}
	double unit_atk_eval(int u,int atk)
	{
		if(u<2)
		{
			if(map.miracles[my_camp^1].hp<=max_miracle_damage) return atk*1e6;
			int delta_hp = map.miracles[my_camp].hp-map.miracles[my_camp^1].hp;
			return delta_hp<=0?atk*1.1:atk;
		}
		Unit u0, u1;
		u0 = u1 = getUnitById(u);
		if(u0.holy_shield) return 0;
		u1.hp = std::max(u1.hp-atk,0);
		return unit_eval(u0)-unit_eval(u1);
	}
	double unit_atk_eval(const Unit &u0,int atk)
	{
		if(u0.holy_shield) return 0;
		Unit u1;
		u1 = u0;
		u1.hp = std::max(u1.hp-atk,0);
		return unit_eval(u0)-unit_eval(u1);
	}
	double unit_combat_eval(int u,const Unit &atker,int atk)
	{
		if(u<2)
		{
			if(map.miracles[my_camp^1].hp<=max_miracle_damage) return atk*1e6;
			int delta_hp = map.miracles[my_camp].hp-map.miracles[my_camp^1].hp;
			return delta_hp<=0?atk*1.1:atk;
		}
		Unit u0, u1, v1;
		u0 = u1 = getUnitById(u);
		u1.hp = std::max(u1.hp-(u0.holy_shield?0:atk),0);
		if(canAttack(u0,atker))
		{
			v1 = atker;
			v1.hp = std::max(v1.hp-(v1.holy_shield?0:u0.atk),0);
			return unit_eval(u0)-unit_eval(u1)-(unit_eval(atker)-unit_eval(v1));
		}
		return unit_eval(u0)-unit_eval(u1);
	}
	double unit_combat_eval(const Unit &u0,const Unit &atker,int atk)
	{
		Unit u1, v1;
		u1 = u0;
		u1.hp = std::max(u1.hp-(u0.holy_shield?0:atk),0);
		if(canAttack(u0,atker))
		{
			v1 = atker;
			v1.hp = std::max(v1.hp-(v1.holy_shield?0:u0.atk),0);
			return unit_eval(u0)-unit_eval(u1)-(unit_eval(atker)-unit_eval(v1));
		}
		return unit_eval(u0)-unit_eval(u1);
	}
	int damage_suffer_eval(const Unit &u, Pos p, const Evaluator &e)
	{
		Unit w = u;
		w.pos = p;
		int s = 0;
		for (const auto &enemy : e.enemy_list)
			if (AiClient::canAttack(enemy, w))
			{
				s += enemy.atk;
				if(s>u.hp) break;
			}
		return s;
	}
	Pos get_central(vector<Unit> ally_list)
	{
		double x = 0, y = 0, z = 0, w = 0;
		for(auto u: ally_list)
		{
			double k = std::exp(unit_eval2(u));
			if(u.flying) k *= 0.2;
			x += get<0>(u.pos)*k;
			y += get<1>(u.pos)*k;
			z += get<2>(u.pos)*k;
			w += k;
		}
		if(w!=0)
		{
			x = x/w+0.5;
			y = y/w+0.5;
			z = z/w+0.5;
		}
		return make_tuple((int)x,(int)y,(int)z);
	}
	/*double damage_suffer_eval2(const Unit &u, Pos p, const Evaluator &e)
	{
		if(damage_suffer_tag[std::get<0>(p)+20][std::get<1>(p)+20]==damage_suffer_time)
			return damage_suffer_cache[std::get<0>(p)+20][std::get<1>(p)+20];
		damage_suffer_tag[std::get<0>(p)+20][std::get<1>(p)+20] = damage_suffer_time
		return damage_suffer_cache[std::get<0>(p)+20][std::get<1>(p)+20] = damage_suffer_eval(u,p,e);
	}*/
	

	Evaluator current_e, best_e;
	double best_eval;
	double search_width;
	int max_targets, max_miracle_damage;

public:
	void chooseCards();
	void play(); 
	//void battle(); //处理生物的战斗
	//void march(); //处理生物的移动
	void search(int i);
	double eval();
	//
	int get_max_targets(const Evaluator &current_e);
	void eval_search_targets(int i);
	void pre_move();
	//

	Evaluator get_evaluator()
	{
		Evaluator s;
		s.ally_list = getUnitsByCamp(my_camp);
		s.enemy_list = getUnitsByCamp(my_camp ^ 1);
		max_miracle_damage = 0;
		for(auto &ally : s.ally_list)
		{
			ally.ori_atk = CARD_DICT.at(ally.type)[ally.level].atk;
			s.enemy_inrange.push_back(vector<int>());
			for(auto enemy : s.enemy_list) if(canAttack(ally,enemy))
				s.enemy_inrange.back().push_back(enemy.id);
			int dis = cube_distance(ally.pos, enemy_pos);
			if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
			{
				s.enemy_inrange.back().push_back(my_camp^1);
				max_miracle_damage += ally.atk;
			}
			if(s.enemy_inrange.back().size()>0)
			{
				search_width *= 2;
				/*int a = ally.ori_atk;
				auto cmp = [a](const int &unit1, const int &unit2) {
					return unit_atk_eval(unit1,a)>unit_atk_eval(unit2,a);
				};
				sort(s.back().begin(), s.back().end(), cmp);*/
			}
			ally.atk = ally.ori_atk;
		}
		max_targets = get_max_targets(s);
		return s;
	}
};

void AI::chooseCards()
{
	my_artifacts = {"SalamanderShield"};
	my_creatures = {"Swordsman", "Archer", "Priest"};
	init();
}

double AI::eval()
{
	damage_suffer_array1.clear();
	damage_suffer_array2.clear();
	heal_received_array.clear();
	barrack_array.clear();

	for(auto barrack : map.barracks)
	{	
		if(barrack.camp!=my_camp)
			barrack_array.rangeAdd(barrack.pos,0,70);
		else 
			for(auto enemy : current_e.enemy_list) if(!enemy.flying&&enemy.hp>0)
				if(cube_point_reachable(enemy,barrack.pos,current_e,map));
					barrack_array.rangeAdd(barrack.pos,0,75);
	}
	vector<Unit> enemy_archer = {}, enemy_sword = {}, enemy_al = {};
	//for(int i=1;i<=2;i++) enemy_sword[i].clear();
	for(auto enemy : current_e.enemy_list) if(enemy.hp>0) enemy_al.push_back(enemy);
	for(auto enemy : current_e.enemy_list) if(enemy.atk&&enemy.hp>0)
	{
		if(enemy.type=="Swordsman") //for(int i=1;i<=enemy.level;i++)
			enemy_sword.push_back(enemy);
		for(int i=enemy.flying?enemy.atk_range[0]:2;i<=enemy.atk_range[1];i++)
			damage_suffer_array1.rangeAdd(enemy.pos,i,enemy.atk);
		if(enemy.type!="Archer") 
		{
			for(int i=enemy.atk_range[0];i<=enemy.atk_range[1];i++)
				damage_suffer_array2.rangeAdd(enemy.pos,i,enemy.atk);
		}
		else enemy_archer.push_back(enemy);
	}
	for(auto ally : current_e.ally_list) if(ally.type=="Priest"&&ally.hp>0)
		for(int i=0;i<=(ally.level==1?2:3);i++)
			heal_received_array.rangeAdd(ally.pos,i,1);
	double res = 0;
	for(auto &ally : current_e.ally_list) if(ally.hp>0)
	{
		vector<Pos> pos_list = {ally.pos};
		if(ally.to_atk==0&&ally.type!="Priest") pos_list = cube_reachable(ally,current_e,map);
		Pos best_pos = pos_list[0];
		double best_v = -1e9;
		int is_archer = (ally.type=="Archer");
		int hp_tmp = ally.hp;
		for(Pos pos : pos_list)
		{
			double v = 0;
			int hp_remain = std::min(ally.hp+heal_received_array.get(pos),ally.max_hp);
			hp_remain -= (is_archer?damage_suffer_array2:damage_suffer_array1).get(pos);
			if(hp_remain<=0) hp_remain = 0;
			else
			{
				ally.pos = pos;
				ally.hp = hp_remain;
				ally.atk = ally.ori_atk+heal_received_array.get(pos);
				v = 1e9;
				if(is_archer)
				{		
					for(auto enemy : enemy_al) if(canAttack(ally,enemy))
					//for(auto enemy : enemy_archer) if(canAttack(ally,enemy))
						v = std::min(v,unit_combat_eval(enemy,ally,ally.atk));
				}
				else
				{
					for(auto enemy : enemy_al) if(canAttack(ally,enemy))
					{
					//for(auto enemy : enemy_sword) if(canAttack(ally,enemy))
						v = std::min(v,unit_combat_eval(enemy,ally,ally.atk));
					}
				}
				if(v>=1e9) v = 0;
				if(v>0) v *= 0.3;
				v += unit_eval(ally);
				v += barrack_array.get(pos)*0.01;
			}
			ally.hp = hp_tmp;
			if(v>best_v)
			{
				best_v = v;
				best_pos = pos;
			}
		}
		ally.moving_value = best_v-unit_eval(ally);
		ally.pos = best_pos;
	}
	for(auto ally : current_e.ally_list) if(ally.hp>0) res += ally.moving_value;
	for(auto ally : current_e.ally_list) if(ally.hp>0) res += unit_eval(ally);
	for(auto enemy : current_e.enemy_list) if(enemy.hp>0) res -= unit_eval(enemy);
	int delta_hp = map.miracles[my_camp].hp-map.miracles[my_camp^1].hp;
	res += map.miracles[my_camp^1].hp<=0?1e9:(delta_hp<=0?delta_hp*1.1:delta_hp);
	return res;
}

void AI::pre_move()
{
	for(auto &ally : current_e.ally_list) if(ally.type=="Priest"&&ally.to_atk==0)
	{
		vector<Unit> atker_list = {};
		for(int i=0;i<current_e.ally_list.size();i++) if(current_e.ally_list[i].to_atk)
		//if(current_e.enemy_inrange[i].size()>0)
		{
			int a = current_e.ally_list[i].atk;
			double v0 = 0, v1 = 0, k0 = 1e9, k1 = 1e9;
			for(auto target : current_e.enemy_inrange[i])
			{
				v0 = std::max(v0,unit_atk_eval(target,a));
				v1 = std::max(v1,unit_atk_eval(target,a+1));
				k0 = std::min(k0,unit_combat_eval(target,current_e.ally_list[i],a));
				k1 = std::min(k1,unit_combat_eval(target,current_e.ally_list[i],a+1));
			}
			if(current_e.enemy_inrange.size()==1) k1 = k0 = 0;
			if(v1+k1>v0+k0)
			{
				current_e.ally_list[i].atker_value = (v1-v0)+(k1-k0);
				atker_list.push_back(current_e.ally_list[i]);
			}
		}
		vector<Pos> pos_list = cube_reachable(ally,current_e,map);
		Pos best_pos = pos_list[0];
		double best_v = -1e9;
		for(Pos pos : pos_list)
		{
			Unit tmp = ally;
			tmp.hp = std::max(0,tmp.hp-damage_suffer_eval(tmp,pos,current_e));
			tmp.pos = pos;
			double v = unit_eval3(tmp);//(unit_eval(tmp)-unit_eval(ally))*2.0;
			for(auto atker : atker_list)
			{
				int dis = cube_distance(pos, atker.pos);
				if (1 <= dis && dis <= (ally.level>=2?3:2))
					v += atker.atker_value;
			}
			if(v>best_v)
			{
				best_v = v;
				best_pos = pos;
			}
		}
		ally.pos = best_pos;
		for(auto &atker : current_e.ally_list)
		{
			int dis = cube_distance(ally.pos, atker.pos);
				if (1 <= dis && dis <= (ally.level>=2?3:2))
					atker.atk++;
		}
	}
	for(int i=0;i<current_e.ally_list.size();i++) if(current_e.enemy_inrange.size()>0)
	{
		Unit u = current_e.ally_list[i];
		auto cmp = [this,u](const int &unit1, const int &unit2) {
			return unit_combat_eval(unit1,u,u.atk)>unit_combat_eval(unit2,u,u.atk);
		};
		sort(current_e.enemy_inrange[i].begin(), current_e.enemy_inrange[i].end(), cmp);
	}
}

int AI::get_max_targets(const Evaluator &current_e)
{
	//if(current_e.ally_list.size()==current_e.enemy_inrange.size()) return 1;
	for(int s=2;s<=10;s++)
	{
		double c = 1;
		for(int i=0;i<current_e.ally_list.size();i++)
			c *= std::min((int)current_e.enemy_inrange[i].size(),s)+1;
		if(c>=5e5) return s-1;
	}
	return 1;
}

void AI::eval_search_targets(int i)
{
	if(i>=current_e.ally_list.size())
	{
		Evaluator tmp = current_e;
		double v = eval();
		if(v>best_eval)
		{
			best_eval = v;
			best_e = current_e;
		}
		current_e = tmp;
		return;
	}
	if(!current_e.ally_list[i].to_atk)
	{
		eval_search_targets(i+1);
		return;
	}
	int cnt = 0;
	for(int k=0;cnt<max_targets&&k<current_e.enemy_inrange[i].size();k++)
	{
		//if(current_e.enemy_inrange[i][k].hp<=0) continue;
		current_e.ally_list[i].target_id = current_e.enemy_inrange[i][k];
		current_e.ally_list[i].target_index = -1;
		int u;
		for(u=0;u<current_e.enemy_list.size();u++) 
			if(current_e.enemy_list[u].id==current_e.enemy_inrange[i][k])
			{
				current_e.ally_list[i].target_index = u;
				break;
			}
		if(u<current_e.enemy_list.size()&&current_e.enemy_list[u].hp<=0) continue;
		++cnt;
		int shield = current_e.enemy_list[u].holy_shield;
		if(u<current_e.enemy_list.size())
		{
			if(canAttack(current_e.enemy_list[u],current_e.ally_list[i]))
				current_e.ally_list[i].hp -= current_e.enemy_list[u].atk;
			if(!shield)
				current_e.enemy_list[u].hp -= current_e.ally_list[i].atk;
			current_e.enemy_list[u].holy_shield = 0;
		}
		else
		{
			map.miracles[my_camp^1].hp -= current_e.ally_list[i].atk;
		}
		eval_search_targets(i+1);
		if(u<current_e.enemy_list.size())
		{
			current_e.enemy_list[u].holy_shield = shield;
			if(!shield)
				current_e.enemy_list[u].hp += current_e.ally_list[i].atk;
			if(canAttack(current_e.enemy_list[u],current_e.ally_list[i]))
				current_e.ally_list[i].hp += current_e.enemy_list[u].atk;
		}
		else
		{
			map.miracles[my_camp^1].hp += current_e.ally_list[i].atk;
		}
	}
}

void AI::search(int i)
{
	if(i>=current_e.ally_list.size())
	{
		Evaluator tmp = current_e;
		pre_move();
		eval_search_targets(0);
		current_e = tmp;
		return;
	}
	for(int atk=0;atk<=current_e.enemy_inrange[i].size()&&atk<=1;atk++)
	{
		current_e.ally_list[i].to_atk = atk;
		//if(atk) current_e.atker_list.push_back(current_e.ally_list[i]);
		search(i+1);
		//if(atk) current_e.atker_list.pop_back();
	}
}

void AI::play()
{
	trace(round);
	if (round == 0 || round == 1) {
		//先确定自己的基地、对方的基地
		miracle_pos = map.miracles[my_camp].pos;
		enemy_pos = map.miracles[my_camp ^ 1].pos;
		//设定目标驻扎点为最近的驻扎点

		for(int camp=0;camp<2;camp++)
		{	
			target_barrack[camp] = map.barracks[0].pos;
			//确定离自己基地最近的驻扎点的位置
			for (const auto &barrack:map.barracks) {
				if (cube_distance(map.miracles[camp].pos, barrack.pos) <
					cube_distance(map.miracles[camp].pos, target_barrack[camp]))
					target_barrack[camp] = barrack.pos;
			}
		}

		// 在正中心偏右召唤一个弓箭手，用来抢占驻扎点
		summon("Swordsman", 1, posShift(posShift(miracle_pos, "SF"),"IF"));
	} else {
		//神器能用就用，选择覆盖单位数最多的地点

		if (players[my_camp].mana >= 6 && players[my_camp].artifact[0].state == "Ready") {
			double max_benefit = -1e9;
			int target_id = -1;
			for(auto ally : getUnitsByCamp(my_camp))
			{
				double v = unit_eval(ally);
				if(v>max_benefit&&ally.type!="Priest"&&ally.level==3)
				{
					max_benefit = v;
					target_id = ally.id;
				}
			}
			if(target_id!=-1) use(players[my_camp].artifact[0].id, target_id);
		}
		
		central[0] = get_central(getUnitsByCamp(0));
		central[1] = get_central(getUnitsByCamp(1));
		current_e = best_e = get_evaluator();
		//endRound();return;
		best_eval = -1e9;
		search_width = 1;
		search(0);
		for(auto ally : best_e.ally_list) if(ally.type=="Priest"&&ally.to_atk==0)
			move(ally.id,ally.pos);
		for(auto ally : best_e.ally_list) if(ally.to_atk)
			attack(ally.id,ally.target_id);
		for(auto ally : best_e.ally_list) if(ally.type!="Priest"&&ally.to_atk==0)
			move(ally.id,ally.pos);

		//最后进行召唤 
		//将所有本方出兵点按照到xx的距离排序，从近到远出兵
		auto summon_pos_list = getSummonPosByCamp(my_camp);
		Pos target_pos = central[my_camp^1];//enemy_pos;
		/*double worst = 0;
		for(auto enemy : getUnitsByCamp(my_camp^1))
		{
			double v = unit_eval(enemy);
			if(v>worst) worst = v, target_pos = enemy.pos;
		}*/
		sort(summon_pos_list.begin(), summon_pos_list.end(), [this,target_pos](Pos _pos1, Pos _pos2) {
			return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
		});
		vector<Pos> available_summon_pos_list;
		for (auto pos:summon_pos_list) {
			auto unit_on_pos_ground = getUnitByPos(pos, false);
			if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
		}

		//统计各个生物的可用数量
		int mana = players[my_camp].mana;
		auto deck = players[my_camp].creature_capacity;
		::map<string, int> available_count, enemy_count, ally_count;
		for (const auto &card_unit:deck)
			available_count[card_unit.type] = card_unit.available_count;
		for (const auto &card_unit:players[my_camp].creature_capacity)
		{
			enemy_count[card_unit.type] = -1;
			ally_count[card_unit.type] = 0;
		}
		for (const auto &card_unit:players[my_camp^1].creature_capacity)
			enemy_count[card_unit.type] = 0;

		int cnt2 = 0;
		for(auto ally : getUnitsByCamp(my_camp))
		{
			ally_count[ally.type]++;
			if(ally.type=="Swordsman"&&ally.level==2) ++cnt2;
		}
		for(auto enemy : getUnitsByCamp(my_camp^1)) enemy_count[enemy.type]++;

		vector< pair<string,int> > summon_list;
		int max_level = players[my_camp].max_mana>=6?3:(players[my_camp].max_mana>=4?2:1);

		bool suc = true;
		while (suc) {
			suc = false;
			while (enemy_count["Archer"]>ally_count["Archer"] && available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[max_level].cost) {
				summon_list.emplace_back(make_pair("Archer",max_level));
				mana -= CARD_DICT.at("Archer")[max_level].cost;
				available_count["Archer"] -= 1;
				ally_count["Archer"] += 1;
				suc = true;
			}
			int sword_level = max_level;
			if(ally_count["Priest"]>2&&max_level==3)
				sword_level = 2;
			while (enemy_count["Swordsman"]>ally_count["Swordsman"] && cnt2*2<std::max(6,ally_count["Swordsman"]) && available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[sword_level].cost) {
				summon_list.emplace_back(make_pair("Swordsman",sword_level));
				mana -= CARD_DICT.at("Swordsman")[sword_level].cost;
				available_count["Swordsman"] -= 1;
				ally_count["Swordsman"] += 1;
				if(sword_level==2) ++cnt2;
				suc = true;
			}
			while (enemy_count["Swordsman"]>ally_count["Swordsman"] && available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[max_level].cost) {
				summon_list.emplace_back(make_pair("Swordsman",max_level));
				mana -= CARD_DICT.at("Swordsman")[max_level].cost;
				available_count["Swordsman"] -= 1;
				ally_count["Swordsman"] += 1;
				if(max_level==2) ++cnt2;
				suc = true;
			}
			if (enemy_count["Archer"]==-1 && ally_count["Priest"]>=1 && available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[max_level].cost) {
				summon_list.emplace_back(make_pair("Archer",max_level));
				mana -= CARD_DICT.at("Archer")[max_level].cost;
				available_count["Archer"] -= 1;
				ally_count["Archer"] += 1;
				suc = true;
			}
			if (available_count["Priest"] > 0 && mana >= CARD_DICT.at("Priest")[2].cost) {
				summon_list.emplace_back(make_pair("Priest",2));
				mana -= CARD_DICT.at("Priest")[2].cost;
				available_count["Priest"] -= 1;
				ally_count["Priest"] += 1;
				suc = true;
			}
			while (cnt2*2<std::max(6,ally_count["Swordsman"]) && available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[sword_level].cost) {
				summon_list.emplace_back(make_pair("Swordsman",sword_level));
				mana -= CARD_DICT.at("Swordsman")[sword_level].cost;
				available_count["Swordsman"] -= 1;
				ally_count["Swordsman"] += 1;
				if(sword_level==2) ++cnt2;
				suc = true;
			}
			while (available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[max_level].cost) {
				summon_list.emplace_back(make_pair("Swordsman",max_level));
				mana -= CARD_DICT.at("Swordsman")[max_level].cost;
				available_count["Swordsman"] -= 1;
				ally_count["Swordsman"] += 1;
				if(max_level==2) ++cnt2;
				suc = true;
			}
			if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[3].cost) {
				summon_list.emplace_back(make_pair("Archer",3));
				mana -= CARD_DICT.at("Archer")[3].cost;
				available_count["Archer"] -= 1;
				ally_count["Archer"] += 1;
				suc = true;
			}
		}

		int i = 0;
		for (auto pos:available_summon_pos_list) {
			if (i == summon_list.size()) break;
			summon(summon_list[i].first, summon_list[i].second, pos);
			++i;
		}
	}
	endRound();
}

Pos AI::posShift(Pos pos, string direct, int x)
{
	/*
	 * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
	 * 本段代码可以自由取用
	 * @param pos:  (x, y, z)
	 * @param direct: 一个str，含2个字符，意义见注释
	 * @return: 移动后的位置 (x', y', z')
	 */
	transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
	if (my_camp == 0) {
		if (direct == "FF")  //正前方
			return make_tuple(get<0>(pos) + x, get<1>(pos) - x, get<2>(pos));
		else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
			return make_tuple(get<0>(pos) + x, get<1>(pos), get<2>(pos) - x);
		else if (direct == "IF")  //劣势路前方
			return make_tuple(get<0>(pos), get<1>(pos) + x, get<2>(pos) - x);
		else if (direct == "BB")  //正后方
			return make_tuple(get<0>(pos) - x, get<1>(pos) + x, get<2>(pos));
		else if (direct == "SB")  //优势路后方
			return make_tuple(get<0>(pos), get<1>(pos) - x, get<2>(pos) + x);
		else if (direct == "IB")  //劣势路后方
			return make_tuple(get<0>(pos) - x, get<1>(pos), get<2>(pos) + x);
	} else {
		if (direct == "FF")  //正前方
			return make_tuple(get<0>(pos) - x, get<1>(pos) + x, get<2>(pos));
		else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
			return make_tuple(get<0>(pos) - x, get<1>(pos), get<2>(pos) + x);
		else if (direct == "IF")  //劣势路前方
			return make_tuple(get<0>(pos), get<1>(pos) - x, get<2>(pos) + x);
		else if (direct == "BB")  //正后方
			return make_tuple(get<0>(pos) + x, get<1>(pos) - x, get<2>(pos));
		else if (direct == "SB")  //优势路后方
			return make_tuple(get<0>(pos), get<1>(pos) + x, get<2>(pos) - x);
		else if (direct == "IB")  //劣势路后方
			return make_tuple(get<0>(pos) + x, get<1>(pos), get<2>(pos) - x);
	}
}

int main()
{
	std::ifstream datafile("Data.json");
	json all_data;
	datafile>>all_data;
	card::get_data_from_json(all_data);

	AI player_ai;
	player_ai.chooseCards();
	while (true) {
		player_ai.updateGameInfo();
		player_ai.play();
	}
	return 0;
}

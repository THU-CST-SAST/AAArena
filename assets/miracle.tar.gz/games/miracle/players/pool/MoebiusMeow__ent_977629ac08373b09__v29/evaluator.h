#ifndef EVALUATOR_H
#define EVALUATOR_H

#include "gameunit.h"

struct Evaluator
{
	std::vector< gameunit::Unit> ally_list, enemy_list;
	std::vector< std::vector<int> > enemy_inrange;
};

#endif
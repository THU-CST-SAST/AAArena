#include "ai_client.h"
#include "card.h"
#include "gameunit.h"
#include "calculator.h"
#include <tuple>
//tocode line 231 确定弓箭手的移动方式
//debug line 332
#include <random>
#include <time.h>
using gameunit::Pos;//点坐标 
using gameunit::Unit;//单位
Pos Archer_hide[3];//弓箭手驻扎点
using calculator::cube_distance;//返回两点距离
using calculator::all_pos_in_map;//地图中所有位置？
using calculator::reachable;
using calculator::cube_reachable;//返回一个包含所有可到达点坐标的容器（已经剔除所有障碍）
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
typedef struct{
Pos position;
bool vacant;
} summon_pos;
class AI : public AiClient
{
private:
Pos miracle_pos;
Pos posShift(Pos pos, string direct);
 Pos enemy_pos;
 Pos target_barrack;
public:
    //选择初始卡组
    void chooseCards()
    {
        // artifacts和creatures可以修改
        my_artifacts = {"InfernoFlame"};
        my_creatures = {"Archer", "Swordsman", "VolcanoDragon"};//已做修改
        init();
    }
    void battle();
    void play();
    void march();
    void _summon();
    void use_artifact();
};
Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::play(){
if(round==1||round==0){
    //确定神迹位置
      miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
}
Archer_hide[1]=posShift(posShift(posShift(posShift(miracle_pos,"FF"),"FF"),"IF"),"IF");
Archer_hide[0]=posShift(posShift(posShift(posShift(miracle_pos,"FF"),"IF"),"IF"),"IF");
Archer_hide[2]=posShift(posShift(posShift(posShift(miracle_pos,"FF"),"FF"),"FF"),"SF");
summon("Swordsman", 1, posShift(miracle_pos, "SF"));
}
//todo先判断是否用神器
use_artifact();
//攻击
battle();//已初步完成
//移动
march();//初步完成
_summon();

endRound();
}

void AI::march(){//思路：弓箭手走位，剑士切弓箭手，龙推家
auto ally_list = getUnitsByCamp(my_camp);
auto enemy_list=getUnitsByCamp(my_camp^1);
sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {//弓箭手先动
            if (type_name == "Swordsman") return 1;
            else if (type_name == "Archer") return 0;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
if(round<=6&&!ally_list.empty()&&(getUnitByPos(target_barrack, false).id == -1)){
//获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally_list[0], map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
move(ally_list[0].id, reach_pos_list[0]);
return;
}//既定策略，让第一个剑士去抢占目标点
for(const Unit &obj:ally_list){
bool on_barrack=false;
for (const auto &barrack:map.barracks)
                if (obj.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }    
if(!obj.can_move||on_barrack)
continue;
if(obj.type=="Swordsman"||obj.type=="Inferno"){
Pos target_pos;
nth_element(enemy_list.begin(),enemy_list.begin(),enemy_list.end(),
[this,&obj](const Unit & _enemy1,const Unit & _enemy2){
if(_enemy1.type=="Archer"&&_enemy2.type=="Archer")
return cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
if(_enemy2.type=="Archer")
return false;
if(_enemy1.type=="Archer")
return true;
return    cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
});
if(cube_distance(obj.pos,enemy_list[0].pos)<cube_distance(obj.pos,enemy_pos))
target_pos=enemy_list[0].pos;
else target_pos=enemy_pos;
if(getUnitByPos(target_barrack, false).id == -1||getUnitByPos(target_barrack,false).camp!=my_camp)
target_pos=target_barrack;
   auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
move(obj.id, reach_pos_list[0]);
}else if(obj.type=="VolcanoDragon"){//火龙只推塔
Pos target_pos=enemy_pos;
 auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
move(obj.id, reach_pos_list[0]);
}


else if(obj.type=="Archer"){
/*bool is_being_attack=false;
for(const Unit &ar:enemy_list)
if(canAttack(ar,obj)){
 is_being_attack=true;
 break;   
}
Pos target_pos;

if(is_being_attack){//必须移动
auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
//code here
int i,tmp;
bool can_hide=false;
bool hide_vacant=false;
for(i=0;i<=2;i++){
    can_hide=true;
    if(getUnitByPos(Archer_hide[i],false).id!=-1){can_hide=false;
    continue;}
   for(const Unit &ar:enemy_list){
tmp=cube_distance(ar.pos,Archer_hide[i]);
if(tmp>=ar.atk_range[0]&&tmp<=ar.atk_range[1]&&ar.type!="Archer")//todo here
{can_hide=false;
continue;
}
}
if(can_hide) break;
}
if(can_hide){//需修改
target_pos=Archer_hide[i];
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
move(obj.id,reach_pos_list[0]);
continue;
}
else{//三个驻扎点都挨打
for(i=0;i<=2;i++)
if(getUnitByPos(Archer_hide[i],false).id==-1){
hide_vacant=true;
break;
}
if(hide_vacant){
    target_pos=Archer_hide[i];
sort(reach_pos_list.begin(),reach_pos_list.end(), [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);});
    bool can_go=false;                            
for(const auto& pos1:reach_pos_list){
    can_go=true;
    for(const Unit& ar:enemy_list)
    if(cube_distance(pos1,ar.pos)>=ar.atk_range[0]&&cube_distance(pos1,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
    }
    if(can_go){
    move(obj.id,pos1);
    break;
    }
}
if(can_go) continue;
Pos a=miracle_pos;//实在没办法就回神迹，待修改
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&a](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, a) < cube_distance(_pos2, a);
                            });
move(obj.id,reach_pos_list[0]);
continue;
}else{
target_pos=miracle_pos;
sort(reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });//优先回神迹
bool can_go;
for(const Pos& pos2:reach_pos_list){ 
   can_go=true ;
   for(const Unit& ar:enemy_list)
    if(cube_distance(pos2,ar.pos)>=ar.atk_range[0]&&cube_distance(pos2,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
    }
   if(can_go){
   move(obj.id,pos2);
   break;
   }
}
if(can_go) continue;
move(obj.id,reach_pos_list[0]);
continue;
}
}
}
else{//当前位置未被攻击，尽量不动
int j=0;
bool is_hide=false;
bool is_vacant=false;
auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
for(j=0;j<=2;j++)
if(obj.pos==Archer_hide[j]){
is_hide=true;
break;
}
if(is_hide) continue;
for(j=0;j<=2;j++){
    //is_vacant=false;
    if(getUnitByPos(Archer_hide[j],false).id==-1){
    is_vacant=true;
    break;
    }
}
if(!is_vacant){continue;}//debug
else{
j=0;    
target_pos=Archer_hide[j];
sort(reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
bool can_go=true;
for(const Pos& pos3:reach_pos_list){  
   can_go=true;  
  for(const Unit &ar:enemy_list)
  if(cube_distance(pos3,ar.pos)>=ar.atk_range[0]&&cube_distance(pos3,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
  }
  if(can_go) {move(obj.id,pos3);
  break;}
  }
continue;
}
}*/
}
}
return;
}

void AI::use_artifact(){
//code here

return;
}








void AI::battle(){//远战单位先攻击  龙>弓箭手>剑士
auto units=getUnitsByCamp(my_camp);//己方单位容器
auto cmp=[](const Unit &unit1, const Unit &unit2){
if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
            else if(unit1.type != unit2.type){
                auto type_id_gen = [](const string &type_name) {
                if (type_name == "VolcanoDragon") return 0;
                else if (type_name == "Swordsman") return 2;
                else return 1;};
                return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
            }
    else return false;//待修改
};
sort(units.begin(),units.end(),cmp);
for(const auto &obj:units ){
if(!obj.can_atk) break;
auto enemy_list = getUnitsByCamp(my_camp ^ 1);
vector<Unit> target_list;
 int dis = cube_distance(obj.pos, enemy_pos);
 bool can_attack_miracle=obj.atk_range[0] <= dis && dis <= obj.atk_range[1];
for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(obj, enemy))
                target_list.push_back(enemy);
if(target_list.empty()&&!can_attack_miracle) continue;
if(obj.type=="Archer"){
for(const auto &ar: enemy_list)
if(AiClient::canAttack(ar,obj)&&ar.type!="Archer")
goto end1;
sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });//攻击低的先打
for(const auto &ar:target_list)
if(!canAttack(ar,obj)&&ar.flying){//必须先打蝙蝠
attack(obj.id,ar.id);
goto end1;
}
if(can_attack_miracle){
    attack(obj.id, my_camp ^ 1);
    goto end1;//推塔
}
for(const auto &ar:target_list)
if(!canAttack(ar,obj)){
    attack(obj.id,ar.id);
goto end1;
}
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end1;
}
end1:
continue;
}else if(obj.type=="VolcanoDragon"){//target_list已经存储了可打击目标
//优先推塔
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}
sort(target_list.begin(),target_list.end(),[&obj](const Unit &_enemy1, 
const Unit &_enemy2){return cube_distance(obj.pos,_enemy1.pos)<cube_distance(obj.pos,_enemy2.pos);});//先打近目标
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end2;
}
end2:
continue;
}else if(obj.type=="Swordsman"){
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔

for(const auto &ar:target_list)
if(ar.type=="Archer"){
attack(obj.id,ar.id);
goto end3;
}
nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(obj.id, target_list[0].id);
end3:
continue;
}else if(obj.type=="Inferno"){
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔
sort(target_list.begin(),target_list.end(),[](const Unit &_enemy1, const Unit &_enemy2){return _enemy1.atk>_enemy2.atk;});
attack(obj.id,target_list[0].id);
continue;

}
}
return;
}

void AI::_summon(){
if(round<=6)
return;
int prim;//优先级
auto summon_pos_list = getSummonPosByCamp(my_camp);//可用出兵点
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
        });
        vector<Pos> available_summon_pos_list;//真正可以放兵的地点 且通过远近排序 前面离敌方基地最近 包括位置和是否用过
        //summon_pos tmp;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) {
                               available_summon_pos_list.push_back(pos);}
        }
int mana = players[my_camp].mana;//法力值
auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;//这是个映射记录当前可以放置单位的数量
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;
bool is_end=true;            
while(is_end){        
is_end=false;        
if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[3].cost&&available_summon_pos_list.size()){//弓箭手在近处召唤且优先
summon("Archer",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("Archer")[3].cost;
is_end=true;
available_count["Archer"]--;
continue;
}
if(available_count["VolcanoDragon"]>0&&mana>=CARD_DICT.at("VolcanoDragon")[3].cost&&available_summon_pos_list.size()){
summon("VolcanoDragon",3,available_summon_pos_list[0]);
//todo 删除头元素
available_summon_pos_list.erase(available_summon_pos_list.begin());
mana-=CARD_DICT.at("VolcanoDragon")[3].cost;
is_end=true;
available_count["VolcanoDragon"]--;
continue;
}
if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[3].cost&&available_summon_pos_list.size()){
summon("Swordsman",3,available_summon_pos_list[0]);
//todo 删除头元素
available_summon_pos_list.erase(available_summon_pos_list.begin());
mana-=CARD_DICT.at("Swordsman")[3].cost;
is_end=true;
available_count["Swordsman"]--;
continue;
}
}
return;
}





int main()
{
    AI player_ai;
    player_ai.chooseCards();
    while (true)
    {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

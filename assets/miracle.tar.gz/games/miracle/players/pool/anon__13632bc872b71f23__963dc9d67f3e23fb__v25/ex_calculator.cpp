
#include "ex_calculator.h"
#include "debug.h"

namespace ex_calculator {

using namespace calculator;
    
std::map<Point, bool> ally_attack_range(gameunit::Unit unit){
    //返回不同位置可被生物攻击的次数
    auto all_pos = all_pos_in_map();
    std::map<Point, bool> attack_cnt;
    std::vector<Point> attack_pos;
    for(auto &pos: all_pos){
        int dis = distance_between(unit.pos, pos);
        attack_cnt[pos] = (dis >= unit.atk_range[0] && dis <= unit.atk_range[1]);
    }
    return attack_cnt;
}
std::map<Point, int> allys_attack_range(std::vector<gameunit::Unit> units){
    //返回不同位置可被一群生物攻击的次数
    auto all_pos = all_pos_in_map();
    std::map<Point, int> attack_cnt;
    for(auto &pos: all_pos){
        for(auto &unit: units){
            int dis = distance_between(unit.pos, pos);
            attack_cnt[pos] += (dis >= unit.atk_range[0] && dis <= unit.atk_range[1]);
        }
    }
    return attack_cnt;
}
std::map<Point, std::vector<gameunit::Unit>> allys_attack_range_detail(std::vector<gameunit::Unit> units){
    //返回不同位置可被一群生物中哪些生物攻击
    auto all_pos = all_pos_in_map();
    std::map<Point, std::vector<gameunit::Unit>> attack_creatures;
    for(auto &pos: all_pos){
        for(auto &unit: units){
            int dis = distance_between(unit.pos, pos);
            if(dis >= unit.atk_range[0] && dis <= unit.atk_range[1])
                attack_creatures[pos].push_back(unit);
        }
    }
    return attack_creatures;
}

int get_path_length(Point start, Point end, std::vector<Point> obstacles){
    std::map<Point, int> dis;
    std::vector<Point> Q;
    Q.push_back(start);
    for(int t = 0; t < Q.size(); ++t){
        Point now = Q[t];
        for(int i = 0; i < 6; ++i){
            Point neighbor = cube_neighbor(now, i);
            if (!contained(neighbor, Q) && !contained(neighbor, obstacles)) {
                if (in_map(neighbor)) {
                    if(neighbor == end) return dis[now] + 1;
                    Q.push_back(neighbor);
                    dis[neighbor] = dis[now] + 1;
                }
            }
        }
    }
    return -1;
}

std::map<std::pair<Point, Point>, int> search_path_distance_tmp;
int search_path_distance(Point start, Point end, bool flying){
    if(flying == 1) return cube_distance(start, end);
    auto &tmp = search_path_distance_tmp[std::make_pair(start, end)];
    if(tmp) return tmp;
    gameunit::Map _map;
    std::vector<Point> tmp_list;
    for(auto i : _map.ground_obstacles) if(i.pos != end)
        tmp_list.push_back(i.pos);
    tmp = get_path_length(start, end, tmp_list);
    if(tmp != cube_distance(start, end)){
        output_tuple(start);
        output_tuple(end);
        debug("\n[%d %d]\n", tmp, cube_distance(start, end));
    }
    return tmp;
}
}
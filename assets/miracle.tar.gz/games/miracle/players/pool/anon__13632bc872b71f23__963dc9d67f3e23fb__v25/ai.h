#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"
#include "ex_calculator.h"
#include "debug.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using namespace ex_calculator;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

class AI : public AiClient
{
private:
    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack[2];

    Pos posShift(Pos pos, string direct);

    std::map<string, int> comment;
    //当前剩余的法力值
    int current_mana;
    //各生物剩余可召唤数
    ::map<string, int> available_count;

    //在正中心偏右召唤一个弓箭手，用来抢占驻扎点
    void summon_SF(string name = "Archer"); 
    //贪心的选择Lv最大的生物召唤，返回Lv
    int summon_gready(string name);
    //优先攻击基地
    void attack_gready(gameunit::Unit ally);

    //void check_fast_attack();
    //void check_defence();
    void check_state();

    std::vector<std::string> enemy_creatures;
    std::vector<std::string> enemy_artifacts;
public:
    AI();
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void prepare(); //提前处理变量

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动

    void artifact(); //处理神器的使用
};

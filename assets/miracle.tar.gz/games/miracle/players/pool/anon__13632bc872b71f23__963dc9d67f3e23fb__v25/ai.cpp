#include "ai.h"

AI::AI(){
    //先确定自己的基地、对方的基地
    miracle_pos = map.miracles[my_camp].pos;
    enemy_pos = map.miracles[my_camp ^ 1].pos;
    //设定目标驻扎点为最近的驻扎点

    target_barrack[0] = map.barracks[0].pos; //0表示离己方最近
    target_barrack[1] = map.barracks[0].pos; //1表示离敌方最近
    //确定离自己基地最近的驻扎点的位置
    for (const auto &barrack:map.barracks) {
        if (cube_distance(miracle_pos, barrack.pos) <
            cube_distance(miracle_pos, target_barrack[0]))
            target_barrack[0] = barrack.pos;
    }
    //确定离敌方基地最近的驻扎点的位置
    for (const auto &barrack:map.barracks) {
        if (cube_distance(enemy_pos, barrack.pos) <
            cube_distance(enemy_pos, target_barrack[1]))
            target_barrack[1] = barrack.pos;
    }
    output_tuple(target_barrack[1]);
}
void AI::summon_SF(string name){
    summon(name, 1, posShift(miracle_pos, "SF"));
}
int AI::summon_gready(string name){
    for(int lv = 3; lv >= 1; --lv){
        if(current_mana >= CARD_DICT.at(name)[lv].cost){
            
            available_count[name] -= 1;
            current_mana -= CARD_DICT.at(name)[lv].cost;
            return lv;
        }
    }
    return 0;
}
void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * artifacts和creatures可以修改
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "BlackBat", "VolcanoDragon"};
    init();
}

void AI::play()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    在费用较低时尽可能召唤星级为1的兵，优先度剑士>弓箭手>火山龙
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */

    prepare();
    debug("round = %d\n", round);
    if (round == 0 || round == 1) {
        summon_SF();
    } 
    else {
        artifact();

        //之后先战斗，再移动
        battle();

        march();

        //最后进行召唤
        auto summon_pos_list = getSummonPosByCamp(my_camp);
        
        //将所有本方出兵点随机排序
        if(comment["defence"]){//将所有本方出兵点按照到己方基地的距离排序，从近到远出兵
            sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
                return cube_distance(_pos1, miracle_pos) < cube_distance(_pos2, miracle_pos);
            });
        }
        else if(comment["random-summon"]) random_shuffle(summon_pos_list.begin(), summon_pos_list.end());
        else if(comment["fast-attack"]){ //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
            sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
            });
        }
        
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
        }

        //统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个剑士、1个弓箭手、1个火山龙的顺序召唤

        struct Pair{ string name; int lv; };
        vector<Pair> summon_list;
        //剑士和弓箭手数量不足或者格子不足则召唤火山龙
        if ((available_summon_pos_list.size() == 1 || available_count["BlackBat"] + available_count["Archer"] < 2) &&
            current_mana >= CARD_DICT.at("VolcanoDragon")[1].cost && available_count["VolcanoDragon"] > 0) {
            summon_list.emplace_back((Pair){"VolcanoDragon", 1});
            current_mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
        }

        bool suc = true;
        while (current_mana >= 2 && suc) {
            suc = false;
            //Test: 加上一些基础值的变化

            if (available_count["BlackBat"] > 0) {
                int lv = summon_gready("BlackBat");
                if(lv){
                    summon_list.emplace_back((Pair){"BlackBat", lv});
                    suc = true;
                }
            }
            if (available_count["Archer"] > 0) {
                int lv = summon_gready("Archer");
                if(lv){
                    summon_list.emplace_back((Pair){"Archer", lv});
                    suc = true;
                }
            }
            if (available_count["VolcanoDragon"] > 0 && current_mana >= CARD_DICT.at("VolcanoDragon")[1].cost) {
                int lv = summon_gready("VolcanoDragon");
                if(lv){
                    summon_list.emplace_back((Pair){"VolcanoDragon", lv});
                    suc = true;
                }
            }
        }
        
        debug("rest of mana: %d\n", current_mana);
        int i = 0;
        for (auto pos:available_summon_pos_list) {
            if (i == summon_list.size()) break;
            summon(summon_list[i].name, summon_list[i].lv, pos);
            ++i;
        }
    }
    endRound();
}

void AI::prepare(){

    comment.clear();

    //如果对方走一步之后仅离基地 7 格
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    bool on_fast_attack = 1, on_defence = 0, on_random_summon = 0;
    for(auto &enemy: enemy_list){
        auto reach_pos = reachable(enemy, map);
        for(auto &poss : reach_pos){
            for(auto & pos : poss){
                if(cube_distance(miracle_pos, pos) <= enemy.max_move + 1) on_defence = 1;
                if(cube_distance(miracle_pos, pos) <= enemy.max_move + 3) on_random_summon = 1;
            }
        }
    }

    comment["defence"] = on_defence; //优先保卫家园
    comment["fast-attack"] = on_fast_attack; //优先选择较近的位置出兵
    comment["random-summon"] = on_random_summon;
    
    current_mana = players[my_camp].mana;

    auto deck = players[my_camp].creature_capacity;
    for (const auto &card_unit:deck)
        available_count[card_unit.type] = card_unit.available_count;

    enemy_artifacts.push_back(players[my_camp ^ 1].artifact[0].name);
    for(auto &creature : players[my_camp ^ 1].creature_capacity){
        enemy_creatures.push_back(creature.type);
    }
}
void AI::artifact(){
    //神器能用就用，选择覆盖单位数最多的地点
    if (my_artifacts[0] == "HolyLight" && current_mana >= 6 && players[my_camp].artifact[0].state == "Ready") {
        auto pos_list = all_pos_in_map();
        auto best_pos = pos_list[0];
        int max_benefit = 0;
        for (auto pos:pos_list) {
            auto unit_list = units_in_range(pos, 2, map, my_camp);
            if (unit_list.size() > max_benefit) {
                best_pos = pos;
                max_benefit = unit_list.size();
            }
        }
        use(players[my_camp].artifact[0].id, best_pos);
    }
    if(my_artifacts[0] == "InfernoFlame" && current_mana >= 8 && players[my_camp].artifact[0].state == "Ready"){
        std::vector<Pos> pos_list = all_pos_in_map();
        std::vector<std::pair<Pos, int>> canuse_pos;
        for(auto i : pos_list){
            if(canUseArtifact(players[my_camp].artifact[0], i, my_camp)){
                auto enemy_list = getUnitsByCamp(my_camp ^ 1); 
                int cnt = 0;
                for(auto enemey : enemy_list) if(cube_distance(enemey.pos, i) <= 2)
                    cnt++;
                canuse_pos.push_back(std::make_pair(i, cnt));
            }      
        }
        std::sort(canuse_pos.begin(), canuse_pos.end(), 
            [](const auto &_pos1, const auto &_pos2){
                return _pos1.second > _pos2.second;
            });
        if(canuse_pos[0].second >= 2){
            use(players[my_camp].artifact[0].id, canuse_pos[0].first);
        }
    }
}
void AI::attack_gready(gameunit::Unit ally){
    //当基地血量不占优时，优先攻击基地
    if(map.miracles[my_camp].hp >= map.miracles[my_camp ^ 1].hp){
        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }
}
void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 火山龙：攻击高>低 （大AOE输出），优先攻击可制空的
     * 弓箭手：攻击高>低 优先打不能反击的攻击力最高的，其次打能反击的攻击力最低的
     * 黑蝙蝠：速度快，优先攻击可制空的
     * 剑士：攻击低>高 打消耗，优先打攻击力低的 (del)
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 例如占领着驻扎点的敌方生物具有极高的价值，优先摧毁可以使敌方下回合损失很多可用出兵点
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */

    auto ally_list = getUnitsByCamp(my_camp);
    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//火山龙>弓箭手>黑蝙蝠
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "VolcanoDragon") return 0;
                else if (type_name == "Archer") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "VolcanoDragon" or unit1.type == "Archer")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };
    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (const auto &ally:ally_list) {
        if (!ally.can_atk) break;
        attack_gready(ally);
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;
        for (const auto &enemy : enemy_list)
            if (canAttack(ally, enemy))
                target_list.push_back(enemy);
        if (target_list.empty()) continue;
        if (ally.type == "VolcanoDragon") {
            sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { 
                    if(_enemy1.type != _enemy2.type){
                        if(_enemy1.type == "Priest")
                            return true;
                        if(_enemy2.type == "Priest")
                            return false;
                    }
                    if(_enemy1.atk_flying != _enemy2.atk_flying)
                        return _enemy1.atk_flying > _enemy2.atk_flying;
                    return _enemy1.id > _enemy2.id;
                 });
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "BlackBat") {
            sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { 
                     if(_enemy1.atk_flying != _enemy2.atk_flying)
                        return _enemy1.atk_flying > _enemy2.atk_flying; 
                     else
                        return _enemy1.atk > _enemy2.atk;
                    });
            

            vector<gameunit::Unit> enemy_can_atk_flying;
            auto enemy_list = getUnitsByCamp(my_camp ^ 1);

            for(const auto &enemy: enemy_list)
                if(enemy.atk_flying)
                    enemy_can_atk_flying.push_back(enemy);

            auto attack_pos_list = allys_attack_range_detail(enemy_can_atk_flying);

            if(!attack_pos_list.empty()){
                bool death = 0;
                for(const auto &pos : attack_pos_list)
                    for(const auto &enemy: pos.second)
                        if(enemy.atk >= ally.hp){
                            death = 1;
                            break;
                        }
                if(death){
                    int Lv = 0;
                    for(auto target: target_list)
                        if(target.hp <= ally.atk)
                            Lv = std::max(target.level, Lv);
                    if(Lv >= ally.level){
                        for(auto target: target_list)
                            if(target.hp <= ally.atk && target.level == Lv)
                                attack(ally.id, target.id);
                        continue;
                    }
                }
                
            }
            
            for(auto target: target_list)
                if(target.type == "Archer" || round >= 15){
                    attack(ally.id, target.id);
                    break;
                }
            //attack(ally.id, target_list[0].id);
        } else if (ally.type == "Archer") {
            sort(enemy_list.begin(), enemy_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { 
                    if(_enemy1.atk != _enemy2.atk) return _enemy1.atk > _enemy2.atk; 
                    return _enemy1.id < _enemy2.id;
                });
            bool suc = false;
            for (const auto &enemy : target_list) // NEED MODIATION
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue; // NEED MODIATION
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "Inferno"){
            sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { 
                     return _enemy1.hp > _enemy2.hp; });
            if(target_list[0].hp >= 6) attack(ally.id, target_list[0].id);
        }
    }
    //最后攻击神迹
    ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (auto ally : ally_list) {
        if (!ally.can_atk) break;
        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }
}

void AI::march()
{
    //处理生物的移动

    /*
     * 先动所有龙，尽可能向敌方神迹移动
     * 若目标驻扎点上没有地面单位，则让弓箭手向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 然后若目标驻扎点上没有地面单位，则让火山之龙向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 蝙蝠在移动时避开敌方飞行生物攻击范围
     * 【进阶】一味向敌方神迹移动并不一定是个好主意
     * 在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
     * 如果采用其他生物组合，可以考虑抢占更多驻扎点
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [this](const Unit &_unit1, const Unit &_unit2) {
        return cube_distance(_unit1.pos, enemy_pos) < cube_distance(_unit2.pos, enemy_pos);
        //auto type_id_gen = [](const string &type_name) {
            
            //if (type_name == "VolcanoDragon") return 0;
            //else if (type_name == "BlackBat") return 1;
            //else return 2;
        //};
        //return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
    for (const auto &ally : ally_list) {
        if (!ally.can_move) continue;
        if (ally.type == "BlackBat") {
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            
            //压平
            vector<std::pair<Pos, int>> reach_pos_list;
            vector<gameunit::Unit> enemy_can_atk_flying;
            auto enemy_list = getUnitsByCamp(my_camp ^ 1);

            for(const auto &enemy: enemy_list)
                if(enemy.atk_flying)
                    enemy_can_atk_flying.push_back(enemy);

            auto attack_pos_list = allys_attack_range_detail(enemy_can_atk_flying);
            for (const auto &reach_pos : reach_pos_with_dis){
                for (auto pos : reach_pos){
                    if(cube_distance(pos, enemy_pos) != 0){//神殿不能停留！
                        int list_length = (attack_pos_list.find(pos) != attack_pos_list.end()) ? attack_pos_list[pos].size() : 0;
                        //debug("[%d]\n", list_length);
                        if(list_length >= 1){
                            bool check = 0;
                            for(auto enemy : attack_pos_list[pos]){
                                int dis = cube_distance(pos, attack_pos_list[pos][0].pos);
                                if(dis > 1) check = 1;
                            }
                            if(check) continue;
                        }
                        reach_pos_list.push_back(std::make_pair(pos, list_length));
                    }
                }
            }
            if (reach_pos_list.empty()) continue;

            //优先走到距离敌方神迹更近的位置，且可攻击该位置的生物能被反击到，也不可被多重攻击力覆盖
            nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                        [this](auto _pos1, auto _pos2) {
                            int d1 = cube_distance(_pos1.first, enemy_pos), d2 = cube_distance(_pos2.first, enemy_pos);
                           // if(d1 != d2) 
                            return d1 < d2;
                            //else return _pos1.second < _pos2.second;
                        });
            
            move(ally.id, reach_pos_list[0].first);
        } else {
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
	   
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则走到
            for(int i = 0; i <= 1; ++i) if (ally.can_move && checkBarrack(target_barrack[i]) != my_camp) {
                debug("Barrack : %d\n", i);
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this, i, ally](Pos _pos1, Pos _pos2) {
                                return search_path_distance(_pos1, target_barrack[i], ally.flying) < 
                                    search_path_distance(_pos2, target_barrack[i], ally.flying);
                            });
                output_tuple(reach_pos_list[0]);
                debug(" {%d : %d} \n", ally.id, search_path_distance(reach_pos_list[0], target_barrack[i], ally.flying));
                move(ally.id, reach_pos_list[0]);
            } 
            if(ally.can_move){
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this, ally](Pos _pos1, Pos _pos2) {
                                return search_path_distance(_pos1, enemy_pos, ally.flying) < search_path_distance(_pos2, enemy_pos, ally.flying);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        }
    }
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);
    
    srand(time(0) + clock());

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

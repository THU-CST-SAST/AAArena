#include"calculator.h"

namespace ex_calculator {

using namespace calculator;
    
std::map<Point, bool> ally_attack_range(gameunit::Unit unit){
    //返回不同位置可被生物攻击的次数
    auto all_pos = all_pos_in_map();
    std::map<Point, bool> attack_cnt;
    std::vector<Point> attack_pos;
    for(auto &pos: all_pos){
        int dis = distance_between(unit.pos, pos);
        attack_cnt[pos] = (dis >= unit.atk_range[0] && dis <= unit.atk_range[1]);
    }
    return attack_cnt;
}
std::map<Point, int> allys_attack_range(std::vector<gameunit::Unit> units){
    //返回不同位置可被一群生物攻击的次数
    auto all_pos = all_pos_in_map();
    std::map<Point, int> attack_cnt;
    for(auto &pos: all_pos){
        for(auto &unit: units){
            int dis = distance_between(unit.pos, pos);
            attack_cnt[pos] += (dis >= unit.atk_range[0] && dis <= unit.atk_range[1]);
        }
    }
    return attack_cnt;
}

}
#pragma once
#include<tuple>
#ifdef DEBUG
	#define debug(...) fprintf(stderr, __VA_ARGS__), fflush(stdout)
	const int DEBUG_FLAG = 1;
	template<class T>
	void output_tuple(const T &point){
		int fir, sec, thi;
		std::tie(fir, sec, thi) = point;
		debug("<tuple (%d, %d, %d)>", fir, sec, thi);
	}
#else
	#define debug(...) 0
	const int DEBUG_FLAG = 0;
	template<class T>
	void output_tuple(const T &point){};
#endif
    
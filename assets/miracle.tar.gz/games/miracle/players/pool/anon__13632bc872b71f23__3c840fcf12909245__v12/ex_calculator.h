//calculator for hex-grids
#pragma once
#include"calculator.h"
#include "debug.h"

namespace ex_calculator {

using namespace calculator;

//返回不同位置可被生物攻击的次数
std::map<Point, bool> ally_attack_range(gameunit::Unit unit);
//返回不同位置可被一群生物攻击的次数
std::map<Point, int> allys_attack_range(std::vector<gameunit::Unit> units);

}
#include <iostream>
#include <tuple>
using namespace std;
tuple <int,int,int> a;
int main(){
get<0>(a)=1;  
get<1>(a)=2;
get<2>(a)=3;
cout<<get<1>(a);
return 0;  
}
#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <unordered_set>
#include <fstream>
#include <cstdlib>
#include <random>
#include <ctime>
#include <map>
#include <cstring>
#include <set>
#include <stack>
#include <queue>
#define mk make_pair
#define mkt make_tuple
#define DOUBLE_INF 1e60
#define INT_INF 0x3f3f3f3f
#define fi first
#define se second
using namespace std;
using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::stack;
using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
#define ARCHER 1
#define SWORDMAN 0
#define PRIEST 2
#define INFERNO 3
#define BLACKBAT 4
#define VLCANODRAGON 5

#define ATTACK_MODE 1
#define DEFEND_MODE 2

typedef std::tuple<int, int, int> keys;
ostream& operator << (ostream& output,tuple<int, int, int>& c) //定义运算符“<<”重载函数
{
    output<<"pos:["<<get<0>(c)<<','<<get<1>(c)<<','<<get<2>(c)<<']';
    return output;
}
struct key_hash : public std::unary_function<keys, std::size_t>
{
    std::size_t operator()(const keys& k) const
    {
        return 1000000 + std::get<0>(k)*10000 + std::get<1>(k)*100 + std::get<2>(k);
    }
};

//阵营为0的玩家先手，阵营为1的玩家后手。
class AI : public AiClient
{
private:

//    ofstream //outfile;

    Pos miracle_pos;

    Pos enemy_pos;

    Pos posShift(Pos pos, string direct);
public:

    Pos center_pos;

    vector<bool> can_attack_mir;

//    std::unordered_map<tuple<int,int,int>, int, key_hash>hurtmp,my_map,dis_map[2];
    ::map <tuple<int,int,int>, int>hurtmp,my_map,dis_map[2];
    vector<Unit>pries_list;

    int my_mode,enemy_mod;

    Pos my_barrack;
    int barrack_id;

    static const Pos directions[6];
    static const double w[3][15];
    static const double ww[5];


    Pos archer_pos[2][3];

    int start_time ;
    bool is_bat;

    set<Pos> my_obstacle;

    vector<vector<int> > can_attack_list;

    vector<Pos> summon_pos_list;

    vector<Unit > can_attack;

    vector<Unit > can_move,can_move_nopriest,can_move_priest;

    vector<Unit> my_list;

    vector<Unit> enemy_list;

    vector<int> visited;

    ::map<int, Unit>mp;

    vector<tuple<int,int,int> >record; //回溯栈 id 受到的伤害
    vector<pair<int,Pos> >map_record; //己方位置修改的回溯栈

    vector<string>creature;

    vector<pair<int,int> >best_answer;
    vector<pair<int,Pos> >best_answer_move;

    double best_answer_value;

//    vector<tuple<int, Pos,Pos> >priest_move;


    void check_enemy_mode();
    //选择初始卡组
    bool can_comm(int type, int level,::map<string, gameunit::CreatureCapacity>& available_count);

    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void init_mymap(); //初始化地图

    void update_mymap();//更新地图

    void back_mymap(); //地图信息回溯

    void get_hurt_map();

    void do_attack(Unit &my_ally, vector<Unit>& target_list);

    int not_low_level(Unit enemy); //判断敌人是否值得攻击

    void search(int deep, vector<int>&); //搜索攻击顺序

    void my_attack(int attacker, int defender); //模拟攻击

    void my_move(int mover, Pos pos);

    void my_march(Unit priest);

    double estimate();//局面评估

    double estimate2(int id,Pos pos);//移动后的局面评估

    pair<double,Pos> get_max_value(int id,unordered_map<Pos, double, key_hash>&score);

    int flag_search2;

    vector<int>pass;

    vector<int>best_answer_search2;

    void search2(int ,int ,int ,vector<pair<int,Pos> >&,vector<pair<int,Pos> >&);//牧师是怎么移动的

    bool canMove(int id,Pos pos);

    void my_summon();

    void my_init();

    void get_oppo_choice(vector<Unit>&can_move, vector<unordered_map<Pos, double, key_hash> >&scores);

    vector<Pos> get_reachable_pos(Unit x);

    Pos get_min_dis_pos(int type);

    int get_level(int type,int mana)
    {
        int level = 1;
        if(mana>=CARD_DICT.at(creature[type])[2].cost)level = 2;
        if(mana>=CARD_DICT.at(creature[type])[3].cost)level = 3;
        return level;
    }

    Pos get_summ_pos(int type, int level);

    Pos add(const Pos &a,const Pos &b)
    {
        return make_tuple((get<0>(a)+get<0>(b)),(get<1>(a)+get<1>(b)),(get<2>(a)+get<2>(b)));
    }
    Pos mult(const Pos &a,int b)
    {
        return make_tuple(get<0>(a)*b,get<1>(a)*b,get<2>(a)*b);
    }
    vector<Pos> get_pos_from_dis(Pos pos,int range)
    {
        vector<Pos>tmp;
        if(range==0)tmp.push_back(pos);
        Pos now_pos = add(pos, mult(directions[4],range));
        for(int i=0;i<6;i++)
        {
            for(int j=0;j<range;j++)
            {
                tmp.push_back(now_pos);
                now_pos = add(now_pos, directions[i]);
            }
        }
        return tmp;
    }
    vector<Pos> get_pos_from_range(Pos pos,int range0,int range1)
    {
        vector<Pos>tmp;
        if(range0==0)tmp.push_back(pos);
        for(int range = range0;range<=range1;range++)
        {
            Pos now_pos = add(pos, mult(directions[4],range));
            for(int i=0;i<6;i++)
            {
                for(int j=0;j<range;j++)
                {
                    tmp.push_back(now_pos);
                    now_pos = add(now_pos, directions[i]);
                }
            }
        }
        return tmp;
    }
    bool cmp(const Unit &unit1, const Unit &unit2)
    {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//火山龙>剑士>弓箭手
            int t1 = 2, t2 = 2;
            if (unit1.type == "Archer")t1 = 0;
            if (unit1.type == "Swordsman")t1 = 1;
            if (unit2.type == "Archer")t2 = 0;
            if (unit2.type == "Swordsman")t2 = 1;
            return t1<t2;
        }
        return unit1.id < unit2.id;
    }
    int check_bat()
    {
        for(int i=0;i<3;i++)
        {
            if(players[my_camp^1].creature_capacity[i].type == "BlackBat")
            {
                return 1;
            }
        }
        return 0;
    }
    void calc_center()
    {
        center_pos = make_tuple(0,0,0);
        int cnt = 0;
        for(auto& unit:my_list)
        {
            if(mp[unit.id].hp>0)
            {
                cnt++;
                center_pos = add(center_pos, mp[unit.id].pos);
            }
        }
        double x = get<0>(center_pos), y = get<1>(center_pos), z = get<2>(center_pos);
        int xx = x/cnt+0.5, yy = y/cnt+0.5, zz = z/cnt+0.5;
        center_pos = mkt(xx,yy,zz);
    }
    bool in_map(Pos pos) {
        if (std::get<0>(pos) > 8 || std::get<0>(pos) < -8 ||
            std::get<1>(pos) > 8 || std::get<1>(pos) < -8 ||
            std::get<2>(pos) > 14 || std::get<2>(pos) < -14) {
            return false;
        } else if (pos == Pos(8, -8, 0) || pos == Pos(-8, 8 ,0)) {
            return false;
        }
        return true;
    }
    void print_pos(Pos pos)
    {
        //outfile<<"POS:"<<get<0>(pos)<<' '<<get<1>(pos)<<' '<<get<2>(pos)<<endl;
    }
};
const Pos AI::directions[6] =
        {make_tuple(+1,-1,0),make_tuple(+1,0,-1),make_tuple(0,+1,-1),
         make_tuple(-1,+1,0),make_tuple(-1,0,+1),make_tuple(0,-1,+1)};
const double AI::w[3][15] = //第二行是攻击模式，第三行是防御模式
        {
                {0,0,0,0,0,0,0,0,0,0,0, 0, 0, 0, 0},
                {1, 1, 1, 1, 2.5,  3, 1, 0.2, 0.5, 1, 1.4, 1, 2,  0.5, 1},
                {1, 1, 1, 1, 3,  2.5, 1, 0.6, 1,   1, 1.4, 1, 0.5,2,   1}
                //0  1  2  3  4   5  6    7    8    9  10   11 12  13  14
        };//0：对面兵营掉血，1：己方兵营掉血，2：己方兵力+等级，3：对面兵力+等级
//4：对方对自己兵营一回合能造成的伤害 5：对对方兵营一回合能造成的伤害
//6:超出聚集范围的处罚 7:己方受伤每点血的权值 8:己方直接死亡的权值（需要乘上花费)
//9:打到对面的权值  10:牧师奶到弓箭手的权值 11:牧师奶到剑士的权值
//12：我方距离地方兵营的距离归一化后乘的系数 13：敌方距离我方兵营归一化后乘的系数
//14: 我方距离帐篷的距离归一化后乘的系数
const double AI::ww[5]={0, 0.2, 0.4, 1, 1.5};
//周围有几个障碍物
void AI::get_hurt_map()
{
    hurtmp.clear();
    enemy_list = getUnitsByCamp(my_camp^1);
    for(auto &unit: enemy_list)
    {
        auto& UC = unit;
        if(UC.hp<=0||UC.id<=1)continue;
        //计算攻击到的地点
        vector<Pos>atk_map = get_pos_from_range(UC.pos, UC.atk_range[0],UC.atk_range[1]);
        for(auto& now_pos:atk_map)
        {
            if (hurtmp.find(now_pos) != hurtmp.end())
                hurtmp[now_pos] += UC.atk;
            else hurtmp[now_pos] = UC.atk;
        }
    }
}
Pos AI::get_min_dis_pos(int type)
{
    vector<Pos> available_summon_pos_list;
    for (auto pos:summon_pos_list) {
        auto unit_on_pos_ground = AiClient::getUnitByPos(pos, false);
        if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
    }
    if(available_summon_pos_list.size()==0)return mkt(-1,-1,-1);
    Pos minPos = summon_pos_list[0];
    double max_value = -DOUBLE_INF;
    int level = type%100;
    type = type/100;
    auto& tmp = CARD_DICT.at(creature[type])[level];
    int id = 100000;
    mp[id] = Unit();
    mp[id].hp = mp[id].max_hp = tmp.max_hp;
    mp[id].atk = tmp.atk;
    while(mp[id].atk_range.size()<2)mp[id].atk_range.push_back(0);
    mp[id].atk_range[1] = tmp.max_atk_range;
    mp[id].atk_range[0] = tmp.min_atk_range;
    mp[id].atk_flying = tmp.atk_flying;
    mp[id].camp = my_camp;
    mp[id].type = tmp.type;
    mp[id].id = id;
    for(Pos& pos:available_summon_pos_list)
    {
        double tmp_value = estimate2(id, pos);
        if(tmp_value>max_value)
        {
            max_value = tmp_value;
            minPos = pos;
        }
    }
    mp.erase(id);
    return minPos;
}
Pos AI::get_summ_pos(int type,int level)
{
    //outfile<<"get_summon_pos"<<type<<' '<<level<<endl;
    get_hurt_map();
    my_list = getUnitsByCamp(my_camp);
    //outfile<<"get2"<<endl;
    if(my_mode==ATTACK_MODE)
    {
        return get_min_dis_pos(type*100+level);
    }
    else if(my_mode==DEFEND_MODE)
    {
        return get_min_dis_pos(type*100+level);
    }
    return mkt(-1,-1,-1);
}
bool AI::can_comm(int type,int level,::map<string, gameunit::CreatureCapacity>& available_count)
{
//    //outfile<<"can"<<endl;
//    //outfile<<"1L:"<<CARD_DICT.at(creature[type])[level].cost<<' '<<players[my_camp].mana<<endl;
//    //outfile<<"2L:"<<available_count[creature[type]].available_count<<endl;
//    //outfile<<available_count[creature[type]].cool_down_list.size()<<endl;
//    //outfile<<"3L:"<<available_count[creature[type]].cool_down_list[level]<<endl;

    if(players[my_camp].mana >= CARD_DICT.at(creature[type])[level].cost&&
       available_count[creature[type]].available_count >= 1)
        return true;
    return false;
}
void AI::my_summon()
{

//    //outfile<<"start_summon"<<endl;

    my_list = AiClient::getUnitsByCamp(my_camp);
    static int summ_first_nobat[] = {-1,ARCHER,PRIEST,SWORDMAN,SWORDMAN,ARCHER,ARCHER,PRIEST,PRIEST,SWORDMAN};
    static int summ_second_nobat[] = {-1,SWORDMAN,SWORDMAN,SWORDMAN,ARCHER,ARCHER,PRIEST,PRIEST,ARCHER,PRIEST};
    static int summ_first_bat[] = {-1,ARCHER,ARCHER,SWORDMAN,SWORDMAN,ARCHER,PRIEST,PRIEST,PRIEST,SWORDMAN};
    static int summ_second_bat[] = {-1,ARCHER,SWORDMAN,SWORDMAN,PRIEST,ARCHER,PRIEST,PRIEST,ARCHER,PRIEST};
    static string summ_pos[] = {"IF","FF","SF"};
    //round是从0开始的，每次需要%2^1
    int FIRST = (round%2) ^ 1;
    int* a;
    if(FIRST&&is_bat)a = summ_first_bat;
    else if(FIRST&&!is_bat)a = summ_first_nobat;
    else if(!FIRST&&is_bat)a = summ_second_bat;
    else if(!FIRST&&!is_bat)a = summ_second_nobat;

    //outfile<<"summon_1"<<endl;

    //将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
    summon_pos_list = getSummonPosByCamp(my_camp);
    sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
        return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
    });


    //outfile<<"summon_2"<<endl;

    //得到每个生物可用的数量
    auto deck = players[my_camp].creature_capacity;
    ::map<string, gameunit::CreatureCapacity> available_count;
    for (const auto &card_unit:deck)
        available_count[card_unit.type] = card_unit;


    //outfile<<"summon_3"<<endl;

    //进攻地狱火
    if(my_mode==ATTACK_MODE&&players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready")
    {
        auto pos_list = all_pos_in_map();
        auto best_pos = pos_list[0];
        int max_benefit = 0;
        int min_dis = INT_INF;
        for (auto pos:pos_list)
        {
            if(canUseArtifact(players[my_camp].artifact[0], pos, my_camp))
            {
                if(cube_distance(pos, enemy_pos) <= min_dis)
                {
                    min_dis = cube_distance(pos, enemy_pos);
                    best_pos = pos;
                }
            }
        }
        if(min_dis!=INT_INF)
        {
            use(players[my_camp].artifact[0].id,best_pos);
        }
    }

    //防御地狱火
    if(my_mode==DEFEND_MODE&&players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready")
    {
        auto pos_list = all_pos_in_map();
        Pos best_pos = pos_list[0];
        int max_eney = -1;
        for(auto pos:pos_list)
        {
            if(cube_distance(pos, miracle_pos)<=7&&getUnitByPos(pos, 0).id==-1)
            {
                auto unit_list = units_in_range(pos, 2, map, my_camp^1);
                if(unit_list.size() > max_eney)
                {
                    max_eney = unit_list.size();
                    best_pos = pos;
                }
                else if(unit_list.size() == max_eney && cube_distance(pos, miracle_pos) < cube_distance(best_pos, miracle_pos))
                {
                    max_eney = unit_list.size();
                    best_pos = pos;
                }
            }
        }
        if(max_eney!=-1)use(players[my_camp].artifact[0].id, best_pos);
    }


    //outfile<<"summon_4"<<endl;
    //outfile<<players[my_camp].mana<<endl;

    int my_round = (round)/2 + 1; //从1开始
    if(my_round<=9)
    {
        int now_level = get_level(a[my_round], players[my_camp].mana);
        //outfile<<creature[a[my_round]]<<' '<<now_level<<' ';
        print_pos(posShift(miracle_pos, summ_pos[my_round%3]));

        summon(creature[a[my_round]], now_level, posShift(miracle_pos, summ_pos[my_round%3]));
        //这里需要考虑三个牧师招满之后的召唤位置
    }
    static vector<pair<int,int>> summ_priority
            = {mk(PRIEST,3), mk(PRIEST, 2), mk(ARCHER,3), mk(SWORDMAN, 3), mk(ARCHER, 2), mk(SWORDMAN, 2), mk(SWORDMAN, 1)};

    //outfile<<"summon_5"<<' '<<players[my_camp].mana<<endl;
    for(auto &bin : summ_priority)
    {
        if(can_comm(bin.first,bin.second,available_count))
        {
            summon(creature[bin.first], bin.second, get_summ_pos(bin.first, bin.second));
        }
    }

    //outfile<<"summon_finish"<<endl;
}
void AI::check_enemy_mode()
{
    //outfile<<"now_check"<<endl;
    enemy_list = AiClient::getUnitsByCamp(my_camp^1);
    int cnt = 0;
    for(auto& unit:enemy_list)
    {
        if(cube_distance(unit.pos, enemy_pos) <= 7)cnt++;
    }
    if((double)cnt/enemy_list.size() >= 0.6)enemy_mod = DEFEND_MODE;
    else enemy_mod = ATTACK_MODE;

}
void AI::my_init()
{
    //调试
//    if(my_camp==1)//outfile.open("out1.txt");
//    if(my_camp==0)//outfile.open("out0.txt");


    //障碍物
    for(auto& barrack:map.obstacles)my_obstacle.insert(barrack.pos);  //2不能经过，1是敌人旁边的位置
    Pos tmp_pos[6] = {mkt(7,-8,1), mkt(-8,8,0), mkt(8,-8,0), mkt(8,-7,-1), mkt(-8,7,1), mkt(-7,8,-1)};
    for(int i=0;i<6;i++)my_obstacle.insert(tmp_pos[i]);

    //求每个位置到水晶的最短路
    for(int i=0;i<=1;i++)
    {
        queue<Pos>q;
        Pos first_pos = map.miracles[i^1].pos;
        q.push(first_pos);
        dis_map[i][first_pos] = 0;
        int cnt = 0;
        while(!q.empty())
        {
            Pos pos_now = q.front();
            int dis = dis_map[i][pos_now];
            q.pop();
            for(int j=0;j<6;j++)
            {
                auto new_pos = add(pos_now, directions[j]);
                if(my_obstacle.find(new_pos)!=my_obstacle.end())continue;
                if(!in_map(new_pos))continue;
                if(dis_map[i].find(new_pos)==dis_map[i].end())
                {
                    dis_map[i][new_pos] = dis+1;
                    q.push(new_pos);
                }
            }
        }
    }

    enemy_mod = ATTACK_MODE;
    my_mode = ATTACK_MODE;
    is_bat = check_bat();
    creature.emplace_back("Swordsman");
    creature.emplace_back("Archer");
    creature.emplace_back("Priest");
    creature.emplace_back("Inferno");
    creature.emplace_back("BlackBat");
    creature.emplace_back("VolcanoDragon");

    archer_pos[0][0] = make_tuple(-6,4,2);
    archer_pos[0][1] = make_tuple(-4,4,0);
    archer_pos[0][2] = make_tuple(-4,6,-2);
    archer_pos[1][0] = make_tuple(6,-4,-2);
    archer_pos[1][1] = make_tuple(4,-4,0);
    archer_pos[1][2] = make_tuple(4,-6,2);


    //先确定自己的基地、对方的基地
    miracle_pos = map.miracles[my_camp].pos;
    enemy_pos = map.miracles[my_camp ^ 1].pos;
    //设定目标驻扎点为最近的驻扎点
    my_barrack = map.barracks[0].pos;
    //确定离自己基地最近的驻扎点的位置
    int ctt = 0;
    for (auto barrack:map.barracks) {

        if (cube_distance(miracle_pos, barrack.pos) <
            cube_distance(miracle_pos, my_barrack))
        {

            my_barrack = barrack.pos;
            barrack_id = ctt;
        }
        ctt ++;
    }

    //outfile<<"init_finish"<<endl;
}
void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * artifacts和creatures可以修改
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Swordsman", "Priest", "Archer"};
    init();
}

void AI::play()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    在费用较低时尽可能召唤星级为1的兵，优先度剑士>弓箭手>火山龙
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */

    //round是从0开始的
    start_time = clock();
    //outfile<<"round:"<<round<<"------------------------------"<<endl;
    if (round == 0 || round == 1)
    {
        my_init();
        my_summon();
    }
    else{

        if(players[my_camp].mana>=5)check_enemy_mode();
        //之后先战斗，再移动\
        //outfile<<"nowbattle"<<endl;
        battle();
        my_summon();
        //先出牧师
//        summon_priest();
        //最后进行召唤

    }
    endRound();
}
int AI::not_low_level(Unit enemy)
{
    if(enemy.level == 1&& (enemy.type == "BlackBat" || enemy.type == "Archer"))return 0;
    return 1;
}
double AI::estimate2(int id, Pos pos)
{
    double value = 0;
    int is_camp = 0;
    if(mp[id].camp==my_camp)is_camp = 1;
    auto& unit = mp[id];
    if(unit.hp <= 0)return 0;
    if(!is_camp)
    {
        //outfile<<"wrong!!!!!!!!!"<<unit.id<<endl;
    }
    else{
        if(unit.type!="Priest")
        {
            // 每个生物距离地方兵营距离
            int mir_dis = dis_map[my_camp][pos];
            value += (double)(15-mir_dis) / 15 * w[my_mode][12];
            //生物能否攻击到兵营
            if (mir_dis <= unit.atk_range[1] && mir_dis >= unit.atk_range[0]) {
                value += unit.atk * w[my_mode][5];
            }
        }

        if(map.barracks[barrack_id].camp!=my_camp)
        {
            int mir_dis = cube_distance(my_barrack, pos);
            value += (double)(7-mir_dis) / 7 * w[my_mode][14];
        }



        //生物距离中心的远近
        int dis = cube_distance(center_pos, pos);
//        //outfile<<"dis???"<<dis<<endl;
        if(dis>=5)value -= w[my_mode][6]*(dis-5);

        //被对方打到的情况
        double v1 = value;
        bool willdie = 0;
        if(hurtmp.find(pos)!=hurtmp.end())
        {
            if(hurtmp[pos]>=min(unit.max_hp, unit.hp+2))value -= w[my_mode][8] * unit.cost;
            else
            {
                willdie = true;
                value -= w[my_mode][7]*hurtmp[pos];
            }
//            //outfile<<"hurtmp"<<pos<<' '<<hurtmp[pos]<<endl;
        }
//        if(hurtmp[pos]>=min(unit.max_hp, unit.hp+2))value -= w[my_mode][8] * unit.cost;
//        else value -= w[my_mode][7]*hurtmp[pos];
//        //outfile<<value-v1<<endl;

        int obstacle_count = 0;
        for(int i=0;i<6;i++)
        {
            Pos tmp_pos = add(pos, directions[i]);
            if(my_obstacle.find(tmp_pos)!=my_obstacle.end())
            {
                obstacle_count ++;
            }
            else if(!in_map(tmp_pos))
            {
                obstacle_count ++;
            }
        }
//        //outfile<<pos<<"obstacle_count"<<obstacle_count<<endl;
        value -= ww[obstacle_count];


        double tmp_value = 0;
        if(unit.type=="Priest")
        {
            for(auto &my_unit:my_list)
            {
                if(my_unit.type=="Priest")continue;
                int dis2 = cube_distance(mp[my_unit.id].pos, pos);
                if(dis2<=min(3,my_unit.level+1))
                {
                    if(my_unit.type=="Archer")tmp_value += w[my_mode][10];
                    else tmp_value += w[my_mode][11];
                }
            }
        }
        else
        {
            //能打到对方的情况
            int num = -1;
            for(auto &enemy_unit:enemy_list)
            {
                num++;
                if(mp[enemy_unit.id].hp<=0)continue;
                int dis2 = cube_distance(mp[enemy_unit.id].pos, pos);
                if(!unit.atk_flying && enemy_unit.flying)continue;
                if(dis2<=unit.atk_range[1]&&dis2>=unit.atk_range[0])
                {
                    tmp_value += w[my_mode][9] * (1 + (int)can_attack_mir[num]);
                    if(can_attack_mir[num])
                    {
                        tmp_value += 2 * w[my_mode][9];
//                        //outfile<<"lalallalalalal"<<' '<<mp[unit.id].atk<<endl;
                    }
                }

            }
        }
        if(!willdie)value += tmp_value;
        else value += 0.5*tmp_value;


    }
    return value;
}
void AI::init_mymap()
{
    my_map.clear();
    for(auto& pos:my_obstacle)
    {
        my_map[pos] = 2;
    }
    for(auto& unit:enemy_list)
    {
        if(unit.type=="BlackBat"||mp[unit.id].hp<=0)continue;
        my_map[unit.pos] = 2;
    }
//    pos a[5] =
    for(auto& unit:enemy_list)
    {
        if(unit.type=="BlackBat"||mp[unit.id].hp<=0)continue;
        for(int j=0;j<6;j++)
        {
            auto tmp_pos = add(unit.pos, directions[j]);
            if(my_map.find(tmp_pos)==my_map.end())
                my_map[tmp_pos] = 1;
        }
    }

}
void AI::update_mymap()
{
    for(auto& unit:my_list)
    {
        if(mp[unit.id].hp<=0)continue;
        if(my_map.find(unit.pos)==my_map.end())my_map[unit.pos] = 2;
        else my_map[unit.pos] += 2;
    }
}
void AI::back_mymap()
{
    auto tmp = map_record.back();
    map_record.pop_back();
    Pos now_pos = mp[tmp.first].pos;
    mp[tmp.first].pos = tmp.second;
    my_map[now_pos] -= 2;
    if(my_map[now_pos]==0)my_map.erase(now_pos);
    my_map[tmp.second] = my_map[tmp.second] + 2;
}
void AI::my_move(int mover, Pos pos)
{
    auto prePos = mp[mover].pos;
    mp[mover].pos = pos;
    my_map[prePos]-=2;
    if(my_map[prePos]==0)my_map.erase(prePos);
    if(my_map.find(pos)==my_map.end())my_map[pos]=2;
    else my_map[pos] += 2;
    map_record.emplace_back(mk(mover,prePos));
}

vector<Pos> AI::get_reachable_pos(Unit unit)
{
    vector<Pos> reach_pos;
    static queue<Pos>q;
    while(!q.empty())q.pop();

    q.push(unit.pos);
    static ::map<Pos,int>tmp_map;
    tmp_map.clear();
    tmp_map[unit.pos] = 0;
    int cnt = 0;
    while(!q.empty())
    {
        Pos tmp_pos = q.front();
        int dis = tmp_map[tmp_pos];
//        //outfile<<dis<<endl;
//        //outfile<<q.size()<<endl;
        int ct = 0;
        if(my_map.find(tmp_pos)!=my_map.end())ct = my_map[tmp_pos];
        if(ct<4)reach_pos.push_back(tmp_pos);
        q.pop();cnt++;
//        if(unit.id==8)
//        {
//            //outfile<<cnt<<endl;
//        }
        if(cnt!=1&&ct>=1)continue;
//        //outfile<<"max_move:"<<unit.max_move<<endl;
        if(dis==unit.max_move)continue;

        for(int j=0;j<6;j++)
        {
            auto new_pos = add(tmp_pos, directions[j]);
//            //outfile<<new_pos<<endl;
            if(my_map.find(new_pos)!=my_map.end()&&my_map[new_pos]>=2)continue;
//            //outfile<<new_pos<<endl;
            if(!in_map(new_pos))continue;

//            if(tmp_map.find(new_pos)==tmp_map.end())
//            {
//                //outfile<<"ha"<<endl;
//            }
//            //outfile<<new_pos<<endl;
            if(tmp_map.find(new_pos)==tmp_map.end())
            {
//                //outfile<<new_pos<<endl;
                tmp_map[new_pos] = dis+1;
                q.push(new_pos);
            }
//            //outfile<<new_pos<<endl;
        }


    }
    return reach_pos;
}
pair<double,Pos> AI::get_max_value(int id,unordered_map<Pos, double, key_hash>&score)
{
//    //outfile<<"id"<<id<<endl;
    vector<Pos> reachable = get_reachable_pos(mp[id]);
    //    //outfile<<"id"<<id<<endl;
    double mx = 0;
    Pos max_pos = make_tuple(-1,-1,-1);
    for(auto& pos:reachable)
    {
//        //outfile<<"pos and estimate2"<<pos<<' '<<score[pos]<<endl;
        if(score.find(pos)==score.end())
        {
            //outfile<<pos<<endl;
            //outfile<<"wrong!!!!!"<<endl;
        }
        if(score[pos]>mx)
        {
            mx = score[pos];
            max_pos = pos;
        }
    }
//    //outfile<<"id"<<id<<endl;

    return mk(mx, max_pos);
}
void AI::get_oppo_choice(vector<Unit>&can_movenow, vector<unordered_map<Pos, double, key_hash> >&scores)
{
    vector<bool>Visited;
    int mover_cnt = can_movenow.size();
    for(int i=0;i<mover_cnt;i++)Visited.push_back(0);
    for(int i=0;i<mover_cnt;i++)
    {
//        //outfile<<"i:"<<i<<endl;
        double max_value = -DOUBLE_INF;
        int choice = -1;
        Pos best_pos = make_tuple(-1,-1,-1);
//        //outfile<<"begin:"<<endl;
        for(int j=0;j<mover_cnt;j++)
        {
//            //outfile<<j<<endl;

            if(Visited[j])continue;
            auto& unit = can_movenow[j];
            auto tmp = get_max_value(unit.id,scores[j]);

//            //outfile<<"j1"<<j<<endl;
            my_move(unit.id, tmp.second);

//            //outfile<<"j2"<<j<<endl;
            double value_j = scores[j][tmp.second];
//            //outfile<<"j2.5 "<<j<<endl;
            for(int k=0;k<mover_cnt;k++)
            {
                if(j==k||Visited[k])continue;
                value_j += get_max_value(can_movenow[k].id, scores[k]).first;
            }

//            //outfile<<"j3"<<j<<endl;
            //outfile<<"value!!!"<<value_j<<' '<<max_value<<endl;
            if(value_j>=max_value)
            {
                max_value = value_j;
                choice = j;
                best_pos = tmp.second;
            }
            back_mymap();

//            //outfile<<"jend"<<j<<endl;
        }
//        //outfile<<"end:"<<endl;
        my_move(can_movenow[choice].id, best_pos);
        Visited[choice] = true;
//        //outfile<<"i:"<<i<<endl;
    }

}
bool AI::canMove(int id,Pos pos)
{
    queue<Pos>q;
    q.push(mp[id].pos);
    if(pos==mp[id].pos)return true;
    unordered_map<Pos,int,key_hash>tmp_map;
    tmp_map[mp[id].pos] = 0;
    int cnt = 0;
//    //outfile<<mp[id].pos<<"id and pos:"<<id<<' '<<pos<<endl;
    while(!q.empty())
    {
        Pos tmp_pos = q.front();
        int dis = tmp_map[tmp_pos];
        q.pop();cnt++;
        if(cnt!=1&&my_map.find(tmp_pos)!=my_map.end())continue;
        if(dis==mp[id].max_move)continue;

        for(int j=0;j<6;j++)
        {
            auto new_pos = add(tmp_pos, directions[j]);
            if(my_map.find(new_pos)!=my_map.end()&&my_map[new_pos]>=2)continue;
            if(!in_map(new_pos))continue;
            if(tmp_map.find(new_pos)==tmp_map.end())
            {
//                //outfile<<new_pos<<endl;
                if(pos==new_pos)return true;
                tmp_map[new_pos] = dis+1;
                q.push(new_pos);
            }
        }
    }
//    //outfile<<"false"<<endl;
    return false;
}
void AI::search2(int deep,int deep1,int deep2,vector<pair<int,Pos> >&other_move,vector<pair<int,Pos> >&priest_move)
{
    //outfile<<"search2 "<<deep<<' '<<deep1<<' '<<deep2<<' '<<other_move.size()<<' '<<priest_move.size()<<endl;
    if(deep2==priest_move.size()+1 && deep1 == other_move.size()+1)
    {
//        best_asn

        best_answer_search2.assign(pass.begin(),pass.end());
//        best_answer_search2 = pass;

//        //outfile<<"passzie!!"<<best_answer_search2.size()<<endl;
        flag_search2 = 1;
        return ;
    }
//    if(deep1==3)
//    {
//        //outfile<<"deep1==3 "<<other_move[deep1-1].first<<' '<<endl;
//        if(my_map.find(mkt(-1,3,-2))!=my_map.end())
//        {
//            //outfile<<my_map[mkt(-1,3,-2)]<<endl;
//        }
//        //outfile<<mp[other_move[deep1-1].first].pos<<mp[other_move[deep1-1].first].max_move<<endl;
//        //outfile<<other_move[deep1-1].second<<' '<<canMove(other_move[deep1-1].first,other_move[deep1-1].second)<<endl;
//    }
    if(deep1<=other_move.size()&&canMove(other_move[deep1-1].first,other_move[deep1-1].second))
    {
        pass.push_back(deep1-1);
//        if(deep1==2)
//        {
//            //outfile<<mp[other_move[deep1-1].first].pos<<' ';
//            //outfile<<my_map[mp[other_move[deep1-1].first].pos]<<endl;
//        }
        my_move(other_move[deep1-1].first,other_move[deep1-1].second);
//        if(deep1==2)
//        {
//            //outfile<<"move_end:"<<mp[other_move[deep1-1].first].pos<<' ';
//            //outfile<<my_map[mp[other_move[deep1-1].first].pos]<<endl;
//        }
        search2(deep+1,deep1+1,deep2,other_move,priest_move);
        back_mymap();
        pass.pop_back();
        if(flag_search2)return ;
    }
    if(deep2<=priest_move.size()&&canMove(priest_move[deep2-1].first, priest_move[deep2-1].second))
    {
        pass.push_back(other_move.size()+deep2-1);
        my_move(priest_move[deep2-1].first,priest_move[deep2-1].second);
        search2(deep+1,deep1,deep2+1,other_move,priest_move);
        back_mymap();
        pass.pop_back();
    }
}

double AI::estimate()
{
    static int ct = 0;
    ct+=1;
    //outfile<<"estimate"<<endl;
    //outfile<<"estimate1 "<<ct<<' '<<(clock()-(double)start_time)/CLOCKS_PER_SEC<<endl;
    //地方兵营爆炸
    double value = 0;
    if(mp[my_camp ^ 1].hp<=0)value = DOUBLE_INF;

    //计算兵营血量
    value += (30-mp[my_camp^1].hp)*w[my_mode][0];
    value -= (30-mp[my_camp].hp)*w[my_mode][1];


    //计算兵力和等级,还没写生物重要性
    double count[2]={0,0};
    for(auto &unit : mp)
    {
//        //outfile<<"unit"<<unit.first<<' '<<unit.second.hp<<endl;
        if(unit.first<=1 || unit.second.hp<0)continue;
        int side = unit.second.camp;
        count[side] += unit.second.cost*(0.5+0.5*((double)unit.second.hp/unit.second.max_hp));
    }
//    //outfile<<count[0]<<' '<<count[1]<<endl;
    value += count[my_camp]*w[my_mode][2] - count[my_camp^1]*w[my_mode][3];

    //outfile<<"estimate2"<<' '<<value<<endl;
    hurtmp.clear();
    //计算受击地点
    for(auto &unit: mp)
    {
        auto& UC = unit.second;
        if(UC.hp<=0||UC.id<=1)continue;
        if(UC.camp==(my_camp^1))
        {
            //计算攻击到的地点
            vector<Pos>atk_map = get_pos_from_range(UC.pos, UC.atk_range[0],UC.atk_range[1]);
            for(auto& now_pos:atk_map)
            {
                if(hurtmp.find(now_pos)!=hurtmp.end())
                    hurtmp[now_pos] += UC.atk;
                else hurtmp[now_pos] = UC.atk;
            }
        }
    }
    //己方兵营爆炸
    if(hurtmp[miracle_pos] >= map.miracles[my_camp].hp)value -= 0.5 * DOUBLE_INF;


    //敌方对我方的威胁
//    //outfile<<"en size"<<enemy_list.size()<<endl;
    can_attack_mir.clear();
    can_attack_mir.insert(can_attack_mir.end(), enemy_list.size(), 0);
    int num = -1;
    for(auto& tmp:enemy_list)
    {
        auto& unit = mp[tmp.id];
        num++;
        if(unit.hp <= 0)continue;
        // 每个生物距离我方兵营距离

        int mir_dis = dis_map[my_camp^1][unit.pos];
        value -= (double)(15-mir_dis)/15*w[my_mode][13];
//        //outfile<<value<<endl;

        //生物能否攻击到兵营
        if(mir_dis <= unit.atk_range[1] && mir_dis >= unit.atk_range[0])
        {
            value -= unit.atk*w[my_mode][4];
            can_attack_mir[num] = true;
            value -= unit.cost*(1*((double)unit.hp/unit.max_hp)) * w[my_mode][3];
        }
    }


    //outfile<<"estimate3"<<' '<<value<<endl;

    can_move.clear();
    can_move_nopriest.clear();
    can_move_priest.clear();
    for(auto& false_unit: my_list)
    {
        auto& unit = mp[false_unit.id];
        if(unit.can_move)
        {
//            //outfile<<unit.id<<' '<<unit.type<<endl;
            can_move.push_back(mp[unit.id]);
            if(unit.type=="Priest")can_move_priest.push_back(unit);
            else can_move_nopriest.push_back(unit);
        }
    }

    //把牧师删掉(血量变为负数)
    for(auto& priest:can_move_priest)
    {
        mp[priest.id].hp *= -1;
    }

    //计算当前的地图
    init_mymap();

    //outfile<<"estimate4"<<' '<<value<<endl;
    //先计算每个人在每个位置的的得分
    vector<unordered_map<Pos, double,key_hash> >scores;

    update_mymap();//更新己方的位置
    calc_center();
    for(int i=0;i<can_move_nopriest.size();i++)
    {
//        //outfile<<i<<' '<<can_move_nopriest[i].pos<<endl;
        auto& unit = can_move_nopriest[i];
        scores.emplace_back(unordered_map<Pos, double,key_hash>());
        auto move_set = get_pos_from_range(unit.pos, 0, unit.max_move);
        double mx = -DOUBLE_INF;
        for(auto& pos:move_set)
        {
            scores[i][pos] = estimate2(unit.id, pos);
        }
    }

//    //outfile<<"estimate5"<<endl;
    //利用机会成本计算
//    //outfile<<scores[0][mkt(-2,2,0)]<<endl;
    get_oppo_choice(can_move_nopriest, scores);
    //现在人走完了
    //outfile<<map_record.size()<<endl;
//    //outfile<<"estimate6"<<endl;
    //牧师复活
    for(auto& priest:can_move_priest)
    {
        mp[priest.id].hp *= -1;
        if(my_map.find(priest.pos)==my_map.end())my_map[priest.pos] = 2;
        else my_map[priest.pos] += 2;
    }


    vector<pair<int,Pos> >other_move;
//    //outfile<<map_record.size()<<"map_record"<<endl;
    for(auto& i: map_record)
    {
        other_move.emplace_back(mk(i.first, mp[i.first].pos));
    }

//    //outfile<<"estimate7"<<endl;

//    //outfile<<other_move.size()<<endl;
    //计算牧师的收益

    vector<unordered_map<Pos, double,key_hash> >scores2;
    for(int i=0;i<can_move_priest.size();i++)
    {
        auto& unit = can_move_priest[i];
        scores2.emplace_back(unordered_map<Pos, double,key_hash>());
        auto move_set = get_pos_from_range(unit.pos, 0, unit.max_move);
        double mx = -DOUBLE_INF;
        calc_center();
        for(auto& pos:move_set)
        {
//            //outfile<<pos<<endl;
            scores2[i][pos] = estimate2(unit.id, pos);
//            //outfile<<pos<<endl;
        }
    }

//    //outfile<<"estimate8"<<endl;
    //计算所有牧师的机会成本
//    update_mymap();//更新己方的位置
    get_oppo_choice(can_move_priest, scores2);
//    //outfile<<map_record.size()<<endl;
//    //outfile<<"estimate9"<<endl;
    vector<pair<int,Pos> >priest_move;
    for(int i=can_move_priest.size();i>0;i--)
    {
        auto tmp = map_record[map_record.size()-i];
        priest_move.emplace_back(mk(tmp.first, mp[tmp.first].pos));
    }
    //在这里清空
    while(!map_record.empty())back_mymap();

    pass.clear();
    best_answer_search2.clear();

    //outfile<<"estimate10"<<endl;
    flag_search2 = false;
    search2(1,1,1,other_move,priest_move);
//    //outfile<<map_record.size()<<endl;
//    for(auto&unit:enemy_list)
//    {
//        if(mp[unit.id].hp>0)
//        {
//            //outfile<<mp[unit.id].pos<<endl;
//        }
//    }
//    for(auto&unit:my_list)
//    {
//        if(mp[unit.id].hp>0)
//        {
//            //outfile<<mp[unit.id].pos<<endl;
//        }
//    }
//    for(int i=0;i<other_move.size();i++)
//    {
//        //outfile<<other_move[i].first<<' '<<mp[other_move[i].first].pos<<other_move[i].second<<endl;
//    }
//    for(int i=0;i<priest_move.size();i++)
//    {
//        //outfile<<priest_move[i].first<<' '<<mp[priest_move[i].first].pos<<priest_move[i].second<<endl;
//    }
    //outfile<<"flag_search_2"<<flag_search2<<' '<<map_record.size()<<endl;
    if(!flag_search2)
    {
        get_oppo_choice(can_move_nopriest, scores);
        for(int i=0;i<can_move_priest.size();i++)
        {
            auto& unit = can_move_priest[i];
            scores2.emplace_back(unordered_map<Pos, double,key_hash>());
            auto move_set = get_pos_from_range(unit.pos, 0, unit.max_move);
            calc_center();
            for(auto& pos:move_set)
            {
                scores2[i][pos] = estimate2(unit.id, pos);
            }
        }
        get_oppo_choice(can_move_priest, scores2);
        other_move.clear();
        priest_move.clear();
        pass.clear();
        best_answer_search2.clear();
        for(auto& i: map_record)
        {
            other_move.emplace_back(mk(i.first, mp[i.first].pos));
        }
        while(!map_record.empty())back_mymap();
        search2(1,1,1,other_move,priest_move);
        //outfile<<"flag_search_2_again"<<flag_search2<<endl;
    }
    for(int i=0;i<best_answer_search2.size();i++)
    {
        int size = other_move.size();
        if(best_answer_search2[i]<size)
            my_move(other_move[best_answer_search2[i]].first,
                    other_move[best_answer_search2[i]].second);
        else my_move(priest_move[best_answer_search2[i]-size].first,
                     priest_move[best_answer_search2[i]-size].second);
    }

    //outfile<<"estimate11"<<endl;
    calc_center();
    for(auto unit:my_list)
    {
        if(mp[unit.id].hp>0)
        {
//            //outfile<<estimate2(unit.id, mp[unit.id].pos)<<endl;
            value+=estimate2(unit.id, mp[unit.id].pos);
        }
    }
//    for(auto unit:enemy_list)
//    {
//        if(mp[unit.id].hp>0)
//        {
//            value -= estimate2(unit.id,mp[unit.id].pos);
//        }
//    }

//    //outfile<<value<<"passsize"<<pass.size()<<endl;

    //outfile<<"value and best_value "<<value<<' '<<best_answer_value<<' '<<best_answer_search2.size()<<endl;
    if(value>best_answer_value)
    {
        best_answer_value = value;
        best_answer.clear();
        best_answer_move.clear();
        //outfile<<"record and best_answer_size"<<record.size()<<' '<<best_answer_search2.size()<<endl;
        for(int i=0;i<record.size();i++)
        {
            auto &tmp = record[i];
            if(get<1>(tmp)==-1)continue;
            best_answer.emplace_back(mk(get<1>(tmp),get<0>(tmp)));
        }
        for(int i=0;i<best_answer_search2.size();i++)
        {
            int size = other_move.size();
            //outfile<<best_answer_search2[i]<<endl;
//            //outfile<<"best_answer_search: "<<size<<' '<<i<<' '<<priest_move.size()<<endl;
            if(best_answer_search2[i]<size)
                best_answer_move.emplace_back(mk(other_move[best_answer_search2[i]].first,other_move[best_answer_search2[i]].second));
            else best_answer_move.emplace_back(mk(priest_move[best_answer_search2[i]-size].first,priest_move[best_answer_search2[i]-size].second));
        }
        //这里增加其他人是怎么移动的
    }
    while(!map_record.empty())back_mymap();
    return value;
}

void AI::search(int deep, vector<int>& to_attack)
{
    //outfile<<"search:"<<deep<<' '<<can_attack.size()<<endl;
    if(deep == to_attack.size()+1)
    {
        estimate();
        return ;
    }
    int id = to_attack[deep-1];
    if(can_attack_list[id].back()==(my_camp^1)&&
       mp[can_attack[id].id].atk>=3)
    {
        int cnt = record.size();
        my_attack(can_attack[id].id, my_camp^1);
        search(deep+1, to_attack);
        while(record.size()!=cnt)
        {
            auto tmp = record.back();
            record.pop_back();
            mp[get<0>(tmp)].hp += get<2>(tmp);
            mp[get<1>(tmp)].can_atk = true;
            mp[get<1>(tmp)].can_move = true;
        }
        return;
    }
    for(auto &k : can_attack_list[id])
    {
        Unit& unit = mp[k];
        if(unit.hp>0)
        {
            int cnt = record.size();
            my_attack(can_attack[id].id, unit.id);

            search(deep+1, to_attack);

            while(record.size()!=cnt)
            {
                auto tmp = record.back();
                record.pop_back();
                mp[get<0>(tmp)].hp += get<2>(tmp);
                mp[get<1>(tmp)].can_atk = true;
                mp[get<1>(tmp)].can_move = true;
            }
        }
    }

}
void AI::do_attack(Unit &ally, vector<Unit> &target_list)
{
    if(target_list.size()==0)return ;
    if(ally.type == "Swordsman")
    {
        sort(target_list.begin(), target_list.end(),
             [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
    }
    if(ally.type == "VolcanoDragon")
    {

    }
    if(ally.type == "Priest")
    {
        if(ally.atk==0)return;
        Unit best_target = target_list[0];
        best_target.id = -1;
        for(auto target:target_list)
        {
            if(target.cost>=4&&target.hp<=ally.atk)
            {
                if(best_target.id == -1 ||(AiClient::canAttack(best_target,ally)&&!AiClient::canAttack(target, ally)))
                {
                    best_target = target;
                }
                else if(target.cost>best_target.cost)
                {
                    best_target = target;
                }
            }
        }
        if(best_target.id!=-1)attack(ally.id, best_target.id);
        return ;
    }
    /*
    for(auto target:target_list)
    {
        if (ally.type == "VolcanoDragon")
        {
            default_random_engine g(static_cast<unsigned int>(time(nullptr)));
            int tar = uniform_int_distribution<>(0, target_list.size() - 1)(g);
            attack(ally.id, target_list[tar].id);
        }
        else if (ally.type == "Swordsman")
        {
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        }
        else if (ally.type == "Priest")
        {
            sort(enemy_list.begin(), enemy_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list)
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue;
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        }
    }*/
}
Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
    return make_tuple(-INT_INF,-INT_INF,-INT_INF);
}
void AI::my_attack(int attacker, int defender)
{
    Unit& Attacker = mp[attacker];
    Unit& Defender = mp[defender];
    Attacker.can_atk = false;
    Attacker.can_move = false;
    Defender.hp -= Attacker.atk;
    record.emplace_back(mkt(Defender.id, Attacker.id, Attacker.atk));
    if(Defender.id<=1)return ;
    if(AiClient::canAttack(Defender, Attacker))
    {
        Attacker.hp -= Defender.atk;
        record.emplace_back(mkt(Attacker.id, -1, Defender.atk));
    }
//这一段貌似用不到
/* vector<Unit>& enemy
    if(Attacker.type == "VolcanoDragon")
    {
        for(auto unit:enemy)
        {
            if(cube_distance(unit.pos, Attacker.pos)==2&&cube_distance(unit.pos, Defender.pos)==1)
            {
                mp[unit.id].hp -= Attacker.level+2;
                record.push(mk(Defender.id, Attacker.level+2));
            }
        }
    }
    */
}
void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 火山龙：攻击高>低 （大AOE输出），随机攻击
     * 剑士：攻击低>高 打消耗，优先打攻击力低的
     * 弓箭手：攻击高>低 优先打不能反击的攻击力最高的，其次打能反击的攻击力最低的
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 例如占领着驻扎点的敌方生物具有极高的价值，优先摧毁可以使敌方下回合损失很多可用出兵点
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */

    auto ally_list = AiClient::getUnitsByCamp(my_camp);

    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//火山龙>剑士>弓箭手
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "Archer") return 0;
                else if (type_name == "Swordsman") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "VolcanoDragon" or unit1.type == "Priest")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };



    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);
    can_attack.clear();
    visited.clear();
    mp.clear();

    enemy_list = AiClient::getUnitsByCamp(my_camp ^ 1);
    my_list = getUnitsByCamp(my_camp);
    for(int i=0;i<my_list.size();i++)mp[my_list[i].id] = my_list[i];
    for(int i=0;i<enemy_list.size();i++)mp[enemy_list[i].id] = enemy_list[i];
    for(int i=0;i<=1;i++)
    {
        mp[i] = Unit();
        mp[i].id = mp[i].camp = i;
        mp[i].hp = map.miracles[my_camp^1].hp;
        mp[i].camp = i;
    }

    can_attack_list.clear();
    for (auto &ally:ally_list)
    {
        if (!ally.can_atk) break;
        vector<int> target_list;

        for (const auto &enemy : enemy_list)
        {
//            //outfile<<"attackDis"<<' '<<cube_distance(enemy.pos, ally.pos)<<endl;
            if (AiClient::canAttack(ally, enemy))
                target_list.push_back(enemy.id);
        }//得到能够攻击的目标
        int dis =  cube_distance(ally.pos, enemy_pos);
        if(dis <= ally.atk_range[1] && dis>=ally.atk_range[0])target_list.push_back(my_camp^1);

        if(target_list.size()!=0)
        {
            can_attack.push_back(ally);
            can_attack_list.push_back(target_list);
        }
    }

    for(int i=0;i<can_attack.size();i++)visited.push_back(0);
    best_answer_value = -DOUBLE_INF;
    //outfile<<"mp"<<mp.size()<<endl;

//    search(1); 17201
//    pries_list.clear();
//    枚举一下每个人攻不攻击

    int cnt = can_attack.size();
    vector<int> to_attack;
    //outfile<<cnt<<endl;
    for(int i=(1<<cnt)-1;i>=0;i--)
    {
        to_attack.clear();
        for(int j=0;j<cnt;j++)
        {
            if((1<<j)&i) //牧师j要移动
            {
                to_attack.push_back(j);
                //这些去攻击
            }
        }
        if((clock()-(double)start_time)/CLOCKS_PER_SEC > 2.6)break;
        search(1,to_attack);
    }
    //outfile<<"attacksie:"<<best_answer.size()<<endl;
    for(auto& action:best_answer)
    {
        //outfile<<"attack:"<<action.first<<' '<<action.second<<endl;
        attack(action.first, action.second);
        //outfile<<"time:"<<(clock()-(double)start_time)/CLOCKS_PER_SEC<<endl;
    }
    //outfile<<"movesize:"<<best_answer_move.size()<<endl;
    for(auto& action:best_answer_move)
    {
        //outfile<<"move:"<<action.first<<action.second<<endl;
//        //outfile<<canMove(action.first, action.second)<<endl;
//        //outfile<<mp[action.first].pos<<endl;
        move(action.first, action.second);
        //outfile<<"time:"<<(clock()-(double)start_time)/CLOCKS_PER_SEC<<endl;

        auto tmp = getUnitByPos(action.second,0);
        if(tmp.id!=action.first)
        {
            //outfile<<"move not success"<<endl;
        }
    }
    //最后攻击神迹
}
int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <unordered_map>
#include <unordered_set>
#include <fstream>
#include <cstdlib>
#include <random>
#include <ctime>
#include <map>
#include <cstring>
#include <stack>
#include <queue>
#define mk make_pair
#define mkt make_tuple
#define DOUBLE_INF 1e60
#define INT_INF 0x3f3f3f3f
#define fi first
#define se second
using namespace std;


using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

typedef std::tuple<int, int, int> keys;

struct key_hash : public std::unary_function<keys, std::size_t>
{
    std::size_t operator()(const keys& k) const
    {
        return 1000000 + std::get<0>(k)*10000 + std::get<1>(k)*100 + std::get<2>(k);
    }
};

class AI : public AiClient
{
private:

    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack;

    Pos posShift(Pos pos, string direct);
public:

    Pos center_pos;

    int priest_mode;

    std::unordered_map<tuple<int,int,int>, int, key_hash>hurtmp,my_map;

    vector<Unit>pries_list;

    int my_mode,enemy_mod;

    static const Pos directions[6];
    static const double w[3][6];

    Pos archer_pos[2][3];

    bool is_bat;

    vector<vector<int> > can_attack_list;

    vector<Pos> summon_pos_list;

    vector<Unit > can_attack;

    vector<Unit > can_move,can_move_nopriest,can_move_priest;

    vector<Unit> my_list;

    vector<Unit> enemy_list;

    vector<int> visited;

    ::unordered_map<int, Unit>mp;

    vector<tuple<int,int,int> >record; //回溯栈 id 受到的伤害
    vector<pair<int,Pos> >map_record; //己方位置修改的回溯栈

    vector<string>creature;

    vector<pair<int,int> >best_answer;
    vector<pair<int,Pos> >best_answer_move;

    double best_answer_value;

    vector<tuple<int, Pos,Pos> >priest_move;

    Pos posShift(Pos pos, string direct);

public:
    //閫夋嫨鍒濆鍗＄粍
    void chooseCards(); //(鏍规嵁鍒濆闃佃惀)閫夋嫨鍒濆鍗＄粍

    void play(); //鐜╁闇€瑕佺紪鍐欑殑ai鎿嶄綔鍑芥暟

    void battle(); //澶勭悊鐢熺墿鐨勬垬鏂�

    void march(); //澶勭悊鐢熺墿鐨勭Щ鍔�
    AI():AiClient()
    {

    }
};
const Pos AI::directions[6] =
        {make_tuple(+1,-1,0),make_tuple(+1,0,-1),make_tuple(0,+1,-1),
         make_tuple(-1,+1,0),make_tuple(-1,0,+1),make_tuple(0,-1,+1)};
const double AI::w[3][6] = //第二行是攻击模式，第三行是防御模式
        {
                {0,0,0,0,0,0},
                {1,1,1,1,1,1},
                {1,1,1,1,1,1}
        };
void AI::chooseCards()
{
    // (鏍规嵁鍒濆闃佃惀)閫夋嫨鍒濆鍗＄粍

    /*
     * artifacts鍜宑reatures鍙互淇敼
     * 銆愯繘闃躲€戝湪閫夋嫨鍗＄墝鏃讹紝灏卞凡缁忕煡閬撲簡鑷繁鐨勬墍鍦ㄩ樀钀ュ拰鍏堝悗鎵嬶紝鍥犳鍙互鍦ㄦ澶勬牴鎹厛鍚庢墜鐨勪笉鍚岃缃笉鍚岀殑鍗＄粍鍜岀鍣�
     */
    my_artifacts = {"HolyLight"};
    my_creatures = {"Archer", "Swordsman", "VolcanoDragon"};
    init();
}

void AI::play()
{
    //鐜╁闇€瑕佺紪鍐欑殑ai鎿嶄綔鍑芥暟

    /*
    鏈珹I閲囩敤杩欐牱鐨勭瓥鐣ワ細
    鍦ㄩ鍥炲悎杩涜鍒濇湡璁剧疆銆佸湪绁炶抗浼樺娍璺晶鍓嶆柟鐨勫嚭鍏电偣鍙敜涓€涓�1鏄熷紦绠墜
    鎺ヤ笅鏉ョ殑姣忓洖鍚堬紝棣栧厛灏藉彲鑳戒娇鐢ㄧ鍣紝鎺ョ潃鎵ц鐢熺墿鐨勬垬鏂楋紝鐒跺悗瀵逛簬娌℃湁杩涜鎴樻枟鐨勭敓鐗╋紝鎵ц绉诲姩锛屾渶鍚庤繘琛屽彫鍞�
    鍦ㄨ垂鐢ㄨ緝浣庢椂灏藉彲鑳藉彫鍞ゆ槦绾т负1鐨勫叺锛屼紭鍏堝害鍓戝＋>寮撶鎵�>鐏北榫�
    銆愯繘闃躲€戝彲浠ュ灞€闈㈣繘琛岃瘎浼帮紝浼樺寲绁炲櫒鐨勪娇鐢ㄦ椂鏈恒€佽皟鏁存瘡涓敓鐗╄鍔ㄧ殑椤哄簭銆佽皟鏁村彫鍞ょ殑浣嶇疆鍜岀敓鐗╃绫汇€佹槦绾х瓑
    */
    if (round == 0 || round == 1) {
        //鍏堢‘瀹氳嚜宸辩殑鍩哄湴銆佸鏂圭殑鍩哄湴
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //璁惧畾鐩爣椹绘墡鐐逛负鏈€杩戠殑椹绘墡鐐�

        target_barrack = map.barracks[0].pos;
        //纭畾绂昏嚜宸卞熀鍦版渶杩戠殑椹绘墡鐐圭殑浣嶇疆
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        // 鍦ㄦ涓績鍋忓彸鍙敜涓€涓紦绠墜锛岀敤鏉ユ姠鍗犻┗鎵庣偣
        summon("Archer", 1, posShift(miracle_pos, "SF"));
    } else {
        //绁炲櫒鑳界敤灏辩敤锛岄€夋嫨瑕嗙洊鍗曚綅鏁版渶澶氱殑鍦扮偣
        if (players[my_camp].mana >= 6 && players[my_camp].artifact[0].state == "Ready") {
            auto pos_list = all_pos_in_map();
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            use(players[my_camp].artifact[0].id, best_pos);
        }

        //涔嬪悗鍏堟垬鏂楋紝鍐嶇Щ鍔�
        battle();

        march();

        //鏈€鍚庤繘琛屽彫鍞�
        //灏嗘墍鏈夋湰鏂瑰嚭鍏电偣鎸夌収鍒板鏂瑰熀鍦扮殑璺濈鎺掑簭锛屼粠杩戝埌杩滃嚭鍏�
        auto summon_pos_list = getSummonPosByCamp(my_camp);
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
        });
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
        }

        //缁熻鍚勪釜鐢熺墿鐨勫彲鐢ㄦ暟閲忥紝鍦ㄥ亣璁惧嚭鍏电偣鏃犻檺鐨勬儏鍐典笅锛屾寜鐓�1涓墤澹€�1涓紦绠墜銆�1涓伀灞遍緳鐨勯『搴忓彫鍞�
        int mana = players[my_camp].mana;
        auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;

        vector<string> summon_list;
        //鍓戝＋鍜屽紦绠墜鏁伴噺涓嶈冻鎴栬€呮牸瀛愪笉瓒冲垯鍙敜鐏北榫�
        if ((available_summon_pos_list.size() == 1 || available_count["Swordsman"] + available_count["Archer"] < 2) &&
            mana >= CARD_DICT.at("VolcanoDragon")[1].cost && available_count["VolcanoDragon"] > 0) {
            summon_list.emplace_back("VolcanoDragon");
            mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
        }

        bool suc = true;
        while (mana >= 2 && suc) {
            suc = false;
            if (available_count["Swordsman"] > 0 && mana >= CARD_DICT.at("Swordsman")[1].cost) {
                summon_list.emplace_back("Swordsman");
                mana -= CARD_DICT.at("Swordsman")[1].cost;
                available_count["Swordsman"] -= 1;
                suc = true;
            }
            if (available_count["Archer"] > 0 && mana >= CARD_DICT.at("Archer")[1].cost) {
                summon_list.emplace_back("Archer");
                mana -= CARD_DICT.at("Archer")[1].cost;
                available_count["Archer"] -= 1;
                suc = true;
            }
            if (available_count["VolcanoDragon"] > 0 && mana >= CARD_DICT.at("VolcanoDragon")[1].cost) {
                summon_list.emplace_back("VolcanoDragon");
                mana -= CARD_DICT.at("VolcanoDragon")[1].cost;
                available_count["VolcanoDragon"] -= 1;
                suc = true;
            }
        }

        int i = 0;
        for (auto pos:available_summon_pos_list) {
            if (i == summon_list.size()) break;
            summon(summon_list[i], 1, pos);
            ++i;
        }
    }
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 瀵逛簬缁欏畾浣嶇疆锛岀粰鍑烘寜鐓ц嚜宸辩殑瑙嗚锛堢杩瑰湪鏈€涓嬫柟锛夌殑鏌愪釜鏂瑰悜绉诲姩涓€姝ュ悗鐨勪綅缃�
     * 鏈浠ｇ爜鍙互鑷敱鍙栫敤
     * @param pos:  (x, y, z)
     * @param direct: 涓€涓猻tr锛屽惈2涓瓧绗︼紝鎰忎箟瑙佹敞閲�
     * @return: 绉诲姩鍚庣殑浣嶇疆 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //姝ｅ墠鏂�
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //浼樺娍璺墠鏂癸紙鑷韩瑙嗚鍙充晶涓轰紭鍔胯矾锛�
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //鍔ｅ娍璺墠鏂�
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //姝ｅ悗鏂�
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //浼樺娍璺悗鏂�
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //鍔ｅ娍璺悗鏂�
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //姝ｅ墠鏂�
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //浼樺娍璺墠鏂癸紙鑷韩瑙嗚鍙充晶涓轰紭鍔胯矾锛�
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //鍔ｅ娍璺墠鏂�
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //姝ｅ悗鏂�
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //浼樺娍璺悗鏂�
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //鍔ｅ娍璺悗鏂�
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::battle()
{
    //澶勭悊鐢熺墿鐨勬垬鏂�

    /*
     * 鍩烘湰鎬濊矾锛岃鍔ㄩ『搴�:
     * 鐏北榫欙細鏀诲嚮楂�>浣� 锛堝ぇAOE杈撳嚭锛夛紝闅忔満鏀诲嚮
     * 鍓戝＋锛氭敾鍑讳綆>楂� 鎵撴秷鑰楋紝浼樺厛鎵撴敾鍑诲姏浣庣殑
     * 寮撶鎵嬶細鏀诲嚮楂�>浣� 浼樺厛鎵撲笉鑳藉弽鍑荤殑鏀诲嚮鍔涙渶楂樼殑锛屽叾娆℃墦鑳藉弽鍑荤殑鏀诲嚮鍔涙渶浣庣殑
     * 瀵瑰崟浣嶇殑鎴樻枟瀹屾垚鍚庯紝瀵圭杩硅繘琛岃緭鍑�
     * 銆愯繘闃躲€戝鎴樻枟鑼冨洿鍐呮晫鏂圭洰鏍囩殑浠峰€艰繘琛岃瘎浼帮紝閫氳繃涓€浜涘尮閰嶇畻娉曞喅瀹氭渶浼樼殑鎴樻枟鏂瑰紡
     * 渚嬪鍗犻鐫€椹绘墡鐐圭殑鏁屾柟鐢熺墿鍏锋湁鏋侀珮鐨勪环鍊硷紝浼樺厛鎽ф瘉鍙互浣挎晫鏂逛笅鍥炲悎鎹熷け寰堝鍙敤鍑哄叺鐐�
     * 涓€浜涚敓鐗╀笉鏀诲嚮鑰岀Щ鍔紝鎴栧畬鍏ㄤ笉鍔紝鍙兘鑳藉甫鏉ユ洿澶х殑濞佹厬鍔涳紝鑰岃耽寰楁洿澶氫紭鍔�
     */

    auto ally_list = getUnitsByCamp(my_camp);

    //鑷畾涔夋帓鍒楅『搴�
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //棣栧厛瑕佽兘鍔�
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//鐏北榫�>鍓戝＋>寮撶鎵�
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "VolcanoDragon") return 0;
                else if (type_name == "Swordsman") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } else if (unit1.type == "VolcanoDragon" or unit1.type == "Archer")
            return unit2.atk < unit1.atk;
        else return unit1.atk < unit2.atk;
    };
    //鎸夐『搴忔帓鍒楀ソ鍗曚綅锛屼緷娆℃敾鍑�
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (const auto &ally:ally_list) {
        if (!ally.can_atk) break;
        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;
        for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(ally, enemy))
                target_list.push_back(enemy);
        if (target_list.empty()) continue;
        if (ally.type == "VolcanoDragon") {
            default_random_engine g(static_cast<unsigned int>(time(nullptr)));
            int tar = uniform_int_distribution<>(0, target_list.size() - 1)(g);
            attack(ally.id, target_list[tar].id);
        } else if (ally.type == "Swordsman") {
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        } else if (ally.type == "Archer") {
            sort(enemy_list.begin(), enemy_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list)
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue;
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        }
    }
    //鏈€鍚庢敾鍑荤杩�
    ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), cmp);
    for (auto ally : ally_list) {
        if (!ally.can_atk) break;
        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1])
            attack(ally.id, my_camp ^ 1);
    }
}

void AI::march()
{
    //澶勭悊鐢熺墿鐨勭Щ鍔�

    /*
     * 鍏堝姩鎵€鏈夊墤澹紝灏藉彲鑳藉悜鏁屾柟绁炶抗绉诲姩
     * 鑻ョ洰鏍囬┗鎵庣偣涓婃病鏈夊湴闈㈠崟浣嶏紝鍒欒寮撶鎵嬪悜鐩爣椹绘墡鐐圭Щ鍔紝鍚﹀垯灏藉彲鑳藉悜鏁屾柟绁炶抗绉诲姩
     * 鐒跺悗鑻ョ洰鏍囬┗鎵庣偣涓婃病鏈夊湴闈㈠崟浣嶏紝鍒欒鐏北涔嬮緳鍚戠洰鏍囬┗鎵庣偣绉诲姩锛屽惁鍒欏敖鍙兘鍚戞晫鏂圭杩圭Щ鍔�
     * 銆愯繘闃躲€戜竴鍛冲悜鏁屾柟绁炶抗绉诲姩骞朵笉涓€瀹氭槸涓ソ涓绘剰
     * 鍦ㄧЩ鍔ㄧ殑鏃跺€欏彲浠ヨ€冭檻涓€涓嬮伩寮€鏁屾柟鐢熺墿鏀诲嚮鑼冨洿瀹炵幇銆佷负宸辨柟寮哄姏鐢熺墿璁╄矾銆佸牭浣忔晫鏂瑰嚭鍏电偣绛夌瓥鐣�
     * 濡傛灉閲囩敤鍏朵粬鐢熺墿缁勫悎锛屽彲浠ヨ€冭檻鎶㈠崰鏇村椹绘墡鐐�
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {
            if (type_name == "Swordsman") return 0;
            else if (type_name == "Archer") return 1;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
    for (const auto &ally : ally_list) {
        if (!ally.can_move) continue;
        if (ally.type == "Swordsman") {
            //鑾峰彇鎵€鏈夊彲鍒拌揪鐨勪綅缃�
            auto reach_pos_with_dis = reachable(ally, map);
            //鍘嬪钩
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
            //浼樺厛璧板埌璺濈鏁屾柟绁炶抗鏇磋繎鐨勪綅缃�
            nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                        [this](Pos _pos1, Pos _pos2) {
                            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                        });
            move(ally.id, reach_pos_list[0]);
        } else {
            //濡傛灉宸茬粡鍦ㄥ叺钀ュ氨涓嶅姩浜�
            bool on_barrack = false;
            for (const auto &barrack:map.barracks)
                if (ally.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }
            if (on_barrack) continue;

            //鑾峰彇鎵€鏈夊彲鍒拌揪鐨勪綅缃�
            auto reach_pos_with_dis = reachable(ally, map);
            //鍘嬪钩
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //浼樺厛璧板埌鏈鍗犻鐨勫叺钀ワ紝鍚﹀垯璧板埌
            if (getUnitByPos(target_barrack, false).id == -1) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        }
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

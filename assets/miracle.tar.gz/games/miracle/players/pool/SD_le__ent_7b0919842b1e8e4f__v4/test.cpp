//
// Created by 仰效益 on 2020-04-29.
//

#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;
int main()
{
    vector<mak>a,b;
    a.push_back(0);
    a.push_back(1);
    b = a;
    cout<<b.size()<<endl;
    a.pop_back();
    cout<<b.size()<<' '<<a.size()<<endl;
    return 0;
}
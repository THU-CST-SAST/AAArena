#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

const int oo = 1000;

class AI : public AiClient
{
private:
    Pos my_miracle, enemy_miracle, left_barrack, enemy_barrack, my_barrack, right_barrack,
            center_archer, left_archer, right_archer,
            miracle_ff, miracle_sf, miracle_if,
            left_back_priest, right_back_priest, left_front_priest, right_front_priest;

    Pos posShift(Pos pos, string direct);

    int id_pioneer, id_barrack_defender, id_artifact;
    vector<int> id_left_swordsman, id_right_swordsman;

    ::map<string, int> available_count;

    vector<Unit> ally_list, enemy_list;

    bool my_can_move(Unit unit, string type)
    {
        return unit.id != -1 && unit.camp == my_camp && unit.type == type && unit.can_move;
    }

    vector<Pos> reachable_all(Unit ally, gameunit::Map map)
    {
        vector<Pos> ret;
        auto reachable_pos_with_dis = calculator::reachable(ally, map);
        for (const auto &reachable_pos : reachable_pos_with_dis)
            for (auto pos : reachable_pos)
                ret.push_back(pos);
        return ret;
    }

    Pos get_closest_barrack(Pos target)
    {
        Pos ret = map.barracks[0].pos;
        for (const auto &barrack:map.barracks) {
            if (cube_distance(target, barrack.pos) > 0 &&
                cube_distance(target, barrack.pos) < cube_distance(target, ret))
                ret = barrack.pos;
        }
        return ret;
    }

    void move_without_hurt(int id, Pos target)
    {
        Unit ally = getUnitById(id);
        if (ally.id == -1) return;
        if (!ally.can_move) return;
        auto reachable_pos_all = reachable_all(ally, map);
        int found_safe = 0;
        Pos destination;
        for (auto pos : reachable_pos_all)
            if (!found_safe || cube_distance(pos, target) < cube_distance(destination, target))
            {
                int can_go = 1;
                enemy_list = getUnitsByCamp(my_camp ^ 1);
                for (Unit enemy : enemy_list)
                {
                    int enemy_attack_dist = cube_distance(pos, enemy.pos);
                    if (enemy.atk_range[0] <= enemy_attack_dist && enemy_attack_dist <= enemy.atk_range[1])
                    {
                        can_go = 0;
                        break;
                    }
                }
                if (can_go)
                {
                    destination = pos;
                    found_safe = 1;
                }
            }
        if (destination != ally.pos)
            move(ally.id, destination);
    }

    void move_and_fight(int id, Pos target)
    {
        Unit ally = getUnitById(id);
        if (ally.id == -1) return;
        if (!ally.can_move) return;
        Unit target_unit = getUnitByPos(target, 0);
        if (target_unit.id != -1 && canAttack(ally, target_unit))
        {
            attack(ally.id, target_unit.id);
            return;
        }
        auto reachable_pos_all = reachable_all(ally, map);
        Pos destination = reachable_pos_all[0];
        enemy_list = getUnitsByCamp(my_camp ^ 1);
        for (int allowable_move = 1; allowable_move <= 3; allowable_move++)
        {
            for (auto pos : reachable_pos_all)
                if (cube_distance(pos, target) < cube_distance(destination, target))
                {
                    int can_go = 1, total_damage = 0, can_attack = 0;
                    enemy_list = getUnitsByCamp(my_camp ^ 1);
                    for (Unit enemy : enemy_list)
                    {
                        int enemy_attack_dist = cube_distance(pos, enemy.pos);
                        bool this_not_allowed = 0;
                        switch (allowable_move)
                        {
                            case 1:
                                this_not_allowed = enemy.atk_range[0] <= enemy_attack_dist &&
                                                   enemy_attack_dist <= enemy.atk_range[1];
                                break;
                            case 2:
                                this_not_allowed = enemy.atk_range[0] <= enemy_attack_dist &&
                                                   enemy_attack_dist <= enemy.atk_range[1] &&
                                                   !(ally.atk_range[0] <= enemy_attack_dist &&
                                                     enemy_attack_dist <= ally.atk_range[1]);
                                break;
                            case 3:
                                if (enemy.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= enemy.atk_range[1])
                                    total_damage += enemy.atk;
                                if (ally.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= ally.atk_range[1])
                                    can_attack = 1;
                                break;

                        }
                        if (this_not_allowed)
                        {
                            can_go = 0;
                            break;
                        }
                    }
                    if (allowable_move == 3)
                        can_go = total_damage < ally.hp && can_attack;
                    if (can_go) destination = pos;
                }
            if (destination != ally.pos)
            {
                move(ally.id, destination);
                return;
            }
        }
    }

    void fight_and_move(int id, Pos target)
    {
        Unit ally = getUnitById(id);
        if (ally.id == -1) return;
        if (!ally.can_move) return;
        Unit target_unit = getUnitByPos(target, 0);
        if (target_unit.id != -1 && canAttack(ally, target_unit))
        {
            attack(ally.id, target_unit.id);
            return;
        }
        int dis_miracle = cube_distance(ally.pos, enemy_miracle);
        if (ally.atk_range[0] <= dis_miracle && dis_miracle <= ally.atk_range[1]) {
            attack(ally.id, my_camp ^ 1);
            return;
        }
        enemy_list = getUnitsByCamp(my_camp ^ 1);
        Unit strongest_enemy;
        bool there_is_strongest_enemy = 0;
        for (const auto &enemy : enemy_list) {
            if (AiClient::canAttack(ally, enemy) && !AiClient::canAttack(enemy, ally)) {
                if (!there_is_strongest_enemy) {
                    there_is_strongest_enemy = 1;
                    strongest_enemy = enemy;
                } else if (enemy.atk > strongest_enemy.atk)
                    strongest_enemy = enemy;
            }
        }
        if (there_is_strongest_enemy)
        {
            attack(ally.id, strongest_enemy.id);
            return;
        }

        //然后打有伤的。他死我不死>同生共死>我死他不死
        enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> classified_enemy[3];
        for (const auto &enemy : enemy_list) {
            if (AiClient::canAttack(ally, enemy)) {
                classified_enemy[(ally.atk >= enemy.hp) + (ally.hp > enemy.atk)].push_back(enemy);
            }
        }
        vector<Unit> to_attack;
        bool there_is_to_attack = 0;
        for (int i = 2; i >= 0; i--) {
            if (!classified_enemy[i].empty()) {
                to_attack = classified_enemy[i];
                there_is_to_attack = 1;
                break;
            }
        }
        if (there_is_to_attack)
        {
            Unit best_enemy = to_attack[0];
            for (const auto &enemy : to_attack)
            {
                if (enemy.atk + enemy.hp > best_enemy.atk + best_enemy.hp)
                    best_enemy = enemy;
            }
            attack(ally.id, best_enemy.id);
            return;
        }
        auto reachable_pos_all = reachable_all(ally, map);
        Pos destination = reachable_pos_all[0];
        bool good;
        enemy_list = getUnitsByCamp(my_camp ^ 1);
        for (int allowable_move = 1; allowable_move <= 2; allowable_move++)
        {
            good = 0;
            for (auto pos : reachable_pos_all)
                if (!good || cube_distance(pos, target) < cube_distance(destination, target))
                {
                    int can_fight = 0, be_attacked = 0;
                    enemy_list = getUnitsByCamp(my_camp ^ 1);
                    for (Unit enemy : enemy_list)
                    {
                        int enemy_attack_dist = cube_distance(pos, enemy.pos);
                        switch (allowable_move)
                        {
                            case 1:
                                if (ally.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= ally.atk_range[1])
                                    can_fight = 1;
                                else if (enemy.atk_range[0] <= enemy_attack_dist &&
                                         enemy_attack_dist <= enemy.atk_range[1])
                                    be_attacked = 100;
                                break;
                            case 2:
                                if (ally.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= ally.atk_range[1])
                                    can_fight = 1;
                                else if (enemy.atk_range[0] <= enemy_attack_dist &&
                                         enemy_attack_dist <= enemy.atk_range[1])
                                    be_attacked = enemy.atk;
                                break;
                        }
                    }
                    if (can_fight && be_attacked < ally.hp) destination = pos;
                }
            if (destination != ally.pos)
            {
                move(ally.id, destination);
                return;
            }
        }
        move_and_fight(id, target);
    }

    int make_unit(string type, Pos pos, int min_lvl)
    {
        std::cerr << type << min_lvl << std::endl;
        auto temp = players[my_camp].creature_capacity;
        int avail = 0;
        for (auto cap : temp)
            if (cap.type == type)
            {
                avail = cap.available_count;
                break;
            }
        std::cerr << players[my_camp].mana << std::endl;
        if (avail >= 1 && getUnitByPos(pos, 0).id == -1)
            for (int level = (type == "Swordsman" && round > 30 ? 2 : 3); level >= min_lvl; level--)
                if (players[my_camp].mana >= CARD_DICT.at(type)[level].cost)
                {
                    summon(type, level, pos);
                    return 1;
                    std::cerr << "Succ." << std::endl;
                    break;
                }
        return 0;
    }

    void swordsman_behav()
    {
        std::cerr << "Swordsman behave." << std::endl;
        std::cerr << "Left for miracle." << std::endl;
        for (const auto &left_swordsman : id_left_swordsman)
        {
            Unit this_swordsman = getUnitById(left_swordsman);
            if (this_swordsman.id == -1) continue;
            int dis_miracle = cube_distance(this_swordsman.pos, enemy_miracle);
            if (this_swordsman.atk_range[0] <= dis_miracle && dis_miracle <= this_swordsman.atk_range[1])
                attack(this_swordsman.id, my_camp ^ 1);
        }
        std::cerr << "Right for miracle." << std::endl;
        for (const auto &right_swordsman : id_right_swordsman)
        {
            Unit this_swordsman = getUnitById(right_swordsman);
            if (this_swordsman.id == -1) continue;
            int dis_miracle = cube_distance(this_swordsman.pos, enemy_miracle);
            if (this_swordsman.atk_range[0] <= dis_miracle && dis_miracle <= this_swordsman.atk_range[1])
                attack(this_swordsman.id, my_camp ^ 1);
        }
        std::cerr << "Defend my barrack." << std::endl;
        if (checkBarrack(my_barrack) != my_camp)
        {
            for (const auto &right_swordsman : id_right_swordsman)
            {
                Unit this_swordsman = getUnitById(right_swordsman);
                if (this_swordsman.id == -1) continue;
                if (cube_distance(this_swordsman.pos, my_barrack) <
                    cube_distance(this_swordsman.pos, enemy_miracle))
                    move_and_fight(right_swordsman, my_barrack);
            }
            if (make_unit("Swordsman", miracle_sf, 1))
                id_right_swordsman.push_back(getUnitByPos(miracle_sf, 0).id);
        }
        std::cerr << "Defend left barrack." << std::endl;
        if (checkBarrack(left_barrack) != my_camp)
        {
            for (const auto &left_swordsman : id_left_swordsman)
            {
                Unit this_swordsman = getUnitById(left_swordsman);
                if (this_swordsman.id == -1) continue;
                if (cube_distance(this_swordsman.pos, left_barrack) <
                    cube_distance(this_swordsman.pos, enemy_miracle))
                    move_and_fight(left_swordsman, left_barrack);
            }

            if (make_unit("Swordsman", miracle_if, 1))
                id_left_swordsman.push_back(getUnitByPos(miracle_if, 0).id);
        }
        if (id_artifact != -1 && getUnitById(id_artifact).id != -1)
            fight_and_move(id_artifact, enemy_miracle);
        std::cerr << "Left attack." << std::endl;
        if (checkBarrack(enemy_barrack) == (my_camp ^ 1))
        {
            for (const auto &left_swordsman : id_left_swordsman)
                move_and_fight(left_swordsman, enemy_barrack);
        }
        else
        {
            for (const auto &left_swordsman : id_left_swordsman)
                move_and_fight(left_swordsman, enemy_miracle);
        }
        std::cerr << "Right attack." << std::endl;
        if (checkBarrack(right_barrack) == (my_camp ^ 1))
        {
            for (const auto &right_swordsman : id_right_swordsman)
                move_and_fight(right_swordsman, right_barrack);
        }
        else if (round <= 18)
        {
            for (const auto &right_swordsman : id_right_swordsman)
                fight_and_move(right_swordsman, enemy_barrack);
        }
        else
        {
            for (const auto &right_swordsman : id_right_swordsman)
                move_and_fight(right_swordsman, enemy_barrack);
        }
        if (players[my_camp].mana >= players[my_camp].artifact[0].cost && players[my_camp].artifact[0].state == "Ready") {
            auto pos_list = all_pos_in_map();
            vector<Pos> available_pos;
            for (const auto & pos:pos_list)
                if (canUseArtifact(players[my_camp].artifact[0], pos, my_camp))
                    available_pos.push_back(pos);
            int max_benefit = 0;
            Pos best_pos = available_pos[0];
            for (auto pos:available_pos) {
                auto unit_list = units_in_range(pos, 2, map, my_camp ^ 1);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            if (max_benefit >= 4)
            {
                use(players[my_camp].artifact[0].id, best_pos);
                id_artifact = getUnitByPos(best_pos, 0).id;
            }

        }
        std::cerr << "Make enemy." << std::endl;
        if (checkBarrack(enemy_barrack) == my_camp)
        {
            enemy_list = getUnitsByCamp(my_camp ^ 1);
            for (const auto &barrack : map.barracks)
                if (barrack.pos == enemy_barrack)
                {
                    for (const auto &pos : barrack.summon_pos_list)
                        if (getUnitByPos(pos, 0).id == -1)
                        {
                            bool not_attacked = 1;
                            for (const auto &enemy : enemy_list)
                            {
                                int enemy_attack_dist = cube_distance(pos, enemy.pos);
                                if (enemy.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= enemy.atk_range[1])
                                    not_attacked = 0;
                            }
                            if (not_attacked)
                            {
                                if (make_unit("Swordsman", pos, 1))
                                    id_left_swordsman.push_back(getUnitByPos(pos, 0).id);
                                break;
                            }
                        }
                    break;
                }
        }
        if (checkBarrack(left_barrack) == my_camp)
        {
            enemy_list = getUnitsByCamp(my_camp ^ 1);
            for (const auto &barrack : map.barracks)
                if (barrack.pos == left_barrack)
                {
                    for (const auto &pos : barrack.summon_pos_list)
                        if (getUnitByPos(pos, 0).id == -1)
                        {
                            bool not_attacked = 1;
                            for (const auto &enemy : enemy_list)
                            {
                                int enemy_attack_dist = cube_distance(pos, enemy.pos);
                                if (enemy.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= enemy.atk_range[1])
                                    not_attacked = 0;
                            }
                            if (not_attacked)
                            {
                                if (make_unit("Swordsman", pos, 1))
                                    id_left_swordsman.push_back(getUnitByPos(pos, 0).id);
                                break;
                            }
                        }
                    break;
                }
        }
        std::cerr << "Make my." << std::endl;
        if (checkBarrack(my_barrack) == my_camp)
        {
            enemy_list = getUnitsByCamp(my_camp ^ 1);
            for (const auto &barrack : map.barracks)
                if (barrack.pos == my_barrack)
                {
                    for (const auto &pos : barrack.summon_pos_list)
                        if (getUnitByPos(pos, 0).id == -1)
                        {
                            bool not_attacked = 1;
                            for (const auto &enemy : enemy_list)
                            {
                                int enemy_attack_dist = cube_distance(pos, enemy.pos);
                                if (enemy.atk_range[0] <= enemy_attack_dist &&
                                    enemy_attack_dist <= enemy.atk_range[1])
                                    not_attacked = 0;
                            }
                            if (not_attacked)
                            {
                                if (make_unit("Swordsman", pos, 1))
                                {
                                    id_right_swordsman.push_back(getUnitByPos(pos, 0).id);
                                    break;
                                }
                            }
                        }
                }
        }
    }

    void all_attack()
    {
        std::cerr << "All attack." << std::endl;
        ally_list = getUnitsByCamp(my_camp);
        enemy_list = getUnitsByCamp(my_camp ^ 1);
        for (const auto &ally : ally_list) {
            if (ally.can_atk) {
                int dis_miracle = cube_distance(ally.pos, enemy_miracle);
                if (ally.atk_range[0] <= dis_miracle && dis_miracle <= ally.atk_range[1]) {
                    attack(ally.id, my_camp ^ 1);
                    continue;
                }
                enemy_list = getUnitsByCamp(my_camp ^ 1);
                Unit strongest_enemy;
                bool there_is_strongest_enemy = 0;
                for (const auto &enemy : enemy_list) {
                    if (AiClient::canAttack(ally, enemy) && !AiClient::canAttack(enemy, ally)) {
                        if (!there_is_strongest_enemy) {
                            there_is_strongest_enemy = 1;
                            strongest_enemy = enemy;
                        } else if (enemy.atk > strongest_enemy.atk)
                            strongest_enemy = enemy;
                    }
                }
                if (there_is_strongest_enemy) attack(ally.id, strongest_enemy.id);
            }

        }
        //然后打有伤的。他死我不死>同生共死>我死他不死
        ally_list = getUnitsByCamp(my_camp);
        for (const auto &ally : ally_list) {
            if (ally.can_atk) {
                enemy_list = getUnitsByCamp(my_camp ^ 1);
                vector<Unit> classified_enemy[3];
                for (const auto &enemy : enemy_list) {
                    if (AiClient::canAttack(ally, enemy)) {
                        classified_enemy[(ally.atk >= enemy.hp) + (ally.hp > enemy.atk)].push_back(enemy);
                    }
                }
                vector<Unit> to_attack;
                bool there_is_to_attack = 0;
                for (int i = 2; i >= 0; i--) {
                    if (!classified_enemy[i].empty()) {
                        to_attack = classified_enemy[i];
                        there_is_to_attack = 1;
                        break;
                    }
                }
                if (there_is_to_attack)
                {
                    Unit best_enemy = to_attack[0];
                    for (const auto &enemy : to_attack)
                    {
                        if (enemy.atk + enemy.hp > best_enemy.atk + best_enemy.hp)
                            best_enemy = enemy;
                    }
                    attack(ally.id, best_enemy.id);
                }
            }
        }
    }

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动
};

void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * artifacts和creatures可以修改
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Archer", "Swordsman", "Priest"};
    id_barrack_defender = id_pioneer = id_artifact = -1;
    my_miracle = map.miracles[my_camp].pos;
    enemy_miracle = map.miracles[my_camp ^ 1].pos;
    miracle_ff = posShift(my_miracle, "FF");
    miracle_sf = posShift(my_miracle, "SF");
    miracle_if = posShift(my_miracle, "IF");
    my_barrack = get_closest_barrack(my_miracle);
    enemy_barrack = get_closest_barrack(enemy_miracle);
    left_barrack = get_closest_barrack(enemy_barrack);
    right_barrack = get_closest_barrack(my_barrack);
    center_archer = posShift(posShift(posShift(miracle_ff, "FF"), "FF"), "FF");
    left_archer = posShift(posShift(posShift(miracle_ff, "IF"), "IF"), "FF");
    right_archer = posShift(posShift(posShift(miracle_ff, "SF"), "SF"), "FF");
    left_back_priest = posShift(posShift(miracle_ff, "IF"), "FF");
    right_back_priest = posShift(posShift(miracle_ff, "SF"), "FF");
    left_front_priest = posShift(posShift(posShift(miracle_ff, "IF"), "FF"), "FF");
    right_front_priest = posShift(posShift(posShift(miracle_ff, "SF"), "FF"), "FF");
    init();
}

void AI::play()
{
    std::cerr << round << " " << players[my_camp].max_mana << std::endl;
    //玩家需要编写的ai操作函数



    //零、开局
    if (players[my_camp].max_mana < 6)
    {
        if (round == 0 || round == 1) //开局叫牧师
        {
            if (make_unit("Priest", miracle_ff, 1))
                id_pioneer = getUnitByPos(miracle_ff, 0).id;
        }
        else if (round == 2 || round == 3)
        {
            move_without_hurt(id_pioneer, left_barrack);
            if (make_unit("Swordsman", miracle_ff, 1))
                id_right_swordsman.push_back(getUnitByPos(miracle_ff, 0).id);
        }
        else if (round == 4 || round == 5)
        {
            move_without_hurt(id_pioneer, left_barrack);
            if (!id_right_swordsman.empty())
                move_without_hurt(id_right_swordsman[0], my_barrack);
            if (make_unit("Swordsman", miracle_ff, 1))
                id_right_swordsman.push_back(getUnitByPos(miracle_ff, 0).id);
        }
        else if (round == 6 || round == 7)
        {
            move_without_hurt(id_pioneer, left_barrack);
            move_without_hurt(id_right_swordsman[0], my_barrack);
            fight_and_move(id_right_swordsman[1], enemy_barrack);
            if (round == 7)
            {
                if (make_unit("Archer", miracle_ff, 2))
                    id_barrack_defender = getUnitByPos(miracle_ff, 0).id;
            }
            else
            {
                if (make_unit("Swordsman", miracle_ff, 1))
                    id_right_swordsman.push_back(getUnitByPos(miracle_ff, 0).id);
            }
        }
        else if (round == 8 || round == 9)
        {
            if (getUnitByPos(enemy_barrack, 0).id == -1)
                move_without_hurt(id_pioneer, enemy_barrack);
            else
                move_without_hurt(id_pioneer, enemy_miracle);
            if (checkBarrack(right_barrack) == (my_camp ^ 1))
            {
                for (const auto &right_swordsman : id_right_swordsman)
                    move_and_fight(right_swordsman, right_barrack);
            }
            if (round == 8)
            {
                if (make_unit("Archer", miracle_ff, 2))
                    id_barrack_defender = getUnitByPos(miracle_ff, 0).id;
            }
            else
            {
                if (id_barrack_defender != -1)
                    move_and_fight(id_barrack_defender, right_archer);
                else if (make_unit("Archer", miracle_ff, 2))
                    id_barrack_defender = getUnitByPos(miracle_ff, 0).id;
            }
            swordsman_behav();
        }
        else
        {
            if (getUnitByPos(enemy_barrack, 0).id == -1)
                move_without_hurt(id_pioneer, enemy_barrack);
            else
                move_without_hurt(id_pioneer, enemy_miracle);
            if (id_barrack_defender != -1)
                move_and_fight(id_barrack_defender, right_archer);
            else if (make_unit("Archer", miracle_ff, 2))
                id_barrack_defender = getUnitByPos(miracle_ff, 0).id;
            swordsman_behav();
        }
        all_attack();
        endRound();
        return;
    }

    all_attack();

    //二、构建防线
    //1.先走弓箭手

    ally_list = getUnitsByCamp(my_camp);
    for (const auto &ally : ally_list)
        if (ally.type == "Archer" && ally.pos != left_archer
            && ally.pos != right_archer && ally.pos != center_archer)
        {
            Unit unit_on_center = getUnitByPos(center_archer, 0);
            if (unit_on_center.id == -1 || unit_on_center.camp != my_camp)
                move_and_fight(ally.id, center_archer);
            Unit unit_on_left = getUnitByPos(left_archer, 0);
            if (unit_on_left.id == -1 || unit_on_left.camp != my_camp)
                move_and_fight(ally.id, left_archer);
            Unit unit_on_right = getUnitByPos(right_archer, 0);
            if (unit_on_right.id == -1 || unit_on_right.camp != my_camp)
                move_and_fight(ally.id, right_archer);
        }

    //2. 然后走牧师


    // 出生点的牧师去该去的地方
    Unit unit_on_ff = getUnitByPos(miracle_ff, 0);
    if (my_can_move(unit_on_ff, "Priest"))
    {
        vector<Pos> reachable_pos_all = reachable_all(unit_on_ff, map);
        int used = 0;
        for (Pos pos : reachable_pos_all)
            if (pos == left_back_priest)
            {
                move(unit_on_ff.id, pos);
                used = 1;
                break;
            }
        if (!used)
            for (Pos pos : reachable_pos_all)
                if (pos == right_back_priest)
                {
                    move(unit_on_ff.id, pos);
                    used = 1;
                    break;
                }
        if (!used)
            for (Pos pos : reachable_pos_all)
                if (pos == left_front_priest)
                {
                    move(unit_on_ff.id, pos);
                    used = 1;
                    break;
                }
        if (!used)
            for (Pos pos : reachable_pos_all)
                if (pos == right_front_priest)
                {
                    move(unit_on_ff.id, pos);
                    used = 1;
                    break;
                }
    }
    //造新的弓箭手
    make_unit("Archer", miracle_ff, 3);
    // 造新牧师
    make_unit("Priest", miracle_ff, 3);
    swordsman_behav();
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

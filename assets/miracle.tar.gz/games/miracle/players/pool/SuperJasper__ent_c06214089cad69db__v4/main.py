"""
AI
"""
import functools
import random
import ctypes

import calculator
import gameunit
from ai_client import AiClient
from card import CARD_DICT


class AI(AiClient):
    """
    玩家编写的ai
    """

    def __init__(self):
        super().__init__()
        # 以下是玩家自己的初始构造
        self.miracle_pos = list()
        self.enemy_pos = list()
        self.target_barrack = gameunit.Barrack()

    def choose_cards(self):
        """
        (根据初始阵营)选择初始卡组
        """

        """
        artifacts和creatures可以修改
        【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
        """
        self.artifacts = ["InfernoFlame"]
        self.creatures = ["Archer", "Swordsman", "Priest"]
        self.init()
        
    def gather_point(self):
        gather_point = self.relative_pos(self.miracle_pos, 0, 3, 0)
        
        warning = False
        for unit in self.get_units_by_camp(self.my_camp ^ 1):
            if calculator.cube_distance(unit.pos, self.miracle_pos) <= 4 or (len(self.get_units_by_camp(self.my_camp)) < 6 and self.round > 15):
                warning = True
        if warning:
            gather_point = self.pos_shift(gather_point, "BB")  
        return gather_point

    def maybe_enemy_dog(self):
        suc = False
        if (len(calculator.units_in_range(self.enemy_pos, 5, self.map, self.enemy_camp)) >= 5 \
                or len(calculator.units_in_range(self.enemy_pos, 2, self.map, self.enemy_camp)) >= 3)\
                and len(calculator.units_in_range(self.miracle_pos, 8, self.map, self.enemy_camp)) <= 3:
            return True
        return False
    
    def swordsman_battle(self):
        ally_list = self.get_units_by_camp(self.my_camp)
        for ally in ally_list:
            if ally.type == "Swordsman":
                if not ally.can_atk:
                    continue
                enemy_list = self.get_units_by_camp(self.my_camp ^ 1)
                target_list = []
                for enemy in enemy_list:
                    if self.can_attack(ally, enemy):
                        target_list.append(enemy)
                if len(target_list) == 0:
                    continue

                if ally.type == 'Swordsman':
                    target_list.sort(key=lambda _enemy: 0 if _enemy.type == "Archer" 
                                                        else 1 if _enemy.type == "Priest"
                                                        else 20 - _enemy.atk)
                    self.attack(ally.id, target_list[0].id)
            
    def miracle_battle(self):
        def cmp(unit1, unit2):
            if unit1.can_atk != unit2.can_atk:  # 首先要能动
                return unit2.can_atk - unit1.can_atk
            elif unit1.type != unit2.type:  # 寒冰龙>弓箭手>法师
                type_id_gen = lambda typename: 0 if typename == 'Swordsman' else 1 if typename == 'Archer' else 2
                return type_id_gen(unit1.type) - type_id_gen(unit2.type)
            elif unit1.type == 'Swordsman' or unit1.type == 'Archer':
                return unit2.atk - unit1.atk
            else:
                return unit1.atk - unit2.atk
                
        ally_list = self.get_units_by_camp(self.my_camp)
        ally_list.sort(key=functools.cmp_to_key(cmp))
        for ally in ally_list:
            if not ally.can_atk:
                break
            dis = calculator.cube_distance(ally.pos, self.enemy_pos)
            if ally.atk_range[0] <= dis <= ally.atk_range[1]:
                self.attack(ally.id, self.my_camp ^ 1)
    
    
    def battle(self):
        """
        处理生物的战斗
        """

        """
        基本思路，行动顺序:
        火山龙：攻击高>低 （大AOE输出），随机攻击
        剑士：攻击低>高 打消耗，优先打攻击力低的
        弓箭手：攻击高>低 优先打不能反击的攻击力最高的，其次打能反击的攻击力最低的
        对单位的战斗完成后，对神迹进行输出
        【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
                例如占领着驻扎点的敌方生物具有极高的价值，优先摧毁可以使敌方下回合损失很多可用出兵点
                一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
        """
        ally_list = self.get_units_by_camp(self.my_camp)

        # 自定义排列顺序
        def cmp(unit1, unit2):
            if unit1.can_atk != unit2.can_atk:  # 首先要能动
                return unit2.can_atk - unit1.can_atk
            elif unit1.type != unit2.type:  # 寒冰龙>弓箭手>法师
                type_id_gen = lambda typename: 0 if typename == 'Swordsman' else 1 if typename == 'Archer' else 2
                return type_id_gen(unit1.type) - type_id_gen(unit2.type)
            elif unit1.type == 'Swordsman' or unit1.type == 'Archer':
                return unit2.atk - unit1.atk
            else:
                return unit1.atk - unit2.atk
                
        ally_list = self.get_units_by_camp(self.my_camp)
        ally_list.sort(key=functools.cmp_to_key(cmp))
        for ally in ally_list:
            if not ally.can_atk:
                break
            dis = calculator.cube_distance(ally.pos, self.enemy_pos)
            if ally.atk_range[0] <= dis <= ally.atk_range[1]:
                self.attack(ally.id, self.my_camp ^ 1)
                
        
        ally_list = self.get_units_by_camp(self.my_camp)
        # 按顺序排列好单位，依次攻击
        ally_list.sort(key=functools.cmp_to_key(cmp))
        for ally in ally_list:
            if not ally.can_atk:
                break #not break here   break is better
            enemy_list = self.get_units_by_camp(self.my_camp ^ 1)
            target_list = []
            for enemy in enemy_list:
                if self.can_attack(ally, enemy):
                    target_list.append(enemy)
            if len(target_list) == 0:
                continue

            if ally.type == 'Swordsman':
                target_list.sort(key=lambda _enemy: 0 if _enemy.type == "Archer" 
                                                    else 1 if _enemy.type == "Priest"
                                                    else 20 - _enemy.atk)
                self.attack(ally.id, target_list[0].id)

            elif ally.type == 'Priest':
                enemy_list.sort(key=lambda _enemy: _enemy.atk)
                self.attack(ally.id, target_list[0].id)

            elif ally.type == 'Archer':
                enemy_list.sort(key=lambda _enemy: _enemy.atk, reverse=True)
                suc = False
                for enemy in target_list:
                    if enemy.type == "BlackBat":
                        self.attack(ally.id, enemy.id)
                        suc = True
                        break
                if suc:
                    continue
                for enemy in target_list:
                    if not self.can_attack(enemy, ally):
                        self.attack(ally.id, enemy.id)
                        suc = True
                        break
                if suc:
                    continue
                enemy_list.sort(key=lambda _enemy: _enemy.atk)
                self.attack(ally.id, target_list[0].id)
            
            elif ally.type == "Inferno":
                if calculator.cube_distance(ally.pos, self.enemy_pos) <= 1:
                    self.attack(ally.id, self.my_camp ^ 1)
                else:
                    suc = False
                    for enemy in target_list:
                        if enemy.type == "BlackBat" or enemy.type == "Archer":
                            self.attack(ally.id, enemy.id)
                            suc = True
                            break
                    if suc:
                        continue
                
            
        # 最后攻击神迹
    
    def radar(self, r_pos, r_min_range, r_max_range, r_type):  #检测周围
        r_enemy_list = self.get_units_by_camp(self.my_camp ^ 1)
        r_radar = False
        if calculator.cube_distance(r_pos, self.miracle_pos) <= 2:  #can not back any more!
            return False
        for r_enemy in r_enemy_list:
            if r_enemy.type == r_type and calculator.cube_distance(r_pos, r_enemy.pos) <= r_max_range \
                                        and calculator.cube_distance(r_pos, r_enemy.pos) >= r_min_range:
                return True
        return r_radar
    
    def how_safer(self, _pos):
        num = 0
        if self.radar(_pos, 3, 4, "Archer") == True:
            num += 1
        if self.radar(_pos, 0, 1, "Blackbat") == True:
            num += 1
        if self.radar(_pos, 0, 1, "Swordsman") == True:
            num += 1
        if self.radar(_pos, 0, 1, "Priest") == True:
            num += 1
        if self.radar(_pos, 0, 1, "VolcanoDragon") == True:
            num += 1
        if self.radar(_pos, 0, 1, "FrostDragon") == True:
            num += 1
        if self.radar(_pos, 0, 1, "Inferno") == True:
            num += 1
        return num
    
    def enemy_distribution(self): #-1是左，1是右
        left_enemy = 0
        right_enemy = 0
        if self.my_camp == 0:
            for enemy in self.get_units_by_camp(self.my_camp ^ 1):
                if enemy.pos[2] < 0:
                    #可以加权
                    if enemy.type == "Archer":
                        right_enemy += 2
                    right_enemy += 1
                elif enemy.pos[0] < enemy.pos[1]:
                    if enemy.type == "Archer":
                        left_enemy += 2
                    left_enemy += 1
        if self.my_camp == 1:
            for enemy in self.get_units_by_camp(self.my_camp ^ 1):
                if enemy.pos[2] > 0:
                    if enemy.type == "Archer":
                        right_enemy += 2
                    right_enemy += 1
                elif enemy.pos[0] > enemy.pos[1]:
                    if enemy.type == "Archer":
                        left_enemy += 2
                    left_enemy += 1
        if left_enemy >= (right_enemy + 6):
            return -1
        elif right_enemy >= (left_enemy + 6):
            return 1
        else:
            return 0
    
    def archer_best_pos(self, _pos):
        pos_benefit = self.how_safer(_pos) * 5
        for enemy in self.get_units_by_camp(self.my_camp ^ 1):
            if calculator.cube_distance(_pos, enemy.pos) == 3 or calculator.cube_distance(_pos, enemy.pos) == 4:
                pos_benefit -= 2
                if enemy.type == "Archer":
                    pos_benefit += 1
        return (pos_benefit * 100) + calculator.cube_distance(_pos, self.enemy_pos)
        
    
    def priest_best_pos(self, _pos):
        pos_benefit = self.how_safer(_pos) * 5
        for ally in self.get_units_by_camp(self.my_camp):
            if calculator.cube_distance(_pos, ally.pos) <= 2:
                pos_benefit -= 2
            if calculator.cube_distance(_pos, ally.pos) == 3:
                pos_benefit -= 1
        return (pos_benefit * 100) + calculator.cube_distance(_pos, self.enemy_pos)
        
    def swordsman_best_pos(self, _pos):
        pos_benefit = 0
        pos_benefit = self.how_safer(_pos) * 3
        for enemy in self.get_units_by_camp(self.my_camp ^ 1):
            if calculator.cube_distance(_pos, enemy.pos) == 1 and not (enemy.type == "BlackBat"):
                pos_benefit -= 1
            if enemy.type == "Archer":
                if calculator.cube_distance(_pos, enemy.pos) == 1:
                    pos_benefit -= 3
                if calculator.cube_distance(_pos, enemy.pos) == 2:
                    pos_benefit -= 1
            if enemy.type == "Priest":
                if calculator.cube_distance(_pos, enemy.pos) == 1:
                    pos_benefit -= 3
                if calculator.cube_distance(_pos, enemy.pos) == 2:
                    pos_benefit -= 1
        
        return (pos_benefit * 100) + calculator.cube_distance(_pos, self.enemy_pos)
    
    def go_toward(self, g_unit, target_pos):
        # 获取所有可到达的位置
        reach_pos_with_dis = calculator.reachable(g_unit, self.map)
        # 压平
        tran_reach_pos_list = []
        for tran_reach_pos in reach_pos_with_dis:
            tran_reach_pos_list += tran_reach_pos
        safe_reach_pos_list = tran_reach_pos_list
        reach_pos_list = []
        for reach_pos in safe_reach_pos_list: #去掉[1:]
            reach_pos_list.append(reach_pos)
        if len(reach_pos_list) != 0:
            reach_pos_list.sort(key=lambda _pos: calculator.cube_distance(_pos, target_pos))
            reach_pos_list.sort(key=lambda _pos: self.how_safer(_pos))
            if not (reach_pos_list[0] == g_unit.pos):
                self.move(g_unit.id, reach_pos_list[0])
            
    def dead_go_toward(self, g_unit, target_pos):
        # 获取所有可到达的位置
        reach_pos_with_dis = calculator.reachable(g_unit, self.map)
        # 压平
        tran_reach_pos_list = []
        for tran_reach_pos in reach_pos_with_dis:
            tran_reach_pos_list += tran_reach_pos
        safe_reach_pos_list = tran_reach_pos_list
        reach_pos_list = []
        for reach_pos in safe_reach_pos_list: #去掉[1:]
            reach_pos_list.append(reach_pos)
        if len(reach_pos_list) != 0:
            reach_pos_list.sort(key=lambda _pos: calculator.cube_distance(_pos, target_pos))
            if not (reach_pos_list[0] == g_unit.pos):
                self.move(g_unit.id, reach_pos_list[0])
    
    def inferno_hurt(self):
        ally_list = self.get_units_by_camp(self.my_camp)
        for ally in ally_list:
            if ally.type == "Inferno":
                if ally.hp < 5:
                    return True
        return False

    def march(self):
        if self.round == 2 or self.round == 3 or self.round == 4 or self.round == 5 or self.round == 6 or self.round == 7:
            self.go_toward(self.get_unit_by_id(first_priest_id), self.relative_pos(self.miracle_pos, 12, 1, 0))
        """
        处理生物的移动
        """

        """
        先动所有剑士，尽可能向敌方神迹移动
        若目标驻扎点上没有地面单位，则让弓箭手向目标驻扎点移动，否则尽可能向敌方神迹移动
        然后若目标驻扎点上没有地面单位，则让火山之龙向目标驻扎点移动，否则尽可能向敌方神迹移动
        【进阶】一味向敌方神迹移动并不一定是个好主意
                在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
                如果采用其他生物组合，可以考虑抢占更多驻扎点
        """
        ally_list = self.get_units_by_camp(self.my_camp)
        ally_list.sort(key=lambda unit: 0 if unit.type == "Priest" else 1 if unit.type == 'Archer' else 2)
        
        for ally in ally_list:
            if ally.type == "Inferno" and ally.can_move:
                if calculator.cube_distance(ally.pos, self.enemy_pos) + self.how_safer(ally.pos) < 6:
                    self.dead_go_toward(ally, self.enemy_pos)
                if self.inferno_hurt():
                    self.go_toward(ally, self.miracle_pos)
                elif (not self.inferno_hurt()):
                    if self.maybe_enemy_dog:#如果对方苟，先占坑
                        if not (self.check_barrack(self.relative_pos(self.miracle_pos, 12, 1, 0) == self.my_camp))\
                                and calculator.units_in_range(self.relative_pos(self.miracle_pos, 12, 1, 0), 2, self.map, self.enemy_camp) is None:
                            self.go_toward(ally, self.relative_pos(self.miracle_pos, 12, 1, 0))
                        elif not (self.check_barrack(self.relative_pos(self.miracle_pos, 0, 1, 12) == self.my_camp))\
                                and calculator.units_in_range(self.relative_pos(self.miracle_pos, 0, 1, 12), 2, self.map, self.my_camp^1) is None:
                            self.go_toward(ally, self.relative_pos(self.miracle_pos, 5, 7, 0))
                        elif not (self.check_barrack(self.relative_pos(self.miracle_pos, 5, 7, 0) == self.my_camp))\
                                and calculator.units_in_range(self.relative_pos(self.miracle_pos, 5, 7, 0), 4, self.map, self.my_camp^1) is None:
                            self.go_toward(ally, self.relative_pos(self.miracle, 5, 7, 0))
                    elif not self.maybe_enemy_dog:
                        self.go_toward(ally, self.enemy_pos)
        
        
        for ally in ally_list:
            if not ally.can_move:
                continue
            if ally.type == "Priest":
                # 获取所有可到达的位置
                reach_pos_with_dis = calculator.reachable(ally, self.map)
                # 压平
                tran_reach_pos_list = []
                for tran_reach_pos in reach_pos_with_dis:
                    tran_reach_pos_list += tran_reach_pos
                
                safe_reach_pos_list = []
                for safe_reach_pos in tran_reach_pos_list:
                    safe_reach_pos_list.append(safe_reach_pos)
                                
                
                reach_pos_list = []
                for reach_pos in safe_reach_pos_list: #去掉[1:]
                    reach_pos_list.append(reach_pos)
                if len(reach_pos_list) == 0:
                    continue

                reach_pos_list.sort(key=lambda _pos: self.priest_best_pos(_pos))
                if reach_pos_list[0] == ally.pos:
                    continue
                self.move(ally.id, reach_pos_list[0])
            
            elif ally.type == "Archer":
                # 获取所有可到达的位置
                reach_pos_with_dis = calculator.reachable(ally, self.map)
                # 压平
                tran_reach_pos_list = []
                for tran_reach_pos in reach_pos_with_dis:
                    tran_reach_pos_list += tran_reach_pos
                
                safe_reach_pos_list = []
                for safe_reach_pos in tran_reach_pos_list:
                    safe_reach_pos_list.append(safe_reach_pos)
                
                reach_pos_list = []
                for reach_pos in safe_reach_pos_list: #去掉[1:]
                    reach_pos_list.append(reach_pos)
                if len(reach_pos_list) == 0:
                    continue
                  
                reach_pos_list.sort(key=lambda _pos: self.archer_best_pos(_pos))
                if reach_pos_list[0] == ally.pos:
                    continue
                self.move(ally.id, reach_pos_list[0])
                

            elif ally.type == "Swordsman":
                # 如果已经在兵营就不动了
#                if ally.pos in [barrack.pos for barrack in self.map.barracks]:
#                    continue

                # 获取所有可到达的位置
                reach_pos_with_dis = calculator.reachable(ally, self.map)
                # 压平
                tran_reach_pos_list = []
                for tran_reach_pos in reach_pos_with_dis:
                    tran_reach_pos_list += tran_reach_pos
                
                safe_reach_pos_list = []
                for safe_reach_pos in tran_reach_pos_list:
                    safe_reach_pos_list.append(safe_reach_pos)
                
                reach_pos_list = []
                for reach_pos in safe_reach_pos_list: #去掉[1:]
                    reach_pos_list.append(reach_pos)
                if len(reach_pos_list) == 0:
                    continue

                # 优先走到未被占领的兵营，否则走到
#                if self.get_unit_by_pos(self.target_barrack.pos, False) is None:
#                    reach_pos_list.sort(key=lambda _pos: calculator.cube_distance(_pos, self.target_barrack.pos))
#                    self.move(ally.id, reach_pos_list[0])
#                else:
                reach_pos_list.sort(key=lambda _pos: self.swordsman_best_pos(_pos))
                if reach_pos_list[0] == ally.pos:
                    continue
                self.move(ally.id, reach_pos_list[0])
             #地域之火
                """
                settle_pos = self.miracle_pos
                for i in range(2):
                    settle_pos = self.pos_shift(settle_pos, "FF")
                for i in range(5):
                    settle_pos = self.pos_shift(settle_pos, "SF")
                    
                if calculator.cube_distance(self.miracle_pos, ally.pos) >= 7:
                    for i in range(5):
                        settle_pos = self.pos_shift(settle_pos, "FF")
                    for i in range(1):
                        settle_pos = self.pos_shift(settle_pos, "SF")
                if calculator.cube_distance(self.miracle_pos, ally.pos) >= 12:  #少1直冲堡垒
                    settle_pos = self.pos_shift(self.enemy_pos, "SB")
                """
                

    def pos_shift(self, pos, direct: str):
        """
        对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
        本段代码可以自由取用
        :param pos:  (x, y, z)
        :param direct: 一个str，含2个字符，意义见注释
        :return: 移动后的位置 (x', y' ,z')
        """
        if self.my_camp == 0:
            if direct.upper() == "FF":  # 正前方
                return pos[0] + 1, pos[1] - 1, pos[2]
            elif direct.upper() == "SF":  # 优势路前方（自身视角右侧为优势路）
                return pos[0] + 1, pos[1], pos[2] - 1
            elif direct.upper() == "IF":  # 劣势路前方
                return pos[0], pos[1] - 1, pos[2] + 1
            elif direct.upper() == "BB":  # 正后方
                return pos[0] - 1, pos[1] + 1, pos[2]
            elif direct.upper() == "SB":  # 优势路后方
                return pos[0], pos[1] + 1, pos[2] - 1
            elif direct.upper() == "IB":  # 劣势路后方
                return pos[0] - 1, pos[1], pos[2] + 1

        else:
            if direct.upper() == "FF":  # 正前方
                return pos[0] - 1, pos[1] + 1, pos[2]
            elif direct.upper() == "SF":  # 优势路前方（自身视角右侧为优势路）
                return pos[0] - 1, pos[1], pos[2] + 1
            elif direct.upper() == "IF":  # 劣势路前方
                return pos[0], pos[1] + 1, pos[2] - 1
            elif direct.upper() == "BB":  # 正后方
                return pos[0] + 1, pos[1] - 1, pos[2]
            elif direct.upper() == "SB":  # 优势路后方
                return pos[0], pos[1] - 1, pos[2] + 1
            elif direct.upper() == "IB":  # 劣势路后方
                return pos[0] + 1, pos[1], pos[2] - 1
    
    def relative_pos(self, pos, x: int, y: int, z: int): #x往左上，y往上，z往右上
        if self.my_camp == 0:
            return pos[0] + y + z, pos[1] - x - y, pos[2] + x - z            
        else:
            return pos[0] - y - z, pos[1] + x + y, pos[2] - x + z

    def play(self):
        """
        玩家需要编写的ai操作函数
        """

        """
        本AI采用这样的策略：
        在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
        接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
        在费用较低时尽可能召唤星级为1的兵，优先度剑士>弓箭手>火山龙
        【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
        """
        if self.round == 0 or self.round == 1:
            # 先确定自己的基地、对方的基地

            self.miracle_pos = self.map.miracles[self.my_camp].pos
            self.enemy_pos = self.map.miracles[self.my_camp ^ 1].pos


            # 在正中心
            self.summon('Priest', 1, self.relative_pos(self.miracle_pos, 1, 0, 0))
            id_list = []
            global first_priest_id
            for unit in self.get_units_by_camp(self.my_camp):
                id_list.append(unit.id)
            id_list.sort(reverse = True)
            for ally_id in id_list:
                if self.get_unit_by_id(ally_id).type == "Priest":
                    first_priest_id = ally_id
                    break
            self.end_round()
            
            
        """
        # 神器能用就用，选择覆盖单位数最多的地点
        def cmp(unit1,unit2):
            return calculator.cube_distance(unit1.pos, self.enemy_pos) - \
                    calculator.cube_distance(unit2.pos, self.enemy_pos)
        shield_list = []
        for unit in self.get_units_by_camp(self.my_camp):
            if unit.level >= 2 and unit.type == "Archer" and unit.holy_shield == False:
                shield_list.append(unit)
        shield_list.sort(key=functools.cmp_to_key(cmp))
        
        if self.players[self.my_camp].mana >= 6 and self.players[self.my_camp].artifact[0].state == 'Ready':
            if shield_list:
                self.use(self.players[self.my_camp].artifact[0].id, shield_list[0].id)
        """
        #如果没占领最近的驻扎点，则要先占领。
        if self.players[self.my_camp].mana >= 8 and self.players[self.my_camp].artifact[0].state == 'Ready' and (not (self.check_barrack(self.relative_pos(self.miracle_pos, 0, 2, 5)) == self.my_camp)):
            settle_pos = self.relative_pos(self.miracle_pos, 0, 2, 5)
            pos_list = calculator.all_pos_in_map()
            can_pos = pos_list[0]
            min_length_benefit = calculator.cube_distance(settle_pos, self.miracle_pos)
            for pos in pos_list:
                if self.can_use_artifact(self.players[self.my_camp].artifact[0], pos, self.my_camp):
                    if calculator.cube_distance(pos, settle_pos) < min_length_benefit:
                        can_pos, min_length_benefit = pos, calculator.cube_distance(pos, settle_pos)
            self.use(self.players[self.my_camp].artifact[0].id, can_pos)
        #如果占领了，计算可以造成最大击杀数或几乎击杀的位置，再尽量向前。
        if self.players[self.my_camp].mana >= 8 and self.players[self.my_camp].artifact[0].state == 'Ready' and (self.check_barrack(self.relative_pos(self.miracle_pos, 0, 2, 5)) == self.my_camp):
            pos_list = calculator.all_pos_in_map()
            pos_list.sort(key = lambda _pos: calculator.cube_distance(_pos, self.enemy_pos))
            best_pos = pos_list[0]
            max_benefit = 0
            for pos in pos_list:
                unit_list = calculator.units_in_range(pos, 2, self.map, self.my_camp ^ 1)
                num = 0
                for _enemy in unit_list:
                    if _enemy.hp <= 3:
                        num += 1
                if num > max_benefit:
                    best_pos, max_benefit = pos, num
            if max_benefit >= 2:
                for pos in pos_list:
                    if self.can_use_artifact(self.players[self.my_camp].artifact[0], pos, self.my_camp):
                        self.use(self.players[self.my_camp].artifact[0].id, pos)
                        break
        #可能没占领但在厮杀
        if self.players[self.my_camp].mana >= 8 and self.players[self.my_camp].artifact[0].state == 'Ready' and (self.check_barrack(self.relative_pos(self.miracle_pos, 0, 2, 5)) == self.my_camp) and (not self.maybe_enemy_dog):
            pos_list = calculator.all_pos_in_map()
            pos_list.sort(key = lambda _pos: calculator.cube_distance(_pos, self.enemy_pos))
            best_pos = pos_list[0]
            max_benefit = 0
            for pos in pos_list:
                unit_list = calculator.units_in_range(pos, 2, self.map, self.my_camp ^ 1)
                num = 0
                for _enemy in unit_list:
                    if _enemy.hp <= 8:
                        num += 1
                if num > max_benefit:
                    best_pos, max_benefit = pos, num
            for pos in pos_list:
                if self.can_use_artifact(self.players[self.my_camp].artifact[0], pos, self.my_camp):
                    self.use(self.players[self.my_camp].artifact[0].id, pos)
                    break
        #可能没占领 苟着 但没有合适的进攻位置
        if self.players[self.my_camp].mana >= 8 and self.players[self.my_camp].artifact[0].state == 'Ready' and (self.maybe_enemy_dog):
            settle_pos = self.relative_pos(self.miracle_pos, 12, 1, 0)
            pos_list = calculator.all_pos_in_map()
            can_pos = pos_list[0]
            min_length_benefit = calculator.cube_distance(settle_pos, self.miracle_pos)
            for pos in pos_list:
                if self.can_use_artifact(self.players[self.my_camp].artifact[0], pos, self.my_camp):
                    if calculator.cube_distance(pos, settle_pos) < min_length_benefit:
                        can_pos, min_length_benefit = pos, calculator.cube_distance(pos, settle_pos)
            self.use(self.players[self.my_camp].artifact[0].id, can_pos)
                
        # 之后先战斗，再移动
        self.miracle_battle()
        self.swordsman_battle()
        self.march()
        self.battle()

        # 最后进行召唤
        # 将所有本方出兵点按照到对方基地的距离排序，从近到远出兵
        summon_pos_list = self.get_summon_pos_by_camp(self.my_camp)
        available_summon_pos_list = []
        for pos in summon_pos_list:
            unit_on_pos_ground = self.get_unit_by_pos(pos, False)
            if unit_on_pos_ground is None:
                available_summon_pos_list.append(pos)
        del summon_pos_list
        available_summon_pos_list.sort(key=lambda _pos: 0 if _pos == self.relative_pos(self.miracle_pos, 0, 1, 0) \
                                                       else 1 if _pos == self.relative_pos(self.miracle_pos, 1, 0, 0) \
                                                       else 2 if _pos == self.relative_pos(self.miracle_pos, 0, 0, 1) \
                                                       else 3 if _pos == self.relative_pos(self.miracle_pos, -1, 0, 1) \
                                                       else 4 if _pos == self.relative_pos(self.miracle_pos, 1, 0, -1) \
                                                       else 5 + calculator.cube_distance(_pos, self.miracle_pos))

        # 统计各个生物的可用数量，在假设出兵点无限的情况下，按照1个剑士、1个弓箭手、1个火山龙的顺序召唤
        mana = self.players[self.my_camp].mana
        deck = self.players[self.my_camp].creature_capacity
        available_count = {}
        for card_unit in deck:
            available_count[card_unit.type] = card_unit.available_count
        summon_list = []
        summon_level = []
        
        def try_summon(k_level, k_type:str, id_mana):
            suc = True
            while ctypes.cast(id_mana, ctypes.py_object).value >= 2 and suc:
                suc = False
                if available_count[k_type] > 0 and ctypes.cast(id_mana, ctypes.py_object).value >= CARD_DICT[k_type][k_level].cost:
                    summon_list.append(k_type)
                    summon_level.append(k_level)
                    ctypes.cast(id_mana, ctypes.py_object).value -= CARD_DICT[k_type][k_level].cost               
                    available_count[k_type] -= 1
                    suc = True
        
        num_S = 0
        num_A = 0
        num_P = 0
        
        for unit in self.get_units_by_camp(self.my_camp):
            if unit.type == "Swordsman":
                num_S += 1
            elif unit.type == "Archer":
                num_A += 1
            elif unit.type == "Priest":
                num_P += 1
           
        if (2 * num_P) > (num_S + num_A) :
            if num_S < (2 * num_A + 1):
                for i in range(3):  
                    try_summon(3-i, "Swordsman", id(mana))
                    try_summon(3-i, 'Archer', id(mana))    
                    try_summon(3-i, 'Priest', id(mana))
            else:
                for i in range(3):  
                    try_summon(3-i, "Archer", id(mana))
                    try_summon(3-i, 'Swordsman', id(mana))    
                    try_summon(3-i, 'Priest', id(mana))
        else:            
            if num_S < (2 * num_A + 1):
                for i in range(3):  
                    try_summon(3-i, "Priest", id(mana))
                    try_summon(3-i, 'Swordsman', id(mana))    
                    try_summon(3-i, 'Archer', id(mana))
            else:
                for i in range(3):  
                    try_summon(3-i, "Priest", id(mana))
                    try_summon(3-i, 'Archer', id(mana))    
                    try_summon(3-i, 'Swordsman', id(mana))                   



        for pos in available_summon_pos_list:
            if not summon_list:
                break
            self.summon(summon_list[0], summon_level[0], pos)
            summon_list.pop(0)
            summon_level.pop(0)

        self.end_round()


first_priest_id = -1
gou_round = 0







def main():    
    """
    启动AI
    """
    player_ai = AI()
    player_ai.choose_cards()
    while True:
        player_ai.update_game_info()
        player_ai.play()
    print(1)

if __name__ == '__main__':
    main()

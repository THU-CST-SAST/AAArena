#include "ai_client.h"
#include "card.hpp"//line 729 控制送人头
#include "gameunit.h"
#include "calculator.h"
#include <tuple>//下个版本用牧师吧。。。
//tocode line 231 确定弓箭手的移动方式
//debug line 332，拖过前面回合，之后开始反攻
#include <random>
#include <time.h>
using gameunit::Pos;//点坐标 
using gameunit::Unit;//单位
using calculator::cube_distance;//返回两点距离
using calculator::all_pos_in_map;//地图中所有位置？
using calculator::reachable;
using calculator::cube_reachable;//返回一个包含所有可到达点坐标的容器（已经剔除所有障碍）
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
typedef struct{
Pos position;
bool vacant;
} summon_pos;
int summon_mode=0;//0表示前7至15回合
int danger_mode=0;//0代表中立，1代表优势，2代表劣势
class AI : public AiClient
{
private:
Pos miracle_pos;
Pos posShift(Pos pos, string direct);
 Pos enemy_pos;
 Pos target_barrack;
 Pos Archer_hide[3];//弓箭手驻扎点
public:
    //选择初始卡组
    void chooseCards()
    {
        // artifacts和creatures可以修改
        my_artifacts = {"InfernoFlame"};
        my_creatures = {"Archer", "Swordsman", "FrostDragon"};//已做修改
        init();
    }
    void battle();
    void play();
    void march();
    void change_summon_mode();
    void _summon();
    void use_artifact();
    void is_danger();
};
Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);//修改
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);//改
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::play(){
if(round==1||round==0){
    //确定神迹位置
      miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
}
Archer_hide[1]=posShift(posShift(posShift(posShift(miracle_pos,"IF"),"IF"),"FF"),"FF");//待修改
Archer_hide[0]=posShift(posShift(posShift(posShift(miracle_pos,"IF"),"IF"),"IF"),"FF");
Archer_hide[2]=posShift(posShift(posShift(posShift(miracle_pos,"SF"),"FF"),"FF"),"FF");
summon("Swordsman", 1, posShift(miracle_pos, "SF"));
}
is_danger();
//todo先判断是否用神器
use_artifact();
//攻击
battle();//已初步完成
//移动
march();//初步完成
change_summon_mode();
_summon();
endRound();
}

void AI::march(){//思路：弓箭手走位，剑士切弓箭手，龙推家
auto ally_list = getUnitsByCamp(my_camp);
auto enemy_list=getUnitsByCamp(my_camp^1);
sort(ally_list.begin(), ally_list.end(), [this](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {//弓箭手先动
            if (type_name == "Swordsman") return 1;
            else if (type_name == "Archer") return 0;
            else return 2;
        };
        if(type_id_gen(_unit1.type) != type_id_gen(_unit2.type))
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
        else return cube_distance(_unit1.pos,enemy_pos)<cube_distance(_unit2.pos,enemy_pos);
    });
if(round<=6&&!ally_list.empty()&&(getUnitByPos(target_barrack, false).id == -1)){
//获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally_list[0], map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
move(ally_list[0].id, reach_pos_list[0]);
return;
}//既定策略，让第一个剑士去抢占目标点，在后期重占目标点
for(const Unit &obj:ally_list){
bool on_barrack=false;
for (const auto &barrack:map.barracks)
                if (obj.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }    
if(!obj.can_move)//在驻扎点就算了
continue;
if(obj.type=="Swordsman"||obj.type=="Inferno"){
Pos target_pos;
nth_element(enemy_list.begin(),enemy_list.begin(),enemy_list.end(),
[this,&obj](const Unit & _enemy1,const Unit & _enemy2){
if((_enemy1.type=="Priest"||_enemy1.type=="Archer")&&(_enemy2.type=="Priest"||_enemy2.type=="Archer"))
return cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
if(_enemy2.type=="Priest"||_enemy2.type=="Archer")
return false;
if(_enemy1.type=="Priest"||_enemy1.type=="Archer")
return true;
return    cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
});
if(!enemy_list.empty())
{if(cube_distance(obj.pos,enemy_list[0].pos)<cube_distance(obj.pos,enemy_pos))
target_pos=enemy_list[0].pos;
else target_pos=enemy_pos;}
else target_pos=enemy_pos;
gameunit::Barrack temp_barrack=map.barracks[0];
for(const auto &a: map.barracks){
if(cube_distance(a.pos,miracle_pos)<cube_distance(temp_barrack.pos,miracle_pos))
temp_barrack=a;
}
if(temp_barrack.camp!=my_camp)
target_pos=target_barrack;
   auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {//需修改
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
move(obj.id, reach_pos_list[0]);
}else if(obj.type=="FrostDragon"){//冰龙只推塔,卡射程
Pos target_pos=enemy_pos;
 auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
if(cube_distance(obj.pos,target_pos)>6)                        
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos,&enemy_list,&obj,this](Pos _pos1, Pos _pos2) {
                                int tmp1,tmp2;
                                int sign1,sign2;
                                sign1=0;//0表示安全
                                sign2=0;
                                for(const Unit &ar:enemy_list){ 
                                tmp1=cube_distance(ar.pos,_pos1);                                      
                                if(tmp1>=ar.atk_range[0]&&tmp1<=ar.atk_range[1]&&ar.atk_range[1]>2)//todo here
                             {//
                             sign1=1;
                             break;
                               }
                                }  
                                for(const Unit &ar:enemy_list){ 
                                tmp2=cube_distance(ar.pos,_pos2);                                      
                                if(tmp2>=ar.atk_range[0]&&tmp2<=ar.atk_range[1]&&ar.atk_range[1]>2)//todo here
                             {//
                             sign2=1;
                             break;
                               }
                                }  
                                if(sign1!=sign2)
                                return sign1<sign2;//不能白挨打
                                //尽量攻击时保持距离为2
                                /*sign1=0;//0表示距离适当
                                sign2=0;//0表示距离恰当
                                for(const Unit &ar:enemy_list){ 
                                tmp1=cube_distance(ar.pos,_pos1);                                      
                                if(tmp1<2&&ar.type!="Priest")//todo here
                             {//
                             sign1=1;
                             break;
                               }
                                }  
                                for(const Unit &ar:enemy_list){ 
                                tmp2=cube_distance(ar.pos,_pos2);                                      
                                if(tmp2<2&&ar.type!="Priest")//todo here
                             {//
                             sign2=1;
                             break;
                               }
                                }  
                               if(sign1!=sign2)  return sign1<sign2;
                                else             */   
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
else  nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                   [&target_pos](Pos _pos1,Pos _pos2){
                   return cube_distance(_pos1,target_pos) <cube_distance(_pos2,target_pos);   
                   }      );                            
move(obj.id, reach_pos_list[0]);
}

else if(obj.type=="Archer"){
bool is_being_attack=false;
for(const Unit &ar:enemy_list)
if(canAttack(ar,obj)){
 is_being_attack=true;
 break;   
}
Pos target_pos;

if(is_being_attack){//必须移动
auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
//code here
int i,tmp;
bool can_hide=false;
bool hide_vacant=false;
for(i=0;i<=2;i++){
    can_hide=true;
    if(getUnitByPos(Archer_hide[i],false).id!=-1){can_hide=false;
    continue;}
   for(const Unit &ar:enemy_list){
tmp=cube_distance(ar.pos,Archer_hide[i]);
if(tmp>=ar.atk_range[0]&&tmp<=ar.atk_range[1]&&ar.type!="Archer")//todo here
{can_hide=false;
break;
}
}
if(can_hide) break;
}
if(can_hide){//需修改，在路上总挨打。。。已改——待检查
target_pos=Archer_hide[i];
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos,&enemy_list,&obj,this](Pos _pos1, Pos _pos2) {
                                int tmp1,tmp2;
                                int sign1,sign2;
                                sign1=0;//0表示安全
                                sign2=0;
                                for(const Unit &ar:enemy_list){ 
                                tmp1=cube_distance(ar.pos,_pos1);                                      
                                if(tmp1>=ar.atk_range[0]&&tmp1<=ar.atk_range[1])//todo here
                             {//
                             sign1=1;
                             break;
                               }
                                }  
                                for(const Unit &ar:enemy_list){ 
                                tmp2=cube_distance(ar.pos,_pos2);                                      
                                if(tmp2>=ar.atk_range[0]&&tmp2<=ar.atk_range[1])//todo here
                             {//
                             sign2=1;
                             break;
                               }
                                }  
                                if(sign1==sign2)
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                                else return sign1<sign2;
                            });
move(obj.id,reach_pos_list[0]);
continue;
}
else{//三个驻扎点都挨打,或者有东西
for(i=0;i<=2;i++)
if(getUnitByPos(Archer_hide[i],false).id==-1){
hide_vacant=true;
break;
}
if(hide_vacant){
    target_pos=Archer_hide[i];
sort(reach_pos_list.begin(),reach_pos_list.end(), [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);});
    bool can_go=false;                            
for(const auto& pos1:reach_pos_list){
    can_go=true;
    for(const Unit& ar:enemy_list)
    if(cube_distance(pos1,ar.pos)>=ar.atk_range[0]&&cube_distance(pos1,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
    }
    if(can_go){
    move(obj.id,pos1);
    break;
    }
}
if(can_go) continue;
Pos a=miracle_pos;//实在没办法就回神迹，待修改
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&a,&enemy_list,&obj,this](Pos _pos1, Pos _pos2) {
                                int tmp1,tmp2;
                                int sign1,sign2;
                                sign1=0;//0表示安全
                                sign2=0;
                                for(const Unit &ar:enemy_list){
                                tmp1=cube_distance(ar.pos,_pos1);                                      
                                if(tmp1>=ar.atk_range[0]&&tmp1<=ar.atk_range[1])//todo here
                             {//
                             sign1=1;
                             break;
                               }
                                }  
                                for(const Unit &ar:enemy_list){ 
                                tmp2=cube_distance(ar.pos,_pos2);                                      
                                if(tmp2>=ar.atk_range[0]&&tmp2<=ar.atk_range[1])//todo here
                             {//
                             sign2=1;
                             break;
                               }
                                }  
                                if(sign1==sign2)
                                return cube_distance(_pos1,a) < cube_distance(_pos2,a);
                                else return sign1<sign2;
                            });
move(obj.id,reach_pos_list[0]);
continue;
}else{
target_pos=miracle_pos;
sort(reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });//优先回神迹
bool can_go;
for(const Pos& pos2:reach_pos_list){ 
   can_go=true ;
   for(const Unit& ar:enemy_list)
    if(cube_distance(pos2,ar.pos)>=ar.atk_range[0]&&cube_distance(pos2,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
    }
   if(can_go){
   move(obj.id,pos2);
   break;
   }
}
if(can_go) continue;
move(obj.id,reach_pos_list[0]);
continue;
}
}
}
else{//当前位置未被攻击，尽量不动
int j=0;
bool is_hide=false;
bool is_vacant=false;
auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
is_hide=false;
for(j=0;j<=2;j++)
if(obj.pos==Archer_hide[j]){
is_hide=true;
break;
}
if(is_hide) continue;//在隐藏点就不动
for(j=0;j<=2;j++){
    //is_vacant=false;
    if(getUnitByPos(Archer_hide[j],false).id==-1){
    is_vacant=true;
    break;
    }
}
if(!is_vacant){continue;}//debug
else{   
target_pos=Archer_hide[j];
sort(reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
bool can_go=true;
for(const Pos& pos3:reach_pos_list){  
   can_go=true;  
  for(const Unit &ar:enemy_list)
  if(cube_distance(pos3,ar.pos)>=ar.atk_range[0]&&cube_distance(pos3,ar.pos)<=ar.atk_range[1]&&ar.type!="Archer"){
      can_go=false;
      break;  
  }
  if(can_go) {move(obj.id,pos3);
  break;}
  }
continue;
}
}
}
}
return;
}

void AI::use_artifact(){
//code here
if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
            vector<Pos> pos_list;
            for(const Pos &a:all_pos_in_map()){
            if(canUseArtifact(players[my_camp].artifact[0],a,my_camp))
            pos_list.push_back(a);
            }
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp^1);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            if(max_benefit>=2)
            use(players[my_camp].artifact[0].id, best_pos);
        }

return;
}

void AI::is_danger(){
if(round<=50){//
danger_mode=1;
return;
}    
int unit_around_my_miracle=0;
int unit_attacking=0;
auto units=getUnitsByCamp(my_camp);//己方
auto enemy_list=getUnitsByCamp(my_camp^1);
danger_mode=0;
for(const Unit &ar:enemy_list){
if(cube_distance(ar.pos,miracle_pos)<=6)
unit_around_my_miracle++;
if(cube_distance(ar.pos,miracle_pos)<=4)
unit_around_my_miracle++;
}
if(unit_around_my_miracle>=2){
    danger_mode=1;//确定劣势
    return;
}
return;    
}


void AI::battle(){//远战单位先攻击  弓箭手>龙>剑士
auto units=getUnitsByCamp(my_camp);//己方单位容器
auto cmp=[](const Unit &unit1, const Unit &unit2){
if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
            else if(unit1.type != unit2.type){
                auto type_id_gen = [](const string &type_name) {
                if (type_name == "Archer") return 0;
                else if (type_name == "Swordsman") return 2;
                else return 1;};
                return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
            }
    else return false;//待修改，增加细节
};
sort(units.begin(),units.end(),cmp);
for(const auto &obj:units ){
if(!obj.can_atk) break;
auto enemy_list = getUnitsByCamp(my_camp ^ 1);
vector<Unit> target_list;
 int dis = cube_distance(obj.pos, enemy_pos);
 bool can_attack_miracle=obj.atk_range[0] <= dis && dis <= obj.atk_range[1];
for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(obj, enemy))
                target_list.push_back(enemy);
if(target_list.empty()&&!can_attack_miracle) continue;
if(obj.type=="Archer"){
for(const auto &ar: enemy_list)
if(AiClient::canAttack(ar,obj)&&ar.type!="Archer")
goto end1;
sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });//攻击低的先打
for(const auto &ar:target_list)
if(!canAttack(ar,obj)&&ar.flying){//必须先打蝙蝠
attack(obj.id,ar.id);
goto end1;
}
if(can_attack_miracle){
    attack(obj.id, my_camp ^ 1);
    goto end1;//推塔
}
for(const auto &ar:target_list)
if(!canAttack(ar,obj)){
    attack(obj.id,ar.id);
goto end1;
}
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end1;
}
end1:
continue;
}else if(obj.type=="FrostDragon"){//target_list已经存储了可打击目标
//优先推塔
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}
sort(target_list.begin(),target_list.end(),[&obj](const Unit &_enemy1, 
const Unit &_enemy2){return cube_distance(obj.pos,_enemy1.pos)<cube_distance(obj.pos,_enemy2.pos);});//先打近目标
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end2;
}
end2:
continue;//待修改
}else if(obj.type=="Swordsman"){
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔

for(const auto &ar:target_list)
if(ar.type=="Archer"){
attack(obj.id,ar.id);
goto end3;
}
nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(obj.id, target_list[0].id);
end3:
continue;
}else if(obj.type=="Inferno"){
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔
sort(target_list.begin(),target_list.end(),[](const Unit &_enemy1, const Unit &_enemy2){return _enemy1.atk>_enemy2.atk;});
attack(obj.id,target_list[0].id);
continue;

}
}
return;
}

void AI::_summon(){
if(round<=7)
return;
int prim;//优先级
auto summon_pos_list = getSummonPosByCamp(my_camp);//可用出兵点
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
        });//前面的小
        vector<Pos> available_summon_pos_list;//真正可以放兵的地点 且通过远近排序 前面离敌方基地最近 包括位置和是否用过
        //summon_pos tmp;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) {
                               available_summon_pos_list.push_back(pos);}
        }
int mana = players[my_camp].mana;//法力值
auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;//这是个映射记录当前可以放置单位的数量
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;
bool is_end=true;
if(summon_mode==0){     //前期       
while(is_end){        
is_end=false;        
if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[2].cost&&available_summon_pos_list.size()){//弓箭手在近处召唤且优先
summon("Archer",2,available_summon_pos_list[available_summon_pos_list.size()-1]);
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("Archer")[2].cost;
is_end=true;
available_count["Archer"]--;
continue;
}
if(available_count["FrostDragon"]>0&&mana>=CARD_DICT.at("FrostDragon")[1].cost&&available_summon_pos_list.size()){//根本出不了龙。。。
summon("FrostDragon",1,available_summon_pos_list[available_summon_pos_list.size()-1]);
//todo 删除头元素
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("FrostDragon")[1].cost;
is_end=true;
available_count["FrostDragon"]--;
continue;
}
if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[1].cost&&available_summon_pos_list.size()){
summon("Swordsman",1,available_summon_pos_list[0]);
//todo 删除头元素
available_summon_pos_list.erase(available_summon_pos_list.begin());
mana-=CARD_DICT.at("Swordsman")[1].cost;
is_end=true;
available_count["Swordsman"]--;
continue;
}
}
}else if(summon_mode==1) {//中期
//code here 
while(is_end){        
is_end=false;        
if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[3].cost&&available_summon_pos_list.size()){//弓箭手在近处召唤且优先
summon("Archer",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("Archer")[3].cost;
is_end=true;
available_count["Archer"]--;
continue;
}
if(available_count["FrostDragon"]>0&&mana>=CARD_DICT.at("FrostDragon")[1].cost&&available_summon_pos_list.size()){
   if(mana>=CARD_DICT.at("FrostDragon")[2].cost){ 

summon("FrostDragon",2,available_summon_pos_list[available_summon_pos_list.size()-1]);
//todo 删除头元素
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("FrostDragon")[2].cost;
is_end=true;
available_count["FrostDragon"]--;
continue;}
else{summon("FrostDragon",1,available_summon_pos_list[available_summon_pos_list.size()-1]);
//todo 删除头元素
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("FrostDragon")[1].cost;
is_end=true;
available_count["FrostDragon"]--;
continue;
}
}
if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[3].cost&&available_summon_pos_list.size()){
 if(danger_mode==0){   
summon("Swordsman",3,available_summon_pos_list[0]);
available_summon_pos_list.erase(available_summon_pos_list.begin());}
else{
    summon("Swordsman",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
    available_summon_pos_list.pop_back();
}
mana-=CARD_DICT.at("Swordsman")[3].cost;
is_end=true;
available_count["Swordsman"]--;
continue;
}
}
}else if(summon_mode==2){
while(is_end){        
is_end=false;        
if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[3].cost&&available_summon_pos_list.size()){//弓箭手在近处召唤且优先
summon("Archer",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
available_summon_pos_list.pop_back();
mana-=CARD_DICT.at("Archer")[3].cost;
is_end=true;
available_count["Archer"]--;
continue;
}
if(available_count["FrostDragon"]>0&&mana>=CARD_DICT.at("FrostDragon")[3].cost&&available_summon_pos_list.size()){//根本出不了龙。。。
if(danger_mode==0){
summon("FrostDragon",3,available_summon_pos_list[0]);
available_summon_pos_list.erase(available_summon_pos_list.begin());}
else{
    summon("FrostDragon",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
    available_summon_pos_list.pop_back();
}
mana-=CARD_DICT.at("FrostDragon")[3].cost;
is_end=true;
available_count["FrostDragon"]--;
continue;
}
if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[3].cost&&available_summon_pos_list.size()){
    if(danger_mode==0){
/*auto ally_list = getUnitsByCamp(my_camp);
int num_sword=0;
for(const Unit& ar:ally_list){
if(ar.type=="Swordsman")
num_sword++;    
}
if(num_sword>=4&&map.miracles[my_camp].hp<30)
continue;*/
summon("Swordsman",3,available_summon_pos_list[0]);
available_summon_pos_list.erase(available_summon_pos_list.begin());}
else {summon("Swordsman",3,available_summon_pos_list[available_summon_pos_list.size()-1]);
available_summon_pos_list.pop_back();
}
mana-=CARD_DICT.at("Swordsman")[3].cost;
is_end=true;
available_count["Swordsman"]--;
continue;
}
}
}
return;
}

void AI::change_summon_mode(){
if(round<=15)
summon_mode=0;
else if(round<=27)
summon_mode=1;
else summon_mode=2;
return;
}






int main()
{
    AI player_ai;
    player_ai.chooseCards();
    while (true)
    {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

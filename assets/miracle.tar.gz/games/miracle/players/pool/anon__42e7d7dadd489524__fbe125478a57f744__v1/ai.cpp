#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::pair;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

const int INF = 0x3f3f3f3f;
const int MATK = 12;
const int BATK = 5;
const int NUM = 2; // 每个敌人最多被几个人盯上
const double C = 1.8;
const int MAXWAIT = 5; // 等待多少回合敌方还不动

class AI : public AiClient
{
private:
    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack;
    Pos rtarget_barrack;

    Pos artifactPos;

    Pos Log[1000];
    int turn[1000];
    bool fflag[1000];

    Pos neighbor(Pos& pos, int dir);

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void BFSG(Pos & pos, int camp);
    void BFSS(Pos & pos, int camp);

    void getDisOnGround(Unit &unit, Pos &tpos);
    void getDisInSky(Unit &unit, Pos &tpos);
    
    int stepreq(Unit & unit, Pos pos1, Pos pos2);
    
    int cal(Unit &ally, Pos pos);
    int eval(int range, bool atk_flying, Pos pos);

    int distan(Unit &unit, Pos pos1, Pos pos2);

    void minCostMaxFlow(int s, int t);

    void Zhan();
    void Volcano();
    void battle_march(); //处理生物的战斗
    void Artifact();
};

void AI::chooseCards()
{
    my_artifacts = {"InfernoFlame"};
    my_creatures = {"Swordsman", "VolcanoDragon", "FrostDragon"};
    init();
}

bool hasfly;
using namespace std;
typedef pair<int, Pos> P;

void AI::play()
{
    endRound();
    return ;
    auto pos_list = all_pos_in_map();
    if (round == 0 || round == 1) {
        for (int i = 0; i < 1000; ++i)
            Log[i] = Pos(-1, -1, -1), turn[i] = 0, fflag[i] = false;
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;

        target_barrack = map.barracks[0].pos;
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        rtarget_barrack = map.barracks[0].pos;
        for (const auto &barrack:map.barracks) {
            if (cube_distance(enemy_pos, barrack.pos) <
                cube_distance(enemy_pos, rtarget_barrack))
                rtarget_barrack = barrack.pos;
        }
        summon("Swordsman", 1, neighbor(miracle_pos, round * 3));
    } else{
        Zhan();

        Volcano();
        battle_march();
        Artifact();


        auto summon_pos_list = getSummonPosByCamp(my_camp);
        vector<Pos> available_summon_pos_list;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
        }
        auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;

        if (available_summon_pos_list.size()){
            int mana = players[my_camp].mana;
            int max_mana = players[my_camp].max_mana;
            int ran = -1; bool atk_fly;
            if (max_mana < 5){
                if (available_count["Swordsman"]) ran = 1, atk_fly = false;
            }else if (max_mana == 5){
                ran = 2;
                if (hasfly && available_count["FrostDragon"])
                    atk_fly = true;
                else if (available_count["VolcanoDragon"])
                    atk_fly = false;
                else if (available_count["FrostDragon"])
                    atk_fly = true;
            }else if (max_mana == 6){
                if (available_count["Swordsman"]) ran = 1, atk_fly = false;
            }else{
                if (hasfly && available_count["FrostDragon"])
                    ran = 2, atk_fly = true;
                else if (available_count["VolcanoDragon"])
                    ran = 2, atk_fly = false;
                else if (available_count["FrostDragon"])
                    ran = 2, atk_fly = true;
                else if (available_count["Swordsman"]) ran = 1, atk_fly = false;
            }
            if (~ran){
                auto enemy_list = getUnitsByCamp(my_camp ^ 1);
                Pos pos;
                double mx = -INF;
                for (auto &ppos: available_summon_pos_list){
                    double bene = -eval(ran, atk_fly, ppos);
                    int dis = cube_distance(ppos, enemy_pos);
                    for (auto &enemy : enemy_list){
                        dis = min(dis, cube_distance(enemy.pos, ppos));
                    }
                    bene += 0.5 / dis;
                    if (bene > mx){
                        mx = bene;
                        pos = ppos;
                    }
                }
                if (max_mana < 4){
                    if (available_count["Swordsman"]) summon("Swordsman", 1, pos);
                }else if (max_mana == 4){
                    if (available_count["Swordsman"]) summon("Swordsman", 2, pos);
                }else if (max_mana == 5){
                    if (hasfly && available_count["FrostDragon"])
                        summon("FrostDragon", 1, pos);
                    else if (available_count["VolcanoDragon"])
                        summon("VolcanoDragon", 1, pos);
                    else if (available_count["FrostDragon"])
                        summon("FrostDragon", 1, pos);
                }else if (max_mana == 6){
                    if (available_count["Swordsman"]) summon("Swordsman", 3, pos);
                }else if (max_mana == 7){
                    if (hasfly && available_count["FrostDragon"])
                        summon("FrostDragon", 2, pos);
                    else if (available_count["VolcanoDragon"])
                        summon("VolcanoDragon", 2, pos);
                    else if (available_count["FrostDragon"])
                        summon("FrostDragon", 2, pos);
                    else if (available_count["Swordsman"]) summon("Swordsman", 3, pos);
                }else if (mana == 8){
                    if (hasfly && available_count["FrostDragon"])
                        summon("FrostDragon", 2, pos);
                    else if (available_count["VolcanoDragon"])
                        summon("VolcanoDragon", 2, pos);
                    else if (available_count["FrostDragon"])
                        summon("FrostDragon", 2, pos);
                    else if (available_count["Swordsman"]) summon("Swordsman", 3, pos);
                }else if (mana > 8){
                    if (hasfly && available_count["FrostDragon"])
                        summon("FrostDragon", 3, pos);
                    else if (available_count["VolcanoDragon"])
                        summon("VolcanoDragon", 3, pos);
                    else if (available_count["FrostDragon"])
                        summon("FrostDragon", 3, pos);
                    else if (available_count["Swordsman"]) summon("Swordsman", 3, pos);
                }
            }
        }
    }
    endRound();
}

Pos AI::neighbor(Pos& pos, int dir) {
    Pos neighbor;
    if (dir == 0)   // first neighbor
        return Pos(get<0>(pos)+1, get<1>(pos), get<2>(pos)-1);
    else if (dir == 1)
        return Pos(get<0>(pos)+1, get<1>(pos)-1, get<2>(pos));
    else if (dir == 2)
        return Pos(get<0>(pos), get<1>(pos)-1, get<2>(pos)+1);
    else if (dir == 3)
        return Pos(get<0>(pos)-1, get<1>(pos), get<2>(pos)+1);
    else if (dir == 4)
        return Pos(get<0>(pos)-1, get<1>(pos)+1, get<2>(pos));
    else
        return Pos(get<0>(pos), get<1>(pos)+1, get<2>(pos)-1);
}

int dx[6] = {1, 1, 0, -1, -1, 0};
int dy[6] = {0, -1, -1, 0, 1, 1};
int Dis[30][30];
bool stp[30][30];
typedef pair<int, int> PP;
PP que[1000];
int h,tail;

int & DIS(Pos &pos){
    return Dis[get<0>(pos) + 15][get<1>(pos) + 15];
}

void BFS(){
    while (h <= tail){
        PP p = que[h++];
        int x = p.first, y = p.second;
        for (int i = 0; i < 6; ++i){
            int tx = x + dx[i];
            int ty = y + dy[i];
            if (Dis[tx][ty] == -2) continue;
            if (Dis[tx][ty] < 0){
                Dis[tx][ty] = Dis[x][y] + 1;
                if (stp[tx][ty]) continue;
                que[++tail] = PP(tx, ty);
            }
        }
    }
}

void AI::BFSG(Pos & pos, int camp){
    memset(Dis, -1, sizeof(Dis));
    memset(stp, 0, sizeof(stp));
    DIS(pos) = 0;
    vector<Pos> obstacles_pos = calculator::MAPBORDER();
    for (auto &pos: obstacles_pos){
        DIS(pos) = -2;
    }
    for (auto p = map.ground_obstacles.begin(); p != map.ground_obstacles.end(); p++)
    {
        DIS(p->pos) = -2;
    }
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != camp && (!p->flying))
        {
            DIS(p->pos) = -2;
            for (int i = 0; i < 6; ++i){
                stp[get<0>(p->pos) + 15][get<1>(p->pos) + 15] = 1;
            }
        }
    }
    que[h=tail=1] = PP(get<0>(pos) + 15, get<1>(pos) + 15);
    BFS();
}

void AI::BFSS(Pos & pos, int camp){
    int x = get<0>(pos), y = get<1>(pos);
    memset(Dis, -1, sizeof(Dis));
    memset(stp, 0, sizeof(stp));
    DIS(pos) = 0;
    vector<Pos> obstacles_pos = calculator::MAPBORDER();
    for (auto &pos: obstacles_pos){
        DIS(pos) = -2;
    }
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != camp && p->flying)
        {
            DIS(p->pos) = -2;
            for (int i = 0; i < 6; ++i){
                stp[get<0>(p->pos) + 15][get<1>(p->pos) + 15] = 1;
            }
        }
    }
    que[h=tail=1] = PP(get<0>(pos) + 15, get<1>(pos) + 15);
    BFS();
}

void AI::getDisOnGround(Unit &unit, Pos &tpos){
    memset(Dis, -1, sizeof(Dis));
    memset(stp, 0, sizeof(stp));
    auto pos_list = all_pos_in_map();
    h = 1, tail = 0;
    for (auto pos: pos_list){
        int dis = cube_distance(pos, tpos);
        if (dis < unit.atk_range[0] || dis > unit.atk_range[1]) continue;
        DIS(pos) = 0;
        que[++tail] = PP(get<0>(pos) + 15, get<1>(pos) + 15);
    }
    vector<Pos> obstacles_pos = calculator::MAPBORDER();
    for (auto &pos: obstacles_pos){
        DIS(pos) = -2;
    }
    for (auto p = map.ground_obstacles.begin(); p != map.ground_obstacles.end(); p++)
    {
        DIS(p->pos) = -2;
    }
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != unit.camp && (!p->flying))
        {
            DIS(p->pos) = -2;
            for (int i = 0; i < 6; ++i){
                stp[get<0>(p->pos) + 15][get<1>(p->pos) + 15] = 1;
            }
        }
    }
    BFS();
}

void AI::getDisInSky(Unit &unit, Pos &tpos){
    memset(Dis, -1, sizeof(Dis));
    memset(stp, 0, sizeof(stp));
    auto pos_list = all_pos_in_map();
    h = 1, tail = 0;
    for (auto pos: pos_list){
        int dis = cube_distance(pos, tpos);
        if (dis < unit.atk_range[0] || dis > unit.atk_range[1]) continue;
        DIS(pos) = 0;
        que[++tail] = PP(get<0>(pos) + 15, get<1>(pos) + 15);
    }
    vector<Pos> obstacles_pos = calculator::MAPBORDER();
    for (auto &pos: obstacles_pos){
        DIS(pos) = -2;
    }
    for (auto p = map.units.begin(); p != map.units.end(); p++)
    {
        if (p->camp != unit.camp && p->flying)
        {
            DIS(p->pos) = -2;
            for (int i = 0; i < 6; ++i){
                stp[get<0>(p->pos) + 15][get<1>(p->pos) + 15] = 1;
            }
        }
    }
    BFS();
}

inline int upper_div(int x,int y){
    return (x + y - 1) / y;
}

inline int min(int x,int y){
    return x < y ? x : y;
}

inline int max(int x,int y){
    return x < y ? y : x;
}

inline void swap(int &x,int &y){
    int t = x;
    x = y;
    y = t;
}

int AI::stepreq(Unit & unit, Pos pos1, Pos pos2){
    if (unit.flying) getDisInSky(unit, pos2);
    else getDisOnGround(unit, pos2);
    int ddd = DIS(pos1);
    return ddd < 0 ? 100 : upper_div(ddd, unit.max_move);
}

int AI::distan(Unit &unit, Pos pos1, Pos pos2){
    int dis = 0, camp = unit.camp;
    if (unit.flying) dis = getDistanceInSky(pos1, pos2, camp);
    else dis = getDistanceOnGround(pos1, pos2, camp);
    return dis > 0 ? upper_div(dis - 1, unit.max_move) : 100;
}

bool canbekilled[100];

int AI::cal(Unit &ally, Pos pos){
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    int res = 0;
    for (auto &enemy : enemy_list){
        if (canAttack(enemy, ally, enemy.pos, pos) && !canAttack(ally, enemy, pos, enemy.pos)){
            res += enemy.atk;
        }
    }
    return res;
}

int AI::eval(int range, bool atk_flying, Pos pos){
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    int res = 0;
    for (auto & enemy : enemy_list){
        int dis = cube_distance(enemy.pos, pos);
        if ((dis > range || (!atk_flying && enemy.flying)) && dis <= enemy.atk_range[1] && dis >= enemy.atk_range[0])
            res += enemy.atk;
    }
    return res;
}

const int maxn=50;
struct Edge {
    int to, cap, rev;
    double cost;
    Edge(int to, double cost, int cap, int rev) : to(to), cost(cost), cap(cap), rev(rev) {}
};
vector<Edge> G[maxn];
int prevE[maxn],prevV[maxn],q[10000];
double Dist[maxn];
bool inq[maxn];
inline void add_edge(int u, int v, int cap, double w) {
    //cerr << u << ' ' << v << ' ' << cap << ' ' << w << endl;
    G[u].push_back(Edge(v, w, cap, G[v].size()));
    G[v].push_back(Edge(u, -w, 0, G[u].size() - 1));
}
void AI::minCostMaxFlow(int s, int t){
    for (;;) {
        for (int i = 0; i <= t; ++i) Dist[i] = INF;
        int l = 0, r = 0;
        q[0] = s, Dist[s] = 0;
        while (l<=r) {
            int u = q[l++];
            inq[u] = false;
            for (int i = 0; i < (int)G[u].size(); ++i) {
                Edge &e = G[u][i];int v=e.to;
                if (e.cap && Dist[v] > Dist[u] + e.cost + 1e-6) {
                    Dist[v]=Dist[u]+e.cost;
                    prevV[v] = u;prevE[v] = i;
                    if (!inq[e.to]){
                        q[++r]=v;inq[v]=1;
                    }
                }
            }
        }
        if (Dist[t] > 1000000) return ;
        int flow=INF;
        for (int i = t; i != s; i = prevV[i]){
            //if (round == 32) cerr << i << endl;
            flow = min(flow, G[prevV[i]][prevE[i]].cap);
        }
        for (int i = t; i != s; i = prevV[i]) {
            Edge &e = G[prevV[i]][prevE[i]];
            e.cap -= flow;
            G[e.to][e.rev].cap += flow;
        }
    }
}

int pid[50], aim[50], raim[50];
double pbene[50], rpbene[50];

void AI::Zhan(){
    auto ally_list = getUnitsByCamp(my_camp);
    int sum = 0;
    for (auto &ally: ally_list){
        if (!ally.can_move) continue;
        int dis = cube_distance(ally.pos, enemy_pos);
        if (dis < ally.atk_range[0] || dis > ally.atk_range[1]) continue;
        sum += ally.atk;
    }
    if (sum < map.miracles[my_camp ^ 1].hp) return ;
    for (auto &ally: ally_list){
        if (!ally.can_move) continue;
        int dis = cube_distance(ally.pos, enemy_pos);
        if (dis < ally.atk_range[0] || dis > ally.atk_range[1]) continue;
        attack(ally.id, my_camp ^ 1);
    }
}

void AI::Volcano(){
    auto ally_list = getUnitsByCamp(my_camp);
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    int n = ally_list.size();
    int m = enemy_list.size();

    for (int i = n - 1; i >= 0; --i){
        auto ally = ally_list[i];
        if (ally.type[0] != 'V' || !ally.can_move) continue;
        int targ = -1, mx = 0;
        for (int j = 0; j < m; ++j){
            auto enemy = enemy_list[j];
            if (!canAttack(ally, enemy)) continue;
            int bene = 0;
            for (int k = 0; k < m; ++k){
                auto enemy1 = enemy_list[k];
                if (enemy1.flying) continue;
                if (cube_distance(enemy1.pos, enemy.pos) == 1 && cube_distance(enemy1.pos, ally.pos) == 2)
                    bene += enemy1.atk;
            }
            if (mx < bene){
                mx = bene;
                targ = j;
            }
        }
        if (~targ){
            attack(ally.id, enemy_list[targ].id);
            enemy_list = getUnitsByCamp(my_camp ^ 1);
            m = enemy_list.size();
        }
    }
}

void AI::battle_march()
{
    auto ally_list = getUnitsByCamp(my_camp);
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    
    int n = ally_list.size();
    int m = enemy_list.size();
    int mxatk = 0, rmxatk = 0;
    for (auto ally: ally_list){
        mxatk = max(mxatk, ally.atk);
    }
    for (auto enemy: enemy_list){
        if (enemy.type[0] == 'B')
            hasfly = true;
        rmxatk = max(rmxatk, enemy.atk);
        if (enemy.pos == Log[enemy.id]){
            turn[enemy.id]++;
        }else{
            turn[enemy.id] = 0;
            Log[enemy.id] = enemy.pos;
        }
    }
    int S = 0, T = n + m + 3;
    int idex = 0, mn = INF;
    for (int i = 0; i < m; ++i){
        auto ally = enemy_list[i];
        int Step = stepreq(ally, ally.pos, miracle_pos);
        if (Step < mn){
            mn = Step;
            idex = i;
        }
    }
    for (int i = 0; i < n; ++i){
        auto ally = ally_list[i];
        if (!ally.can_move) continue;
        for (int j = 0; j < m; ++j){
            auto enemy = enemy_list[j];
            if (enemy.flying && !ally.atk_flying) continue;
            add_edge(i + 1, n + j + 1, 1, -ally.atk*enemy.atk/(C+stepreq(ally, ally.pos, enemy.pos)));
        }
        add_edge(i + 1, n + m + 1, 1, -ally.atk*MATK/(C+stepreq(ally, ally.pos, enemy_pos)));
        add_edge(i + 1, n + m + 2, 1, -ally.atk*BATK/(C+distan(ally, ally.pos, target_barrack)));
    }
    for (int i = 0; i < n; ++i)
        add_edge(S, i + 1, 1, 0);
    for (int i = 0; i < m; ++i)
        add_edge(n + i + 1, T, 1 + (enemy_list[i].hp > mxatk) + enemy_list[i].holy_shield + 2*(i == idex), 0);
    add_edge(n + m + 1, T, 10, 0);
    add_edge(n + m + 2, T, checkBarrack(target_barrack)!=my_camp, 0);
    minCostMaxFlow(S, T);
    for (int i = 0; i < n; ++i){
        int u = i + 1, v;
        for (int j = 0; j < (int)G[u].size(); ++j){
            if (G[u][j].cap) continue;
            aim[i] = G[u][j].to - n - 1;
        }
    }
    for (int i = 0; i < n; ++i){
        auto ally = ally_list[i];
        if (!ally.can_move) continue;
        if (aim[i] < m){
            pbene[i] = enemy_list[aim[i]].atk/(C + stepreq(ally, ally.pos, enemy_list[aim[i]].pos));
        }else if (aim[i] == m){
            pbene[i] = MATK/(C + stepreq(ally, ally.pos, enemy_pos));
        }else{
            pbene[i] = BATK/(C + distan(ally, ally.pos, target_barrack));
        }
        pbene[i] *= ally.atk;
    }
    for (int i = 0; i <= T; ++i) G[i].clear();
    for (int i = 0; i < m; ++i){
        auto ally = enemy_list[i];
        for (int j = 0; j < n; ++j){
            auto enemy = ally_list[j];
            if (enemy.flying && !ally.atk_flying) continue;
            add_edge(i + 1, m + j + 1, 1, -ally.atk*enemy.atk/(C+stepreq(ally, ally.pos, enemy.pos)));
        }
        add_edge(i + 1, n + m + 1, 1, -ally.atk*MATK/(C+stepreq(ally, ally.pos, miracle_pos)));
        add_edge(i + 1, n + m + 2, 1, -ally.atk*BATK/(C+distan(ally, ally.pos, rtarget_barrack)));
    }
    for (int i = 0; i < m; ++i)
        add_edge(S, i + 1, 1, 0);
    for (int i = 0; i < n; ++i)
        add_edge(m + i + 1, T, 1 + (ally_list[i].hp > rmxatk), 0);
    add_edge(n + m + 1, T, 10, 0);
    add_edge(n + m + 2, T, checkBarrack(rtarget_barrack)!=(my_camp^1), 0);
    minCostMaxFlow(S, T);
    for (int i = 0; i < m; ++i){
        int u = i + 1, v;
        for (int j = 0; j < (int)G[u].size(); ++j){
            if (G[u][j].cap) continue;
            raim[i] = G[u][j].to - m - 1;
        }
    }
    for (int i = 0; i < m; ++i){
        auto ally = enemy_list[i];
        if (raim[i] < n){
            rpbene[i] = ally_list[aim[i]].atk/(C + stepreq(ally, ally.pos, ally_list[aim[i]].pos));
        }else if (raim[i] == n){
            rpbene[i] = MATK/(C + stepreq(ally, ally.pos, miracle_pos));
        }else{
            rpbene[i] = BATK/(C + distan(ally, ally.pos, rtarget_barrack));
        }
        rpbene[i] *= ally.atk;
    }
    for (int i = 0; i <= T; ++i) G[i].clear();
    T = n + m + 2;
    for (auto &ally: ally_list){
        if (!ally.can_move) continue;
        for (int j = 0; j < m; ++j){
            auto enemy = enemy_list[j];
            if (!canAttack(ally, enemy)) continue;
            if (enemy.hp <= ally.atk) canbekilled[j] = true;
        }
    }
    for (int i = 0; i < n; ++i){
        auto ally = ally_list[i];
        if (!ally.can_move) continue;
        auto reach_pos_with_dis = reachable(ally, map);
        vector<Pos> reach_pos_list;
        reach_pos_list.push_back(ally.pos);
        for (const auto &reach_pos : reach_pos_with_dis) {
            for (auto pos : reach_pos)
                reach_pos_list.push_back(pos);
        }
        double mx = -INF;
        if (aim[i] < m){
            if (ally.flying) getDisInSky(ally, enemy_list[aim[i]].pos);
            else getDisOnGround(ally, enemy_list[aim[i]].pos);
        }else if (aim[i] == m){
            if (ally.flying) getDisInSky(ally, enemy_pos);
            else getDisOnGround(ally, enemy_pos);
        }else{
            if (ally.flying) BFSS(target_barrack, ally.camp);
            else BFSG(target_barrack, ally.camp);
        }
        for (auto pos: reach_pos_list){
            double bene; int ddd = DIS(pos);
            if (ddd < 0) ddd = 100;
            if (aim[i] < m){
                bene = enemy_list[aim[i]].atk/(C + upper_div(ddd, ally.max_move));
            }else if (aim[i] == m){
                bene = MATK/(C + upper_div(ddd, ally.max_move));
            }else{
                bene = BATK/(C + upper_div(ddd, ally.max_move));
            }
            bene *= ally.atk;
            bene -= pbene[i];
            int hpcost = cal(ally, pos);
            if (hpcost < ally.hp){
                bene -= hpcost * ally.atk;
            }else{
                bene = -ally.hp * ally.atk - pbene[i];
            }
            mx = max(mx, bene);
        }
        add_edge(i + 1, T, 1, -mx);
        for (int j = 0; j < m; ++j){
            auto enemy = enemy_list[j];
            if (!canAttack(ally, enemy)) continue;
            double bene = 0;
            int allyrem = ally.hp;
            int enemyrem = enemy.hp;
            if (enemy.hp > ally.atk){
                bene += ally.atk * enemy.atk;
                if (!canbekilled[j] || enemy.holy_shield) bene += rpbene[j] / (1 + (!canbekilled[j]) + enemy.holy_shield);
                enemyrem -= ally.atk;
            }else{
                enemyrem = 0;
                bene += enemy.atk * enemy.hp;
                bene += rpbene[j];
            }
            if (canAttack(enemy, ally)){
                allyrem -= enemy.atk;
            }
            allyrem -= cal(ally, ally.pos);
            if (allyrem > 0){
                bene -= (ally.hp - allyrem) * ally.atk;
            }else{
                bene -= ally.hp * ally.atk;
                bene -= pbene[i];
            }
            add_edge(i + 1, n + j + 1, 1, -bene);
        }

        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1]){
            double bene = MATK * ally.atk;
            int hpcost = cal(ally, ally.pos);
            if (hpcost < ally.hp){
                bene -= hpcost * ally.atk;
            }else{
                bene -= ally.hp * ally.atk;
                bene -= pbene[i];
            }
            add_edge(i + 1, n + m + 1, 1, -bene);
        }
    }
    for (int i = 0; i < n; ++i)
        add_edge(S, i + 1, 1, 0);
    for (int i = 0; i < m; ++i){
        add_edge(n + i + 1, T, 1 + (!canbekilled[i]) + enemy_list[i].holy_shield, 0);
    }
    for (int i = 0; i < m; ++i)
        canbekilled[i] = false;
    add_edge(n + m + 1, T, INF, 0);
    minCostMaxFlow(S, T);
    for (int i = 0; i < n; ++i) pid[i] = i;
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j){
            if (ally_list[pid[i]].atk > ally_list[pid[j]].atk)
                swap(pid[i], pid[j]);
        }

    for (int ii = 0; ii < n; ++ii){
        int i = pid[ii];
        if (!ally_list[i].can_move) continue;
        int u = i + 1, v;
        for (int j = 0; j < (int) G[u].size(); ++j){
            if (G[u][j].cap) continue;
            v = G[u][j].to;
            if (v <= n + m){
                attack(ally_list[i].id, enemy_list[v - n - 1].id);
            }else if (v == n + m + 1){
                attack(ally_list[i].id, my_camp ^ 1);
            }
        }
    }

    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (pbene[pid[i]] < pbene[pid[j]])
                swap(pid[i], pid[j]);
    for (int i = 0; i < n; ++i){
        auto ally = ally_list[pid[i]];
        if (!ally.can_move) continue;
        int id = aim[pid[i]];
        if (id < m && turn[enemy_list[id].id] > MAXWAIT && fflag[i]) continue;
        fflag[i] = false;
        auto reach_pos_with_dis = reachable(ally, map);
        vector<Pos> reach_pos_list;
        for (const auto &reach_pos : reach_pos_with_dis) {
            for (auto pos : reach_pos)
                reach_pos_list.push_back(pos);
        }
        double mx = -INF; Pos final_pos = ally.pos;
        bool flag = false;
        if (id < m){
            if (ally.flying) getDisInSky(ally, enemy_list[id].pos);
            else getDisOnGround(ally, enemy_list[id].pos);
        }else if (id == m){
            if (ally.flying) getDisInSky(ally, enemy_pos);
            else getDisOnGround(ally, enemy_pos);
        }else{
            if (ally.flying) BFSS(target_barrack, ally.camp);
            else BFSG(target_barrack, ally.camp);
        }
        for (auto pos: reach_pos_list){
            double bene; int ddd = DIS(pos);
            if (ddd < 0) ddd = 100;
            if (id < m){
                bene = enemy_list[id].atk/(C + upper_div(ddd, ally.max_move));
            }else if (id == m){
                bene = MATK/(C + upper_div(ddd, ally.max_move));
            }else{
                bene = BATK/(C + upper_div(ddd, ally.max_move));
            }
            bene *= ally.atk;
            bene -= pbene[i];
            int hpcost = cal(ally, pos);
            if (hpcost < ally.hp){
                bene -= ally.atk * hpcost;
            }else{
                bene = -pbene[i];
                bene -= ally.atk * ally.hp;
            }
            if (mx < bene){
                mx = bene;
                final_pos = pos;
                flag = true;
            }
        }
        if (flag) move(ally.id, final_pos);
        else if (id < m && turn[enemy_list[id].id] > MAXWAIT) fflag[i] = true;
    }
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (cube_distance(miracle_pos, ally_list[pid[i]].pos) > cube_distance(miracle_pos, ally_list[pid[j]].pos))
                swap(pid[i], pid[j]);
    for (int i = 0; i < n; ++i){//回防
        auto ally = ally_list[pid[i]];
        if (!ally.can_move || !fflag[i]) continue;
        int id = aim[pid[i]];
        auto reach_pos_with_dis = reachable(ally, map);
        vector<Pos> reach_pos_list;
        for (const auto &reach_pos : reach_pos_with_dis) {
            for (auto pos : reach_pos)
                reach_pos_list.push_back(pos);
        }
        Pos final_pos = ally.pos;
        int mn = INF;
        for (auto &pos: reach_pos_list){
            int dis = cube_distance(pos, miracle_pos);
            if (dis < mn){
                mn = dis;
                final_pos = pos;
            }
        }
        if (final_pos != ally.pos) move(ally.id, final_pos);
    }
    for (int i = 0; i < n; ++i)
    for (int i = 0; i <= T; ++i) G[i].clear();
    auto pos_list = all_pos_in_map();
    double art_bene = -INF;
    for (auto &pos : pos_list){
        if (!canUseArtifact(players[my_camp].artifact[0], pos, my_camp)) continue;
        double bene = 0;
        for (int i = 0; i < m; ++i){
            auto enemy = enemy_list[i];
            if (cube_distance(pos, enemy.pos) > 2) continue;
            if (enemy.hp > 2){
                bene += 2 * enemy.atk;
            }else{
                bene += enemy.hp * enemy.atk;
                bene += rpbene[i];
            }
        }
        bene -= 8 * eval(2, true, pos);
        if (bene > art_bene){
            art_bene = bene;
            artifactPos = pos;
        }
    }
}

void AI::Artifact(){
    if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
        use(players[my_camp].artifact[0].id, artifactPos);
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

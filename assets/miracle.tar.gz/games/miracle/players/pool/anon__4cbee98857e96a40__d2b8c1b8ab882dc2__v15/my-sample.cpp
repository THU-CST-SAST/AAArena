#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <fstream>
#include <stdlib.h>
#include <random>
#include <time.h>
#include <iostream>
using namespace std;

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::pair;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;

class AI : public AiClient
{
private:
    Pos miracle_pos;

    Pos enemy_pos;

    Pos target_barrack;

    Pos posShift(Pos pos, string direct);

public:
    //选择初始卡组
    void chooseCards(); //(根据初始阵营)选择初始卡组

    void play(); //玩家需要编写的ai操作函数

    void battle(); //处理生物的战斗

    void march(); //处理生物的移动

    void look(); //扒对面阵容

    vector<vector<pair<string,int>>> selections;
    bool shelled;
};

void AI::chooseCards()
{
    // (根据初始阵营)选择初始卡组

    /*
     * artifacts和creatures可以修改
     * 【进阶】在选择卡牌时，就已经知道了自己的所在阵营和先后手，因此可以在此处根据先后手的不同设置不同的卡组和神器
     */
    my_artifacts = {"SalamanderShield"};
    my_creatures = {"Swordsman", "Priest", "Archer"};
    shelled = 0;
    int u1=0, u2=0, u3=0;
    for(int i=-1;i<9;i++) {
        u1 = i;
        for(int j=i;j<9;j++) {
            u2 = j;
            for(int k=j;k<9;k++) {
                u3 = k;
                vector<pair<string,int>> selection;
                if(u1!=-1) selection.push_back(make_pair(my_creatures[u1/3],u1%3+1));
                if(u2!=-1) selection.push_back(make_pair(my_creatures[u2/3],u2%3+1));
                if(u3!=-1) selection.push_back(make_pair(my_creatures[u3/3],u3%3+1));
                if(!selection.empty()) selections.push_back(selection);
            }
        }
    }

    init();
}

void AI::look()
{
    std::cerr<<endl<<round<<endl;
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
    for(const auto &enemy : enemy_list){
        std::cerr<<enemy.id<<" "<<enemy.type<<enemy.level<<endl;
    }
    std::cerr<<endl;
}

void AI::play()
{
    //玩家需要编写的ai操作函数

    /*
    本AI采用这样的策略：
    在首回合进行初期设置、在神迹优势路侧前方的出兵点召唤一个1星弓箭手
    接下来的每回合，首先尽可能使用神器，接着执行生物的战斗，然后对于没有进行战斗的生物，执行移动，最后进行召唤
    在费用较低时尽可能召唤星级为1的兵，优先度剑士>弓箭手>火山龙
    【进阶】可以对局面进行评估，优化神器的使用时机、调整每个生物行动的顺序、调整召唤的位置和生物种类、星级等
    */

    look();

    if (round == 0 || round == 1) {
        //先确定自己的基地、对方的基地
        miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        
        //设定目标驻扎点为最近的驻扎点
        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
        }

        // 在正中心召唤一个牧师
        summon("Priest", 1, posShift(miracle_pos, "FF"));
        // std::cerr<<round<<" init\n";

    } else {
        //神器能用就用
        if (players[my_camp].mana >= 6 && players[my_camp].artifact[0].state == "Ready") {
            
            auto ally_list = getUnitsByCamp(my_camp);
            //自定义排列顺序
            auto cmp = [this](const Unit &unit1, const Unit &unit2) {
                if (unit1.type != unit2.type) {//剑士>弓箭手
                    auto type_id_gen = [](const string &type_name) {
                        if (type_name == "Swordsman") return 0;
                        else if (type_name == "Archer") return 1;
                        else return 2;
                    };
                    return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
                } else if (unit1.level != unit2.level) { //level 越高越好
                    return unit1.level > unit2.level;
                } else { //离对面越近越好
                    int dis1 = cube_distance(unit1.pos, enemy_pos);
                    int dis2 = cube_distance(unit2.pos, enemy_pos);
                    return dis1 < dis2;
                }
            };
            //按顺序排列好单位
            sort(ally_list.begin(), ally_list.end(), cmp);
            for (const auto ally:ally_list) {
                if (ally.type == "Priest" || ally.type == "Archer") break; //只给剑士套
                if (canUseArtifact(players[my_camp].artifact[0], ally) ) 
                    use(players[my_camp].artifact[0].id, ally.id);
                }
        }

        //之后先战斗，再移动
        battle();
        
        march();
        std::cerr<<"round "<<round<<"mymana "<<players[my_camp].mana<<endl;
        if (players[my_camp].mana>=2) {    
            auto summon_pos_list = getSummonPosByCamp(my_camp);

            //防偷家
            bool tou = false;
            auto enemy_list = getUnitsByCamp(my_camp^1);
            for (auto enemy : enemy_list) 
                if (cube_distance(enemy.pos, miracle_pos)<=5) {
                    tou = true;
                    break;
                }
            if(tou == true) 
                sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
                    return cube_distance(_pos1, miracle_pos) < cube_distance(_pos2, miracle_pos);   // fix: 会不会出来就被打？
                });
            else
                sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
                    return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
                });

            vector<Pos> available_summon_pos_list;
            for (auto pos:summon_pos_list) {
                auto unit_on_pos_ground = getUnitByPos(pos, false);
                if (unit_on_pos_ground.id == -1) available_summon_pos_list.push_back(pos);
            }

            //统计各个生物的可用数量
            int mana = players[my_camp].mana;
            auto deck = players[my_camp].creature_capacity;
            ::map<string, int> available_count;
            for (const auto &card_unit:deck)
                available_count[card_unit.type] = card_unit.available_count;

            //所有可用选怪组合
            vector<vector<pair<string,int>>> avail_list;
            for (auto const &selection : selections) {
                int sel_cost = 0;
                ::map<string, int> sel_count;
                sel_count["Swordsman"] = 0;
                sel_count["Priest"] = 0;
                sel_count["Archer"] = 0;
                for (auto const &u : selection) {
                    sel_count[u.first] ++;
                    sel_cost += CARD_DICT.at(u.first)[u.second].cost;
                }
                if(available_count["Swordsman"] >= sel_count["Swordsman"] &&
                available_count["Priest"] >= sel_count["Priest"] &&
                available_count["Archer"] >= sel_count["Archer"] &&
                mana >= sel_cost ) {
                    avail_list.push_back(selection);
                    }
            }
            std::cerr<<"avail_list: "<<endl;
            if(avail_list.empty()) return;
            for(auto const &selection : avail_list) {
                for(auto const &_unit : selection) {
                    std::cerr<<_unit.first<<_unit.second<<"\n";
                }
            }
            std::cerr<<endl;
            // 按照选怪的估价排序
            sort(avail_list.begin(), avail_list.end(), [this](const vector<pair<string,int>> &_sel1, const vector<pair<string,int>> &_sel2) {   
                auto sel_value_gen = [this](const vector<pair<string,int>> &_sel) {
                    ::map<pair<string,int>,int> sel_count;
                    sel_count[make_pair("Swordsman",1)]=sel_count[make_pair("Swordsman",2)]=sel_count[make_pair("Swordsman",3)]=0;
                    sel_count[make_pair("Priest",1)]=sel_count[make_pair("Priest",2)]=sel_count[make_pair("Priest",3)]=0;
                    sel_count[make_pair("Archer",1)]=sel_count[make_pair("Archer",2)]=sel_count[make_pair("Archer",3)]=0;
                    for (auto const &u : _sel) sel_count[u] ++;
                    
                    ::map<pair<string,int>, int> map_count;
                    map_count[make_pair("Swordsman",1)]=map_count[make_pair("Swordsman",2)]=map_count[make_pair("Swordsman",3)]=0;
                    map_count[make_pair("Priest",1)]=map_count[make_pair("Priest",2)]=map_count[make_pair("Priest",3)]=0;
                    map_count[make_pair("Archer",1)]=map_count[make_pair("Archer",2)]=map_count[make_pair("Archer",3)]=0;
                    for (auto const &u : getUnitsByCamp(my_camp)) map_count[make_pair(u.type,u.level)] ++;
                    
                    int value = 0;
                    if(sel_count[make_pair("Swordsman",1)]!=0) value += 9*sel_count[make_pair("Swordsman",1)]-3*map_count[make_pair("Swordsman",1)];
                    if(sel_count[make_pair("Swordsman",2)]!=0) value += 50*sel_count[make_pair("Swordsman",2)]-10*map_count[make_pair("Swordsman",2)];
                    if(sel_count[make_pair("Swordsman",3)]!=0) value += 100*sel_count[make_pair("Swordsman",3)]-20*map_count[make_pair("Swordsman",3)];

                    if(sel_count[make_pair("Priest",1)]!=0) value += 10*sel_count[make_pair("Priest",1)]-10*map_count[make_pair("Priest",1)];
                    if(sel_count[make_pair("Priest",2)]!=0) value += 30*sel_count[make_pair("Priest",2)]-30*map_count[make_pair("Priest",2)];
                    if(sel_count[make_pair("Priest",3)]!=0) value += 120*sel_count[make_pair("Priest",3)]-90*map_count[make_pair("Priest",3)];
                    
                    if(sel_count[make_pair("Archer",1)]!=0) value += 0*sel_count[make_pair("Archer",1)]-0*map_count[make_pair("Archer",1)];
                    if(sel_count[make_pair("Archer",2)]!=0) value += 19*sel_count[make_pair("Archer",2)]-10*map_count[make_pair("Archer",2)];
                    if(sel_count[make_pair("Archer",3)]!=0) value += 100*sel_count[make_pair("Archer",3)]-20*map_count[make_pair("Archer",3)];
                    return value;
                };
                return sel_value_gen(_sel1) > sel_value_gen(_sel2);
            });

            std::cerr<<"sorted "<<endl;
            for(auto const &selection : avail_list) {
                for(auto const &_unit : selection) {
                    std::cerr<<_unit.first<<_unit.second<<"\n";
                }
                auto sel_value_gen = [this](const vector<pair<string,int>> &_sel) {
                    ::map<pair<string,int>,int> sel_count;
                    sel_count[make_pair("Swordsman",1)]=sel_count[make_pair("Swordsman",2)]=sel_count[make_pair("Swordsman",3)]=0;
                    sel_count[make_pair("Priest",1)]=sel_count[make_pair("Priest",2)]=sel_count[make_pair("Priest",3)]=0;
                    sel_count[make_pair("Archer",1)]=sel_count[make_pair("Archer",2)]=sel_count[make_pair("Archer",3)]=0;
                    for (auto const &u : _sel) sel_count[u] ++;
                    
                    ::map<pair<string,int>, int> map_count;
                    map_count[make_pair("Swordsman",1)]=map_count[make_pair("Swordsman",2)]=map_count[make_pair("Swordsman",3)]=0;
                    map_count[make_pair("Priest",1)]=map_count[make_pair("Priest",2)]=map_count[make_pair("Priest",3)]=0;
                    map_count[make_pair("Archer",1)]=map_count[make_pair("Archer",2)]=map_count[make_pair("Archer",3)]=0;
                    for (auto const &u : getUnitsByCamp(my_camp)) map_count[make_pair(u.type,u.level)] ++;
                    
                    int value = 0;
                    if(sel_count[make_pair("Swordsman",1)]!=0) value += 5*sel_count[make_pair("Swordsman",1)]-3*map_count[make_pair("Swordsman",1)];
                    if(sel_count[make_pair("Swordsman",2)]!=0) value += 50*sel_count[make_pair("Swordsman",2)]-10*map_count[make_pair("Swordsman",2)];
                    if(sel_count[make_pair("Swordsman",3)]!=0) value += 100*sel_count[make_pair("Swordsman",3)]-20*map_count[make_pair("Swordsman",3)];

                    if(sel_count[make_pair("Priest",1)]!=0) value += 10*sel_count[make_pair("Priest",1)]-10*map_count[make_pair("Priest",1)];
                    if(sel_count[make_pair("Priest",2)]!=0) value += 30*sel_count[make_pair("Priest",2)]-30*map_count[make_pair("Priest",2)];
                    if(sel_count[make_pair("Priest",3)]!=0) value += 120*sel_count[make_pair("Priest",3)]-90*map_count[make_pair("Priest",3)];
                    
                    if(sel_count[make_pair("Archer",1)]!=0) value += 1*sel_count[make_pair("Archer",1)]-0*map_count[make_pair("Archer",1)];
                    if(sel_count[make_pair("Archer",2)]!=0) value += 19*sel_count[make_pair("Archer",2)]-10*map_count[make_pair("Archer",2)];
                    if(sel_count[make_pair("Archer",3)]!=0) value += 100*sel_count[make_pair("Archer",3)]-20*map_count[make_pair("Archer",3)];
                    return value;
                };
                std::cerr<<"value: "<<sel_value_gen(selection)<<"\n";
            }
            std::cerr<<"\n";

            vector<string> summon_list;
            vector<int> summon_level;
            for(auto const &_unit : avail_list[0]) {
                summon_list.push_back(_unit.first);
                summon_level.push_back(_unit.second);
            }

            int i = 0;
            for (auto pos:available_summon_pos_list) {
                if (i == summon_list.size()) break;
                summon(summon_list[i], summon_level[i], pos);
                ++i;
            }
            // std::cerr<<round<<" summon2\n\n";
        }
    }
    endRound();
}

Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::battle()
{
    //处理生物的战斗

    /*
     * 基本思路，行动顺序:
     * 剑士：攻击低>高 打消耗，优先打攻击力低的
     * 弓箭手：攻击高>低 优先打不能反击的攻击力最高的，其次打能反击的攻击力最低的
     * 牧师：补刀
     * 对单位的战斗完成后，对神迹进行输出
     * 【进阶】对战斗范围内敌方目标的价值进行评估，通过一些匹配算法决定最优的战斗方式
     * 例如占领着驻扎点的敌方生物具有极高的价值，优先摧毁可以使敌方下回合损失很多可用出兵点
     * 一些生物不攻击而移动，或完全不动，可能能带来更大的威慑力，而赢得更多优势
     */
    // std::cerr<<round<<" battle1\n";
    auto ally_list = getUnitsByCamp(my_camp);

    //自定义排列顺序
    auto cmp = [](const Unit &unit1, const Unit &unit2) {
        if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
        else if (unit1.type != unit2.type) {//剑士>弓箭手
            auto type_id_gen = [](const string &type_name) {
                if (type_name == "Swordsman") return 0;
                else if (type_name == "Archer") return 1;
                else return 2;
            };
            return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
        } 
        else return unit2.atk < unit1.atk;
    };
    //按顺序排列好单位，依次攻击
    sort(ally_list.begin(), ally_list.end(), cmp);
    //先攻击神迹
    for (const auto &ally:ally_list) {

        if (!ally.can_atk) break;                   
        int dis = cube_distance(ally.pos, enemy_pos);
        if (ally.atk_range[0] <= dis && dis <= ally.atk_range[1]) {
            attack(ally.id, my_camp ^ 1);
            continue;
        }

        auto enemy_list = getUnitsByCamp(my_camp ^ 1);
        vector<Unit> target_list;                       //所有能被打的list
        for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(ally, enemy)&&(!enemy.holy_shield))
                target_list.push_back(enemy);
        if (target_list.empty()) continue;
        
        if (ally.type == "Priest") {
            vector<Unit> weak_list;
            for (const auto &tar : target_list)
                if (ally.atk>=tar.hp)
                    weak_list.push_back(tar);
            if (weak_list.empty()) continue;
            default_random_engine g(static_cast<unsigned int>(time(nullptr)));
            int tar = uniform_int_distribution<>(0, weak_list.size() - 1)(g);
            attack(ally.id, weak_list[tar].id);
        }

        else if (ally.type == "Swordsman") {
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        } 
        
        else if (ally.type == "Archer") {
            sort(enemy_list.begin(), enemy_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk > _enemy2.atk; });
            bool suc = false;
            for (const auto &enemy : target_list)
                if (!canAttack(enemy, ally)) {
                    attack(ally.id, enemy.id);
                    suc = true;
                    break;
                }
            if (suc) continue;
            nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk < _enemy2.atk; });
            attack(ally.id, target_list[0].id);
        }
    }
    // std::cerr<<round<<" battle2\n";

}

void AI::march()
{
    //处理生物的移动

    /*
     * 先动所有剑士，尽可能向敌方神迹移动
     * 若目标驻扎点上没有地面单位，则让弓箭手向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 然后若目标驻扎点上没有地面单位，则让火山之龙向目标驻扎点移动，否则尽可能向敌方神迹移动
     * 【进阶】一味向敌方神迹移动并不一定是个好主意
     * 在移动的时候可以考虑一下避开敌方生物攻击范围实现、为己方强力生物让路、堵住敌方出兵点等策略
     * 如果采用其他生物组合，可以考虑抢占更多驻扎点
     */
    auto ally_list = getUnitsByCamp(my_camp);
    sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {
            if (type_name == "Swordsman") return 0;
            else if (type_name == "Archer") return 1;
            else return 2;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
    auto enemy_list = getUnitsByCamp(my_camp ^ 1);
         
    for (const auto &ally : ally_list) {

        if (!ally.can_move) continue;
        if (ally.type == "Swordsman") {
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (const auto &pos : reach_pos) {
                    reach_pos_list.push_back(pos);
                }
            }
            if (reach_pos_list.empty()) continue;
            nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                        [this](Pos _pos1, Pos _pos2) {
                            auto attacked = [this](Pos _pos) {
                                auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                for(const auto &enemy : _enemy_list) {
                                    int dis = cube_distance(enemy.pos, _pos);
                                    if(dis<=enemy.atk_range[1] && dis>=enemy.atk_range[0])
                                        return 1;
                                }
                                return 0;
                            };
                            auto attackable = [this](Pos _pos) {
                                auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                for(const auto &enemy : _enemy_list) {
                                    int dis = cube_distance(enemy.pos, _pos);
                                    if(dis==1) return 1;
                                }
                                return 0;
                            };
                            int atd1=attacked(_pos1), atd2=attacked(_pos2);
                            int atb1=attackable(_pos1), atb2=attackable(_pos2);
                            if(atd1!=atd2)
                                return atd1<atd2;
                            else if(atd1==1&&atd2==1) { //挨打的话可以打别人的靠前
                                return atb1>atb2;
                            }
                            else if(atd1==0&&atd2==0) { //不挨打的话离对面近的靠前
                                return cube_distance(_pos1,enemy_pos) < cube_distance(_pos2,enemy_pos);
                            }
                            return (bool)(rand()%2);
                        });
            move(ally.id, reach_pos_list[0]);
        } else if(ally.type == "Archer"){
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则走到
            if (checkBarrack(target_barrack) != my_camp) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                auto attacked = [this](Pos _pos) {
                                    auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                    for(const auto &enemy : _enemy_list) {
                                        int dis = cube_distance(enemy.pos, _pos);
                                        if(dis<=enemy.atk_range[1] && dis>=enemy.atk_range[0])
                                            return 1;
                                    }
                                    return 0;
                                };
                                auto attackable = [this](Pos _pos) {
                                    auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                    for(const auto &enemy : _enemy_list) {
                                        int dis = cube_distance(enemy.pos, _pos);
                                        if(3<=dis && dis<=4) return 1;
                                    }
                                    return 0;
                                };
                                int atd1=attacked(_pos1), atd2=attacked(_pos2);
                                int atb1=attackable(_pos1), atb2=attackable(_pos2);
                                int dis1=cube_distance(_pos1,enemy_pos), dis2=cube_distance(_pos2,enemy_pos);
                                if(atd1!=atd2)
                                    return atd1<atd2;
                                else if(atd1==1&&atd2==1) { //挨打的话可以打别人的靠前
                                    return atb1>atb2;
                                }
                                else if(atd1==0&&atd2==0) { //不挨打的话离对面近的靠前
                                    if(3<=dis1 && dis1<=4) return true;
                                    if(3<=dis2 && dis2<=4) return false;
                                    return dis1 < dis2;
                                }
                                return (bool)(rand()%2);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        } else { //牧师
            //获取所有可到达的位置
            auto reach_pos_with_dis = reachable(ally, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;

            //优先走到未被占领的兵营，否则走到
            if (checkBarrack(target_barrack) != my_camp) {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                return cube_distance(_pos1, target_barrack) < cube_distance(_pos2, target_barrack);
                            });
                move(ally.id, reach_pos_list[0]);
            } else {
                nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [this](Pos _pos1, Pos _pos2) {
                                auto attacked = [this](Pos _pos) {
                                    auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                    for(const auto &enemy : _enemy_list) {
                                        int dis = cube_distance(enemy.pos, _pos);
                                        if(dis<=enemy.atk_range[1] && dis>=enemy.atk_range[0])
                                            return 1;
                                    }
                                    return 0;
                                };
                                auto attackable = [this](Pos _pos) {
                                    auto _enemy_list = getUnitsByCamp(my_camp ^ 1);
                                    for(const auto &enemy : _enemy_list) {
                                        int dis = cube_distance(enemy.pos, _pos);
                                        if(0<=dis && dis<=1) return 1;
                                    }
                                    return 0;
                                };
                                auto adjnum = [this](Pos _pos) {
                                    auto _ally_list = getUnitsByCamp(my_camp ^ 1);
                                    int _num = 0;
                                    for(const auto &ally : _ally_list) {
                                        int dis = cube_distance(ally.pos, _pos);
                                        if(dis<=2) return _num++;
                                    }
                                    return _num;
                                };
                                int atd1=attacked(_pos1), atd2=attacked(_pos2);
                                int atb1=attackable(_pos1), atb2=attackable(_pos2);
                                if(atd1!=atd2)
                                    return atd1<atd2;
                                else if(atd1==1&&atd2==1) { //挨打的话可以打别人的靠前
                                    return atb1>atb2;
                                } else if(atd1==0&&atd2==0) { //不挨打的话去人多的地方
                                    if(adjnum(_pos1) != adjnum(_pos2))
                                        return adjnum(_pos1) > adjnum(_pos2);
                                    return cube_distance(_pos1,enemy_pos) < cube_distance(_pos2,enemy_pos);
                                }
                                return (bool)(rand()%2);
                            });
                move(ally.id, reach_pos_list[0]);
            }
        }
    }
}

int main()
{
    std::ifstream datafile("Data.json");
    json all_data;
    datafile>>all_data;
    
    card::get_data_from_json(all_data);

    AI player_ai;
    player_ai.chooseCards();
    while (true) {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

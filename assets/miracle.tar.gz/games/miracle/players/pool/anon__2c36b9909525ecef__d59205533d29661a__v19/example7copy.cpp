//牧师版本
#include "ai_client.h"
#include "card.hpp"
#include "gameunit.h"
#include "calculator.h"
#include <tuple>
//line 102
//debug line 332，拖过前面回合，之后开始反攻
#include <random>
#include <time.h>
using gameunit::Pos;//点坐标 
using gameunit::Unit;//单位
using calculator::cube_distance;//返回两点距离
using calculator::all_pos_in_map;//地图中所有位置？
using calculator::reachable;
using calculator::cube_reachable;//返回一个包含所有可到达点坐标的容器（已经剔除所有障碍）
using calculator::units_in_range;

using card::CARD_DICT;

using std::string;
using std::map;
using std::vector;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::get;
using std::make_tuple;
typedef struct{
Pos position;
bool vacant;
} summon_pos;
int summon_mode=0;//0表示前7至15回合
int danger_mode=0;//0代表中立，1代表劣势，2代表大劣势
int unit_around_my_miracle=0;
int unit_attacking=0;
int defense_power=0;
int enemy_defense=0;
class AI : public AiClient
{
private:
Pos miracle_pos;
Pos posShift(Pos pos, string direct);
 Pos enemy_pos;
 Pos target_barrack;
 Pos Archer_hide[3];//弓箭手驻扎点
public:
    //选择初始卡组
    void chooseCards()
    {
        // artifacts和creatures可以修改
        my_artifacts = {"InfernoFlame"};
        my_creatures = {"Archer", "Priest", "Swordsman"};//最新版本
        init();
    }
    void battle();
    void play();
    void march();
    void _summon();
    void use_artifact();
    void is_danger();
};
Pos AI::posShift(Pos pos, string direct)
{
    /*
     * 对于给定位置，给出按照自己的视角（神迹在最下方）的某个方向移动一步后的位置
     * 本段代码可以自由取用
     * @param pos:  (x, y, z)
     * @param direct: 一个str，含2个字符，意义见注释
     * @return: 移动后的位置 (x', y', z')
     */
    transform(direct.begin(), direct.end(), direct.begin(), ::toupper);
    if (my_camp == 0) {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);//修改
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) - 1, get<2>(pos) + 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
    } else {
        if (direct == "FF")  //正前方
            return make_tuple(get<0>(pos) - 1, get<1>(pos) + 1, get<2>(pos));
        else if (direct == "SF")  //优势路前方（自身视角右侧为优势路）
            return make_tuple(get<0>(pos) - 1, get<1>(pos), get<2>(pos) + 1);
        else if (direct == "IF")  //劣势路前方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);//改
        else if (direct == "BB")  //正后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos) - 1, get<2>(pos));
        else if (direct == "SB")  //优势路后方
            return make_tuple(get<0>(pos), get<1>(pos) + 1, get<2>(pos) - 1);
        else if (direct == "IB")  //劣势路后方
            return make_tuple(get<0>(pos) + 1, get<1>(pos), get<2>(pos) - 1);
    }
}

void AI::play(){
if(round==1||round==0){
    //确定神迹位置
      miracle_pos = map.miracles[my_camp].pos;
        enemy_pos = map.miracles[my_camp ^ 1].pos;
        //设定目标驻扎点为最近的驻扎点

        target_barrack = map.barracks[0].pos;
        //确定离自己基地最近的驻扎点的位置
        for (const auto &barrack:map.barracks) {
            if (cube_distance(miracle_pos, barrack.pos) <
                cube_distance(miracle_pos, target_barrack))
                target_barrack = barrack.pos;
}
Archer_hide[1]=posShift(posShift(posShift(posShift(miracle_pos,"IF"),"IF"),"FF"),"FF");//待修改
Archer_hide[0]=posShift(posShift(posShift(posShift(miracle_pos,"IF"),"IF"),"IF"),"FF");
Archer_hide[2]=posShift(posShift(posShift(posShift(miracle_pos,"SF"),"FF"),"FF"),"FF");
summon("Swordsman", 1, posShift(miracle_pos, "SF"));
}
is_danger();
//todo先判断是否用神器
use_artifact();
//攻击
battle();//已初步完成
//移动
march();//初步完成
_summon();
endRound();
}

void AI::march(){//思路：弓箭手走位，剑士切弓箭手，
auto ally_list = getUnitsByCamp(my_camp);
auto enemy_list=getUnitsByCamp(my_camp^1);
sort(ally_list.begin(), ally_list.end(), [](const Unit &_unit1, const Unit &_unit2) {
        auto type_id_gen = [](const string &type_name) {//弓箭手、剑士、地狱火、牧师的移动顺序
            if (type_name == "Swordsman") return 0;
            else if (type_name == "Archer") return 1;
            else if(type_name=="Inferno") return 2;
            else return 3;
        };
        return type_id_gen(_unit1.type) < type_id_gen(_unit2.type);
    });
  auto reach_pos_with_dis = reachable(ally_list[0], map);
            //压平
 vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
//reach_pos_list为可到达地点
for(const Unit &obj:ally_list){
bool on_barrack=false;
for (const auto &barrack:map.barracks)
                if (obj.pos == barrack.pos) {
                    on_barrack = true;
                    break;
                }    
if(!obj.can_move||reach_pos_list.empty())
continue;
if(obj.type=="Swordsman"){//分开，让地狱火去偷家
/*Pos target_pos;
nth_element(enemy_list.begin(),enemy_list.begin(),enemy_list.end(),
[this,&obj](const Unit & _enemy1,const Unit & _enemy2){
if(_enemy1.type=="Archer"&&_enemy2.type=="Archer")
return cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
if(_enemy2.type=="Archer")
return false;
if(_enemy1.type=="Archer")
return true;
return    cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
});
if(!enemy_list.empty())
{if(cube_distance(obj.pos,enemy_list[0].pos)<cube_distance(obj.pos,enemy_pos))
target_pos=enemy_list[0].pos;
else target_pos=enemy_pos;}
else target_pos=enemy_pos;
gameunit::Barrack temp_barrack=map.barracks[0];
for(const auto &a: map.barracks){
if(cube_distance(a.pos,miracle_pos)<cube_distance(temp_barrack.pos,miracle_pos))
temp_barrack=a;
}
if(temp_barrack.camp!=my_camp)
target_pos=target_barrack;
if(enemy_defense<2&&cube_distance(obj.pos,enemy_pos)<=10){//直接进攻神迹
target_pos=enemy_pos;
}
            if (reach_pos_list.empty()) continue;
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos,&enemy_list](Pos _pos1, Pos _pos2) {//需修改
                                int total_atk1=0,total_atk2=0;
                                if(cube_distance(_pos1, target_pos) !=cube_distance(_pos2, target_pos))
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                                else {
                                for(const Unit& ene:enemy_list){
                                if(cube_distance(_pos1,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos1,ene.pos)>=ene.atk_range[0]&&ene.atk_range[1]>=1)
                                total_atk1+=ene.atk;
                                if(cube_distance(_pos2,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos2,ene.pos)>=ene.atk_range[0]&&ene.atk_range[1]>=1)
                                total_atk2+=ene.atk;             
                                }
                                return total_atk1<total_atk2;
                                }
                            });
move(obj.id, reach_pos_list[0]);*/
Pos target_pos;
nth_element(enemy_list.begin(),enemy_list.begin(),enemy_list.end(),
[this,&obj](const Unit & _enemy1,const Unit & _enemy2){
if(_enemy1.type=="Archer"&&_enemy2.type=="Archer")
return cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
if(_enemy2.type=="Archer")
return false;
if(_enemy1.type=="Archer")
return true;
return    cube_distance(_enemy1.pos, obj.pos) < cube_distance(_enemy2.pos, obj.pos);
});
if(!enemy_list.empty())
{if(cube_distance(obj.pos,enemy_list[0].pos)<cube_distance(obj.pos,enemy_pos))
target_pos=enemy_list[0].pos;
else target_pos=enemy_pos;}
else target_pos=enemy_pos;
gameunit::Barrack temp_barrack=map.barracks[0];
for(const auto &a: map.barracks){
if(cube_distance(a.pos,miracle_pos)<cube_distance(temp_barrack.pos,miracle_pos))
temp_barrack=a;
}
if(temp_barrack.camp!=my_camp)
target_pos=target_barrack;
   auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos](Pos _pos1, Pos _pos2) {//需修改
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                            });
move(obj.id, reach_pos_list[0]);
}else if(obj.type=="FrostDragon"){//冰龙只推塔
Pos target_pos=enemy_pos;
 auto reach_pos_with_dis = reachable(obj, map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
            if (reach_pos_list.empty()) continue;
if(cube_distance(obj.pos,target_pos)>6)                        
nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                            [&target_pos,&enemy_list,&obj,this](Pos _pos1, Pos _pos2) {
                                int tmp1,tmp2;
                                int sign1,sign2;
                                sign1=0;//0表示安全
                                sign2=0;
                                for(const Unit &ar:enemy_list){ 
                                tmp1=cube_distance(ar.pos,_pos1);                                      
                                if(tmp1>=ar.atk_range[0]&&tmp1<=ar.atk_range[1]&&ar.atk_range[1]>2)//todo here
                             {//
                             sign1=1;
                             break;
                               }
                                }  
                                for(const Unit &ar:enemy_list){ 
                                tmp2=cube_distance(ar.pos,_pos2);                                      
                                if(tmp2>=ar.atk_range[0]&&tmp2<=ar.atk_range[1]&&ar.atk_range[1]>2)//todo here
                             {//
                             sign2=1;
                             break;
                               }
                                }  
                                if(sign1==sign2)
                                return cube_distance(_pos1, target_pos) < cube_distance(_pos2, target_pos);
                                else return sign1<sign2;
                            });
else  nth_element(reach_pos_list.begin(), reach_pos_list.begin(), reach_pos_list.end(),
                   [&target_pos](Pos _pos1,Pos _pos2){
                   return cube_distance(_pos1,target_pos) <cube_distance(_pos2,target_pos);   
                   }      );                            
move(obj.id, reach_pos_list[0]);

}else if(obj.type=="Priest"){//todo写牧师的移动方式
bool is_being_atk=false;
for(const auto& ene:enemy_list)
if(canAttack(ene,obj)&&ene.type!="Archer"){
    is_being_atk=true;
    break;
}
Pos target_pos;
if(danger_mode==2)
target_pos=miracle_pos;
else target_pos=enemy_pos;
int current_benefit=0;
int pre_range;
if(obj.level==1)
pre_range=2;
else pre_range=3;
auto benefit_list =units_in_range(obj.pos,pre_range,map,my_camp);
for(const auto &a:benefit_list){
if(a.type=="Archer")
current_benefit+=3;
else if(a.type=="Priest")
current_benefit+=1;
else current_benefit+=2;
}
nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),[this,&enemy_list,&pre_range,&target_pos](Pos _pos1,Pos _pos2){
int sign1=0;
int sign2=0;
for(const auto & ene:enemy_list){
if(cube_distance(_pos1,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos1,ene.pos)>=ene.atk_range[0])
sign1=1;
if(cube_distance(_pos2,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos2,ene.pos)>=ene.atk_range[0])
sign2=1;
}
if(sign1!=sign2){
return sign1<sign2;
}
int benefit1=0;
int benefit2=0;
auto benefit1_list=units_in_range(_pos1,pre_range,map,my_camp);
auto benefit2_list=units_in_range(_pos2,pre_range,map,my_camp);
for(const auto &a:benefit1_list){
if(a.type=="Archer")
benefit1+=3;
else if(a.type=="Priest")
benefit1+=1;
else benefit1+=2;
}
for(const auto &a:benefit2_list){
if(a.type=="Archer")
benefit2+=3;
else if(a.type=="Priest")
benefit2+=1;
else benefit2+=2;
}
if(benefit1!=benefit2)
return benefit1>benefit2;
return cube_distance(target_pos,_pos1)<=cube_distance(target_pos,_pos2);
});
int best_benefit=0;
auto next_list=units_in_range(reach_pos_list[0],pre_range,map,my_camp);
for(const auto &a:next_list){
if(a.type=="Archer")
best_benefit+=3;
else if(a.type=="Priest")
best_benefit+=1;
else best_benefit+=2;
}
bool willing_atk=false;
for(const auto& ene:enemy_list)
if(cube_distance(reach_pos_list[0],ene.pos)<=ene.atk_range[1]&&cube_distance(reach_pos_list[0],ene.pos)>=ene.atk_range[0])//最优地点挨打
{
willing_atk=true;
break;
}
if(is_being_atk){
if(!willing_atk)
{
move(obj.id,reach_pos_list[0]);
continue;    
}
else if(best_benefit>=current_benefit){
move(obj.id,reach_pos_list[0]);
continue; 
}
}  else {
if(!willing_atk){//改
move(obj.id,reach_pos_list[0]);
continue; 
}
}
continue;
}
else if(obj.type=="Archer"){//需重新写弓箭手的移动策略,能移动说明挨打或者没有目标
bool is_being_atk=false;
bool has_move=false;
for(const auto& ene:enemy_list)
if(canAttack(ene,obj)&&ene.type!="Archer"){
    is_being_atk=true;
    break;
}
for(const auto & a:reach_pos_list){
   int can_atk_en=0;
   bool be_atk=false;
   for(const auto & ene:enemy_list){
   if(cube_distance(a,ene.pos)<=obj.atk_range[1]&&cube_distance(a,ene.pos)>=obj.atk_range[0])
   can_atk_en++; 
   if(cube_distance(a,ene.pos)<=ene.atk_range[1]&&cube_distance(a,ene.pos)>=ene.atk_range[0]&&ene.type!="Archer")
   be_atk=true;
   }
   if(be_atk)
   continue;
   if(can_atk_en){
   move(obj.id,a);
   has_move=true;
   break;
   }
}
if(has_move)//至此结束说明找到了一个可以不挨打又可以打别人的地方
continue;
Pos target_pos;
if(danger_mode==2)
target_pos=miracle_pos;
else target_pos=enemy_pos;
    nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),[this,&enemy_list,&target_pos](Pos _pos1,Pos _pos2){
int sign1=0;//零表示未被攻击
int sign2=0;
for(const auto & ene:enemy_list){
if(cube_distance(_pos1,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos1,ene.pos)>=ene.atk_range[0]&&ene.type!="Archer")//挨打
sign1=1;
if(cube_distance(_pos2,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos2,ene.pos)>=ene.atk_range[0]&&ene.type!="Archer")//挨打
sign2=1;
}
if(sign1!=sign2)
return sign1<sign2;
int flag1=1;
int flag2=1;
if(cube_distance(_pos1,target_pos)<=4&&cube_distance(_pos1,target_pos)>=3)
flag1=0;
if(cube_distance(_pos2,target_pos)<=4&&cube_distance(_pos2,target_pos)>=3)
flag2=0;
if(flag1!=flag2)
return flag1<flag2;
return cube_distance(_pos1,target_pos)<cube_distance(_pos2,target_pos);
});
if(is_being_atk){
int sign=0;    
for(const auto &ene:enemy_list)
if(cube_distance(ene.pos,reach_pos_list[0])<=ene.atk_range[1]&&cube_distance(ene.pos,reach_pos_list[0])>=ene.atk_range[0]){
sign=1;
break;
}
if(!sign)//最优点不挨打就走
{move(obj.id,reach_pos_list[0]);
has_move=true;}
else if(cube_distance(target_pos,reach_pos_list[0])<cube_distance(target_pos,obj.pos))//或者距离近也走
{move(obj.id,reach_pos_list[0]);
has_move=true;}
}else{//不挨打的情况
int sign=0;    
for(const auto &ene:enemy_list)
if(cube_distance(ene.pos,reach_pos_list[0])<=ene.atk_range[1]&&cube_distance(ene.pos,reach_pos_list[0])>=ene.atk_range[0]){
sign=1;
break;
}
if(!sign){if(cube_distance(target_pos,reach_pos_list[0])<cube_distance(target_pos,obj.pos))
{move(obj.id,reach_pos_list[0]);
has_move=true;}
}
}
continue;
}
else if(obj.type=="Inferno"){//地狱火去偷家
Pos target_pos=enemy_pos;
nth_element(reach_pos_list.begin(),reach_pos_list.begin(),reach_pos_list.end(),[this,&target_pos,&enemy_list](Pos _pos1,Pos _pos2){
if(cube_distance(_pos1,target_pos)!=cube_distance(_pos2,target_pos))
return cube_distance(_pos1,target_pos)<cube_distance(_pos2,target_pos);
int atk1=0; int atk2=0;
for(const auto& ene:enemy_list){
if(cube_distance(_pos1,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos1,ene.pos)>=ene.atk_range[0])
    atk1+=ene.atk;
if(cube_distance(_pos2,ene.pos)<=ene.atk_range[1]&&cube_distance(_pos2,ene.pos)>=ene.atk_range[0])
    atk2+=ene.atk;
}
return atk1<atk2;
});
move(obj.id,reach_pos_list[0]);
return;
}
}
return;
}

void AI::use_artifact(){//地狱火版本，改
//code here
if (players[my_camp].mana >= 8 && players[my_camp].artifact[0].state == "Ready") {
            vector<Pos> pos_list;
            for(const Pos &a:all_pos_in_map()){
            if(canUseArtifact(players[my_camp].artifact[0],a,my_camp))
            pos_list.push_back(a);
            }
            auto best_pos = pos_list[0];
            int max_benefit = 0;
            for (auto pos:pos_list) {
                auto unit_list = units_in_range(pos, 2, map, my_camp^1);
                if (unit_list.size() > max_benefit) {
                    best_pos = pos;
                    max_benefit = unit_list.size();
                }
            }
            if(max_benefit>=2)
            use(players[my_camp].artifact[0].id, best_pos);
        }


return;
}

void AI::is_danger(){
 unit_around_my_miracle=0;
 unit_attacking=0;
 defense_power=0;
 enemy_defense=0;
danger_mode=0;//代表不危险
auto enemys=getUnitsByCamp(my_camp^1);
auto my_units=getUnitsByCamp(my_camp);
for(const auto& me:my_units){
if(cube_distance(me.pos,miracle_pos)<6){
defense_power++;
}
}
for(const auto& ene:enemys){
if(cube_distance(ene.pos,miracle_pos)<=ene.atk_range[1]&&cube_distance(ene.pos,miracle_pos)>=ene.atk_range[0])
unit_attacking++;
if(cube_distance(ene.pos,enemy_pos)<=6)
defense_power++;
}
if(unit_attacking!=0)
{danger_mode=2;//及其危险
return;}
for(const auto& ene:enemys){
if(cube_distance(ene.pos,miracle_pos)<=(ene.max_move+ene.atk_range[1]))
unit_around_my_miracle++;
}
if(unit_around_my_miracle!=0){
danger_mode=1;//较为危险
return;
}
return;    
}


void AI::battle(){//远战单位先攻击  弓箭手>剑士>地狱火>牧师，思路一二级牧师可以缓慢地死，以求星级提升
auto units=getUnitsByCamp(my_camp);//己方单位容器
auto cmp=[](const Unit &unit1, const Unit &unit2){
if (unit1.can_atk != unit2.can_atk)  //首先要能动
            return unit2.can_atk < unit1.can_atk;
            else if(unit1.type != unit2.type){
                auto type_id_gen = [](const string &type_name) {
                if (type_name == "Archer") return 0;
                else if (type_name == "Swordsman") return 1;
                else if(type_name=="Inferno") return 2;
                else return 3;};
                return (type_id_gen(unit1.type) < type_id_gen(unit2.type));
            }
    else return unit1.hp<unit2.hp;//待修改，增加细节,血少的先攻击
};
sort(units.begin(),units.end(),cmp);
for(const auto &obj:units ){
if(!obj.can_atk) break;
auto enemy_list = getUnitsByCamp(my_camp ^ 1);
vector<Unit> target_list;
 int dis = cube_distance(obj.pos, enemy_pos);
 bool can_attack_miracle=obj.atk_range[0] <= dis && dis <= obj.atk_range[1];
for (const auto &enemy : enemy_list)
            if (AiClient::canAttack(obj, enemy))
                target_list.push_back(enemy);
if(target_list.empty()&&!can_attack_miracle) continue;//找到可以攻击的对象
if(obj.type=="Archer"){//细节切换攻击防守模式
if(can_attack_miracle){//推塔是最优选择
    attack(obj.id, my_camp ^ 1);
    goto end1;//推塔
}
for(const auto &ar: enemy_list)
if(AiClient::canAttack(ar,obj)&&ar.type!="Archer")
goto end1;//挨打就走位
if(danger_mode==2&&defense_power<2) goto end1;
sort(target_list.begin(), target_list.end(),
                 [](const Unit &_enemy1, const Unit &_enemy2) {  return _enemy1.hp < _enemy2.hp; });//攻击低的先打
for(const auto &ar:target_list)
if(!canAttack(ar,obj)&&ar.flying){//必须先打蝙蝠，必杀
attack(obj.id,ar.id);
goto end1;
}
for(const auto &ar:target_list)
if(!canAttack(ar,obj)){
    attack(obj.id,ar.id);
goto end1;
}
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end1;
}
end1:
continue;
}else if(obj.type=="Priest"){//待修改，牧师基本不用输出，关键在于走位
//优先推塔
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}
for(const auto &ar: enemy_list)
if(AiClient::canAttack(ar,obj)&&ar.type!="Priest")
goto end2;//挨打就走位
sort(target_list.begin(),target_list.end(),[&obj](const Unit &_enemy1, 
const Unit &_enemy2){return _enemy1.atk<_enemy2.atk;});//打攻击低的
for(const auto &ar:target_list){
attack(obj.id,ar.id);
goto end2;
}
end2:
continue;//待修改
}else if(obj.type=="Swordsman"){//优化攻击模式
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔
for(const auto &ar:target_list)
if(ar.type=="Archer"&&ar.type=="Priest"){
attack(obj.id,ar.id);
goto end3;
}
nth_element(enemy_list.begin(), enemy_list.begin(), enemy_list.end(),
                        [](const Unit &_enemy1, const Unit &_enemy2) { return _enemy1.atk <_enemy2.atk; });
            attack(obj.id, target_list[0].id);//打血厚的？
end3:
continue;
}else if(obj.type=="Inferno"){
bool can_cut=false;    
if(can_attack_miracle){
    attack(obj.id,my_camp^1);
    continue;
}//优先推塔
auto reach_pos_with_dis = reachable(obj ,map);
            //压平
            vector<Pos> reach_pos_list;
            for (const auto &reach_pos : reach_pos_with_dis) {
                for (auto pos : reach_pos)
                    reach_pos_list.push_back(pos);
            }
for(const auto & po:reach_pos_list)
if(cube_distance(po,enemy_pos)<=obj.atk_range[1]){
   int total_atk=0;
   for(const auto& ene:enemy_list){
   if(cube_distance(po,ene.pos)<=ene.atk_range[1]&&cube_distance(po,ene.pos)>=ene.atk_range[0]&&ene.atk_range[1]>1)
   total_atk+=ene.atk;
   }  
   if(obj.hp>total_atk)
   {
    can_cut=true;
   break;
   } 
}
if(can_cut){
    continue;
}//感觉进攻有点拖节奏，改
sort(target_list.begin(),target_list.end(),[](const Unit &_enemy1, const Unit &_enemy2){
    int sign1=2;
    int sign2=2;//代表不是脆皮
    if(_enemy1.type=="Priest"||_enemy1.type=="Archer")
    sign1=0;
    else if(_enemy1.type=="BlackBat")
    sign1=1; 
     if(_enemy2.type=="Priest"||_enemy2.type=="Archer")
    sign2=0;
    else if(_enemy2.type=="BlackBat")
    sign2=1;
    if(sign1!=sign2)
    return sign1<sign2;
    else 
    return _enemy1.hp>_enemy2.hp;
    });//打血厚的
attack(obj.id,target_list[0].id);
continue;
}
}
return;
}

void AI::_summon(){//可以避免第一回合挨打
if(round<=2) return;
int prim;//优先级
auto summon_pos_list = getSummonPosByCamp(my_camp);//可用出兵点
        sort(summon_pos_list.begin(), summon_pos_list.end(), [this](Pos _pos1, Pos _pos2) {
            return cube_distance(_pos1, enemy_pos) < cube_distance(_pos2, enemy_pos);
        });//前面的离敌方基地近
        vector<Pos> available_summon_pos_list;//真正可以放兵的地点 且通过远近排序 前面离敌方基地最远 包括位置和是否用过
        //summon_pos tmp;
        for (auto pos:summon_pos_list) {
            auto unit_on_pos_ground = getUnitByPos(pos, false);
            if (unit_on_pos_ground.id == -1) {
                               available_summon_pos_list.push_back(pos);}
        }
int mana = players[my_camp].mana;//法力值
auto deck = players[my_camp].creature_capacity;
        ::map<string, int> available_count;//这是个映射记录当前可以放置单位的数量
        for (const auto &card_unit:deck)
            available_count[card_unit.type] = card_unit.available_count;
bool is_end=true;//判断是否召唤结束，用danger_mode标志召唤状态
vector<string> summon_list;
auto my_units=getUnitsByCamp(my_camp);
auto enemys=getUnitsByCamp(my_camp^1);
int num_arc=0;
int num_pre=0;
int num_sword=0;
for(const Unit &a:my_units){
if(a.type=="Priest"){
    num_pre++;
    continue;
} else if(a.type=="Archer"){
    num_arc++;
    continue;}
  else if(a.type=="Swordsman"){
   num_sword++;
   continue;
  }
};
while(is_end){
is_end=false;
if(danger_mode==0){//安全情况不用考虑挨打问题
      if(num_pre<num_arc&&num_pre<(num_sword-1)){
        int level=1;
        if(available_count["Priest"]>0&&mana>=CARD_DICT.at("Priest")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
        level=1;  
        int cost;  
        if(7<=mana){
        level=3;cost=7;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
       
        bool has_summon=false;
        
        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Priest",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){   
        summon("Priest",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        //summon("Priest",level,available_summon_pos_list[available_summon_pos_list.size()-1]);
        is_end=true;
        mana-=cost;
        available_count["Priest"]--;
        num_pre++;
        continue;
        }
        if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for(  auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.type!="Archer"){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Archer",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Archer",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Archer"]--;
        num_arc++;
        continue;
        }

        if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for(  auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.atk_range[1]>1){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Swordsman",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Swordsman",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Swordsman"]--;
        num_sword++;
        continue;
        }
      }
      else  if(num_arc<=num_pre&&num_arc<=num_sword){
          int level;
if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for(  auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.type!="Archer"){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Archer",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Archer",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Archer"]--;
        num_arc++;
        continue;
        }
if(available_count["Priest"]>0&&mana>=CARD_DICT.at("Priest")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
        level=1;  
        int cost;  
        if(7<=mana){
        level=3;cost=7;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Priest",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Priest",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Priest"]--;
        num_pre++;
        //available_summon_pos_list.pop_back();
        continue;
        }
         if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
       level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(6<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.atk_range[1]>1){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Swordsman",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Swordsman",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Swordsman"]--;
        num_sword++;
        continue;
        }
      }//else的括号
      else {
       int level=1;   
      if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
       level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(6<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.atk_range[1]>1){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Swordsman",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Swordsman",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Swordsman"]--;
        num_sword++;
        continue;
        }
        if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for(  auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.type!="Archer"){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Archer",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Archer",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Archer"]--;
        num_arc++;
        continue;
        }
        if(available_count["Priest"]>0&&mana>=CARD_DICT.at("Priest")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
        level=1;  
        int cost;  
        if(7<=mana){
        level=3;cost=7;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Priest",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Priest",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Priest"]--;
        num_pre++;
        //available_summon_pos_list.pop_back();
        continue;
        }
      }
} //danger_mode的括号
else{//危险时先召唤剑士
int level=1;
auto enemys=getUnitsByCamp(my_camp^1);
          nth_element(enemys.begin(),enemys.begin(),enemys.end(),[this](Unit _p1, Unit _p2 ){//找到离神迹最近的单位
          return cube_distance(_p1.pos,miracle_pos)<cube_distance(_p2.pos,miracle_pos);
          });
  sort(available_summon_pos_list.begin(), available_summon_pos_list.end(), [this,&enemys](Pos _pos1, Pos _pos2) {
      return cube_distance(_pos1,enemys[0].pos)<cube_distance(_pos1,enemys[0].pos);
        });//前面近
if(available_count["Swordsman"]>0&&mana>=CARD_DICT.at("Swordsman")[1].cost&&available_summon_pos_list.size())
{//远端召唤要放挨打
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        summon("Swordsman",level,available_summon_pos_list[0]);//在离敌人最近处召唤
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        is_end=true;
        mana-=cost;
        available_count["Swordsman"]--;
        num_sword++;
        continue;
        }
        if(available_count["Archer"]>0&&mana>=CARD_DICT.at("Archer")[1].cost&&available_summon_pos_list.size()){//近端召唤
         level=1;  
        int cost;  
        if(6<=mana){
        level=3;cost=6;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]&&un.type!="Archer"){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Archer",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Archer",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Archer"]--;
        num_arc++;
        continue;
        }
        //
        if(available_count["Priest"]>0&&mana>=CARD_DICT.at("Priest")[1].cost&&available_summon_pos_list.size()){//远端召唤要放挨打
         level=1;  
        int cost;  
        if(7<=mana){
        level=3;cost=7;}
       else if(4<=mana){
        level=2;cost=4;}
       else {level=1;cost=2;}
        bool has_summon=false;

        for( auto it =available_summon_pos_list.begin();it!=available_summon_pos_list.end();it++){
           bool being_atk=false; 
           for(const auto & un:enemys){
           if(cube_distance(un.pos,*it)<=un.atk_range[1]&&cube_distance(un.pos,*it)>=un.atk_range[0]){
               being_atk=true;
               break;
           }
           }
           if(!being_atk){
           summon("Priest",level,*it);
           available_summon_pos_list.erase(it);
           has_summon=true;
           break;
           }
        }
        if(!has_summon){
        summon("Priest",level,available_summon_pos_list[0]);
         available_summon_pos_list.erase(available_summon_pos_list.begin());
        }
        is_end=true;
        mana-=cost;
        available_count["Priest"]--;
        num_pre++;
        continue;
        }
}
}//while的括号
return;
}



int main()
{
    AI player_ai;
    player_ai.chooseCards();
    while (true)
    {
        player_ai.updateGameInfo();
        player_ai.play();
    }
    return 0;
}

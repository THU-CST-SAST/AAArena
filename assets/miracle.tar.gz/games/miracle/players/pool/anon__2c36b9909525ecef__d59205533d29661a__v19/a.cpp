#include <iostream>
#include <vector>
using namespace std;
int main(){
vector<int> a;
a.push_back(1);
a.clear();
for(const auto& b :a){


}
return 0;
}
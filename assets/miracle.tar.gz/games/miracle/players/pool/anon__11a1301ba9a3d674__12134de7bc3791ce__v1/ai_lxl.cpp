#include "ai_client.h"
#include "gameunit.h"
#include "card.hpp"
#include "calculator.h"

#include <random>
#include <time.h>

using gameunit::Pos;
using gameunit::Unit;

using calculator::cube_distance;
using calculator::all_pos_in_map;
using calculator::reachable;
using calculator::cube_reachable;
using calculator::units_in_range;

using card::CARD_DICT;

using std :: string;
using std :: map;
using std :: vector;
using std :: default_random_engine;
using std :: uniform_int_distribution;
using std :: get;
using std :: make_tuple;
using std :: pair;

#define eps ( 1 ) 

class AI : public AiClient
{
private:

	Pos target_barrack;

	//Pos posShift(Pos pos, string direct);
	
	Pos posShift( Pos pos , int x , int y , int z );

public:
	//ѡ���ʼ����
	void chooseCards(); //(���ݳ�ʼ��Ӫ)ѡ���ʼ����

	void play(); //�����Ҫ��д��ai��������
	
	void getAttack();
	
	void calc_summon();
	
	void move_army();

	void summon1();

	void summon2();
	
	void summon3();
	
	void summon_bat();
	
	void calcBatThreat();
	
	void update_ans( double predict );
	
	void shield_pre();
	
	void AttackEnemyBase_HolyShieldCast();
};

void AI::chooseCards()
{
	// (���ݳ�ʼ��Ӫ)ѡ���ʼ����

	/*
	 * artifacts��creatures�����޸�
	 * �����ס���ѡ����ʱ�����Ѿ�֪�����Լ���������Ӫ���Ⱥ��֣���˿����ڴ˴������Ⱥ��ֵĲ�ͬ���ò�ͬ�Ŀ��������
	 */
	my_artifacts = { "SalamanderShield" };
	my_creatures = { "Swordsman" , "Archer" , "Priest" };
	init();
}

Pos enemy_pos , miracle_pos;
int id_firstPriest , id_firstSwordsman , id_secondSwordsman , initial_mana;
bool is_ABYSS[20][20];
Pos ABYSS_POS_LIST[25] = {make_tuple(0, 0, 0), make_tuple(-1, 0, 1), make_tuple(0, -1, 1), make_tuple(1, -1, 0), make_tuple(1, 0, -1), make_tuple(0, 1, -1), make_tuple(-1, 1, 0), make_tuple(-2, -1, 3), make_tuple(-1, -2, 3), make_tuple(-2, -2, 4), make_tuple(-3, -2, 5), make_tuple(-4, -4, 8), make_tuple(-5, -4, 9), make_tuple(-4, -5, 9), make_tuple(-5, -5, 10), make_tuple(-6, -5, 11), make_tuple(1, 2, -3), make_tuple(2, 1, -3), make_tuple(2, 2, -4), make_tuple(3, 2, -5), make_tuple(4, 4, -8), make_tuple(5, 4, -9), make_tuple(4, 5, -9), make_tuple(5, 5, -10), make_tuple(6, 5, -11)};
AI player_ai;
Pos bridge[6] = { make_tuple( -2 , 0 , 2 ) , make_tuple( -1 , -1 , 2 ) , make_tuple( 0 , -2 , 2 ) , make_tuple( 0 , 2 , -2 ) , make_tuple( 1 , 1 , -2 ) , make_tuple( 2 , 0 , -2 ) }; 

bool have_dragon , have_bat , have_priest , have_sword; //�����Ƿ�������������ʦ����ʿ 
int Round , ennewpr;

const double C_enkill[7][3] = { { 2 , 6 , 10 } , { 3 , 8 , 16 } , { 3 , 8 , 12 } , { 5 , 7 , 9 } , { 4 , 6 , 8 } , { 4 , 7 , 15 } , { 15 , 15 , 15 } };
//ɱ�����˽��������������������������𣬵����������
const double C_enhurt[7][3] = { { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 1 } , { 1 , 1 , 7 } , { 4 , 4 , 4 } };
//���˵��˽��������������������������𣬵����������
const double C_mykill[7][3] = { { -0.5 , -3 , -5 } , { -2 , -7 , -9 } , { 0 , -10 , -12 } , { 0 , 0 , 0 } , { 0 , 0 , 0 } , { 0 , 0 , 0 } , { -6 , -6 , -6 } };
//ɱ���Լ�����������������
const double C_myhurt[7][3] = { { -0.2 , -0.5 , -0.8 } , { -1 , -1 , -1 } , { 0 , -0.7 , -0.7 } , { 0 , 0 , 0 } , { 0 , 0 , 0 } , { 0 , 0 , 0 } , { -1 , -1 , -1 } };
//�����Լ�����������������
const double C_arpos[12] = { -3 , 2.5 , 0.5 , 3 , 20 , 1.5 , -0.9 , 1 , 5 , 2 , 4 , 3 };
//����λ�ñ��»غ����ϣ�����һ���������Ƕ����������һ�������㣨����ҪȨֵ���룩���ǻ��أ����Ƕ�����԰��εı��������ţ�����������в�����������ң����ǶԷ����������񣨲���ҪȨֵ���룩�������ҷ��մ��������������񣬸����ҷ�����в��������������� 
const double C_swpos[10] = { 3 , 2.5 , 1 , 2 , 20 , 1 , -1.1 , 6 , 15 , 3 };
//����λ�ü�ס���湭���֣���ס����������ס���潣ʿ������һ�������㣨����ҪȨֵ���룩�����ǻ��أ���������˾��룬�����ţ�����������в�����������ң����Ǹմ������Ķ�������������
const double C_prpos[4] = { 2 , 1 , 0.15 , -0.9 }; 
//����λ�û��һ���Ѿ��ӹ��������壬��һ���Ѿ���Ѫ�����壬��Χ����һ���Ѿ��������ŵ����� 
const double C_my_arpos[3][6] = { { -3 , 3 , 0 , 1 , -2 , -1 } , { -7 , 3 , -1 , 1 , -6 , -4 } , { -15 , -1 , -2.5 , -0.5 , -13 , -9 } };
//����λ�ûᱻ���������ᱻ�����������˺�����Ѫ�˺������ܷǱ����������ԶԷ������֣�һ���Ǳ����������ԶԷ������ֵ����� 
const double C_my_swpos[3][4] = { { -1 , 0 , -0.2 , 1 } , { -6 , 1 , -0.3 , 1 } , { -8 , 2 , -1 , 0.5 } };
//����λ�ûᱻ���������ᱻ�����������˺�����Ѫ�˺������� 
const double C_my_prpos[3][2] = { { 0 , 0 } , { -8 , -2 } , { -10 , -2 } };
//����λ�ûᱻ�������������˺������� 
const double C_barrack_value[7] = { 8 , 2 , 1 , -1 , -1 , -1 , 15 } , C_base_value[7] = { 10 , 5 , 2 , -1 , -1 , -1 , 10 };
//����Ӫ�ͻ��ص�ֵ 
const double C_holy = 20;
//����ʥ��Ŀ������� 
const double threat_base[7][3] = { { 8 , 10 , 12 } , { 10 , 20 , 30 } , { 1 , 2 , 3 } , { 10 , 15 , 20 } , { 10 , 15 , 20 } , { 5 , 10 , 20 } , { 20 , 20 , 20 } };
//��в���صĸ���Ȩֵ 
const double threat_barrack[7][3] = { { 6 , 8 , 10 } , { 3 , 4 , 5 } , { 2 , 4 , 6 } , { 0.5 , 1 , 1.5 } , { 0.5 , 1 , 1.5 } , { 0 , 0 , 0 } , { 15 , 15 , 15 } };
//��в������ĸ���Ȩֵ 
const double attack_Camp = 4;
//������������ɱ������ 
const double stayCamp = 6;
//�Է���camp����ʱ�����camp������ 
double stealCamp = 4;
//����camp������ 
const double bridgeBlock = 1.5;
//�����ܹ��ŵ�ʱ��ס������ 
double amiBridge = 1.5;
//�����ܹ��ŵ�ʱ�򹭼����������� 
double defence_move1 = 5 , defence_move2 = 0.3;
//����������<=8���˼�ȥ���Ǿ������<=5��ʿ�������棬����Զ����в������ 

double Dbase_sword[7][10] = {
	{ 0 , 8 , 2 , 1 , 1 , 1 , 0 , 0 , 0 , 0 } , 
	{ 0 , 8 , 1 , 1 , 1 , 1 , 0 , 0 , 0 , 0 } , 
	{ 0 , 8 , 1 , 1 , 1 , 1 , 0 , 0 , 0 , 0 } , 
	{ 0 , 10 , 3 , 4 , 2 , 0 , 0 , 0 , 0 , 0 } , 
	{ 0 , 10 , 3 , 4 , 2 , 0 , 0 , 0 , 0 , 0 } , 
	{ -5 , -5 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } , 
	{ 0 , 16 , 4 , 2 , 1 , 1 , 0 , 0 , 0 , 0 } , 
};
//�������ؾ��뽣����������������������������ÿ������ļ�ֵ
double Dbarrack_sword[4][2] = { { 1 , 0 } , { 4 , 0 } , { 5 , 0 } , { 2 , 1 } }; 
//������Ӫ��������������ʿ��������=1,2�ļ�ֵ
double DA_sword[2] = { 30 , 15 };
//���������ܴ�ҵ�Ŀ��ļ�ֵ

double Dbarrack_archer = 5 , Dbase_archer = 6 , DA_archer = 15; 
//�����ַ����ļ�ֵ 

double enkill[7][3] , enhurt[7][3];
double mykill[7][3] , myhurt[7][3];
double arpos[12] , swpos[10] , prpos[4] , barrack_value[7] , base_value[7];
double my_arpos[3][6] , my_swpos[3][4] , my_prpos[3][2];
double holy;
double protect_base_ext[1000];
bool lock[1000];

vector < gameunit :: Unit > my_army , en_army;

vector < gameunit :: Pos > enemy_barrack , my_barrack , my_capture;

vector < Pos > basesummon;

int attack_count;

Pos center[4] = { make_tuple( 0 , -5 , 5 ) , make_tuple( 0 , 5 , -5 ) , make_tuple( -6 , -6 , 12 ) , make_tuple( 6 , 6 , -12 ) };

vector < gameunit :: Pos > en_center , my_center;

vector < gameunit :: Unit > threat , threat_base_unit , threat_barrack_unit , base_attack_unit;
Pos threat_pos[1000];

double extra_value[1000];

inline bool canAttackEnemyBase( gameunit :: Unit & a )
{
	if( !a.atk ) return 0;
	if( cube_distance( a.pos , enemy_pos ) >= a.atk_range[0] && cube_distance( a.pos , enemy_pos ) <= a.atk_range[1] )
		return 1;
	return 0;
}

inline bool canAttackMyBase( gameunit :: Unit & a )
{
	if( !a.atk ) return 0;
	if( cube_distance( a.pos , miracle_pos ) >= a.atk_range[0] && cube_distance( a.pos , miracle_pos ) <= a.atk_range[1] )
		return 1;
	return 0;
}

inline int trans( string type )
{
	if( type == "Swordsman" ) return 0;
	if( type == "Archer" ) return 1;
	if( type == "Priest" ) return 2;
	if( type == "VolcanoDragon" ) return 3;
	if( type == "FrostDragon" ) return 4;
	if( type == "BlackBat" ) return 5;
	return 6;
}

inline void get_center()
{
	en_center.clear();
	my_center.clear();
	for( int i = 0 ; i < 4 ; i++ )
	{
		for( auto & j : enemy_barrack )
			if( cube_distance( center[i] , j ) == 1 )
				en_center.push_back( center[i] );
		for( auto & j : my_barrack )
			if( cube_distance( center[i] , j ) == 1 )
				my_center.push_back( center[i] );
	}
	//std :: cerr << "enemy base: " << ( get < 0 > ( enemy_pos ) ) << " " << ( get < 1 > ( enemy_pos ) ) << std :: endl;
}

inline void get_threat() //�������в���غͳ������Ŀ��
{
	threat.clear();
	threat_base_unit.clear();
	threat_barrack_unit.clear();
	base_attack_unit.clear();
	memset( threat_pos , 0 , sizeof( threat_pos ) );
	for( auto & i : en_army )
		if( i.hp > 0 )
			if( cube_distance( i.pos , miracle_pos ) <= i.max_move + i.atk_range[1] ) //��һ�غϿ�����в������ 
			{
				threat.push_back( i );
				threat_pos[ i.id ] = miracle_pos;
				threat_base_unit.push_back( i );
			}
	for( auto & j : my_center )
		for( auto & i : en_army )
			if( i.hp > 0 && i.type != "BlackBat" )
				if( cube_distance( i.pos , j ) <= i.max_move ) //��һ�غϿ�����в�������� 
					if( threat_pos[ i.id ] != miracle_pos )
					{
						threat.push_back( i );
						threat_pos[ i.id ] = j;
						threat_barrack_unit.push_back( i );
					}
	for( auto & i : en_army )
		if( canAttackMyBase( i ) )
			base_attack_unit.push_back( i );
}

int en_camp;

int swordsman_available , archer_available , priest_available;

inline double AttackEnemyBaseValue( gameunit :: Unit & a )
{
	return 200 * a.atk;
}

inline void getExtra()
{
	memset( extra_value , 0 , sizeof( extra_value ) );
	for( auto & i : threat )
		if( threat_pos[ i.id ] == miracle_pos )
			extra_value[ i.id ] += threat_base[ trans( i.type ) ][ i.level - 1 ]; //��в���ؼ�Ȩ 
		else
			extra_value[ i.id ] += threat_barrack[ trans( i.type ) ][ i.level - 1 ]; //��в�������Ȩ 
	for( auto & i : en_army )
		if( canAttackMyBase( i ) )
			extra_value[ i.id ] += 200 * i.atk; //�������ؼ�Ȩ 
}

inline void AI :: calc_summon() //������ˮ��
{
	int cd_num[6] = { 0 } , cnt = 0;
	for( auto & i : players[ my_camp ].creature_capacity )
	{
		if( i.type == "Archer" )
			archer_available = i.available_count;
		else if( i.type == "Swordsman" )
			swordsman_available = i.available_count;
		else if( i.type == "Priest" )
			priest_available = i.available_count;
		for( auto & j : i.cool_down_list )
			cd_num[j] += ( i.type == "Priest" ? 4 : 7 );
	}
	if( round <= 30 ) return;
	cnt = archer_available * 6 + swordsman_available * ( have_dragon ? 6 : 4 ) + priest_available * 4;
	bool flag = 0;
	for( int i = 0 ; i < 5 ; i++ )
	{
		if( round + i == 50 || round + i == 51 || round + i == 75 || round + i == 76 ) //���мӱ��Ļغ� 
			cnt += archer_available * 6 + swordsman_available * ( have_dragon ? 6 : 4 ) + priest_available * 4;
		if( cd_num[i] <= 6 ) //��غ�cd�����Ĳ��� 
			cnt -= 6;
		if( cd_num[i] > 12 ) //��غ�cd�����Ķ��� 
			cnt += ceil( ( cd_num[i] - 12 ) * 1.0 / 6 ) * 6;
		if( ( i == 3 || i == 4 ) && cnt <= -4 ) //Ӧ����غ϶໻�� 
			flag = 1;
	}
	if( flag )
	{
		//std :: cerr << "calc ready: " << round << std :: endl;
		for( int i = 0 ; i < 7 ; i++ )
			for( int j = 0 ; j < 3 ; j++ )
			{
				enkill[i][j] *= 2 , enhurt[i][j] *= 2;
				if( i != 2 ) mykill[i][j] += 4;
				myhurt[i][j] += 1;
			}
		for( int i = 0 ; i < 3 ; i++ )
		{
			if( !have_bat )
				my_arpos[i][1] += 4 , my_arpos[i][3] += 1;
			my_swpos[i][1] += 4 , my_swpos[i][3] += 1;
			my_prpos[i][1] += 1;
		}
		prpos[0] += 2;
	}
}

inline void AI :: AttackEnemyBase_HolyShieldCast() //��غ��ܹ���������ص�ʥ�� 
{
	if( players[ my_camp ].mana >= 6 && players[ my_camp ].artifact[0].state == "Ready" )
	{
		for( auto & i : my_army )
			if( i.hp > 0 && i.type == "Archer" && canAttackEnemyBase( i ) )
			{
				use( players[ my_camp ].artifact[0].id , i.id );
				break;
			}
	}
	if( players[ my_camp ].mana >= 6 && players[ my_camp ].artifact[0].state == "Ready" )
	{ 
		for( auto & i : my_army )
			if( i.hp > 0 && i.type == "Swordsman" && canAttackEnemyBase( i ) )
			{
				use( players[ my_camp ].artifact[0].id , i.id );
				break;
			}
	}
}

inline bool canAttack_earth( gameunit :: Unit attacker , Pos target )  
{
	//������Χ
	int dist = calculator :: cube_distance( attacker.pos , target );
	if( dist < attacker.atk_range[0] || dist > attacker.atk_range[1] )
		return 0;
	return true;
}

inline bool canAttack_air( gameunit :: Unit attacker , Pos target ) 
{
	//������Χ
	int dist = calculator :: cube_distance( attacker.pos , target );
	if( dist < attacker.atk_range[0] || dist > attacker.atk_range[1] )
		return false;
	//�Կչ���
	if( !attacker.atk_flying )
		return false;
	return true;
}

gameunit :: Unit shield_target[2];

inline void use_proposal( gameunit :: Unit a , int atk_base ) //�����һ������ʥ�� 
{
	if( shield_target[ atk_base ].level < a.level )
		shield_target[ atk_base ] = a;
	else
		if( shield_target[ atk_base ].atk > a.atk )
			shield_target[ atk_base ] = a;
}

void AI :: play()
{
	//�����Ҫ��д��ai��������
	Round = round;
	//std :: cerr << "Start Round: " << Round << std :: endl;
	en_camp = 1 ^ my_camp;
	auto & detect = players[ en_camp ].creature_capacity;
	for( auto & i : detect )
		if( i.type == "VolcanoDragon" || i.type == "FrostDragon" )
			have_dragon = 1;
		else if( i.type == "BlackBat" )
			have_bat = 1;
		else if( i.type == "Priest" )
			have_priest = 1;
		else if( i.type == "Swordsman" )
			have_sword = 1;
	//std :: cerr << "A1" << std :: endl;
	memcpy( enkill , C_enkill , sizeof( enkill ) );
	memcpy( enhurt , C_enhurt , sizeof( enhurt ) );
	memcpy( mykill , C_mykill , sizeof( mykill ) );
	memcpy( myhurt , C_myhurt , sizeof( myhurt ) );
	memcpy( arpos , C_arpos , sizeof( arpos ) );
	memcpy( swpos , C_swpos , sizeof( swpos ) );
	memcpy( prpos , C_prpos , sizeof( prpos ) );
	memcpy( my_arpos , C_my_arpos , sizeof( my_arpos ) );
	memcpy( my_swpos , C_my_swpos , sizeof( my_swpos ) );
	memcpy( my_prpos , C_my_prpos , sizeof( my_prpos ) );
	memcpy( barrack_value , C_barrack_value , sizeof( barrack_value ) );
	memcpy( base_value , C_base_value , sizeof( base_value ) );
	//std :: cerr << "A2" << std :: endl;
	if( have_priest ) //����ʦ�Ļ����˵�Ч����� 
		for( int i = 0 ; i < 7 ; i++ )
			for( int j = 0 ; j < 3 ; j++ )
				enhurt[i][j] *= 0.3 , enkill[i][j] *= 1.2;
	
	ennewpr = 0;
	for( auto & i : players[ en_camp ].creature_capacity )
		if( i.type == "Priest" )
			for( auto & j : i.cool_down_list )
				if( j <= 1 )
					ennewpr++;
	
	//std :: cerr << "A3" << std :: endl;
	calc_summon();
	//std :: cerr << "A4" << std :: endl;
	if( have_bat )
	{
		mykill[1][1] -= 6 , mykill[1][2] -= 8;
		enkill[1][1] += 2 , enkill[1][2] += 4;
		mykill[1][1] += 2 , mykill[1][2] += 3;
		my_arpos[0][1] -= 2;
		my_arpos[1][1] -= 4;
		my_arpos[2][1] -= 6;
		my_swpos[1][0] = -2 , my_swpos[2][0] = -3;
	}
	//std :: cerr << "A5" << std :: endl;
	my_barrack = getSummonPosByCamp( my_camp );
	enemy_barrack = getSummonPosByCamp( en_camp );
	
	miracle_pos = map.miracles[ my_camp ].pos;
	enemy_pos = map.miracles[ en_camp ].pos;
	holy = C_holy;
	
	get_center();
	//std :: cerr << "A6" << std :: endl;
	
	//std :: cerr << "enemy_miracle: " << ( get < 0 > ( enemy_pos ) ) << " " << ( get < 1 > ( enemy_pos ) ) << std :: endl;
	
	if( round == 0 || round == 1 )
	{
		//��ȷ���Լ��Ļ��ء��Է��Ļ���
		for( int i = 0 ; i < 25 ; i++ )
			is_ABYSS[ get < 0 > ( ABYSS_POS_LIST[i] ) + 9 ][ get < 1 > ( ABYSS_POS_LIST[i] ) + 9 ] = 1;
		for( int i = -8 ; i <= +8 ; i++ )
			for( int j = -8 ; j <= +8 ; j++ )
			{
				if( abs( i + j ) >= 13 ) //���� 
					is_ABYSS[ i + 9 ][ j + 9 ] = 1;
				if( abs( i ) + abs( j ) >= 15 ) //���� 
					is_ABYSS[ i + 9 ][ j + 9 ] = 1;
				if( abs( i ) == 7 && abs( j ) == 7 ) //���� 
					is_ABYSS[ i + 9 ][ j + 9 ] = 1;
			}
		is_ABYSS[ get < 0 > ( miracle_pos ) + 9 ][ get < 1 > ( miracle_pos ) + 9 ] = 1;
		is_ABYSS[ get < 0 > ( enemy_pos ) + 9 ][ get < 1 > ( enemy_pos ) + 9 ] = 1;
		basesummon.push_back( posShift( miracle_pos , 1 , 0 , 0 ) );
		basesummon.push_back( posShift( miracle_pos , 0 , 1 , 0 ) );
		basesummon.push_back( posShift( miracle_pos , 0 , 0 , 1 ) );
		if( round == 0 )
			summon( "Priest" , 1 , posShift( miracle_pos , 1 , 0 , 0 ) );
		else
			summon( "Swordsman" , 1 , posShift( miracle_pos , 1 , 0 , 0 ) );
	}
	else if( round == 2 || round == 3 )
	{
		id_firstPriest = getUnitByPos( posShift( miracle_pos , 1 , 0 , 0 ) , false ).id;
		
		if( round == 2 )
			move( id_firstPriest , posShift( miracle_pos , 1 , 5 , 0 ) );
		else
			move( id_firstPriest , posShift( miracle_pos , 1 , 0 , 3 ) );
		
		summon( "Swordsman" , 1 , posShift( miracle_pos , 1 , 0 , 0 ) );
		
	}
	else if( round == 4 || round == 5 )
	{
		id_firstSwordsman = getUnitByPos( posShift( miracle_pos , 1 , 0 , 0 ) , false ).id;
		
		if( round == 4 )
		{
			move( id_firstPriest , posShift( miracle_pos , 1 , 10 , 0 ) );
			move( id_firstSwordsman , posShift( miracle_pos , 1 , 0 , 3 ) );
		}
		else
		{
			move( id_firstPriest , posShift( miracle_pos , 2 , 0 , 5 ) );
			move( id_firstSwordsman , posShift( miracle_pos , 4 , 0 , 0 ) );
		}
		
		if( !have_bat )	
			summon( "Swordsman" , 1 , posShift( miracle_pos , 1 , 0 , 0 ) );
		else
			summon( "Archer" , 1 , posShift( miracle_pos , 1 , 0 , 0 ) );
	}
	else if( round == 6 || round == 7 )
	{
		if( round == 6 )
		{
			move( id_firstPriest , posShift( miracle_pos , 1 , 12 , 0 ) );
			move( id_firstSwordsman , posShift( miracle_pos , 2 , 0 , 5 ) );
		}
		else
			move( getUnitByPos( posShift( miracle_pos , 1 , 0 , 0 ) , false ).id , posShift( miracle_pos , 4 , 0 , 0 ) );
		getAttack();
		//std :: cerr << "OK0" << std :: endl;
		move_army();
		//std :: cerr << "OK1" << std :: endl;
		if( have_bat )
			calcBatThreat();
		//std :: cerr << "OK2" << std :: endl;
		summon_bat();
		//std :: cerr << "OK3" << std :: endl;
		summon1();
		//std :: cerr << "OK4" << std :: endl;
		summon2();
		//std :: cerr << "OK5" << std :: endl;
	}

	else
	{
		initial_mana = players[ my_camp ].mana;
		getAttack();
		if( have_bat )
			calcBatThreat();
		shield_pre();
		get_threat();
		if( threat.size() == 0 )
		{
			summon_bat();
			summon1();
			getAttack();
			getExtra();
			move_army();
			getAttack();
			summon2();
		}
		else
		{
			summon_bat();
			getAttack();
			getExtra();
			move_army();
			getAttack();
			get_threat();
			if( threat.size() ) //�ų���в 
				summon3();
			summon1();
			summon2();
		}
	}
	if( players[ my_camp ].mana >= 6 && players[ my_camp ].artifact[0].state == "Ready" )
	{
		int id = 0 , mindist = 114514;
		for( auto & i : my_army )
			if( i.hp > 0 )
				if( i.type != "Priest" )
					if( cube_distance( i.pos , enemy_pos ) - i.atk_range[1] < mindist && i.level >= 2 ) //���������ĸ߼�Ŀ��ʹ�� 
					{
						mindist = cube_distance( i.pos , enemy_pos ) - i.atk_range[1];
						id = i.id;
					}
		if( id )
			use( players[ my_camp ].artifact[0].id , id );
	}
	endRound();
}

Pos AI :: posShift( Pos pos , int x , int y , int z ) //��ǰ��x����������y����������z 
{
	if( my_camp == 0 )
		return make_tuple( get < 0 > ( pos ) + x + z , get < 1 > ( pos ) - x - y , get < 2 > ( pos ) + y - z ); 
	else
		return make_tuple( get < 0 > ( pos ) - x - z , get < 1 > ( pos ) + x + y , get < 2 > ( pos ) - y + z );
}

inline int cover( gameunit :: Unit & a ) //cover��ʾ�м�����ʦ���� 
{
	int p = 0;
	for( auto & i : my_army )
		if( i.type == "Priest" && i.hp > 0 )
			if( cube_distance( a.pos , i.pos ) <= ( i.level == 1 ? 2 : 3 ) )
				p++;
	//if( t != p ) std :: cerr << "ERROR: " << a.type << " " << t << " " << p << std :: endl;
	return p;
}

struct activity
{
	Pos pos;
	int att;
	activity( int x ) : att( x ) , pos( make_tuple( 114 , 114 , 114 ) ) {}
	activity( Pos pos ) : att( -1 ) , pos( pos ) {}
	activity() {}
} action[1000] , recorded_action[1000];

gameunit :: Unit recorded_shield;

double now_ans;
//��غ����Լ�����Ѫ���»غϵ���̰�Ĵ���ҵ�Ѫ 

char en_block[20][20] , exist[20][20] , vis[20][20];

void AI :: getAttack()
{
	my_army.clear();
	en_army.clear();
	memset( action , 0 , sizeof( action ) );
	memset( recorded_action , 0 , sizeof( recorded_action ) );
	memset( vis , 0 , sizeof( vis ) );
	//for( int i = 0 ; i < 1000 ; i++ ) target[i].clear(); 
	for( int i = -8 ; i <= +8 ; i++ )
		for( int j = -8 ; j <= +8 ; j++ )
			for( int t = 0 ; t <= 1 ; t++ )
			{
				int k = -( i + j );
				gameunit :: Unit p = getUnitByPos( make_tuple( i , j , k ) , t );
				if( p.id != -1 )
					if( p.camp == my_camp )
						my_army.push_back( p );
					else
						en_army.push_back( p );
			}
}

int BT1 , BT2;

void AI :: calcBatThreat()
{
	BT1 = BT2 = 0;
	for( auto & i : en_army )
		if( i.hp > 0 && i.type == "BlackBat" )
		{
			if( cube_distance( i.pos , miracle_pos ) <= i.max_move + 1 ) //һ�غ��ܵ������� 
				BT1++;
			if( cube_distance( i.pos , miracle_pos ) <= i.max_move * 2 + 1 ) //���غ��ܵ�������
				BT2++;
		}
}

bool canAttack(gameunit::Unit attacker, gameunit::Unit target)
{
	//������С�ڵ���0�������޷�����
	if (attacker.atk <= 0)
		return false;
	//������Χ
	int dist = calculator::cube_distance(attacker.pos, target.pos);
	if (dist < attacker.atk_range[0] || dist > attacker.atk_range[1])
		return false;
	//�Կչ���
	if (target.flying && (!attacker.atk_flying))
		return false;
	return true;
}

vector < Pos > accessable; 

inline void mark_surronding( Pos pos )
{
	int x = get < 0 > ( pos ) , y = get < 1 > ( pos );
	exist[x + 9][y + 9] = 1;
	en_block[x - 1 + 9][y + 1 + 9] = 1;
	en_block[x - 1 + 9][y	 + 9] = 1;
	en_block[x	 + 9][y + 1 + 9] = 1;
	en_block[x	 + 9][y - 1 + 9] = 1;
	en_block[x + 1 + 9][y - 1 + 9] = 1;
	en_block[x + 1 + 9][y	 + 9] = 1;
}

inline void get_Remaining_En() //���˶��Լ��ĸ� 
{
	for( auto & i : en_army )
		if( !i.flying && i.hp > 0 )
			mark_surronding( i.pos );
}

inline void get_Remaining_My() //�Լ����Լ��ĸ� 
{
	for( auto & i : my_army )
		if( !i.flying && i.hp > 0 )
			exist[ get < 0 > ( i.pos ) + 9 ][ get < 1 > ( i.pos ) + 9 ] = 1;
}

std :: tuple < int , int , int > q[200];
int qr = 0;

void search( int x , int y , int v )
{
	qr = 0;
	q[ qr++ ] = make_tuple( x , y , v );
	int ql = 0 , r = en_block[x + 9][y + 9];
	en_block[x + 9][y + 9] = 0;
	exist[x + 9][y + 9] = 0;
	//std :: cerr << "find: " << x << " " << y << std :: endl;
	while( ql != qr )
	{
		std :: tuple < int , int , int > now = q[ ql++ ];
		int x = get < 0 > ( now ) , y = get < 1 > ( now ) , v = get < 2 > ( now );
		if( x < -8 || x > +8 || y < -8 || y > +8 ) continue;
		if( is_ABYSS[x + 9][y + 9] ) continue;
		//std :: cerr << "now: " << v << std :: endl;
		if( !exist[x + 9][y + 9] ) //���λ��û�е������� 
		{
			accessable.push_back( make_tuple( x , y , -( x + y ) ) );
			if( !en_block[x + 9][y + 9] && v )
				for( int i = -1 ; i <= +1 ; i++ )
					for( int j = -1 ; j <= + 1 ; j++ )
						if( i != j )
							if( !vis[x + i + 9][y + j + 9] && !exist[x + i + 9][y + j + 9] ) //���λ��û�е������� 
							{
								vis[x + i + 9][y + j + 9] = 1;
								q[ qr++ ] = make_tuple( x + i , y + j , v - 1 );
							}
		}
	}
	exist[x + 9][y + 9] = 1;
	en_block[x + 9][y + 9] = r;
}

inline void get_Move( gameunit :: Unit now , int lim )
{
	accessable.clear();
	memset( vis , 0 , sizeof( vis ) );
	search( get < 0 > ( now.pos ) , get < 1 > ( now.pos ) , lim );
}

double result;

vector < gameunit :: Unit > move_order;

vector < gameunit :: Unit > my_alive_army , en_alive_army;
vector < gameunit :: Unit > my_alive_sword , my_alive_archer , my_alive_priest;

int EFA[1000]; //ÿ�����������ܵ��Ĵ�� 

inline int get_maxatk( gameunit :: Unit a ) //�Է���Ŀ���»غ������ܵĹ���������ʱûдʥ��֮ҫ 
{
	int v = a.atk;
	for( auto & i : en_army )
		if( i.type == "Priest" && i.hp > 0 && cube_distance( i.pos , a.pos ) > ( i.level == 1 ? 2 : 3 ) )
			if( cube_distance( i.pos , a.pos ) <= 5 + ( i.level == 1 ? 2 : 3 ) )
				v++;
	int cnt = 0;
	for( auto & i : enemy_barrack )
	{
		if( cnt == 3 ) break;
		if( cube_distance( i , a.pos ) <= 5 + 3 )
			cnt++;
	}
	if( cnt > ennewpr ) cnt = ennewpr;
	return v + ennewpr;
}

inline bool isCamp( Pos pos )
{
	for( int i = 0 ; i < 4 ; i++ )
		if( center[i] == pos )
			return 1;
	return 0;
}

//���������������������������������
inline double calc_enattack_value( gameunit :: Unit & a , int x ) //�������˵����� 
{
	//ʥ��������д 
	if( a.holy_shield )
	{
		int v = 0;
		for( auto & i : my_army )
			if( i.can_move && canAttack( i , a ) )
				v += i.atk;
		if( v >= a.hp )
			return holy;
		else
			return -5;
	}
	if( x >= a.hp )
		return enkill[ trans( a.type ) ][ a.level - 1 ] + extra_value[ a.id ] + ( isCamp( a.pos ) ? attack_Camp : 0 );
	double ex = 0;
	if( extra_value[ a.id ] )
		if( extra_value[ a.id ] < 200 )
			ex = arpos[7];
		else
			ex = arpos[8];
	return x * enhurt[ trans( a.type ) ][ a.level - 1 ] + x * ex;
}

inline double calc_myattack_value( gameunit :: Unit & a , int x ) //������������ 
{
	if( a.holy_shield ) return 0;
	if( x >= a.hp )
		return mykill[ trans( a.type ) ][ a.level - 1 ];
	x -= cover( a );
	return x * myhurt[ trans( a.type ) ][ a.level - 1 ];
}

inline double receive_attack( gameunit :: Unit a , int v1 , int v2 )
{
	if( a.type == "Archer" )
	{
		if( v1 >= a.hp )
			return my_arpos[ a.level - 1 ][0];
		if( v1 + v2 >= a.hp )
			return my_arpos[ a.level - 1 ][1] + v1 * my_arpos[ a.level - 1 ][2] + ( a.hp - v1 ) * my_arpos[ a.level - 1 ][3];
		return v1 * my_arpos[ a.level - 1 ][2] + v2 * my_arpos[ a.level - 1 ][3];
	}
	else if( a.type == "Priest" )
	{
		if( v1 + v2 >= std :: min( a.hp + 1 , a.max_hp ) )
			return my_prpos[ a.level - 1 ][0];
		return ( v1 + v2 ) * my_prpos[ a.level - 1 ][1];
	}
	else
	{
		if( v1 >= a.hp )
			return my_swpos[ a.level - 1 ][0];
		if( v1 + v2 >= a.hp )
			return my_swpos[ a.level - 1 ][1] + v1 * my_swpos[ a.level - 1 ][2] + ( a.hp - v1 ) * my_swpos[ a.level - 1 ][3];
		return v1 * my_swpos[ a.level - 1 ][2] + v2 * my_swpos[ a.level - 1 ][3];
	}
} 

inline bool onBridge( Pos pos ) //���ŵ��ж� 
{
	bool flag = 0;
	for( auto & i : bridge )
		if( i == pos )
		{
			flag = 1;
			break;
		}
	if( !flag ) return 0;
	int d = cube_distance( miracle_pos , pos );
	for( auto & i : my_army ) //��������ϣ�������һ���˾���������<=1����������˾�����ر������˾�����ؽ� 
		if( i.hp > 0 && i.can_move && cube_distance( pos , i.pos ) <= 1 && cube_distance( miracle_pos , i.pos ) < d )
			return 1;
	return 0; 
}

inline bool isMyCenter( Pos pos ) //�ǲ����ҵ�С���� 
{
	for( auto & i : my_center )
		if( i == pos )
			return 1;
	return 0;
}

inline bool isEnCenter( Pos pos ) //�ǲ��ǵ��˵�С���� 
{
	for( auto & i : en_center )
		if( i == pos )
			return 1;
	return 0;
}

inline bool capture( Pos pos )
{
	for( auto & i : my_capture )
		if( cube_distance( i , pos ) <= 1 )
			return 1;
	return 0;
}

inline bool can_threat_barrack( gameunit :: Unit & a )
{
	for( auto & i : threat_barrack_unit )
		if( i.id == a.id )
			return 1;
	return 0;
}

inline bool can_threat_base( gameunit :: Unit & a )
{
	for( auto & i : threat_base_unit )
		if( i.id == a.id )
			return 1;
	return 0;
}

inline bool important( Pos pos ) //�Ƿ�����Ҫλ��
{
	if( cube_distance( pos , make_tuple( 6 , 6 , -12 ) ) <= 1 || cube_distance( pos , make_tuple( -6 , -6 , 12 ) ) <= 1 )
		return 0;
	return 1;
}

double DBR = 10;

int bat_reach[3];

int defend_bat[1000];

inline void calc_bat()
{
	memset( bat_reach , 0 , sizeof( bat_reach ) );
	for( auto & i : en_army )
		if( i.type == "BlackBat" )
		{
			int now = 0;
			for( auto & j : basesummon )
			{
				if( cube_distance( i.pos , j ) <= i.max_move ) //������Ե�����
				{
					bat_reach[ now ]++;
					if( i.max_hp > 2 ) bat_reach[ now ] += 2; //ʥ������ 
				}
				now++;
			}
		}
}

inline double Pos_value( gameunit :: Unit a , Pos pos ) //a�ߵ�pos������ 
{
	int v1 = 0 , v2 = 0 , min_enatk = 100 , bridge = 0; //���ι����ͶԴ򹥻� 
	int mindist = 114514;
	if( onBridge( a.pos ) ) //a�����ϲ����� 
		bridge--;
	int bridge_block = 0;
	a.atk -= cover( a );
	Pos rec = a.pos;
	a.pos = pos;
	a.atk += cover( a );
	if( onBridge( a.pos ) ) //a�����ϲ����� 
		bridge++ , bridge_block = 1;
	double ex = 0;
	int reach = 0;
	for( auto & i : en_army ) //�ܵ�v1�İ����˺���v2�ĶԴ��˺� 
		if( i.hp > 0 ) //����Է��ܴ��һ��صĻ���Ϊ��ֱ�Ӵ���� 
		{
			if( bridge_block && onBridge( i.pos ) && cube_distance( i.pos , a.pos ) <= 3 ) //��ס������� 
				ex += bridgeBlock;
			if( !canAttackMyBase( i ) )
				if( canAttack( i , a ) )
				{
					bool flag = 1;
					if( i.type == "BlackBat" )
					{
						for( auto & j : my_army ) //�ҵĹ����ֿ��Դ� 
							if( cube_distance( i.pos , j.pos ) >= 3 && cube_distance( i.pos , j.pos ) <= 4 )
								flag = 0;
					}
					int t = get_maxatk( i );
					if( canAttack( a , i ) && a.atk >= i.hp ) //������ɱ�� 
						v2 += t;
					else //������ 
					{
						if( lock[ i.id ] && a.type == "Swordsman" ) //lock�Ĺ�������Ϊ����ɱ�˽�ʿ 
							;
						else
							v1 += t;
					}
					min_enatk = std :: min( min_enatk , t );
				}
			int d = cube_distance( i.pos , pos );
			if( d <= i.max_move ) //д�˸���ֵļ�Ȩ 
				if( i.type != "BlackBat" )
					reach += i.max_move - d + 1; //�м����˵ľ������ֱ�ӵ����� 
			if( i.type != "BlackBat" ) 
				mindist = std :: min( mindist , d );
		}
	double ans = a.type == "Swordsman" ? swpos[5] / ( mindist + eps ) : 0;
	if( a.id > 0 && a.type == "Archer" && defend_bat[ a.id ] && a.hp > 0 )
	{
		if( defend_bat[ a.id ] == 1 )
		{
			if( v1 + v2 < a.hp ) //��ס�ҷ������������ 
			{
				int now = 0;
				for( auto & i : basesummon ) //�����ܵ��Ļ���λ�� 
				{
					if( bat_reach[ now ] && cube_distance( pos , i ) >= 3 && cube_distance( pos , i ) <= 4 )
					{
						bat_reach[ now ]--;
						ex += 100;
					}
					now++;
				}
			}
		}
		else
		{
			int v = cube_distance( pos , miracle_pos ) - cube_distance( rec , miracle_pos );
			ex += DBR * v;
		}
	}
	
	//��в���� 
	if( v1 < a.hp )
		for( auto & i : en_army )
			if( i.hp > 0 )
				if( extra_value[ i.id ] )
				{
					int d = cube_distance( i.pos , a.pos );
					if( a.type == "Swordsman" ) //��һ����вĿ��
						if( d <= 9 )
							if( can_threat_barrack( i ) )
							{
								if( d <= 2 && d >= 1 )
									if( i.type == "Priest" ) 
										ex += Dbarrack_sword[0][d - 1];
									else if( i.type == "VolcanoDragon" || i.type == "FrostDragon" )
										ex += Dbarrack_sword[1][d - 1];
									else if( i.type == "Swordsman" )
										ex += Dbarrack_sword[2][d - 1];
									else
										ex += Dbarrack_sword[3][d - 1];
							}
							else if( can_threat_base( i ) )
								ex += Dbase_sword[ trans( i.type ) ][d];
							else
								ex += DA_sword[ d == 1 ? 0 : 1 ];
					if( a.type == "Archer" )
						if( can_threat_barrack( i ) )
							if( 4 <= d <= 7 )
								ex += Dbarrack_archer;
							else;
						else if( can_threat_base( i ) )
							if( 6 <= d <= 7 )
								ex += Dbase_archer;
							else;
						else
							if( 3 <= d <= 4 )
								ex += DA_archer;
							else;
				}
	if( player_ai.players[ en_camp ].mana >= 7 && player_ai.players[ en_camp ].artifact[0].state != "In Use" && player_ai.players[ en_camp ].artifact[0].cool_down_time <= 1 && player_ai.players[ en_camp ].artifact[0].name == "InfernoFlame" )
		if( isCamp( pos ) && cube_distance( pos , miracle_pos ) == 12 ) //�Է�Զ�����������
			reach += 2;
	if( reach && isCamp( pos ) && v1 < a.hp && a.type == "Swordsman" ) //�������������ڳ���������� 
		ans += reach * stayCamp;
	if( isCamp( pos ) && !isMyCenter( pos ) && !isEnCenter( pos ) )
		ans += stealCamp; 
	if( v1 < a.hp ) ans += ex; //�赲��в 
	//��������˾��룬������������ǵ��˱�������㣬���Ƕ��ѵ�Ч�� 
	
	mindist = 114514;
	for( auto & i : en_center )
	{
		if( cube_distance( i , a.pos ) < mindist )
			mindist = cube_distance( i , a.pos );
	}
	if( a.type == "Priest" && a.level == 1 ) ans += 99 / ( mindist + eps ); //�����͵��Ǹ���ʦ 
	ans += barrack_value[ trans( a.type ) ] / ( mindist + eps );
	ans += base_value[ trans( a.type ) ] / ( cube_distance( enemy_pos , a.pos ) + eps );
	if( a.type == "Archer" )
	{
		if( v1 < a.hp || ( a.holy_shield && v1 + v2 - min_enatk < a.hp ) )
		{
			for( auto & j : enemy_barrack ) //���ǵ��˳����� 
				if( !capture( j ) ) //û�б�ռ�� 
					if( cube_distance( a.pos , j ) >= 3 && cube_distance( a.pos , j ) <= 4 )
						ans += arpos[3] * ( important( j ) ? 1 : 0.5 );
			for( auto & j : en_center ) //���ǵ���С����
				if( cube_distance( a.pos , j ) >= 3 && cube_distance( a.pos , j ) <= 4 )
					if( capture( j ) ) //��ռ�� 
						ans += arpos[10] * ( important( j ) ? 1 : 0.5 );
					else
						ans += arpos[9] * ( important( j ) ? 1 : 0.5 ); 
			//for( auto & j : my_center ) //�����Լ�С����
			//	if( cube_distance( a.pos , j ) >= 3 && cube_distance( a.pos , j ) <= 4 )
					
			for( auto & j : en_army )
				if( j.hp > 0 )
					if( cube_distance( a.pos , j.pos ) >= 3 && cube_distance( a.pos , j.pos ) <= 4 ) //���ǵ��� 
					{
						ans += arpos[2];
						if( j.type == "Swordsman" || j.type == "BlackBat" || j.type == "VolcanoDragon" || j.type == "FrostDragon" )
							for( auto & i : my_army )
								if( i.hp > 0 ) //���ܶ����Ѿ�
									if( canAttack( i , j ) && !canAttack( j , i ) && i.atk >= j.hp ) //���ܷ���
									{
										ans += arpos[1];
										if( j.type == "BlackBat" )
											ans += arpos[1] * 2;
									}
					}
			if( v1 + v2 < a.hp || ( a.holy_shield && v1 + v2 - min_enatk < a.hp ) )
				if( cube_distance( a.pos , enemy_pos ) >= 3 && cube_distance( a.pos , enemy_pos ) <= 4 ) //���ǵ��˻��� 
					ans += arpos[4];
		}
		ans += bridge * arpos[6];
	}
	else if( a.type == "Priest" )
	{
		for( auto & j : my_army )
			if( j.hp > 0 && cube_distance( a.pos , j.pos ) <= ( a.level == 1 ? 2 : 3 ) ) //���Ը��ǵ��Լ��� 
			{
				if( j.can_move && canAttackEnemyBase( j ) ) //��һ�����Թ������ص��Լ��˼ӹ����� 
					if( cube_distance( rec , j.pos ) > ( a.level == 1 ? 2 : 3 ) ) //ԭ�����ǲ��� 
						ans += 200;
				if( j.hp + cover( j ) < j.max_hp ) //���Լ��˼�Ѫ 
					ans += prpos[1];
				for( auto & k : en_army ) //���Լ��˼ӹ��� 
					if( k.hp > 0 )
						if( canAttack( j , k ) && j.atk < k.hp )
						{
							if( j.can_move ) ans += prpos[0]; //����һ����غ��ܶ��ļӳ�
							else if( v1 + v2 < std :: min( a.max_hp , a.hp + cover( a ) ) ) ans += prpos[0]; //��ȥ�����»غϱ����� 
						}
				ans += prpos[2]; //�����Լ��� 
			}
		ans += bridge * prpos[3];
	}
	else
	{
		if( v1 < a.hp || ( a.holy_shield && v1 + v2 - min_enatk < a.hp ) )
		{
			for( auto & j : enemy_barrack ) //���ǵ��˳����� 
				if( !capture( j ) && cube_distance( a.pos , j ) <= 1 ) //���Ǹմ������ĳ����� 
					ans += swpos[3] * ( important( j ) ? 1 : 0.5 );
			for( auto & j : en_center ) //���ǵ��˸ձ�ռ���С����
				if( capture( j ) && cube_distance( a.pos , j ) <= 1 )
					ans += swpos[9];
			if( v1 + v2 < a.hp || ( a.holy_shield && v1 + v2 - min_enatk < a.hp ) )
				if( cube_distance( enemy_pos , a.pos ) <= 1 ) //���ǵ��˻���
					ans += swpos[4];
			for( auto & j : en_army )
				if( j.hp > 0 && cube_distance( a.pos , j.pos ) == 1 ) //��ס���˲��� 
				{
					if( j.type == "Archer" )
					{
						ans += swpos[0];
						if( v1 + v2 < a.hp && a.atk >= j.hp )
							ans += swpos[0]; //���ᱻ�������Ҽ�ס�˹�����
					}
					else if( j.type == "VolcanoDragon" || j.type == "FrostDragon" )
						ans += swpos[1];
					else if( j.type == "Swordsman" || j.type == "Priest" || j.type == "Inferno" )
						ans += swpos[2];
					else //���� 
						; 
				}
		}
		ans += bridge * swpos[6];
	}
	return ans + receive_attack( a , v1 , v2 );
}

inline void AI :: update_ans( double predict ) //���������´� 
{
	my_alive_army.clear();
	my_alive_sword.clear();
	my_alive_archer.clear();
	my_alive_priest.clear();
	en_alive_army.clear();
	for( auto & i : my_army )
		if( i.hp > 0 )
		{
			my_alive_army.push_back( i );
			if( i.type == "Swordsman" )
				my_alive_sword.push_back( i );
			else if( i.type == "Archer" )
				my_alive_sword.push_back( i );
			else
				my_alive_priest.push_back( i );
		}
	
	for( auto & i : en_army )
		if( i.hp > 0 )
			en_alive_army.push_back( i );
	
	double ans = 0;
	/*for( auto & i : en_army ) //ɱ������в���Լ�ɱ�˶Է�����Ч��
	{
		if( i.hp <= 0 )
			if( extra_value[ i.id ] )
				ans += extra_value[ i.id ];
		if( i.hp != i.max_hp )
		{
			int v = i.hp;
			i.hp = i.max_hp; 
			ans += calc_enattack_value( i , EFA[ i.id ] );
			i.hp = v;
		}
	}
	
	for( auto & i : my_army ) //���Լ���ɱ��Ч�� 
	{
		if( i.hp != i.max_hp )
		{
			int v = i.hp;
			i.hp = i.max_hp;
			ans += calc_myattack_value( i , i.max_hp - i.hp );
			i.hp = v;
		}
		if( i.hp > 0 ) ans += Pos_value( i , i.pos ); //���ŵĻ�����λ�õļ�ֵ 
	}*/
	
	for( auto & i : en_alive_army ) //���Լ����ش���Ĺ��� 
		if( cube_distance( i.pos , miracle_pos ) >= i.atk_range[0] && cube_distance( i.pos , miracle_pos ) <= i.atk_range[1] ) //�ܱ����ռ���
			ans += -200 * i.atk;
	
	if( shield_target[1].id ) //������˻��ص�Ŀ���ʥ�� 
		if( players[ my_camp ].artifact[0].state == "Ready" && players[ my_camp ].mana >= 6 )
			ans += 200 * shield_target[1].atk;
	
	//�����Ȳ����Ǽ��ŵĸ��Ӳ��� 
	for( auto & i : my_alive_archer ) //ö���ҵĹ����� 
	{
		if( i.max_hp != 7 )
		{
			int flag = 0;
			for( auto & j : en_alive_army ) //ö�ٵ������������� 
				if( j.type == "Archer" && canAttack( j , i ) ) //���Դ���
				{
					flag = std :: max( j.level , flag );
					break;
				}
			if( !flag ) continue;
			int v0 = 0 , v1 = 0;
			for( auto & j : my_alive_priest ) //ö���ҵ���ʦ 
			{
				bool flag = 0;
				if( cube_distance( i.pos , j.pos ) <= ( j.level == 1 ? 2 : 3 ) ) //ö�ٵ��˵ı� 
				{
					for( auto & k : en_alive_army )
						if( canAttack( k , j ) ) //�����ʦ���Ա��˴� 
							if( k.type != "Priest" )
								flag = 1;
				}
				if( flag ) v0++;
				else v1++;
			}
			if( v1 + v0 / 2 + i.level >= flag + 1 ) continue;
			if( flag + 1 - ( v1 + v0 / 2 + i.level ) <= 0.5 )
				ans += my_arpos[ i.level - 1 ][5];
			else
				ans += my_arpos[ i.level - 1 ][4];
		}
	}
	for( auto & i : my_army ) //���ˣ����˶��Լ��ĸ����� 
		if( i.hp <= 0 )
			ans += mykill[ trans( i.type ) ][ i.level - 1 ];
		else
		{
			int cover = 0;
			for( auto & j : my_army ) //������ʦ���� 
				if( j.hp > 0 && j.type == "Priest" )
					cover++;
			if( cover + i.hp < i.max_hp )
				ans += myhurt[ trans( i.type ) ][ i.level - 1 ] * ( i.max_hp - cover - i.hp );
		}

	for( auto & i : my_army ) //ɱ���˶��Լ��������� 
		if( i.hp <= 0 )
			ans += enkill[ trans( i.type ) ][ i.level - 1 ];
		else
			ans += myhurt[ trans( i.type ) ][ i.level - 1 ] * ( i.max_hp - i.hp );
	
	//��ûд��ס���˵Ĺ��ۣ�Ŀǰֻ�ǿ����ʲ�ͬ�İ��� 
	/*for( auto & i : my_swordsman )
		for( auto & j : en_army )
			if( cube_distance( i.pos , j.pos ) == 1 ) //���� 
			{
				if( j.type == "Archer" ) //���Ϲ�����
				{
					ans +=  */
	
	ans += predict;
					
	
	if( ans > result )
	{
		move_order.clear();
		result = ans;
		for( auto & i : my_army )
		{
			move_order.push_back( i );
			recorded_action[ i.id ] = action[ i.id ];
		}
		for( int i = 1 ; i >= 0 ; i-- )
			if( shield_target[i].id )
				recorded_shield = shield_target[i];
	}
}

int temp;

inline double Att_value( gameunit :: Unit & a , gameunit :: Unit & b ) //a��b������ 
{
	double ans = 0;
	temp = 0;
	ans += calc_enattack_value( b , a.atk );
	if( canAttack( b , a ) )
	{
		ans += calc_myattack_value( a , b.atk );
		temp = b.atk;
	}
	return ans;
}

inline void enforce_Attack( gameunit :: Unit & a , int x )
{
	if( a.holy_shield ) a.holy_shield = 0;
	else a.hp -= x;
}

inline void enforce( int id , activity a )
{
	int now;
	for( now = 0 ; now < my_army.size() ; now++ )
		if( my_army[ now ].id == id )
			break;
	if( my_army[ now ].id == shield_target[0].id ) //�����ܴ���صļ�ʥ�� 
	{
		my_army[ now ].holy_shield = 1;
		my_army[ now ].hp += 3;
		my_army[ now ].max_hp += 3;
	}
	//my_army[ now ].can_move = 0;
	if( a.att == -1 ) //��· 
	{
		my_army[ now ].pos = a.pos;
		for( auto & j : en_center ) //ռ����˳����� 
			if( a.pos == j )
			{
				my_capture.push_back( j );
				break;
			}
	}
	else
	{
		//std :: cerr << "Enf4: " << std :: endl;
		if( a.att == en_camp )
			return; //����˻��� 
		int en;
		for( en = 0 ; en < en_army.size() ; en++ )
			if( en_army[ en ].id == a.att )
				break;
		if( canAttack( en_army[ en ] , my_army[ now ] ) )
			enforce_Attack( my_army[ now ] , en_army[ en ].atk );
		enforce_Attack( en_army[ en ] , my_army[ now ].atk );
		if( en_army[ en ].hp <= 0 && en_army[ en ].type == "Priest" ) //ɱ��������ʦ 
		{
			int d = en_army[ en ].level == 1 ? 2 : 3;
			for( auto & i : en_army )
				if( i.id != en_army[ en ].id && cube_distance( en_army[ en ].pos, i.pos ) <= d )
					i.atk--;
		}
	}
	for( auto & i : my_army )
		if( i.type == "Archer" ) i.atk = i.level + cover( i );
		else if( i.type == "Swordsman" ) i.atk = i.level * 2 + cover( i );
		else i.atk = cover( i ) - 1;
	if( my_army[ now ].type == "Swordsman" && my_army[ now ].hp > 0 )
	{
		int v = 0;
		for( auto & i : en_army ) //�ܵ��˺�
			if( i.hp > 0 ) //����Է��ܴ��һ��صĻ���Ϊ��ֱ�Ӵ���� 
				if( !canAttackMyBase( i ) )
					if( canAttack( i , my_army[ now ] ) )
						v += get_maxatk( i );
		if( v < std :: min( cover( my_army[ now ] ) + my_army[ now ].hp , my_army[ now ].max_hp ) )
			for( auto & i : en_army ) //��ס������ 
				if( i.type == "Archer" && cube_distance( my_army[ now ].pos , i.pos ) <= 1 && my_army[ now ].atk >= i.hp && i.max_hp <= 4 )
					lock[ i.id ] = 1;
	}
}

int re[3];

void AI :: move_army()
{
	vector < gameunit :: Unit > My_army , En_army;
	My_army = my_army , En_army = en_army;
	int num = 5;
	double a = clock();
	if( BT1 > 3 ) BT1 = 3;
	for( int i = 0 ; i < 3 ; i++ )
		re[i] = bat_reach[i];
	while( num-- )
	{
		memset( lock , 0 , sizeof( lock ) );
		my_army = My_army , en_army = En_army;
		my_capture.clear();
		random_shuffle( my_army.begin() , my_army.end() );
		memset( shield_target , 0 , sizeof( shield_target ) );
		int now = 0;
		double predict = 0;
		result = -1000000000;
		vector < int > archer;
		archer.clear();
		for( auto & i : my_army )
			action[ i.id ] = activity( -1 );
		for( int i = 0 ; i < 3 ; i++ )
			bat_reach[i] = re[i];
		if( have_bat ) //������
		{
			memset( defend_bat , 0 , sizeof( defend_bat ) );
			if( BT1 <= 1 )
			{
				for( auto & i : my_army )
					if( i.type == "Archer" )
						if( cube_distance( i.pos , miracle_pos ) <= 6 )
							defend_bat[ i.id ] = 1;
			}
			else
			{
				for( auto & i : my_army )
					if( i.type == "Archer" )
						if( cube_distance( i.pos , miracle_pos ) <= 6 )
							defend_bat[ i.id ] = 1;
						else
							defend_bat[ i.id ] = 2;
			}
		}
		for( auto & i : my_army )
			if( i.can_move && i.hp > 0 )
			{
				memset( en_block , 0 , sizeof( en_block ) );
				memset( exist , 0 , sizeof( exist ) );
				get_Remaining_En();
				get_Remaining_My();
				get_Move( i , i.max_move );
				double ans = -1000000000; //���ϴ��Ų��������� 
				double atkvalue = -1000000000;

				for( auto & j : en_army ) //ö�ٿ��Դ�ĵ��� 
					if( j.hp > 0 )
					{
						if( canAttack( i , j ) )
						{
							double v = Att_value( i , j );
							if( i.hp - temp > 0 ) //������֮����һ��pos_value 
							{
								i.hp -= temp;
								j.hp -= i.atk;
								v += Pos_value( i , i.pos );
								i.hp += temp;
								j.hp += i.atk;
							}
							if( v > ans )
								ans = v , action[ i.id ] = activity( j.id );
						}
					}
				
				if( canAttackEnemyBase( i ) ) //����˵Ļ��� 
				{
					double v = AttackEnemyBaseValue( i ) + Pos_value( i , i.pos );
					if( v > ans )
						ans = v , action[ i.id ] = activity( en_camp );
				}
				
				for( auto & j : accessable ) //ö�ٿ����ߵĵط� 
				{
					double v = Pos_value( i , j );
					if( v > ans ) //move_ans���ߵ��������� 
						ans = v , action[ i.id ] = activity( j );
				}

				if( players[ my_camp ].artifact[0].state == "Ready" && players[ my_camp ].mana >= 6 && 
				threat.size() == 0 && i.type == "Archer" ) //û����в��������ʥ�� 
				{
					if( shield_target[0].id == 0 && shield_target[1].id == 0 )
					{
						int num = 0 , v = 0 , v0 = 0;
						for( auto & j : en_army ) //ö�ٿ��Դ�ĵ��� 
							if( j.hp > 0 )
							{
								if( canAttack( j , i ) )
									if( j.type == "Archer" ) //�ͼ��������ֱȻ� 
										num++ , v0 += j.atk;
									else
										v += j.atk;
							}
						if( num && std :: min( i.hp - v0 + cover( i ) , i.max_hp + 3 ) < v ) //�»غ�Ҳ������
							use_proposal( i , 0 );
					}
				}
				
				if( players[ my_camp ].artifact[0].state == "Ready" && players[ my_camp ].mana >= 6 && 
				canAttackEnemyBase( i ) && i.type != "Priest" ) //�����Դ���صļ�ʥ�� 
				{
					if( shield_target[0].id == 0 )
					{
						int v = 0 , minatk = 114514; 
						for( auto & j : en_army ) //ʥ�ܶ��� 
							if( j.hp > 0 )
								if( canAttack( j , i ) )
									v += j.atk , minatk = std :: min( minatk , j.atk );
						if( v - minatk <= std :: min( i.max_hp , i.hp + cover( i ) ) + 3 ) //���ᱻ����
							use_proposal( i , 1 );
					} 
				}
				
				enforce( i.id , action[ i.id ] );
				predict += ans;
			}
		update_ans( predict );
		if( num == 0 )
		{
			double b = clock();
			if( b - a <= 0.3 * CLOCKS_PER_SEC )
				num = 5;
		}
	}
	
	num = 5;
	a = clock();
	if( BT1 > 3 ) BT1 = 3;
	for( int i = 0 ; i < 3 ; i++ )
		re[i] = bat_reach[i];
	while( num-- ) //������� 
	{
		memset( lock , 0 , sizeof( lock ) );
		my_army = My_army , en_army = En_army;
		my_capture.clear();
		random_shuffle( my_army.begin() , my_army.end() );
		memset( shield_target , 0 , sizeof( shield_target ) );
		int now = 0;
		double predict = 0;
		for( auto & i : my_army )
			action[ i.id ] = activity( -1 );
		for( int i = 0 ; i < 3 ; i++ )
			bat_reach[i] = re[i];
		if( have_bat ) //������
		{
			memset( defend_bat , 0 , sizeof( defend_bat ) );
			if( BT1 <= 1 )
			{
				for( auto & i : my_army )
					if( i.type == "Archer" )
						if( cube_distance( i.pos , miracle_pos ) <= 6 )
							defend_bat[ i.id ] = 1;
			}
			else
			{
				for( auto & i : my_army )
					if( i.type == "Archer" )
						if( cube_distance( i.pos , miracle_pos ) <= 6 )
							defend_bat[ i.id ] = 1;
						else
							defend_bat[ i.id ] = 2;
			}
		}
		
		for( auto & i : my_army )
			if( i.can_move && i.hp > 0 )
			{
				memset( en_block , 0 , sizeof( en_block ) );
				memset( exist , 0 , sizeof( exist ) );
				get_Remaining_En();
				get_Remaining_My();
				get_Move( i , i.max_move );
				double ans = -1000000000; //���ϴ��Ų��������� 
				
				if( canAttackEnemyBase( i ) ) //����˵Ļ��� 
				{
					double v = AttackEnemyBaseValue( i ) + Pos_value( i , i.pos );
					if( v > ans )
						ans = v , action[ i.id ] = activity( en_camp );
				}
				else //������ܴ��
				{
					vector < gameunit :: Unit > canAtk; 
	
					for( auto & j : en_army ) //ö�ٿ��Դ�ĵ��� 
						if( j.hp > 0 )
							if( canAttack( i , j ) )
								canAtk.push_back( j );
					if( canAtk.size() ) //������� 
					{
						int p = rand() % canAtk.size();
						for( auto & j : en_army )
						{
							if( j.id == canAtk[p].id )
							{
								double v = Att_value( i , j );
								if( i.hp - temp > 0 ) //������֮����һ��pos_value 
								{
									i.hp -= temp;
									j.hp -= i.atk;
									v += Pos_value( i , i.pos );
									i.hp += temp;
									j.hp += i.atk;
								}
								ans = v , action[ i.id ] = activity( j.id );
								break;
							}
						}
					}
				
					if( ans < -10000000 || rand() % 10 < 5 ) //ǰ��û���ж�������� 
						for( auto & j : accessable ) //ö�ٿ����ߵĵط� 
						{
							double v = Pos_value( i , j );
							if( v > ans ) //move_ans���ߵ��������� 
								ans = v , action[ i.id ] = activity( j );
						}
				}

				if( players[ my_camp ].artifact[0].state == "Ready" && players[ my_camp ].mana >= 6 && 
				threat.size() == 0 && i.type == "Archer" ) //û����в��������ʥ�� 
				{
					if( shield_target[0].id == 0 && shield_target[1].id == 0 )
					{
						int num = 0 , v = 0 , v0 = 0;
						for( auto & j : en_army ) //ö�ٿ��Դ�ĵ��� 
							if( j.hp > 0 )
							{
								if( canAttack( j , i ) )
									if( j.type == "Archer" ) //�ͼ��������ֱȻ� 
										num++ , v0 += j.atk;
									else
										v += j.atk;
							}
						if( num && std :: min( i.hp - v0 + cover( i ) , i.max_hp + 3 ) < v ) //�»غ�Ҳ������
							use_proposal( i , 0 );
					}
				}
				
				if( players[ my_camp ].artifact[0].state == "Ready" && players[ my_camp ].mana >= 6 && 
				canAttackEnemyBase( i ) && i.type != "Priest" ) //�����Դ���صļ�ʥ�� 
				{
					if( shield_target[0].id == 0 )
					{
						int v = 0 , minatk = 114514; 
						for( auto & j : en_army ) //ʥ�ܶ��� 
							if( j.hp > 0 )
								if( canAttack( j , i ) )
									v += j.atk , minatk = std :: min( minatk , j.atk );
						if( v - minatk <= std :: min( i.max_hp , i.hp + cover( i ) ) + 3 ) //���ᱻ����
							use_proposal( i , 1 );
					}
				}
				
				enforce( i.id , action[ i.id ] );
				predict += ans;
			}
		update_ans( predict );
		if( num == 0 )
		{
			double b = clock();
			if( b - a <= 2.4 * CLOCKS_PER_SEC )
				num = 5;
		}
	}
	
	if( recorded_shield.id )
		if( players[ my_camp ].mana >= 6 && players[ my_camp ].artifact[0].state == "Ready" )
			use( players[ my_camp ].artifact[0].id , recorded_shield.id );
	
	memset( EFA , 0 , sizeof( EFA ) );
	//int cnt = 0;
	for( auto & i : move_order )
		if( recorded_action[ i.id ].att != -1 )
		{
			EFA[ recorded_action[ i.id ].att ] += getUnitByPos( i.pos , false ).atk;
			attack( i.id , recorded_action[ i.id ].att );
		}
		else if( get < 0 > ( recorded_action[ i.id ].pos ) != 114 )
		{
			/*for( auto & j : My_army )
				if( j.id == i.id )
				{
					if( j.pos == recorded_action[ i.id ].pos )
						cnt++;
					break;
				}*/
			move( i.id , recorded_action[ i.id ].pos );
		}
	//std :: cerr << cnt << std :: endl;
}

int mindist[20] , maxattack_rec[20];

inline void AI :: shield_pre()
{
	if( players[ my_camp ].mana >= 6 && players[ my_camp ].artifact[0].state == "Ready" )
	{
		vector < gameunit :: Unit > pre1 , pre2;
		for( auto & i : my_army )
			if( i.can_move && i.hp > 0 && i.type != "Priest" )
			{
				memset( en_block , 0 , sizeof( en_block ) );
				memset( exist , 0 , sizeof( exist ) );
				get_Remaining_My();
				get_Move( i , i.max_move );
				
				if( canAttackEnemyBase( i ) ) //����˵Ļ��� 
					pre1.push_back( i );
				
				for( auto & j : accessable ) //ö�ٿ����ߵĵط� 
				{
					i.pos = j;
					if( canAttackEnemyBase( i ) ) //����˵Ļ��� 
					{
						vector < int > v;
						for( auto & k : en_army )
							if( k.hp > 0 )
								if( canAttack( k , i ) )
									v.push_back( get_maxatk( k ) );
						std :: sort( v.begin() , v.end() );
						int temp = 0;
						for( int i = 1 ; i < v.size() ; i++ )
							temp += v[i];
						if( i.hp + 3 > temp )
							pre2.push_back( i );
					}
				}
			}
		gameunit :: Unit a;
		a.id = -1 , a.atk = 0;
		if( pre1.size() )
		{
			for( auto & i : pre1 )
				if( i.atk > a.atk )
					a = i;
			if( a.id != -1 )
				use( players[ my_camp ].artifact[0].id , a.id );
		}
		else if( pre2.size() )
		{
			for( auto & i : pre2 )
				if( i.atk > a.atk )
					a = i;
			if( a.id != -1 )
				use( players[ my_camp ].artifact[0].id , a.id );
		}
	}
}

inline gameunit :: Unit make_sword( Pos pos , int level )
{
	gameunit :: Unit i;
	i.id = 0;
	i.type = "Swordsman";
	i.atk = level * 2;
	for( auto & i : my_army )
		if( i.hp > 0 && i.type == "Priest" && cube_distance( pos , i.pos ) <= ( i.level == 1 ? 2 : 3 ) )
			i.atk++;
	if( level == 1 )
		i.max_hp = i.hp = 2;
	else if( level == 2 )
		i.max_hp = i.hp = 4;
	else
		i.max_hp = i.hp = 6;
	i.atk_range.clear();
	i.atk_range.push_back( 0 );
	i.atk_range.push_back( 1 );
	i.max_move = 3;
	i.pos = pos;
	i.level = level;
	i.flying = 0;
	i.atk_flying = 0;
	i.agility = 0;
	i.holy_shield = 0;
	i.can_atk = 0;
	i.can_move = 0;
	return i;
}

inline gameunit :: Unit make_archer( Pos pos , int level )
{
	gameunit :: Unit i;
	i.id = 0;
	i.type = "Archer";
	i.atk = level;
	for( auto & i : my_army )
		if( i.hp > 0 && i.type == "Priest" && cube_distance( pos , i.pos ) <= ( i.level == 1 ? 2 : 3 ) )
			i.atk++;
	if( level == 1 )
		i.max_hp = i.hp = 2;
	else if( level == 2 )
		i.max_hp = i.hp = 3;
	else
		i.max_hp = i.hp = 4;
	i.atk_range.clear();
	i.atk_range.push_back( 3 );
	i.atk_range.push_back( 4 );
	i.max_move = 3;
	i.pos = pos;
	i.level = level;
	i.flying = 0;
	i.atk_flying = 1;
	i.agility = 0;
	i.holy_shield = 0;
	i.can_atk = 0;
	i.can_move = 0;
	return i;
}

inline gameunit :: Unit make_priest( Pos pos , int level )
{
	gameunit :: Unit i;
	i.id = 0;
	i.type = "Priest";
	i.atk = 0;
	for( auto & i : my_army )
		if( i.hp > 0 && i.type == "Priest" && cube_distance( pos , i.pos ) <= ( i.level == 1 ? 2 : 3 ) )
			i.atk++;
	if( level == 1 )
		i.max_hp = i.hp = 2;
	else if( level == 2 )
		i.max_hp = i.hp = 4;
	else
		i.max_hp = i.hp = 6;
	i.atk_range.clear();
	i.atk_range.push_back( 0 );
	if( i.hp == 7 )
		i.atk_range.push_back( 2 );
	else
		i.atk_range.push_back( 1 );
	i.max_move = 5;
	i.pos = pos;
	i.level = level;
	i.flying = 0;
	i.atk_flying = 1;
	i.agility = 0;
	i.holy_shield = 0;
	i.can_atk = 0;
	i.can_move = 0;
	return i;
}

void AI :: summon1()
{
	if( round <= 15 ) //ǰ���غ��ٵ���ʦ 
	{
		int cnt = 0;
		for( auto & i : my_army )
			if( i.type == "Priest" )
				cnt++;
		if( cnt >= 2 )
			return;
	}
	int rd = 6;
	while( players[ my_camp ].mana >= 4 && priest_available )
	{
		rd--;
		if( rd == 0 ) break;
		getAttack();
		auto summon_pos_list = getSummonPosByCamp( my_camp );
		double ans = -1000000000;
		int wish = priest_available * 7 + swordsman_available * 4 + archer_available * 6 <= players[ my_camp ].mana ? 3 : 2;
		if( have_bat && players[ my_camp ].mana >= 7 ) wish = 3; 
		Pos summonpos;
		for( auto & i : summon_pos_list )
			if( getUnitByPos( i , false ).id == -1 )
			{
				gameunit :: Unit a;
				if( wish == 3 )
					a = make_priest( i , 3 );
				else
					a = make_priest( i , 2 );
				if( Pos_value( a , i ) > ans )
					ans = Pos_value( a , i ) , summonpos = i;
			}
		if( ans > 0 )
		{
			bool flag = 0; //�Ƿ�������������� 
			for( auto & i : my_army )
				if( i.hp > 0 && cube_distance( i.pos , summonpos ) <= 3 )
					for( auto & j : en_army )
						if( j.hp > 0 && canAttack( i , j ) && i.atk < j.hp )
							flag = 1;
			if( flag )
			{ 
				priest_available--;
				summon( "Priest" , wish , summonpos );
			}
			else
				break;
		}
		else
			break;
	}
}

int enemy_archer_cnt , my_archer_cnt , my_priest_cnt , enemy_priest_cnt;

inline double changeV( double & v , Pos pos )
{
	if( important( pos ) );
	else v *= 0.8;
}

void AI :: summon2() //��� 
{
	int rd = 6;
	auto summon_pos_list = getSummonPosByCamp( my_camp );
	while( players[ my_camp ].mana >= 2 )
	{
		rd--;
		if( rd == 0 ) break;
		getAttack();
		gameunit :: Unit best;
		double ans = -1000000000;
		for( auto & i : summon_pos_list )
		{
			if( getUnitByPos( i , false ).id == -1 )
			{
				gameunit :: Unit a = make_archer( make_tuple( 114 , 114 , 114 ) , std :: min( 3 , players[ my_camp ].mana / 2 ) );
				double v = Pos_value( a , i );
				a.pos = i;
				changeV( v , i );
				if( ( have_bat || players[ my_camp ].mana >= 4 ) && archer_available && v > ans )
					ans = v , best = a;
				
				a = make_sword( make_tuple( 114 , 114 , 114 ) , std :: min( have_dragon ? 2 : 3 , players[ my_camp ].mana / 2 ) );
				v = Pos_value( a , i );
				a.pos = i;
				changeV( v , i );
				if( swordsman_available && v > ans )
					ans = v , best = a;
				
				
				a = make_priest( make_tuple( 114 , 114 , 114 ) , ( have_bat && players[ my_camp ].mana >= 7 ) ? 3 : 2 );
				v = Pos_value( a , i );
				a.pos = i;
				changeV( v , i );
				if( players[ my_camp ].mana >= 4 && priest_available && v > ans )
					ans = v , best = a;
			}
		}
		if( ans > 0 )
		{
			if( best.type == "Archer" ) archer_available--;
			else if( best.type == "Priest" ) priest_available--;
			else swordsman_available--;
			summon( best.type , best.level , best.pos );
		}
		else
			break;
	}
}

void AI :: summon_bat() //��������
{
	int batnum = 0 , archernum = 0;
	getAttack();
	auto summon_pos_list = getSummonPosByCamp( my_camp );
	for( auto & i : en_army )
		if( i.hp > 0 && i.type == "BlackBat" )
			if( cube_distance( i.pos , miracle_pos ) <= i.max_move * 2 + 1 )
				batnum++; //2�غϵ��ҵĵ���
	for( auto & i : my_army )
		if( i.hp > 0 && i.type == "Archer" && cube_distance( i.pos , miracle_pos ) <= 7 )
			archernum++;
	//std :: cerr << "cal bat start" << std :: endl;
	int rd = 6;
	if( batnum > archernum )
		while( players[ my_camp ].mana >= 4 && archer_available )
		{
			rd--;
			if( rd == 0 ) break;
			getAttack();
			int level;
			if( batnum - archernum == 1 )
				if( players[ my_camp ].mana >= 6 ) level = 3;
				else level = 2;
			else if( batnum - archernum == 2 )
				if( players[ my_camp ].mana >= 8 ) level = 2;
				else level = 3;
			else level = 2;
			double ans = -1000000000;
			Pos best;
			for( auto & i : summon_pos_list )
				if( getUnitByPos( i , false ).id == -1 )
					if( cube_distance( i , miracle_pos ) <= 8 ) //�ڽ������ 
					{
						gameunit :: Unit a = make_archer( make_tuple( 114 , 114 , 114 ) , level );
						double v = Pos_value( a , i );
						if( v > ans )
							ans = v , best = i;
					}
			if( ans > 0 )
			{
				archer_available--;
				summon( "Archer" , level , best );
			}
			else
				break;
		}
	//std :: cerr << "cal bat end" << std :: endl;
}

void AI :: summon3() //��������� 
{
	getAttack();
	for( auto & i : threat )
		for( auto & j : en_army )
			if( i.id == j.id )
				i = j;
	double a = clock();
	for( auto & i : threat )
		if( i.type != "BlackBat" && i.hp > 0 )
		{
			double b = clock();
			if( b - a > 0.1 * CLOCKS_PER_SEC )
				break;
			auto summon_pos_list = getSummonPosByCamp( my_camp );
			for( auto & j : summon_pos_list )
				if( getUnitByPos( j , false ).id == -1 )
					if( cube_distance( i.pos , threat_pos[ i.id ] ) == cube_distance( i.pos , j ) + cube_distance( j , threat_pos[ i.id ] ) && cube_distance( i.pos , j ) <= 2 ) //ֱ�Ӹ� 
					{
						if( players[ my_camp ].mana >= 2 )
						{
							if( i.type != "Archer" ) //�����ǹ����� 
							{
								if( swordsman_available )
								{
									swordsman_available--;
									if( threat_pos[ i.id ] == miracle_pos && getUnitByPos( posShift( miracle_pos , 1 , 0 , 0 ) , false ).id == -1 ) //�������� 
										summon( "Swordsman" , std :: min( 3 , players[ my_camp ].mana / 2 ) , posShift( miracle_pos , 1 , 0 , 0 ) );
									else
										summon( "Swordsman" , std :: min( 3 , players[ my_camp ].mana / 2 ) , j );
								}
								else if( archer_available )
								{
									archer_available--;
									summon( "Archer" , std :: min( 3 , players[ my_camp ].mana / 2 ) , j );
								}
								else if( priest_available )
								{
									priest_available--;
									summon( "Priest" , std :: min( 2 , players[ my_camp ].mana / 2 ) , j );
								}
							}
							else if( archer_available ) //����������
							{
								archer_available--;
								if( threat_pos[ i.id ] == miracle_pos ) //�������� 
								{
									Pos pos = make_tuple( 114 , 114 , 114 );
									for( auto & k : summon_pos_list )
										if( getUnitByPos( k , false ).id == -1 && cube_distance( k , miracle_pos ) <= 2 ) //�����Աߵĵ� 
											if( cube_distance( k , i.pos ) == 6 )
											{
												int v = 0;
												for( auto j : en_army )
													if( canAttack_earth( j , k ) )
														v += j.atk;
												if( v < players[ my_camp ].mana / 2 + 1 )
													pos = k;
											}
									if( get < 0 > ( pos ) == 114 )
										for( auto & k : summon_pos_list )
											if( getUnitByPos( k , false ).id == -1 && cube_distance( k , miracle_pos ) <= 2 ) //�����Աߵĵ� 
												if( cube_distance( k , i.pos ) == 7 )
												{
													int v = 0;
													for( auto j : en_army )
														if( canAttack_earth( j , k ) )
															v += j.atk;
													if( v < players[ my_camp ].mana / 2 + 1 )
														pos = k;
												}
									if( get < 0 > ( pos ) == 114 && getUnitByPos( posShift( miracle_pos , 1 , 0 , 0 ) , false ).id == -1 )
										summon( "Archer" , std :: min( 3 , players[ my_camp ].mana / 2 ) , posShift( miracle_pos , 1 , 0 , 0 ) );
									else
										summon( "Archer" , std :: min( 3 , players[ my_camp ].mana / 2 ) , pos );
								}
								else
									summon( "Archer" , std :: min( 3 , players[ my_camp ].mana / 2 ) , j );
							}
						}
						break;
					}
		}
}

int main()
{
	player_ai.chooseCards();
	while( 1 )
	{
		player_ai.updateGameInfo();
		player_ai.play();
	}
	return 0;
}

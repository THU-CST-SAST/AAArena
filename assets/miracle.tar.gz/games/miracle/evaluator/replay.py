"""Miracle 回放解码 —— 把后端产出的 int32 大端二进制回放解析为结构化事件。

回放文件是后端 `send_media_info` 写出的连续 int32（大端有符号），每 7 个为一条
媒体记录。第一条为头部 `[0,0,0,map_type,day_time,0,0]`；其后每条形如
`[round, event, ...payload]`，不足 7 个用 0 补齐。详见 `replay_format.md`。
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path

EVENT_NAMES = [
    "", "TurnStart", "TurnEnd", "Spawn", "Move", "Attack",
    "Damage", "Death", "Heal", "ActivateArtifact",
    "GameEnd", "GameStart", "BuffAdd", "BuffRemove",
    "Attacking", "Attacked", "Leave", "Arrive", "Summon",
]


@dataclass(frozen=True)
class MediaRecord:
    round: int
    event: int
    event_name: str
    payload: tuple[int, ...]


@dataclass(frozen=True)
class ReplayReport:
    map_type: int
    day_time: int
    records: tuple[MediaRecord, ...]
    winner: int | None
    rounds: int


def decode_replay(path: str | Path) -> ReplayReport:
    raw = Path(path).read_bytes()
    if len(raw) < 28:
        raise ValueError("replay too short to contain a header")
    count = len(raw) // 4
    ints = struct.unpack(">" + "i" * count, raw[: count * 4])

    header = ints[0:7]
    map_type = int(header[3])
    day_time = int(header[4])

    records: list[MediaRecord] = []
    winner: int | None = None
    rounds = 0
    for offset in range(7, len(ints) - 6, 7):
        chunk = ints[offset : offset + 7]
        record_round = int(chunk[0])
        event = int(chunk[1])
        name = EVENT_NAMES[event] if 0 <= event < len(EVENT_NAMES) else str(event)
        records.append(MediaRecord(record_round, event, name, tuple(int(x) for x in chunk[2:])))
        if event == 10:  # GameEnd -> [round, 10, winner, ...]
            winner = int(chunk[2])
            rounds = max(rounds, record_round)
        elif record_round >= 0:
            rounds = max(rounds, record_round)

    return ReplayReport(
        map_type=map_type,
        day_time=day_time,
        records=tuple(records),
        winner=winner,
        rounds=rounds,
    )

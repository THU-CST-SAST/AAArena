"""Miracle process placement and role-aware result interpretation."""

from __future__ import annotations

import json
import struct
import subprocess
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

from .runtime import PreparedPlayer

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]


class MiracleMatchError(RuntimeError):
    """The Miracle terminal payload is not scientifically usable."""


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or not self.role:
            raise ValueError("match role must be a non-empty string")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise TypeError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    points: float | None
    score_margin: float | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.points is None or self.score_margin is None:
                raise ValueError("complete match requires outcome and score margin")
            if self.rounds is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or self.points is not None:
                raise ValueError("incomplete match cannot be scored")
            if not self.error:
                raise ValueError("incomplete match requires an error")
        else:
            raise ValueError(f"unknown match status: {self.status}")


def run_saiblo_match(
    *,
    backend: ProcessSpec,
    candidate: ProcessSpec,
    opponent: ProcessSpec,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    candidate_player = 0 if case.role == "P0" else 1
    players = (candidate, opponent) if candidate_player == 0 else (opponent, candidate)
    judged = run_stdio_match(
        backend=backend,
        players=players,
        config={"random_seed": case.seed},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    raw = judged.end_message.get("end_info")
    try:
        end_info = json.loads(raw) if isinstance(raw, str) else raw
    except json.JSONDecodeError as exc:
        raise MiracleMatchError("invalid terminal end_info JSON") from exc
    if not isinstance(end_info, Mapping):
        raise MiracleMatchError("terminal end_info is not an object")
    return _result_from_end_info(
        end_info,
        case=case,
        replay_path=replay_path,
        events_path=events_path,
        returncodes=tuple(judged.process_returncodes[:3]),
    )


def _result_from_end_info(
    end_info: Mapping[str, Any],
    *,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    returncodes: tuple[int, int, int],
) -> MatchResult:
    try:
        score0 = float(end_info["0"])
        score1 = float(end_info["1"])
    except (KeyError, TypeError, ValueError) as exc:
        raise MiracleMatchError(f"invalid end_info: {end_info!r}") from exc
    winner_player = 0 if score0 > score1 else 1
    candidate_player = 0 if case.role == "P0" else 1
    won = winner_player == candidate_player
    candidate_score = score0 if candidate_player == 0 else score1
    opponent_score = score1 if candidate_player == 0 else score0
    return MatchResult(
        case=case,
        status="complete",
        result="win" if won else "loss",
        points=1.0 if won else 0.0,
        score_margin=candidate_score - opponent_score,
        rounds=_rounds_from_replay(replay_path),
        payload={"terminal_scores": (score0, score1)},
        replay_path=replay_path,
        events_path=events_path,
        process_returncodes=returncodes,
    )


def _rounds_from_replay(replay_path: Path) -> int:
    try:
        raw = replay_path.read_bytes()
    except OSError:
        return 0
    if len(raw) < 28:
        return 0
    count = len(raw) // 4
    values = struct.unpack(">" + "i" * count, raw[: count * 4])
    rounds = 0
    for offset in range(0, len(values) - 6, 7):
        record_round = values[offset]
        event = values[offset + 1]
        if event == 10:
            return max(int(record_round), 0)
        if record_round >= 0:
            rounds = max(rounds, int(record_round))
    return rounds


class MiracleArena:
    def __init__(
        self,
        *,
        backend: ProcessSpec,
        opponents: Mapping[str, PreparedPlayer],
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
    ) -> None:
        self.backend = backend
        self.opponents = dict(opponents)
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)

    def run_case(self, case: MatchCase, candidate: PreparedPlayer) -> MatchResult:
        try:
            opponent = self.opponents[case.opponent_id]
        except KeyError as exc:
            raise ValueError(f"unknown or unrunnable opponent: {case.opponent_id}") from exc
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role.lower()
            / f"seed-{case.seed}"
        )
        try:
            return run_saiblo_match(
                backend=self.backend,
                candidate=ProcessSpec(candidate.argv, candidate.cwd),
                opponent=ProcessSpec(opponent.argv, opponent.cwd),
                case=case,
                replay_path=root / "replay.bin",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            MiracleMatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                points=None,
                score_margin=None,
                rounds=None,
                error=str(exc),
            )

"""Miracle（神迹之战 / 24 届）后端资源定位、选手池审计与选手准备。

Miracle 的对局内核（游戏资产）属仓库 A。本模块**不依赖任何框架层**，负责：
- 定位本 GamePack 内的官方 Python 后端 `backend/`；
- 审计冻结的人类天梯选手池 `games/miracle/players/pool/`；
- 把选手准备成一个可运行进程规格：Python 选手直接跑 `main.py`；
  `make` 类（C++）选手在 gitignore 的 data/ 构建目录内编译出可执行文件。

A 的 evaluator 在此之上组织一局对战；B/C 通过 A 复用。
"""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    CppBuildError,
    build_cpp_player,
    has_cpp_build,
    native_build_root,
)
from aa_arena.core.player_environment import player_command
from aa_arena.core.player_entry import find_build_dir, find_python_entry


class MiracleRuntimeError(RuntimeError):
    """冻结运行时资源未通过完整性/准备要求。"""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)
_GAME_DIR = Path(__file__).resolve().parents[1]


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise MiracleRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class MiracleLayout:
    """Miracle 的资源布局：后端源码 + 人类选手池。"""

    aa_arena_root: Path
    build_root: Path
    backend_source_root: Path
    human_manifest: Path
    human_pool_root: Path

    @classmethod
    def from_game_dir(
        cls, game_dir: str | Path, build_root: str | Path
    ) -> MiracleLayout:
        game = Path(game_dir).resolve()
        players = game / "players"
        return cls(
            aa_arena_root=game.parents[1],
            build_root=Path(build_root).resolve(),
            backend_source_root=game / "backend",
            human_manifest=players / "manifest.tsv",
            human_pool_root=players / "pool",
        )

    @classmethod
    def from_root(cls, aa_arena_root: str | Path, build_root: str | Path) -> MiracleLayout:
        return cls.from_game_dir(Path(aa_arena_root) / "games" / "miracle", build_root)

    def validate(self) -> None:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        if not (self.backend_source_root / "main.py").is_file():
            raise FileNotFoundError(self.backend_source_root / "main.py")
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_pool_root.is_dir():
            raise FileNotFoundError(self.human_pool_root)


@dataclass(frozen=True)
class PreparedPlayer:
    """一名可运行选手：启动命令 + 工作目录。"""

    player_id: str
    argv: tuple[str, ...]
    cwd: Path


@dataclass(frozen=True)
class Opponent:
    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    lang: str
    package_root: Path
    runnable: bool
    exclusion_diagnostic: str | None


_RUNNABLE_LANGS = {"python", "python_zip", "make", "auto", "cpp", "c++"}


def audit_human_pool(layout: MiracleLayout) -> tuple[Opponent, ...]:
    """审计人类选手池：读取 manifest，定位每个 rank 的 pool 目录。"""

    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            packages = tuple(sorted(layout.human_pool_root.glob(f"rank{rank:02d}__*")))
            if not packages:
                continue
            package = packages[0]
            lang = (row.get("lang") or "").strip().lower()
            runnable, diagnostic = _classify_runnable(package, lang)
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    lang=lang,
                    package_root=package,
                    runnable=runnable,
                    exclusion_diagnostic=diagnostic,
                )
            )
    pool.sort(key=lambda item: item.rank)
    return tuple(pool)


def _classify_runnable(package: Path, lang: str) -> tuple[bool, str | None]:
    """判断选手是否可运行。Python 需 main.py；make/C++ 需 makefile。"""

    if find_python_entry(package) is not None:
        return True, None
    if has_cpp_build(package):
        return True, None
    return False, "no runnable entry (main.py / makefile) found"


def prepare_player(
    opponent: Opponent,
    *,
    build_root: Path,
) -> PreparedPlayer:
    """把一名选手准备为可运行进程规格。

    - Python 选手：直接在 pool 目录内跑 `python main.py`。
    - make / C++ 选手：把源码拷进 gitignore 的 build_root 内，`make` 编译出
      可执行 `main`，返回该可执行文件为启动命令。构建按目录树哈希缓存。
    """

    package = opponent.package_root
    python_entry = find_python_entry(package)
    if python_entry is not None and opponent.lang not in {"make", "cpp", "c++"}:
        return PreparedPlayer(opponent.opponent_id, player_command(), python_entry)

    if has_cpp_build(package):
        return _build_native_player(opponent, build_root=build_root)

    if python_entry is not None:
        return PreparedPlayer(opponent.opponent_id, player_command(), python_entry)

    raise MiracleRuntimeError(
        f"player {opponent.opponent_id} is not runnable: {opponent.exclusion_diagnostic}"
    )


def _build_native_player(opponent: Opponent, *, build_root: Path) -> PreparedPlayer:
    package = opponent.package_root
    build_dir = find_build_dir(package, allow_cmake=False)
    relative_build = (
        build_dir.relative_to(package) if build_dir is not None else Path(".")
    )
    try:
        executable = build_cpp_player(
            player_dir=package,
            game_dir=_GAME_DIR,
            cache_root=build_root / "players",
        )
    except CppBuildError as exc:
        raise MiracleRuntimeError(
            f"native player {opponent.opponent_id} build_error: {exc}"
        ) from exc
    cwd = native_build_root(executable) / relative_build
    return PreparedPlayer(opponent.opponent_id, (str(executable),), cwd)

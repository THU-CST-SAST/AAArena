"""Miracle 回放 → 自然语言。

Miracle（第 24 届）的回放**不是 JSON**：它是后端 ``send_media_info`` 写出的连续
int32（大端有符号），每 7 个整数一条媒体记录。复用同目录 `replay.py` 的解码器。

这意味着 agent 在容器里**无法自己读懂这份回放** —— 没有格式说明就是一堆字节。
所以这个游戏是"A 负责翻译"这件事最刚需的一个：没有这层翻译，miracle 的反馈通道
实际上等于只有一个胜负布尔值。

叙述的组织依据游戏本体：Miracle 是**卡牌 + 单位召唤**的对抗，
胜负来自单位交换（Attack/Damage/Death）与神器激活（ActivateArtifact）。
所以按"回合 → 事件流"讲，并把三类关键事件单独汇总：召唤、死亡、神器。
"""

from __future__ import annotations

from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, render_events

from . import replay as replay_decoder

#: 事件码 → 人话。索引与 `replay.py` 的 EVENT_NAMES 对齐。
_EVENTS: dict[str, str] = {
    "TurnStart": "回合开始",
    "TurnEnd": "回合结束",
    "Spawn": "单位登场",
    "Move": "单位移动",
    "Attack": "发起攻击",
    "Damage": "造成伤害",
    "Death": "单位死亡",
    "Heal": "治疗",
    "ActivateArtifact": "激活神器",
    "GameEnd": "对局结束",
    "GameStart": "对局开始",
    "BuffAdd": "获得 buff",
    "BuffRemove": "buff 消失",
    "Attacking": "攻击动作开始",
    "Attacked": "受到攻击",
    "Leave": "离场",
    "Arrive": "入场",
    "Summon": "召唤",
}

#: 只有这几类事件值得逐条念；其余（Move/Attacking/Attacked 这些动画帧）折叠。
_KEY_EVENTS = frozenset({"Spawn", "Death", "ActivateArtifact", "Summon", "GameEnd", "GameStart"})

#: 事件构成里最多列这么多行。
_MAX_DISTRIBUTION_ROWS = 24

#: 已知事件码的占比低于这个阈值，就认为这份文件**根本不是 miracle 回放**。
_SANITY_THRESHOLD = 0.5


def _describe(record: replay_decoder.MediaRecord) -> str:
    name = _EVENTS.get(record.event_name, record.event_name or f"事件{record.event}")
    payload = [value for value in record.payload if value != 0]
    if not payload:
        return name
    return f"{name}（参数 {payload}）"


def _bucket(record: replay_decoder.MediaRecord) -> str:
    """事件分类名。**未识别的码全部归到同一桶**，不各自成类。

    为什么这条很重要：miracle 的回放是无头无魔数的 int32 流，只要读进来的字节不是
    回放（拿错了文件、文件被截断、或者 7-int 的步长与该版本后端不符），解码出的
    ``event`` 就是一堆随机大整数。若按码分类，会得到几千个"事件类型"各出现一两次 ——
    产出一份 70 KB 的、看起来煞有介事其实全是噪声的"风格指纹"。这种输出比报错危险得多：
    agent 会认真地基于噪声去写策略。
    """

    if record.event_name in _EVENTS:
        return _EVENTS[record.event_name]
    if 0 <= record.event < len(replay_decoder.EVENT_NAMES):
        return replay_decoder.EVENT_NAMES[record.event] or "空事件"
    return "未识别事件"


def _sanity(records: tuple[replay_decoder.MediaRecord, ...]) -> tuple[bool, float]:
    """已知事件码的占比。用来判断这份文件是否真的是 miracle 回放。"""

    if not records:
        return False, 0.0
    known = sum(1 for item in records if 0 <= item.event < len(replay_decoder.EVENT_NAMES))
    share = known / len(records)
    return share >= _SANITY_THRESHOLD, share


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    report = replay_decoder.decode_replay(replay_path)
    sane, known_share = _sanity(report.records)
    if not sane:
        # 与其产出一份基于噪声的"复盘"，不如明确说清"这文件读不出来"。
        return Narration(
            game="miracle",
            match_id=context.match_id,
            text=(
                f"# Miracle 对局叙述：{context.match_id}\n\n"
                "> **这份文件解不出有效回放**，已停止叙述以免给出误导性结论。\n\n"
                "## 判断依据\n\n"
                f"- 解码出 {len(report.records)} 条媒体记录，但其中只有 "
                f"{known_share:.1%} 的事件码落在官方枚举（0–18）范围内。\n"
                "- miracle 回放是无魔数的 int32 大端流，拿错文件或文件被截断时"
                "同样能「解码成功」，只会得到随机大整数 —— 这正是当前的情况。\n\n"
                "## 仍然确定的事实\n\n"
                f"- 官方裁决胜者：{context.official_winner or '未知'}。\n"
                f"- 回合数：{context.official_rounds if context.official_rounds is not None else '未知'}。\n"
                + (f"- 对战器诊断：{context.diagnostic}。\n" if context.diagnostic else "")
            ),
            rounds=context.official_rounds,
            winner=context.official_winner,
            highlights={"replay_unreadable": True, "known_event_share": known_share},
        )

    winner = context.official_winner
    if winner is None and report.winner is not None:
        winner = f"P{report.winner}" if report.winner in (0, 1) else None
    rounds = context.official_rounds or report.rounds

    verdict: list[str] = []
    if winner is None:
        verdict.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        verdict.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        verdict.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        verdict.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    verdict.append(
        f"- 地图类型 {report.map_type}、昼夜参数 {report.day_time}；"
        f"共 {rounds} 回合 / {len(report.records)} 条媒体事件。"
    )
    verdict.append(
        "- ⚠️ 本游戏回放是 int32 大端二进制（每 7 个整数一条记录），"
        "不是 JSON。这份自然语言叙述是由 A 仓解码后翻译的。"
    )
    if context.diagnostic:
        verdict.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")

    tally: dict[str, int] = {}
    for record in report.records:
        key = _bucket(record)
        tally[key] = tally.get(key, 0) + 1
    ordered = sorted(tally.items(), key=lambda item: -item[1])
    distribution = [f"- {name}：{count} 次" for name, count in ordered[:_MAX_DISTRIBUTION_ROWS]]
    if len(ordered) > _MAX_DISTRIBUTION_ROWS:
        rest = sum(count for _name, count in ordered[_MAX_DISTRIBUTION_ROWS:])
        distribution.append(f"- （其余 {len(ordered) - _MAX_DISTRIBUTION_ROWS} 类共 {rest} 次）")
    if known_share < 1.0:
        distribution.append(
            f"- ⚠️ 有 {1 - known_share:.1%} 的事件码不在官方枚举内，已并入「未识别事件」。"
        )

    key_events = [
        f"- 第 {record.round} 回合：{_describe(record)}"
        for record in report.records
        if record.event_name in _KEY_EVENTS
    ]

    events = [
        Event(
            round=record.round,
            actor="",
            text=_describe(record),
            ref=f"r{record.round:04d}",
            fold_key="" if record.event_name in _KEY_EVENTS else f"anim-{_bucket(record)}",
            fold_label=f"{_bucket(record)}（动画/中间帧）",
        )
        for record in report.records
    ]

    doc = Document(
        title=(
            f"Miracle 对局叙述：{context.match_id}"
            + (f" vs {context.opponent_id}" if context.opponent_id else "")
        ),
        subtitle=(
            f"共 {rounds} 回合 / {len(report.records)} 条事件。"
            "由 A 仓 `aa_arena.replay` 从**二进制**回放解码并翻译。"
        ),
    )
    doc.section("终局事实", verdict)
    doc.section(
        "状态变化与数值增量",
        distribution + key_events[:200]
        + ([f"- 关键事件截断 {len(key_events) - 200} 条。"] if len(key_events) > 200 else []),
    )
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=240)
    doc.section("可观测动作", timeline or ["- 回放未记录事件。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=240。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="miracle",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights={"event_tally": tally, "records": len(report.records)},
    )

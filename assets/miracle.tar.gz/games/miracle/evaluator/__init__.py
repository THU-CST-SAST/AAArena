"""Miracle（神迹之战 / 24 届）对战器 —— 满足 `aa_arena.core.Evaluator` 协议。

Miracle 是双人对抗策略对战（Saiblo Game.code）。本包对外暴露 `MiracleEvaluator`，
其 `evaluate(players, roles, seed) -> EvaluateResult` 遵循 `docs/evaluator-contract.md`：

- 定位官方 Python 后端并按 Saiblo judge 协议驱动它与两名选手完成一局；
- 选手支持 Python（main.py）与 C++（make 编译）两类；
- 从后端终局 `end_info` 与二进制回放裁决胜负与回合数，返回可复现结果；
- 三态区分：后端/选手池准备失败 = `infra_error`；选手超时/非法/崩溃 =
  `game_error`；正常终局 = `complete`。

B(HL)/C(RL) 通过统一入口 `evaluate("miracle", ...)` 复用本实现。
"""

from __future__ import annotations

from pathlib import Path
from aa_arena.saiblo.player_errors import transport_player_errors

from aa_arena.core.buildcache import backend_run_dir
from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError
from aa_arena.core.player_entry import find_python_entry
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    MatchCase,
    MatchResult,
    MiracleArena,
    MiracleMatchError,
    ProcessSpec,
    run_saiblo_match,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    MiracleLayout,
    MiracleRuntimeError,
    Opponent,
    PreparedPlayer,
    audit_human_pool,
    prepare_player,
    tree_sha256,
)

__all__ = [
    "MatchCase",
    "MatchResult",
    "MiracleArena",
    "MiracleEvaluator",
    "MiracleLayout",
    "MiracleMatchError",
    "MiracleRuntimeError",
    "Opponent",
    "PreparedPlayer",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "decode_replay",
    "make_evaluator",
    "prepare_player",
    "run_saiblo_match",
    "tree_sha256",
]


def _other_role(role: str) -> str:
    return "P1" if role == "P0" else "P0"


class MiracleEvaluator:
    """Miracle 对战器：给定两名选手、角色与种子，跑一局并返回契约结果。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        # games/<game>/ 上两级是 A 仓库根（后端源码 + 人类池所在）。
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "miracle-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "miracle-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"miracle requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"miracle roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = MiracleLayout.from_game_dir(self.game_dir, self._build_root)

        # 后端定位 + 选手池审计 + 选手准备（含 C++ 编译）：失败属基础设施故障。
        try:
            layout.validate()
            pool = audit_human_pool(layout)
            prepared = [
                self._resolve_player(player, pool=pool, build_root=self._build_root)
                for player in players
            ]
        except (
            MiracleRuntimeError,
            MiracleMatchError,
            PlayerEnvironmentError,
            FileNotFoundError,
            OSError,
        ) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        # players[0] 为 candidate，players[1] 为 opponent。
        candidate_role = roles[0]
        candidate = prepared[0]
        opponent = prepared[1]

        case = MatchCase(candidate.player_id, opponent.player_id, candidate_role, seed)
        # 后端必须在**可写、每局独占**的目录里跑（详见
        # aa_arena.core.buildcache.backend_run_dir）：miracle 的后端目前不写 cwd，
        # 但这属于"碰巧没坏"，一旦后端源码里出现一行写文件就会重演 generals 的
        # "全员同分"事故，而流水线不会报错。
        try:
            with backend_run_dir(
                layout.backend_source_root, parent=self._build_root, tag="miracle-backend"
            ) as backend_cwd:
                backend_spec = ProcessSpec((self._backend_python(), "main.py"), backend_cwd)
                arena = MiracleArena(
                    backend=backend_spec,
                    opponents={opponent.player_id: opponent},
                    artifact_root=self._artifact_root,
                    timeout_s=self.timeout_s,
                )
                result = arena.run_case(case, candidate=candidate)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend run dir preparation failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        return self._to_evaluate_result(result, candidate_role)

    # -- helpers -----------------------------------------------------------

    def _backend_python(self) -> str:
        import sys

        return sys.executable

    def _resolve_player(
        self,
        player: PlayerRef,
        *,
        pool: tuple[Opponent, ...],
        build_root: Path,
    ) -> PreparedPlayer:
        """把 PlayerRef 解析并准备为可运行选手。"""

        if player.code_path is not None:
            root = Path(player.code_path).resolve()
            opponent = Opponent(
                opponent_id=player.player_id,
                rank=0,
                username=None,
                score=None,
                lang="python" if find_python_entry(root) is not None else "make",
                package_root=root,
                runnable=True,
                exclusion_diagnostic=None,
            )
            return prepare_player(opponent, build_root=build_root)
        for opponent in pool:
            if opponent.opponent_id == player.player_id and opponent.runnable:
                prepared = prepare_player(opponent, build_root=build_root)
                # 保持 player_id 与请求一致（opponent_id 即 rankNN）。
                return PreparedPlayer(player.player_id, prepared.argv, prepared.cwd)
        raise MiracleMatchError(
            f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
        )

    def _to_evaluate_result(
        self,
        result: MatchResult,
        candidate_role: str,
    ) -> EvaluateResult:
        scores_tuple = result.payload.get("terminal_scores")
        if not (isinstance(scores_tuple, tuple) and len(scores_tuple) == 2):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing terminal_scores payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        p0_score, p1_score = float(scores_tuple[0]), float(scores_tuple[1])
        scores = {"P0": p0_score, "P1": p1_score}
        candidate_won = result.result == "win"
        winner = candidate_role if candidate_won else _other_role(candidate_role)
        # The official backend adjudicates a player crash/timeout as a forfeit,
        # so a valid terminal score does not imply an error-free game. Preserve
        # that score while exposing the transport's authoritative failed seat.
        failed_roles, diagnostic = transport_player_errors(result.events_path)
        return EvaluateResult(
            status=EvaluationStatus.GAME_ERROR if failed_roles else EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
            diagnostic=diagnostic,
            payload={"failed_roles": failed_roles},
        )


def make_evaluator(game_dir: Path) -> MiracleEvaluator:
    """插件工厂：供 `games/miracle/plugin.py` 装配对战器。"""

    return MiracleEvaluator(game_dir)

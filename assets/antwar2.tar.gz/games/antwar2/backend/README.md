# 30_antwar2

- 届次：第 30 届 AntWar2 / 蚁洋陷役2
- 类型：双人回合制塔防对抗
- 内容：`logic/` 保存解包后的后端、SDK、server 或样例 AI。原始包 `archives/` 与 `SHA256SUMS` 通过 `.gitignore` 排除、不入库（仅存在于本地采集环境）。
- 注：本游戏的规范文件（rules/decision_space/replay_format）与选手池已收拢到 `games/antwar2/`（参考示范）。
- 来源：Saiblo Game.code

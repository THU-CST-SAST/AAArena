"""AntWar2 process placement, replay parsing, and public trace generation."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)
from aa_arena.core.player_environment import player_command

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or not self.role:
            raise ValueError("match role must be a non-empty string")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise ValueError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    points: float | None
    score_margin: float | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    trace_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.points is None or self.score_margin is None:
                raise ValueError("complete match requires an outcome and score margin")
            if self.rounds is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or self.points is not None:
                raise ValueError("incomplete match cannot be scored")
            if not self.error:
                raise ValueError("incomplete match requires an error")
        else:
            raise ValueError(f"unknown match status: {self.status}")


class AntWar2MatchError(RuntimeError):
    """The AntWar2 replay does not contain a valid terminal result."""


def _load_replay(path: Path) -> list[dict[str, Any]]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AntWar2MatchError(f"cannot read replay {path}: {exc}") from exc
    if not isinstance(value, list) or not value:
        raise AntWar2MatchError("replay must be a non-empty JSON array")
    if not all(isinstance(record, dict) for record in value):
        raise AntWar2MatchError("replay contains a non-object round")
    return value


def match_result_from_replay(
    replay_path: str | Path,
    *,
    candidate_id: str,
    opponent_id: str,
    role: str,
    seed: int,
    trace_path: str | Path | None = None,
    events_path: str | Path | None = None,
    process_returncodes: tuple[int, int, int] | None = None,
) -> MatchResult:
    case = MatchCase(candidate_id, opponent_id, role, seed)
    source = Path(replay_path).resolve()
    replay = _load_replay(source)
    terminal = replay[-1].get("round_state")
    if not isinstance(terminal, dict):
        raise AntWar2MatchError("replay has no terminal round_state")
    winner = terminal.get("winner")
    if winner not in {0, 1}:
        raise AntWar2MatchError("replay has no valid terminal winner")
    replay_camps = terminal.get("camps")
    if (
        not isinstance(replay_camps, list)
        or len(replay_camps) != 2
        or any(
            isinstance(value, bool) or not isinstance(value, (int, float))
            for value in replay_camps
        )
    ):
        raise AntWar2MatchError("replay has invalid terminal base-HP mapping")
    base_hp = (float(replay_camps[0]), float(replay_camps[1]))
    candidate_player = 0 if role == "P0" else 1
    opponent_player = 1 - candidate_player
    won = winner == candidate_player
    return MatchResult(
        case=case,
        status="complete",
        result="win" if won else "loss",
        points=1.0 if won else 0.0,
        score_margin=base_hp[candidate_player] - base_hp[opponent_player],
        rounds=len(replay),
        payload={"terminal_base_hp": base_hp},
        replay_path=source,
        trace_path=None if trace_path is None else Path(trace_path).resolve(),
        events_path=None if events_path is None else Path(events_path).resolve(),
        process_returncodes=process_returncodes,
    )


def write_public_trace(replay_path: Path, trace_path: Path) -> None:
    replay = _load_replay(replay_path)
    trace_path.parent.mkdir(parents=True, exist_ok=True)
    with trace_path.open("w", encoding="utf-8") as stream:
        sequence = 0
        for round_index, record in enumerate(replay):
            for player in (0, 1):
                operations = record.get(f"op{player}", [])
                if not isinstance(operations, list):
                    raise AntWar2MatchError(
                        f"round {round_index} P{player} operations are invalid"
                    )
                stream.write(
                    json.dumps(
                        {
                            "sequence": sequence,
                            "round": round_index,
                            "kind": "accepted_operations",
                            "player": player,
                            "operations": operations,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
                sequence += 1
            public_state = record.get("round_state")
            if not isinstance(public_state, dict):
                raise AntWar2MatchError(f"round {round_index} has no public state")
            stream.write(
                json.dumps(
                    {
                        "sequence": sequence,
                        "round": round_index,
                        "kind": "public_state",
                        "public_state": public_state,
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )
            sequence += 1


def run_native_match(
    *,
    game: ProcessSpec,
    candidate_process: ProcessSpec,
    opponent_process: ProcessSpec,
    case: MatchCase,
    replay_path: Path,
    trace_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    candidate_player = 0 if case.role == "P0" else 1
    players = (
        (candidate_process, opponent_process)
        if candidate_player == 0
        else (opponent_process, candidate_process)
    )
    judged = run_stdio_match(
        backend=game,
        players=players,
        config={"random_seed": case.seed},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    write_public_trace(replay_path, trace_path)
    return match_result_from_replay(
        replay_path,
        candidate_id=case.candidate_id,
        opponent_id=case.opponent_id,
        role=case.role,
        seed=case.seed,
        trace_path=trace_path,
        events_path=events_path,
        process_returncodes=tuple(judged.process_returncodes[:3]),
    )


Runner = Callable[..., MatchResult]


class AntWar2Arena:
    def __init__(
        self,
        *,
        game: ProcessSpec,
        opponents: Mapping[str, ProcessSpec],
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
        candidate_command_prefix: tuple[str, ...] = (),
        runner: Runner = run_native_match,
    ) -> None:
        self.game = game
        self.opponents = dict(opponents)
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)
        self.candidate_command_prefix = tuple(candidate_command_prefix)
        self.runner = runner

    def run_case(
        self,
        case: MatchCase,
        candidate_root: Path | None = None,
        candidate_process: ProcessSpec | None = None,
    ) -> MatchResult:
        try:
            opponent = self.opponents[case.opponent_id]
        except KeyError as exc:
            raise ValueError(f"unknown or unrunnable opponent: {case.opponent_id}") from exc
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role.lower()
            / f"seed-{case.seed}"
        )
        try:
            return self.runner(
                game=self.game,
                candidate_process=(
                    candidate_process
                    if candidate_process is not None
                    else ProcessSpec(
                        (*self.candidate_command_prefix, *player_command()),
                        candidate_root if candidate_root is not None else Path.cwd(),
                    )
                ),
                opponent_process=opponent,
                case=case,
                replay_path=root / "replay.json",
                trace_path=root / "public-trace.jsonl",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            AntWar2MatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                points=None,
                score_margin=None,
                rounds=None,
                error=str(exc),
            )

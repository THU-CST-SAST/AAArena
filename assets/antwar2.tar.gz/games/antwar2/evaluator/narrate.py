"""AntWar2 回放 → 自然语言。

复用同目录 `replay.py` 的解码器（它已经把回放数字落回公开语义：原子事件时间线、
关键窗口、指标），这里只负责**讲人话**。两者分工刻意分开：

* `replay.py`：数字 → 结构（谁在第几回合做了什么，可被程序消费）；
* `narrate.py`：结构 → 散文（这一局的故事，给读者消费）。

叙述的组织原则来自"读者是谁"：读它的是刚刚打完这局的候选自己。所以：

1. **先给判决与死因**（赢没赢、怎么输的），而不是先铺垫；
2. 再给**对手的行为规律**（它开局做什么、什么时候用超武、爱打哪些格子）——
   这是唯一能拿来蒸馏的东西，因为对手代码不可见；
3. 再给**自己的浪费**（金币囤着不花、建了又拆），这是最容易改的一类问题；
4. 最后才是逐回合时间线，且连续同类操作会被折叠。
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import (
    budget_lines,
    Document,
    Event,
    describe_pair,
    render_events,
)

from . import replay as replay_decoder

_ROLES = ("P0", "P1")


def _load(path: Path) -> Sequence[Mapping[str, object]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, list):
        # ValueError 而非 TypeError：这是"回放文件内容不对"（数据问题），
        # 不是"调用方传错了类型"（编程问题）。narrate() 会把它降级成一段说明。
        raise ValueError("antwar2 回放应当是 JSON 数组（每元素一回合）")  # noqa: TRY004
    return document


def _index(role: str) -> int:
    return 1 if role.endswith("1") else 0


def _verdict(report: replay_decoder.ReplayReport, context: NarrationContext) -> list[str]:
    winner = context.official_winner or report.winner
    lines: list[str] = []
    if winner is None:
        lines.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        lines.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        lines.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        lines.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    final = report.frames[-1]
    lines.append(
        f"- 终局第 {final.round_index} 回合，"
        + describe_pair(
            "基地 HP", [int(value) for value in final.base_hp], [context.label(r) for r in _ROLES]
        )
        + "。"
    )
    lines.append(
        "- 终局资源与等级："
        + describe_pair("金币", [int(v) for v in final.coins], [context.label(r) for r in _ROLES])
        + "；"
        + describe_pair(
            "出兵速度等级",
            [int(v) for v in final.generation_level],
            [context.label(r) for r in _ROLES],
        )
        + "；"
        + describe_pair(
            "蚂蚁血量等级",
            [int(v) for v in final.ant_level],
            [context.label(r) for r in _ROLES],
        )
        + "。"
    )
    if context.diagnostic:
        lines.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")
    return lines


def _rival_profile(report: replay_decoder.ReplayReport, context: NarrationContext) -> list[str]:
    """把对手的可观测行为规律讲出来 —— 对手代码不可见，这里是唯一的蒸馏来源。"""

    metrics = report.metrics
    lines: list[str] = []
    for role in _ROLES:
        if context.perspective is not None and role == context.perspective:
            continue
        label = context.label(role)
        first_action = metrics["first_action_round"][role]  # type: ignore[index]
        first_weapon = metrics["first_weapon_round"][role]  # type: ignore[index]
        builds = metrics["build_count"][role]  # type: ignore[index]
        downgrades = metrics["downgrade_count"][role]  # type: ignore[index]
        coverage = metrics["weapon_target_coverage"][role]  # type: ignore[index]
        churn = metrics["build_downgrade_churn"][role]  # type: ignore[index]
        delay = metrics["downgrade_to_weapon_delay"][role]  # type: ignore[index]
        lines.append(
            f"- {label} 的节奏："
            f"首次操作在第 {first_action if first_action is not None else '—'} 回合；"
            f"首次超级武器在第 {first_weapon if first_weapon is not None else '未使用'} 回合。"
        )
        lines.append(
            f"- {label} 的经营："
            f"建塔 {builds} 次、降级/拆塔 {downgrades} 次"
            f"（其中反复建拆约 {churn} 次）；超武打过 {coverage} 个不同格子。"
        )
        if delay is not None:
            lines.append(
                f"- {label} 出现过「先拆塔攒钱、{delay} 回合后放超武」的组合 ——"
                "这是一个可预测的窗口：拆塔那一刻就能推断它接下来要放超武。"
            )
        if first_weapon is None:
            lines.append(
                f"- {label} **整局没用过超级武器**。若这条在多局稳定复现，"
                "说明它的资源全在塔上，你可以按「它不会突然清场」来规划蚂蚁流。"
            )
    return lines


def _own_waste(report: replay_decoder.ReplayReport, context: NarrationContext) -> list[str]:
    metrics = report.metrics
    lines: list[str] = []
    roles = (context.perspective,) if context.perspective else _ROLES
    for role in roles:
        if role not in _ROLES:
            continue
        idle = metrics["idle_resource_rounds"][role]  # type: ignore[index]
        churn = metrics["build_downgrade_churn"][role]  # type: ignore[index]
        label = context.label(role)
        if idle:
            span = f"第 {idle[0]}" + (f"–{idle[-1]} 回合" if len(idle) > 1 else " 回合")
            lines.append(
                f"- {label} 有 {len(idle)} 个回合在金币 ≥90 时**什么都没做**（{span}）。"
                "金币不产生任何收益，囤着等于白扔 —— 这类回合是最容易换成实际收益的。"
            )
        if churn >= 3:
            lines.append(
                f"- {label} 出现 {churn} 次「建了又拆」。建拆都要付费，"
                "反复摇摆等于持续漏钱，通常说明选址判据不稳定。"
            )
    breaches = metrics["base_breaches"]  # type: ignore[index]
    if isinstance(breaches, list) and breaches:
        first = breaches[0]
        lines.append(
            f"- 第一次基地掉血发生在第 {first['round']} 回合（{context.label(str(first['player']))}"
            f" 掉 {first['damage']:g} HP）。在此之前是双方的「安全期」，"
            "这个时间点决定了你还有多少回合可以纯发育。"
        )
    return lines


def _state_deltas(
    report: replay_decoder.ReplayReport, context: NarrationContext
) -> list[str]:
    lines: list[str] = []
    fields = (
        ("base_hp", "基地 HP"),
        ("coins", "金币"),
        ("generation_level", "出兵速度等级"),
        ("ant_level", "蚂蚁血量等级"),
    )
    for before, after in zip(report.frames, report.frames[1:], strict=False):
        for attribute, label in fields:
            old_pair = getattr(before, attribute)
            new_pair = getattr(after, attribute)
            for player, (old, new) in enumerate(zip(old_pair, new_pair, strict=True)):
                if old != new:
                    lines.append(
                        f"- 第 {after.round_index} 回合：{context.label(f'P{player}')} {label} "
                        f"{old:g}→{new:g}（{new - old:+g}）。"
                    )
        tower_change = len(after.towers) - len(before.towers)
        if tower_change:
            lines.append(
                f"- 第 {after.round_index} 回合：场上塔数量 "
                f"{len(before.towers)}→{len(after.towers)}（{tower_change:+d}）。"
            )
    return lines or ["- 相邻状态帧中的基地 HP、金币、等级和塔数量均未变化。"]


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    document = _load(replay_path)
    report = replay_decoder.decode_replay(document, match_id=context.match_id.replace("/", "_"))

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"AntWar2 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"共 {len(report.frames)} 回合 / {len(report.timeline)} 个原子决策。"
            "本文由 A 仓 `aa_arena.replay` 从官方回放逐帧翻译而来，"
            "所有断言都能对回到具体回合。"
        ),
    )
    doc.section("终局事实", _verdict(report, context))
    state_lines = _state_deltas(report, context)
    if context.detail != "full":
        state_lines = budget_lines(state_lines, 160)
    doc.section("状态变化与数值增量", state_lines)

    events = [
        Event(
            round=item.round_index,
            actor=context.label(item.player),
            text=item.text.split("；", 1)[0].split(" ", 1)[1] if " " in item.text else item.text,
            ref=item.state_id,
            # HOLD 是最容易连成一片的事件，折叠它收益最大
            # （实测一局 726 条决策里 600+ 条是 HOLD）。
            fold_key="hold" if item.action == "HOLD" else "",
            fold_label="未提交操作（HOLD）",
        )
        for item in report.timeline
    ]
    if context.detail == "full":
        # full = **完整**翻译：每一个原子决策一行，不折叠、不裁剪。
        # 这是"把回放完整翻译成自然语言"的字面实现，用于需要逐帧复盘的场合。
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=240)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=240。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="antwar2",
        match_id=context.match_id,
        text=doc.render(),
        rounds=context.official_rounds or len(report.frames),
        winner=context.official_winner or report.winner,
        highlights={
            key: report.metrics[key]
            for key in (
                "first_action_round",
                "first_weapon_round",
                "build_count",
                "downgrade_count",
                "weapon_target_coverage",
                "base_breaches",
            )
        },
    )

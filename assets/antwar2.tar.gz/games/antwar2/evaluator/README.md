# antwar2 evaluator — 对战器

AntWar2 的对战器满足统一契约
[`../../../docs/evaluator-contract.md`](../../../docs/evaluator-contract.md)：

```python
evaluate("antwar2", players, roles, seed) -> {
    "status": "complete" | "game_error" | "infra_error",
    "winner": <"P0"|"P1"|null>,
    "scores": {"P0": <float>, "P1": <float>},
    "rounds": <int|null>,
    "replay_path": <str|null>,
}
```

## 实现

本目录是 AntWar2 对战器的**可运行实现**（游戏资产，属 A）：

| 文件 | 职责 |
| --- | --- |
| `runtime.py` | 编译官方 C++ 后端（优先从已提交的源码树，可复现于全新 checkout；退回 gitignored 归档）、审计冻结的人类天梯选手池、物化选手引导目录。 |
| `arena.py` | 用长度前缀 stdio 协议驱动后端 + 两名 Python 选手完成一局，产出角色感知的 `MatchResult`（含 `terminal_base_hp`、`score_margin`、`rounds`）。自包含 `ProcessSpec`/`MatchCase`/`MatchResult`，不依赖任何框架层。 |
| `replay.py` | 把回放 JSON 解码为公开语义的原子事件时间线、关键窗口与指标（供 B 的回放技能翻译）。 |
| `__init__.py` | 暴露 `AntWar2Evaluator`，满足 `aa_arena.core.Evaluator` 协议：`evaluate(players, roles, seed) -> EvaluateResult`。 |

对战器由 `../plugin.py` 的 `PLUGIN.evaluator_factory` 装配，经框架 Core 的统一
入口 `aa_arena.core.evaluate("antwar2", ...)` 调用。

## AntWar2 特有约定

- **角色不对称**：P0 起始 `(2,9)`、P1 起始 `(16,9)`。side-balanced 评测须交换
  `roles` 顺序并固定成对 `seed`。
- **终局判定**：基地 0 HP 判负；双方同时归零或第 512 轮平局判定均判 **P0 胜**
  （见 `../rules.md`）。
- **status 三态**：编译/后端进程/资源准备失败 → `infra_error`（不惩罚选手，应重跑）；
  选手超时/非法动作/进程崩溃 → `game_error`（按规则判负，计入）；无协议错误的
  正常终局 → `complete`。
- **scores 语义**：`scores["P0"]`/`scores["P1"]` 为终局双方基地 HP（绝对 P0/P1
  顺序，回放 `camps` 语义）。
- **后端**：规则权威是官方 C++ 后端，源码位于
  `games/antwar2/backend/logic/`（见 `../backend/README.md`）。
- **选手引用**：`PlayerRef.player_id` 可为人类池的 `rankNN`，或用
  `PlayerRef.code_path` 指向一个含 `main.py` 的自包含选手目录。

## 环境要求

真跑一局需要本机具备 `make` / `g++`（编译 C++ 后端）与 Python（运行选手）。
仅做 `import` 与插件装配不需要上述工具链。

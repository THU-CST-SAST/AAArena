"""Frozen AntWar2 resources, builds, and human-pool audit.

AntWar2 的对战器内核（游戏资产），属仓库 A。负责：
- 从**源码目录**（优先，可复现于全新 checkout）或 gitignored 归档编译官方 C++ 后端；
- 审计冻结的人类天梯选手池。

本模块**不依赖任何框架**（既不依赖 A 的 core，也不依赖 B 的 HL 框架），
可被 A 的 evaluator 直接调用，也可被 B/C 通过 A 复用。
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import shutil
import stat
import subprocess
import sys
import threading
import zipfile
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    CppBuildError as CppBuildError,
    build_player as build_player,
    has_cpp_build as has_cpp_build,
)
from aa_arena.core.player_entry import find_python_entry
from aa_arena.core.player_environment import player_command


class AntWar2RuntimeError(RuntimeError):
    """A frozen runtime resource failed an integrity requirement."""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)


_BACKEND_BUILD_LOCKS: dict[Path, threading.Lock] = {}
_BACKEND_BUILD_LOCKS_GUARD = threading.Lock()


def _backend_build_lock(root: Path) -> threading.Lock:
    """Return the process-local lock for one immutable backend cache path."""

    with _BACKEND_BUILD_LOCKS_GUARD:
        return _BACKEND_BUILD_LOCKS.setdefault(root, threading.Lock())


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise AntWar2RuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class AntWar2Layout:
    aa_arena_root: Path
    build_root: Path
    backend_archive: Path
    backend_source_root: Path
    human_manifest: Path
    human_extracted_root: Path
    public_sdk_root: Path

    @classmethod
    def from_root(cls, aa_arena_root: str | Path, build_root: str | Path) -> AntWar2Layout:
        aa_arena = Path(aa_arena_root).resolve()
        # 人类池来自统一的 population pool（games/<game>/players/），不再依赖
        # 已删除的 top_algorithms 精选榜单目录。
        players = aa_arena / "games/antwar2/players"
        pool = players / "pool"
        backend = aa_arena / "games/antwar2/backend"
        sdk_candidates = sorted(pool.glob("rank01__*/SDK"))
        public_sdk_root = sdk_candidates[0] if sdk_candidates else (pool / "rank01" / "SDK")
        return cls(
            aa_arena_root=aa_arena,
            build_root=Path(build_root).resolve(),
            backend_archive=(backend / "archives/gamecode_logic__141.zip"),
            backend_source_root=(backend / "logic/gamecode_logic"),
            human_manifest=players / "manifest.tsv",
            human_extracted_root=pool,
            public_sdk_root=public_sdk_root,
        )

    def has_backend_archive(self) -> bool:
        return self.backend_archive.is_file()

    def backend_fingerprint(self) -> str:
        """Content hash of the frozen backend.

        Prefer the committed source tree so a fresh checkout is reproducible
        without the gitignored ``archives/*.zip``; fall back to the archive
        when only that is available.
        """

        if self.backend_source_root.is_dir():
            return tree_sha256(self.backend_source_root)
        if self.backend_archive.is_file():
            return sha256_file(self.backend_archive)
        raise FileNotFoundError(self.backend_source_root)

    def validate(self, expected_sdk_sha256: str | None = None) -> None:
        if not self.backend_source_root.is_dir() and not self.backend_archive.is_file():
            raise FileNotFoundError(self.backend_source_root)
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        for path in (self.human_extracted_root, self.public_sdk_root):
            if not path.is_dir():
                raise FileNotFoundError(path)
        if expected_sdk_sha256 is not None:
            actual = tree_sha256(self.public_sdk_root)
            if actual != expected_sdk_sha256:
                raise AntWar2RuntimeError(
                    f"public SDK hash mismatch: expected {expected_sdk_sha256}, got {actual}"
                )


def safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    resolved_destination = destination.resolve()
    with zipfile.ZipFile(archive) as package:
        for member in package.infolist():
            relative = Path(member.filename)
            mode = member.external_attr >> 16
            target = (destination / relative).resolve()
            if (
                relative.is_absolute()
                or ".." in relative.parts
                or stat.S_ISLNK(mode)
                or not target.is_relative_to(resolved_destination)
            ):
                raise AntWar2RuntimeError(f"unsafe archive member: {member.filename}")
        package.extractall(destination)


def validate_cached_backend(
    executable: Path,
    manifest_path: Path,
    archive_sha256: str,
) -> dict[str, object] | None:
    if not executable.is_file() or not manifest_path.is_file():
        return None
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict):
        return None
    if value.get("archive_sha256") != archive_sha256:
        return None
    if value.get("executable_sha256") != sha256_file(executable):
        return None
    return value


def _enable_windows_binary_transport(main_source: Path) -> bool:
    if sys.platform != "win32":
        return False
    text = main_source.read_text(encoding="utf-8")
    if "AGENTBENCH_BINARY_TRANSPORT" in text:
        return True
    include_anchor = "#include <vector>"
    main_anchor = "int main(/*int argc, char *argv[]*/) {"
    if include_anchor not in text or main_anchor not in text:
        raise AntWar2RuntimeError("cannot apply Windows binary transport patch")
    text = text.replace(
        include_anchor,
        include_anchor + "\n#ifdef _WIN32\n#include <fcntl.h>\n#include <io.h>\n#endif",
        1,
    ).replace(
        main_anchor,
        main_anchor
        + "\n#ifdef _WIN32 // AGENTBENCH_BINARY_TRANSPORT\n"
        + "    _setmode(_fileno(stdin), _O_BINARY);\n"
        + "    _setmode(_fileno(stdout), _O_BINARY);\n#endif",
        1,
    )
    main_source.write_text(text, encoding="utf-8")
    return True


@dataclass(frozen=True)
class FrozenBackend:
    executable: Path
    archive_sha256: str
    executable_sha256: str
    manifest_path: Path


def build_backend(layout: AntWar2Layout) -> FrozenBackend:
    layout.validate()
    archive_hash = layout.backend_fingerprint()
    root = layout.build_root / f"backend-{archive_hash[:16]}"
    # One evaluator process uses a thread pool. Without this lock, both seat
    # workers can quarantine/copy/build the same cache concurrently and turn a
    # healthy full-pool baseline into hundreds of infrastructure failures.
    with _backend_build_lock(root):
        game_root = root / "game"
        executable = game_root / "output" / (
            "main.exe" if sys.platform == "win32" else "main"
        )
        manifest_path = root / "build-manifest.json"
        cached = validate_cached_backend(executable, manifest_path, archive_hash)
        if cached is not None:
            return FrozenBackend(
                executable,
                archive_hash,
                str(cached["executable_sha256"]),
                manifest_path,
            )
        quarantine = root.with_name(f"{root.name}.invalid")
        if root.exists():
            # A previous interrupted or racing build may have left both paths.
            # They are run-local invalid caches, so keep only the newest one.
            shutil.rmtree(quarantine, ignore_errors=True)
            root.rename(quarantine)
        # Prefer the committed source tree (reproducible from a fresh checkout);
        # fall back to the gitignored archive only when the source tree is absent.
        if layout.backend_source_root.is_dir():
            shutil.copytree(layout.backend_source_root, root)
        else:
            safe_extract(layout.backend_archive, root)
        if not game_root.is_dir():
            raise AntWar2RuntimeError("backend source has no game directory")
        patched = _enable_windows_binary_transport(game_root / "src/main.cpp")
        completed = subprocess.run(
            ("make", "-C", str(game_root), f"-j{max(1, min(os.cpu_count() or 1, 8))}"),
            capture_output=True,
            text=True,
            check=False,
            timeout=300,
        )
        if completed.returncode != 0 or not executable.is_file():
            diagnostic = (completed.stderr or completed.stdout)[-8000:]
            raise AntWar2RuntimeError(f"backend build failed: {diagnostic}")
        compiler = subprocess.run(
            ("g++", "--version"),
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        executable_hash = sha256_file(executable)
        backend_source = (
            str(layout.backend_source_root)
            if layout.backend_source_root.is_dir()
            else str(layout.backend_archive)
        )
        manifest = {
            "schema_version": "1.0",
            "archive": backend_source,
            "archive_sha256": archive_hash,
            "executable": str(executable),
            "executable_sha256": executable_hash,
            "platform": platform.platform(),
            "python": sys.version,
            "compiler": (compiler.stdout or compiler.stderr).splitlines()[0],
            "windows_binary_transport_patch": patched,
        }
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
        shutil.rmtree(quarantine, ignore_errors=True)
        return FrozenBackend(executable, archive_hash, executable_hash, manifest_path)


@dataclass(frozen=True)
class Opponent:
    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    archive: Path
    archive_sha256: str
    package_root: Path
    runnable: bool
    entry_command: tuple[str, ...] | None
    exclusion_diagnostic: str | None


def audit_human_pool(layout: AntWar2Layout) -> tuple[Opponent, ...]:
    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            # 统一 pool 的 manifest 含全部选手；只有带 rank 的（原精选榜单选手）
            # 作为人类池对手（有 Elo 锚点、role-balanced 评测）。
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            packages = tuple(sorted(layout.human_extracted_root.glob(f"rank{rank:02d}__*")))
            if len(packages) != 1:
                raise AntWar2RuntimeError(
                    f"rank{rank:02d} maps to {len(packages)} pool packages"
                )
            package = packages[0]
            # 选手代码即 pool 目录（自包含），archive_sha256 取目录树哈希，
            # 保证从干净 checkout 可复现。
            archive = package
            archive_sha256 = tree_sha256(package)
            entry_root = find_python_entry(package)
            runnable = entry_root is not None
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    archive=archive,
                    archive_sha256=archive_sha256,
                    package_root=package,
                    runnable=runnable,
                    entry_command=player_command() if runnable else None,
                    exclusion_diagnostic=(
                        None if runnable else "missing recursive public main.py entry point"
                    ),
                )
            )
    pool.sort(key=lambda item: item.rank)
    if [item.rank for item in pool] != list(range(1, len(pool) + 1)):
        raise AntWar2RuntimeError("human ranks must be contiguous from rank01")
    return tuple(pool)


def materialize_bootstrap(layout: AntWar2Layout, support_root: Path, destination: Path) -> None:
    """Copy only the public SDK and policy support; the Goal must create ai.py."""

    layout.validate()
    if destination.exists() and any(destination.iterdir()):
        raise AntWar2RuntimeError(f"bootstrap destination is not empty: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    for name in ("main.py", "common.py", "protocol.py"):
        source = support_root / name
        if not source.is_file():
            raise FileNotFoundError(source)
        shutil.copy2(source, destination / name)
    shutil.copytree(
        layout.public_sdk_root,
        destination / "SDK",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )

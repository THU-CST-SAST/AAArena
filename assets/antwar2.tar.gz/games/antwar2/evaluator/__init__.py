"""AntWar2 对战器 —— 满足 `aa_arena.core.Evaluator` 协议的可运行实现。

AntWar2 的游戏语义（编译后端、跑对局、解码回放、裁决胜负）是仓库 A 的资产。
本包对外暴露 `AntWar2Evaluator`，其 `evaluate(players, roles, seed) -> EvaluateResult`
严格遵循 `docs/evaluator-contract.md`：

- 定位并编译官方 C++ 后端（优先从已提交的源码树，可复现于全新 checkout）；
- 用长度前缀 stdio 协议驱动后端与两名 Python 选手完成一局；
- 解析回放，返回可解析、可复现的 `EvaluateResult`；
- 严格区分三态：编译/后端进程故障 = `infra_error`；选手超时/非法/崩溃 =
  `game_error`；正常终局 = `complete`。

B (HL) / C (RL) 通过 A 的统一入口 `evaluate("antwar2", ...)` 复用本实现，
不再各自维护对局裁决逻辑。
"""

from __future__ import annotations

import threading
from pathlib import Path

from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError, player_command
from aa_arena.core.player_entry import find_python_entry
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    AntWar2Arena,
    AntWar2MatchError,
    MatchCase,
    MatchResult,
    ProcessSpec,
    match_result_from_replay,
    run_native_match,
    write_public_trace,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    AntWar2Layout,
    CppBuildError,
    AntWar2RuntimeError,
    FrozenBackend,
    Opponent,
    audit_human_pool,
    build_backend,
    build_player,
    has_cpp_build,
    materialize_bootstrap,
    safe_extract,
    sha256_file,
    tree_sha256,
    validate_cached_backend,
)

__all__ = [
    "AntWar2Arena",
    "AntWar2Evaluator",
    "AntWar2Layout",
    "AntWar2MatchError",
    "AntWar2RuntimeError",
    "FrozenBackend",
    "MatchCase",
    "MatchResult",
    "Opponent",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "build_backend",
    "decode_replay",
    "make_evaluator",
    "match_result_from_replay",
    "materialize_bootstrap",
    "run_native_match",
    "safe_extract",
    "sha256_file",
    "tree_sha256",
    "validate_cached_backend",
    "write_public_trace",
]


# A benchmark process evaluates many seat-matches against one immutable game tree.
# Preparing that tree for every match needlessly re-hashes the backend and the full
# frozen human pool.  Keep the cache process-local: a fresh controller process still
# performs the complete validation once.
_RUNTIME_PREPARATION_LOCK = threading.RLock()
_PREPARED_BACKENDS: dict[tuple[Path, Path], FrozenBackend] = {}
_AUDITED_POOLS: dict[tuple[Path, Path], tuple[Opponent, ...]] = {}


def _layout_cache_key(layout: AntWar2Layout) -> tuple[Path, Path]:
    return (
        Path(layout.backend_source_root).resolve(),
        Path(layout.build_root).resolve(),
    )


def _prepare_backend(layout: AntWar2Layout) -> FrozenBackend:
    key = _layout_cache_key(layout)
    with _RUNTIME_PREPARATION_LOCK:
        cached = _PREPARED_BACKENDS.get(key)
        if cached is not None:
            return cached
        layout.validate()
        backend = build_backend(layout)
        _PREPARED_BACKENDS[key] = backend
        return backend


def _prepare_human_pool(layout: AntWar2Layout) -> tuple[Opponent, ...]:
    key = _layout_cache_key(layout)
    with _RUNTIME_PREPARATION_LOCK:
        cached = _AUDITED_POOLS.get(key)
        if cached is not None:
            return cached
        pool = audit_human_pool(layout)
        _AUDITED_POOLS[key] = pool
        return pool


def _resolve_player_root(
    player: PlayerRef,
    *,
    pool: tuple[Opponent, ...],
) -> Path:
    """把 PlayerRef 解析为一个自包含、可运行的选手目录（含 main.py）。"""

    if player.code_path is not None:
        root = Path(player.code_path).resolve()
        entry_root = find_python_entry(root)
        if entry_root is not None:
            return entry_root
        if has_cpp_build(root):
            return root
        raise AntWar2MatchError(f"player code path has no runnable entry: {root}")
    for opponent in pool:
        if opponent.opponent_id == player.player_id and opponent.runnable:
            entry_root = find_python_entry(opponent.package_root)
            if entry_root is not None:
                return entry_root
    raise AntWar2MatchError(
        f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
    )


class AntWar2Evaluator:
    """AntWar2 的对战器：给定两名选手、角色与种子，跑一局并返回契约结果。

    `game_dir` 指向 `games/antwar2/`，据此定位 A 仓库根（后端源码与人类池所在）
    以及产物构建目录。
    """

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        # games/<game>/ 上两级是 A 仓库根（后端源码 + 人类池所在）。
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "antwar2-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "antwar2-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"antwar2 requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"antwar2 roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = AntWar2Layout.from_root(self.aa_arena_root, self._build_root)

        # 后端在进程内只准备一次。MatchService 会为 candidate 与 opponent 都提供
        # 显式 code_path，此时无需扫描、哈希整个人类池；只有按 player_id 解析时才审计。
        try:
            backend = _prepare_backend(layout)
            pool = (
                _prepare_human_pool(layout)
                if any(player.code_path is None for player in players)
                else ()
            )
        except (AntWar2RuntimeError, PlayerEnvironmentError, FileNotFoundError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        # 解析两名选手到可运行目录：无法解析属基础设施/配置故障。
        try:
            player_roots = [_resolve_player_root(player, pool=pool) for player in players]
        except AntWar2MatchError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=str(exc),
            )

        # 以 players[0] 为 candidate、players[1] 为 opponent 组织一局。
        candidate_role = roles[0]
        candidate_id = players[0].player_id
        opponent_id = players[1].player_id
        opponent_root = player_roots[1]

        try:
            python_command = player_command()
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )

        def player_spec(player_root: Path) -> ProcessSpec:
            python_root = find_python_entry(player_root)
            if python_root is not None:
                return ProcessSpec(python_command, python_root)
            if has_cpp_build(player_root):
                executable = build_player(player_root, self._build_root / "players")
                return ProcessSpec((str(executable),), executable.parent)
            raise AntWar2RuntimeError(f"player has no runnable entry: {player_root}")

        try:
            candidate_process = player_spec(player_roots[0])
        except CppBuildError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=_other_role(candidate_role),
                diagnostic=f"candidate build failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"candidate build infrastructure failed: {exc}",
            )
        try:
            opponent_process = player_spec(opponent_root)
        except CppBuildError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=candidate_role,
                diagnostic=f"opponent build failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"opponent build infrastructure failed: {exc}",
            )

        arena = AntWar2Arena(
            game=ProcessSpec((str(backend.executable),), backend.executable.parents[1]),
            opponents={opponent_id: opponent_process},
            artifact_root=self._artifact_root,
            timeout_s=self.timeout_s,
        )
        case = MatchCase(candidate_id, opponent_id, candidate_role, seed)
        try:
            result = arena.run_case(case, candidate_process=candidate_process)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )

        if result.status != "complete":
            # 选手侧在规则框架内失败（超时/非法/崩溃）：按契约计 game_error。
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )

        return self._to_evaluate_result(result, roles, candidate_role)

    def _to_evaluate_result(
        self,
        result: MatchResult,
        roles: list[str],
        candidate_role: str,
    ) -> EvaluateResult:
        """把 arena 的候选视角 MatchResult 映射为角色绝对的 EvaluateResult。"""

        base_hp = result.payload.get("terminal_base_hp")
        if not (isinstance(base_hp, tuple) and len(base_hp) == 2):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing terminal_base_hp payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        # payload 的 terminal_base_hp 是绝对 (P0, P1) 顺序（回放 camps 语义）。
        p0_hp, p1_hp = float(base_hp[0]), float(base_hp[1])
        scores = {"P0": p0_hp, "P1": p1_hp}
        # candidate 视角的 win/loss 换算为绝对胜者角色。
        candidate_won = result.result == "win"
        winner = candidate_role if candidate_won else _other_role(candidate_role)

        replay_path = str(result.replay_path) if result.replay_path else None
        return EvaluateResult(
            status=EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=replay_path,
        )


def _other_role(role: str) -> str:
    return "P1" if role == "P0" else "P0"


def make_evaluator(game_dir: Path) -> AntWar2Evaluator:
    """插件工厂：供 `games/antwar2/plugin.py` 装配对战器。"""

    return AntWar2Evaluator(game_dir)

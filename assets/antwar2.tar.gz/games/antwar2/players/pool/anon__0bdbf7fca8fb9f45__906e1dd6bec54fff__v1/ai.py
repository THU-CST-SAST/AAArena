from __future__ import annotations

from dataclasses import replace
import os
from pathlib import Path

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.alphazero import PolicyValueNet, PriorGuidedMCTS, SearchConfig, infer_observation_dim
from SDK.utils.actions import ActionBundle
from SDK.utils.constants import MAX_ACTIONS, OperationType
from SDK.backend.state import BackendState
from SDK.utils.turns import DecisionContext


class MCTSAgent(BaseAgent):
    def __init__(
        self,
        iterations: int = 64,
        max_depth: int = 4,
        seed: int | None = None,
        max_actions: int = MAX_ACTIONS,
        model_path: str | os.PathLike[str] | None = None,
        c_puct: float = 1.25,
        prior_mix: float = 0.7,
        value_mix: float = 0.7,
    ) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self._base_iterations = iterations
        self._base_max_depth = max_depth
        self._base_c_puct = c_puct
        self._base_prior_mix = prior_mix
        self._base_value_mix = value_mix
        self.model = self._load_model(model_path)
        self._search_seed = seed or 0
        self._search_cache: dict[tuple[int, int, int, int, int, int, int], PriorGuidedMCTS] = {}
        self._base_search_config = SearchConfig(
            iterations=iterations,
            max_depth=max_depth,
            c_puct=c_puct,
            prior_mix=prior_mix,
            value_mix=value_mix,
            seed=self._search_seed,
        )
        self.search = self._search_for_config(self._base_search_config)

    def _candidate_model_paths(self, override: str | os.PathLike[str] | None) -> list[Path]:
        candidates: list[Path] = []
        if override is not None:
            candidates.append(Path(override))
            return candidates
        env_path = os.getenv("AGENT_TRADITION_MCTS_MODEL")
        if env_path:
            candidates.append(Path(env_path))
        module_root = Path(__file__).resolve().parent
        repo_root = module_root.parent
        candidates.extend(
            [
                module_root / "ai_mcts_model.npz",
                repo_root / "checkpoints" / "ai_mcts_latest.npz",
                repo_root / "SDK" / "checkpoints" / "ai_mcts_latest.npz",
            ]
        )
        return candidates

    def _load_model(self, model_path: str | os.PathLike[str] | None) -> PolicyValueNet | None:
        expected_obs_dim = infer_observation_dim(self.feature_extractor, self.catalog.max_actions)
        for candidate in self._candidate_model_paths(model_path):
            if not candidate.exists():
                continue
            try:
                model = PolicyValueNet.from_checkpoint(candidate)
            except (OSError, ValueError, KeyError):
                continue
            if model.action_dim != self.catalog.max_actions:
                continue
            if model.obs_dim != expected_obs_dim:
                continue
            return model
        return None

    def list_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        return self.catalog.build(state, player, context=DecisionContext.for_player(player), rerank=False)

    def _search_for_config(self, config: SearchConfig) -> PriorGuidedMCTS:
        cache_key = (
            int(config.iterations),
            int(config.max_depth),
            int(round(config.c_puct * 1000.0)),
            int(round(config.prior_mix * 1000.0)),
            int(round(config.value_mix * 1000.0)),
            int(config.root_action_limit),
            int(config.child_action_limit),
        )
        cached = self._search_cache.get(cache_key)
        if cached is not None:
            return cached
        search = PriorGuidedMCTS(
            model=self.model,
            search_config=config,
            feature_extractor=self.feature_extractor,
            action_catalog=self.catalog,
        )
        self._search_cache[cache_key] = search
        return search

    @staticmethod
    def _has_operation(bundle: ActionBundle, *op_types: OperationType) -> bool:
        op_values = {int(op_type) for op_type in op_types}
        return any(int(operation.op_type) in op_values for operation in bundle.operations)

    def _bundle_phase_bonus(
        self,
        bundle: ActionBundle,
        phase: str,
        summary: dict[str, float],
    ) -> float:
        bonus = 0.0
        tags = set(bundle.tags)
        under_pressure = summary["hp_delta"] < -4.0 or summary["enemy_progress"] > summary["my_progress"] + 4.0
        closing = summary["hp_delta"] > 4.0 or summary["my_progress"] > summary["enemy_progress"] + 6.0
        if phase == "growth":
            if "base" in tags:
                bonus += 3.0
            if "build" in tags or "upgrade" in tags:
                bonus += 2.4
            if "tempo" in tags:
                bonus += 1.5
            if "sell" in tags:
                bonus -= 3.5
            if "weapon" in tags:
                bonus -= 1.5
        elif phase == "defense":
            if "weapon" in tags:
                bonus += 2.8
            if "build" in tags or "upgrade" in tags:
                bonus += 1.8
            if "panic" in tags or "shield" in tags or "emp" in tags:
                bonus += 3.0
            if "tempo" in tags:
                bonus -= 1.5
            if "sell" in tags:
                bonus -= 5.0
        else:
            if "weapon" in tags:
                bonus += 2.4
            if "storm" in tags or "emp" in tags:
                bonus += 2.6
            if "offense" in tags:
                bonus += 1.4
            if "build" in tags:
                bonus -= 1.0
            if "tempo" in tags:
                bonus -= 2.0

        if self._has_operation(bundle, OperationType.USE_DEFLECTOR, OperationType.USE_EMERGENCY_EVASION) and under_pressure:
            bonus += 1.8
        if self._has_operation(bundle, OperationType.USE_LIGHTNING_STORM, OperationType.USE_EMP_BLASTER) and closing:
            bonus += 1.8
        if self._has_operation(bundle, OperationType.DOWNGRADE_TOWER):
            bonus -= 1.2
        if len(bundle.operations) > 1:
            bonus += 0.4
        return bonus

    def _bundle_priority(
        self,
        bundle: ActionBundle,
        phase: str,
        summary: dict[str, float],
    ) -> float:
        return float(bundle.score + self._bundle_phase_bonus(bundle, phase, summary))

    def _phase_for_state(self, summary: dict[str, float]) -> str:
        if summary["hp_delta"] < -5.0 or summary["enemy_progress"] > summary["my_progress"] + 5.0:
            return "defense"
        if summary["round_ratio"] >= 0.55 or summary["hp_delta"] > 5.0 or summary["my_progress"] > summary["enemy_progress"] + 7.0:
            return "finish"
        return "growth"

    def _filtered_bundles(
        self,
        bundles: list[ActionBundle],
        phase: str,
        summary: dict[str, float],
    ) -> list[ActionBundle]:
        if len(bundles) <= 8:
            return bundles
        ranked = sorted(bundles, key=lambda bundle: self._bundle_priority(bundle, phase, summary), reverse=True)
        keep_count = {
            "growth": min(20, len(ranked)),
            "defense": min(28, len(ranked)),
            "finish": min(24, len(ranked)),
        }[phase]
        selected: list[ActionBundle] = []
        seen_keys: set[tuple[tuple[int, int, int], ...]] = set()

        def add_bundle(candidate: ActionBundle) -> None:
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in candidate.operations)
            if key in seen_keys:
                return
            seen_keys.add(key)
            selected.append(candidate)

        for bundle in ranked[:keep_count]:
            add_bundle(bundle)
        for predicate in (
            lambda bundle: "noop" in bundle.tags,
            lambda bundle: "weapon" in bundle.tags,
            lambda bundle: "base" in bundle.tags,
            lambda bundle: "build" in bundle.tags or "upgrade" in bundle.tags,
        ):
            for bundle in ranked:
                if predicate(bundle):
                    add_bundle(bundle)
                    break
        return selected[: max(keep_count, min(8, len(selected)))] or bundles[:1]

    def _search_config_for_phase(self, phase: str, bundle_count: int) -> tuple[SearchConfig, float]:
        config = replace(self._base_search_config)
        if phase == "growth":
            config.iterations = max(self._base_iterations, 48)
            config.max_depth = max(3, min(self._base_max_depth, 4))
            config.c_puct = self._base_c_puct + 0.15
            config.prior_mix = max(self._base_prior_mix, 0.82)
            config.value_mix = min(self._base_value_mix, 0.55)
            config.root_action_limit = min(max(bundle_count, 12), 18)
            config.child_action_limit = min(10, max(6, bundle_count // 3))
            return config, 1e-6
        if phase == "defense":
            config.iterations = max(self._base_iterations, 96)
            config.max_depth = max(self._base_max_depth, 5)
            config.c_puct = self._base_c_puct + 0.25
            config.prior_mix = max(self._base_prior_mix, 0.75)
            config.value_mix = max(self._base_value_mix, 0.75)
            config.root_action_limit = min(max(bundle_count, 16), 24)
            config.child_action_limit = min(12, max(8, bundle_count // 2))
            return config, 1e-6
        config.iterations = max(self._base_iterations, 80)
        config.max_depth = max(self._base_max_depth, 5)
        config.c_puct = max(0.95, self._base_c_puct - 0.1)
        config.prior_mix = max(self._base_prior_mix, 0.72)
        config.value_mix = max(self._base_value_mix, 0.72)
        config.root_action_limit = min(max(bundle_count, 14), 20)
        config.child_action_limit = min(10, max(6, bundle_count // 2))
        return config, 1e-6

    def _prefer_heuristic_choice(
        self,
        bundles: list[ActionBundle],
        phase: str,
        summary: dict[str, float],
    ) -> bool:
        if len(bundles) <= 2:
            return True
        lead = self._bundle_priority(bundles[0], phase, summary)
        runner_up = self._bundle_priority(bundles[1], phase, summary)
        if lead - runner_up >= 7.5:
            return True
        if phase == "defense" and lead - runner_up >= 4.5 and self._has_operation(
            bundles[0],
            OperationType.USE_DEFLECTOR,
            OperationType.USE_EMERGENCY_EVASION,
            OperationType.USE_EMP_BLASTER,
        ):
            return True
        return False

    @staticmethod
    def _fallback_bundle(bundles: list[ActionBundle]) -> ActionBundle:
        if bundles:
            return bundles[0]
        return ActionBundle(name="hold", score=0.0, tags=("noop",))

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        bundles = bundles or self.list_bundles(state, player)
        if not bundles:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))
        context = DecisionContext.for_player(player)
        summary = self.feature_extractor.summarize(state, player, context=context).named
        phase = self._phase_for_state(summary)
        filtered = self._filtered_bundles(bundles, phase, summary)
        filtered = sorted(filtered, key=lambda bundle: self._bundle_priority(bundle, phase, summary), reverse=True)
        if self._prefer_heuristic_choice(filtered, phase, summary):
            return filtered[0]
        config, temperature = self._search_config_for_phase(phase, len(filtered))
        search = self._search_for_config(config)
        try:
            result = search.search(
                state=state,
                player=player,
                bundles=filtered,
                context=context,
                temperature=temperature,
                add_root_noise=False,
            )
        except Exception:
            return self._fallback_bundle(filtered)
        if result.bundle in filtered:
            return result.bundle
        return self._fallback_bundle(filtered)


class StrongMCTSAgent(MCTSAgent):
    def __init__(self, **kwargs) -> None:
        defaults = {
            "iterations": 80,
            "max_depth": 5,
            "c_puct": 1.15,
            "prior_mix": 0.78,
            "value_mix": 0.72,
        }
        defaults.update(kwargs)
        super().__init__(**defaults)


class AI(StrongMCTSAgent):
    pass

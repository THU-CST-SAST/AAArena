import math
import sys
import time
from typing import List, Dict, Tuple

try:
    from common import BaseAgent
except ModuleNotFoundError:
    from AI.common import BaseAgent

from SDK.backend.state import BackendState
from SDK.utils.actions import ActionBundle

class AI(BaseAgent):
    def __init__(self):
        super().__init__()
        # 核心评价权重
        self.W_HP = 5000.0        # 基地生命：绝对优先级
        self.W_COIN = 1.2         # 金币：资源储备
        self.W_TOWER_VAL = 200.0  # 塔的战略价值
        self.W_ANT_PROG = 8.0     # 蚂蚁推进权重
        self.W_DANGER = -15.0     # 火力网惩罚

        self.MAX_DEPTH = 2
        self.BRANCH_LIMIT = 5     # 搜索宽度

    def choose_bundle(self, state: BackendState, player: int, bundles: list[ActionBundle] | None = None) -> ActionBundle:
        turn_start_time = time.time()
        
        if bundles is None:
            bundles = self.list_bundles(state, player)
            
        # 1. 预处理：计算敌方火力图，用于后续快速评估
        danger_map = self._compute_danger_map(state, 1 - player)
        
        # 2. 硬规则过滤：剔除自杀式经济行为
        filtered_bundles = self._apply_hard_rules(state, bundles, player)
        
        # 3. 启发式排序：让高价值动作（如升级）优先搜索
        filtered_bundles.sort(key=lambda b: self._quick_eval(state, b, player), reverse=True)
        
        best_score = -math.inf
        alpha = -math.inf
        beta = math.inf
        best_bundle = filtered_bundles[0] if filtered_bundles else ActionBundle([])

        # 4. 限制宽度的 Alpha-Beta 搜索
        for bundle in filtered_bundles[:self.BRANCH_LIMIT]:
            if time.time() - turn_start_time > 0.80: # 严格时间管理，预留通信冗余
                break
            
            # 由于 Python 模拟结算太慢，我们采用“动作即时收益 + 静态盘面评估”
            score = self._evaluate_state(state, player, bundle, danger_map)
            
            if score > best_score:
                best_score = score
                best_bundle = bundle
            alpha = max(alpha, best_score)

        return best_bundle

    def _compute_danger_map(self, state: BackendState, enemy_player: int) -> Dict[Tuple[int, int], int]:
        """计算全图火力覆盖：坐标 -> 覆盖该格的敌塔数量"""
        d_map = {}
        for tower in state.towers_of(enemy_player):
            if tower.hp <= 0: continue
            # 根据塔的 range 获取覆盖范围
            # 简化处理：此处仅演示逻辑，实际可扩展为根据 range 计算格点
            # 假设所有塔射程内的格点都会受到威胁
            pass 
        return d_map

    def _apply_hard_rules(self, state: BackendState, bundles: List[ActionBundle], player: int) -> List[ActionBundle]:
        """经济与防御硬规则"""
        my_coins = state.coins[player]
        tower_count = len(state.towers_of(player))
        # 动态计算下一座塔的价格：15 * 2^n
        next_tower_cost = 15 * (2 ** tower_count)
        
        valid = []
        for b in bundles:
            keep = True
            # 规则 A：经济保护。如果金币不足 2 倍造塔钱且正在造新塔，除非塔极少，否则跳过
            if any(op.op_type == 11 for op in b.operations):
                if my_coins < next_tower_cost * 1.5 and tower_count > 3:
                    keep = False
            
            # 规则 B：基地升级强行保留。如果钱够升级生产线且动作里有升级，优先考虑
            if my_coins > 260 and any(op.op_type in [31, 32] for op in b.operations):
                # 这种 bundle 具有高优先度
                pass
                
            if keep: valid.append(b)
        return valid

    def _quick_eval(self, state: BackendState, bundle: ActionBundle, player: int) -> float:
        """动作即时价值预判"""
        score = 0.0
        for op in bundle.operations:
            if op.op_type in [31, 32]: score += 1000 # 基地升级最香
            if op.op_type == 12: score += 300        # 塔升级
            if op.op_type == 21: # 闪电风暴：如果敌军多则权重高
                score += 150
        return score

    def _evaluate_state(self, state: BackendState, player: int, bundle: ActionBundle, danger_map: dict) -> float:
        """深度评估：结合盘面状态与拟执行动作"""
        enemy = 1 - player
        
        # 1. 基础资源价值
        # 估算执行动作后的金币残余
        cost = sum([15*(2**len(state.towers_of(player))) if op.op_type==11 else 0 for op in bundle.operations])
        remaining_coins = state.coins[player] - cost
        
        v_base = (state.bases[player].hp - state.bases[enemy].hp) * self.W_HP
        v_coin = remaining_coins * self.W_COIN
        
        # 2. 防御建筑价值：高阶塔权重倍增
        v_tower = 0
        for t in state.towers_of(player):
            # 高级塔（如类型 11, 33）的 tower_type 较大
            multiplier = 3.0 if t.tower_type >= 10 else 1.0
            v_tower += t.hp * multiplier
            
        # 3. 蚂蚁战力与生存评估
        v_ant = 0
        enemy_base_pos = (state.bases[enemy].x, state.bases[enemy].y)
        for ant in state.ants_of(player):
            if ant.hp <= 0: continue
            dist = self._hex_dist(ant.x, ant.y, enemy_base_pos[0], enemy_base_pos[1])
            # 推进收益
            prog = (20 - dist) ** 2
            # 火力风险惩罚：如果蚂蚁所在格子在敌方火力图中，根据覆盖层数扣分
            danger_penalty = danger_map.get((ant.x, ant.y), 0) * self.W_DANGER
            v_ant += (prog + danger_penalty)
            
        return v_base + v_coin + (v_tower * self.W_TOWER_VAL) + (v_ant * self.W_ANT_PROG)

    def _hex_dist(self, x1, y1, x2, y2) -> int:
        """Even-q 坐标系到 Cube 坐标系的转换与求距"""
        q1, q2 = x1, x2
        r1, r2 = y1 - (x1-(x1&1))//2, y2 - (x2-(x2&1))//2
        return max(abs(q1-q2), abs(r1-r2), abs(-q1-r1 - (-q2-r2)))
#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
from typing import Any


OP_NAMES = {
    11: "build",
    12: "upgrade_tower",
    13: "downgrade",
    21: "storm",
    22: "emp",
    23: "deflector",
    24: "evasion",
    31: "upgrade_gen",
    32: "upgrade_ant",
}


def _op_type(op: dict[str, Any]) -> int | None:
    value = op.get("type")
    return int(value) if value is not None else None


def _tower_owner(row: dict[str, Any]) -> int | None:
    value = row.get("player")
    return int(value) if value is not None else None


def _tower_id(row: dict[str, Any]) -> str:
    return str(row.get("id"))


def analyze_replay(path: Path) -> dict[str, Any]:
    replay = json.loads(path.read_text(encoding="utf-8"))
    op_counts = [Counter(), Counter()]
    op_positions: list[Counter[tuple[int, int]]] = [Counter(), Counter()]
    live_towers: list[dict[str, dict[str, Any]]] = [{}, {}]
    tower_count_samples: list[tuple[int, int, int]] = []
    camp_samples: list[tuple[int, int, int]] = []

    for round_index, record in enumerate(replay):
        for player in (0, 1):
            for op in record.get(f"op{player}", []):
                op_type = _op_type(op)
                if op_type is None:
                    continue
                op_counts[player][op_type] += 1
                pos = op.get("pos") or {}
                x = pos.get("x")
                y = pos.get("y")
                if x is not None and y is not None and int(x) >= 0 and int(y) >= 0:
                    op_positions[player][(int(x), int(y))] += 1

        state = record.get("round_state", {})
        for tower in state.get("towers", []):
            owner = _tower_owner(tower)
            if owner not in (0, 1):
                continue
            if int(tower.get("type", -1)) == -1:
                live_towers[owner].pop(_tower_id(tower), None)
            else:
                live_towers[owner][_tower_id(tower)] = tower

        if round_index % 25 == 0 or round_index == len(replay) - 1:
            camps = state.get("camps", [-1, -1])
            camp_samples.append((round_index, int(camps[0]), int(camps[1])))
            tower_count_samples.append((round_index, len(live_towers[0]), len(live_towers[1])))

    final_state = replay[-1].get("round_state", {}) if replay else {}
    winner = int(final_state.get("winner", -1))
    final_camps = final_state.get("camps", [-1, -1])
    return {
        "file": str(path),
        "rounds": len(replay),
        "winner": winner,
        "final_camps": [int(final_camps[0]), int(final_camps[1])],
        "op_counts": [
            {OP_NAMES.get(key, str(key)): value for key, value in sorted(op_counts[player].items())}
            for player in (0, 1)
        ],
        "top_positions": [
            [{"pos": list(pos), "count": count} for pos, count in op_positions[player].most_common(8)]
            for player in (0, 1)
        ],
        "tower_count_samples": tower_count_samples,
        "camp_samples": camp_samples,
    }


def iter_paths(inputs: list[str]) -> list[Path]:
    paths: list[Path] = []
    for item in inputs:
        path = Path(item)
        if path.is_dir():
            paths.extend(sorted(path.glob("*.json")))
        else:
            paths.extend(sorted(Path().glob(item)))
    return paths


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize Ant Game replay JSON files")
    parser.add_argument("inputs", nargs="+", help="Replay files, globs, or directories")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON")
    args = parser.parse_args()

    summaries = [analyze_replay(path) for path in iter_paths(args.inputs)]
    if args.json:
        print(json.dumps(summaries, ensure_ascii=False, indent=2))
        return 0

    for summary in summaries:
        print(f"{summary['file']}: rounds={summary['rounds']} winner={summary['winner']} final_camps={summary['final_camps']}")
        for player in (0, 1):
            print(f"  player{player} ops={summary['op_counts'][player]} top_positions={summary['top_positions'][player]}")
        print(f"  camp_samples={summary['camp_samples']}")
        print(f"  tower_count_samples={summary['tower_count_samples']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

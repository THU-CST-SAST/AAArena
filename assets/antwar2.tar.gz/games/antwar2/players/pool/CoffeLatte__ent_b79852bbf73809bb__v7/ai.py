from __future__ import annotations

import time

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.backend.model import Operation, Tower
from SDK.backend.state import BackendState
from SDK.utils.actions import ActionBundle
from SDK.utils.constants import (
    AntBehavior,
    AntKind,
    OperationType,
    PLAYER_BASES,
    SUPER_WEAPON_STATS,
    SuperWeaponType,
    TowerType,
)
from SDK.utils.geometry import hex_distance
from SDK.utils.turns import DecisionContext


class StrategicAgent(BaseAgent):
    """Tournament agent with bounded two-stage search.

    The SDK owns legality and rule simulation. This agent first scores a broad
    candidate set with cheap tactical features, then spends a small fixed budget
    on one-step simulation for the best candidates.
    """

    TIME_BUDGET_SECONDS = 4.2
    MAX_HEURISTIC_CANDIDATES = 140
    MAX_ROLLOUT_CANDIDATES = 24

    OPENING_BUILD_BONUS = {
        0: {
            (5, 9): 6.0,
            (6, 9): 5.4,
            (5, 12): 3.2,
            (7, 8): 2.7,
            (7, 5): 2.4,
            (8, 7): 1.9,
        },
        1: {
            (13, 9): 6.0,
            (12, 9): 5.4,
            (11, 4): 3.8,
            (12, 7): 3.5,
            (12, 6): 3.0,
            (10, 8): 2.8,
            (10, 10): 2.6,
            (13, 11): 2.4,
            (14, 9): 2.2,
        },
    }

    def __init__(self, seed: int | None = None, max_actions: int = 96) -> None:
        super().__init__(seed=seed, max_actions=max_actions)

    def list_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        bundles = self.catalog.build(
            state,
            player,
            context=DecisionContext.for_player(player),
            rerank=False,
        )
        extra_bundles: list[ActionBundle] = []
        for factory_name in ("_superweapon_candidates", "_upgrade_candidates", "_base_upgrade_candidates"):
            factory = getattr(self.catalog, factory_name, None)
            if callable(factory):
                extra_bundles.extend(factory(state, player))

        unique: dict[tuple[tuple[int, int, int], ...], ActionBundle] = {}
        for bundle in (*bundles, *extra_bundles):
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in bundle.operations)
            current = unique.get(key)
            if current is None or bundle.score > current.score:
                unique[key] = bundle
        return sorted(unique.values(), key=self._candidate_prefilter_score, reverse=True)

    def _candidate_prefilter_score(self, bundle: ActionBundle) -> float:
        score = bundle.score
        for operation in bundle.operations:
            if operation.op_type in (
                OperationType.USE_LIGHTNING_STORM,
                OperationType.USE_EMP_BLASTER,
                OperationType.USE_DEFLECTOR,
                OperationType.USE_EMERGENCY_EVASION,
            ):
                score += 18.0
            elif operation.op_type == OperationType.UPGRADE_TOWER:
                score += 10.0
            elif operation.op_type in (OperationType.UPGRADE_GENERATION_SPEED, OperationType.UPGRADE_GENERATED_ANT):
                score += 7.0
            elif operation.op_type == OperationType.BUILD_TOWER:
                score += 4.0
            elif operation.op_type == OperationType.DOWNGRADE_TOWER:
                score -= 10.0
        return score

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        bundles = self.list_bundles(state, player) if bundles is None else bundles
        if not bundles:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))

        deadline = time.monotonic() + self.TIME_BUDGET_SECONDS
        metrics = self._metrics(state, player)
        scored: list[tuple[float, int, ActionBundle]] = []

        for index, bundle in enumerate(bundles[: min(len(bundles), self.MAX_HEURISTIC_CANDIDATES)]):
            if time.monotonic() >= deadline:
                break
            if not self._bundle_is_legal(state, player, bundle):
                continue
            score = self._score_bundle(state, player, bundle, index, metrics)
            scored.append((score, index, bundle))

        if not scored:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))

        scored.sort(key=lambda item: item[0], reverse=True)
        baseline = None
        reranked: list[tuple[float, int, ActionBundle]] = []
        for score, index, bundle in scored[: self.MAX_ROLLOUT_CANDIDATES]:
            if time.monotonic() >= deadline:
                reranked.append((score, index, bundle))
                continue
            if baseline is None:
                baseline = self.feature_extractor.evaluate(state, player)
            score += self._rollout_bonus(state, player, bundle, baseline)
            reranked.append((score, index, bundle))

        reranked.extend(scored[self.MAX_ROLLOUT_CANDIDATES :])
        reranked.sort(key=lambda item: (item[0], -item[1]), reverse=True)
        best_bundle = reranked[0][2]

        return best_bundle

    def _bundle_is_legal(self, state: BackendState, player: int, bundle: ActionBundle) -> bool:
        accepted: list[Operation] = []
        for operation in bundle.operations:
            if not state.can_apply_operation(player, operation, accepted):
                return False
            accepted.append(operation)
        return True

    def _score_bundle(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        index: int,
        metrics: dict[str, float],
    ) -> float:
        score = bundle.score
        score += self._operation_tactical_bonus(state, player, bundle, metrics)
        score += self._resource_timing_bonus(state, player, bundle, metrics)
        score -= index * 0.015
        return score

    def _rollout_bonus(self, state: BackendState, player: int, bundle: ActionBundle, baseline: float) -> float:
        trial = state.clone()
        illegal = trial.apply_operation_list(player, bundle.operations)
        if illegal:
            return -10000.0
        return (self.feature_extractor.evaluate(trial, player) - baseline) * 0.55

    def _metrics(self, state: BackendState, player: int) -> dict[str, float]:
        return {
            "pressure": self._defensive_pressure(state, player),
            "attack_momentum": self._attack_momentum(state, player),
            "enemy_near_base": self._enemy_near_base_count(state, player, radius=7),
            "friendly_near_enemy_base": self._friendly_near_enemy_base_count(state, player, radius=7),
            "tower_count": float(state.tower_count(player)),
            "enemy_tower_count": float(state.tower_count(1 - player)),
            "upgrade_count": float(sum(1 for tower in state.towers_of(player) if tower.tower_type != TowerType.BASIC)),
            "basic_count": float(sum(1 for tower in state.towers_of(player) if tower.tower_type == TowerType.BASIC)),
        }

    def _operation_tactical_bonus(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        metrics: dict[str, float],
    ) -> float:
        bonus = 0.0
        pressure = metrics["pressure"]
        attack_momentum = metrics["attack_momentum"]
        enemy_near_base = metrics["enemy_near_base"]
        friendly_near_enemy_base = metrics["friendly_near_enemy_base"]
        enemy = 1 - player

        for operation in bundle.operations:
            op_type = operation.op_type
            if op_type == OperationType.BUILD_TOWER:
                bonus += 1.0 + pressure * 1.3 + self._build_position_bonus(state, player, operation.arg0, operation.arg1)
                bonus += self._opening_build_bonus(state, player, operation.arg0, operation.arg1)
                bonus -= self._build_cluster_penalty(state, player, operation.arg0, operation.arg1)
                if enemy_near_base >= 2:
                    bonus += 2.0
            elif op_type == OperationType.UPGRADE_TOWER:
                tower = state.tower_by_id(operation.arg0)
                if tower is not None:
                    bonus += self._upgrade_bonus(state, player, tower, TowerType(operation.arg1), pressure)
                    if enemy_near_base >= 2 and hex_distance(PLAYER_BASES[player][0], PLAYER_BASES[player][1], tower.x, tower.y) <= 7:
                        bonus += 2.2
                    if metrics["upgrade_count"] < 3 and state.round_index >= 35:
                        bonus += 3.0
            elif op_type == OperationType.DOWNGRADE_TOWER:
                tower = state.tower_by_id(operation.arg0)
                if tower is not None:
                    local_pressure = self._enemy_pressure_near(state, player, tower.x, tower.y, radius=4)
                    bonus += -4.0 - local_pressure * 3.0 - tower.level * 2.0
                    if state.coins[player] < 20 and local_pressure < 0.5 and state.round_index < 120:
                        bonus += 3.0
            elif op_type == OperationType.UPGRADE_GENERATION_SPEED:
                bonus += 8.0 - state.round_index * 0.022
                if state.tower_count(player) >= 2:
                    bonus += 1.5
            elif op_type == OperationType.UPGRADE_GENERATED_ANT:
                bonus += 3.4 + min(attack_momentum, 4.0) * 0.5
            elif op_type in (
                OperationType.USE_LIGHTNING_STORM,
                OperationType.USE_EMP_BLASTER,
                OperationType.USE_DEFLECTOR,
                OperationType.USE_EMERGENCY_EVASION,
            ):
                bonus += self._weapon_bonus(state, player, enemy, operation, pressure, attack_momentum)
                if op_type in (OperationType.USE_DEFLECTOR, OperationType.USE_EMERGENCY_EVASION):
                    bonus += friendly_near_enemy_base * 0.7

        if not bundle.operations:
            if state.coins[player] >= 45 or pressure > 1.2 or enemy_near_base >= 2:
                bonus -= 2.0 + pressure * 4.5
            else:
                bonus -= 0.25
        return bonus

    def _resource_timing_bonus(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        metrics: dict[str, float],
    ) -> float:
        if not bundle.operations:
            return 0.0

        cost = self._bundle_net_cost(state, player, bundle)
        coins = state.coins[player]
        pressure = metrics["pressure"]
        tower_count = int(metrics["tower_count"])
        bonus = 0.0

        if cost > 0 and coins - cost < 0:
            return -1000.0
        if cost > 0 and coins - cost < 10 and pressure < 0.8:
            bonus -= 1.2
        if cost <= 0 and coins < 90 and pressure < 1.4:
            bonus += 1.2
        if any(op.op_type == OperationType.UPGRADE_GENERATION_SPEED for op in bundle.operations):
            if state.round_index < 80 and pressure < 2.5:
                bonus += 5.0
            elif state.round_index < 150:
                bonus += 1.2
        if any(op.op_type == OperationType.BUILD_TOWER for op in bundle.operations):
            if tower_count < 3:
                bonus += 4.5
            elif tower_count < 5 and state.round_index < 180:
                bonus += 2.0
            elif tower_count >= 6 and pressure < 1.0:
                bonus -= 2.4
            if coins - cost > 35:
                bonus += 1.0
        if any(op.op_type == OperationType.UPGRADE_TOWER for op in bundle.operations):
            if tower_count >= 2:
                bonus += 2.5
            if metrics["basic_count"] >= 2:
                bonus += 1.8
        if coins >= 70 and cost > 0:
            bonus += min(3.5, (coins - 60) * 0.05)
        return bonus

    def _bundle_net_cost(self, state: BackendState, player: int, bundle: ActionBundle) -> int:
        trial_count = state.tower_count(player)
        total = 0
        for operation in bundle.operations:
            if operation.op_type == OperationType.BUILD_TOWER:
                total += state.build_tower_cost(trial_count)
                trial_count += 1
            elif operation.op_type == OperationType.UPGRADE_TOWER:
                total += state.upgrade_tower_cost(TowerType(operation.arg1))
            elif operation.op_type == OperationType.DOWNGRADE_TOWER:
                total -= state.operation_income(player, operation, trial_count)
                tower = state.tower_by_id(operation.arg0)
                if tower is not None and tower.tower_type == TowerType.BASIC:
                    trial_count = max(0, trial_count - 1)
            elif operation.op_type in (
                OperationType.USE_LIGHTNING_STORM,
                OperationType.USE_EMP_BLASTER,
                OperationType.USE_DEFLECTOR,
                OperationType.USE_EMERGENCY_EVASION,
            ):
                weapon_type = SuperWeaponType(int(operation.op_type) - 20)
                total += SUPER_WEAPON_STATS[weapon_type].cost
            elif operation.op_type in (OperationType.UPGRADE_GENERATION_SPEED, OperationType.UPGRADE_GENERATED_ANT):
                level = state.bases[player].generation_level
                if operation.op_type == OperationType.UPGRADE_GENERATED_ANT:
                    level = state.bases[player].ant_level
                total += state.upgrade_base_cost(level)
        return total

    def _defensive_pressure(self, state: BackendState, player: int) -> float:
        base_x, base_y = PLAYER_BASES[player]
        total = 0.0
        for ant in state.ants_of(1 - player):
            distance = hex_distance(base_x, base_y, ant.x, ant.y)
            if distance > 9:
                continue
            weight = 1.0 + ant.level * 0.45
            if ant.kind == AntKind.COMBAT:
                weight += 0.8
            if ant.behavior in (AntBehavior.CONTROL_FREE, AntBehavior.CONSERVATIVE):
                weight += 0.25
            total += max(0.0, 9.5 - distance) * weight / 3.0
        return total

    def _attack_momentum(self, state: BackendState, player: int) -> float:
        enemy_base_x, enemy_base_y = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(player):
            distance = hex_distance(enemy_base_x, enemy_base_y, ant.x, ant.y)
            if distance > 8:
                continue
            weight = 1.0 + ant.level * 0.4
            if ant.kind == AntKind.COMBAT:
                weight += 0.9
            if ant.shield > 0 or ant.deflector:
                weight += 0.5
            total += max(0.0, 8.5 - distance) * weight / 3.0
        return total

    def _build_position_bonus(self, state: BackendState, player: int, x: int, y: int) -> float:
        base_x, base_y = PLAYER_BASES[player]
        center_bonus = state.slot_priority(player, x, y) * 0.3
        near_base = max(0.0, 6.0 - hex_distance(base_x, base_y, x, y)) * 0.25
        pressure = self._enemy_pressure_near(state, player, x, y, radius=5)
        return center_bonus + near_base + pressure * 0.7

    def _opening_build_bonus(self, state: BackendState, player: int, x: int, y: int) -> float:
        if state.round_index > 90:
            return 0.0
        bonus = self.OPENING_BUILD_BONUS[player].get((x, y), 0.0)
        if state.round_index > 35:
            bonus *= 0.45
        return bonus

    def _build_cluster_penalty(self, state: BackendState, player: int, x: int, y: int) -> float:
        penalty = 0.0
        for tower in state.towers_of(player):
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance <= 1:
                penalty += 1.8
            elif distance == 2:
                penalty += 0.55
        if state.round_index < 35:
            penalty *= 0.35
        return penalty

    def _enemy_near_base_count(self, state: BackendState, player: int, radius: int) -> float:
        base_x, base_y = PLAYER_BASES[player]
        return float(sum(1 for ant in state.ants_of(1 - player) if hex_distance(base_x, base_y, ant.x, ant.y) <= radius))

    def _friendly_near_enemy_base_count(self, state: BackendState, player: int, radius: int) -> float:
        base_x, base_y = PLAYER_BASES[1 - player]
        return float(sum(1 for ant in state.ants_of(player) if hex_distance(base_x, base_y, ant.x, ant.y) <= radius))

    def _upgrade_bonus(
        self,
        state: BackendState,
        player: int,
        tower: Tower,
        target: TowerType,
        pressure: float,
    ) -> float:
        local_pressure = self._enemy_pressure_near(state, player, tower.x, tower.y, radius=5)
        enemy_density = self._enemy_density_near(state, player, tower.x, tower.y, radius=3)
        bonus = 2.2 + tower.level * 0.8 + local_pressure * 1.0

        if target == TowerType.HEAVY:
            bonus += 2.2 + local_pressure * 0.5
        elif target == TowerType.QUICK:
            bonus += 1.2 + max(0.0, 3.5 - enemy_density) * 0.25
        elif target == TowerType.MORTAR:
            bonus += 3.0 + enemy_density * 1.1
        elif target == TowerType.PRODUCER:
            if state.round_index < 120 and pressure < 2.0:
                bonus += 4.0
            else:
                bonus += 0.8
        elif target in (TowerType.ICE, TowerType.BEWITCH, TowerType.PULSE):
            bonus += pressure * 0.9 + enemy_density * 0.8
        elif target in (TowerType.MORTAR, TowerType.MORTAR_PLUS, TowerType.MISSILE):
            bonus += 2.5 + enemy_density * 1.4
        elif target in (TowerType.QUICK, TowerType.QUICK_PLUS, TowerType.DOUBLE):
            bonus += max(0.0, 4.0 - enemy_density) * 0.3 + local_pressure * 0.5
        elif target == TowerType.SNIPER:
            bonus += max(0.0, 8.0 - self._nearest_enemy_ant_distance(state, player, tower.x, tower.y)) * 0.4
        elif target in (TowerType.PRODUCER, TowerType.PRODUCER_FAST, TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC):
            if pressure < 2.5:
                bonus += 3.0
            if target in (TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC):
                bonus += 1.5
        return bonus

    def _weapon_bonus(
        self,
        state: BackendState,
        player: int,
        enemy: int,
        operation: Operation,
        pressure: float,
        attack_momentum: float,
    ) -> float:
        weapon_type = SuperWeaponType(int(operation.op_type) - 20)
        x, y = operation.arg0, operation.arg1
        if weapon_type == SuperWeaponType.LIGHTNING_STORM:
            ant_value = 0.0
            for ant in state.ants_of(enemy):
                distance = hex_distance(x, y, ant.x, ant.y)
                if distance <= 3:
                    ant_value += 2.5 + ant.level * 1.0 + (1.3 if ant.kind == AntKind.COMBAT else 0.0)
                    if ant.hp <= 20:
                        ant_value += 1.8
                    ant_value += max(0.0, 3 - distance) * 0.35
            tower_value = sum(2.4 + tower.level * 1.4 for tower in state.towers_of(enemy) if hex_distance(x, y, tower.x, tower.y) <= 3)
            cluster_bonus = 2.5 if ant_value + tower_value >= 5.0 else 0.0
            return ant_value + tower_value + cluster_bonus + pressure * 0.35 - 1.0
        if weapon_type == SuperWeaponType.EMP_BLASTER:
            tower_hits = sum(1 + tower.level for tower in state.towers_of(enemy) if hex_distance(x, y, tower.x, tower.y) <= 3)
            return tower_hits * 3.2 + attack_momentum * 1.0 - 1.2
        if weapon_type == SuperWeaponType.DEFLECTOR:
            covered = self._covered_friendly_ants(state, player, x, y)
            return covered * 1.7 + attack_momentum * 0.9 - max(0.0, pressure - 3.0) * 0.4
        if weapon_type == SuperWeaponType.EMERGENCY_EVASION:
            covered = self._covered_friendly_ants(state, player, x, y)
            urgent = sum(
                1
                for ant in state.ants_of(player)
                if hex_distance(x, y, ant.x, ant.y) <= 3 and ant.hp * 2 <= ant.max_hp
            )
            return covered * 1.0 + urgent * 1.8 + attack_momentum * 0.7
        return 0.0

    def _enemy_pressure_near(self, state: BackendState, player: int, x: int, y: int, radius: int) -> float:
        total = 0.0
        for ant in state.ants_of(1 - player):
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance <= radius:
                total += (radius + 1 - distance) * (1.0 + ant.level * 0.35 + (0.6 if ant.kind == AntKind.COMBAT else 0.0))
        return total

    def _enemy_density_near(self, state: BackendState, player: int, x: int, y: int, radius: int) -> float:
        return float(sum(1 for ant in state.ants_of(1 - player) if hex_distance(x, y, ant.x, ant.y) <= radius))

    def _nearest_enemy_ant_distance(self, state: BackendState, player: int, x: int, y: int) -> int:
        return min((hex_distance(x, y, ant.x, ant.y) for ant in state.ants_of(1 - player)), default=99)

    def _covered_friendly_ants(self, state: BackendState, player: int, x: int, y: int) -> float:
        total = 0.0
        for ant in state.ants_of(player):
            if hex_distance(x, y, ant.x, ant.y) <= 3:
                total += 1.0 + ant.level * 0.35 + (0.7 if ant.kind == AntKind.COMBAT else 0.0)
        return total


class AI(StrategicAgent):
    pass

from __future__ import annotations

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.utils.actions import ActionBundle
from SDK.backend.state import BackendState


class SimpleAgent(BaseAgent):
    """
    Simple heuristic-based agent with no tree search.

    Extremely fast - just picks the best action based on heuristic scores.
    """

    def __init__(self, seed: int | None = None, max_actions: int = 96) -> None:
        super().__init__(seed=seed, max_actions=max_actions)

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        """Choose action based purely on heuristic scores."""
        bundles = bundles or self.list_bundles(state, player)
        if len(bundles) <= 1:
            return bundles[0] if bundles else ActionBundle(name="hold", score=0.0, tags=("noop",))

        # Get game state
        round_num = state.round_index
        my_hp = state.bases[player].hp
        enemy_hp = state.bases[1 - player].hp
        my_coins = state.coins[player]
        tower_count = state.tower_count(player)

        # Score adjustments
        best_bundle = bundles[0]
        best_score = -float('inf')

        for bundle in bundles[1:]:  # Skip noop
            score = bundle.score

            # Early game (0-150): prioritize economy and defense
            if round_num < 150:
                if "build" in bundle.tags:
                    score *= 1.3
                if "upgrade_generation" in bundle.tags:
                    score *= 1.2
                if tower_count < 5 and "build" in bundle.tags:
                    score *= 1.2

            # Mid game (150-400): balanced
            elif round_num < 400:
                if "upgrade" in bundle.tags:
                    score *= 1.15
                if "superweapon" in bundle.tags and my_coins > 200:
                    score *= 1.1
                if tower_count < 10 and "build" in bundle.tags:
                    score *= 1.1

            # Late game (400+): aggressive
            else:
                if "superweapon" in bundle.tags:
                    score *= 1.4
                if "upgrade_ant" in bundle.tags:
                    score *= 1.3
                if my_coins > 300:
                    if "upgrade" in bundle.tags or "superweapon" in bundle.tags:
                        score *= 1.2

            # HP-based adjustments
            hp_ratio = my_hp / max(enemy_hp, 1)

            if hp_ratio > 1.5:
                # Winning: be aggressive
                if "superweapon" in bundle.tags or "upgrade_ant" in bundle.tags:
                    score *= 1.25
            elif hp_ratio < 0.7:
                # Losing: focus defense
                if "build" in bundle.tags or "upgrade" in bundle.tags:
                    score *= 1.35
                if "superweapon" in bundle.tags and "deflector" in bundle.name.lower():
                    score *= 1.3

            # Resource management
            if my_coins > 250:
                if "upgrade" in bundle.tags or "superweapon" in bundle.tags:
                    score *= 1.15
            elif my_coins < 80:
                if "build" in bundle.tags or "upgrade" in bundle.tags:
                    score *= 0.8

            # Tower count management
            if tower_count > 15 and "build" in bundle.tags:
                score *= 0.7

            if score > best_score:
                best_score = score
                best_bundle = bundle

        return best_bundle


class AI(SimpleAgent):
    """Main AI class."""
    pass

from __future__ import annotations

import importlib.util
import itertools
import math
from pathlib import Path
import sys
import time
from typing import List, Optional, Sequence, Tuple

from SDK.backend.forecast import (
    MAX_ROUND,
    MAP_PROPERTY,
    Ant,
    AntState,
    BuildingType,
    ForecastOperation as Operation,
    ForecastSimulator as Simulator,
    ForecastState as GameInfo,
    OperationType,
    SuperWeaponType,
    Tower,
    TowerType,
    build_forecast_state,
    hex_distance as distance,
    is_valid_pos,
)
from SDK.utils.constants import ANT_AGE_LIMIT
from SDK.utils.constants import (
    BASE_HP,
    BASE_UPGRADE_COST,
    LEVEL2_TOWER_UPGRADE_COST,
    LEVEL3_TOWER_UPGRADE_COST,
    SUPER_WEAPON_STATS,
    TOWER_DOWNGRADE_REFUND_RATIO,
    TOWER_STATS,
    tower_build_cost_for_count,
)
from SDK.utils.geometry import is_path, neighbors

SEARCH_BUDGET = 0.15
MAX_NODE_COUNT = 20000
SEARCH_STAGING_ENEMY_BASE_HP = BASE_HP
EVALUATION_HORIZON = 60
TOWER_COUNT_SCORE = 1.0
BASE_ARC_TARGET_DEGREES = (-30.0, 0.0, 30.0)
BASE_ARC_TOLERANCE_DEGREES = 20.0
BASE_ARC_MISSING_PENALTY = 8.0
EMP_COST = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost
EMP_COOLDOWN = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cooldown
DEFLECTOR_COST = SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR].cost
EVASION_COST = SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].cost
EMP_BUFFER_CAP = max(EMP_COST - 1, 0)
LEVEL2_BASE_UPGRADE_COST, LEVEL3_BASE_UPGRADE_COST = BASE_UPGRADE_COST
LEVEL2_TOWER_TOTAL_COST = LEVEL2_TOWER_UPGRADE_COST
LEVEL3_TOWER_TOTAL_COST = LEVEL2_TOWER_UPGRADE_COST + LEVEL3_TOWER_UPGRADE_COST


def _total_build_investment(tower_count: int) -> int:
    return sum(tower_build_cost_for_count(index) for index in range(max(tower_count, 0)))


def _load_runtime_module():
    module_name = "_agent_tradition_ai_greedy_runtime"
    cached = sys.modules.get(module_name)
    if cached is not None:
        return cached
    module_path = Path(__file__).with_name("runtime.py")
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError("unable to load greedy runtime module")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module

SITE_LAYOUT = (
    (
        (2, 9),
        (4, 9),
        (5, 9),
        (5, 7),
        (6, 9),
        (5, 11),
        (5, 6),
        (6, 7),
        (6, 11),
        (5, 12),
        (4, 3),
        (5, 3),
        (7, 8),
        (7, 10),
        (4, 15),
        (5, 15),
        (4, 2),
        (6, 4),
        (7, 5),
        (8, 7),
        (8, 11),
        (7, 13),
        (6, 14),
        (4, 16),
        (6, 1),
        (6, 2),
        (6, 16),
        (6, 17),
        (7, 1),
        (8, 4),
        (8, 14),
        (7, 17),
        (8, 2),
        (8, 16),
        (3, 9),
    ),
    (
        (16, 9),
        (14, 9),
        (13, 9),
        (13, 7),
        (12, 9),
        (13, 11),
        (12, 6),
        (12, 7),
        (12, 11),
        (12, 12),
        (14, 3),
        (13, 3),
        (10, 8),
        (10, 10),
        (14, 15),
        (13, 15),
        (13, 2),
        (11, 4),
        (11, 5),
        (10, 7),
        (10, 11),
        (11, 13),
        (11, 14),
        (13, 16),
        (12, 1),
        (11, 2),
        (11, 16),
        (12, 17),
        (11, 1),
        (9, 4),
        (9, 14),
        (11, 17),
        (9, 2),
        (9, 16),
        (15, 9),
    ),
)

HOME_SLOT = 0
STORM_SLOT = 34
ACTIONABLE_SITES = (
    1,
    2,
    4,
    10,
    16,
    11,
    14,
    23,
    15,
    17,
    18,
    22,
    21,
    3,
    6,
    7,
    5,
    8,
    9,
    19,
    12,
    13,
    20,
    24,
    25,
    28,
    27,
    26,
    31,
)

SITE_FAMILIES = (
    (1, 2, 4),
    (3, 6, 7),
    (5, 8, 9),
    (10, 16, 11),
    (14, 23, 15),
    (19, 12, 13, 20),
    (17, 18),
    (22, 21),
    (24, 25, 28),
    (27, 26, 31),
    (32, 29),
    (30, 33),
)

SITE_TO_FAMILY = {}
for family in SITE_FAMILIES:
    for site in family:
        SITE_TO_FAMILY[site] = family


# Strategy parameters derived from cross-replay analysis of 8 winning pro matches.
# Memory: pro_replay_actionable_strategy.md, pro_replay_doorway_sniper.md.
TOWER_CAP = 3
CHASE_DEMOLISH_COOLDOWN = 4
CORNERSTONE_SITE = 1  # site index → (4,9) for p0, (14,9) for p1
CORNERSTONE_FAMILY = SITE_TO_FAMILY[CORNERSTONE_SITE]  # reserve for the cornerstone scheduler
CORNERSTONE_START_ROUND = 100  # earliest round we'll commit to the chain
CORNERSTONE_SAVE_ROUND = 80    # from this round, freeze non-cornerstone builds
                                # so the chain savings can accumulate
BUILD_DIST_RANGE = (4, 7)
STORM_MIN_ENEMIES_R3 = 3
STORM_SAVE_THRESHOLD = 5  # while saving for Sniper, cluster size required to cast
HEAL_HP_THRESHOLD = 4  # Basic hp at or below this → upgrade to Heavy to heal+strengthen
STORM_DEFENSIVE_DOWN_BIAS = 6  # tiebreak prefers cells with d_own_base ≤ this
SWARM_NEAR_DOORWAY_RADIUS = 4
SWARM_TRIGGER_COUNT = 2
COMPANION_DOORWAY_RADIUS = 2
COMPANION_DOWN_RANGE = (3, 5)

# Site indices ordered by replay frequency (cornerstone site 1 excluded since
# `_try_cornerstone_sniper` owns it).
HOT_HEX_SITES_BY_SIDE = (
    # p0: (5,7), (5,6), (5,11), (5,12), (6,7), (6,11), (4,16), (8,11), (8,2), (6,16)
    (3, 6, 5, 9, 7, 8, 23, 20, 32, 26),
    # p1: (12,7), (12,9), (12,11), (12,12), (13,7), (13,11), (10,8), (10,10), (10,11), (9,16)
    (7, 4, 8, 9, 3, 5, 12, 13, 20, 33),
)


class ForecastNode:
    def __init__(self, brain: AI, sim: Simulator) -> None:
        self.brain = brain
        self.sim = sim.clone()
        self.node_id = -1
        self.parent = -1
        self.children: List[int] = []
        self.chosen: List[Operation] = []
        self.score = 0.0
        self.best_descendant = 0.0
        self.round_tag = self.sim.info.round
        self.sunk_cost = 0.0
        self.best_depth = 0
        self.expanded_layers = 0
        self.collapse_round = 0
        self.danger = False
        self.solvent = True
        self.distance_trace = [0] * EVALUATION_HORIZON

    @property
    def action_count(self) -> int:
        return len(self.chosen)

    def _record_hostile_distance(self, info: GameInfo) -> None:
        brain = self.brain
        trace_idx = info.round - brain.current_round
        if 0 <= trace_idx < EVALUATION_HORIZON:
            self.distance_trace[trace_idx] = brain._nearest_hostile_step(info)

    def _advance_trial_until_hp_drop(self, trial: Simulator, hp_drop: int) -> int:
        info = trial.info
        brain = self.brain
        horizon = brain.current_round + EVALUATION_HORIZON
        for turn in range(info.round, horizon):
            if not trial.fast_next_round(brain.side):
                break
            self.distance_trace[turn - brain.current_round] = brain._nearest_hostile_step(info)
            if info.bases[brain.side].hp <= brain.wall_hp_snapshot - hp_drop:
                return info.round
        return horizon

    def _forecast_ruin_round(self, trial: Simulator) -> int:
        info = trial.info
        brain = self.brain
        horizon = brain.current_round + EVALUATION_HORIZON
        ruin_round = horizon
        if info.bases[brain.side].hp <= brain.wall_hp_snapshot - 1:
            ruin_round = self.collapse_round
        else:
            self.collapse_round = self._advance_trial_until_hp_drop(trial, 1)
            if info.bases[brain.side].hp <= brain.wall_hp_snapshot - 2:
                ruin_round = self.collapse_round
        if info.bases[brain.side].hp > brain.wall_hp_snapshot - 2:
            ruin_round = self._advance_trial_until_hp_drop(trial, 2)
        return ruin_round

    def _safe_gap(self, info: GameInfo) -> int:
        brain = self.brain
        if brain.current_round <= 60:
            self.solvent = True
            return 0
        safe_gap = brain._cash_safety_gap(info)
        self.solvent = safe_gap == 0
        return safe_gap

    def _score_survival_window(self, info: GameInfo, ruin_round: int) -> float:
        brain = self.brain
        return (
            (info.bases[brain.side].hp - brain.wall_hp_snapshot)
            + (self.collapse_round - brain.current_round) * 0.8
            + (ruin_round - self.collapse_round) * 0.1
            - self.sunk_cost * 1.5
            + 20
        )

    def _score_frontline_trades(self, info: GameInfo) -> float:
        brain = self.brain
        if brain.front_state != 0:
            return 0.0
        ant_weight = {0: 3.0, 1: 5.0, 2: 7.0}[info.bases[1 - brain.side].ant_level]
        return (
            -(info.old_count[1 - brain.side] - brain.enemy_old_baseline) * ant_weight * 2
            + (info.die_count[1 - brain.side] - brain.enemy_die_baseline) * ant_weight * 1.5
        )

    def _score_danger_window(self, ruin_round: int) -> float:
        brain = self.brain
        self.danger = False
        if self.collapse_round - brain.current_round > 16:
            return 0.0
        self.danger = True
        score = -500.0
        if ruin_round - self.collapse_round <= 8:
            score -= 300.0
        return score

    def _score_cash_safety(self, safe_gap: int) -> float:
        brain = self.brain
        if self.solvent or self.danger or brain.front_state < 0:
            return 0.0
        return (-40 + safe_gap / 5) * min((brain.current_round - 60) / 30, 1)

    def _my_towers(self, info: GameInfo) -> List[Tower]:
        return [tower for tower in info.towers if tower.player == self.brain.side]

    def _score_tower_count(self, tower_count: int) -> float:
        return tower_count * TOWER_COUNT_SCORE

    def _score_tower_investment(self, towers: Sequence[Tower]) -> float:
        tower_count = len(towers)
        score = -_total_build_investment(tower_count) * 0.2 * 0.75
        for tower in towers:
            if 0 < int(tower.type) and int(tower.type) // 10 == 0:
                score -= LEVEL2_TOWER_TOTAL_COST * 0.2 * 0.75
            elif int(tower.type) // 10 > 0:
                score -= LEVEL3_TOWER_TOTAL_COST * 0.2 * 0.75
        return score

    def _score_tower_spacing(self, towers: Sequence[Tower]) -> float:
        tower_count = len(towers)
        if tower_count <= 1:
            return 0.0

        penalty = 0.0
        distanced = False
        for idx, tower in enumerate(towers[:-1]):
            for other in towers[idx + 1 :]:
                gap = distance(tower.x, tower.y, other.x, other.y)
                if gap <= 3:
                    penalty += 5
                elif gap <= 6:
                    penalty += 2
                else:
                    distanced = True

        if tower_count >= 3 and not distanced:
            penalty += 20
        return -penalty / math.sqrt(tower_count)

    def _score_tower_advancement(self, towers: Sequence[Tower], info: GameInfo) -> float:
        base = info.bases[self.brain.side]
        return sum(distance(tower.x, tower.y, base.x, base.y) * 0.4 for tower in towers)

    @staticmethod
    def _world_pos(x: int, y: int) -> Tuple[float, float]:
        return x + 0.5 * (y & 1), y * math.sqrt(3) / 2

    @staticmethod
    def _angle_delta(angle: float, target: float) -> float:
        return (angle - target + math.pi) % (2 * math.pi) - math.pi

    def _score_base_arc_coverage(self, towers: Sequence[Tower], info: GameInfo) -> float:
        base = info.bases[self.brain.side]
        enemy_base = info.bases[1 - self.brain.side]
        base_x, base_y = self._world_pos(base.x, base.y)
        enemy_x, enemy_y = self._world_pos(enemy_base.x, enemy_base.y)
        forward_angle = math.atan2(enemy_y - base_y, enemy_x - base_x)
        tolerance = math.radians(BASE_ARC_TOLERANCE_DEGREES)
        covered = {target: False for target in BASE_ARC_TARGET_DEGREES}

        for tower in towers:
            tower_x, tower_y = self._world_pos(tower.x, tower.y)
            angle = math.atan2(tower_y - base_y, tower_x - base_x)
            if abs(self._angle_delta(angle, forward_angle)) > math.pi / 2:
                continue
            for target in BASE_ARC_TARGET_DEGREES:
                target_angle = forward_angle + math.radians(target)
                if abs(self._angle_delta(angle, target_angle)) <= tolerance:
                    covered[target] = True

        missing = sum(1 for is_covered in covered.values() if not is_covered)
        return -missing * BASE_ARC_MISSING_PENALTY

    def _score_hostile_distance_trace(self, info: GameInfo) -> float:
        brain = self.brain
        if brain.front_state < 0:
            return 0.0

        score = 0.0
        close_flag = False
        for idx in range(min(EVALUATION_HORIZON, info.round - brain.current_round - 4)):
            if self.distance_trace[idx] <= 3:
                close_flag = True
            if self.distance_trace[idx] == 5:
                score -= 0.2
            elif self.distance_trace[idx] == 4:
                score -= 2.5
            elif self.distance_trace[idx] in (1, 2, 3):
                score -= 2
        if close_flag:
            score -= 20
        return score

    def _score_enemy_pressure(self, info: GameInfo) -> float:
        brain = self.brain
        if brain.front_state < 0 or brain.current_round < 20:
            return 0.0

        base = info.bases[brain.side]
        enemy_count = 0
        pressure = 0.0
        for ant in info.ants:
            if ant.player != 1 - brain.side:
                continue
            pressure += ANT_AGE_LIMIT - ant.age - distance(ant.x, ant.y, base.x, base.y) * 1.5
            enemy_count += 1
        if enemy_count == 0:
            return 0.0
        return pressure / enemy_count * 0.5

    def evaluate(self) -> float:
        trial = self.sim.clone()
        info = trial.info
        self._record_hostile_distance(info)
        safe_gap = self._safe_gap(info)
        ruin_round = self._forecast_ruin_round(trial)
        my_towers = self._my_towers(info)

        score = 0.0
        score += self._score_survival_window(info, ruin_round)
        score += self._score_frontline_trades(info)
        score += self._score_danger_window(ruin_round)
        score += self._score_cash_safety(safe_gap)
        score += self._score_tower_count(len(my_towers))
        score += self._score_tower_investment(my_towers)
        score += self._score_tower_spacing(my_towers)
        score += self._score_tower_advancement(my_towers, info)
        score += self._score_base_arc_coverage(my_towers, info)
        score += self._score_hostile_distance_trace(info)
        score += self._score_enemy_pressure(info)

        self.score = score
        self.best_descendant = score
        return score

    def expand(self, is_root: bool = False) -> None:
        brain = self.brain
        info = self.sim.info
        if info.round >= MAX_ROUND or info.bases[brain.side].hp <= 0 or info.bases[1 - brain.side].hp <= 0:
            return

        if not is_root:
            if info.round - brain.current_round < EVALUATION_HORIZON:
                self.distance_trace[info.round - brain.current_round] = brain._nearest_hostile_step(info)
            if not self.sim.fast_next_round(brain.side):
                return

        emp_blocked = [False] * 34
        for weapon in self.sim.info.super_weapons:
            if weapon.player == 1 - brain.side and weapon.type == SuperWeaponType.EMP_BLASTER:
                for site in range(34):
                    sx, sy = SITE_LAYOUT[brain.side][site]
                    if distance(weapon.x, weapon.y, sx, sy) <= 3:
                        emp_blocked[site] = True
                break

        bundles: List[List[Operation]] = []
        for tactic in range(8):
            if tactic == 1:  # skip tower upgrades entirely
                continue
            if self.action_count > 0 and tactic in (3, 5):
                continue
            if (
                self.action_count == 1
                and self.chosen[0].type == OperationType.BUILD_TOWER
                and self.expanded_layers < 2
                and tactic in (3, 4, 6)
            ):
                continue
            if (
                self.action_count == 1
                and self.chosen[0].type == OperationType.UPGRADE_TOWER
                and self.expanded_layers < 2
                and tactic == 2
            ):
                continue
            if (
                self.action_count == 2
                and self.chosen[1].type == OperationType.BUILD_TOWER
                and self.expanded_layers < 2
                and tactic in (3, 4, 6)
            ):
                continue
            if self.sim.info.tower_num_of_player(brain.side) >= 4 and tactic in (0, 2):
                continue
            bundles.extend(brain._candidate_bundles(tactic, self.sim.info, emp_blocked))

        if is_root:
            idle = ForecastNode(brain, self.sim)
            idle.node_id = len(brain.nodes)
            idle.parent = self.node_id
            idle.evaluate()
            brain.nodes.append(idle)
            self.children.append(idle.node_id)

        for bundle in bundles:
            if len(brain.nodes) >= MAX_NODE_COUNT - 10:
                break
            child = ForecastNode(brain, self.sim)
            child.node_id = len(brain.nodes)
            child.parent = self.node_id
            child.sunk_cost = self.sunk_cost
            child.chosen = list(bundle)
            child.collapse_round = self.collapse_round
            child.score = -1e9
            child.best_descendant = -1e9
            if self.sim.info.round > brain.current_round:
                trace_len = min(EVALUATION_HORIZON, self.sim.info.round - brain.current_round)
                child.distance_trace[:trace_len] = self.distance_trace[:trace_len]
            child.sim.operations[0].clear()
            child.sim.operations[1].clear()
            mutable = child.sim.info
            for op in bundle:
                if op.type == OperationType.DOWNGRADE_TOWER:
                    tower = brain._tower_by_id(op.arg0, mutable)
                    if tower is not None:
                        if tower.type == TowerType.BASIC:
                            child.sunk_cost += mutable.build_tower_cost(mutable.tower_num_of_player(brain.side)) * 0.2
                        else:
                            child.sunk_cost += mutable.upgrade_tower_cost(int(tower.type)) * 0.2
                child.sim.add_operation_of_player(brain.side, op)
            child.sim.apply_operations_of_player(brain.side)
            value = child.evaluate()
            if value > self.best_descendant:
                self.best_descendant = value
                self.best_depth = self.expanded_layers + 1
            brain.nodes.append(child)
            self.children.append(child.node_id)

        if is_root and not self.sim.fast_next_round(brain.side):
            return
        self.expanded_layers += 1


class AI:
    def __init__(self) -> None:
        self.side = 0
        self.current_round = 0
        self.front_state = 0
        self.wall_hp_snapshot = 0
        self.enemy_old_baseline = 0
        self.enemy_die_baseline = 0
        self.assault_memory = False
        self.last_superweapon_type: Optional[SuperWeaponType] = None
        self.last_superweapon_round = -1
        self.reserve_depth = 0
        self.nodes: List[ForecastNode] = []
        self.last_chase_demolish_round = -100
        self.cornerstone_tower_id: Optional[int] = None
        self.cornerstone_phase = 0  # 0=not built, 1=Basic, 2=Quick, 3=Sniper
        self.pending_upgrade: dict = {}

    def choose_bundle(self, state, player: int, bundles):
        """Match greedy AI output to one of the available action bundles."""
        game_info = build_forecast_state(state)
        ops = self(player, game_info)
        for i, bundle in enumerate(bundles):
            if len(bundle.operations) == len(ops):
                match = True
                for want, have in zip(ops, bundle.operations):
                    if int(want.type) != int(have.op_type) or int(want.arg0) != have.arg0 or int(want.arg1) != have.arg1:
                        match = False
                        break
                if match:
                    return bundle
        # Fallback: return first bundle
        return bundles[0] if bundles else None

    def create_session(self):
        return _load_runtime_module().GreedySession(self)

    def _mark_super(self, weapon_type: SuperWeaponType) -> None:
        self.last_superweapon_round = self.current_round
        self.last_superweapon_type = weapon_type

    def _tower_at(self, x: int, y: int, info: GameInfo) -> Optional[Tower]:
        for tower in info.towers:
            if tower.x == x and tower.y == y:
                return tower
        return None

    def _tower_by_id(self, tower_id: int, info: GameInfo) -> Optional[Tower]:
        return info.tower_of_id(tower_id)

    def _nearest_push_distance(self, info: GameInfo) -> int:
        best = 100
        tx, ty = SITE_LAYOUT[1 - self.side][HOME_SLOT]
        for ant in info.ants:
            if ant.player == self.side:
                best = min(best, distance(ant.x, ant.y, tx, ty))
        return best

    def _opponent_emp_buffer(self, info: GameInfo) -> int:
        cd = info.super_weapon_cd[1 - self.side][int(SuperWeaponType.EMP_BLASTER)]
        if cd >= EMP_COOLDOWN - 10:
            return 0
        if cd > 0:
            return max(int(min(info.coins[1 - self.side], EMP_BUFFER_CAP) - cd * 1.66), 0)
        return min(info.coins[1 - self.side], EMP_BUFFER_CAP)

    def _max_future_liquidation_coins(
        self,
        info: GameInfo,
        operations: Sequence[Operation],
    ) -> int:
        trial = info.clone()
        for op in operations:
            trial.apply_operation(self.side, op)
        while True:
            tower_ids = [
                tower.id
                for tower in trial.towers
                if tower.player == self.side and not trial.tower_under_emp(tower)
            ]
            if not tower_ids:
                break
            progressed = False
            for tower_id in tower_ids:
                tower = trial.tower_of_id(tower_id)
                if tower is None:
                    continue
                trial.apply_operation(self.side, Operation(OperationType.DOWNGRADE_TOWER, tower_id))
                progressed = True
            if not progressed:
                break
        return trial.coins[self.side]

    def _cash_safety_gap(self, info: GameInfo) -> int:
        return min(0, info.coins[self.side] - self._opponent_emp_buffer(info))

    def _nearest_hostile_step(self, info: GameInfo) -> int:
        best = 32
        tx, ty = SITE_LAYOUT[self.side][HOME_SLOT]
        for ant in info.ants:
            if ant.player == 1 - self.side:
                best = min(best, distance(ant.x, ant.y, tx, ty))
        return best

    def _site_operation(
        self,
        site: int,
        mode: int,
        info: GameInfo,
        coins: int,
        towers: int,
        upgrade_branch: int = 0,
        exempt_site: int = -1,
    ) -> Tuple[Optional[Operation], int, int]:
        x, y = SITE_LAYOUT[self.side][site]

        if mode == 1:
            cost = info.build_tower_cost(towers)
            if coins < cost:
                return None, coins, towers
            for peer in SITE_TO_FAMILY[site]:
                if peer == exempt_site:
                    continue
                px, py = SITE_LAYOUT[self.side][peer]
                if info.building_tag[px][py] != BuildingType.EMPTY:
                    return None, coins, towers
            return Operation(OperationType.BUILD_TOWER, x, y), coins - cost, towers + 1

        if mode == 2:
            if info.building_tag[x][y] == BuildingType.EMPTY:
                return None, coins, towers
            tower = self._tower_at(x, y, info)
            if tower is None or int(tower.type) // 10 > 0:
                return None, coins, towers

            target: Optional[TowerType] = None
            if tower.type == TowerType.BASIC:
                target = (TowerType.HEAVY, TowerType.MORTAR, TowerType.QUICK)[upgrade_branch]
            elif tower.type == TowerType.HEAVY:
                target = (TowerType.HEAVY_PLUS, TowerType.BEWITCH, TowerType.ICE)[upgrade_branch]
            elif tower.type == TowerType.MORTAR:
                target = (TowerType.MORTAR_PLUS, TowerType.MISSILE, TowerType.PULSE)[upgrade_branch]
            elif tower.type == TowerType.QUICK:
                target = (TowerType.QUICK_PLUS, TowerType.DOUBLE, TowerType.SNIPER)[upgrade_branch]

            if target is None:
                return None, coins, towers
            cost = info.upgrade_tower_cost(int(target))
            if coins < cost:
                return None, coins, towers
            return Operation(OperationType.UPGRADE_TOWER, tower.id, int(target)), coins - cost, towers

        if mode == 3:
            if info.building_tag[x][y] == BuildingType.EMPTY:
                return None, coins, towers
            tower = self._tower_at(x, y, info)
            if tower is None or tower.type != TowerType.BASIC:
                return None, coins, towers
            refund = info.destroy_tower_income(towers)
            return Operation(OperationType.DOWNGRADE_TOWER, tower.id), coins + refund, towers - 1

        if mode == 4:
            if info.building_tag[x][y] == BuildingType.EMPTY:
                return None, coins, towers
            tower = self._tower_at(x, y, info)
            if tower is None or tower.type == TowerType.BASIC:
                return None, coins, towers
            refund = info.downgrade_tower_income(int(tower.type))
            return Operation(OperationType.DOWNGRADE_TOWER, tower.id), coins + refund, towers

        return None, coins, towers

    def _candidate_bundles(self, tactic: int, info: GameInfo, emp_blocked: Sequence[bool]) -> List[List[Operation]]:
        bundles: List[List[Operation]] = []

        # Reserve the cornerstone slot (site 1) from any tree-search action so
        # the cornerstone scheduler can drive Basic→Quick→Sniper without being
        # demolished or re-upgraded by the search.
        cornerstone_locked = True

        # While saving for the cornerstone chain, suppress tactics that would
        # spend on new builds (tactics 0 and 2 grow the tower count).
        saving = self._saving_for_cornerstone(info)
        if saving and tactic in (0, 2):
            return bundles

        if tactic == 0:
            if info.tower_num_of_player(self.side) >= TOWER_CAP:
                return bundles
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if site in CORNERSTONE_FAMILY:
                    continue  # reserved for the cornerstone scheduler
                op, _, _ = self._site_operation(site, 1, info, info.coins[self.side], info.tower_num_of_player(self.side))
                if op is not None:
                    bundles.append([op])
        elif tactic == 1:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                for branch in range(3):
                    op, _, _ = self._site_operation(
                        site,
                        2,
                        info,
                        info.coins[self.side],
                        info.tower_num_of_player(self.side),
                        branch,
                    )
                    if op is not None:
                        bundles.append([op])
        elif tactic == 2:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                head, coins, towers = self._site_operation(
                    site,
                    4,
                    info,
                    info.coins[self.side],
                    info.tower_num_of_player(self.side),
                )
                if head is None:
                    continue
                if towers >= TOWER_CAP:
                    continue
                for site2 in ACTIONABLE_SITES:
                    if emp_blocked[site2] or site2 == site:
                        continue
                    if site2 in CORNERSTONE_FAMILY:
                        continue  # reserved for the cornerstone scheduler
                    tail, _, _ = self._site_operation(site2, 1, info, coins, towers)
                    if tail is not None:
                        bundles.append([head, tail])
        elif tactic == 3:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                op, _, _ = self._site_operation(site, 3, info, info.coins[self.side], info.tower_num_of_player(self.side))
                if op is not None:
                    bundles.append([op])
        elif tactic == 4:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                head, coins, towers = self._site_operation(
                    site,
                    3,
                    info,
                    info.coins[self.side],
                    info.tower_num_of_player(self.side),
                )
                if head is None:
                    continue
                for site2 in ACTIONABLE_SITES:
                    if emp_blocked[site2] or site2 == site:
                        continue
                    for branch in range(3):
                        tail, _, _ = self._site_operation(site2, 2, info, coins, towers, branch)
                        if tail is not None:
                            bundles.append([head, tail])
        elif tactic == 5:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                op, _, _ = self._site_operation(site, 4, info, info.coins[self.side], info.tower_num_of_player(self.side))
                if op is not None:
                    bundles.append([op])
        elif tactic == 6:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                head, coins, towers = self._site_operation(
                    site,
                    3,
                    info,
                    info.coins[self.side],
                    info.tower_num_of_player(self.side),
                )
                if head is None:
                    continue
                for site2 in ACTIONABLE_SITES:
                    if emp_blocked[site2] or site2 == site:
                        continue
                    if site2 in CORNERSTONE_FAMILY and site not in CORNERSTONE_FAMILY:
                        continue  # don't pivot a non-cornerstone slot into cornerstone family
                    tail, _, _ = self._site_operation(site2, 1, info, coins, towers, exempt_site=site)
                    if tail is not None:
                        bundles.append([head, tail])
        elif tactic == 7:
            for site in ACTIONABLE_SITES:
                if emp_blocked[site]:
                    continue
                if cornerstone_locked and site == CORNERSTONE_SITE:
                    continue
                head, coins, towers = self._site_operation(
                    site,
                    4,
                    info,
                    info.coins[self.side],
                    info.tower_num_of_player(self.side),
                )
                if head is None:
                    continue
                for site2 in ACTIONABLE_SITES:
                    if emp_blocked[site2] or site2 == site:
                        continue
                    for branch in range(3):
                        tail, _, _ = self._site_operation(site2, 2, info, coins, towers, branch)
                        if tail is not None:
                            bundles.append([head, tail])

        return bundles

    def _expand_one(self) -> bool:
        root = self.nodes[0]
        if not root.children:
            return False

        target_id = -1
        best = -1e9
        for child_id in root.children:
            child = self.nodes[child_id]
            value = -child.expanded_layers
            if child_id == 0:
                value += self.reserve_depth
            if not child.children:
                value += 1000
            if child.danger:
                value += 20
            if not child.solvent:
                value -= 20
            if value > best:
                best = value
                target_id = child_id
        if target_id < 0:
            return False
        self.nodes[target_id].expand()
        return True

    def _support_expand(self, bias: int) -> None:
        root = self.nodes[0]
        if not root.children:
            return
        for child_id in root.children:
            child = self.nodes[child_id]
            if child.collapse_round - self.current_round > 24:
                continue
            now_round = child.sim.info.round
            target_round = min(MAX_ROUND - 1, child.collapse_round - bias)
            if now_round >= target_round:
                continue
            for _ in range(now_round, target_round - 1):
                if not child.sim.fast_next_round(self.side):
                    break
            child.expand()

    def _liquidate_all(
        self, coins: int, towers: int, coin_need: int, info: GameInfo
    ) -> Optional[Tuple[List[Operation], int, int]]:
        ops: List[Operation] = []

        for tower in info.towers:
            if tower.player != self.side or info.tower_under_emp(tower):
                continue
            if tower.type == TowerType.BASIC:
                coins += info.destroy_tower_income(towers)
                towers -= 1
            else:
                coins += info.downgrade_tower_income(int(tower.type))
            ops.append(Operation(OperationType.DOWNGRADE_TOWER, tower.id))
            if coins >= coin_need:
                return ops, coins, towers

        if self._max_future_liquidation_coins(info, ops) >= coin_need:
            return ops, coins, towers
        return None

    def _liquidate_cautious(
        self, coins: int, towers: int, coin_need: int, info: GameInfo
    ) -> Optional[Tuple[List[Operation], int, int]]:
        tower_ids = [tower.id for tower in info.towers if tower.player == self.side and not info.tower_under_emp(tower)]
        if not tower_ids:
            return None

        baseline = Simulator(info)
        fallback_round = 48
        for step in range(1, 49):
            if not baseline.fast_next_round(self.side):
                break
            if baseline.info.bases[self.side].hp < info.bases[self.side].hp:
                fallback_round = step
                break

        max_round = -1
        max_coins = coins
        best_ops: List[Operation] = []
        for order in itertools.permutations(tower_ids):
            plan: List[Operation] = []
            trial = Simulator(info)
            snapshot = trial.info
            wallet = coins
            tower_count = towers
            valid = False

            for tower_id in order:
                tower = self._tower_by_id(tower_id, snapshot)
                if tower is None:
                    continue
                if tower.type == TowerType.BASIC:
                    wallet += snapshot.destroy_tower_income(tower_count)
                    tower_count -= 1
                else:
                    wallet += snapshot.downgrade_tower_income(int(tower.type))
                plan.append(Operation(OperationType.DOWNGRADE_TOWER, tower_id))
                if wallet >= coin_need:
                    valid = True
                    break

            if not valid:
                continue

            for op in plan:
                trial.add_operation_of_player(self.side, op)
            trial.apply_operations_of_player(self.side)
            window = 48
            base_hp = snapshot.bases[self.side].hp
            for step in range(1, 49):
                if not trial.fast_next_round(self.side):
                    break
                if snapshot.bases[self.side].hp < base_hp:
                    window = step
                    break
            if window > max_round:
                max_round = window
                max_coins = wallet
                best_ops = plan

        if max_round < min(24, fallback_round):
            return None
        return best_ops, max_coins, towers

    def _try_use_storm(self, info: GameInfo, all_in: bool) -> List[Operation]:
        if info.super_weapon_cd[self.side][int(SuperWeaponType.LIGHTNING_STORM)] > 0:
            return []

        cost = info.use_super_weapon_cost(int(SuperWeaponType.LIGHTNING_STORM))
        wallet = info.coins[self.side]
        tower_count = info.tower_num_of_player(self.side)
        prefix: List[Operation] = []
        can_cast = wallet >= cost

        if not can_cast:
            liquidation = self._liquidate_all(wallet, tower_count, cost, info) if all_in else self._liquidate_cautious(wallet, tower_count, cost, info)
            if liquidation is not None:
                prefix, wallet, tower_count = liquidation
                can_cast = wallet >= cost
        if not can_cast:
            return []

        best_value = -1
        best_point: Optional[Tuple[int, int]] = None
        for x in range(19):
            for y in range(19):
                if not is_valid_pos(x, y):
                    continue
                trial = Simulator(info)
                for op in prefix:
                    trial.add_operation_of_player(self.side, op)
                trial.add_operation_of_player(self.side, Operation(OperationType.USE_LIGHTNING_STORM, x, y))
                trial.apply_operations_of_player(self.side)
                fail_round = 32
                for tick in range(32):
                    if not trial.fast_next_round(self.side):
                        break
                    if trial.info.bases[self.side].hp < info.bases[self.side].hp:
                        fail_round = tick
                        break
                if fail_round < 24:
                    continue
                value = trial.info.die_count[1 - self.side] + fail_round
                if value > best_value:
                    best_value = value
                    best_point = (x, y)

        if best_point is None:
            return []
        return [*prefix, Operation(OperationType.USE_LIGHTNING_STORM, best_point[0], best_point[1])]

    def _try_end_storm(self, info: GameInfo) -> List[Operation]:
        if info.super_weapon_cd[self.side][int(SuperWeaponType.LIGHTNING_STORM)] > 0:
            return []

        cost = info.use_super_weapon_cost(int(SuperWeaponType.LIGHTNING_STORM))
        wallet = info.coins[self.side]
        tower_count = info.tower_num_of_player(self.side)
        prefix: List[Operation] = []
        can_cast = wallet >= cost

        if not can_cast:
            liquidation = self._liquidate_all(wallet, tower_count, cost, info)
            if liquidation is not None:
                prefix, wallet, tower_count = liquidation
                can_cast = wallet >= cost
        if not can_cast:
            return []

        x, y = SITE_LAYOUT[self.side][STORM_SLOT]
        return [*prefix, Operation(OperationType.USE_LIGHTNING_STORM, x, y)]

    def _try_use_superweapon(self, info: GameInfo) -> List[Operation]:
        if self._saving_for_cornerstone(info):
            return []
        wallet = info.coins[self.side]
        tower_count = info.tower_num_of_player(self.side)
        can_emp = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.EMP_BLASTER)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.EMP_BLASTER))
        )
        can_deflect = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.DEFLECTOR)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.DEFLECTOR))
        )
        can_eva = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.EMERGENCY_EVASION)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.EMERGENCY_EVASION))
        )
        enemy_storm = (
            info.super_weapon_cd[1 - self.side][int(SuperWeaponType.LIGHTNING_STORM)] == 0
            and info.coins[1 - self.side] >= info.use_super_weapon_cost(int(SuperWeaponType.LIGHTNING_STORM))
        )

        prefix: List[Operation] = []
        if not can_emp and info.super_weapon_cd[self.side][int(SuperWeaponType.EMP_BLASTER)] == 0:
            sale = self._liquidate_cautious(wallet, tower_count, EMP_COST, info)
            if sale is not None:
                prefix, wallet, tower_count = sale

        if (
            not prefix
            and (
                (info.super_weapon_cd[self.side][int(SuperWeaponType.DEFLECTOR)] == 0 and not can_deflect)
                or (
                    info.super_weapon_cd[self.side][int(SuperWeaponType.EMERGENCY_EVASION)] == 0
                    and not can_eva
                )
            )
        ):
            sale = self._liquidate_cautious(wallet, tower_count, min(DEFLECTOR_COST, EVASION_COST), info)
            if sale is not None:
                prefix, wallet, tower_count = sale

        can_emp = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.EMP_BLASTER)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.EMP_BLASTER))
        )
        can_deflect = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.DEFLECTOR)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.DEFLECTOR))
        )
        can_eva = (
            info.super_weapon_cd[self.side][int(SuperWeaponType.EMERGENCY_EVASION)] == 0
            and wallet >= info.use_super_weapon_cost(int(SuperWeaponType.EMERGENCY_EVASION))
        )

        preview = Simulator(info)
        for _ in range(24):
            if not preview.fast_next_round(1 - self.side):
                break
        base_enemy_hp = preview.info.bases[1 - self.side].hp
        base_die_count = preview.info.die_count[self.side]

        reserved_emp_targets: List[Tuple[int, int, float]] = []
        if can_emp:
            results: List[Tuple[int, int, float]] = []
            for x in range(19):
                for y in range(19):
                    if not is_valid_pos(x, y):
                        continue
                    value = 0.0
                    for tower in info.towers:
                        if tower.player == 1 - self.side and distance(tower.x, tower.y, x, y) <= 3:
                            if tower.type == TowerType.BASIC:
                                value += 50
                            elif int(tower.type) // 10 < 0:
                                value += 60
                            else:
                                value += 80
                    if value < 100:
                        continue
                    trial = Simulator(info)
                    for op in prefix:
                        trial.add_operation_of_player(self.side, op)
                    trial.add_operation_of_player(self.side, Operation(OperationType.USE_EMP_BLASTER, x, y))
                    trial.apply_operations_of_player(self.side)
                    for _ in range(24):
                        if not trial.fast_next_round(1 - self.side):
                            break
                    if self.current_round > 495:
                        if trial.info.bases[1 - self.side].hp >= base_enemy_hp:
                            continue
                    elif self.current_round > 460:
                        if trial.info.bases[1 - self.side].hp >= base_enemy_hp - 2:
                            continue
                    elif trial.info.bases[1 - self.side].hp >= base_enemy_hp - 4:
                        continue
                    value += 100 * (base_enemy_hp - trial.info.bases[1 - self.side].hp)
                    for site in range(1, 34):
                        sx, sy = SITE_LAYOUT[1 - self.side][site]
                        if distance(sx, sy, x, y) <= 3:
                            bx, by = SITE_LAYOUT[1 - self.side][HOME_SLOT]
                            value += 3 - distance(sx, sy, bx, by) * 0.01
                    results.append((x, y, value))

            if results and not enemy_storm:
                x, y, _ = max(results, key=lambda item: item[2])
                self._mark_super(SuperWeaponType.EMP_BLASTER)
                return [*prefix, Operation(OperationType.USE_EMP_BLASTER, x, y)]
            reserved_emp_targets = results

        if can_deflect or can_eva:
            results: List[Tuple[int, int, float, bool]] = []
            if can_eva:
                for x in range(19):
                    for y in range(19):
                        if not is_valid_pos(x, y):
                            continue
                        value = 0.0
                        count = 0
                        min_dis = 100
                        for ant in info.ants:
                            if ant.player == self.side and distance(ant.x, ant.y, x, y) <= 3 and ant.is_alive():
                                value += ant.level + 1
                                count += 1
                                gap = distance(
                                    ant.x,
                                    ant.y,
                                    SITE_LAYOUT[1 - self.side][HOME_SLOT][0],
                                    SITE_LAYOUT[1 - self.side][HOME_SLOT][1],
                                )
                                min_dis = min(min_dis, gap)
                        if self.current_round <= 506 and min_dis > 5:
                            continue
                        if count < 3 or (self.current_round > 460 and count < 2):
                            continue
                        trial = Simulator(info)
                        for op in prefix:
                            trial.add_operation_of_player(self.side, op)
                        trial.add_operation_of_player(self.side, Operation(OperationType.USE_EMERGENCY_EVASION, x, y))
                        trial.apply_operations_of_player(self.side)
                        for _ in range(24):
                            if not trial.fast_next_round(1 - self.side):
                                break
                        if self.current_round > 506:
                            if (
                                trial.info.bases[1 - self.side].hp >= base_enemy_hp
                                and trial.info.die_count[self.side] >= base_die_count - 2
                            ):
                                continue
                        elif self.current_round > 460:
                            if trial.info.bases[1 - self.side].hp >= base_enemy_hp - 2:
                                continue
                        elif trial.info.bases[1 - self.side].hp >= base_enemy_hp - 3:
                            continue
                        value += 100 * (base_enemy_hp - trial.info.bases[1 - self.side].hp)
                        results.append((x, y, value, True))

            if can_deflect and not results:
                bx, by = SITE_LAYOUT[1 - self.side][HOME_SLOT]
                sx, sy = SITE_LAYOUT[1 - self.side][STORM_SLOT]
                for x in range(19):
                    for y in range(19):
                        if not is_valid_pos(x, y):
                            continue
                        if distance(x, y, bx, by) > 4:
                            continue
                        value = 0.0
                        trial = Simulator(info)
                        for op in prefix:
                            trial.add_operation_of_player(self.side, op)
                        trial.add_operation_of_player(self.side, Operation(OperationType.USE_DEFLECTOR, x, y))
                        trial.apply_operations_of_player(self.side)
                        for _ in range(24):
                            if not trial.fast_next_round(1 - self.side):
                                break
                        if (
                            (self.current_round > 460 and trial.info.bases[1 - self.side].hp >= base_enemy_hp - 2)
                            or trial.info.bases[1 - self.side].hp >= base_enemy_hp - 3
                        ):
                            continue
                        value += 100 * (base_enemy_hp - trial.info.bases[1 - self.side].hp)
                        value -= distance(x, y, sx, sy)
                        results.append((x, y, value, False))

            if results:
                x, y, _, is_eva = max(results, key=lambda item: item[2])
                if is_eva:
                    self._mark_super(SuperWeaponType.EMERGENCY_EVASION)
                    return [*prefix, Operation(OperationType.USE_EMERGENCY_EVASION, x, y)]
                self._mark_super(SuperWeaponType.DEFLECTOR)
                return [*prefix, Operation(OperationType.USE_DEFLECTOR, x, y)]

        if can_emp and reserved_emp_targets:
            x, y, _ = max(reserved_emp_targets, key=lambda item: item[2])
            self._mark_super(SuperWeaponType.EMP_BLASTER)
            return [*prefix, Operation(OperationType.USE_EMP_BLASTER, x, y)]
        return []

    def _try_emp(self, info: GameInfo) -> List[Operation]:
        if self._saving_for_cornerstone(info):
            return []
        if self._nearest_push_distance(info) > 5:
            return []
        if info.super_weapon_cd[self.side][int(SuperWeaponType.EMP_BLASTER)] > 0:
            return []

        wallet = info.coins[self.side]
        tower_count = info.tower_num_of_player(self.side)
        enemy_wallet = info.coins[1 - self.side]
        prefix: List[Operation] = []

        if wallet - enemy_wallet < 100 or wallet < EMP_COST:
            sale = self._liquidate_cautious(wallet, tower_count, max(enemy_wallet + 100, EMP_COST), info)
            if sale is None:
                return []
            prefix, wallet, tower_count = sale

        own_preview = Simulator(info)
        for _ in range(24):
            if not own_preview.fast_next_round(self.side):
                break
            if own_preview.info.bases[self.side].hp < info.bases[self.side].hp:
                return []

        preview = Simulator(info)
        for _ in range(24):
            if not preview.fast_next_round(1 - self.side):
                break
        base_enemy_hp = preview.info.bases[1 - self.side].hp

        results: List[Tuple[int, int, float]] = []
        for x in range(19):
            for y in range(19):
                if MAP_PROPERTY[x][y] < 0:
                    continue
                value = 0.0
                for tower in info.towers:
                    if tower.player == 1 - self.side and distance(tower.x, tower.y, x, y) <= 3:
                        if tower.type == TowerType.BASIC:
                            value += 50
                        elif int(tower.type) // 10 < 0:
                            value += 60
                        else:
                            value += 80
                if value < 100:
                    continue
                trial = Simulator(info)
                for op in prefix:
                    trial.add_operation_of_player(self.side, op)
                trial.add_operation_of_player(self.side, Operation(OperationType.USE_EMP_BLASTER, x, y))
                trial.apply_operations_of_player(self.side)
                for _ in range(24):
                    if not trial.fast_next_round(1 - self.side):
                        break
                if trial.info.bases[1 - self.side].hp >= base_enemy_hp - 4:
                    continue
                value += 100 * (base_enemy_hp - trial.info.bases[1 - self.side].hp)
                for site in range(1, 34):
                    sx, sy = SITE_LAYOUT[1 - self.side][site]
                    if distance(sx, sy, x, y) <= 3:
                        bx, by = SITE_LAYOUT[1 - self.side][HOME_SLOT]
                        value += 3 - distance(sx, sy, bx, by) * 0.01
                results.append((x, y, value))

        if not results:
            return []
        x, y, _ = max(results, key=lambda item: item[2])
        self._mark_super(SuperWeaponType.EMP_BLASTER)
        return [*prefix, Operation(OperationType.USE_EMP_BLASTER, x, y)]

    def _try_attack(self, info: GameInfo) -> List[Operation]:
        # Pro replays: 0 base upgrades on either side across all 8 winners.
        # The base-upgrade branches that used to live here have been removed.
        # Only delegate to super-weapon path for offensive plays.
        if self._saving_for_cornerstone(info):
            return []
        return self._try_use_superweapon(info)

    def _try_hot_hex_build(self, info: GameInfo) -> List[Operation]:
        """Seed defensive towers at the highest-priority empty hot-hex sites
        derived from pro-replay frequencies. Respects TOWER_CAP and the
        BUILD_DIST_RANGE [4, 7] window from own base. Reserves the third
        slot for the cornerstone scheduler whenever the cornerstone hasn't
        been placed yet, so we don't have to demolish to free a slot later.
        While saving for the cornerstone chain, abstain entirely.
        """
        if self._saving_for_cornerstone(info):
            return []
        towers = info.tower_num_of_player(self.side)
        if towers >= TOWER_CAP:
            return []
        sx0, sy0 = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        cornerstone_present = self._tower_at(sx0, sy0, info) is not None
        if not cornerstone_present and towers >= TOWER_CAP - 1:
            return []  # save the last slot for the cornerstone Sniper
        coins = info.coins[self.side]
        cost = info.build_tower_cost(towers)
        reserve = self._cornerstone_reserve(info)
        if coins - reserve < cost:
            return []
        bx, by = SITE_LAYOUT[self.side][HOME_SLOT]
        for site in HOT_HEX_SITES_BY_SIDE[self.side]:
            if site in CORNERSTONE_FAMILY:
                continue  # reserve cornerstone family for the cornerstone scheduler
            sx, sy = SITE_LAYOUT[self.side][site]
            if info.building_tag[sx][sy] != BuildingType.EMPTY:
                continue
            d_own = distance(sx, sy, bx, by)
            if not (BUILD_DIST_RANGE[0] <= d_own <= BUILD_DIST_RANGE[1]):
                continue
            op, _, _ = self._site_operation(site, 1, info, coins, towers)
            if op is not None:
                return [op]
        return []

    def _try_heal_low_basic(self, info: GameInfo) -> List[Operation]:
        """Saving trick: a Basic at low HP (<= HEAL_HP_THRESHOLD) wastes most
        of its build cost when demolished — refund scales with current_hp /
        max_hp. Upgrading the Basic to Heavy first refills HP to full (Heavy
        max_hp = 15), turns the slot into a stronger defender, AND keeps the
        refund value high if the slot later needs to be freed.

        Skips the cornerstone tower (its scheduler owns the upgrade chain)
        and skips during the cornerstone save phase so the heal doesn't
        steal coins from the Sniper plan.
        """
        if self._saving_for_cornerstone(info):
            return []
        coins = info.coins[self.side]
        towers = info.tower_num_of_player(self.side)
        cost = info.upgrade_tower_cost(int(TowerType.HEAVY))
        reserve = self._cornerstone_reserve(info)
        if coins - reserve < cost:
            return []
        cornerstone_xy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        for tower in info.towers:
            if tower.player != self.side:
                continue
            if tower.type != TowerType.BASIC:
                continue
            if (tower.x, tower.y) == cornerstone_xy:
                continue
            if tower.id == self.cornerstone_tower_id:
                continue
            max_hp = TOWER_STATS[TowerType.BASIC].max_hp
            if tower.hp > HEAL_HP_THRESHOLD or tower.hp >= max_hp:
                continue
            site_idx = self._site_at_pos(tower.x, tower.y)
            if site_idx < 0:
                continue
            op, _, _ = self._site_operation(
                site_idx,
                2,
                info,
                coins,
                towers,
                upgrade_branch=0,  # Basic → Heavy
            )
            if op is not None:
                return [op]
        return []

    def _try_swarm_companion(self, info: GameInfo) -> List[Operation]:
        """When a swarm builds up near our doorway, plant a Basic at a
        companion hex and queue a Mortar upgrade for the next turn. Replays
        show Mortar is the dominant AOE companion (15% co-presence with the
        cornerstone Sniper). Slot reserved for cornerstone if it isn't built.
        Abstain while saving for the cornerstone chain.
        """
        if self._saving_for_cornerstone(info):
            return []
        towers = info.tower_num_of_player(self.side)
        if towers >= TOWER_CAP:
            return []
        sx0, sy0 = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        cornerstone_present = self._tower_at(sx0, sy0, info) is not None
        if not cornerstone_present and towers >= TOWER_CAP - 1:
            return []
        dx, dy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        bx, by = SITE_LAYOUT[self.side][HOME_SLOT]
        enemy = 1 - self.side
        swarm = 0
        for ant in info.ants:
            if ant.player != enemy or not ant.is_alive():
                continue
            if distance(ant.x, ant.y, dx, dy) <= SWARM_NEAR_DOORWAY_RADIUS:
                swarm += 1
        if swarm < SWARM_TRIGGER_COUNT:
            return []
        coins = info.coins[self.side]
        towers = info.tower_num_of_player(self.side)
        cost = info.build_tower_cost(towers)
        reserve = self._cornerstone_reserve(info)
        if coins - reserve < cost:
            return []
        candidates: List[Tuple[int, int]] = []
        for site in ACTIONABLE_SITES:
            if site in CORNERSTONE_FAMILY:
                continue  # reserve cornerstone family for the cornerstone scheduler
            sx, sy = SITE_LAYOUT[self.side][site]
            if info.building_tag[sx][sy] != BuildingType.EMPTY:
                continue
            d_door = distance(sx, sy, dx, dy)
            d_own = distance(sx, sy, bx, by)
            if d_door > COMPANION_DOORWAY_RADIUS:
                continue
            if not (COMPANION_DOWN_RANGE[0] <= d_own <= COMPANION_DOWN_RANGE[1]):
                continue
            candidates.append((d_door, site))
        candidates.sort(key=lambda kv: kv[0])
        for _, site in candidates:
            op, _, _ = self._site_operation(site, 1, info, coins, towers)
            if op is not None:
                self.pending_upgrade[("site", site, int(TowerType.BASIC))] = int(TowerType.MORTAR)
                return [op]
        return []

    def _is_side_site(self, site: int) -> bool:
        """Check if a build site is on the left/right flank (for path diversion)."""
        x, y = SITE_LAYOUT[self.side][site]
        return y <= 5 or y >= 13

    def _site_at_pos(self, x: int, y: int) -> int:
        layout = SITE_LAYOUT[self.side]
        for idx, (sx, sy) in enumerate(layout):
            if sx == x and sy == y:
                return idx
        return -1

    def _predict_path_step(self, ax: int, ay: int, target_x: int, target_y: int) -> Tuple[int, int]:
        best_pos = (ax, ay)
        best_d = distance(ax, ay, target_x, target_y)
        for _direction, nx, ny in neighbors(ax, ay):
            if not is_path(nx, ny):
                continue
            d = distance(nx, ny, target_x, target_y)
            if d < best_d:
                best_d = d
                best_pos = (nx, ny)
        return best_pos

    def _lead_position(self, ant: Ant, target_x: int, target_y: int, steps: int) -> Tuple[int, int]:
        cx, cy = ant.x, ant.y
        for _ in range(max(steps, 0)):
            nx, ny = self._predict_path_step(cx, cy, target_x, target_y)
            if (nx, ny) == (cx, cy):
                break
            cx, cy = nx, ny
        return cx, cy

    def _saving_for_cornerstone(self, info: GameInfo) -> bool:
        """True from CORNERSTONE_SAVE_ROUND onward, until the cornerstone
        Sniper is up. While true, non-cornerstone build paths abstain so the
        chain coin savings can accumulate.
        """
        if self.current_round < CORNERSTONE_SAVE_ROUND:
            return False
        if self.cornerstone_phase >= 3:
            return False
        sx, sy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        tower = self._tower_at(sx, sy, info)
        if tower is not None and int(tower.type) == int(TowerType.SNIPER) and tower.player == self.side:
            return False
        return True

    def _cornerstone_reserve(self, info: GameInfo) -> int:
        """Coins to reserve for the next stage of the cornerstone Basic→Quick→Sniper
        chain. Other build/chase paths should subtract this from their coin
        budget once the cornerstone scheduler is engaged.
        """
        if self.current_round < CORNERSTONE_START_ROUND:
            return 0
        sx, sy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        tower = self._tower_at(sx, sy, info)
        if tower is None or tower.player != self.side:
            return 0
        if int(tower.type) == int(TowerType.BASIC):
            return info.upgrade_tower_cost(int(TowerType.QUICK)) + info.upgrade_tower_cost(int(TowerType.SNIPER))
        if int(tower.type) == int(TowerType.QUICK):
            return info.upgrade_tower_cost(int(TowerType.SNIPER))
        return 0

    def _resolve_pending_upgrade(self, info: GameInfo) -> List[Operation]:
        """Fire one queued tower upgrade if affordable. Entries in
        `self.pending_upgrade` are populated by other paths (cornerstone
        scheduler, swarm companion) right after they build a fresh tower.
        Keys are either an int tower id (preferred, when the id is known) or
        the tuple ("site", site_idx, expected_pre_type).
        """
        if not self.pending_upgrade:
            return []
        coins = info.coins[self.side]
        towers = info.tower_num_of_player(self.side)
        to_remove: list = []

        for key, target_type in list(self.pending_upgrade.items()):
            tower = None
            if isinstance(key, int):
                tower = self._tower_by_id(key, info)
            else:
                _, site_idx, expected_pre_type = key
                sx, sy = SITE_LAYOUT[self.side][site_idx]
                tower = self._tower_at(sx, sy, info)
                if tower is not None and int(tower.type) != int(expected_pre_type):
                    # Tower morphed (e.g. demolished and rebuilt as a different
                    # plan, or already past expected_pre_type). Drop the entry.
                    to_remove.append(key)
                    continue
            if tower is None or tower.player != self.side:
                to_remove.append(key)
                continue
            if int(tower.type) == int(target_type):
                # Already there.
                to_remove.append(key)
                continue
            cost = info.upgrade_tower_cost(int(target_type))
            if coins < cost:
                continue
            site_idx = self._site_at_pos(tower.x, tower.y)
            if site_idx < 0:
                to_remove.append(key)
                continue
            for branch in (0, 1, 2):
                op, _, _ = self._site_operation(
                    site_idx,
                    2,
                    info,
                    coins,
                    towers,
                    upgrade_branch=branch,
                )
                if op is not None and int(op.arg1) == int(target_type):
                    to_remove.append(key)
                    for k in to_remove:
                        self.pending_upgrade.pop(k, None)
                    # If the queued key was a site-tuple, also requeue the
                    # final-stage upgrade by tower id when the chain has more
                    # steps (Basic→Quick is the first leg of Basic→Quick→Sniper).
                    return [op]

        for k in to_remove:
            self.pending_upgrade.pop(k, None)
        return []

    def _try_cornerstone_sniper(self, info: GameInfo) -> List[Operation]:
        """Drive Basic→Quick→Sniper at the doorway hex once the midgame opens.
        Strategy: only START the chain when we already have enough cash to
        finish it within 3 turns (Basic + Quick + Sniper). Half-built Basic
        sitting at the doorway gets killed by ant fire before it can be
        upgraded; spending coins on a Basic we can't follow through on is
        wasted. Once the chain is in progress, finish on consecutive turns
        via the pending-upgrade resolver.
        """
        if self.current_round < CORNERSTONE_START_ROUND:
            return []

        sx, sy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]
        tower = self._tower_at(sx, sy, info)

        # Drop stale id if the cornerstone died (rebuild from scratch).
        if self.cornerstone_tower_id is not None and tower is None:
            self.cornerstone_tower_id = None
            self.cornerstone_phase = 0

        coins = info.coins[self.side]
        towers = info.tower_num_of_player(self.side)

        if tower is None:
            if towers >= TOWER_CAP:
                return []
            build_cost = info.build_tower_cost(towers)
            quick_cost = info.upgrade_tower_cost(int(TowerType.QUICK))
            sniper_cost = info.upgrade_tower_cost(int(TowerType.SNIPER))
            full_chain = build_cost + quick_cost + sniper_cost
            # All-in gate: only commit the Basic when the entire chain is
            # affordable now, so the Basic doesn't sit half-finished and die.
            if coins < full_chain:
                return []
            op, _, _ = self._site_operation(
                CORNERSTONE_SITE,
                1,
                info,
                coins,
                towers,
            )
            if op is None:
                return []
            self.cornerstone_phase = 1
            self.pending_upgrade[("site", CORNERSTONE_SITE, int(TowerType.BASIC))] = int(
                TowerType.QUICK
            )
            return [op]

        if tower.player != self.side:
            return []

        self.cornerstone_tower_id = tower.id

        if tower.type == TowerType.BASIC:
            op, _, _ = self._site_operation(
                CORNERSTONE_SITE,
                2,
                info,
                coins,
                towers,
                upgrade_branch=2,  # Basic → Quick
            )
            if op is None:
                return []
            self.cornerstone_phase = 2
            self.pending_upgrade[tower.id] = int(TowerType.SNIPER)
            return [op]

        if tower.type == TowerType.QUICK:
            op, _, _ = self._site_operation(
                CORNERSTONE_SITE,
                2,
                info,
                coins,
                towers,
                upgrade_branch=2,  # Quick → Sniper
            )
            if op is None:
                return []
            self.cornerstone_phase = 3
            self.pending_upgrade.pop(tower.id, None)
            return [op]

        if int(tower.type) == int(TowerType.SNIPER):
            self.cornerstone_phase = 3
            return []

        # Tower at doorway is some other type (e.g. picked up by a different
        # path before cornerstone scheduling kicked in). Leave it alone.
        return []

    def _try_chase_escaped_ants(self, info: GameInfo) -> List[Operation]:
        """Reposition towers to chase enemy ants that have slipped past current
        tower coverage. Single-tower chase (replays show winners keep 1-3
        towers active, never doubled up). The cornerstone tower at
        SITE_LAYOUT[self.side][CORNERSTONE_SITE] is excluded from demolish
        candidates. Abstain entirely while saving for the cornerstone chain.
        """
        if self._saving_for_cornerstone(info):
            return []

        enemy = 1 - self.side
        bx, by = SITE_LAYOUT[self.side][HOME_SLOT]
        cornerstone_xy = SITE_LAYOUT[self.side][CORNERSTONE_SITE]

        my_towers = [t for t in info.towers if t.player == self.side and t.hp > 0]
        if not my_towers:
            return []

        escaping: List[Tuple[int, Ant]] = []
        for ant in info.ants:
            if ant.player != enemy or not ant.is_alive():
                continue
            d_base = distance(ant.x, ant.y, bx, by)
            if d_base > 8:
                continue  # still on enemy half, let static defense handle it
            covered = False
            for t in my_towers:
                atk_range = TOWER_STATS[t.type].attack_range
                if atk_range <= 0:
                    continue
                if distance(t.x, t.y, ant.x, ant.y) <= atk_range:
                    covered = True
                    break
            if not covered:
                escaping.append((d_base, ant))
        if not escaping:
            return []

        escaping.sort(key=lambda kv: kv[0])
        _, target = escaping[0]

        lead_steps = 2 if target.hp >= 15 else 1
        lead_x, lead_y = self._lead_position(target, bx, by, lead_steps)

        coins = info.coins[self.side]
        towers = info.tower_num_of_player(self.side)
        build_cost = info.build_tower_cost(towers)

        # Reserve coins for the cornerstone upgrade chain so chase doesn't
        # starve Quick→Sniper.
        reserve = self._cornerstone_reserve(info)
        budget = coins - reserve

        empty_candidates: List[Tuple[int, int]] = []
        if towers < TOWER_CAP and budget >= build_cost:
            for site in ACTIONABLE_SITES:
                if site in CORNERSTONE_FAMILY:
                    continue  # reserve for cornerstone scheduler
                sx, sy = SITE_LAYOUT[self.side][site]
                if info.building_tag[sx][sy] != BuildingType.EMPTY:
                    continue
                d = distance(sx, sy, lead_x, lead_y)
                if d > 2:
                    continue
                op_check, _, _ = self._site_operation(site, 1, info, coins, towers)
                if op_check is None:
                    continue
                empty_candidates.append((d, site))
            empty_candidates.sort(key=lambda kv: kv[0])

            if empty_candidates and budget >= build_cost:
                first_d, first_site = empty_candidates[0]
                op, _, _ = self._site_operation(first_site, 1, info, coins, towers)
                if op is not None:
                    return [op]

        # No empty site (or at tower cap): do nothing. Demolish + rebuild
        # churn was disabled — per-turn slot-swaps drained coins faster than
        # the income could refill, starving the cornerstone Sniper chain.
        # Towers die naturally; their slots reopen on their own and the build
        # branch above will fill them.
        return []

    def _try_lightning_simple(self, info: GameInfo) -> List[Operation]:
        """Cast lightning storm only when ≥STORM_MIN_ENEMIES_R3 enemy ants
        cluster within a single radius-3 area. Tiebreak prefers cells closer
        to our own base (defensive bias confirmed by replay analysis). While
        saving for the cornerstone Sniper: only emergency casts allowed —
        cluster must be ≥STORM_SAVE_THRESHOLD AND coins after the cast must
        still cover the chain reserve, so the Sniper goal stays funded.
        """
        if info.super_weapon_cd[self.side][int(SuperWeaponType.LIGHTNING_STORM)] > 0:
            return []
        cost = info.use_super_weapon_cost(int(SuperWeaponType.LIGHTNING_STORM))
        if info.coins[self.side] < cost:
            return []
        saving = self._saving_for_cornerstone(info)
        min_enemies = STORM_MIN_ENEMIES_R3
        if saving:
            # During save: only fire on a much larger cluster, and only if
            # we have a comfortable surplus over the cornerstone chain cost.
            min_enemies = STORM_SAVE_THRESHOLD
            chain_floor = (
                info.build_tower_cost(info.tower_num_of_player(self.side))
                + info.upgrade_tower_cost(int(TowerType.QUICK))
                + info.upgrade_tower_cost(int(TowerType.SNIPER))
            )
            if info.coins[self.side] - cost < chain_floor:
                return []

        enemy = 1 - self.side
        base_x, base_y = SITE_LAYOUT[self.side][HOME_SLOT]
        best_x, best_y = -1, -1
        best_count = 0
        best_d_own = 99
        for x in range(19):
            for y in range(19):
                if not is_valid_pos(x, y):
                    continue
                count = 0
                for ant in info.ants:
                    if ant.player == enemy and ant.is_alive() and distance(ant.x, ant.y, x, y) <= 3:
                        count += 1
                if count == 0:
                    continue
                d_own = distance(x, y, base_x, base_y)
                better = False
                if count > best_count:
                    better = True
                elif count == best_count and d_own < best_d_own and d_own <= STORM_DEFENSIVE_DOWN_BIAS:
                    better = True
                if better:
                    best_count = count
                    best_d_own = d_own
                    best_x, best_y = x, y

        if best_count >= min_enemies and best_x >= 0:
            return [Operation(OperationType.USE_LIGHTNING_STORM, best_x, best_y)]
        return []

    def __call__(self, player_id: int, game_info: GameInfo) -> List[Operation]:
        self.current_round = game_info.round
        if self.current_round == 0:
            self.side = player_id

        enemy = 1 - self.side
        self.enemy_old_baseline = game_info.old_count[enemy]
        self.enemy_die_baseline = game_info.die_count[enemy]
        self.wall_hp_snapshot = game_info.bases[self.side].hp
        # Decay any multi-turn reserve from a prior tree-search plan so the
        # higher-priority hooks (lightning, EMP, cornerstone, swarm, chase)
        # eventually get a chance to fire again.
        if self.reserve_depth > 0:
            self.reserve_depth -= 1

        self.front_state = 0
        if game_info.bases[self.side].hp > game_info.bases[enemy].hp:
            self.front_state = 1
            self.assault_memory = False
        elif game_info.bases[self.side].hp < game_info.bases[enemy].hp:
            self.front_state = -1

        # 0) Resolve pending tower upgrades queued from a prior turn's build.
        # Replays show ~90% of upgrades happen within 0-2 rounds of build, so
        # firing the queued upgrade at the very top is the right priority.
        ops = self._resolve_pending_upgrade(game_info)
        if ops:
            return ops

        # 1) Lightning storm — only when ≥3 enemy ants cluster in R3 (replays).
        ops = self._try_lightning_simple(game_info)
        if ops:
            return ops

        attack = self.front_state == -1
        own_pressure = float(game_info.die_count[enemy])
        enemy_pressure = float(game_info.die_count[self.side])
        live_weight = min(1.0, (512 - self.current_round) / 20.0)
        for ant in game_info.ants:
            if ant.player == enemy and ant.is_alive():
                own_pressure += live_weight
            elif ant.player == self.side and ant.is_alive():
                enemy_pressure += live_weight

        if not attack and self.front_state == 0:
            if own_pressure - enemy_pressure >= 4:
                self.assault_memory = False
            elif own_pressure - enemy_pressure <= -3 - max((450 - self.current_round) // 50, 0):
                attack = True
            elif self.assault_memory:
                attack = True
            elif self.current_round >= 450 and own_pressure - enemy_pressure <= 1:
                attack = True

        enemy_emp = -1
        for weapon in game_info.super_weapons:
            if weapon.player == enemy and weapon.type == SuperWeaponType.EMP_BLASTER:
                enemy_emp = weapon.left_time
                break

        # 3) Emergency EMP defense
        if self.front_state <= 0 and not self.reserve_depth:
            ops = self._try_emp(game_info)
            if ops:
                return ops

        # 3.5) Cornerstone Sniper at the doorway hex (universal across 8
        # winning replays). Drives Basic→Quick→Sniper from CORNERSTONE_START_ROUND.
        if not self.reserve_depth:
            ops = self._try_cornerstone_sniper(game_info)
            if ops:
                return ops

        # 4) Attack if behind (upgrade ants, use superweapons)
        if attack and not self.reserve_depth:
            self.assault_memory = True
            ops = self._try_attack(game_info)
            if ops:
                return ops

        # 5) In winning position late game: storm to finish
        if self.front_state == 1 and self.current_round >= 488:
            ops = self._try_end_storm(game_info)
            if ops:
                return ops

        # 6) Even late game: storm
        if self.front_state == 0 and self.current_round >= 510:
            ops = self._try_use_storm(game_info, True)
            if ops:
                return ops

        # 6.4) Swarm AOE companion — plant a Mortar-bound Basic adjacent to
        # the doorway when ≥SWARM_TRIGGER_COUNT ants are within doorway radius.
        if not self.reserve_depth:
            ops = self._try_swarm_companion(game_info)
            if ops:
                return ops

        # 6.45) Heal-via-upgrade: a low-HP Basic refills to full max_hp when
        # promoted to Heavy. Stronger defender and a much higher demolish
        # refund later if the slot ever needs freeing.
        if not self.reserve_depth:
            ops = self._try_heal_low_basic(game_info)
            if ops:
                return ops

        # 6.5) Chase ants that have slipped past current tower coverage.
        # Single-tower chase; cornerstone tower is excluded from demolish
        # candidates. Demolish-rebuild gap is rate-limited.
        if not self.reserve_depth:
            ops = self._try_chase_escaped_ants(game_info)
            if ops:
                return ops

        # 7) Hot-hex defensive seed (replaces older flank-tower diversion logic).
        if not self.reserve_depth:
            ops = self._try_hot_hex_build(game_info)
            if ops:
                return ops

        # 8) Tree search (with tower upgrades disabled)
        start_cpu = time.process_time()
        staging = game_info.clone()
        staging.bases[enemy].hp = SEARCH_STAGING_ENEMY_BASE_HP

        self.nodes = []
        root = ForecastNode(self, Simulator(staging))
        root.node_id = 0
        root.parent = -1
        root.evaluate()
        self.nodes.append(root)
        self.nodes[0].expand(is_root=True)

        while True:
            if time.process_time() - start_cpu >= SEARCH_BUDGET or len(self.nodes) >= MAX_NODE_COUNT - 10:
                break
            if not self._expand_one():
                break

        best_id = -1
        best_value = -1e9
        for child_id in root.children:
            child = self.nodes[child_id]
            if child.best_descendant > best_value:
                best_value = child.best_descendant
                best_id = child_id

        if len(self.nodes) > 1 and best_id > 1 and best_value - self.nodes[1].best_descendant < 2:
            best_id = 1
            best_value = self.nodes[1].best_descendant

        emergency_storm = False
        if best_id >= 0:
            imminent = self.nodes[best_id].collapse_round - self.current_round
            emergency_storm = (
                (
                    self.front_state >= 0
                    and (
                        (enemy_emp > 0 and imminent < min(8, enemy_emp) and best_value < -400)
                        or (best_value < -700 and imminent <= 2)
                    )
                )
                or (
                    self.front_state == 0
                    and game_info.die_count[enemy] - game_info.die_count[self.side] >= 8
                    and imminent <= 1
                )
            )

        if emergency_storm:
            ops = self._try_use_storm(game_info, self.current_round >= 480)
            if ops:
                return ops

        if best_id > 0:
            self.reserve_depth = self.nodes[best_id].best_depth
            return list(self.nodes[best_id].chosen)
        return []

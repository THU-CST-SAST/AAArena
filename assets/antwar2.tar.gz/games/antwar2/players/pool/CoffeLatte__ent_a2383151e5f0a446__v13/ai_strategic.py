from __future__ import annotations

from dataclasses import dataclass
from math import inf
from time import perf_counter

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:  # pragma: no cover - packaged/repo layout
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.backend.state import BackendState
from SDK.backend.model import Ant, Operation, Tower
from SDK.utils.actions import ActionBundle
from SDK.utils.constants import (
    ANT_AGE_LIMIT,
    ANT_MAX_HP,
    MAX_ACTIONS,
    MAX_ROUND,
    OperationType,
    PLAYER_BASES,
    SUPER_WEAPON_STATS,
    SuperWeaponType,
    TOWER_STATS,
    TOWER_UPGRADE_TREE,
    TowerType,
    AntKind,
)
from SDK.utils.geometry import hex_distance
from SDK.utils.turns import DecisionContext


WEAPON_OPERATION_TYPES = {
    OperationType.USE_LIGHTNING_STORM: SuperWeaponType.LIGHTNING_STORM,
    OperationType.USE_EMP_BLASTER: SuperWeaponType.EMP_BLASTER,
    OperationType.USE_DEFLECTOR: SuperWeaponType.DEFLECTOR,
    OperationType.USE_EMERGENCY_EVASION: SuperWeaponType.EMERGENCY_EVASION,
}

CONTROL_TOWERS = {TowerType.ICE, TowerType.BEWITCH, TowerType.PULSE}
AREA_TOWERS = {TowerType.MORTAR, TowerType.MORTAR_PLUS, TowerType.PULSE, TowerType.MISSILE}
PRODUCER_TOWERS = {
    TowerType.PRODUCER,
    TowerType.PRODUCER_FAST,
    TowerType.PRODUCER_SIEGE,
    TowerType.PRODUCER_MEDIC,
}
FAST_TOWERS = {TowerType.QUICK, TowerType.QUICK_PLUS, TowerType.DOUBLE, TowerType.SNIPER}
HEAVY_TOWERS = {TowerType.HEAVY, TowerType.HEAVY_PLUS}


@dataclass(slots=True)
class DefenseEmergency:
    active: bool
    severity: float
    nearest_distance: int
    focus: tuple[int, int]
    threats: tuple[Ant, ...]


@dataclass(slots=True)
class AttackPressure:
    score: float
    focus: tuple[int, int]
    ant_count: int
    nearest_distance: int
    tower_density: float


@dataclass(slots=True)
class StrategicAnalysis:
    player: int
    enemy: int
    round_ratio: float
    hp_delta: int
    coin_delta: int
    safe_coin: int
    my_towers: tuple[Tower, ...]
    enemy_towers: tuple[Tower, ...]
    my_ants: tuple[Ant, ...]
    enemy_ants: tuple[Ant, ...]
    defense: DefenseEmergency
    attack: AttackPressure


class StrategicAgent(BaseAgent):
    """Rule-aware heuristic agent built on top of the official SDK."""

    def __init__(
        self,
        seed: int | None = None,
        max_actions: int = MAX_ACTIONS,
        time_budget_seconds: float = 0.85,
    ) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self.time_budget_seconds = time_budget_seconds
        self.max_scored_bundles = max_actions + 32

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        deadline = perf_counter() + self.time_budget_seconds
        try:
            analysis = self.analyze_state(state, player)
            candidates = bundles or self.generate_candidates(state, player, analysis, deadline)
            if not candidates:
                return self.fallback_action(state, player)

            current_value = self.evaluate_state(state, player, analysis)
            best = self.fallback_action(state, player, candidates)
            best_score = -inf

            for bundle in candidates[: self.max_scored_bundles]:
                if perf_counter() >= deadline:
                    break
                score = self.evaluate_action(state, player, bundle, analysis, current_value, deadline)
                if score > best_score:
                    best_score = score
                    best = bundle

            return self._sanitize_bundle(state, player, best)
        except Exception:
            return self.fallback_action(state, player, bundles)

    def choose_operations(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> list[Operation]:
        try:
            return list(self.choose_bundle(state, player, bundles=bundles).operations)
        except Exception:
            return list(self.fallback_action(state, player, bundles).operations)

    def analyze_state(self, state: BackendState, player: int) -> StrategicAnalysis:
        enemy = 1 - player
        my_towers = tuple(state.towers_of(player))
        enemy_towers = tuple(state.towers_of(enemy))
        my_ants = tuple(state.ants_of(player))
        enemy_ants = tuple(state.ants_of(enemy))
        defense = self.detect_defense_emergency(state, player, enemy_ants)
        attack = self.estimate_attack_pressure(state, player, my_ants, enemy_towers)
        safe_coin = max(int(state.coins[player]) - int(state.safe_coin_threshold(player)), 0)
        return StrategicAnalysis(
            player=player,
            enemy=enemy,
            round_ratio=float(state.round_index) / float(MAX_ROUND),
            hp_delta=int(state.bases[player].hp - state.bases[enemy].hp),
            coin_delta=int(state.coins[player] - state.coins[enemy]),
            safe_coin=safe_coin,
            my_towers=my_towers,
            enemy_towers=enemy_towers,
            my_ants=my_ants,
            enemy_ants=enemy_ants,
            defense=defense,
            attack=attack,
        )

    def generate_candidates(
        self,
        state: BackendState,
        player: int,
        analysis: StrategicAnalysis,
        deadline: float | None = None,
    ) -> list[ActionBundle]:
        context = DecisionContext.for_player(player)
        try:
            bundles = list(self.catalog.build(state, player, context=context, rerank=False))
        except Exception:
            bundles = [ActionBundle(name="hold", score=0.0, tags=("noop",))]

        bundles.extend(self.score_weapons(state, player, analysis))
        bundles.extend(self._priority_build_candidates(state, player, analysis))
        bundles.extend(self._priority_upgrade_candidates(state, player, analysis))

        unique: dict[tuple[tuple[int, int, int], ...], ActionBundle] = {}
        for bundle in bundles:
            if deadline is not None and perf_counter() >= deadline:
                break
            legal = self._legal_operations(state, player, bundle.operations)
            if legal is None:
                continue
            key = tuple((int(op.op_type), int(op.arg0), int(op.arg1)) for op in legal)
            normalized = bundle if tuple(legal) == bundle.operations else ActionBundle(
                name=f"{bundle.name}-legal",
                operations=tuple(legal),
                score=bundle.score,
                tags=bundle.tags,
            )
            if key not in unique or normalized.score > unique[key].score:
                unique[key] = normalized

        ordered = sorted(unique.values(), key=lambda item: (item.score, -len(item.operations)), reverse=True)
        if not ordered:
            return [ActionBundle(name="hold", score=0.0, tags=("noop",))]
        return ordered[: self.max_scored_bundles]

    def evaluate_state(
        self,
        state: BackendState,
        player: int,
        analysis: StrategicAnalysis | None = None,
    ) -> float:
        if analysis is None:
            analysis = self.analyze_state(state, player)
        try:
            sdk_value = self.feature_extractor.evaluate(state, player, context=DecisionContext.for_player(player))
        except Exception:
            sdk_value = 0.0

        my_tower_value = self._tower_group_value(state, player, analysis.my_towers, analysis.enemy_ants)
        enemy_tower_value = self._tower_group_value(state, analysis.enemy, analysis.enemy_towers, analysis.my_ants)
        base_levels = (
            state.bases[player].generation_level * 9.0
            + self._ant_hp_upgrade_value(state.bases[player].ant_level) * 7.0
            - state.bases[analysis.enemy].generation_level * 5.0
            - self._ant_hp_upgrade_value(state.bases[analysis.enemy].ant_level) * 4.0
        )

        value = sdk_value * 0.35
        value += analysis.hp_delta * 34.0
        value += analysis.coin_delta * 0.10 + analysis.safe_coin * 0.08
        value += analysis.attack.score * 2.2
        value -= analysis.defense.severity * 4.2
        value += my_tower_value * 1.4 - enemy_tower_value * 0.9
        value += base_levels
        value += (len(analysis.my_ants) - len(analysis.enemy_ants)) * 1.2
        if state.terminal:
            if state.winner == player:
                value += 10000.0
            elif state.winner == analysis.enemy:
                value -= 10000.0
        return value

    def evaluate_action(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        analysis: StrategicAnalysis,
        current_value: float,
        deadline: float,
    ) -> float:
        legal = self._legal_operations(state, player, bundle.operations)
        if legal is None:
            return -inf
        if not legal:
            idle_penalty = -24.0 if analysis.defense.active else -3.0 if analysis.safe_coin > 60 else 0.0
            return bundle.score * 0.2 + idle_penalty

        score = bundle.score * 0.45
        pending: list[Operation] = []
        for operation in legal:
            score += self._operation_score(state, player, operation, analysis, pending)
            pending.append(operation)

        if len(legal) > 1:
            score += 2.0
            if analysis.defense.active and any(op.op_type in WEAPON_OPERATION_TYPES for op in legal):
                score += 3.0

        if perf_counter() < deadline:
            score += self._rollout_delta(state, player, legal, current_value) * 0.20
        return score

    def detect_defense_emergency(
        self,
        state: BackendState,
        player: int,
        enemy_ants: tuple[Ant, ...] | None = None,
    ) -> DefenseEmergency:
        if enemy_ants is None:
            enemy_ants = tuple(state.ants_of(1 - player))
        base_x, base_y = PLAYER_BASES[player]
        weighted: list[tuple[float, Ant, int]] = []
        severity = 0.0
        nearest = 32

        for ant in enemy_ants:
            distance = hex_distance(ant.x, ant.y, base_x, base_y)
            nearest = min(nearest, distance)
            if distance > 8:
                continue
            proximity = max(0.0, 9.0 - distance) ** 1.35
            hp_ratio = max(float(ant.hp), 1.0) / max(float(ant.max_hp), 1.0)
            kind_factor = 1.45 if ant.kind == AntKind.COMBAT else 1.0
            level_factor = 1.0 + ant.level * 0.28
            age_factor = 1.0 if ant.kind == AntKind.COMBAT else max(0.35, (ANT_AGE_LIMIT - ant.age) / ANT_AGE_LIMIT)
            imminent = 12.0 if distance <= 1 else 6.0 if distance <= 2 else 2.5 if distance <= 3 else 0.0
            weight = proximity * hp_ratio * kind_factor * level_factor * age_factor + imminent
            severity += weight
            if distance <= 6:
                weighted.append((weight, ant, distance))

        if weighted:
            weighted.sort(key=lambda item: item[0], reverse=True)
            focus = (weighted[0][1].x, weighted[0][1].y)
            threats = tuple(item[1] for item in weighted[:8])
        else:
            focus = (base_x, base_y)
            threats = ()

        active = nearest <= 4 or severity >= 18.0 or (state.bases[player].hp <= 20 and bool(weighted))
        return DefenseEmergency(active=active, severity=severity, nearest_distance=nearest, focus=focus, threats=threats)

    def estimate_attack_pressure(
        self,
        state: BackendState,
        player: int,
        my_ants: tuple[Ant, ...] | None = None,
        enemy_towers: tuple[Tower, ...] | None = None,
    ) -> AttackPressure:
        if my_ants is None:
            my_ants = tuple(state.ants_of(player))
        if enemy_towers is None:
            enemy_towers = tuple(state.towers_of(1 - player))

        enemy_base = PLAYER_BASES[1 - player]
        best_focus = PLAYER_BASES[player]
        best_weight = 0.0
        score = 0.0
        ant_count = 0
        nearest = 32

        for ant in my_ants:
            distance = hex_distance(ant.x, ant.y, *enemy_base)
            nearest = min(nearest, distance)
            if distance > 11:
                continue
            hp_ratio = max(float(ant.hp), 1.0) / max(float(ant.max_hp), 1.0)
            kind_factor = 1.55 if ant.kind == AntKind.COMBAT else 1.0
            shield_bonus = 0.35 * max(int(getattr(ant, "shield", 0)), 0)
            weight = max(0.0, 12.0 - distance) * hp_ratio * kind_factor + shield_bonus
            if distance <= 5:
                weight += 5.0
            if weight > best_weight:
                best_weight = weight
                best_focus = (ant.x, ant.y)
            if weight > 0:
                ant_count += 1
                score += weight

        tower_density = 0.0
        if best_weight > 0:
            for tower in enemy_towers:
                distance = hex_distance(tower.x, tower.y, *best_focus)
                if distance <= 5:
                    tower_density += max(0.0, 6.0 - distance) * (1.0 + tower.level * 0.55)

        return AttackPressure(
            score=score,
            focus=best_focus,
            ant_count=ant_count,
            nearest_distance=nearest,
            tower_density=tower_density,
        )

    def score_weapons(
        self,
        state: BackendState,
        player: int,
        analysis: StrategicAnalysis,
    ) -> list[ActionBundle]:
        results: list[ActionBundle] = []

        if self._can_use_weapon(state, player, SuperWeaponType.LIGHTNING_STORM):
            centers = {(ant.x, ant.y) for ant in analysis.enemy_ants}
            centers.update((tower.x, tower.y) for tower in analysis.enemy_towers)
            if analysis.defense.active:
                centers.add(analysis.defense.focus)
            best = self._best_center(
                centers,
                lambda x, y: self._lightning_score(state, player, x, y, analysis),
            )
            if best and (best[2] >= 8.0 or analysis.defense.active):
                op = Operation(OperationType.USE_LIGHTNING_STORM, best[0], best[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle("strategic-storm", (op,), best[2], ("weapon", "storm")))

        if self._can_use_weapon(state, player, SuperWeaponType.EMP_BLASTER) and analysis.enemy_towers:
            centers = {(tower.x, tower.y) for tower in analysis.enemy_towers}
            best = self._best_center(centers, lambda x, y: self._emp_score(state, player, x, y, analysis))
            if best and best[2] >= 9.0:
                op = Operation(OperationType.USE_EMP_BLASTER, best[0], best[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle("strategic-emp", (op,), best[2], ("weapon", "emp")))

        if self._can_use_weapon(state, player, SuperWeaponType.DEFLECTOR) and analysis.my_ants:
            centers = {(ant.x, ant.y) for ant in analysis.my_ants}
            if analysis.attack.ant_count:
                centers.add(analysis.attack.focus)
            best = self._best_center(centers, lambda x, y: self._deflector_score(state, player, x, y, analysis))
            if best and best[2] >= 6.5:
                op = Operation(OperationType.USE_DEFLECTOR, best[0], best[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle("strategic-deflector", (op,), best[2], ("weapon", "shield")))

        if self._can_use_weapon(state, player, SuperWeaponType.EMERGENCY_EVASION) and analysis.my_ants:
            centers = {(ant.x, ant.y) for ant in analysis.my_ants}
            if analysis.attack.ant_count:
                centers.add(analysis.attack.focus)
            best = self._best_center(centers, lambda x, y: self._evasion_score(state, player, x, y, analysis))
            if best and best[2] >= 6.0:
                op = Operation(OperationType.USE_EMERGENCY_EVASION, best[0], best[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle("strategic-evasion", (op,), best[2], ("weapon", "evasion")))

        return results

    def fallback_action(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        if bundles:
            for bundle in bundles:
                sanitized = self._sanitize_bundle(state, player, bundle)
                if sanitized.operations or not bundle.operations:
                    return sanitized
        return ActionBundle(name="hold", score=0.0, tags=("noop",))

    def _priority_build_candidates(
        self,
        state: BackendState,
        player: int,
        analysis: StrategicAnalysis,
    ) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        tower_count = state.tower_count(player)
        if state.coins[player] < state.build_tower_cost(tower_count):
            return results
        for index, (x, y) in enumerate(state.strategic_slots(player)[:14]):
            op = Operation(OperationType.BUILD_TOWER, x, y)
            if not state.can_apply_operation(player, op):
                continue
            score = self._build_score(state, player, x, y, analysis, tower_count, index)
            results.append(ActionBundle(f"strategic-build@{x},{y}", (op,), score, ("build", "strategic")))
        return results

    def _priority_upgrade_candidates(
        self,
        state: BackendState,
        player: int,
        analysis: StrategicAnalysis,
    ) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        for tower in analysis.my_towers:
            local_pressure = self._local_enemy_pressure(state, player, tower.x, tower.y, radius=5)
            for target in TOWER_UPGRADE_TREE.get(tower.tower_type, ()):
                op = Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target))
                if not state.can_apply_operation(player, op):
                    continue
                score = self._upgrade_score(state, player, tower, target, local_pressure, analysis)
                results.append(ActionBundle(f"strategic-upgrade#{tower.tower_id}->{int(target)}", (op,), score, ("upgrade",)))
        return results

    def _operation_score(
        self,
        state: BackendState,
        player: int,
        operation: Operation,
        analysis: StrategicAnalysis,
        pending: list[Operation],
    ) -> float:
        del pending
        if operation.op_type == OperationType.BUILD_TOWER:
            tower_count = state.tower_count(player)
            try:
                order = state.strategic_slots(player).index((operation.arg0, operation.arg1))
            except ValueError:
                order = 99
            return self._build_score(state, player, operation.arg0, operation.arg1, analysis, tower_count, order)

        if operation.op_type == OperationType.UPGRADE_TOWER:
            tower = state.tower_by_id(operation.arg0)
            if tower is None:
                return -inf
            target = TowerType(operation.arg1)
            pressure = self._local_enemy_pressure(state, player, tower.x, tower.y, radius=5)
            return self._upgrade_score(state, player, tower, target, pressure, analysis)

        if operation.op_type == OperationType.DOWNGRADE_TOWER:
            tower = state.tower_by_id(operation.arg0)
            if tower is None:
                return -inf
            pressure = self._local_enemy_pressure(state, player, tower.x, tower.y, radius=5)
            refund = state.operation_income(player, operation)
            score = refund * 0.05 - 18.0 - tower.level * 8.0 - pressure * 3.0
            if hex_distance(tower.x, tower.y, *PLAYER_BASES[player]) <= 5:
                score -= 12.0
            if analysis.defense.active:
                score -= 25.0
            return score

        if operation.op_type == OperationType.UPGRADE_GENERATION_SPEED:
            level = state.bases[player].generation_level
            if level >= 2:
                return -inf
            cost = state.upgrade_base_cost(level)
            score = 21.0 + (2 - level) * 5.0 + analysis.round_ratio * 9.0 - cost * 0.035
            if analysis.defense.active or analysis.defense.nearest_distance <= 5:
                score -= 35.0
            if len(analysis.my_towers) < 3 and state.round_index < 80:
                score -= 18.0
            if state.coins[player] - cost < max(45, state.safe_coin_threshold(player)):
                score -= 20.0
            if analysis.hp_delta < -5:
                score -= 14.0
            return score

        if operation.op_type == OperationType.UPGRADE_GENERATED_ANT:
            level = state.bases[player].ant_level
            if level >= 2:
                return -inf
            hp_gain = ANT_MAX_HP[level + 1] - ANT_MAX_HP[level]
            if hp_gain <= 0:
                return -40.0
            cost = state.upgrade_base_cost(level)
            score = 15.0 + hp_gain * 2.2 + analysis.attack.score * 0.18 - cost * 0.035
            if analysis.defense.active:
                score -= 28.0
            if state.coins[player] - cost < max(45, state.safe_coin_threshold(player)):
                score -= 18.0
            return score

        if operation.op_type == OperationType.USE_LIGHTNING_STORM:
            return self._lightning_score(state, player, operation.arg0, operation.arg1, analysis)
        if operation.op_type == OperationType.USE_EMP_BLASTER:
            return self._emp_score(state, player, operation.arg0, operation.arg1, analysis)
        if operation.op_type == OperationType.USE_DEFLECTOR:
            return self._deflector_score(state, player, operation.arg0, operation.arg1, analysis)
        if operation.op_type == OperationType.USE_EMERGENCY_EVASION:
            return self._evasion_score(state, player, operation.arg0, operation.arg1, analysis)
        return 0.0

    def _build_score(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        analysis: StrategicAnalysis,
        tower_count: int,
        order: int,
    ) -> float:
        cost = state.build_tower_cost(tower_count)
        pressure = self._local_enemy_pressure(state, player, x, y, radius=6)
        base_distance = hex_distance(x, y, *PLAYER_BASES[player])
        lane_priority = state.slot_priority(player, x, y)
        early = max(0.0, 1.0 - analysis.round_ratio * 4.0)
        score = lane_priority * 0.72 + pressure * 2.7 + early * max(0.0, 5 - tower_count) * 4.0
        if analysis.defense.active:
            score += max(0.0, 7.0 - base_distance) * 4.5
            score += max(0.0, 10.0 - hex_distance(x, y, *analysis.defense.focus)) * 1.1
        if tower_count >= 5 and pressure < 2.5:
            score -= (tower_count - 4) * 6.0
        if order > 10 and not analysis.defense.active:
            score -= (order - 10) * 0.9
        score -= cost * (0.075 if analysis.defense.active else 0.12)
        if state.coins[player] - cost < state.safe_coin_threshold(player):
            score -= 8.0
        return score

    def _upgrade_score(
        self,
        state: BackendState,
        player: int,
        tower: Tower,
        target: TowerType,
        local_pressure: float,
        analysis: StrategicAnalysis,
    ) -> float:
        cost = state.upgrade_tower_cost(target)
        base_distance = hex_distance(tower.x, tower.y, *PLAYER_BASES[player])
        enemy_base_distance = hex_distance(tower.x, tower.y, *PLAYER_BASES[1 - player])
        cluster = self._enemy_cluster_value(state, player, tower.x, tower.y, radius=3)
        score = local_pressure * 1.25 + state.slot_priority(player, tower.x, tower.y) * 0.22
        score += tower.level * 2.0 - cost * 0.045

        if target in CONTROL_TOWERS:
            score += local_pressure * 1.25 + (8.0 if analysis.defense.active else 2.0)
        if target in AREA_TOWERS:
            score += cluster * 1.15 + max(0.0, 9.0 - base_distance) * 0.7
        if target in HEAVY_TOWERS:
            score += local_pressure * 0.9 + max(0.0, 6.0 - base_distance) * 1.2
        if target in FAST_TOWERS:
            score += 4.0 + max(0.0, 8.0 - base_distance) * 0.8
        if target == TowerType.SNIPER:
            score += max(0.0, 14.0 - enemy_base_distance) * 0.9
        if target in PRODUCER_TOWERS:
            score += self._producer_upgrade_score(target, local_pressure, enemy_base_distance, analysis)

        if analysis.defense.active and target in PRODUCER_TOWERS:
            score -= 28.0
        if state.coins[player] - cost < state.safe_coin_threshold(player) and not analysis.defense.active:
            score -= 10.0
        return score

    def _producer_upgrade_score(
        self,
        target: TowerType,
        local_pressure: float,
        enemy_base_distance: int,
        analysis: StrategicAnalysis,
    ) -> float:
        if local_pressure > 4.0:
            return -12.0
        score = 3.5 + analysis.attack.score * 0.20 + max(0.0, 14.0 - enemy_base_distance) * 0.45
        if target == TowerType.PRODUCER_FAST:
            score += 3.0
        elif target == TowerType.PRODUCER_SIEGE:
            score += 4.5 + analysis.round_ratio * 4.0
        elif target == TowerType.PRODUCER_MEDIC:
            score += 3.0 + min(analysis.attack.ant_count, 5) * 1.1
        return score

    def _lightning_score(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        analysis: StrategicAnalysis,
    ) -> float:
        stats = SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM]
        score = -stats.cost * 0.055
        base = PLAYER_BASES[player]
        for ant in analysis.enemy_ants:
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance > stats.attack_range:
                continue
            damage_ratio = min(20.0, float(ant.hp)) / max(float(ant.max_hp), 1.0)
            base_distance = hex_distance(ant.x, ant.y, *base)
            score += damage_ratio * (10.0 + ant.level * 3.0)
            score += max(0.0, 6.0 - base_distance) * 3.0
            if ant.kind == AntKind.COMBAT:
                score += 3.5
            if ant.hp <= 20:
                score += ant.kill_reward * 0.32
        for tower in analysis.enemy_towers:
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance <= stats.attack_range:
                score += (3.0 / max(tower.hp, 1)) * (9.0 + tower.level * 3.0)
        if analysis.defense.active and hex_distance(x, y, *analysis.defense.focus) <= 2:
            score += 14.0 + analysis.defense.severity * 0.35
        return score

    def _emp_score(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        analysis: StrategicAnalysis,
    ) -> float:
        stats = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER]
        score = -stats.cost * 0.04
        for tower in analysis.enemy_towers:
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance <= stats.attack_range:
                score += 5.0 + tower.level * 4.0 + tower.damage * 0.18
                if hex_distance(tower.x, tower.y, *analysis.attack.focus) <= 4:
                    score += 4.0
        score += analysis.attack.score * 0.22 + analysis.attack.tower_density * 0.45
        if analysis.attack.ant_count == 0:
            score -= 7.0
        return score

    def _deflector_score(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        analysis: StrategicAnalysis,
    ) -> float:
        stats = SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR]
        score = -stats.cost * 0.04
        for ant in analysis.my_ants:
            if hex_distance(x, y, ant.x, ant.y) > stats.attack_range:
                continue
            enemy_base_distance = hex_distance(ant.x, ant.y, *PLAYER_BASES[analysis.enemy])
            fire = self._enemy_fire_pressure(state, analysis.enemy, ant.x, ant.y)
            score += 2.2 + max(0.0, 8.0 - enemy_base_distance) * 1.15 + fire * 1.3
            if ant.kind == AntKind.COMBAT:
                score += 2.0
        score += analysis.attack.score * 0.12
        return score

    def _evasion_score(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        analysis: StrategicAnalysis,
    ) -> float:
        stats = SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION]
        score = -stats.cost * 0.035
        covered = 0
        for ant in analysis.my_ants:
            if hex_distance(x, y, ant.x, ant.y) > stats.attack_range:
                continue
            covered += 1
            enemy_base_distance = hex_distance(ant.x, ant.y, *PLAYER_BASES[analysis.enemy])
            fire = self._enemy_fire_pressure(state, analysis.enemy, ant.x, ant.y)
            score += 2.4 + max(0.0, 6.0 - enemy_base_distance) * 1.6 + fire * 2.0
            if ant.kind == AntKind.COMBAT:
                score += 1.6
        if covered >= 3:
            score += 3.0
        if analysis.attack.nearest_distance <= 4:
            score += 4.0
        return score

    def _rollout_delta(
        self,
        state: BackendState,
        player: int,
        operations: list[Operation],
        current_value: float,
    ) -> float:
        try:
            trial = state.clone()
            invalid = trial.apply_operation_list(player, operations)
            if invalid:
                return -500.0
            if not trial.terminal and DecisionContext.for_player(player).settles_after_action:
                trial.advance_round()
            return self.evaluate_state(trial, player) - current_value
        except Exception:
            return 0.0

    def _tower_group_value(
        self,
        state: BackendState,
        owner: int,
        towers: tuple[Tower, ...],
        opposing_ants: tuple[Ant, ...],
    ) -> float:
        total = 0.0
        for tower in towers:
            stats = TOWER_STATS[tower.tower_type]
            pressure = 0.0
            for ant in opposing_ants:
                distance = hex_distance(tower.x, tower.y, ant.x, ant.y)
                if distance <= max(6, tower.attack_range + 3):
                    pressure += max(0.0, 6.5 - distance) * (1.0 + ant.level * 0.3)
            base_distance = hex_distance(tower.x, tower.y, *PLAYER_BASES[owner])
            value = 2.0 + tower.level * 3.5 + stats.damage * 0.18 + stats.attack_range * 0.7
            value += pressure * 0.9 + max(0.0, 7.0 - base_distance) * 0.8
            if tower.tower_type in CONTROL_TOWERS:
                value += pressure * 0.6
            if tower.tower_type in AREA_TOWERS:
                value += pressure * 0.4
            if tower.tower_type in PRODUCER_TOWERS:
                value += 4.0 + max(0.0, 12.0 - hex_distance(tower.x, tower.y, *PLAYER_BASES[1 - owner])) * 0.3
            total += value * max(float(tower.hp), 1.0) / max(float(tower.max_hp), 1.0)
        return total

    def _local_enemy_pressure(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        radius: int,
    ) -> float:
        pressure = 0.0
        for ant in state.ants_of(1 - player):
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance <= radius:
                pressure += max(0.0, radius + 0.5 - distance) * (1.0 + ant.level * 0.35)
                if ant.kind == AntKind.COMBAT:
                    pressure += 1.5
        return pressure

    def _enemy_cluster_value(
        self,
        state: BackendState,
        player: int,
        x: int,
        y: int,
        radius: int,
    ) -> float:
        value = 0.0
        for ant in state.ants_of(1 - player):
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance <= radius:
                value += max(0.0, radius + 1 - distance) * (1.0 + ant.level * 0.4)
        return value

    def _enemy_fire_pressure(self, state: BackendState, enemy: int, x: int, y: int) -> float:
        pressure = 0.0
        for tower in state.towers_of(enemy):
            if tower.is_producer:
                continue
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance <= tower.attack_range + 1:
                pressure += max(0.0, tower.attack_range + 2 - distance) * (1.0 + tower.level * 0.5)
        return pressure

    def _ant_hp_upgrade_value(self, level: int) -> float:
        if level <= 0:
            return 0.0
        return float(ANT_MAX_HP[level] - ANT_MAX_HP[0]) / max(ANT_MAX_HP[-1] - ANT_MAX_HP[0], 1)

    def _can_use_weapon(self, state: BackendState, player: int, weapon_type: SuperWeaponType) -> bool:
        stats = SUPER_WEAPON_STATS[weapon_type]
        return int(state.weapon_cooldowns[player, weapon_type]) <= 0 and int(state.coins[player]) >= stats.cost

    def _best_center(self, centers, scorer):
        best: tuple[int, int, float] | None = None
        for x, y in centers:
            score = scorer(x, y)
            if best is None or score > best[2]:
                best = (x, y, score)
        return best

    def _legal_operations(
        self,
        state: BackendState,
        player: int,
        operations: tuple[Operation, ...] | list[Operation],
    ) -> list[Operation] | None:
        accepted: list[Operation] = []
        for operation in operations:
            if not state.can_apply_operation(player, operation, accepted):
                return None
            accepted.append(operation)
        return accepted

    def _sanitize_bundle(self, state: BackendState, player: int, bundle: ActionBundle) -> ActionBundle:
        accepted: list[Operation] = []
        for operation in bundle.operations:
            try:
                if state.can_apply_operation(player, operation, accepted):
                    accepted.append(operation)
            except Exception:
                continue
        if tuple(accepted) == bundle.operations:
            return bundle
        if not accepted:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))
        return ActionBundle(
            name=f"{bundle.name}-filtered",
            operations=tuple(accepted),
            score=bundle.score,
            tags=bundle.tags,
        )


class AI(StrategicAgent):
    pass

from __future__ import annotations

try:
    from ai_strategic import AI, StrategicAgent
except ModuleNotFoundError as exc:  # pragma: no cover - repository layout
    if exc.name != "ai_strategic":
        raise
    from AI.ai_strategic import AI, StrategicAgent


__all__ = ["AI", "StrategicAgent"]

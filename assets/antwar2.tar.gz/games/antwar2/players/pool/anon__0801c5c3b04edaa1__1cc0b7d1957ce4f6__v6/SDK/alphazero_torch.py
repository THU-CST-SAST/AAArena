"""PyTorch-based PolicyValueNet with GPU support for training.

This module provides a PyTorch implementation of the policy-value network
that can run on CUDA GPUs.  It is fully compatible with the NumPy-based
:class:`SDK.alphazero.PolicyValueNet` — checkpoints are stored in the same
``.npz`` format so that models trained on GPU can be loaded by the pure-NumPy
inference path used inside :class:`SDK.alphazero.PriorGuidedMCTS`.

Usage example::

    from SDK.alphazero_torch import TorchPolicyValueNet

    net = TorchPolicyValueNet(obs_dim=512, action_dim=96, device="cuda")
    metrics = net.update(obs, masks, policy_targets, value_targets)
    priors, value = net.predict(single_obs, mask)
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from SDK.alphazero import PolicyValueNetConfig


def _default_device() -> torch.device:
    """Return *cuda* if available, otherwise *cpu*."""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


class TorchPolicyValueNet(nn.Module):
    """PyTorch policy–value network with transparent GPU support.

    The architecture mirrors :class:`SDK.alphazero.PolicyValueNet` exactly:

    * ``fc1``   – obs_dim  → hidden_dim   (ReLU)
    * ``fc2``   – hidden_dim → hidden_dim2 (ReLU)
    * ``policy_head`` – hidden_dim2 → action_dim
    * ``value_head``  – hidden_dim2 → 1  (tanh)

    Checkpoint I/O uses the same ``.npz`` layout as the NumPy network so
    that models are interchangeable between the two implementations.
    """

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        config: PolicyValueNetConfig | None = None,
        device: str | torch.device | None = None,
    ) -> None:
        super().__init__()
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.config = config or PolicyValueNetConfig()

        # Resolve device ------------------------------------------------
        if device is None or device == "auto":
            self._device = _default_device()
        else:
            self._device = torch.device(device)

        hidden = self.config.hidden_dim
        hidden2 = self.config.hidden_dim2

        # Layers --------------------------------------------------------
        self.fc1 = nn.Linear(obs_dim, hidden)
        self.fc2 = nn.Linear(hidden, hidden2)
        self.policy_head = nn.Linear(hidden2, action_dim)
        self.value_head = nn.Linear(hidden2, 1)

        self._init_weights_from_rng()
        self.to(self._device)

        # Bookkeeping
        self.loaded_from: str | None = None

    # ------------------------------------------------------------------
    # Device helper
    # ------------------------------------------------------------------
    @property
    def device(self) -> torch.device:  # noqa: D401
        """Current device the model lives on."""
        return next(self.parameters()).device

    # ------------------------------------------------------------------
    # Weight initialisation (matches the NumPy version exactly)
    # ------------------------------------------------------------------
    def _init_weights_from_rng(self) -> None:
        rng = np.random.default_rng(self.config.seed)
        scale1 = 1.0 / math.sqrt(max(self.obs_dim, 1))
        scale2 = 1.0 / math.sqrt(max(self.config.hidden_dim, 1))
        scale3 = 1.0 / math.sqrt(max(self.config.hidden_dim2, 1))

        with torch.no_grad():
            # fc1
            self.fc1.weight.copy_(
                torch.from_numpy(rng.normal(0.0, scale1, (self.config.hidden_dim, self.obs_dim)).astype(np.float32))
            )
            nn.init.zeros_(self.fc1.bias)
            # fc2
            self.fc2.weight.copy_(
                torch.from_numpy(rng.normal(0.0, scale2, (self.config.hidden_dim2, self.config.hidden_dim)).astype(np.float32))
            )
            nn.init.zeros_(self.fc2.bias)
            # policy head
            self.policy_head.weight.copy_(
                torch.from_numpy(rng.normal(0.0, scale3, (self.action_dim, self.config.hidden_dim2)).astype(np.float32))
            )
            nn.init.zeros_(self.policy_head.bias)
            # value head
            self.value_head.weight.copy_(
                torch.from_numpy(rng.normal(0.0, scale3, (1, self.config.hidden_dim2)).astype(np.float32))
            )
            nn.init.zeros_(self.value_head.bias)

    # ------------------------------------------------------------------
    # Checkpoint I/O  (.npz — same format as the NumPy network)
    # ------------------------------------------------------------------
    @classmethod
    def from_checkpoint(
        cls,
        path: str | Path,
        device: str | torch.device | None = None,
    ) -> TorchPolicyValueNet:
        """Load from a ``.npz`` checkpoint (same format as :class:`PolicyValueNet`)."""
        checkpoint = np.load(Path(path), allow_pickle=False)
        config = PolicyValueNetConfig(
            hidden_dim=int(checkpoint["hidden_dim"]),
            hidden_dim2=int(checkpoint["hidden_dim2"]),
            seed=int(checkpoint["seed"]),
        )
        net = cls(
            obs_dim=int(checkpoint["obs_dim"]),
            action_dim=int(checkpoint["action_dim"]),
            config=config,
            device=device,
        )
        with torch.no_grad():
            # NumPy weights are (in, out); PyTorch Linear expects (out, in) → transpose
            net.fc1.weight.copy_(torch.from_numpy(checkpoint["w1"].astype(np.float32).T))
            net.fc1.bias.copy_(torch.from_numpy(checkpoint["b1"].astype(np.float32)))
            net.fc2.weight.copy_(torch.from_numpy(checkpoint["w2"].astype(np.float32).T))
            net.fc2.bias.copy_(torch.from_numpy(checkpoint["b2"].astype(np.float32)))
            net.policy_head.weight.copy_(torch.from_numpy(checkpoint["policy_w"].astype(np.float32).T))
            net.policy_head.bias.copy_(torch.from_numpy(checkpoint["policy_b"].astype(np.float32)))
            net.value_head.weight.copy_(torch.from_numpy(checkpoint["value_w"].astype(np.float32).T))
            net.value_head.bias.copy_(torch.from_numpy(checkpoint["value_b"].astype(np.float32)))
        net.loaded_from = str(Path(path))
        return net

    @classmethod
    def from_numpy_model(
        cls,
        numpy_model,  # PolicyValueNet
        device: str | torch.device | None = None,
    ) -> TorchPolicyValueNet:
        """Create a PyTorch model from an existing NumPy :class:`PolicyValueNet`."""
        net = cls(
            obs_dim=numpy_model.obs_dim,
            action_dim=numpy_model.action_dim,
            config=numpy_model.config,
            device=device,
        )
        with torch.no_grad():
            # NumPy weights are (in, out); PyTorch Linear expects (out, in) → transpose
            net.fc1.weight.copy_(torch.from_numpy(numpy_model.w1.T.copy()))
            net.fc1.bias.copy_(torch.from_numpy(numpy_model.b1))
            net.fc2.weight.copy_(torch.from_numpy(numpy_model.w2.T.copy()))
            net.fc2.bias.copy_(torch.from_numpy(numpy_model.b2))
            net.policy_head.weight.copy_(torch.from_numpy(numpy_model.policy_w.T.copy()))
            net.policy_head.bias.copy_(torch.from_numpy(numpy_model.policy_b))
            net.value_head.weight.copy_(torch.from_numpy(numpy_model.value_w.T.copy()))
            net.value_head.bias.copy_(torch.from_numpy(numpy_model.value_b))
        net.loaded_from = numpy_model.loaded_from
        return net

    def to_numpy_model(self):  # noqa: D102  (returns PolicyValueNet)
        """Convert this PyTorch model back to a NumPy :class:`PolicyValueNet`."""
        # Late import to avoid circular dependency
        from SDK.alphazero import PolicyValueNet

        numpy_model = PolicyValueNet(
            obs_dim=self.obs_dim,
            action_dim=self.action_dim,
            config=self.config,
        )
        with torch.no_grad():
            # PyTorch Linear weights are (out, in); NumPy expects (in, out) → transpose
            numpy_model.w1 = self.fc1.weight.detach().cpu().numpy().T.copy()
            numpy_model.b1 = self.fc1.bias.detach().cpu().numpy().copy()
            numpy_model.w2 = self.fc2.weight.detach().cpu().numpy().T.copy()
            numpy_model.b2 = self.fc2.bias.detach().cpu().numpy().copy()
            numpy_model.policy_w = self.policy_head.weight.detach().cpu().numpy().T.copy()
            numpy_model.policy_b = self.policy_head.bias.detach().cpu().numpy().copy()
            numpy_model.value_w = self.value_head.weight.detach().cpu().numpy().T.copy()
            numpy_model.value_b = self.value_head.bias.detach().cpu().numpy().copy()
        numpy_model.loaded_from = self.loaded_from
        return numpy_model

    def save(self, path: str | Path) -> None:
        """Save weights to ``.npz`` (compatible with the NumPy network)."""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with torch.no_grad():
            # PyTorch Linear weights are (out, in); NumPy format expects (in, out) → transpose
            np.savez(
                target,
                obs_dim=np.int64(self.obs_dim),
                action_dim=np.int64(self.action_dim),
                hidden_dim=np.int64(self.config.hidden_dim),
                hidden_dim2=np.int64(self.config.hidden_dim2),
                seed=np.int64(self.config.seed),
                w1=self.fc1.weight.detach().cpu().numpy().T.copy(),
                b1=self.fc1.bias.detach().cpu().numpy().copy(),
                w2=self.fc2.weight.detach().cpu().numpy().T.copy(),
                b2=self.fc2.bias.detach().cpu().numpy().copy(),
                policy_w=self.policy_head.weight.detach().cpu().numpy().T.copy(),
                policy_b=self.policy_head.bias.detach().cpu().numpy().copy(),
                value_w=self.value_head.weight.detach().cpu().numpy().T.copy(),
                value_b=self.value_head.bias.detach().cpu().numpy().copy(),
            )
        self.loaded_from = str(target)

    # ------------------------------------------------------------------
    # Inference  (called by MCTS during self-play)
    # ------------------------------------------------------------------
    @torch.no_grad()
    def predict(self, observation: np.ndarray, mask: np.ndarray) -> tuple[np.ndarray, float]:
        """Run inference on a single observation.

        Returns
        -------
        priors : np.ndarray   shape ``(action_dim,)`` float32
        value  : float
        """
        self.eval()
        obs_t = torch.from_numpy(observation.astype(np.float32)).unsqueeze(0).to(self.device)
        mask_t = torch.from_numpy(mask.astype(np.float32)).unsqueeze(0).to(self.device)

        hidden = F.relu(self.fc1(obs_t))
        hidden = F.relu(self.fc2(hidden))
        logits = self.policy_head(hidden)
        value = torch.tanh(self.value_head(hidden))

        # Masked softmax
        masked_logits = logits.clone()
        masked_logits[mask_t <= 0] = -1e9
        probs = F.softmax(masked_logits, dim=1)

        return probs[0].cpu().numpy(), float(value[0, 0].cpu().numpy())

    # ------------------------------------------------------------------
    # Training step  (runs on GPU when available)
    # ------------------------------------------------------------------
    def update(
        self,
        observations: np.ndarray,
        masks: np.ndarray,
        policy_targets: np.ndarray,
        value_targets: np.ndarray,
        learning_rate: float = 1e-3,
        value_weight: float = 1.0,
        l2_weight: float = 1e-5,
    ) -> dict[str, float]:
        """Execute one SGD step **with automatic differentiation on GPU**.

        The semantics match :meth:`PolicyValueNet.update` exactly:

        * Cross-entropy policy loss  (masked softmax)
        * MSE value loss
        * L2 regularisation on **weight** matrices only (not biases)
        * Vanilla SGD update

        Returns a metrics dict identical to the NumPy version.
        """
        self.train()

        # Move data to device ------------------------------------------------
        obs = torch.from_numpy(observations.astype(np.float32)).to(self.device)
        mask = torch.from_numpy(masks.astype(np.float32)).to(self.device)
        tgt_pol = torch.from_numpy(policy_targets.astype(np.float32)).to(self.device)
        tgt_val = torch.from_numpy(value_targets.astype(np.float32).reshape(-1, 1)).to(self.device)

        # Forward pass --------------------------------------------------------
        hidden1 = F.relu(self.fc1(obs))
        hidden2 = F.relu(self.fc2(hidden1))
        logits = self.policy_head(hidden2)
        values = torch.tanh(self.value_head(hidden2))

        # Masked softmax probabilities
        masked_logits = logits.clone()
        masked_logits[mask <= 0] = -1e9
        probs = F.softmax(masked_logits, dim=1)

        # Normalise target policy with mask
        tgt_pol = tgt_pol * mask
        pol_denom = tgt_pol.sum(dim=1, keepdim=True).clamp(min=1e-8)
        tgt_pol = tgt_pol / pol_denom

        # Losses
        safe_probs = probs.clamp(min=1e-8)
        policy_loss = -(tgt_pol * safe_probs.log()).sum(dim=1).mean()
        value_error = values - tgt_val
        value_loss = (value_error ** 2).mean()
        entropy = -(probs.clamp(min=1e-8).log() * probs).sum(dim=1).mean()

        # Total loss (no L2 here — L2 is added in the manual SGD step
        # to match the NumPy reference implementation exactly).
        total_loss = policy_loss + value_weight * value_loss

        # Backward + manual SGD with L2 (matches the NumPy implementation)
        total_loss.backward()

        with torch.no_grad():
            for module in (self.fc1, self.fc2, self.policy_head, self.value_head):
                module.weight -= learning_rate * (module.weight.grad + l2_weight * module.weight)
                module.bias -= learning_rate * module.bias.grad

        # Zero out gradients after the step
        self.zero_grad()

        return {
            "policy_loss": float(policy_loss.detach().cpu()),
            "value_loss": float(value_loss.detach().cpu()),
            "entropy": float(entropy.detach().cpu()),
            "mean_value_target": float(tgt_val.mean().detach().cpu()),
            "mean_prediction": float(values.mean().detach().cpu()),
        }
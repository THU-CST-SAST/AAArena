from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from SDK.utils.constants import (
    ANT_GENERATION_CYCLE,
    ANT_MAX_HP,
    LIGHTNING_STORM_ANT_DAMAGE,
    LIGHTNING_STORM_TOWER_DAMAGE,
    LIGHTNING_STORM_TOWER_INTERVAL,
    MAX_ACTIONS,
    MAX_ROUND,
    OperationType,
    PLAYER_BASES,
    STRATEGIC_BUILD_ORDER,
    SUPER_WEAPON_STATS,
    SuperWeaponType,
    TOWER_STATS,
    TOWER_UPGRADE_TREE,
    TowerType,
)
from SDK.utils.features import FeatureExtractor
from SDK.utils.geometry import hex_distance
from SDK.backend.state import BackendState
from SDK.backend.model import Operation, Tower
from SDK.utils.turns import DecisionContext


@dataclass
class ActionBundle:
    name: str
    operations: tuple[Operation, ...] = ()
    score: float = 0.0
    tags: tuple[str, ...] = field(default_factory=tuple)

    def protocol_lines(self) -> list[list[int]]:
        return [op.to_protocol_tokens() for op in self.operations]


class ActionCatalog:
    def __init__(self, max_actions: int = MAX_ACTIONS, feature_extractor: FeatureExtractor | None = None) -> None:
        self.max_actions = max_actions
        self.feature_extractor = feature_extractor or FeatureExtractor(max_actions=max_actions)

    def build(
        self,
        state: BackendState,
        player: int,
        context: DecisionContext | None = None,
        *,
        rerank: bool = True,
    ) -> list[ActionBundle]:
        if context is None:
            context = DecisionContext.for_player(player)
        bundles: list[ActionBundle] = [ActionBundle(name="hold", score=0.0, tags=("noop",))]
        bundles.extend(self._build_candidates(state, player))
        bundles.extend(self._upgrade_candidates(state, player))
        bundles.extend(self._downgrade_candidates(state, player))
        bundles.extend(self._base_upgrade_candidates(state, player))
        bundles.extend(self._superweapon_candidates(state, player))
        bundles.extend(self._paired_candidates(state, player, bundles[1:]))
        unique: dict[tuple[tuple[int, int, int], ...], ActionBundle] = {}
        for bundle in bundles:
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in bundle.operations)
            if key not in unique or bundle.score > unique[key].score:
                unique[key] = bundle
        ordered = sorted(unique.values(), key=lambda item: item.score, reverse=True)
        ordered = ordered[: min(len(ordered), self.max_actions * 2)]
        if not rerank:
            return ordered[: self.max_actions]
        reranked = self._rerank_with_one_step_rollout(state, player, context, ordered)
        return reranked[: self.max_actions]

    def action_mask(self, bundles: list[ActionBundle]) -> np.ndarray:
        mask = np.zeros(self.max_actions, dtype=np.int8)
        mask[: len(bundles)] = 1
        return mask

    def bundle_for_index(self, bundles: list[ActionBundle], action_index: int) -> ActionBundle:
        if 0 <= action_index < len(bundles):
            return bundles[action_index]
        return bundles[0]

    def _enemy_emp_threat_at(self, state: BackendState, player: int, x: int, y: int) -> float:
        """Return 0-1 threat level that enemy could EMP this position (from greedy EMP-aware building)."""
        enemy = 1 - player
        emp_cd = state.weapon_cooldowns[enemy, SuperWeaponType.EMP_BLASTER]
        if emp_cd > 0:
            return 0.0
        emp_cost = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost
        if state.coins[enemy] < emp_cost:
            return 0.0
        # Enemy can EMP — threat proportional to how many of our towers would be hit
        emp_range = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].attack_range
        my_towers_near = sum(
            1 for t in state.towers_of(player)
            if hex_distance(x, y, t.x, t.y) <= emp_range
        )
        return min(1.0, my_towers_near * 0.2)

    def _build_candidates(self, state: BackendState, player: int) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        tower_count = state.tower_count(player)
        build_cost = state.build_tower_cost(tower_count)
        if state.coins[player] < build_cost:
            return results
        round_ratio = state.round_index / MAX_ROUND
        for x, y in STRATEGIC_BUILD_ORDER[player]:
            op = Operation(OperationType.BUILD_TOWER, x, y)
            if not state.can_apply_operation(player, op):
                continue
            pressure = self._local_enemy_pressure(state, player, x, y)
            lane_bonus = state.slot_priority(player, x, y)
            score = lane_bonus + pressure * 2.5 - build_cost * 0.03
            # EMP-aware: penalize building where enemy can EMP our cluster
            emp_threat = self._enemy_emp_threat_at(state, player, x, y)
            score -= emp_threat * 5.0
            # Late game: penalize building new towers (towers won't pay off)
            if round_ratio > 0.8:
                score -= (round_ratio - 0.8) * 15.0
            results.append(ActionBundle(name=f"build@{x},{y}", operations=(op,), score=score, tags=("build",)))
        return results

    def _upgrade_candidates(self, state: BackendState, player: int) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        enemy_base = PLAYER_BASES[1 - player]
        for tower in state.towers_of(player):
            local_density = self._local_enemy_pressure(state, player, tower.x, tower.y)
            for target in TOWER_UPGRADE_TREE.get(tower.tower_type, ()): 
                op = Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target))
                if not state.can_apply_operation(player, op):
                    continue
                fit = self._tower_type_fit(target, local_density, hex_distance(tower.x, tower.y, *enemy_base))
                score = fit + tower.level * 1.5 + state.slot_priority(player, tower.x, tower.y) * 0.15
                results.append(
                    ActionBundle(
                        name=f"upgrade#{tower.tower_id}->{int(target)}",
                        operations=(op,),
                        score=score,
                        tags=("upgrade", f"tower:{int(target)}"),
                    )
                )
        return results

    def _downgrade_candidates(self, state: BackendState, player: int) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        for tower in state.towers_of(player):
            pressure = self._local_enemy_pressure(state, player, tower.x, tower.y)
            if pressure > 1.5:
                continue
            op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
            if not state.can_apply_operation(player, op):
                continue
            refund = state.operation_income(player, op)
            score = refund * 0.04 - state.slot_priority(player, tower.x, tower.y) * 0.3 - tower.level * 3.0
            results.append(ActionBundle(name=f"downgrade#{tower.tower_id}", operations=(op,), score=score, tags=("sell",)))
        return results

    def _base_upgrade_candidates(self, state: BackendState, player: int) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        round_ratio = state.round_index / MAX_ROUND
        enemy = 1 - player
        hp_delta = state.bases[player].hp - state.bases[enemy].hp

        if state.bases[player].ant_level < 2:
            level = state.bases[player].ant_level
            hp_gain = ANT_MAX_HP[level + 1] - ANT_MAX_HP[level]
            if hp_gain > 0:
                op = Operation(OperationType.UPGRADE_GENERATED_ANT)
                if state.can_apply_operation(player, op):
                    score = 8.0 + hp_gain * 1.4 + state.frontline_distance(player) * 0.22 - state.round_index * 0.01 - level * 1.2
                    results.append(ActionBundle("upgrade-ant", (op,), score, ("base", "offense")))

                # --- Sell+ant upgrade combo (from greedy _try_attack) ---
                # When losing or pressured, sell a tower to afford ant upgrade
                if not state.can_apply_operation(player, op) and round_ratio > 0.3:
                    for tower in state.towers_of(player):
                        sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                        if not state.can_apply_operation(player, sell_op):
                            continue
                        refund = state.operation_income(player, sell_op)
                        upgrade_cost = -state.operation_income(player, op)
                        if state.coins[player] + refund >= upgrade_cost:
                            trial = state.clone()
                            trial.apply_operation_list(player, (sell_op, op))
                            # Verify it works
                            combo_score = 6.0 + hp_gain * 1.2 - level * 1.0
                            # Extra priority when behind (assault mode from greedy)
                            if hp_delta < 0:
                                combo_score += 4.0
                            if round_ratio > 0.9:
                                combo_score += 3.0
                            results.append(ActionBundle(
                                f"sell+ant-upg#{tower.tower_id}",
                                (sell_op, op),
                                combo_score,
                                ("base", "offense", "combo"),
                            ))
                            break  # Only need one sell target

        if state.bases[player].generation_level < 2:
            level = state.bases[player].generation_level
            current_cycle = ANT_GENERATION_CYCLE[level]
            next_cycle = ANT_GENERATION_CYCLE[level + 1]
            if next_cycle < current_cycle - 1e-6:
                op = Operation(OperationType.UPGRADE_GENERATION_SPEED)
                if state.can_apply_operation(player, op):
                    tempo_gain = current_cycle - next_cycle
                    score = 10.0 + tempo_gain * 14.0 + state.nearest_ant_distance(player) * 0.12 - state.round_index * 0.015
                    results.append(ActionBundle("upgrade-gen", (op,), score, ("base", "tempo")))

                # --- Sell+gen upgrade combo (from greedy _try_attack) ---
                # When losing badly, sell everything to afford generation speed upgrade
                if not state.can_apply_operation(player, op) and hp_delta < 0 and round_ratio > 0.5:
                    for tower in state.towers_of(player):
                        sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                        if not state.can_apply_operation(player, sell_op):
                            continue
                        refund = state.operation_income(player, sell_op)
                        upgrade_cost = -state.operation_income(player, op)
                        if state.coins[player] + refund >= upgrade_cost:
                            trial = state.clone()
                            trial.apply_operation_list(player, (sell_op, op))
                            combo_score = 8.0 + tempo_gain * 10.0
                            if round_ratio > 0.85:
                                combo_score += 3.0
                            results.append(ActionBundle(
                                f"sell+gen-upg#{tower.tower_id}",
                                (sell_op, op),
                                combo_score,
                                ("base", "tempo", "combo"),
                            ))
                            break

        return results

    def _superweapon_candidates(self, state: BackendState, player: int) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        enemy = 1 - player
        enemy_ants = state.ants_of(enemy)
        my_ants = state.ants_of(player)
        enemy_towers = state.towers_of(enemy)
        round_ratio = state.round_index / MAX_ROUND

        # --- Lightning Storm (enhanced with greedy-inspired logic) ---
        if state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM] == 0 and state.coins[player] >= SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost:
            centers = {(ant.x, ant.y) for ant in enemy_ants}
            centers.update((tower.x, tower.y) for tower in enemy_towers)
            # Add enemy base area as target (greedy targets STORM_SLOT near enemy base)
            enemy_base_x, enemy_base_y = PLAYER_BASES[enemy]
            centers.add((enemy_base_x, enemy_base_y))
            # Also add positions near enemy base for wall-of-damage effect
            for dx in range(-2, 3):
                for dy in range(-2, 3):
                    nx, ny = enemy_base_x + dx, enemy_base_y + dy
                    if 0 <= nx < 19 and 0 <= ny < 19:
                        centers.add((nx, ny))

            # Late-game urgency: boost score and lower threshold
            late_game_bonus = 0.0
            threshold = 1.5
            if round_ratio > 0.7:  # After round ~350
                late_game_bonus = (round_ratio - 0.7) * 15.0
                threshold = max(0.3, 1.5 - (round_ratio - 0.7) * 4.0)
            if round_ratio > 0.9:  # After round ~450: very aggressive
                late_game_bonus += 8.0
                threshold = 0.0

            best = max(
                ((x, y, self._storm_value(state, player, x, y) + late_game_bonus) for x, y in centers),
                key=lambda item: item[2],
                default=None,
            )
            if best and best[2] > threshold:
                op = Operation(OperationType.USE_LIGHTNING_STORM, best[0], best[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle(f"storm@{best[0]},{best[1]}", (op,), best[2], ("weapon", "storm")))
        
        # --- Storm + Sell: liquidate a tower to afford storm in late game ---
        if (not results
            and state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM] == 0
            and round_ratio > 0.75
            and state.coins[player] < SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost):
            storm_cost = SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost
            deficit = storm_cost - state.coins[player]
            # Try selling one tower to afford storm
            for tower in state.towers_of(player):
                sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                if not state.can_apply_operation(player, sell_op):
                    continue
                refund = state.operation_income(player, sell_op)
                if state.coins[player] + refund < storm_cost:
                    continue
                # Simulate: sell tower then cast storm
                trial = state.clone()
                trial.apply_operation_list(player, (sell_op,))
                # Re-evaluate storm targets after selling
                best_storm = None
                best_val = -1e9
                enemy_bx, enemy_by = PLAYER_BASES[enemy]
                storm_centers = {(enemy_bx, enemy_by)}
                for ant in trial.ants_of(enemy):
                    storm_centers.add((ant.x, ant.y))
                for tower_e in trial.towers_of(enemy):
                    storm_centers.add((tower_e.x, tower_e.y))
                for sx, sy in storm_centers:
                    storm_op = Operation(OperationType.USE_LIGHTNING_STORM, sx, sy)
                    if trial.can_apply_operation(player, storm_op):
                        val = self._storm_value(trial, player, sx, sy)
                        if val > best_val:
                            best_val = val
                            best_storm = (sx, sy)
                if best_storm and best_val > 0.5:
                    combined = (sell_op, Operation(OperationType.USE_LIGHTNING_STORM, best_storm[0], best_storm[1]))
                    trial2 = state.clone()
                    invalid = trial2.apply_operation_list(player, combined)
                    if not invalid:
                        score = best_val + (round_ratio - 0.75) * 10.0
                        results.append(ActionBundle(f"sell+storm@{best_storm[0]},{best_storm[1]}", combined, score, ("weapon", "storm", "combo")))
                    break  # Only try the first viable sell target

        # --- EMP Blaster (enhanced with greedy scoring + sell combo) ---
        if state.weapon_cooldowns[player, SuperWeaponType.EMP_BLASTER] == 0:
            emp_cost = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost
            can_emp = state.coins[player] >= emp_cost
            prefix_ops: tuple[Operation, ...] = ()

            # Sell+EMP combo: liquidate a tower to afford EMP
            if not can_emp and round_ratio > 0.5:
                for tower in state.towers_of(player):
                    sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                    if not state.can_apply_operation(player, sell_op):
                        continue
                    refund = state.operation_income(player, sell_op)
                    if state.coins[player] + refund >= emp_cost:
                        prefix_ops = (sell_op,)
                        can_emp = True
                        break

            if can_emp and enemy_towers:
                centers = {(tower.x, tower.y) for tower in enemy_towers}
                scored = [
                    (x, y, self._emp_value(state, player, x, y))
                    for x, y in centers
                ]
                best = max(scored, key=lambda item: item[2], default=None)
                if best and best[2] > 2.0:
                    op = Operation(OperationType.USE_EMP_BLASTER, best[0], best[1])
                    if state.can_apply_operation(player, op):
                        ops = prefix_ops + (op,)
                        score = best[2] + (round_ratio - 0.5) * 3.0
                        results.append(ActionBundle(f"emp@{best[0]},{best[1]}", ops, score, ("weapon", "emp")))

        # --- Precompute shared state ---
        hostile_dist = state.nearest_ant_distance(player)
        hp_delta = state.bases[player].hp - state.bases[enemy].hp

        # --- End-game finishing storm: when winning, storm enemy base STORM_SLOT (from greedy _try_end_storm) ---
        if (not results
            and state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM] == 0
            and state.coins[player] >= SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost
            and hp_delta > 0
            and round_ratio > 0.95):
            enemy_base_x, enemy_base_y = PLAYER_BASES[enemy]
            # Storm right on enemy base as finishing move
            storm_op = Operation(OperationType.USE_LIGHTNING_STORM, enemy_base_x, enemy_base_y)
            if state.can_apply_operation(player, storm_op):
                val = self._storm_value(state, player, enemy_base_x, enemy_base_y)
                val += 10.0 + (round_ratio - 0.95) * 50.0  # Huge late-game bonus
                results.append(ActionBundle(f"end-storm@{enemy_base_x},{enemy_base_y}", (storm_op,), val, ("weapon", "storm", "finishing")))

        # --- Emergency Defensive Storm: use storm defensively when base is under threat ---
        if (not results
            and state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM] == 0
            and state.coins[player] >= SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost
            and hostile_dist <= 4
            and hp_delta <= 5
        ):
            # Find best defensive storm center (near our base, hitting enemy ants)
            my_base_x, my_base_y = PLAYER_BASES[player]
            best_def = None
            best_def_val = -1e9
            for ant in state.ants_of(1 - player):
                for cx, cy in [(ant.x, ant.y), (my_base_x, my_base_y)]:
                    val = self._storm_value(state, player, cx, cy)
                    # Bonus for protecting our base area
                    base_dist = hex_distance(cx, cy, my_base_x, my_base_y)
                    if base_dist <= 4:
                        val += 5.0 - base_dist
                    if val > best_def_val:
                        best_def_val = val
                        best_def = (cx, cy)
            if best_def and best_def_val > 0.5:
                op = Operation(OperationType.USE_LIGHTNING_STORM, best_def[0], best_def[1])
                if state.can_apply_operation(player, op):
                    results.append(ActionBundle(f"def-storm@{best_def[0]},{best_def[1]}", (op,), best_def_val + 3.0, ("weapon", "storm", "defensive")))

        # --- Deflector (enhanced: use near enemy base when pushing, + sell combo) ---
        if my_ants and state.weapon_cooldowns[player, SuperWeaponType.DEFLECTOR] == 0:
            deflect_cost = SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR].cost
            can_deflect = state.coins[player] >= deflect_cost
            prefix_ops_d: tuple[Operation, ...] = ()
            if not can_deflect and round_ratio > 0.7:
                for tower in state.towers_of(player):
                    sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                    if not state.can_apply_operation(player, sell_op):
                        continue
                    refund = state.operation_income(player, sell_op)
                    if state.coins[player] + refund >= deflect_cost:
                        prefix_ops_d = (sell_op,)
                        can_deflect = True
                        break
            if can_deflect:
                best = max(
                    ((ant.x, ant.y, self._deflector_value(state, player, ant.x, ant.y)) for ant in my_ants),
                    key=lambda item: item[2],
                    default=None,
                )
                if best and best[2] > 1.5:
                    op = Operation(OperationType.USE_DEFLECTOR, best[0], best[1])
                    if state.can_apply_operation(player, op):
                        ops = prefix_ops_d + (op,)
                        results.append(ActionBundle(f"deflect@{best[0]},{best[1]}", ops, best[2], ("weapon", "shield")))

        # --- Emergency Evasion (enhanced: require ant group, + sell combo) ---
        if my_ants and state.weapon_cooldowns[player, SuperWeaponType.EMERGENCY_EVASION] == 0:
            eva_cost = SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].cost
            can_eva = state.coins[player] >= eva_cost
            prefix_ops_e: tuple[Operation, ...] = ()
            if not can_eva and round_ratio > 0.7:
                for tower in state.towers_of(player):
                    sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
                    if not state.can_apply_operation(player, sell_op):
                        continue
                    refund = state.operation_income(player, sell_op)
                    if state.coins[player] + refund >= eva_cost:
                        prefix_ops_e = (sell_op,)
                        can_eva = True
                        break
            if can_eva:
                best = max(
                    ((ant.x, ant.y, self._evasion_value(state, player, ant.x, ant.y)) for ant in my_ants),
                    key=lambda item: item[2],
                    default=None,
                )
                if best and best[2] > 1.0:
                    # Greedy: require at least 3 ants in range for evasion (2 in late game)
                    eva_range = SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].attack_range
                    ants_in_range = sum(
                        1 for ant in my_ants
                        if hex_distance(best[0], best[1], ant.x, ant.y) <= eva_range
                    )
                    min_ants = 2 if round_ratio > 0.9 else 3
                    if ants_in_range >= min_ants:
                        op = Operation(OperationType.USE_EMERGENCY_EVASION, best[0], best[1])
                        if state.can_apply_operation(player, op):
                            ops = prefix_ops_e + (op,)
                            results.append(ActionBundle(f"evasion@{best[0]},{best[1]}", ops, best[2], ("weapon", "panic")))

        return results

    def _paired_candidates(self, state: BackendState, player: int, singles: list[ActionBundle]) -> list[ActionBundle]:
        results: list[ActionBundle] = []
        left = [bundle for bundle in singles if bundle.tags and bundle.tags[0] in {"sell", "build", "upgrade", "base"}]
        left = sorted(left, key=lambda item: item.score, reverse=True)[:8]
        for first in left:
            for second in left:
                if first is second:
                    continue
                operations = first.operations + second.operations
                if len(operations) > 2:
                    continue
                trial = state.clone()
                invalid_ops = trial.apply_operation_list(player, operations)
                if invalid_ops:
                    continue
                score = first.score + second.score * 0.9
                name = f"{first.name}+{second.name}"
                results.append(ActionBundle(name=name, operations=tuple(operations), score=score, tags=("combo",)))
        return results

    def _rerank_with_one_step_rollout(
        self,
        state: BackendState,
        player: int,
        context: DecisionContext,
        bundles: list[ActionBundle],
    ) -> list[ActionBundle]:
        baseline = self.feature_extractor.evaluate(state, player, context=context)
        reranked: list[ActionBundle] = []
        for bundle in bundles:
            trial = state.clone()
            trial.apply_operation_list(player, bundle.operations)
            child_context = context.next_turn()
            if not trial.terminal:
                if context.settles_after_action:
                    trial.advance_round()
                else:
                    enemy = 1 - player
                    enemy_bundles = self.build(trial, enemy, child_context, rerank=False)
                    enemy_bundle = enemy_bundles[0] if enemy_bundles else ActionBundle(name="hold")
                    trial.apply_operation_list(enemy, enemy_bundle.operations)
                    if not trial.terminal:
                        trial.advance_round()
            rollout_value = self.feature_extractor.evaluate(trial, player, context=DecisionContext.for_player(player)) - baseline
            reranked.append(ActionBundle(bundle.name, bundle.operations, bundle.score + rollout_value * 0.2, bundle.tags))
        reranked.sort(key=lambda item: item.score, reverse=True)
        if not reranked:
            return [ActionBundle(name="hold")]
        return reranked

    def _local_enemy_pressure(self, state: BackendState, player: int, x: int, y: int) -> float:
        pressure = 0.0
        for ant in state.ants_of(1 - player):
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance <= 6:
                pressure += max(0.0, 6.5 - distance) * (1.0 + ant.level * 0.4)
        return pressure

    def _tower_type_fit(self, tower_type: TowerType, local_density: float, forward_distance: int) -> float:
        if tower_type in (TowerType.HEAVY, TowerType.HEAVY_PLUS, TowerType.BEWITCH):
            return local_density * 1.1 - forward_distance * 0.1
        if tower_type in (TowerType.ICE, TowerType.PULSE):
            return local_density * 1.3
        if tower_type in (TowerType.MORTAR, TowerType.MORTAR_PLUS, TowerType.MISSILE):
            return local_density * 0.85 + max(0.0, 12 - forward_distance)
        if tower_type in (TowerType.QUICK, TowerType.QUICK_PLUS, TowerType.DOUBLE):
            return local_density * 0.9 + 4.0
        if tower_type == TowerType.SNIPER:
            return max(0.0, 18 - forward_distance) + local_density * 0.4
        if tower_type in (TowerType.PRODUCER, TowerType.PRODUCER_FAST, TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC):
            stats = TOWER_STATS[tower_type]
            cadence = 12.0 / max(stats.spawn_interval, 1)
            density_bonus = max(0.0, 10 - local_density) * 0.75
            forward_bonus = max(0.0, 16 - forward_distance) * 0.22
            branch_bonus = {
                TowerType.PRODUCER: 0.0,
                TowerType.PRODUCER_FAST: 0.5,
                TowerType.PRODUCER_SIEGE: 1.1,
                TowerType.PRODUCER_MEDIC: 1.0,
            }[tower_type]
            return density_bonus + forward_bonus + cadence + branch_bonus
        return 0.0

    def _storm_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        enemy = 1 - player
        stats = SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM]
        tower_strikes = max(stats.duration // LIGHTNING_STORM_TOWER_INTERVAL, 1)
        total = 0.0
        enemy_base_x, enemy_base_y = PLAYER_BASES[enemy]

        # --- Ant damage (unchanged) ---
        for ant in state.ants_of(enemy):
            distance = hex_distance(x, y, ant.x, ant.y)
            if distance > stats.attack_range:
                continue
            immediate_damage = min(LIGHTNING_STORM_ANT_DAMAGE, ant.hp)
            sustained_damage = min(ant.hp, LIGHTNING_STORM_ANT_DAMAGE * tower_strikes)
            total += immediate_damage / max(ant.max_hp, 1) * (2.5 + ant.level)
            total += sustained_damage / max(ant.max_hp, 1) * (0.8 + ant.level * 0.4)
            if ant.hp <= LIGHTNING_STORM_ANT_DAMAGE:
                total += ant.kill_reward
            total += max(0.0, stats.attack_range + 1 - distance) * 0.2

        # --- Tower damage (unchanged) ---
        for tower in state.towers_of(enemy):
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance > stats.attack_range:
                continue
            projected_damage = min(tower.hp, LIGHTNING_STORM_TOWER_DAMAGE * tower_strikes)
            total += projected_damage / max(tower.max_hp, 1) * (6.0 + tower.level * 2.5)
            total += max(0.0, stats.attack_range + 1 - distance) * 0.15

        # --- NEW: Enemy base proximity bonus (storming near enemy base is very valuable) ---
        base_distance = hex_distance(x, y, enemy_base_x, enemy_base_y)
        if base_distance <= stats.attack_range:
            # Strong bonus for hitting near enemy base (wall-of-damage / ant-blocking)
            base_closeness = max(0.0, stats.attack_range + 1 - base_distance)
            total += base_closeness * 1.5
            # Extra bonus if storm center is very close to enemy base
            if base_distance <= 3:
                total += 4.0

        # --- NEW: My ant count bonus (storm is more valuable when pushing) ---
        my_ants_near = sum(
            1 for ant in state.ants_of(player)
            if hex_distance(ant.x, ant.y, x, y) <= stats.attack_range + 2
        )
        if my_ants_near > 0:
            total += my_ants_near * 0.3

        return total - stats.cost * 0.03

    def _emp_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        """Enhanced EMP scoring with greedy tower-type weighting and base proximity bonus."""
        total = 0.0
        emp_range = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].attack_range
        enemy_base_x, enemy_base_y = PLAYER_BASES[1 - player]
        for tower in state.towers_of(1 - player):
            distance = hex_distance(x, y, tower.x, tower.y)
            if distance > emp_range:
                continue
            # Greedy tower-type weighting: 50/60/80 for BASIC/intermediate/advanced
            if tower.tower_type == TowerType.BASIC:
                total += 50.0
            elif tower.level <= 1:
                total += 60.0
            else:
                total += 80.0
            # Higher-level towers are more valuable to EMP
            total += tower.level * 15.0
        # Greedy: bonus for hitting near enemy base path slots
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                nx, ny = enemy_base_x + dx, enemy_base_y + dy
                if hex_distance(x, y, nx, ny) <= emp_range:
                    base_dist = hex_distance(nx, ny, enemy_base_x, enemy_base_y)
                    total += max(0.0, 3 - base_dist) * 0.5
        # Must have significant value to justify EMP cost
        if total < 100:
            return total * 0.01 - SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost * 0.025
        return total * 0.05 - SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost * 0.025

    def _deflector_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        """Enhanced deflector scoring with enemy base proximity bonus (from greedy _try_use_superweapon)."""
        total = 0.0
        deflect_range = SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR].attack_range
        ant_count = 0
        min_enemy_base_dist = 100
        enemy_base_x, enemy_base_y = PLAYER_BASES[1 - player]
        for ant in state.ants_of(player):
            if hex_distance(x, y, ant.x, ant.y) <= deflect_range:
                total += 0.8 + ant.level * 0.8
                ant_count += 1
                dist_to_enemy_base = hex_distance(ant.x, ant.y, enemy_base_x, enemy_base_y)
                min_enemy_base_dist = min(min_enemy_base_dist, dist_to_enemy_base)
        # Greedy: bonus when ants are close to enemy base (pushing hard)
        if ant_count >= 3 and min_enemy_base_dist <= 5:
            total += 8.0 - min_enemy_base_dist
        total += max(0.0, 7 - state.nearest_ant_distance(player)) * 0.5
        return total - SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR].cost * 0.02

    def _evasion_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        """Enhanced evasion scoring with enemy base proximity and ant group size bonus (from greedy)."""
        total = 0.0
        eva_range = SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].attack_range
        ant_count = 0
        ant_level_sum = 0.0
        min_enemy_base_dist = 100
        enemy_base_x, enemy_base_y = PLAYER_BASES[1 - player]
        for ant in state.ants_of(player):
            if hex_distance(x, y, ant.x, ant.y) <= eva_range:
                total += 0.6 + ant.level * 0.7
                ant_count += 1
                ant_level_sum += ant.level + 1
                dist_to_enemy_base = hex_distance(ant.x, ant.y, enemy_base_x, enemy_base_y)
                min_enemy_base_dist = min(min_enemy_base_dist, dist_to_enemy_base)
        # Greedy: bonus for ant groups close to enemy base (critical push moment)
        if ant_count >= 2 and min_enemy_base_dist <= 5:
            total += ant_level_sum * 1.5
        # Greedy: larger groups get bonus
        if ant_count >= 4:
            total += ant_count * 0.5
        total += max(0.0, 5 - state.nearest_ant_distance(player))
        return total - SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].cost * 0.02

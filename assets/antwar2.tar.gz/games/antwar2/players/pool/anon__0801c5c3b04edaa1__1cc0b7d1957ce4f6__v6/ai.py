from __future__ import annotations

import math
import os
import time
from pathlib import Path
from typing import Optional

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.utils.actions import ActionBundle
from SDK.utils.constants import (
    MAX_ACTIONS,
    MAX_ROUND,
    ANT_AGE_LIMIT,
    PLAYER_BASES,
    LEVEL2_TOWER_UPGRADE_COST,
    LEVEL3_TOWER_UPGRADE_COST,
    OperationType,
    SuperWeaponType,
    SUPER_WEAPON_STATS,
    TowerType,
    tower_build_cost_for_count,
)
from SDK.utils.geometry import hex_distance
from SDK.backend.state import BackendState
from SDK.utils.turns import DecisionContext


# ---------------------------------------------------------------------------
# Greedy-style scoring - mirrors the greedy ForecastNode.evaluate() exactly
# ---------------------------------------------------------------------------

# Constants from greedy AI
EVALUATION_HORIZON = 60
TOWER_COUNT_SCORE = 1.0
BASE_ARC_TARGET_DEGREES = (-30.0, 0.0, 30.0)
BASE_ARC_TOLERANCE_DEGREES = 20.0
BASE_ARC_MISSING_PENALTY = 8.0


def _world_pos(x: int, y: int) -> tuple[float, float]:
    return x + 0.5 * (y & 1), y * math.sqrt(3) / 2.0


def _angle_delta(angle: float, target: float) -> float:
    return (angle - target + math.pi) % (2 * math.pi) - math.pi


def _simulate_and_score(
    state: BackendState,
    player: int,
    horizon: int,
    base_hp_snapshot: int,
    sunk_cost: float = 0.0,
) -> tuple[float, BackendState]:
    """Simulate *horizon* rounds and return (score, final_state).

    Tracks HP trajectory and distance trace during simulation,
    matching greedy ForecastNode.evaluate() closely.
    """
    enemy = 1 - player
    my_base_x, my_base_y = PLAYER_BASES[player]
    enemy_base_x, enemy_base_y = PLAYER_BASES[enemy]

    # Determine front_state (from greedy __call__)
    front_state = 0
    if state.bases[player].hp > state.bases[enemy].hp:
        front_state = 1
    elif state.bases[player].hp < state.bases[enemy].hp:
        front_state = -1

    sim = state.clone()
    collapse_round = horizon   # first round where HP drops by >= 1
    ruin_round = horizon       # first round where HP drops by >= 2

    # Record baseline counts for delta computation (matching greedy)
    baseline_old_enemy = state.old_count[enemy]
    baseline_die_enemy = state.die_count[enemy]

    # Distance trace (matching greedy ForecastNode)
    distance_trace = [0] * horizon

    # --- Run simulation, tracking HP drops ---
    for step in range(horizon):
        if sim.terminal:
            cur_hp = sim.bases[player].hp
            if cur_hp <= 0:
                collapse_round = step
            break
        sim.advance_round()
        cur_hp = sim.bases[player].hp

        # Track nearest hostile distance at each step
        hostile_dist = sim.nearest_ant_distance(player)
        distance_trace[step] = hostile_dist

        # Track HP drops (FIX: hp_drop2 tracks HP drop >= 2, not >= 1)
        if cur_hp < base_hp_snapshot and collapse_round == horizon:
            collapse_round = step + 1
        if cur_hp <= base_hp_snapshot - 2 and ruin_round == horizon:
            ruin_round = step + 1
        if cur_hp <= 0:
            collapse_round = step + 1
            ruin_round = step + 1
            break

    final_hp = sim.bases[player].hp
    final_enemy_hp = sim.bases[enemy].hp
    hp_lost = base_hp_snapshot - final_hp

    # --- 1. Survival window (matching greedy _score_survival_window exactly) ---
    if final_hp <= 0:
        survival_score = -500.0 + collapse_round * 0.8 + (ruin_round - collapse_round) * 0.1 - sunk_cost * 1.5 + 20
    elif hp_lost > 0:
        survival_score = (
            (final_hp - base_hp_snapshot)
            + collapse_round * 0.8
            + (ruin_round - collapse_round) * 0.1
            - sunk_cost * 1.5
            + 20
        )
    else:
        survival_score = 20.0 + horizon * 0.5

    # --- 2. Danger window (matching greedy _score_danger_window exactly) ---
    danger_score = 0.0
    if collapse_round <= 16:
        danger_score = -500.0
        if ruin_round - collapse_round <= 8:
            danger_score -= 300.0

    # --- 3. HP delta ---
    hp_delta = final_hp - final_enemy_hp

    # --- 4. Frontline trades (FIX: matching greedy _score_frontline_trades exactly) ---
    #   Greedy uses old_count[enemy] delta with weight 2.0, die_count[enemy] delta with weight 1.5
    #   Only applied when front_state == 0 (tied game)
    frontline_trade = 0.0
    if front_state == 0:
        ant_weight = {0: 3.0, 1: 5.0, 2: 7.0}.get(state.bases[enemy].ant_level, 3.0)
        old_delta_enemy = sim.old_count[enemy] - baseline_old_enemy
        die_delta_enemy = sim.die_count[enemy] - baseline_die_enemy
        frontline_trade = (
            -old_delta_enemy * ant_weight * 2.0
            + die_delta_enemy * ant_weight * 1.5
        )

    # --- 5. Hostile distance trace (matching greedy _score_hostile_distance_trace) ---
    hostile_trace_score = 0.0
    if front_state >= 0:
        close_flag = False
        # Only score steps 0..N-4 (matching greedy's min(horizon, round - current - 4))
        trace_len = min(horizon, max(0, sim.round_index - state.round_index - 4))
        for idx in range(trace_len):
            d = distance_trace[idx]
            if d <= 3:
                close_flag = True
            if d == 5:
                hostile_trace_score -= 0.2
            elif d == 4:
                hostile_trace_score -= 2.5
            elif d in (1, 2, 3):
                hostile_trace_score -= 2.0
        if close_flag:
            hostile_trace_score -= 20.0

    # --- 6. Enemy pressure (matching greedy _score_enemy_pressure) ---
    pressure_score = 0.0
    enemy_ants = sim.ants_of(enemy)
    if enemy_ants and state.round_index >= 20:
        total_pressure = 0.0
        enemy_count = 0
        for ant in enemy_ants:
            total_pressure += (ANT_AGE_LIMIT - ant.age - hex_distance(ant.x, ant.y, my_base_x, my_base_y) * 1.5)
            enemy_count += 1
        if enemy_count > 0:
            pressure_score = total_pressure / enemy_count * 0.5

    # --- 7. Tower evaluation ---
    my_towers = state.towers_of(player)  # Use pre-simulation towers (what we actually built)
    tower_count = len(my_towers)

    tower_count_score = tower_count * TOWER_COUNT_SCORE

    build_investment = sum(tower_build_cost_for_count(i) for i in range(max(tower_count, 0)))
    investment_penalty = -build_investment * 0.2 * 0.75
    for tower in my_towers:
        tt = tower.tower_type
        if tt != _BASIC_TYPE:
            if tower.level <= 1:
                investment_penalty -= LEVEL2_TOWER_UPGRADE_COST * 0.2 * 0.75
            else:
                investment_penalty -= (LEVEL2_TOWER_UPGRADE_COST + LEVEL3_TOWER_UPGRADE_COST) * 0.2 * 0.75

    spacing_score = 0.0
    if tower_count > 1:
        spacing_penalty = 0.0
        distant_pair = False
        for idx, tower in enumerate(my_towers[:-1]):
            for other in my_towers[idx + 1:]:
                gap = hex_distance(tower.x, tower.y, other.x, other.y)
                if gap <= 3:
                    spacing_penalty += 5
                elif gap <= 6:
                    spacing_penalty += 2
                else:
                    distant_pair = True
        if tower_count >= 3 and not distant_pair:
            spacing_penalty += 20
        spacing_score = -spacing_penalty / math.sqrt(tower_count)

    advancement_score = sum(hex_distance(t.x, t.y, my_base_x, my_base_y) * 0.4 for t in my_towers)

    # --- 8. Base arc coverage (matching greedy _score_base_arc_coverage) ---
    base_wx, base_wy = _world_pos(my_base_x, my_base_y)
    enemy_wx, enemy_wy = _world_pos(enemy_base_x, enemy_base_y)
    forward_angle = math.atan2(enemy_wy - base_wy, enemy_wx - base_wx)
    tolerance = math.radians(BASE_ARC_TOLERANCE_DEGREES)
    covered = {t: False for t in BASE_ARC_TARGET_DEGREES}
    for tower in my_towers:
        twx, twy = _world_pos(tower.x, tower.y)
        angle = math.atan2(twy - base_wy, twx - base_wx)
        if abs(_angle_delta(angle, forward_angle)) > math.pi / 2:
            continue
        for target in BASE_ARC_TARGET_DEGREES:
            target_angle = forward_angle + math.radians(target)
            if abs(_angle_delta(angle, target_angle)) <= tolerance:
                covered[target] = True
    arc_missing = sum(1 for hit in covered.values() if not hit)
    arc_score = -arc_missing * BASE_ARC_MISSING_PENALTY

    # --- 9. Cash safety (matching greedy _score_cash_safety) ---
    cash_safety_score = 0.0
    if front_state >= 0 and state.round_index > 60:
        emp_cost = SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].cost
        emp_cd = state.weapon_cooldowns[enemy, SuperWeaponType.EMP_BLASTER]
        emp_buffer = 0
        if emp_cd == 0:
            emp_buffer = min(state.coins[enemy], max(emp_cost - 1, 0))
        safe_gap = min(0, state.coins[player] - emp_buffer)
        solvent = safe_gap == 0
        danger = collapse_round <= 16
        if not solvent and not danger and front_state >= 0:
            cash_safety_score = (-40 + safe_gap / 5) * min((state.round_index - 60) / 30, 1)

    # --- Combine (matching greedy ForecastNode.evaluate weights exactly) ---
    total = 0.0
    total += survival_score
    total += frontline_trade
    total += danger_score
    total += cash_safety_score
    total += tower_count_score
    total += investment_penalty
    total += spacing_score
    total += advancement_score
    total += arc_score
    total += hostile_trace_score
    total -= pressure_score
    total += hp_delta * 2.0

    return total, sim


def _compute_sunk_cost(state: BackendState, player: int, operations: tuple) -> float:
    """Compute sunk cost from downgrade operations (matching greedy's sunk_cost tracking)."""
    sunk_cost = 0.0
    for op in operations:
        if op.op_type == OperationType.DOWNGRADE_TOWER:
            tower = state.tower_by_id(op.arg0)
            if tower is not None:
                if tower.tower_type == _BASIC_TYPE:
                    sunk_cost += state.build_tower_cost() * 0.2
                else:
                    sunk_cost += state.upgrade_tower_cost(tower.tower_type) * 0.2
    return sunk_cost


def _greedy_score(
    state: BackendState,
    player: int,
    base_hp_snapshot: int,
    initial_hostile_dist: int,
) -> float:
    """Score a state using greedy-style evaluation with deep simulation."""
    score, _ = _simulate_and_score(state, player, EVALUATION_HORIZON, base_hp_snapshot)
    return score


# TowerType.BASIC reference (constant, initialized from top-level import)
_BASIC_TYPE = TowerType.BASIC


class MCTSAgent(BaseAgent):
    """Greedy-style search agent that replaces MCTS tree search with deep simulation.

    For each candidate action:
    1. Apply operations to a cloned state
    2. Simulate 60 rounds forward
    3. Score using greedy-style evaluation (11+ sub-scores)
    4. Optionally deepen the best candidates

    This matches the greedy AI's approach and avoids the structural problems
    of MCTS (shallow depth, expensive tree nodes, mismatched half-turn granularity).
    """

    def __init__(
        self,
        iterations: int = 64,
        max_depth: int = 6,
        seed: int | None = None,
        max_actions: int = MAX_ACTIONS,
        model_path: str | os.PathLike[str] | None = None,
        time_limit: float = 0.35,
        simulation_horizon: int = 60,
        deepening_rounds: int = 2,
        **kwargs,  # Ignore extra MCTS params for backward compatibility
    ) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self.time_limit = time_limit
        self.simulation_horizon = simulation_horizon
        self.deepening_rounds = deepening_rounds
        # Keep model loading for compatibility (not used in search)
        self.model = None

    def _candidate_model_paths(self, override: str | os.PathLike[str] | None) -> list[Path]:
        candidates: list[Path] = []
        if override is not None:
            candidates.append(Path(override))
            return candidates
        env_path = os.getenv("AGENT_TRADITION_MCTS_MODEL")
        if env_path:
            candidates.append(Path(env_path))
        module_root = Path(__file__).resolve().parent
        repo_root = module_root.parent
        candidates.extend(
            [
                module_root / "ai_mcts_model.npz",
                repo_root / "checkpoints" / "ai_mcts_latest.npz",
                repo_root / "SDK" / "checkpoints" / "ai_mcts_latest.npz",
            ]
        )
        return candidates

    def list_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        return self.catalog.build(state, player, context=DecisionContext.for_player(player), rerank=False)

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        bundles = bundles or self.list_bundles(state, player)
        if not bundles:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))
        if len(bundles) == 1:
            return bundles[0]

        # --- Override 1: Emergency storm when base is in immediate danger ---
        storm_override = self._check_emergency_storm(state, player, bundles)
        if storm_override is not None:
            return storm_override

        # --- Override 2: Base upgrade when pushing (matching greedy _try_attack) ---
        upgrade_override = self._check_base_upgrade(state, player, bundles)
        if upgrade_override is not None:
            return upgrade_override

        return self._greedy_search(state, player, bundles)

    def _check_emergency_storm(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle],
    ) -> ActionBundle | None:
        """Check if we should use lightning storm immediately (emergency override from greedy).

        The greedy AI checks emergency storm AFTER tree search, but for the MCTS
        we check it FIRST to avoid wasting time searching when storm is clearly best.
        """
        # Check if storm is available
        storm_cd = state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM]
        if storm_cd > 0:
            return None

        storm_cost = SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM].cost
        if state.coins[player] < storm_cost:
            return None

        round_ratio = state.round_index / MAX_ROUND

        # Check danger: simulate 16 rounds and see if HP drops
        sim = state.clone()
        collapse_in_16 = False
        for step in range(16):
            if sim.terminal:
                if sim.bases[player].hp < state.bases[player].hp:
                    collapse_in_16 = True
                break
            sim.advance_round()
            if sim.bases[player].hp < state.bases[player].hp:
                collapse_in_16 = True
                break

        # Only override if in danger or very late game
        if not collapse_in_16 and round_ratio < 0.9:
            return None

        # Find the best storm bundle
        storm_bundles = [b for b in bundles if "storm" in b.name or "storm" in " ".join(b.tags)]
        if not storm_bundles:
            return None

        # Score each storm target
        best_storm = None
        best_storm_score = -1e9
        for bundle in storm_bundles:
            trial = state.clone()
            trial.apply_operation_list(player, bundle.operations)
            # Simulate 24 rounds (matching greedy's storm evaluation)
            trial_sim = trial.clone()
            for _ in range(24):
                if trial_sim.terminal:
                    break
                trial_sim.advance_round()
            # Score based on enemy base HP reduction
            enemy = 1 - player
            value = 0.0
            if trial_sim.bases[enemy].hp < state.bases[enemy].hp:
                value += 100 * (state.bases[enemy].hp - trial_sim.bases[enemy].hp)
            # Also score die count
            value += trial_sim.die_count[enemy] * 5.0
            if value > best_storm_score:
                best_storm_score = value
                best_storm = bundle

        if best_storm is not None and best_storm_score > 0:
            return best_storm
        return None

    def _check_base_upgrade(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle],
    ) -> ActionBundle | None:
        """Check if we should upgrade base (matching greedy _try_attack logic).

        The greedy AI prioritizes base upgrades when losing or in late game.
        """
        enemy = 1 - player
        hp_delta = state.bases[player].hp - state.bases[enemy].hp
        round_ratio = state.round_index / MAX_ROUND

        # Only override for base upgrade when losing or very late game
        if hp_delta >= 0 and round_ratio < 0.9:
            return None

        # Find base upgrade bundles
        upgrade_bundles = [b for b in bundles if "upgrade-ant" in b.name or "upgrade-gen" in b.name]
        if not upgrade_bundles:
            return None

        # When losing and round > 460, prioritize ant upgrade (matching greedy)
        if hp_delta < 0 and round_ratio > 0.9:
            ant_bundles = [b for b in upgrade_bundles if "upgrade-ant" in b.name]
            if ant_bundles:
                # Score by checking if we can afford it
                for bundle in ant_bundles:
                    trial = state.clone()
                    invalid = trial.apply_operation_list(player, bundle.operations)
                    if not invalid:
                        return bundle

        # When losing, check if upgrade bundle is affordable
        if hp_delta < 0:
            for bundle in upgrade_bundles:
                trial = state.clone()
                invalid = trial.apply_operation_list(player, bundle.operations)
                if not invalid:
                    return bundle

        return None

    def _greedy_search(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle],
    ) -> ActionBundle:
        """Greedy-style search: simulate each candidate forward and pick the best.

        Phase 1: Score all candidates with deep simulation
        Phase 2 (optional): Deepen the top candidates for more precision
        """
        deadline = time.monotonic() + self.time_limit if self.time_limit > 0 else float('inf')

        base_hp_snapshot = state.bases[player].hp
        initial_hostile_dist = state.nearest_ant_distance(player)

        # --- Phase 1: Score all candidates ---
        scored: list[tuple[float, ActionBundle]] = []
        for bundle in bundles:
            if time.monotonic() > deadline:
                break
            score = self._score_candidate(state, player, bundle, base_hp_snapshot, initial_hostile_dist)
            scored.append((score, bundle))

        if not scored:
            return bundles[0]

        # Sort by score descending
        scored.sort(key=lambda x: x[0], reverse=True)

        # --- Phase 2: Deepen top candidates ---
        if self.deepening_rounds > 0 and time.monotonic() < deadline:
            top_n = min(5, len(scored))
            deepened: list[tuple[float, ActionBundle]] = []
            for i in range(top_n):
                if time.monotonic() > deadline:
                    # Keep remaining scores from phase 1
                    deepened.extend(scored[i:])
                    break
                score, bundle = scored[i]
                deep_score = self._deep_score_candidate(
                    state, player, bundle, base_hp_snapshot, initial_hostile_dist
                )
                deepened.append((deep_score, bundle))
            # Merge deepened scores with remaining phase-1 scores
            remaining = scored[top_n:]
            deepened.extend(remaining)
            deepened.sort(key=lambda x: x[0], reverse=True)
            scored = deepened

        # --- Final safety check: prefer hold if best action isn't significantly better ---
        # (Matching greedy's idle fallback: best_id > 1 and best_value - idle_value < 2 -> idle)
        if len(scored) > 1:
            best_score = scored[0][0]
            hold_candidates = [(s, b) for s, b in scored if b.name == "hold"]
            if hold_candidates:
                hold_score = hold_candidates[0][0]
                # If best action isn't meaningfully better than hold, prefer hold
                if scored[0][1].name != "hold" and best_score - hold_score < 2.0:
                    return hold_candidates[0][1]

        return scored[0][1]

    def _score_candidate(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        base_hp_snapshot: int,
        initial_hostile_dist: int,
    ) -> float:
        """Score a single candidate: apply operations, simulate forward, evaluate."""
        trial = state.clone()
        trial.apply_operation_list(player, bundle.operations)

        # Compute sunk cost from downgrade operations (matching greedy)
        sunk_cost = _compute_sunk_cost(state, player, bundle.operations)

        # Simulate and score - uses same scale for ALL actions including hold
        score, _ = _simulate_and_score(trial, player, self.simulation_horizon, base_hp_snapshot, sunk_cost)
        return score

    def _deep_score_candidate(
        self,
        state: BackendState,
        player: int,
        bundle: ActionBundle,
        base_hp_snapshot: int,
        initial_hostile_dist: int,
    ) -> float:
        """Score a candidate with extended simulation horizon."""
        trial = state.clone()
        trial.apply_operation_list(player, bundle.operations)

        # Compute sunk cost
        sunk_cost = _compute_sunk_cost(state, player, bundle.operations)

        # Extended horizon for top candidates
        extended_horizon = min(self.simulation_horizon + 20, 80)
        score, _ = _simulate_and_score(trial, player, extended_horizon, base_hp_snapshot, sunk_cost)
        return score


class AI(MCTSAgent):
    pass
from __future__ import annotations

"""Clean-room v24: v20 baseline adapted to the latest slower-spawn, stronger-tower rules."""

from collections import Counter
from dataclasses import dataclass

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.backend import BackendState
from SDK.backend.model import Operation, Tower
from SDK.utils.actions import ActionBundle
from SDK.utils.constants import (
    AntKind,
    BASE_HP,
    OperationType,
    PLAYER_BASES,
    SuperWeaponType,
    TowerType,
)
from SDK.utils.geometry import hex_distance


AOE_TYPES = {TowerType.MORTAR, TowerType.MORTAR_PLUS, TowerType.PULSE, TowerType.MISSILE}
CONTROL_TYPES = {TowerType.ICE, TowerType.BEWITCH, TowerType.PULSE}
PRODUCER_TYPES = {TowerType.PRODUCER, TowerType.PRODUCER_FAST, TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC}
RESPONSE_ARCHETYPES = {"A3_single_adapt_emp", "A4_single_adapt_shield", "A4_single_flank_32", "A5_asymmetric_geometry"}
UPGRADE_RACE_ARCHETYPES = {"A2_single_center_upgrade", "A2b_fast_double_upgrade"}
MACRO_ARCHETYPES = {"A1_center_reconfig_macro", "A6_empty_open_engine"}

CENTER_SLOTS = {
    0: [(5, 9), (6, 9), (4, 9), (8, 7), (8, 11), (7, 8), (7, 10)],
    1: [(13, 9), (12, 9), (14, 9), (10, 7), (10, 11), (11, 8), (11, 10)],
}
UPPER_SLOTS = {
    0: [(8, 7), (7, 8), (5, 6), (6, 4), (4, 3)],
    1: [(10, 7), (11, 8), (12, 6), (11, 4), (14, 3)],
}
LOWER_SLOTS = {
    0: [(8, 11), (7, 10), (5, 12), (6, 14), (4, 15)],
    1: [(10, 11), (11, 10), (12, 12), (11, 14), (14, 15)],
}
REAR_SLOTS = {
    0: [(5, 6), (5, 12), (6, 4), (6, 14), (4, 3), (4, 15), (7, 5), (7, 13)],
    1: [(12, 6), (12, 12), (11, 4), (11, 14), (14, 3), (14, 15), (11, 5), (11, 13)],
}

OPEN_SIGS = {
    "std_double": {(((5, 9), (6, 9)), (), ()), (((12, 9), (13, 9)), (), ())},
    "std_double_third": {(((5, 9), (6, 9)), (), ((4, 9),)), (((12, 9), (13, 9)), (), ((14, 9),))},
    "offset_double": {(((4, 9), (5, 9)), (), ()), (((13, 9), (14, 9)), (), ())},
    "single_center": {
        (((5, 9),), (), ()),
        (((6, 9),), (), ()),
        (((12, 9),), (), ()),
        (((13, 9),), (), ()),
    },
    "single_fill": {(((6, 9),), ((5, 9),), ()), (((12, 9),), ((13, 9),), ())},
    "single_outer_fill": {(((6, 9),), ((4, 9),), ()), (((12, 9),), ((14, 9),), ())},
    "single_flank": {(((5, 9),), ((8, 7),), ()), (((13, 9),), ((10, 7),), ())},
    "edge_double": {(((4, 9),), ((5, 9),), ()), (((14, 9),), ((13, 9),), ())},
    "highland_shell": {
        (((4, 2), (6, 1)), (), ()),
        (((4, 2), (7, 1)), (), ()),
        (((9, 2), (11, 1)), (), ()),
        (((9, 2), (12, 1)), (), ()),
    },
    "empty_open": {((), (), ())},
}


@dataclass(frozen=True)
class Plan:
    name: str
    ops: tuple[Operation, ...]
    tags: tuple[str, ...] = ()


class AI(BaseAgent):
    def __init__(self, seed: int | None = None, max_actions: int = 96) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self.enemy_turns: list[list[tuple[int, int, int]]] = []
        self.enemy_op_counter: Counter[int] = Counter()
        self.enemy_opening_bucket: str | None = None
        self.enemy_archetype: str = "A0_unknown"
        self.response_side: str | None = None
        self.round_seen = 0

    def on_match_start(self, player: int, seed: int) -> None:
        super().on_match_start(player, seed)
        self.enemy_turns = []
        self.enemy_op_counter = Counter()
        self.enemy_opening_bucket = None
        self.enemy_archetype = "A0_unknown"
        self.response_side = None
        self.round_seen = 0

    def on_opponent_operations(self, operations) -> None:
        if self.round_seen < 4:
            snapshot: list[tuple[int, int, int]] = []
            for op in operations:
                snapshot.append((int(op.op_type), int(op.arg0), int(op.arg1)))
            self.enemy_turns.append(snapshot)
        for op in operations:
            self.enemy_op_counter[int(op.op_type)] += 1

    def on_round_state(self, public_round_state) -> None:
        self.round_seen = public_round_state.round_index
        self.enemy_opening_bucket = self._classify_enemy_opening()
        self.response_side = self._infer_response_side()
        self.enemy_archetype = self._classify_enemy_archetype()

    def choose_bundle(self, state: BackendState, player: int, bundles=None) -> ActionBundle:
        ops = tuple(self.choose_operations(state, player, bundles))
        return ActionBundle(name="v24", operations=ops, score=0.0, tags=("manual",))

    def choose_operations(self, state: BackendState, player: int, bundles=None) -> list[Operation]:
        plans = self._generate_plans(state, player)
        baseline = self._evaluate_state(state, player)
        best_plan = plans[0]
        best_score = float("-inf")
        for plan in plans:
            score = self._score_plan(state, player, baseline, plan)
            if score > best_score:
                best_score = score
                best_plan = plan
        return list(best_plan.ops)

    def _classify_enemy_opening(self) -> str | None:
        if not self.enemy_turns:
            return None

        def build_positions(turn_ops: list[tuple[int, int, int]]) -> tuple[tuple[int, int], ...]:
            return tuple(sorted((x, y) for t, x, y in turn_ops if t == int(OperationType.BUILD_TOWER)))

        signature = tuple(build_positions(self.enemy_turns[i]) if i < len(self.enemy_turns) else () for i in range(3))
        for name, signatures in OPEN_SIGS.items():
            if signature in signatures:
                return name
        return None

    def _infer_response_side(self) -> str | None:
        if not self.enemy_turns:
            return None
        ys = [y for turn in self.enemy_turns[:3] for t, _, y in turn if t == int(OperationType.BUILD_TOWER) and y >= 0]
        if not ys:
            return None
        avg_y = sum(ys) / len(ys)
        if avg_y < 9:
            return "upper"
        if avg_y > 9:
            return "lower"
        if self.enemy_opening_bucket == "single_flank":
            return "upper"
        return None

    def _classify_enemy_archetype(self) -> str:
        bucket = self.enemy_opening_bucket
        sells = self.enemy_op_counter[int(OperationType.DOWNGRADE_TOWER)]
        emps = self.enemy_op_counter[int(OperationType.USE_EMP_BLASTER)]
        shields = self.enemy_op_counter[int(OperationType.USE_DEFLECTOR)] + self.enemy_op_counter[int(OperationType.USE_EMERGENCY_EVASION)]
        upgrades = self.enemy_op_counter[int(OperationType.UPGRADE_TOWER)]
        if bucket == "empty_open":
            return "A6_empty_open_engine"
        if bucket in {"highland_shell", "offset_double"}:
            return "A5_asymmetric_geometry"
        if bucket == "edge_double":
            return "A2b_fast_double_upgrade"
        if bucket == "single_center":
            if emps >= 2:
                return "A3_single_adapt_emp"
            if upgrades >= 8 and shields == 0:
                return "A2_single_center_upgrade"
            return "A4_single_pressure"
        if bucket == "single_fill":
            return "A3_single_adapt_emp"
        if bucket == "single_outer_fill":
            if shields >= 4:
                return "A4_single_adapt_shield"
            return "A4_single_pressure"
        if bucket == "single_flank":
            if upgrades >= 2 and shields == 0 and emps == 0:
                return "A4_single_flank_32"
            if self.enemy_op_counter[int(OperationType.UPGRADE_GENERATED_ANT)] >= 1:
                return "A4_single_flank_32"
            if shields >= 4:
                return "A4_single_adapt_shield"
            return "A4_single_pressure"
        if bucket in {"std_double", "std_double_third"}:
            if sells >= 6 or upgrades >= 12:
                return "A1_center_reconfig_macro"
            if shields >= 4:
                return "A1_center_shield_push"
            if emps >= 2:
                return "A1_center_shield_push"
            return "A1_center_shield_push"
        return "A0_unknown"

    def _generate_plans(self, state: BackendState, player: int) -> list[Plan]:
        plans = [Plan("hold", (), ("hold",))]
        danger = self._base_danger(state, player)
        stable = danger <= 5.0 and state.bases[player].hp >= BASE_HP * 0.5
        towers = state.towers_of(player)
        basics = [tower for tower in towers if tower.tower_type == TowerType.BASIC]
        aoe_count = sum(1 for tower in towers if tower.tower_type in AOE_TYPES)
        control_count = sum(1 for tower in towers if tower.tower_type in CONTROL_TYPES)
        producer_count = sum(1 for tower in towers if tower.tower_type in PRODUCER_TYPES)

        if state.round_index == 0:
            open_pair = CENTER_SLOTS[player][:2]
            ops = self._seq(state, player, [Operation(OperationType.BUILD_TOWER, *open_pair[0]), Operation(OperationType.BUILD_TOWER, *open_pair[1])])
            if ops:
                return [plans[0], Plan("opening-double-center", ops, ("opening", "center"))]
            return plans

        if state.round_index < 80:
            for cell in self._opening_priority(state, player):
                ops = self._seq(state, player, [Operation(OperationType.BUILD_TOWER, *cell)])
                if ops:
                    plans.append(Plan(f"opening-build-{cell[0]}-{cell[1]}", ops, ("opening", "build")))
                    break

        plans.extend(self._archetype_specific_plans(state, player, stable, aoe_count, control_count))

        for role in ("center", "response", "rear", "rental"):
            for cell in self._build_sites(state, player, role)[:2]:
                ops = self._seq(state, player, [Operation(OperationType.BUILD_TOWER, *cell)])
                if ops:
                    plans.append(Plan(f"build-{role}-{cell[0]}-{cell[1]}", ops, ("build", role)))
                target = self._new_tower_target(state, player, role)
                combo = self._build_upgrade(state, player, cell, target)
                if combo:
                    plans.append(Plan(f"build-{role}-{target.name.lower()}", combo, ("build", "upgrade", role, target.name.lower())))

        for tower in basics:
            target = self._basic_upgrade_target(state, player, tower, aoe_count, control_count, producer_count)
            if target is not None:
                ops = self._seq(state, player, [Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target))])
                if ops:
                    plans.append(Plan(f"upgrade-basic-{tower.tower_id}-{target.name.lower()}", ops, ("upgrade", target.name.lower())))

        for tower in towers:
            target = self._advanced_upgrade_target(state, player, tower)
            if target is not None:
                ops = self._seq(state, player, [Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target))])
                if ops:
                    plans.append(Plan(f"upgrade-advanced-{tower.tower_id}-{target.name.lower()}", ops, ("upgrade", target.name.lower())))

        if stable and state.bases[player].ant_level == 0 and state.round_index >= 110 and (aoe_count + control_count) >= 2:
            ops = self._seq(state, player, [Operation(OperationType.UPGRADE_GENERATED_ANT)])
            if ops:
                plans.append(Plan("upgrade-ant-hp", ops, ("tech", "hp")))
        if stable and state.bases[player].generation_level == 0 and state.bases[player].ant_level >= 1 and state.round_index >= 180 and control_count >= 1:
            ops = self._seq(state, player, [Operation(OperationType.UPGRADE_GENERATION_SPEED)])
            if ops:
                plans.append(Plan("upgrade-ant-speed", ops, ("tech", "speed")))

        sell = self._sell_candidate(state, player)
        if sell is not None:
            ops = self._seq(state, player, [Operation(OperationType.DOWNGRADE_TOWER, sell.tower_id)])
            if ops:
                plans.append(Plan(f"sell-{sell.tower_id}", ops, ("sell",)))
            for cell in self._build_sites(state, player, "response")[:1]:
                ops = self._seq(state, player, [Operation(OperationType.DOWNGRADE_TOWER, sell.tower_id), Operation(OperationType.BUILD_TOWER, *cell)])
                if ops:
                    plans.append(Plan(f"sell-build-{sell.tower_id}-{cell[0]}-{cell[1]}", ops, ("sell", "build", "response")))

        plans.extend(self._weapon_plans(state, player))

        unique: dict[tuple[tuple[int, int, int], ...], Plan] = {}
        for plan in plans:
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in plan.ops)
            unique.setdefault(key, plan)
        return list(unique.values())

    def _opening_priority(self, state: BackendState, player: int) -> list[tuple[int, int]]:
        bucket = self.enemy_archetype
        if bucket == "A5_asymmetric_geometry":
            side = self.response_side or "upper"
            candidates = (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player] + CENTER_SLOTS[player][2:5]
        elif bucket == "A3_single_adapt_emp":
            side = self.response_side or "upper"
            response = (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player]
            candidates = [response[0], CENTER_SLOTS[player][2], response[1], CENTER_SLOTS[player][3]]
        elif bucket == "A4_single_flank_32":
            side = self.response_side or "upper"
            response = (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player]
            candidates = [CENTER_SLOTS[player][2], response[0], CENTER_SLOTS[player][3], response[1]]
        elif bucket in {"A4_single_pressure", "A4_single_adapt_shield"}:
            side = self.response_side or "upper"
            candidates = (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player][:2] + CENTER_SLOTS[player][2:4]
        elif bucket in {"A2_single_center_upgrade", "A2b_fast_double_upgrade"}:
            candidates = CENTER_SLOTS[player][2:5]
        elif bucket == "A6_empty_open_engine":
            candidates = CENTER_SLOTS[player][2:4] + REAR_SLOTS[player][:2]
        else:
            candidates = CENTER_SLOTS[player][2:6]
        return [cell for cell in candidates if state.tower_at(*cell) is None]

    def _archetype_specific_plans(
        self,
        state: BackendState,
        player: int,
        stable: bool,
        aoe_count: int,
        control_count: int,
    ) -> list[Plan]:
        plans: list[Plan] = []
        center_towers = [tower for tower in state.towers_of(player) if (tower.x, tower.y) in CENTER_SLOTS[player]]
        response_slots = self._response_slots(player)
        response_towers = [tower for tower in state.towers_of(player) if (tower.x, tower.y) in response_slots]
        third_center = CENTER_SLOTS[player][2]
        basic_center = next((tower for tower in center_towers if tower.tower_type == TowerType.BASIC), None)
        basic_response = next((tower for tower in response_towers if tower.tower_type == TowerType.BASIC), None)
        heavy_response = next((tower for tower in response_towers if tower.tower_type == TowerType.HEAVY), None)

        if self.enemy_archetype in {"A2_single_center_upgrade", "A2b_fast_double_upgrade", "A3_single_adapt_emp", "A4_single_flank_32"}:
            center_deadline = 120 if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_flank_32"} else 90
            if state.round_index < center_deadline and state.tower_at(*third_center) is None:
                ops = self._seq(state, player, [Operation(OperationType.BUILD_TOWER, *third_center)])
                if ops:
                    plans.append(Plan("center-third", ops, ("build", "center", "urgent")))
            if basic_center is not None and aoe_count == 0:
                ops = self._seq(state, player, [Operation(OperationType.UPGRADE_TOWER, basic_center.tower_id, int(TowerType.MORTAR))])
                if ops:
                    plans.append(Plan("center-mortar", ops, ("upgrade", "center", "urgent")))

        if self.enemy_archetype in RESPONSE_ARCHETYPES:
            first_response = response_slots[0]
            response_target = TowerType.MORTAR if self.enemy_archetype == "A5_asymmetric_geometry" else TowerType.HEAVY
            if state.tower_at(*first_response) is None:
                ops = self._seq(state, player, [Operation(OperationType.BUILD_TOWER, *first_response)])
                if ops:
                    plans.append(Plan("response-build", ops, ("build", "response", "urgent")))
                combo = self._build_upgrade(state, player, first_response, response_target)
                if combo:
                    plans.append(
                        Plan(
                            f"response-{response_target.name.lower()}",
                            combo,
                            ("build", "upgrade", "response", response_target.name.lower(), "urgent"),
                        )
                    )
            if basic_response is not None and self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_flank_32"}:
                ops = self._seq(state, player, [Operation(OperationType.UPGRADE_TOWER, basic_response.tower_id, int(TowerType.HEAVY))])
                if ops:
                    plans.append(Plan("response-basic-heavy", ops, ("upgrade", "response", "heavy", "urgent")))
            if heavy_response is not None and control_count == 0:
                ops = self._seq(state, player, [Operation(OperationType.UPGRADE_TOWER, heavy_response.tower_id, int(TowerType.ICE))])
                if ops:
                    plans.append(Plan("response-ice", ops, ("upgrade", "response", "ice", "urgent")))

        if self.enemy_archetype in {"A2_single_center_upgrade", "A2b_fast_double_upgrade"} and stable and state.bases[player].ant_level == 0:
            ops = self._seq(state, player, [Operation(OperationType.UPGRADE_GENERATED_ANT)])
            if ops:
                plans.append(Plan("mirror-32", ops, ("tech", "hp", "urgent")))
        if (
            self.enemy_archetype == "A4_single_flank_32"
            and stable
            and state.bases[player].ant_level == 0
            and state.round_index >= 130
            and (heavy_response is not None or control_count > 0)
            and len(center_towers) >= 3
        ):
            ops = self._seq(state, player, [Operation(OperationType.UPGRADE_GENERATED_ANT)])
            if ops:
                plans.append(Plan("delayed-32", ops, ("tech", "hp", "urgent")))

        return plans

    def _build_sites(self, state: BackendState, player: int, role: str) -> list[tuple[int, int]]:
        if role == "center":
            candidates = CENTER_SLOTS[player]
        elif role == "rear":
            candidates = REAR_SLOTS[player]
        elif role == "response":
            side = self.response_side or "upper"
            candidates = (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player]
        else:
            candidates = CENTER_SLOTS[player][2:5] + REAR_SLOTS[player][:2]
        return [cell for cell in candidates if state.tower_at(*cell) is None]

    def _new_tower_target(self, state: BackendState, player: int, role: str) -> TowerType:
        danger = self._base_danger(state, player)
        if role == "rear":
            return TowerType.PRODUCER_MEDIC if danger >= 6.5 else TowerType.PRODUCER_SIEGE
        if role == "response":
            if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_pressure", "A4_single_adapt_shield", "A4_single_flank_32"} or danger >= 6.5:
                return TowerType.HEAVY
            return TowerType.MORTAR
        if role == "rental":
            if self.enemy_archetype in MACRO_ARCHETYPES:
                return TowerType.HEAVY
            return TowerType.MORTAR
        if not any(t.tower_type in AOE_TYPES for t in state.towers_of(player)):
            return TowerType.MORTAR
        if not any(t.tower_type in CONTROL_TYPES for t in state.towers_of(player)):
            return TowerType.HEAVY
        return TowerType.MORTAR

    def _basic_upgrade_target(
        self,
        state: BackendState,
        player: int,
        tower: Tower,
        aoe_count: int,
        control_count: int,
        producer_count: int,
    ) -> TowerType | None:
        pressure = self._pressure(state, player, tower.x, tower.y)
        if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_flank_32"} and (tower.x, tower.y) == self._response_slots(player)[0]:
            return TowerType.HEAVY
        if producer_count == 0 and len(state.towers_of(player)) >= 3 and pressure <= 3.0 and (tower.x, tower.y) not in CENTER_SLOTS[player][:3]:
            return TowerType.PRODUCER
        if aoe_count == 0:
            return TowerType.MORTAR
        if control_count == 0 or self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_pressure", "A4_single_adapt_shield", "A4_single_flank_32"} or self._base_danger(state, player) >= 6.5:
            return TowerType.HEAVY
        return TowerType.MORTAR

    def _advanced_upgrade_target(self, state: BackendState, player: int, tower: Tower) -> TowerType | None:
        local = self._enemy_count(state, player, tower.x, tower.y, 4)
        if tower.tower_type == TowerType.HEAVY:
            if self.enemy_archetype in RESPONSE_ARCHETYPES or self._base_danger(state, player) >= 6.2 or local >= 4:
                return TowerType.ICE
            return TowerType.BEWITCH
        if tower.tower_type == TowerType.MORTAR:
            if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_adapt_shield", "A5_asymmetric_geometry"} and local >= 4:
                return TowerType.PULSE
            return TowerType.PULSE if local >= 6 else TowerType.MORTAR_PLUS
        if tower.tower_type == TowerType.PRODUCER:
            return TowerType.PRODUCER_MEDIC if self._base_danger(state, player) >= 7.5 else TowerType.PRODUCER_SIEGE
        if tower.tower_type == TowerType.PRODUCER_SIEGE and self._wounded_combats(state, player) >= 2:
            return TowerType.PRODUCER_MEDIC
        if tower.tower_type == TowerType.PRODUCER_MEDIC and self._combat_presence(state, player, enemy_side=True) >= 3:
            return TowerType.PRODUCER_SIEGE
        return None

    def _sell_candidate(self, state: BackendState, player: int) -> Tower | None:
        if len(state.towers_of(player)) < 4:
            return None
        best: tuple[float, Tower] | None = None
        for tower in state.towers_of(player):
            if (tower.x, tower.y) in self._response_slots(player) and self.enemy_archetype in RESPONSE_ARCHETYPES:
                continue
            pressure = self._pressure(state, player, tower.x, tower.y)
            if pressure > 2.0:
                continue
            if tower.tower_type in {TowerType.HEAVY_PLUS, TowerType.MORTAR_PLUS, TowerType.PULSE, TowerType.ICE, TowerType.BEWITCH} and tower.hp > tower.max_hp * 0.8:
                continue
            score = 5.0 * tower.hp / max(1, tower.max_hp) + 0.3 * hex_distance(tower.x, tower.y, PLAYER_BASES[player][0], PLAYER_BASES[player][1])
            if tower.tower_type in {TowerType.BASIC, TowerType.PRODUCER, TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC}:
                score += 2.0
            if best is None or score > best[0]:
                best = (score, tower)
        return None if best is None else best[1]

    def _weapon_plans(self, state: BackendState, player: int) -> list[Plan]:
        plans: list[Plan] = []
        emp = self._emp_plan(state, player)
        dfl = self._deflector_plan(state, player)
        eva = self._evasion_plan(state, player)
        lig = self._lightning_plan(state, player)
        for item in (emp, dfl, eva, lig):
            if item is not None:
                plans.append(item)
        if emp and dfl:
            ops = self._seq(state, player, [*emp.ops, *dfl.ops])
            if ops:
                plans.append(Plan("emp-deflector", ops, ("emp", "deflector")))
        if emp and eva:
            ops = self._seq(state, player, [*emp.ops, *eva.ops])
            if ops:
                plans.append(Plan("emp-evasion", ops, ("emp", "evasion")))
        return plans

    def _emp_plan(self, state: BackendState, player: int) -> Plan | None:
        if state.weapon_cooldowns[player, SuperWeaponType.EMP_BLASTER] != 0 or state.coins[player] < state.weapon_cost(SuperWeaponType.EMP_BLASTER):
            return None
        enemy_towers = state.towers_of(1 - player)
        assault_threshold = 4.2
        if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_adapt_shield"}:
            assault_threshold = 3.6
        if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
            assault_threshold = 5.5
        if len(enemy_towers) < 2 or self._assault_mass(state, player) < assault_threshold:
            return None
        best_center: tuple[int, int] | None = None
        best_score = 0.0
        for tower in enemy_towers:
            cx, cy = tower.x, tower.y
            cluster = sum(3.0 + 2.5 * other.level for other in enemy_towers if hex_distance(cx, cy, other.x, other.y) <= 3)
            support = sum(2.2 if ant.kind == AntKind.COMBAT else 0.9 for ant in state.ants_of(player) if hex_distance(cx, cy, ant.x, ant.y) <= 6)
            score = cluster + support
            if score > best_score:
                best_score, best_center = score, (cx, cy)
        min_score = 10.5
        if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_adapt_shield", "A5_asymmetric_geometry"}:
            min_score = 8.0
        if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
            min_score = 13.0
        if best_center is None or best_score < min_score:
            return None
        return Plan("emp", (Operation(OperationType.USE_EMP_BLASTER, *best_center),), ("emp",))

    def _deflector_plan(self, state: BackendState, player: int) -> Plan | None:
        if state.weapon_cooldowns[player, SuperWeaponType.DEFLECTOR] != 0 or state.coins[player] < state.weapon_cost(SuperWeaponType.DEFLECTOR):
            return None
        if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES and state.round_index < 220:
            return None
        center, score = self._friendly_cluster(state, player, enemy_side=True)
        threshold = 4.2
        if self.enemy_archetype in {"A1_center_shield_push", "A4_single_adapt_shield"}:
            threshold = 3.4
        if center is None or score < threshold:
            return None
        return Plan("deflector", (Operation(OperationType.USE_DEFLECTOR, *center),), ("deflector",))

    def _evasion_plan(self, state: BackendState, player: int) -> Plan | None:
        if state.weapon_cooldowns[player, SuperWeaponType.EMERGENCY_EVASION] != 0 or state.coins[player] < state.weapon_cost(SuperWeaponType.EMERGENCY_EVASION):
            return None
        if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES and state.round_index < 220:
            return None
        center, score = self._friendly_cluster(state, player, enemy_side=False)
        if center is None:
            return None
        base = PLAYER_BASES[player]
        if score >= 3.5 and hex_distance(center[0], center[1], base[0], base[1]) <= 7:
            return Plan("evasion-base", (Operation(OperationType.USE_EMERGENCY_EVASION, *center),), ("evasion", "defense"))
        push_threshold = 5.2 if self.enemy_archetype not in {"A4_single_adapt_shield", "A5_asymmetric_geometry"} else 4.5
        assault_threshold = 4.0 if self.enemy_archetype not in {"A4_single_adapt_shield", "A5_asymmetric_geometry"} else 3.5
        if score >= push_threshold and self._assault_mass(state, player) >= assault_threshold:
            return Plan("evasion-push", (Operation(OperationType.USE_EMERGENCY_EVASION, *center),), ("evasion", "push"))
        return None

    def _lightning_plan(self, state: BackendState, player: int) -> Plan | None:
        if state.weapon_cooldowns[player, SuperWeaponType.LIGHTNING_STORM] != 0 or state.coins[player] < state.weapon_cost(SuperWeaponType.LIGHTNING_STORM):
            return None
        ant_cluster = self._enemy_cluster(state, player)
        tower_cluster = self._enemy_tower_cluster(state, player)
        best_center: tuple[int, int] | None = None
        best_score = float("-inf")
        best_near_base = False
        if ant_cluster is not None:
            center, score, near_base = ant_cluster
            if score > best_score:
                best_center, best_score, best_near_base = center, score, near_base
        if tower_cluster is not None:
            center, score, near_base = tower_cluster
            if score > best_score:
                best_center, best_score, best_near_base = center, score, near_base
        if best_center is None:
            return None
        if best_score < 8.2 and not (best_near_base and best_score >= 6.4):
            return None
        return Plan("lightning", (Operation(OperationType.USE_LIGHTNING_STORM, *best_center),), ("lightning",))

    def _seq(self, state: BackendState, player: int, ops: list[Operation]) -> tuple[Operation, ...] | None:
        trial = state.clone()
        accepted: list[Operation] = []
        for op in ops:
            if not trial.can_apply_operation(player, op, accepted):
                return None
            accepted.append(op)
            trial.apply_operation(player, op)
        return tuple(accepted)

    def _build_upgrade(self, state: BackendState, player: int, cell: tuple[int, int], target: TowerType) -> tuple[Operation, ...] | None:
        if target == TowerType.BASIC:
            return None
        trial = state.clone()
        accepted: list[Operation] = []
        build = Operation(OperationType.BUILD_TOWER, *cell)
        if not trial.can_apply_operation(player, build, accepted):
            return None
        next_id = trial.next_tower_id
        accepted.append(build)
        trial.apply_operation(player, build)
        upgrade = Operation(OperationType.UPGRADE_TOWER, next_id, int(target))
        if not trial.can_apply_operation(player, upgrade, accepted):
            return None
        accepted.append(upgrade)
        return tuple(accepted)

    def _score_plan(self, state: BackendState, player: int, baseline: float, plan: Plan) -> float:
        trial = state.clone()
        illegal = trial.apply_operation_list(player, plan.ops)
        if illegal:
            return -10**9
        before = self._evaluate_state(trial, player)
        try:
            trial.advance_round()
        except Exception:
            return -10**9
        after = self._evaluate_state(trial, player)
        return 0.45 * (before - baseline) + 0.85 * (after - baseline) + self._plan_bias(state, player, plan) - 0.02 * len(plan.ops)

    def _plan_bias(self, state: BackendState, player: int, plan: Plan) -> float:
        danger = self._base_danger(state, player)
        if not plan.ops:
            return (-2.0 if state.coins[player] > 80 else 0.0) + (-1.5 if danger >= 5.0 else 0.0)
        score = 0.0
        if "build" in plan.tags:
            score += 1.1
            if "response" in plan.tags and self.enemy_archetype in RESPONSE_ARCHETYPES:
                score += 1.2
            if "center" in plan.tags and self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
                score += 1.2
            if "center" in plan.tags and self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_flank_32"}:
                score += 0.9
        if "upgrade" in plan.tags:
            score += 0.8
            if "response" in plan.tags and self.enemy_archetype in RESPONSE_ARCHETYPES:
                score += 0.9
            if "center" in plan.tags and self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
                score += 0.8
            if "response" in plan.tags and self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_flank_32"}:
                score += 0.6
        if "sell" in plan.tags:
            if self.enemy_archetype in MACRO_ARCHETYPES:
                score += 0.5
            elif self.enemy_archetype == "A4_single_flank_32":
                score -= 0.9
            else:
                score -= 0.2
        if "emp" in plan.tags:
            score += 2.4 if self.enemy_archetype in {"A3_single_adapt_emp", "A4_single_adapt_shield"} else 2.0
            if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
                score -= 1.1
        if "deflector" in plan.tags or "evasion" in plan.tags:
            score += 1.1 if self.enemy_archetype in {"A1_center_shield_push", "A3_single_adapt_emp", "A4_single_adapt_shield"} else 0.4
            if self.enemy_archetype in UPGRADE_RACE_ARCHETYPES:
                score -= 1.0
        if "lightning" in plan.tags:
            score += 0.7 if self.enemy_archetype == "A5_asymmetric_geometry" else 0.2
        if "tech" in plan.tags and self.enemy_archetype in {"A4_single_pressure", "A4_single_flank_32", "A6_empty_open_engine", "A2_single_center_upgrade", "A2b_fast_double_upgrade"}:
            score += 0.9
            if self.enemy_archetype == "A4_single_flank_32" and state.round_index < 130:
                score -= 0.7
        if "tech" in plan.tags and state.round_index < 110:
            score -= 0.8
        return score

    def _evaluate_state(self, state: BackendState, player: int) -> float:
        enemy = 1 - player
        own_base = PLAYER_BASES[player]
        enemy_base = PLAYER_BASES[enemy]
        score = 40.0 * (state.bases[player].hp - state.bases[enemy].hp) + 0.18 * (state.coins[player] - state.coins[enemy])
        for tower in state.towers_of(player):
            score += 3.0 * tower.hp / max(1, tower.max_hp)
            if tower.tower_type in AOE_TYPES:
                score += 7.2
            elif tower.tower_type in CONTROL_TYPES:
                score += 6.1
            elif tower.tower_type in {TowerType.HEAVY, TowerType.HEAVY_PLUS}:
                score += 4.0
            elif tower.tower_type in PRODUCER_TYPES:
                score += 3.8 if tower.tower_type == TowerType.PRODUCER_SIEGE else 2.6
        for tower in state.towers_of(enemy):
            score -= 2.5 * tower.hp / max(1, tower.max_hp)
            if tower.tower_type in AOE_TYPES:
                score -= 5.1
            elif tower.tower_type in CONTROL_TYPES:
                score -= 4.8
            elif tower.tower_type in PRODUCER_TYPES:
                score -= 2.6
        for ant in state.ants_of(player):
            dist = hex_distance(ant.x, ant.y, enemy_base[0], enemy_base[1])
            score += (2.8 if ant.kind == AntKind.COMBAT else 1.0 + 0.3 * ant.level) * max(0, 14 - dist) + 0.25 * ant.hp
        for ant in state.ants_of(enemy):
            dist = hex_distance(ant.x, ant.y, own_base[0], own_base[1])
            score -= (3.0 if ant.kind == AntKind.COMBAT else 1.1 + 0.35 * ant.level) * max(0, 14 - dist) + 0.25 * ant.hp
        score -= 8.0 * self._base_danger(state, player)
        score += 3.4 * self._assault_mass(state, player) - 2.6 * self._assault_mass(state, enemy)
        score -= 1.5 * max(0, state.super_weapon_usage[player] - state.super_weapon_usage[enemy])
        if getattr(state, "terminal", False):
            if state.winner == player:
                score += 100000.0
            elif state.winner == enemy:
                score -= 100000.0
        return score

    def _pressure(self, state: BackendState, player: int, x: int, y: int) -> float:
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(x, y, ant.x, ant.y)
            if d <= 6:
                total += (2.3 if ant.kind == AntKind.COMBAT else 1.0 + 0.35 * ant.level) * max(0, 7 - d)
        return total

    def _enemy_count(self, state: BackendState, player: int, x: int, y: int, radius: int) -> int:
        return sum(1 for ant in state.ants_of(1 - player) if hex_distance(x, y, ant.x, ant.y) <= radius)

    def _base_danger(self, state: BackendState, player: int) -> float:
        bx, by = PLAYER_BASES[player]
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(bx, by, ant.x, ant.y)
            if d <= 8:
                total += (2.8 if ant.kind == AntKind.COMBAT else 1.2 + 0.35 * ant.level) * max(0, 9 - d)
        return total

    def _assault_mass(self, state: BackendState, player: int) -> float:
        ex, ey = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(player):
            d = hex_distance(ex, ey, ant.x, ant.y)
            if d <= 9:
                total += (2.5 if ant.kind == AntKind.COMBAT else 1.0 + 0.25 * ant.level) * max(0, 10 - d) / 5.0
        return total

    def _combat_presence(self, state: BackendState, player: int, enemy_side: bool) -> int:
        tx, ty = PLAYER_BASES[1 - player] if enemy_side else PLAYER_BASES[player]
        limit = 9 if enemy_side else 8
        return sum(1 for ant in state.ants_of(player) if ant.kind == AntKind.COMBAT and hex_distance(tx, ty, ant.x, ant.y) <= limit)

    def _wounded_combats(self, state: BackendState, player: int) -> int:
        return sum(1 for ant in state.ants_of(player) if ant.kind == AntKind.COMBAT and ant.hp * 2 < ant.max_hp * 2)

    def _friendly_cluster(self, state: BackendState, player: int, enemy_side: bool) -> tuple[tuple[int, int] | None, float]:
        tx, ty = PLAYER_BASES[1 - player] if enemy_side else PLAYER_BASES[player]
        best_center = None
        best_score = 0.0
        for ant in state.ants_of(player):
            if enemy_side and hex_distance(tx, ty, ant.x, ant.y) > 10:
                continue
            score = sum(2.0 if other.kind == AntKind.COMBAT else 1.0 for other in state.ants_of(player) if hex_distance(ant.x, ant.y, other.x, other.y) <= 3)
            if not enemy_side:
                score += max(0, 10 - hex_distance(tx, ty, ant.x, ant.y))
            if score > best_score:
                best_center, best_score = (ant.x, ant.y), score
        return best_center, best_score

    def _response_slots(self, player: int) -> list[tuple[int, int]]:
        side = self.response_side or "upper"
        return (UPPER_SLOTS if side == "upper" else LOWER_SLOTS)[player]

    def _enemy_cluster(self, state: BackendState, player: int) -> tuple[tuple[int, int], float, bool] | None:
        own_base = PLAYER_BASES[player]
        enemy_base = PLAYER_BASES[1 - player]
        best = None
        best_score = 0.0
        for ant in state.ants_of(1 - player):
            score = sum(2.2 if other.kind == AntKind.COMBAT else 1.0 for other in state.ants_of(1 - player) if hex_distance(ant.x, ant.y, other.x, other.y) <= 3)
            score += max(0, 9 - hex_distance(enemy_base[0], enemy_base[1], ant.x, ant.y)) * 0.3
            score += max(0, 9 - hex_distance(own_base[0], own_base[1], ant.x, ant.y)) * 0.6
            if score > best_score:
                best_score = score
                best = ((ant.x, ant.y), score, hex_distance(own_base[0], own_base[1], ant.x, ant.y) <= 8)
        return best

    def _enemy_tower_cluster(self, state: BackendState, player: int) -> tuple[tuple[int, int], float, bool] | None:
        own_base = PLAYER_BASES[player]
        best = None
        best_score = 0.0
        towers = state.towers_of(1 - player)
        for tower in towers:
            score = 0.0
            for other in towers:
                if hex_distance(tower.x, tower.y, other.x, other.y) > 3:
                    continue
                score += 2.0 + 0.45 * other.level + 0.06 * other.hp
                if other.tower_type in PRODUCER_TYPES:
                    score += 1.4
                elif other.tower_type in CONTROL_TYPES:
                    score += 1.1
                elif other.tower_type in AOE_TYPES:
                    score += 0.9
            if score > best_score:
                best_score = score
                best = ((tower.x, tower.y), score, hex_distance(own_base[0], own_base[1], tower.x, tower.y) <= 9)
        return best

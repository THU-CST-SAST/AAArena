from __future__ import annotations
"""
对局运行时包装层。

MatchRuntime 的定位：
    - 它不是完整规则引擎（那在 backend/state/engine 里）
    - 它也不是协议层（那在 AI/protocol.py 里）
    - 它是“站在某一名玩家视角上，维护本地对局状态”的桥梁
"""

from dataclasses import dataclass
from typing import Iterable

from SDK.backend.core import EngineBackend, load_backend
from SDK.backend.state import BackendState
from SDK.backend.engine import PublicRoundState
from SDK.backend.model import Operation


@dataclass(slots=True)
class MatchRuntime:
    player: int
    state: BackendState

    @classmethod
    def create(
        cls,
        player: int,
        seed: int,
        *,
        prefer_native: bool = False,
        backend: EngineBackend | None = None,
    ) -> MatchRuntime:
        # 按指定 seed 构造一份初始局面。
        engine = backend or load_backend(prefer_native=prefer_native)
        return cls(player=player, state=engine.initial_state(seed=seed))

    @property
    def opponent(self) -> int:
        return 1 - self.player

    def apply_operations(self, player: int, operations: Iterable[Operation]) -> list[Operation]:
        # 这里返回的是非法操作列表，便于上层调试或统计。
        return self.state.apply_operation_list(player, operations)

    def apply_self_operations(self, operations: Iterable[Operation]) -> list[Operation]:
        return self.apply_operations(self.player, operations)

    def apply_opponent_operations(self, operations: Iterable[Operation]) -> list[Operation]:
        return self.apply_operations(self.opponent, operations)

    def finish_round(self, public_round_state: PublicRoundState) -> None:
        # 对局进入下一回合时，本地先 advance_round()，
        # 再用平台回传的 public_round_state 做一次强同步。
        self.state.advance_round()
        self.state.sync_public_round_state(public_round_state)

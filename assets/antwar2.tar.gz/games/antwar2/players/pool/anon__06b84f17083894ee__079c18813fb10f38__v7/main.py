from __future__ import annotations
"""
打包后 AI 的统一入口。

平台最终不会关心你仓库里有多少个 AI 文件，
它只要求打包产物中有一个 main.py，并且 main.py 能启动 AI。

因此这个文件的职责非常纯粹：
    1. 载入 ai.py 里导出的 AI 类
    2. 为它创建一个 MatchSession
    3. 循环执行整场对局
"""

try:
    from ai import AI as PackagedAI
except ModuleNotFoundError as exc:  # pragma: no cover - repository layout
    if exc.name != "ai":
        raise
    PackagedAI = None

try:
    from common import BaseAgent, MatchSession
except ModuleNotFoundError as exc:  # pragma: no cover - repository layout
    if exc.name != "common":
        raise
    from AI.common import BaseAgent, MatchSession


def build_session(agent) -> MatchSession:
    # 高级用法：如果 AI 自己想控制整套运行会话，可以实现 create_session()。
    factory = getattr(agent, "create_session", None)
    if callable(factory):
        session = factory()
        if not isinstance(session, MatchSession):
            raise TypeError("AI.create_session() must return a MatchSession")
        return session

    # 常规用法：AI 继承 BaseAgent，就自动走协议会话。
    if isinstance(agent, BaseAgent):
        try:
            from protocol import ProtocolSession
        except ModuleNotFoundError as exc:  # pragma: no cover - repository layout
            if exc.name != "protocol":
                raise
            from AI.protocol import ProtocolSession
        return ProtocolSession(agent)

    raise TypeError("AI must inherit BaseAgent or expose create_session()")


def run_session(session: MatchSession) -> None:
    # 这里直接体现了 README 里描述的回合流程：
    #   - 先手：自己动 -> 收对手动作 -> 同步回合结果
    #   - 后手：先收对手动作 -> 自己动 -> 同步回合结果
    while True:
        if session.player == 0:
            session.perform_self_turn()
            if not session.receive_opponent_turn():
                break
            if not session.sync_round():
                break
        else:
            if not session.receive_opponent_turn():
                break
            session.perform_self_turn()
            if not session.sync_round():
                break


def main(ai_cls=None) -> None:
    # 默认从打包后的 ai.py 里读取 AI 类；测试时也允许外部显式传类进来。
    agent_cls = ai_cls or PackagedAI
    if agent_cls is None:
        raise RuntimeError("main.py expects ai.py to export class AI, or an explicit ai_cls argument")
    run_session(build_session(agent_cls()))


if __name__ == "__main__":  # pragma: no cover - exercised in packaged layout
    main()

#!/usr/bin/env python3
from __future__ import annotations

"""
AI Lab：本地批量评测 + 回放目录分析工具（增强版）

用途：
1. 批量跑本地对战，不再一场一场手敲 run_local_match.py
2. 自动生成：
   - summary.json
   - results.csv
   - scoreboard.csv（按 AI 汇总胜负）
   - matrix.csv（版本之间对战矩阵）
   - report.html（可直接浏览器打开）
3. 扫描 playback/ 回放目录，生成更可读的摘要与统计

说明：
- 这是本地工作台，不依赖比赛网站内部 API
- 侧重点是减少你“批量测试 + 手工汇总”的成本
"""

import argparse
import csv
import html
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import time
from collections import Counter, defaultdict
from statistics import mean

try:
    import replay_style_lab as replay_lab
except ModuleNotFoundError:  # pragma: no cover - import path differs by launch mode
    from tools import replay_style_lab as replay_lab

REPO_ROOT = Path(__file__).resolve().parents[1]
GAME_DIR = REPO_ROOT / "game"
DEFAULT_GAME_BIN = GAME_DIR / "output" / "main"
PACKAGE_AI = REPO_ROOT / "AI" / "package_ai.sh"


def discover_supported_ais() -> tuple[str, ...]:
    """自动扫描仓库里的可用 AI 名称，避免每次新增版本都手改工具。"""
    preferred_order = ["random", "mcts", "greedy", "mybot"]
    discovered = set()

    # 1) 从打包脚本推断目标名
    for path in (REPO_ROOT / "AI").glob("zip_*.sh"):
        name = path.stem.removeprefix("zip_")
        if name == "rand":
            discovered.add("random")
        else:
            discovered.add(name)

    # 2) 从 ai_*.py 补充 mybot 系列/示例
    for path in (REPO_ROOT / "AI").glob("ai_*.py"):
        stem = path.stem.removeprefix("ai_")
        if stem == "random":
            discovered.add("random")
        elif stem == "greedy":
            discovered.add("greedy")
        elif stem == "mcts":
            discovered.add("mcts")
        elif stem.startswith("mybot") or stem == "example":
            discovered.add(stem)

    ordered = []
    for name in preferred_order:
        if name in discovered:
            ordered.append(name)
            discovered.remove(name)
    ordered.extend(sorted(discovered))
    return tuple(ordered)


SUPPORTED_AIS = discover_supported_ais()
TIMEOUT_SECONDS = 20.0


def make_game_once(game_bin: Path) -> None:
    if game_bin == DEFAULT_GAME_BIN and not game_bin.exists():
        subprocess.run(["make"], cwd=GAME_DIR, check=True)


def preferred_python() -> str:
    override = os.environ.get("AI_LAUNCH_PYTHON")
    if override:
        return override
    for candidate in (
        REPO_ROOT / ".venv" / "bin" / "python",
        REPO_ROOT / ".venv" / "Scripts" / "python.exe",
    ):
        if candidate.exists():
            return str(candidate)
    return sys.executable


def clean_tree(root: Path) -> None:
    for path in root.rglob("__pycache__"):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
    for pattern in ("*.pyc", ".DS_Store", "*.so", "*.dylib", "*.pyd"):
        for path in root.rglob(pattern):
            if path.is_file():
                path.unlink(missing_ok=True)


def resolve_ai_payload(target: str) -> tuple[Path, list[tuple[Path, str]]]:
    if target == "random":
        return REPO_ROOT / "AI" / "ai_random.py", []
    if target == "mcts":
        return REPO_ROOT / "AI" / "ai_mcts.py", []
    if target == "greedy":
        return REPO_ROOT / "AI" / "ai_greedy.py", [(REPO_ROOT / "AI" / "ai_greedy", "ai_greedy")]
    if target == "example":
        return REPO_ROOT / "AI" / "ai_example.py", []
    if target == "mybot":
        return REPO_ROOT / "AI" / "ai_mybot.py", []
    candidate = REPO_ROOT / "AI" / f"ai_{target}.py"
    if candidate.exists():
        return candidate, []
    raise FileNotFoundError(f"unsupported AI target: {target}")


def stage_ai_native(target: str, output_dir: Path) -> Path:
    ai_script, extra_trees = resolve_ai_payload(target)
    shutil.copy2(REPO_ROOT / "AI" / "main.py", output_dir / "main.py")
    shutil.copy2(REPO_ROOT / "AI" / "common.py", output_dir / "common.py")
    shutil.copy2(REPO_ROOT / "AI" / "protocol.py", output_dir / "protocol.py")
    shutil.copy2(ai_script, output_dir / "ai.py")
    shutil.copytree(REPO_ROOT / "SDK", output_dir / "SDK")
    shutil.copytree(REPO_ROOT / "tools", output_dir / "tools")
    for source, relative_target in extra_trees:
        shutil.copytree(source, output_dir / relative_target)
        clean_tree(output_dir / relative_target)
    clean_tree(output_dir / "SDK")
    clean_tree(output_dir / "tools")
    return output_dir


def package_ai_command(target: str, output_dir: Path) -> list[str]:
    if os.name == "nt":
        return []
    return [str(PACKAGE_AI), target, str(output_dir)]


def packet(payload: object) -> bytes:
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return struct.pack(">I", len(body)) + body


def read_exact(stream, size: int, proc: subprocess.Popen[bytes], label: str, timeout: float = TIMEOUT_SECONDS) -> bytes:
    fd = stream.fileno()
    data = bytearray()
    deadline = time.monotonic() + timeout
    while len(data) < size:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"timed out while reading {label}")
        import select

        ready, _, _ = select.select([fd], [], [], remaining)
        if not ready:
            continue
        chunk = os.read(fd, size - len(data))
        if not chunk:
            code = proc.poll()
            if code is None:
                raise EOFError(f"unexpected EOF while reading {label}")
            raise EOFError(f"{label} closed with exit code {code}")
        data.extend(chunk)
    return bytes(data)


def read_game_packet(game: subprocess.Popen[bytes]) -> tuple[int, bytes]:
    size = struct.unpack(">I", read_exact(game.stdout, 4, game, "game packet length"))[0]
    obj = struct.unpack(">i", read_exact(game.stdout, 4, game, "game packet object"))[0]
    payload = read_exact(game.stdout, size, game, "game packet payload")
    return obj, payload


def read_ai_packet(ai: subprocess.Popen[bytes], label: str) -> bytes:
    size = struct.unpack(">I", read_exact(ai.stdout, 4, ai, f"{label} packet length"))[0]
    payload = read_exact(ai.stdout, size, ai, f"{label} packet payload")
    return struct.pack(">I", size) + payload


def write_all(stream, payload: bytes) -> None:
    stream.write(payload)
    stream.flush()


def close_stdin(proc: subprocess.Popen[bytes] | None) -> None:
    if proc is None or proc.stdin is None:
        return
    try:
        proc.stdin.close()
    except OSError:
        pass


def terminate(proc: subprocess.Popen[bytes] | None) -> None:
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=3)


def stage_ai_once(target: str, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=False)
    if os.name == "nt":
        stage_ai_native(target, output_dir)
    else:
        subprocess.run(package_ai_command(target, output_dir), cwd=REPO_ROOT, check=True)
    return output_dir


def launch_ai(ai_dir: Path, stderr_path: Path) -> subprocess.Popen[bytes]:
    stderr_handle = stderr_path.open("wb")
    return subprocess.Popen(
        [preferred_python(), "main.py"],
        cwd=ai_dir,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=stderr_handle,
    )


def read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def run_one_match(ai0_dir: Path, ai1_dir: Path, seed: int, workdir: Path, game_bin: Path) -> dict[str, object]:
    replay_path = workdir / "replay.json"
    game_stderr_path = workdir / "game.stderr.log"
    ai0_stderr_path = workdir / "ai0.stderr.log"
    ai1_stderr_path = workdir / "ai1.stderr.log"

    game_stderr_handle = game_stderr_path.open("wb")
    game = ai0 = ai1 = None
    result: dict[str, object] = {
        "seed": seed,
        "workdir": str(workdir),
        "replay": str(replay_path),
    }

    try:
        ai0 = launch_ai(ai0_dir, ai0_stderr_path)
        ai1 = launch_ai(ai1_dir, ai1_stderr_path)
        ais = {0: ai0, 1: ai1}

        game = subprocess.Popen(
            [str(game_bin)],
            cwd=GAME_DIR,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=game_stderr_handle,
        )

        init = {
            "player_list": [1, 1],
            "player_num": 2,
            "config": {"random_seed": seed},
            "replay": str(replay_path),
        }
        write_all(game.stdin, packet(init))

        while True:
            obj, payload = read_game_packet(game)
            if obj in (0, 1):
                write_all(ais[obj].stdin, payload)
                continue

            message = json.loads(payload.decode("utf-8"))
            if isinstance(message, dict) and "player" in message and "content" in message:
                for player, content in zip(message["player"], message["content"]):
                    write_all(ais[int(player)].stdin, content.encode("utf-8"))
            if isinstance(message, dict) and message.get("listen"):
                for player in message["listen"]:
                    ai_packet = read_ai_packet(ais[int(player)], f"ai{player}")
                    reply = {
                        "player": int(player),
                        "content": ai_packet.decode("latin1"),
                        "time": 0,
                    }
                    write_all(game.stdin, packet(reply))
            if isinstance(message, dict) and "end_state" in message:
                result["end_state"] = message["end_state"]
                result["end_info"] = message.get("end_info")
                break

        game.wait(timeout=3)
        close_stdin(ai0)
        close_stdin(ai1)
        for ai in (ai0, ai1):
            try:
                ai.wait(timeout=3)
            except subprocess.TimeoutExpired:
                terminate(ai)

        result["game_returncode"] = game.returncode
        result["ai0_returncode"] = ai0.returncode
        result["ai1_returncode"] = ai1.returncode
        result["game_stderr"] = read_text(game_stderr_path)
        result["ai0_stderr"] = read_text(ai0_stderr_path)
        result["ai1_stderr"] = read_text(ai1_stderr_path)
        if replay_path.exists():
            replay = json.loads(replay_path.read_text(encoding="utf-8"))
            result["rounds_recorded"] = len(replay)
            if replay:
                last_round = replay[-1].get("round_state", {})
                result["winner"] = last_round.get("winner")
                result["last_error"] = last_round.get("error")
                result["message"] = last_round.get("message")
                result["camps"] = last_round.get("camps")
                result["coins"] = last_round.get("coins")
        return result
    except Exception as exc:
        result["exception"] = f"{type(exc).__name__}: {exc}"
        result["game_returncode"] = None if game is None else game.poll()
        result["ai0_returncode"] = None if ai0 is None else ai0.poll()
        result["ai1_returncode"] = None if ai1 is None else ai1.poll()
        result["game_stderr"] = read_text(game_stderr_path)
        result["ai0_stderr"] = read_text(ai0_stderr_path)
        result["ai1_stderr"] = read_text(ai1_stderr_path)
        result["replay_exists"] = replay_path.exists()
        return result
    finally:
        terminate(ai0)
        terminate(ai1)
        terminate(game)
        game_stderr_handle.close()


def summarize_batch(results: list[dict[str, object]], ai0_name: str, ai1_name: str) -> dict[str, object]:
    total = len(results)
    valid = [r for r in results if "winner" in r]
    crashes = [r for r in results if "exception" in r or r.get("ai0_stderr") or r.get("ai1_stderr")]
    slot0_wins = sum(1 for r in valid if r.get("winner") == 0)
    slot1_wins = sum(1 for r in valid if r.get("winner") == 1)
    draws = sum(1 for r in valid if r.get("winner") not in (0, 1))
    avg_rounds = round(sum(int(r.get("rounds_recorded", 0)) for r in valid) / max(len(valid), 1), 2)
    return {
        "slot0_ai": ai0_name,
        "slot1_ai": ai1_name,
        "total_matches": total,
        "valid_matches": len(valid),
        "slot0_wins": slot0_wins,
        "slot1_wins": slot1_wins,
        "draws_or_unknown": draws,
        "slot0_win_rate": round(slot0_wins / max(len(valid), 1), 4),
        "slot1_win_rate": round(slot1_wins / max(len(valid), 1), 4),
        "avg_rounds": avg_rounds,
        "crash_like_matches": len(crashes),
        "note": "slot0/slot1 are current-match positions only; use scoreboard/matrix to compare AI strength.",
    }


def winner_ai_name(row: dict[str, object]) -> str:
    winner = row.get("winner")
    if winner == 0:
        return str(row.get("ai0"))
    if winner == 1:
        return str(row.get("ai1"))
    return "draw_or_unknown"


def build_scoreboard(results: list[dict[str, object]]) -> list[dict[str, object]]:
    stats: dict[str, dict[str, object]] = {}

    def ensure(name: str) -> dict[str, object]:
        if name not in stats:
            stats[name] = {
                "ai": name,
                "matches": 0,
                "wins": 0,
                "losses": 0,
                "draws": 0,
                "rounds": [],
                "as_ai0_matches": 0,
                "as_ai0_wins": 0,
                "as_ai1_matches": 0,
                "as_ai1_wins": 0,
            }
        return stats[name]

    for row in results:
        ai0 = str(row["ai0"])
        ai1 = str(row["ai1"])
        ensure(ai0)
        ensure(ai1)
        winner = row.get("winner")
        rounds = int(row.get("rounds_recorded", 0) or 0)

        s0 = ensure(ai0)
        s1 = ensure(ai1)

        s0["matches"] += 1
        s1["matches"] += 1
        s0["as_ai0_matches"] += 1
        s1["as_ai1_matches"] += 1
        s0["rounds"].append(rounds)
        s1["rounds"].append(rounds)

        if winner == 0:
            s0["wins"] += 1
            s1["losses"] += 1
            s0["as_ai0_wins"] += 1
        elif winner == 1:
            s1["wins"] += 1
            s0["losses"] += 1
            s1["as_ai1_wins"] += 1
        else:
            s0["draws"] += 1
            s1["draws"] += 1

    table = []
    for item in stats.values():
        matches = max(int(item["matches"]), 1)
        row = {
            "ai": item["ai"],
            "matches": item["matches"],
            "wins": item["wins"],
            "losses": item["losses"],
            "draws": item["draws"],
            "win_rate": round(int(item["wins"]) / matches, 4),
            "avg_rounds": round(mean(item["rounds"]) if item["rounds"] else 0.0, 2),
            "as_ai0_matches": item["as_ai0_matches"],
            "as_ai0_wins": item["as_ai0_wins"],
            "as_ai0_win_rate": round(int(item["as_ai0_wins"]) / max(int(item["as_ai0_matches"]), 1), 4),
            "as_ai1_matches": item["as_ai1_matches"],
            "as_ai1_wins": item["as_ai1_wins"],
            "as_ai1_win_rate": round(int(item["as_ai1_wins"]) / max(int(item["as_ai1_matches"]), 1), 4),
        }
        table.append(row)

    table.sort(key=lambda r: (r["win_rate"], -r["avg_rounds"]), reverse=True)
    return table


def build_matrix(results: list[dict[str, object]]) -> list[dict[str, object]]:
    # 记录 A 对 B 的胜负（不区分 A 在哪一侧，按 AI 名义聚合）
    matrix: dict[tuple[str, str], dict[str, int]] = defaultdict(lambda: {"matches": 0, "wins": 0, "losses": 0, "draws": 0})
    for row in results:
        ai0 = str(row["ai0"])
        ai1 = str(row["ai1"])
        winner = row.get("winner")
        pair = (ai0, ai1)
        matrix[pair]["matches"] += 1
        if winner == 0:
            matrix[pair]["wins"] += 1
        elif winner == 1:
            matrix[pair]["losses"] += 1
        else:
            matrix[pair]["draws"] += 1

        reverse = (ai1, ai0)
        matrix[reverse]["matches"] += 1
        if winner == 1:
            matrix[reverse]["wins"] += 1
        elif winner == 0:
            matrix[reverse]["losses"] += 1
        else:
            matrix[reverse]["draws"] += 1

    rows = []
    for (left, right), item in sorted(matrix.items()):
        rows.append(
            {
                "left_ai": left,
                "right_ai": right,
                "matches": item["matches"],
                "wins": item["wins"],
                "losses": item["losses"],
                "draws": item["draws"],
                "win_rate": round(item["wins"] / max(item["matches"], 1), 4),
            }
        )
    return rows


def save_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})


def write_html_report(out_dir: Path, overall: dict[str, object], scoreboard: list[dict[str, object]], matrix_rows: list[dict[str, object]], results: list[dict[str, object]]) -> None:
    def table(headers: list[str], rows: list[list[object]]) -> str:
        head_html = "".join(f"<th>{html.escape(str(h))}</th>" for h in headers)
        body_html = ""
        for row in rows:
            body_html += "<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>\n"
        return f"<table><thead><tr>{head_html}</tr></thead><tbody>{body_html}</tbody></table>"

    scoreboard_table = table(
        ["AI", "Matches", "Wins", "Losses", "Draws", "WinRate", "AvgRounds", "AI0 WinRate", "AI1 WinRate"],
        [
            [
                row["ai"],
                row["matches"],
                row["wins"],
                row["losses"],
                row["draws"],
                row["win_rate"],
                row["avg_rounds"],
                row["as_ai0_win_rate"],
                row["as_ai1_win_rate"],
            ]
            for row in scoreboard
        ],
    )

    matrix_table = table(
        ["LeftAI", "RightAI", "Matches", "Wins", "Losses", "Draws", "WinRate"],
        [
            [
                row["left_ai"],
                row["right_ai"],
                row["matches"],
                row["wins"],
                row["losses"],
                row["draws"],
                row["win_rate"],
            ]
            for row in matrix_rows
        ],
    )

    latest_results_table = table(
        ["AI0", "AI1", "Seed", "Winner", "Rounds", "Exception", "Workdir"],
        [
            [
                row.get("ai0"),
                row.get("ai1"),
                row.get("seed"),
                row.get("winner"),
                row.get("rounds_recorded"),
                row.get("exception", ""),
                row.get("workdir"),
            ]
            for row in results[: min(len(results), 30)]
        ],
    )

    html_text = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>AI Lab Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }}
    table {{ border-collapse: collapse; margin: 16px 0; width: 100%; }}
    th, td {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; font-size: 14px; }}
    th {{ background: #f5f5f5; }}
    h1, h2 {{ margin-top: 28px; }}
    code {{ background: #f3f3f3; padding: 1px 4px; }}
    .small {{ color: #666; font-size: 13px; }}
  </style>
</head>
<body>
  <h1>AI Lab Batch Report</h1>
  <p class="small">Generated at: {html.escape(time.strftime("%Y-%m-%d %H:%M:%S"))}</p>

  <h2>Overall</h2>
  <pre>{html.escape(json.dumps(overall, ensure_ascii=False, indent=2))}</pre>
  <p class="small"><strong>注意：</strong>Overall 里的 slot0/slot1 只是当前批量任务中的对战位置，不代表版本强弱。真正比较 AI 强弱请看下面的 <code>Scoreboard</code> 和 <code>Match Matrix</code>。</p>

  <h2>Scoreboard</h2>
  {scoreboard_table}

  <h2>Match Matrix</h2>
  {matrix_table}

  <h2>Recent Match Results (Top 30)</h2>
  {latest_results_table}

  <p class="small">See also: <code>summary.json</code>, <code>results.csv</code>, <code>scoreboard.csv</code>, <code>matrix.csv</code></p>
</body>
</html>
"""
    (out_dir / "report.html").write_text(html_text, encoding="utf-8")


def run_batch(args: argparse.Namespace) -> int:
    ai0 = args.ai0
    ai1 = args.ai1
    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    swap_sides = args.swap_sides
    keep_replays = args.keep_replays

    out_dir = Path(args.out_dir).resolve()
    if out_dir.exists() and args.clean:
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    game_bin = Path(args.game_bin).resolve()
    make_game_once(game_bin)
    exec_stage_dir = Path(tempfile.mkdtemp(prefix="ai-lab-game-"))
    staged_game_bin = exec_stage_dir / game_bin.name
    shutil.copy2(game_bin, staged_game_bin)
    staged_game_bin.chmod(0o755)

    packaged_root = out_dir / "packaged"
    if packaged_root.exists() and args.repackage:
        shutil.rmtree(packaged_root)
    packaged_root.mkdir(parents=True, exist_ok=True)

    staged_dirs: dict[str, Path] = {}
    for target in {ai0, ai1}:
        stage_dir = packaged_root / target
        if not stage_dir.exists():
            stage_ai_once(target, stage_dir)
        staged_dirs[target] = stage_dir

    all_results: list[dict[str, object]] = []
    pair_specs = [(ai0, ai1, False)]
    if swap_sides and ai0 != ai1:
        pair_specs.append((ai1, ai0, True))

    total_runs = len(seeds) * len(pair_specs)
    match_index = 0

    try:
        for left, right, swapped in pair_specs:
            pair_dir = out_dir / f"{left}_vs_{right}"
            pair_dir.mkdir(parents=True, exist_ok=True)
            pair_results: list[dict[str, object]] = []
            for seed in seeds:
                match_index += 1
                workdir = pair_dir / f"seed_{seed}"
                if workdir.exists():
                    shutil.rmtree(workdir)
                workdir.mkdir(parents=True)
                print(f"[{match_index}/{total_runs}] running {left} vs {right} seed={seed}", flush=True)
                result = run_one_match(staged_dirs[left], staged_dirs[right], seed, workdir, staged_game_bin)
                result["ai0"] = left
                result["ai1"] = right
                result["swapped"] = swapped
                pair_results.append(result)
                all_results.append(result)
                print(
                    "    -> "
                    f"winner_slot={result.get('winner')} "
                    f"winner_ai={winner_ai_name(result)} "
                    f"rounds={result.get('rounds_recorded')} "
                    f"exception={result.get('exception', '')}",
                    flush=True,
                )
                if not keep_replays:
                    for name in ("replay.json", "ai0.stderr.log", "ai1.stderr.log", "game.stderr.log"):
                        (workdir / name).unlink(missing_ok=True)

            summary = summarize_batch(pair_results, left, right)
            (pair_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

        overall = summarize_batch(all_results, ai0, ai1)
        scoreboard = build_scoreboard(all_results)
        matrix_rows = build_matrix(all_results)

        args_dump = {k: v for k, v in vars(args).items() if k != "func"}
        batch_summary = {
            "args": args_dump,
            "overall": overall,
            "results": all_results,
        }
        (out_dir / "summary.json").write_text(json.dumps(batch_summary, ensure_ascii=False, indent=2), encoding="utf-8")

        save_csv(
            out_dir / "results.csv",
            all_results,
            [
                "ai0",
                "ai1",
                "seed",
                "winner",
                "rounds_recorded",
                "swapped",
                "exception",
                "ai0_returncode",
                "ai1_returncode",
                "last_error",
                "message",
                "workdir",
            ],
        )

        save_csv(
            out_dir / "scoreboard.csv",
            scoreboard,
            [
                "ai",
                "matches",
                "wins",
                "losses",
                "draws",
                "win_rate",
                "avg_rounds",
                "as_ai0_matches",
                "as_ai0_wins",
                "as_ai0_win_rate",
                "as_ai1_matches",
                "as_ai1_wins",
                "as_ai1_win_rate",
            ],
        )

        save_csv(
            out_dir / "matrix.csv",
            matrix_rows,
            ["left_ai", "right_ai", "matches", "wins", "losses", "draws", "win_rate"],
        )

        write_html_report(out_dir, overall, scoreboard, matrix_rows, all_results)

        print(json.dumps(overall, ensure_ascii=False, indent=2), flush=True)
        print("\nBatch scoreboard:", flush=True)
        for row in scoreboard:
            print(
                f"  {row['ai']}: "
                f"wins={row['wins']}/{row['matches']} "
                f"win_rate={row['win_rate']} "
                f"(ai0={row['as_ai0_win_rate']}, ai1={row['as_ai1_win_rate']})",
                flush=True,
            )
        print(f"\nSaved batch report to: {out_dir}")
        print(f"Open HTML report: {out_dir / 'report.html'}")
        return 0
    finally:
        shutil.rmtree(exec_stage_dir, ignore_errors=True)


def run_tournament(args: argparse.Namespace) -> int:
    """循环赛模式：给定多个 AI，自动做两两对战。"""
    ai_list = [name.strip() for name in args.ais.split(",") if name.strip()]
    if len(ai_list) < 2:
        print("Tournament needs at least 2 AI names")
        return 1

    invalid = [name for name in ai_list if name not in SUPPORTED_AIS]
    if invalid:
        print(f"Unsupported AI names: {invalid}")
        print(f"Supported: {SUPPORTED_AIS}")
        return 1

    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    out_dir = Path(args.out_dir).resolve()
    if out_dir.exists() and args.clean:
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    game_bin = Path(args.game_bin).resolve()
    make_game_once(game_bin)
    exec_stage_dir = Path(tempfile.mkdtemp(prefix="ai-lab-game-"))
    staged_game_bin = exec_stage_dir / game_bin.name
    shutil.copy2(game_bin, staged_game_bin)
    staged_game_bin.chmod(0o755)

    packaged_root = out_dir / "packaged"
    if packaged_root.exists() and args.repackage:
        shutil.rmtree(packaged_root)
    packaged_root.mkdir(parents=True, exist_ok=True)

    staged_dirs: dict[str, Path] = {}
    for target in ai_list:
        stage_dir = packaged_root / target
        if not stage_dir.exists():
            stage_ai_once(target, stage_dir)
        staged_dirs[target] = stage_dir

    pair_specs: list[tuple[str, str]] = []
    for i, left in enumerate(ai_list):
        for right in ai_list[i + 1 :]:
            pair_specs.append((left, right))
            if args.swap_sides:
                pair_specs.append((right, left))

    total_runs = len(pair_specs) * len(seeds)
    run_index = 0
    all_results: list[dict[str, object]] = []

    try:
        for left, right in pair_specs:
            pair_dir = out_dir / f"{left}_vs_{right}"
            pair_dir.mkdir(parents=True, exist_ok=True)
            pair_results: list[dict[str, object]] = []
            for seed in seeds:
                run_index += 1
                workdir = pair_dir / f"seed_{seed}"
                if workdir.exists():
                    shutil.rmtree(workdir)
                workdir.mkdir(parents=True)
                print(f"[{run_index}/{total_runs}] tournament {left} vs {right} seed={seed}", flush=True)
                result = run_one_match(staged_dirs[left], staged_dirs[right], seed, workdir, staged_game_bin)
                result["ai0"] = left
                result["ai1"] = right
                result["swapped"] = False
                pair_results.append(result)
                all_results.append(result)
                print(
                    "    -> "
                    f"winner_slot={result.get('winner')} "
                    f"winner_ai={winner_ai_name(result)} "
                    f"rounds={result.get('rounds_recorded')} "
                    f"exception={result.get('exception', '')}",
                    flush=True,
                )
                if not args.keep_replays:
                    for name in ("replay.json", "ai0.stderr.log", "ai1.stderr.log", "game.stderr.log"):
                        (workdir / name).unlink(missing_ok=True)

            summary = summarize_batch(pair_results, left, right)
            (pair_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

        overall = {
            "ai_pool": ai_list,
            "seed_count": len(seeds),
            "pair_count": len(pair_specs),
            "match_count": len(all_results),
        }
        scoreboard = build_scoreboard(all_results)
        matrix_rows = build_matrix(all_results)

        args_dump = {k: v for k, v in vars(args).items() if k != "func"}
        tournament_summary = {
            "args": args_dump,
            "overall": overall,
            "scoreboard": scoreboard,
            "results": all_results,
        }
        (out_dir / "summary.json").write_text(json.dumps(tournament_summary, ensure_ascii=False, indent=2), encoding="utf-8")

        save_csv(
            out_dir / "results.csv",
            all_results,
            [
                "ai0",
                "ai1",
                "seed",
                "winner",
                "rounds_recorded",
                "exception",
                "ai0_returncode",
                "ai1_returncode",
                "last_error",
                "message",
                "workdir",
            ],
        )

        save_csv(
            out_dir / "scoreboard.csv",
            scoreboard,
            [
                "ai",
                "matches",
                "wins",
                "losses",
                "draws",
                "win_rate",
                "avg_rounds",
                "as_ai0_matches",
                "as_ai0_wins",
                "as_ai0_win_rate",
                "as_ai1_matches",
                "as_ai1_wins",
                "as_ai1_win_rate",
            ],
        )

        save_csv(
            out_dir / "matrix.csv",
            matrix_rows,
            ["left_ai", "right_ai", "matches", "wins", "losses", "draws", "win_rate"],
        )

        write_html_report(out_dir, overall, scoreboard, matrix_rows, all_results)

        print(json.dumps(overall, ensure_ascii=False, indent=2), flush=True)
        print("\nTournament scoreboard:")
        for row in scoreboard:
            print(f"  {row['ai']}: win_rate={row['win_rate']}, matches={row['matches']}, avg_rounds={row['avg_rounds']}", flush=True)
        print(f"\nSaved tournament report to: {out_dir}")
        print(f"Open HTML report: {out_dir / 'report.html'}")
        return 0
    finally:
        shutil.rmtree(exec_stage_dir, ignore_errors=True)


def infer_side_heuristic(data: list[dict]) -> int | None:
    """一个非常粗糙的回放侧别推断器，只用于摘要辅助。"""
    if not data:
        return None
    c0 = Counter(op["type"] for t in data for op in t.get("op0", []))
    c1 = Counter(op["type"] for t in data for op in t.get("op1", []))
    signal0 = c0[23] + c0[24] + 0.3 * c0[21]
    signal1 = c1[23] + c1[24] + 0.3 * c1[21]
    if signal0 > signal1:
        return 0
    if signal1 > signal0:
        return 1
    return None


def analyze_playback(args: argparse.Namespace) -> int:
    folder = Path(args.folder).resolve()
    files, skipped = replay_lab.iter_replay_files(folder)
    if not files:
        print(f"No raw replay json files found in {folder}")
        if skipped:
            print(f"Skipped {len(skipped)} derived/invalid json files")
        return 1

    rows = []
    grouped_by_seed: dict[object, list[dict[str, object]]] = defaultdict(list)
    winner_counter = Counter()
    msg_counter = Counter()
    rounds = []

    for p in files:
        try:
            data = replay_lab.load_replay(p)
            first = data[0]
            last = data[-1].get("round_state", {})
            my_side = replay_lab.infer_my_side(data)
            opp_style = None if my_side is None else replay_lab.classify_style(data, 1 - my_side)
            row = {
                "file": p.name,
                "rounds": len(data),
                "seed": first.get("seed"),
                "winner": last.get("winner"),
                "message": last.get("message"),
                "error": last.get("error"),
                "camps": last.get("camps"),
                "coins": last.get("coins"),
                "speedLv": last.get("speedLv"),
                "anthpLv": last.get("anthpLv"),
                "my_side_guess": my_side,
                "opp_style": opp_style,
            }
            rows.append(row)
            grouped_by_seed[row["seed"]].append(row)
            winner_counter[str(row["winner"])] += 1
            msg_counter[str(row["message"])] += 1
            rounds.append(int(row["rounds"]))
        except Exception as exc:
            rows.append({"file": p.name, "error": f"load_error: {exc}"})

    save_csv(
        folder / "playback_summary.csv",
        rows,
        ["file", "rounds", "seed", "winner", "message", "error", "camps", "coins", "speedLv", "anthpLv", "my_side_guess", "opp_style"],
    )

    overview = {
        "raw_replay_file_count": len(files),
        "skipped_json_count": len(skipped),
        "avg_rounds": round(mean(rounds), 2) if rounds else 0.0,
        "winner_distribution": dict(winner_counter),
        "message_distribution": dict(msg_counter),
        "seed_group_count": len(grouped_by_seed),
    }

    html_rows = []
    for row in rows:
        html_rows.append(
            [
                row.get("file"),
                row.get("rounds"),
                row.get("seed"),
                row.get("winner"),
                row.get("message"),
                row.get("error"),
                row.get("camps"),
                row.get("coins"),
                row.get("my_side_guess"),
                row.get("opp_style"),
            ]
        )

    def table(headers: list[str], rows_: list[list[object]]) -> str:
        head_html = "".join(f"<th>{html.escape(str(h))}</th>" for h in headers)
        body_html = ""
        for row in rows_:
            body_html += "<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>\n"
        return f"<table><thead><tr>{head_html}</tr></thead><tbody>{body_html}</tbody></table>"

    html_text = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>Playback Summary</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; }}
    table {{ border-collapse: collapse; width: 100%; margin: 16px 0; }}
    th, td {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; font-size: 14px; }}
    th {{ background: #f5f5f5; }}
    pre {{ background: #f7f7f7; padding: 12px; }}
  </style>
</head>
<body>
  <h1>Playback Summary</h1>
  <pre>{html.escape(json.dumps(overview, ensure_ascii=False, indent=2))}</pre>
  {table(["file", "rounds", "seed", "winner", "message", "error", "camps", "coins", "my_side_guess", "opp_style"], html_rows)}
</body>
</html>
"""
    (folder / "playback_report.html").write_text(html_text, encoding="utf-8")

    print(f"Scanned {len(files)} raw replay files in {folder}\n")
    print(json.dumps(overview, ensure_ascii=False, indent=2))
    print(f"\nSaved CSV summary to: {folder / 'playback_summary.csv'}")
    print(f"Saved HTML report to: {folder / 'playback_report.html'}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="AI Lab: batch local evaluation and playback analysis")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_batch = sub.add_parser("batch", help="Run many local matches and summarize the results")
    p_batch.add_argument("--ai0", required=True, choices=SUPPORTED_AIS)
    p_batch.add_argument("--ai1", required=True, choices=SUPPORTED_AIS)
    p_batch.add_argument("--seeds", required=True, help="Comma-separated seeds, e.g. 7,19,23,31")
    p_batch.add_argument("--swap-sides", action="store_true", help="Also run ai1 vs ai0 on the same seed set")
    p_batch.add_argument("--out-dir", default="batch_runs/latest", help="Output directory for reports and per-match artifacts")
    p_batch.add_argument("--game-bin", default=str(DEFAULT_GAME_BIN))
    p_batch.add_argument("--keep-replays", action="store_true", help="Keep every replay/stderr file instead of cleaning them after each match")
    p_batch.add_argument("--clean", action="store_true", help="Delete output directory before starting")
    p_batch.add_argument("--repackage", action="store_true", help="Force repackaging AI code even if cached package dirs exist")
    p_batch.set_defaults(func=run_batch)

    p_tournament = sub.add_parser("tournament", help="Run a round-robin tournament across many AIs")
    p_tournament.add_argument("--ais", required=True, help="Comma-separated AI names, e.g. mybot,mybot_v3,greedy")
    p_tournament.add_argument("--seeds", required=True, help="Comma-separated seeds, e.g. 7,19,23,31")
    p_tournament.add_argument("--swap-sides", action="store_true", help="Also run reversed pair order for each AI pair")
    p_tournament.add_argument("--out-dir", default="batch_runs/tournament_latest", help="Output directory for tournament reports")
    p_tournament.add_argument("--game-bin", default=str(DEFAULT_GAME_BIN))
    p_tournament.add_argument("--keep-replays", action="store_true", help="Keep every replay/stderr file instead of cleaning them after each match")
    p_tournament.add_argument("--clean", action="store_true", help="Delete output directory before starting")
    p_tournament.add_argument("--repackage", action="store_true", help="Force repackaging AI code even if cached package dirs exist")
    p_tournament.set_defaults(func=run_tournament)

    p_playback = sub.add_parser("analyze-playback", help="Summarize replay json files under a folder")
    p_playback.add_argument("--folder", default="playback", help="Folder containing downloaded replay json files")
    p_playback.set_defaults(func=analyze_playback)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())

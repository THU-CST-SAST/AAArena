#!/usr/bin/env python3
from __future__ import annotations

"""
AI Lab GUI

一个本地桌面小工具，目标是：
- 不用手敲终端命令
- 直接点选 AI 版本、seed、输出目录
- 一键执行：
  1. 单场对战
  2. 批量 batch 测试
  3. tournament 循环赛
  4. playback 目录分析

实现方式：
- 使用 tkinter 做一个轻量图形界面
- 在 Windows 侧运行，通过 `wsl bash -lc ...` 调用你已经配好的 WSL Python 环境
"""

import os
from pathlib import Path
import queue
import shlex
import subprocess
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


REPO_ROOT = Path(__file__).resolve().parents[1]


def discover_supported_ais() -> tuple[str, ...]:
    """自动扫描 AI 目录中的可用版本，避免每次新增版本都手改 GUI。"""
    preferred_order = ["random", "mcts", "greedy", "mybot"]
    discovered = set()

    # 1) 从 zip 脚本名推导可用 target
    for path in (REPO_ROOT / "AI").glob("zip_*.sh"):
        name = path.stem.removeprefix("zip_")
        if name == "rand":
            discovered.add("random")
        else:
            discovered.add(name)

    # 2) 从 ai_*.py 里补充 mybot 系列
    for path in (REPO_ROOT / "AI").glob("ai_*.py"):
        stem = path.stem.removeprefix("ai_")
        if stem == "random":
            discovered.add("random")
        elif stem == "greedy":
            discovered.add("greedy")
        elif stem == "mcts":
            discovered.add("mcts")
        elif stem.startswith("mybot") or stem == "example":
            discovered.add(stem)

    # 只保留 package_ai.sh 能支持的常用目标风格名称
    ordered = []
    for name in preferred_order:
        if name in discovered:
            ordered.append(name)
            discovered.remove(name)
    ordered.extend(sorted(discovered))
    return tuple(ordered)


SUPPORTED_AIS = discover_supported_ais()


def windows_path_to_wsl(path: Path) -> str:
    """把 Windows 路径转成 WSL 路径。"""
    text = str(path.resolve())
    if len(text) >= 3 and text[1:3] == ":\\":
        drive = text[0].lower()
        rest = text[3:].replace("\\", "/")
        return f"/mnt/{drive}/{rest}"
    return text.replace("\\", "/")


def shell_quote(value: str) -> str:
    return shlex.quote(value)


class RunnerThread(threading.Thread):
    def __init__(self, command: list[str], output_queue: queue.Queue[str]) -> None:
        super().__init__(daemon=True)
        self.command = command
        self.output_queue = output_queue
        self.process: subprocess.Popen[str] | None = None

    def run(self) -> None:
        try:
            self.output_queue.put(f"[RUN] {' '.join(self.command)}\n")
            self.process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            assert self.process.stdout is not None
            for line in self.process.stdout:
                self.output_queue.put(line)
            code = self.process.wait()
            self.output_queue.put(f"\n[EXIT CODE] {code}\n")
        except Exception as exc:
            self.output_queue.put(f"\n[ERROR] {type(exc).__name__}: {exc}\n")

    def stop(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()


class AILabGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("AI Lab GUI")
        self.geometry("1100x760")
        self.minsize(980, 680)

        self.output_queue: queue.Queue[str] = queue.Queue()
        self.runner: RunnerThread | None = None

        self.repo_root_win = REPO_ROOT
        self.repo_root_wsl = windows_path_to_wsl(REPO_ROOT)

        self._build_ui()
        self.after(120, self._poll_output)

    def _build_ui(self) -> None:
        top = ttk.Frame(self, padding=12)
        top.pack(fill=tk.BOTH, expand=True)

        notebook = ttk.Notebook(top)
        notebook.pack(fill=tk.BOTH, expand=True)

        self.tab_single = ttk.Frame(notebook, padding=10)
        self.tab_batch = ttk.Frame(notebook, padding=10)
        self.tab_tournament = ttk.Frame(notebook, padding=10)
        self.tab_playback = ttk.Frame(notebook, padding=10)

        notebook.add(self.tab_single, text="单场对战")
        notebook.add(self.tab_batch, text="批量测试")
        notebook.add(self.tab_tournament, text="循环赛")
        notebook.add(self.tab_playback, text="回放分析")

        self._build_single_tab()
        self._build_batch_tab()
        self._build_tournament_tab()
        self._build_playback_tab()
        self._build_log_panel(top)

    def _combo(self, parent, values, width=18, default=None):
        var = tk.StringVar(value=default or values[0])
        box = ttk.Combobox(parent, textvariable=var, values=list(values), width=width, state="readonly")
        return var, box

    def _browse_dir(self, target_var: tk.StringVar) -> None:
        chosen = filedialog.askdirectory(initialdir=str(REPO_ROOT))
        if chosen:
            target_var.set(chosen)

    def _build_single_tab(self) -> None:
        frame = self.tab_single
        row = 0

        ttk.Label(frame, text="AI0").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.single_ai0_var, single_ai0 = self._combo(frame, SUPPORTED_AIS, default="mybot_v3")
        single_ai0.grid(row=row, column=1, sticky="w", padx=4, pady=6)

        ttk.Label(frame, text="AI1").grid(row=row, column=2, sticky="w", padx=4, pady=6)
        self.single_ai1_var, single_ai1 = self._combo(frame, SUPPORTED_AIS, default="greedy")
        single_ai1.grid(row=row, column=3, sticky="w", padx=4, pady=6)

        row += 1
        ttk.Label(frame, text="Seed").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.single_seed_var = tk.StringVar(value="7")
        ttk.Entry(frame, textvariable=self.single_seed_var, width=18).grid(row=row, column=1, sticky="w", padx=4, pady=6)

        ttk.Label(frame, text="输出目录").grid(row=row, column=2, sticky="w", padx=4, pady=6)
        self.single_out_var = tk.StringVar(value=str(REPO_ROOT / "match_logs" / "gui_single"))
        ttk.Entry(frame, textvariable=self.single_out_var, width=48).grid(row=row, column=3, sticky="we", padx=4, pady=6)
        ttk.Button(frame, text="选择目录", command=lambda: self._browse_dir(self.single_out_var)).grid(row=row, column=4, padx=4, pady=6)

        row += 1
        ttk.Button(frame, text="开始单场对战", command=self.run_single_match).grid(row=row, column=0, columnspan=2, sticky="w", padx=4, pady=10)

        frame.columnconfigure(3, weight=1)

    def _build_batch_tab(self) -> None:
        frame = self.tab_batch
        row = 0

        ttk.Label(frame, text="AI0").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.batch_ai0_var, batch_ai0 = self._combo(frame, SUPPORTED_AIS, default="mybot_v3")
        batch_ai0.grid(row=row, column=1, sticky="w", padx=4, pady=6)

        ttk.Label(frame, text="AI1").grid(row=row, column=2, sticky="w", padx=4, pady=6)
        self.batch_ai1_var, batch_ai1 = self._combo(frame, SUPPORTED_AIS, default="greedy")
        batch_ai1.grid(row=row, column=3, sticky="w", padx=4, pady=6)

        row += 1
        ttk.Label(frame, text="Seeds").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.batch_seeds_var = tk.StringVar(value="7,19,23")
        ttk.Entry(frame, textvariable=self.batch_seeds_var, width=24).grid(row=row, column=1, sticky="w", padx=4, pady=6)

        self.batch_swap_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame, text="自动换边", variable=self.batch_swap_var).grid(row=row, column=2, sticky="w", padx=4, pady=6)

        self.batch_keep_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame, text="保留 replay/log", variable=self.batch_keep_var).grid(row=row, column=3, sticky="w", padx=4, pady=6)

        row += 1
        ttk.Label(frame, text="输出目录").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.batch_out_var = tk.StringVar(value=str(REPO_ROOT / "batch_runs" / "gui_batch"))
        ttk.Entry(frame, textvariable=self.batch_out_var, width=60).grid(row=row, column=1, columnspan=3, sticky="we", padx=4, pady=6)
        ttk.Button(frame, text="选择目录", command=lambda: self._browse_dir(self.batch_out_var)).grid(row=row, column=4, padx=4, pady=6)

        row += 1
        ttk.Button(frame, text="开始批量测试", command=self.run_batch_test).grid(row=row, column=0, columnspan=2, sticky="w", padx=4, pady=10)

        frame.columnconfigure(3, weight=1)

    def _build_tournament_tab(self) -> None:
        frame = self.tab_tournament
        row = 0

        ttk.Label(frame, text="参赛 AI（逗号分隔）").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.tour_ais_var = tk.StringVar(value="mybot,mybot_v3,mybot_v5,greedy")
        ttk.Entry(frame, textvariable=self.tour_ais_var, width=60).grid(row=row, column=1, columnspan=3, sticky="we", padx=4, pady=6)

        row += 1
        ttk.Label(frame, text="Seeds").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.tour_seeds_var = tk.StringVar(value="7,19,23")
        ttk.Entry(frame, textvariable=self.tour_seeds_var, width=24).grid(row=row, column=1, sticky="w", padx=4, pady=6)

        self.tour_swap_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame, text="每对 AI 双向换边", variable=self.tour_swap_var).grid(row=row, column=2, sticky="w", padx=4, pady=6)

        self.tour_keep_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frame, text="保留 replay/log", variable=self.tour_keep_var).grid(row=row, column=3, sticky="w", padx=4, pady=6)

        row += 1
        ttk.Label(frame, text="输出目录").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.tour_out_var = tk.StringVar(value=str(REPO_ROOT / "batch_runs" / "gui_tournament"))
        ttk.Entry(frame, textvariable=self.tour_out_var, width=60).grid(row=row, column=1, columnspan=3, sticky="we", padx=4, pady=6)
        ttk.Button(frame, text="选择目录", command=lambda: self._browse_dir(self.tour_out_var)).grid(row=row, column=4, padx=4, pady=6)

        row += 1
        ttk.Button(frame, text="开始循环赛", command=self.run_tournament).grid(row=row, column=0, columnspan=2, sticky="w", padx=4, pady=10)

        frame.columnconfigure(3, weight=1)

    def _build_playback_tab(self) -> None:
        frame = self.tab_playback
        row = 0

        ttk.Label(frame, text="回放目录").grid(row=row, column=0, sticky="w", padx=4, pady=6)
        self.playback_dir_var = tk.StringVar(value=str(REPO_ROOT / "playback"))
        ttk.Entry(frame, textvariable=self.playback_dir_var, width=60).grid(row=row, column=1, columnspan=3, sticky="we", padx=4, pady=6)
        ttk.Button(frame, text="选择目录", command=lambda: self._browse_dir(self.playback_dir_var)).grid(row=row, column=4, padx=4, pady=6)

        row += 1
        ttk.Button(frame, text="分析回放目录", command=self.run_playback_analysis).grid(row=row, column=0, columnspan=2, sticky="w", padx=4, pady=10)

        frame.columnconfigure(3, weight=1)

    def _build_log_panel(self, parent: ttk.Frame) -> None:
        box = ttk.LabelFrame(parent, text="运行日志", padding=8)
        box.pack(fill=tk.BOTH, expand=True, padx=4, pady=8)

        toolbar = ttk.Frame(box)
        toolbar.pack(fill=tk.X)
        ttk.Button(toolbar, text="清空日志", command=self.clear_log).pack(side=tk.LEFT, padx=4, pady=4)
        ttk.Button(toolbar, text="停止当前任务", command=self.stop_current_task).pack(side=tk.LEFT, padx=4, pady=4)

        self.log_text = tk.Text(box, wrap="word", height=18)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.insert("end", "AI Lab GUI 已就绪。\n")
        self.log_text.insert("end", f"Repo: {self.repo_root_win}\n")
        self.log_text.insert("end", f"WSL Path: {self.repo_root_wsl}\n\n")
        self.log_text.configure(state="disabled")

    def append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _poll_output(self) -> None:
        try:
            while True:
                text = self.output_queue.get_nowait()
                self.append_log(text)
        except queue.Empty:
            pass
        self.after(120, self._poll_output)

    def stop_current_task(self) -> None:
        if self.runner is not None:
            self.runner.stop()
            self.append_log("\n[INFO] 已请求停止当前任务。\n")

    def _run_wsl_command(self, command_str: str) -> None:
        if self.runner is not None and self.runner.is_alive():
            messagebox.showwarning("任务仍在运行", "请先等待当前任务结束，或点击“停止当前任务”。")
            return
        self.append_log(f"\n[INFO] 开始任务：{command_str}\n\n")
        self.runner = RunnerThread(["wsl", "bash", "-lc", command_str], self.output_queue)
        self.runner.start()

    def _base_wsl_prefix(self) -> str:
        return f"cd {shell_quote(self.repo_root_wsl)} && source .venv/bin/activate"

    def run_single_match(self) -> None:
        ai0 = self.single_ai0_var.get().strip()
        ai1 = self.single_ai1_var.get().strip()
        seed = self.single_seed_var.get().strip()
        out_dir = windows_path_to_wsl(Path(self.single_out_var.get().strip()))
        cmd = (
            f"{self._base_wsl_prefix()} && "
            f"python tools/run_local_match.py "
            f"--ai0 {shell_quote(ai0)} --ai1 {shell_quote(ai1)} "
            f"--seed {shell_quote(seed)} "
            f"--keep-dir {shell_quote(out_dir)}"
        )
        self._run_wsl_command(cmd)

    def run_batch_test(self) -> None:
        ai0 = self.batch_ai0_var.get().strip()
        ai1 = self.batch_ai1_var.get().strip()
        seeds = self.batch_seeds_var.get().strip()
        out_dir = windows_path_to_wsl(Path(self.batch_out_var.get().strip()))
        swap = " --swap-sides" if self.batch_swap_var.get() else ""
        keep = " --keep-replays" if self.batch_keep_var.get() else ""
        cmd = (
            f"{self._base_wsl_prefix()} && "
            f"python tools/ai_lab.py batch "
            f"--ai0 {shell_quote(ai0)} --ai1 {shell_quote(ai1)} "
            f"--seeds {shell_quote(seeds)} "
            f"--out-dir {shell_quote(out_dir)} --clean{swap}{keep}"
        )
        self._run_wsl_command(cmd)

    def run_tournament(self) -> None:
        ais = self.tour_ais_var.get().strip()
        seeds = self.tour_seeds_var.get().strip()
        out_dir = windows_path_to_wsl(Path(self.tour_out_var.get().strip()))
        swap = " --swap-sides" if self.tour_swap_var.get() else ""
        keep = " --keep-replays" if self.tour_keep_var.get() else ""
        cmd = (
            f"{self._base_wsl_prefix()} && "
            f"python tools/ai_lab.py tournament "
            f"--ais {shell_quote(ais)} "
            f"--seeds {shell_quote(seeds)} "
            f"--out-dir {shell_quote(out_dir)} --clean{swap}{keep}"
        )
        self._run_wsl_command(cmd)

    def run_playback_analysis(self) -> None:
        folder = windows_path_to_wsl(Path(self.playback_dir_var.get().strip()))
        cmd = (
            f"{self._base_wsl_prefix()} && "
            f"python tools/ai_lab.py analyze-playback "
            f"--folder {shell_quote(folder)}"
        )
        self._run_wsl_command(cmd)


def main() -> None:
    app = AILabGUI()
    app.mainloop()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations

"""
Replay Style Lab

???
1. ?? playback/ ???? summary/csv/html ??????????? json
2. ???? side??????????????????????
3. ??? v13/v14 ?????????????
"""

import argparse
import csv
import html
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean


REPO_ROOT = Path(__file__).resolve().parents[1]
DERIVED_NAME_PREFIXES = (
    "replay_style_",
    "playback_",
)

# ????? mybot ??????????????????
KNOWN_OPENINGS = {
    0: {
        ((5, 9), (6, 9)),
        ((4, 9), (5, 9)),
        ((6, 9),),
        ((5, 9),),
        ((4, 2), (6, 1)),
        ((4, 2), (7, 1)),
        (),
    },
    1: {
        ((12, 9), (13, 9)),
        ((13, 9), (14, 9)),
        ((12, 9),),
        ((13, 9),),
        ((9, 2), (11, 1)),
        ((9, 2), (12, 1)),
        (),
    },
}
OPENING_STYLE_BUCKETS = {
    "standard_double": {((5, 9), (6, 9)), ((12, 9), (13, 9))},
    "offset_double": {((4, 9), (5, 9)), ((13, 9), (14, 9))},
    "single_center": {((5, 9),), ((6, 9),), ((12, 9),), ((13, 9),)},
    "highland_shell": {((4, 2), (6, 1)), ((4, 2), (7, 1)), ((9, 2), (11, 1)), ((9, 2), (12, 1))},
}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def is_raw_replay_data(data: object) -> bool:
    if not isinstance(data, list) or not data:
        return False
    first = data[0]
    return isinstance(first, dict) and "round_state" in first


def iter_replay_files(folder: Path) -> tuple[list[Path], list[Path]]:
    accepted: list[Path] = []
    skipped: list[Path] = []
    for path in sorted(folder.glob("*.json")):
        if path.name.startswith(DERIVED_NAME_PREFIXES):
            skipped.append(path)
            continue
        try:
            data = load_json(path)
        except Exception:
            skipped.append(path)
            continue
        if is_raw_replay_data(data):
            accepted.append(path)
        else:
            skipped.append(path)
    return accepted, skipped


def load_replay(path: Path) -> list[dict]:
    data = load_json(path)
    if not is_raw_replay_data(data):
        raise ValueError("replay root is not a non-empty list of round objects")
    return data


def build_positions(turn: dict, side: int) -> tuple[tuple[int, int], ...]:
    key = f"op{side}"
    out: list[tuple[int, int]] = []
    for op in turn.get(key, []):
        if not isinstance(op, dict) or op.get("type") != 11:
            continue
        pos = op.get("pos", {})
        if isinstance(pos, dict) and "x" in pos and "y" in pos:
            out.append((pos["x"], pos["y"]))
    return tuple(sorted(out))


def opening_signature(data: list[dict], side: int, rounds: int = 3) -> str:
    return "|".join(f"r{i}={list(build_positions(data[i], side))}" for i in range(min(rounds, len(data))))


def op_counter(data: list[dict], side: int) -> Counter:
    c = Counter()
    for turn in data:
        for op in turn.get(f"op{side}", []):
            if isinstance(op, dict) and "type" in op:
                c[int(op["type"])] += 1
    return c


def infer_my_side(data: list[dict]) -> int | None:
    if not data:
        return None

    def score_side(side: int) -> float:
        r0 = build_positions(data[0], side)
        r1 = build_positions(data[1], side) if len(data) >= 2 else ()
        r2 = build_positions(data[2], side) if len(data) >= 3 else ()
        score = 0.0
        if r0 in KNOWN_OPENINGS[side]:
            score += 5.0
        if side == 0:
            if r0 == ((5, 9), (6, 9)):
                score += 4.0
            if r0 == ((5, 9),):
                score += 1.5
            if (4, 9) in r0:
                score += 1.0
            if r0 in {((4, 2), (6, 1)), ((4, 2), (7, 1))}:
                score += 2.4
            if (8, 7) in r1 or (8, 7) in r2:
                score += 2.5
            if (8, 11) in r1 or (8, 11) in r2:
                score += 1.8
        else:
            if r0 == ((12, 9), (13, 9)):
                score += 4.0
            if r0 == ((13, 9),):
                score += 1.5
            if (14, 9) in r0:
                score += 1.0
            if r0 in {((9, 2), (11, 1)), ((9, 2), (12, 1))}:
                score += 2.4
            if (10, 7) in r1 or (10, 7) in r2:
                score += 2.5
            if (10, 11) in r1 or (10, 11) in r2:
                score += 1.8
        early_ops = sum(len(data[i].get(f"op{side}", [])) for i in range(1, min(12, len(data))))
        if early_ops <= 3:
            score += 0.8
        return score

    score0 = score_side(0)
    score1 = score_side(1)
    if max(score0, score1) < 4.0:
        return None
    return 0 if score0 >= score1 else 1


def classify_opening_bucket(r0: tuple[tuple[int, int], ...]) -> str:
    for bucket, signatures in OPENING_STYLE_BUCKETS.items():
        if r0 in signatures:
            return bucket
    if not r0:
        return "late_builder"
    return "misc_opening"


def classify_style(data: list[dict], side: int) -> str:
    counter = op_counter(data, side)
    r0 = build_positions(data[0], side) if data else tuple()
    build = counter[11]
    upgrade = counter[12]
    sell = counter[13]
    storm = counter[21]
    emp = counter[22]
    deflector = counter[23]
    evasion = counter[24]
    base_up = counter[31] + counter[32]
    weapons = storm + emp + deflector + evasion

    if sell >= 8 and build >= 8:
        return "sell_loop_stall"
    if weapons >= 6 and (deflector + evasion) >= 4:
        return "weapon_reactive"
    bucket = classify_opening_bucket(r0)
    if bucket == "highland_shell":
        return "highland_shell"
    if bucket == "offset_double":
        return "offset_double"
    if bucket == "single_center":
        return "single_center"
    if bucket == "standard_double":
        if base_up >= 2 and upgrade >= 6:
            return "std_double_econ"
        if weapons >= 3:
            return "std_double_weapon_mix"
        return "std_double_core"
    if base_up >= 2 and build <= 6:
        return "econ_upgrade"
    return "mixed_or_unknown"


def summarize_group(rows: list[dict]) -> dict[str, object]:
    wins = sum(1 for row in rows if row.get("my_win") is True)
    losses = sum(1 for row in rows if row.get("my_win") is False)
    rounds = [int(row["rounds"]) for row in rows]
    return {
        "count": len(rows),
        "wins": wins,
        "losses": losses,
        "win_rate": round(wins / max(len(rows), 1), 4),
        "avg_rounds": round(mean(rounds), 2) if rounds else 0.0,
    }


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fieldnames})


def build_html_report(out_dir: Path, overview: dict[str, object], replay_rows: list[dict], group_rows: list[dict]) -> None:
    def table(headers: list[str], rows: list[list[object]]) -> str:
        head = "".join(f"<th>{html.escape(str(header))}</th>" for header in headers)
        body = ""
        for row in rows:
            body += "<tr>" + "".join(f"<td>{html.escape(str(cell))}</td>" for cell in row) + "</tr>\n"
        return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"

    replay_table = table(
        ["file", "seed", "my_side", "winner", "my_win", "rounds", "opp_style", "my_ops", "opp_ops", "camps", "coins"],
        [
            [
                row["file"],
                row["seed"],
                row["my_side"],
                row["winner"],
                row["my_win"],
                row["rounds"],
                row["opp_style"],
                row["my_ops_short"],
                row["opp_ops_short"],
                row["camps"],
                row["coins"],
            ]
            for row in replay_rows
        ],
    )
    group_table = table(
        ["group_type", "group_key", "count", "wins", "losses", "win_rate", "avg_rounds"],
        [
            [
                row["group_type"],
                row["group_key"],
                row["count"],
                row["wins"],
                row["losses"],
                row["win_rate"],
                row["avg_rounds"],
            ]
            for row in group_rows
        ],
    )

    html_text = f"""<!doctype html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\">
  <title>Replay Style Lab Report</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }}
    table {{ border-collapse: collapse; margin: 16px 0; width: 100%; }}
    th, td {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; font-size: 13px; }}
    th {{ background: #f5f5f5; }}
    pre {{ background: #f7f7f7; padding: 12px; }}
  </style>
</head>
<body>
  <h1>Replay Style Lab Report</h1>
  <h2>Overview</h2>
  <pre>{html.escape(json.dumps(overview, ensure_ascii=False, indent=2))}</pre>
  <h2>Grouped Summary</h2>
  {group_table}
  <h2>Per Replay</h2>
  {replay_table}
</body>
</html>"""
    (out_dir / "replay_style_report.html").write_text(html_text, encoding="utf-8")


def analyze_playback(folder: Path) -> int:
    files, skipped = iter_replay_files(folder)
    if not files:
        print(f"No raw replay json files found in {folder}")
        if skipped:
            print(f"Skipped {len(skipped)} derived/invalid json files")
        return 1

    replay_rows: list[dict] = []
    style_groups: dict[str, list[dict]] = defaultdict(list)
    opening_groups: dict[str, list[dict]] = defaultdict(list)

    side_known = 0
    wins = losses = 0
    by_side = Counter()
    by_style = Counter()
    round_lengths = []

    for path in files:
        try:
            data = load_replay(path)
            my_side = infer_my_side(data)
            if my_side is None:
                replay_rows.append({"file": path.name, "error": "unable to infer my side"})
                continue
            side_known += 1
            opp_side = 1 - my_side
            last = data[-1].get("round_state", {})
            winner = last.get("winner")
            my_win = winner == my_side
            wins += int(my_win)
            losses += int(not my_win)
            by_side[f"side_{my_side}"] += 1
            my_counter = op_counter(data, my_side)
            opp_counter = op_counter(data, opp_side)
            opp_style = classify_style(data, opp_side)
            by_style[opp_style] += 1
            rounds = len(data)
            round_lengths.append(rounds)
            row = {
                "file": path.name,
                "seed": data[0].get("seed"),
                "my_side": my_side,
                "winner": winner,
                "my_win": my_win,
                "rounds": rounds,
                "camps": last.get("camps"),
                "coins": last.get("coins"),
                "message": last.get("message"),
                "my_ops": dict(my_counter),
                "opp_ops": dict(opp_counter),
                "my_ops_short": f"11:{my_counter[11]} 12:{my_counter[12]} 13:{my_counter[13]} 21:{my_counter[21]} 22:{my_counter[22]} 23:{my_counter[23]} 24:{my_counter[24]} 31:{my_counter[31]} 32:{my_counter[32]}",
                "opp_ops_short": f"11:{opp_counter[11]} 12:{opp_counter[12]} 13:{opp_counter[13]} 21:{opp_counter[21]} 22:{opp_counter[22]} 23:{opp_counter[23]} 24:{opp_counter[24]} 31:{opp_counter[31]} 32:{opp_counter[32]}",
                "opp_style": opp_style,
                "my_opening_signature": opening_signature(data, my_side),
                "opp_opening_signature": opening_signature(data, opp_side),
            }
            replay_rows.append(row)
            style_groups[opp_style].append(row)
            opening_groups[row["opp_opening_signature"]].append(row)
        except Exception as exc:
            replay_rows.append({"file": path.name, "error": str(exc)})

    overview = {
        "folder": str(folder),
        "raw_replay_file_count": len(files),
        "skipped_json_count": len(skipped),
        "identified_my_side_count": side_known,
        "wins": wins,
        "losses": losses,
        "estimated_win_rate": round(wins / max(side_known, 1), 4),
        "avg_rounds": round(mean(round_lengths), 2) if round_lengths else 0.0,
        "my_side_distribution": dict(by_side),
        "opponent_style_distribution": dict(by_style),
        "note": "Mixed-version safe: derived json files are filtered, and side inference uses current mybot-family opening signatures instead of assuming playback is pure v7.",
    }

    group_rows: list[dict] = []
    for style, rows in sorted(style_groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        group_rows.append({"group_type": "opponent_style", "group_key": style, **summarize_group(rows)})
    for signature, rows in sorted(opening_groups.items(), key=lambda kv: (-len(kv[1]), kv[0]))[:16]:
        group_rows.append({"group_type": "opponent_opening", "group_key": signature, **summarize_group(rows)})

    replay_rows.sort(key=lambda row: (str(row.get("opp_style")), str(row.get("file"))))
    out_json = folder / "replay_style_summary.json"
    out_replays_csv = folder / "replay_style_replays.csv"
    out_groups_csv = folder / "replay_style_groups.csv"
    out_json.write_text(json.dumps({"overview": overview, "groups": group_rows, "replays": replay_rows}, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(
        out_replays_csv,
        [
            "file",
            "seed",
            "my_side",
            "winner",
            "my_win",
            "rounds",
            "opp_style",
            "my_ops_short",
            "opp_ops_short",
            "camps",
            "coins",
            "message",
            "my_opening_signature",
            "opp_opening_signature",
            "error",
        ],
        replay_rows,
    )
    write_csv(out_groups_csv, ["group_type", "group_key", "count", "wins", "losses", "win_rate", "avg_rounds"], group_rows)
    build_html_report(folder, overview, replay_rows, group_rows)

    print(json.dumps(overview, ensure_ascii=False, indent=2))
    print(f"\nSaved: {out_json}")
    print(f"Saved: {out_replays_csv}")
    print(f"Saved: {out_groups_csv}")
    print(f"Saved: {folder / 'replay_style_report.html'}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Analyze online replay styles with raw-replay filtering and mixed-version-safe side inference")
    parser.add_argument("--folder", default="playback", help="Folder containing replay json files")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return analyze_playback(Path(args.folder).resolve())


if __name__ == "__main__":
    raise SystemExit(main())

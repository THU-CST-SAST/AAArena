#!/usr/bin/env python3
from __future__ import annotations

"""
Train/derive the tiny v29 reranker from the existing playback/v26 aggregate.

This is intentionally a lightweight, dependency-free model.  It does not try to
replace the v26 policy.  Instead it turns the side-neutral replay statistics
from playback/v26 into a compact set of linear feature weights that can be
embedded directly into AI/ai_mybot_v29.py.
"""

import argparse
import json
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = REPO_ROOT / "playback" / "v26" / "v28_replay_analysis.json"
DEFAULT_OUTPUT = REPO_ROOT / "playback" / "v26" / "v29_reranker_weights.json"


def _metric(summary: dict[str, Any], name: str) -> dict[str, float]:
    row = summary["winner_vs_loser_metrics"][name]
    return {
        "winner_avg": float(row["winner_avg"]),
        "loser_avg": float(row["loser_avg"]),
    }


def _winner_edge(summary: dict[str, Any], name: str) -> float:
    row = _metric(summary, name)
    denom = max(abs(row["winner_avg"]), abs(row["loser_avg"]), 1.0)
    return (row["winner_avg"] - row["loser_avg"]) / denom


def _earlier_edge(summary: dict[str, Any], name: str) -> float:
    row = _metric(summary, name)
    denom = max(abs(row["winner_avg"]), abs(row["loser_avg"]), 1.0)
    return (row["loser_avg"] - row["winner_avg"]) / denom


def _factor_share(summary: dict[str, Any], key: str) -> float:
    total_rows = max(float(summary.get("rows", 0) or summary.get("parsed_games", 1) * 2), 1.0)
    for row in summary.get("all_failure_factor_counts", []):
        if row["key"] == key:
            return float(row["count"]) / total_rows
    return 0.0


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def derive_weights(summary: dict[str, Any]) -> dict[str, Any]:
    storm_edge = _winner_edge(summary, "ops_storm")
    storm_timing = _earlier_edge(summary, "first_storm")
    aoe_edge = _winner_edge(summary, "aoe_share")
    aoe_timing = _earlier_edge(summary, "first_aoe")
    deflector_edge = _winner_edge(summary, "ops_deflector")
    evasion_edge = _winner_edge(summary, "ops_evasion")
    build_churn = -_winner_edge(summary, "ops_build")
    early_build_churn = -_winner_edge(summary, "early_builds")
    producer_overuse = -_winner_edge(summary, "producer_share")
    counterpressure = _winner_edge(summary, "avg_combat_near_enemy")

    weights = {
        # Strongest learned separator: winners convert with Lightning much more
        # frequently and earlier. Keep this as a bonus only to v26's legal,
        # already-thresholded Lightning candidates.
        "uses_lightning": _clamp(0.80 * storm_edge + 0.35 * storm_timing, 0.20, 0.95),
        "closeout_lightning": _clamp(
            0.55 * storm_edge
            + 0.35 * _factor_share(summary, "late_closeout_conversion")
            + 0.20 * _factor_share(summary, "lightning_conversion_gap"),
            0.25,
            0.90,
        ),
        # Winners are earlier and denser on AOE/control conversion.
        "artillery_plan": _clamp(0.65 * aoe_edge + 0.35 * aoe_timing, 0.15, 0.70),
        "control_plan": _clamp(0.22 * aoe_edge + 0.12, 0.12, 0.35),
        "deflector_plan": _clamp(0.35 * deflector_edge, 0.05, 0.25),
        # Evasion appears slightly loser-skewed in aggregate, so keep it nearly
        # neutral and let v26's danger gate decide.
        "evasion_plan": _clamp(0.10 * evasion_edge, -0.08, 0.05),
        "emp_plan": _clamp(0.10 + 0.12 * storm_edge, 0.08, 0.22),
        # Churn and producer overuse are loser-skewed. Penalize only as a
        # reranker nudge; v26 still owns hard strategic gating.
        "generic_build_churn": -_clamp(0.30 * build_churn + 0.20 * early_build_churn, 0.05, 0.28),
        "producer_plan": -_clamp(0.22 * producer_overuse, 0.03, 0.18),
        "non_closeout_sell": -_clamp(
            0.45 * _factor_share(summary, "sell_churn_or_rebuild_tax") + 0.18,
            0.25,
            0.55,
        ),
        "counterpressure": _clamp(0.35 * counterpressure, 0.05, 0.22),
        "unsafe_tech": -0.16,
    }
    return {
        "model": "v29_tiny_linear_reranker",
        "source": str(DEFAULT_INPUT.relative_to(REPO_ROOT)),
        "raw_replays": int(summary.get("raw_replays", 0)),
        "parsed_games": int(summary.get("parsed_games", 0)),
        "rows": int(summary.get("rows", 0) or int(summary.get("parsed_games", 0)) * 2),
        "signals": {
            "storm_edge": round(storm_edge, 6),
            "storm_timing": round(storm_timing, 6),
            "aoe_edge": round(aoe_edge, 6),
            "aoe_timing": round(aoe_timing, 6),
            "build_churn": round(build_churn, 6),
            "producer_overuse": round(producer_overuse, 6),
            "counterpressure": round(counterpressure, 6),
        },
        "weights": {key: round(value, 6) for key, value in weights.items()},
        "runtime": {
            "scale": 0.42,
            "cap": 1.65,
            "policy": "add capped linear bonus to v26 one-step plan score; never generate actions directly",
        },
    }


def write_markdown(model: dict[str, Any], output_json: Path) -> None:
    md_path = output_json.with_suffix(".md")
    lines = [
        "# v29 tiny reranker training summary",
        "",
        f"- model: `{model['model']}`",
        f"- source: `{model['source']}`",
        f"- raw replays: `{model['raw_replays']}`",
        f"- parsed games: `{model['parsed_games']}`",
        f"- side rows: `{model['rows']}`",
        f"- runtime scale: `{model['runtime']['scale']}`",
        f"- runtime cap: `{model['runtime']['cap']}`",
        "",
        "## Learned signals",
        "",
    ]
    for key, value in model["signals"].items():
        lines.append(f"- `{key}`: `{value}`")
    lines.extend(["", "## Embedded weights", ""])
    for key, value in model["weights"].items():
        lines.append(f"- `{key}`: `{value}`")
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "- Keep v26 as the base policy.",
            "- Reward legal Lightning / AOE / closeout candidates more when v26 already proposes them.",
            "- Penalize churny generic builds, non-closeout sells, and unsafe tech only as small tie-break nudges.",
            "- The model is intentionally small enough to embed in the submitted AI without new dependencies.",
            "",
        ]
    )
    md_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Derive v29 tiny reranker weights from playback/v26 aggregate stats.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    summary = json.loads(args.input.read_text(encoding="utf-8"))
    model = derive_weights(summary)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(model, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_markdown(model, args.output)
    print(json.dumps(model, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

from __future__ import annotations
"""
AI 侧的公共抽象。

这个文件回答 3 个最重要的问题：

1. 一个“选手 AI”最少需要实现什么接口？
   -> BaseAgent.choose_bundle()

2. 比赛过程中，AI 如何与对局流程交互？
   -> MatchSession 抽象 + ProtocolSession 具体实现（见 AI/protocol.py）

3. AI 平时如何拿到候选动作？
   -> BaseAgent.list_bundles() -> ActionCatalog.build()
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
import random

from SDK.utils.actions import ActionBundle, ActionCatalog
from SDK.backend.state import BackendState
from SDK.utils.constants import MAX_ACTIONS
from SDK.utils.features import FeatureExtractor
from SDK.backend.model import Operation


@dataclass(slots=True)
class AgentContext:
    """一个很轻量的上下文容器。

    目前项目里没有重度使用它，但它表达了 AI 决策最关键的三元组：
        - state: 当前局面
        - player: 当前执棋方
        - bundles: 当前候选动作
    """
    state: BackendState
    player: int
    bundles: list[ActionBundle]


class MatchSession(ABC):
    """“一场比赛中的一个 AI 运行会话”抽象。

    你可以把它理解成：
        BaseAgent 只负责“想动作”
        MatchSession 负责“在什么时候想、收到什么信息、怎么和外界同步”

    本项目默认的具体实现是 ProtocolSession，它把 stdin/stdout 协议包装成这个接口。
    """
    @property
    @abstractmethod
    def player(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def perform_self_turn(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def receive_opponent_turn(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def sync_round(self) -> bool:
        raise NotImplementedError


class BaseAgent(ABC):
    """所有选手 AI 的推荐基类。

    重要设计思想：
        - 规则逻辑不要写在 AI 里
        - 候选动作不要手写枚举，交给 ActionCatalog
        - 你只需要实现 choose_bundle()
    """
    def __init__(self, seed: int | None = None, max_actions: int = MAX_ACTIONS) -> None:
        self._seed_override = seed
        # 每个 AI 自带一个随机数发生器，避免直接污染全局 random 状态。
        self.rng = random.Random(seed)
        # FeatureExtractor: 把局面编码成更适合做评分/训练的特征。
        self.feature_extractor = FeatureExtractor(max_actions=max_actions)
        # ActionCatalog: 从当前局面生成“候选动作包”。
        self.catalog = ActionCatalog(max_actions=max_actions, feature_extractor=self.feature_extractor)

    def list_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        # 大多数 AI 的起点都是这一步：
        # “不要自己从零枚举操作，而是先拿到系统筛过的一批候选动作”
        return self.catalog.build(state, player)

    def on_match_start(self, player: int, seed: int) -> None:
        # 如果外部没有显式传 seed，就用平台 seed + player 做一个稳定初始化。
        if self._seed_override is None:
            self.rng.seed((seed << 1) ^ player)

    def on_self_operations(self, operations) -> None:
        # 这些 on_xxx 钩子给你做“带记忆的 AI”准备。
        # 例如你可以记录自己上一回合做了什么、统计对手风格等等。
        del operations

    def on_opponent_operations(self, operations) -> None:
        del operations

    def on_round_state(self, public_round_state) -> None:
        del public_round_state

    @abstractmethod
    def choose_bundle(self, state: BackendState, player: int, bundles: list[ActionBundle] | None = None) -> ActionBundle:
        """你真正要实现的核心接口。

        输入：
            - state: 当前完整后端状态（可读）
            - player: 当前玩家编号 0/1
            - bundles: 当前候选动作包，若为 None 可自行调用 list_bundles()

        输出：
            - 一个 ActionBundle，表示这一回合决定执行的操作集合
        """
        raise NotImplementedError

    def choose_operations(self, state: BackendState, player: int, bundles: list[ActionBundle] | None = None) -> list[Operation]:
        # 比赛协议层最终需要的是 Operation 列表；
        # 这里只是把 choose_bundle() 的结果拆出来。
        return list(self.choose_bundle(state, player, bundles=bundles).operations)

    def choose_action_index(self, state: BackendState, player: int, bundles: list[ActionBundle] | None = None) -> int:
        # 训练环境通常不用“操作列表”，而用“离散动作编号”；
        # 这个函数就是把 bundle 反查成 index。
        bundles = bundles or self.list_bundles(state, player)
        target = self.choose_bundle(state, player, bundles=bundles)
        for index, bundle in enumerate(bundles):
            if bundle.operations == target.operations:
                return index
        return 0

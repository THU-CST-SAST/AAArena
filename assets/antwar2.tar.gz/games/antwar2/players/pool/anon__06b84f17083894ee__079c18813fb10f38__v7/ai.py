﻿from __future__ import annotations

"""v35: combat-aware model-predictive AI.

This version is rebuilt from current mechanics: base HP is the main objective;
forward Producers shorten our ant path; control/AOE towers protect HP; and
super weapons are used only when the live board state justifies their cost.
"""

from dataclasses import dataclass
from typing import Iterable

from SDK.backend.model import Operation, Tower
from SDK.backend.state import BackendState
from SDK.utils.actions import ActionBundle
try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent
from SDK.utils.constants import (
    COMBAT_SELF_DESTRUCT_DAMAGE,
    COMBAT_SELF_DESTRUCT_RANGE,
    HIGHLAND_CELLS,
    LIGHTNING_STORM_ANT_DAMAGE,
    LIGHTNING_STORM_TOWER_DAMAGE,
    LIGHTNING_STORM_TOWER_INTERVAL,
    OperationType,
    PLAYER_BASES,
    SUPER_WEAPON_STATS,
    TOWER_UPGRADE_TREE,
    AntKind,
    TowerType,
    SuperWeaponType,
)
from SDK.utils.geometry import hex_distance, is_valid_pos, neighbors


CONTROL_TYPES = {TowerType.ICE, TowerType.BEWITCH, TowerType.PULSE}
AOE_TYPES = {TowerType.MORTAR, TowerType.MORTAR_PLUS, TowerType.PULSE, TowerType.MISSILE}
PRODUCER_TYPES = {TowerType.PRODUCER, TowerType.PRODUCER_FAST, TowerType.PRODUCER_SIEGE, TowerType.PRODUCER_MEDIC}

P0_DEFENSE_CORE = [(4, 9), (5, 9), (5, 7), (5, 11), (6, 9), (6, 7), (6, 11)]
P0_OPENING_DEFENSE = [(4, 9)]
P0_FORWARD_PROD = [(7, 8), (7, 10), (8, 7), (8, 11), (8, 4), (8, 14), (7, 5), (7, 13)]
P0_SAFE_PROD = [(5, 7), (5, 11), (6, 7), (6, 11), (7, 8), (7, 10), (6, 9)]
P0_SIDE_BAIT = [(4, 3), (4, 15), (5, 3), (5, 15), (6, 4), (6, 14), (6, 1), (6, 17), (7, 1), (7, 17)]

TOWER_BASE_VALUE = {
    TowerType.BASIC: 2.2,
    TowerType.HEAVY: 5.2,
    TowerType.QUICK: 5.7,
    TowerType.MORTAR: 6.2,
    TowerType.PRODUCER: 9.5,
    TowerType.HEAVY_PLUS: 8.2,
    TowerType.ICE: 10.8,
    TowerType.BEWITCH: 11.5,
    TowerType.QUICK_PLUS: 7.2,
    TowerType.DOUBLE: 8.6,
    TowerType.SNIPER: 7.6,
    TowerType.MORTAR_PLUS: 9.0,
    TowerType.PULSE: 11.8,
    TowerType.MISSILE: 10.0,
    TowerType.PRODUCER_FAST: 11.0,
    TowerType.PRODUCER_SIEGE: 13.2,
    TowerType.PRODUCER_MEDIC: 12.0,
}


@dataclass(frozen=True)
class Candidate:
    name: str
    ops: tuple[Operation, ...]
    bias: float = 0.0
    tags: tuple[str, ...] = ()


class AI(BaseAgent):
    def __init__(self, seed: int | None = None, max_actions: int = 96) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self.player = 0

    def on_match_start(self, player: int, seed: int) -> None:
        super().on_match_start(player, seed)
        self.player = player

    def choose_bundle(self, state: BackendState, player: int, bundles=None) -> ActionBundle:
        ops = tuple(self.choose_operations(state, player, bundles))
        return ActionBundle(name="v35-combat-aware", operations=ops, score=0.0, tags=("v35",))

    def choose_operations(self, state: BackendState, player: int, bundles=None) -> list[Operation]:
        self.player = player
        candidates = self._generate_candidates(state, player)
        scored = self._score_candidates(state, player, candidates)
        if not scored:
            return []
        best_score, best = max(scored, key=lambda item: item[0])
        hold_score = next((score for score, cand in scored if not cand.ops), None)
        if hold_score is not None and best.ops and best_score < hold_score + 0.35 and "emergency" not in best.tags:
            return []
        return list(best.ops)

    # ---------- candidate generation ----------

    def _generate_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        singles: list[Candidate] = []
        singles.extend(self._opening_candidates(state, player))
        singles.extend(self._build_candidates(state, player))
        singles.extend(self._upgrade_candidates(state, player))
        singles.extend(self._weapon_candidates(state, player))
        singles.extend(self._base_upgrade_candidates(state, player))
        singles.extend(self._refund_candidates(state, player))
        singles.extend(self._anti_combat_bait_candidates(state, player))
        singles = [cand for cand in singles if self._can_sequence(state, player, cand.ops)]
        singles.sort(key=lambda cand: cand.bias, reverse=True)

        out = [Candidate("hold", (), 0.0, ("hold",))]
        out.extend(singles[:64])
        out.extend(self._combo_candidates(state, player, singles[:24]))
        unique: dict[tuple[tuple[int, int, int], ...], Candidate] = {}
        for cand in out:
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in cand.ops)
            old = unique.get(key)
            if old is None or cand.bias > old.bias:
                unique[key] = cand
        return list(unique.values())[:96]

    def _opening_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        """High-confidence book derived from the current combat-ant rules.

        Cheap, separated Basic towers absorb the early stochastic wave and lure
        combat ants without forming self-destruct clusters; the first upgraded
        defense then unlocks a safe Producer.  These are candidates rather than
        hard commands so emergency weapon/refund logic can still override them.
        """
        out: list[Candidate] = []
        opening_cells = [self._mirror(player, cell) for cell in P0_OPENING_DEFENSE]
        existing = {(t.x, t.y): t for t in state.towers_of(player)}

        if state.round_index < 8:
            for index, cell in enumerate(opening_cells):
                if cell in existing:
                    continue
                op = Operation(OperationType.BUILD_TOWER, *cell)
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"book-build@{cell[0]},{cell[1]}", (op,), 88.0 - index * 1.5, ("book", "build")))
                    break

        if state.round_index < 70 and not self._has_upgraded_defense(state, player):
            targets = [existing[cell] for cell in opening_cells if cell in existing and existing[cell].tower_type == TowerType.BASIC]
            targets.extend(t for t in state.towers_of(player) if t.tower_type == TowerType.BASIC and (t.x, t.y) in self._defense_cells(player) and t not in targets)
            if targets:
                tower = max(targets, key=lambda item: (item.hp, item.x == opening_cells[-1][0] and item.y == opening_cells[-1][1]))
                target_type = self._opening_upgrade_type(state, player, tower)
                op = Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target_type))
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"book-up#{tower.tower_id}->{target_type.name}", (op,), 86.0 + self._base_danger(state, player) * 0.8, ("book", "upgrade", self._type_tag(target_type))))

        prod_count = sum(1 for t in state.towers_of(player) if t.tower_type in PRODUCER_TYPES)
        if self._has_upgraded_defense(state, player) and prod_count == 0 and state.round_index < 125:
            shells = [
                t
                for t in state.towers_of(player)
                if t.tower_type == TowerType.BASIC and (t.x, t.y) in self._producer_cells(player)
            ]
            if shells:
                tower = min(shells, key=lambda item: (self._pressure_on_cell(state, player, item.x, item.y), -self._cell_forward_value(player, (item.x, item.y))))
                op = Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(TowerType.PRODUCER))
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"book-prod#{tower.tower_id}", (op,), 44.0 - self._pressure_on_cell(state, player, tower.x, tower.y), ("book", "upgrade", "producer")))
            elif state.tower_count(player) <= 3 or self._base_danger(state, player) < 8.0:
                for cell in self._safe_producer_order(state, player):
                    if state.tower_at(*cell) is not None:
                        continue
                    op = Operation(OperationType.BUILD_TOWER, *cell)
                    if state.can_apply_operation(player, op):
                        out.append(Candidate(f"book-prod-shell@{cell[0]},{cell[1]}", (op,), 40.0 - self._pressure_on_cell(state, player, *cell), ("book", "build", "producer")))
                        break
        return out

    def _build_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        cost = state.build_tower_cost(state.tower_count(player))
        if state.coins[player] < cost:
            return []
        danger = self._base_danger(state, player)
        tower_count = state.tower_count(player)
        prod_count = sum(1 for t in state.towers_of(player) if t.tower_type in PRODUCER_TYPES)
        basic_prod_shell = any(t.tower_type == TowerType.BASIC and (t.x, t.y) in self._producer_cells(player) for t in state.towers_of(player))
        has_basic_defense = any(t.tower_type == TowerType.BASIC and (t.x, t.y) in self._defense_cells(player) for t in state.towers_of(player))
        if state.round_index >= 1 and state.round_index < 75 and has_basic_defense and not self._has_upgraded_defense(state, player):
            return []
        if tower_count >= 3 and danger < 7.0 and state.round_index < 180:
            return []
        if tower_count >= 2 and prod_count == 0 and basic_prod_shell and danger < 7.5:
            return []
        out: list[Candidate] = []
        cells = self._ordered_build_cells(player)
        for ant in state.ants_of(1 - player):
            for _, nx, ny in neighbors(ant.x, ant.y):
                if (nx, ny) in HIGHLAND_CELLS[player] and (nx, ny) not in cells:
                    cells.append((nx, ny))
        for cell in cells[:28]:
            if state.tower_at(*cell) is not None:
                continue
            if self._has_upgraded_defense(state, player) and prod_count == 0:
                inner_safe = {self._mirror(player, c) for c in P0_SAFE_PROD[:4]}
                allowed = inner_safe if danger < 7.5 else (inner_safe | self._defense_cells(player))
                if cell not in allowed:
                    continue
            op = Operation(OperationType.BUILD_TOWER, *cell)
            if not state.can_apply_operation(player, op):
                continue
            bias = self._build_cell_value(state, player, cell) - 0.045 * cost
            if state.round_index < 3 and cell in self._forward_cells(player):
                bias += 1.4
            if self._base_danger(state, player) > 6.5 and self._cell_defense_value(state, player, cell) > 2.0:
                bias += 2.8
            out.append(Candidate(f"build@{cell[0]},{cell[1]}", (op,), bias, ("build",)))
        return out

    def _upgrade_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        out: list[Candidate] = []
        for tower in state.towers_of(player):
            for target in TOWER_UPGRADE_TREE.get(tower.tower_type, ()):
                op = Operation(OperationType.UPGRADE_TOWER, tower.tower_id, int(target))
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"up#{tower.tower_id}->{target.name}", (op,), self._upgrade_value(state, player, tower, target), ("upgrade", self._type_tag(target))))
        return out

    def _weapon_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        return (
            self._lightning_candidates(state, player)
            + self._deflector_candidates(state, player)
            + self._evasion_candidates(state, player)
            + self._emp_candidates(state, player)
        )

    def _base_upgrade_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        if self._base_danger(state, player) > 4.5 or state.coins[player] < 220 or self._producer_count_quality(state, player) < 1.0:
            return []
        out: list[Candidate] = []
        if state.bases[player].generation_level < 2:
            op = Operation(OperationType.UPGRADE_GENERATION_SPEED)
            if state.can_apply_operation(player, op):
                out.append(Candidate("base-speed", (op,), 17.0 + 0.035 * state.round_index - state.bases[player].generation_level * 1.5 + self._assault_pressure(state, player) * 0.8, ("base",)))
        if state.bases[player].ant_level < 2:
            op = Operation(OperationType.UPGRADE_GENERATED_ANT)
            if state.can_apply_operation(player, op):
                out.append(Candidate("base-hp", (op,), 14.5 + 0.030 * state.round_index - state.bases[player].ant_level * 1.2 + self._assault_pressure(state, player) * 0.6, ("base",)))
        return out

    def _refund_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        if state.tower_count(player) <= 1:
            return []
        out: list[Candidate] = []
        for tower in state.towers_of(player):
            if tower.tower_type != TowerType.BASIC:
                continue
            op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
            if not state.can_apply_operation(player, op):
                continue
            pressure = self._pressure_on_cell(state, player, tower.x, tower.y)
            critical = self._cell_defense_value(state, player, (tower.x, tower.y)) > 3.0 or tower.tower_type in CONTROL_TYPES
            refund = state.operation_income(player, op)
            blast_risk = self._combat_blast_risk(state, player, tower)
            if blast_risk > 0 and tower.hp <= 7 and not self._is_opening_anchor(player, tower.x, tower.y):
                out.append(Candidate(f"deny-blast#{tower.tower_id}", (op,), 10.0 + refund * 0.05 + blast_risk, ("sell", "emergency")))
                continue
            if tower.hp <= 3 and pressure < 0.8 and not critical and state.coins[player] < 70:
                out.append(Candidate(f"salvage#{tower.tower_id}", (op,), 1.4 + refund * 0.04, ("sell",)))
        return out

    def _anti_combat_bait_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        if state.coins[player] < state.build_tower_cost(state.tower_count(player)):
            return []
        if state.round_index < 75 and not self._has_upgraded_defense(state, player) and state.coins[player] >= 45:
            return []
        combat_threat = self._enemy_combat_threat(state, player)
        if combat_threat < 5.0:
            return []
        out: list[Candidate] = []
        existing = list(state.towers_of(player))
        for cell in self._ordered_build_cells(player):
            if cell not in self._defense_cells(player) and cell not in {self._mirror(player, c) for c in P0_SIDE_BAIT[:6]}:
                continue
            if state.tower_at(*cell) is not None:
                continue
            if any(hex_distance(cell[0], cell[1], t.x, t.y) <= COMBAT_SELF_DESTRUCT_RANGE for t in existing):
                continue
            local_pull = sum(
                max(0.0, 7 - hex_distance(cell[0], cell[1], ant.x, ant.y))
                for ant in state.ants_of(1 - player)
                if ant.kind == AntKind.COMBAT
            )
            if local_pull <= 0:
                continue
            op = Operation(OperationType.BUILD_TOWER, *cell)
            if state.can_apply_operation(player, op):
                out.append(Candidate(f"combat-bait@{cell[0]},{cell[1]}", (op,), 7.5 + local_pull - 0.6 * self._pressure_on_cell(state, player, *cell), ("build", "emergency")))
        out.sort(key=lambda item: item.bias, reverse=True)
        return out[:3]

    def _combo_candidates(self, state: BackendState, player: int, singles: list[Candidate]) -> list[Candidate]:
        out: list[Candidate] = []
        economy = [cand for cand in singles if cand.tags and cand.tags[0] in {"build", "upgrade", "sell", "base"}][:12]
        for i, first in enumerate(economy):
            for second in economy[i + 1 :]:
                ops = first.ops + second.ops
                if state.round_index < 45 and all(op.op_type == OperationType.BUILD_TOWER for op in ops):
                    continue
                if len(ops) <= 3 and self._can_sequence(state, player, ops):
                    out.append(Candidate(first.name + "+" + second.name, ops, first.bias + 0.82 * second.bias - 0.25, ("combo",)))
        sells = [cand for cand in economy if "sell" in cand.tags][:4]
        weapons = [cand for cand in singles if "weapon" in cand.tags][:6]
        for sell in sells:
            for weapon in weapons:
                ops = sell.ops + weapon.ops
                if self._can_sequence(state, player, ops):
                    out.append(Candidate(sell.name + "+" + weapon.name, ops, sell.bias + weapon.bias + 1.5, ("combo", "weapon")))
        return out

    # ---------- scoring ----------

    def _score_candidates(self, state: BackendState, player: int, candidates: list[Candidate]) -> list[tuple[float, Candidate]]:
        rough: list[tuple[float, Candidate]] = []
        for cand in candidates:
            if self._can_sequence(state, player, cand.ops):
                rough.append((cand.bias + self._operation_delta_static(state, player, cand.ops), cand))
        rough.sort(key=lambda item: item[0], reverse=True)
        # Full simulation rollouts are too expensive inside the Python SDK.
        # v35 therefore uses live-rule heuristics and only a tiny one-tick
        # lookahead on the highest-impact moments.
        if len(getattr(state, "ants", [])) <= 55:
            base_value = self._evaluate_state(state, player)
            refined: list[tuple[float, Candidate]] = []
            horizon = 6 if len(getattr(state, "ants", [])) <= 32 else 4
            if self._base_danger(state, player) > 7.0 or self._enemy_combat_threat(state, player) > 6.0:
                horizon += 2
            for rough_score, cand in rough[:10]:
                if not cand.ops or ("weapon" not in cand.tags and "emergency" not in cand.tags and "book" not in cand.tags and rough_score < 4.0):
                    refined.append((rough_score, cand))
                    continue
                trial = state.clone()
                if trial.apply_operation_list(player, cand.ops):
                    continue
                for _ in range(horizon):
                    trial.advance_round()
                    if getattr(trial, "terminal", False):
                        break
                refined.append((rough_score + 0.055 * (self._evaluate_state(trial, player) - base_value), cand))
            refined.extend(rough[10:])
            rough = refined
        if not any(not cand.ops for _, cand in rough):
            rough.append((0.0, Candidate("hold", (), 0.0, ("hold",))))
        return rough

    def _operation_delta_static(self, state: BackendState, player: int, ops: Iterable[Operation]) -> float:
        return 0.10 * self._sequence_coin_delta(state, player, tuple(ops))

    def _rollout_horizon(self, state: BackendState) -> int:
        ant_count = len(getattr(state, "ants", []))
        if ant_count > 45:
            return 4
        if state.round_index < 80:
            return 10
        if state.round_index < 220:
            return 8
        return 6

    def _evaluate_state(self, state: BackendState, player: int) -> float:
        enemy = 1 - player
        if getattr(state, "terminal", False):
            if state.winner == player:
                return 1_000_000.0
            if state.winner == enemy:
                return -1_000_000.0
        score = 72.0 * (state.bases[player].hp - state.bases[enemy].hp)
        score += 0.18 * (state.coins[player] - state.coins[enemy])
        score += 1.7 * (state.die_count[player] - state.die_count[enemy])
        score -= 1.2 * (state.super_weapon_usage[player] - state.super_weapon_usage[enemy])
        for tower in state.towers_of(player):
            score += self._tower_value(state, player, tower)
        for tower in state.towers_of(enemy):
            score -= 0.82 * self._tower_value(state, enemy, tower)
        score += 11.5 * self._assault_pressure(state, player)
        score -= 15.0 * self._base_danger(state, player)
        score -= 7.0 * self._assault_pressure(state, enemy)
        score += 2.4 * self._producer_count_quality(state, player)
        score -= 1.8 * self._producer_count_quality(state, enemy)
        return score

    def _tower_value(self, state: BackendState, player: int, tower: Tower) -> float:
        value = TOWER_BASE_VALUE.get(tower.tower_type, 3.0) * max(0.2, tower.hp / max(1, tower.max_hp))
        value += 0.65 * self._cell_defense_value(state, player, (tower.x, tower.y))
        if tower.tower_type in PRODUCER_TYPES:
            value += 0.85 * self._cell_forward_value(player, (tower.x, tower.y))
            if self._pressure_on_cell(state, player, tower.x, tower.y) > 5.0:
                value -= 4.0
        if tower.tower_type in CONTROL_TYPES:
            value += 1.4 * min(4.0, self._enemy_density(state, player, tower.x, tower.y, 3))
        if tower.tower_type in AOE_TYPES:
            value += 0.9 * min(5.0, self._enemy_density(state, player, tower.x, tower.y, 3))
        nearby = sum(1 for other in state.towers_of(player) if other.tower_id != tower.tower_id and hex_distance(tower.x, tower.y, other.x, other.y) <= 1)
        return value - 1.8 * nearby

    # ---------- tactical values ----------

    def _build_cell_value(self, state: BackendState, player: int, cell: tuple[int, int]) -> float:
        defense = self._cell_defense_value(state, player, cell)
        forward = self._cell_forward_value(player, cell)
        pressure = self._pressure_on_cell(state, player, *cell)
        prod_count = sum(1 for t in state.towers_of(player) if t.tower_type in PRODUCER_TYPES)
        defense_towers = sum(1 for t in state.towers_of(player) if (t.x, t.y) in self._defense_cells(player))
        has_basic_defense = any(t.tower_type == TowerType.BASIC and (t.x, t.y) in self._defense_cells(player) for t in state.towers_of(player))
        has_l1_defense = self._has_upgraded_defense(state, player)
        basic_prod_shell = any(t.tower_type == TowerType.BASIC and (t.x, t.y) in self._producer_cells(player) for t in state.towers_of(player))
        value = defense * 1.15 + forward * (0.42 if prod_count < 2 else 0.18) - pressure * 0.35
        if defense_towers == 0:
            if cell in self._defense_cells(player):
                value += 4.4 + max(0.0, 5 - hex_distance(cell[0], cell[1], *PLAYER_BASES[player])) * 0.45
            elif state.round_index < 60:
                value -= 3.4
        elif state.round_index < 70 and has_basic_defense and not has_l1_defense:
            # Rule-derived opening discipline: the first Basic near base is only
            # a scaffold.  Spending the next 30/45 coins on more Basic towers
            # delays the 60-coin real damage/control breakpoint and lets ants
            # leak through enhanced pathing.
            opening_second_basic = False
            if opening_second_basic:
                value += 10.5
            else:
                value -= 10.0
                if state.coins[player] >= 45:
                    value -= 18.0
                if cell in self._defense_cells(player) and self._base_danger(state, player) > 5.5:
                    value += 6.0
        if cell in self._forward_cells(player) and prod_count < (1 if state.round_index < 80 else 2):
            value += 1.5 if defense_towers == 0 else 3.0
        if has_l1_defense and prod_count == 0:
            if cell in self._producer_cells(player):
                inner_safe = {self._mirror(player, c) for c in P0_SAFE_PROD[:4]}
                value += (9.0 if cell in inner_safe else 2.0) - min(3.0, pressure * 0.55)
            else:
                value -= 4.0
            if basic_prod_shell and state.round_index < 110:
                value -= 12.0
        if state.tower_count(player) >= 4:
            value -= 1.8 * (state.tower_count(player) - 3)
        return value

    def _upgrade_value(self, state: BackendState, player: int, tower: Tower, target: TowerType) -> float:
        density = self._enemy_density(state, player, tower.x, tower.y, 3)
        pressure = self._pressure_on_cell(state, player, tower.x, tower.y)
        defense = self._cell_defense_value(state, player, (tower.x, tower.y))
        forward = self._cell_forward_value(player, (tower.x, tower.y))
        value = TOWER_BASE_VALUE.get(target, 4.0) - TOWER_BASE_VALUE.get(tower.tower_type, 2.0)
        value += max(0.0, 1.0 - tower.hp / max(1, tower.max_hp)) * 3.0
        if target == TowerType.PRODUCER:
            prod_count = sum(1 for t in state.towers_of(player) if t.tower_type in PRODUCER_TYPES)
            value += 2.4 * forward - 0.7 * pressure - 2.2 * prod_count
            primary_defense = self._mirror(player, P0_DEFENSE_CORE[0])
            if (
                tower.tower_type == TowerType.BASIC
                and (tower.x, tower.y) in self._defense_cells(player)
                and ((tower.x, tower.y) == primary_defense or not self._has_upgraded_defense(state, player))
                and state.round_index < 90
            ):
                value -= 10.0
            if tower.tower_type == TowerType.BASIC and (tower.x, tower.y) in self._producer_cells(player) and self._has_upgraded_defense(state, player) and prod_count == 0:
                value += 10.0 + max(0.0, 2.5 - pressure)
            if state.round_index <= 90 and prod_count == 0:
                value += 4.0
            if defense > 4.0 and self._base_danger(state, player) > 6.0:
                value -= 5.0
        elif target in PRODUCER_TYPES:
            value += 1.8 * forward - 0.4 * pressure
            if target == TowerType.PRODUCER_SIEGE:
                value += 24.0 + min(8.0, 0.08 * state.round_index)
                if self._assault_pressure(state, player) >= 4.0:
                    value += 5.0
                if self._base_danger(state, player) > 7.0:
                    value -= 8.0
            if target == TowerType.PRODUCER_FAST:
                value += 15.0 + min(5.0, 0.04 * state.round_index)
            if target == TowerType.PRODUCER_MEDIC and self._own_frontline_wounded(state, player) >= 2:
                value += 20.0
            if state.round_index < 95 and state.coins[player] < 320:
                value -= 8.0
        elif target in AOE_TYPES:
            value += 1.3 * density + 0.55 * defense
            if tower.tower_type == TowerType.BASIC and (tower.x, tower.y) in self._defense_cells(player) and state.round_index < 80:
                value += 11.0 if target == TowerType.MORTAR else 7.0
            if target == TowerType.PULSE:
                value += 2.0 if density >= 3.0 else -0.4
            if target == TowerType.MISSILE:
                value += 1.2 * self._assault_pressure(state, player)
        elif target in CONTROL_TYPES:
            value += 1.6 * density + 0.95 * defense
            if self._base_danger(state, player) > 5.0:
                value += 3.5
            if target == TowerType.BEWITCH and self._enemy_combat_near(state, player, tower.x, tower.y, 4):
                value += 2.2
        elif target in (TowerType.QUICK, TowerType.QUICK_PLUS, TowerType.DOUBLE, TowerType.SNIPER):
            value += 0.9 * density + 0.45 * defense
            if tower.tower_type == TowerType.BASIC and (tower.x, tower.y) in self._defense_cells(player) and state.round_index < 80:
                value += 15.0 if target == TowerType.QUICK else 5.0
            if target == TowerType.DOUBLE:
                value += 1.8 if density >= 2.0 else 0.4
            if target == TowerType.SNIPER:
                value += max(0.0, 10 - hex_distance(tower.x, tower.y, *PLAYER_BASES[1 - player])) * 0.25
        elif target in (TowerType.HEAVY, TowerType.HEAVY_PLUS):
            value += density + 0.65 * defense
            if tower.tower_type == TowerType.BASIC and (tower.x, tower.y) in self._defense_cells(player) and state.round_index < 80:
                value += 3.0
            if self._enemy_combat_near(state, player, tower.x, tower.y, 3):
                value += 1.8
        if state.coins[player] < 120 and target.value >= 10 and self._base_danger(state, player) < 4.0:
            value -= 2.5
        return value

    def _lightning_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        weapon = SuperWeaponType.LIGHTNING_STORM
        if state.weapon_cooldowns[player, weapon] > 0 or state.coins[player] < SUPER_WEAPON_STATS[weapon].cost:
            return []
        centers = {PLAYER_BASES[player], PLAYER_BASES[1 - player]}
        for ant in state.ants_of(1 - player):
            centers.add((ant.x, ant.y))
            for _, nx, ny in neighbors(ant.x, ant.y):
                if is_valid_pos(nx, ny):
                    centers.add((nx, ny))
        centers.update((tower.x, tower.y) for tower in state.towers_of(1 - player))
        out = []
        for x, y in centers:
            if not is_valid_pos(x, y):
                continue
            value = self._lightning_value(state, player, x, y)
            near_own = hex_distance(x, y, *PLAYER_BASES[player]) <= 6
            if value >= 8.0 or (near_own and value >= 5.5):
                op = Operation(OperationType.USE_LIGHTNING_STORM, x, y)
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"storm@{x},{y}", (op,), value - SUPER_WEAPON_STATS[weapon].cost * 0.018, ("weapon", "storm", "emergency" if near_own else "attack")))
        out.sort(key=lambda c: c.bias, reverse=True)
        return out[:6]

    def _deflector_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        weapon = SuperWeaponType.DEFLECTOR
        if state.weapon_cooldowns[player, weapon] > 0 or state.coins[player] < SUPER_WEAPON_STATS[weapon].cost:
            return []
        if state.round_index < 90 and not self._has_upgraded_defense(state, player) and self._base_danger(state, player) < 7.0:
            return []
        out = []
        for center in self._own_ant_centers(state, player):
            value = self._deflector_value(state, player, *center)
            if value >= 4.8:
                op = Operation(OperationType.USE_DEFLECTOR, *center)
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"deflect@{center[0]},{center[1]}", (op,), value - 1.2, ("weapon", "deflector")))
        out.sort(key=lambda c: c.bias, reverse=True)
        return out[:4]

    def _evasion_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        weapon = SuperWeaponType.EMERGENCY_EVASION
        if state.weapon_cooldowns[player, weapon] > 0 or state.coins[player] < SUPER_WEAPON_STATS[weapon].cost:
            return []
        if state.round_index < 90 and not self._has_upgraded_defense(state, player) and self._base_danger(state, player) < 7.0:
            return []
        out = []
        for center in self._own_ant_centers(state, player):
            value = self._evasion_value(state, player, *center)
            if value >= 5.2:
                op = Operation(OperationType.USE_EMERGENCY_EVASION, *center)
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"evasion@{center[0]},{center[1]}", (op,), value - 1.25, ("weapon", "evasion")))
        out.sort(key=lambda c: c.bias, reverse=True)
        return out[:4]

    def _emp_candidates(self, state: BackendState, player: int) -> list[Candidate]:
        weapon = SuperWeaponType.EMP_BLASTER
        if state.weapon_cooldowns[player, weapon] > 0 or state.coins[player] < SUPER_WEAPON_STATS[weapon].cost:
            return []
        if state.round_index < 110 and not self._producer_count_quality(state, player):
            return []
        out = []
        for x, y in {(t.x, t.y) for t in state.towers_of(1 - player)}:
            value = self._emp_value(state, player, x, y)
            if value >= 8.5:
                op = Operation(OperationType.USE_EMP_BLASTER, x, y)
                if state.can_apply_operation(player, op):
                    out.append(Candidate(f"emp@{x},{y}", (op,), value - 2.4, ("weapon", "emp")))
        out.sort(key=lambda c: c.bias, reverse=True)
        return out[:3]

    # ---------- weapon valuation ----------

    def _lightning_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        stats = SUPER_WEAPON_STATS[SuperWeaponType.LIGHTNING_STORM]
        tower_ticks = max(1, stats.duration // LIGHTNING_STORM_TOWER_INTERVAL)
        own_base = PLAYER_BASES[player]
        enemy_base = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(x, y, ant.x, ant.y)
            if d > stats.attack_range:
                continue
            shield = getattr(ant, "shield", 0)
            hits = shield + max(1, (ant.hp + LIGHTNING_STORM_ANT_DAMAGE - 1) // LIGHTNING_STORM_ANT_DAMAGE)
            kind = 2.2 if ant.kind == AntKind.COMBAT else 1.0 + 0.35 * ant.level
            urgency = max(0.0, 9 - hex_distance(ant.x, ant.y, *own_base)) * 0.8
            offense = max(0.0, 6 - hex_distance(ant.x, ant.y, *enemy_base)) * 0.35
            total += (3.0 + urgency + offense) * kind * max(0.4, (stats.attack_range + 1 - d) / 3.5)
            if hits <= 5:
                total += 3.0 + ant.kill_reward * 0.20
        for tower in state.towers_of(1 - player):
            d = hex_distance(x, y, tower.x, tower.y)
            if d <= stats.attack_range:
                projected = min(tower.hp, LIGHTNING_STORM_TOWER_DAMAGE * tower_ticks)
                total += projected / max(1, tower.max_hp) * (5.0 + 1.8 * tower.level)
                if tower.tower_type in PRODUCER_TYPES:
                    total += 2.2
                if tower.tower_type in CONTROL_TYPES or tower.tower_type in AOE_TYPES:
                    total += 1.4
        if hex_distance(x, y, *own_base) <= 5:
            total += 2.0
        return total

    def _deflector_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        enemy_base = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(player):
            if hex_distance(x, y, ant.x, ant.y) <= SUPER_WEAPON_STATS[SuperWeaponType.DEFLECTOR].attack_range:
                dbase = hex_distance(ant.x, ant.y, *enemy_base)
                kind = 2.5 if ant.kind == AntKind.COMBAT else 1.0 + 0.2 * ant.level
                total += kind * (max(0.0, 10 - dbase) * 0.55 + self._enemy_tower_damage_near(state, player, ant.x, ant.y) * 0.35 + 0.8)
                if dbase <= 5:
                    total += 2.5 * kind
        return total

    def _evasion_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        enemy_base = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(player):
            if hex_distance(x, y, ant.x, ant.y) <= SUPER_WEAPON_STATS[SuperWeaponType.EMERGENCY_EVASION].attack_range:
                dbase = hex_distance(ant.x, ant.y, *enemy_base)
                kind = 2.0 if ant.kind == AntKind.COMBAT else 1.0 + 0.2 * ant.level
                total += kind * (self._enemy_tower_damage_near(state, player, ant.x, ant.y) * 0.55 + max(0.0, 8 - dbase) * 0.45 + 0.7)
                if dbase <= 4:
                    total += 2.0 * kind
        return total

    def _emp_value(self, state: BackendState, player: int, x: int, y: int) -> float:
        total = min(8.0, self._assault_pressure(state, player)) * 0.9
        for tower in state.towers_of(1 - player):
            if hex_distance(x, y, tower.x, tower.y) <= SUPER_WEAPON_STATS[SuperWeaponType.EMP_BLASTER].attack_range:
                total += 3.0 + 2.0 * tower.level
                if tower.tower_type in PRODUCER_TYPES:
                    total += 2.5
                if tower.tower_type in CONTROL_TYPES or tower.tower_type in AOE_TYPES:
                    total += 2.0
        return total

    # ---------- board helpers ----------

    def _base_danger(self, state: BackendState, player: int) -> float:
        bx, by = PLAYER_BASES[player]
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(ant.x, ant.y, bx, by)
            if d <= 15:
                kind = 2.0 if ant.kind == AntKind.COMBAT else 1.0 + 0.25 * ant.level
                hp = ant.hp / max(1, ant.max_hp)
                total += (max(0, 15 - d) ** 1.25) * kind * (0.45 + hp + 0.35 * getattr(ant, "shield", 0))
                if d <= 4:
                    total += 6.0 * kind
        return total / 6.0

    def _assault_pressure(self, state: BackendState, player: int) -> float:
        ex, ey = PLAYER_BASES[1 - player]
        total = 0.0
        for ant in state.ants_of(player):
            d = hex_distance(ant.x, ant.y, ex, ey)
            kind = 2.2 if ant.kind == AntKind.COMBAT else 1.0 + 0.25 * ant.level
            total += max(0, 16 - d) * kind * (0.55 + ant.hp / max(1, ant.max_hp) + 0.3 * getattr(ant, "shield", 0))
            if d <= 4:
                total += 7.0 * kind
        return total / 8.0

    def _producer_count_quality(self, state: BackendState, player: int) -> float:
        total = 0.0
        for tower in state.towers_of(player):
            if tower.tower_type in PRODUCER_TYPES:
                total += 1.0 + 0.12 * self._cell_forward_value(player, (tower.x, tower.y))
                if tower.tower_type == TowerType.PRODUCER_SIEGE:
                    total += 1.4
                elif tower.tower_type == TowerType.PRODUCER_FAST:
                    total += 0.8
                elif tower.tower_type == TowerType.PRODUCER_MEDIC:
                    total += 1.0
        return total

    def _mirror(self, player: int, cell: tuple[int, int]) -> tuple[int, int]:
        return cell if player == 0 else (18 - cell[0], cell[1])

    def _ordered_build_cells(self, player: int) -> list[tuple[int, int]]:
        out: list[tuple[int, int]] = []
        for cell in P0_DEFENSE_CORE + P0_FORWARD_PROD + P0_SIDE_BAIT:
            mirrored = self._mirror(player, cell)
            if mirrored in HIGHLAND_CELLS[player] and mirrored not in out:
                out.append(mirrored)
        return out

    def _forward_cells(self, player: int) -> set[tuple[int, int]]:
        return {self._mirror(player, cell) for cell in P0_FORWARD_PROD}

    def _defense_cells(self, player: int) -> set[tuple[int, int]]:
        return {self._mirror(player, cell) for cell in P0_DEFENSE_CORE}

    def _producer_cells(self, player: int) -> set[tuple[int, int]]:
        return {self._mirror(player, cell) for cell in P0_SAFE_PROD[:4]}

    def _has_upgraded_defense(self, state: BackendState, player: int) -> bool:
        defense_cells = self._defense_cells(player)
        return any(t.tower_type != TowerType.BASIC and (t.x, t.y) in defense_cells for t in state.towers_of(player))

    def _is_opening_anchor(self, player: int, x: int, y: int) -> bool:
        return (x, y) in {self._mirror(player, cell) for cell in P0_OPENING_DEFENSE}

    def _safe_producer_order(self, state: BackendState, player: int) -> list[tuple[int, int]]:
        base_order = [self._mirror(player, cell) for cell in P0_SAFE_PROD]
        order_index = {cell: index for index, cell in enumerate(base_order)}
        cells = list(base_order)
        existing = list(state.towers_of(player))
        cells.sort(
            key=lambda cell: (
                1 if self._pressure_on_cell(state, player, *cell) > 6.5 else 0,
                order_index.get(cell, 99),
                sum(1 for tower in existing if hex_distance(cell[0], cell[1], tower.x, tower.y) <= COMBAT_SELF_DESTRUCT_RANGE),
                self._pressure_on_cell(state, player, *cell),
            )
        )
        return cells

    def _opening_upgrade_type(self, state: BackendState, player: int, tower: Tower) -> TowerType:
        density = self._enemy_density(state, player, tower.x, tower.y, 3)
        combat = self._enemy_combat_near(state, player, tower.x, tower.y, 5)
        if density >= 4.0 and combat == 0:
            return TowerType.MORTAR
        return TowerType.QUICK

    def _enemy_combat_threat(self, state: BackendState, player: int) -> float:
        bx, by = PLAYER_BASES[player]
        total = 0.0
        for ant in state.ants_of(1 - player):
            if ant.kind != AntKind.COMBAT:
                continue
            d = hex_distance(ant.x, ant.y, bx, by)
            if d <= 12:
                total += max(0.0, 12 - d) * (1.0 + ant.hp / max(1, ant.max_hp) + 0.25 * getattr(ant, "shield", 0))
        return total / 3.0

    def _combat_blast_risk(self, state: BackendState, player: int, tower: Tower) -> float:
        risk = 0.0
        for ant in state.ants_of(1 - player):
            if ant.kind != AntKind.COMBAT or hex_distance(ant.x, ant.y, tower.x, tower.y) > 1:
                continue
            if ant.hp * 2 >= ant.max_hp:
                continue
            splash = sum(
                min(COMBAT_SELF_DESTRUCT_DAMAGE, other.hp)
                for other in state.towers_of(player)
                if hex_distance(other.x, other.y, tower.x, tower.y) <= COMBAT_SELF_DESTRUCT_RANGE
            )
            risk += 4.0 + 0.55 * splash
        return risk

    def _cell_forward_value(self, player: int, cell: tuple[int, int]) -> float:
        enemy_base = PLAYER_BASES[1 - player]
        best = hex_distance(cell[0], cell[1], *enemy_base)
        for _, nx, ny in neighbors(cell[0], cell[1]):
            if is_valid_pos(nx, ny):
                best = min(best, hex_distance(nx, ny, *enemy_base))
        return max(0.0, 14 - best)

    def _cell_defense_value(self, state: BackendState, player: int, cell: tuple[int, int]) -> float:
        value = max(0.0, 11 - hex_distance(cell[0], cell[1], *PLAYER_BASES[player])) * 0.35
        if cell in self._defense_cells(player):
            value += 1.2
        for ant in state.ants_of(1 - player):
            d = hex_distance(cell[0], cell[1], ant.x, ant.y)
            if d <= 5:
                value += max(0.0, 5.5 - d) * (1.8 if ant.kind == AntKind.COMBAT else 1.0 + 0.25 * ant.level)
        return value

    def _pressure_on_cell(self, state: BackendState, player: int, x: int, y: int) -> float:
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(x, y, ant.x, ant.y)
            if d <= 4:
                total += max(0.0, 4.5 - d) * (2.0 if ant.kind == AntKind.COMBAT else 1.0 + 0.3 * ant.level)
        return total

    def _enemy_density(self, state: BackendState, player: int, x: int, y: int, radius: int) -> float:
        total = 0.0
        for ant in state.ants_of(1 - player):
            d = hex_distance(x, y, ant.x, ant.y)
            if d <= radius:
                total += (2.0 if ant.kind == AntKind.COMBAT else 1.0 + 0.25 * ant.level) * max(0.25, radius + 1 - d)
        return total

    def _enemy_combat_near(self, state: BackendState, player: int, x: int, y: int, radius: int) -> int:
        return sum(1 for ant in state.ants_of(1 - player) if ant.kind == AntKind.COMBAT and hex_distance(x, y, ant.x, ant.y) <= radius)

    def _own_frontline_wounded(self, state: BackendState, player: int) -> int:
        enemy_base = PLAYER_BASES[1 - player]
        return sum(1 for ant in state.ants_of(player) if hex_distance(ant.x, ant.y, *enemy_base) <= 7 and ant.hp < ant.max_hp)

    def _enemy_tower_damage_near(self, state: BackendState, player: int, x: int, y: int) -> float:
        total = 0.0
        for tower in state.towers_of(1 - player):
            if tower.tower_type not in PRODUCER_TYPES and hex_distance(x, y, tower.x, tower.y) <= tower.attack_range + 1:
                total += tower.damage / max(1.0, tower.speed)
        return total / 6.0

    def _own_ant_centers(self, state: BackendState, player: int) -> list[tuple[int, int]]:
        return list({(ant.x, ant.y) for ant in state.ants_of(player)})[:32]

    def _best_weapon_shortfall(self, state: BackendState, player: int) -> int | None:
        needs = []
        for weapon in (SuperWeaponType.LIGHTNING_STORM, SuperWeaponType.DEFLECTOR, SuperWeaponType.EMERGENCY_EVASION):
            if state.weapon_cooldowns[player, weapon] == 0 and state.coins[player] < SUPER_WEAPON_STATS[weapon].cost:
                needs.append(SUPER_WEAPON_STATS[weapon].cost - state.coins[player])
        return min(needs) if needs else None

    def _type_tag(self, tower_type: TowerType) -> str:
        if tower_type in PRODUCER_TYPES:
            return "producer"
        if tower_type in CONTROL_TYPES:
            return "control"
        if tower_type in AOE_TYPES:
            return "aoe"
        return "damage"

    def _legal_sequence(self, state: BackendState, player: int, ops: Iterable[Operation]) -> bool:
        trial = state.clone()
        illegal = trial.apply_operation_list(player, tuple(ops))
        return not illegal and not (getattr(trial, "terminal", False) and trial.winner == 1 - player)

    def _can_sequence(self, state: BackendState, player: int, ops: Iterable[Operation]) -> bool:
        pending: list[Operation] = []
        for op in ops:
            if not state.can_apply_operation(player, op, pending):
                return False
            pending.append(op)
        return True

    def _sequence_coin_delta(self, state: BackendState, player: int, ops: tuple[Operation, ...]) -> int:
        delta = 0
        tower_count = state.tower_count(player)
        for op in ops:
            if op.op_type == OperationType.BUILD_TOWER:
                delta -= state.build_tower_cost(tower_count)
                tower_count += 1
            elif op.op_type == OperationType.DOWNGRADE_TOWER:
                tower = state.tower_by_id(op.arg0)
                if tower is None:
                    continue
                delta += state.operation_income(player, op, tower_count)
                if tower.tower_type == TowerType.BASIC:
                    tower_count -= 1
            else:
                delta += state.operation_income(player, op)
        return delta

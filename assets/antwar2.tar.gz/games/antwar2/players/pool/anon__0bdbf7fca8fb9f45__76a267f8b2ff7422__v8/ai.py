from __future__ import annotations

from dataclasses import replace
import os
from pathlib import Path

try:
    from common import BaseAgent
except ModuleNotFoundError as exc:
    if exc.name != "common":
        raise
    from AI.common import BaseAgent

from SDK.alphazero import PolicyValueNet, PriorGuidedMCTS, SearchConfig, infer_observation_dim
from SDK.utils.actions import ActionBundle
from SDK.utils.constants import MAX_ACTIONS, OperationType
from SDK.backend.model import Operation
from SDK.backend.state import BackendState
from SDK.utils.turns import DecisionContext

# Optimal tower placement positions per player (mirrored from greedy AI's SITE_LAYOUT)
_SITE_LAYOUT: tuple[tuple[tuple[int, int], ...], tuple[tuple[int, int], ...]] = (
    (  # player 0
        (2, 9), (4, 9), (5, 9), (5, 7), (6, 9), (5, 11), (5, 6),
        (6, 7), (6, 11), (5, 12), (4, 3), (5, 3), (7, 8), (7, 10),
        (4, 15), (5, 15), (4, 2), (6, 4), (7, 5), (8, 7), (8, 11),
        (7, 13), (6, 14), (4, 16), (6, 1), (6, 2), (6, 16), (6, 17),
        (7, 1), (8, 4), (8, 14), (7, 17), (8, 2), (8, 16), (3, 9),
    ),
    (  # player 1
        (16, 9), (14, 9), (13, 9), (13, 7), (12, 9), (13, 11), (12, 6),
        (12, 7), (12, 11), (12, 12), (14, 3), (13, 3), (10, 8), (10, 10),
        (14, 15), (13, 15), (13, 2), (11, 4), (11, 5), (10, 7), (10, 11),
        (11, 13), (11, 14), (13, 16), (12, 1), (11, 2), (11, 16), (12, 17),
        (11, 1), (9, 4), (9, 14), (11, 17), (9, 2), (9, 16), (15, 9),
    ),
)
# Priority order for tower placement (lower rank = higher priority)
_ACTIONABLE_SITES = (1, 2, 4, 10, 16, 11, 14, 23, 15, 17, 18, 22, 21, 3, 6, 7, 5, 8, 9, 19, 12, 13, 20, 24, 25, 28, 27, 26, 31)
# Precomputed: (x, y) -> priority rank (0 = best) for each player
_SITE_PRIORITY: tuple[dict[tuple[int, int], int], dict[tuple[int, int], int]] = tuple(  # type: ignore[assignment]
    {_SITE_LAYOUT[p][site]: rank for rank, site in enumerate(_ACTIONABLE_SITES)}
    for p in range(2)
)


class MCTSAgent(BaseAgent):
    def __init__(
        self,
        iterations: int = 120,
        max_depth: int = 4,
        seed: int | None = None,
        max_actions: int = MAX_ACTIONS,
        model_path: str | os.PathLike[str] | None = None,
        c_puct: float = 1.25,
        prior_mix: float = 0.7,
        value_mix: float = 0.7,
    ) -> None:
        super().__init__(seed=seed, max_actions=max_actions)
        self._base_iterations = iterations
        self._base_max_depth = max_depth
        self._base_c_puct = c_puct
        self._base_prior_mix = prior_mix
        self._base_value_mix = value_mix
        self.model = self._load_model(model_path)
        self._search_seed = seed or 0
        self._search_cache: dict[tuple[int, int, int, int, int, int, int], PriorGuidedMCTS] = {}
        self._base_search_config = SearchConfig(
            iterations=iterations,
            max_depth=max_depth,
            c_puct=c_puct,
            prior_mix=prior_mix,
            value_mix=value_mix,
            seed=self._search_seed,
        )
        self.search = self._search_for_config(self._base_search_config)

    def _candidate_model_paths(self, override: str | os.PathLike[str] | None) -> list[Path]:
        candidates: list[Path] = []
        if override is not None:
            candidates.append(Path(override))
            return candidates
        env_path = os.getenv("AGENT_TRADITION_MCTS_MODEL")
        if env_path:
            candidates.append(Path(env_path))
        module_root = Path(__file__).resolve().parent
        repo_root = module_root.parent
        candidates.extend(
            [
                module_root / "ai_mcts_model.npz",
                repo_root / "checkpoints" / "ai_mcts_latest.npz",
                repo_root / "SDK" / "checkpoints" / "ai_mcts_latest.npz",
            ]
        )
        return candidates

    def _load_model(self, model_path: str | os.PathLike[str] | None) -> PolicyValueNet | None:
        expected_obs_dim = infer_observation_dim(self.feature_extractor, self.catalog.max_actions)
        for candidate in self._candidate_model_paths(model_path):
            if not candidate.exists():
                continue
            try:
                model = PolicyValueNet.from_checkpoint(candidate)
            except (OSError, ValueError, KeyError):
                continue
            if model.action_dim != self.catalog.max_actions:
                continue
            if model.obs_dim != expected_obs_dim:
                continue
            return model
        return None

    def list_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        return self.catalog.build(state, player, context=DecisionContext.for_player(player), rerank=False)

    def _search_for_config(self, config: SearchConfig) -> PriorGuidedMCTS:
        cache_key = (
            int(config.iterations),
            int(config.max_depth),
            int(round(config.c_puct * 1000.0)),
            int(round(config.prior_mix * 1000.0)),
            int(round(config.value_mix * 1000.0)),
            int(config.root_action_limit),
            int(config.child_action_limit),
        )
        cached = self._search_cache.get(cache_key)
        if cached is not None:
            return cached
        search = PriorGuidedMCTS(
            model=self.model,
            search_config=config,
            feature_extractor=self.feature_extractor,
            action_catalog=self.catalog,
        )
        self._search_cache[cache_key] = search
        return search

    @staticmethod
    def _has_operation(bundle: ActionBundle, *op_types: OperationType) -> bool:
        op_values = {int(op_type) for op_type in op_types}
        return any(int(operation.op_type) in op_values for operation in bundle.operations)

    def _site_position_bonus(self, bundle: ActionBundle, player: int, phase: str) -> float:
        priority_map = _SITE_PRIORITY[player]
        best_rank = len(_ACTIONABLE_SITES)
        for op in bundle.operations:
            if int(op.op_type) == int(OperationType.BUILD_TOWER):
                rank = priority_map.get((op.arg0, op.arg1), len(_ACTIONABLE_SITES))
                best_rank = min(best_rank, rank)
        if best_rank >= len(_ACTIONABLE_SITES):
            return 0.0
        # Strong signal: top positions get large bonuses to guide build order
        if best_rank < 3:
            base_bonus = 6.0 - best_rank * 0.5
        elif best_rank < 8:
            base_bonus = 4.5 - (best_rank - 3) * 0.5
        elif best_rank < 15:
            base_bonus = 2.0 - (best_rank - 8) * 0.15
        else:
            base_bonus = max(0.0, 0.8 - (best_rank - 15) * 0.05)
        # Scale bonus by phase importance
        if phase == "finish":
            return base_bonus * 0.25
        return base_bonus

    def _bundle_phase_bonus(
        self,
        bundle: ActionBundle,
        phase: str,
        summary: dict[str, float],
        player: int = 0,
    ) -> float:
        bonus = 0.0
        tags = set(bundle.tags)
        under_pressure = summary["hp_delta"] < -4.0 or summary["enemy_progress"] > summary["my_progress"] + 4.0
        closing = summary["hp_delta"] > 4.0 or summary["my_progress"] > summary["enemy_progress"] + 6.0
        if phase == "growth":
            if "base" in tags:
                bonus += 1.2
            if "build" in tags or "upgrade" in tags:
                bonus += 0.8
            if "tempo" in tags:
                bonus += 0.5
            if "sell" in tags:
                bonus -= 1.0
        elif phase == "defense":
            if "weapon" in tags:
                bonus += 1.2
            if "build" in tags or "upgrade" in tags:
                bonus += 0.6
            if "panic" in tags or "shield" in tags or "emp" in tags:
                bonus += 1.2
            if "tempo" in tags:
                bonus -= 0.5
            if "sell" in tags:
                bonus -= 1.5
        else:
            if "weapon" in tags:
                bonus += 1.0
            if "storm" in tags or "emp" in tags:
                bonus += 1.0
            if "offense" in tags:
                bonus += 0.6
            if "tempo" in tags:
                bonus -= 0.8

        if self._has_operation(bundle, OperationType.USE_DEFLECTOR, OperationType.USE_EMERGENCY_EVASION) and under_pressure:
            bonus += 0.8
        if self._has_operation(bundle, OperationType.USE_LIGHTNING_STORM, OperationType.USE_EMP_BLASTER) and closing:
            bonus += 0.8
        if self._has_operation(bundle, OperationType.DOWNGRADE_TOWER) and "combo" not in tags:
            bonus -= 0.5
        if len(bundle.operations) > 1:
            bonus += 0.2

        # Add mild position bonus for building at optimal tower sites
        has_build_op = self._has_operation(bundle, OperationType.BUILD_TOWER)
        if has_build_op:
            bonus += self._site_position_bonus(bundle, player, phase) * 0.5

        return bonus

    def _bundle_priority(
        self,
        bundle: ActionBundle,
        phase: str,
        summary: dict[str, float],
        player: int = 0,
    ) -> float:
        return float(bundle.score + self._bundle_phase_bonus(bundle, phase, summary, player))

    def _phase_for_state(self, summary: dict[str, float]) -> str:
        if summary["hp_delta"] < -5.0 or summary["enemy_progress"] > summary["my_progress"] + 5.0:
            return "defense"
        if summary["round_ratio"] >= 0.55 or summary["hp_delta"] > 5.0 or summary["my_progress"] > summary["enemy_progress"] + 7.0:
            return "finish"
        return "growth"

    def _filtered_bundles(
        self,
        bundles: list[ActionBundle],
        phase: str,
        summary: dict[str, float],
        player: int = 0,
    ) -> list[ActionBundle]:
        if len(bundles) <= 8:
            return bundles
        ranked = sorted(bundles, key=lambda bundle: self._bundle_priority(bundle, phase, summary, player), reverse=True)
        keep_count = {
            "growth": min(20, len(ranked)),
            "defense": min(28, len(ranked)),
            "finish": min(24, len(ranked)),
        }[phase]
        selected: list[ActionBundle] = []
        seen_keys: set[tuple[tuple[int, int, int], ...]] = set()

        def add_bundle(candidate: ActionBundle) -> None:
            key = tuple((int(op.op_type), op.arg0, op.arg1) for op in candidate.operations)
            if key in seen_keys:
                return
            seen_keys.add(key)
            selected.append(candidate)

        for bundle in ranked[:keep_count]:
            add_bundle(bundle)
        for predicate in (
            lambda bundle: "noop" in bundle.tags,
            lambda bundle: "weapon" in bundle.tags,
            lambda bundle: "base" in bundle.tags,
            lambda bundle: "build" in bundle.tags or "upgrade" in bundle.tags,
        ):
            for bundle in ranked:
                if predicate(bundle):
                    add_bundle(bundle)
                    break
        return selected[: max(keep_count, min(8, len(selected)))] or bundles[:1]

    def _search_config_for_phase(self, phase: str, bundle_count: int) -> tuple[SearchConfig, float]:
        config = replace(self._base_search_config)
        # Conservative time budget to avoid TLE: 60-70 iterations, narrow action limits
        if phase == "growth":
            config.iterations = min(self._base_iterations, 60)
            config.max_depth = 3
            config.root_action_limit = min(bundle_count, 8)
            config.child_action_limit = min(5, bundle_count)
        elif phase == "defense":
            config.iterations = min(self._base_iterations, 70)
            config.max_depth = 3
            config.root_action_limit = min(bundle_count, 10)
            config.child_action_limit = min(6, bundle_count)
        else:
            config.iterations = min(self._base_iterations, 65)
            config.max_depth = 3
            config.root_action_limit = min(bundle_count, 8)
            config.child_action_limit = min(5, bundle_count)
        config.c_puct = self._base_c_puct
        config.prior_mix = self._base_prior_mix
        config.value_mix = self._base_value_mix
        return config, 1e-6

    def _prefer_heuristic_choice(
        self,
        bundles: list[ActionBundle],
        phase: str,
        summary: dict[str, float],
        player: int = 0,
    ) -> bool:
        if len(bundles) <= 1:
            return True
        lead = self._bundle_priority(bundles[0], phase, summary, player)
        runner_up = self._bundle_priority(bundles[1], phase, summary, player)
        # Use heuristic only for extremely obvious choices - trust MCTS for nuanced decisions
        if lead - runner_up >= 4.0:
            return True
        return False

    def _sell_rebuild_bundles(self, state: BackendState, player: int) -> list[ActionBundle]:
        """Generate sell+rebuild combos when direct build is unaffordable but sell+build is."""
        tower_count = state.tower_count(player)
        build_cost_direct = state.build_tower_cost(tower_count)
        if state.coins[player] >= build_cost_direct:
            return []  # Direct build is affordable
        towers = state.towers_of(player)
        if not towers:
            return []

        priority_map = _SITE_PRIORITY[player]
        results: list[ActionBundle] = []

        for tower in towers:
            sell_op = Operation(OperationType.DOWNGRADE_TOWER, tower.tower_id)
            if not state.can_apply_operation(player, sell_op):
                continue
            trial = state.clone()
            if trial.apply_operation_list(player, [sell_op]):
                continue  # Invalid
            new_count = trial.tower_count(player)
            build_cost = trial.build_tower_cost(new_count)
            if trial.coins[player] < build_cost:
                continue

            sold_rank = priority_map.get((tower.x, tower.y), len(_ACTIONABLE_SITES))
            for build_x, build_y in _SITE_LAYOUT[player]:
                build_rank = priority_map.get((build_x, build_y), len(_ACTIONABLE_SITES))
                if build_rank >= sold_rank:
                    continue  # Only rebuild at strictly better positions
                build_op = Operation(OperationType.BUILD_TOWER, build_x, build_y)
                if not trial.can_apply_operation(player, build_op):
                    continue
                site_bonus = self._site_position_bonus(
                    ActionBundle("tmp", (build_op,), 0.0, ("build",)), player, "growth"
                )
                score = site_bonus + (sold_rank - build_rank) * 0.3
                results.append(ActionBundle(
                    name=f"rebuildto@{build_x},{build_y}",
                    operations=(sell_op, build_op),
                    score=score,
                    tags=("combo", "build"),
                ))

        results.sort(key=lambda b: b.score, reverse=True)
        return results[:5]

    def _arc_coverage_gain(self, state: BackendState, bundle: ActionBundle, player: int) -> float:
        """Return improvement in arc coverage (0..1) if bundle is executed. Only for build bundles."""
        if "build" not in bundle.tags:
            return 0.0
        before = self.feature_extractor._base_arc_coverage(state, player)
        if before >= 1.0:
            return 0.0
        cloned = state.clone()
        for op in bundle.operations:
            try:
                cloned.apply_operation(player, op)
            except Exception:
                pass
        after = self.feature_extractor._base_arc_coverage(cloned, player)
        return max(0.0, after - before)

    def _rerank_by_coverage(
        self,
        state: BackendState,
        bundles: list[ActionBundle],
        player: int,
        phase: str,
        summary: dict[str, float],
    ) -> list[ActionBundle]:
            """Rerank candidates with mild arc coverage bonus. Disabled in favor of MCTS search."""
            # Let MCTS make this decision - reranking too aggressively leads to suboptimal choices
            return bundles

    def _danger_filter(
        self,
        bundles: list[ActionBundle],
        summary: dict[str, float],
    ) -> list[ActionBundle]:
        """Mildly filter options when facing immediate threat."""
        hostile = summary.get("hostile_distance", 99.0)
        hp_delta = summary.get("hp_delta", 0.0)
        # Only apply strict filter in critical situations
        if hostile > 3.0 or hp_delta > -5.0:
            return bundles
        critical = []
        for bundle in bundles:
            tags = set(bundle.tags)
            if "weapon" in tags or "panic" in tags or "shield" in tags:
                critical.append(bundle)
        return critical or bundles

    def _lookahead_delta_score(
        self,
        state: BackendState,
        bundle: ActionBundle,
        player: int,
        summary_before: dict[str, float],
    ) -> float:
        """Estimate immediate gain by applying bundle and evaluating the projected state."""
        projected = state.clone()
        try:
            projected.apply_operation_list(player, bundle.operations)
        except Exception:
            return -1e9

        context = DecisionContext.for_player(player)
        after = self.feature_extractor.summarize(projected, player, context=context).named
        score = 0.0
        score += (after.get("hp_delta", 0.0) - summary_before.get("hp_delta", 0.0)) * 0.8
        score += (after.get("my_progress", 0.0) - summary_before.get("my_progress", 0.0)) * 0.5
        score -= (after.get("enemy_progress", 0.0) - summary_before.get("enemy_progress", 0.0)) * 0.5
        score += (after.get("generation_level", 0.0) - summary_before.get("generation_level", 0.0)) * 0.6
        score += (after.get("ant_level", 0.0) - summary_before.get("ant_level", 0.0)) * 0.4

        # Mild danger-window penalty: avoid critical misplays without over-constraining
        hostile_after = after.get("hostile_distance", 99.0)
        hostile_before = summary_before.get("hostile_distance", 99.0)
        if hostile_after < 6.0 and hostile_after <= hostile_before:
            score -= (6.0 - hostile_after) * 1.0

        return score

    def _rerank_by_lookahead(
        self,
        state: BackendState,
        bundles: list[ActionBundle],
        player: int,
        summary: dict[str, float],
    ) -> list[ActionBundle]:
        if len(bundles) <= 2:
            return bundles
        top_n = min(4, len(bundles))
        head = bundles[:top_n]
        tail = bundles[top_n:]
        ranked_head = sorted(
            head,
            key=lambda bundle: (
                self._bundle_priority(bundle, self._phase_for_state(summary), summary, player)
                + self._lookahead_delta_score(state, bundle, player, summary)
            ),
            reverse=True,
        )
        return ranked_head + tail

    def _opening_script_bundle(
        self,
        state: BackendState,
        bundles: list[ActionBundle],
        player: int,
        summary: dict[str, float],
    ) -> ActionBundle | None:
        # Disabled: Let MCTS handle early decisions rather than forcing fixed strategies
        return None

    @staticmethod
    def _fallback_bundle(bundles: list[ActionBundle]) -> ActionBundle:
        if bundles:
            return bundles[0]
        return ActionBundle(name="hold", score=0.0, tags=("noop",))

    def choose_bundle(
        self,
        state: BackendState,
        player: int,
        bundles: list[ActionBundle] | None = None,
    ) -> ActionBundle:
        bundles = bundles or self.list_bundles(state, player)
        if not bundles:
            return ActionBundle(name="hold", score=0.0, tags=("noop",))
        context = DecisionContext.for_player(player)
        summary = self.feature_extractor.summarize(state, player, context=context).named
        phase = self._phase_for_state(summary)
        # Inject sell+rebuild combos when direct build is unaffordable (matches greedy strategy)
        if phase != "finish":
            extra = self._sell_rebuild_bundles(state, player)
            if extra:
                bundles = list(bundles) + extra
        filtered = self._filtered_bundles(bundles, phase, summary, player)
        filtered = sorted(filtered, key=lambda bundle: self._bundle_priority(bundle, phase, summary, player), reverse=True)
        filtered = self._danger_filter(filtered, summary)
        opening_choice = self._opening_script_bundle(state, filtered, player, summary)
        if opening_choice is not None:
            return opening_choice
        # Boost build bundles that fill missing arc angles (same key metric as greedy AI)
        if phase != "finish":
            filtered = self._rerank_by_coverage(state, filtered, player, phase, summary)
            filtered = self._rerank_by_lookahead(state, filtered, player, summary)
        if self._prefer_heuristic_choice(filtered, phase, summary, player):
            return filtered[0]
        config, temperature = self._search_config_for_phase(phase, len(filtered))
        search = self._search_for_config(config)
        try:
            result = search.search(
                state=state,
                player=player,
                bundles=filtered,
                context=context,
                temperature=temperature,
                add_root_noise=False,
            )
        except Exception:
            return self._fallback_bundle(filtered)
        if result.bundle in filtered:
            return result.bundle
        return self._fallback_bundle(filtered)


class StrongMCTSAgent(MCTSAgent):
    def __init__(self, **kwargs) -> None:
        defaults = {
            "iterations": 120,
            "max_depth": 4,
            "c_puct": 1.2,
            "prior_mix": 0.75,
            "value_mix": 0.7,
        }
        defaults.update(kwargs)
        super().__init__(**defaults)


class AI(StrongMCTSAgent):
    pass

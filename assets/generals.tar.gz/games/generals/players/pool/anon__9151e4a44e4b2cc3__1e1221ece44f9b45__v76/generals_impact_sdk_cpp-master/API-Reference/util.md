# util.hpp

本文件定义了所有游戏逻辑的函数。

## 函数列表

### `bool call_generals(GameState &gamestate, int player, std::pair<int, int> location)`

* 描述：在指定位置召唤副将。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：召唤副将的玩家编号。
    * `std::pair<int, int> location`：召唤副将的位置。
* 返回值：如果召唤成功，返回 `true`；否则返回 `false`。

### `float compute_attack(Cell cell, GameState gamestate)`

* 描述：计算指定格子的攻击力。
* 参数：
    * `Cell cell`：目标格子。
    * `GameState gamestate`：游戏状态对象。
* 返回值：攻击力值。

### `float compute_defence(Cell cell, GameState gamestate)`

* 描述：计算指定格子的防御力。
* 参数：
    * `Cell cell`：目标格子。
    * `GameState gamestate`：游戏状态对象。
* 返回值：防御力值。

### `bool outrange(std::pair<int, int> location)`

* 描述：检查位置是否越界。
* 参数：
    * `std::pair<int, int> location`：待检查的位置。
* 返回值：如果越界，返回 `true`；否则返回 `false`。

### `std::pair<int, int> calculate_new_pos(std::pair<int, int> location, Direction direction)`

* 描述：根据移动方向计算新的位置。
* 参数：
    * `std::pair<int, int> location`：当前位置。
    * `Direction direction`：移动方向。
* 返回值：新的位置坐标。

### `bool army_move(const std::pair<int, int> location, GameState &gamestate, int player, Direction direction, int num)`

* 描述：执行军队移动操作。
* 参数：
    * `std::pair<int, int> location`：起始位置。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行移动的玩家编号。
    * `Direction direction`：移动方向。
    * `int num`：移动的兵力数量。
* 返回值：如果移动成功，返回 `true`；否则返回 `false`。

### `bool general_move(const std::pair<int, int> location, GameState &gamestate, int player, const std::pair<int, int> destination)`

* 描述：执行将军移动操作（注：此函数不进行合法性检查）。
* 参数：
    * `std::pair<int, int> location`：将军当前位置。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行移动的玩家编号。
    * `std::pair<int, int> destination`：目标位置。
* 返回值：如果移动成功，返回 `true`；否则返回 `false`。

### `bool check_general_movement(const std::pair<int, int> location, GameState &gamestate, int player, const std::pair<int, int> destination)`

* 描述：检查将军移动的合法性。
* 参数：
    * `std::pair<int, int> location`：将军当前位置。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行移动的玩家编号。
    * `std::pair<int, int> destination`：目标位置。
* 返回值：如果移动合法，返回 `true`；否则返回 `false`。

### `bool army_rush(std::pair<int, int> location, GameState &gamestate, int player, std::pair<int, int> destination)`

* 描述：处理军队突袭技能（注，此函数不检查合法性）。
* 参数：
    * `std::pair<int, int> location`：当前位置。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行技能的玩家编号。
    * `std::pair<int, int> destination`：目标位置。
* 返回值：如果处理成功，返回 `true`；否则返回 `false`。

### `bool check_rush_param(int player, std::pair<int, int> destination, std::pair<int, int> location, GameState &gamestate)`

* 描述：检查军队突袭技能参数的合法性。
* 参数：
    * `int player`：执行技能的玩家编号。
    * `std::pair<int, int> destination`：目标位置。
    * `std::pair<int, int> location`：当前位置。
    * `GameState &gamestate`：游戏状态对象的引用。
* 返回值：如果参数合法，返回 `true`；否则返回 `false`。

### `bool handle_breakthrough(std::pair<int, int> destination, GameState &gamestate)`

* 描述：处理突破技能（注，此函数不检查合法性）。
* 参数：
    * `std::pair<int, int> destination`：目标位置。
    * `GameState &gamestate`：游戏状态对象的引用。
* 返回值：如果处理成功，返回 `true`；否则返回 `false`。

### `bool skill_activate(int player, std::pair<int, int> location, std::pair<int, int> destination, GameState &gamestate, SkillType skillType)`

* 描述：激活将军技能。
* 参数：
    * `int player`：执行技能的玩家编号。
    * `std::pair<int, int> location`：将军当前位置。
    * `std::pair<int, int> destination`：目标位置。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `SkillType skillType`：要激活的技能类型。
* 返回值：如果激活成功，返回 `true`；否则返回 `false`。

### `bool handle_bomb_cell(GameState &gamestate, int x, int y)`

* 描述：处理炸弹对单元格的影响。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int x`：单元格的 x 坐标。
    * `int y`：单元格的 y 坐标。
* 返回值：如果处理成功，返回 `true`；否则返回 `false`。

### `bool handle_bomb(GameState &gamestate, const std::pair<int, int> &location)`

* 描述：处理使用炸弹的操作，触发炸弹效果。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `const std::pair<int, int> &location`：炸弹爆炸的位置。
* 返回值：如果处理成功，返回 `true`；否则返回 `false`。

### `bool bomb(GameState &gamestate, const std::pair<int, int> location, int player)`

* 描述：激活炸弹超级武器。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `const std::pair<int, int> location`：炸弹爆炸的位置。
    * `int player`：执行操作的玩家编号。
* 返回值：如果激活成功，返回 `true`；否则返回 `false`。

### `bool strengthen(GameState &gamestate, std::pair<int, int> location, int player)`

* 描述：激活强化超级武器。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `std::pair<int, int> location`：超级武器激活的位置。
    * `int player`：执行操作的玩家编号。
* 返回值：如果激活成功，返回 `true`；否则返回 `false`。

### `bool tp(GameState &gamestate, const std::pair<int, int> start, const std::pair<int, int> to, int player)`

* 描述：激活超时空传送超级武器，将军队从起始位置传送到目标位置。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `const std::pair<int, int> start`：传送起始位置。
    * `const std::pair<int, int> to`：传送目标位置。
    * `int player`：执行操作的玩家编号。
* 返回值：如果激活成功，返回 `true`；否则返回 `false`。

### `bool timestop(GameState &gamestate, const std::pair<int, int> location, int player)`

* 描述：激活时间停止超级武器，冻结指定位置。
* 参数：
    * `GameState &gamestate`：游戏状态对象的引用。
    * `const std::pair<int, int> location`：冻结位置的坐标。
    * `int player`：执行操作的玩家编号。
* 返回值：如果激活成功，返回 `true`；否则返回 `false`。

### `bool production_up(std::pair<int, int> location, GameState &gamestate, int player)`

* 描述：执行将军生产力升级。
* 参数：
    * `std::pair<int, int> location`：升级将军位置的坐标。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行操作的玩家编号。
* 返回值：如果技术升级成功，返回 `true`；否则返回 `false`。

### `bool defence_up(std::pair<int, int> location, GameState &gamestate, int player)`

* 描述：执行将军防御力升级。
* 参数：
    * `std::pair<int, int> location`：升级将军位置的坐标。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行操作的玩家编号。
* 返回值：如果技术升级成功，返回 `true`；否则返回 `false`。

### `bool movement_up(std::pair<int, int> location, GameState &gamestate, int player)`

* 描述：执行将军移动力升级。
* 参数：
    * `std::pair<int, int> location`：升级将军位置的坐标。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行操作的玩家编号。
* 返回值：如果技术升级成功，返回 `true`；否则返回 `false`。

### `bool tech_update(int tech_type, GameState &gamestate, int player)`

* 描述：科技升级。
* 参数：
    * `int tech_type`：升级的科技类型。
    * `GameState &gamestate`：游戏状态对象的引用。
    * `int player`：执行操作的玩家编号。
* 返回值：如果技术升级成功，返回 `true`；否则返回 `false`。



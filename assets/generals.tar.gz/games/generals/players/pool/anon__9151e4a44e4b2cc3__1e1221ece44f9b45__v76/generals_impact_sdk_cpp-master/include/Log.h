//
// Created by 15010 on 2024/2/13.
//

#ifndef GENERALS_IMPACT_SDK_CPP_MASTER_LOG_H
#define GENERALS_IMPACT_SDK_CPP_MASTER_LOG_H
#include <iostream>
#include <fstream>

// Define a macro to log messages
#define LOG(msg) Logger::log(__FILE__, __LINE__, msg)

class Logger {
public:
    // Function to log messages to a file
    static void log(const char* file, int line, const std::string& message) {
        std::ofstream logfile("log.txt", std::ios_base::app); // Open file in append mode
        if (logfile.is_open()) {
            logfile << "File: " << file << ", Line: " << line << ": " << message << std::endl;
            logfile.close();
        } else {
            std::cerr << "Error opening log file!" << std::endl;
        }
    }
};

#endif //GENERALS_IMPACT_SDK_CPP_MASTER_LOG_H

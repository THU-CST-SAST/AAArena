# protocol.hpp

本文件定义了所有与 judger 通信需要用到的函数。

## 通信函数

### `std::tuple<int, GameState> read_init_map()`

* 描述：读取初始地图及先后手信息。
* 返回值：包含先后手编号和游戏状态的元组。

### `std::vector<Operation> read_enemy_operations()`

* 描述：读取敌方操作列表。
* 返回值：包含敌方操作的操作对象向量。

### `void convert_to_big_endian(const void* src, std::size_t size, void* dest)`

* 描述：将数据从小端序转换为大端序。
* 参数：
    * `const void* src`：源数据指针。
    * `std::size_t size`：数据大小。
    * `void* dest`：目标数据指针。

### `void print_header(int size)`

* 描述：按照评测机要求发送消息长度。
* 参数：
    * `int size`：消息长度。

### `void write_to_judger(const std::string& msg)`

* 描述：向评测机发送一个字符串。
* 参数：
    * `const std::string& msg`：要发送的字符串。

### `void write_our_operation(const std::vector<Operation>& ops)`

* 描述：向评测机发送我方操作列表。
* 参数：
    * `const std::vector<Operation>& ops`：我方操作的操作对象向量。

//
// Created by 15010 on 2024/2/12.
//

#ifndef GENERALS_IMPACT_SDK_CPP_MASTER_MAPWIZARD_H
#define GENERALS_IMPACT_SDK_CPP_MASTER_MAPWIZARD_H

#include <iostream>
#include <queue>
#include <vector>
#include <utility>
#include <climits>
#include "Log.h"

using namespace std;

bool cellAreSame(Cell* a, Cell* b)
{
    return (a->position.first == b->position.first && a->position.second == b->position.second);
}

Cell* translateCell(Cell* a, GameState* gameState)
{
    return &gameState->board[a->position.first][a->position.second];
}

bool cellIsValid(int posx, int posy, GameState* gameState)
{
    return posx >= 0 && posx < Constant::col && posy >= 0 && posy < Constant::row && gameState->board[posx][posy].type == CellType::PLAIN;
}

vector<Cell*> findBorderCells(int player, GameState* gameState)
{
    vector<Cell*> results;
    for (int x = 0; x < Constant::col; ++x)
    {
        for (int y = 0; y < Constant::row; ++y)
        {
            if(gameState->board[x][y].player != player)
                continue;
            bool isBorder = false;
            if(gameState->board[x - 1][y].player != player && gameState->board[x - 1][y].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x + 1][y].player != player && gameState->board[x + 1][y].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x][y - 1].player != player && gameState->board[x][y - 1].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x][y + 1].player != player && gameState->board[x][y + 1].type == CellType::PLAIN)
                isBorder = true;
            if(isBorder)
                results.push_back(&gameState->board[x][y]);
        }
    }
    cerr << "Found " << results.size() << " border cells\n";
    return results;
}

// 一个边界格子五步内可抵达的格子总数
int outpostBFS(int player, Cell* startCell, GameState* gameState)
{
    Cell* _startCell = translateCell(startCell, gameState);
    int count = 0;
    Cell* current = _startCell;
    queue<Cell*> q;
    bool visited[Constant::col][Constant::row] = {false};
    int steps[Constant::col][Constant::row] = {0};
    q.push(current);
    visited[_startCell->position.first][_startCell->position.second] = true;
    steps[_startCell->position.first][_startCell->position.second] = 0;

    while(!q.empty())
    {
        current = q.front();
        q.pop();

        int cx = current->position.first;   int cy = current->position.second;

        int step = steps[cx][cy];
        if(step <= 5)
            if(current->player != player)
                count++;
        if(step == 5)
            continue;

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if ((dx == 0 && dy == 0) || dx * dy != 0)
                    continue;
                int newx = current->position.first + dx;
                int newy = current->position.second + dy;

                if(cellIsValid(newx, newy, gameState) && visited[newx][newy] != true)
                {
                    visited[newx][newy] = true;
                    steps[newx][newy] = steps[cx][cy] + 1;
                    Cell* newCell = &gameState->board[newx][newy];
                    q.push(newCell);
                }
            }
        }
    }
    return count;
}

Cell* findBestOutpost(int player, GameState* gameState)
{
    int maxReachableCells = 0;
    Cell* bestCell = NULL;
    vector<Cell*> borderCells = findBorderCells(player, gameState);
    vector<int> reachableCells(borderCells.size(), 0); // num of cells within reach in 5 steps
    for (int i = 0; i < borderCells.size(); ++i)
    {
        reachableCells[i] = outpostBFS(player, borderCells[i], gameState);
        if(reachableCells[i] > maxReachableCells)
        {
            maxReachableCells = reachableCells[i];
            bestCell = borderCells[i];
        }
    }
    cerr << "Best cell: " << bestCell->position.first << " " << bestCell->position.second << endl;
    return bestCell;
}

vector<pair<int, int>> findShortestPath(int player, Cell *origin, Cell *destination, GameState *gameState, bool v)
{
    vector<pair<int, int>> temp;
    vector<pair<int, int>> result;
    bool endSearch = false;

    Cell* _origin = translateCell(origin, gameState);
    Cell* _destination = translateCell(destination, gameState);

    if(cellAreSame(_origin, _destination))
    {
        if(v)
        cerr << "WARNING: BFS search failed due to overlapping _origin and _destination\n";
        return result;
    }


    Cell* current = _origin;

    bool visited[Constant::col][Constant::row] = {false};
    Cell* trace[Constant::col][Constant::row] = {NULL};

    queue<Cell*> q;
    q.push(current);

    visited[current->position.first][current->position.second] = true;
    trace[current->position.first][current->position.second] = _destination;

    while(!q.empty() && !endSearch)
    {
        current = q.front();
        q.pop();

        int cx = current->position.first;   int cy = current->position.second;

        if(cellAreSame(current, _destination))
        {
            endSearch = true;
            continue;
        }

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if ((dx == 0 && dy == 0) || dx * dy != 0)
                    continue;
                int newx = current->position.first + dx;
                int newy = current->position.second + dy;

                if(cellIsValid(newx, newy, gameState) && visited[newx][newy] != true)
                {
                    visited[newx][newy] = true;
                    LOG("");
                    trace[newx][newy] = current;
                    LOG("");
                    Cell* newCell = &gameState->board[newx][newy];
                    LOG("");
                    if(newCell != _origin && newCell != _destination && newCell->generals != NULL)
                        continue;
                    LOG("");
                    q.push(newCell);
                    LOG("");
                }
            }
        }
    }

    if(!endSearch)
    {
        if(v)
        cerr << "WARNING: BFS search failed due to no valid path\n";
        return result;
    }

    current = _destination;
    while(trace[current->position.first][current->position.second] != _destination)
    {
        temp.push_back(current->position);
        current = trace[current->position.first][current->position.second];
    }
    for (int i = temp.size() - 1; i >= 0; --i)
        result.push_back(temp[i]);
    if(v)
    cerr << "BFS found shortest path with " << temp.size() << "Steps.\n";
    return result;
}

void printPath(vector<pair<int, int>> p)
{
    for (int i = 0; i < p.size(); ++i)
    {
        cerr << p[i].first << " " << p[i].second;
        if(i < p.size() - 1)
            cerr << "->";
    }
    cerr << endl;
}

vector<Cell*> inRangeBFS(int range, Cell* centerCell, GameState* gameState)
{
    Cell* _startCell = translateCell(centerCell, gameState);
    vector<Cell*> result;
    Cell* current = _startCell;
    queue<Cell*> q;
    bool visited[Constant::col][Constant::row] = {false};
    int steps[Constant::col][Constant::row] = {0};
    q.push(current);
    visited[_startCell->position.first][_startCell->position.second] = true;
    steps[_startCell->position.first][_startCell->position.second] = 0;

    while(!q.empty())
    {
        current = q.front();
        q.pop();

        int cx = current->position.first;   int cy = current->position.second;

        int step = steps[cx][cy];
        if(step <= range)
            result.push_back(&gameState->board[cx][cy]);
        if(step == range)
            continue;

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if ((dx == 0 && dy == 0) || dx * dy != 0)
                    continue;
                int newx = current->position.first + dx;
                int newy = current->position.second + dy;

                if(cellIsValid(newx, newy, gameState) && visited[newx][newy] != true)
                {
                    visited[newx][newy] = true;
                    steps[newx][newy] = steps[cx][cy] + 1;
                    Cell* newCell = &gameState->board[newx][newy];
                    q.push(newCell);
                }
            }
        }
    }
    return result;
}

vector<Cell*> findInGeneralRangeCells(Generals* general, GameState* gameState)
{
    vector<Cell*> result;
    int r;
    r = 2;
    auto centerPos = general->position;
    auto centerCell = &gameState->board[centerPos.first][centerPos.second];
    auto temp = inRangeBFS(r, centerCell, gameState);
    for (int i = 0; i < temp.size(); ++i)
    {
        if(temp[i]->player == general->player)
            result.push_back(temp[i]);
    }
    return result;
}

Operation generateMoveOp(pair<int, int> pos1, pair<int, int> pos2, int num)
{
    int dx = pos2.first - pos1.first;
    int dy = pos2.second - pos1.second;
    if(dx == -1)
        return move_army_op(pos1, Direction::LEFT, num);
    if(dx == +1)
        return move_army_op(pos1, Direction::RIGHT, num);
    if(dy == -1)
        return move_army_op(pos1, Direction::DOWN, num);
    if(dy == +1)
        return move_army_op(pos1, Direction::UP, num);
}
#endif //GENERALS_IMPACT_SDK_CPP_MASTER_MAPWIZARD_H

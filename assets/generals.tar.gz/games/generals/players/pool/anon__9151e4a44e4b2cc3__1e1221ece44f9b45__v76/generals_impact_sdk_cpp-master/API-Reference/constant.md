# constant.hpp

## `class Constant`

常量类，内部定义了游戏中所有常量及参数

- `col = 15`
  定义了地图的列数。

- `row = 15`
  定义了地图的行数。

- `Oilwell_production_T1 = 20`
  定义了石油井生产等级1的升级所需金币。

- `Oilwell_production_T2 = 50`
  定义了石油井生产等级2的升级所需金币。

- `Oilwell_production_T3 = 80`
  定义了石油井生产等级3的升级所需金币。

- `Oilwell_defense_T1 = 10`
  定义了石油井防御等级1的升级所需金币。

- `Oilwell_defense_T2 = 15`
  定义了石油井防御等级2的升级所需金币。

- `Oilwell_defense_T3 = 30`
  定义了石油井防御等级3的升级所需金币。

- `lieutenant_new_recruit = 50`
  定义了征召副将所需的金币。

- `lieutenant_production_T1 = 80`
  定义了将军产量等级1的升级所需金币。

- `lieutenant_production_T2 = 100`
  定义了将军产量等级2的升级所需金币。

- `lieutenant_defense_T1 = 40`
  定义了将军防御等级1的升级所需金币。

- `lieutenant_defense_T2 = 120`
  定义了将军防御等级2的升级所需金币。

- `general_movement_T1 = 20`
  定义了将军行动力等级1的升级所需金币。

- `general_movement_T2 = 40`
  定义了将军行动力等级2的升级所需金币。

- `tactical_strike = 30`
  定义了突袭所需的金币。

- `breakthrough = 10`
  定义了击破所需的金币。

- `leadership = 50`
  定义了统率所需的金币。

- `fortification = 50`
  定义了坚守所需的金币。

- `weakening = 50`
  定义了弱化所需的金币。

- `army_movement_T1 = 150`
  定义了军队行动力等级1的升级所需金币。

- `army_movement_T2 = 250`
  定义了军队行动力等级2的升级所需金币。

- `swamp_immunity = 100`
  定义了免疫沼泽的科技升级所需金币。

- `sand_immunity = 150`
  定义了免疫流沙的科技升级所需金币。

- `unlock_super_weapon = 300`
  定义了解锁超级武器所需金币。

- `sand_percent = 0.15`
  定义了沙地的百分比。

- `swamp_percent = 0.05`
  定义了沼泽的百分比。

- 

#include "include/ai_template.hpp"
#include "include/MapWizard.h"
#include "include/util2.h"

using namespace std;

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate)
{
    cerr << "ROUND " << gamestate.round << endl;

    std::vector<Operation> ops;
    GameState gameState = gamestate;

    cerr << "EVAL: " << Evaluator::evaluate_1(&gameState) << endl;

    if(gameState.round <= 50)
        cmd1->reBrief("raid general", &gameState);
    else
        cmd1->reBrief("raid oil", &gameState);
    cmd1->think();
    ops = cmd1->submitWarPlan();
    if(gameState.coin[my_seat] >= 20)
        ops.push_back(update_generals_op(my_seat, QualityType::MOBILITY));

    return ops;
}

int main()
{
    run_ai(simple_ai);
}
//
// Created by 15010 on 2024/2/13.
//

#ifndef GENERALS_IMPACT_SDK_CPP_MASTER_EVALUATOR_H
#define GENERALS_IMPACT_SDK_CPP_MASTER_EVALUATOR_H

#include "gamestate.hpp"
#include "operation.hpp"
using namespace std;

static float unitValue = 1.0f;
static float landValue = 1.0f;
static float terrainPenalty = 100.0f;
static float generalValue = 10.0f;

class Evaluator
{
public:
    static float evaluate_1 (GameState* gameState)
    {
        float evalPlayer[2] = {0.0f};
        float eval;
        auto board = gameState->board;
        for (int x = 0; x < Constant::col; ++x)
            for (int y = 0; y < Constant::row; ++y)
            {
                auto cell = &board[x][y];

                if(cell->player != 0 && cell->player != 1)
                    continue;
                evalPlayer[cell->player] += landValue;
                evalPlayer[cell->player] += unitValue * cell->army;
                if(cell->type != CellType::PLAIN)
                    evalPlayer[cell->player] -= terrainPenalty;
                if(cell->generals != nullptr)
                    evalPlayer[cell->player] += generalValue;
//                cerr << evalPlayer[0] << evalPlayer[1] << endl;
            }
        return evalPlayer[0] - evalPlayer[1];
    }
};

#endif //GENERALS_IMPACT_SDK_CPP_MASTER_EVALUATOR_H

//
// Created by 15010 on 2024/2/13.
//

#ifndef GENERALS_IMPACT_SDK_CPP_MASTER_UTIL2_H
#define GENERALS_IMPACT_SDK_CPP_MASTER_UTIL2_H
#include "Evaluator.h"
#include "Commander.h"
using namespace std;

Generals* findGeneralByID(int general_id, GameState* gameState)
{
    for (Generals &gen: gameState->generals)
        if (gen.id == general_id)
            return &gen;
    return nullptr;
}

pair<int, int> getGeneralPos(GameState* gameState, int generalID)
{
    return gameState->generals[generalID].position;
}

Cell* getGeneralCell(GameState* gameState, int generalID)
{
    auto pos = getGeneralPos(gameState, generalID);
    return &gameState->board[pos.first][pos.second];
}

vector<Cell*> findOilfields(GameState* gameState)
{
    vector<Cell*> result;
    for (int x = 0; x < Constant::col; ++x)
        for (int y = 0; y < Constant::row; ++y)
        {
            auto cell = &gameState->board[x][y];
            if(cell->generals != nullptr && dynamic_cast<OilWell *>(cell->generals))
                result.push_back(cell);
        }
    return result;
}
vector<Cell*> findSubGenerals(GameState* gameState)
{
    vector<Cell*> result;
    for (int x = 0; x < Constant::col; ++x)
        for (int y = 0; y < Constant::row; ++y)
        {
            auto cell = &gameState->board[x][y];
            if(cell->generals != nullptr && dynamic_cast<SubGenerals *>(cell->generals))
                result.push_back(cell);
        }
    return result;
}

Cell* findNearestOilfield(int player, GameState *gameState, Cell *start, bool ignoreCaptured)
{
    Cell* _start = translateCell(start, gameState);
    auto temp = findOilfields(gameState);
    int maxDist = 100;
    Cell* result = nullptr;
    for (int i = 0; i < temp.size(); ++i)
    {
        if(ignoreCaptured && temp[i]->player == player)
            continue;
        int dist;
        auto path = findShortestPath(player, _start, temp[i], gameState, false);
        dist = path.size();
        if(dist == 0)
            continue;
        if(dist < maxDist)
        {
            maxDist = dist;
            result = temp[i];
        }
    }
    return result;
}

Cell* findNearestSubGeneral(int player, GameState *gameState, Cell *start, bool ignoreCaptured)
{
    Cell* _start = translateCell(start, gameState);
    auto temp = findSubGenerals(gameState);
    int maxDist = 100;
    Cell* result = nullptr;
    for (int i = 0; i < temp.size(); ++i)
    {
        if(ignoreCaptured && temp[i]->player == player)
            continue;
        int dist;
        auto path = findShortestPath(player, _start, temp[i], gameState, false);
        dist = path.size();
        if(dist == 0)
            continue;
        if(dist < maxDist)
        {
            maxDist = dist;
            result = temp[i];
        }
    }
    return result;
}
#endif //GENERALS_IMPACT_SDK_CPP_MASTER_UTIL2_H

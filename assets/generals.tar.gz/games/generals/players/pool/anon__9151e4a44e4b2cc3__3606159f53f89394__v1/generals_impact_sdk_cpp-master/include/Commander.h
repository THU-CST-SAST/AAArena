//
// Created by 15010 on 2024/2/13.
//

#ifndef GENERALS_IMPACT_SDK_CPP_MASTER_COMMANDER_H
#define GENERALS_IMPACT_SDK_CPP_MASTER_COMMANDER_H
#include "MapWizard.h"
#include <iostream>
#include "util2.h"
#include "Evaluator.h"

using namespace std;

struct MoveNode
{
    int index;
    int parentIndex;
    int layer;
    Operation operation;
    GameState gameState;
    float eval;
    bool isEnd;
};

vector<MoveNode> findValidMoves(int player, Generals* general, GameState gameState);

class Commander
{
public:
    int playerID;
    string name;
    string mode;
    Generals* general;
    GameState* gameState;
    vector<Operation> warPlan;

    void init(int playerID, string name, string mode, Generals* general, GameState* gameState);
    void reBrief(string mode, GameState* gameState);
    void think();
    vector<Operation> submitWarPlan();

private:
    void raid(string goal)
    {
        auto currentPos = getGeneralPos(gameState, general->id);
        auto currentCell = getGeneralCell(gameState, general->id);
        Cell* target;
        if(goal == "oil")
            target = findNearestOilfield(general->id, gameState, currentCell, true);
        else if(goal == "general")
            target = findNearestSubGeneral(general->id, gameState, currentCell, true);
        cerr << target->position.first << " " << target->position.second << endl;
        if(target == nullptr)
            return;

        auto path = findShortestPath(general->id, currentCell, target, gameState, true);

        printPath(path);
        Operation op1, op2;
        if(currentCell->army >= 2 && !path.empty())
        {
            op1 = generateMoveOp(currentPos, path[0], 1);
            op2 = move_generals_op(general->id, path[0]);
        }
        warPlan.push_back(op1);
        warPlan.push_back(op2);
        return;
    }
    void raid(Cell* target)
    {
        auto currentPos = getGeneralPos(gameState, general->id);
        auto currentCell = getGeneralCell(gameState, general->id);
        if(target == nullptr)
            return;

        auto path = findShortestPath(general->id, currentCell, target, gameState, true);

        printPath(path);
        Operation op1, op2;
        if(currentCell->army >= 2 && !path.empty())
        {
            op1 = generateMoveOp(currentPos, path[0], 1);
            op2 = move_generals_op(general->id, path[0]);
        }
        warPlan.push_back(op1);
        warPlan.push_back(op2);
        return;
    }
    void expand()
    {
        auto _gameState = *gameState;
        auto validMoves =  findValidMoves(general->player, general, _gameState);
        if(validMoves.size() <= 1)
            return;

        auto bestMove = validMoves[1];
        float bestEval = validMoves[1].eval;

        for (int i = 1; i < validMoves.size(); ++i)
        {
            if(playerID == 0)
            {
                if(validMoves[i].eval > bestEval)
                {
                    bestEval = validMoves[i].eval;
                    bestMove = validMoves[i];
                }
            }
            else if(playerID == 1)
            {
                if(validMoves[i].eval < bestEval)
                {
                    bestEval = validMoves[i].eval;
                    bestMove = validMoves[i];
                }
            }
        }
        vector<Operation> temp;
        MoveNode* current = &bestMove;
        while(current->layer != 0)
        {
            temp.push_back(current->operation);
            current = &validMoves[current->parentIndex];
        }
        for (int i = temp.size() - 1; i >= 0 ; --i)
        {
            warPlan.push_back(temp[i]);
        }

        auto bestOutpost = findBestOutpost(playerID, gameState);
        auto currentCell = getGeneralCell(gameState, general->id);
        auto path = findShortestPath(playerID, currentCell, bestOutpost, gameState, true);
        Operation op2, op3, op4;
        cerr << general->mobility_level <<" MSDDS\n";
        if(!path.empty())
        {
            op2 = move_generals_op(general->id, path[0]);
            warPlan.push_back(op2);
        }
        if(path.size() >= 2)
        {
            op3 = move_generals_op(general->id, path[1]);
            warPlan.push_back(op3);
        }
        if(path.size() >= 3)
        {
            op4 = move_generals_op(general->id, path[2]);
            warPlan.push_back(op4);
        }
        return;
    }
};
void Commander::init(int playerID, string name, std::string mode, Generals *general, GameState *gameState)
{
    this->playerID = playerID; this->name = name;  this->mode = mode;  this->general = general;  this->gameState = gameState;
    this->warPlan.clear();
}
void Commander::reBrief(std::string mode, GameState *gameState)
{
    this->mode = mode;
    this->gameState = gameState;
    this->warPlan.clear();
}
void Commander::think()
{
    istringstream iss(mode);
    vector<string> modes;
    string tmp;
    while(iss >> tmp)
        modes.push_back(tmp);

    if(modes[0] == "raid")
    {
        if(modes[1] == "oil")
            raid("oil");
        else if(modes[1] == "general")
            raid("general");
    }
    if(modes[0] == "expand")
        expand();
    return;
}
vector<Operation> Commander::submitWarPlan()
{
    auto temp = warPlan;
    warPlan.clear();
    return temp;
}

vector<MoveNode> findValidMoves(int player, Generals* general, GameState gameState)
{
    vector<MoveNode> nodes;
    MoveNode rootNode = {0, 0, 0, do_nothing_op(), gameState, Evaluator::evaluate_1(&gameState),true}; // root node of tree
    nodes.push_back(rootNode);
    int searchLayer = 1;
    int searchCnt = 0;
    int nodeCnt = 0;
    int numValidOpsCurrLayer;
    bool quitSearch = false;

    while(!quitSearch)
    {
        numValidOpsCurrLayer = 0;
        for (int i = 0; i < nodes.size(); ++i)
        {
            if(nodes[i].layer != searchLayer - 1)
                continue;
            if(nodes[i].gameState.rest_move_step[player] == 0)
                continue;
            // 开始搜索子节点
            // 搜索移动军队操作
            auto eligibleCells = findInGeneralRangeCells(general, &nodes[i].gameState);
            vector<Cell*> cells;
            for (int j = 0; j < eligibleCells.size(); ++j)
                if(eligibleCells[j]->player == general->player)
                    cells.push_back(eligibleCells[j]);

            vector<pair<int, int>> positions;

            for (int j = 0; j < cells.size(); ++j)
            {
                positions.push_back({cells[j]->position.first, cells[j]->position.second});
            }

            for (int j = 0; j < positions.size(); ++j)
            {
                int x = positions[j].first;
                int y = positions[j].second;
                // 如果某一处有多于两个部队的话，那么可以移动
                if(nodes[i].gameState.board[x][y].army >= 2)
                {
                    int num = nodes[i].gameState.board[x][y].army - 1;
                    // 尝试这一处的各种方向
                    for (int dir = 0; dir < 4; ++dir)
                    {
                        searchCnt ++ ;
                        GameState nextLevelGs = nodes[i].gameState;
                        //如果走不通的话，直接换方向
                        if (army_move(positions[j], nextLevelGs, player, Direction(dir), num) == 0)
                            continue;
                        else
                        {
                            MoveNode child = {++nodeCnt, nodes[i].index, searchLayer,
                                              move_army_op(positions[j], Direction(dir), num), nextLevelGs, Evaluator::evaluate_1(&nextLevelGs),
                                              true};
                            nodes.push_back(child);
                            nodes[i].isEnd = false;
                            numValidOpsCurrLayer++;
                        }
                    }
                }
            }
        }
        if(numValidOpsCurrLayer == 0)
            quitSearch = true;
        searchLayer++;
    }
    cerr << "SearchCount: " << searchCnt << endl;
    cerr << "NodeCount: " << nodes.size() << endl;
    cerr << endl;
    return nodes;
}

#endif //GENERALS_IMPACT_SDK_CPP_MASTER_COMMANDER_H
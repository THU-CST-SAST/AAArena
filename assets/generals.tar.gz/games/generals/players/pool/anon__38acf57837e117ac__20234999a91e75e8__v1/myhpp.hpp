#pragma once

#include "controller.hpp"

namespace Constant
{
    const int dx[4] = {-1, 1, 0, 0};
    const int dy[4] = {0, 0, -1, 1};
}

inline bool check_cell(int x, int y)
{
    return x >= 0 && x < Constant::row && y >= 0 && y < Constant::col;
}

inline bool approachable_cell(int x, int y, int my_seat, GameState const & state)
{
    CellType type = state.board[x][y].type;
    int player = state.board[x][y].player;
    bool type_ok (type != CellType::PLAIN || state.tech_level[my_seat][(int)type]);
    bool player_ok (player == -1 || player == my_seat);
    return type_ok;
}

inline std::pair<int, int> neighbour(std::pair<int, int> pos, int direction)
{
    if (direction >= 0 && direction <= 3)
        return make_pair(pos.first + Constant::dx[direction], pos.second + Constant::dy[direction]);
    return pos;
}
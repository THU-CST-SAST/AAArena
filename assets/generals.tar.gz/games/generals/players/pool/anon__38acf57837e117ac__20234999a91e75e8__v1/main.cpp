#include "ai_template.hpp"

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    return ops;
}
int main(){
    run_ai(simple_ai);
}
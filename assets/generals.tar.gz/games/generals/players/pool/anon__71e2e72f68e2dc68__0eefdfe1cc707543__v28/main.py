import random
from generals_impact_game.controller import run_ai
from generals_impact_game.gamestate import *
from generals_impact_game.computation import *
def get_direction_2(round, x, y, my_seat, state):
    # 获取敌方将军的位置
    enemy_general_pos = state.generals[1 - my_seat].position
    enemy_x, enemy_y = enemy_general_pos

    # 计算当前与敌方将军的相对位置
    dx = enemy_x - x
    dy = enemy_y - y

    # 计算当前周围的空位数量
    zero_count = 0
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        new_x, new_y = x + dx, y + dy
        if 0 <= new_x <= 14 and 0 <= new_y <= 14 and state.board[new_x][new_y].type == 0:
            zero_count += 1

    # 如果四周只有一个方向有0，向0走
    if zero_count == 1:
        directions = {(-1, 0): 1, (1, 0): 2, (0, -1): 3, (0, 1): 4}
        direction = directions[(dx, dy)]
        return direction

    # 如果有两个以上方向有0，选择使dx或dy减少的方向移动
    elif zero_count >= 2:
        if dx < 0:
            return 1 if x > 0 and state.board[x - 1][y].type == 0 else 2
        elif dx > 0:
            return 2 if x < 14 and state.board[x + 1][y].type == 0 else 1
        elif dy < 0:
            return 3 if y > 0 and state.board[x][y - 1].type == 0 else 4
        elif dy > 0:
            return 4 if y < 14 and state.board[x][y + 1].type == 0 else 3

    # 如果没有0，则向沙漠走
    else:
        if y > 0 and state.board[x][y - 1].type == 2:
            return 3
        elif y < 14 and state.board[x][y + 1].type == 2:
            return 4
        elif x > 0 and state.board[x - 1][y].type == 2:
            return 1
        elif x < 14 and state.board[x + 1][y].type == 2:
            return 2
        else:
            return 0

def get_direction(round, x, y, my_seat, state):
    dx = state.generals[1 - my_seat].position[0] - x
    dy = state.generals[1 - my_seat].position[1] - y

    zero_count = 0
    if x - 1 >= 0 and state.board[x - 1][y].type == 0:
        zero_count += 1
    if x + 1 <= 14 and state.board[x + 1][y].type == 0:
        zero_count += 1
    if y - 1 >= 0 and state.board[x][y - 1].type == 0:
        zero_count += 1
    if y + 1 <= 14 and state.board[x][y + 1].type == 0:
        zero_count += 1

    # 如果四周只有一个方向有0，向0走
    if zero_count == 1:
        if x - 1 >= 0 and state.board[x - 1][y].type == 0:
            return 1
        elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
            return 2
        elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
            return 3
        elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
            return 4
        
    # 如果有两个以上方向有0，选择dx或dy能减小的方向移动
    elif zero_count >= 2:
        i = random.randint(0,1)
        if i == 0:
            if dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
        else:
            if dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2

    # 如果没有0，则向沙漠走
    else:
        if dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 2:
            return 3
        elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 2:
            return 4
        elif dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 2:
            return 1
        elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 2:
            return 2
        else:
            return 0

def recent_dir(q1, q2, w1, w2) ->int:
    if q2 - w2 == 1:return 3 
    if q2 - w2 == -1:return 4
    if q1 - w1 == 1:return 1
    if q1 - w1 == -1:return 2
def test_if_attack(state,my_seat,x,y,dir):
    global armi 
    armi = 0
    if state.board[x][y].army == 1:
        return False
    elif dir == 3 and y > 0:
        if ( state.board[x][y-1].army > (state.board[x][y].army - 2)):
            return False
        else:
            armi = state.board[x][y].army - 1 - state.board[x][y-1].army 
            return True
            
    elif dir == 4 and y < 14:
        if ( state.board[x][y+1].army > (state.board[x][y].army - 2)):
            return False
        else:
            armi = state.board[x][y].army - 1 - state.board[x][y+1].army 
            return True
    elif dir == 1 and x > 0:
        if ( state.board[x-1][y].army > (state.board[x][y].army - 2)):
            return False
        else:
            armi = state.board[x][y].army - 1 - state.board[x-1][y].army 
            return True
    elif dir == 2 and x < 14 and state.board[x+1][y].player != my_seat:
        if ( state.board[x+1][y].army > (state.board[x][y].army - 2)):
            return False
        else:
            armi = state.board[x][y].army - 1 - state.board[x+1][y].army 
            return True
    return False
def example_ai(round, my_seat, state) -> list[list[int]]:
    operations = []
    global x
    # x= state.generals[my_seat].position[0]
    global y 
    global x_1
    global y_1
    # y= state.generals[my_seat].position[1]
    for gen in state.generals:
        if gen.player == 1 - my_seat:
            x_1 = gen.position[0]
            y_1 = gen.position[1]
        if gen.player == my_seat:
            x = gen.position[0]
            y = gen.position[1]
    # 仅在第一轮进行一次升级
    if round == 1:
        operations.append([3, state.generals[my_seat].id, 3])
        operations.append([3,state.generals[my_seat].id,1])
        return operations

    s = abs(x - x_1) + abs(y - y_1)
    money = state.coin[my_seat]
    if s <= 5 and money >= 15:
        defence = compute_defence(state.board[x_1][y_1],state) * state.board[x_1][y_1].army
        attack = compute_attack(state.board[x_1][y_1],state) * state.board[x_1][y_1].army
        if(s <= 2):
            defence = 0
            attack = 0
            attack_my = compute_attack(state.board[x][y], state) * (state.board[x][y].army - 1)
            if(s == 1):
                defence = compute_defence(state.board[x_1][y_1],state) * state.board[x_1][y_1].army
                attack = compute_attack(state.board[x_1][y_1],state) * state.board[x_1][y_1].army
            else:
                if abs(x - x_1) == 2:
                    x_2 = x + (x_1 - x)/2
                    y_2 = y
                elif abs(y - y_1) == 2:
                    x_2 = x
                    y_2 = y + (y_1 - y)/2
                else:
                    x_2 = x_1
                    y_2 = y_1
                attack_my = compute_attack(state.board[x][y],state) * (state.board[x][y].army - 2)
                defence = compute_defence(state.board[x_1][y_1],state) * state.board[x_1][y_1].army + state.board[x_2][y_2].army
                attack = compute_attack(state.board[x_1][y_1],state) * state.board[x_1][y_1].army +  state.board[x_2][y_2].army

            if(money < 30):
                operations.append([4,state.generals[my_seat].id,2,x_1,y_1])
                state.board[x_1][y_1].army -= 15
                state.coin[my_seat] -= 15
            elif(money < 45):    
                if(defence < attack_my * 1.5):
                    operations.append([4,state.generals[my_seat].id,3])
                    attack_my *= 1.5
                elif(defence - 15 < attack):
                    operations.append([4,state.generals[my_seat].id,2,x_1,y_1])
                    state.board[x_1][y_1].army -= 15
                    state.coin[my_seat] -= 15
                else:
                    operations.append([4,state.generals[my_seat].id,4])
            elif(money < 60):
                operations.append([4,state.generals[my_seat].id,2,x_1,y_1])
                state.board[x_1][y_1].army -= 15
                state.coin[my_seat] -= 15
                defence -= 15
                if(defence < attack_my * 1.5):
                    operations.append([4,state.generals[my_seat].id,3])
                    attack_my *= 1.5
                elif(defence - 15 < attack):
                    operations.append([4,state.generals[my_seat].id,2,x_1,y_1])
                    state.board[x_1][y_1].army -= 15
                else:
                    operations.append([4,state.generals[my_seat].id,4])
            else:
                operations.append([4,state.generals[my_seat].id,5])
                defence *= 0.75
                attack *= 0.75
                if(defence < attack_my * 1.5):
                    operations.append([4,state.generals[my_seat].id,3])
                    attack_my *= 1.5
                elif(defence - 15 < attack):
                    operations.append([4,state.generals[my_seat].id,2,x_1,y_1])
                    state.board[x_1][y_1].army -= 15
                else:
                    operations.append([4,state.generals[my_seat].id,4])

            if(s == 1):
                if defence < attack_my:
                    dir = recent_dir(x,y,x_1,y_1)
                    operations.append([1,x,y,dir,state.board[x][y].army - 1])
                    return operations
            else:
                if defence < attack_my:
                    dir = recent_dir(x,y,x_2,y_2)
                    operations.append([1,x,y,dir,state.board[x][y].army - 1])
                    state.board[x_2][y_2].army = state.board[x][y].army - 1 - state.board[x_2][y_2].army     
                    state.board[x_2][y_2].player = my_seat
                    dir = recent_dir(x_2,y_2,x_1,y_1)
                    operations.append([1,x_2,y_2,dir,state.board[x_2][y_2].army - 1]) 
                    return operations
        else:
            if money >= 20 :
                operations.append([4,state.generals[my_seat].id,1,abs(x-x_1)*3/(x-x_1),abs(y-y_1)*3/(y-y_1)])
                money -= 20
            if money >= 30 :
                operations.append([4,state.generals[my_seat].id,5])
                money -= 30
            if money >= 30:
                operations.append([4,state.generals[my_seat].id,4])

    if s > 2:    
        dir = get_direction(round,x,y,my_seat,state)       
        if test_if_attack(state,my_seat,x,y,dir) == True:
            operations.append([1,x,y,dir,state.board[x][y].army - 1])
            state.board[x][y].army == 1
            moved = state.board[x][y].army - 1
            if dir == 3:y-=1 
            if dir == 4:y+=1 
            if dir == 1:x-=1 
            if dir == 2:x+=1
            if(state.board[x][y].player == my_seat):
                state.board[x][y].army += moved
            else:
                state.board[x][y].army = armi
            state.board[x][y].player = my_seat
        
            dir_2 = get_direction(round,x,y,my_seat,state)
            
            if test_if_attack(state,my_seat,x,y,dir_2) == True:
                operations.append([1,x,y,dir_2,state.board[x][y].army - 1])
                state.board[x][y].army == 1
                moved = state.board[x][y].army - 1
                if dir_2 == 3:y-=1 
                if dir_2 == 4:y+=1 
                if dir_2 == 1:x-=1 
                if dir_2 == 2:x+=1
                if(state.board[x][y].player == my_seat):
                    state.board[x][y].army += moved
                else:
                    state.board[x][y].army = armi
                state.board[x][y].player = my_seat
            if state.board[x][y].player == my_seat:
                operations.append([2,state.generals[my_seat].id,x,y])
    else:
        dir = get_direction_2(round,x,y,my_seat,state)       
        if test_if_attack(state,my_seat,x,y,dir) == True:
            operations.append([1,x,y,dir,state.board[x][y].army - 1])
            state.board[x][y].army == 1
            moved = state.board[x][y].army - 1
            if dir == 3:y-=1 
            if dir == 4:y+=1 
            if dir == 1:x-=1 
            if dir == 2:x+=1
            if(state.board[x][y].player == my_seat):
                state.board[x][y].army += moved
            else:
                state.board[x][y].army = armi
            state.board[x][y].player = my_seat
        
            dir_2 = get_direction_2(round,x,y,my_seat,state)
            
            if test_if_attack(state,my_seat,x,y,dir_2) == True:
                operations.append([1,x,y,dir_2,state.board[x][y].army - 1])
                moved = state.board[x][y].army - 1
                if dir_2 == 3:y-=1 
                if dir_2 == 4:y+=1 
                if dir_2 == 1:x-=1 
                if dir_2 == 2:x+=1
                if(state.board[x][y].player == my_seat):
                    state.board[x][y].army += moved
                else:
                    state.board[x][y].army = armi
                state.board[x][y].player = my_seat
            if state.board[x][y].player == my_seat:
                operations.append([2,state.generals[my_seat].id,x,y])

    return operations


run_ai(example_ai)
#include "include/ai_template.hpp"

/*std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    if(gamestate.round==1)ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::DOWN,1));
    return ops;
}*/

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    if (gamestate.round<4){
        ops.push_back(update_generals_op(0,QualityType::PRODUCTION));
        ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::UP,2));    
    }
    if (gamestate.round<8 && gamestate.round>=4){
        
        ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::LEFT,2));    
    } 
    if (gamestate.round<12 && gamestate.round>=8){
        
        ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::DOWN,2));    
    }
    if (gamestate.round<16 && gamestate.round>=12){
        
        ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::RIGHT,2));    
    }
    
    
    return ops;
}


int main(){
    run_ai(simple_ai);
}
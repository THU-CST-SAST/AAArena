# Generals Impact C++ SDK 使用文档

本文档为第二十八届智能体大赛 Generals Impact 官方 C++ SDK 的说明文档，包含文件结构及样例AI编写指南。

## 一·、文件结构

打开SDK包我们可以看到 `include/`, `main.cpp`, 及`Makefile`

首先说明 `include/`:

- `constant.hpp`: 包含类`Constant`, 内容即为游戏中所有常数。

- `operation.hpp`: 包含操作类，及封装好的操作函数。

- `gamestate.hpp`: 包含游戏将军类、棋盘格子类、其他辅助类，以及最重要的——游戏状态类`Gamestate`。

- `protocol.hpp`: 包含 sdk 与 saiblo judger 通信的所有函数。

- `util.hpp`: 包含 sdk 内置逻辑的所有函数（如，军队移动、使用超级武器等等）。

- `controller.hpp`: 包含游戏流程控制器类 `GameController`。

- `ai_template.hpp`: 提供了一个基于`GameController`的函数，允许选手不关注游戏流程只关心决策本身。

然后是`main.cpp`, 一个使用了`ai_template.hpp`模板编写的简单 AI 样例。

最后是`Makefile`，选手可以将自己的程序放入 sdk 包根目录下，再执行 `make {your_source_file_name}`即可编译，注意文件名不要加后缀。



## 二、 AI 模板编写示范

让我们打开`main.cpp`, 从头开始编写一个只专注于决策的~~弱智~~ AI

1. 包含`ai_template.hpp`头文件
   
   ```c++
   #include "include/ai_template.hpp"
   ```
   
   

2. `ai_template.hpp`中实际上只有一个函数`run_ai`, 其接受的参数为：
   
   ```c++
   void run_ai(std::function<std::vector<Operation>(int, const GameState &)> ai)
   ```
   
   这里的 `std::function<std::vector<Operation>(int, const GameState &)>` 是一个返回类型为`std::vector<Operation>`，参数类型为`int, const GameState &`的函数。也就是说，我们要传给`run_ai`实际上是一个这样的函数，它的功能是：结合先后手信息 `int my_seat` 和游戏状态信息 `const GameState & gamestate` ，得到一个操作序列 `std::vector<Operation>`。
   这样一来，我们只需要编写一个决策函数并作为参数传递给`run_ai`函数即可。
   
   

3. 让我们看一下`main.cpp`中是怎样编写这样的决策函数的
   
   ```c++
   std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
       std::vector<Operation> ops;
       if(gamestate.round==4)ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::DOWN,1));
       return ops;
   }
   ```
   
   不难读懂，这个决策函数的意思就是在第四回合的时候，把我方主将所在格子的军队向下移动一格。
   其中，`move_army_op`函数来自`operation.hpp`，即上文提到的方便选手使用的一系列操作函数之一。这些操作函数的返回值为可以直接使用的`Operation`类对象，选手在编写自己的决策函数时可以参考 API Reference 文档使用其他操作。
   
   

## 三、 进阶版：直接使用 GameController

如果你希望自行进行模拟游戏流程（~~何苦呢~~），我们可以通过对`run_ai`的代码解读来了解`GameController`类的具体功能

```c++
void run_ai(std::function<std::vector<Operation>(int, const GameState &)> ai)
{
    GameController c;
    c.init();
    while (true)
    {
        if (c.my_seat == 0) // 先手
        {
            // AI 给出操作
            std::vector<Operation> ops = ai(c.my_seat, c.game_state);
            // 尝试执行操作
            c.try_apply_our_ops(ops);
            // 向judger发送操作
            c.finish_and_send_our_ops();
            // 读取并应用敌方操作
            c.read_and_apply_enemy_ops();
            //更新回合
            c.update_round_info();
        }
        else // 后手
        {
            // 读取并应用敌方操作
            c.read_and_apply_enemy_ops();
            // AI 给出操作
            std::vector<Operation> ops = ai(c.my_seat, c.game_state);
            // 尝试执行操作
            c.try_apply_our_ops(ops);
            // 向judger发送操作
            c.finish_and_send_our_ops();
            //更新回合
            c.update_round_info();
        }
    }
}
```

游戏开始前， AI 需要从评测机获取本局游戏的初始地图及先后手信息，通过`GameController::init`函数实现

接下来，以先手为例，每回合游戏需要：

1. AI 依据现在游戏局面及先后手信息给出本回合操作（调用决策函数）。

2. 尝试执行这些操作（`GameController:: try_apply_our_ops`函数），注意在尝试执行时，`GameController`会自行检查这些操作的合法性，一旦发现不合法操作会终止后续所有操作。

3. 向 judger 发送这些操作（`GameController:: finish_and_send_our_ops`函数），这时可以保证这些操作是合法的。

4. 读取敌方操作并依此修改游戏状态（`GameController:: read_and_apply_enemy_ops`函数）。

5. 最后，在回合结束后，更新游戏状态（`GameController:: update_round_info`函数），如增兵、技能CD减少等。

后手操作也是类似的。

`GameController`中也提供了一些如`execute_single_command` 这样其他的函数，选手可以自行调用。



## 四、 大道至简版

如果你连`GameController`都不想用（why??），只需要跟 judger 通信，那么可以看看`protocol.hpp`，其中重点函数如下：

- `read_init_map()`: 读取初始地图及先后手。

- `read_enemy_operations()`: 读取敌方操作。

- `write_our_operation(const std::vector<Operation>& ops)`: 把我们的操作发给 judger 。



## 五、 最后

祝各位游戏愉快~

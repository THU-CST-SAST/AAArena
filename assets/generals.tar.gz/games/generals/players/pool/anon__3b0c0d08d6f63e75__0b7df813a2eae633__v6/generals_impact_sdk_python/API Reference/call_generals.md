### `call_generals(state: GameState, player: int, position: list[int, int]) -> bool`

在指定位置征兆将军的函数。

#### 参数

- `state`: `GameState` 当前的游戏状态。
- `player`: `int` 当前进行操作的玩家。
- `position`: `list[int, int]` 一个包含两个整数的列表，表示当前操作的格子的坐标。

#### 返回值

- `bool`：如果征召成功，返回`True`；否则返回`False`。

# `movement.py`

本文件用于实现将军和军队的移动逻辑。


### `outrange(location: list[int, int])` -> `bool`

判断给定的位置是否越界。

#### 参数

- `location`: `list[int, int]` 一个包含两个整数的列表，表示位置。

#### 返回

- 如果位置越界，返回`True`；否则返回`False`。

### `calculate_new_pos(location: list[int, int], direction: Direction)` -> `tuple[int, int]`

计算给定位置和方向的新位置。

#### 参数

- `location`:`list[int, int]` 一个包含两个整数的列表，表示当前位置。
- `direction`:`Direction` 移动方向，是`Direction`枚举的一个实例。

#### 返回

- 一个包含两个整数的元组，表示新的位置。如果新的位置越界，返回`(-1, -1)`。


### `army_move(location: list[int, int], gamestate: GameState, player: int, direction: Direction, num: int)` -> `bool`

移动指定数量的军队。

#### 参数

- `location`:`list[int, int]` 一个包含两个整数的列表，表示位置。
- `gamestate`: `GameState` 表示游戏状态。
- `player`: `int` 表示玩家编号（0或1）。
- `direction`:`Direction`  移动方向，是`Direction`枚举的一个实例。
- `num`: `int` 表示要移动的军队数量。

#### 返回

- 如果移动成功，返回`True`；否则返回`False`。

### `general_move(location: list[int, int], gamestate: GameState, player: int, destination: list[int, int])` -> `bool`

移动将军到指定的目的地。

#### 参数

- `location`:`list[int, int]` 一个包含两个整数的列表，表示将军所在的位置。
- `gamestate`: `GameState`的一个实例，表示游戏状态。
- `player`: `int`，表示玩家编号（0或1）。
- `destination`:`list[int, int]` 一个包含两个整数的列表，表示目的地。

#### 返回

- 如果移动成功，返回`True`；否则返回`False`。


### `check_general_movement(location: list[int, int], gamestate: GameState, player: int, destination: list[int, int])` -> `bool`

检查将军的移动是否合法。

#### 参数

- `location`:`list[int, int]` 一个包含两个整数的列表，表示将军所在的位置。
- `gamestate`: `GameState`的一个实例，表示游戏状态。
- `player`: `int` 整数，表示玩家编号（0或1）。
- `destination`:`list[int, int]`一个包含两个整数的列表，表示目的地。

#### 返回

- 如果移动合法，返回`True`；否则返回`False`。



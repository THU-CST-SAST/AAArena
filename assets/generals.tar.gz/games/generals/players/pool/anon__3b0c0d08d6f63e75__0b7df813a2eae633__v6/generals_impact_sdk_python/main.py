import random
from generals_impact_game.controller import run_ai
from generals_impact_game.gamestate import *
from generals_impact_game.computation import *
import random
import sys
def get_direction(round, x, y, my_seat, state):
    dx = state.generals[1 - my_seat].position[0] - x
    dy = state.generals[1 - my_seat].position[1] - y

    zero_count = 0
    if x - 1 >= 0 and state.board[x - 1][y].type == 0:
        zero_count += 1
    if x + 1 <= 14 and state.board[x + 1][y].type == 0:
        zero_count += 1
    if y - 1 >= 0 and state.board[x][y - 1].type == 0:
        zero_count += 1
    if y + 1 <= 14 and state.board[x][y + 1].type == 0:
        zero_count += 1

    # 如果四周只有一个方向有0，向0走
    if zero_count == 1:
        if x - 1 >= 0 and state.board[x - 1][y].type == 0:
            return 1
        elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
            return 2
        elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
            return 3
        elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
            return 4
        
    # 如果有两个以上方向有0，选择dx或dy能减小的方向移动
    elif zero_count >= 2:
        i = random.randint(0,1)
        if i == 0:
            if dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
        else:
            if dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2
            elif y - 1 >= 0 and state.board[x][y - 1].type == 0:
                return 3
            elif y + 1 <= 14 and state.board[x][y + 1].type == 0:
                return 4
            elif x - 1 >= 0 and state.board[x - 1][y].type == 0:
                return 1
            elif x + 1 <= 14 and state.board[x + 1][y].type == 0:
                return 2

    else:
        if dy < 0 and y - 1 >= 0 and state.board[x][y - 1].type == 2:
            return 3
        elif dy > 0 and y + 1 <= 14 and state.board[x][y + 1].type == 2:
            return 4
        elif dx < 0 and x - 1 >= 0 and state.board[x - 1][y].type == 2:
            return 1
        elif dx > 0 and x + 1 <= 14 and state.board[x + 1][y].type == 2:
            return 2
        else:
            return 0

def move_general(state, my_seat, x, y, dir):
    # 移动将军的位置
    if dir == 3:
        y -= 1
    elif dir == 4:
        y += 1
    elif dir == 1:
        x -= 1
    elif dir == 2:
        x += 1
def test_if_attack(state,my_seat,x,y,dir):
    if dir == 3 and y > 0 and state.board[x][y-1].player != my_seat:
        if compute_defence(state.board[x][y-1],state) * state.board[x][y-1].army <= state.board[x][y].army - 1:
            return True
    elif dir == 4 and y < 14 and state.board[x][y+1].player != my_seat:
        if compute_defence(state.board[x][y+1],state) * state.board[x][y+1].army <= state.board[x][y].army - 1:
            return True
    elif dir == 1 and x > 0 and state.board[x - 1][y].player != my_seat:
        if compute_defence(state.board[x-1][y],state) * state.board[x-1][y].army <= state.board[x][y].army - 1:
            return True
    elif dir == 2 and x < 14 and state.board[x+1][y].player != my_seat:
        if compute_defence(state.board[x+1][y],state) * state.board[x+1][y].army <= state.board[x][y].army - 1:
            return True
    return False

def example_ai(round, my_seat, state) -> list[list[int]]:

    operations = []
    global x
    x= state.generals[my_seat].position[0]
    global y 
    y= state.generals[my_seat].position[1]
    # 仅在第一轮进行一次升级
    if round == 1:
        operations.append([3, state.generals[my_seat].id, 3])
        operations.append([3,state.generals[my_seat].id,1])
        return operations

    if get_direction(round,x, y,my_seat,state) != 0:
        dir = get_direction(round,x, y,my_seat,state)
    else:
        dir = random.randint(1, 4)
    
    if abs(state.generals[1-my_seat].position[0] - state.generals[my_seat].position[0]) <=2 or abs(state.generals[1-my_seat].position[1] - state.generals[my_seat].position[1]) <=2:
        operations.append([4, state.generals[my_seat].id, 2, state.generals[1-my_seat].position[0], state.generals[1-my_seat].position[1]])
        x_1 = state.generals[1-my_seat].position[0]
        y_1 = state.generals[1-my_seat].position[1]
        if compute_defence(state.board[x_1][y_1],state) * state.board[x_1][y_1].army <= state.board[x][y].army - 1:
            operations.append([1,x,y,dir,state.board[x][y].army - 1])
            if dir == 3:y-=1 
            if dir == 4:y+=1 
            if dir == 1:x-=1 
            if dir == 2:x+=1 
            dir_3 = get_direction(round,x,y,my_seat,state)
            operations.append([1,x,y,dir_3,state.board[x][y].army -1 ])
            return operations
        else:
            operations.append([2,state.generals[my_seat].id,x-(2 if dir == 1 else -2),y])
            operations.append([2,state.generals[my_seat].id,x,y-(2 if dir == 4 else -2)])
            return operations
            
    if test_if_attack(state,my_seat,x,y,dir):
        print("1", file=sys.stderr, flush=True)
        operations.append([1,x,y,dir,state.board[x][y].army - 1])
        if dir == 3:y-=1 
        if dir == 4:y+=1 
        if dir == 1:x-=1 
        if dir == 2:x+=1 
    
    dir_2 = get_direction(round,x,y,my_seat,state)
    
    if test_if_attack(state,my_seat,x,y,dir_2):
        print("2", file=sys.stderr, flush=True)
        operations.append([1,x,y,dir_2,state.board[x][y].army - 1])
        if dir_2 == 3:y-=1 
        if dir_2 == 4:y+=1 
        if dir_2 == 1:x-=1 
        if dir_2 == 2:x+=1 
    
    operations.append([2,state.generals[my_seat].id,x,y])
    print(operations, file=sys.stderr, flush=True)
    return operations

run_ai(example_ai)
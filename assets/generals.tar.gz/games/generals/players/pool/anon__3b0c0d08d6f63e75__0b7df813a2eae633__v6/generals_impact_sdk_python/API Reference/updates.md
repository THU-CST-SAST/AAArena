# `updates.py`

这个文件包含了一些用于升级游戏状态的函数。

### `upgrade_produce_level(generals: Generals, player_coins: int, produce_costs: dict) -> int`

升级将军的产量等级的函数。

#### 参数

- `generals`: `Generals` 当前的将军。
- `player_coins`: `int` 玩家当前的金币数量。
- `produce_costs`: `dict` 产量等级的升级成本。

#### 返回值

- `int`：如果升级成功，返回升级所需的金币数量；否则返回0。

### `production_up(location: list[int, int], gamestate: GameState, player: int) -> bool`

升级指定位置的将军的产量等级的函数。

#### 参数

- `location`: `list[int, int]` 一个包含两个整数的列表，表示当前操作的格子的坐标。
- `gamestate`: `GameState` 当前的游戏状态。
- `player`: `int` 当前的玩家。

#### 返回值

- `bool`：如果升级成功，返回`True`；否则返回`False`。

### `upgrade_defense(generals: Generals, player_coins: int, defense_costs: dict) -> int`

升级将军的防御等级的函数。

#### 参数

- `generals`: `Generals` 当前的将军。
- `player_coins`: `int` 玩家当前的金币数量。
- `defense_costs`: `dict` 防御等级的升级成本。

#### 返回值

- `int`：如果升级成功，返回升级所需的金币数量；否则返回0。

### `defence_up(location: list[int, int], gamestate: GameState, player: int) -> bool`

升级指定位置的将军的防御等级的函数。

#### 参数

- `location`: `list[int, int]` 一个包含两个整数的列表，表示当前操作的格子的坐标。
- `gamestate`: `GameState` 当前的游戏状态。
- `player`: `int` 当前的玩家。

#### 返回值

- `bool`：如果升级成功，返回`True`；否则返回`False`。

### `upgrade_mobility(generals: Generals, player_coins: int, mobility_costs: dict) -> int`

升级将军的行动力等级的函数。

#### 参数

- `generals`: `Generals` 当前的将军。
- `player_coins`: `int` 玩家当前的金币数量。
- `mobility_costs`: `dict` 行动力等级的升级成本。

#### 返回值

- `int`：如果升级成功，返回升级所需的金币数量；否则返回0。

### `movement_up(location: list[int, int], gamestate: GameState, player: int) -> bool`

升级指定位置的将军的行动力等级的函数。

#### 参数

- `location`: `list[int, int]` 一个包含两个整数的列表，表示当前操作的格子的坐标。
- `gamestate`: `GameState` 当前的游戏状态。
- `player`: `int` 当前的玩家。

#### 返回值

- `bool`：如果升级成功，返回`True`；否则返回`False`。

### `tech_update(tech_type: int, gamestate: GameState, player: int) -> bool`

进行科技升级的函数。

#### 参数

- `tech_type`: `int` 需要升级的科技的类型。
- `gamestate`: `GameState` 当前的游戏状态。
- `player`: `int` 当前的玩家。

#### 返回值

- `bool`：如果升级成功，返回`True`；否则返回`False`。
# `superweapons.py`

这个文件包含了处理超级武器的函数。

## 函数

### `handle_bomb(gamestate: GameState, location: list[int, int]) -> bool`

处理核弹爆炸的函数。

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `location`:`list[int, int]` 一个包含两个整数的列表，表示当前放置炸弹的格子的坐标。

#### 返回值

- `bool`：如果处理成功，返回`True`；否则返回`False`。

### `handle_bomb_cell(gamestate: GameState, x: int, y: int) -> bool`

处理被核弹影响的单元格的函数。

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `x`:`int` 当前处理的单元格的x坐标。
- `y`:`int` 当前处理的单元格的y坐标。

#### 返回值

- `bool`：如果使用成功，返回`True`；否则返回`False`。

### `bomb(gamestate: GameState, location: list[int, int], player: int) -> bool`

使用核弹

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `location`:`list[int, int]` 一个包含两个整数的列表，表示当前位置。
- `player`:`int` 玩家编号，可以是0或1。

#### 返回值

- `bool`：如果使用成功，返回`True`；否则返回`False`。

### `strengthen(gamestate: GameState, location: list[int, int], player: int) -> bool`

使用攻击强化

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `location`:`list[int, int]` 一个包含两个整数的列表，表示当前位置。
- `player`:`int` 玩家编号，可以是0或1。

#### 返回值

- `bool`：如果使用成功，返回`True`；否则返回`False`。

### `tp(gamestate: GameState, start: list[int, int], to: list[int, int], player: int) -> bool`

使用超时空传送

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `start`:`list[int, int]` 一个包含两个整数的列表，表示传送开始位置。
- `to`:`list[int, int]` 一个包含两个整数的列表，表示传送目标位置。

#### 返回值

- `bool`：如果使用成功，返回`True`；否则返回`False`。

### `timestop(gamestate: GameState, location: list[int, int], player: int) -> bool`

使用时间停止

#### 参数

- `gamestate`:`GameState` 当前的游戏状态。
- `location`:`list[int, int]` 一个包含两个整数的列表，表示当前位置。
- `player`:`int` 玩家编号，可以是0或1。

#### 返回值

- `bool`：如果使用成功，返回`True`；否则返回`False`。

# `gamecontroller.py`

## `class GameController`
游戏控制器。可以帮助选手处理通讯与数据维护有关的繁琐操作。

### `init(self) -> None`
初始化游戏的函数。

### `read_enemy_ops(self) -> list[Operation]`
读取敌方操作列表的函数。

### `apply_enemy_ops(self, ops: list[Operation]) -> bool`
应用敌方操作的函数。

#### 参数
- `ops`: `list[Operation]` 敌方的操作列表。
#### 返回值
- `bool`：如果敌方操作合法，返回`True`；否则返回`False`。


### `read_and_apply_enemy_ops(self) -> bool`
读取并应用敌方操作的函数。

### `try_apply_our_op(self, op: Operation) -> bool`
尝试执行我方操作的函数。

#### 参数
- `op`: `Operation` 我方的操作。

#### 返回值
- `bool`：如果我方操作合法，返回`True`；否则返回`False`。

### `try_apply_our_ops(self, ops: list[Operation]) -> bool`
尝试执行我方若干操作的函数。

#### 参数
- `ops`: `list[Operation]` 我方的操作列表。

#### 返回值
- `bool`：如果我方所有操作都合法，返回`True`；否则在第一个非法操作处返回`False`。

### `finish_and_send_our_ops(self) -> None`
结束我方操作回合，将操作列表打包发送并清空的函数。

## `run_ai(ai_func: Callable[[int, GameState], list[list[int]]]) -> None`
执行AI的函数。将你的决策过程封装在一个函数中，我们帮你处理各类通讯相关的繁琐事项。

#### 参数
- `ai_func`: `Callable[[int, GameState], list[list[int]]]` 你的决策函数，第一个参数为`my_seat`，第二个参数为当前的`gamestate.GameState`对象。

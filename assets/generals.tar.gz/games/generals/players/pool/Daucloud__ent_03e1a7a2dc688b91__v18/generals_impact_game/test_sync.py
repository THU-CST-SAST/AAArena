from generals_impact_game import constant
from generals_impact_game.gamestate import GameState


def show_state(state: GameState):
    def print_color(color, end, message, background="0"):
        print("\033[" + color + ";" + background + "m" + message + "\033[0m", end=end)

    print("   ", end="")
    for i in range(15):
        print(str(format(i, "03d")), end="")
    print("")
    for i in range(constant.row):
        print(str(format(i, "03d")), end="")
        for j in range(constant.col):
            if state.board[i][j].player != -1:
                if state.board[i][j].player == 0:
                    print_color(
                        "0", "", str(format(state.board[i][j].army, "03d")), "41"
                    )

                elif state.board[i][j].player == 1:
                    print_color(
                        "0", "", str(format(state.board[i][j].army, "03d")), "44"
                    )
                else:
                    print("xxx", end="")
            else:
                if int(state.board[i][j].type) == 0:
                    print_color(
                        "0", "", str(format(state.board[i][j].army, "03d")), "47"
                    )
                elif int(state.board[i][j].type) == 1:
                    print_color(
                        "0", "", str(format(state.board[i][j].army, "03d")), "42"
                    )
                elif int(state.board[i][j].type) == 2:
                    print_color(
                        "0", "", str(format(state.board[i][j].army, "03d")), "43"
                    )
                else:
                    print(int(state.board[i][j].type), end=" ")
        print("")
    print("round:", state.round)
    print("coins:", state.coin)
    print("super weapons:", state.active_super_weapon)
    print("super weapon cds:", state.super_weapon_cd)
    print("tech level:", state.tech_level)
    for gen in state.generals:
        print(
            "|generals id: ",
            gen.id,
            "\t|type: ",
            type(gen).__name__,
            "\t|position: ",
            gen.position,
            "\tplayer:",
            gen.player,
        )

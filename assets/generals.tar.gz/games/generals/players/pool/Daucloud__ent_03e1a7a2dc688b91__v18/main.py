from generals_impact_game.controller import *
from generals_impact_game.gamestate import *

max_depth=20
moves=[]
bornPos=[-1,-1]
ifSearchBorn=True
oilList=[]
genList=[]

def manDis(p1,p2):
    return abs(p1[0]-p2[0])+abs(p1[1]-p2[1])

def calNearestOilDis(my_seat:int,point,state:GameState):
    ans=40
    for gen in state.genreals:
        if gen.mobility_level==0 and gen.player!=my_seat:
            ans=min(ans,manDis(point,gen.position))
    return ans

def evaluation(my_seat:int,state:GameState):
    val=0
    val-=calNearestOilDis(my_seat,state.generals[my_seat],state)
    for gen in state.generals:
        if gen.player==my_seat:
            if gen.mobility_level==0:
                val+=5+3*gen.produce_level+gen.defense_level
            else:
                val+=4+2*gen.produce_level+gen.defense_level+gen.mobility_level
    return val

def actions(state:GameState):
    """
    当前状态可能采取的动作。暂时只考虑主将
    """
    list=set()

dx=[-1,1,0,0]
dy=[0,0,-1,1]

class Node:
    def __init__(self,pos,parent,action) -> None:
        self.pos=pos
        self.parent=parent
        self.action=action

def calPos(pos,dir):
    if dir==1:
        return [pos[0]-1,pos[1]]
    elif dir==2:
        return [pos[0]+1,pos[1]]
    elif dir==3:
        return [pos[0],pos[1]-1]
    elif dir==4:
        return [pos[0],pos[1]+1]

visited=set()


def dfs(start,end,state:GameState):
    global mySeat
    frontier=[]
    init=Node(start,None,None)
    frontier.append(init)
    explored=set()
    while len(frontier)>0:
        foo=frontier.pop()
        explored.add(tuple(foo.pos))
        news=[]
        for i in range(1,5):
            next=Node(calPos(foo.pos,i),foo,i)
            if next.pos==end:
                actions=[i]
                while foo.parent!=None:
                    actions.append(foo.action)
                    foo=foo.parent
                actions.reverse()
                return actions
            else:
                if 0<=next.pos[0]<=14 and 0<=next.pos[1]<=14 and tuple(next.pos) not in explored and state.board[next.pos[0]][next.pos[1]].generals==None and (state.board[next.pos[0]][next.pos[1]].type!=CellType(2) or state.tech_level[mySeat][1]!=0):
                    news.append(next)
            news.sort(key=lambda x:-manDis(end,x.pos))
            frontier+=news
    return None

def sortOil(pos,my_seat:int,state:GameState):
    ans=[]
    for gen in state.generals:
        if gen.mobility_level==0 and state.board[gen.position[0]][gen.position[1]].type!=CellType(2) and gen.player!=my_seat:
            ans.append(gen)
    ans.sort(key=lambda x:manDis(x.position,pos))
    return ans

def upgradable(state:GameState,gen:Generals,attr:int,my_seat:int):
    if isinstance(gen,MainGenerals):
        if attr==1:
            if gen.produce_level==1:
                return state.coin[my_seat]>=20
            elif gen.produce_level==2:
                return state.coin[my_seat]>=40
        elif attr==2:
            if gen.defense_level==1:
                return state.coin[my_seat]>=20
            elif gen.defense_level==2:
                return state.coin[my_seat]>=50
        elif attr==3:
            if gen.mobility_level==1:
                return state.coin[my_seat]>=10
            elif gen.mobility_level==2:
                return state.coin[my_seat]>=20
    elif isinstance(gen,SubGenerals):
        if attr==1:
            if gen.produce_level==1:
                return state.coin[my_seat]>=40
            elif gen.produce_level==2:
                return state.coin[my_seat]>=80
        elif attr==2:
            if gen.defense_level==1:
                return state.coin[my_seat]>=40
            elif gen.defense_level==2:
                return state.coin[my_seat]>=100
        elif attr==3:
            if gen.mobility_level==1:
                return state.coin[my_seat]>=20
            elif gen.mobility_level==2:
                return state.coin[my_seat]>=40
    elif isinstance(gen,Oilwell):
        if attr==1:
            if gen.produce_level==1:
                return state.coin[my_seat]>=10
            elif gen.produce_level==2:
                return state.coin[my_seat]>=25
            elif gen.produce_level==3:
                return state.coin[my_seat]>=35
        elif attr==2:
            if gen.defense_level==1:
                return state.coin[my_seat]>=10
            elif gen.defense_level==2:
                return state.coin[my_seat]>=15
            elif gen.defense_level==3:
                return state.coin[my_seat]>=30
    return False


def silly_ai(round:int,my_seat:int,state:GameState)->list[list[int]]:
    global moves,ifSearchBorn,bornPos
    ops=[]
    myMajor:Generals
    for gen in state.generals:
        if gen.player is my_seat and gen.mobility_level!=0:
            myMajor=gen
    for gen in state.generals:
        if gen.player==my_seat:
            if upgradable(state,gen,1,my_seat):
                ops.append([3,gen.id,1])
            elif upgradable(state,gen,3,my_seat):
                ops.append([3,gen.id,3])
            elif upgradable(state,gen,2,my_seat):
                ops.append([3,gen.id,2])
    if round==1:
        bornPos=myMajor.position
    if len(moves)==0 and ifSearchBorn:
        objs=[]
        for gen in state.generals:
            if gen.player!=my_seat and state.board[gen.position[0]][gen.position[1]].type!=CellType(2):
                objs.append(gen)
        objs.sort(key=lambda x:manDis(x.position,myMajor.position))
        actions=None
        for obj in objs:
            actions=dfs(myMajor.position,obj.position,state)
            if actions!=None:
                curPos=myMajor.position
                i=0
                for action in actions:
                    moves.append([1,curPos[0],curPos[1],action,state.board[myMajor.position[0]][myMajor.position[1]].army-i-1])
                    curPos=calPos(curPos,action)
                    moves.append([2,myMajor.id,curPos[0],curPos[1]])
                    i+=1
                break
        if actions==None:
            ifSearchBorn=False
    step=min(state.rest_move_step[my_seat],myMajor.rest_move,len(moves))
    ops+=moves[:step*2]
    moves=moves[step*2:]
    return ops

#run_ai(silly_ai)
def armyDif(state:GameState,myGen:Generals,tarGen:Generals):
    return state.board[myGen.position[0]][myGen.position[1]].army-state.board[tarGen.position[0]][tarGen.position[1]].army*tarGen.defense_level

mySeat=-1

oppoDir={1:2,2:1,3:4,4:3}

def Luo_AI(round:int,my_seat:int,state:GameState)->list[list[int]]:
    global moves,oilList,genList,mySeat
    if round==1:
        mySeat=my_seat
    ops=[]
    oilList.clear()
    genList.clear()
    oilForSearch=[]
    myMajor=state.generals[my_seat]
    target=state.generals[my_seat^1]
    oilNum=3 #只占领三个油田
    genNum=2 #只要两个副将
    dif=armyDif(state,myMajor,target)
    if  manDis(myMajor.position,target.position)<10 and dif>0:
        moves=[]
        myCoin=state.coin[my_seat]
        if manDis(myMajor.position,target.position)<5:
            if myCoin>=15 and myMajor.skills_cd[1]==0:
                ops.append([4,myMajor.id,2,target.position[0],target.position[1]])
                myCoin-=15
            if myCoin>=30 and myMajor.skills_cd[2]==0:
                ops.append([4,myMajor.id,3])
                myCoin-=30
            if myCoin>=20 and myMajor.skills_cd[0]==0:
                for i in range(1,5):
                    pos=calPos(target.position,i)
                    if state.board[pos[0]][pos[1]].generals==None and (state.board[pos[0]][pos[1]].type!=CellType(2) or state.tech_level[my_seat][1]!=0) and dif+20-state.board[pos[0]][pos[1]].army>0:
                        ops.append([4,myMajor.id,1,pos[0],pos[1]])
                myCoin-=20
        actions=dfs(myMajor.position,target.position,state)
        if actions!=None:
            step=min(myMajor.rest_move,state.rest_move_step[my_seat],len(actions))
            curPos=myMajor.position
            for i in range(step):
                ops.append([1,curPos[0],curPos[1],actions[i],state.board[myMajor.position[0]][myMajor.position[1]].army-i-1])
                curPos=calPos(curPos,actions[i])
                ops.append([2,myMajor.id,curPos[0],curPos[1]])
    elif dif<=0 and manDis(myMajor.position,target.position)<5:
        myCoin=state.coin[my_seat]
        if myCoin>=30 and myMajor.skills_cd[4]==0:
            ops.append([4,myMajor,5])
            myCoin-=30
        if myCoin>=30 and myMajor.skills_cd[3]==0:
            ops.append([4,myMajor,4])
            myCoin-=30
    else:
        if state.coin[my_seat]>=250 and state.super_weapon_unlocked==False:#解除超武
            ops.append([5,4])
        if state.super_weapon_cd[my_seat]==0:#使用核弹
            ops.append([6,1,target.position[0],target.position[1]])
        if state.coin[my_seat]>=100 and state.tech_level[my_seat][1]==0:
            ops.append([5,2]) #免除沼泽
            oilNum+=2 #免除了沼泽再多占两个油田
        if state.coin[my_seat]>=75 and state.tech_level[my_seat][2]==0:
            ops.append([5,3]) #免除流沙
        for gen in state.generals[2:]: #获取自己的油田和副将列表
            if gen.player==my_seat:
                if gen.mobility_level==0:
                    oilList.append(gen)
                else:
                    genList.append(gen)
            elif gen.mobility_level==0 and (state.board[gen.position[0]][gen.position[1]].type!=CellType(2) or state.tech_level[my_seat][1]!=0):
                oilForSearch.append(gen) 
        oilForSearch.sort(key=lambda x:manDis(x.position,myMajor.position))
        if upgradable(state,myMajor,1,my_seat):
            ops.append([3,myMajor.id,1])
        if upgradable(state,myMajor,3,my_seat):
            ops.append([3,myMajor.id,3])
        if upgradable(state,myMajor,2,my_seat):
            ops.append([3,myMajor.id,2])
        for oil in oilList:
            if upgradable(state,oil,1,my_seat):
                ops.append([3,oil.id,1])
            if upgradable(state,oil,2,my_seat):
                ops.append([3,oil.id,2])
        if len(moves)==0:
            actions=None
            for oil in oilForSearch:
                actions=dfs(myMajor.position,oil.position,state)
                if actions!=None:
                    curPos=myMajor.position
                    nextPos=curPos
                    i=0
                    for action in actions:
                        nextPos=calPos(curPos,actions[i])
                        if state.board[nextPos[0]][nextPos[1]].generals!=None:
                            moves.append([1,curPos[0],curPos[1],action,int(min(state.board[myMajor.position[0]][myMajor.position[1]].army-i-1,state.board[nextPos[0]][nextPos[1]].army*state.board[nextPos[0]][nextPos[1]].generals.defense_level+1))])
                        else:
                            moves.append([1,curPos[0],curPos[1],action,state.board[myMajor.position[0]][myMajor.position[1]].army-i-1])
                        moves.append([2,myMajor.id,nextPos[0],nextPos[1]])
                        curPos=nextPos
                        i+=1
                    break
            '''
            else:#资源储备完毕，开始铺地
                cells=[]
                for i in range(15):
                    for j in range(15):
                        if state.board[i][j].player!=my_seat and state.board[i][j].generals==None and (state.board[i][j].type!=CellType(2) or state.tech_level[my_seat][1]!=0):
                            cells.append([i,j])
                cells.sort(key=lambda x:manDis(x,myMajor.position))
                for cell in cells:
                    actions=dfs(myMajor.position,cell,state)
                    if actions!=None:
                        curPos=myMajor.position
                        i=0
                        for action in actions:
                            moves.append([1,curPos[0],curPos[1],action,state.board[myMajor.position[0]][myMajor.position[1]].army-i-1])
                            curPos=calPos(curPos,action)
                            moves.append([2,myMajor.id,curPos[0],curPos[1]])
                            i+=1
                        break
            '''
        step=min(state.rest_move_step[my_seat]*2,myMajor.rest_move*2,len(moves))
        ops+=moves[:step]
        moves=moves[step:]
    print("ops: ",ops,file=sys.stderr)
    return ops

run_ai(Luo_AI)
import random

from generals_impact_game.controller import *


def example_ai(round: int, me: int, game: GameController, state: GameState):
    if round == 1:
        # Init, do some operations
        for gen in state.generals:
            if gen.player == me and isinstance(gen, MainGenerals):
                # Upgrade prod army
                assert game.try_apply_our_op(update_general_production_level_op(gen.id))
        return
    gen_pos = [None, None]  # Main Generals positions
    for gen in state.generals:
        if isinstance(gen, MainGenerals):
            gen_pos[gen.player] = gen.position
    game.try_apply_our_op(move_army_op(gen_pos[me], Direction.LEFT, 1))
    return


game = GameController()
game.init()
round = 1
while True:
    if game.my_seat == 0:
        ops = example_ai(round, 0, game, game.game_state)
        #game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()
        game.read_and_apply_enemy_ops()
    else:
        game.read_and_apply_enemy_ops()
        ops = example_ai(round, 1, game, game.game_state)
        #game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()
    round += 1

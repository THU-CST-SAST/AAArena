# `computation.py`

本文件中的函数负责计算攻击敌方格子时的attack和defence参数。



### `compute_attack(cell: Cell, gamestate: GameState) -> float`

计算攻击力。这个函数会根据格子上的将军以及被激活的效果，计算出cell的攻击力，并返回一个float类型的值。

#### 参数

- `cell: Cell`：要计算攻击力的格子。
- `gamestate: GameState`：当前的游戏状态。

#### 返回值

- `float`：计算出的攻击力。


### `compute_defence(cell: Cell, gamestate: GameState) -> float`

计算防御力。这个函数会根据格子上的将军以及被激活的效果，计算出cell的防御力，并返回一个float类型的值。

#### 参数

- `cell: Cell`：要计算防御力的格子。
- `gamestate: GameState`：当前的游戏状态。

#### 返回值

- `float`：计算出的防御力。

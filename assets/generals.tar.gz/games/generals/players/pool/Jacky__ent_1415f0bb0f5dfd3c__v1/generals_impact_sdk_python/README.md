# python sdk使用文档
## 使用 run_ai

```python
from gamestate import GameState
from game_controller import *


def example_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    """一个AI示例"""
    if round == 2:
        return [move_army_op(state.generals[my_seat].position, Direction.DOWN, 1)]
    return []

run_ai(example_ai)
```
上面的合法且完整的AI代码做的事情主要是：在第二回合，将当前指定将军率领的军队向下移1个单位。在非第二回合的时候不进行任何操作，返回一个空的操作列表。
可以看到，玩家几乎完全不需要考虑任何与评测机通讯有关的事宜， 只需要根据提供的`gamestate.GameState`对象进行决策即可。`GameState `中包含了完整的游戏运行时的信息。

还可以利用SDK代码实现中的相关特性进行某种意义上的计划操作，如：

```python
def example_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    """一个AI示例"""
    operations = []
    operations.append(
        [
            1,
            state.generals[my_seat].position[0],
            state.generals[my_seat].position[1],
            random.randint(1, 4),
            1,
        ]
    )
    return operations

```
如 `game_controller.GameController.try_apply_our_op()` 的API文档所描述，`GameController` 在实施执行操作、发送操作之前都会检查操作的有效性，防止选手执行错误操作。 因此，选手可以一直给SDK一系列操作，然后让SDK自己决定应用和发送的时机。
>警告
但是，这种设计有潜在的隐藏选手自身程序问题的风险，因此我们非常建议不要在复杂的逻辑之中应用这种操作。

## 使用 GameController

实际上， `run_ai`就是一段可能所有用户都要写的代码的封装。如果您认为这种封装给自己的控制权太小，也可以直接使用 `GameController`对游戏过程进行直接控制，即直接将`run_ai`中的主体代码复制到主函数中重复利用，如下所示：
```python
from gamestate import GameState
from game_controller import *

game = GameController()
game.init()
round = 1
while True:
    if game.my_seat == 0:
        ops = example_ai(round, 0, game.game_state) # 上文中定义的ai函数
        game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()
        game.read_and_apply_enemy_ops()
    else:
        game.read_and_apply_enemy_ops()
        ops = example_ai(round, 1, game.game_state)
        game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()
    round += 1

```


## 使用辅助函数
controller.py中含有返回操作列表的函数，可以直接使用。

# `execution.py`

## `execute_single_command(player: int, state: GameState, op: Operation) -> bool`

执行单个命令的函数。

### 参数

- `player`: `int` 当前的玩家。
- `state`: `GameState` 当前的游戏状态。
- `op`: `Operation` 要执行的操作。

### 返回值

- `bool`：如果操作成功，返回`True`；否则返回`False`。

此函数根据操作类型（`OperationType`）执行相应的操作，包括移动军队、移动将军、升级将军、使用将军技能、升级科技、使用超级武器和召唤将军等,并修改全局GameState。

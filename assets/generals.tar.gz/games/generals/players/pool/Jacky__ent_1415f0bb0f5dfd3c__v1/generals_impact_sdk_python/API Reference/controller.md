# `controller.py`

这个文件包含了与评测机交互的相关函数。


### `read_init_map() -> tuple[int, GameState]`

从评测机读取先后手信息与初始地图。

#### 返回值

- `tuple[int, GameState]`：一个元组，包含先后手信息和初始地图状态。


### `read_enemy_operations() -> list[list]`

读取敌方操作列表。

#### 返回值

- `list[list]`：一个包含敌方所有操作的列表。


### `write_to_judger(msg: str) -> None`

按照4+N协议将消息输出给评测机。

#### 参数

- `msg`: `str` 需要输出的消息。


### `write_our_operation(ops: list[list]) -> None`

向评测机输出我方的操作列表。

#### 参数

- `ops`: `list[list]` 我方的操作列表。


#  `gamedata.py`

这个文件定义了游戏中主要的数据结构（不包含游戏状态）。

---

## 类

### `class` `gamedata.SkillType(IntEnum)`

玩家技能种类的枚举类。包括：`SURPRISE_ATTACK`, `ROUT`, `COMMAND`, `DEFENCE`, `WEAKEN`。
- `SURPRISE_ATTACK = 0`: 突袭
- `ROUT = 1`: 击破
- `COMMAND = 2`: 统率
- `DEFENCE = 3`: 坚守
- `WEAKEN = 4`: 弱化

### `class` `gamedata.QualityType(IntEnum)`

将军技能种类的枚举类。包括：`PRODUCTION`, `DEFENCE`, `MOBILITY`。
- `PRODUCTION = 0`: 产量
- `DEFENCE = 1`: 防御
- `MOBILITY = 2`: 行动力

### `class` `gamedata.WeaponType(IntEnum)`

超级武器种类的枚举类。包括：`NUCLEAR_BOOM`, `ATTACK_ENHANCE`, `TRANSMISSION`, `TIME_STOP`。
- `NUCLEAR_BOOM = 0`: 核弹
- `ATTACK_ENHANCE = 1`: 攻击强化
- `TRANSMISSION = 2`: 超时空传送
- `TIME_STOP = 3`: 时间停止

### `class` `gamedata.CellType(IntEnum)`

地形种类的枚举类。包括：`PLAIN`, `BOG`, `MOUNTAIN`。注意：将军不算地形，而属于地形的元素。
- `PLAIN = 0`: 平原
- `BOG = 1`: 沼泽
- `MOUNTAIN = 2`: 流沙

### `class` `gamedata.TechType(IntEnum)`

科技升级类型的枚举类。包括：`MOBILITY`, `CLIMB`, `IMMUNE`, `UNLOCK`。
- `MOBILITY = 0`: 军队行动力升级
- `CLIMB = 1`: 免疫沼泽
- `IMMUNE = 2`: 免疫流沙
- `UNLOCK = 3`: 解锁超级武器

### `class` `gamedata.Direction(IntEnum)`

方向的枚举类。包括：`UP`, `DOWN`, `LEFT`, `RIGHT`。
- `UP = 0`: 上
- `DOWN = 1`: 下
- `LEFT = 2`: 左
- `RIGHT = 3`: 右

### `class` `gamedata.Skill`

技能的数据类。包含两个属性：`type`和`cd`。`type`是`SkillType`类型，表示技能的类型。`cd`是`int`类型，表示技能的冷却时间。

### `class` `gamedata.SuperWeapon`

超级武器的数据类。包含五个属性：`type`, `player`, `cd`, `rest`, `position`。
- `type`:`WeaponType`
    超级武器类型。
- `player`:`int`
    玩家
- `cd`:`int`
    超级武器发挥作用的总回合数
- `rest`:`int`类型，
    超级武器发挥作用的剩余回合数
- `position`:`list`
    超级武器的位置

### `class` `gamedata.Generals`

将军的数据类。包含五个属性：`id`, `player`, `position`, `skills_cd`, `skill_duration`。
- `id`:`int`
    将军id
- `player`:`int`
    将军从属的玩家
- `position`:`list`
    将军位置
- `skills_cd`:`int`类型，
    将军技能的冷却时间
- `skills_duration`:`int`
    将军技能的发挥作用的剩余回合数

### `class` `gamedata.Oilwell(Generals)`

油井的数据类，继承自`Generals`。增加了三个属性：`produce_level`, `defense_level`, `mobility_level`。
- `produce_level`:`int`
    产量等级，默认为1，可升级
- `defense_level`:`int`
    防御等级，默认为1，可升级
- `mobility_level`:`int`
    行动力等级，默认为0，且不可升级，即油田不可移动

### `class` `gamedata.MainGenerals(Generals)`

主将的数据类，继承自`Generals`。增加了四个属性：`produce_level`, `defense_level`,`mobility_level`，`skills` 
- `produce_level`:`int`
    将军产量等级，默认为1，可升级
- `defense_level`:`int`
    将军防御等级，默认为1，可升级
- `mobility_level`:`int`
    将军行动力等级，默认为1，可升级
- `skills`:`list`
    将军技能列表

### `class` `gamedata.SubGenerals(Generals)`

副将的数据类，继承自`Generals`。增加了四个属性：`produce_level`, `defense_level`,`mobility_level`，`skills` 
- `produce_level`:`int`
    将军产量等级，默认为1，可升级
- `defense_level`:`int`
    将军防御等级，默认为1，可升级
- `mobility_level`:`int`
    将军行动力等级，默认为1，可升级
- `skills`:`list`
    将军技能列表

### `class` `gamedata.Cell`

格子的数据类。包含六个属性：`position`, `type`, `player`, `generals`, `weapon_activate`, `army`。
- `position`:`list`
    格子位置
- `type`:`CellType`
    格子类型
- `player`:`int`
    表示玩家
- `generals`:`Generals`
    格子上的将军，若无将军则为None
- `weapon_activate`:`list`
    格子上放置的激活的超级武器列表
- `army`:`int`
    格子上的军队数目
    
---

## 方法

### `gamedata.init_coin()` → `int`

初始化金币，设置为0。

### `gamedata.init_cell_type()` → `int`

初始化格子类型




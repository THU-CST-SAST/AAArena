# `gamestate.py`

本文件定义了游戏状态类，以及负责初始化将军，更新回合的函数。

---

## 类

### `class GameState`

这是一个数据类，用于表示游戏状态。

#### 属性

- `round: int`：当前游戏回合数，默认为1。
- `generals: list[Generals]`：游戏中的将军列表，用于通信。
- `coin: list[int]`：每个玩家的金币数量列表，分别对应玩家1，玩家2。
- `active_super_weapon: list[SuperWeapon]`：活跃的超级武器列表。
- `super_weapon_unlocked: list[bool]`：超级武器是否解锁的列表，解锁了是true，分别对应玩家1，玩家2。
- `super_weapon_cd: list[int]`：超级武器的冷却回合数列表，分别对应玩家1，玩家2。
- `tech_level: list[list[int]]`：科技等级列表，第一层对应玩家一，玩家二，第二层分别对应行动力，免疫沼泽，免疫流沙，超级武器。
- `rest_move_step: list[int, int]`：军队剩余移动步数列表，分别对应玩家1、2。
- `board: list[list[Cell]]`：游戏棋盘的二维列表，每个元素是一个Cell对象。
- `next_generals_id: int`：游戏中下一个将产生的将军的ID。
- `winner: int`：赢家，-1表示还没有决出胜者。

#### 类函数

- `find_general_position_by_id(general_id: int) -> list[int, int] or None`：通过将军的ID查找其位置。如果找不到，返回None。

---

### 方法
`update_round(gamestate: GameState) -> None`

更新回合。这个函数会更新每个单元格的军队数量，处理超级武器的效果，处理超级武器cd、duration、军队行动力等等。

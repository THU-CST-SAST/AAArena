import random
import math

from generals_impact_game.controller import run_ai
from generals_impact_game.gamestate import GameState
from generals_impact_game.gamedata import Oilwell
from generals_impact_game.gamedata import MainGenerals
from generals_impact_game.gamedata import Cell
from generals_impact_game.computation import *


def example_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    """一个AI示例"""
    operations = []
    operations.append(
        [
            1,
            state.generals[my_seat].position[0],
            state.generals[my_seat].position[1],
            random.randint(1, 4),
            1,
        ]
    )
    return operations

# 标注地图上每个坐标将军分别需要多少步到达
map_distance = [[100000 for i in range(15)] for j in range(15)]

# 标注地图上每个坐标将军走最短路线到达之的最短路线的前一格与之相对位置（0上1下2右3左）
map_pre = [[0 for i in range(15)] for j in range(15)]

# 使用bfs标注地图上每个坐标将军分别需要多少步到达，以及最短路线的前一格与之相对位置
def bfs(gamestate: GameState, x: int, y: int):
    q = []
    q.append([x, y])
    map_distance[x][y] = 0
    while len(q) > 0:
        t = q.pop(0)
        for i in range(4):
            tx = t[0] + [0, 0, 1, -1][i]
            ty = t[1] + [1, -1, 0, 0][i]
            if tx < 0 or tx >= 15 or ty < 0 or ty >= 15:
                continue
            if gamestate.board[tx][ty].type == 1:
                continue
            if map_distance[tx][ty] != 0:
                continue
            map_distance[tx][ty] = map_distance[t[0]][t[1]] + 1
            map_pre[tx][ty] = i
            q.append([tx, ty])

# 从终点开始回溯最短路线
def get_path(gamestate: GameState, x: int, y: int, tx: int, ty: int):
    # x和y是起点，tx和ty是终点
    path = []
    while x != tx or y != ty:
        path.append([tx, ty])
        tx -= [0, 0, 1, -1][map_pre[tx][ty]]
        ty -= [1, -1, 0, 0][map_pre[tx][ty]]
    path.append([x, y])
    path.reverse()
    return path

# 按照bfs已经做好的标注，找到离本方主将最近的油井
def find_nearest_oilwell(gamestate: GameState, my_seat: int):
    min_distance = 10000
    min_x = -1
    min_y = -1
    for general in gamestate.generals:
        if isinstance(general, Oilwell) and general.player != my_seat and gamestate.board[general.position[0]][general.position[1]].type != 1:
            if map_distance[general.position[0]][general.position[1]] < min_distance:
                min_distance = map_distance[general.position[0]][general.position[1]]
                min_x = general.position[0]
                min_y = general.position[1]               
    return min_x, min_y

# 找到敌方主将的位置
def find_enemy_general(gamestate: GameState, my_seat: int):
    for general in gamestate.generals:
        if isinstance(general, MainGenerals) and general.player != my_seat:
            return general.position[0], general.position[1]
    return -1, -1

# 计算某点到我方主将的距离
def distance_to_my_general(gamestate: GameState, x: int, y: int, my_seat: int):
    return map_distance[gamestate.generals[my_seat].position[0]][gamestate.generals[my_seat].position[1]]

# 计算某格兵力攻击另一格是否成功，若成功则返回剩余军队数量，否则返回-1
def attack_success(gamestate: GameState, x: int, y: int, tx: int, ty: int, army: int):
    # 最多用该格兵力-1进行攻击
    available_army = army - 1
    defence_army = gamestate.board[tx][ty].army
    is_success = available_army - compute_defence(gamestate.board[tx][ty], gamestate) * defence_army
    if is_success > 0:
        return math.ceil(is_success)
    else:
        return -1

# 计算某一位置是否在主将的5*5范围内
def in_range(gamestate: GameState, x: int, y: int, my_seat: int):
    if x < gamestate.generals[my_seat].position[0] - 2 or x > gamestate.generals[my_seat].position[0] + 2 or y < gamestate.generals[my_seat].position[1] - 2 or y > gamestate.generals[my_seat].position[1] + 2:
        return False
    else:
        return True

def my_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    operations = [] # 操作列表
    coin = state.coin[my_seat] # 我方金币数量
    main_general_position = state.generals[my_seat].position # 我方主将位置
    main_army_position = main_general_position # 我方主力部队位置（理论上应该跟主将位置一样）
    main_army_num = state.board[main_general_position[0]][main_general_position[1]].army # 我方主力部队数量
    
    nearest_oilwell = find_nearest_oilwell(state, my_seat)
    enemy_general = find_enemy_general(state, my_seat)
    oilwell_distance = map_distance[nearest_oilwell[0]][nearest_oilwell[1]]
    enemy_distance = map_distance[enemy_general[0]][enemy_general[1]]
    # 第一回合，升级主将
    if round == 1:
        operations.append([3, state.generals[my_seat].id, 1])
        operations.append([3, state.generals[my_seat].id, 3])
        return operations
    
    # 最优先判定：能否突袭击杀敌方主将
    # 先判断石油是否充足
    if coin >= 20:
        # 再判断敌方主将周边的四个格是否可达（在我方主将为中心的5*5范围内），选取可达的格子中兵力最少的一格
        min_army = 10000
        min_x = -1
        min_y = -1
        for i in range(4):
            tx = enemy_general[0] + [0, 0, 1, -1][i]
            ty = enemy_general[1] + [1, -1, 0, 0][i]
            if not in_range(state, tx, ty, my_seat):
                continue
            if tx < 0 or tx >= 15 or ty < 0 or ty >= 15:
                continue
            if state.board[tx][ty].type == 1:
                continue
            if state.board[tx][ty].player == my_seat:
                continue
            if state.board[tx][ty].generals != None:
                continue
            if state.board[tx][ty].army < min_army:
                min_army = state.board[tx][ty].army
                min_x = tx
                min_y = ty
        if min_x != -1 and min_y != -1:
            # 如果钱够空袭，则假设空袭敌方主将，下面计算空袭后是否能击杀敌方主将
            if coin >= 35 and in_range(state, enemy_general[0], enemy_general[1], my_seat):
                # 计算空袭后敌方主将剩余兵力
                enemy_general_army = max(state.board[enemy_general[0]][enemy_general[1]].army - 20, 0)
                # 第一步到达敌方主将的旁边，计算剩余兵力
                attack_1 = attack_success(state, main_general_position[0], main_general_position[1], min_x, min_y, main_army_num)
                if attack_1 != -1:
                    main_army_num = math.ceil(attack_1)
                    # 第二步攻击敌方主将，计算剩余兵力
                    if enemy_general_army < main_army_num - 1:
                        operations.append([4, 1, min_x, min_y])
                        operations.append([4, 2, enemy_general[0], enemy_general[1]])
                        operations.append([1, min_x, min_y, enemy_general[0], enemy_general[1]])
                        return operations
            # 如果钱不够空袭，则假设不空袭敌方主将，下面计算不空袭后是否能击杀敌方主将
            else:
                # 第一步到达敌方主将的旁边，计算剩余兵力
                attack_1 = attack_success(state, main_general_position[0], main_general_position[1], min_x, min_y, main_army_num)
                if attack_1 != -1:
                    main_army_num = math.ceil(attack_1)
                    # 第二步攻击敌方主将，计算剩余兵力
                    if state.board[enemy_general[0]][enemy_general[1]].army < main_army_num - 1:
                        operations.append([4, 1, min_x, min_y])
                        operations.append([1, min_x, min_y, enemy_general[0], enemy_general[1]])
                        return operations

    # 满足条件时升级主将产量
    if coin >= 40:
        operations.append([3, state.generals[my_seat].id, 1])
        coin -= 40
    # 满足条件时升级油田
    for general in state.generals:
        if isinstance(general, Oilwell) and general.player == my_seat and general.produce_level == 1 and coin >= 10:
            operations.append([3, general.id, 1])
            coin -= 10
    # 计算全图到主将的最短路
    bfs(state, state.generals[my_seat].position[0], state.generals[my_seat].position[1])
    # 判断最近的油井和敌方主将哪一个离我方主将更近
    # 如果油田更近，就去占领油田
    if oilwell_distance < enemy_distance:
        path = get_path(state, state.generals[my_seat].position[0], state.generals[my_seat].position[1], nearest_oilwell[0], nearest_oilwell[1])
        # 考虑到行动力只有2，所以部队最多走两步，如果油井距离大于2，就只走两步
        if len(path) > 3:
            path = path[:3]
        # 部队移动，每走一步都需要判定这一步能否取胜，且主力部队数量多于1
        for i in range(1, len(path)):
            if main_army_num > 1 and attack_success(state, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1], main_army_num) != -1:
                operations.append([1, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1]])
                main_army_num = attack_success(state, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1], main_army_num)
                main_army_position = path[i]
            else:
                break
        # 将军移动，如果主力部队占领了油井，则不动，反之移动到主力部队所在处
        if state.board[main_army_position[0]][main_army_position[1]].generals == None:
            operations.append([1, state.generals[my_seat].position[0], state.generals[my_seat].position[1], path[-1][0], path[-1][1]])
    # 如果敌方主将更近，如果兵力占优势，就去攻击敌方主将，否则调动后方部队支援主将
    else:
        # 如果主力部队数量大于敌方主将数量，就去攻击敌方主将
        if main_army_num > state.board[enemy_general[0]][enemy_general[1]].army:
            path = get_path(state, state.generals[my_seat].position[0], state.generals[my_seat].position[1], enemy_general[0], enemy_general[1])
            # 考虑到行动力只有2，所以部队最多走两步，如果敌方主将距离大于2，就只走两步
            if len(path) > 3:
                path = path[:3]
            # 部队移动，每走一步都需要判定这一步能否取胜，且主力部队数量多于1
            for i in range(1, len(path)):
                if main_army_num > 1 and attack_success(state, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1], main_army_num) != -1:
                    operations.append([1, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1]])
                    main_army_num = attack_success(state, path[i - 1][0], path[i - 1][1], path[i][0], path[i][1], main_army_num)
                    main_army_position = path[i]
                else:
                    break
            # 将军移动，如果主力部队占领了敌方主将，则不动，反之移动到主力部队所在处
            if state.board[main_army_position[0]][main_army_position[1]].generals == None:
                operations.append([1, state.generals[my_seat].position[0], state.generals[my_seat].position[1], path[-1][0], path[-1][1]])
        # 如果主力部队数量小于敌方主将数量，不动
        else:
            pass
    return operations

run_ai(my_ai)

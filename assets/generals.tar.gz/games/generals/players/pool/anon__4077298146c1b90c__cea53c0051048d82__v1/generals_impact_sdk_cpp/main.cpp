#include "include/ai_template.hpp"


Direction findMoveDirection(std::pair<int,int> position,int my_seat, const GameState &gamestate);

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    if(gamestate.round==1)ops.push_back(update_generals_op(0,QualityType::PRODUCTION));
    if(gamestate.coin[my_seat]>=80)ops.push_back(update_generals_op(0,QualityType::PRODUCTION));
    if(gamestate.round==4)ops.push_back(move_army_op(gamestate.generals[my_seat]->position,Direction::DOWN,1));

    int move_army_op_num = 0;
    for(int i = 0; i < Constant::row; ++i)
    {
      for(int j =0; j < Constant::col; ++j)
      {
        Direction dir = findMoveDirection({i,j},my_seat,gamestate);
        if(gamestate.board[i][j].player==my_seat&&gamestate.board[i][j].army>1&&dir!=Direction::NONE&&move_army_op_num<2)
        {
          ops.push_back(move_army_op({i,j},dir,gamestate.board[i][j].army/2));
          move_army_op_num++;
        }
      }
    }
    return ops;
}

Direction findMoveDirection(std::pair<int,int> position,int my_seat, const GameState &gamestate){
    if(position.first-1>=0&&gamestate.board[position.first-1][position.second].player==-1&&gamestate.board[position.first-1][position.second].type==CellType::PLAIN)
    {
        return Direction::UP;
    }
    if(position.first+1<Constant::row&&gamestate.board[position.first+1][position.second].player==-1&&gamestate.board[position.first+1][position.second].type==CellType::PLAIN)
    {
        return Direction::DOWN;
    }
    if(position.second-1>=0&&gamestate.board[position.first][position.second-1].player==-1&&gamestate.board[position.first][position.second-1].type==CellType::PLAIN)
    {
        return Direction::LEFT;
    }
    if(position.second+1<Constant::col&&gamestate.board[position.first][position.second+1].player==-1&&gamestate.board[position.first][position.second+1].type==CellType::PLAIN)
    {
        return Direction::RIGHT;
    }
    return Direction::NONE;
}
int main(){
    run_ai(simple_ai);
}
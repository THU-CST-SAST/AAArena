import random

from generals_impact_game.constant import *
from generals_impact_game.controller import run_ai
from generals_impact_game.gamedata import *
from generals_impact_game.gamestate import GameState


def example_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    # 占一个油井->升一次生产力->叫一个副将，升级生产力->占两个油井->升行动力->能否直接传送打
    state.seat = my_seat
    operations = []

    if round == 1:
        operations.append(
            [3, my_seat, 1],
        )

    else:
        for gen in state.generals:
            if gen.player == 0 and isinstance(gen, MainGenerals):
                operations.append([1, gen.position[0], gen.position[1], random.randint(1, 4), 100])
                break

    return operations


run_ai(example_ai)

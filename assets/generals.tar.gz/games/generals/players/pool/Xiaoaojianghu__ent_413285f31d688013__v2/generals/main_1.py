import sys

from generals_impact_game.constant import *
from generals_impact_game.controller import run_ai
from generals_impact_game.gamedata import *
from generals_impact_game.gamestate import GameState


def bfs(
    state: GameState,
    my_seat: int,
    start_pos: list[int, int],
    skip_cells: list[list[int]],
    able_cell_check,
    end_check,
) -> list[list[int]]:

    visited = set()
    visited.add(start_pos[0] * row + start_pos[1])
    for cell in skip_cells:
        visited.add(cell[0] * row + cell[1])
    queue = [(start_pos, [])]

    while len(queue):
        pos, path = queue.pop(0)

        if end_check(state.board[pos[0]][pos[1]], state):
            return path

        for posx, posy in [
            (pos[0] - 1, pos[1]),
            (pos[0], pos[1] - 1),
            (pos[0] + 1, pos[1]),
            (pos[0], pos[1] + 1),
        ]:
            if posx >= 0 and posy >= 0 and posx < row and posy < col:
                if (
                    able_cell_check(state.board[posx][posy], state)
                    and posx * row + posy not in visited
                ):
                    new_path = path + [[posx, posy]]
                    queue.append(([posx, posy], new_path))
                    visited.add(posx * row + posy)

    return []


public_save = [
    [],
    [1],
]  # 0: 占领过的油井 1：当前阶段 2：副将序号 3: 副将可征召位置


def check_func_1(cell: Cell, state: GameState) -> bool:
    # 是普通地块且没将军
    return (
        cell.type == CellType(0)
        and not type(cell.generals).__name__ == "MainGenerals"
        and not type(cell.generals).__name__ == "SubGenerals"
        and cell.player != 1 - state.seat
    )


def check_func_2(cell: Cell, state: GameState) -> bool:
    # 不是山且没将军
    return (
        cell.type != CellType(2)
        and not type(cell.generals).__name__ == "MainGenerals"
        and not type(cell.generals).__name__ == "SubGenerals"
        and cell.player != 1 - state.seat
    )


def check_func_3(cell: Cell, state: GameState) -> bool:
    # 不是山且没将军
    return (
        not (cell.type == CellType(2) and state.tech_level[state.seat][1] == 0)
        and cell.generals == None
    )


def end_func_1(cell: Cell, state: GameState) -> bool:
    return isinstance(cell.generals, Oilwell)


def end_func_2(cell: Cell, state: GameState) -> bool:
    # 打对方兵
    print("check cell ", cell.position, file=sys.stderr)
    return (cell.player == 1 - state.seat) and not (
        cell.type == CellType(2) and state.tech_level[state.seat][1] == 0
    )


def example_ai(round: int, my_seat: int, state: GameState) -> list[list[int]]:
    # 占一个油井->升一次生产力->叫一个副将，升级生产力->占两个油井->升行动力->能否直接传送打
    state.seat = my_seat
    operations = []

    if round == 1:
        # upgrade production of main general
        operations.append(
            [3, my_seat, 1],
        )

    # stage 1: find a Oilwell and occupy
    print("occupy oilwell ", public_save[1][0] - 1, file=sys.stderr)
    path = bfs(
        state,
        my_seat,
        state.generals[my_seat].position,
        public_save[0],
        check_func_1,
        end_func_1,
    )
    if len(path) == 0:
        path = bfs(
            state,
            my_seat,
            state.generals[my_seat].position,
            public_save[0],
            check_func_2,
            end_func_1,
        )
    if len(path) == 0:
        public_save[1][0] += 1
    direc = None
    print("path ", path, file=sys.stderr)
    if len(path) > 0:
        if path[0][0] - state.generals[my_seat].position[0] == 0:
            if path[0][1] - state.generals[my_seat].position[1] == 1:
                direc = 4
            else:
                direc = 3
        elif path[0][0] - state.generals[my_seat].position[0] == 1:
            direc = 2
        else:
            direc = 1

        operations.append(
            [
                1,
                state.generals[my_seat].position[0],
                state.generals[my_seat].position[1],
                direc,
                114,
            ]
        )

        if len(path) != 1:
            operations.append(
                [2, my_seat, path[0][0], path[0][1]],
            )
        else:
            # 添加已到达
            if state.board[path[0][0]][path[0][1]].generals.player == my_seat:
                public_save[0].append(path[0])

    return operations


run_ai(example_ai)

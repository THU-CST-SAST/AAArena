#pragma once

#include "controller.hpp"

inline bool check_cell(int x, int y)
{
    return x >= 0 && x < Constant::row && y >= 0 && y < Constant::col;
}

inline bool approachable_cell(int x, int y, int my_seat, GameState const & state)
{
    CellType type = state.board[x][y].type;
    int player = state.board[x][y].player;
    bool type_ok (type == CellType::PLAIN || type == CellType::SAND || state.tech_level[my_seat][(int)type]);
    bool player_ok (player == -1 || player == my_seat);
    // bool general_ok (player == -1 || state.board[x][y].generals == nullptr);
    bool general_ok ((player == -1 && dynamic_cast<OilWell*>(state.board[x][y].generals))|| state.board[x][y].generals == nullptr);
    return (type_ok && general_ok && player_ok);
}

inline std::pair<int, int> neighbour(std::pair<int, int> pos, int direction)
{
    if (direction >= 0 && direction <= 3)
        return std::make_pair(pos.first + Constant::dx[direction], pos.second + Constant::dy[direction]);
    return pos;
}
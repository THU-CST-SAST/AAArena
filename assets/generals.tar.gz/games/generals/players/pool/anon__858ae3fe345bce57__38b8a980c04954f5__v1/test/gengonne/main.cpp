#include "include/ai_template.hpp"
#include "include/myhpp.hpp"
#include <queue>

int manhatton(int a, int b, int c, int d){
    return std::abs(a-c) + std::abs(b-d);
}

const int infty = 10000;

/*std::vector<Operation> my_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    int genmaxmove = gamestate.generals[my_seat]->rest_move;
    int genmaxnew = gamestate.generals[my_seat]->produce_level;
    int smaxmove = gamestate.tech_level[my_seat][0];
    if(gamestate.round == 1){
        ops.push_back(update_generals_op(gamestate.generals[my_seat]->id,QualityType::PRODUCTION));
        ops.push_back(update_generals_op(gamestate.generals[my_seat]->id,QualityType::MOBILITY));
    }else{
        int dist = infty;
        std::pair <int,int> nearest_oilwell_pos = {-1,-1};
        for (int i = 0; i < Constant::row; ++i){
            for (int j = 0; j < Constant::col; ++j){
                if (dynamic_cast<OilWell*>(gamestate.board[i][j].generals) && gamestate.board[i][j].player == -1 
                && manhatton(i,j,gamestate.generals[my_seat]->position.first, gamestate.generals[my_seat]->position.second) < dist){
                    dist = manhatton(i,j,gamestate.generals[my_seat]->position.first, gamestate.generals[my_seat]->position.second);
                    std::pair <int,int> nearest_oilwell_pos = std::make_pair(i,j);
                }
            }
        }
        if (dist == infty) return ops; 
        for (int i = 0; i < 4; i++){
            std::pair <int, int> npos = std::make_pair(gamestate.generals[my_seat]->position.first + Constant::dx[i], gamestate.generals[my_seat]->position.second + Constant::dy[i]);
            if (manhatton(npos.first, npos.second, nearest_oilwell_pos.first, nearest_oilwell_pos.second) < dist){
                dist = manhatton(npos.first, npos.second, nearest_oilwell_pos.first, nearest_oilwell_pos.second);
                ops.push_back(move_army_op(gamestate.generals[my_seat]->position, Direction(i), gamestate.board[gamestate.generals[my_seat]->position.first][gamestate.generals[my_seat]->position.second].army-1));
                ops.push_back(move_generals_op(my_seat, npos));
                break;
            }
        }
    }
    return ops;
} */



std::vector<Operation> my_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    int genmaxmove = gamestate.generals[my_seat]->rest_move;
    int genmaxnew = gamestate.generals[my_seat]->produce_level;
    int smaxmove = gamestate.tech_level[my_seat][0];
    if(gamestate.round == 1){
        ops.push_back(update_generals_op(gamestate.generals[my_seat]->id,QualityType::PRODUCTION));
        ops.push_back(update_generals_op(gamestate.generals[my_seat]->id,QualityType::MOBILITY));
    }else{
        int dist = infty;
        std::pair <int,int> nearest_oilwell_pos = {-1,-1};
        for (int i = 0; i < Constant::row; ++i){
            for (int j = 0; j < Constant::col; ++j){
                if (dynamic_cast<OilWell*>(gamestate.board[i][j].generals) && gamestate.board[i][j].player == -1 
                && manhatton(i,j,gamestate.generals[my_seat]->position.first, gamestate.generals[my_seat]->position.second) < dist){
                    dist = manhatton(i,j,gamestate.generals[my_seat]->position.first, gamestate.generals[my_seat]->position.second);
                    std::pair <int,int> nearest_oilwell_pos = std::make_pair(i,j);
                }
            }
        }
        std::pair <int, int> npos = std::make_pair(gamestate.generals[my_seat]->position.first + Constant::dx[0], gamestate.generals[my_seat]->position.second + Constant::dy[0]);
        ops.push_back(move_army_op(gamestate.generals[my_seat]->position, Direction(0), gamestate.board[gamestate.generals[my_seat]->position.first][gamestate.generals[my_seat]->position.second].army-1));
        ops.push_back(move_generals_op(my_seat, npos));
        /*if (dist == infty) return ops; 
        for (int i = 0; i < 4; i++){
            std::pair <int, int> npos = std::make_pair(gamestate.generals[my_seat]->position.first + Constant::dx[i], gamestate.generals[my_seat]->position.second + Constant::dy[i]);
            if (manhatton(npos.first, npos.second, nearest_oilwell_pos.first, nearest_oilwell_pos.second) < dist){
                dist = manhatton(npos.first, npos.second, nearest_oilwell_pos.first, nearest_oilwell_pos.second);
                ops.push_back(move_army_op(gamestate.generals[my_seat]->position, Direction(i), gamestate.board[gamestate.generals[my_seat]->position.first][gamestate.generals[my_seat]->position.second].army-1));
                ops.push_back(move_generals_op(my_seat, npos));
                break;
            }
        }*/
    }
    return ops;
}


int main(){
    run_ai(my_ai);
}


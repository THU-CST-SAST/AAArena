#include <vector>
#include "operation.hpp"
#include "gamestate.hpp"
#include "MyUtilities.hpp"
#include "util.hpp"
#include "Evaluator.hpp"
#include "MapWizard.hpp"
#pragma once
using namespace std;

Cell* mainGeneralDest;
vector<pair<int, int>> path;
int mainGeneralWptIdx = 0;

struct SpotLight
{
    Generals* general;
    Cell* centerCell;
    int range;
};

struct MoveNode
{
    int index;
    int parentIndex;
    int layer;
    Operation operation;
    GameState gameState;
    bool isEnd;
};

vector<pair<int, int>> calcSpotlightCoverage(SpotLight* spotLight, int ext)
{
    vector<pair<int, int>> result;
    int r = spotLight->range + ext;
    for (int x = spotLight->centerCell->position.first - r; x <= spotLight->centerCell->position.first + r; ++x)
    {
        for (int y = spotLight->centerCell->position.second -abs(r - abs(x)); y <= spotLight->centerCell->position.second + abs(r - abs(x)) ; ++y)
        {
            result.push_back({x, y});
        }
    }
    return result;
}

vector<SpotLight> createSpotLights(int player, GameState* gameState)
{
    vector<SpotLight> result;
    for (int x = 0; x < Constant::col; ++x)
    {
        for (int y = 0; y < Constant::row; ++y)
        {
            if(gameState->board[x][y].player != player)
                continue;
            if(gameState->board[x][y].generals != nullptr)
                result.push_back({gameState->board[x][y].generals, &gameState->board[x][y], 5});
        }
    }
    return result;
}

vector<pair<int, int>> calcGeneralMoveRange(int player, int generalID, GameState gameState)
{
    vector<pair<int, int>> result;
    Generals* general = findGeneralByID(generalID, &gameState);
    int x = general->position.first;
    int y = general->position.second;
    for (int dx = -4; dx <= 4 ; ++dx)
        for (int dy = -4; dy < 4; ++dy)
        {
            if(dx == 0 && dy == 0)
                continue;
            pair<int, int> destination = {x + dx, y + dy};
            if(check_general_movement(general->position, gameState, player, destination).first)
                result.push_back(destination);
        }
    return result;
}

pair <vector<vector<Operation>>, vector<pair<float, float>>> findValidMoves(int player, GameState gameState)
{
    vector<MoveNode> nodes;
    MoveNode rootNode = {0, 0, 0, do_nothing_op(), gameState, true}; // root node of tree
    nodes.push_back(rootNode);
    int searchLayer = 1;
    int nodeCnt = 0;
    int numValidOpsCurrLayer;
    bool quitSearch = false;

    while(!quitSearch)
    {
        numValidOpsCurrLayer = 0;
        for (int i = 0; i < nodes.size(); ++i)
        {
            if(nodes[i].layer != searchLayer - 1)
                continue;
            if(nodes[i].gameState.rest_move_step[player] == 0)
                continue;
            // 开始搜索子节点
            // 搜索移动军队操作
            auto positions = getPlayerOccupiedPositions(player, &nodes[i].gameState);
            for (int j = 0; j < positions.size(); ++j)
            {
                int x = positions[j].first;
                int y = positions[j].second;
                // 如果某一处有多于两个部队的话，那么可以移动
                if(nodes[i].gameState.board[x][y].army >= 2)
                {
                    // 尝试这一处的各种方向
                    for (int dir = 0; dir < 4; ++dir)
                    {
//                        auto newPos = calculate_new_pos({x, y}, static_cast<Direction>(dir));
//                        if(gameState.board[newPos.first][newPos.second].player == player)
//                            continue;
                        for (int num = 1; num <= nodes[i].gameState.board[x][y].army - 1; ++num)
                        {
                            GameState nextLevelGs = nodes[i].gameState;
                            //如果走不通的话，直接换方向
                            if (army_move(positions[j], nextLevelGs, player, Direction(dir), num) == 0)
                                break;
                            else
                            {
                                MoveNode child = {++nodeCnt, nodes[i].index, searchLayer,
                                                  move_army_op(positions[j], Direction(dir), num), nextLevelGs, true};
                                nodes.push_back(child);
                                nodes[i].isEnd = false;
                                numValidOpsCurrLayer++;
                            }
                        }
                    }
                }
            }
        }
        if(numValidOpsCurrLayer == 0)
            quitSearch = true;
        searchLayer++;
    }

    vector<vector<Operation>> result;
    vector<pair<float, float>> evaluations;

    for (int i = 0; i < nodes.size(); ++i)
    {
        if(!nodes[i].isEnd)
            continue;

        pair<float, float> eval = {0.0f, 0.0f};
        vector<Operation> temp, ops;

        MoveNode* node = &nodes[i];
        eval = evaluate(&node->gameState);
        while(node->layer >= 1)
        {
            temp.push_back(node->operation);
            node = &nodes[node->parentIndex];
        }
        for (int j = temp.size() - 1; j >= 0  ; --j)
            ops.push_back(temp[j]);

        evaluations.push_back(eval);
        result.push_back(ops);
    }
    return {result, evaluations};
}

pair <vector<vector<Operation>>, vector<pair<float, float>>> findMaskedValidMoves(int player, GameState gameState)
{
    vector<MoveNode> nodes;
    MoveNode rootNode = {0, 0, 0, do_nothing_op(), gameState, true}; // root node of tree
    nodes.push_back(rootNode);
    int searchLayer = 1;
    int nodeCnt = 0;
    int numValidOpsCurrLayer;
    bool quitSearch = false;
    auto spotLights = createSpotLights(player, &gameState);

    while(!quitSearch)
    {
        numValidOpsCurrLayer = 0;
        for (int i = 0; i < nodes.size(); ++i)
        {
            if(nodes[i].layer != searchLayer - 1)
                continue;
            if(nodes[i].gameState.rest_move_step[player] == 0)
                continue;
            // 开始搜索子节点
            // 搜索移动军队操作

            auto mask = calcSpotlightCoverage(&spotLights[0], searchLayer - 1);
            auto positions = getPlayerOccupiedMaskedPositions(player, &nodes[i].gameState, mask);

            for (int j = 0; j < positions.size(); ++j)
            {
                int x = positions[j].first;
                int y = positions[j].second;
                // 如果某一处有多于两个部队的话，那么可以移动
                if(nodes[i].gameState.board[x][y].army >= 2)
                {
                    // 尝试这一处的各种方向
                    for (int dir = 0; dir < 4; ++dir)
                    {
//                        auto newPos = calculate_new_pos({x, y}, static_cast<Direction>(dir));
//                        if(gameState.board[newPos.first][newPos.second].player == player)
//                            continue;
                        for (int num = 1; num <= nodes[i].gameState.board[x][y].army - 1; ++num)
                        {
                            GameState nextLevelGs = nodes[i].gameState;
                            //如果走不通的话，直接换方向
                            if (army_move(positions[j], nextLevelGs, player, Direction(dir), num) == 0)
                                break;
                            else
                            {
                                MoveNode child = {++nodeCnt, nodes[i].index, searchLayer,
                                                  move_army_op(positions[j], Direction(dir), num), nextLevelGs, true};
                                nodes.push_back(child);
                                nodes[i].isEnd = false;
                                numValidOpsCurrLayer++;
                            }
                        }
                    }
                }
            }
        }
        if(numValidOpsCurrLayer == 0)
            quitSearch = true;
        searchLayer++;
    }

    vector<vector<Operation>> result;
    vector<pair<float, float>> evaluations;

    for (int i = 0; i < nodes.size(); ++i)
    {
        if(!nodes[i].isEnd)
            continue;

        pair<float, float> eval = {0.0f, 0.0f};
        vector<Operation> temp, ops;

        MoveNode* node = &nodes[i];
        eval = evaluate(&node->gameState);
        while(node->layer >= 1)
        {
            temp.push_back(node->operation);
            node = &nodes[node->parentIndex];
        }
        for (int j = temp.size() - 1; j >= 0  ; --j)
            ops.push_back(temp[j]);

        evaluations.push_back(eval);
        result.push_back(ops);
    }
    return {result, evaluations};
}

vector<pair<int, int>> planMainGeneralMovePath(int player, Cell* destination, GameState* gameState)
{

    vector<pair<int, int>> result;
    auto pos = findGeneralByID(player, gameState)->position;
    if(pos == destination->position)
        return result;
    mainGeneralWptIdx = 0;
    auto origin = gameState->board[pos.first][pos.second];
    result = findShortestPath(&origin, destination, gameState);
    cerr << "Planned Path:\n";
    for (int i = 0; i < result.size(); ++i)
    {
        cerr << result[i].first << " " << result[i].second << endl;
    }
    cerr << "Check: ";
    check_general_movement(pos, *gameState, player, result[0]);
    path = result;
    return result;
}

Operation moveMainGeneral(int player)
{
    if(path.empty() || mainGeneralWptIdx >= path.size())
        return do_nothing_op();

    cerr << "dest:" << path[path.size() - 1].first << " " << path[path.size() - 1].second << "moving mg to wpt " << mainGeneralWptIdx << " @ " << path[mainGeneralWptIdx].first << " " << path[mainGeneralWptIdx].second << endl;

    mainGeneralWptIdx++;

    auto op = Operation(OperationType::MOVE_GENERALS, {player, path[mainGeneralWptIdx - 1].first, path[mainGeneralWptIdx - 1].second});

    cerr << "StringlizedOP:" << op.stringize() << endl;

    return op;
}

//class Dispatcher
//{
//public:
//    Generals* general;
//    vector<pair<int, int>> path;
//    int atPathPosition;
//    bool planGeneralMovePath(Cell* destination, GameState* gameState)
//    {
//        if(!path.empty())
//            if(path[path.size() - 1] == destination->position)
//                return true;
//        auto position = general->position;
//        auto origin = gameState->board[position.first][position.second];
//        auto p = findShortestPath(&origin, destination, gameState);
//        path = p;
//        atPathPosition = 0;
//        cerr << "Planned Path:\n";
//        for (int i = 0; i < path.size(); ++i)
//        {
//            cerr << path[i].first << " " << path[i].second << endl;
//        }
//        return true;
//    }
//    Operation moveGeneral()
//    {
//        if(atPathPosition == path.size())
//            return do_nothing_op();
//        if(!path.empty())
//        {
//            cerr << path.size() << atPathPosition << "moving general to " << path[atPathPosition].first << " " << path[atPathPosition].second << endl;
//            atPathPosition++;
//            return move_generals_op(general->id, path[atPathPosition]);
//        }
//        else
//            return do_nothing_op();
//    }
//};
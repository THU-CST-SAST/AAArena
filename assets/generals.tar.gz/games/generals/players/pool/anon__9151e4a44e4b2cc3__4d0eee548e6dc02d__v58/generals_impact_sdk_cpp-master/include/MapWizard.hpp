#pragma once

#include "Evaluator.hpp"
#include <queue>

using namespace std;

bool cellIsValid(int posx, int posy, GameState* gameState)
{
    return posx >= 0 && posx < Constant::col && posy >= 0 && posy < Constant::row && gameState->board[posx][posy].type == CellType::PLAIN;
}

vector<Cell*> findBorderCells(int player, GameState* gameState)
{
    vector<Cell*> results;
    for (int x = 0; x < Constant::col; ++x)
    {
        for (int y = 0; y < Constant::row; ++y)
        {
            if(gameState->board[x][y].player != player)
                continue;
            bool isBorder = false;
            if(gameState->board[x - 1][y].player != player && gameState->board[x - 1][y].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x + 1][y].player != player && gameState->board[x + 1][y].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x][y - 1].player != player && gameState->board[x][y - 1].type == CellType::PLAIN)
                isBorder = true;
            if(gameState->board[x][y + 1].player != player && gameState->board[x][y + 1].type == CellType::PLAIN)
                isBorder = true;
            if(isBorder)
                results.push_back(&gameState->board[x][y]);
        }
    }
    cerr << "Found " << results.size() << " border cells\n";
    return results;
}

int outpostBFS(Cell* startCell, GameState* gameState)
{
    int count = 0;
    Cell* current = startCell;
    queue<Cell*> q;
    bool visited[Constant::col][Constant::row] = {false};
    int steps[Constant::col][Constant::row] = {0};
    q.push(current);
    visited[startCell->position.first][startCell->position.second] = true;
    steps[startCell->position.first][startCell->position.second] = 0;

    while(!q.empty())
    {
        current = q.front();
        q.pop();

        int cx = current->position.first;   int cy = current->position.second;

        int step = steps[cx][cy];
        if(step <= 5)
            count++;
        if(step == 5)
            continue;

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if ((dx == 0 && dy == 0) || dx * dy != 0)
                    continue;
                int newx = current->position.first + dx;
                int newy = current->position.second + dy;

                if(cellIsValid(newx, newy, gameState) && visited[newx][newy] != true)
                {
                    visited[newx][newy] = true;
                    steps[newx][newy] = steps[cx][cy] + 1;
                    Cell* newCell = &gameState->board[newx][newy];
                    q.push(newCell);
                }
            }
        }
    }
//    cerr << "outpost @ " <<startCell->position.first << " " << startCell->position.second << " has reach of " << count << endl;
    return count;
}

Cell* findBestOutpost(int player, GameState* gameState)
{
    int maxReachableCells = 0;
    Cell* bestCell = NULL;
    vector<Cell*> borderCells = findBorderCells(player, gameState);
    vector<int> reachableCells(borderCells.size(), 0); // num of cells within reach in 5 steps
    for (int i = 0; i < borderCells.size(); ++i)
    {
        reachableCells[i] = outpostBFS(borderCells[i], gameState);
        if(reachableCells[i] > maxReachableCells)
        {
            maxReachableCells = reachableCells[i];
            bestCell = borderCells[i];
        }
    }
    cerr << "Best cell: " << bestCell->position.first << " " << bestCell->position.second << endl;
    return bestCell;
}

vector<pair<int, int>> findShortestPath(Cell* origin, Cell* destination, GameState* gameState)
{
    vector<pair<int, int>> temp;
    vector<pair<int, int>> result;
    bool endSearch = false;
    int count = 0;

    Cell* current = origin;

    bool visited[Constant::col][Constant::row] = {false};
    int steps[Constant::col][Constant::row] = {0};
    Cell* trace[Constant::col][Constant::row] = {NULL};

    queue<Cell*> q;
    q.push(current);

    visited[current->position.first][current->position.second] = true;
    steps[current->position.first][current->position.second] = 0;
    trace[current->position.first][current->position.second] = destination;

    while(!q.empty() && !endSearch)
    {
        current = q.front();
        q.pop();

        int cx = current->position.first;   int cy = current->position.second;

        int step = steps[cx][cy];
        if(step <= 5)
            count++;
        if(step == 5)
            continue;
        if(current == destination)
        {
            endSearch = true;
            continue;
        }

        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if ((dx == 0 && dy == 0) || dx * dy != 0)
                    continue;
                int newx = current->position.first + dx;
                int newy = current->position.second + dy;

                if(cellIsValid(newx, newy, gameState) && visited[newx][newy] != true)
                {
                    visited[newx][newy] = true;
                    steps[newx][newy] = steps[cx][cy] + 1;
                    trace[newx][newy] = current;
                    Cell* newCell = &gameState->board[newx][newy];
                    q.push(newCell);
                }
            }
        }
    }

    current = destination;
    while(trace[current->position.first][current->position.second] != destination)
    {
        temp.push_back(current->position);
        current = trace[current->position.first][current->position.second];
    }
    for (int i = temp.size() - 1; i >= 0; --i)
        result.push_back(temp[i]);
    cerr << "Found shortest path with " << temp.size() << "Steps.\n";
    return result;
}
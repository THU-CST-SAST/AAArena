#pragma once
#include "gamestate.hpp"
#include "operation.hpp"
#include <iostream>
#include <sstream>
using namespace std;
vector<Operation> ReadEnemyOperations()
{
    std::cerr << "ReadEnemyOperations() awake!\n";
    std::vector<Operation> operations;
    std::vector<int> params;
    Operation op;
    int param, op_type;
    bool quit = false;
    std::cerr << "Preparing to Enter Big Loop\n";
    while (!quit)
    {

        cerr << 18 << endl;
        string line;
        cerr << 20 << endl;
        if(!getline(cin, line))
        {
            cerr << 242 << endl;
            quit = true;
            continue;
        }
        else
        {
            cerr << 30 << endl;
        }
        cerr << 22 << endl;
        istringstream iss(line);
        cerr << 24 << endl;
        int op_type;
        cerr << 23 << endl;
        iss >> op_type;
        if(op_type == 8)
        {
            quit = true;
            cerr << "quitting big loop\n";
            break;
        }
        cerr << 31 << endl;
        int num;
        while(iss >> num)
        {
            cerr << 35 << endl;
            params.push_back(num);
        }
        cerr << 38 << endl;
        op = Operation(static_cast<OperationType>(op_type), params);
        operations.push_back(op);
        cerr << 41 << endl;
    }
    std::cerr << "loop 1 quit\n";
    std::cerr << "read_enemy_operations() is returning!\n";
    return operations;
}
#include "gamestate.hpp"
#include "constant.hpp"
using namespace std;
Generals* findGeneralByID(int general_id, GameState* gameState)
{
    for (Generals &gen: gameState->generals)
        if (gen.id == general_id)
            return &gen;
}

vector<pair<int, int>> getPlayerOccupiedPositions(int player, GameState* gameState)
{
    vector<pair<int, int>> result;
    for (int x = 0; x < Constant::col; ++x)
        for (int y = 0; y < Constant::row; ++y)
            if(gameState->board[x][y].player == player)
                result.push_back({x, y});
    return result;
}

vector<pair<int, int>> getPlayerOccupiedMaskedPositions(int player, GameState* gameState, vector<pair<int, int>> maskedPos)
{
    vector<pair<int, int>> result;
    for (auto pos: maskedPos)
        if(gameState->board[pos.first][pos.second].player == player)
                result.push_back(pos);
    return result;
}
#include "gamestate.hpp"
#include "constant.hpp"
#include <cmath>

#pragma once

using namespace std;

const float unitValue = 1.0f;
const float landValue = 1.0f;
const float generalValue = 10.0f;

vector<pair<int, int>> getBorders(int player, const GameState* gameState)
{
    vector<pair<int, int>> result;
    for (int x = 1; x < Constant::col - 1; ++x)
        for (int y = 1; y < Constant::row - 1; ++y)
        {
            if(gameState->board[x][y].player == player)
            {
                bool b1 = (gameState->board[x - 1][y - 1].player == player);
                bool b2 = (gameState->board[x - 1][y + 1].player == player);
                bool b3 = (gameState->board[x + 1][y - 1].player == player);
                bool b4 = (gameState->board[x + 1][y + 1].player == player);
                if((b1 + b2 + b3 + b4) <= 2)
                    result.push_back({x, y});
            }
            else
                continue;
        }
    return result;
}


pair<float, float> evaluate(const GameState *gameState)
{
    auto borders0 = getBorders(0, gameState);
    auto borders1 = getBorders(1, gameState);
    float player0Eval = 0.0f;
    float player1Eval = 0.0f;
    float eval = 0.0f;
    float advantage = 50.0f;
    for (int x = 0; x < Constant::col; ++x)
        for (int y = 0; y < Constant::row; ++y)
        {
            if (gameState->board[x][y].player == 0)
            {
                player0Eval += landValue;
                player0Eval += gameState->board[x][y].army * unitValue;
                if (gameState->board[x][y].generals != nullptr)
                    player0Eval += generalValue;
                if (gameState->board[x][y].type == CellType::SAND)
                {
                    cerr << "sand penalty triggered\n";
                }
            }
            else if (gameState->board[x][y].player == 1)
            {
                player1Eval += landValue;
                player1Eval += gameState->board[x][y].army * unitValue;
                if (gameState->board[x][y].generals != nullptr)
                    player1Eval += generalValue;
            }
        }

    eval = player0Eval - player1Eval;
    advantage = eval / (player0Eval + player1Eval);
    return {eval, advantage};
}

vector<Operation> pickBestMove_1(int player, pair <vector<vector<Operation>>, vector<pair<float, float>>> moves)
{
    vector<vector<Operation>> options = moves.first;
    vector<pair<float, float>> evaluations = moves.second;
    if(options.size() != evaluations.size())
        cerr << "mismatch: sizes of options and evaluations\n";
    float bestEval;
    vector<Operation> bestMove;
    if(player == 0)
    {
        bestEval = -999;
        for (int i = 0; i < evaluations.size(); ++i)
        {
            if(evaluations[i].first > bestEval)
            {
                bestEval = evaluations[i].first;
                bestMove = options[i];
            }
        }
    }
    else if(player == 1)
    {
        bestEval = 999;
        for (int i = 0; i < evaluations.size(); ++i)
        {
            if(evaluations[i].first < bestEval)
            {
                bestEval = evaluations[i].first;
                bestMove = options[i];
            }
        }
    }
    return bestMove;
}
#include "include/ai_template.hpp"
#include "include/Dispatcher.hpp"
#include "include/Evaluator.hpp"
#include "include/MapWizard.hpp"
using namespace std;

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate)
{
    cerr << "simple_ai" << endl;
    std::vector<Operation> ops;

    if(gamestate.round == 1)
    {
        ops.push_back(update_generals_op(my_seat, QualityType::MOBILITY));
        ops.push_back(update_generals_op(my_seat, QualityType::MOBILITY));
    }

    if(gamestate.round > 40)
        return ops;

    auto validMoves = findValidMoves(my_seat, gamestate);
    vector<Operation> bestMoves = pickBestMove_1(my_seat, validMoves);

    cerr << "Round " << gamestate.round << " Best Moves:\n";
    for(auto op : bestMoves)
        cerr << " -> " << op.stringize();

    for (int i = 0; i < bestMoves.size(); ++i)
        ops.push_back(bestMoves[i]);

    auto bestOutpost = findBestOutpost(my_seat, &const_cast<GameState&>(gamestate));
    planMainGeneralMovePath(my_seat, bestOutpost, &const_cast<GameState&>(gamestate));
    ops.push_back(moveMainGeneral(my_seat));


    return ops;
}

int main()
{
    cerr << "main40" << endl;
    run_ai(simple_ai);
    cerr << "main42" << endl;
}
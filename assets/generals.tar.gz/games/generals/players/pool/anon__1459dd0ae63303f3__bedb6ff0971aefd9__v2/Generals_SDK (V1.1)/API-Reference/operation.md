# operation.hpp

本文件定义了游戏的操作类以及一系列帮助选手封装操作的函数

## 枚举类型

### `enum class OperationType`

* 描述：操作类型。
* 可选值：
  * DEFAULT_OP
  * MOVE_ARMY
  * MOVE_GENERALS
  * UPDATE_GENERALS
  * USE_GENERAL_SKILLS
  * UPDATE_TECH
  * USE_SUPERWEAPON
  * CALL_GENERAL

## 类定义

### `class Operation`

* 描述：操作类。
* 成员变量：
  * `OperationType opcode`：操作类型。
  * `std::vector<int> operand`：操作参数列表。
* 构造函数：
  * `Operation(OperationType opcode = OperationType::DEFAULT_OP, const std::vector<int>& operand = {})`：构造函数。
* 成员函数：
  * `std::string stringize() const`：将操作对象转化为字符串形式，便于发送 judger。

## 封装函数

### `Operation move_army_op(std::pair<int,int> position, Direction direction, int num)`

* 描述：创建移动军队的操作对象。
* 参数：
  * `std::pair<int,int> position`：移动的起始位置坐标。
  * `Direction direction`：移动的方向。
  * `int num`：移动的数量。
* 返回值：移动军队的操作对象。

### `Operation move_generals_op(int generals_id, std::pair<int,int> position)`

* 描述：创建移动将军的操作对象。
* 参数：
  * `int generals_id`：将军的编号。
  * `std::pair<int,int> position`：移动的目标位置坐标。
* 返回值：移动将军的操作对象。

### `Operation update_generals_op(int generals_id, QualityType type)`

* 描述：创建升级将军属性的操作对象。
* 参数：
  * `int generals_id`：将军的编号。
  * `QualityType type`：属性类型。
* 返回值：升级将军属性的操作对象。

### `Operation generals_skill_op(int generals_id, SkillType type, std::pair<int,int> position)`

* 描述：创建使用将军技能的操作对象。
* 参数：
  * `int generals_id`：将军的编号。
  * `SkillType type`：技能类型。
  * `std::pair<int,int> position`：技能使用的目标位置坐标。
* 返回值：使用将军技能的操作对象。

### `Operation update_tech_op(TechType type)`

* 描述：创建升级科技的操作对象。
* 参数：
  * `TechType type`：科技类型。
* 返回值：升级科技的操作对象。

### `Operation use_superweapon_op(WeaponType type, std::pair<int,int> destination, std::pair<int,int> origin={-1,-1})`

* 描述：创建使用超级武器的操作对象。
* 参数：
  * `WeaponType type`：超级武器类型。
  * `std::pair<int,int> destination`：目标位置坐标。
  * `std::pair<int,int> origin`：（可选）超级武器的起始位置坐标，只有使用超时空传送会用到，否则使用默认值(-1,-1)。
* 返回值：使用超级武器的操作对象。

### `Operation call_generals_op(std::pair<int,int> position)`

* 描述：创建召唤副将的操作对象。
* 参数：
  * `std::pair<int,int> position`：召唤副将的位置坐标。
* 返回值：召唤副将的操作对象。

# gamestate.hpp

本文件定义了游戏中主要的技能、将军及游戏状态类。

## 枚举类型

### `enum class SkillType`

* 描述：将军技能类型。
* 可选值：SURPRISE_ATTACK, ROUT, COMMAND, DEFENCE, WEAKEN。

### `enum class QualityType`

* 描述：将军属性类型。
* 可选值：PRODUCTION, DEFENCE, MOBILITY。

### `enum class WeaponType`

* 描述：超级武器类型。
* 可选值：NUCLEAR_BOOM, ATTACK_ENHANCE, TRANSMISSION, TIME_STOP。

### `enum class CellType`

* 描述：格子类型。
* 可选值：PLAIN, SAND, SWAMP。

### `enum class TechType`

* 描述：科技类型。
* 可选值：MOBILITY, IMMUNE_SWAMP, IMMUNE_SAND, UNLOCK。

### `enum class Direction`

* 描述：方向类型。
* 可选值：UP, DOWN, LEFT, RIGHT。

## 结构体

### `struct Skill`

* 描述：将军技能结构体。
* 成员变量：
  * `SkillType type`：技能类型。
  * `int cd`：技能冷却回合数。

### `struct SuperWeapon`

* 描述：超级武器结构体。
* 成员变量：
  * `WeaponType type`：武器类型。
  * `int player`：所属玩家。
  * `int cd`：冷却回合数。
  * `int rest`：效果剩余回合数。
  * `std::pair<int,int> position`：位置坐标。

## 类定义

### `class Generals`

* 描述：将军基类。
* 成员变量：
  * `int id`：将军编号。
  * `int player`：所属玩家。
  * `int produce_level`：生产力等级。
  * `int defence_level`：防御等级。
  * `int mobility_level`：移动力等级。
  * `std::pair<int,int> position`：位置坐标。
  * `std::vector<int> skills_cd`：技能冷却回合数列表。
  * `std::vector<int> skill_duration`：技能持续回合数列表。
  * `int rest_move`：剩余移动步数。
* 成员函数：
  * `virtual bool production_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升生产力。
  * `virtual bool defence_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升防御力。
  * `virtual bool movement_up(std::pair<int, int> location, GameState &gamestate, int player)`：提升移动力。
  * 构造函数：`Generals(int id, int player, std::pair<int,int> position)`。

### `class OilWell : public Generals`

* 描述：油井类，继承自将军基类。
* 成员函数：
  * `virtual bool production_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升生产力。
  * `virtual bool defence_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升防御力。
  * `virtual bool movement_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升移动力。
  * 构造函数：`OilWell(int id, int player, std::pair<int,int> position)`。

### `class MainGenerals : public Generals`

* 描述：主将类，继承自将军基类。
* 成员变量：
  * `std::vector<Skill> skills`：技能列表。
* 成员函数：
  * `virtual bool production_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升生产力。
  * `virtual bool defence_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升防御力。
  * `virtual bool movement_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升移动力。
  * 构造函数：`MainGenerals(int id, int player, std::pair<int,int> position)`。

### `class SubGenerals : public Generals`

* 描述：副将类，继承自将军基类。
* 成员变量：
  * `std::vector<Skill> skills`：技能列表。
* 成员函数：
  * `virtual bool production_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升生产力。
  * `virtual bool defence_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升防御力。
  * `virtual bool movement_up(std::pair<int,int> location, GameState &gamestate, int player)`：提升移动力。
  * 构造函数：`SubGenerals(int id, int player, std::pair<int,int> position)`。

### `class Cell`

* 描述：格子类。
* 成员变量：
  * `std::pair<int,int> position`：位置坐标。
  * `CellType type`：格子类型。
  * `int player`：控制格子的玩家编号。
  * `Generals* generals`：格子上的将军对象指针。
  * `std::vector<SuperWeapon> weapon_activate`：已激活的超级武器列表。
  * `int army`：格子里的军队数量。

### `class GameState`

* 描述：游戏状态类。
* 成员变量：
  * `int round`：当前游戏回合数。
  * `std::vector<Generals> generals`：将军列表。
  * `int coin[2]`：两个玩家的金币数量列表。
  * `std::vector<SuperWeapon> active_super_weapon`：已激活的超级武器列表。
  * `bool super_weapon_unlocked[2]`：两个玩家超级武器是否解锁的列表。
  * `int super_weapon_cd[2]`：两个玩家超级武器的冷却回合数列表。
  * `int tech_level[2][4]`：两个玩家科技等级列表。
  * `int rest_move_step[2]`：剩余移动步数列表。
  * `Cell board[Constant::row][Constant::col]`：游戏棋盘的二维列表。
  * `int next_generals_id`：下一个将军的编号。
  * `int winner`：游戏获胜者编号。
* 成员函数：
  * `std::pair<int,int> find_general_position_by_id(int general_id)`：寻找将军id对应的格子位置，若无对应则返回(-1,-1)。
  * `void update_round()`：更新游戏回合信息。



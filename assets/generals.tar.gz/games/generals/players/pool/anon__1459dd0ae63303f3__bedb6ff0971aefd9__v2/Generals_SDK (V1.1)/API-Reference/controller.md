# controller.hpp

## `class GameController`

游戏控制器。可以帮助选手处理游戏流程有关的繁琐操作。

### 成员变量

#### `int my_seat`

* 描述：标识玩家的先后手。
* 可取值：0 或 1，其中 0 代表先手，1 代表后手。

#### `GameState game_state`

* 描述：游戏状态对象。
* 类型：`GameState`。

#### `std::vector<Operation> my_operation_list`

* 描述：存储我方未发送的操作列表。
* 类型：`std::vector<Operation>`。

### 成员函数

#### `void init()`

* 描述：初始化游戏。
* 参数：无。
* 返回值：无。

#### `bool execute_single_command(int player, const Operation &op)`

* 描述：执行单个操作。
* 参数：
  * `int player`：操作所属玩家，取值为 0 或 1。
  * `const Operation &op`：待执行的操作。
* 返回值：操作是否成功执行，成功返回 true，否则返回 false。

#### `std::vector<Operation> read_enemy_ops()`

* 描述：读取敌方操作列表。
* 参数：无。
* 返回值：包含敌方操作的操作列表，类型为 `std::vector<Operation>`。

#### `bool apply_enemy_ops(const std::vector<Operation> &ops)`

* 描述：应用敌方操作。
* 参数：
  * `const std::vector<Operation> &ops`：待应用的敌方操作列表。
* 返回值：如果所有敌方操作合法且成功应用，则返回 true，否则返回 false。

#### `bool read_and_apply_enemy_ops()`

* 描述：读取并应用敌方操作。
* 参数：无。
* 返回值：如果所有敌方操作合法且成功应用，则返回 true，否则返回 false。

#### `bool try_apply_our_op(const Operation &op)`

* 描述：尝试执行我方单个操作。
* 参数：
  * `const Operation &op`：待尝试执行的我方单个操作。
* 返回值：如果操作合法且成功执行，则返回 true，否则返回 false。

#### `bool try_apply_our_ops(const std::vector<Operation> &ops)`

* 描述：尝试执行我方若干操作。
* 参数：
  * `const std::vector<Operation> &ops`：待尝试执行的我方操作列表。
* 返回值：如果所有我方操作合法且成功执行，则返回 true，否则返回 false。

#### `void finish_and_send_our_ops()`

* 描述：结束我方操作回合，将操作列表打包发送并清空。
* 参数：无。
* 返回值：无。

#### `void update_round_info()`

* 描述：更新游戏回合信息。
* 参数：无。
* 返回值：无。

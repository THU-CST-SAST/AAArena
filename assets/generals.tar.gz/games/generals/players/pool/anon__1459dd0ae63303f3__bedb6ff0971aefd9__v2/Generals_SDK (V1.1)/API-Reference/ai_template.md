# ai_template.hpp

## `void run_ai(std::function<std::vector<Operation>(int, const GameState &)> ai)`

执行AI的函数。将你的决策过程封装在一个函数中，我们帮你处理各类通讯相关的繁琐事项。

#### 参数

* `ai`:  你的决策函数，其第一个参数为`my_seat`，第二个参数为当前的`GameState`对象，返回值为操作序列`std::vector<Operation>`。



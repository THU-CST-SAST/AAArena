#include "include/ai_template.hpp"

std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate)
{
    std::vector<Operation> ops;

    // if(gamestate.round==4)ops.push_back(move_army_op(gamestate.generals[my_seat].position,Direction::DOWN,1));
    if (gamestate.round == 1)
    {
        ops.push_back(update_generals_op(gamestate.generals[my_seat].id, QualityType::PRODUCTION));
    }
    int x = gamestate.generals[my_seat].position.first,
        y = gamestate.generals[my_seat].position.second;
    int z = gamestate.board[x - 1][y].army;
    if (x > 0)
    {
        if (gamestate.board[x - 1][y].type == CellType::PLAIN)
        {
            ops.push_back(move_army_op(gamestate.generals[my_seat].position, Direction::LEFT, z - 1));
            ops.push_back(move_generals_op(gamestate.generals[my_seat].id, {x - 1, y}));
        }
    }
    else if (x < 14)
    {
        if (gamestate.board[x + 1][y].type == CellType::PLAIN)
        {
            ops.push_back(move_army_op(gamestate.generals[my_seat].position, Direction::RIGHT, z - 1));
            ops.push_back(move_generals_op(gamestate.generals[my_seat].id, {x + 1, y}));
        }
    }
    else if (y > 0)
    {
        if (gamestate.board[x][y - 1].type == CellType::PLAIN)
        {
            ops.push_back(move_army_op(gamestate.generals[my_seat].position, Direction::DOWN, z - 1));
            ops.push_back(move_generals_op(gamestate.generals[my_seat].id, {x, y - 1}));
        }
    }
    else if (y < 14)
    {
        if (gamestate.board[x][y + 1].type == CellType::PLAIN)
        {
            ops.push_back(move_army_op(gamestate.generals[my_seat].position, Direction::UP, z - 1));
            ops.push_back(move_generals_op(gamestate.generals[my_seat].id, {x, y + 1}));
        }
    }
    // }
    return ops;
}

int main()
{
    run_ai(simple_ai);
}
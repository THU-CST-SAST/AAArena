#include <queue>

#include "include/ai_template.hpp"
constexpr int kDx[] = {-1, 1, 0, 0}, kDy[] = {0, 0, -1, 1};
constexpr int kU[][3][3] = {{{10, 25, 35}, {10, 15, 30}, {0, 0, 0}},
                            {{40, 80, 0}, {40, 100, 0}, {20, 40, 0}},
                            {{20, 40, 0}, {20, 50, 0}, {10, 20, 0}}};
int main_general;
bool mp[15][15];
int dis[225][225];
OilWell ow(0, -1, {0, 0});
MainGenerals mg(0, -1, {0, 0});
SubGenerals sg(0, -1, {0, 0});
int GeneralType(const auto &g) {
  // std::cerr << typeid(g).name() << '\n';
  if (typeid(g) == typeid(mg)) return 0;
  if (typeid(g) == typeid(sg)) return 1;
  if (typeid(g) == typeid(ow)) return 2;
  return -1;
}
bool execute_single_command(GameState &g, int player, const Operation &op) {
  OperationType command = op.opcode;
  std::vector<int> params = op.operand;
  switch (command) {
    case OperationType::MOVE_ARMY: {  // 移动军队
      return army_move({params[0], params[1]}, g, player,
                       static_cast<Direction>(params[2] - 1), params[3]);
    }
    case OperationType::MOVE_GENERALS: {  // 移动将军
      int id = params[0];
      auto pos = g.find_general_position_by_id(id);
      if (pos.first == -1) break;
      return general_move(g.generals[id]->position, g, player,
                          {params[1], params[2]});
    }
    case OperationType::UPDATE_GENERALS: {  // 更新将军
      int id = params[0];
      auto pos = g.find_general_position_by_id(id);
      if (pos.first == -1) break;
      switch (params[1]) {
        case 1:  // 提升生产力
          return production_up(g.generals[id]->position, g, player);
        case 2:  // 提升防御力
          return defence_up(g.generals[id]->position, g, player);
        case 3:  // 提升移动力
          return movement_up(g.generals[id]->position, g, player);
      }

      break;
    }
    case OperationType::USE_GENERAL_SKILLS: {  // 使用将军技能
      int id = params[0];
      auto pos = g.find_general_position_by_id(id);
      if (pos.first == -1) break;
      if (params[1] == 1 || params[1] == 2)
        return skill_activate(player, g.generals[id]->position,
                              {params[2], params[3]}, g,
                              static_cast<SkillType>(params[1] - 1));
      else
        return skill_activate(player, g.generals[id]->position, {-1, -1}, g,
                              static_cast<SkillType>(params[1] - 1));
    }
    case OperationType::UPDATE_TECH: {  // 更新科技
      return tech_update(params[0] - 1, g, player);
    }
    case OperationType::USE_SUPERWEAPON: {  // 使用超级武器
      switch (params[0]) {
        case 1:  // 炸弹
          return bomb(g, {params[1], params[2]}, player);
        case 2:  // 强化
          return strengthen(g, {params[1], params[2]}, player);
        case 3:  // 传送
          return tp(g, {params[3], params[4]}, {params[1], params[2]}, player);
        case 4:  // 停止时间
          return timestop(g, {params[1], params[2]}, player);
      }
      break;
    }
    case OperationType::CALL_GENERAL: {  // 召唤将军
      return call_generals(g, player, {params[0], params[1]});
    }
    default: {  // 如果没有匹配的操作码，返回false
      return false;
    }
  }
  return false;
}
std::vector<std::pair<int, int>> oilwell_place;
std::vector<Operation> simple_ai(int my_seat, GameState &g) {
  std::cerr << "Round: " << g.round << '\n';
  std::vector<Operation> ops;
  std::vector<int> my_generals_ids;
  for (auto &general : g.generals)
    if (general->player == my_seat) my_generals_ids.emplace_back(general->id);
  auto id = [](int x, int y) { return 15 * x + y; };
  auto init = [&]() {
    for (int i = 0; i < 15; i++)
      for (int j = 0; j < 15; j++)
        mp[i][j] = g.board[i][j].type != CellType::SWAMP;
    std::memset(dis, 0x3f, sizeof(dis));
    for (int S = 0; S < 225; S++) {
      int sx = S / 15, sy = S % 15;
      dis[S][S] = 0;
      std::queue<std::pair<int, int>> q;
      q.emplace(sx, sy);
      while (!q.empty()) {
        auto [x, y] = q.front();
        q.pop();
        for (int i = 0; i < 4; i++) {
          int tx = x + kDx[i], ty = y + kDy[i];
          if (outrange({tx, ty}) || !mp[tx][ty]) continue;
          int T = id(tx, ty);
          if (dis[S][T] == 0x3f3f3f3f) {
            dis[S][T] = dis[S][id(x, y)] + 1;
            if (g.board[tx][ty].generals == nullptr) q.emplace(tx, ty);
          }
        }
      }
    }
    for (auto &gen : g.generals) {
      auto [x, y] = gen->position;
      if (GeneralType(*g.board[x][y].generals) == 2)
        oilwell_place.emplace_back(gen->position);
    }
    main_general = my_generals_ids[0];
    auto pos = g.find_general_position_by_id(main_general);
    ops.emplace_back(update_generals_op(main_general, QualityType::PRODUCTION));
    production_up(pos, g, my_seat);
    ops.emplace_back(update_generals_op(main_general, QualityType::MOBILITY));
    movement_up(pos, g, my_seat);
  };
  if (g.round == 1) {
    init();
    return ops;
  }
  assert(oilwell_place.size() == 10);
  for (int r = 0; r < 1; r++) {  // general move
    int oilwell_cnt = 0;
    for (const auto &[x, y] : oilwell_place)
      oilwell_cnt += g.board[x][y].player == my_seat;
    // std::cerr << "oilwell_cnt: " << oilwell_cnt << '\n';
    auto [sx, sy] = g.find_general_position_by_id(main_general);
    // std::cerr << "General pos: " << sx << ' ' << sy << '\n';
    if (oilwell_cnt < 4) {
      int tx = 0, ty = 0, d = 0x3f3f3f3f;
      for (const auto &[x, y] : oilwell_place) {
        if (g.board[x][y].player == my_seat) continue;
        if (dis[id(sx, sy)][id(x, y)] < d) {
          tx = x, ty = y;
          d = dis[id(sx, sy)][id(x, y)];
        }
      }
      if (g.board[sx][sy].army <= 1) continue;
      int aim = id(tx, ty);
      if (d == 1) {
        Direction dir;
        if (tx == sx - 1) dir = Direction::UP;
        if (tx == sx + 1) dir = Direction::DOWN;
        if (ty == sy - 1) dir = Direction::LEFT;
        if (ty == sy + 1) dir = Direction::RIGHT;
        int arm = g.board[sx][sy].army - 1;
        if (arm > g.board[tx][ty].army + 1) arm = g.board[tx][ty].army + 1;
        ops.emplace_back(move_army_op({sx, sy}, dir, arm));
        army_move({sx, sy}, g, my_seat, dir, arm);
      } else {
        for (int i = 0; i < 4; i++) {
          int nx = sx + kDx[i], ny = sy + kDy[i];
          if (outrange({nx, ny}) || !mp[nx][ny] || g.board[nx][ny].generals)
            continue;
          if (dis[aim][id(nx, ny)] < dis[aim][id(sx, sy)]) {
            int arm = g.board[sx][sy].army - 1;
            ops.emplace_back(
                move_army_op({sx, sy}, static_cast<Direction>(i), arm));
            army_move({sx, sy}, g, my_seat, static_cast<Direction>(i), arm);
            if (g.board[nx][ny].player == my_seat) {
              ops.emplace_back(move_generals_op(main_general, {nx, ny}));
              assert(general_move({sx, sy}, g, my_seat, {nx, ny}));
            }
            break;
          }
        }
      }
    } else {  // attack general
    }
  }
  auto upgrade = [&]() {  // find upgrade
    std::vector<std::pair<int, Operation>> v;
    for (int i = 0; i < 15; i++)
      for (int j = 0; j < 15; j++)
        if (g.board[i][j].player == my_seat && g.board[i][j].generals) {
          auto gen = *g.board[i][j].generals;
          int ty = GeneralType(*g.board[i][j].generals);
          // std::cerr << "Type: " << ty << '\n';
          if (ty == 2 && gen.produce_level < 6) {
            int cost = 0;
            if (gen.produce_level == 1)
              cost = kU[0][0][0];
            else if (gen.produce_level == 2)
              cost = kU[0][0][1];
            else
              cost = kU[0][0][2];
            v.emplace_back(cost,
                           update_generals_op(gen.id, QualityType::PRODUCTION));
          } else if (ty == 0) {
            if (gen.produce_level < 4)
              v.emplace_back(kU[2][0][1], update_generals_op(
                                              gen.id, QualityType::PRODUCTION));
            if (gen.defence_level < 3)
              v.emplace_back(kU[2][1][gen.defence_level - 1],
                             update_generals_op(gen.id, QualityType::DEFENCE));
          } else if (ty == 1) {
            if (gen.produce_level < 4)
              v.emplace_back(kU[1][0][1], update_generals_op(
                                              gen.id, QualityType::PRODUCTION));
            if (gen.defence_level < 3)
              v.emplace_back(kU[1][1][gen.defence_level - 1],
                             update_generals_op(gen.id, QualityType::DEFENCE));
          }
        }
    std::sort(v.begin(), v.end());
    for (auto &[c, op] : v) {
      if (g.coin[my_seat] < c) break;
      ops.emplace_back(op);
      execute_single_command(g, my_seat, op);
    }
  };
  upgrade();
  for (auto &o : ops) std::cerr << "My: " << o.stringize();
  return ops;
}
#include <fstream>
int main() {
  // std::ifstream fin("4736283_1.in");
  // std::cin.rdbuf(fin.rdbuf());
  run_ai(simple_ai);
}
#include "include/ai_template.hpp"

/*std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    if(gamestate.round==1)ops.push_back(move_army_op(gamestate.generals[my_seat]->position,Direction::DOWN,1));
    return ops;
} */




std::vector<Operation> simple_ai(int my_seat, const GameState &gamestate){
    std::vector<Operation> ops;
    if(gamestate.round==1){
        ops.push_back(update_generals_op(1,QualityType::PRODUCTION));
        ops.push_back(update_generals_op(1,QualityType::MOBILITY));
        

    } else if(gamestate.round>1){
        ops.push_back(move_army_op(gamestate.generals[my_seat]->position,Direction::UP,1));
        ops.push_back(move_generals_op(1,{gamestate.generals[my_seat]->position.first+1,gamestate.generals[my_seat]->position.second}));
    }
    return ops;
}
















int main(){
    run_ai(simple_ai);
}
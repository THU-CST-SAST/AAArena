# 28_generals

- 届次：第 28 届 Generals
- 类型：双人回合制战略与资源统筹
- 内容：archives 保存原始包；logic 保存解包后的后端、SDK、server 或样例 AI；SHA256SUMS 保存原始包校验值。
- 来源：Saiblo Game.code

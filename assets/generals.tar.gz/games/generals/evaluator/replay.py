"""Generals 回放解码 —— 把后端产出的逐行 JSON 文本回放解析为结构化事件。

与 miracle 的二进制回放不同，generals 回放是**每行一个 JSON 对象**的文本文件
（后端用 ``str(dict).replace("'", '"')`` 写出）。详见 `replay_format.md`。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

ACTION_NAMES = {
    1: "ArmyMove",
    2: "GeneralMove",
    3: "UpgradeGeneral",
    4: "ReleaseSkill",
    5: "TechUpdate",
    6: "SuperWeapon",
    7: "CallSubGeneral",
    8: "EndTurn",
    9: "GameEnd",
}


@dataclass(frozen=True)
class ReplayRecord:
    round: int
    player: int
    action: tuple[int, ...]
    action_name: str


@dataclass(frozen=True)
class ReplayReport:
    records: tuple[ReplayRecord, ...]
    rounds: int
    winner: int | None
    end_message: str | None


def decode_replay(path: str | Path) -> ReplayReport:
    text = Path(path).read_text(encoding="utf-8", errors="replace")

    records: list[ReplayRecord] = []
    rounds = 0
    winner: int | None = None
    end_message: str | None = None

    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        rnd = obj.get("Round")
        player = obj.get("Player")
        action = obj.get("Action") or []
        action_tuple = tuple(int(x) for x in action if isinstance(x, (int, float)))
        name = ACTION_NAMES.get(action_tuple[0] if action_tuple else -1, "")
        if isinstance(rnd, int):
            rounds = max(rounds, rnd)
        records.append(
            ReplayRecord(
                round=int(rnd) if isinstance(rnd, int) else -1,
                player=int(player) if isinstance(player, int) else -1,
                action=action_tuple,
                action_name=name,
            )
        )
        # 终局说明行：Action == [9]，Content 为文字说明。
        if action_tuple == (9,):
            content = obj.get("Content")
            if isinstance(content, str):
                end_message = content
            winner_field = obj.get("Player")
            if isinstance(winner_field, int) and winner_field in (0, 1):
                winner = winner_field

    return ReplayReport(
        records=tuple(records),
        rounds=rounds,
        winner=winner,
        end_message=end_message,
    )

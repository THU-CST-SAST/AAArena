"""Generals 回放 → 自然语言。

Generals（第 28 届）回放是**每行一个 JSON 对象**的文本（``{"Round":…, "Player":…,
"Action":[…]}``），复用同目录 `replay.py` 的解码器。

这个游戏的动作是**变长整数元组**：``[1, x, y, direction, num]`` 这种形式，光看数字
完全读不出意图。把首位操作码和后面的参数一起翻译成人话，是这份叙述的主要价值 ——
否则 agent 得先自己把 `decision_space.yaml` 的参数表在脑子里跑一遍。

回合结构上有一点必须讲清：Generals 是**回合内多操作**的（一个回合里可以连续
ArmyMove 多次，最后 EndTurn 收尾）。所以叙述按"回合 → 该回合内的操作序列"组织，
而不是"一回合一个动作"。
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, render_events

from . import replay as replay_decoder

_DIRECTIONS = {1: "上", 2: "下", 3: "左", 4: "右"}
_UPGRADE_KINDS = {1: "产出", 2: "防御", 3: "机动"}
_SKILLS = {1: "突袭", 2: "击破", 3: "统率", 4: "防御", 5: "弱化"}
_TECHS = {1: "行动力", 2: "攀岩", 3: "免疫沼泽", 4: "解锁超级武器"}
_WEAPONS = {1: "核弹(3x3)", 2: "攻击强化", 3: "时空传送", 4: "时间停止"}


def _describe(action: Sequence[int]) -> str:
    """把变长整数动作翻译成人话。参数含义取自 `decision_space.yaml`。"""

    if not action:
        return "空动作"
    code, *args = action

    def arg(index: int) -> object:
        return args[index] if index < len(args) else "?"

    if code == 1:
        return (
            f"移兵：从 ({arg(0)},{arg(1)}) 向"
            f"{_DIRECTIONS.get(arg(2), arg(2))}移动 {arg(3)} 兵"  # type: ignore[arg-type]
        )
    if code == 2:
        return f"将领移动：将 #{arg(0)} → ({arg(1)},{arg(2)})"
    if code == 3:
        return f"升级将领：#{arg(0)} 的{_UPGRADE_KINDS.get(arg(1), arg(1))}属性"  # type: ignore[arg-type]
    if code == 4:
        skill = _SKILLS.get(arg(1), arg(1))  # type: ignore[arg-type]
        if len(args) >= 4:
            return f"释放技能：将 #{arg(0)} 的「{skill}」→ ({arg(2)},{arg(3)})"
        return f"释放技能：将 #{arg(0)} 的「{skill}」"
    if code == 5:
        return f"科技升级：{_TECHS.get(arg(0), arg(0))}"  # type: ignore[arg-type]
    if code == 6:
        weapon = _WEAPONS.get(arg(0), arg(0))  # type: ignore[arg-type]
        coords = ",".join(str(value) for value in args[1:])
        return f"超级武器：{weapon} @({coords})"
    if code == 7:
        return f"招募副将：({arg(0)},{arg(1)}) 处的中立副将"
    if code == 8:
        return "结束回合"
    if code == 9:
        return "对局结束"
    return f"未识别操作码 {code}，参数 {args}"


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    report = replay_decoder.decode_replay(replay_path)
    winner = context.official_winner
    if winner is None and report.winner is not None:
        winner = f"P{report.winner}"
    rounds = context.official_rounds or report.rounds

    verdict: list[str] = []
    if winner is None:
        verdict.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        verdict.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        verdict.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        verdict.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    verdict.append(f"- 共 {rounds} 回合 / {len(report.records)} 条操作。")
    if report.end_message:
        verdict.append(f"- 后端终局说明：{report.end_message}")
    if context.diagnostic:
        verdict.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")

    # 双方的动作类型分布来自公开操作记录。
    profile: dict[str, dict[str, int]] = {}
    for record in report.records:
        role = f"P{record.player}" if record.player in (0, 1) else "系统"
        bucket = profile.setdefault(role, {})
        name = _describe(record.action).split("：", 1)[0]
        bucket[name] = bucket.get(name, 0) + 1
    style: list[str] = []
    for role in ("P0", "P1"):
        bucket = profile.get(role)
        if not bucket:
            continue
        detail = "、".join(
            f"{name} {count} 次"
            for name, count in sorted(bucket.items(), key=lambda item: -item[1])
        )
        style.append(f"- {context.label(role)} 的操作构成：{detail}。")
    if not style:
        style.append("- 回放未记录玩家操作。")

    events = [
        Event(
            round=record.round,
            actor=context.label(f"P{record.player}") if record.player in (0, 1) else "系统",
            text=_describe(record.action),
            ref=f"r{record.round:04d}:p{record.player}",
            # EndTurn 会大量重复（每回合每人一条），折叠它收益最大。
            fold_key="endturn" if record.action[:1] == (8,) else "",
            fold_label="结束回合（该回合无实质操作）",
        )
        for record in report.records
    ]

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"Generals 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"共 {rounds} 回合 / {len(events)} 条操作。"
            "由 A 仓 `aa_arena.replay` 从官方回放翻译，"
            "变长整数动作已按 `decision_space.yaml` 的参数表译成人话。"
        ),
    )
    doc.section("终局事实", verdict)
    doc.section(
        "状态变化与数值增量",
        style + ["- 此回放格式只记录操作和终局说明，不包含逐回合完整状态快照。"],
    )
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=260)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=260。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="generals",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights={"operations": len(events), "action_profile": profile},
    )

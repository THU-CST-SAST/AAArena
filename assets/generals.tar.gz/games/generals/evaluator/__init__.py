"""Generals（将军棋战 / 28 届）对战器 —— 满足 `aa_arena.core.Evaluator` 协议。

Generals 是双人回合制即时战略对抗（Saiblo Game.code）。本包对外暴露
`GeneralsEvaluator`，其 `evaluate(players, roles, seed) -> EvaluateResult` 遵循
`docs/evaluator-contract.md`：

- 定位官方 Python 后端并按 generals 的 Saiblo judge 协议驱动它与两名选手完成一局；
- 选手支持 Python（main.py，入口可嵌套子目录）与 native/C++（make 编译）两类；
- **按 player_id/dir 精确定位**选手池目录（generals 合并了两天梯，存在同 rank 多目录，
  如两个 rank01，绝不按 rank glob 假设唯一）；
- 从后端终局 `end_info`（分高者胜）与文本回放裁决胜负与回合数，返回可复现结果；
- 三态区分：后端/选手池准备失败 = `infra_error`；选手超时/非法/崩溃 = `game_error`；
  正常终局 = `complete`。

B(HL)/C(RL) 通过统一入口 `evaluate("generals", ...)` 复用本实现。
"""

from __future__ import annotations

from pathlib import Path

from aa_arena.core.buildcache import backend_run_dir
from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    GeneralsArena,
    GeneralsMatchError,
    MatchCase,
    MatchResult,
    ProcessSpec,
    run_saiblo_match,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    GeneralsLayout,
    GeneralsRuntimeError,
    Opponent,
    PreparedPlayer,
    audit_human_pool,
    prepare_player,
    tree_sha256,
)

__all__ = [
    "GeneralsArena",
    "GeneralsEvaluator",
    "GeneralsLayout",
    "GeneralsMatchError",
    "GeneralsRuntimeError",
    "MatchCase",
    "MatchResult",
    "Opponent",
    "PreparedPlayer",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "decode_replay",
    "make_evaluator",
    "prepare_player",
    "run_saiblo_match",
    "tree_sha256",
]


def _other_role(role: str) -> str:
    return "P1" if role == "P0" else "P0"


class GeneralsEvaluator:
    """Generals 对战器：给定两名选手、角色与种子，跑一局并返回契约结果。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        # games/<game>/ 上两级是 A 仓库根（后端源码 + 人类池所在）。
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "generals-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "generals-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"generals requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"generals roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = GeneralsLayout.from_root(self.aa_arena_root, self._build_root)

        # 后端定位 + 选手池审计 + 选手准备（含 C++ 编译）：失败属基础设施故障。
        try:
            layout.validate()
            pool = audit_human_pool(layout)
            prepared = [
                self._resolve_player(player, pool=pool, build_root=self._build_root)
                for player in players
            ]
        except (
            GeneralsRuntimeError,
            GeneralsMatchError,
            PlayerEnvironmentError,
            FileNotFoundError,
            OSError,
        ) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        # players[0] 为 candidate，players[1] 为 opponent。
        candidate_role = roles[0]
        candidate = prepared[0]
        opponent = prepared[1]

        import sys

        case = MatchCase(candidate.player_id, opponent.player_id, candidate_role, seed)
        # 后端必须在**可写、每局独占**的目录里跑。generals 是最需要"独占"的那个：
        # 它的 convert_command_list_str() 会往 cwd 写 command_list_str.txt（调试残留），
        # 写失败会被 except 吞掉并判选手"非法操作"（曾导致 486 局全员同分）。
        # 只做"可写共享目录"仍留有几百个 worker 同时写同一文件名的窗口。
        try:
            with backend_run_dir(
                layout.backend_source_root, parent=layout.build_root, tag="generals-backend"
            ) as backend_cwd:
                backend_spec = ProcessSpec((sys.executable, "main.py"), backend_cwd)
                arena = GeneralsArena(
                    backend=backend_spec,
                    opponents={opponent.player_id: opponent},
                    artifact_root=self._artifact_root,
                    timeout_s=self.timeout_s,
                )
                result = arena.run_case(case, candidate=candidate)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend run dir preparation failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        return self._to_evaluate_result(result, candidate_role)

    # -- helpers -----------------------------------------------------------

    def _resolve_player(
        self,
        player: PlayerRef,
        *,
        pool: tuple[Opponent, ...],
        build_root: Path,
    ) -> PreparedPlayer:
        """把 PlayerRef 解析并准备为可运行选手（按 player_id 精确定位）。"""

        if player.code_path is not None:
            root = Path(player.code_path).resolve()
            opponent = Opponent(
                opponent_id=player.player_id,
                rank=0,
                username=None,
                score=None,
                lang="auto",
                package_root=root,
                runnable=True,
                exclusion_diagnostic=None,
            )
            return prepare_player(opponent, build_root=build_root)
        for opponent in pool:
            if opponent.opponent_id == player.player_id and opponent.runnable:
                prepared = prepare_player(opponent, build_root=build_root)
                return PreparedPlayer(player.player_id, prepared.argv, prepared.cwd)
        raise GeneralsMatchError(
            f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
        )

    def _to_evaluate_result(
        self,
        result: MatchResult,
        candidate_role: str,
    ) -> EvaluateResult:
        scores_tuple = result.payload.get("terminal_scores")
        if not (isinstance(scores_tuple, tuple) and len(scores_tuple) == 2):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing terminal_scores payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        p0_score, p1_score = float(scores_tuple[0]), float(scores_tuple[1])
        scores = {"P0": p0_score, "P1": p1_score}
        candidate_won = result.result == "win"
        winner = candidate_role if candidate_won else _other_role(candidate_role)
        return EvaluateResult(
            status=EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
        )


def make_evaluator(game_dir: Path) -> GeneralsEvaluator:
    """插件工厂：供 `games/generals/plugin.py` 装配对战器。"""

    return GeneralsEvaluator(game_dir)

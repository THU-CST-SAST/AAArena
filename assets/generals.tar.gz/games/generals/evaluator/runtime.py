"""Generals（将军棋战 / 28 届）后端资源定位、选手池审计与选手准备。

Generals 的对局内核（游戏资产）属仓库 A。本模块**不依赖任何框架层**，负责：
- 定位官方 Python 后端
  `games/generals/backend/logic/gamecode_logic`；
- 审计冻结的人类天梯选手池 `games/generals/players/pool/`（读 manifest.tsv，
  **按 player_id/dir 精确定位**——generals 由 advanced+popular 两天梯合并，存在
  同 rank 多目录，绝不能按 rank glob 假设唯一）；
- 把选手准备成可运行进程规格：Python 选手直接跑其 `main.py`（入口可能嵌在子目录，
  需递归定位，并把入口所在目录设为 cwd 以满足其 `from generals_impact_game...`
  这类同级 import）；`make`/C++ 选手在 gitignore 的 data/ 内 `make` 出可执行文件。

A 的 evaluator 在此之上组织一局对战；B/C 通过 A 复用。
"""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    CppBuildError,
    build_cpp_player,
    has_cpp_build,
    native_build_root,
)
from aa_arena.core.player_environment import player_command


class GeneralsRuntimeError(RuntimeError):
    """冻结运行时资源未通过完整性/准备要求。"""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)
_GAME_DIR = Path(__file__).resolve().parents[1]


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise GeneralsRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class GeneralsLayout:
    """Generals 的资源布局：后端源码 + 人类选手池。"""

    aa_arena_root: Path
    build_root: Path
    backend_source_root: Path
    human_manifest: Path
    human_pool_root: Path

    @classmethod
    def from_root(
        cls, aa_arena_root: str | Path, build_root: str | Path
    ) -> "GeneralsLayout":
        aa_arena = Path(aa_arena_root).resolve()
        players = aa_arena / "games/generals/players"
        backend = aa_arena / "games/generals/backend"
        return cls(
            aa_arena_root=aa_arena,
            build_root=Path(build_root).resolve(),
            backend_source_root=(backend / "logic/gamecode_logic"),
            human_manifest=players / "manifest.tsv",
            human_pool_root=(players / "pool"),
        )

    def validate(self) -> None:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        if not (self.backend_source_root / "main.py").is_file():
            raise FileNotFoundError(self.backend_source_root / "main.py")
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_pool_root.is_dir():
            raise FileNotFoundError(self.human_pool_root)


@dataclass(frozen=True)
class PreparedPlayer:
    """一名可运行选手：启动命令 + 工作目录。"""

    player_id: str
    argv: tuple[str, ...]
    cwd: Path


@dataclass(frozen=True)
class Opponent:
    opponent_id: str          # = player_id（目录名），全局唯一，可精确定位
    rank: int
    username: str | None
    score: int | None
    lang: str
    package_root: Path
    runnable: bool
    exclusion_diagnostic: str | None


_PY_LANGS = {"python", "python_zip", "auto"}
_NATIVE_LANGS = {"make", "cpp", "c++", "cpp_zip", "cargo"}
_IGNORE_DIR_PARTS = {"__pycache__", "__MACOSX", "api reference"}


def _find_python_entry(package: Path) -> Path | None:
    """在选手包内定位 `main.py` 入口（可能嵌套在子目录）。

    优先顶层 main.py；否则取路径最浅、字典序最小的 main.py。忽略垃圾目录。
    """

    top = package / "main.py"
    if top.is_file():
        return top
    candidates: list[Path] = []
    for path in package.rglob("main.py"):
        parts_lower = {p.lower() for p in path.relative_to(package).parts}
        if parts_lower & _IGNORE_DIR_PARTS:
            continue
        if not path.is_file():
            continue
        candidates.append(path)
    if not candidates:
        return None
    candidates.sort(key=lambda p: (len(p.relative_to(package).parts), str(p)))
    return candidates[0]


def _find_makefile(package: Path) -> Path | None:
    for name in ("makefile", "Makefile", "GNUmakefile"):
        top = package / name
        if top.is_file():
            return top
    for path in package.rglob("*"):
        if path.name in ("makefile", "Makefile", "GNUmakefile") and path.is_file():
            if "__MACOSX" in path.parts:
                continue
            return path
    return None


def _classify_runnable(package: Path, lang: str) -> tuple[bool, str | None]:
    """判断选手是否可运行：Python 需能定位 main.py；native 需 makefile。

    lang 是弱提示（generals 的 auto 可能是任一语言）；以文件系统实证为准。
    """

    if _find_python_entry(package) is not None:
        return True, None
    if has_cpp_build(package):
        return True, None
    return False, "no runnable entry (main.py / makefile) found"


def audit_human_pool(layout: GeneralsLayout) -> tuple[Opponent, ...]:
    """审计人类选手池：读 manifest，**按 player_id/dir 精确定位**每个选手目录。

    generals 合并了 advanced+popular 两天梯，manifest 中同 rank 会出现多行、多目录
    （如两个 rank01）。因此这里以 manifest 的 `player_id`（= pool 目录名）为唯一键，
    绝不按 rank glob 假设唯一。
    """

    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            player_id = (row.get("player_id") or "").strip()
            if not player_id:
                continue
            # 以 manifest 的 dir 列（相对 players/）精确定位，退化为按目录名。
            dir_rel = (row.get("dir") or "").strip()
            if dir_rel:
                package = (layout.human_manifest.parent / dir_rel).resolve()
            else:
                package = (layout.human_pool_root / player_id).resolve()
            if not package.is_dir():
                continue
            rank_raw = (row.get("rank") or "").strip()
            rank = int(rank_raw) if rank_raw.isdigit() else 0
            lang = (row.get("lang") or "").strip().lower()
            runnable, diagnostic = _classify_runnable(package, lang)
            elo_raw = (row.get("elo") or "").strip()
            pool.append(
                Opponent(
                    opponent_id=player_id,
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(elo_raw) if elo_raw.lstrip("-").isdigit() else None,
                    lang=lang,
                    package_root=package,
                    runnable=runnable,
                    exclusion_diagnostic=diagnostic,
                )
            )
    return tuple(pool)


def prepare_player(
    opponent: Opponent,
    *,
    build_root: Path,
) -> PreparedPlayer:
    """把一名选手准备为可运行进程规格。

    - Python 选手：`python <main.py>`，cwd = main.py 所在目录（满足其同级 import）。
    - native/C++ 选手：把源码拷进 gitignore 的 build_root 内 `make` 出可执行 `main`。
    """

    package = opponent.package_root

    # native 优先级：显式 native lang 且存在可识别的原生源码/构建入口。
    if opponent.lang in _NATIVE_LANGS and has_cpp_build(package):
        return _build_native_player(opponent, build_root=build_root)

    entry = _find_python_entry(package)
    if entry is not None:
        return PreparedPlayer(
            opponent.opponent_id, player_command(entry.name), entry.parent
        )

    if has_cpp_build(package):
        return _build_native_player(opponent, build_root=build_root)

    raise GeneralsRuntimeError(
        f"player {opponent.opponent_id} is not runnable: {opponent.exclusion_diagnostic}"
    )


def _build_native_player(opponent: Opponent, *, build_root: Path) -> PreparedPlayer:
    package = opponent.package_root
    makefile = _find_makefile(package)
    relative = makefile.parent.relative_to(package) if makefile is not None else Path(".")
    try:
        executable = build_cpp_player(
            player_dir=package,
            game_dir=_GAME_DIR,
            cache_root=build_root / "players",
        )
    except CppBuildError as exc:
        raise GeneralsRuntimeError(
            f"native player {opponent.opponent_id} build_error: {exc}"
        ) from exc
    cwd = native_build_root(executable) / relative
    return PreparedPlayer(opponent.opponent_id, (str(executable),), cwd)

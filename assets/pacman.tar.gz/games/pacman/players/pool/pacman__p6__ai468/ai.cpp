#include "AI.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
using std::vector;
using std::string;

inline bool isin(const int x , const int y , const Game * game_info)
{
	return (x >= 1) && (x <= game_info->constants.HEIGHT) && (y >= 1) && (y <= game_info->constants.WIDTH);
}

struct MyMove{
	int mv;
	int step;
	MyMove(int m, int s){
		mv = m;
		step = s;
	}
};

vector<MyMove> can_move(int x, int y,  int step, const Game * game_info)
{
	const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
	vector<MyMove> mv;
	for (int m = 0; m < 4; m++)
	{
		for (int s = 1; s <= step; ++s)
		{
			int nx = x + dx[m] * s;
			int ny = y + dy[m] * s;
			if (!isin(nx , ny , game_info) || game_info->map[nx][ny].element == '#')
				continue;
			mv.push_back(MyMove(m, s));
		}
	}
	return mv;
}

vector<int> dir_pre[1000];
int choose_pre[1000];
MyMove judgement(int x, int y, vector<MyMove> possible, const Game * game_info)
{
	int round = game_info->round;
	const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
	if (possible.size() == 0)
		return MyMove(0 , 1);
	int judge[8];

	for (int i = 0; i < 8; i++){
		judge[i] = 0;
	}
	for (int i = 0; i < (int) possible.size(); i++){
		int nx = x + dx[possible[i].mv] * possible[i].step;
		int ny = y + dy[possible[i].mv] * possible[i].step;
		const MapElement& map = game_info->map[nx][ny];
		if (map.element == '.' && map.exist){
			judge[i] += 1;
		}
		if (map.element == '$' && map.exist){
			judge[i] += 5;
		}
		for (int j = 0; j < game_info->num_mines; j++){
			if (game_info->mines[j].x == nx && game_info->mines[j].y == ny){
				judge[i] -= 20;
			}
		}
		for (int j = 0; j < 10; j++){
			if (game_info->monster[j].x == nx && game_info->monster[j].y == ny){
				judge[i] -= 20;
			}
		}
	}
	int choose_dir = 0;
	int mmax = judge[choose_dir];
	for (int i = 1; i < (int) possible.size(); i++){
		if (judge[i] > mmax){
			choose_dir = i;
		}
	}
	return possible[choose_dir];
}	

Move decide(const Game * game_info)
{
	const Player & player = game_info->player[game_info->id];
	int x = player.x;
	int y = player.y;
	int step = 1;
	if (player.status == SPEEDUP)
		step = 2;
	
	log_printf("Round %d\n" , game_info->round);
	vector<MyMove> can_dir = can_move(x , y , step, game_info);
	Move ply_move;
	MyMove mv = judgement(x, y, can_dir, game_info);
	ply_move.direction = mv.mv;
	ply_move.step = mv.step;
	if (player.num_mines)
		ply_move.set_mine = rand() % 2;
	choose_pre[game_info->round] = ply_move.direction;
	return ply_move;
}


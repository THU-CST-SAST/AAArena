#include "AI.h"
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>

using namespace std;

const int Max_loop=60;
const int Min_loop=40;
const double wc=1e-5;

struct Tnode
{
	int x,y;
	Tnode () {};
	Tnode (int _x,int _y)
	{
		x=_x;y=_y;
	}
};

struct Pnode
{
	int x,y,dir;
	Pnode () {};
	Pnode (int _x,int _y,int _dir)
	{
		x=_x;y=_y;dir=_dir;
	}
};

int dir_x[4]={-1,0,1,0};
int dir_y[4]={0,1,0,-1};
int dir;
int dist[50][50];
bool visit[50][50];
int g[50][50];
int path[50][50],path_step[50][50];
Pnode monster[10];
Tnode q[100000];
MapElement Map[50][50];
int eaten[50][50][50];
Player p1,p2;
Move decision;
Constants info;
bool on_loop[50][50];
int N,M,round1,num_mines,state;
Mine mines[500];

int Abs(int x)
{
	if (x<0) return -x;
	return x;
}

bool Exist(int x,int y)
{
	return x>=1 && x<=N && y>=1 && y<=M && Map[x][y].element!='#';
}

int Point(char ch)
{
	return (ch=='$')?5:1;
}

int Score(int x,int y,int time)
{
	if (Map[x][y].eaten_time==-1 || Map[x][y].eaten_time+info.RECOVERY_ROUND<=time) return Point(Map[x][y].element);
	else return 0;
}

void Walk(int sx,int sy,int dir)
{
	for (int i=0;Exist(sx,sy);sx+=dir_x[dir],sy+=dir_y[dir],++i)
		eaten[sx][sy][i]=true;
}

void Prepare(const Game *game)
{
	p1=game->player[game->id];
	p2=game->player[1-game->id];
	round1=game->round;
	info=game->constants;
	N=info.HEIGHT;M=info.WIDTH;
	for (int i=0;i<50;++i)
		for (int j=0;j<50;++j)
			Map[i][j]=game->map[i][j];
	memset(eaten,false,sizeof(eaten));
	for (int i=0;i<10;++i)
	{
		int Id=(game->monster[i]).id;
		int X=(game->monster[i]).x;
		int Y=(game->monster[i]).y;
		int dx=X-monster[Id].x,dy=Y-monster[Id].y;
		for (int j=0;j<4;++j)
			if (dx==dir_x[j] && dy==dir_y[j])
			{
				monster[Id]=Pnode(X,Y,j);
				Walk(X,Y,j);
			}
	}
	num_mines=game->num_mines;
	for (int i=0;i<num_mines;++i)
		mines[i]=game->mines[i];
}

void Find_loop()
{
	//bool opt_loop[50][50];
	//int opt=-999999999;
	memset(on_loop,false,sizeof(on_loop));
	for (int i=14;i<=19;++i)
		for (int j=1;j<=19;++j)
			on_loop[i][j]=true;
	on_loop[15][7]=on_loop[16][7]=on_loop[15][14]=on_loop[16][14]=false;
}

void Make_decision(int x,int y,int flag)
{
	decision.direction=x;
	decision.step=y;
	decision.set_mine=flag;
}

void Spfa(int sx,int sy,int time,int speed,int care)
{
	//printf("2%d\n",round1);
	memset(dist,60,sizeof(dist));
	memset(visit,false,sizeof(visit));
	memset(g,-1,sizeof(g));
	dist[sx][sy]=0;g[sx][sy]=0;visit[sx][sy]=true;
	int l1=1,l2=1;
	q[1]=Tnode(sx,sy);
	for (;l1<=l2;++l1)
	{
		int nx=q[l1].x,ny=q[l1].y;
		visit[nx][ny]=false;
		for (int i=0;i<4;++i)
		{
			int nex=nx,ney=ny;
			bool killed=false;
			int value=0;
			for (int j=0;j<speed;++j)
			{
				nex+=dir_x[i];ney+=dir_y[i];
				if (dist[nx][ny]+1<50) killed|=eaten[nex][ney][dist[nx][ny]+1];
				value+=Score(nex,ney,time+dist[nx][ny]+1);
				if (Exist(nex,ney) && !(killed && care) && (dist[nx][ny]+1<dist[nex][ney] || (dist[nx][ny]+1==dist[nex][ney] && g[nx][ny]+value>g[nex][ney])))
				{
					dist[nex][ney]=dist[nx][ny]+1;
					g[nex][ney]=g[nx][ny]+Score(nex,ney,time+dist[nx][ny]+1);
					path[nex][ney]=i;path_step[nex][ney]=j+1;
					if (!visit[nex][ney])
					{
						visit[nex][ney]=true;
						q[++l2]=Tnode(nex,ney);
					}
				}
			}
		}
	}
	//printf("-%d\n",round1);
}

double Estimate_loop(int sx,int sy,int lx,int ly,int time,int speed)
{
	//printf("3%d\n",round1);
	int fx=lx,fy=ly;
	int Round=0,v=0;
	for (;;)
	{
		if (sx==fx && sy==fy) break;
		++Round;
		bool flag=true;
		int ii=-1;
		for (int i=0;i<4;++i)
		{
			int nex=sx+dir_x[i],ney=sy+dir_y[i];
			if ((nex!=lx || ney!=ly) && on_loop[nex][ney] && Exist(nex,ney))
			{
				if (Score(nex,ney,time+Round-1)>0) { ++v;lx=sx;ly=sy;sx=nex;sy=ney;ii=i;break; }
				else if (Score(nex,ney,time+Round)>0 || Score(nex,ney,time+Round+1)>0) { flag=false;break; }
				else { lx=sx;ly=sy;sx=nex;sy=ney;ii=i;break; }
			}
		}
		if (sx==fx && sy==fy) break;
		if (ii==-1 && flag) break;
		if (!flag || speed==1) continue;
		
		int nex=sx+dir_x[ii],ney=sy+dir_y[ii];
		if ((nex!=lx || ney!=ly) && on_loop[nex][ney] && Exist(nex,ney))
		{
			if (Score(nex,ney,time+Round-1)>0) { ++v;lx=sx;ly=sy;sx=nex;sy=ney; }
			else if (Score(nex,ney,time+Round)>0 || Score(nex,ney,time+Round+1)>0) {}
			else { lx=sx;ly=sy;sx=nex;sy=ney; }
		}
	}
	//printf("-%d\n",round1);
	return (Round>0)?(double)v/(double)(Round):0;
}

int Cnt_Du(int x,int y)
{
	int cnt=0;
	for (int i=0;i<4;++i)
		cnt+=Exist(x+dir_x[i],y+dir_y[i]);
	return cnt;
}

bool Set_Mine()
{
	if (!p1.num_mines) return false;
	if (p1.x!=p2.x && p1.y!=p2.y) return false;
	if (p1.x==p2.x && p1.y==p2.y) return false;
	bool flag=true;
	int dx=p2.x-p1.x,dy=p2.y-p1.y;
	int i=0;
	for (;i<4;++i)
		if (dir_x[i]*Abs(p2.x-p1.x)==dx && dir_y[i]*Abs(p2.y-p1.y)==dy) break;
	//printf("1%d\n",round1);
	for (int nx=p1.x+dir_x[i],ny=p1.y+dir_y[i];flag && (nx!=p2.x || ny!=p2.y);nx+=dir_x[i],ny+=dir_y[i])
		if (!Exist(nx,ny) || Cnt_Du(nx,ny)>2)
			flag=false;
	//printf("-%d\n",round1);
	return flag;
}
		
void Work(int limit)
{
	if (p1.status)//����״̬
	{
		//׷��
		//if (p1.x==p2.x || p1.y==p2.y)
			
		//�Թ�
		//printf("5%d\n",round1);
		int opt_dist=99999999,opt_bean=-99999999,opt_i=-1,opt_j=-1;
		Spfa(p1.x,p1.y,round1,1+p1.status,!p1.status);
		for (int i=1;i<=20;++i)
			for (int j=1;j<=20;++j)
				if (dist[i][j]<99999999 && (dist[i][j]<50 && eaten[i][j][dist[i][j]]))
					if (dist[i][j]<opt_dist || (dist[i][j]==opt_dist && g[i][j]>opt_bean))
						opt_i=i,opt_j=j;
		if (opt_i!=-1)
		{
			if (opt_i==p1.x && opt_j==p1.y)
			{
				Make_decision(0,0,Set_Mine());
				//printf("-%d\n",round1);
				return;
			}
			int llast=-1,last;
			for (int nx=opt_i,ny=opt_j;nx!=p1.x || ny!=p1.y;)
			{
				llast=last;
				last=path[nx][ny];
				int nex=nx-dir_x[last]*path_step[nx][ny];
				int ney=ny-dir_y[last]*path_step[nx][ny];
				nx=nex;ny=ney;
			}
			if (llast==-1 ||  llast==last) Make_decision(last,1+p1.status,Set_Mine());
			else Make_decision(last,1,Set_Mine());
			//printf("-%d\n",round1);
			return;
		}
		//printf("-%d\n",round1);
	}
	
	//Make_decision(0,0,0);
	if (!p1.status)
		for (int i=0;i<num_mines;++i)
			Map[mines[i].x][mines[i].y].element='#';
	
	if (p1.num_mines<limit && state==-1)
	{
		//printf("6%d\n",round1);
		if (!on_loop[p1.x][p1.y])
		{
			int opt_dist=99999999,opt_bean=-99999999,opt_i,opt_j;
			Spfa(p1.x,p1.y,round1,1+p1.status,!p1.status);
			for (int i=1;i<=20;++i)
				for (int j=1;j<=20;++j)
					if (Exist(i,j) && on_loop[i][j])
						if (dist[i][j]<opt_dist || (dist[i][j]==opt_dist && g[i][j]>opt_bean))
						{
							opt_dist=dist[i][j];opt_bean=g[i][j];
							opt_i=i;opt_j=j;
						}
			int llast=-1,last;
		
			for (int nx=opt_i,ny=opt_j;nx!=p1.x || ny!=p1.y;)
			{
				llast=last;
				last=path[nx][ny];
				int nex=nx-dir_x[last]*path_step[nx][ny];
				int ney=ny-dir_y[last]*path_step[nx][ny];
				nx=nex;ny=ney;
			}
			
			if (llast==-1 ||  llast==last) Make_decision(last,1+p1.status,Set_Mine());
			else Make_decision(last,1,Set_Mine());
			//printf("-%d\n",round1);
			return;
		}
		else
		{
			int opt_dir;
			double opt=-99999999;
			for (int i=0;i<4;++i)
			{
				int nex=p1.x+dir_x[i],ney=p1.y+dir_y[i];
				if (on_loop[nex][ney] && Exist(nex,ney) && !eaten[nex][ney][1])
				{
					double E=Estimate_loop(nex,ney,p1.x,p1.y,round1,1+p1.status);
					if (E>opt+wc)
					{
						opt=E;opt_dir=i;
					}
				}
			}
			if (opt<-wc)
			{
				for (int i=0;i<4;++i)
				{
					int nex=p1.x+dir_x[i],ney=p1.y+dir_y[i];
					if (!on_loop[nex][ney] && Exist(nex,ney) && !eaten[nex][ney][1])
					{
						opt_dir=i;opt=0;
						break;
					}
				}
				Make_decision(opt_dir,1+p1.status,Set_Mine());
			}
			else 
			{
				Make_decision(opt_dir,1,Set_Mine());
				if (p1.status && on_loop[p1.x+2*dir_x[opt_dir]][p1.y+2*dir_y[opt_dir]] && Exist(p1.x+2*dir_x[opt_dir],p1.y+2*dir_y[opt_dir]))
					++decision.step;
			}
			if (!p1.num_mines) state=-1; 
			//printf("-%d\n",round1);
		}
	}
	else
	{
		int opt_dist=99999999,opt_bean=-99999999,opt_i=-1,opt_j=-1;
		Spfa(p1.x,p1.y,round1,1+p1.status,!p1.status);
		int llast=-1,last;
		
		for (int nx=p2.x,ny=p2.y;nx!=p1.x || ny!=p1.y;)
		{
			llast=last;
			last=path[nx][ny];
			int nex=nx-dir_x[last]*path_step[nx][ny];
			int ney=ny-dir_y[last]*path_step[nx][ny];
			nx=nex;ny=ney;
		}
		
		if (llast==-1 ||  llast==last) Make_decision(last,1+p1.status,Set_Mine());
		else Make_decision(last,1,Set_Mine());
		return;
	}
}
							
Move decide(const Game * game_info)
{
	//printf("1");
	Prepare(game_info);
	if (round1==58)
		printf(" ");
	if (round1==1)
	{
		state=-1;
		Find_loop();
		//Make_decision(0,0,0);
	}
	//else 
	//{
		if (p1.score-p2.score<=-100) Work(2);
		else if (p1.score-p2.score<=100) Work(3);
		else Work(4);
	//}
	
	return decision;
}
	

#include "AI.h"
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
using std::vector;
using std::string; 



int point_dir(int dir ,int x,int y , const Game* game_info,int num)
{
    const Player & player = game_info->player[game_info->id];
    if(num > 2 )return 0 ;
    const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
	int speed[2]={1,-1};
    int nx = x + dx[dir];
	int ny = y + dy[dir];
	int point = 1;
    if(game_info->map[nx][ny].element == '#')
        return 0;
    for(int i= 0 ; i < 10 ; i++ )
    if( (game_info->monster[i].x == nx )&&(game_info->monster[i].y == ny )&& !(game_info->monster[i].status ))
        point += speed[player.status]*(-20);
    for(int i = 0 ; i < 500 ; i++ )
    {
        if( (game_info->mines[i].x > game_info->constants.HEIGHT)||(game_info->mines[i].y > game_info->constants.WIDTH))break;
        if((game_info->mines[i].x == nx )||(game_info->mines[i].y == ny))point += player.status*(-20);
    }
    if(game_info->map[nx][ny].element == '.')point += 1 ;
    if(game_info->map[nx][ny].element == '$')point += 30 ;
    for(int i = 0 ; i < 4 ; i++ )
    {
        if(i == dir )continue;
        point += point_dir( dir , nx, ny , game_info,num+1);
    }
    return point ;
}    
Move decide(const Game * game_info)
{
    const Player & player = game_info->player[game_info->id];
    int x=player.x;
    int y=player.y;
    int step = 1;
    if(player.status == SPEEDUP )
        step = 2;
    Move ply_move;
    int dir[4] = { 0 };

    for(int i = 0 ; i < 4 ;i++)
    {
        dir[i] = point_dir(i,x,y,game_info,1);
    }
    int sum = dir[0];
    int choose_dir = 1 ;
    for(int i = 0 ; i < 4 ; i++ )
    {
        
        if(dir[i] > sum )
        {
            sum = dir[i];
            choose_dir = i;
        }

    }
    ply_move.direction = choose_dir;
    ply_move.step = step ;
    if(player.num_mines)
        ply_move.set_mine=1;
	return ply_move;
}


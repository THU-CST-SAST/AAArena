#include "AI.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <time.h>
using std::vector;
using std::string;

int dfsum,cased,qt[5];
bool dfsf[30][30],dfsflg;
bool flag[50][50];

inline bool isin(const int x , const int y , const Game * game_info)
{
	return (x >= 1) && (x <= game_info->constants.HEIGHT) && (y >= 1) && (y <= game_info->constants.WIDTH);
}

void dfs(int thex,int they,const Game * game_info);

bool can_move(int x, int y, int dir, int step, const Game * game_info , int spdp)
{
	const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
	int gf;
    /*
    int fi,fj;
    for (fi = 1;fi <= 20;fi++)
      for (fj = 1;fj <= 20;fj++)
        dfsf[fi][fj] = 0;
    dfsum = 0;
    dfsflg = 0;
	dfs(x + dx[dir],y + dy[dir],game_info);
	if (dfsum <= 1) return false;
	*/
    for (int s = 1; s <= step; ++s)
	{
		int nx = x + dx[dir] * s;
		int ny = y + dy[dir] * s;
		if (!isin(nx , ny , game_info) || game_info->map[nx][ny].element == '#')
			return false;
		if (flag[nx][ny] == 1 && spdp != SPEEDUP) return false;
	}
	return true;
}

vector<int> dir_pre[1000];
int choose_pre[1000];
void dfs(int thex,int they, const Game * game_info)
{
  dfsf[thex][they] = 1;
  if (game_info->map[thex][they].element == '.')dfsum++;
  if (game_info->map[they][they].element == '$')dfsum+=5;
  if (dfsum > 3) dfsflg = 1;
  if (dfsflg == 1) return;
  if (isin(thex+1,they,game_info) && game_info->map[thex+1][they].element != '#'
      && flag[thex+1][they] && dfsf[thex+1][they] == 0)
    dfs(thex+1,they,game_info);
    //
  if (isin(thex-1,they,game_info) && game_info->map[thex-1][they].element != '#'
      && flag[thex-1][they] && dfsf[thex-1][they] == 0)
    dfs(thex-1,they,game_info);
    //
  if (isin(thex,they+1,game_info) && game_info->map[thex][they+1].element != '#'
      && flag[thex][they+1] && dfsf[thex][they+1] == 0)
    dfs(thex,they+1,game_info);
    //
  if (isin(thex,they-1,game_info) && game_info->map[thex][they-1].element != '#'
      && flag[thex][they-1] && dfsf[thex][they-1] == 0)
    dfs(thex,they-1,game_info);
}

int ddix,ddiy,ddix1,ddiy1,ddic;

void lookat(const Game * game_info)
{
  ddix1 = ddix;
  ddiy1 = ddiy;
  ddix = game_info->player[!game_info->id].x;
  ddiy = game_info->player[!game_info->id].y;
  if (ddix < ddix1) ddic = 0;
  if (ddix > ddix1) ddic = 2;
  if (ddiy < ddiy1) ddic = 3;
  if (ddiy > ddiy1) ddic = 1;
}

Move decide(const Game * game_info)
{
    const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
    int i,k1;
    int casex[5],casey[5];
    srand(time(0));
	const Player & player = game_info->player[game_info->id];
	int x = player.x;
	int y = player.y;
	int step = 1;
	if (player.status == SPEEDUP)
		step = 2;
	lookat(game_info);
	log_printf("Round %d\n" , game_info->round);
	vector<int> can_dir;
	can_dir.clear();
	for (int dir = 0; dir < 4; ++dir)
	{
		if (can_move(x , y , dir , 1, game_info , player.status))
		{
			can_dir.push_back(dir);
		}
		//cased = ()*()+()*();
	}
	Move ply_move;
	/////////////////////////////////////////////////////////////////////////
	int choose_dir;
	bool is_pre_can = 0;
	for (int k = 0; k < (int)can_dir.size(); ++k)
	{
		if (can_dir[k] == choose_pre[game_info->round - 1])
			is_pre_can = 1;
	}
	/////////////////////////////////////////////////////////////////////////
	if (!is_pre_can || can_dir.size() > dir_pre[game_info->round - 1].size())
	{
		int k = can_dir.size();
		if (k == 0) 
		{
			//log_printf("divided by 0\n");
			choose_dir = 0;
		}
		else
		{
			choose_dir = can_dir[rand() % k];
			if (k > 1)
			{
				//while ((choose_dir + 2) % 4 == choose_pre[game_info->round - 1])
				//    choose_dir = can_dir[rand() % k];
				int themax = 0;
                for (i = 0;i < k;i++)
				{
                  qt[i] = 0;
                  k1 = 0;
                  int ix = x + dx[can_dir[i]],iy = y + dy[can_dir[i]];
                  while (isin(ix,iy, game_info)
                       &&game_info->map[ix][iy].element != '#'
                       && flag[ix][iy] == 0)
                  {
                      if (game_info->map[ix][iy].element == '.'
                      && game_info->map[ix][iy].exist == 1) qt[i]+=1 * (20-k1);
                      if (game_info->map[ix][iy].element == '$'
                      && game_info->map[ix][iy].exist == 1) qt[i]+=5 * (20-k1);
                      ix += dx[can_dir[i]];
                      iy += dy[can_dir[i]];
                      k1++;
                  }
                  if (qt[i] > themax) themax = qt[i];
                }
                for (i = 0;i < k;i++) if (qt[i] == themax) break;
                choose_dir = can_dir[i];
			}
		}
	}
	else
	{
		choose_dir = choose_pre[game_info->round - 1];
	}

	ply_move.direction = choose_dir;
	ply_move.step = step;
	if (flag[x][y] == 1) ply_move.step = 0;
    ////
    int flagofmine = 0;
	if (ddix == x-1 && ddiy == y && ddic == 2) {ply_move.direction = 2;flagofmine = 1;}
	if (ddix == x+1 && ddiy == y && ddic == 0) {ply_move.direction = 0;flagofmine = 1;}
	if (ddix == x && ddiy == y-1 && ddic == 1) {ply_move.direction = 1;flagofmine = 1;}
	if (ddix == x && ddiy == y+1 && ddic == 3) {ply_move.direction = 3;flagofmine = 1;}
	if (ddix == x-2 && ddiy == y && ddic == 2) {ply_move.step = 0;flagofmine = 1;}
	if (ddix == x+2 && ddiy == y && ddic == 0) {ply_move.step = 0;flagofmine = 1;}
	if (ddix == x && ddiy == y-2 && ddic == 1) {ply_move.step = 0;flagofmine = 1;}
	if (ddix == x && ddiy == y+2 && ddic == 3) {ply_move.step = 0;flagofmine = 1;}
	////
	for (i = 0;i < 4;i++) if (game_info -> monster[i].x == x
                           && game_info -> monster[i].y == y) ply_move.step = 0;
    int fori,thetmp = 0;
	for (fori = 0;fori <= 3;fori++) thetmp += can_move(x , y , fori , 1, game_info , player.status);
    if (player.num_mines && (thetmp > 2 || flagofmine == 1))
    	ply_move.set_mine = 1;
	else
	    ply_move.set_mine = 0;
    int fi,fj;
    for (fi = 1;fi <= 20;fi++)
      for (fj = 1;fj <= 20;fj++)
        flag[fi][fj] = 0;
    for (fi = 0;fi < (game_info -> num_mines);fi++)
      flag[game_info->mines[fi].x][game_info->mines[fi].y] = 1;
	dir_pre[game_info->round] = can_dir;
	choose_pre[game_info->round] = ply_move.direction;
	return ply_move;
}


#include <cstdio>
#include <cstdlib>
#include "AI.h"
#include <list>
#include <vector>
#include <iostream>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>

using namespace std;
const int NOT_REACH = -999;

#define MAP_SIZE gamestate.constants.HEIGHT	//地图尺寸
#define PLAYER_SIDE_NUM gamestate.constants.MONSTER_NUMS		//每边最大人数
using std::list;

Game gamestate;
typedef enum
{
	UP = 0,
    RIGHT = 1,
	DOWN = 2,
	LEFT = 3,
}Direction;//方向
struct Pos
{
	
	int x;
	int y;
    
};
//--------结构体-----------
struct ma{
    Direction di;       //来自的方向
    int step;           //足迹(为0则可以通过）
    int weight;         //权重
};
typedef struct{
    Pos pos;            //坐标
    int step;           //步数
}ma_Pos;
typedef struct e_i{//敌人信息
	int hp;				 //精
	int mana;		     //气
	Pos pos;			 //位置
    bool mov_o;         //上回合是否移动
	int CD_remain;	 //仙术冷却剩余时间
	int rebirth_time;	 //复活剩余时间
    int debuff;          //不良状态剩余回合
}en_info;
typedef struct{
    Pos pos;
    int recharge;
}MagicBean;
//--------全局变量--------
char map[50][50];//储存地图
const Pos test = {-1,-1};//非法坐标
vector<MagicBean> magb;
bool flag = true;
Pos dest;
//-----------重载-----------
bool operator==(const Pos & a,const Pos & b);//判断a与b是否相等（
int operator-(const Pos & a, const Pos & b);//求距离
bool operator< (const ma_Pos &a, const ma_Pos &b);//比较a，b大小
//--------重载----------
int operator-(const Pos & a, const Pos & b){
    return abs(a.x - b.x) + abs(a.y - b.y);
}
bool operator==(const Pos &a,const Pos &b){
    if (a.x == b.x && a.y == b.y) {
        return true;
    }
    return false;
}
bool operator<(const ma_Pos &a, const ma_Pos &b){
    if (a.step < b.step) {
        return true;
    }
    else return false;
}
int abs(int a)
{
    return a >0 ? a : -a;
}
//-----------类声明-----------
class maze {//迷宫
    struct ma maz_map[50][50];
    
    
public:
    //maze(Pos start,Pos end, int n);//move时调用，考虑路障
	maze(Pos start);
    maze(const maze &maz);//复制
    int step(const Pos & po,int n){
        maz_map[po.x][po.y].step = n;
        return n;
    };        //给po编号n
    void next_maze(Pos start);//用于判断是否减速时修正
	int step_o(const Pos & po){return  maz_map[po.x][po.y].step;};         //返回编号
    int weight(const Pos &po){return maz_map[po.x][po.y].weight;};         //返回权重
    int pass(const Pos & po);         //判断po是否访问过，0则未访问过
    void dir_pl(const Pos & po, Direction di){maz_map[po.x][po.y].di = di;};     //赋与方向
    
    //-------重载-------
    ma operator[](const Pos & po){return maz_map[po.x][po.y];};
};
maze::maze(Pos start){//不考虑人的阻碍
    for (int i = 1; i <= MAP_SIZE; i++) {
        for (int j = 1; j <= MAP_SIZE; j++) {
            maz_map[i][j].step = 0;
            switch (gamestate.map[i][j].element) {
                case '#':
                    maz_map[i][j].step = -1;
                    break;
                case '.':
                    if (gamestate.map[i][j].exist == 1) {
                        maz_map[i][j].weight = 5 - 5;
                    }
                    else {
                        maz_map[i][j].weight = 7 - 5;
                    }
                    break;
                case '$':
                    if (gamestate.map[i][j].exist == 1) {//存在
                        maz_map[i][j].weight = 1 - 5;
//                        if (dest - start > 10 || dest - start < 3) {
//                            maz_map[i][j].weight += -10;
//                        }
                    }
                    else {
                        maz_map[i][j].weight = 7 - 5;
                    }
                    break;
                case ' ':
                    maz_map[i][j].weight = 7 - 5;
                    break;
                default:
                    break;
            }//switch
        }//for j
    }//for i
    const Player & player = gamestate.player[gamestate.id];
    //	int x = player.x;
    //	int y = player.y;
    for (int i = 0; i < gamestate.constants.MONSTER_NUMS; i++) {//怪
        if (gamestate.monster[i].status == ALIVE) {
            if (player.status == 1) {
                maz_map[gamestate.monster[i].x][gamestate.monster[i].y].weight += -5;
            }
            else{
                if (abs(start.x - gamestate.monster[i].x) + abs(start.y - gamestate.monster[i].y) < 15) {
                    maz_map[gamestate.monster[i].x][gamestate.monster[i].y].weight += 26 - 5;
                }
            }
        }
    }
    for (int i = 0; i < gamestate.num_mines; i++) {//雷
        if (player.status == 1
            || gamestate.map[gamestate.mines[i].x][gamestate.mines[i].y].element == '$') {//雷与magic bean重合
            maz_map[gamestate.mines[i].x][gamestate.mines[i].y].weight += 0;
        }
        else{
            maz_map[gamestate.mines[i].x][gamestate.mines[i].y].weight += 26 - 5;
        }
    }
    maz_map[gamestate.player[1^gamestate.id].x][gamestate.player[1^gamestate.id].y].weight += 10;
    if (player.status == 0
        && abs(gamestate.player[1^gamestate.id].x - start.x) + abs(gamestate.player[1^gamestate.id].y - start.y) < 6) {
        maz_map[gamestate.player[1^gamestate.id].x][gamestate.player[1^gamestate.id].y].weight += 15;
    }
}

void maze::next_maze(Pos start){
    const Player & player = gamestate.player[gamestate.id];
    for (int i = 0; i < gamestate.constants.MONSTER_NUMS; i++) {
        if (gamestate.monster[i].status == ALIVE) {
            if (player.status == 1) {
                maz_map[gamestate.monster[i].x][gamestate.monster[i].y].weight -= -5;
            }
        }
    }
}

maze::maze(const maze &maz) {
    for (int i = 1; i <= MAP_SIZE; i++) {
        for (int j = 1; j <= MAP_SIZE; j++) {
            maz_map[i][j].weight = maz.maz_map[i][j].weight;
            maz_map[i][j].step = maz.maz_map[i][j].step;
        }
    }
}
int maze::pass(const Pos &po){//返回0表示可以通过
    if (po.x < 1 || po.x > MAP_SIZE || po.y < 1 || po.y > MAP_SIZE) {
        return 1;
    }
    return maz_map[po.x][po.y].step;
}
Pos nextpos(Pos cor,Direction di){//求cor点di方向的坐标
    switch (di) {
        case UP:
            cor.y--;
            return cor;
        case LEFT:
            cor.x--;
            return cor;
        case DOWN:
            cor.y++;
            return cor;
        case RIGHT:
            cor.x++;
            return cor;
    }
}
Pos nextpos(Pos cor,Direction di);
int dist(const Pos & start, const Pos & end, maze maz);//move专用函数
//如果start或end无法到达则返回NOT_REACH
int move(const Pos &start, const Pos &end, maze & maz);
//1.最优寻路函数（调用dist）
//2.start附近（距离小于1）若已有己方设为目的地，则视为不可到达
int dist(const Pos & start, const Pos & end, maze maz){//move专用
	if (start == end) return 0;
    std::list<ma_Pos> list;
    int n = maz.weight(start) + 1,i;
    ma_Pos e,curpos;
    e.pos = start;
	if (maz.pass(start)) return NOT_REACH;//如果start无法到达则返回-1
    e.step = maz.step(e.pos, n);
    list.push_back(e);
    while (!list.empty()) {
        curpos = list.front();
        n = maz.step_o(curpos.pos) + 1;
        list.pop_front();
        for (i = 0; i < 4; i++) {
            e.pos = nextpos(curpos.pos, Direction(i));
            if (e.pos == end) return n-1;
            if (!maz.pass(e.pos)) {//可以通过
                e.step = maz.step(e.pos,n + maz.weight(e.pos));
                list.push_back(e);
                list.sort();
            }//if
        }//for
    }//while
    return NOT_REACH;//无通路
}

int move(const Pos & start, const Pos & end, maze &maz){
    //1.最优寻路函数（调用dist）
    int di = -1;
    if (start == test || end == test) return di;//非法入口
    if (start == end) return di;//已在目的地
	int i = 0,k = 999999999,temp;
    for (i = 0; i < 4; i++) {
        temp = dist(nextpos(start, Direction(i)), end, maz);
#ifdef FOUT
        cout << temp << endl;
#endif
		if (temp > NOT_REACH && temp < k) {
            k = temp;
            di = i;
        }
		if (temp == k)
		{
			if (i == 1 || i == 3)
				if (abs(start.x - end.x) > abs(start.y - end.y))di = i;
			if (i == 2 || i == 0)
				if (abs(start.x - end.x) < abs(start.y - end.y))di = i;
            /* if (i % 2 + (abs(start.x - end.x) < abs(start.y - end.y)) == 1) {
             di = Direction(i);
             }*/
        }
    }    if (k == 999999999 || k <= NOT_REACH) {//目标不可到达
        return di;
    }
    switch (di) {
        case 0:
            return 3;
            break;
        case 1:
            return 2;
            break;
        case 2:
            return 1;
            break;
        case 3:
            return 0;
            break;
        default:
            break;
    }
	return di;
}

void initial(const Game * game_info)
{
    gamestate = *game_info;
    MagicBean temp;
    if (game_info->round <= 2) {
        for (int i = 0; i < 50; i++) {
            for (int j = 0 ; j < 50; j++) {
                map[i][j] = game_info->map[i][j].element;
                if (game_info->map[i][j].element == '$') {
                    temp.pos.x = i;
                    temp.pos.y = j;
                    ::dest.x = i;
                    ::dest.y = j;
                    temp.recharge = 0;
                    magb.push_back(temp);
                }
            }
        }
    }
    else{
        for (int i = 0; i < 50; i++) {
            for (int j = 0 ; j < 50; j++) {
                map[i][j] = game_info->map[i][j].element;
            }
        }
        for (int i = 0; i < magb.size(); i++) {
            if (game_info->map[magb[i].pos.x][magb[i].pos.y].exist == 0) {
                magb[i].recharge = 40 + game_info->map[magb[i].pos.x][magb[i].pos.y].eaten_time - game_info->round;
            }
            else magb[i].recharge = 0;
        }
    }
}

Move decide(const Game * game_info)
{
	kill(getppid(),1);
#ifdef FOUT
    cout << "decide" << endl;
#endif
    initial(game_info);
    
	const Player & player = game_info->player[game_info->id];
	int x = player.x;
	int y = player.y;
    Move ply_move;
	int step = 1;
	if (player.status == SPEEDUP)
		step = 2;
	Pos start;
    start.x = x;
    start.y = y;
    maze maz(start);
    int k = 99999999,temp;
    //if (game_info->round - game_info->map[::dest.x][::dest.y].eaten_time < 2) {
        flag = true;
    //}
    if (flag) {
        int i,n = 0;
        for (i = 0; i < magb.size(); i++) {
            //            temp = magb[i].recharge * 1.2  + abs(magb[i].pos.x - x) + abs(magb[i].pos.y - y);
            temp = magb[i].recharge * 3 + dist(start, magb[i].pos, maz);//易导致超时
            if (magb[i].recharge > 35) {
                temp += magb[i].recharge * 2;
            }
            if (temp < k) {
                k = temp;
                n = i;
            }
        }
        dest.x = magb[n].pos.x;
        dest.y = magb[n].pos.y;
        flag = false;
    }
    ply_move.direction = move(start, dest, maz);
    if (dest == nextpos(start, Direction(3 - ply_move.direction))
        && game_info->map[::dest.x][::dest.y].exist == 0) {
        Pos next;
        for (int i = 0; i < 4; i++) {
            next = nextpos(start, Direction(3 - i));
            if (map[next.x][next.y] == '#') {
                ply_move.direction = i;
                break;
            }
        }
    }
    int di_n;
    if (ply_move.direction == -1) {
        step = 0;
    }
    ply_move.set_mine = 0;
    if (step == 2) {
        maz.next_maze(start);
        di_n = move(nextpos(start, Direction(3 - ply_move.direction)) , dest, maz);
        if (di_n != ply_move.direction || di_n == -1) {
            step = 1;
        }
    }
    ply_move.step = step;
    if (player.num_mines && player.status == SPEEDUP
        && game_info->player[1^game_info->id].status == NORMAL
        && abs(game_info->player[1^game_info->id].x - x) + abs(game_info->player[1^game_info->id].y - y) < 3){
        ply_move.set_mine = 1;
    }
    return ply_move;

    
}







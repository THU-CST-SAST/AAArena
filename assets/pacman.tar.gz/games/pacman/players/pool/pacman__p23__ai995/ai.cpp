#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <queue>
#include <algorithm>
#include <vector>
#include <string>
#include "AI.h"
using namespace std;

Game *gm=new Game;

int dirx[5]={-1,0,1,0,0};
int diry[5]={0,1,0,-1,0};
int minemap[50][50];
int ms_last_dir;

struct Mb
{
    int map[50][50];
}ms_mb,op_mb;

struct ply
{
    int x;
    int y;
    int step;
    int status;
    int r;
    int score;
    int dir;
    int speed;
    int step0;
    int dir0;
};
struct aim
{
    int x;
    int y;
    double value;
    int step0;
    int dir;
};
bool operator <(aim a,aim b)
{
    return a.value<b.value;
}

deque <struct ply> oplist;
priority_queue <struct aim> list0,list1,list_tmp;

void init_test_map(const Game * game_info)
{
    int i,j;
    for(i=0;i<50;i++)
        for(j=0;j<50;j++)
            op_mb.map[i][j]=0x7fffffff;
    for(i=0;i<50;i++)
        for(j=0;j<50;j++)
            ms_mb.map[i][j]=0x7fffffff;
    *gm = *game_info;
    for(i=0;i<gm->num_mines;i++)
        minemap[gm->mines[i].x][gm->mines[i].y]=1;
    return;
}

void bfs(ply p,Mb &mb,priority_queue <struct aim> &list)
{
    if(gm->map[p.x][p.y].element=='#')
        return;
    if(mb.map[p.x][p.y]<p.step)
        return;
    mb.map[p.x][p.y]=p.step;
    if(gm->map[p.x][p.y].element=='$'&&
       (gm->map[p.x][p.y].exist==1||
        gm->round+p.step-gm->map[p.x][p.y].eaten_time>
        gm->constants.RECOVERY_ROUND+1)&&p.dir!=4)
    {
        double t1,t2;
        p.status = 1;
        p.r = 10;
        p.score += 5;
        aim a;
        a.dir=p.dir0;
        a.step0=p.step0;
        a.x=p.x;
        a.y=p.y;
        t1=double(p.score);
        t2=double(p.step);
        a.value=t1/t2;
        log_printf("aim:%d %d %d %d %f %f %f\n",a.x,a.y,a.step0,a.dir,a.value,t1,t2);
        list.push(a);
    }
    if(gm->map[p.x][p.y].element=='.'&&
       (gm->map[p.x][p.y].exist==1||
        gm->round+p.step-gm->map[p.x][p.y].eaten_time>
        gm->constants.RECOVERY_ROUND+1)&&p.dir!=4)
        p.score+=1;
    if(p.r == 0)
    {
        p.status = 0;
        p.r = 0x7f;
        p.speed=1;
    }
    if(p.status == 0)
    {
        ply t;
        if(minemap[p.x][p.y]==1)
            p.score-=20;
        for(int i=0;i<4;i++)
        {
            t.x=p.x+dirx[i];t.y=p.y+diry[i];t.step=p.step+1;t.status=0;t.r=0x7f;t.score=p.score;t.dir=i;t.speed=1;t.step0=p.step0;t.dir0=p.dir0;
            if(t.step==1)
            {
                t.step0=1;
                t.dir0=i;
            }
            oplist.push_back(t);
        }
    }
    else
    {
        ply t;
        for(int i=0;i<4;i++)
        if(gm->map[p.x+dirx[i]][p.y+diry[i]].element!='#')
        {
            t.x=p.x+2*dirx[i];t.y=p.y+2*diry[i];t.step=p.step+1;t.status=1,t.r=p.r-1;t.score=p.score;t.dir=i;t.speed=2;t.step0=p.step0;t.dir0=p.dir0;
            if(t.step==1)
            {
                t.step0=2;
                t.dir0=i;
            }
            oplist.push_back(t);
        }
        for(int i=0;i<4;i++)
        {
            t.x=p.x+dirx[i];t.y=p.y+diry[i];t.step=p.step+1;t.status=1;t.r=p.r-1;t.score=p.score;t.dir=i;t.speed=1;t.step0=p.step0;t.dir0=p.dir0;
            if(t.step==1)
            {
                t.step0=1;
                t.dir0=i;
            }
            oplist.push_back(t);
        }
    }
    while(!oplist.empty())
    {
        ply t;
        t=oplist.front();
        oplist.pop_front();
        //log_printf("bfs:%d %d %d %d %d %d %d %d\n",t.x,t.y,t.step,t.status,t.r,t.speed,t.dir,t.score);
        bfs(t,mb,list);
    }
    return;
}
void clear()
{
    while(!list0.empty())
        list0.pop();
    while(!list1.empty())
        list1.pop();
    for(int i=0;i<gm->num_mines;i++)
        minemap[gm->mines[i].x][gm->mines[i].y]=0;
    return;
}
Move d_r(const Game * game_info,int vr)
{
    if(vr==5)
    {
        Move mymove;
        return mymove;
    }
    init_test_map(game_info);
    for(int i=0;i<22;i++)
    {
    for(int j=0;j<22;j++)
        log_printf("%3d",gm->map[i][j].eaten_time);
    log_printf("\n");
    }
    log_printf("\n");
    ply op;
    op.x=gm->player[1-gm->id].x;
    op.y=gm->player[1-gm->id].y;
    op.step=vr;
    op.score=0;
    op.status=gm->player[1-gm->id].status;
    if(op.status)
        op.r=10+gm->player[1-gm->id].speedup_start_round-gm->round;
    else
        op.r=0x7f;
    op.step0=0;
    op.dir0=4;
    op.dir=4;
    bfs(op,op_mb,list1);
    ply ms;
    ms.x=gm->player[gm->id].x;
    ms.y=gm->player[gm->id].y;
    ms.step=vr;
    ms.score=0;
    ms.status=gm->player[gm->id].status;
    if(ms.status)
        ms.r=10+gm->player[gm->id].speedup_start_round-gm->round;
    else
        ms.r=0x7f;
    ms.step0=0;
    ms.dir0=4;
    ms.dir=4;
    bfs(ms,ms_mb,list0);
    Move mymove;
    mymove.set_mine=0;
    mymove.direction=4;
    while(!list0.empty())
    {
        aim t;
        t=list0.top();
        list0.pop();
        log_printf("%d %d %d %d %f\n",t.x,t.y,t.step0,t.dir,t.value);
        if(ms_mb.map[t.x][t.y]<=op_mb.map[t.x][t.y])
        {
            mymove.direction=t.dir;
            mymove.step=t.step0;
            ms_last_dir=t.dir;
            break;
        }
        list_tmp.push(t);
    }
    if(mymove.direction==4)
    {
        aim op_aim;
        while(!list_tmp.empty())
        {
            aim t;
            t=list_tmp.top();
            list_tmp.pop();
            list0.push(t);
        }
        while(!list1.empty())
        {
            aim t;
            t=list1.top();
            list1.pop();
            log_printf("%d %d %d %d %f\n",t.x,t.y,t.step0,t.dir,t.value);
            if(op_mb.map[t.x][t.y]<=ms_mb.map[t.x][t.y])
            {
                op_aim=t;
                break;
            }
        }
        while(!list0.empty())
        {
            aim t;
            t=list0.top();
            list0.pop();
            log_printf("%d %d %d %d %f\n",t.x,t.y,t.step0,t.dir,t.value);
            if(!(t.x==op_aim.x&&t.y==op_aim.y))
            {
                mymove.direction=t.dir;
                mymove.step=t.step0;
                ms_last_dir=t.dir;
                break;
            }
        }
    }
    clear();
    if(mymove.direction==4)
        mymove=d_r(game_info,vr+1);
    return mymove;
}

Move decide(const Game * game_info)
{
    Move mymove;
    mymove=d_r(game_info,0);
    //log
    for(int i=0;i<22;i++)
    {
    for(int j=0;j<22;j++)
    {
        if(ms_mb.map[i][j]==0x7fffffff)
            log_printf("%3c",'N');
        else
            log_printf("%3d",ms_mb.map[i][j]);
    }
    log_printf("\n");
    }
    log_printf("\n");
    return mymove;
}

#include "AI.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
using std::vector;
using std::string;


const static int dx[] = {-1 , 0 , 1 , 0};
const static int dy[] = {0 , 1 , 0 , -1};

bool if_magic (int x, int y, const Game * game_info) {
    return game_info->map[x][y].element == '$' && game_info->map[x][y].exist== 1;
}
bool if_normal (int x, int y, const Game * game_info) {
    return game_info->map[x][y].element == '.' && game_info->map[x][y].exist== 1;
}

//判断是否能走；
inline bool isin(const int x , const int y , const Game * game_info) {
	return (x >= 1) && (x <= game_info->constants.HEIGHT) && (y >= 1) && (y <= game_info->constants.WIDTH);
}

bool can_move(int x, int y, int dir, int step, const Game * game_info) { 

	
	for (int s = 1; s <= step; ++s) {
		int nx = x + dx[dir] * s;
		int ny = y + dy[dir] * s;
		if (!isin(nx , ny , game_info) || game_info->map[nx][ny].element == '#')
			return false;
	}
	return true;
}

Move decide (const Game * game_info) {
       
    Move dec;
    int choose_dir;//此变量选择方向；并最终返回值；
//记录状态部分；

    //选择当前的步数；
    int step = 1;
    if (SPEEDUP == game_info->player[game_info->id].status)
        step = 2;

    //定义位置信息；
    int x = game_info->player[game_info->id].x;
    int y = game_info->player[game_info->id].y;

    //这个变量储存的是试探到的可行的行走方案；
    vector<int> can_dir;

    for (int dir = 0; dir < 4; dir ++)
        if (can_move (x, y, dir, step, game_info)) {
            can_dir.push_back (dir);
        }//记录可行方案，记录完毕；


//决策部分；
//此部分重点在于分析并给出choose_dir 的值；
    int mode;
    vector<int> Mbean;
    vector<int> Nbean;
    vector<int> Road;

//mode 1






//mode 2
    for (int k = 0; k < can_dir.size(); k ++) {
        if (if_magic (x + dx[can_dir[k]],y + dy[can_dir[k]], game_info))
            Mbean.push_back (k);
        else if (if_normal (x + dx[can_dir[k]],y + dy[can_dir[k]], game_info))
            Nbean.push_back (k);
        else
            Road.push_back (k);
    }

    if (Mbean.size () > 0) {
        if (Mbean.size () == 1)
            choose_dir = can_dir[Mbean[0]];
        else
            choose_dir = can_dir[Mbean[rand () % Mbean.size ()]];
    }
    else if (Nbean.size () > 0) {
        if (Nbean.size () == 1)
            choose_dir = can_dir[Nbean[0]];
        else
            choose_dir = can_dir[Nbean[rand () % Nbean.size ()]];
    }
    else {
        if (Road.size () == 1)
            choose_dir = can_dir[Road[0]];
        else
            choose_dir = can_dir[Road[rand () % Road.size ()]];
    }
 
    
    

//返回数据部分；

    //给出最终的结果；
    dec.direction = choose_dir;
    dec.step = step;

    return dec;
}

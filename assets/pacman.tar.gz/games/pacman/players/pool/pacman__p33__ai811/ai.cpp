//pacman_AI_v2.0 Hewr
#include "AI.h"
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstring>
using namespace std;
#define fo(i,a,b) for (int i = a; i <= b; ++i)
#define SIZE(x) ((int) (x).size())
#define pb push_back
#define MP make_pair
#define fi first
#define se second
#define clr(a,x) memset(a, x, sizeof(a))
#define move(a,b) memcpy(&b, &a, sizeof(a))
#define SIGN(x,y) (((x) - 1) * Height + (y))
#define updmin(a,b) a = min(a, b)
#define updmax(a,b) a = max(a, b)

typedef pair<int, int> PII;

const int fx[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
const int oo = ~0u >> 2;

const int MaxLen = 60, MaxGrids = MaxLen * MaxLen;

Game SYS;
struct MapRec{
	char ch; // #-Barrier;  .-Bean;  $-Magic Bean;  <space>-Blank;

	void init(char _ch){
		ch = _ch;
	}
} Map[MaxLen][MaxLen];
PII Dis[MaxLen][MaxLen];
int Height, Width;

vector<PII> MagicBeans;

int ABS(int x){
	if (x < 0) x = -x;
	return x;
}

// |x1 - x2| + |y1 - y2|
int Manhattan(int x1, int y1, int x2, int y2){
	return ABS(x1 - x2) + ABS(y1 - y2);
}

// if Point(x, y) is in the area
bool InBound(int x, int y){
	return 1 <= x && x <= Height && 1 <= y && y <= Width;
}

// if Point(x, y) is good to reach
bool CanGo(int x, int y){
	return InBound(x, y) && Map[x][y].ch != '#';
}

// only have two directions to go
bool InTwoWayRoad(int x, int y){
	int cnt(0);
	fo (i, 0, 3){
		int nx = x + fx[i][0], ny = y + fx[i][1];
		cnt += CanGo(nx, ny);
		if (cnt > 2) break;
	}
	return cnt <= 2;
}

// Initialize the Map
void initMap(){
	MagicBeans.clear();
	Height = SYS.constants.HEIGHT, Width = SYS.constants.WIDTH;
	fo (i, 1, Height) fo (j, 1, Width){
		Map[i][j].init(SYS.map[i][j].element);
		if (Map[i][j].ch == '$') 
			MagicBeans.pb(MP(i, j));
	}
}

int BeanAppearTime(int x, int y){
	MapElement t = SYS.map[x][y];
	if (t.eaten_time <= 0 || t.eaten_time + SYS.constants.RECOVERY_ROUND <= SYS.round) return 0;
	return SYS.constants.RECOVERY_ROUND - (SYS.round - t.eaten_time);
}

struct ANIMAL{
	// Number;  Birth Round(0-alive);
	int Num, BirthTime;

	int init(int id){
		Num = id, BirthTime = 0;
	}

	int getX(){
		if (!BirthTime) return SYS.monster[Num].x;
		else return SYS.monster[Num].birth_x;
	}

	int getY(){
		if (!BirthTime) return SYS.monster[Num].y;
		else return SYS.monster[Num].birth_y;
	}

	bool dead(){
		return SYS.monster[Num].status == KILLED;
	}

	void update(){
		if (SYS.monster[Num].status == KILLED) 
			BirthTime = SYS.constants.REBIRTH_ROUND - (SYS.round - SYS.monster[Num].dead_time);
		else	BirthTime = 0;
	}
};

struct MAN{
	// Number;  Rounds left for Magic; Any Mines left?
	int Num, Magic, Mines;

	void init(int id){
		Num = id, Magic = Mines = 0;
	}

	int getX(){
		return SYS.player[Num].x;
	}

	int getY(){
		return SYS.player[Num].y;
	}

	int getSpeed(){
		return 1 + (SYS.player[Num].status == SPEEDUP);
	}

	// BUG : the Magic Time has mistake within 1 Round
	void update(){
		Mines = SYS.player[Num].num_mines;
		if (SYS.player[Num].status == SPEEDUP) Magic = SYS.constants.SPEEDUP_ROUND - (SYS.round - SYS.player[Num].speedup_start_round);
		else Magic = 0;
	}
} p1;

vector<PII> Mines;
vector<ANIMAL> Mon;
MAN p2;

void InitInfo(){
	p2.init(1 - SYS.id);
	Mon.resize(SYS.constants.MONSTER_NUMS);
	fo (i, 0, SIZE(Mon) - 1) 
		Mon[i].init(SYS.monster[i].id);
}

void UpdateInfo(){
	p2.update();
	fo (i, 0, SIZE(Mon) - 1) 
		Mon[i].update();
	Mines.clear();
	fo (i, 0, SYS.constants.MAX_NUM_MINES - 1){
		int x = SYS.mines[i].x, y = SYS.mines[i].y;
		if (!InBound(x, y)) continue;
		Mines.pb(MP(x, y));
	}
}

// if the distance between any animals and the grid (x,y) <= 1, we met an animal.
bool MeetAnimals(int x, int y, int DIS = 1){
	if (!p1.Magic)
	fo (i, 0, SIZE(Mon) - 1) if (!Mon[i].dead()){
		int dis = Manhattan(Mon[i].getX(), Mon[i].getY(), x, y);
		if (dis <= DIS) return 1;
	}
	return 0;
}

// if there is any mines right in grid (x,y), we're on a bomb.
bool MeetMines(int x, int y){
	if (!p1.Magic)
	fo (i, 0, SIZE(Mines) - 1) 
		if (Mines[i].fi == x && Mines[i].se == y) 
			return 1;
	return 0;
}

bool Place(0);

struct EVALUATE{
	int Grade, Dir, Speed, Mine; // Direction;  Step;  Set Mine;

	void init(){
		Grade = 0, Dir = 4, Speed = p1.getSpeed();
		if (p1.Mines > 2 && !p1.Magic) Place = 1;
		if (!p1.Mines) Place = 0;
		if (Place) --p1.Mines, Mine = 1; else Mine = 0;
		/*if (p1.Mines && !InTwoWayRoad(p1.getX(), p1.getY())) 
			--p1.Mines, Mine = 1;
		else	Mine = 0;*/
	}
} eva;

// move (x,y) by steps in direction dir; check Monsters; check Mines;
bool MoveSteps(int &x, int &y, int dir, int steps, bool MON = 0, bool MINE = 0){
	fo (STEP, 1, steps){
		x += fx[dir][0], y += fx[dir][1];
		if (!CanGo(x, y) && STEP == 2) x -= fx[dir][0], y -= fx[dir][1];
		if (!CanGo(x, y) || (MON && MeetAnimals(x, y)) || (MINE && MeetMines(x, y))) return 0;
	}
	return 1;
}

PII Q[MaxGrids];

// Calculate the exact Distance to the Magic Bean
// first-Mines? second-Distance
void BeanBFS(int sx, int sy){
	clr(Dis, 60);
	if (MeetMines(sx, sy)) return;
	Dis[sx][sy] = MP(0, 0);
	int l = 0, r = 0;
	Q[r = 1] = MP(sx, sy);
	while (l != r){
		l = (l + 1) % MaxGrids;
		sx = Q[l].fi, sy = Q[l].se;
		fo (i, 0, 3) fo (j, 1, p1.getSpeed()){
			int x = sx, y = sy;
			if (!MoveSteps(x, y, i, j)) continue;
			x = sx, y = sy;
			PII t = MP(!MoveSteps(x, y, i, j, 0, 1), Dis[sx][sy].se + 1);
			t.fi |= Dis[sx][sy].fi;
			if (t < Dis[x][y]){
				Dis[x][y] = t;
				Q[r = (r + 1) % MaxGrids] = MP(x, y);
			}
		}
	}
}

// Calculate the exact Distance to the Monster
void MonsterBFS(int sx, int sy){
	clr(Dis, 60); Dis[sx][sy] = MP(0, 0);
	int l = 0, r = 0;
	Q[r = 1] = MP(sx, sy);
	while (l != r){
		l = (l + 1) % MaxGrids;
		sx = Q[l].fi, sy = Q[l].se;
		fo (i, 0, 3){
			int x = sx, y = sy;
			if (!MoveSteps(x, y, i, 1)) continue;
			PII t = MP(0, Dis[sx][sy].se + 1);
			if (t < Dis[x][y]){
				Dis[x][y] = t;
				Q[r = (r + 1) % MaxGrids] = MP(x, y);
			}
		}
	}
}

// return the Number of the Nearest Magic Bean
int NearestMagicBean(int x, int y){
	PII opt = MP(0, oo);
	int ret(rand() % SIZE(MagicBeans));
	fo (i, 0, SIZE(MagicBeans) - 1){
		PII bean = MagicBeans[i];
		int dis = Manhattan(bean.fi, bean.se, x, y);
		if (dis < BeanAppearTime(bean.fi, bean.se)) continue;
		BeanBFS(bean.fi, bean.se);
		if (dis < BeanAppearTime(bean.fi, bean.se)) continue;
		dis = Dis[x][y].se;
		if (Dis[x][y] < opt) 
			opt = Dis[x][y], ret = i;
	}
	return ret;
}

// return the Number of the Nearest Monster
int NearestMonster(int x, int y){
	int opt(oo), ret(0);
	//log_printf("MagicTime: %d\n", p1.Magic);
	fo (i, 0, SIZE(Mon) - 1) if (!Mon[i].dead()){
		int mx = Mon[i].getX(), my = Mon[i].getY();
		int dis = Manhattan(mx, my, x, y);
		MonsterBFS(mx, my);
		dis = Dis[x][y].se;
		//log_printf("MonDis%d (%d,%d) %d Birth:%d\n", i, mx, my, dis, Mon[i].BirthTime);
		if (dis < opt) 
			opt = dis, ret = i;
	}
	if (opt >= p1.Magic) 
		return SIZE(Mon);
	return ret;
}

int lastDir(4);

EVALUATE Evaluate(){
	EVALUATE ret;
	ret.init();

	int sx = p1.getX(), sy = p1.getY(), ssx = sx + fx[lastDir][0], ssy = sy + fx[lastDir][1];

	if (!p1.Magic){
		// get rid of the Animals
		if (MeetAnimals(sx, sy)){
			// try to dodge them
			fo (i, 0, 3){
				int nx = sx, ny = sy;
				int status = MoveSteps(nx, ny, i, ret.Speed, 1, 1);
				//log_printf("Status:%d (%d,%d) Mon:%d Mine:%d\n", status, nx, ny, MeetAnimals(nx, ny), MeetMines(nx, ny));
				nx = sx, ny = sy;
				if (MoveSteps(nx, ny, i, ret.Speed, 1, 1)){
					//log_printf("Dodge Animal:%d\n", i);
					ret.Dir = i;
					return ret;
				}
			}
			// stay static otherwise
			fo (i, 0, 3){
				int nx = sx, ny = sy;
				if (!MoveSteps(nx, ny, i, ret.Speed)){
					//log_printf("Let Pass:%d\n", i);
					ret.Dir = i;
					return ret;
				}
			}
		}

		// Chase the nearest Magic Bean
		int MB = NearestMagicBean(sx, sy);
		//log_printf("Bean%d %d %d\n", MB, MagicBeans[MB].fi, MagicBeans[MB].se);
		BeanBFS(MagicBeans[MB].fi, MagicBeans[MB].se);
		//log_printf("NowDis:(%d,%d)\n", Dis[sx][sy].fi, Dis[sx][sy].se);
		if (Dis[sx][sy].se && Dis[sx][sy].se == BeanAppearTime(MagicBeans[MB].fi, MagicBeans[MB].se)){
			ret.Grade = 5;
			fo (i, 0, 3){
				int nx = sx, ny = sy;
				if (!MoveSteps(nx, ny, i, ret.Speed)){
					ret.Dir = i;
					return ret;
				}
			}
		}
		fo (i, 0, 3){
			int nx = sx, ny = sy;
			if (!MoveSteps(nx, ny, i, ret.Speed)) continue;
			log_printf("Dir%d:(%d,%d)\n", i, Dis[nx][ny].fi, Dis[nx][ny].se);
			int Grade = 0;
			if (Dis[nx][ny].fi || (!MeetAnimals(sx, sy) && MeetAnimals(nx, ny))){
				if (Dis[nx][ny].se > Dis[sx][sy].se) 
					Grade = 1;
				else	Grade = 2;
			} else {
				if (Dis[nx][ny].se > Dis[sx][sy].se)
					Grade = 3;
				else	Grade = 4;
			}
			if (Grade > ret.Grade) 
				ret.Grade = Grade, ret.Dir = i;
		}
	} else {
		log_printf("Magic Time!\n");
		// Chase the Monsters
		int MT = NearestMonster(sx, sy);
		/*if (MT == SIZE(Mon)){
			ret.Dir = rand() % 4;
			return ret;
		}*/
		if (MT == SIZE(Mon)) MT = 0;
		MonsterBFS(Mon[MT].getX(), Mon[MT].getY());
		int NowDis = Dis[sx][sy].se;
		log_printf("Mon%d (%d,%d) Dis:%d\n", MT, Mon[MT].getX(), Mon[MT].getY(), NowDis);
		fo (i, 0, 3){
			int nx = sx, ny = sy;
			if (!MoveSteps(nx, ny, i, ret.Speed)) continue;
			int dis = Dis[nx][ny].se;
			log_printf("Dir:%d Distance:%d\n", i, dis);
			int Grade = 0;
			if (MeetAnimals(nx, ny)){
				if (dis > NowDis) 
					Grade = 1;
				else	Grade = 2;
			} else {
				if (dis > NowDis) 
					Grade = 3;
				else	Grade = 4;
			}
			if (Grade > ret.Grade) 
				ret.Grade = Grade, ret.Dir = i;
		}
	}

	if (ret.Dir == 4) ret.Dir = lastDir;
	return ret;
}

Move decide(const Game * game_info)
{
	Move MyMove;
	SYS = *game_info;

	// Initialize when the game begins
	if (SYS.round == 1){
		InitInfo();
		p1.init(SYS.id);
		initMap();

		//DEBUG
		fo (i, 1, Height){
			fo (j, 1, Width) log_printf("%c", Map[i][j].ch);
			log_printf("\n");
		}
	}
	
	// Update Private Informations every Round
	UpdateInfo();
	p1.update();
	
	// Enumerate every direction and decide one to go
	eva = Evaluate();

	//DEBUG
	/*fo (i, 0, SIZE(Mon) - 1) log_printf("%d %d\n", Mon[i].getX(), Mon[i].getY());
	log_printf("  %d %d\n", p1.getX() + fx[eva.Dir][0] * eva.Speed, p1.getY() + fx[eva.Dir][1] * eva.Speed);
	log_printf("%d %d\n", lastDir, eva.Dir);
	log_printf("Grade:%d\n", eva.Grade);
	log_printf("\n");*/
	
	lastDir = MyMove.direction = eva.Dir, MyMove.step = eva.Speed, MyMove.set_mine = eva.Mine;
	return MyMove;
}


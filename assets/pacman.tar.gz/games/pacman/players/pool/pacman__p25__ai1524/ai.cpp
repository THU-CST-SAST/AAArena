#include <map>
#include "AI.h"
#include <cmath>
#include <cstdio>
#include <vector>
#include <string>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <fstream>
#include <iostream>
#include <algorithm>
#define PB push_back
#define MP make_pair
#define BG begin()
#define ED end()
#define SZ(x) ((int)((x).size()))
#define FF first
#define SS second
#define foreach(i,x) for (__typeof((x).begin()) i=(x).begin();i!=(x).end();i++)
#define FOR(i,l,r) for (int i=(l);i<=(r);i++)
#define ROF(i,r,l) for (int i=(r);i>=(l);i--)
using namespace std;
 
int fs=0;
Move a[50][50];
 
void init() {
#define U(xx,yy,x,y,z) a[xx][yy]=(Move){x,y,z};
  FOR(i,9,13) U(i,9,2,2,0);
  FOR(i,9,13) U(i,12,2,2,0);
  U(14,9,3,2,0);
  U(14,8,3,2,0);
  U(14,7,3,1,0);
  U(14,6,3,1,0);
  U(14,5,3,2,0);
  U(14,4,3,2,0);
  U(14,3,3,2,0);
  FOR(i,14,18)  U(i,2,2,2,0);//19 2
  FOR(i,2,4)    U(19,i,1,2,0);//19 5
  ROF(i,19,18)  U(i,5,0,2,0);//17 5
  FOR(i,5,7)    U(17,i,1,2,0);//17 8
  FOR(i,17,18)  U(i,8,2,2,0);//19 8
  FOR(i,8,12)   U(19,i,1,2,0);//19 13
  ROF(i,19,18)  U(i,13,0,2,0);//17 13
  FOR(i,13,15)  U(17,i,1,2,0);//17 16
  FOR(i,17,18)  U(i,16,2,2,0);//19 16
  FOR(i,16,18)  U(19,i,1,2,0);//19 19
  ROF(i,19,15)  U(i,19,0,2,0);//14 19
  ROF(i,19,10)  U(14,i,3,2,0);
  U(14,13,3,2,0);
  U(14,15,3,2,0);
  U(14,2,2,2,0);
  U(14,16,3,2,0);
  U(14,10,3,2,0);
  U(17,7,1,2,0);
  U(14,19,3,2,0);
}
 
Move decide(const Game *game_info) {
  if (!fs) {
    fs=1;
    init();
  }
  if (game_info->id==1)
  {
  int id=game_info->id,x=game_info->player[id].x,y=21-game_info->player[id].y;
  int et=game_info->map[14][17].eaten_time;
  if (x==14 && y==5 && et>0 && game_info->round-et<41)
    return (Move){0,0,0};
  Move b=a[x][y];
  if (b.direction==1) b.direction=3; else
  if (b.direction==3) b.direction=1;
  return b;
  }
  int id=game_info->id,x=game_info->player[id].x,y=game_info->player[id].y;
  int et=game_info->map[14][4].eaten_time;
  if (x==14 && y==5 && et>0 && game_info->round-et<41)
    return (Move){0,0,0};
  return a[game_info->player[id].x][game_info->player[id].y];
}

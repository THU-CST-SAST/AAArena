#include "AI.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
using std::vector;
using std::string;

inline bool isin(const int x , const int y , const Game * game_info)
{
	return (x >= 1) && (x <= game_info->constants.HEIGHT) && (y >= 1) && (y <= game_info->constants.WIDTH);
}

bool can_move(int x, int y, int dir, int step, const Game * game_info)
{
	const static int dx[] = {-1 , 0 , 1 , 0};
	const static int dy[] = {0 , 1 , 0 , -1};
	
	for (int s = 1; s <= step; ++s)
	{
		int nx = x + dx[dir] * s;
		int ny = y + dy[dir] * s;
		if (!isin(nx , ny , game_info) || game_info->map[nx][ny].element == '#')
			return false;
	}
	return true;
}

vector<int> dir_pre[1000];
int choose_pre[1000];

Move decide(const Game * game_info)
{
	const Player & player = game_info->player[game_info->id];
	int x = player.x;
	int y = player.y;
	int step = 1;
	
	if (player.status == SPEEDUP)
		step = 2;
	
	log_printf("Round %d\n" , game_info->round);
	vector<int> can_dir;
	can_dir.clear();
	for (int dir = 0; dir < 4; ++dir)
	{
		if (can_move(x , y , dir , 1, game_info))
		{
			can_dir.push_back(dir);
		}
	}
	Move ply_move;
	
	int choose_dir;
	bool is_pre_can = 0;
	for (int k = 0; k < (int)can_dir.size(); ++k)
	{
		if (can_dir[k] == choose_pre[game_info->round - 1])
			is_pre_can = 1;
	}
		
	if (!is_pre_can || can_dir.size() > dir_pre[game_info->round - 1].size())
	{
		int k = can_dir.size();
		if (k == 0) 
		{
			log_printf("divided by 0\n");
			choose_dir = 0;
		}
		else
		{
			choose_dir = can_dir[rand() % k];
			if (k > 1)
			{
				while ((choose_dir + 2) % 4 == choose_pre[game_info->round - 1])
					choose_dir = can_dir[rand() % k];
			}
		}
	}
	else
	{
		choose_dir = choose_pre[game_info->round - 1];
	}

	ply_move.direction = choose_dir;
	ply_move.step = step;
	if (player.num_mines)
		ply_move.set_mine = rand() % 2;
	
	dir_pre[game_info->round] = can_dir;
	choose_pre[game_info->round] = ply_move.direction;
	
	return ply_move;
}


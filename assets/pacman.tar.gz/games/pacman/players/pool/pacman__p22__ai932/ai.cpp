/********************************************************
 * TITLE: PACMAN AI                                     *
 * AUTHOR: Dwt136                                       *
 * DATE: 2012-11-30                                     *
 * VERSION: 2.6                                         *
 * UNFINISHED                                           *
 ********************************************************/

#include "AI.h"
//#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <limits.h>
using std::vector;
using std::priority_queue;
using std::stack;
/* ---------------------------------------- */
/* ----------- * Declarations * ----------- */
/* ---------------------------------------- */
class Cell;
class Point;
class Line;
/* ---------- Struct vec ---------- */
// A vector
struct vec {
    int x, y;
};
vec zero_vec = {0, 0};
vec left_vec = {-1, 0};
vec up_vec = {0, -1};
vec right_vec = {1, 0};
vec down_vec = {0, 1};
int lengthOf(const vec& v) {
    return v.x + v.y;
}
vec operator + (const vec& v1, const vec& v2) {
    vec v;
    v.x = v1.x + v2.x;
    v.y = v1.y + v2.y;
    return v;
}
vec operator - (const vec& v1, const vec& v2) {
    vec v;
    v.x = v1.x - v2.x;
    v.y = v1.y - v2.y;
    return v;
}
void operator += (vec& v1, const vec& v2) {
    v1.x += v2.x;
    v1.y += v2.y;
}
/* ---------- Declaration of Class Cell ---------- */
// The cell on the map
// Cell type
enum Type {
    WALL = 0, ROAD = 1, UNCOUNTED_NODE = 2, NODE = 3
};
// Type of object on a cell
enum ObjectType {
    SPACE = 0, BEAN = 1, MAGIC = 2
};

class Cell {
    public:
        Type getType();                         // The type of this cell - Wall, Road or Joint
        int getNum();                           // No. of the cell (which Line it belongs to or the number of the Point(when joint))
        ObjectType getObj();                    // The object type on it //trough MapElement
        bool isMined();
        void setMined(bool);
        bool isMonstered();
        void setMonstered(bool);
        vector<Point*> getMonsterTo();          // Return the points the monster(s) may be going to
        void addMonsterTo(Point*);
        void clearMonsterTo();
        int getX();
        int getY();
        int count(int dist, int magicDist, Point* fromPoint);//count the score.
        Cell(int x, int y, Type type, int num);

    private:
        int num;
        int x, y;
        Type type;
        bool mined;
        bool monstered;
        vector<Point*> monsterTo;
};
/* ---------- End of Declaration of Class Cell ---------- */

/* ---------- Declaration of Class Point ---------- */
// Abstracted point on the graph
class Point {
    public:
        int getNum();                           // The number of this point
        int getX();
        int getY();
        vector<Line*> getLines();               // The lines connected to this point
        void addLine(Line*);
        Cell* getCell();                        // The cell the point is on

        bool isCounted();                       // Whether this point has been counted when counting
        void setCounted(bool);
        int getDist();                          // The distance to the player. The two is used to calculate;
        void setDist(int);
        int getScore();                         // The counting score
        void resetScore();
        void count();
        Move getMove();                         // return the best move when on the point

        Point(int x, int y, int num);

    private:
        int x, y;
        int num;
        vector<Line*> ls;
        int dist;
        bool counted;
        int score;
};

struct comparePoint {
    bool operator() (Point* a, Point* b) {
        return (a -> getDist()) > (b -> getDist());
    }
};
/* ---------- End of Declaration of Class Point ---------- */

/* ---------- Declaration of Class Line ---------- */
class Line {
    public:
        int getNum();                           // The number of this line
        int getLength();
        bool isRing();                          // Whether it is a ring
        Cell* getEndOne();                      // One of the two ends
        Cell* getEndTwo();                      // The other end
        vector<Cell*> getCells();               // Cells that belong to this line
        void addCell(Cell*);
        Point* getPointOne();                   // One of the two points
        Point* getPointTwo();                   // The other point
        Point* theOtherPoint(Point*);
        Point* onMonsterTo(int, Cell*);         // The Point the monster on the line is going to. If on end, return the other end (int - monster num, cell - the cell the monster is on)
        int getBelong();
        void setBelong(int);
        void makeDist(Point*, Cell*);           // make the point's dist = the distance between the point and the cell
        void updateMagicDist(int);
        int count();
        Move getMove();                         // return the best move when on the line(except the point)
        Move getMoveByPoint(Point*);
        Line(int num);

    private:
        int num;
        int length;                             // in fact the size of cells
        vector<Cell*> cs;
        int belong;                             // The point that the line belongs to when counting // clear when count
        int magicDist;                          // The distance between magic bean and the player
};
/* ---------- End of Declaration of Class Line ---------- */

int vecToDir(const vec&);
inline bool isIn(const vec&);
inline char getMapElementByXY(int, int);
inline char getMapElement(const vec& v);
inline int existByXY(int, int);
bool canMove(const vec&, const vec&);
int countSurrounding(int, int);
/* ----------------------------------------------------*/
/* ------------- * End of Declarations * ------------- */
/* ----------------------------------------------------*/

/* ---------- Globle ---------- */
// "consts"
const char MAP_WALL = '#';
const char MAP_SPACE = ' ';
const char MAP_BEAN = '.';
const char MAP_MAGIC = '$';

const int NO_BELONG = -1;
const int STARTER_PATH = -2;

const int LEFT = 0;
const int UP = 1;
const int RIGHT = 2;
const int DOWN = 3;

unsigned int DEPTH = 30; // if the number of points is less than the previous value, update it to point number
const Game* game;

// whether it is the first round
bool firstRound = true;

// player's parameters
vec pos;
vec posPrev;
PLAYER_STATUS status;
int mine;

// the other player's parameters
vec posOther;
vec posPrevOther;
PLAYER_STATUS statusOther;

// monster parameters
int numMonster;
vec monsterPosPre[10];
vec monsterPos[10];

// mine parameter
int numMine;
vec minePos[500];

// map
int width, height;
Cell* cells[50][50];
vector<Point*> points;
vector<Line*> lines;

//std::ofstream log; //debug
// moving decision parameters and variables. IMPORTANT
// 1. Adding the neibour points to openlist, calculate distance of the points
// 2. get the closest point in openlist, pop it out of openlist and push it into the checkPoints stack, add the points uncounted and connecting to this point to the openlist.
// 3. do step 2 until the size of the stack reaches the DEPTH
// 4. pop every points and count the line connected to it. change the counted field of line when it's counted
// 5. pay attension to step 4 feed back
// 6. choose the better way
priority_queue<Point*, vector<Point*>, comparePoint> openList;
stack<Point*> checkPoints; // MAYBE should be a queue
///////////////////////////////////////////////////////////////////////////////////////////////////////

/* ---------- End of Globle ---------- */

/* ---------- Class Cell ---------- */
Type Cell::getType() {
    return type;
}
int Cell::getNum() {
    return num;
}
ObjectType Cell::getObj() {
    char type = getMapElementByXY(x, y);
    int exist = existByXY(x, y);
    if(type == MAP_BEAN && exist) {
        return BEAN;
    }
    if(type == MAP_MAGIC && exist) {
        return MAGIC;
    }
    return SPACE;
}
bool Cell::isMined() {
    return mined;
}
void Cell::setMined(bool m) {
    mined = m;
}
bool Cell::isMonstered() {
    return monstered;
}
void Cell::setMonstered(bool m) {
    monstered = m;
}
vector<Point*> Cell::getMonsterTo() {
    return monsterTo;
}
void Cell::addMonsterTo(Point* p) {
    monsterTo.push_back(p);
}
void Cell::clearMonsterTo() {
    monsterTo.clear();
}
int Cell::getX() {
    return x;
}
int Cell::getY() {
    return y;
}

const int COUNT_DEVIDE = 1;
int Cell::count(int dist, int magicDist, Point* fromPoint) {
    static const int COUNT_BEAN = 100;
    static const int COUNT_MAGIC = 5500;
    static const int COUNT_MONSTER = -2750;
    static const int COUNT_MINE = -2250;
    static const int COUNT_PLAYER = -2000;
    int sum = 0;

    ObjectType ot = getObj();
    if(ot == BEAN) {
        sum += COUNT_BEAN;
    }
    if(ot == MAGIC) {
        sum += COUNT_MAGIC;
        lines[num] -> updateMagicDist(dist);
    }
    if(mined && ot != MAGIC) {
        sum += COUNT_MINE;
    }
    if(monstered) {
        if(dist <= 2 * magicDist) {
            int size = monsterTo.size();
            for(int i = 0; i < size; i ++) {
                if(monsterTo[i] == fromPoint) {
                    sum += COUNT_MONSTER;
                    break;
                }
            }
        }
    }
    return sum;
}

Cell::Cell(int x, int y, Type type, int num) {
    this -> x = x;
    this -> y = y;
    this -> type = type;
    this -> num = num;
}
/* ---------- End of Class cell ---------- */

/* ---------- Class Point ---------- */
int Point::getNum() {
    return num;
}
int Point::getX() {
    return x;
}
int Point::getY() {
    return y;
}
vector<Line*> Point::getLines() {
    return ls;
}
void Point::addLine(Line* p) {
    ls.push_back(p);
}
Cell* Point::getCell() {
    return cells[y][x];
}
bool Point::isCounted() {
    return counted;
}
void Point::setCounted(bool c) {
    counted = c;
}
int Point::getDist() {
    return dist;
}
void Point::setDist(int d) {
    dist = d;
}
int Point::getScore() {
    return score;
}
void Point::resetScore() {
    score = 0;
}
void Point::count() {
    int n = ls.size();
    int max = INT_MIN;
    int c;
    for(int i = 0; i < n; i ++) {
        if(ls[i] -> getBelong() == NO_BELONG || ls[i] -> getBelong() == num) {
            c = ls[i] -> count();
            if(c > max) {
                max = c;
            }
        }
    }
    score = max;
}
Move Point::getMove() {
    int n = ls.size();
    int max = INT_MIN;
    int numLine = 0;
    int c;
    for(int i = 0; i < n; i ++) {
        c = ls[i] -> count();
        if(c > max) {
            max = c;
            numLine = i;
        }
    }
    return ls[numLine] -> getMoveByPoint(this);
}

Point::Point(int x, int y, int num) {
    this -> x = x;
    this -> y = y;
    this -> num = num;
    ls.clear();
}
/* ---------- End of Class Point ---------- */

/* ---------- Class Line ---------- */
// Abstracted line on the graph

int Line::getNum() {
    return num;
}
int Line::getLength() {
    return length;
}
bool Line::isRing() {
    return cs.front() == cs.back();
}
Cell* Line::getEndOne() {
    return cs.front();
}
Cell* Line::getEndTwo() {
    return cs.back();
}
vector<Cell*> Line::getCells() {
    return cs;
}
void Line::addCell(Cell* c) {
    cs.push_back(c);
    length ++;
}
Point* Line::getPointOne() {
    return points[cs.front() -> getNum()];
}
Point* Line::getPointTwo() {
    return points[cs.back() -> getNum()];
}
Point* Line::theOtherPoint(Point* p) {
    if(getPointOne() == p) {
        return getPointTwo();
    }
    return getPointOne();
}
Point* Line::onMonsterTo(int m, Cell* cell) {
    if(cell -> getType() == NODE) {
        return theOtherPoint(points[cell -> getNum()]);
    }
    Cell* cellPre = cells[monsterPosPre[m].y][monsterPosPre[m].x];
    for(int i = 0; i < length; i ++) {
        if(cs[i] == cell) {
            return getPointOne();
        }
        if(cs[i] == cellPre) {
            return getPointTwo();
        }
    }
    return getPointOne();
}
int Line::getBelong() {
    return belong;
}
void Line::setBelong(int b) {                                       // set belong and reset magic dist
    belong = b;
    magicDist = -1;
}
void Line::makeDist(Point* p, Cell* c) {
    int i;
    for(i = 0; i < length; i ++) {
        if(p == points[cs[i] -> getNum()]) {
            break;
        }
    }
    if(c == cs.front()) {
        p -> setDist(i);
    }
    p -> setDist(length - i - 1);
}
void Line::updateMagicDist(int d) {
    if(magicDist < 0) {
        magicDist = d;
    }
}
int Line::count() {
    Point* pointBelong = points[belong];
    int score = 0;
    if(getPointOne() == pointBelong) {
        for(int i = 0; i < length - 1; i ++) {
            score += cs[i] -> count(pointBelong -> getDist() + i, magicDist, pointBelong);
        }
        score += (getPointTwo() -> getScore()) / COUNT_DEVIDE;
    } else {
        for(int i = length - 1; i > 0; i --) {
            score += cs[i] -> count(pointBelong -> getDist() + length - 1 - i, magicDist, pointBelong);
        }
        score += (getPointOne() -> getScore()) / COUNT_DEVIDE;
    }
    return score;
}
Move Line::getMove() {
    int score1 = 0;
    int score2 = 0;
    int i;
    for(i = 0; i < length; i ++) {
        if(cs[i] == cells[pos.y][pos.x]) {
            break; // i would be the number of the cell player's on
        }
    }
    for(int j = i - 1; j > 0; j --) {
        score1 += cs[j] -> count(i - j, magicDist, getPointTwo());
    }
    score1 += (getPointOne() -> getScore()) / COUNT_DEVIDE;
    for(int j = i + 1; j < length - 1; j ++) {
        score2 += cs[j] -> count(j - i, magicDist, getPointOne());
    }
    score2 += (getPointOne() -> getScore()) / COUNT_DEVIDE;

    Move move;
    vec positionTo;
    if(score1 > score2) {
        positionTo.x = cs[i - 1] -> getX();
        positionTo.y = cs[i - 1] -> getY();
    } else {
        positionTo.x = cs[i + 1] -> getX();
        positionTo.y = cs[i + 1] -> getY();
    }
    move.direction = vecToDir(positionTo - pos);
    move.step = 1; // TODO
    return move;
}
Move Line::getMoveByPoint(Point* p) {
    vec positionTo;
    if(getPointOne() == p) {
        positionTo.x = cs[1] -> getX();
        positionTo.y = cs[1] -> getY();
    } else {
        positionTo.x = cs[length - 2] -> getX();
        positionTo.y = cs[length - 2] -> getY();
    }
    Move move;
    move.direction = vecToDir(positionTo - pos);
    move.step = 1; // TODO
    return move;
}
Line::Line(int num) {
    this -> num = num;
    length = 0;
    cs.clear();
}
/* ---------- End of Class Line ---------- */

/* ---------- Tools ---------- */
int vecToDir(const vec& v) {
    const static int LEFT = 0;
    const static int UP = 1;
    const static int RIGHT = 2;
    const static int DOWN = 3;
    if(v.x < 0) {
        return LEFT;
    }
    if(v.x > 0) {
        return RIGHT;
    }
    if(v.y < 0) {
        return UP;
    }
    return DOWN;
}

bool isIn(const vec& v) {
    return (v.x >= 1) && (v.x <= width) && (v.y >= 1) && (v.y <= height);
}

char getMapElementByXY(int x, int y) {
    return game -> map[x][y].element;
}

char getMapElement(const vec& v) {
    return getMapElementByXY(v.x, v.y);
}

int existByXY(int x, int y) {
    return game -> map[x][y].exist;
}

bool canMove(const vec& position, const vec& speed) {
    vec posNow;
    posNow.x = position.x;
    posNow.y = position.y;
    int length = lengthOf(speed);
    vec move;
    move.x = speed.x / length;
    move.y = speed.y / length;

    for (int s = 1; s <= length; s ++) {
        posNow += move;
        if (!isIn(posNow) || getMapElement(posNow) == MAP_WALL) {
            return false;
        }
    }
    return true;
}

const vec sur[4] = {left_vec , up_vec, right_vec, down_vec};
int countSurrounding(int x, int y) {
    int sum = 0;
    vec p;
    p.x = x;
    p.y = y;
    vec dest;
    for(int i = 0; i < 4; i ++) {
        dest = p + sur[i];
        if(isIn(dest) && getMapElement(dest) != MAP_WALL) {
            sum ++;
        }
    }
    return sum;
}
/* ---------- End of Tools ---------- */

/* ---------- Main ---------- */
void init();
void update();
void initMap();
void resetLines();
void resetPoints();
void count();                                   //most imp one

Point* addPoint(const vec&);
void addPointToLine(const vec&, Line*);

Move decide(const Game* game_info) {
    //log.open("log.txt"); // debug
    game = game_info;
    Move move;
    // init if it is the first round
    if(firstRound) {
        init();
        firstRound = false;
    } else {
        update();
    }
//debug
//    for(int i = 1; i <= height; i ++) {
//        for(int j = 1; j <= width; j ++) {
//            log << cells[i][j]->getNum() << " \t";
//        }
//        log << std::endl;
//    }
    // make decision
    Cell* cell;
    Point* ps[4];
    Point* point;
    Line* line;
    cell = cells[pos.y][pos.x];
    resetLines();
    resetPoints();
    if(cell -> getType() == ROAD) { /////////// NOTE: ERROR From here to the end of decide
        line = lines[cell -> getNum()];
        line -> setBelong(STARTER_PATH);
        if(line -> isRing()) {
            move = line -> getMove();
        } else {
            ps[0] = line -> getPointOne();
            ps[1] = line -> getPointTwo();
            line -> makeDist(ps[0], cell);
            ps[1] -> setDist((line -> getLength()) - 1 - (ps[0] -> getDist()));
            openList.push(ps[0]);
            openList.push(ps[1]);
            count();
            move = line -> getMove();
        } // TODO !!!!!!!!!!!!!rethink speededUp!!!!!!!!!!!!!!!!!
    } else if(cell -> getType() == NODE) {
        point = points[cell -> getNum()];
        point -> setCounted(true);
        int size = (point -> getLines()).size();  // n = lines connected to the point
        for(int i = 0; i < size ;i ++) {
            ps[i] = (point -> getLines())[i] -> theOtherPoint(point);
            ps[i] -> setDist(point -> getLines()[i] -> getLength() - 1);
            openList.push(ps[i]);
        }
        count();
        move = point -> getMove();
    } else {
        move.direction = 0;
        move.step = 0;
        move.set_mine = 0;
    }

    // TODO setting of mine

    //log.close(); // debug

    return move;
}

void count() {
    Point* point;
    Point* point2;
    vector<Line*> ls;
    while(checkPoints.size() < DEPTH) {
        point = openList.top();
        openList.pop();
        checkPoints.push(point);
        ls = point -> getLines();
        int size = ls.size();
        for(int i = 0; i < size; i ++) {
            if(ls[i] -> getBelong() >= 0) {
                continue;
            }
            ls[i] -> setBelong(point -> getNum());
            point2 = ls[i] -> theOtherPoint(point);
            if(!point2 -> isCounted()) {
                point2 -> setDist(point -> getDist() + ls[i] -> getLength() - 1);
                openList.push(point2);
                point2 -> setCounted(true);
            }
        }
    }

    while(!checkPoints.empty()) {
        point = checkPoints.top();
        checkPoints.pop();
        point -> count();
    }
}

void resetLines() {
    Line* line;
    int size = lines.size();
    for(int i = 0; i < size; i ++) {
        line = lines[i];
        line -> setBelong(NO_BELONG);
    }
}

void resetPoints() {
    Point* point;
    int size = points.size();
    for(int i = 0; i < size; i ++) {
        point = points[i];
        point -> setCounted(false);
        point -> resetScore();
    }
}

void update() {
    const Player& player = game -> player[game -> id];
    posPrev.x = pos.x;
    posPrev.y = pos.y;
    pos.x = player.x;
    pos.y = player.y;
    status = player.status;
    mine = player.num_mines;

    const Player& playerOther = game -> player[1 - (game -> id)];
    posPrevOther.x = posOther.x;
    posPrevOther.y = posOther.y;
    posOther.x = playerOther.x;
    posOther.y = playerOther.y;
    statusOther = playerOther.status;

    for(int i = 1; i <= height; i ++) {
        for(int j = 1; j <= width; j ++) {
            cells[i][j] -> setMonstered(false);
            cells[i][j] -> clearMonsterTo();
            cells[i][j] -> setMined(false);
        }
    }

    Cell* cell;
    Point* point;
    Line* line;
    for(int i = 0; i < numMonster; i ++) {
        monsterPosPre[i].x = monsterPos[i].x;
        monsterPosPre[i].y = monsterPos[i].y;
        monsterPos[i].x = (game -> monster)[i].x;
        monsterPos[i].y = (game -> monster)[i].y;
        cell = cells[monsterPos[i].y][monsterPos[i].x];
        cell -> setMonstered(true);
        if(cell -> getType() == NODE) {
            point = points[cell -> getNum()];
            int size = (point -> getLines()).size();
            for(int j = 0; j < size; j ++) {
                cell -> addMonsterTo((point -> getLines())[j] -> theOtherPoint(point));
            }
        } else {
            line = lines[cell -> getNum()];
            cell -> addMonsterTo(line -> onMonsterTo(i, cell));
        }
    }

    numMine = game -> num_mines;
    for(int i = 0; i < numMine; i ++) {
        minePos[i].x = (game -> mines)[i].x;
        minePos[i].y = (game -> mines)[i].y;
        cell = cells[monsterPos[i].y][monsterPos[i].x];
        cell -> setMined(true);
    }
}

void init() {
    initMap();
    const Player& player = game -> player[game -> id];

    pos.x = player.x;
    pos.y = player.y;
    posPrev.x = pos.x;
    posPrev.y = pos.y;
    status = player.status;
    mine = player.num_mines;

    const Player& playerOther = game -> player[1 - (game -> id)];
    posOther.x = playerOther.x;
    posOther.y = playerOther.y;
    posPrevOther.x = posOther.x;
    posPrevOther.y = posOther.y;
    statusOther = playerOther.status;

    numMonster = (game -> constants).MONSTER_NUMS;
    for(int i = 1; i <= height; i ++) {
        for(int j = 1; j <= width; j ++) {
            cells[i][j] -> setMonstered(false);
            cells[i][j] -> clearMonsterTo();
            cells[i][j] -> setMined(false);
        }
    }

    Cell* cell;
    Point* point;
    Line* line;
    for(int i = 0; i < numMonster; i ++) {
        monsterPos[i].x = (game -> monster)[i].x;
        monsterPos[i].y = (game -> monster)[i].y;
        monsterPosPre[i].x = monsterPos[i].x;
        monsterPosPre[i].y = monsterPos[i].y;
        cell = cells[monsterPos[i].y][monsterPos[i].x];
        cell -> setMonstered(true);
        if(cell -> getType() == NODE) {
            point = points[cell -> getNum()];
            int size = (point -> getLines()).size();
            for(int j = 0; j < size; j ++) {
                cell -> addMonsterTo((point -> getLines())[i] -> theOtherPoint(point));
            }
        } else {
            line = lines[cell -> getNum()];
            cell -> addMonsterTo(line -> onMonsterTo(i, cell));
        }
    }

    numMine = game -> num_mines;
    for(int i = 0; i < numMine; i ++) {
        minePos[i].x = (game -> mines)[i].x;
        minePos[i].y = (game -> mines)[i].y;
        cell = cells[monsterPos[i].y][monsterPos[i].x];
        cell -> setMined(true);
    }

    if(points.size() < DEPTH) {
        DEPTH = points.size();
    }
}

Type mapInfo[50][50];
void initMap() {
    width = (game -> constants).WIDTH;
    height = (game -> constants).HEIGHT;

    points.clear();
    lines.clear();

    char type;
    int surrounding;
    vec currentNodePosition;
    for(int i = 1; i <= height; i ++) {
        for(int j = 1; j <= width; j ++) {
            type = getMapElementByXY(i, j);
            if(type == MAP_WALL) {
                mapInfo[i][j] = WALL;
                cells[i][j] = new Cell(j, i, WALL, 0);
                continue;
            }
            surrounding = countSurrounding(i, j);
            if(surrounding == 2) {
                mapInfo[i][j] = ROAD;
            } else if(surrounding == 3 || surrounding == 4 || surrounding == 1) {
                mapInfo[i][j] = UNCOUNTED_NODE;
                currentNodePosition.x = j;
                currentNodePosition.y = i;
            }
        }
    }
    addPoint(currentNodePosition);
}

// add the cell to a line
void addToLine(Line* line, const vec& p) {
    cells[p.y][p.x] = new Cell(p.x, p.y, ROAD, line -> getNum());
    line -> addCell(cells[p.y][p.x]);
    mapInfo[p.y][p.x] = WALL;
    for(int i = 0; i < 4; i ++) {
        const vec& dest = p + sur[i];
        if(isIn(dest) && mapInfo[dest.y][dest.x] != WALL) {
            if(mapInfo[dest.y][dest.x] == ROAD) {
                addToLine(line, dest);
            } else {
                addPointToLine(dest, line);
            }
        }
    }
}
// new line
Line* addLine(Cell* starter, const vec& p) {
    int num = lines.size();
    Line* line = new Line(num);
    lines.push_back(line);
    line -> addCell(starter);
    if(mapInfo[p.y][p.x] == ROAD) {
        addToLine(line, p);
    } else {
        addPointToLine(p, line);
    }
    return line;
}
// new point activated by function initMap()
Point* addPoint(const vec& p) {
    int num = points.size();
    Point* point = new Point(p.x, p.y, num);
    points.push_back(point);
    cells[p.y][p.x] = new Cell(p.x, p.y, NODE, num);
    mapInfo[p.y][p.x] = NODE;
    for(int i = 0; i < 4; i ++) {
        const vec& dest = p + sur[i];
        if(isIn(dest) && mapInfo[dest.y][dest.x] != WALL) {
            Line* l = addLine(cells[p.y][p.x], dest);
            point -> addLine(l);
        }
    }
    return point;
}
// new point activated by line
void addPointToLine(const vec& p, Line* line) {
    Point* point;
    if(mapInfo[p.y][p.x] == UNCOUNTED_NODE) {
        point = addPoint(p);
    }
    if(cells[p.y][p.x] != line -> getEndOne()) {
        line -> addCell(cells[p.y][p.x]);
        point -> addLine(line);
    }
}
/* ---------- End of Main ---------- */

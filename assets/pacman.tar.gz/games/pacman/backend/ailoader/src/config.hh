/*
 * $File: config.hh
 * $Date: Sun Oct 14 19:26:57 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

constexpr int LOG_SIZE_MAX = 1024 * 1024;

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


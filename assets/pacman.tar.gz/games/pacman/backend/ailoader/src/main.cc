/*
 * $File: main.cc
 * $Date: Fri Nov 02 17:06:25 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "sdk/AI.h"
#include "ailoader.hh"
#include "config.hh"

#include <string>

#include <cstdlib>
#include <cstdarg>

#include <dlfcn.h>

static PrintfOsstream log_stream;

static void logger(const char *fmt, va_list ap)
{
	log_stream.vprintf(fmt, ap);
}

extern "C" __attribute__((format(printf, 1, 2)))
void log_printf(const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	logger(fmt, ap);
	va_end(ap);
}

class PacmanController: public GameControllerBase
{
	typedef decltype(decide) *ai_func_t;
	ai_func_t m_ai;

	Game m_arg;
	Move m_result;
	std::string m_fpath;

	ai_func_t get_ai()
	{
		if (m_ai)
			return m_ai;
		void *hdl = dlopen(m_fpath.c_str(), RTLD_NOW);
		if (!hdl)
			throw AI9Error("failed to load AI: %s", dlerror());
		m_ai = reinterpret_cast<ai_func_t>(dlsym(hdl, "decide"));
		if (!m_ai)
			throw AI9Error("failed to lookup AI func: %s", dlerror());

		typedef void (*reg_logger_t)(void*);
		reg_logger_t r = reinterpret_cast<reg_logger_t>(dlsym(hdl, "register_logger"));
		if (r)
			r(reinterpret_cast<void*>(logger));
		return m_ai;
	}

	public:
		PacmanController(const char *fpath):
			m_fpath(fpath),
			m_ai(nullptr)
		{}

		void on_game_init()
		{
			get_ai();
		}

		void on_round_start()
		{
			*m_conn >> recvable(m_arg);
		}

		void do_round()
		{
			m_result = get_ai()(&m_arg);
		}

		void on_round_end()
		{
			*m_conn << sendable(m_result);
		}

		void on_game_end()
		{
		}

		std::string get_log_msg()
		{
			return log_stream.str();
		}
};

int main(int argc, char **argv)
{
	if (argc != 2 && argc != 3)
	{
		fprintf(stderr, "usage: %s <AI .so file> [<port numnber>]\n", argv[0]);
		return 1;
	}
	log_stream.set_max_size(LOG_SIZE_MAX);
	try
	{
		PacmanController ctl(argv[1]);
		uint16_t port = 0;
		if (argc == 3)
		{
			int x;
			if (sscanf(argv[2], "%d", &x) != 1 || x < 0 || x > 0xFFFF)
				throw AI9Error("invalid port number: %s", argv[2]);
			port = x;
		}
		AILoader::add_allowed_open_path(argv[1]);
		AILoader::mainloop(port, ctl);
	} catch (std::exception &e)
	{
		fprintf(stderr, "%s: caught exception: %s\n", argv[0], e.what());
		return -1;
	}
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


/*
 * $File: AI.h
 * $Date: Sun Oct 14 20:18:22 2012 +0800
 */

#ifndef AI_H
#define AI_H

#ifdef __GNUC__
#define PACKED __attribute__((packed))
#define FMT_PRINTF __attribute__((format(printf, 1, 2)))
#define DllExport
#elif _MSC_VER
#define DllExport __declspec( dllexport ) 
#define PACKED
#define FMT_PRINTF
#else
#define PACKED
#define DllExport
#define FMT_PRINTF
#warn "GCC is recommended"
#endif

// 人物状态
enum PLAYER_STATUS
{
	NORMAL = 0,
	SPEEDUP = 1
};

// 怪物状态
enum MONSTER_STATUS
{
	ALIVE = 0,
	KILLED = 1
};

// 游戏常数
typedef struct
{
	int MAX_ROUND; // 游戏最大回合数
	int HEIGHT , WIDTH; // 游戏区域大小
	int PLAYER_SPEED; // 人物移动速度
	int MONSTER_SPEED; // 怪物移动速度
	int PLAYER_NUMS; // 玩家数目
	int MONSTER_NUMS; // 怪物数目
	int BEAN_SCORE; // 普通豆子奖励
	int TREASURE_SCORE; // 特殊豆子奖励
	int BONUS_SCORE; // 杀死怪物奖励得分
	int PUNISH_SCORE; // 被怪物杀死或踩到地雷的惩罚
	int SPEEDUP_ROUND; // 加速持续回合
	int REBIRTH_ROUND; // 怪物复活时间
	int RECOVERY_ROUND; // 豆子恢复回合
	int MAX_NUM_MINES; // 最大地雷数量（特殊豆子数量）
	int INITIAL_SCORE; // 玩家初始得分
} PACKED Constants;

/*
 * 選手信息
 */
typedef struct
{
	enum PLAYER_STATUS status; //狀態
	int x, y; //座標
	int score; //得分
	int num_mines; //可用地雷數目
	int speedup_start_round; //無敵狀態開始的回合
} PACKED Player;

//怪物信息
typedef struct 
{
	enum MONSTER_STATUS status; //狀態
	int id; //編號
	int x, y; //座標
	int birth_x; //出生x座標
	int birth_y; //出生y座標
	int birth_dir; //出生方向
	int dead_time; //上次死亡的回合
} PACKED Monster;

//地圖信息
typedef struct
{
	char element; //位置元素 #障礙 .豆子 $特殊豆子 <Space>空地
	int exist; //如果是豆子的話，是否沒有被吃掉
	int eaten_time; //如果是豆子的話，上次被吃掉的回合(-1爲從來沒有被吃掉)
} PACKED MapElement;

//地雷信息
typedef struct
{
	int x, y; //座標
} PACKED Mine;

//移動信息
typedef struct
{
	int direction; //0U 1R 2D 3L
	int step; //移動的步數
	int set_mine; //是否設置地雷
} PACKED Move;

//遊戲信息
typedef struct
{
	int round;
	int num_mines;
	int id; // player id
	Constants constants;
	MapElement map[50][50];
	Player player[10];
	Monster monster[10];
	Mine mines[500];
} PACKED Game;

#ifdef __cplusplus
extern "C" {
#endif

//接口聲明
DllExport Move decide(const Game * game_info);

/*
 * print log information
 */
DllExport void log_printf(const char *fmt, ...) FMT_PRINTF;

#ifdef __cplusplus
}
#endif

#endif
// vim: syntax=cpp foldmethod=marker foldmarker=f{{{,f}}}

/*
 * $File: ailoader.cc
 * $Date: Tue Mar 26 22:50:38 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "ailoader.hh"
#include "include_private/lib.hh"
#include "include_private/config.hh"

#include <exception>

#include <cstdlib>
#include <cmath>

#include <signal.h>
#include <setjmp.h>
#include <time.h>

#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ptrace.h>
#include <sys/time.h>
#include <sys/resource.h>

// variables
static jmp_buf jmp_timeout;
static timer_t round_cpu_timer;

// functions
static void on_sigalarm(int);
static void on_sigxcpu(int);
static void init_signal();

struct AILoader::SubProcShared
{
	static constexpr int ERRMSG_MAXLEN = 2048;
	bool limit_syscall;
	char err_msg[ERRMSG_MAXLEN];
};


void AILoader::mainloop(uint16_t port_num, GameControllerBase &game)
{
	ServerSocket srv(port_num);
	printf("%d\n", srv.port());
	fflush(stdout);
	auto conn(srv.accept());
	AILoader loader(conn, game);
	loader.run();
	exit(0);
}


AILoader::AILoader(SocketBase &conn, GameControllerBase &game):
	m_supervise_flag(true),
	m_conn(conn), m_game(game),
	m_subproc_shared(static_cast<SubProcShared*>(get_shared_mem(sizeof(SubProcShared))))
{
	bzero(m_subproc_shared, sizeof(SubProcShared));
}

AILoader::~AILoader()
{
	unget_shared_mem(m_subproc_shared, sizeof(SubProcShared));
}

void AILoader::run()
{
	if (getenv("AI9_AILOADER_NOSUPERVISOR"))
	{
		fprintf(stderr, "\n===========================================\n"
				"AI9_AILOADER_NOSUPERVISOR set, do not fork and use ptrace");
		m_supervise_flag = false;
		no_supervisor_mode();
		return;
	}
	// become the process group leader, so subproc can be killed
	if (getsid(0) != getpid() && setsid() < 0)
		throw AI9Error("failed to setsid: %m");
	pid_t pid = fork();
	if (pid == -1)
		throw AI9Error("failed to fork: %m");
	if (!pid)
		run_worker();
	else
		run_supervisor();
}

void AILoader::no_supervisor_mode() {
	setup_game();
	m_game.set_connection(m_conn);
	m_game.on_game_init();
	core_loop();
	m_conn.close();
}

void AILoader::run_worker()
{
	init_signal();
	setup_game();
	m_game.set_connection(m_conn);
        m_game.on_game_init();

	if (ptrace(PTRACE_TRACEME, 0, nullptr, nullptr))
		throw AI9Error("failed to ptrace: %m");
	if (getenv("AI9_AILOADER_NOCLOSESTDIO"))
	{
		fprintf(stderr, "\n==============================================\n"
				"AI9_AILOADER_NOCLOSESTDIO set, do not close stdio\n");
	} else
	{
		fclose(stdin);
		fclose(stdout);
		fclose(stderr);
	}
	kill(getpid(), SIGSTOP); // trigger the ptrace
	//core_loop();
	try
	{
		core_loop();
	} catch (std::exception &e)
	{
		asm volatile ("_allow_chgshared_begin1:");
		if (m_subproc_shared->limit_syscall)
			m_subproc_shared->limit_syscall = false;
		mprotect(m_subproc_shared, sizeof(SubProcShared),
				PROT_READ | PROT_WRITE);
		strncpy(m_subproc_shared->err_msg, e.what(),
				SubProcShared::ERRMSG_MAXLEN);
		m_subproc_shared->err_msg[SubProcShared::ERRMSG_MAXLEN - 1] = 0;
		asm volatile ("_allow_chgshared_end1:");
	}
	m_conn.close();
	kill(getpid(), SIGKILL);
}

void AILoader::core_loop() {
	for (; ;)
	{
		Command cmd;
		m_conn >> recvable(cmd);
		switch (cmd)
		{
			case Command::START_ROUND:
				single_round();
				break;
			case Command::FINISH:
				finalize_game();
				m_game.on_game_end();
			case Command::KILL:
				m_conn.close();
				kill(getpid(), SIGKILL);
		}
	}
}

void AILoader::run_supervisor()
{
	typedef RoundResultMeta::Status S;
	RoundResultMeta rst;
	bzero(&rst, sizeof(rst));
	rst.cpu_time = rst.real_time = -1;

	bool opt_set = false,
		 // whether ptrace options have been set

		 prev_is_sigsegv = false;
		 // whether previous stop is cause by SIGSEGV at cancel_limcall (two
		 // consecutive SIGSEGVs are considered real segfault)

	init_syscall_check();
	for (int status; ; )
	{
#define CONTINUE(data) \
	{ \
		ptrace(PTRACE_SYSCALL, pid, nullptr, data); \
		continue; \
	}
		pid_t pid = wait(&status);
		if (pid == -1)
		{
			ai9log(LOG_ERROR, "failed to wait: %m");
			rst.status = S::UNKNOWN_ERROR;
			break;
		}

		if (WIFSTOPPED(status)) // caused by ptrace
		{ // f{{{
			if (!opt_set)
			{
				opt_set = true;
				if (ptrace(PTRACE_SETOPTIONS, pid, nullptr,
							(void*)PTRACE_O_TRACESYSGOOD))
					throw AI9Error("failed to set ptrace option: %m");
				CONTINUE(nullptr);
			}
			size_t sig = WSTOPSIG(status);
			if (sig == SIGSEGV)
			{
				if (!prev_is_sigsegv)
				{
					size_t addr = (size_t)get_instruction_addr(pid);
					extern int
						var_begin0 asm("_allow_chgshared_begin0"),
						var_end0 asm ("_allow_chgshared_end0"),
						var_begin1 asm("_allow_chgshared_begin1"),
						var_end1 asm ("_allow_chgshared_end1");
					size_t addr_begin0 = (size_t)&var_begin0,
						   addr_end0 = (size_t)&var_end0,
						   addr_begin1 = (size_t)&var_begin1,
						   addr_end1 = (size_t)&var_end1;
					if ((addr >= addr_begin0 && addr < addr_end0) ||
							(addr >= addr_begin1 && addr < addr_end1))
					{
						m_subproc_shared->limit_syscall = false;
						if (addr >= addr_begin0 && addr < addr_end0)
							ptrace_goto(pid, &var_begin0);
						else
							ptrace_goto(pid, &var_begin1);


						// by now we can know that a round is completed, so
						// initialize syscall check for next round
						init_syscall_check();

						prev_is_sigsegv = true;
						CONTINUE(nullptr);
					}
				}
				rst.status = S::SEGFAULT;
			}
			else
			{
				prev_is_sigsegv = false;

				if (sig == SIGALRM || sig == SIGXCPU)
					CONTINUE((void*)sig);
				if (sig == (SIGTRAP | 0x80))
				{
					int no;
					if (!m_subproc_shared->limit_syscall ||
							!(no = check_syscall(pid)))
						CONTINUE(nullptr);
					rst.status = S::ILLEGAL_SYSCALL;
					rst.status_data = no;
				}
				else
				{
					rst.status = S::SIGNALED;
					rst.status_data = sig;
				}
			}
			kill(pid, SIGKILL);
			wait(&status);
			break;

		} // f}}} 

		if (WIFSIGNALED(status))
		{
			rst.status = S::SIGNALED;
			rst.status_data = WTERMSIG(status);
			break;
		}

		if (WIFEXITED(status))
		{
			rst.status = S::EXITED;
			rst.status_data = WEXITSTATUS(status);
			break;
		}
#undef CONTINUE
	}
	if (m_subproc_shared->err_msg[0])
	{
		rst.status = S::OTHER_ERROR;
		strncpy(rst.err_msg, m_subproc_shared->err_msg,
				RoundResultMeta::ERRMSG_MAXLEN);
		rst.err_msg[RoundResultMeta::ERRMSG_MAXLEN - 1] = 0;
	}
	try
	{
		m_conn << sendable(rst);
	} catch (AI9Error &)
	{
	}
	m_conn.close();
	if (m_subproc_shared->err_msg[0])
		throw AI9Error("%s", m_subproc_shared->err_msg);
}

void AILoader::single_round()
{
	RoundInfoMeta info;
	m_conn >> recvable(info);
	m_game.on_round_start();
	RoundResultMeta rst;

	if (m_supervise_flag)
		run_user_func(info, rst);
	else
		m_game.do_round();

	m_conn << sendable(rst);
	if (rst.status != RoundResultMeta::Status::NORMAL)
		exit(0);
	m_game.on_round_end();
}

void AILoader::run_user_func(const RoundInfoMeta &info, RoundResultMeta &rst)
{
	typedef RoundResultMeta::Status S;

    // RLIMIT_CPU is an absolute, coarse process lifetime limit. Its
    // accounting can signal before this round's precise CPU allowance.
    // Use the same thread CPU clock as get_cputime(), with a relative timer.
    sigset_t timeout_mask, previous_mask;
    sigemptyset(&timeout_mask);
    sigaddset(&timeout_mask, SIGXCPU);
    sigaddset(&timeout_mask, SIGALRM);
    if (sigprocmask(SIG_BLOCK, &timeout_mask, &previous_mask))
        throw AI9Error("sigprocmask: %m");
    timespec no_wait{};
    while (sigtimedwait(&timeout_mask, nullptr, &no_wait) >= 0) {}

    double cpu0 = get_cputime(), real0 = get_realtime();
    if (!setjmp(jmp_timeout))
    {
        itimerspec timer{};
        timer.it_value.tv_sec = static_cast<time_t>(info.rlim_cpu);
        timer.it_value.tv_nsec = static_cast<long>(
            (info.rlim_cpu - timer.it_value.tv_sec) * 1e9);
        if (!timer.it_value.tv_sec && !timer.it_value.tv_nsec)
            timer.it_value.tv_nsec = 1;
        if (timer_settime(round_cpu_timer, 0, &timer, nullptr))
            throw AI9Error("timer_settime: %m");
        alarm(int(REAL_TIME_LIMIT_DELTA + info.rlim_cpu));
        if (sigprocmask(SIG_SETMASK, &previous_mask, nullptr))
            throw AI9Error("sigprocmask: %m");
        m_subproc_shared->limit_syscall = true;
        mprotect(m_subproc_shared, sizeof(SubProcShared), PROT_READ);
        m_game.do_round();
    } else
        rst.status = S::TIMED_OUT;

	// unget_shared_mem(m_subproc_shared, sizeof(SubProcShared));
	// uncomment the line above to test for munmap m_subproc_shared in user func

	asm volatile ("_allow_chgshared_begin0:");
	if (m_subproc_shared->limit_syscall)
		m_subproc_shared->limit_syscall = false;
	asm volatile ("_allow_chgshared_end0:");
	mprotect(m_subproc_shared, sizeof(SubProcShared), PROT_READ | PROT_WRITE);


    // Block, disarm, and drain before leaving this setjmp frame. A queued
    // timeout must never jump into a completed round or the next one.
    if (sigprocmask(SIG_BLOCK, &timeout_mask, nullptr))
        throw AI9Error("sigprocmask: %m");
    itimerspec disarmed{};
    if (timer_settime(round_cpu_timer, 0, &disarmed, nullptr))
        throw AI9Error("timer_settime: %m");
    alarm(0);
    while (sigtimedwait(&timeout_mask, nullptr, &no_wait) >= 0)
        rst.status = S::TIMED_OUT;

    rst.cpu_time = get_cputime() - cpu0;
    rst.real_time = get_realtime() - real0;
    if (rst.cpu_time >= info.rlim_cpu)
        rst.status = S::TIMED_OUT;
    if (rst.status == S::TIMED_OUT)
        fprintf(stderr, "AI9_ROUND_TIMEOUT cpu_limit=%.9f cpu=%.9f real=%.9f\n",
                info.rlim_cpu, rst.cpu_time, rst.real_time);
    if (sigprocmask(SIG_SETMASK, &previous_mask, nullptr))
        throw AI9Error("sigprocmask: %m");
}

void AILoader::setup_game()
{
	GameInfoMeta info;
	m_conn >> recvable(info);
	struct rlimit rlim{info.rlim_mem, info.rlim_mem};
	if (setrlimit(RLIMIT_AS, &rlim))
		throw AI9Error("setrlimit(RLIMIT_AS, %d): %m", info.rlim_mem);
}

void AILoader::finalize_game()
{
	m_conn << m_game.get_log_msg();
}

void AILoader::add_allowed_open_path(const char *path)
{
	::add_allowed_open_path(path);
}

void init_signal()
{
    sigevent event{};
    event.sigev_notify = SIGEV_SIGNAL;
    event.sigev_signo = SIGXCPU;
    if (timer_create(CLOCK_THREAD_CPUTIME_ID, &event, &round_cpu_timer))
        throw AI9Error("timer_create: %m");
	struct sigaction act;
	bzero(&act, sizeof(act));
	act.sa_handler = on_sigxcpu;
	sigaction(SIGXCPU, &act, nullptr);
	act.sa_handler = on_sigalarm;
	sigaction(SIGALRM, &act, nullptr);
}

void on_sigxcpu(int)
{
	longjmp(jmp_timeout, 1);
}

void on_sigalarm(int)
{
	longjmp(jmp_timeout, 1);
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}

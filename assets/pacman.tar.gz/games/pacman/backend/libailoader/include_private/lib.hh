/*
 * $File: lib.hh
 * $Date: Thu Nov 01 09:58:07 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

#include <cstddef>
#include <unistd.h>

double get_cputime();
double get_realtime();


void* get_shared_mem(size_t len);
void unget_shared_mem(void *addr, size_t len);

/*!
 * \brief check whether this is a legal system call in a ptrace stop
 * return non-zero for illegal call number.
 */
int check_syscall(pid_t pid);

void init_syscall_check();

/*!
 * \brief get instruction address in a ptrace stop
 */
void *get_instruction_addr(pid_t pid);

void ptrace_goto(pid_t pid, void *addr);

void add_allowed_open_path(const char *path);

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


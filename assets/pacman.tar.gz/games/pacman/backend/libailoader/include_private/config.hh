/*
 * $File: config.hh
 * $Date: Mon Oct 15 20:14:57 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

constexpr int REAL_TIME_LIMIT_DELTA = 3;
///< real_time_limit = cpu_time_limit  + REAL_TIME_LIMIT_DELTA

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


/*
 * $File: ailoader.hh
 * $Date: Fri Mar 22 19:50:23 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

#include "msg.hh"
#include "socket.hh"
#include <string>

/*!
 * \brief base class for a specific game
 */
class GameControllerBase
{
	protected:
		SocketBase *m_conn;
	public:
		virtual ~GameControllerBase() {}
		virtual void set_connection(SocketBase &conn)
		{ m_conn = &conn; }

		virtual void on_game_init() = 0;

		/*!
		 * \brief read information and start player AI;
		 *	** do not write to m_conn in this function **
		 */
		virtual void on_round_start() = 0;

		/*!
		 * \brief Call user AI functions here.
		 *  The reported CPU time is that of this function.
		 *  Note: untrusted code should only be allowed to execute here!
		 *  load user AI code on the first call
		 */
		virtual void do_round() = 0;

		/*!
		 * \brief round ends, send back result using m_conn
		 */
		virtual void on_round_end() = 0;

		/*!
		 * \brief finalize here
		 *
		 * *Note:* do not run untrusted code here;
		 *	the process will be killed directly afterward, since it is hard to
		 *	set a reasonable limit on finalization resource usage
		 */
		virtual void on_game_end() = 0;

		/*!
		 * \brief return logging message
		 */
		virtual std::string get_log_msg() = 0;
};

class AILoader
{
	bool m_supervise_flag;	/// whether to supervise AI
	SocketBase &m_conn;
	GameControllerBase &m_game;
	struct SubProcShared;
	SubProcShared *m_subproc_shared;

	AILoader(SocketBase &conn, GameControllerBase &game);
	~AILoader();
	AILoader(const AILoader &) = delete;

	void run();

	void no_supervisor_mode();

	void core_loop();

	void run_worker();
	void run_supervisor();

	void setup_game();
	void single_round();
	void finalize_game();

	/*!
	 * \brief execute m_game.do_round in protected environment
	 */
	void run_user_func(const RoundInfoMeta &info, RoundResultMeta &rst);

	public:
		static void mainloop(uint16_t port_num, GameControllerBase &game) 
			__attribute__((noreturn));

		/*!
		 * \brief Add a path to the list of allowed open file path
		 */
		static void add_allowed_open_path(const char *path);
};

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


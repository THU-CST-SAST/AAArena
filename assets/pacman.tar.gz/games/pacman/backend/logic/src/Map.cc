﻿#include "json/json.h"
#include "Map.h"
#include "common.h"
#include <cstdio>
#include <fstream>
#include <string>

void Map::init(const char* file , const Constants& constants)
{
	std::ifstream fin(file);
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);
	Json::Value root;
	Json::Reader reader;
	if (!reader.parse(res , root))
	{
		// EXCEPTION
		return;
	}
	std::string str_map = root["initial_map"].asString();
	int l = 0;
	for (int i = 0; i <= constants.HEIGHT + 1; ++i)
	{
		for (int j = 0; j <= constants.WIDTH + 1; ++j)
		{
			data[i][j].element = str_map[l++];
			if (data[i][j].element == '.' || data[i][j].element == '$' || data[i][j].element == '#')
			{
				data[i][j].exist = 1;
			}
			else
			{
				if (data[i][j].element != ' ')
				{
					data[i][j].element = '.';
					data[i][j].exist = 1;
				}
			}
		}
		l++;
	}
	fin.close();
}

void Map::update(const Event& event)
{
	if (event.type == Event::EAT)
	{
		int x = event.x , y = event.y;
		if (data[x][y].exist)
		{
			data[x][y].exist = 0;
			data[x][y].eaten_time = event.time;
		}
	}
}

void Map::recovery(int now_time , const Constants& constants)
{
	for (int x = 1; x <= constants.HEIGHT; ++x)
	{
		for (int y = 1; y <= constants.WIDTH; ++y)
		{
			//if (data[x][y].element == '$' && (!data[x][y].exist)) data[x][y].element = '.';
			if (data[x][y].element == '.' || data[x][y].element == '$')
			{
				if (!data[x][y].exist && data[x][y].eaten_time + constants.RECOVERY_ROUND == now_time)
				{
					data[x][y].exist = 1;
				}
			}
		}
	}
}

inline bool isin(const int& x , const int& y , const Constants& constants)
{
	return (x >= 1) && (x <= constants.HEIGHT) && (y >= 1) && (y <= constants.WIDTH);
}

bool Map::can_move(int x , int y , int direction , int step , const Constants& constants) const
{
	for (int s = 1; s <= step; ++s)
	{
		int nx = x + dx[direction] * s;
		int ny = y + dy[direction] * s;
		if (!isin(nx , ny , constants) || this->data[nx][ny].element == '#') return 0;
	}
	return 1;
}

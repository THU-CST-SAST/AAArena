#ifndef MAP_H
#define MAP_H

#include "AI.h"
#include "Event.h"
#include "Constants.h"

class Map
{
public:
	sdk::MapElement data[50][50];
	void update(const Event& event);
	void recovery(int now_time , const Constants& constants);
	void init(const char* file , const Constants& constants);
	bool can_move(int x , int y , int direction , int step , const Constants& constants) const;
};

#endif

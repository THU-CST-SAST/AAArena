﻿#ifndef CONSTANTS_H
#define CONSTANTS_H

#include "AI.h"

struct Constants: public sdk::Constants
{
	void init(const char* file);
};

#endif // CONSTANTS_H
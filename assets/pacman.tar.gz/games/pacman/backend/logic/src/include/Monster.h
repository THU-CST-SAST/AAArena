﻿#ifndef MONSTER_H
#define MONSTER_H

#include "AI.h"
#include "Move.h"
#include "Map.h"
#include "Constants.h"
#include <vector>

struct Monster: public sdk::Monster
{
	std::vector<int> previous_directions; //上一步的能走的方向
	int previous_chosen_direction; //上一步选择的方向

	void init(int _id, const char* file , const Constants& constants);
	Move get_move(const Map& game_map , const Constants& constants);
	Move get_move_level_4(int id, int round);
	Move get_move_level_5(int id, int round);
	void update(const Event& event);
};

#endif

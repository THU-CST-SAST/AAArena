#ifndef COMMON_H
#define COMMON_H

#include "GameInfo.h"

Move make_move_0(const GameInfo& game_info);
Move make_move_1(const GameInfo& game_info);

const int dx[] = {-1 , 0 , 1 , 0};
const int dy[] = {0 , 1 , 0 , -1};

#endif // COMMON_H

#ifndef EVENT_H
#define EVENT_H

struct Event
{
	enum EVENT_TYPE
	{
		PLAYER_KILL_MONSTER = 0 , 
		PLAYER_KILLED_BY_MONSTER ,
		SET_MINE ,
		PLAYER_KILLED_BY_MINE ,
		PLAYER_EXPLODE_MINE ,
		EAT ,
		NOTHING
	};
	EVENT_TYPE type;
	int player_id , monster_id;
	int time , x , y;

	Event() : type(NOTHING) , player_id(-1) , monster_id(-1) ,
		time(-1) , x(0) , y(0) {}
};

#endif

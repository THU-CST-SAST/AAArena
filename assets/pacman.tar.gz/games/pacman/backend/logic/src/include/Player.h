#ifndef PLAYER_H
#define PLAYER_H

#include "AI.h"
#include "Event.h"
#include "Constants.h"

struct Player: public sdk::Player
{
	int id; //編號
	int previous_direction; //上一步的方向

	void init(int _id, const char* file , const Constants& constants);
	void update(const Event& event , const Constants& constants);
};

#endif

﻿#ifndef CONTEST_H
#define CONTEST_H

#include "GameInfo.h"

class Contest
{
public:
	int goal_x , goal_y , goal_score;
	virtual void init();
	virtual int check_success(const GameInfo& game_info);
	virtual ~Contest() {}
};

class ContestLevelOne: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

class ContestLevelTwo: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

class ContestLevelThree: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

class ContestLevelFour: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

class ContestLevelFive: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

class ContestLevelSix: public Contest
{
public:
	void init();
	int check_success(const GameInfo& game_info);
};

#endif // CONTEST_H

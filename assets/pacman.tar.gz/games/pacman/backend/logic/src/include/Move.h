#ifndef MOVE_H
#define MOVE_H

#include "AI.h"

typedef sdk::Move Move;

#endif

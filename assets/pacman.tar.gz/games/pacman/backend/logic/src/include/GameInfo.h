﻿#ifndef LOGIC_MAIN_H
#define LOGIC_MAIN_H

#include "AI.h"
#include "Player.h"
#include "Map.h"
#include "Monster.h"
#include "Move.h"
#include "Constants.h"

#include <vector>
#include <string>
using std::vector;
using std::string;

struct Mine: public sdk::Mine
{
	int set_time;
	bool exist;
};

class GameInfo
{
public:
	Constants constants;
	Map game_map;
	Player player[10];
	Monster monster[10];
	vector<Mine> mine;
	int round;
	int mode;
	bool error_occur[10];
	string error_type[10];

	Move player_move[10];
	Move monster_move[10];
	vector<Event> events;
	
	void init(const char* file);
	void collect_player_move();
	void calc_monster_move();
	void collect_move(char* file);
	void run();
	void update();
};

inline void justify_move(Move& mov , const Player& ply , const Map& game_map);

inline bool judge_cross(const Player& ply , const Move& ply_mov , 
	const Monster& mon , const Move& mon_mov);

inline bool judge_mine(const Player& ply , const Move& ply_mov ,
	const Mine& mine);

#endif // LOGIC_MAIN_H

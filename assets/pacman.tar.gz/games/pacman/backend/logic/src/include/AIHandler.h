#ifndef AI_HANDLER_H
#define AI_HANDLER_H

#include "AI.h"
void user_ai_init(int argc, char **argv);
void user_ai_finalize();
sdk::Move user_ai_action(sdk::Game & game);

#endif

#ifndef REPLAY_MAKER_H
#define REPLAY_MAKER_H

#include "Constants.h"
#include "GameInfo.h"
#include <string>

using std::string;

class ReplayMaker
{
public:
	string str;
	GameInfo pre, now;

	ReplayMaker() : str("") {}
	void add_init_map(const Constants& constants);
	void add_map_change(const Constants& constants);
	void add_creature_change(const Constants& constants);
	void add_mines();
	void add_mine_change();
	void add_init_round(const Constants& constants);
	void add_new_round(const Constants& constants);
};

#endif // REPLAY_MAKER_H

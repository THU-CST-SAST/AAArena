#include "json/json.h"
#include "Player.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>

void Player::init(int _id , const char* file , const Constants& constants)
{
	std::ifstream fin(file);
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);
	Json::Value root;
	Json::Reader reader;
	if (!reader.parse(res , root))
	{
		// EXCEPTION
		return;
	}
	id = _id;
	int j = 0;
	const Json::Value creatures = root["breadcrumbs"][j]["creatures"];
	for (int i = 0; i < creatures.size(); ++i)
	{
		const Json::Value ply = creatures[i];
		int j = 0;
		int tp = ply[j++].asInt();
		if (id == tp)
		{
			x = ply[j++].asInt();
			y = ply[j++].asInt();
			previous_direction = rand() % 4;
		}
	}
	status = sdk::NORMAL;
	score = constants.INITIAL_SCORE;
	num_mines = 0;
	speedup_start_round = -1;
	fin.close();
}

void Player::update(const Event& event , const Constants& constants)
{
	if (event.player_id != id) return;
	if (event.type == Event::PLAYER_KILL_MONSTER)
	{
		score += constants.BONUS_SCORE;		
	}
	if (event.type == Event::PLAYER_KILLED_BY_MONSTER)
	{
		score += constants.PUNISH_SCORE;
	}
	if (event.type == Event::PLAYER_EXPLODE_MINE)
	{
		//s = sdk::NORMAL;
		//speedup_start_round = -1;
	}
	if (event.type == Event::PLAYER_KILLED_BY_MINE)
	{
		score += constants.PUNISH_SCORE;
	}
	if (event.type == Event::EAT)
	{
		if (event.monster_id == constants.BEAN_SCORE)
		{
			score += constants.BEAN_SCORE;
		}
		else
		{
			num_mines++;
			score += constants.TREASURE_SCORE;
			status = sdk::SPEEDUP;
			speedup_start_round = event.time + 1;
		}
	}
}

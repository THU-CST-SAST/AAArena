﻿/*
 * $File: GameInfo.cc
 * $Date: Thu Nov 15 23:18:21 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "common.h"
#include "Constants.h"
#include "GameInfo.h"
#include "AI.h"
#include "AIHandler.h"
#include "json/json.h"

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <fstream>
#include <string>
#include <stdexcept>

inline int cmp(const double& x)
{
	const static double precision = 1e-6;
	return (x < -precision ? -1 : (x > precision));
}

inline void justify_move(Move& mov , const Player& ply , const Map& game_map , const Constants& constants)
{
	if (mov.direction < 0 || mov.direction > 3) mov.direction = ply.previous_direction;
	
	if (mov.step < 1 || mov.step > 2)
	{
		if (ply.status == sdk::SPEEDUP) mov.step = 2;
		else mov.step = 1;
	}
	else
	{
		if (ply.status != sdk::SPEEDUP) mov.step = 1;
	}
	for (int step = mov.step; step >= 0; --step)
	{
		if (game_map.can_move(ply.x , ply.y , mov.direction , step , constants))
		{
			mov.step = step;
			return;
		}
	}
}

inline bool judge_cross(const Player& ply , const Move& ply_mov , 
	const Monster& mon , const Move& mon_mov)
{
	double p_vx = (double)dx[ply_mov.direction] * ply_mov.step;
	double p_vy = (double)dy[ply_mov.direction] * ply_mov.step;
	double m_vx = (double)dx[mon_mov.direction] * mon_mov.step;
	double m_vy = (double)dy[mon_mov.direction] * mon_mov.step;

	double a1 = p_vx - m_vx , b1 = (double)mon.x - ply.x;
	double a2 = p_vy - m_vy , b2 = (double)mon.y - ply.y;

	if (cmp(a1) == 0 && cmp(b1) != 0) return 0;
	if (cmp(a2) == 0 && cmp(b2) != 0) return 0;
	if (cmp(a1) == 0 && cmp(b1) == 0 && cmp(a2) == 0 && cmp(b2) == 0) return 1;

	double t;
	if (cmp(a1) != 0)
	{
		t = b1 / a1;
	}
	else
	{
		if (cmp(a2) != 0) 
			t = b2 / a2;
		else
			t = NAN; //FIXME t should be assigned
	}

	if (cmp(t - 0.0) > 0 && cmp(t - 1.0) <= 0) 
	{
		if (cmp(a1 * t - b1) == 0 && cmp(a2 * t - b2) == 0) return 1;
	}
	return 0;
}

inline bool judge_mine(const Player& ply , const Move& ply_mov ,
	const Mine& mine)
{
	for (int step = 1; step <= ply_mov.step; ++step)
	{
		int x = ply.x + dx[ply_mov.direction] * step;
		int y = ply.y + dy[ply_mov.direction] * step;
		if (mine.exist == 1 && x == mine.x && y == mine.y) return 1;
	}
	return 0;
}

void GameInfo::init(const char* file)
{
	round = 0;
	
	std::ifstream fin(file);
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);
	Json::Value root;
	Json::Reader reader;
	if (!reader.parse(res , root))
	{
		// EXCEPTION
		return;
	}
	std::string str_mode = root["mode"].asString();
	if (str_mode == "fight") mode = 0;
	if (str_mode == "contest_level_1") mode = 1;
	if (str_mode == "contest_level_2") mode = 2;
	if (str_mode == "contest_level_3") mode = 3;
	if (str_mode == "contest_level_4") mode = 4;
	if (str_mode == "contest_level_5") mode = 5;
	if (str_mode == "contest_level_6") mode = 6;
	
	if (mode == 5 || mode == 6)
	{
		int j = 0;
		const Json::Value jmines = root["breadcrumbs"][j]["mines"];
		for (int i = 0; i < jmines.size(); ++i)
		{
			const Json::Value jmine = jmines[i];
			Mine new_mine;
			j = 0;
			new_mine.x = jmine[j++].asInt();
			new_mine.y = jmine[j++].asInt();
			new_mine.exist = 1;
			new_mine.set_time = 0;
			mine.push_back(new_mine);
		}
	}
	
	memset(error_occur , 0 , sizeof(error_occur));
	constants.init(file);
	game_map.init(file , constants);
	for (int i = 0; i < constants.PLAYER_NUMS; ++i) player[i].init(i , file , constants);
	for (int i = 0; i < constants.MONSTER_NUMS; ++i) monster[i].init(i , file , constants);
}

void GameInfo::collect_player_move()
{
	sdk::Game game;
	game.round = round;
	assert(sizeof(game.map) == sizeof(this->game_map.data));
	memcpy(game.map, this->game_map.data, sizeof(game.map));
	for (int i = 0; i < constants.PLAYER_NUMS; i ++)
		game.player[i] = this->player[i];
	for (int i = 0; i < constants.MONSTER_NUMS; i ++)
		game.monster[i] = this->monster[i];
	game.constants = this->constants;
	assert((int)mine.size() < constants.MAX_NUM_MINES);
	game.num_mines = 0;
	for (auto &i: this->mine)
		if (i.exist)
			game.mines[game.num_mines ++] = i;
	
	for (int i = 0; i < constants.PLAYER_NUMS; i ++)
	{
		game.id = i;
		try
		{
			player_move[i] = user_ai_action(game);
		}
		catch (std::runtime_error &err)
		{
			error_occur[i] = 1;
			error_type[i] = err.what();
		}
	}
	
}

void GameInfo::calc_monster_move()
{
	if (mode == 0)
	{
		for (int j = 0; j < constants.MONSTER_NUMS; ++j)
			monster_move[j] = monster[j].get_move(game_map , constants);
	}
	if (mode == 4)
	{
		for (int j = 0; j < constants.MONSTER_NUMS; ++j)
			monster_move[j] = monster[j].get_move_level_4(j , round);
	}
	if (mode == 5)
	{
		for (int j = 0; j < constants.MONSTER_NUMS; ++j)
			monster_move[j] = monster[j].get_move_level_5(j , round);
	}
}

void GameInfo::collect_move(char* file)
{
}

void GameInfo::run()
{
	events.clear();
	Event eve;
	for (int i = 0; i < constants.PLAYER_NUMS; ++i)
	{
		Move mov;

		// check move
		mov = player_move[i];
		justify_move(mov , player[i] , game_map , constants);
		player_move[i] = mov;

		// set mine
		if (mov.set_mine == 1 && player[i].num_mines > 0)
		{
			player[i].num_mines--;
			eve.type = Event::SET_MINE;
			eve.time = round;
			eve.x = player[i].x; eve.y = player[i].y;
			events.push_back(eve);
		}

		// eat
		for (int s = 1; s <= mov.step; ++s)
		{
			int x = player[i].x + dx[mov.direction] * s;
			int y = player[i].y + dy[mov.direction] * s;
			if ((game_map.data[x][y].element == '.' || game_map.data[x][y].element == '$') &&
				game_map.data[x][y].exist)
			{
				eve.type = Event::EAT;
				eve.player_id = i;
				eve.time = round;
				if (game_map.data[x][y].element == '.') eve.monster_id = constants.BEAN_SCORE;
				else eve.monster_id = constants.TREASURE_SCORE;
				eve.x = x; eve.y = y;
				events.push_back(eve);
			}
		}

		// kill or be killed by monster
		for (int j = 0; j < constants.MONSTER_NUMS; ++j)
		{
			if (monster[j].status == sdk::KILLED) continue;
			if (judge_cross(player[i] , mov , monster[j] , monster_move[j]))
			{
				if (player[i].status == sdk::NORMAL)
				{
					eve.type = Event::PLAYER_KILLED_BY_MONSTER;
					eve.time = round;
					eve.player_id = i;
					events.push_back(eve);
				}
				else
				{
					eve.type = Event::PLAYER_KILL_MONSTER;
					eve.time = round;
					eve.player_id = i; 
					eve.monster_id = j;
					events.push_back(eve);
				}
			}
		}

		// kill or killed by mine
		for (size_t j = 0; j < mine.size(); ++j)
		{
			if (!mine[j].exist) continue;
			if (judge_mine(player[i] , mov , mine[j]))
			{
				if (player[i].status == sdk::NORMAL)
				{
					eve.type = Event::PLAYER_KILLED_BY_MINE;
					eve.player_id = i;
					eve.monster_id = j;
					eve.time = round;
					events.push_back(eve);
				}
				else
				{
					eve.type = Event::PLAYER_EXPLODE_MINE;
					eve.player_id = i;
					eve.monster_id = j;
					eve.time = round;
					events.push_back(eve);
				}
			}
		}
	}
}

void GameInfo::update()
{
	for (size_t i = 0; i < events.size(); ++i)
	{
		for (int j = 0; j < constants.PLAYER_NUMS; ++j)
			player[j].update(events[i] , constants);
		for (int j = 0; j < constants.MONSTER_NUMS; ++j)
			monster[j].update(events[i]);
		game_map.update(events[i]);
		if (events[i].type == Event::PLAYER_EXPLODE_MINE)
		{
			int k = events[i].monster_id;
			mine[k].exist = 0;
		}
		if (events[i].type == Event::PLAYER_KILLED_BY_MINE)
		{
			int k = events[i].monster_id;
			mine[k].exist = 0;
		}
		if (events[i].type == Event::SET_MINE)
		{
			Mine new_mine;
			new_mine.x = events[i].x; new_mine.y = events[i].y;
			new_mine.exist = 1; new_mine.set_time = events[i].time + 1;
			mine.push_back(new_mine);
		}
	}

	for (int i = 0; i < constants.PLAYER_NUMS; ++i)
	{
		if (player[i].status == sdk::SPEEDUP)
		{
			if (round - player[i].speedup_start_round + 1 == constants.SPEEDUP_ROUND)
				player[i].status = sdk::NORMAL;
		}
		player[i].x += dx[player_move[i].direction] * player_move[i].step;
		player[i].y += dy[player_move[i].direction] * player_move[i].step;
		player[i].previous_direction = player_move[i].direction;
	}
	for (int i = 0; i < constants.MONSTER_NUMS; ++i)
	{
		if (monster[i].status == sdk::KILLED)
		{
			if (round - monster[i].dead_time + 1 == constants.REBIRTH_ROUND)
			{
				monster[i].status = sdk::ALIVE;
				monster[i].x = monster[i].birth_x;
				monster[i].y = monster[i].birth_y;
				monster[i].previous_chosen_direction = monster[i].birth_dir;
				monster[i].dead_time = -1;
			}
		}
		else
		{
			monster[i].x += dx[monster_move[i].direction] * monster_move[i].step;
			monster[i].y += dy[monster_move[i].direction] * monster_move[i].step;
			monster[i].previous_chosen_direction = monster_move[i].direction;
		}
	}

	vector<Mine> new_mines;
	for (int k = 0; k < (int)mine.size(); ++k)
	{
		if (mine[k].exist) new_mines.push_back(mine[k]);
	}
	mine = new_mines;
	game_map.recovery(round , constants);
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}

#include "ReplayMaker.h"
#include "Constants.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

void ReplayMaker::add_init_map(const Constants& constants)
{
	str += "\"initial_map\": \"";
	for (int i = 0; i <= constants.HEIGHT + 1; ++i)
	{
		for (int j = 0; j <= constants.WIDTH + 1; ++j)
		{
			str.push_back(now.game_map.data[i][j].element);
		}
		str += ("\\n");
	}
	str += "\"";
};

inline string int_to_string(int x)
{
	if (x == 0) return string("0");
	string res("");
	if (x < 0)
	{
		x = -x;
		res += "-";
	}
	int base = 1;
	while (base <= x) base *= 10;
	base /= 10;
	while (base)
	{
		int bit = x / base;
		bit %= 10;
		res.push_back('0' + bit - 0);
		base /= 10;
	}
	return res;
}

void ReplayMaker::add_map_change(const Constants& constants)
{
	str += "\"map\": [ ";
	int tot = 0;
	for (int i = 1; i <= constants.HEIGHT; ++i)
	{
		for (int j = 1; j <= constants.WIDTH; ++j)
		{
			if (pre.game_map.data[i][j].exist == 1 &&
				now.game_map.data[i][j].exist == 0)
			{
				if (tot) str += ", ";
				str += "[";
				//str += int_to_string(i) + "," + int_to_string(j) + ",\" \"";
				str += int_to_string(j) + "," + int_to_string(i) + ",\" \"";
				str += "]";
				tot++;
			}
			if (pre.game_map.data[i][j].exist == 0 &&
				now.game_map.data[i][j].exist == 1)
			{
				if (tot) str += ", ";
				str += "[";
				//str += int_to_string(i) + "," + int_to_string(j) + ",\".\"";
				str += int_to_string(j) + "," + int_to_string(i) + ",\"";
				str.push_back(now.game_map.data[i][j].element);
				str += "\"]";
				tot++;
			}
		}
	}
	str += " ]";
}

void ReplayMaker::add_creature_change(const Constants& constants)
{
	str += "\"creatures\": [ ";
	int tot = 0;
	for (int i = 0; i < constants.PLAYER_NUMS; ++i)
	{
		if (tot) str += ", ";
		tot++;
		str += "[" + int_to_string(i) + ",";
		//str += int_to_string(now.player[i].x) + "," + int_to_string(now.player[i].y);
		str += int_to_string(now.player[i].y) + "," + int_to_string(now.player[i].x);
		if (now.player[i].status == sdk::SPEEDUP) str += ",1";
		else
			if (pre.player[i].score > now.player[i].score) str += ",-1";

		str += "," + int_to_string(now.player[i].num_mines);
		
		str += "]";
	}
	for (int i = 0; i < constants.MONSTER_NUMS; ++i)
	{
		
		if (tot) str += ", ";
		tot++;
		str += "[-" + int_to_string(i + 1) + ",";
		if (now.monster[i].status == sdk::ALIVE)
			//str += int_to_string(now.monster[i].x) + "," + int_to_string(now.monster[i].y) + "]";
			str += int_to_string(now.monster[i].y) + "," + int_to_string(now.monster[i].x) + ",1]";
		else
			str += int_to_string(now.monster[i].birth_y) + "," + int_to_string(now.monster[i].birth_x) + ",-1]";
	}
	str += " ]";
}

void ReplayMaker::add_mines()
{
	str += "\"mines\": [ ";
	int tot = 0;
	for (size_t i = 0; i < now.mine.size(); ++i)
	{
		if (tot) str += ", ";
		tot++;
		//str += "[" + int_to_string(now.mine[i].x) + "," + int_to_string(now.mine[i].y) + "]";
		str += "[" + int_to_string(now.mine[i].y) + "," + int_to_string(now.mine[i].x) + "]";
	}
	str += " ]";
}

void ReplayMaker::add_mine_change()
{
	str += "\"mines\": [ ";
	int tot = 0;
	for (size_t i = 0; i < now.mine.size(); ++i)
	{
		bool is_new = 1; 
		for (int j = 0; j < (int)pre.mine.size(); ++j)
		{
			if (now.mine[i].x == pre.mine[j].x &&
				now.mine[i].y == pre.mine[j].y &&
				now.mine[i].set_time == pre.mine[j].set_time)
			{
				is_new = 0;
				break;
			}
		}
		if (is_new)
		{
			if (tot) str += ", ";
			tot++;
			//str += "[" + int_to_string(now.mine[i].x) + "," + int_to_string(now.mine[i].y) + "]";
			str += "[" + int_to_string(now.mine[i].y) + "," + int_to_string(now.mine[i].x) + "]";
		}
	}

	for (int i = 0; i < (int)pre.mine.size(); ++i)
	{
		bool is_disapp = 1;
		for (int j = 0; j < (int)now.mine.size(); ++j)
		{
			if (pre.mine[i].x == now.mine[j].x &&
				pre.mine[i].y == now.mine[j].y &&
				pre.mine[i].set_time == now.mine[j].set_time)
			{
				is_disapp = 0;
				break;
			}
		}
		if (is_disapp)
		{
			if (tot) str += ", ";
			tot++;
			//str += "[" + int_to_string(pre.mine[i].x) + "," + int_to_string(pre.mine[i].y) + "]";
			str += "[" + int_to_string(pre.mine[i].y) + "," + int_to_string(pre.mine[i].x) + "]";
		}
	}
	str += " ]";
}

void ReplayMaker::add_new_round(const Constants& constants)
{
	str += "{";
	add_map_change(constants);
	str += ", ";
	add_creature_change(constants);
	str += ", ";
	add_mine_change();
	str += ", ";
	str += "\"scores\": [";
	str += int_to_string(now.player[0].score) + "," + int_to_string(now.player[1].score);
	str += "]";
	str += "}";
	//str += "\n";
}

void ReplayMaker::add_init_round(const Constants& constants)
{
	str += "{";
	add_map_change(constants);
	str += ", ";
	add_creature_change(constants);
	str += ", ";
	add_mines();
	str += ", ";
	str += "\"scores\": [";
	str += int_to_string(now.player[0].score) + "," + int_to_string(now.player[1].score);
	str += "]";
	str += "}";
}
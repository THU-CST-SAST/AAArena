﻿#include "Contest.h"

void Contest::init()
{
}

int Contest::check_success(const GameInfo& game_info)
{
	return 0;
}

void ContestLevelOne::init()
{
	goal_x = 2;
	goal_y = 5;
}

int ContestLevelOne::check_success(const GameInfo& game_info)
{
	if (game_info.player[0].x == goal_x && game_info.player[0].y == goal_y)
		return 1;
	else
		return 0;
}

void ContestLevelTwo::init()
{
	goal_x = 7;
	goal_y = 7;
}

int ContestLevelTwo::check_success(const GameInfo& game_info)
{
	if (game_info.player[0].x == goal_x && game_info.player[0].y == goal_y)
		return 1;
	else
		return 0;
}

void ContestLevelThree::init()
{
	goal_score = 20;
}

int ContestLevelThree::check_success(const GameInfo& game_info)
{
	if (game_info.player[0].score >= goal_score) return 1; else return 0;
}

void ContestLevelFour::init()
{
}

int ContestLevelFour::check_success(const GameInfo& game_info)
{
    static int pre_score = 0;
	if (game_info.player[0].score < pre_score) return -1;
	if (game_info.player[0].score > 10) return 1;
	pre_score = game_info.player[0].score;
	return 0;
}

void ContestLevelFive::init() 
{
}

int ContestLevelFive::check_success(const GameInfo& game_info)
{
    static int pre_score = 0;
	if (game_info.player[0].score < pre_score) return -1;
	if (game_info.player[0].score > 15) return 1;
	pre_score = game_info.player[0].score;
	return 0;
}

void ContestLevelSix::init() 
{
}

int ContestLevelSix::check_success(const GameInfo& game_info)
{
    if (game_info.round > 10) return -1;
	if (game_info.player[0].score > 21) return 1;
	return 0;
}
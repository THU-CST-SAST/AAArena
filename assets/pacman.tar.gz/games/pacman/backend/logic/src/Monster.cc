#include "json/json.h"
#include "Monster.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <string>

using std::vector;

void Monster::init(int _id , const char* file , const Constants& constants)
{
	std::ifstream fin(file);
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);
	Json::Value root;
	Json::Reader reader;
	if (!reader.parse(res , root))
	{
		// EXCEPTION
		return;
	}
	id = _id;
	int j = 0;
	const Json::Value creatures = root["breadcrumbs"][j]["creatures"];
	for (int i = 0; i < creatures.size(); ++i)
	{
		const Json::Value ply = creatures[i];
		int j = 0;
		int tp = ply[j++].asInt();
		if (id == -tp - 1)
		{
			birth_x = ply[j++].asInt();
			birth_y = ply[j++].asInt();
			birth_dir = rand() % 4;
		}
	}
	previous_directions.clear();
	previous_chosen_direction = birth_dir;
	status = sdk::ALIVE;
	x = birth_x; y = birth_y; dead_time = -1;
	fin.close();
}

void Monster::update(const Event& event)
{
	if (event.monster_id != id) return;
	if (event.type == Event::PLAYER_KILL_MONSTER)
	{
		status = sdk::KILLED;
		dead_time = event.time;
	}
}

Move Monster::get_move(const Map& game_map , const Constants& constants)
{
	vector<int> can_dir;
	for (int direction = 0; direction < 4; ++direction)
	{
		if (game_map.can_move(x , y , direction , 1 , constants)) 
			can_dir.push_back(direction);
	}
	Move mov;
	bool is_pre_can = 0;
	int choose_dir;
	
	for (int i = 0; i < (int)can_dir.size(); ++i)
	{
		if (can_dir[i] == previous_chosen_direction) is_pre_can = 1;
	}
	
	if (!is_pre_can || can_dir.size() > previous_directions.size())
	{
		int k = can_dir.size();
		choose_dir = can_dir[rand() % k];
		if (k > 1)
		{
			while ((choose_dir + 2) % 4 == previous_chosen_direction)
				choose_dir = can_dir[rand() % k];
		}
	}
	else
	{
		choose_dir = previous_chosen_direction;
	}
	
	mov.direction = choose_dir;
	mov.step = 1;
	
	previous_directions = can_dir;
	previous_chosen_direction = choose_dir;
	return mov;
}

Move Monster::get_move_level_4(int id, int round)
{
    Move move;
    move.step = 0;
    move.direction = 0;
    if (id == 0 && round > 3 && round < 10)
    {
        move.direction = 0;
        move.step = 1;
    }
    if (id == 1 && round > 7 && round < 10)
    {
        move.direction = 2;
        move.step = 1;
    }
    return move;
}

Move Monster::get_move_level_5(int id, int round)
{
    Move move;
    move.step = 0;
    move.direction = 0;
    if (id == 0 && round > 3 && round < 10)
    {
        move.direction = 0;
        move.step = 1;
    }
    if (id == 1 && round > 7 && round < 10)
    {
        move.direction = 2;
        move.step = 1;
    }
    return move;
}
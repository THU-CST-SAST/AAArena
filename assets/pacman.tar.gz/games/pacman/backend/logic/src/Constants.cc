﻿#include "AI.h"
#include "Constants.h"
#include "json/json.h"
#include <cstdio>
#include <fstream>
#include <string>

void Constants::init(const char* file)
{
	std::ifstream fin(file);
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);

	Json::Value root;
	Json::Reader reader;
	
	if (!reader.parse(res , root))
	{
		return; // EXCEPTION
	}
	Json::Value cst = root["constants"];
	MAX_ROUND = cst["max_round"].asInt();
	HEIGHT = cst["height"].asInt();
	WIDTH = cst["width"].asInt();
	PLAYER_SPEED = cst["player_speed"].asInt();
	MONSTER_SPEED = cst["monster_speed"].asInt();
	PLAYER_NUMS = cst["player_nums"].asInt();
	MONSTER_NUMS = cst["monster_nums"].asInt();
	BEAN_SCORE = cst["bean_score"].asInt();
	TREASURE_SCORE = cst["treasure_score"].asInt();
	BONUS_SCORE = cst["bonus_score"].asInt();
	PUNISH_SCORE = cst["punish_score"].asInt();
	SPEEDUP_ROUND = cst["speedup_round"].asInt();
	REBIRTH_ROUND = cst["rebirth_round"].asInt();
	RECOVERY_ROUND = cst["recovery_round"].asInt();
	MAX_NUM_MINES = cst["max_num_mines"].asInt();
	INITIAL_SCORE = cst["initial_score"].asInt();
	
	fin.close();
}

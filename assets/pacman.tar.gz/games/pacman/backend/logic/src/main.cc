﻿/*
 * $File: main.cc
 * $Date: Fri Nov 16 01:05:27 2012 +0800
 */

#include "ai9.hh"
#include "AIHandler.h"

#include "GameInfo.h"
#include "ReplayMaker.h"
#include "Contest.h"

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

static void mainloop();
static bool no_error = true;

int main(int argc, char **argv)
{
	try
	{
		user_ai_init(argc, argv);
		mainloop();
		if (no_error)
			user_ai_finalize();
	}
	catch (std::exception &e)
	{
		fprintf(stderr, "%s: caught exception: %s\n", argv[0], e.what());
		return -1;
	}
}

void contests_init(vector<Contest*>& contests)
{
	Contest* contest_level_1 = new ContestLevelOne;
	contest_level_1->init();
	contests.push_back(contest_level_1);
	Contest* contest_level_2 = new ContestLevelTwo;
	contest_level_2->init();
	contests.push_back(contest_level_2);
	Contest* contest_level_3 = new ContestLevelThree;
	contest_level_3->init();
	contests.push_back(contest_level_3);
	Contest* contest_level_4 = new ContestLevelFour;
	contest_level_4->init();
	contests.push_back(contest_level_4);
	Contest* contest_level_5 = new ContestLevelFive;
	contest_level_5->init();
	contests.push_back(contest_level_5);
	Contest* contest_level_6 = new ContestLevelSix;
	contest_level_6->init();
	contests.push_back(contest_level_6);
}

void mainloop()
{
	const char* aa_arena_seed = getenv("AA_ARENA_GAME_SEED");
    srand(aa_arena_seed ? static_cast<unsigned int>(strtoul(aa_arena_seed, nullptr, 10)) : static_cast<unsigned int>(time(NULL)));
	//freopen("debug_result.txt" , "w" , stdout);
	GameInfo game_info;
	string file_name = "resources.res";
	game_info.init(file_name.c_str());

	ai9log(LOG_INFO, "rounds: %d", game_info.constants.MAX_ROUND);
	
	vector<Contest*> contests;
	contests_init(contests);
	
	bool contest_success_flag = 0;
	
	ReplayMaker replay_maker;
	replay_maker.pre = replay_maker.now = game_info;
	replay_maker.str += "{ ";
	replay_maker.add_init_map(game_info.constants);
	replay_maker.str += " , ";
	replay_maker.str += "\"breadcrumbs\": [ ";
	
	replay_maker.add_init_round(game_info.constants);
		
	for (int r = 1; r <= game_info.constants.MAX_ROUND; ++r)
	{
		game_info.round++;
		replay_maker.pre = game_info;
		game_info.collect_player_move();
		
		for (int i = 0; i < game_info.constants.PLAYER_NUMS; ++i)
		{
			if (game_info.error_occur[i]) no_error = 0;
		}
		if (!no_error) break;
		
		game_info.calc_monster_move();
		game_info.run();
		game_info.update();
		replay_maker.now = game_info;
		replay_maker.str += ", ";
		replay_maker.add_new_round(game_info.constants);
#if 0
		printf("------------------Round %d--------------------\n" , r);
		printf("Events:\n");
		for (auto &eve: game_info.events)
		{
			printf("type = %d, pid = %d, mid = %d, x = %d, y = %d, time = %d\n",
					eve.type, eve.player_id, eve.monster_id, eve.x, eve.y,
					eve.time);
		}

		printf("\nPlayers:\n");
		for (int i = 0; i < game_info.constants.PLAYER_NUMS; ++i)
		{
			Player ply = game_info.player[i];
			printf("id = %d, score = %d, status = %d, x = %d , y = %d , previous_direction = %d, num_mines = %d, start_time = %d\n" , 
					ply.id , ply.score , ply.status , ply.x , ply.y , ply.previous_direction , ply.num_mines , ply.speedup_start_round);
		}

		printf("\nMonsters:\n");
		for (int i = 0; i < game_info.constants.MONSTER_NUMS; ++i)
		{
			Monster mon = game_info.monster[i];
			printf("id = %d , status = %d , x = %d , y = %d , deadtime = %d\n" ,
					mon.id , mon.status , mon.x , mon.y , mon.dead_time);
		}

		printf("\nMines:\n");
		for (auto &m: game_info.mine)
		{
			if (m.exist)
			{
				printf("x = %d, y = %d, set_time = %d\n", m.x, m.y, m.set_time);
			}
		}
		printf("\nNew Map:\n");
		for (int x = 1; x <= 20; ++x)
		{
			for (int y = 1; y <= 20; ++y)
			{
				if (game_info.game_map.data[x][y].exist) printf("%c" , game_info.game_map.data[x][y].element);
				else printf(" ");
			}
			printf("\n");
		}
#endif
		
		// 若出现选手分数为负数,游戏结束
		if (game_info.player[0].score < 0 || game_info.player[1].score < 0)
		{
			if (game_info.player[0].score != game_info.player[1].score) break;
		}
		if (game_info.mode) 
		{
			if (contests[game_info.mode - 1]->check_success(game_info) == 1)
			{
				contest_success_flag = 1;
				break;
			}
			if (contests[game_info.mode - 1]->check_success(game_info) == -1)
			{
				contest_success_flag = 0;
				break;
			}
		}
	}
	replay_maker.str += "], ";
	if (no_error)
	{
		replay_maker.str += "\"result\": ";
		if (game_info.mode == 0)
		{
			if (game_info.player[0].score < game_info.player[1].score)
				replay_maker.str += "-1";
			if (game_info.player[0].score == game_info.player[1].score)
				replay_maker.str += "0";
			if (game_info.player[0].score > game_info.player[1].score)
				replay_maker.str += "1";
		}
		else
		{
			if (contest_success_flag) replay_maker.str += "1";
			else replay_maker.str += "-1";
		}
	}
	else
	{
		replay_maker.str += "\"error\": [";
		bool first = 1;
		if (game_info.error_occur[0]) replay_maker.str += "0" , first = 0;
		if (game_info.error_occur[1]) 
		{
			if (!first) replay_maker.str += ",";
			replay_maker.str += "1";
		}
		replay_maker.str += "], ";
		
		replay_maker.str += "\"error_type\": [";
		first = 1;
		if (game_info.error_occur[0]) replay_maker.str += "\"" + game_info.error_type[0] + "\"" , first = 0;
		if (game_info.error_occur[1]) 
		{
			if (!first) replay_maker.str += ",";
			replay_maker.str += "\"" + game_info.error_type[1] + "\"";
		}
		replay_maker.str += "]";
	}
	replay_maker.str += "}";
	//freopen("replay.txt" , "w" , stdout);
	//printf("%s" , replay_maker.str.c_str());
	ofstream fout("result.txt");
	fout << replay_maker.str << endl;
	fout.close();
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}

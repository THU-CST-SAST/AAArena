﻿#include "AIHandler.h"
#include "ai9.hh"
#include <cstdio>
#include <stdexcept>

static FILE* fp = fopen("log.txt" , "w");

#ifdef LOGIC_LOCAL
	static void logger(const char *fmt, va_list ap)
	{
	}

	#include <stdexcept>

	#ifdef WINDOWS
		#include <windows.h>
	#else
		#include <dlfcn.h>
	#endif

	typedef decltype(sdk::decide) *ai_func_t;
    typedef void (*reg_logger_t)(void*);
	struct UserAI
	{
		ai_func_t decide;
		UserAI(const char * filename)
		{
			#ifdef WINDOWS
				hLibrary = LoadLibrary(filename);
				if (!hLibrary)
					throw std::runtime_error("Unable to load AI DLL");
				decide = reinterpret_cast<ai_func_t>(GetProcAddress((HINSTANCE) hLibrary, "decide"));
				if (!decide)
					throw std::runtime_error("Unable to load 'decide' function in AI DLL");
                
    			reg_logger_t r = reinterpret_cast<reg_logger_t>(GetProcAddress((HINSTANCE) hLibrary, "register_logger"));
    			if (!r)
    				throw std::runtime_error("Unable to load 'register_logic' function in AI DLL");
			#else
				hLibrary = dlopen(filename, RTLD_LAZY);
				if (!hLibrary)
					throw std::runtime_error(dlerror());
				decide = reinterpret_cast<ai_func_t>(dlsym(hLibrary, "decide"));
				if (!decide)
					throw std::runtime_error(dlerror());
                
    			reg_logger_t r = reinterpret_cast<reg_logger_t>(dlsym(hLibrary, "register_logger"));
    			if (!r)
    				throw std::runtime_error(dlerror());
			#endif
            //Register logger
    		r(reinterpret_cast<void*>(logger));
		}
		
		~UserAI()
		{
			#ifdef WINDOWS
				FreeLibrary((HINSTANCE) hLibrary);
			#else
				dlclose(hLibrary);
			#endif
		}
		
	private:
		void * hLibrary;
	};
	UserAI * user_ai[10];
#else
	#include "logic.hh"
#endif // LOGIC_LOCAL

void user_ai_init(int argc, char **argv)
{
#ifdef LOGIC_LOCAL
	#ifdef WINDOWS
	#define AI1_FILE "ai1.dll"
	#define AI2_FILE "ai2.dll"
	#else
	#define AI1_FILE "./ai1.so"
	#define AI2_FILE "./ai2.so"
	#endif
	user_ai[0] = new UserAI(AI1_FILE);
	user_ai[1] = new UserAI(AI2_FILE);
#else
	GameInfoMeta info{1 << 30}; // XXX
	logic::init(argc, argv, info, [](int, SocketBase&){});
	/*
	if (logic::get_nr_ai() != 2)
		throw AI9Error("exactly 2 AIs are needed");
	//FIXME
	*/
#endif
}

void user_ai_finalize()
{
#ifdef LOGIC_LOCAL
#else
	logic::end([](int, SocketBase&){});
	for (int i = 0; i < logic::get_nr_ai(); i ++)
		ai9log(LOG_INFO, "ai %d log: %s\n", i, logic::get_log(i).c_str());
	
	fclose(fp);
#endif
}

sdk::Move user_ai_action(sdk::Game & game)
{
	int i = game.id;
#ifdef LOGIC_LOCAL
	//Directly invoke AI entry point
    return user_ai[i]->decide(&game);
#else
	//Communicate with ai via logic server
	RoundInfoMeta rinfo{1}; // XXX
	auto &conn = logic::get_conn(i);
	logic::start_round(conn, rinfo);
	conn << sendable(game);
	RoundResultMeta rst;
	logic::wait(conn, rst);
	typedef RoundResultMeta::Status S;
	sdk::Move result;
	if (rst.status == S::NORMAL) {
		conn >> recvable(result);
	} else {
		if (rst.status == S::TIMED_OUT) throw std::runtime_error("TIMED_OUT");
		if (rst.status == S::SEGFAULT) throw std::runtime_error("SEGFAULT");
		if (rst.status == S::ILLEGAL_SYSCALL) throw std::runtime_error("ILLEGAL_SYSCALL");
		if (rst.status == S::EXITED) throw std::runtime_error("EXITED");
		if (rst.status == S::SIGNALED) throw std::runtime_error("SIGNALED");
		if (rst.status == S::OTHER_ERROR) throw std::runtime_error("OTHER_ERROR");
		if (rst.status == S::UNKNOWN_ERROR) throw std::runtime_error("UNKNOWN_ERROR");
	}
	return result;
#endif
}

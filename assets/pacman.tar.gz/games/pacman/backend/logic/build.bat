@mkdir deps
@xcopy ..\..\..\liblogic\* deps /E /Y
@xcopy ..\..\..\shared\* deps /E /Y
@echo D | xcopy ..\sdk deps\include\sdk /E /Y
@mkdir winbuild\src
@mkdir winbuild\src\lib_json
@mkdir winbuild\deps
@mingw32-make --makefile=Makefile.win
@rd /s /q deps

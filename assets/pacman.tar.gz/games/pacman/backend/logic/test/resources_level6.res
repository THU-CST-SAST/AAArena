{ 	"initial_map": "#################\n######$...#######\n######$##.#######\n######.##.#######\n######....#######\n######.##$#######\n#$........$.$...#\n#.#######.###.#.#\n#.#######.......#\n#.........#.#.#.#\n#########.......#\n#################\n" ,
	"constants": {"max_round" : 13 ,
				  "height" : 10 ,
				  "width" : 15 ,
				  "player_speed" : 1 ,
				  "monster_speed" : 1 ,
				  "player_nums" : 1 ,
				  "monster_nums" : 0 ,
				  "bean_score" : 1 ,
				  "treasure_score" : 5 ,
				  "bonus_score" : 10 ,
				  "punish_score" : -20 ,
				  "speedup_round" : 10 ,
				  "rebirth_round" : 5 ,
				  "recovery_round" : 100 ,
				  "max_num_mines" : 200 ,
				  "initial_score" : 0} ,
	"breadcrumbs" : [
						{
							"map" : [],
							"creatures" : [
								[0,6,9]
							],
							"mines" : [
                                [6,15],
                                [7,13],
                                [8,13],
                                [8,15],
                                [3,6],
                                [4,9]
							]
						}
					] ,
	"mode" : "contest_level_6"
}

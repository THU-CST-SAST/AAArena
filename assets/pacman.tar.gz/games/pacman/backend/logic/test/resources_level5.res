{ 	"initial_map": "#########\n#.#######\n#.###.###\n#.###.#.#\n#.###.#.#\n#.......#\n#......$#\n#.#####.#\n#########\n" ,
	"constants": {"max_round" : 100 ,
				  "height" : 7 ,
				  "width" : 7 ,
				  "player_speed" : 1 ,
				  "monster_speed" : 1 ,
				  "player_nums" : 1 ,
				  "monster_nums" : 2 ,
				  "bean_score" : 1 ,
				  "treasure_score" : 5 ,
				  "bonus_score" : 10 ,
				  "punish_score" : -20 ,
				  "speedup_round" : 10 ,
				  "rebirth_round" : 5 ,
				  "recovery_round" : 100 ,
				  "max_num_mines" : 200 ,
				  "initial_score" : 0} ,
	"breadcrumbs" : [
						{
							"map" : [],
							"creatures" : [
								[0,1,1],
								[-1,7,1],
								[-2,2,5]
							],
							"mines" : [
                                [6,6] , [6,2] , [6,4]
							]
						}
					] ,
	"mode" : "contest_level_5"
}

/*
 * $File: logic.hh
 * $Date: Mon Oct 15 20:36:16 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

#include "msg.hh"
#include "socket.hh"

#include <functional>

namespace logic
{
	/*!
	 * \brief initialize; call this function once from main
	 * \parm init_each_ai send global information to each AI; received by
	 *		GameControllerBase::on_game_init
	 *		arguments: ai_num, conn
	 */
	void init(int &argc, char **&argv, const GameInfoMeta &game_info, 
			std::function<void(int, SocketBase&)> init_each_ai);

	/*!
	 * \brief return the number of connected AIs
	 */
	int get_nr_ai();

	/*!
	 * \brief return the connection to a specific AI
	 */
	SocketBase& get_conn(int num);

	/*!
	 * \brief call this function first in each round; then send game-specific
	 *			information
	 */
	void start_round(SocketBase &conn, const RoundInfoMeta &info);

	/*!
	 * \brief call this function to wait for AI action
	 *
	 * read other game-specific
	 * information if rst.status == RoundResultMeta::Status::NORMAL
	 */
	void wait(SocketBase &conn, RoundResultMeta &rst);

	/*!
	 * \brief call this function after game ends
	 */
	void end(std::function<void(int, SocketBase&)> end_each_ai);

	/*!
	 * \brief kill the AI that is waiting to start a new round
	 * e.g. used when the opponent AI timed out.
	 */
	void kill(int ai_num);

	/*!
	 * \brief return the log message of an AI; only available after calling end
	 */
	const std::string& get_log(int ai_num);
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


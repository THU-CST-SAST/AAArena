/*
 * $File: logic.cc
 * $Date: Mon Oct 15 22:39:08 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "logic.hh"
#include "ai9.hh"

#include <cstring>
#include <vector>
using namespace std;

static vector<SocketBase> ai_conn;
static vector<string> ai_log_msg;
static void usage(const char *name) __attribute__((noreturn));
static void check_ai_num(int n);

void logic::init(int &argc, char **&argv, const GameInfoMeta &game_info,
			std::function<void(int, SocketBase&)> init_each_ai)
{
	int ai_num = 0;
	for (int i = 1; i < argc; i ++)
		if (!strcmp(argv[i], "--ai"))
		{
			if (i + 1 == argc)
				usage(argv[0]);
			char *v = argv[i + 1];
			bool ok = false;
			for (char *p = v + strlen(v) - 1; p >= v; p --)
				if (*p == ':')
				{
					*p = 0;
					auto cur(ClientSocket(v, p + 1));
					ai_conn.push_back(cur);
					cur << sendable(game_info);
					init_each_ai(ai_num ++, cur);
					ok = true;
					break;
				}
			if (!ok)
				usage(argv[0]);
			argc -= 2;
			for (int j = i; j < argc; j ++)
				argv[j] = argv[j + 2];
			i --;
		}
	if (!ai_num)
		usage(argv[0]);
}

void usage(const char *name)
{
	throw AI9Error("invalid command line argument\n"
			"usage: %s --ai <AI host>:<AI port> ... [<other logic specific options>]",
			name);
}

int logic::get_nr_ai()
{
	return ai_conn.size();
}

SocketBase& logic::get_conn(int num)
{
	check_ai_num(num);
	return ai_conn[num];
}

void logic::start_round(SocketBase &conn, const RoundInfoMeta &info)
{
	conn << sendable(Command::START_ROUND);
	conn << sendable(info);
}

void logic::wait(SocketBase &conn, RoundResultMeta &rst)
{
	conn >> recvable(rst);
}

void logic::end(std::function<void(int, SocketBase&)> end_each_ai)
{
	int num = 0;
	ai_log_msg.resize(ai_conn.size());
	for (auto &cur: ai_conn)
	{
		cur << sendable(Command::FINISH);
		cur >> ai_log_msg[num];
		end_each_ai(num ++, cur);
	}
}

void logic::kill(int ai_num)
{
	check_ai_num(ai_num);
	try
	{
		ai_conn[ai_num] << sendable(Command::KILL);
	} catch (AI9Error&)
	{
	}
}

const std::string& logic::get_log(int ai_num)
{
	check_ai_num(ai_num);
	return ai_log_msg[ai_num];
}

void check_ai_num(int n)
{
	if (n < 0 || n >= logic::get_nr_ai())
		throw AI9Error("no AI nbered %d", n);
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


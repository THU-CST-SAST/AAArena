/*
 * $File: msg.cc
 * $Date: Wed Mar 27 20:06:05 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "msg.hh"

#include <cstdio>
#include <cstring>

const char* RoundResultMeta::status2str(const Status &s) {
#define STAT(name)	if (s == Status::name) return #name;

	STAT(NORMAL);
	STAT(TIMED_OUT);
	STAT(SEGFAULT);
	STAT(ILLEGAL_SYSCALL);
	STAT(EXITED);
	STAT(SIGNALED);
	STAT(OTHER_ERROR);
	STAT(UNKNOWN_ERROR);

	return "unknown";
}

const char* RoundResultMeta::to_str() const {
#ifdef WINDOWS
	return status2str(status);
#else
	static constexpr int MSG_LEN =
		ERRMSG_MAXLEN + 512;
	static char msg[MSG_LEN];
	FILE *fmsg = fmemopen(msg, MSG_LEN, "w");
	typedef Status S;
	if (status == S::ILLEGAL_SYSCALL)
		fprintf(fmsg, "Illegal syscall (%d)", status_data);
	else if (status == S::EXITED)
		fprintf(fmsg, "Exited unexpectedly with code %d",
				status_data);
	else if (status == S::SIGNALED)
		fprintf(fmsg, "Terminated by signal %s(%d)",
				strsignal(status_data), status_data);
	else if (status == S::TIMED_OUT)
		fprintf(fmsg, "Time limit exceeded "
				"(real time: %.3lfms; cpu time: %.3lfms)",
				real_time * 1000, cpu_time * 1000);
	else fprintf(fmsg, "%s", status2str(status));
	if (err_msg[0])
		fprintf(fmsg, " (%s)", err_msg);
	fputc(0, fmsg);
	fclose(fmsg);
	return msg;
#endif
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}

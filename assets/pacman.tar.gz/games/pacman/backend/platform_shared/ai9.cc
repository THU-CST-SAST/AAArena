/*
 * $File: ai9.cc
 * $Date: Fri Mar 22 21:16:28 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "ai9.hh"
#include "config.hh"

#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <ctime>
#include <cstring>

#include <libgen.h>
#include <unistd.h>

#include <sys/time.h>

FDCloser::~FDCloser()
{
	if (fd != -1)
		close(fd);
}

AI9Error::AI9Error(const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	PrintfOsstream msg;
	msg.vprintf(fmt, ap);
	va_end(ap);
	m_msg = msg.str();
}

void PrintfOsstream::printf(const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
}

void PrintfOsstream::vprintf(const char *fmt, va_list ap)
{
	int size = 128;
	char *p, *np;

	if ((p = (char*)malloc(size)) == NULL)
	{
		fprintf(stderr, "failed to alloc memory\n");
		exit(EXIT_FAILURE);
	}

	for (; ;)
	{
		va_list aq;
		va_copy(aq, ap);
		int n = vsnprintf(p, size, fmt, aq);
		va_end(aq);

		if (n > -1 && n < size)
		{
			if (m_max_size && n + m_cur_size >= m_max_size)
			{
				if (m_cur_size >= m_max_size)
					break;
				n = m_max_size - m_cur_size;
			}
			this->write(p, n);
			break;
		}
		if (n > -1)		/* glibc 2.1 */
			size = n+1;	/* precisely what is needed */
		else			/* glibc 2.0 */
			size *= 2;	/* twice the old size */

		if ((np = (char*)realloc(p, size)) == NULL)
		{
			fprintf(stderr, "failed to alloc memory\n");
			exit(EXIT_FAILURE);
		} else
			p = np;
	}
	free(p);
}


void __ai9_log__(log_lvl_t lvl, const char *fpath, const char *func, int line,
		const char *fmt, ...)
{
	/*
	FILE *fout = fopen(LOG_FILEPATH, "a");
	if (!fout)
	{
		fprintf(stderr, "failed to open log file: %s (%m)\n", LOG_FILEPATH);
		exit(EXIT_FAILURE);
	}
	*/
	FILE *fout = stderr;

	time_t cur_time;
	time(&cur_time);
	char timestr[64];
	strftime(timestr, sizeof(timestr), LOG_TIMEFMT, localtime(&cur_time));
	
	char * fileName = new char[strlen(fpath) + 1];
	strcpy(fileName, fpath);
	char * fileBaseName = basename(fileName);
	
	fprintf(fout, "%s[%s] [%s@%s:%d] ", lvl == LOG_INFO ? "" : "[ERROR] ",
			timestr, func, fileBaseName, line);

	delete [] fileName;

	va_list ap;
	va_start(ap, fmt);
	vfprintf(fout, fmt, ap);
	va_end(ap);
	fputc('\n', fout);
	// fclose(fout);
}

double get_time() {
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec + tv.tv_usec * 1e-6;
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


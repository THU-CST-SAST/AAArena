/*
 * $File: ai9.hh
 * $Date: Fri Mar 22 21:02:39 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

/*!
 * \file
 * \brief common utils for AI9
 */
#pragma once

#include <exception>
#include <string>
#include <sstream>

#include <cstdarg>

double get_time();

/*!
 * \brief close the file describer on destruction
 */
struct FDCloser
{
	int fd;
	FDCloser(int f = -1):
		fd(f)
	{}

	~FDCloser();
};

/*!
 * \brief string stream with C printf-like functions
 */
class PrintfOsstream: public std::ostringstream
{
//	size_t m_max_size = 0, m_cur_size = 0;
	size_t m_max_size, m_cur_size;

	public:
		PrintfOsstream():m_max_size(0),m_cur_size(0){};
		void printf(const char *fmt, ...) __attribute__((format(printf, 2, 3)));
		void vprintf(const char *fmt, va_list ap);

		/*!
		 * \brief set the maximal output string size; extra data would be
		 *		truncated
		 *
		 *	\param size the size in bytes; set to 0 for no limit
		 */
		void set_max_size(size_t size)
		{ m_max_size = size; }
};

/*!
 * \brief error exception class
 */
class AI9Error: public std::exception
{
	std::string m_msg;

	public:
		AI9Error(const char *fmt, ...) __attribute__((format(printf, 2, 3)));
		~AI9Error() throw() {}

		const char* what() const throw()
		{ return m_msg.c_str(); }
};

enum log_lvl_t
{
	LOG_INFO, LOG_ERROR
};
/*
 * print log
 *
 * eg: ai9log(LOG_INFO, "program started, pid=%d", pid)
 */
#define ai9log(level, fmt, ...) __ai9_log__(level, __FILE__, __func__, __LINE__, \
		fmt, ## __VA_ARGS__)


// internal implementation, ignore this
void __ai9_log__(log_lvl_t lvl, const char *fpath, const char *func, int line,
		const char *fmt, ...) __attribute__((format(printf, 5, 6)));


// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


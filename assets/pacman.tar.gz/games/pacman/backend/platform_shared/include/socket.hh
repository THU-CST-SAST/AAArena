/*
 * $File: socket.hh
 * $Date: Wed Oct 03 17:19:50 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

#define _IN_SOCKET_
#include "socket_base.hh"
#include "socket_stream.hh"
#undef _IN_SOCKET_ 

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


/*
 * $File: socket_stream.hh
 * $Date: Mon Oct 08 17:01:06 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#ifndef _IN_SOCKET_
#error "do not directly include this header"
#endif

#include <string>
#include <vector>

#include <cstring>


#define BASIC_IO(type) \
	static inline SocketBase& operator << (SocketBase &s, const type &val) \
	{ \
		s.send(&val, sizeof(type)); \
		return s; \
	} \
	static inline SocketBase& operator >> (SocketBase &s, type &val) \
	{ \
		s.recv(&val, sizeof(type)); \
		return s; \
	}

BASIC_IO(char);
BASIC_IO(unsigned char);
BASIC_IO(short);
BASIC_IO(unsigned short);
BASIC_IO(int);
BASIC_IO(unsigned int);
BASIC_IO(long);
BASIC_IO(unsigned long);
BASIC_IO(long long);
BASIC_IO(unsigned long long);
BASIC_IO(double);
BASIC_IO(float);
BASIC_IO(bool);
#undef BASIC_IO

template <typename T>
SocketBase& operator << (SocketBase &s, const std::vector<T> &val)
{
	s << val.size();
	for (auto &i: val)
		s << i;
	return s;
}

template <typename T>
SocketBase& operator >> (SocketBase &s, std::vector<T> &val)
{
	std::size_t size;
	s >> size;
	val.resize(size);
	for (auto &i: val)
		s >> i;
	return s;
}

SocketBase& operator << (SocketBase &s, const std::string &val);

static inline SocketBase& operator << (SocketBase &s, const char *val)
{
	return s << std::string(val);
}

SocketBase& operator >> (SocketBase &s, std::string &val);


/*!
 * \brief use ths constructor to explicitly send an object
 */
struct sendable
{
	const void *addr;
	size_t len;

	template<typename T>
	explicit sendable(const T &val):
		addr(&val), len(sizeof(T))
	{
	}
};

/*!
 * \brief use ths constructor to explicitly send an object
 */
struct recvable
{
	void *addr;
	size_t len;

	template<typename T>
	explicit recvable(T &val):
		addr(&val), len(sizeof(T))
	{}
};

static inline SocketBase& operator << (SocketBase &s, const sendable &val)
{
	s.send(val.addr, val.len);
	return s;
}

static inline SocketBase& operator >> (SocketBase &s, const recvable &val)
{
	s.recv(val.addr, val.len);
	return s;
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


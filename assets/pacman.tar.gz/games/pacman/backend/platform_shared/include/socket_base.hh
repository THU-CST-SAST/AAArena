/*
 * $File: socket_base.hh
 * $Date: Fri Mar 22 21:38:05 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#ifndef _IN_SOCKET_
#error "do not directly include this header"
#endif

#include "ai9.hh"
#include "shared_ptr.hh"

#include <stdint.h>

class SocketBase
{
	public:
		void send(const void *buf, size_t size);
		void recv(void *buf, size_t size);
		SocketBase(const SocketBase &s);

		/*
		 * FIXME: this constructor should be protected, but not seems to
		 * compile?
		 */
		SocketBase(int fd);

		void close();

	protected:
		SocketBase();
		SharedPtr<FDCloser> m_sock;

		void set_socket_fd(int fd);
};

class ClientSocket: public SocketBase
{
	public:
		ClientSocket(const char *host, const char *service);
};

class ServerSocket: public SocketBase
{
	FDCloser m_srvsock;
	int m_port;

	public:
		/*!
		 * \brief pass 0 to *port* to use an ephemeral port
		 */
		ServerSocket(uint16_t port, int backlog = 5);

		/*!
		 * \brief get the port number
		 */
		int port() const
		{ return m_port; }

		SocketBase accept();
};

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


/*
 * $File: msg.hh
 * $Date: Tue Mar 26 22:08:55 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

/*!
 * \file
 * \brief communication between AI and logic
 */

#pragma once

struct GameInfoMeta
{
	unsigned rlim_mem;	// memory limit, in bytes
} __attribute__((packed));

struct RoundInfoMeta
{
	double rlim_cpu;	// cpu limit in seconds
}  __attribute__((packed));

struct RoundResultMeta
{
	static constexpr int ERRMSG_MAXLEN = 128;
	enum class Status
	{
		NORMAL, TIMED_OUT, SEGFAULT,
		ILLEGAL_SYSCALL,	// status_data would be the call number
		EXITED,				// status_data would be the exit code
		SIGNALED,			// status_data would be the signal number
		OTHER_ERROR,		// detailed description in err_msg
		UNKNOWN_ERROR		// other error
	};
	Status status;
	double cpu_time, real_time;
	int status_data;
	char err_msg[ERRMSG_MAXLEN];

	RoundResultMeta():
		status(Status::NORMAL),
		cpu_time(-1), real_time(-1),
		status_data(0)
	{ err_msg[0] = 0; }

	static const char* status2str(const Status &s);

	const char *to_str() const;
	// return a global str, not thread safe

} __attribute__((packed));

enum class Command
{
	START_ROUND,
	FINISH,
	KILL
};

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


/*
 * $File: config.hh
 * $Date: Wed Mar 20 22:39:26 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 * $Author: BYVoid <byvoid@byvoid.com>
 */

#pragma once

#define LOG_TIMEFMT		"%Y-%m-%d %H:%M:%S"
#define SOCKET_TIMEOUT	100

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}

/*
 * $File: shared_ptr.hh
 * $Date: Wed Oct 03 11:18:25 2012 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#pragma once

/*!
 * \brief shared pointer based on reference count
 * Note: not thread-safe
 */
template<typename T>
class SharedPtr
{
	struct Holder
	{
		T* ptr;
		int cnt;

		Holder(T* p):
			ptr(p), cnt(1)
		{}

		~Holder()
		{ delete ptr; ptr = nullptr; }
	};
	Holder *m_holder;

	void incr_ref()
	{  m_holder->cnt ++; }

	void decr_ref()
	{
		if (m_holder && !(-- m_holder->cnt))
		{
			delete m_holder;
			m_holder = nullptr;
		} 
	}

	public:
		SharedPtr(T *p = nullptr):
			m_holder(new Holder(p))
		{}

		SharedPtr(const SharedPtr &r):
			m_holder(r.m_holder)
		{ incr_ref(); }

		~SharedPtr()
		{ decr_ref(); }

		SharedPtr& operator = (const SharedPtr &r)
		{
			if (m_holder != r.m_holder)
			{
				decr_ref();
				m_holder = r.m_holder;
				incr_ref();
			}
			return *this;
		}

		T* get_ptr() const { return m_holder->ptr; }

		T* operator -> () const { return get_ptr(); }
		T& operator *() const { return *get_ptr(); }

		bool operator == (const SharedPtr<T> &p) const
		{ return m_holder->ptr == p.m_holder->ptr; }

		bool operator == (T *p) const
		{ return m_holder->ptr == p; }

		operator bool() const
		{ return m_holder->ptr != nullptr; }
};

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


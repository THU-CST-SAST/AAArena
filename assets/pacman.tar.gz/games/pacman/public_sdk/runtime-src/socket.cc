/*
 * $File: socket.cc
 * $Date: Sun Mar 24 17:30:50 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "socket.hh"
#include "config.hh"

#include <cstdio>
#include <cstring>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>

#ifdef WINDOWS
	#define _WIN32_WINNT 0x501
	#include <winsock2.h>
	#include <ws2tcpip.h>
	#include <malloc.h>
	WSADATA wsaData;
	bool wsaInited = false;
#else
	#include <sys/time.h>
	#include <sys/socket.h>
	#include <sys/types.h>
	#include <netinet/in.h>
	#include <netinet/tcp.h>
	#include <netdb.h>
	#include <alloca.h>
#endif

SocketBase::SocketBase()
{
#ifdef WINDOWS
	if (!wsaInited)
	{
		WSAStartup(MAKEWORD(2,2), &wsaData);
		wsaInited = true;
	}
#endif
}

SocketBase::SocketBase(int fd)
{
	set_socket_fd(fd);
}

SocketBase::SocketBase(const SocketBase &s):
	m_sock(s.m_sock)
{
}

void SocketBase::close()
{
	if (m_sock)
		::close(m_sock->fd);
}

void SocketBase::set_socket_fd(int fd) {
	m_sock = new FDCloser(fd);
	int flag = 1;
#ifndef WINDOWS
	if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag)))
#else
	if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (const char*)&flag, sizeof(flag)))
#endif
		throw AI9Error("failed to setsockopt: %s", strerror(errno));
}

void SocketBase::send(const void *buf0, size_t size)
{
	int fd;
	if (!m_sock || (fd = m_sock->fd) == -1)
		throw AI9Error("attempt to write to unbinded socket");
	const char *buf = static_cast<const char *>(buf0);
	while (size)
	{
		ssize_t s = ::send(fd, buf, size, 0);
		if (s < 0)
			throw AI9Error("socket: failed to write: %s", strerror(errno));
		size -= s;
		buf += s;
	}
}

void SocketBase::recv(void *buf0, size_t size)
{
	int fd;
	if (!m_sock || (fd = m_sock->fd) == -1)
		throw AI9Error("attempt to write to unbinded socket");
	char *buf = static_cast<char *>(buf0);
	while (size)
	{
		ssize_t s = ::recv(fd, buf, size, 0);
		if (s < 0)
			throw AI9Error("socket: failed to read: %s", strerror(errno));
		size -= s;
		buf += s;
	}
}

ClientSocket::ClientSocket(const char *host, const char *service)
{
	struct addrinfo hints, *result;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;

	if (int s = getaddrinfo(host, service, &hints, &result))
		throw AI9Error("failed to getaddrinfo(%s, %s): %s",
				host, service, gai_strerror(s));

	int sfd = -1;
	for (struct addrinfo *rp = result; rp; rp = rp->ai_next)
	{
		sfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1)
			continue;

		if (!connect(sfd, rp->ai_addr, rp->ai_addrlen))
			break;  // return 0, successfully connected
		::close(sfd);
	}
	freeaddrinfo(result);
	if (sfd == -1)
		throw AI9Error("failed to connect to (%s, %s): %m", host, service);
	set_socket_fd(sfd);
}

ServerSocket::ServerSocket(uint16_t port, int backlog)
{
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		throw AI9Error("failed to create socket: %m");

	struct sockaddr_in srv_addr;
	struct sockaddr* srv_addr_ptr = (struct sockaddr*)&srv_addr;
	memset(&srv_addr, 0, sizeof(srv_addr));
	srv_addr.sin_family = AF_INET;
	srv_addr.sin_addr.s_addr = INADDR_ANY;
	srv_addr.sin_port = htons(port);
	m_srvsock.fd = sockfd;

	int optval = 1;

	struct timeval timeout;
	timeout.tv_sec = SOCKET_TIMEOUT;
	timeout.tv_usec = 0;

	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,
				(const char *) &optval, sizeof(optval)))
		throw AI9Error("failed to setsockopt: %m");
	if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO,
				(const char *) &timeout, sizeof(timeout)))
		throw AI9Error("failed to setsockopt: %m");
	if (setsockopt(sockfd, SOL_SOCKET, SO_SNDTIMEO,
				(const char *) &timeout, sizeof(timeout)))
		throw AI9Error("failed to setsockopt: %m");

	if (bind(sockfd, srv_addr_ptr, sizeof(srv_addr)) < 0)
		throw AI9Error("faied to bind: %m");

	socklen_t addrlen = sizeof(srv_addr);
	memset(&srv_addr, 0, addrlen);
	if (getsockname(sockfd, srv_addr_ptr, &addrlen))
		throw AI9Error("getsockname: %m");

	m_port = ntohs(srv_addr.sin_port);

	listen(sockfd, backlog);
	ai9log(LOG_INFO, "listening on %d ...", m_port);
}

SocketBase ServerSocket::accept()
{
	struct sockaddr_in cli_addr;
	socklen_t cli_addr_len = sizeof(cli_addr);
	int clifd = ::accept(m_srvsock.fd,
			(struct sockaddr*)&cli_addr, &cli_addr_len);

	char hostbuf[NI_MAXHOST] = "?", servbuf[NI_MAXSERV] = "?";
	getnameinfo((struct sockaddr*)&cli_addr, cli_addr_len,
			hostbuf, NI_MAXHOST,
			servbuf, NI_MAXSERV,
			NI_NUMERICHOST | NI_NUMERICSERV);
	ai9log(LOG_INFO, "connected by %s:%s\n", hostbuf, servbuf);
	return SocketBase(clifd);
}

SocketBase& operator << (SocketBase &s, const std::string &val)
{
	s << val.length();
	s.send(val.c_str(), val.length());
	return s;
}

SocketBase& operator >> (SocketBase &s, std::string &val)
{
	std::size_t len;
	s >> len;
	char *buf = static_cast<char*>(alloca(len));
	s.recv(buf, len);
	val.assign(buf, len);
	return s;
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


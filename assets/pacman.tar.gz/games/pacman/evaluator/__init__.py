from __future__ import annotations
from pathlib import Path
from aa_arena.core.contract import EvaluateResult, EvaluationStatus
from aa_arena.legacy.ai9 import Ai9Error, Ai9GameConfig, build_backend, build_player, run_ai9_match

class PacmanEvaluator:
    def __init__(self, game_dir, *, build_root=None, artifact_root=None, timeout_s=1800.0, max_rounds=1000):
        self._game_dir = Path(game_dir).resolve()
        _root = self._game_dir.parents[1]
        self._build_root = Path(build_root).resolve() if build_root else _root / "data" / "pacman-build"
        self._artifact_root = Path(artifact_root).resolve() if artifact_root else _root / "data" / "pacman-matches"
        self._timeout = float(timeout_s)
        self._max_rounds = int(max_rounds)
        backend = self._game_dir / "backend"
        self._config = Ai9GameConfig(
            name="pacman", backend_source_root=backend,
            player_sdk_includes=(backend / "sdk", backend / "logic" / "src" / "include",
                                 backend / "platform_shared" / "include"),
            player_sdk_sources=(backend / "platform_shared" / "socket.cc",
                                backend / "platform_shared" / "msg.cc",
                                backend / "platform_shared" / "ai9.cc"),
            resources_source=backend / "logic" / "test" / "resources_fight.res", map_source=None,
            npc_library_name="ai.so", roles=("P0", "P1"), player_count=2,
        )
    def preflight_candidate(self, package_root):
        try:
            build_player(self._config, 'candidate', Path(package_root), self._build_root)
        except (Ai9Error, OSError) as exc:
            raise ValueError(f'AI9 candidate preflight failed: {exc}') from exc

    def evaluate(self, players, roles, seed):
        if len(players) != 2:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic="expects 2 players")
        try:
            backend = build_backend(self._config, self._build_root)
            self._game_dir / "players" / "pool"
            prepared = [build_player(self._config, p.player_id, Path(p.code_path), self._build_root) for p in players]
        except (Ai9Error, OSError) as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))
        try:
            return run_ai9_match(self._config, backend, prepared, build_root=self._build_root,
                                 artifact_root=self._artifact_root, seed=seed, timeout_s=self._timeout, max_rounds=self._max_rounds)
        except (Ai9Error, OSError) as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))

def make_evaluator(game_dir, **kwargs):
    return PacmanEvaluator(game_dir, **kwargs)

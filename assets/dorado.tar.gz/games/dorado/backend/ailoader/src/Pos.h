﻿#ifndef POS_H
#define POS_H
#include<vector>
#include<iostream>
struct Pos
{
	int x, y;
	
	Pos(int _x = -1, int _y = -1):
		x(_x), y(_y)
	{
	}
};

std::ostream& operator<< (std::ostream&, const Pos&);//输出形式为"(x,y)",当然,不包括引号
int crossProduct(Pos A, Pos B, Pos C);//向量AB叉乘AC
int dotProduct (Pos A, Pos B, Pos C);//向量AB点乘AC
bool cross(Pos A, Pos B, Pos C, Pos D);//判断线段AB与CD是否有公共点
bool checkOnLine(Pos A, Pos B, Pos C);//判断AB连线是否与C（方格）有交点
int dis2(Pos A, Pos B);//欧氏距离平方
double dis(Pos A, Pos B);//欧几里得距离
bool operator==(Pos A, Pos B);//相等
bool operator!=(Pos A, Pos B);//不等
Pos operator+(Pos A, Pos B);//加法
Pos operator-(Pos A, Pos B);//减法
Pos operator*(Pos A, int k);//数乘
Pos operator*(int k, Pos A);//数乘
int length(const std::vector<Pos>& path);//一条路径的长度。如果你需要大量调用请根据定义重新实现以避免重复计算。


#endif//POS_H

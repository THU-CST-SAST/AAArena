import sys
import os

os.system("rm const.cc")
os.system("ln -s ../../logic/src/const.cpp const.cc")
os.system("rm Pos.cc")
os.system("ln -s ../../logic/src/Pos.cpp Pos.cc")
os.system("rm sdk.cc")
os.system("ln -s ../../logic/src/sdk.cpp sdk.cc")
os.system("rm socket_trans.cc")
os.system("ln -s ../../logic/src/socket_trans.cpp socket_trans.cc")
os.system("rm trans.cc")
os.system("ln -s ../../logic/src/trans.cpp trans.cc")


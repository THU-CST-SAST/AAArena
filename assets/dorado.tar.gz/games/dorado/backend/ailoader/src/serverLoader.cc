#include "serverLoader.h"
using namespace std;
ServerLoader::AI_FUNC ServerLoader::get_ai()
{
	if ( play_ai )
		return play_ai;
	if ( !hdl )
		hdl = dlopen( aiPath.c_str(),RTLD_NOW );
    if ( !hdl )
    {
//        throw AI9Error("failed to load AI: %s", dlerror());
        printf("failed to load AI: %s", dlerror());
        return NULL;
    }
	play_ai = reinterpret_cast<AI_FUNC>(dlsym(hdl,"player_ai"));
    if (!play_ai)
    {
//        throw AI9Error("failed to lookup AI func: %s", dlerror());
        printf("failed to lookup AI func: %s", dlerror());
        return NULL;
    }
	return play_ai;
}
void ServerLoader::on_game_init()
{
    *m_conn >> map;
    get_ai();
}
void ServerLoader::on_round_start()
{
    string infoString;
    *m_conn >> infoString;
    info=PPlayerInfo(infoString);
}
void ServerLoader::do_round()
{
    cmd.cmds.clear();
    AI_FUNC ai=get_ai();
    if(ai)
        ai(map,info,cmd);
}
void ServerLoader::on_round_end()
{
	*m_conn << cmd;
}

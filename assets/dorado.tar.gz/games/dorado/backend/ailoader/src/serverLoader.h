#ifndef SERVERLOADER_H
#define SERVERLOADER_H

#include <string>
#include <cstdlib>
#include <fstream>
#include <dlfcn.h>

#include "sdk/sdk.h"
#include "ailoader.hh"
#include "socket_trans.h"
class ServerLoader:public GameControllerBase
{
	public:
		typedef decltype(player_ai)* AI_FUNC;
		ServerLoader(const char *AiPath):
			play_ai(NULL),hdl(NULL),aiPath(AiPath)
		{
		}
		void on_game_init();
		void on_round_start();
		void do_round();
		void on_round_end();
		void on_game_end()
		{
		}
		std::string get_log_msg()
		{
			return std::string("");
		}
		~ServerLoader()
		{
			if ( hdl )
				dlclose(hdl);			
		}
	private:
		PCommand cmd;
		PPlayerInfo info;
		PMap map;
		AI_FUNC play_ai;
		AI_FUNC get_ai();
		void *hdl;
		std::string aiPath;



};
#endif//SERVERLOADER_H

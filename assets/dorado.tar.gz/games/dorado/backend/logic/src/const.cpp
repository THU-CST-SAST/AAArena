#ifndef _AI__
#include "include/sdk/const.h"
#else
#include "const.h"
#endif//_AI__

UNIT_ARGS::UNIT_ARGS(int _TYPE_ID, int _HP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _VIEW, int _ATTACK_MAXCD):
	TYPE_ID(_TYPE_ID), HP(_HP), ATK(_ATK), DEF(_DEF), SPEED(_SPEED), RANGE(_RANGE), VIEW(_VIEW), ATTACK_MAXCD(_ATTACK_MAXCD)
{
    NAME = UNIT_NAME[TYPE_ID];
    POS_LIST.clear();
}

void UNIT_ARGS::newPos(Pos _)                                                             //添加位置
{
    POS_LIST.push_back(_);
}

UNIT_ARGS::UNIT_ARGS(int _TYPE_ID, int _HP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _LEVEL, int _VIEW, int _ATTACK_MAXCD, int _TIME, const Pos* _BEGIN, const Pos* _END):
    TYPE_ID(_TYPE_ID), HP(_HP), ATK(_ATK), DEF(_DEF), SPEED(_SPEED), RANGE(_RANGE), LEVEL(_LEVEL), VIEW(_VIEW), ATTACK_MAXCD(_ATTACK_MAXCD), REVIVING_TIME(_TIME)
{
    NAME = UNIT_NAME[TYPE_ID];
    POS_LIST.clear();
    for (const Pos* i=_BEGIN; i<_END; ++i)
        newPos(*i);
}

HERO_ARGS::HERO_ARGS(int _TYPE_ID, int _HP, int _MP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _VIEW, int _ATTACK_MAXCD,
		             int _HP_DELTA, int _ATK_DELTA, int _DEF_DELTA):
    UNIT_ARGS(_TYPE_ID, _HP, _ATK, _DEF, _SPEED, _RANGE, _VIEW, _ATTACK_MAXCD),
	MP(_MP), HP_DELTA(_HP_DELTA), ATK_DELTA(_ATK_DELTA), DEF_DELTA(_DEF_DELTA)
{
    NAME = UNIT_NAME[TYPE_ID];
}

SPECIAL_UNIT_ARGS::SPECIAL_UNIT_ARGS(int _PLAYER, int _TYPE_ID, int _HP, int _ATK, int _DEF, int _RANGE, int _VIEW, int _ATTACK_MAXCD,
		                             const Pos* _BEGIN, const Pos* _END):
    PLAYER(_PLAYER), UNIT_ARGS(_TYPE_ID, _HP, _ATK, _DEF, 0, _RANGE, _VIEW, _ATTACK_MAXCD)
{
    NAME = UNIT_NAME[TYPE_ID];
    for (const Pos* i=_BEGIN; i<_END; ++i)
        newPos(*i);
}


#ifndef _AI__
#include "include/sdk/sdk.h"
#include "include/sdk/console.h"
#include "include/trans.h"
#include "include/Pos.h"
#include "include/sdk/filter.h"
#else
#include "Pos.h"
#include "filter.h"
#include "sdk.h"
#include "console.h"
#include "trans.h"
#endif//_AI__

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <climits>
#include <algorithm>
#include <time.h>
#include <vector>
#include <utility>
#define Pi 3.1415926
using namespace std;
inline string lowerCase(const string& str)
{
    string s(str);
    for (int i = 0; i < s.size(); ++i)
    {
        if (s[i] >= 'A' && s[i] <= 'Z')
            s[i] += ('a' - 'A');
    }
    return move(s);
}
Circle::Circle(int centerX, int centerY, int _radius2)
{
    center = Pos(centerX, centerY);
    radius2 = _radius2;
}

Circle::Circle(const Pos &_center, int _radius2)
{
    center = _center;
    radius2 = _radius2;
}

void Circle::output (ostream& os) const
{
    os << "{" << center << ";" << radius2 << '}';
}

ostream& operator<< (ostream& os, const Circle& circle)
{
    circle.output(os);
    return os;
}

bool Circle::contain(const Pos &_pos)
{
    return dis2(center, _pos) <= radius2;
}

Pos Circle::randPosInArea () const
{
    int range = rand () % radius2;
    double angle = double(rand () % int((2 * Pi) * 100)) / 100;
    double r = sqrt (range);
    return center + Pos (cos(angle) * r, sin(angle) * r);
}

/*
 * 过滤器相关实现
 */
Filter::Filter(int _limitSize)
{
    types.clear();
    avoids.clear();
    limits.clear();
    limits.resize(_limitSize, make_pair(INT_MIN, INT_MAX));
}

Filter::~Filter()
{
    cleanAll();
}

void Filter::output (ostream& os) const
{
    os << "allowed types:";
    if (types.size() == 0)
        os << "no constraints, all types will be valid";
    else
        for (vector<string>::const_iterator iter = types.begin(); iter != types.end(); ++ iter)
            os << *iter << "\t";
    os << endl;

    os << "avoided types:";
    if (avoids.size() == 0)
        os << "no constraints, all types will be valid";
    else
        for (vector<string>::const_iterator iter = avoids.begin(); iter != avoids.end(); ++ iter)
            os << *iter << "\t";
    os << endl;


}


void Filter::setTypeFilter(const char* type, const char* method)
{
    bool clear = false;
    if (strcmp(method, "w") == 0)
        clear = true;
    else if (strcmp(method, "a") == 0)
        clear = false;
    else {
        cout << "wrong typeFilter method: " << method << endl;
        return;
    }

    if (clear)
        types.clear();
    types.push_back(lowerCase(type));
}

void Filter::cleanTypeFilter()
{
    types.clear();
}

void Filter::setAvoidFilter(const char* type, const char* method)
{
    bool clear = false;
    if (strcmp (method, "w") == 0)
        clear = true;
    else if (strcmp (method, "a") == 0)
        clear = false;
    else {
        cout << "wrong typeFilter method: " << method << endl;
        return;
    }

    if (clear)
        avoids.clear();
    avoids.push_back(lowerCase(type));
}

void Filter::cleanAvoidFilter()
{
    avoids.clear();
}
void Filter::setLimitSize(int _limitSize)
{
    if (_limitSize >= MAX_LIMIT_SIZE)
        limitSize = MAX_LIMIT_SIZE;
    else if (_limitSize < 0)
        limitSize = 0;
    else
        limitSize = _limitSize;

    limits.clear();
    for (int i=0; i<limitSize; ++i)
        limits.push_back(make_pair(INT_MIN, INT_MAX));
}

void Filter::setLimitFilter(int rank, int lo, int hi)
{
    if (rank >= 0 && rank < limitSize)
        limits[rank] = make_pair(lo, hi);
}

void Filter::appendLimitFilter(int lo, int hi)
{
    if (limitSize < MAX_LIMIT_SIZE) {
        ++limitSize;
        limits.push_back(make_pair(lo, hi));
    }
}

void Filter::cleanLimitFilter(int rank)
{
    if (rank >= 0 && rank < limitSize)
        limits[rank] = make_pair(INT_MIN, INT_MAX);
}

void Filter::cleanAll()
{
    cleanTypeFilter();
    cleanAvoidFilter();
    setLimitSize();
}

#define SIZE(x) (int(x.size()))

static int vst[MAP_SIZE][MAP_SIZE];
static Pos Q[MAP_SIZE * MAP_SIZE + 1], Q_prior[MAP_SIZE][MAP_SIZE];
static int countF = 0;

ostream& operator<< (ostream& os, const Pos& pos)
{
    os << "(" << pos.x << ", " << pos.y << ")";
    return os;
}
/*
 * 作用范围相关实现
 */
PArea::PArea(int _typeId, int _id, int _camp, int _timeLeft, Geometry* const _geo):
    typeId(_typeId), id(_id), camp(_camp), timeLeft(_timeLeft), geo(_geo)
{
    strcpy(name, AREA_NAME[typeId]);
}

PArea::PArea(string a):
    typeId(-1)
{
    int len = a.length();
    for (int i=0; i<len; ++i)
    {
        if (a[i] == '&')
            a[i] = ' ';
    }

    char tmp1[10];
    int _radius;
    sscanf (a.c_str(), "%s%d%d%d%s%d", name, &id, &camp, &timeLeft, tmp1, &_radius);
    for (int i=AREA_NAME_SIZE-1; i>=0; --i)
        if (!strcmp(AREA_NAME[i], name)) {
            typeId = i;
            break;
        }

    string tmp = tmp1;
    geo = new Circle(String2Pos(tmp), _radius);
}

/*
 * 参数相关实现
 */
PArg::PArg(int _typeId):
    typeId(_typeId)
{
    strcpy(name, ARGS_NAME[typeId]);
    val.clear();
}

PArg::PArg(string a):
    typeId(-1)
{
    val.clear();
    int s = 0;
    int e = a.find('&', s);
    if(e != -1) {
        sscanf(a.substr(s, e-s).c_str(), "%s", name);
        for (int i=ARGS_NAME_SIZE-1; i>=0; --i)
            if (!strcmp(ARGS_NAME[i], name)) {
                typeId = i;
                break;
            }
    } else {
        sscanf(a.c_str(), "%s", name);
        for (int i=ARGS_NAME_SIZE-1; i>=0; --i)
            if (!strcmp(ARGS_NAME[i], name)) {
                typeId = i;
                return;
            }
    }

    int len = a.length();
    do {
        s = e + 1;
        e = a.find('&', s);
        if (e == -1) e = len;
        val.push_back(String2Int(a.substr(s, e - s)));
    } while (e != len);
}

PArg::PArg(const PArg& arg)
{
	this->typeId = arg.typeId;
	strcpy(this->name, arg.name);
	this->val.clear();
	for(int i = 0; i < arg.val.size(); ++i)
		this->val.push_back(arg.val[i]);
}

/*
 * 状态相关实现
 */
PBuff::PBuff(int _typeId, int _level, int _timeLeft):
    typeId(_typeId), level(_level), timeLeft(_timeLeft)
{
    strcpy(name, BUFF_NAME[typeId]);
}

PBuff::PBuff(string a): typeId(-1)
{
    int len = a.length();
    for (int i=0; i<len; ++i)
    {
        if (a[i] == '&')
            a[i] = ' ';
    }

    sscanf(a.c_str(), "%s%d%d", name, &level, &timeLeft);
    for (int i=BUFF_NAME_SIZE-1; i>=0; --i)
        if (!strcmp(BUFF_NAME[i], name)) {
            typeId = i;
            return;
        }
}

PBuff::PBuff(const PBuff& buff)
{
	this->typeId = buff.typeId;
	strcpy(this->name, buff.name);
	this->level = buff.level;
	this->timeLeft = buff.timeLeft;
}

/*
 * 飞行道具相关实现
 */
PFlight::PFlight(int _typeId, int _id, int _unitId, int _camp, int _speed, int _pos_x, int _pos_y, int _target_x, int _target_y):
    typeId(_typeId), id(_id), unitId(_unitId), camp(_camp), speed(_speed), pos(Pos(_pos_x, _pos_y)), target(Pos(_target_x, _target_y))
{
    strcpy(name, FLIGHT_NAME[typeId]);
}

PFlight::PFlight(string a):
    typeId(-1)
{
    int len = a.length();
    for (int i=0; i<len; ++i)
    {
        if (a[i] == '&')
            a[i] = ' ';
    }
    char tmp1[10];
    char tmp2[10];

    sscanf(a.c_str(), "%d%s%d%d%s%s",&id, name, &camp, &speed, tmp1, tmp2);
    for (int i=FLIGHT_NAME_SIZE-1; i>=0; --i)
        if (!strcmp(FLIGHT_NAME[i], name)) {
            typeId = i;
            break;
        }

    string tmp = tmp1;
    pos = String2Pos(tmp);
    tmp = tmp2;
    target = String2Pos(tmp);
}

/*
 * 地图相关实现
 */
PMap::PMap(const char *fileName)
{
    playerIds.clear();
    playerIds.push_back(-1);
    playerIds.push_back(-1);
    playerIds.push_back(-1);

    ifstream fin(fileName);
    for (int i=0; i<MAP_SIZE; ++i)
        for (int j=0; j<MAP_SIZE; ++j)
            fin >> height[i][j];
    fin.close();
}
int PMap::getHeight(int x, int y) const
{
    if (x < 0 || x >= MAP_SIZE || y < 0 || y > MAP_SIZE)
    {
        cerr << "postion outside map" << endl;
        return -1;
    }
    return height[x][y];
}

/*
 * 技能相关实现
 */
PSkill::PSkill(int _typeId, int _mp, int _level, int _maxLevel, int _cd, int _maxCd):
    typeId(_typeId), mp(_mp), level(_level), maxLevel(_maxLevel), cd(_cd), maxCd(_maxCd)
{
    strcpy(name, SKILL_NAME[typeId]);
}

PSkill::PSkill(string a): typeId(-1)
{
    int len = a.length();
    for (int i=0; i<len; ++i)
    {
        if (a[i] == '&')
            a[i] = ' ';
    }

    sscanf (a.c_str(), "%s%d%d%d%d", name, &level, &maxLevel, &cd, &maxCd);
    mp = 0;
    int nlen = strlen(name);
    for (int i=0; i<nlen; ++i)
        if (name[i] >= '0' && name[i] <= '9') {
            mp = mp * 10 + name[i] - '0';
            name[i] = 0;
        }
    for (int i=SKILL_NAME_SIZE-1; i>=0; --i)
        if (!strcmp(SKILL_NAME[i], name)) {
            typeId = i;
            break;
        }
}

PSkill::PSkill(const PSkill& skill)
{
	this->typeId = skill.typeId;
	strcpy(this->name, skill.name);
	this->mp = skill.mp;
	this->level = skill.level;
	this->maxLevel = skill.maxLevel;
	this->cd = skill.cd;
	this->maxCd = skill.maxCd;
}

bool PSkill::needTarget() const //判断技能是否需要指定坐标
{
    return  lowerCase(name) == lowerCase("HammerAttack") || lowerCase(name) == lowerCase("SetObserver") || lowerCase(name) == lowerCase("Blink");
}

int PSkill::range() const
{
    if (lowerCase(name) == lowerCase("HammerAttack"))
        return HAMMERATTACK_RANGE;
    else if (lowerCase(name) == lowerCase("Blink"))
        return BLINK_RANGE;
    else if (lowerCase(name) == lowerCase("SetObserver"))
        return SET_OBSERVER_RANGE;
    else
        return -1;
}

bool PSkill::skillMask(const string &name)
{
    return lowerCase(name) == lowerCase("Stop") || lowerCase(name) == lowerCase("Move") || lowerCase(name) == lowerCase("Dead") || lowerCase(name) == lowerCase("Mining") || lowerCase(name) == lowerCase("Attack") || lowerCase(name) == lowerCase("SuperDead");
}

SkillFilter::SkillFilter():
    Filter(SKILL_LIMIT_SIZE)
{
}

void SkillFilter::output (ostream& os) const
{
    Filter::output(os);
    os << "level:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
    os << "mp:[" << limits[MP].first << "," << limits[MP].second << ")" << endl;
    os << "cd:[" << limits[CD].first << "," << limits[CD].second << ")" << endl;
    os << "maxCd:[" << limits[MAX_CD].first << "," << limits[MAX_CD].second << ")" << endl;
}
ostream& operator << (ostream& os, const SkillFilter& filter)
{
    filter.output(os);
    return os;
}

void SkillFilter::setLevelFilter(int lo, int hi)
{
    setLimitFilter(LEVEL, lo, hi);
}

void SkillFilter::cleanLevelFilter()
{
    cleanLimitFilter(LEVEL);
}

void SkillFilter::setMpFilter(int lo, int hi)
{
    setLimitFilter(MP, lo, hi);
}

void SkillFilter::cleanMpFilter()
{
    cleanLimitFilter(MP);
}

void SkillFilter::setCdFilter(int lo, int hi)
{
    setLimitFilter(CD, lo, hi);
}

void SkillFilter::cleanCdFilter()
{
    cleanLimitFilter(CD);
}

void SkillFilter::setMaxCdFilter(int lo, int hi)
{
    setLimitFilter(MAX_CD, lo, hi);
}

void SkillFilter::cleanMaxCdFilter()
{
    cleanLimitFilter(MAX_CD);
}

bool SkillFilter::valid(const PSkill* skill) const
{
    bool typeValidator = (types.size() == 0) || find(types.begin(), types.end(), lowerCase(skill->name)) != types.end();
    bool avoidValidator = (avoids.size() == 0) || find(avoids.begin(), avoids.end(), lowerCase(skill->name)) == avoids.end();
    bool levelValidator = skill->level >= limits[LEVEL].first && skill->level < limits[LEVEL].second;
    bool mpValidator = skill->mp >= limits[MP].first && skill->mp < limits[MP].second;
    bool cdValidator = skill->cd >= limits[CD].first && skill->cd < limits[CD].second;
    bool maxCdValidator = skill->maxCd >= limits[MAX_CD].first && skill->maxCd <= limits[MAX_CD].second;
    return typeValidator && avoidValidator && levelValidator && mpValidator && cdValidator && maxCdValidator;
}

void SkillFilter::cleanAll ()
{
    Filter::cleanAll();
}

/*
 * 单位相关实现
 */
PUnit::PUnit(int _typeId, int _id, int _player, int _camp, int _pos_x, int _pos_y):
    typeId(_typeId), id(_id), player(_player), camp(_camp), pos(Pos(_pos_x, _pos_y)), max_hp(0), max_mp(0), hp(0), mp(0), atk(0), def(0), speed(0), exp(0), range(0), view(0),level (0)
{
    strcpy(name, UNIT_NAME[typeId]);
    args.clear();
    buffs.clear();
    skills.clear();
}

PUnit::PUnit(string a):
    typeId(-1), max_hp(0), max_mp(0), hp(0), mp(0), atk(0), def(0), speed(0), exp(0), range(0), view(0), level (0)
{
    int len = a.length();
    for (int i=0; i<len; ++i) {
        if (a[i] == '=')
            a[i] = ' ';
    }
    char tmp1[3000];
    char tmp2[3000];
    char tmp3[3000];
    char posC[10];

    int __;
    sscanf(a.c_str(), "%s%d%d%d%d%s%s%s%s", name, &id, &player, &camp, &__, posC, tmp1, tmp2, tmp3);
    for (int i=UNIT_NAME_SIZE-1; i>=0; --i)
        if (!strcmp(UNIT_NAME[i], name)) {
            typeId = i;
            break;
        }

    string posS = posC;
    pos = String2Pos(posS);

    string tmp = tmp1;
    len = tmp.length();
    int e = -1;
    args.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('$', s);
            args.push_back(PArg(tmp.substr(s, e - s)));
            if (strcmp(args[args.size() - 1].name, "Hp") == 0) {
                hp = args[args.size() - 1].val[0];
                max_hp = args[args.size() - 1].val[1];
            } else if (strcmp(args[args.size() - 1].name,"Mp") == 0) {
                mp = args[args.size() - 1].val[0];
                max_mp = args[args.size() - 1].val[1];
            } else if (strcmp(args[args.size() - 1].name, "Atk") == 0)
                atk = args[args.size() - 1].val[0];
            else if (strcmp(args[args.size() - 1].name, "Def") == 0)
                def = args[args.size() - 1].val[0];
            else if (strcmp(args[args.size() - 1].name, "Range") == 0)
                range = args[args.size() - 1].val[0];
            else if (strcmp(args[args.size() - 1].name, "Exp") == 0) {
                exp = args[args.size() - 1].val[0];
                level = args[args.size() - 1].val[2];
            } else if (strcmp(args[args.size() - 1].name, "Speed") == 0)
                speed = args[args.size() - 1].val[0];
            else if (strcmp(args[args.size() - 1].name, "View") == 0)
                view = args[args.size() - 1].val[0];
        } while (e != len - 1);
    }

    tmp = tmp2;
    len = tmp.length();
    e = -1;
    buffs.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('$', s);
            buffs.push_back(PBuff(tmp.substr(s, e - s)));
        } while (e != len - 1);
    }

    tmp = tmp3;
    len = tmp.length();
    e = -1;
    skills.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('$', s);
            skills.push_back(PSkill(tmp.substr(s, e - s)));
        } while (e != len - 1);
    }
}

PUnit::PUnit(const PUnit& unit)
{
	this->typeId = unit.typeId;
	strcpy(this->name,unit.name);
	this->id = unit.id;
	this->player = unit.player;
	this->camp = unit.camp;
	this->pos = unit.pos;
	this->args.clear();
	this->buffs.clear();
	this->skills.clear();
	for(int i = 0; i < unit.args.size(); ++i)
		this->args.push_back(unit.args[i]);
	for(int i = 0; i < unit.buffs.size(); ++i)
		this->buffs.push_back(unit.buffs[i]);
	for(int i = 0; i < unit.skills.size(); ++i)
		this->skills.push_back(unit.skills[i]);
	this->max_hp = unit.max_hp;
	this->max_mp = unit.max_mp;
	this->hp = unit.hp;
	this->mp = unit.mp;
	this->atk = unit.atk;
	this->def = unit.def;
	this->speed = unit.speed;
	this->exp = unit.exp;
	this->range = unit.range;
	this->view = unit.view;
	this->level = unit.level;
}

bool PUnit::isHero() const //判断单位是否为英雄
{
    return lowerCase(name) == lowerCase("Hammerguard") || lowerCase(name) == lowerCase("Berserker") || lowerCase(name) == lowerCase("Scouter") || lowerCase(name) == lowerCase("Master");
}

bool PUnit::isWild() const //判断单位是否为野怪
{
    return lowerCase(name) == lowerCase("Bow") || lowerCase(name) == lowerCase("Dog") || lowerCase(name) == lowerCase("Wolf") || lowerCase(name) == lowerCase("StoneMan") || lowerCase(name) == lowerCase("Dragon") || lowerCase(name) == lowerCase("Roshan");
}
bool PUnit::isMine() const
{
    return lowerCase(name) == lowerCase("mine");
}
bool PUnit::isBase() const
{
    return lowerCase(name) == lowerCase("militaryBase");
}

const PArg* PUnit::operator[] (int _typeId) const //按类型编号查询参数
{
    int _sz = args.size();
    for (int i=0; i<_sz; ++i)
        if (_typeId == args[i].typeId || lowerCase(ARGS_NAME[_typeId]) == lowerCase(args[i].name))
            return &args[i];
    return 0;
}

const PArg* PUnit::operator[] (string _) const //按名称查询参数
{
    int _sz = args.size();
    for (int i=0; i<_sz; ++i)
    {
        if (lowerCase(_) == lowerCase(args[i].name))
            return &args[i];
    }
    return 0;
}

const PBuff* PUnit::findBuff(int _typeId) const //按类型编号查询状态
{
    int _sz = buffs.size();
    for (int i=0; i<_sz; ++i)
        if (_typeId == buffs[i].typeId || BUFF_NAME[_typeId] == buffs[i].name)
            return &buffs[i];
    return 0;
}

const PBuff* PUnit::findBuff(string _) const //按名称查询状态
{
    int _sz = buffs.size();
    for (int i=0; i<_sz; ++i)
        if (lowerCase(_) == lowerCase(buffs[i].name))
            return &buffs[i];
    return 0;
}

const PSkill* PUnit::findSkill(int _typeId) const //按类型编号查询技能
{
    int _sz = skills.size();
    for (int i=0; i<_sz; ++i)
        if (_typeId == skills[i].typeId || SKILL_NAME[_typeId] == skills[i].name)
            return &skills[i];
    return 0;
}

const PSkill* PUnit::findSkill(string _) const //按名称查询技能
{
    int _sz = skills.size();
    for (int i=0; i<_sz; ++i)
        if (lowerCase(_) == lowerCase(skills[i].name))
            return &skills[i];
    return 0;
}

bool PUnit::canMove() const //判断单位目前是否可以移动
{
    if (typeId >= 3 && typeId <= 5) return 0;
    int _sz = buffs.size();
    for (int i=0; i<_sz; ++i)
        switch (buffs[i].typeId)
            case 4: case 7: return 0;
    return 1;
}

bool PUnit::canUseSkill (const PSkill* skill) const
{
    if (!skill)
        return false;
    if (mp < skill->mp)
        return false;
    if (findBuff("Dizzy") || findBuff("Reviving"))
        return false;
    if (skill->cd)
        return false;
    return true;
}

bool PUnit::canUseSkill(int _typeId) const //判断单位目前是否可以使用某种技能，_typeId为技能类型编号
{
    return canUseSkill(findSkill(_typeId));
    /*
    const PSkill* _ = findSkill(_typeId);
    if (!_)
        return 0;
    int mp, skill_point;
    const PArg* _arg = (*this)[1];
    if (_arg)
        mp = _arg->val[0];
    else
        mp = 0;

    _arg = (*this)[6];
    if (_arg)
        skill_point = _arg->val[3];
    else
        skill_point = 0;

    bool with_dizzy = findBuff(4), with_reviving = findBuff(7);
    if (with_reviving)
        return 0;

    if (!_typeId)
        return !with_dizzy && !_->cd;
    else if (_typeId >= 20)
        return 1;
    else if (_->maxCd)
        return !with_dizzy && _->level >= 0 && mp >= _->mp && !_->cd;
    else if (_typeId == 19)
        return skill_point;
    else {
        _ = findSkill(_typeId - 1);
        return skill_point && _->level < _->maxLevel;
    }
    return 0;
    */
}

bool PUnit::canUseSkill(const string &str) const
{
    return canUseSkill(findSkill(str));
}

bool PUnit::unitMask (const string &name)
{
    return name == "PlayerInformation";
}

UnitFilter::UnitFilter():
    Filter(UNIT_LIMIT_SIZE)
{
}

void UnitFilter::output (ostream& os) const
{
    Filter::output (os);
    os << "allowed camps:";
    if (allowedCamps.size() == 0)
        os << "no constraints, all types will be valid";
    else
        for (vector<int>::const_iterator iter = allowedCamps.begin(); iter != allowedCamps.end(); ++ iter)
            os << *iter << "\t";
    os << endl;

    os << "areas:";
    if (areas.size() == 0)
        os << "no constraints, all types will be valid";
    else
        for (vector<Geometry*>::const_iterator iter = areas.begin(); iter != areas.end(); ++ iter)
            os << *iter << "\t";
    os << endl;

    os << "level:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
    os << "hp:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
    os << "mp:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
    os << "maxHp:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
    os << "maxMp:[" << limits[LEVEL].first << "," << limits[LEVEL].second << ")" << endl;
}

ostream& operator << (ostream& os,  const UnitFilter& filter)
{
    filter.output(os);
    return os;
}

void UnitFilter::setLevelFilter(int lo, int hi)
{
    setLimitFilter(LEVEL, lo, hi);
}

void UnitFilter::cleanLevelFilter()
{
    cleanLimitFilter(LEVEL);
}

void UnitFilter::setHpFilter(int lo, int hi)
{
    setLimitFilter(HP, lo, hi);
}

void UnitFilter::cleanHpFilter()
{
    cleanLimitFilter(HP);
}

void UnitFilter::setMpFilter(int lo, int hi)
{
    setLimitFilter(MP, lo, hi);
}

void UnitFilter::cleanMpFilter()
{
    cleanLimitFilter(MP);
}

void UnitFilter::setMaxHpFilter(int lo, int hi)
{
    setLimitFilter(MAX_HP, lo, hi);
}

void UnitFilter::cleanMaxHpFilter()
{
    cleanLimitFilter(MAX_HP);
}

void UnitFilter::setMaxMpFilter(int lo, int hi)
{
    setLimitFilter(MAX_MP, lo, hi);
}

void UnitFilter::cleanMaxMpFilter()
{
    cleanLimitFilter(MAX_MP);
}

void UnitFilter::setCampFilter (int camp)
{
    allowedCamps.push_back(camp);
}

void UnitFilter::cleanCampFilter ()
{
    allowedCamps.clear();
}

void UnitFilter::setAreaFilter(Geometry* const area, const char* method)
{
    bool clear = false;
    if (strcmp(method, "w") == 0)
        clear = true;
    else if (strcmp(method, "a") == 0)
        clear = false;
    else {
        cout << "wrong typeFilter method: " << method << endl;
        return;
    }

    if (clear)
        areas.clear();
    areas.push_back(area);
}

void UnitFilter::cleanAreaFilter()
{
    try {
        int areaSize = areas.size();
        for (int i=0; i<areaSize; ++i)
            delete areas[i];
    }

    catch (const std::exception &e) {
        std::cout << " a standard exception was caught, with message: "
                  << e.what() << endl;
    }
    areas.clear();
}

void UnitFilter::cleanAll()
{
    Filter::cleanAll();
    cleanAreaFilter();
}
bool UnitFilter::valid(const PUnit* unit) const
{
    bool typeValidator = (types.size() == 0) || find(types.begin(), types.end(), lowerCase(unit->name)) != types.end();
    bool avoidValidator = (avoids.size() == 0) || find(avoids.begin(), avoids.end(), lowerCase(unit->name)) == avoids.end();
    bool levelValidator = unit->level >= limits[LEVEL].first && unit->level < limits[LEVEL].second;
    bool hpValidator = unit->hp >= limits[HP].first && unit->hp < limits[HP].second;
    bool mpValidator = unit->mp >= limits[MP].first && unit->mp < limits[MP].second;
    bool maxHpValidator = unit->max_hp >= limits[MAX_HP].first && unit->max_hp < limits[MAX_HP].second;
    bool maxMpValidator = unit->max_mp >= limits[MAX_MP].first && unit->max_mp < limits[MAX_MP].second;
    int areaSize = areas.size();
    bool areaValidator = areaSize == 0;
    for (int i=0; i<areaSize; ++i)
        areaValidator |= areas[i]->contain(unit->pos);
    bool campValidator = allowedCamps.size() == 0;
    if (campValidator == false)
    {
        for (vector<int>::const_iterator iter = allowedCamps.begin(); iter != allowedCamps.end(); ++iter)
            if (unit->camp == *iter)
            {
                campValidator = true;
                break;
            }
    }
    //cout << typeValidator << avoidValidator << levelValidator << hpValidator << mpValidator << maxMpValidator << maxHpValidator << areaValidator << campValidator << endl;
    //cout << types.size() << endl;
    //if (types.size())
        //for (auto s: types)
            //cout << s << endl;
    return typeValidator && avoidValidator && levelValidator && hpValidator && mpValidator && maxMpValidator && maxHpValidator && maxMpValidator && areaValidator && campValidator;
}

/*
 * 作为传入参数的局面信息相关实现
 */
PPlayerInfo::PPlayerInfo(int _round, int _player, int _camp, int _gold):
    round(_round), player(_player), camp(_camp), gold(_gold)
{
    units.clear();
    flights.clear();
    areas.clear();
}

PPlayerInfo::PPlayerInfo(string a)
{
    int len = a.length();
    for (int i=0; i<len; ++i) {
        if (a[i] == '#')
            a[i] = ' ';
    }
    static char tmp1[30000];
    static char tmp2[30000];
    static char tmp3[30000];
    sscanf(a.c_str(), "%d%d%d%d%s%s%s", &camp, &player, &round, &gold, tmp1, tmp2, tmp3);

    string tmp = tmp1;
    len = tmp.length();
    int e = -1;

    units.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('@', s);
            units.push_back(PUnit(tmp.substr(s, e - s)));
        } while (e != len - 1);
    }

    tmp = tmp2;
    len = tmp.length();
    e = -1;
    flights.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('@', s);
            flights.push_back(PFlight(tmp.substr(s, e - s)));
        } while (e != len - 1);
    }

    tmp = tmp3;
    len = tmp.length();
    e = -1;
    areas.clear();

    if (len != 1) {
        do {
            int s = e + 1;
            e = tmp.find('@', s);
            areas.push_back(PArea(tmp.substr(s, e - s)));
        } while (e != len - 1);
    }

}

PPlayerInfo::PPlayerInfo(const PPlayerInfo& playerInfo)
{
	this->round = playerInfo.round;
	this->player = playerInfo.player;
	this->camp = playerInfo.camp;
	this->gold = playerInfo.gold;
	this->units.clear();
	this->flights.clear();
	this->areas.clear();
	for(int i = 0; i < playerInfo.units.size(); ++i)
		this->units.push_back(playerInfo.units[i]);
	for(int i = 0; i < playerInfo.flights.size(); ++i)
		this->flights.push_back(playerInfo.flights[i]);
	for(int i = 0; i < playerInfo.areas.size(); ++i)
		this->areas.push_back(playerInfo.areas[i]);
}


/*
 * 操作相关实现
 */

Operation::Operation(const Operation &_):
    id(_.id)
{
    if (_.typeId >= 0 && _.typeId < OPERATION_NAME_SIZE) {
        typeId = _.typeId;
        type = OPERATION_NAME[typeId];
    } else {
        typeId = -1;
        for (int i=OPERATION_NAME_SIZE-1; i>=0; --i)
            if (_.type == OPERATION_NAME[i]) {
                typeId = i;
                break;
            }
        if (typeId >= 0) type = _.type;
        else type = "Stop";
    }
    targets.clear();
    int _sz = _.targets.size();
    for (int i=0; i<_sz; ++i)
        targets.push_back(_.targets[i]);
}

bool checkPos(Pos A)
{
    return 0 <= A.x && A.x < MAP_SIZE && 0 <= A.y && A.y < MAP_SIZE;
}

void findShortestPath(const PMap &map, Pos start, Pos dest, std::vector<Pos> &_path)
//寻路，返回从位置start到dest的一条最短路径，考虑悬崖，不考虑其它单位，若路径不存在返回到离目标点最近的一个点的路径
{
    PMap map0 = map;
    _path.clear();
    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    ++countF;
    vst[start.x][start.y] = countF;
    int min = INT_MAX;
    Pos nearest = start;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord+4);

        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }
    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }

}

void findShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径
{
    PMap map0 = map;
    int _sz = blocks.size();

    ++countF;
    _path.clear();
    int min = INT_MAX;
    Pos nearest = start;
    for (int i=0; i<_sz; ++i)
    {
        if (checkPos(blocks[i]))
            vst[blocks[i].x][blocks[i].y] = countF;
    }
    if (!checkPos(start) || !checkPos(dest))
    {
        _path.push_back(Pos());
        return;
    }
    vst[start.x][start.y] = vst[dest.x][dest.y] = countF - 1;

    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord+4);

        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }

    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }
}

void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, std::vector<Pos> &_path)
//带标志点寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），考虑悬崖，不考虑其它单位，若路径不存在返回到离目标点最近的一个点的路径
{
    _path.clear();
    _path.push_back(symbols[0]);
    int _sz = symbols.size(), _sz0;
    std::vector<Pos> segPath;
    for (int i=1; i<_sz; ++i) {
        findShortestPath(map, symbols[i - 1], symbols[i], segPath);
        _sz0 = segPath.size();
        for (int j=1; j<_sz0; ++j)
            _path.push_back(segPath[j]);
        if (segPath.back() != symbols[i])
            return;
    }
}
void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//带卡位和标志点的寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径i
{
    _path.clear(); _path.push_back(symbols[0]);
    int _sz = symbols.size(), _sz0;
    std::vector<Pos> segPath;
    for (int i=1; i<_sz; ++i) {
        findShortestPath(map, symbols[i - 1], symbols[i], blocks, segPath);
        _sz0 = segPath.size();
        for (int j=1; j<_sz0; ++j)
            _path.push_back(segPath[j]);
        if (segPath.back() != symbols[i])
            return;
    }
}

/*
void infectedBySkill(const PPlayerInfo &info, int _unitId, int _typeId, std::vector<const PUnit*> &_unitList)
//返回编号为_unitId的单位目前使用某种技能可能影响到（即在射程内）的单位列表_unitList，_typeId为技能类型编号
{
    _unitList.clear();
    int _sz = info.units.size(), _camp = info.camp; const PUnit* hero = 0;
    for (int i=0; i<_sz; ++i)
        if (info.units[i].id == _unitId) {
            hero = &info.units[i];
            break;
        }
    if (!hero) return;

    _sz = hero->skills.size();
    bool skill_ex = 0;
    for (int i=0; i<_sz; ++i)
        if (hero->skills[i].typeId == _typeId) {
            skill_ex = 1;
            break;
        }
    if (!skill_ex) return;

    int _range = 0;
    switch (_typeId) {
        case 0: {
            _sz = hero->args.size();
            for (int i=0; i<_sz; ++i)
                if (hero->args[i].typeId == 5) {
                    _range = hero->args[i].val[0];
                    break;
                }
            break;
        }
        case 1: {
            _range = Charge_range;
            break;
        }
        case 3: {
            _range = Spin_range;
            break;
        }
        case 5: {
            _range = Yell_range;
            break;
        }
        case 7: {
            _range = PiercingArrow_range;
            break;
        }
        case 9: {
            _range = RainyPlace_range;
            break;
        }
        case 15: {
            _range = FlyingBlade_range;
            break;
        }
        case 17: {
            _range = Blink_range;
            break;
        }
    }
    if (!_range) return;

    _sz = info.units.size();
    Pos pos = hero->pos;
    const PUnit* _;
    for (int i=0; i<_sz; ++i)
        if (dis2(pos, info.units[i].pos) <= _range && info.units[i].id != _unitId) {
            _ = &info.units[i];
            if (_typeId < 17 && _->camp == _camp) continue;
            if (_typeId == 1 && _->typeId >= 3 && _->typeId <= 5) continue;
            _unitList.push_back(&info.units[i]);
        }
}
*/

Console::Console(const PMap &_map, const PPlayerInfo &_info, PCommand &_cmd)
{
    srand(time(NULL));
    map = &(_map);
    info = &(_info);
    cmd = &(_cmd);
    cmd->cmds.clear();
	newHeroPos.clear();
    shortestPathInUse = findShortestPath;
    selected = NULL;
    if(info->camp == 2) return; //中立单位略去与基地相关所有操作
    for(int i = 0; i < info->units.size(); ++i)
    {
        if(!strcmp(info->units[i].name,"MilitaryBase") && info->units[i].camp == info->camp)
        {
            militaryBase = &info->units[i];
            break;
        }
    }
    std::vector<const PUnit*> enemyNearBase;
    for(int i = 0; i < info->units.size(); ++i)
    {
        if(info->units[i].isHero()
        && info->units[i].camp != info->camp
        && dis2(info->units[i].pos, militaryBase->pos) <= MILITARY_BASE_RANGE)
            enemyNearBase.push_back(&(info->units[i]));
    }
    if(enemyNearBase.size() > 0)
        baseAttackTarget = enemyNearBase[rand()%enemyNearBase.size()];
    else
        baseAttackTarget = NULL;

    gold_cost_round = 0;
}

Console::~Console()
{
    if(info->camp == 2) return; //中立单位略去与基地相关所有操作
    if(baseAttackTarget != NULL)
    {
        Operation op;
        op.id = militaryBase->id;
        op.type = "Attack";
        op.targets.push_back(baseAttackTarget->pos);
        cmd->cmds.push_back(op);
    }
}
PUnit* Console::getUnit(int id)
{
    PUnit* res = NULL;
    for (const auto& unit: info->units)
    {
        if (unit.id == id)
        {
            res = (PUnit*)&unit;
            break;
        }
    }
    return res;
}
PSkill* Console::getSkill (const string& name, const PUnit* ptr)
{
    checkSelected (ptr);
    vector<PSkill> skills = ptr->skills;
    for (auto& skill: skills)
        if (lowerCase(skill.name) == lowerCase(name))
            return &skill;
    return NULL;
}

PBuff* Console::getBuff (const string& name, const PUnit* ptr)
{
    checkSelected (ptr);
    vector<PBuff> buffs = ptr->buffs;
    for (auto& buff: buffs)
        if (lowerCase(buff.name) == lowerCase(name))
            return &buff;
    return NULL;
}

void Console::changeShortestPathFunc(shortestPathFunc newSPFunc)
{
    shortestPathInUse = newSPFunc;
}

void Console::selectUnit(const PUnit* selectedUnit)
{
    selected = selectedUnit;
}

void Console::selectHero(int chooseRank)
{
    for(int i = 0; i < info->units.size(); ++i)
    {
        if(info->units[i].isHero() && info->units[i].camp == info->camp)
        {
            if(chooseRank == 0)
            {
                selectUnit(&(info->units[i]));
                return;
            }
            else --chooseRank;
        }
    }
    cout << "Cannot find hero chosen in rank of " << chooseRank << endl;
}
bool Console::checkSelected (const PUnit*& unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    return true;
}

void Console::move(const Pos& target, const PUnit* ptr)
{
    if(ptr == NULL)  ptr = selected;
    if(ptr == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return;
    }
    vector<Pos> blocks,path;
    blocks.clear();
    path.clear();
    for(int j = 0; j < info->units.size(); ++j)
        if (info->units[j].id != ptr->id)
            blocks.push_back(info->units[j].pos);
    for(int k = 0; k < MINE_NUM; ++k)
        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
        blocks.push_back(MILITARY_BASE_POS[k]);
    Pos destination = (Pos)target;
    shortestPathInUse(*map, ptr->pos, destination, blocks, path);
    move (path, ptr);
}

void Console::move (const vector<Pos>& path, const PUnit* unit)
{
    checkSelected(unit);
    Operation op;
    op.id = unit->id;
    op.type = "Move";
    op.targets = path;
    cmd->cmds.push_back(op);
}

void Console::attack(const PUnit* target, const PUnit* ptr)
{
    if(ptr == NULL)  ptr = selected;
    if(ptr == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return;
    }
    if(dis2(ptr->pos, target->pos) <= ptr->range && ptr->canUseSkill("Attack"))
    {
        Operation op;
        op.id = ptr->id;
		op.type = "Attack";
        op.targets.push_back(target->pos);
        cmd->cmds.push_back(op);
    }
    else
        move(target->pos, ptr);
}

void Console::chooseHero(std::string name, Pos pos)
{
    UnitFilter filter;
    filter.setTypeFilter(name.c_str());
    int num = friendlyUnits(filter).size();

    Operation op;
    op.id = militaryBase->id;
    if(lowerCase(name) == "hammerguard")
    {
        op.type = "ChooseHammerguard";
        gold_cost_round += (NEW_HAMMERGUARD_COST * (num + 1));
    }
    else if(lowerCase(name) == "master")
    {
        op.type = "ChooseMaster";
        gold_cost_round += (NEW_MASTER_COST * (num + 1));
    }
    else if(lowerCase(name) == "berserker")
    {
        op.type = "ChooseBerserker";
        gold_cost_round += (NEW_BERSERKER_COST * (num + 1));
    }
    else if(lowerCase(name) == "scouter")
    {
        op.type = "ChooseScouter";
        gold_cost_round += (NEW_SCOUTER_COST * (num + 1));
    }
    else
    {
        std::cout << "Error:Cannot find hero whose name is " << name << "!" << std::endl;
        return;
    }
    if(!checkPos(pos))
	{
		Pos bornPos = randPosInArea(militaryBase->pos, 16);
		while(find(newHeroPos.begin(),newHeroPos.end(),bornPos) != newHeroPos.end())
			bornPos = randPosInArea(militaryBase->pos, 16);
        op.targets.push_back(bornPos);//to ensure that the new hero is to be born on a flat place;
		newHeroPos.push_back(bornPos);
	}
    else
        op.targets.push_back(closestPos(militaryBase->pos, BUY_NEW_HERO_RANGE, pos));
    cmd->cmds.push_back(op);
}
void Console::buyBackHero(const PUnit* target, Pos pos)
{
    Operation op;
    op.id = militaryBase->id;
    op.type = "BuyBackHero";
    op.targets.push_back(target->pos);
    if(!checkPos(pos))
        op.targets.push_back(randPosInArea(militaryBase->pos, BUYBACK_RANGE));
    else
        op.targets.push_back(closestPos(militaryBase->pos, BUYBACK_RANGE, pos));
    cmd->cmds.push_back(op);
    gold_cost_round += buyBackCost(unitArg("level", "l", target));
}

void Console::callBackHero(const PUnit* target, Pos pos)
{
    Operation op;
    op.id = militaryBase->id;
    op.type = "CallBackHero";
    op.targets.push_back(target->pos);
    if(!checkPos(pos))
        op.targets.push_back(randPosInArea(militaryBase->pos, 16));
    else
        op.targets.push_back(closestPos(militaryBase->pos, CALLBACK_RANGE, pos));
    cmd->cmds.push_back(op);
    gold_cost_round += callBackCost(unitArg("level", "l", target));
}

void Console::buyHeroLevel(const PUnit* target)
{
    Operation op;
    op.id = militaryBase->id;
    op.type = "BuyHeroLevel";
    op.targets.push_back(target->pos);
    cmd->cmds.push_back(op);
    gold_cost_round += levelUpCost(unitArg("level", "l", target));
}

void Console::baseAttack(const PUnit* target)
{
    baseAttackTarget = target;
}
Pos Console::randPosInArea (const Geometry* geo)
{
    while (true)
    {
        Pos pos = geo->randPosInArea();
        bool conflict = false;
        for(int i = 0; i < info->units.size(); ++i)
            if(pos.x == info->units[i].pos.x && pos.y == info->units[i].pos.y)
            {
                conflict = true;
                break;
            }
        if(!conflict && checkPos(pos)) 
            return pos;
    }
}
Pos Console::randPosInArea(Pos center, int range)
{
    while(true)
    {
        int r = (int)sqrt((double)range);
        int x = (rand()% (r + 1)) * ((rand()%2) * 2 - 1);
        int y = (rand()%((int)sqrt((double)(range - x * x)) + 1)) * ((rand()%2) * 2 - 1);
        x += center.x;
        y += center.y;
        bool conflict = false;
        for(int i = 0; i < info->units.size(); ++i)
            if(x == info->units[i].pos.x && y == info->units[i].pos.y)
            {
                conflict = true;
                break;
            }
        Pos ansPos = Pos(x,y);
        if(!conflict && checkPos(ansPos)) return ansPos;
    }
}

Pos Console::closestPos(Pos center, int range, Pos target)
{
    if(dis2(center, target) <= range) return target;
    double delta_x = (double)(target.x - center.x);
    double delta_y = (double)(target.y - center.y);
    double l = sqrt((double)(delta_x * delta_x + delta_y * delta_y));
    double r = sqrt((double)range);
    int x = (int)(delta_x / l * r) + center.x;
    int y = (int)(delta_y / l * r) + center.y;
    return Pos(x,y);
}
vector<PUnit*> Console::friendlyUnits (const UnitFilter& filter)
{
    vector<PUnit*> result;
    result.clear();
    for (int i = 0; i < SIZE(info->units); ++i)
    {
        //cout << info->units[i].id << " " << info->units[i].name << " " << info->units[i].camp << " " << info->camp << " " <<  filter.valid(&(info->units[i]))  << " " <<  PUnit::unitMask(info->units[i].name) << endl;
        if (info->units[i].camp == info->camp && filter.valid(&(info->units[i])) && !PUnit::unitMask(info->units[i].name))
            result.push_back ((PUnit*)(&(info->units[i])));
    }
    return std::move(result);
}
vector<PUnit*> Console::enemyUnits (const UnitFilter& filter)
{
    vector<PUnit*> result;
    result.clear();
    for (int i = 0; i < SIZE(info->units); ++i)
    {
        if (info->units[i].camp != info->camp && filter.valid(&(info->units[i])) && !PUnit::unitMask(info->units[i].name))
            result.push_back ((PUnit*)(&(info->units[i])));
    }
    return std::move(result);
}

vector<PSkill*> Console::getSkills (const SkillFilter& filter, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error: There is no selected unit." << std::endl;
        return vector<PSkill*>();
    }
    vector<PSkill*> res;
    for (int i = 0; i < SIZE(unit->skills); ++i)
    {
        if (filter.valid (&(unit->skills[i])) && !PSkill::skillMask(unit->skills[i].name))
            res.push_back ((PSkill*)(&(unit->skills[i])));
    }
    return std::move(res);
}
vector<PSkill*> Console::getAvailableSkills(const SkillFilter& filter, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error: There is no selected unit." << std::endl;
        return vector<PSkill*>();
    }
    vector<PSkill*> all = getSkills(filter, unit), res;
    for (vector<PSkill*>::iterator iter = all.begin(); iter != all.end(); ++iter)
    {
        if (unit->canUseSkill(*iter))
            res.push_back(*iter);
    }
    return std::move(res);
}

bool Console::useSkill (const PSkill* skill, const PUnit* target, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (skill == NULL)
    {
        cout << "Error: There is no such a skill: " << skill->name << endl;
        return false;
    }
    if (skill->needTarget() && target == NULL)
    {
        cout << "Error: There is no target: " << skill->name << endl;
        return false;
    }
    if (!unit->canUseSkill(skill))
        return false;
    Operation op;
    op.id = unit->id;
    if (skill->needTarget() == false || skill->range() >= dis2 (unit->pos, target->pos))
    {
        op.type = skill->name;
        op.targets.clear();
        if (target != NULL)
            op.targets.push_back (target->pos);

        if (skill->needTarget() == false)
            op.targets.clear();
        cmd->cmds.push_back (op);
    }
    else
    {
        op.type = "Move";
        op.targets.clear();
        op.targets.push_back (target->pos);
        cmd->cmds.push_back (op);
    }
    return true;
}
bool Console::useSkill (const char* skillName, const PUnit* target, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (unit->findSkill(skillName) == NULL)
    {
        cout << "Error: There is no such a skill: " << skillName << endl;
        return false;
    }
    return useSkill(unit->findSkill(skillName), target, unit);
}

bool Console::useSkill (const PSkill* skill, const vector<Pos>& target, const PUnit* unit)
{
    if (!skill)
        return false;
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (!unit->canUseSkill(skill))
        return false;
    Operation op;
    op.id = unit->id;
    op.type = skill->name;
    op.targets = target;
    cmd->cmds.push_back (op);
    return true;
}
bool Console::useSkill (const char* skillName, const vector<Pos>& target, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (unit->findSkill(skillName) == NULL)
    {
        cout << "Error: There is no such a skill: " << skillName << endl;
        return false;
    }
    return useSkill(unit->findSkill(skillName), target, unit);
}
bool Console::useSkill (const PSkill* skill, const Pos target, const PUnit* unit)
{
    if (!skill)
        return false;
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (!unit->canUseSkill(skill))
        return false;
    Operation op;
    op.id = unit->id;
    op.type = skill->name;
    op.targets.push_back(target);
    cmd->cmds.push_back (op);
    return true;
}
bool Console::useSkill (const char* skillName, const Pos target, const PUnit* unit)
{
    if (unit == NULL)
        unit = selected;
    if (unit == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return false;
    }
    if (unit->findSkill(skillName) == NULL)
    {
        cout << "Error: There is no such a skill: " << skillName << endl;
        return false;
    }
    return useSkill(unit->findSkill(skillName), target, unit);
}
int Console::unitArg (const string& arg, const string& val, const PUnit* unit)
{
    checkSelected(unit);
    const PArg* _arg = (*unit)[arg];
    vector<int> vals = _arg == NULL ? vector<int> () : _arg->val;
    if (lowerCase(arg) == "hp" || lowerCase(arg) == "mp")
    {
        if (lowerCase(val) == "current" || lowerCase(val) == "c")
            return vals[0];
        else if (lowerCase(val) == "max" || lowerCase(val) == "m")
            return vals[1];
        else if (lowerCase(val) == "rate" || lowerCase(val) == "r")
            return vals[2];
        else
            return -1;
    }
    else if (lowerCase(arg) == "atk" || lowerCase(arg) == "def" || lowerCase(arg) == "speed")
    {
        if (lowerCase(val) == "current" || lowerCase(val) == "c")
            return vals[0];
        else if (lowerCase(val) == "origin" || lowerCase(val) == "o")
            return vals[1];
        else
            return -1;
    }
    else if (lowerCase(arg) == "view")
    {
        if (lowerCase(val) == "current" || lowerCase(val) == "c")
            return vals[0];
        else if (lowerCase(val) == "origin" || lowerCase(val) == "o")
            return vals[1];
        else if (lowerCase(val) == "ability" || lowerCase(val) == "a")
            return val[2];
        else
            return -1;
    }
    else if (lowerCase(arg) == "range")
    {
        if (lowerCase(val) == "current" || lowerCase(val) == "c")
            return vals[0];
        else if (lowerCase(val) == "origin" || lowerCase(val) == "o")
            return vals[1];
        else if (lowerCase(val) == "affected" || lowerCase(val) == "a")
            return vals[2];
        else
            return -1;
    }
    else if (lowerCase(arg) == "level")
    {
        return unit->level;
    }
    else if (lowerCase(arg) == "lasthit")
    {
        int id;
        stringstream idStream(val);
        idStream >> id;
        if (vals.size() > id)
            return vals[id];
        else
            return -1;
    }
    else if (lowerCase(arg) == "energy")
    {
        if (vals.size())
            return vals[0];
        else
            return -1;
    }
    else
        return -1;
}
const vector<int>& Console::unitArg (const string& arg, const PUnit* unit)
{
    checkSelected(unit);
    return (*unit)[arg]->val;
}
int Console::property ()
{
    int res = gold ();
    for (auto& unit: info->units)
        if (unit.isHero())
            res += (unitArg("level", "c", &unit) * LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE);
    return res;
}
//==============================================================================================

#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Game/Game.h"
#include "include/Unit/MilitaryBase.h"
#include "include/Skill/Skills.h"
#include "include/PCommand//Operation.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
#include <vector>
#include <iostream>
using namespace std;

MilitaryBase::MilitaryBase(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Unit(Gm,"MilitaryBase",Camp,Player,ID,1,Ps)
{
    addSkill(new ChooseHammerguard(this));
    addSkill(new ChooseMaster(this));
    addSkill(new ChooseBerserker(this));
    addSkill(new ChooseScouter(this));
    addSkill(new Attack(this,MILITARY_BASE_ATTACK_MAXCD));
    addSkill(new BuyBackHero(this));
    addSkill(new CallBackHero(this));
    addSkill(new BuyHeroLevel(this));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(MILITARY_BASE_HP, MILITARY_RATE_HP, this));
    addArg(new Atk(MILITARY_BASE_ATK,this));
    addArg(new Def(MILITARY_BASE_DEF,this));
    addArg(new Range(MILITARY_BASE_RANGE,0,this));
    addArg(new View(MILITARY_BASE_VIEW,this));
    addArg(new LastHit(this));
	cmds.clear();
}

void MilitaryBase::setCmd(const Operation& Cmd)
{
    if(Cmd.type == "Attack")
    {
        if(cmd!=NULL)
            delete cmd;
        cmd=new Operation(Cmd);
    }
    else
    {
        Operation* single_cmd=new Operation(Cmd);
        cmds.push_back(single_cmd);
    }
}

void MilitaryBase::addBuff(Buff* newBuff)
{
	delete newBuff;
}

int MilitaryBase::getStatus()
{
    return findArg("Hp")->getVal()<=0;
}

void MilitaryBase::roundStart()
{
    UnitArg* goldPtr;
    if (goldPtr = findArg("Gold"))
        goldPtr->change(Gold::Total, getPlayerInfo()->getGold());
	for(int i = 0; i < cmds.size(); ++i)
	{
		if(cmds[i] != NULL)
			delete cmds[i];
	}
    cmds.clear();
    if(cmd!=NULL)
        delete cmd;
    Operation StopOperation;
    StopOperation.type = "Stop";
    cmd = new Operation(StopOperation);
    for(int i=0;i<args.size();++i)
        args[i]->roundStart();
    for(int i=0;i<buffs.size();++i)
        buffs[i]->roundStart();
    col=0;
    step=0;
    lastPos=pos;
}

#include "include/ActMaker/ActMakerLocal.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/PCommand/PCommand.h"
#include "include/sdk/sdk.h"
#include <iostream>
#include <fstream>
using namespace std;
bool ActMakerLocal::load(const char* fileName)
{
#ifdef _AC_WIN_
#ifdef _AC_WIN_VS_
    int len = strlen(fileName);
    WCHAR *fileNameWChar = new WCHAR[(len + 10) * 4];
    MultiByteToWideChar(0, 0, fileName, (len + 5) * 4, fileNameWChar, (len + 5) * 4 + 1);
    dll=LoadLibrary(fileNameWChar);
    delete []fileNameWChar;
#else
    dll=LoadLibrary(fileName);
#endif//_AC_WIN_VS_
    if (!dll)
    {
        cerr<< "Get Last Error" << GetLastError() << endl;
        return false;
    }
    player_ai=(ai_func)(GetProcAddress(dll,"player_ai"));
    // before_fight = (pre_func)(GetProcAddress(dll,"before_fight"))
    if (!player_ai)
    {
        cerr<< "Get Last Error" << GetLastError() << endl;
        return false;
    }
#else
    dll=dlopen(fileName,RTLD_NOW);
    if (!dll)
    {
        cerr<< dlerror() << endl;
    }
    player_ai=reinterpret_cast<ai_func>(dlsym(dll,"player_ai"));
    // before_fight=reinterpret_cast<pre_func>(dlsym(dll,"before_fight"));
    if ( !player_ai)
    {
        cerr << "Load AI func Failed!" << endl;
        cerr<< dlerror() << endl;
    }
#endif//_AC_WIN_
    return true;
}

void ActMakerLocal::setMap(PMap *pmap)
{
    map=pmap;
}

ActMakerLocal::~ActMakerLocal()
{
    if ( dll )
#ifdef _AC_WIN_
        FreeLibrary(dll);
#else
        dlclose(dll);
#endif//_AC_WIN_
}
bool ActMakerLocal::getCmd(const PlayerInfo *info, PCommand *cmd)
{
    try
    {
        player_ai(*map,PPlayerInfo(info->toString()),*cmd);
    }
    catch(...)
    {
        return false;
    }
    return true;
}

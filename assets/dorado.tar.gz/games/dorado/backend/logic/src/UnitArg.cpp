//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/Unit/Mine.h"
#include "include/UnitArg/UnitArg.h"
#include <assert.h>
#include <ctime>
#include <cstdlib>
UnitArg::UnitArg(const char* myName, Unit* myUnit):
    name(myName),unit(myUnit)
{
    val.clear();
}
void UnitArg::add(int no,int deltaValue)
{
 //   val[no]+=deltaValue;
    change(no,val[no]+deltaValue);
}
int UnitArg::getVal(int no)//获取数值
{
	if(val.size()<=no)
	{
		int k=val.size();
		val.resize(no+1);
		for(int i=k;i<val.size();++i)
			val[i]=-1;
	}
    return val[no];
}
void UnitArg::oneRoundPass()//参数生效，如生命值回复速率，法力回复速率等
{
}
void UnitArg::roundStart()//回合初始，无视所有buff
{
}
void UnitArg::change(int no,int newValue)//数值变化,可能引起事件，如升级等
{
	if(val.size()<=no)
	{
		int k=val.size();
		val.resize(no+1);
		for(int i=k;i<val.size();++i)
			val[i]=-1;
	}
    val[no]=newValue;
}
string UnitArg::toString()
{
    string tmp = name;
    int _size = val.size();
    for (int i=0; i<_size; ++i)
    {
        tmp = tmp + "&" + ToString(val[i]);
    }
    return tmp;
}
//===========================
Hp::Hp(int Origin, int Rate, Unit* myUnit) :
    UnitArg("Hp", myUnit)//hp/当前hp上限/hp回复速率/正常hp上限
{
    val.resize(4);
    val[0]=val[1]=val[3]=Origin;
    val[2]=Rate;
    if(val[2]<1)
        val[2]=1;
}
void Hp::roundStart()
{
}
void Hp::oneRoundPass()
{
    if (!unit->findBuff("Reviving"))
        val[0]+=val[2];
//    if(val[0]>val[1])
//        val[0]=val[1];
}
void Hp::output(ostream &os, bool seperator)
{
    os<<"hp:"<<val[0]<<";";
    os<<"maxHp:"<<val[1]<<";";
    os<<"hpRate:"<<val[2];
	if (seperator)
		os << ";";
}
void Hp::check()
{
    if (val[0]>val[1])
        val[0]=val[1];
}
//===================
Mp::Mp(int Origin, int Rate, Unit* myUnit) :
    UnitArg("Mp", myUnit)//Mp/当前Mp上限/Mp回复速率/正常Mp上限
{
    val.resize(4);
    val[0]=val[1]=val[3]=Origin;
    val[2]=Rate;
    if(val[2]<1)
        val[2]=1;
}
void Mp::roundStart()
{
}
void Mp::oneRoundPass()
{
    val[0]+=val[2];
//    if(val[0]>val[1])
//        val[0]=val[1];
}
void Mp::output(ostream &os, bool seperator)
{
    os<<"mp:"<<val[0]<<";";
    os<<"maxMp:"<<val[1]<<";";
    os<<"mpRate:"<<val[2];
	if (seperator)
		os << ";";
}

void Mp::check()
{
    if (val[0]>val[1])
        val[0]=val[1];
}
//===================
Exp::Exp(int nextLevel,int level,int skillPoint,int DeadExp, Unit* myUnit) :
    UnitArg("Exp", myUnit)//当前经验值，升一级要达到的经验，当前等级，当前剩余技能点
{
    val.push_back(0);
    val.push_back(nextLevel);
    val.push_back(level);
    val.push_back(skillPoint);
    val.push_back(DeadExp);
}
void Exp::output(ostream &os, bool seperator)
{
    os<<"exp:"<<val[0]<<";";
    os<<"nextLevel:"<<val[1]<<";";
    os<<"level:"<<val[2]<<";";
    os<<"skillPoints:"<<val[3];
	if (seperator)
		os << ";";
}
//===============
Speed::Speed(int Origin,Unit* myUnit):
	UnitArg("Speed",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Speed::output(ostream &os, bool seperator)
{
    os<<"speed:"<<val[0];
	if (seperator)
		os << ";";
}
//============
View::View(int Origin,Unit* myUnit,int Detector):
	UnitArg("View",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
    val.push_back(Detector);
}
void View::output(ostream &os, bool seperator)
{
    os<<"view:"<<val[0]<<";";
    os<<"detector:"<<val[2];
	if (seperator)
		os << ";";
}
//===========
Atk::Atk(int Origin,Unit* myUnit):
	UnitArg("Atk",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Atk::output(ostream &os, bool seperator)
{
    os<<"atk:"<<val[0];
	if (seperator)
		os << ";";
}

void Atk::add(int no, int deltaValue)
{
    UnitArg::add(no,deltaValue);
    if(no==1)
        UnitArg::add(0,deltaValue);
}
//==========
Def::Def(int Origin,Unit* myUnit):
	UnitArg("Def",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Def::output(ostream &os, bool seperator)
{
    os<<"def:"<<val[0];
	if (seperator)
		os << ";";
}

void Def::add(int no, int deltaValue)
{
    UnitArg::add(no,deltaValue);
    if(no==1)
        UnitArg::add(0,deltaValue);
}
//=================
Range::Range(int Origin,int Fly,Unit* myUnit):
	UnitArg("Range",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
	val.push_back(Fly);
}
void Range::output(ostream &os, bool seperator)
{
    os<<"range:"<<val[0];
	if (seperator)
		os << ";";
}
//===================
LastHit::LastHit(Unit *myUnit):
    UnitArg("LastHit",myUnit)
{
}

void LastHit::output(ostream &os, bool seperator)
{
    os<<"lastHit:{";
    int k=0;
    for(int i=0;i<val.size();++i)
        if(val[i]==unit->getGame()->getRound())
        {
            if(k>0)
                os<<";";
            ++k;
            os<<i;
        }
    os<<"}";
	if (seperator)
		os << ";";
}
//==================
OnlyTarget::OnlyTarget(Unit *myUnit):
    UnitArg("OnlyTarget",myUnit)
{
    val.push_back(-1);
}
void OnlyTarget::output(ostream &os, bool seperator)
{
    os<<"onlyTarget:"<<val[0];
	if (seperator)
		os << ";";
}
//===============================
Gold::Gold ( int total, int ability,Unit* owner):
    UnitArg("Gold", owner)
{
    val.clear();
	val.push_back(total);
	val.push_back(ability);
}
//================================
Energy::Energy (Unit* unit): UnitArg("Energy", unit)
{
    assert (unit->getName() == string ("Mine"));
    val.clear();
    val.push_back (0);
}
void Energy::output (ostream& os, bool seperator)
{
    os << "existTime:" << val[ExistTime];
    if (seperator)
        os << ";";
}
void Energy::oneRoundPass ()
{
    if (val[ExistTime] > 0)
    {
        --val[ExistTime];
        if (val[ExistTime] <= 0)
            Mine::availableCount (-1);
    }
}
void Energy::roundStart ()
{
    if (val[ExistTime] > 0 || Mine::availableCount() >= MINE_NUM_AVAILABLE)
        return;
    int randTmp = rand() % (MINE_NUM - Mine::randomCount());
    if (randTmp < MINE_NUM_AVAILABLE - Mine::availableCount())
    {
        val[ExistTime] = rand () % (EXIST_TIME_MAX - EXIST_TIME_MIN) + EXIST_TIME_MIN;
        Mine::availableCount (+1);
    }
    Mine::randomCount(+1);
}
#include "include/ActMaker/ActMakerWeb.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/PCommand/PCommand.h"
#include "include/socket_trans.h"
bool ActMakerWeb::getCmd(const PlayerInfo *info, PCommand *cmd)
{
    if ( conn_id==-1 )
        return false;
    try
    {
        auto &conn = logic::get_conn( conn_id );
        RoundInfoMeta rinfometa;
        if(conn_id==2)
            rinfometa.rlim_cpu = 1.0;
        else
            rinfometa.rlim_cpu = 0.1;
        logic::start_round(conn, rinfometa);

        conn << info->toString();
    }
    catch(...)
    {
    }
    auto &conn = logic::get_conn( conn_id );
    logic::wait( conn , rst );
    cmd->cmds.clear();
    if ( rst.status == RoundResultMeta::Status::NORMAL )
    {
        conn >> *cmd;
        return true;
    }else {
       // throw conn_id;
    }
    return false;
}
void ActMakerWeb::outStatus(ostream &os)
{
    os<<"status:"<<RoundResultMeta::status2str(rst.status)<<" msg:"<<rst.err_msg<< "status_data:" << rst.status_data << endl;
}

#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/Skill/Skill.h"
#include "include/Skill/Skills.h"
#include "include/Flight/Flights.h"
#include "include/Unit/Unit.h"
#include "include/Unit/Observer.h"
#include "include/Unit/Heroes.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Buff/Buffs.h"
#include "include/PCommand/Operation.h"
#include "include/sdk/const.h"
#include <iostream>
#define sqr(x) ((x)*(x))
#define STRUCT_ID 15
const int MAX_DES = 200;

const char* genDes(const char* s, int t)
{
    static char des[MAX_DES];
    sprintf(des, s, t);
    return des;
}
const char* genDes(const char* s, int t, int u)
{
    static char des[MAX_DES];
    sprintf(des, s, t, u);
    return des;
}
const char* genDes(const char* s, int t, int u, int v)
{
    static char des[MAX_DES];
    sprintf(des, s, t, u, v);
    return des;
}
void getAdd(int &ahp,int &aatk,int &adef,string type)
{
    if(type == "Hammerguard")
    {
        ahp = HAMMERGUARD_HP_DELTA;
        aatk = HAMMERGUARD_ATK_DELTA;
        adef = HAMMERGUARD_DEF_DELTA;
    }
    else if(type == "Master")
    {
        ahp = MASTER_HP_DELTA;
        aatk = MASTER_ATK_DELTA;
        adef = MASTER_DEF_DELTA;
    }
    else if(type == "Berserker")
    {
        ahp = BERSERKER_HP_DELTA;
        aatk = BERSERKER_ATK_DELTA;
        adef = BERSERKER_DEF_DELTA;
    }
    else if(type == "Scouter")
    {
        ahp = SCOUTER_HP_DELTA;
        aatk = SCOUTER_ATK_DELTA;
        adef = SCOUTER_DEF_DELTA;
    }
}
static int baseGoldOfHero(string name)
{
	if(name == "Hammerguard") return NEW_HAMMERGUARD_COST;
	if(name == "Master") return NEW_MASTER_COST;
	if(name == "Berserker") return NEW_BERSERKER_COST;
	if(name == "Scouter") return NEW_SCOUTER_COST;
	return 0;
}

Attack::Attack(Unit* myUnit,int MaxCd):
Skill("Attack",genDes("target ready, Range=%d", HAMMERGUARD_RANGE),
    myUnit,0,0,MaxCd,1)
{
}
bool Attack::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(!unit->getGame()->getMap()->checkPos(unit->getCmd()->targets[0]) || unit->getCmd()->targets[0] == unit->getPos())
        return false;
    int range=unit->findArg("Range")->getVal();
    if(unit->getGame()->getRoundProcess()==1)
        return cd==0&&dis2(unit->getCmd()->targets[0],unit->getPos())<=range;
    return unit->getGame()->getRoundProcess()==2
    &&lastUse==unit->getGame()->getRound();
}
bool Attack::trigger()
{
#define injury (max(dmg-def,5))
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            int dmg=unit->findArg("Atk")->getVal();
            int h0=unit->getGame()->getMap()->getHeight(unit->getPos());
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];

                if(ptr->getPos()==unit->getCmd()->targets[0])
                {
                    double percent=1.0;
                    if(h0+1<ptr->getGame()->getMap()->getHeight(unit->getPos())
                        && unit->findArg("Range")->getVal(2)==1)
                        percent=0.5;
                    int def=ptr->findArg("Def")->getVal();
                    ptr->findArg("Hp")->add(0,-percent*injury);
                    ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                    ptr->addBuff(new Buff("BeAttacked", ptr, HURT_LAST_TIME));
                }
            }
        }
        if (unit->findBuff("WinOrDie"))
            unit->findBuff("WinOrDie")->buffEnd ();
        return true;
    }
    return false;
}

//============
Dead::Dead(Unit* myUnit,Pos Ps):
Skill("Dead","No description",myUnit,0,0,0),
pos(Ps),range(EXP_SHARE_RANGE)
{
}
bool Dead::canBeUse()
{
    return unit->getGame()->getRoundProcess()==3
    && unit->findArg("Hp")->getVal(0)<=0
    && unit->findBuff("Reviving")==NULL && (!unit->findSkill("SuperDead") || !unit->findSkill("SuperDead")->canBeUse());
}
bool Dead::trigger()
{
    if(canBeUse())
    {
    //in 2016_logic, the exp must be allocated by base.
    //shareExp();
        giveMoney();
        if (unit->getName() == "MilitaryBase")
            return false;
        else
            unit->addBuff(new Reviving(unit,(unit->findArg("Exp")->getVal(2)+2)*7));

        for(int d=0;true;++d)
        {
            Pos tmp(pos.x+d,pos.y);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x-d,pos.y);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x,pos.y+d);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x,pos.y-d);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
        }
        if (unit && unit->findBuff ("WaitRevive"))
            unit->findBuff("WaitRevive")->buffEnd ();
        return true;
    }
    return false;
}
bool Dead::check(Pos tmp)
{
    // Respawn probes can leave the map before a free position is found.
    // Reject them before reading the height array.
    if (!unit->getGame()->getMap()->checkPos(tmp))
        return false;
    if (unit->getGame()->getMap()->getHeight(tmp.x, tmp.y) != unit->getGame()->getMap()->getHeight(pos.x, pos.y))//这里是应播放器的要求，他们不希望复活在坡地上
        return false;
    if(!unit->getGame()->getMap()->tryPosition(tmp,unit->getVolume()))
        return false;
    for(int i=0;i<unit->getGame()->getUnits().size();++i)
    {
        Unit* ptr=unit->getGame()->getUnits()[i];
        if(ptr->getId()==unit->getId())
            continue;
        if(dis2(ptr->getPos(),tmp)<sqr(ptr->getVolume()+unit->getVolume()-1))
            return false;
    }
    return true;
}
void Dead::giveMoney()
{
#define killercheck (ptr->getCamp()!=camp \
    && ptr->getCamp()<2 \
    && unit->findArg("LastHit")->getVal(ptr->getId())==round )
#define nearbycheck ((dis2(ptr->getPos(),unit->getPos()))<=range&& \
ptr->getCamp()!=unit->getCamp() && ptr->getCamp()!=2 && ptr->getId()>STRUCT_ID)

int lvl = 0;
if (unit->getName() == "MilitaryBase")
    lvl = 5;
else if (unit->getName() == "Observer")
    return;
else
    lvl = unit->findArg("Exp")->getVal(2);
int extraGold;
int moneyDelta;
int camp  = unit->getCamp();
Game *game= unit->getGame();
int round = unit->getGame()->getRound();
if(unit->getCamp() < 2)
{
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(killercheck && ptr->getCamp() != unit->getCamp())
        {
            extraGold = unit->getPlayerInfo()->getProperty() - ptr->getPlayerInfo()->getProperty();
            extraGold = (extraGold > 0 ? extraGold : 0) * DEATH_DELTA_FACTOR;
            moneyDelta = (lvl * LEVELUP_COST_BASE + (((lvl - 1) * lvl)/2) * LEVELUP_COST_PER_LEVEL
						 + baseGoldOfHero(ptr->getName())) * DEATH_FACTOR + extraGold;
            ptr->getPlayerInfo()->goldInc(moneyDelta);
            break;
        }
    }
    // unit->getPlayerInfo()->goldInc(-moneyDelta);
}
else
{
    int killerCamp[3] = {0};
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(killercheck && ptr->getCamp() != unit->getCamp())
            killerCamp[ptr->getCamp()] = 1;
    }
    moneyDelta = (lvl * LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE) * DEATH_FACTOR;
    if(killerCamp[0] + killerCamp[1] == 2) moneyDelta /= 2;
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(killerCamp[ptr->getCamp()])
        {
            ptr->getPlayerInfo()->goldInc(moneyDelta);
            killerCamp[ptr->getCamp()] = 0;
        }
    }
}
}
void Dead::shareExp()
{
    int delta = unit->findArg("Exp")->getVal(4);
    int camp  = unit->getCamp();
    Game *game= unit->getGame();
    int round = unit->getGame()->getRound();
    int cnt=0;
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(killercheck)
            ++cnt;
    }
    if(cnt>0)
        for(int i=0;i<game->getUnits().size();++i)
        {
            Unit* ptr=game->getUnits()[i];
            if(killercheck)
                ptr->findArg("Exp")->add(0,delta/2/cnt);
        }
        cnt=0;
        for(int i=0;i<unit->getGame()->getUnits().size();++i)
        {
            Unit* ptr=unit->getGame()->getUnits()[i];
            if(nearbycheck)
                cnt++;
        }
        if(cnt>0)
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(nearbycheck)
                    ptr->findArg("Exp")->add(0,delta/2/cnt);
            }
        }

/*
//===========
ChooseFighter::ChooseFighter(Unit* myUnit,Pos Ps):
Skill("ChooseFighter","No description",myUnit,0,0,0),pos(Ps)
{
}

bool ChooseFighter::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseFighter::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Fighter(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
//=========================
ChooseArcher::ChooseArcher(Unit *myUnit, Pos Ps):
Skill("ChooseArcher","No description",myUnit,0,0,0),pos(Ps)
{
}
bool ChooseArcher::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseArcher::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Archer(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
//===========================
ChooseAssassin::ChooseAssassin(Unit *myUnit, Pos Ps):
Skill("ChooseAssassin","No description",myUnit,0,0,0),pos(Ps)
{
}
bool ChooseAssassin::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseAssassin::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Assassin(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
*/

//Buy Hero

static bool isHero(Unit* unit)
{
    return unit->getName() == "Hammerguard" || unit->getName() == "Master"
        || unit->getName() == "Scouter" || unit->getName() == "Berserker";
}

static int getCampHeroNum(Unit* unit)
{
    int HeroNum = 0;
    vector<Unit*> units = unit->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(units[i]->getCamp() == unit->getCamp() && isHero(units[i]))
            ++HeroNum;
    }
    return HeroNum;
}

ChooseHammerguard::ChooseHammerguard(MilitaryBase *myBase):
Skill("ChooseHammerguard","No description",myBase,0,0,0,true),base(myBase)
{
}

bool ChooseHammerguard::canBeUse(Operation* cmd)
{
    if(base->getPlayerInfo()->getGold() < cost())
        return false;
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=1)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || dis2(base->getPos(),cmd->targets[0]) > BUY_NEW_HERO_RANGE)
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0)
            return false;
    }
    if(getCampHeroNum(base) >= HERO_LIMIT) return false;
    return true;
}

bool ChooseHammerguard::trigger()
{
    bool flag = false;
    vector<Operation*> cmds = base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            base->getPlayerInfo()->goldInc(-cost());
            unit->getGame()->addUnit(new Hammerguard(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,cmds[k]->targets[0]));
            vector<Unit*>units = unit->getGame()->getUnits();
            units[units.size() - 1]->addBuff(new ChosenByBase(units[units.size() - 1]));
            flag = true;
        }
    }
    return flag;
}
int ChooseHammerguard::cost()
{
    int i = 0;
    vector<Unit*> units = base->getGame()->getUnits();
    for (vector<Unit*>::const_iterator iter = units.begin(); iter != units.end(); ++iter)
    {
        if ((*iter)->getName() == "Hammerguard" && (*iter)->getCamp() == base->getCamp())
            ++i;
    }
    return (NEW_HAMMERGUARD_COST * (i + 1));
}

ChooseMaster::ChooseMaster(MilitaryBase *myBase):
Skill("ChooseMaster","No description",myBase,0,0,0,true),base(myBase)
{
}

bool ChooseMaster::canBeUse(Operation* cmd)
{
    if(base->getPlayerInfo()->getGold() < cost())
        return false;
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=1)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || dis2(base->getPos(),cmd->targets[0]) > BUY_NEW_HERO_RANGE)
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0)
            return false;
    }
    if(getCampHeroNum(base) >= HERO_LIMIT) return false;
    return true;
}

bool ChooseMaster::trigger()
{
    bool flag = false;
    vector<Operation*> cmds = base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            base->getPlayerInfo()->goldInc(-cost());
            unit->getGame()->addUnit(new Master(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,cmds[k]->targets[0]));
            vector<Unit*>units = unit->getGame()->getUnits();
            units[units.size() - 1]->addBuff(new ChosenByBase(units[units.size() - 1]));
            flag = true;
        }
    }
    return flag;
}
int ChooseMaster::cost()
{
    int i = 0;
    vector<Unit*> units = base->getGame()->getUnits();
    for (vector<Unit*>::const_iterator iter = units.begin(); iter != units.end(); ++iter)
    {
        if ((*iter)->getName() == "Master" && (*iter)->getCamp() == base->getCamp())
            ++i;
    }
    return (NEW_MASTER_COST * (i + 1));
}

ChooseBerserker::ChooseBerserker(MilitaryBase *myBase):
Skill("ChooseBerserker","No description",myBase,0,0,0,true),base(myBase)
{
}

bool ChooseBerserker::canBeUse(Operation* cmd)
{
    if(base->getPlayerInfo()->getGold() < cost())
        return false;
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=1)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || dis2(base->getPos(),cmd->targets[0]) > BUY_NEW_HERO_RANGE)
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0)
            return false;
    }
    if(getCampHeroNum(base) >= HERO_LIMIT) return false;
    return true;
}

bool ChooseBerserker::trigger()
{
    bool flag = false;
    vector<Operation*> cmds = base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            base->getPlayerInfo()->goldInc(-cost());
            unit->getGame()->addUnit(new Berserker(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,cmds[k]->targets[0]));
            vector<Unit*>units = unit->getGame()->getUnits();
            units[units.size() - 1]->addBuff(new ChosenByBase(units[units.size() - 1]));
            flag = true;
        }
    }
    return flag;
}
int ChooseBerserker::cost()
{
    int i = 0;
    vector<Unit*> units = base->getGame()->getUnits();
    for (vector<Unit*>::const_iterator iter = units.begin(); iter != units.end(); ++iter)
    {
        if ((*iter)->getName() == "Berserker" && (*iter)->getCamp() == base->getCamp())
            ++i;
    }
    return (NEW_BERSERKER_COST * (i + 1));
}

ChooseScouter::ChooseScouter(MilitaryBase *myBase):
Skill("ChooseScouter","No description",myBase,0,0,0,true),base(myBase)
{
}

bool ChooseScouter::canBeUse(Operation* cmd)
{
    if(base->getPlayerInfo()->getGold() < cost())
        return false;
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=1)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || dis2(base->getPos(),cmd->targets[0]) > BUY_NEW_HERO_RANGE)
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0)
            return false;
    }
    if(getCampHeroNum(base) >= HERO_LIMIT) return false;
    return true;
}

bool ChooseScouter::trigger()
{
    bool flag = false;
    vector<Operation*> cmds = base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            base->getPlayerInfo()->goldInc(-cost());
            unit->getGame()->addUnit(new Scouter(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,cmds[k]->targets[0]));
            vector<Unit*>units = unit->getGame()->getUnits();
            units[units.size() - 1]->addBuff(new ChosenByBase(units[units.size() - 1]));
            flag = true;
        }
    }
    return flag;
}
int ChooseScouter::cost()
{
    int i = 0;
    vector<Unit*> units = base->getGame()->getUnits();
    for (vector<Unit*>::const_iterator iter = units.begin(); iter != units.end(); ++iter)
    {
        if ((*iter)->getName() == "Scouter" && (*iter)->getCamp() == base->getCamp())
            ++i;
    }
    return (NEW_SCOUTER_COST * (i + 1));
}
//==============================
//mining
Mining::Mining(Unit* myUnit):
Skill("Mining", "Mining", myUnit, 0, 0, 0, true)
{
    mine = NULL;
}

bool Mining::canBeUse()
{
    if(level<0)
        return false;
    if (unit->getGame()->getRoundProcess() != Game::PASSIVE_SKILL_FIRST)//operate mining after movement
        return false;
    vector<Unit*> units = unit->getGame()->getUnits();
    for (int i = 0; i < units.size(); ++i)
    {
        if (units[i]->getName() == "Mine" && dis2(units[i]->getPos(), unit->getPos()) <= MINING_RANGE)
        {
            mine = static_cast<Mine*>(units[i]);
            return mine->okToMining(unit->getCamp())
            && (mine->getMaxGoldInc() != unit->findArg("Gold")->getVal(Gold::Ability)
                ||  mine->getMineCamp() != unit->getCamp());
        }
    }
    return false;
}

bool Mining::trigger()
{
    if (!canBeUse())
        return false;
    if (mine->empty())
        return false;
    mine->mining(unit->getCamp(), unit->findArg("Gold")->getVal(Gold::Ability), unit);
    return true;
}


/*
// 武伟轩 2015.09.23 新增技能

//Skill(const char* Name,const char* Des,Unit* myUnit,int Level,int MaxLevel,int MaxCd,bool TargetNeeded=0, int type = positive);

HammerAttack::HammerAttack(Unit* myUnit):
Skill("HammerAttack",genDes("I will kill you, Range=%d, MP=%d", HammerAttack_range, HammerAttack_mp),
    myUnit,0,5,HammerAttack_maxcd),
mp(HammerAttack_mp),range(HammerAttack_range)
{
}
bool HammerAttack::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        return true;
    }
    return false;
}
bool HammerAttack::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
        return unit->findArg("Mp")->getVal()>=mp&&cd==0;
    return unit->getGame()->getRoundProcess()==2
    &&lastUse==unit->getGame()->getRound();
}
bool HammerAttack::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->addBuff(new Yelling(unit,level));
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(dis2(ptr->getPos(),unit->getPos())<=range
                    &&ptr->getCamp()!=unit->getCamp())
                    ptr->addBuff(new Yelled(ptr,level,unit->getId()));
            }
        }
        return true;
    }
    return false;
}

string HammerAttack::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
*/
//These skills are for military_base of ai9_2016


BuyBackHero::BuyBackHero(MilitaryBase *myBase):
Skill("BuyBackHero","No description",myBase,0,0,0,true),base(myBase)
{
}

int BuyBackHero::goldToBuyBack(Operation* cmd)
{
    vector<Unit*> units = base->getGame()->getUnits();
    int lvl = 1 << 20;
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
        {
            lvl = units[i]->findArg("Exp")->getVal(2);
            break;
        }
    }
    return lvl * BUYBACK_COST_PER_LEVEL + BUYBACK_COST_BASE;
}

bool BuyBackHero::canBeUse(Operation* cmd)
{
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=2)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || !unit->getGame()->getMap()->checkPos(cmd->targets[1]) || dis2(base->getPos(),cmd->targets[1]) > BUYBACK_RANGE)
        return false;
    if(base->getPlayerInfo()->getGold() < goldToBuyBack(cmd))
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[1]) == 0)
            return false;
    }
    bool flag = false;
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
        {
            Buff *ptr=units[i]->findBuff("Reviving");
            if(ptr != NULL)
                flag = true;
            else
                flag = false;
        }
    }
    return flag;
}

bool BuyBackHero::trigger()
{
    bool flag = false;
    vector<Operation*> cmds =base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            vector<Unit*> units = base->getGame()->getUnits();
            for (int i = 0; i < units.size(); ++i)
            {
                if(dis2(units[i]->getPos(),cmds[k]->targets[0]) == 0)
                {
                    base->getPlayerInfo()->goldInc(-goldToBuyBack(cmds[k]));
                    Buff *ptr=units[i]->findBuff("Reviving");
                    ptr->buffEnd();
                    units[i]->changePos(cmds[k]->targets[1]);
                    units[i]->addBuff(new BuyBackByBase(units[i]));
                    break;
                }
            }
            flag = true;
        }
    }
    return flag;
}

CallBackHero::CallBackHero(MilitaryBase *myBase):
Skill("CallBackHero","No description",myBase,0,0,0,true),base(myBase)
{
}

int CallBackHero::goldToCallBack(Operation* cmd)
{
    vector<Unit*> units = base->getGame()->getUnits();
    int lvl = 1 << 20;
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
        {
            lvl = units[i]->findArg("Exp")->getVal(2);
            break;
        }
    }
    return lvl * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE;
}

bool CallBackHero::canBeUse(Operation* cmd)
{
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=2)
        return false;
    if (base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || !unit->getGame()->getMap()->checkPos(cmd->targets[1]) || dis2(base->getPos(),cmd->targets[1]) > CALLBACK_RANGE)
        return false;
    if(base->getPlayerInfo()->getGold() < goldToCallBack(cmd))
        return false;
    
    vector<Unit*> units = base->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[1]) == 0)
            return false;
    }
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
            return units[i]->findBuff("BeAttacked")==NULL;
    }
    return false;
}

bool CallBackHero::trigger()
{
    bool flag = false;
    vector<Operation*> cmds =base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            vector<Unit*> units = base->getGame()->getUnits();
            for (int i = 0; i < units.size(); ++i)
            {
                if(dis2(units[i]->getPos(),cmds[k]->targets[0]) == 0)
                {
                    base->getPlayerInfo()->goldInc(-goldToCallBack(cmds[k]));
                    units[i]->changePos(cmds[k]->targets[1]);
                    units[i]->addBuff(new CallBackByBase(units[i]));
                    break;
                }
            }
            flag = true;
        }
    }
    return flag;
}

BuyHeroLevel::BuyHeroLevel(MilitaryBase *myBase):
Skill("BuyHeroLevel","No description",myBase,0,0,0,true),base(myBase)
{
}

int BuyHeroLevel::goldToBuyLevel(Operation* cmd)
{
    vector<Unit*> units = base->getGame()->getUnits();
    int lvl = 1 << 20;
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
        {
            lvl = units[i]->findArg("Exp")->getVal(2);
            break;
        }
    }
    return lvl * LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE;
}

bool BuyHeroLevel::canBeUse(Operation* cmd)
{
    if(name!=cmd->type)
        return false;
    if(cmd->targets.size()!=1)
        return false;
    if(base->getGame()->getRoundProcess() != Game::START)
        return false;
    if(!unit->getGame()->getMap()->checkPos(cmd->targets[0]) || dis2(base->getPos(),cmd->targets[0]) > LEVELUP_RANGE)
        return false;
    if(base->getPlayerInfo()->getGold() < goldToBuyLevel(cmd))
        return false;
    vector<Unit*> units = base->getGame()->getUnits();
    int lvl = 1 << 20;
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),cmd->targets[0]) == 0 && isHero(units[i]) && units[i]->getCamp() == base->getCamp())
        {
            lvl = units[i]->findArg("Exp")->getVal(2);
            break;
        }
    }
    if(lvl >= HERO_LEVEL_LIMIT) return false;
	else return true;
    return false;
}

bool BuyHeroLevel::trigger()
{
    bool flag = false;
    vector<Operation*> cmds = base->getCmds();
    for(int k = 0; k < cmds.size(); ++k)
    {
        if(canBeUse(cmds[k]))
        {
            vector<Unit*> units = base->getGame()->getUnits();
            for (int i = 0; i < units.size(); ++i)
            {
                if(dis2(units[i]->getPos(),cmds[k]->targets[0]) == 0)
                {
                    Unit* ptr = units[i];
                    ptr->getPlayerInfo()->goldInc(-goldToBuyLevel(cmds[k]));
                    units[i]->addBuff(new LevelUpByBase(units[i]));
                    ptr->findArg("Exp")->add(2,1);
                    int lvl=ptr->findArg("Exp")->getVal(2),ahp,aatk,adef;
                    getAdd(ahp,aatk,adef,ptr->getName());
                    ptr->findArg("Exp")->add(3,1);
                    ptr->findArg("Exp")->add(1,HERO_ARGS::EXP_FOR_LEVELUP(lvl));
                    ptr->findArg("Exp")->change(4,HERO_ARGS::CURRENT_LEVEL_EXP(lvl));
                    ptr->findArg("Hp")->add (0,ahp);
                    ptr->findArg("Hp")->add (1,ahp);
                    ptr->findArg("Hp")->change (2, ptr->findArg("Hp")->getVal(1) / 100);
                    ptr->findArg("Atk")->add(1,aatk);
                    ptr->findArg("Def")->add(1,adef);
                    if(ptr->getName()=="Hammerguard")
                    {
                        ptr->findSkill("HammerAttack")->levelUp();
                    }
                    else if(ptr->getName()=="Master")
                    {
                        ptr->findSkill("Cure")->levelUp();
                    }
                    else if(ptr->getName()=="Scouter")
                    {
                        ptr->findSkill("SetObserver")->levelUp();
                        ptr->findSkill("Plunder")->levelUp();
                    }
					else if(ptr->getName() == "Berserker")
					{
						ptr->findArg("Range")->add(1,BERSERKER_RANGE_DELTA);
					}
                    break;
                }
            }
            flag = true;
        }
    }
    return flag;
}

HammerAttack::HammerAttack(Unit* myUnit):
Skill("HammerAttack",genDes("No description, Range=%d, MP=%d", HAMMERATTACK_RANGE, HAMMERATTACK_MP),
    myUnit,0,5,HAMMERATTACK_MAXCD,1),
mp(HAMMERATTACK_MP),dmg(HAMMERATTACK_DAMAGE[0]),range(HAMMERATTACK_RANGE)
{
}

bool HammerAttack::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=HAMMERATTACK_DAMAGE[level];
        return true;
    }
    return false;
}

bool HammerAttack::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(!unit->getGame()->getMap()->checkPos(unit->getCmd()->targets[0]) || unit->getCmd()->targets[0] == unit->getPos())
        return false;
    if(unit->getGame()->getRoundProcess()==1)
    {
        Unit* target = unit->getGame()->findUnitByPos(unit->getCmd()->targets[0]);
        if(!target) return false;
        else
        {
            return unit->findArg("Mp")->getVal()>=mp&&cd==0
            &&dis2(unit->getCmd()->targets[0],unit->getPos())<=range
            &&target->getCamp()!=unit->getCamp()
			&&target->getName()!="MilitaryBase";
        }
    }
    return unit->getGame()->getRoundProcess()==2&&lastUse==unit->getGame()->getRound();
}
bool HammerAttack::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(ptr->getPos()==unit->getCmd()->targets[0])
                {
                    ptr->addBuff(new Dizzy(ptr,HAMMERATTACK_DIZZY));
                    ptr->addBuff(new BeAttacked(ptr, HURT_LAST_TIME));
                    ptr->findArg("Hp")->add(0,-dmg);
                    ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                }
            }
        }
        return true;
    }
    return false;
}

string HammerAttack::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}


EarthShake::EarthShake(Unit* myUnit):
Skill("EarthShake",genDes("No description, Range=%d, MP=%d", EARTHSHAKE_RANGE, EARTHSHAKE_MP),
myUnit,0,5,EARTHSHAKE_MAXCD),
mp(EARTHSHAKE_MP),dmg(EARTHSHAKE_DAMAGE[0]),range(EARTHSHAKE_RANGE)
{
}

bool EarthShake::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=EARTHSHAKE_DAMAGE[level];
        return true;
    }
    return false;
}

bool EarthShake::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==1
    &&unit->findArg("Mp")->getVal()>=mp&&cd==0;
}

bool EarthShake::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Mp")->add(0,-mp);
        cd=maxCd;
        unit->addBuff(new Singing(unit, name,  EARTHSHAKE_SING_TIME, EarthShake::execute, unit));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}

void EarthShake::execute(Unit* unit)
{
    for(int i=0;i<unit->getGame()->getUnits().size();++i)
    {
      Unit* ptr=unit->getGame()->getUnits()[i];
      if(dis2(ptr->getPos(),unit->getPos())<=((EarthShake*)unit->findSkill("EarthShake"))->range
       &&ptr->getCamp()!=unit->getCamp())
      {
//                     int init_dmg = ((EarthShake*)unit->findSkill("EarthShake"))->dmg;
//                     ptr->findArg("Hp")->add(0,-init_dmg);
         int cur_level = unit->findArg("Exp")->getVal(2);
         ptr->findArg("Hp")->add(0,-EARTHSHAKE_DAMAGE[cur_level]);
         ptr->addBuff(new Slow(ptr, 0));
         ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
         ptr->addBuff(new BeAttacked(ptr, HURT_LAST_TIME));
     }
 }
}

string EarthShake::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
EarthShake::~EarthShake()
{}

Sacrifice::Sacrifice(Unit* myUnit):
Skill("Sacrifice",genDes("No description, Range=%d, MP=%d", SACRIFICE_RANGE, SACRIFICE_MP),
    myUnit,0,5,SACRIFICE_MAXCD)
{}

bool Sacrifice::canBeUse()
{
    if(level < 0)
        return false;
    if(name != unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==1 && !unit->findBuff("WinOrDie") && cd == 0;
}

bool Sacrifice::trigger()
{
    if(canBeUse())
    {
        lastUse = unit->getGame()->getRound();
        cd = maxCd;
        int hpDecrease = unit->findArg("Hp")->getVal(0)-1;
        int cur_atk = unit->findArg("Atk")->getVal(0);
        unit->addBuff(new WinOrDie(unit, WINORDIE_TIME, hpDecrease, hpDecrease));
        return true;
    }
    return false;
}

Sacrifice::~Sacrifice()
{}

/*
Revenge::Revenge(Unit* myUnit):
Skill("Revenge",genDes("No description, Range=%d, MP=%d", REVENGE_RANGE, REVENGE_MP),
    myUnit,0,5,REVENGE_MAXCD),
mp(REVENGE_MP)
{}

bool Revenge::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==1
    &&unit->findArg("Mp")->getVal()>=mp&&cd==0;
}

bool Revenge::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess() == 1){
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        Unit* ptr=NULL;
        UnitArg* atr=unit->findArg("LastHit");
        int tmp=-1;
        for(int i=0;i<atr->valSize();++i)
            if(atr->getVal(i)>tmp)
                tmp=atr->getVal(i),ptr=unit->getGame()->findUnitById(i);
            if (ptr!=NULL)
            {
              int Hp_lose = unit->findArg("Hp")->getVal(3) - unit->findArg("Hp")->getVal(0);
              this->dmg = Hp_lose * REVENGE_RATE;
              ptr->findArg("Hp")->add(0,-dmg);
              ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
          }
          return true;
      }
      return false;
  }




  string Revenge::toString()
  {
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
Revenge::~Revenge()
{}*/


SuperDead::SuperDead(Unit* myUnit):
Skill("SuperDead","No description",myUnit,0,0,SUPERDEAD_MAXCD)
{}

bool SuperDead::canBeUse()
{
    return unit->getGame()->getRoundProcess() == 3 && unit->findArg("Hp")->getVal(0) <= 0 && unit->findBuff("Reviving") == NULL && cd == 0 && unit->findBuff("WaitRevive") == NULL;
}

bool SuperDead::trigger()
{
	if(canBeUse())
	{
        cd=maxCd;
        for (int i = 0; i < sizeof(DIZZY_TIME) / sizeof (int); ++i)
            if (DIZZY_TIME[i] == SUPERDEAD_ROUND_TIMES)
                unit->addBuff(new Dizzy(unit, i)); //dizzy 6 rounds
        unit->addBuff(new WaitRevive(unit, SUPERDEAD_ROUND_TIMES));
        return true;
    }
    return false;
}
SuperDead::~SuperDead()
{}

/*
Sting::Sting(Unit* myUnit):
Skill("Sting","No description",myUnit,0,5,0,0),
dmg(STING_DAMAGE[0]), mp(0), canbeuse(true)
{}

bool Sting::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=STING_DAMAGE[level];
        return true;
    }
    return false;
}

bool Sting::canBeUse()
{
    if(unit->getGame()->getRoundProcess() == 2)
    {
        canbeuse = true;
    }
    if(unit->getGame()->getRoundProcess() == 3 && canbeuse)
    {
        return true;
    }
}

bool Sting::trigger()
{
    if(canBeUse())
    {
        for(int i=0;i<unit->getGame()->getUnits().size();++i)
        {
            Unit* ptr=unit->getGame()->getUnits()[i];
            if(ptr->getCamp()!=unit->getCamp()&&unit->getGame()->getRound() == unit->findArg("LastHit")->getVal(ptr->getId()))
            {
                ptr->findArg("Hp")->add(0,-dmg);
			//ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
            }
        }
        canbeuse = false;
        return true;
    }
    return false;
}

string Sting::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}

Sting::~Sting()
{

}*/


SetObserver::SetObserver(Unit *myUnit):
Skill("SetObserver",genDes("No description, Range=%d, MP=%d", SET_OBSERVER_RANGE, SET_OBSERVER_MP),
    myUnit,0,5,SET_OBSERVER_MAXCD[0]),
mp(SET_OBSERVER_MP)
{
}

bool SetObserver::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if (unit->getGame()->getRoundProcess() != 1)
        return false;
    if(!unit->getGame()->getMap()->checkPos(unit->getCmd()->targets[0]) || dis2(unit->getPos(),unit->getCmd()->targets[0]) > SET_OBSERVER_RANGE)
        return false;
    vector<Unit*> units = unit->getGame()->getUnits();
    for(int i = 0; i < units.size(); ++i)
    {
        if(dis2(units[i]->getPos(),unit->getCmd()->targets[0]) == 0)
            return false;
    }
    return unit->findArg("Mp")->getVal()>=mp&&cd==0
		&& unit->getGame()->getMap()->getHeight(unit->getCmd()->targets[0]) -  unit->getGame()->getMap()->getHeight(unit->getPos()) < 2;
}

bool SetObserver::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess() == 1){
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        unit->getGame()->addUnit(new Observer(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,unit->getCmd()->targets[0]));
        return true;
    }
    return false;
}

string SetObserver::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}

bool SetObserver::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        maxCd=SET_OBSERVER_MAXCD[level];
		return true;
	}
	return false;
}

//以下为Master的技能:Blink,Cure
Blink::Blink(Unit* myUnit):
Skill("Blink",genDes("Twinkle, Range=%d, MP=%d", BLINK_RANGE, BLINK_MP),
    myUnit,0,0,BLINK_MAXCD,1),
mp(BLINK_MP),range(BLINK_RANGE)
{
}

bool Blink::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type) return false;
    if(unit->getCmd()->targets.size()!=1) return false;
	if(!unit->getGame()->getMap()->checkPos(unit->getCmd()->targets[0])) return false;
	if(unit->getGame()->getMap()->getHeight(unit->getCmd()->targets[0]) >= 50) return false;
    return unit->getGame()->getRoundProcess()==1
    &&unit->findArg("Mp")->getVal()>=mp&&cd==0
    &&dis2(unit->getCmd()->targets[0],unit->getPos())<=range;
}
bool Blink::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Mp")->add(0,-mp);
        cd=maxCd;
        unit->changePos(unit->getCmd()->targets[0]);
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}

string Blink::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}


Cure::Cure(Unit* myUnit):
Skill("Cure",genDes("Be healed near the hero, Range=%d",CURE_RANGE),myUnit,0,5,0),
healthy_hp_cure_rate(HEALTHY_HP_CURE_RATE[0]), sick_hp_cure_rate(SICK_HP_CURE_RATE[0]), range(CURE_RANGE)
{
}
bool Cure::canBeUse()
{
    if (unit->findBuff("Reviving") != NULL)
        return false;
    return unit->getGame()->getRoundProcess()==1;
}

bool Cure::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        healthy_hp_cure_rate = HEALTHY_HP_CURE_RATE[level];
        sick_hp_cure_rate = SICK_HP_CURE_RATE[level];
        return true;
    }
    return false;
}
bool Cure::trigger()
{
    if (canBeUse())
    {
        for(int i=0; i<unit->getGame()->getUnits().size(); ++i)
        {
                Unit* ptr = unit->getGame()->getUnits()[i];
                if(dis2(ptr->getPos(),unit->getPos()) <= range
                        && ptr->getCamp() == unit->getCamp()
                        && (ptr->getName() == "Hammerguard" || ptr->getName() == "Master"
                        || ptr->getName() == "Berserker" || ptr->getName() == "Scouter"))
                {
                    UnitArg* arg=ptr->findArg("Hp");
                    if(arg==NULL) continue;
                    int ahp = 0;
                    if(unit->findBuff("BeAttacked"))
                    {
                        ahp = arg->getVal(1) * sick_hp_cure_rate;
                    }
                    else
                    {
                        ahp = arg->getVal(1) * healthy_hp_cure_rate;
                    }
                    if(ahp < 1) ahp = 1;
                    arg->add(0, ahp);
                }
        }
        return true;
    }
    return false;
}

Plunder::Plunder(Unit* myUnit,int MaxCd):
Skill("Plunder","No description",myUnit,0,5,MaxCd,1)
{
	goldFromBase = PLUNDER_GOLD_BASE[0];
	goldFromHero = PLUNDER_GOLD_HERO[0];
}

bool Plunder::canBeUse()
{
    if(unit->getCmd()->type!="Attack")
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(unit->getCmd()->targets[0] == unit->getPos())
        return false;
    int range=unit->findArg("Range")->getVal();
    if(unit->getGame()->getRoundProcess()==1)
        return cd==0&&dis2(unit->getCmd()->targets[0],unit->getPos())<=range;
    return unit->getGame()->getRoundProcess()==2
    &&lastUse==unit->getGame()->getRound();
}

bool Plunder::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(ptr->getPos()==unit->getCmd()->targets[0]
				&& ptr->getCamp() < 2 && ptr->getCamp() != unit->getCamp())
                {
					int delta_money = 0;
					if(ptr->getName() == "MilitaryBase") delta_money = goldFromBase;
					else if(ptr->getName() == "Hammerguard" || ptr->getName() == "Master"
						||  ptr->getName() == "Berserker" || ptr->getName() == "Scouter")
						delta_money = goldFromHero;
					if(ptr->getPlayerInfo()->getGold() < delta_money) delta_money = ptr->getPlayerInfo()->getGold();
					ptr->getPlayerInfo()->goldInc(-delta_money);
					unit->getPlayerInfo()->goldInc(delta_money);
					break;
                }
            }
        }
		return true;
	}
	return false;
}

bool Plunder::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
		goldFromBase = PLUNDER_GOLD_BASE[level];
		goldFromHero = PLUNDER_GOLD_HERO[level];
        return true;
    }
    return false;
}

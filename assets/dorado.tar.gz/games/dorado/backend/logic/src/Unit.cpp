//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#define sqr(x) ((x)*(x))
Unit::Unit(Game* gm,const char* Name,int Camp,int Player,int ID,int Volume,Pos Ps):
    game(gm),name(Name),camp(Camp),
    player(Player),id(ID),
    volume(Volume),pos(Ps),
    lastPos(Ps),cmd(new Operation())
{
    if(id==-1)
        id=game->getNewId(name);
    else game->addId(id,name);
    buffs.clear();
    skills.clear();
    args.clear();
}
void Unit::init()//添加技能、设定属性值等，不能放在构造函数中
{
    name="Unit";
}
UnitArg* Unit::findArg(const string& Name)//找到某个参数
{
    for(int i=0;i<args.size();++i)
        if (args[i]->getName()==Name)
            return args[i];
    return NULL;
}
Buff* Unit::findBuff(const string &Name)//找到某个buff
{
    for(int i=0;i<buffs.size();++i)
    {
        if(buffs[i]->getName()==Name)
            return buffs[i];
    }
    return NULL;
}
Skill* Unit::findSkill(const string& Name)//找到某个buff
{
    for(int i=0;i<skills.size();++i)
        if(skills[i]->getName()==Name)
            return skills[i];
    return NULL;
}
void Unit::addSkill(Skill* newSkill)//添加技能
{
    skills.push_back(newSkill);
}
void Unit::addBuff(Buff* newBuff)//添加Buff
{
    Buff* buff=findBuff(newBuff->getName());
    if(buff==NULL)
    {
        buffs.push_back(newBuff);
        newBuff->work();
    }
    else
        buff->overlap(newBuff);
}
void Unit::addArg(UnitArg* arg)//添加参数
{
    args.push_back(arg);
}
void Unit::oneRoundPass()
{
    for(int i=0;i<args.size();++i)
        args[i]->oneRoundPass();
    for(int i=0;i<buffs.size();++i)
        buffs[i]->oneRoundPass();
    for(int i=0;i<skills.size();++i)
        skills[i]->oneRoundPass();
}
void Unit::roundStart()
{
    UnitArg* goldPtr;
    //金矿的金钱不同步
    if (camp != 2 && (goldPtr = findArg("Gold")) && getPlayerInfo())
        goldPtr->change(Gold::Total, getPlayerInfo()->getGold());

    if(cmd!=NULL)
    {
        delete cmd;
        cmd=NULL;
    }
    cmd=new Operation();
    for(int i=0;i<args.size();++i)
        args[i]->roundStart();
    for(int i=0;i<buffs.size();++i)
        buffs[i]->roundStart();
    col=0;
    step=0;
    lastPos=pos;
}
int Unit::getStatus()//0:生 1:死
{
    return !remove();
}
bool Unit::useSkill()
{
    bool ret=false;
    for(int i=0;i<skills.size();++i)
    {
        if(skills[i]->trigger())
            ret=true;
    }
    return ret;
}
void Unit::output(ostream &os)//输出replay信息
{
    os<<"{";
    os<<"type:Unit;";
    os<<"id:"<<id<<";";
    os<<"camp:"<<camp<<";";
    os<<"player:"<<player<<";";
    os<<"name:"<<name<<";";
    os<<"lastPos:{"<<lastPos.x<<";"<<lastPos.y<<"};";
    os<<"pos:{"<<pos.x<<";"<<pos.y<<"};";
    os<<"args:{";
    {
        for(int i=0;i<args.size();++i)
        {
            if(i>0)
                os<<';';
            args[i]->output(os, i);
            //if(i<args.size()-1)
              //  os<<";";
        }
    }
    os<<"};";
    os<<"skills:{";
    {
        for(int i=0;i<skills.size();++i)
        {
            skills[i]->output(os,i);
        }
    }

    os<<"};";
    os<<"buffs:{";
    {
        for(int i=0;i<buffs.size();++i)
        {
            buffs[i]->output(os);
            if(i<buffs.size()-1)
                os<<";";
        }
    }
    os<<"};";
    os<<"finalStatus:"<<getStatus()<<';';
    //============
    int k=-1;
    for(int i=0;i<skills.size();++i)
        if(skills[i]->getLastUse()==game->getRound())
            k=i;
    os<<"Action:";
    if(k!=-1)
    {
        os<<skills[k]->getName()<<";target:";
        if(cmd->targets.size()>0)
            os<<"{"<<cmd->targets[0].x<<";"<<cmd->targets[0].y<<"}";
        else
            os<<"{"<<-1<<";"<<-1<<"}";
    }
    else if(cmd->type=="Move")
    {
        os<<"Move;target:";
        os<<"{"<<pos.x<<";"<<pos.y<<"}";
    }
    else
    {
        os<<"Stop;target:";
        os<<"{"<<-1<<";"<<-1<<"}";
    }
    //==================
    os<<"}\n";
}
void Unit::checkArg()
{
    for(int i=0;i<args.size();++i)
        args[i]->check();
}
void Unit::setCmd(const Operation &Cmd)
{
//    cout<<"setCmd\n";
    if(cmd!=NULL)
        delete cmd;
    cmd=new Operation(Cmd);
//    cout<<"endset\n";
}
bool Unit::findCollision()
{
    col=false;
    if(game->getRoundProcess()==4)
    {
        if(cmd!=NULL && cmd->type=="Move")
        {
            if(step==cmd->targets.size() || pos!=cmd->targets[step] || step==0)
                return col=false;
        }
        else
            return col=false;
    }
    else if(pos==lastPos)
        return col=false;
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(ptr->id!=id)
            if(dis2(ptr->pos,pos)<sqr(ptr->volume+volume-1))
            {
                if(ptr->id>=id||ptr->camp!=camp||!ptr->findCollision())
                     return col=true;
            }
    }
    return col=(!game->getMap()->tryPosition(pos,volume));
}
void Unit::checkMoveCmd()
{
    if(cmd==NULL)return;
    if( cmd->type!="Move")
        return;
    double v;
	if(findArg("Speed") != NULL)
		v = sqrt(findArg("Speed")->getVal());
	else
		v = 0;
    if(cmd->targets.size()<1)
        return;
//    cout<<"in check "<<cmd->targets.size()<<' '<<id<<'\n';
    if(cmd->targets[0]!=pos)
    {
        cmd->targets.clear();
        cmd->targets.push_back(pos);
    }
    vector<double> dp;
    dp.clear();
    dp.push_back(0);
    for(int i=1;i<cmd->targets.size();++i){
//        cout<<i<<' '<<cmd->targets[i].x<<' '<<cmd->targets[i].y<<' '
//              <<game->getMap()->getHeight(cmd->targets[i])<<' '<<game->getMap()->getHeight(cmd->targets[i-1])<<'\n';
        if(dis2(cmd->targets[i],cmd->targets[i-1])!=1
                || !game->getMap()->tryPosition(cmd->targets[i],volume)
                || abs(game->getMap()->getHeight(cmd->targets[i])-game->getMap()->getHeight(cmd->targets[i-1]))>1)
        {
            cmd->targets.resize(i);
            break;
        }
        else{
            dp.push_back(v+1);
            for(int j=0;j<i;++j)
            {
                bool flag=true;
                for(int k=j+1;k<i&&flag;++k)
                    flag=checkOnLine(cmd->targets[i],cmd->targets[j],cmd->targets[k]);
                if( flag && dp[j]+dis(cmd->targets[i],cmd->targets[j])<dp[i] )
                    dp[i]=dp[j]+dis(cmd->targets[i],cmd->targets[j]);
            }
            if(dp[i]>v)
            {
                cmd->targets.resize(i);
                break;
            }
        }
    }
    //cout<<"out check"<<cmd->targets.size()<<'\n';
}
void Unit::roundTerminate()
{
    for(int i=0;i<buffs.size();++i)
        buffs[i]->terminate();
}
void Unit::stepBack()
{
    if(!col || cmd->type!="Move") return;
    if(step==cmd->targets.size() || pos!=cmd->targets[step] || step==0)
        return;
    pos=cmd->targets[step-1];
}
void Unit::makeOneStep()
{
	if(cmd==NULL)return;
    if(cmd->type!="Move")
        return;
    if(step<cmd->targets.size() && pos==cmd->targets[step])
        ++step;
    if(step<cmd->targets.size())
        pos=cmd->targets[step];
}
void Unit::dealCollision()
{
    if(!col)
        return;
    Pos ret;
    int d=123456789;
    for(int x=pos.x-1;x<=pos.x+1;++x)
        for(int y=pos.y-1;y<=pos.y+1;++y)        
            if( abs(x-pos.x)+abs(y-pos.y)==1/*&&game->getMap()->tryPosition(Pos(x,y),volume)*/)
                if( dis2(Pos(x,y),lastPos)<=d)
                {
                    if (dis2(Pos(x,y),lastPos) < d || rand()%2)
                    {
                        ret=Pos(x,y);
                        d=dis2(ret,lastPos);
                    }
                }
    pos=ret;
    col=false;
}
Unit::~Unit()
{
    for(int i=0;i<args.size();++i)
        delete args[i];
    for(int i=0;i<buffs.size();++i)
        delete buffs[i];
    for(int i=0;i<skills.size();++i)
        delete skills[i];
    if(cmd!=NULL)
        delete cmd;
}

void Unit::clean()
{
    for(vector<Buff*>::iterator i=buffs.begin();i!=buffs.end();)
        if((*i)->remove())
        {
            delete (*i);
            buffs.erase(i);
        }
        else ++i;
}
string Unit::toString()
{
    string tmp = name + "=" + ToString(id) + "=" + ToString(player)
            + "=" + ToString(camp) + "=" + ToString(volume) + "=" + ToString(pos);
    int _size = args.size();
    tmp += '=';
    for (int i=0; i<_size; ++i)
    {
        tmp += args[i]->toString();
        if (i != _size-1)
            tmp += '$';
    }
    tmp += '$';
    _size = buffs.size();
    tmp += '=';
    for (int i=0; i<_size; ++i)
    {
        tmp += buffs[i]->toString();
        if (i != _size-1)
            tmp += '$';
    }
    tmp+= '$';
    _size = skills.size();
    tmp += '=';
    for (int i=0; i<_size; ++i)
    {
        tmp += skills[i]->toString();
        if (i != _size-1)
            tmp += '$';
    }
    tmp += '$';
    return tmp;
}

PlayerInfo* Unit::getPlayerInfo()
{
    for (int i = 0; i < getGame()->getPlayerInfos().size(); ++i)
        if (getGame()->getPlayerInfos()[i]->getCamp() == camp)
            return getGame()->getPlayerInfos()[i];
    return NULL;
}

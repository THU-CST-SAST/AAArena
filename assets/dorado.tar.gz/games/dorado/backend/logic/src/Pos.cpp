#ifndef _AI__
#include "include/sdk/sdk.h"
#else
#include "sdk.h"
#endif//_AI__

#include <math.h>
#include <vector>
int crossProduct(Pos A, Pos B, Pos C)//向量AB叉乘AC
{
    return (B.x - A.x) * (C.y - A.y) - (C.x - A.x) * (B.y - A.y);
}
int dotProduct (Pos A, Pos B, Pos C)//向量AB点乘AC
{
	return (C-A).x*(B-A).x + (B-A).y*(C-A).y;
}
bool cross(Pos A, Pos B, Pos C, Pos D)//判断线段AB与CD是否有公共点
{
    return (long long) crossProduct(A, B, C) * crossProduct(A, B, D) <= 0
		&& (long long) crossProduct(C, D, A) * crossProduct(C, D, B) <= 0;
}

bool checkOnLine(Pos A, Pos B, Pos C)//判断AB连线是否与C（方格）有交点
{
    if (A == B)
	return false;
    Pos a(A.x * 2, A.y * 2), b(B.x * 2, B.y * 2), c(C.x * 2, C.y * 2);
    return cross(a, b, Pos(c.x + 1, c.y + 1), Pos(c.x + 1, c.y - 1))
        || cross(a, b, Pos(c.x + 1, c.y + 1), Pos(c.x - 1, c.y + 1))
        || cross(a, b, Pos(c.x - 1, c.y - 1), Pos(c.x + 1, c.y - 1))
        || cross(a, b, Pos(c.x - 1, c.y - 1), Pos(c.x - 1, c.y + 1));
}

int dis2(Pos A, Pos B)//欧氏距离平方
{
    return (A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y);
}

double dis(Pos A, Pos B)//欧几里得距离
{
    return sqrt(dis2(A, B));
}
int length(const std::vector<Pos>& path)
{
    std::vector<int> dp;
    dp.resize(path.size(), 0);
    for (int i = 1; i < int(path.size()); ++i)
    {
        dp[i] = 1 << 30;
        for (int j = 0; j < i; ++j)
        {
            bool flag = true;
            for(int k = j + 1;k < i && flag; ++k)
                flag = checkOnLine(path[i],path[j],path[k]);
            if( flag && dp[j] + dis(path[i],path[j]) < dp[i] )
                dp[i] = dp[j] + dis(path[i], path[j]);
        }
    }
    return dp.back();
}

bool operator==(Pos A, Pos B)//相等
{
    return A.x == B.x && A.y == B.y;
}

bool operator!=(Pos A, Pos B)//不等
{
    return !(A == B);
}

Pos operator+(Pos A, Pos B)//加法
{
    return Pos(A.x + B.x, A.y + B.y);
}

Pos operator- (Pos A, Pos B)//减法
{
    return Pos(A.x - B.x, A.y - B.y);
}

Pos operator* (Pos A, int k)//数乘
{
    return Pos(A.x * k, A.y * k);
}

Pos operator* (int k, Pos A)//数乘
{
    return Pos(k * A.x, k * A.y);
}


#ifndef MILITARY_BASE_H
#define MILITARY_BASE_H
#include "Unit.h"
#include "../Buff/Buff.h"
#include "../Pos.h"
class MilitaryBase:public Unit
{
public:
	MilitaryBase(Game* Gm,int Camp,int Player,int ID,Pos Ps);
	virtual void addBuff(Buff* newBuff);
    virtual int getStatus();
    vector<Operation*> getCmds(){return cmds;}
    virtual void setCmd(const Operation& Cmd);
    virtual void roundStart();
protected:
	vector<Operation*> cmds;
};
#endif //MILITARY_BASE_H
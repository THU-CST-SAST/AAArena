#ifndef BASE_H
#define BASE_H
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <algorithm>
using namespace std;
#include "Pos.h"
#include "trans.h"
#endif//BASE_H

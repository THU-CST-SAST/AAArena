#ifndef FLIGHT_H
#define FLIGHT_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
struct PCommand;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
class Flight
{
public:
	virtual void oneRoundPass();//飞行一回合
	virtual void terminate();//飞行道具生命终止时发生事件，例如爆炸
	virtual bool remove();
	virtual void output(ostream &os);
	virtual void roundStart();
	virtual string toString();
	Flight(Game* Gm,const char* Name,int UnitID,int ID,int Camp,int Time,int Speed,Pos Start);
	virtual ~Flight(){}
public:
	Pos getPos(){return Pos((int)pos.x,(int)pos.y);}
	int getId(){return id;}
	virtual int getHit(){return timeLeft==0;}
protected:
	Game* game;
	string name;
	int unitId;//发出者id
	int id;//飞行道具唯一id
	int camp;
	int timeLeft;//剩余存活时间
	int speed;
	Pos pos;//当前坐标
	Pos lastPos;//回合初坐标
	Pos target;
};
#endif//FLIGHT_H

#ifndef OPERATION_H
#define OPERATION_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
//struct PCommand;
class Flight;
class Game;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
class Map;

/*const string Operation_name[] = {"Attack", "Charge", "ChargeLU", "Spin", "SpinLU", "Yell", "YellLU", "PiercingArrow", "PALU", "ArrowsRain", "ARLU", "PowerUp", "PULU",
"Hide", "HideLU", "FlyingBlade", "FBLU", "Blink", "BlinkLU", "YellowPoint", "ChooseFighter", "ChooseArcher", "ChooseAssassin", "Move", "Stop"};
const int Operation_name_size = 25;
*/
struct Operation
{
    int id;
    int typeId;//类型编号，与名称的对应关系详见Operation_name[]
	std::string type;
	vector<Pos> targets;
    Operation():
        id(-1),typeId(-1),type("Stop")
    {
        targets.clear();
    }
//    Operation(const Operation& X):
//        id(X.id),type(X.type)
//    {
//        targets.clear();
//        for(int i=0;i<X.targets.size();++i)
//            targets.push_back(X.targets[i]);
//    }
    Operation(const Operation& _);

};
#endif//OPERATION_H

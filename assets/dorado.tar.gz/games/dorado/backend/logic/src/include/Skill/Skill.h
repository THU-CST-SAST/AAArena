#ifndef SKILL_H
#define SKILL_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
struct PCommand;
class Flight;
class Game;
struct Operation;
class PlayerInfo;
class Unit;
class UnitArg;
class Map;
class Skill
{
public:
        virtual bool canBeUse();//是否满足使用条件
        virtual bool trigger();//技能触发
        virtual void oneRoundPass();
        virtual bool levelUp();
        Skill(const char* Name,const char* Des,Unit* myUnit,int Level,int MaxLevel,int MaxCd,bool TargetNeeded=0);
        //virtual void output(ostream &os);
        virtual void output(ostream &os,int x);
        virtual string toString();
        virtual ~Skill(){}
    public:
      string getName(){return name;}
      int getLevel() {return level;}
      int getCd() {return cd;}
      int getLastUse(){return lastUse;}
  protected:
      string name;
      string des;
      Unit* unit;
      int cd,maxCd;
      int level,maxLevel;
      bool targetNeeded;
      int lastUse;
      int type;
  };

#endif//SKILL_H

#ifndef MINE_H
#define MINE_H
#include "../Base.h"
#include "Unit.h"
#include "../UnitArg/UnitArg.h"
class Mine:public Unit
{
	int maxGoldInc;
    int mineCamp;
	Unit* miner;
protected:
	virtual int goldInc(int inc);
	static int _availableCount;
    static int _randomed;
public:
	Mine(Game *gm, int Camp, int Player, int ID, int Volume, Pos Ps);
	virtual bool okToMining(int Camp);
	virtual bool empty() {return this->findArg("Gold")->getVal(Gold::Total) <= 0;}
	virtual void mining(int Camp, int goldInc, Unit*);
	virtual void roundStart();
	virtual void oneRoundPass();
	static int availableCount (int delta = 0) {return (_availableCount += delta);}
    static int randomCount(int x = 0) {return (_randomed += x);}
    int getMineCamp(){return mineCamp;}
    int getMaxGoldInc(){return maxGoldInc;}
};
#endif
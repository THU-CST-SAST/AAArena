#ifndef SKILLS_H
#define SKILLS_H

#include "Skill.h"
#include "../Unit/Mine.h"
#include "../Unit/Unit.h"
#include "../Unit/MilitaryBase.h"
#include "../PlayerInfo/PlayerInfo.h"

class Attack:public Skill
{
public:
    Attack(Unit* myUnit,int MaxCd);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~Attack(){}
};

class Recovery:public Skill
{
public:
    Recovery(Unit* myUnit);
	virtual bool canBeUse();
	virtual bool trigger();
    virtual ~Recovery(){}
protected:
	int ahp;
	int amp;
	int range;
};

class LevelUp:public Skill
{
public:
    LevelUp(Unit* myUnit,int Hp,int Atk,int Def);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~LevelUp(){}
protected:
    int ahp;
    int aatk;
    int adef;
};
class Dead:public Skill
{
public:
    Dead(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~Dead(){}
protected:
    Pos pos;
    int range;
    bool check(Pos tmp);
    void shareExp();
    void giveMoney();
};


//choose hero of ai9_2016

class ChooseHammerguard:public Skill
{
public:
	ChooseHammerguard(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
    int cost();
protected:
	MilitaryBase* base;
};

class ChooseMaster:public Skill
{
public:
	ChooseMaster(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
    int cost();
protected:
	MilitaryBase* base;
};

class ChooseBerserker:public Skill
{
public:
	ChooseBerserker(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
    int cost();
protected:
	MilitaryBase* base;
};

class ChooseScouter:public Skill
{
public:
	ChooseScouter(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
    int cost();
protected:
	MilitaryBase* base;
};

//These skills are for military_base of ai9_2016
class BuyBackHero:public Skill
{
public:
	BuyBackHero(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToBuyBack(Operation* cmd);
	MilitaryBase* base;
};

class CallBackHero:public Skill
{
public:
	CallBackHero(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToCallBack(Operation* cmd);
	MilitaryBase* base;
};

class BuyHeroLevel:public Skill
{
public:
	BuyHeroLevel(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToBuyLevel(Operation* cmd);
	MilitaryBase* base;
};

//mining is designed as a passive skill.
//It should be called every round
class Mining:public Skill
{
public:
    Mining(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    ~Mining() {}
private:
    Mine* mine;
};

// By 武伟轩
class HammerAttack : public Skill
{
public:
    HammerAttack(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~HammerAttack(){}
protected:
    int mp;
    int dmg;
    int range;
};

class EarthShake: public Skill
{
public:
    EarthShake(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~EarthShake();
    static void execute(Unit*);//没有吟唱的使用效果
protected:
    int mp;
    int dmg;
    int range;
};

class DragonAttack:public Skill
{
public:
    DragonAttack(Unit* myUnit,int MaxCd);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~DragonAttack(){}
};

class Sacrifice:public Skill
{
public:
    Sacrifice(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~Sacrifice();
protected:
};

class Revenge:public Skill
{
public:
    Revenge(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Revenge();
protected:
    int mp;
    int dmg;
};

class SuperDead:public Skill
{
public:
    SuperDead(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~SuperDead();
};

class Sting:public Skill
//被动技能
{
public:
    Sting(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Sting();
protected:
    int mp;
    int dmg;
    bool canbeuse;
};

//放眼
class SetObserver:public Skill
{
public:
    SetObserver(Unit* myUnit);
	virtual bool canBeUse();
	virtual bool trigger();
    virtual string toString();
    virtual bool levelUp();
protected:
    int mp;
};

class Plunder:public Skill
{
public:
    Plunder(Unit* myUnit,int MaxCd);
	virtual bool canBeUse();
	virtual bool trigger();
    virtual bool levelUp();
protected:
    int goldFromHero;
	int goldFromBase;
};

class Blink : public Skill
{
public:
    Blink(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Blink(){}
protected:
    int mp;
    int range;
};

class Cure:public Skill
{
public:
    Cure(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~Cure(){}
protected:
    double healthy_hp_cure_rate;
    double sick_hp_cure_rate;
    int range;
};

/*
class ChooseProfessor:public Skill
{
public:
    ChooseProfessor(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseProfessor(){}
protected:
    Pos pos;
};
class FinalExam : public Skill
{
public:
    FinalExam(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~FinalExam(){}
protected:
    int mp;
    int range;
};

class ChooseNameless:public Skill
{
public:
    ChooseNameless(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseNameless(){}
protected:
    Pos pos;
};
class Freeze : public Skill
{
public:
    Freeze(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Freeze(){}
protected:
    int mp;
    int range;
};

class ChooseAnonymous:public Skill
{
public:
    ChooseAnonymous(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseAnonymous(){}
protected:
    Pos pos;
};
class Whateveritis : public Skill
{
public:
    Whateveritis(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Whateveritis(){}
protected:
    int mp;
    int range;
};

class ChooseReaper:public Skill
{
public:
    ChooseReaper(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseReaper(){}
protected:
    Pos pos;
};
*/

#endif//SKILLS_H

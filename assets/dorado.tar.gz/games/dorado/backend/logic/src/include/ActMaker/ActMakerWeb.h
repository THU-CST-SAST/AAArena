#ifndef ACTMAKER_WEB_H
#define ACTMAKER_WEB_H
#include "ActMaker.h"
#include "logic.hh"
class ActMakerWeb:public ActMaker
{
public:
    ActMakerWeb(int ConnID=-1):
        conn_id(ConnID)
    {
        rst.status = RoundResultMeta::Status::NORMAL;
    }
    virtual bool getCmd(const PlayerInfo *info, PCommand *cmd);
    void outStatus(std::ostream &os);
    virtual ~ActMakerWeb(){}
protected:
    int conn_id;
    RoundResultMeta rst;
};
#endif//ACTMAKER_WEB_H

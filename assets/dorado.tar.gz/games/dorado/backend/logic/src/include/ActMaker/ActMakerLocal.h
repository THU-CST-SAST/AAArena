#ifndef ACTMAKER_LOCAL_H
#define ACTMAKER_LOCAL_H
#include "ActMaker.h"
#ifdef _AC_WIN_
#include <windows.h>
#else
#include <dlfcn.h>
#endif

class ActMakerLocal: public ActMaker
{
public:
    virtual bool getCmd(const PlayerInfo *info, PCommand *cmd);
    bool load(const char* file_name);
    ActMakerLocal():dll(0), player_ai(0) {}
    void setMap(PMap *pmap);
    virtual void outStatus(std::ostream &os){}
    virtual ~ActMakerLocal();
protected:
#ifdef _AC_WIN_
    HMODULE dll;
#else
    void* dll;
#endif
    ai_func player_ai;
    PMap* map;
};
#endif//ACTMAKER_LOCAL_H

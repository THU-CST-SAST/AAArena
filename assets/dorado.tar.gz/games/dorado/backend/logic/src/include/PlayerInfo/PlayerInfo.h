#ifndef PLAYERINFO_H
#define PLAYERINFO_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
struct PCommand;
class Flight;
class Game;
struct Operation;
class Skill;
class Unit;
class UnitArg;
class Map;
class PlayerInfo
{
public:
    void roundInit(int Round);
    PlayerInfo(Game* Gm,int Camp);
    virtual void addUnit(Unit* unit);
    virtual bool goldInc(int inc);
	virtual int countProperty();
    virtual void addFlight(Flight* flight);
    virtual void addArea(Area* area);
    virtual string toString()const;
    virtual void output(ostream&);
    virtual ~PlayerInfo(){}
public:
    void setPlayer(int Player){player=Player;}
    int getCamp() const {return camp;}
    int getGold() const {return gold;}
    int getLastGold() const {return lastGold;}
	int getProperty() const {return property;}
    int getRound() const {return round;}
protected:
  Game* game;
  int round;	
  int camp;
  int player;
  int gold;
  int lastGold;
  int property;
  vector<Unit*> units;
  vector<Flight*> flights;
  vector<Area*> areas;
};
#endif//PLAYERINFO_H

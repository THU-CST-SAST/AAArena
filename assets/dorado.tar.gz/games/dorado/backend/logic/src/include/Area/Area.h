#ifndef AREA_H
#define AREA_H
#include "../Base.h"
class ActMaker;
//class Buff;
struct PCommand;
class Flight;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
class Area
{
	public:
		virtual void roundStart();
        virtual void oneRoundPass();
        virtual void terminate();
        virtual bool remove();
        virtual void work(Unit* unit);
        virtual bool inArea(Pos Pos);
        virtual void output(ostream &os);

        virtual string toString();
		Area(const char* Name,Game* Gm,int Camp,int TimeLeft,int ID,Pos Center,double Radius);
        virtual ~Area(){}
    public:
        int getId(){return id;}
    protected:
		string name;
        Game* game;//所属游戏
		int camp;//区域所属阵营,-1为中立
		int unitId;//创造该区域的单位，用于计算伤血类区域特效造成死亡时的经验结算
		int timeLeft;//剩余存在时间
		int id;
		//Area* clone;//表示回合开始时的状态
		Pos center;
		double radius;
};

#endif//AREA_H

#ifndef OBSERVER_H
#define OBSERVER_H

#include "Unit.h"
#include "../Buff/Buff.h"
#include "../Pos.h"
#include "../Game/Game.h"

class Observer:public Unit
{
public:
	Observer(Game* Gm,int camp,int Player,int ID,Pos Ps);
	virtual void oneRoundPass();
    virtual void setCmd(const Operation& Cmd);
    virtual bool remove();
	virtual void addBuff(Buff* newBuff);
    virtual int getStatus();
};

#endif //OBSERVER_H
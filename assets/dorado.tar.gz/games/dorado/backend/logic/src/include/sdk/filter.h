#ifndef _FILTER_H
#define _FILTER_H
#include<vector>
#include<iostream>
#include<string>
class Geometry;
struct PUnit;
struct PSkill;
/*************************************************************
 * ¹ýÂËÆ÷£¨ÒÔÒ»¶¨µÄ±ê×¼½øÐÐ¹ýÂË£©
 * Äã½«¶Ô¹ýÂËÆ÷ÉèÖÃÒ»Ð©Ìõ¼þ£¬È»ºó¹ýÂËÆ÷¿ÉÒÔ¶Ô¼¼ÄÜ£¬µ¥Î»µÈ½øÐÐÅÐ¶Ï£¬ÊÇ·ñ·ûºÏÄãËùÉè¶¨µÄÌõ¼þ
 * ÕâÀïÊÇ¹ýÂËÆ÷µÄ»ùÀàµÄÉùÃ÷£¬Äã²»ÐèÒªÊµÀý»¯Õâ¸öÀà
 * ÕæÕýÓÃµ½µÄÊÇÏÂÃæµÄSkillFilterºÍUnitFilter
 * Çë×¢ÒâËùÓÐµÄÇø¼ä¶¼ÊÇ×ó±ÕÓÒ¿ªµÄ¡£
 **************************************************************/
struct Filter {
protected:
    std::vector<std::string> types;                               //ÔÊÐíµÄÄÚÈÝ
    std::vector<std::string> avoids;                              //²»ÔÊÐíµÄÄÚÈÝ
    //enum {LEVEL = 0, HP, MP, MAX_HP, MAX_MP, CD} LIMIT;
    std::vector<std::pair<int, int> > limits;                     //ÏÞÖÆÇø¼ä
    int limitSize;                                                    //ÏÞÖÆÇø¼ä¸öÊý£¨¼´limits´óÐ¡£©
    static const int MAX_LIMIT_SIZE = 1024;                           //×î¶àµÄÏÞÖÆÇø¼ä¸öÊý
    //std::map<std::string, int> name2rank;                           //½«ÏÞÖÆµÄÀàÐÍ×ª»»ÎªÖÈ
    //level, hp, mp, maxHp, maxMp, area, cd...
protected:
    void setLimitSize(int _limitSize = 0);                            //ÉèÖÃÏÞÖÆÇø¼äµÄ¸öÊý
    void appendLimitFilter(int lo = -1, int hi = 1 << 30);            //Ôö¼ÓÒ»¸öÏÞÖÆÇø¼ä
    void setLimitFilter(int rank, int lo, int hi);                    //ÉèÖÃÏÞÖÆÇø¼ä£¬rankÎªÖÈ£¨ÏÂ±ê£©£¬Çø¼äÎª[lo, hi)£¨×¢Òâ¿ª±Õ£©
    void cleanLimitFilter(int rank);                                  //Çå¿ÕÏÞÖÆÇø¼ä£¬rankÎªÖÈ£¨ÏÂ±ê£©
public:
    Filter(int _limitSize = 0);                                       //Ö¸¶¨ÏÞÖÆÇø¼ä¸öÊý
    virtual ~Filter();
    void setTypeFilter(const char* type, const char* method = "a");   //ÉèÖÃÔÊÐíµÄÄÚÈÝ£¬method£º"w"ÖØÐ´£¬"a"Ìí¼Ó£¬ÏÂÍ¬
    void cleanTypeFilter();                                           //Çå¿ÕÔÊÐíµÄÄÚÈÝ
    void setAvoidFilter(const char* avoid, const char* method = "a"); //ÉèÖÃ²»ÔÊÐíµÄÄÚÈÝ
    void cleanAvoidFilter();                                          //Çå¿Õ²»ÔÊÐíµÄÄÚÈÝ

    virtual void cleanAll();                                                    //È«²¿Çå¿Õ

    virtual void output (std::ostream&) const;
};

/*
 * ¼¼ÄÜ¹ýÂËÆ÷
 */
struct SkillFilter : public Filter
{
private:
    enum {LEVEL = 0, MP, CD, MAX_CD} SKILL_LIMIT;                       //¹ýÂË±ê×¼£ºlevel, mp, cd, maxCd
    static const int SKILL_LIMIT_SIZE = 4;                              //¹ýÂË±ê×¼ÊýÁ¿

public:
    SkillFilter();                                                      //³õÊ¼»¯
    void setLevelFilter(int lo, int hi);                                //ÉèÖÃlevelÇø¼ä
    void cleanLevelFilter();                                            //Çå¿ÕlevelÇø¼ä
    void setMpFilter(int lo, int hi);                                   //ÉèÖÃmpÇø¼ä
    void cleanMpFilter();                                               //Çå¿ÕmpÇø¼ä
    void setCdFilter(int lo, int hi);                                   //ÉèÖÃcdÇø¼ä
    void cleanCdFilter();                                               //Çå¿ÕcdÇø¼ä
    void setMaxCdFilter(int lo, int hi);                                //ÉèÖÃmaxCdÇø¼ä
    void cleanMaxCdFilter();                                            //Çå¿ÕmaxCdÇø¼ä
    bool valid(const PSkill* skill) const;                              //ÑéÖ¤¼¼ÄÜÊÇ·ñ·ûºÏ±ê×¼
    void output (std::ostream&) const;
    void cleanAll();
};
std::ostream& operator<< (std::ostream&, const SkillFilter&);
/*
 * µ¥Î»¹ýÂËÆ÷
 */
struct UnitFilter : public Filter {
private:
    enum {LEVEL = 0, HP, MP, MAX_HP, MAX_MP} UNIT_LIMIT;                //¹ýÂË±ê×¼£ºlevel, hp, mp, m
    static const int UNIT_LIMIT_SIZE = 5;                               //¹ýÂË±ê×¼ÊýÁ¿
    std::vector<int> allowedCamps;
    std::vector<Geometry*> areas;                                            //ÓÐÐ§µÄÇøÓò
public:
    UnitFilter();                                                       //³õÊ¼»¯
    void setLevelFilter(int lo, int hi);                                //ÉèÖÃlevelÇø¼ä
    void cleanLevelFilter();                                            //Çå¿ÕlevelÇø¼ä
    void setHpFilter(int lo, int hi);                                   //ÉèÖÃhpÇø¼ä
    void cleanHpFilter();                                               //Çå¿ÕhpÇø¼ä
    void setMpFilter(int lo, int hi);                                   //ÉèÖÃmpÇø¼ä
    void cleanMpFilter();                                               //Çå¿ÕmpÇø¼ä
    void setMaxHpFilter(int lo, int hi);                                //ÉèÖÃmaxHpÇø¼ä
    void cleanMaxHpFilter();                                            //Çå¿ÕmaxHpÇø¼ä
    void setMaxMpFilter(int lo, int hi);                                //ÉèÖÃmaxMpÇø¼ä
    void cleanMaxMpFilter();                                            //Çå¿ÕmaxMpÇø¼ä
    void setCampFilter (int camp);
    void cleanCampFilter ();
    void setAreaFilter(Geometry* const area, const char* method = "a"); //ÉèÖÃÓÐÐ§ÇøÓò
    //area»áÔÚclean»òÕßfilterÎö¹¹Ê±×Ô¶¯delete.¿ÉÒÔ²»ÐèÒªÊÖ¶¯delete
    void cleanAreaFilter();                                             //Çå¿ÕÓÐÐ§ÇøÓò
    bool valid(const PUnit* unit) const;                         //ÑéÖ¤¼¼ÄÜÊÇ·ñ·ûºÏ±ê×¼
    void output (std::ostream&) const;
    void cleanAll();
};
std::ostream& operator<< (std::ostream&, const UnitFilter&);
#endif//_FILTER_H

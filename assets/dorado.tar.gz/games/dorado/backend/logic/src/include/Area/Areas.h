#ifndef AREAS_H
#define AREAS_H
#include "Area.h"
class Unit;

/*
class RainyPlace:public Area
{
public:
    RainyPlace(Game* Gm,int Camp,int UnitId,int ID,Pos Center,int Level);
    virtual void work(Unit* unit);
    virtual ~RainyPlace(){}
protected:
    int level;
    int unitId;
};
class LifeSpring:public Area
{
public:
    LifeSpring(Game* Gm,int Camp,int ID,Pos Center);
    virtual void work(Unit* unit);
    virtual ~LifeSpring(){}
};


class IcyPlace:public Area
{
public:
    IcyPlace(Game* Gm,int Camp,int UnitId,int ID,Pos Center,int Level);
    virtual void work(Unit* unit);
    virtual ~IcyPlace(){}
protected:
    int level;
    int unitId;
};
*/
#endif//AREAS_H

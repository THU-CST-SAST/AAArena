#ifndef SOCKET_TRANS_H
#define SOCKET_TRANS_H
#include "socket.hh"
#include "sdk/sdk.h"
SocketBase &operator << (SocketBase& s, const Pos& pos);
SocketBase &operator >> (SocketBase& s, Pos& pos);

SocketBase &operator << (SocketBase& s, const PMap& map);
SocketBase &operator >> (SocketBase& s, PMap& map);

SocketBase &operator << (SocketBase& s, const PCommand& cmd);
SocketBase &operator >> (SocketBase& s, PCommand& cmd);

SocketBase &operator << (SocketBase& s, const Operation& op);
SocketBase &operator >> (SocketBase& s, Operation& op);
#endif//SOCKET_TRANS_H

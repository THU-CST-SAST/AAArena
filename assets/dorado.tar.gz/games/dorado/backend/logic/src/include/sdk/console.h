﻿#ifndef _CONSOLE_H
#define _CONSOLE_H
#include "sdk.h"
#include "const.h"
/***************************************************
*控制台
*每回合你通过传入的参数初始化一个控制台
*之后你的所有操作都将可以通过控制台完成
*这将是你打交道最多最多的一个部分
*************************************************/
extern const int LEVELUP_COST_PER_LEVEL, LEVELUP_COST_BASE;
extern const int CALLBACK_COST_PER_LEVEL, CALLBACK_COST_BASE;
extern const int BUYBACK_COST_PER_LEVEL, BUYBACK_COST_BASE;
struct Console
{
private:
    //标准寻路函数指针，参数为(PMap，起点Pos，终点Pos，障碍点列表vector<Pos>引用，路径点列表vector<Pos>引用)
    typedef void (*shortestPathFunc)(const PMap&, Pos, Pos, const std::vector<Pos>&, std::vector<Pos>&);
private:
    //禁止拷贝控制台
    Console(const Console&);
    Console& operator= (const Console&);
private:
    //Console类的私有成员
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
    const PUnit* selected; //被选中的单位
    const PUnit* militaryBase; //基地单位
    shortestPathFunc shortestPathInUse; //指向寻路函数的函数指针
    const PUnit* baseAttackTarget; //被指定的基地攻击目标
	std::vector<Pos> newHeroPos; //记录这回合即将召唤的英雄，防止一回合多次召唤英雄时随机到同一位置
    int gold_cost_round;
    //统计所有命令消耗的金钱之和。仅供参考。请选手自己把握命令是否能够真的被执行
    //当一个英雄被传递了多个命令，logic只会选择一个来执行，但是这里的金钱消耗会累计
protected:
    bool checkSelected (const PUnit*& unit);
public:
    //随机在中心为center,半径平方为range的区域内取出一个不与可见单位位置重复的点
    Pos randPosInArea(Pos center, int range);
    //随机在给定区域内取出一个不与可见单位位置重复的点
    Pos randPosInArea(const Geometry*);
    //随机在中心为center,半径平方为range的区域内取出距离target欧式距离最近的点
    Pos closestPos(Pos center, int range, Pos target);
    //
public:
    Console(const PMap&, const PPlayerInfo&, PCommand&);//初始化一个控制台
    ~Console();

    //filter是过滤器，返回满足特定要求的单位列表
    std::vector<PUnit*> friendlyUnits(const UnitFilter& = UnitFilter());//己方单位
    std::vector<PUnit*> enemyUnits(const UnitFilter& = UnitFilter());//敌方单位

    PUnit* getUnit (int id);//根据ID获取某一个单位
    PSkill* getSkill (const std::string& name, const PUnit*);
    PBuff* getBuff (const std::string&, const PUnit*);

    void selectUnit(const PUnit*);//选中某一个单位，之后的操作可以不传单位的参数，直接使用这个单位
    void selectHero(int);//选中相应召唤次序的英雄(从0开始计数)

/******************************
*基地相关操作（每回合均可进行多次操作）
********************************/
    //召唤新英雄，参数为英雄名+出生位置，若未指定出生位置，则在可出生的范围内随机选取位置
    //若指定的出生位置不在允许范围内，自动选取允许范围中距离目标点最近的点作为出生点
    void chooseHero(std::string name, Pos pos = Pos(-1,-1));
    //买活英雄，参数为单位指针+买活位置，买活位置判定同上述出生位置
    void buyBackHero(const PUnit*, Pos pos = Pos(-1,-1));
    //召回英雄，参数为单位指针+召唤位置，召唤位置判定同出生位置
    void callBackHero(const PUnit*, Pos pos = Pos(-1,-1));
    //将英雄升一级，参数为单位指针
    void buyHeroLevel(const PUnit*);
    //指定基地攻击某一目标（若不调用该函数则基地随机选取可攻击目标），若参数为空，则强制基地该回合不进行攻击操作
    void baseAttack(const PUnit* = NULL);
    const PUnit* getMilitaryBase() {return militaryBase;}

/**************************
*英雄相关操作
****************************/
    //指定某一单位移动，若未在参数中指定，则移动单位为选中单位，以下函数同
    void move (const Pos& target, const PUnit* = NULL);
    //给出一个目标，将所有可见单位作为障碍，调用选定的寻路函数。
    void move (const std::vector<Pos>& path, const PUnit* = NULL);
    //给出一个路径，沿这个路径移动。

    //更改寻路函数，寻路函数格式见shortestPathFunc的typedef
    void changeShortestPathFunc(shortestPathFunc newSPFunc);
    //指定某一单位攻击
    void attack (const PUnit* target, const PUnit* = NULL);
    //获得某一单位技能列表
    std::vector<PSkill*> getSkills(const SkillFilter& = SkillFilter(), const PUnit* = NULL);
    std::vector<PSkill*> getAvailableSkills (const SkillFilter& = SkillFilter(), const PUnit* = NULL);


    //指定某一单位使用指定技能（两个函数分别为对人与对地）
    bool useSkill(const char* skillName, const PUnit* target, const PUnit* = NULL);
    bool useSkill(const char* skillName, const std::vector<Pos>& target, const PUnit* = NULL);
    bool useSkill(const char* skillName, const Pos target, const PUnit* = NULL);
    bool useSkill(const PSkill* skill, const PUnit* target, const PUnit* = NULL);
    bool useSkill(const PSkill* skill, const std::vector<Pos>& target, const PUnit* = NULL);
    bool useSkill(const PSkill* skill, const Pos target, const PUnit* = NULL);
/******************************************************************************
* 得到某个参数，arg是参数的名称，val是你要获取的量的代码，具体参看规则文档：参数获取方式列表
*******************************************************************************/
    int unitArg (const std::string& arg, const std::string& val, const PUnit* = NULL);
    const std::vector<int>& unitArg (const std::string& arg, const PUnit* = NULL);
/**************************
*得到当前回合的一些信息
***************************/
    inline int round () {return info->round;}
    inline int gold () {return info->gold;}
    inline int camp () {return info->camp;}
    int property (); //总财产
/********************
*计算一些操作的花费
***********************/
    inline int levelUpCost (int _level) const  {return _level * LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE;}
    inline int callBackCost (int _level) const  {return _level * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE;}
    inline int buyBackCost (int _level) const  {return _level * BUYBACK_COST_PER_LEVEL + BUYBACK_COST_BASE;}
    inline int reviveTime (int _level) const  {return (_level + 1) * 5;}
//这一回合的命令已经消耗了多少金钱
    inline int goldCostCurrentRound() const {return gold_cost_round;}
};
#endif// _CONSOLE_H

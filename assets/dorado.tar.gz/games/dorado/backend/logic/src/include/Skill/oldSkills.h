#ifndef AI9_2015_Skills_H
#define AI9_2015_Skills_H

#include "Skill.h"
#include "../Unit/Mine.h"
#include "../Unit/Unit.h"
#include "../Unit/MilitaryBase.h"
#include "../PlayerInfo/PlayerInfo.h"

class Attack:public Skill
{
public:
    Attack(Unit* myUnit,int MaxCd);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~Attack(){}
};
class YellowPoint:public Skill
{
public:
    YellowPoint(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual ~YellowPoint(){}
protected:
    int ahp;
    int aatk;
    int adef;
};
class Recovery:public Skill
{
public:
    Recovery(Unit* myUnit);
	virtual bool canBeUse();
	virtual bool trigger();
    virtual ~Recovery(){}
protected:
	int ahp;
	int amp;
	int range;
};
class Hide : public Skill
{
public:
    Hide(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Hide(){}
protected:
	int mp;
};
class HideLU:public Skill
{
public:
    HideLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~HideLU(){}
};
class FlyingBlade : public Skill
{
public:
    FlyingBlade(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~FlyingBlade(){}
protected:
    int mp;
    int range;
};
class FBLU:public Skill
{
public:
    FBLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~FBLU(){}
};
class Blink : public Skill
{
public:
    Blink(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Blink(){}
protected:
    int mp;
    int range;
};
class BlinkLU:public Skill
{
public:
    BlinkLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~BlinkLU(){}
};
class PiercingArrow : public Skill
{
public:
    PiercingArrow(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~PiercingArrow(){}
protected:
    bool check(Pos a, Pos b, Pos c);
    int mp;
    int range;
    int dmg;
    double wid;
};
class PALU:public Skill
{
public:
    PALU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~PALU(){}
};
class ArrowsRain : public Skill
{
public:
    ArrowsRain(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~ArrowsRain(){}
protected:
    int mp;
    int range;
};
class ARLU:public Skill
{
public:
    ARLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~ARLU(){}
};
class PowerUp : public Skill
{
public:
    PowerUp(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~PowerUp(){}
protected:
	int mp;
};
class PULU:public Skill
{
public:
    PULU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~PULU(){}
};
class Charge:public Skill
{
public:
    Charge(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Charge(){}
protected:
    int mp;
    int range;
    int dmg;
};
class ChargeLU:public Skill
{
public:
    ChargeLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~ChargeLU(){}
};
class Spin : public Skill
{
public:
    Spin(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Spin(){}
protected:
    int mp;
    int range;
    int dmg;
};
class SpinLU:public Skill
{
public:
    SpinLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~SpinLU(){}
};
class Yell : public Skill
{
public:
    Yell(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Yell(){}
protected:
    int mp;
    int range;
};
class YellLU:public Skill
{
public:
    YellLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~YellLU(){}
};
class LevelUp:public Skill
{
public:
    LevelUp(Unit* myUnit,int Hp,int Atk,int Def);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~LevelUp(){}
protected:
    int ahp;
    int aatk;
    int adef;
};
class Dead:public Skill
{
public:
    Dead(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~Dead(){}
protected:
    Pos pos;
    int range;
    bool check(Pos tmp);
    void shareExp();
    void giveMoney();
};
//=================
class ChooseFighter:public Skill
{
public:
    ChooseFighter(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseFighter(){}
protected:
    Pos pos;
};

class ChooseArcher:public Skill
{
public:
    ChooseArcher(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseArcher(){}
protected:
    Pos pos;
};

class ChooseAssassin:public Skill
{
public:
    ChooseAssassin(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseAssassin(){}
protected:
    Pos pos;
};

//choose hero of ai9_2016

class ChooseHammerguard:public Skill
{
public:
	ChooseHammerguard(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	MilitaryBase* base;
};

class ChooseMaster:public Skill
{
public:
	ChooseMaster(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	MilitaryBase* base;
};

class ChooseBerserker:public Skill
{
public:
	ChooseBerserker(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	MilitaryBase* base;
};

class ChooseScouter:public Skill
{
public:
	ChooseScouter(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	MilitaryBase* base;
};

//These skills are for military_base of ai9_2016
class BuyBackHero:public Skill
{
public:
	BuyBackHero(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToBuyBack(Operation* cmd);
	MilitaryBase* base;
};

class CallBackHero:public Skill
{
public:
	CallBackHero(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToCallBack(Operation* cmd);
	MilitaryBase* base;
};

class BuyHeroLevel:public Skill
{
public:
	BuyHeroLevel(MilitaryBase* myBase);
	virtual bool canBeUse(Operation* cmd);
	virtual bool trigger();
protected:
	int goldToBuyLevel(Operation* cmd);
	MilitaryBase* base;
};

//mining is designed as a passive skill.
//It should be called every round
class Mining:public Skill
{
public:
    Mining(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    ~Mining() {}
private:
    Mine* mine;
};
// 武伟轩 2015.09.23 新增具体技能

class HammerAttack : public Skill
{
public:
    HammerAttack(Unit* myUnit);
    //virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~HammerAttack(){}
protected:
    int mp;
    int dmg;
    int range;
};


class EarthShake: public Skill
{
public:
    EarthShake(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~EarthShake();
    static void execute(Unit*);//没有吟唱的使用效果
protected:
    int mp;
    int dmg;
    int range;
};

class DragonAttack:public Skill
{
public:
    DragonAttack(Unit* myUnit,int MaxCd);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~DragonAttack(){}
};

class Sacrifice:public Skill
{
public:
    Sacrifice(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void setUsed(bool u) {used = u;}
    virtual string toString();
    virtual ~Sacrifice();
protected:
    int mp;
    int selfdmg;
    int range;
    bool used;//是否使用过
};

class Revenge:public Skill
{
public:
    Revenge(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Revenge();
protected:
    int mp;
    int dmg;
};

class SuperDead:public Skill
{
public:
    SuperDead(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~SuperDead();
};

class Sting:public Skill
//被动技能
{
public:
    Sting(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Sting();
protected:
    int mp;
    int dmg;
    bool canbeuse;
};

//=================
class ChooseProfessor:public Skill
{
public:
    ChooseProfessor(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseProfessor(){}
protected:
    Pos pos;
};
class FinalExam : public Skill
{
public:
    FinalExam(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~FinalExam(){}
protected:
    int mp;
    int range;
};

//=================
class ChooseNameless:public Skill
{
public:
    ChooseNameless(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseNameless(){}
protected:
    Pos pos;
};
class Freeze : public Skill
{
public:
    Freeze(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Freeze(){}
protected:
    int mp;
    int range;
};

//=================
class ChooseAnonymous:public Skill
{
public:
    ChooseAnonymous(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseAnonymous(){}
protected:
    Pos pos;
};
class Whateveritis : public Skill
{
public:
    Whateveritis(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Whateveritis(){}
protected:
    int mp;
    int range;
};

//===================
class ChooseReaper:public Skill
{
public:
    ChooseReaper(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseReaper(){}
protected:
    Pos pos;
};

#endif//AI9_2015_Skills_H

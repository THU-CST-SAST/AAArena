﻿/*************************
 *这里是sdk.h
 *这里包含了游戏sdk所需的基本的接口
 *你可以 只使用本文件 完成你的AI
 *不过这不太方便，你需要很多复杂重复的代码
 *我们还准备了console.h,filter.h
 *他们是对本文件的重新封装，你可以依靠他们来 更简单 地完成AI
 *如果你已经熟悉了游戏，你可以通读此文件来进一步了解游戏，让你的AI更强大。
 ************************/
#ifndef AI9_2016_H
#define AI9_2016_H
#include <string.h>
#include <utility>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include "kernel.h"
#include "filter.h"
#ifndef _AI__
#include "../Pos.h"
#else
#include "Pos.h"
#endif//_AI__

/**************************************************************************8
*这是一个将字符串转化为全小写的函数。
*由于框架的缺陷，SDK中有的地方使用了char*存储字符串，有的地方采用了string。
*为了避免出错，推荐比较两个字符串的时候使用lowerCase(str1) == lowerCase(str2)的形式
*一方面，这可以避免错误地将char*和string进行比较。
*另一方面，可以防止大小的错误。在我们的SDK中，所有的字符串判断均不区分大小写，你可以放心使用。
***********************************************************************/
std::string lowerCase(const std::string& str);

#include "const.h"

/*
 * 几何区域
 * 抽象地描述一个几何区域
 */
struct Geometry {
    Geometry () {}
    virtual ~Geometry() {}
    virtual bool contain (const Pos &_pos) = 0;//是否包含某个点
    virtual void output(std::ostream&) const = 0;//输出这个区域的信息以供调试
    virtual Pos getCenter () const = 0;//中心点坐标
    virtual double getSquare () const = 0;//面积
    virtual Pos randPosInArea () const = 0;//在这个区域中取一个随机的点
};

/*
 * 圆形区域
 */
struct Circle : public Geometry {
private:
    Pos center;
    int radius2;

public:
    //请注意这里用的是半径的平方值
    Circle (int centerX, int centerY, int _radius2);
    Circle (const Pos &_center, int _radius2);
    virtual void output(std::ostream&) const;
    virtual Pos randPosInArea () const;
    Pos getCenter () const {return center;}
    double getSquare () const {return 3.1415 * double(radius2) * double(radius2);}
    bool contain (const Pos &_pos);
};
std::ostream& operator<< (std::ostream&, const Circle&);


//有的地方使用了typeId，这对应在const.h定义的一些数组中某个字符串的秩
//但是在El Dorado中，我们不希望你使用typeId来标识一种技能或者单位，因为这太容易出错了，也不够直观
//我们更加希望你直接使用字符串。第三部分提供的高级接口中将避免typeId。


/*
 * 各种参数（属性等）
 * 比如说生命值hp，就是作为一个PArg在单位PUnit中存储.
 * 但是hp不仅仅包括一个值，会包括hp回复速率，当前值，上限，这些数值以向量形式存储在val里
 * 具体的参见规则文档，单位参数获取方式列表.
 */
struct PArg {
    int typeId;                                                         //类型编号，与名称的对应关系详见ARGS_NAME[]
    char name[100];                                                     //名称
    std::vector<int> val;                                               //参数列表，各个下标的意义见游戏规则说明

    PArg(int _typeId);                                                  //初始化
    PArg(std::string a);   	//用转换后的字符串初始化
	PArg(const PArg& arg);
};

/*
 * 状态
 * 单位的特殊状态，比如减速.
 */
struct PBuff
{
    int typeId;          //类型编号，与名称的对应关系详见BUFF_NAME[]
    char name[100];      //名称
    int level;           //等级
    int timeLeft;        //剩余作用时间

    PBuff(int _typeId, int _level, int _timeLeft);                      //初始化
    PBuff(std::string a);               //用转换后的字符串初始化
	PBuff(const PBuff& buff);
    bool isPositive() const;            //判断是否为对自己有利的状态
};


/*
 * 地图
 * 地图是一个１５０＊１５０的矩阵，每一点的高度不同
 */
struct PMap
{
private:
    int height[MAP_SIZE][MAP_SIZE];      //地图中各个点的高度

public:
    std::vector<int> playerIds;          //玩家编号列表（默认0、1为游戏双方，2为野怪）

    PMap() {
        playerIds.clear();
    }
    PMap(const char* fileName);                             //读入地图信息
    int* operator[](int width) {return height[width];}      //引用高度
    int getHeight (int x, int y) const;
};

/*
 * 技能
 */
struct PSkill
{
    int typeId;           //类型编号，与名称的对应关系详见SKILL_NAME[]
    char name[100];       //名称
    int mp;               //所需魔法
    int level;            //等级
    int maxLevel;         //等级上限
    int cd;               //目前剩余cd时间
    int maxCd;            //总cd时间，对于普通攻击（Attack）即为攻速

    PSkill(int _typeId, int _mp, int _level, int _maxLevel, int _cd, int _maxCd);
                                //初始化
    PSkill(std::string a);      //用转换后的字符串初始化
	PSkill(const PSkill& skill);
    bool needTarget() const;          //判断技能是否需要指定坐标
    int range() const;                //技能的作用范围
    static bool skillMask (const std::string&);//用来屏蔽一些技能，玩家无需使用
};

/*
 * 单位
 * 同一个单位每回合对应的PUnit是不同的，但他们的id是相同的。你不可以存储Punit*以在不同的回合访问同一个单位，而应该用id每回合更新PUnit。请务必注意这一点。
 */
struct PUnit
{
public:
    int typeId;                   //类型编号，与名称的对应关系详见UNIT_NAME[]
    char name[100];               //名称
    int id;                       //编号
    int player;                   //所属玩家编号
    int camp;                     //所属阵营
    Pos pos;                      //位置
    std::vector<PArg> args;       //单位参数列表
    std::vector<PBuff> buffs;     //单位状态列表
    std::vector<PSkill> skills;   //单位技能列表
    //以下均为目前的属性值，供简便调用
    int max_hp;       //生命值上限
    int max_mp;       //魔法值上限
    int hp;           //生命值
    int mp;           //魔法值
    int atk;          //攻击
    int def;          //防御
    int speed;        //速度
    int exp;          //经验值
    int range;        //射程
    int view;         //视野
    int level;        //等级

    PUnit ():max_hp(0), max_mp(0), hp(0), mp(0), atk(0), def(0), speed(0), exp(0), range(0), view(0), level(0) {}
    PUnit(int _typeId, int _id, int _player, int _camp, int _pos_x, int _pos_y);//初始化
    PUnit(std::string a);             //用转换后的字符串初始化
    PUnit(const PUnit& unit);

    bool isHero() const;                //判断单位是否为英雄
    bool isWild() const;                //判断单位是否为野怪
    bool isMine() const;                //判断单位是否为金矿
    bool isBase() const;                //判断单位是否为基地
    const PArg* operator[] (int _typeId) const;      //按类型编号查询参数
    const PArg* operator[] (std::string _) const;    //按名称查询参数
    const PBuff* findBuff(int _typeId) const;        //按类型编号查询状态
    const PBuff* findBuff(std::string _) const;      //按名称查询状态
    const PSkill* findSkill(int _typeId) const;      //按类型编号查询技能
    const PSkill* findSkill(std::string _) const;    //按名称查询技能
    bool canMove() const;                            //判断单位目前是否可以移动
    bool canUseSkill(int _typeId) const;             //判断指定单位目前是否可以使用某种技能，_typeId为技能类型编号
    bool canUseSkill(const std::string& str) const;  //这个单位目前能否使用该技能
    bool canUseSkill(const PSkill* skill) const;
    static bool unitMask(const std::string &name);   //屏蔽一些单位，玩家无需使用
};


/*
 * 作为传入参数的局面信息
 * 玩家每回合所能得到的全部信息都在这个结构体中被传入
 * 你的ai所能做的就是根据PPlayerInfo给出的信息，选择一些操作加入下面的PCommand.
 * 这个结构体有一些方法，这些方法可以帮助你使用这些信息.
 * 不过在El Dorado中更推荐使用第三部分的接口来完成．
 */
struct PPlayerInfo
{
    int round;                        //目前回合
    int player;                       //你的玩家编号
    int camp;                         //你的玩家所属阵营
    int gold;                         //你的玩家目前拥有的金钱
    std::vector<PUnit> units;         //可见的单位列表
    std::vector<PFlight> flights;     //可见的飞行道具列表
    std::vector<PArea> areas;         //可见的作用范围列表

    PPlayerInfo(int _round = 0, int _player = 0, int _camp = 0, int _gold = 0);
    PPlayerInfo(std::string a);  	//用转换后的字符串初始化
	PPlayerInfo(const PPlayerInfo& playerInfo);
};

#ifndef _AI__
#include "../PCommand/Operation.h"
#include "../PCommand/PCommand.h"
#else
#ifndef OPERATION_H
#define OPERATION_H
/*
 * 操作
 * 一个操作，你的ai所能做的就是根据上面的PPlayerInfo给出信息，选择一些操作加入下面的PCommand.
 * 你完全可以不必直接操作这个结构体，第三部分的方法会帮你完成
 */
struct Operation
{
    int id;                          //实施者编号
    int typeId;                      //类型编号，与名称的对应关系详见Operation_name[]
    std::string type;                //操作名称
    std::vector<Pos> targets;             //目标位置列表，注：除移动（"Move"）外的操作，该列表的长度不大于1

    Operation():                     //初始化，默认为不动（Stop）
        id(-1),typeId(-1),type("Stop")
    {
        targets.clear();
    }
    Operation(const Operation &_);   //给出typeId和type的其中之一即可，默认为typeId
};
#endif//OPERATION_H

#ifndef PCOMMAND_H
#define PCOMMAND_H
/*
 * 玩家给出的行动列表
 * 你的ai所能做的就是根据上面的PPlayerInfo给出信息，选择一些操作加入PCommand.
 * 你完全可以不必直接操作这个结构体，第三部分的方法会帮你完成
 */
struct PCommand
{
    std::vector<Operation> cmds;
    PCommand()                       //初始化
    {
        cmds.clear();
    }
};
#endif//PCOMMAND_H
#endif//_AI__

bool checkPos(Pos A);
//判断坐标是否在地图内

//下面是一些根据给定条件寻找最短路径的函数
void findShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path);
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径
//这个函数将会作为void Console::move (const Pos& target, const PUnit* = NULL)的默认的寻路方案
//下面的函数你可以将得到的路径作为参数，使用void Console::move (const vector<Pos>& target, const PUnit* = NULL)进行移动

void findShortestPath(const PMap &map, Pos start, Pos dest, std::vector<Pos> &_path);
//寻路，返回从位置start到dest的一条最短路径，考虑悬崖，不考虑其它单位，若路径不存在返回到离目标点最近的一个点的路径

void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, std::vector<Pos> &_path);
//带标志点寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），考虑悬崖，不考虑其它单位，若路径不存在返回到离目标点最近的一个点的路径

void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, const std::vector<Pos> &blocks, std::vector<Pos> &_path);
//带卡位和标志点的寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径


extern "C" void player_ai(const PMap &map,const PPlayerInfo &info,PCommand &cmd);
//你的ai将要实现这个函数，这里是一个声明

#include "console.h"
#endif//AI9_2016_H
//~~~~~~~~~~~~~~~~~~~~~~`

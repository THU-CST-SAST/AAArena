#ifndef ACTMAKER_H
#define ACTMAKER_H
#include "../Base.h"
#include "../sdk/sdk.h"
class Area;
class Buff;
struct PCommand;
class Flight;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
typedef void (*ai_func)(const PMap& map,const PPlayerInfo& info,PCommand& cmd);
class ActMaker
{
public:
    ActMaker():status(true){}
    // virtual bool start_game(const PrototypeInfo* info,const PrototypeCmd* cmd) = 0;
    virtual bool getCmd(const PlayerInfo* info,PCommand* cmd) = 0;
    virtual ~ActMaker(){}
    virtual bool aiStatus(){return status;}
    virtual void getWrong(){status=false;}
    virtual void outStatus(std::ostream &os)=0;
protected:
    bool status;
};

#endif//ACTMAKER_H

#ifndef MAP_H
#define MAP_H
#include "../Base.h"
class ActMaker;
class Area;
//class Buff;
struct PCommand;
class Flight;
class Game;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
class Map
{
    public:
        Map(int M,int N,const char* filename);
        virtual void roundInit();
        //virtual bool addUnit(Unit* unit);
        virtual bool tryPosition(Pos pos,int volume);
        //virtual void removeUnit(Unit* unit);
        virtual void calcView(Unit* unit);
        virtual ~Map();
    public:
        inline bool checkPos (int x, int y) {return x >= 0 && x < length() && y >= 0 && y < width();}
        inline bool checkPos (Pos p) {return p.x >= 0 && p.x < length() && p.y >= 0 && p.y < width();}
        int getView(int x,int y){return view[x][y];}
        int getView(Pos pos){return view[pos.x][pos.y];}
        int getHeight(int x,int y){return height[x][y];}
        int getHeight(Pos pos){return height[pos.x][pos.y];}
        int width(){return n;}
        int length(){return m;}
        int getDetector(int x,int y){return detector[x][y];}
        int getDetector(Pos pos){return detector[pos.x][pos.y];}

        void setView(int x,int y,int z){view[x][y]=z;}
        void setView(Pos pos,int z){view[pos.x][pos.y]=z;}
        void setHeight(int x,int y,int z){height[x][y]=z;}
        void setHeight(Pos pos,int z){height[pos.x][pos.y]=z;}
        void setWidth(int z){n=z;}
        void setLength(int z){m=z;}
        void setDetector(int x,int y,int z){detector[x][y]=z;}
        void setDetector(Pos pos,int z){detector[pos.x][pos.y]=z;}
    protected:
        int m,n;//n行m列
        int height[300][300];
        int view[300][300];//视野
        int detector[300][300];//反隐形
        //int occupy[300][300];//此处是否被占用,存储占有该位置的单位，暂不考虑飞行单位
        Game* game;
};
#endif//MAP_H

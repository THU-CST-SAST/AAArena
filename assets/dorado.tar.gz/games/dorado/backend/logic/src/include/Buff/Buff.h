﻿#ifndef BUFF_H
#define BUFF_H
#include "../Base.h"
class ActMaker;
class Area;
struct PCommand;
class Flight;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
class Buff
{
public:
    virtual void oneRoundPass();
    virtual void terminate();//buff终止特效
    virtual void work();//非累计型buff生效
    virtual void overlap(Buff *buff);
    virtual bool remove();
    virtual void output(ostream &os);
	virtual void roundStart();
	virtual void buffEnd();
    Buff(const char* Name,Unit* myUnit, int TimeLeft,int Level=0,const char* Des="No description");
    virtual string toString();
    virtual ~Buff(){}
public:
    std::string getName(){return name;}
    int getTimeLeft(){return timeLeft;}
protected:
    Unit* unit;
    std::string name;
    std::string des;//description,buff描述
    int timeLeft;
    int level;
};
#endif//BUFF_H

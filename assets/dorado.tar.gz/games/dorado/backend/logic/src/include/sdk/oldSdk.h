#ifndef AI9_2016_H
#define AI9_2016_H

#include <string.h>
#include <utility>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#ifndef POS_H
#define POS_H

struct Pos//整数坐标
{
    int x,y;
    Pos(int X=-1,int Y=-1):
        x(X),y(Y)
    {
    }
    //Pos||DPos可用函数String2Pos||String2DPos转化为字符串……
};
std::ostream& operator<< (std::ostream&, const Pos&);
struct DPos//浮点数坐标
{
    double x,y;
    DPos(double X=-1,double Y=-1):
        x(X),y(Y)
    {
    }
    DPos(const Pos &pos):
        x(pos.x),y(pos.y)
    {
    }
};
std::ostream& operator<< (std::ostream&, const DPos&);
int crossProduct(Pos A,Pos B,Pos C);//向量AB叉乘AC
bool cross(Pos A,Pos B,Pos C,Pos D);//判断线段AB与CD是否有公共点
bool checkOnLine(Pos A,Pos B,Pos C);//判断AB连线是否与C（方格）有交点
int dis2(Pos A,Pos B);//欧氏距离平方
double dis(Pos A,Pos B);//欧几里得距离
bool operator==(Pos A,Pos B);//相等
bool operator!=(Pos A,Pos B);//不等
Pos operator+(Pos A,Pos B);//加法
Pos operator-(Pos A,Pos B);//减法
Pos operator*(Pos A,int _);//数乘
Pos operator*(int _,Pos A);//数乘
//以下面对DPos定义的函数其功能与面对Pos的同名函数相同
double crossProduct(DPos A,DPos B,DPos C);
bool cross(DPos A,DPos B,DPos C,DPos D);
bool checkOnLine(DPos A,DPos B,DPos C);
double dis2(DPos A,DPos B);
double dis(DPos A,DPos B);
bool operator==(DPos A,DPos B);
bool operator!=(DPos A,DPos B);
DPos operator+(DPos A,DPos B);
DPos operator-(DPos A,DPos B);
DPos operator*(DPos A,double _);
DPos operator*(double _,DPos A);

#endif//POS_H

#include "const.h"
struct PMap//地图
{
    vector<int> playerIds;//玩家编号列表（默认0、1为游戏双方，2为野怪）
    int height[MAP_SIZE][MAP_SIZE];//地图中各个点的高度
	//zyli14
	int* operator[] (int width) {return height[width];}
	//zyli14
    PMap(const char* fileName);//读入地图信息
    PMap()
    {
        playerIds.clear();
    }
};
struct PFlight//飞行道具
{
    int typeId;//类型编号，与名称的对应关系详见Flight_name[]
    char name[100];//名称
    int id;//编号
    int unitId;//来源的单位编号
    int camp;//所属阵营
    int speed;//速度
    Pos pos;//位置
    Pos target;//目标位置
    PFlight(string a);
    PFlight(int _typeId, int _id, int _unitId, int _camp, int _speed, int _pos_x, int _pos_y, int target_x, int target_y);
};
struct PArea//（作用）范围
{
    int typeId;//类型编号，与名称的对应关系详见Area_name[]
    char name[100];//名称
    int id;//编号
    int camp;//所属阵营
    int timeLeft;//剩余时间
    Pos center;//圆心坐标
    int radius;//半径
    PArea(string a);
    PArea(int _typeId, int _id, int _camp, int _timeLeft, int _center_x, int _center_y, int _radius);
    bool containPos(Pos _) const;//求区域内是否包含某个点_
    bool containDPos(DPos _, double zero = 1e-10) const;//求区域内是否包含某个点_，zero表示精度（下溢值）
};
struct PArg//各种参数（属性等）
{
    int typeId;//类型编号，与名称的对应关系详见Args_name[]
    char name[100];//名称
    std::vector<int> val;//参数列表，各个下标的意义见游戏规则说明
    PArg(string a);
    PArg(int _typeId);
};
struct PBuff//状态
{
    int typeId;//类型编号，与名称的对应关系详见Buff_name[]
    char name[100];//名称
    int level;//等级
    int timeLeft;//剩余时间
    PBuff(string a);
    PBuff(int _typeId, int _level, int _timeLeft);
    bool isPositive() const;//判断是否为对自己有利的状态
};
struct PSkill//技能
{
    int typeId;//类型编号，与名称的对应关系详见Skill_name[]
    char name[100];//名称
    int mp;//所需魔法
    int level;//等级
    int maxLevel;//等级上限
    int cd;//目前剩余cd时间
    int maxCd;//总cd时间，对于普通攻击（Attack）即为攻速
    PSkill(string a);
    PSkill(int _typeId, int _mp, int _level, int _maxLevel, int _cd, int _maxCd);
    bool isLU() const;//判断技能是否为升级类技能（不含黄点）
    bool isHeroSkill() const;//判断技能是否为英雄技能（不含升级类技能）
    bool needTarget() const;//判断技能是否需要指定坐标
    int range() const;
    static bool skillMask (const string&);
};
struct PUnit//单位
{
    int typeId;//类型编号，与名称的对应关系详见Unit_name[]
    char name[100];//名称
    int id;//编号
    int player;//所属玩家编号
    int camp;//所属阵营
    Pos pos;//位置
    std::vector<PArg> args;//单位参数列表
    std::vector<PBuff> buffs;//单位状态列表
    std::vector<PSkill> skills;//单位技能列表
    PUnit(string a);
    PUnit(int _typeId, int _id, int _player, int _camp, int _pos_x, int _pos_y);
    //以下均为目前的属性值，供简便调用
    int max_hp;//生命值上限
    int max_mp;//魔法值上限
    int hp;//生命值
    int mp;//魔法值
    int atk;//攻击
    int def;//防御
    int speed;//速度
    int exp;//经验值
    int range;//射程
    int view;//视野
    int level;//等级
    
    bool isHero() const;//判断单位是否为英雄
    bool isWild() const;//判断单位是否为野怪
    const PArg* operator[] (int _typeId) const;//按类型编号查询参数
    const PArg* operator[] (string _) const;//按名称查询参数
    const PBuff* findBuff(int _typeId) const;//按类型编号查询状态
    const PBuff* findBuff(string _) const;//按名称查询状态
    const PSkill* findSkill(int _typeId) const;//按类型编号查询技能
    const PSkill* findSkill(string _) const;//按名称查询技能
    bool canMove() const;//判断单位目前是否可以移动
    bool canUseSkill(int _typeId) const;//判断指定单位目前是否可以使用某种技能，_typeId为技能类型编号
    bool canUseSkill(const string& str) const;
    bool canUseSkill(const PSkill* skill) const;
    static bool unitMask(const string&);
};
struct PPlayerInfo//作为传入参数的局面信息
{
    int round;//目前回合
    int player;//你的玩家编号
    int camp;//你的玩家所属阵营
    std::vector<PUnit> units;//可见的单位列表
    std::vector<PFlight> flights;//可见的飞行道具列表
    std::vector<PArea> areas;//可见的作用范围列表
    PPlayerInfo(int _round = 0, int _player = 0, int _camp = 0):  round(_round), player(_player), camp(_camp)
    {
        units.clear() ;
        flights.clear();
        areas.clear();
    }
    PPlayerInfo(string a);
    
    int gold; //玩家拥有金钱
    
    const PUnit* findUnitById(int _id) const;//返回编号为_id的单位
    const PUnit* findUnitByPos(Pos _pos) const;//返回位置为_pos的单位
    void findUnitByTypeId(int _typeId, std::vector<const PUnit*> &_unitList) const;//返回所有类型编号为_typeId的单位列表_unitList
    void findUnitByName(string _name, std::vector<const PUnit*> &_unitList) const;//返回所有名称为_name的单位列表_unitList
    void findUnitByPlayer(int _player, std::vector<const PUnit*> &_unitList) const;//返回所有属于玩家_player的单位列表_unitList
    void findUnitInArea(Pos _, int _range, std::vector<const PUnit*> &_unitList) const;//返回到点_的距离不超过_range的单位列表_unitList
    const PFlight* findFlightById(int _id) const;//返回编号为_id的飞行道具
    void findFlightByTypeId(int _typeId, std::vector<const PFlight*> &_flightList) const;//返回所有类型编号为_typeId的飞行道具列表_flightList
    void findFlightByName(string _name, std::vector<const PFlight*> &_flightList) const;//返回所有名称为_name的飞行道具列表_flightList
    void findFlightByPlayer(int _player, std::vector<const PFlight*> &_flightList) const;//返回所有属于玩家_player的飞行道具列表_flightList
    const PArea* findAreaById(int _id) const;//返回编号为_id的作用范围
    void findAreaByCenterPos(Pos _center, std::vector<const PArea*> &_areaList) const;//返回所有圆心坐标为_center的作用范围列表_areaList
    void findAreaByTypeId(int _typeId, std::vector<const PArea*> &_areaList) const;//返回所有类型编号为_typeId的作用范围列表_areaList
    void findAreaByName(string _name, std::vector<const PArea*> &_areaList) const;//返回所有名称为_name的作用范围列表_areaList
    void findAreaByCamp(int _camp, std::vector<const PArea*> &_areaList) const;//返回所有属于阵营_camp的作用范围列表_areaList
};
#ifndef _AI__
#include "../PCommand/Operation.h"
#include "../PCommand/PCommand.h"
#else
#ifndef OPERATION_H
#define OPERATION_H
struct Operation//操作
{
    int id;//实施者编号
    int typeId;//类型编号，与名称的对应关系详见Operation_name[]
    std::string type;//操作名称
    vector<Pos> targets;//目标位置列表，注：除移动（"Move"）外的操作，该列表的长度不大于1
    Operation(): id(-1),typeId(-1),type("Stop") //默认不动
    {
        targets.clear();
    }
    Operation(const Operation &_);//给出typeId和type的其中之一即可，默认为typeId
};
#endif//OPERATION_H
#ifndef PCOMMAND_H
#define PCOMMAND_H
struct PCommand//玩家给出的行动列表
{
    std::vector<Operation> cmds;
    PCommand()
    {
        cmds.clear();
    }
};
#endif//PCOMMAND_H
#endif//_AI__

bool checkPos(Pos A);
//判断坐标是否在地图内
void findShortestPath(const PMap &map, Pos start, Pos dest, std::vector<Pos> &_path);
//寻路，返回从位置start到dest的一条最短路径，考虑悬崖，不考虑其它单位，若路径不存在返回一个负数坐标
void findShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path);
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回一个负数坐标

void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, std::vector<Pos> &_path);
//带标志点寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），考虑悬崖，不考虑其它单位，若路径不存在返回一个负数坐标
void findShortestPathWithSymbols(const PMap &map, const std::vector<Pos> &symbols, const std::vector<Pos> &blocks, std::vector<Pos> &_path);
//带卡位和标志点的寻路，返回经过symbols内所有位置的一条最短路径（symbols的首尾元素表示起、终点），blocks中的位置不可经过，考虑悬崖，若路径不存在返回一个负数坐标

void infectedBySkill(const PPlayerInfo &info, int _unitId, int _typeId, std::vector<const PUnit*> &_unitList);
//返回编号为_unitId的单位目前使用某种技能可能影响到（即在射程内）的单位列表_unitList，_typeId为技能类型编号

extern "C" void player_ai(const PMap &map,const PPlayerInfo &info,PCommand &cmd);


//lizeyan added on 2015.12.9
class Geometry//定义一个区域
{
protected:
    vector<int> args;
public:
    Geometry () {};
    virtual bool contain (const Pos&) = 0;
    virtual bool contain (const DPos&) = 0;
};
class Rectangle: public Geometry//矩形区域
{
public:
    Rectangle (int minx, int miny, int maxx, int maxy);
    Rectangle (const Pos& a, const Pos& b);
    Rectangle (const DPos& a, const DPos& b);
    bool contain (const Pos&);
    bool contain (const DPos&);
};
class Circle: public Geometry//圆形区域
{
public:
    Circle (int centerX, int centerY, int radius2);
    Circle (const Pos& , int radius2);
    Circle (const DPos& , int radius2);
    bool contain (const Pos&);
    bool contain (const DPos&);
};

class Filter//过滤器,去除满足特定需求的单位或者技能
{
    vector<std::string> types;//允许的类型
    vector<std::string> avoids;//不允许的类型
    enum {LEVEL = 0, HP, MP, MAX_HP, MAX_MP, CD} LIMIT;
    static const int limitSize = 6;
    vector<std::pair<int, int> > limits;//限制区间
    vector<Geometry*> areas;//有效的区域
    std::map<std::string, int> name2rank;//将限制的类型转换为秩 
    //level, hp, mp, maxHp, maxMp, area, cd
public:
    Filter();
    ~Filter();
    bool valid (const PUnit*) const;//验证一个单位
    bool valid (const PSkill*) const;//验证一个技能
    void clean(const std::string&);//type, level, hp, mp, maxHp, maxMp, area, cd, all, 分号分隔
    void typeFilter (const char* type, const char* method = "a");//method, "w"重写， "a"添加
    void cleanTypeFilter();

    void avoidFilter (const char* avoid, const char* method = "a");
    void cleanAvoidFilter();

    void levelFilter(int lo, int hi);//[lo, hi)
    void cleanLevelFilter();

    void hpFilter(int lo, int hi);
    void cleanHpFilter();

    void mpFilter(int lo, int hi);  
    void cleanMpFilter();

    void areaFilter(Geometry* const geo, const char* method = "a");
    //geo会在clean或者fileter析构时自动delete.可以不需要手动delete
    void cleanAreaFilter();

    void maxHpFilter(int lo, int hi);
    void cleanMaxHpFilter();

    void maxMpFilter(int lo, int hi);
    void cleanMaxMpFilter();

    void cdFilter(int lo, int hi);
    void cleanCdFilter();
};

class Console
{
private:
    //标准寻路函数指针，参数为(PMap，起点Pos，终点Pos，障碍点列表vector<Pos>引用，路径点列表vector<Pos>引用)
    typedef void (*shortestPathFunc)(const PMap&, Pos, Pos, const std::vector<Pos>&, std::vector<Pos>&);
private:
    //禁止拷贝控制台
    Console(const Console&) {}
    Console& operator= (const Console&) {}
private:
    //Console类的私有成员
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
    const PUnit* selected; //被选中的单位
    const PUnit* militaryBase; //基地单位
    shortestPathFunc shortestPathInUse; //指向寻路函数的函数指针
    const PUnit* baseAttackTarget; //被指定的基地攻击目标
public:
    //随机在中心为center,半径平方为range的区域内取出一个不与已有单位位置重复的点
    Pos randPosInArea(Pos center, int range);
    //随机在中心为center,半径平方为range的区域内取出距离target欧式距离最近的点
    Pos closestPos(Pos center, int range, Pos target);
    //
protected:
public:
    Console(const PMap&, const PPlayerInfo&, PCommand&);//初始化一个控制台
    ~Console();

    //filter是过滤器，返回满足特定要求的己方单位列表
    vector<PUnit*> friendlyUnits(const Filter& = Filter());

    vector<PUnit*> enemyUnits(const Filter& = Filter());

    void selectUnit(const PUnit*);//选中某一个单位，之后的操作可以不传单位的参数，直接使用这个单位
    void selectHero(int);//选中相应召唤次序的英雄(从0开始计数)
    
    //基地相关操作（每回合均可进行多次操作）
    
    //召唤新英雄，参数为英雄名+出生位置，若未指定出生位置，则在可出生的范围内随机选取位置
    //若指定的出生位置不在允许范围内，自动选取允许范围中距离目标点最近的点作为出生点
    void chooseHero(std::string name, Pos pos = Pos(-1,-1));
    //买活英雄，参数为单位指针+买活位置，买活位置判定同上述出生位置
    void buyBackHero(const PUnit*, Pos pos = Pos(-1,-1));
    //召回英雄，参数为单位指针+召唤位置，召唤位置判定同出生位置
    void callBackHero(const PUnit*, Pos pos = Pos(-1,-1));
    //将英雄升一级，参数为单位指针
    void buyHeroLevel(const PUnit*);
    //指定基地攻击某一目标（若不调用该函数则基地随机选取可攻击目标），若参数为空，则强制基地该回合不进行攻击操作
    void baseAttack(const PUnit* = NULL);
    const PUnit* getMilitaryBase() {return militaryBase;}

    //英雄相关操作
    
    //指定某一单位移动，若未在参数中指定，则移动单位为选中单位，以下函数同
    void move (const Pos& target, const PUnit* = NULL);
    //更改寻路函数，寻路函数格式见shortestPathFunc的typedef
    void changeShortestPathFunc(shortestPathFunc newSPFunc);
    
    //指定某一单位攻击
    void attack (const PUnit* target, const PUnit* = NULL);

    //获得某一单位技能列表
    vector<PSkill*> getSkills(const Filter& = Filter(), const PUnit* = NULL);
    vector<PSkill*> getAvailableSkills (const Filter& = Filter(), const PUnit* = NULL);

    //指定某一单位使用指定技能（两个函数分别为对人与对地）
    bool useSkill(const char* skillName, const PUnit* target, const PUnit* = NULL);
    bool useSkill(const char* skillName, const vector<Pos>& target, const PUnit* = NULL);
    bool useSkill(const PSkill* skill, const PUnit* target, const PUnit* = NULL);
    bool useSkill(const PSkill* skill, const vector<Pos>& target, const PUnit* = NULL);
    //check
};
#endif//AI9_2016_H
//~~~~~~~~~~~~~~~~~~~~~~`

#ifndef PCOMMAND_H
#define PCOMMAND_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
class Flight;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
struct PCommand
{
public:
    vector<Operation> cmds;
    PCommand()
    {
        cmds.clear();
    }
};
#endif//COMMAND_H

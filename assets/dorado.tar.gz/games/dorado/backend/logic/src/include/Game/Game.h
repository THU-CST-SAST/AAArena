#ifndef GAME_H
#define GAME_H
#include "../Base.h"
#include "../PCommand/Operation.h"
#include "../PCommand/PCommand.h"
#ifndef STATEMENT
#define STATEMENT
class ActMaker;
class Area;
class Buff;
class Flight;
class Map;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg;
#endif
class Game
{
public:
	enum {START = 0, SELF_EFFECT = 1, REAL_TIME_SKILL = 2, PASSIVE_SKILL_FIRST = 3, MOVE = 4, ONE_ROUND_PASS = 5, FLIGHT = 6, DELAYED_SKILL = 7, PASSIVE_SKILL_SECOND = 8, JUDGE_FINISHED = 9, OUPUT_REPLAY = 10, CLEAN = 11};
	/*
        回合进度
        0:回合开始~获取选手操作,使加技能点等技能生效
        1:技能对施术者作用结算
        2:即时生效技能结算
        3:各类被动技能循环结算
        4:移动阶段
        5:各对象的oneRoundPass
        6:指向型飞行道具命中结算阶段
        7:延时技能释放，包括Buff与Area的终结效果
        8:同3
        9:胜负判定
        10:录像输出
        11:部分对象delete

        */
    virtual void passiveTrigger();//各类被动技能循环结算
    virtual void makeMove();//移动处理
    virtual void init()=0;//初始化
    virtual void roundStart();//回合开始
    virtual void calcTheRound();//计算回合
    virtual void clean();//回合结束，多余对象清除
    virtual void outputReplayInfo(ostream &os);//输出录像信息
    virtual void outAiStatus(ostream &os);
    virtual void setPVCcmd(const Operation &op)=0;
public:
    virtual void getMapAndPlayer(int MaxRound,const char* FileName)=0;//得到地图
    virtual void getPlayerInfo();//获取各阵营（同阵营各选手信息共享）信息，包括视野计算
    virtual void getPlayerCmd();//获取选手操作
    virtual int winnerJudge()=0;
    virtual Unit* findUnitById(int ID);
    virtual Unit* findUnitByPos(Pos POS);
    Game();
    virtual ~Game();
    virtual void oneRoundRun();
    virtual int getNewId(string Name);
    virtual void addId(int ID,string Name);
public:
    virtual void addFlight(Flight* flight){flights.push_back(flight);}
    virtual void addArea(Area* area){areas.push_back(area);}
    virtual void addUnit(Unit* unit){units.push_back(unit);}
    virtual void addCmd(PCommand* cmd){cmds.push_back(cmd);}
    virtual void addInfo(PlayerInfo* info){infos.push_back(info);}
    virtual void addActMaker(ActMaker* actMaker){actMakers.push_back(actMaker);}
    virtual void setMode(int Mode);
public:
    Map* getMap(){return map;}
    vector<Unit*>& getUnits(){return units;}
    int getRound(){return round;}
    int getRoundProcess(){return roundProcess;}
    int getPlayerNum(){return playerNum;}
    int getCampNum(){return campNum;}
    int getMaxRound(){return maxRound;}
    vector<PlayerInfo*> getPlayerInfos(){return infos;}
protected:
    void deduplicateCmd (PCommand* cmds);
protected:
    int round;
    int maxRound;
    int playerNum;
    int campNum;
    int roundProcess;
    ofstream fout;
    vector<Unit*> units;
    vector<Flight*> flights;
    vector<Area*> areas;
    vector<ActMaker*> actMakers;
    vector<PCommand*> cmds;
    vector<PlayerInfo*> infos;
    vector<int> playerCamp;
    Map* map;
    int winner;
    vector<pair<string,bool> > ids;
    int mode;
};

#endif//GAME_H

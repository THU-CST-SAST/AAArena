//本文件包含游戏中可能用到的所有常数
//请大致浏览一遍主要内容
#ifndef CONST_H
#define CONST_H
#ifndef _AI__
#include "../Pos.h"
#else
#include "Pos.h"
#endif//_AI__
//#include "sdk.h"
//#endif//_AI_
#include <string>
#include <vector>
#include <math.h>

const int dir[4][2] = {{0, -1}, {-1, 0}, {1, 0}, {0, 1}};       //四连通方向
const int MAP_SIZE = 150;                                       //地图大小
const int MAX_ROUND = 1000;                                     //最大回合数
const int BASE_GOLD = 1024;                                     //基础金钱

 /************************************************
 *游戏中各种元素的名称列表，每个名称的下标即为其类型编号(typeId)
 *El Dorado不推荐使用typeId的方式进行操作，我们更加希望你直接使用字符串。
 ************************************************/
 //名称列表大小
static const int AREA_NAME_SIZE = 0;
static const int ARGS_NAME_SIZE = 12;
static const int BUFF_NAME_SIZE = 10;
static const int FLIGHT_NAME_SIZE = 0;
static const int SKILL_NAME_SIZE = 15;
static const int UNIT_NAME_SIZE = 14;
static const int OPERATION_NAME_SIZE = 14;

static const char* AREA_NAME[AREA_NAME_SIZE] = {};
static const char* ARGS_NAME[ARGS_NAME_SIZE] = {"Hp", "Mp", "Exp", "Speed", "View", "Atk", "Def", "Range", "LastHit", "OnlyTarget", "Gold", "Energy"};
static const char* BUFF_NAME[BUFF_NAME_SIZE] = {"Dizzy", "Reviving", "WaitRevive", "ChosenByBase", "BuyBackByBase", "CallBackByBase", "LevelUpByBase", "IsMining", "BeAttacked", "WinOrDie"};
static const char* FLIGHT_NAME[FLIGHT_NAME_SIZE] = {};
static const char* SKILL_NAME[SKILL_NAME_SIZE] = {"Attack", "ChooseHammerguard", "ChooseBerserker", "ChooseMaster", "ChooseScouter", "BuyHeroLevel", "BuyBackHero", "CallBackHero", "HammerAttack", "Blink", "Cure", "Sacrifice", "SuperDead", "SetObserver", "Plunder"};
static const char* UNIT_NAME[UNIT_NAME_SIZE] = {"MilitaryBase", "Mine", "PlayerInformation", "Hammerguard", "Master", "Berserker", "Scouter", "Dog", "Bow", "Wolf", "StoneMan", "Dragon", "Roshan","Observer"};
static const char* OPERATION_NAME[OPERATION_NAME_SIZE] = {"Attack", "Stop", "Move", "ChooseHammerguard", "ChooseMaster", "ChooseBerserker", "ChooseScouter", "BuyHeroLevel", "BuyBackHero", "CallBackHero", "HammerAttack", "Sacrifice", "Blink", "SetObserver"};

/************************************************
 *特殊单位的位置，包括基地，金矿，野怪（出生位置）
 ************************************************/

static const Pos MILITARY_BASE_POS[] = {Pos(15, 5), Pos(135, 145)};
static const Pos MINE_POS[] = {Pos(74, 75), Pos(43, 61), Pos(43, 89), Pos(107, 61), Pos(107, 89), Pos(20, 140), Pos(130, 10)};
static const Pos Dragon_pos[] = {Pos(38, 61), Pos(112, 89), Pos(24, 138), Pos(126, 12)};
static const Pos Roshan_pos[] = {Pos(38, 89), Pos(112, 61)};

/************************************************
 *除基地外均使用此常数计算
 ************************************************/
static const double HP_RECOVER_RATE = 0.01;             //生命值回复速度
static const double RECOVER_RATE = 0.01;             //魔法值回复速度



/************************************************
 *基地的相关参数
 ************************************************/
static const int MILITARY_BASE_NUM = 2;                       //基地数
static const int MILITARY_BASE_ATTACK_MAXCD = 1;
static const int MILITARY_BASE_HP = 3000;
static const int MILITARY_BASE_ATK = 50;
static const int MILITARY_BASE_DEF = 20;
static const int MILITARY_BASE_RANGE = 144;
static const int MILITARY_BASE_VIEW = 144;
static const int MILITARY_RATE_HP = 1;//基地的生命值恢复速率

/************************************************
 *金矿的相关参数
 ************************************************/
static const int MINE_NUM = 7;                      //金矿数
const int MINE_NUM_AVAILABLE = 5;                   //任意时间可用金矿数
const int EXIST_TIME_MAX = 50;                       //金矿最长连续可用时间
const int EXIST_TIME_MIN = 20;
static const int MINE_HP = 10000;
static const int MINE_MP = 0;
static const int MINE_ATK = 0;
static const int MINE_DEF = 10000;
static const int MINE_RANGE = 0;
static const int MINE_SPEED = 0;
static const int MINE_ATTACK_MAXCD = MAX_ROUND;
static const int MINE_BASE_GOLD = 10000;
static const int MINE_VIEW = 16;
static const int MINE_VOLUME = 2;                    //体积，表示金矿为半径为2格，直径为3格的圆形。

/************************************************
 *观察守卫的相关参数
 ************************************************/
static const int OBSERVER_HP = 50;
static const int OBSERVER_DEF = 200;
static const int OBSERVER_VIEW = 400;
 
/************************************************
 *野怪们的相关参数
 ************************************************/
static const int Dog_HP = 250;
static const int Dog_ATK = 25;
static const int Dog_DEF = 10;
static const int Dog_SPEED = 16;
static const int Dog_RANGE = 9;
static const int Dog_VIEW = 144;
static const int Dog_ATTACK_MAXCD = 2;
static const int Dog_LEVEL = 1;
static const int Dog_REVIVING_TIME = (Dog_LEVEL + 1) * 5;
static const int Bow_HP = 280;
static const int Bow_ATK = 35;
static const int Bow_DEF = 0;
static const int Bow_SPEED = 16;
static const int Bow_RANGE = 81;
static const int Bow_VIEW = 144;
static const int Bow_ATTACK_MAXCD = 2;
static const int Bow_LEVEL = 1;
static const int Bow_REVIVING_TIME = (Bow_LEVEL + 1) * 5;
static const int Wolf_HP = 350;
static const int Wolf_ATK = 42;
static const int Wolf_DEF = 12;
static const int Wolf_SPEED = 16;
static const int Wolf_RANGE = 9;
static const int Wolf_VIEW = 144;
static const int Wolf_ATTACK_MAXCD = 1;
static const int Wolf_LEVEL = 3;
static const int Wolf_REVIVING_TIME = (Wolf_LEVEL + 1) * 5;
static const int StoneMan_HP = 550;
static const int StoneMan_ATK = 35;
static const int StoneMan_DEF = 25;
static const int StoneMan_SPEED = 12;
static const int StoneMan_RANGE = 9;
static const int StoneMan_VIEW = 144;
static const int StoneMan_ATTACK_MAXCD = 2;
static const int StoneMan_LEVEL = 3;
static const int StoneMan_REVIVING_TIME = (StoneMan_LEVEL + 1) * 5;
static const int Dragon_HP = 800;
static const int Dragon_ATK = 80;
static const int Dragon_DEF = 10;
static const int Dragon_SPEED = 12;
static const int Dragon_RANGE = 81;
static const int Dragon_VIEW = 144;
static const int Dragon_ATTACK_MAXCD = 2;
static const int Dragon_LEVEL = 5;
static const int Dragon_REVIVING_TIME = (Dragon_LEVEL + 1) * 5;
static const int Roshan_HP = 1200;
static const int Roshan_ATK = 65;
static const int Roshan_DEF = 25;
static const int Roshan_SPEED = 12;
static const int Roshan_RANGE = 9;
static const int Roshan_VIEW = 144;
static const int Roshan_ATTACK_MAXCD = 2;
static const int Roshan_LEVEL = 5;
static const int Roshan_REVIVING_TIME = (Roshan_LEVEL + 1) * 5;

/************************************************
 *英雄们的相关参数
 ************************************************/
static const int HAMMERGUARD_BASE_HP = 400;
static const int HAMMERGUARD_MP = 200;
static const int HAMMERGUARD_BASE_ATK = 50;
static const int HAMMERGUARD_BASE_DEF = 10;
static const int HAMMERGUARD_SPEED = 25;
static const int HAMMERGUARD_RANGE = 8;
static const int HAMMERGUARD_VIEW = 144;
static const int HAMMERGUARD_HP_DELTA = 30;
static const int HAMMERGUARD_ATK_DELTA = 8;
static const int HAMMERGUARD_DEF_DELTA = 2;
static const int HAMMERGUARD_ATTACK_MAXCD = 2;
static const int HAMMERGUARD_MINE_ABILITY = 10;

static const int MASTER_BASE_HP = 270;
static const int MASTER_MP = 200;
static const int MASTER_BASE_ATK = 25;
static const int MASTER_BASE_DEF = 5;
static const int MASTER_SPEED = 12;
static const int MASTER_RANGE = 36;
static const int MASTER_VIEW = 144;
static const int MASTER_HP_DELTA = 30;
static const int MASTER_ATK_DELTA = 4;
static const int MASTER_DEF_DELTA = 1;
static const int MASTER_ATTACK_MAXCD = 1;
static const int MASTER_MINE_ABILITY = 10;


static const int BERSERKER_BASE_HP = 300;
static const int BERSERKER_MP = 0;
static const int BERSERKER_BASE_ATK = 30;
static const int BERSERKER_BASE_DEF = 10;
static const int BERSERKER_SPEED = 25;
static const int BERSERKER_RANGE = 8;
static const int BERSERKER_VIEW = 144;
static const int BERSERKER_HP_DELTA = 40;
static const int BERSERKER_ATK_DELTA = 8;
static const int BERSERKER_DEF_DELTA = 3;
static const int BERSERKER_RANGE_DELTA = 4;
static const int BERSERKER_ATTACK_MAXCD = 3;
static const int BERSERKER_MINE_ABILITY = 10;

static const int SCOUTER_BASE_HP = 250;
static const int SCOUTER_MP = 200;
static const int SCOUTER_BASE_ATK = 25;
static const int SCOUTER_BASE_DEF = 10;
static const int SCOUTER_SPEED = 36;
static const int SCOUTER_RANGE = 36;
static const int SCOUTER_VIEW = 144;
static const int SCOUTER_HP_DELTA = 30;
static const int SCOUTER_ATK_DELTA = 4;
static const int SCOUTER_DEF_DELTA = 3;
static const int SCOUTER_ATTACK_MAXCD = 1;
static const int SCOUTER_MINE_ABILITY = 10;


/************************************************
 *与技能相关的参数
 ************************************************/
static const int MINING_RANGE = MINE_VIEW;         //英雄采矿范围
static const float DEATH_FACTOR = 0.4;             //英雄击杀基本金钱 = 英雄原价 * 该系数
static const float DEATH_DELTA_FACTOR = 0.05;      //英雄击杀额外金钱 = 双方经济差额 * 该系数

static const int DIZZY_TIME[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

//========================
static const int FLIGHT_WHATEVER_RANGE = 36;
static const int FLIGHT_WHATEVER_SPEED = 25;

static const double SLOW_SPEED_DELTA_RATE = -0.75;        //减速75%，同上
static const int SLOW_TIME = 4;
//=======================================================
static const int WINORDIE_TIME = 5;


static const int HAMMERATTACK_RANGE = 36;
static const int HAMMERATTACK_DAMAGE[]= {80,110,140,170,200,230};
static const int HAMMERATTACK_MP = 100;
static const int HAMMERATTACK_MAXCD = 10;
static const int HAMMERATTACK_DIZZY = 3;

static const int EARTHSHAKE_RANGE = 36;
static const int EARTHSHAKE_DAMAGE[]={20,25,30,35,40,45};
static const int EARTHSHAKE_MP = 140;
static const int EARTHSHAKE_MAXCD = 20;
static const int EARTHSHAKE_SING_TIME = 3;

static const int BLINK_RANGE = 81;
static const int BLINK_MP = 80;
static const int BLINK_MAXCD = 20;

static const int CURE_RANGE = 121;
static const double HEALTHY_HP_CURE_RATE[] = {0.01, 0.02, 0.02, 0.03, 0.03, 0.04};
static const double SICK_HP_CURE_RATE[] = {0.00, 0.00, 0.01, 0.01, 0.02, 0.02};

static const int SACRIFICE_RANGE = 0;
static const int SACRIFICE_MP = 0;
static const int SACRIFICE_MAXCD = 30;

static const int REVENGE_RANGE = 0;
static const int REVENGE_MP = 100;
static const int REVENGE_MAXCD = 2;
static const double REVENGE_RATE = 0.5;

static const int SET_OBSERVER_RANGE = 25;
static const int SET_OBSERVER_MP = 50;
static const int SET_OBSERVER_MAXCD[] = {50,44,38,32,26,20};

static const int PLUNDER_GOLD_HERO[] = {1,2,3,4,5,6};
static const int PLUNDER_GOLD_BASE[] = {10,12,14,16,18,20};

static const int STING_DAMAGE[] = {10,12,14,16,18,20};

static const int WAITREVIVE_HP = 99999;
static const int WAITREVIVE_ATK_TIMES = 1;
static const int SUPERDEAD_ROUND_TIMES = 8;
static const int SUPERDEAD_MAXCD = 30;

//花费金钱 （花费金钱 = 英雄等级 * PER_LEVEL + BASE）
static const int BUYBACK_COST_PER_LEVEL = 50, BUYBACK_COST_BASE = 100;    //买活
static const int BUYBACK_RANGE = 64;
static const int CALLBACK_COST_PER_LEVEL = 30, CALLBACK_COST_BASE = 50;    //召回
static const int CALLBACK_RANGE = 144;
static const int LEVELUP_COST_PER_LEVEL = 50, LEVELUP_COST_BASE = 100;    //升级
static const int LEVELUP_RANGE = 144;
static const int NEW_HAMMERGUARD_COST = 250;
static const int NEW_MASTER_COST = 250;
static const int NEW_BERSERKER_COST = 250;
static const int NEW_SCOUTER_COST = 250;
static const int BUY_NEW_HERO_RANGE = 144;                                //购买新英雄
static const int HERO_LIMIT = 8;
static const int HERO_LEVEL_LIMIT = 5;


//其它参数
static const int MOVE_HEIGHT_DELTA = 1;                                    //移动高度差限制
static const int ATTACK_MIN_DAMAGE = 5;                                    //普通攻击最低伤害值
static const double EXP_SHARE_RATE = 0.5;                                  //周围单位分享的经验值比例
static const int EXP_SHARE_RANGE = 100;                                    //分享经验值范围
static const int HERO_INITIAL_LEVEL = 0;                                   //英雄初始等级
static const int HERO_MAX_LEVEL = HERO_LEVEL_LIMIT;                                                      //英雄最高等级
static const int SKILL_INITIAL_LEVEL = -1;                                 //英雄技能初始等级（未分配技能点）
static const int SKILL_MAX_LEVEL = HERO_LEVEL_LIMIT;                                                     //英雄技能最高等级
static const int HURT_LAST_TIME = 3; //被攻击后BeAttacked的Buff的持续时间

//集成单位参数信息类的定义
struct UNIT_ARGS                                                                         //单位属性参数，同时用于野怪属性参数信息
{
    int TYPE_ID;                                                                         //类型编号
    std::string NAME;                                                                         //名称
    int HP;                                                                              //生命值，在HeroArgs中表示初始生命值
    int ATK;                                                                             //攻击力，在HeroArgs中表示初始攻击力
    int DEF;                                                                             //防御力，在HeroArgs中表示初始防御力
    int SPEED;                                                                           //速度（对SpecialUnitArgs无效）
    int RANGE;                                                                           //射程
    int LEVEL;                                                                           //固定等级，英雄无固定等级
    int VIEW;                                                                            //视野
    int ATTACK_MAXCD;                                                                    //攻速
    int REVIVING_TIME;                                                                   //复活回合数（对SpecialUnitArgs无效）
    std::vector<Pos> POS_LIST;                                                                //位置列表（对HeroArgs无效）

protected:
    UNIT_ARGS(int _TYPE_ID, int _HP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _VIEW, int _ATTACK_MAXCD);
    void newPos(Pos _);                                                                  //添加位置
public:
    UNIT_ARGS(int _TYPE_ID, int _HP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _LEVEL, int _VIEW, int _ATTACK_MAXCD,
              int _TIME, const Pos* _BEGIN, const Pos* _END);

};

struct HERO_ARGS : public UNIT_ARGS                                                      //英雄属性参数信息
{
    int MP;                                                                              //魔法值
    int HP_DELTA;                                                                        //生命成长值
    int ATK_DELTA;                                                                       //攻击力成长值
    int DEF_DELTA;                                                                       //防御力成长值

    HERO_ARGS(int _TYPE_ID, int _HP, int _MP, int _ATK, int _DEF, int _SPEED, int _RANGE, int _VIEW, int _ATTACK_MAXCD,
              int _HP_DELTA, int _ATK_DELTA, int _DEF_DELTA);

    inline int CURRENT_LEVEL_HP(int _LEVEL)                                              //返回等级为_LEVEL时的生命值
    {
        return HP + _LEVEL * HP_DELTA;
    }

    inline int CURRENT_LEVEL_ATK(int _LEVEL)                                             //返回等级为_LEVEL时的攻击力
    {
        return ATK + _LEVEL * ATK_DELTA;
    }

    inline int CURRENT_LEVEL_DEF(int _LEVEL)                                             //返回等级为_LEVEL时的防御力
    {
        return DEF + _LEVEL * DEF_DELTA;
    }

    inline static int EXP_FOR_LEVELUP(int _LEVEL)                                        //返回从_LEVEL级升到(_LEVEL+1)级所需经验，与英雄种类无关
    {
        return 100 + _LEVEL * 25;
    }

    inline static int CURRENT_LEVEL_REVIVING_TIME(int _LEVEL)                            //返回等级为_LEVEL时的复活时间，与英雄种类无关
    {
        return 7 * (_LEVEL + 2);
    }

    inline static int CURRENT_LEVEL_EXP(int _LEVEL)                                      //返回等级为_LEVEL时的死亡分配经验值，与英雄种类无关
    {
        return 50 + _LEVEL * 50;
    }
};

struct SPECIAL_UNIT_ARGS : public UNIT_ARGS                                              //特殊单位属性参数信息
{
    int PLAYER;                                                                          //所属玩家

    SPECIAL_UNIT_ARGS(int _PLAYER, int _TYPE_ID, int _HP, int _ATK, int _DEF, int _RANGE, int _VIEW, int _MAXCD, const Pos* _BEGIN, const Pos* _END);
};

//以下均为集成的单位参数信息，供某些场合简便调用
#ifndef _ANALYSER_
//英雄
static const HERO_ARGS HEROES[] = {
	HERO_ARGS(3, HAMMERGUARD_BASE_HP, HAMMERATTACK_MP, HAMMERGUARD_BASE_ATK, HAMMERGUARD_BASE_DEF, HAMMERGUARD_SPEED, HAMMERATTACK_RANGE, HAMMERGUARD_VIEW, HAMMERGUARD_ATTACK_MAXCD,HAMMERGUARD_HP_DELTA, HAMMERGUARD_ATK_DELTA, HAMMERGUARD_DEF_DELTA),
    HERO_ARGS(4, MASTER_BASE_HP, MASTER_MP, MASTER_BASE_ATK, MASTER_BASE_DEF, MASTER_SPEED, MASTER_RANGE, MASTER_VIEW, MASTER_ATTACK_MAXCD,MASTER_HP_DELTA, MASTER_ATK_DELTA, MASTER_DEF_DELTA),
    HERO_ARGS(5, BERSERKER_BASE_HP, BERSERKER_MP, BERSERKER_BASE_ATK, BERSERKER_BASE_DEF, BERSERKER_SPEED, BERSERKER_RANGE, BERSERKER_VIEW, BERSERKER_ATTACK_MAXCD,BERSERKER_HP_DELTA, BERSERKER_ATK_DELTA, BERSERKER_DEF_DELTA),
    HERO_ARGS(6, SCOUTER_BASE_HP, SCOUTER_MP, SCOUTER_BASE_ATK, SCOUTER_BASE_DEF, SCOUTER_SPEED, SCOUTER_RANGE, SCOUTER_VIEW, SCOUTER_ATTACK_MAXCD,SCOUTER_HP_DELTA, SCOUTER_ATK_DELTA, SCOUTER_DEF_DELTA)
};

//特殊单位
static const SPECIAL_UNIT_ARGS SPECIAL_UNITS[] = {
	SPECIAL_UNIT_ARGS(0, 0, MILITARY_BASE_HP, MILITARY_BASE_ATK, MILITARY_BASE_DEF, MILITARY_BASE_RANGE, MILITARY_BASE_VIEW, MILITARY_BASE_ATTACK_MAXCD, MILITARY_BASE_POS + 0, MILITARY_BASE_POS + 1),
    SPECIAL_UNIT_ARGS(1, 0, MILITARY_BASE_HP, MILITARY_BASE_ATK, MILITARY_BASE_DEF, MILITARY_BASE_RANGE, MILITARY_BASE_VIEW, MILITARY_BASE_ATTACK_MAXCD, MILITARY_BASE_POS + 0, MILITARY_BASE_POS + 1),
    SPECIAL_UNIT_ARGS(2, 1, MINE_HP, MINE_ATK, MINE_DEF, MINE_RANGE, MINE_VIEW, MINE_ATTACK_MAXCD, MINE_POS + 0, MINE_POS + MINE_NUM)
};

//野怪
static const UNIT_ARGS MONSTERS[] = {
    //TODO

	/*(6, Dog_HP, Dog_ATK, Dog_DEF, Dog_SPEED, Dog_RANGE, Dog_LEVEL, Dog_VIEW, Dog_ATTACK_MAXCD, Dog_REVIVING_TIME,
        Dog_pos, Dog_pos + sizeof(Dog_pos) / sizeof(Pos)),
    UNIT_ARGS(7, Bow_HP, Bow_ATK, Bow_DEF, Bow_SPEED, Bow_RANGE, Bow_LEVEL, Bow_VIEW, Bow_ATTACK_MAXCD, Bow_REVIVING_TIME,
        Bow_pos, Bow_pos + sizeof(Bow_pos) / sizeof(Pos)),
    UNIT_ARGS(8, Wolf_HP, Wolf_ATK, Wolf_DEF, Wolf_SPEED, Wolf_RANGE, Wolf_LEVEL, Wolf_VIEW, Wolf_ATTACK_MAXCD, Wolf_REVIVING_TIME,
        Wolf_pos, Wolf_pos + sizeof(Wolf_pos) / sizeof(Pos)),
    UNIT_ARGS(9, StoneMan_HP, StoneMan_ATK, StoneMan_DEF, StoneMan_SPEED, StoneMan_RANGE, StoneMan_LEVEL, StoneMan_VIEW, StoneMan_ATTACK_MAXCD, StoneMan_REVIVING_TIME,
        StoneMan_pos, StoneMan_pos + sizeof(StoneMan_pos) / sizeof(Pos)),*/
    UNIT_ARGS(10, Dragon_HP, Dragon_ATK, Dragon_DEF, Dragon_SPEED, Dragon_RANGE, Dragon_LEVEL, Dragon_VIEW, Dragon_ATTACK_MAXCD, Dragon_REVIVING_TIME,
        Dragon_pos, Dragon_pos + sizeof(Dragon_pos) / sizeof(Pos)),
    UNIT_ARGS(11, Roshan_HP, Roshan_ATK, Roshan_DEF, Roshan_SPEED, Roshan_RANGE, Roshan_LEVEL, Roshan_VIEW, Roshan_ATTACK_MAXCD, Roshan_REVIVING_TIME,
        Roshan_pos, Roshan_pos + sizeof(Roshan_pos) / sizeof(Pos))

};
#endif //_ANALYSER_
#endif //CONST_H

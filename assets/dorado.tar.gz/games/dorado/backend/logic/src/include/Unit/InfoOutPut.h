#ifndef INFO_OUTPUT_H
#define INFO_OUTPUT_H
#include "Unit.h"
class InfoOutPut:public Unit
{
public:
	InfoOutPut(Game* Gm,int Camp,int Player,int ID,Pos Ps);
	virtual void output(ostream &os);
};
#endif //INFO_OUTPUT_H
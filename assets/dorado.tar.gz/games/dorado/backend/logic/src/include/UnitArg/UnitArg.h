#ifndef UNITARG_H
#define UNITARG_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
struct PCommand;
class Flight;
class Game;
class Map;
struct Operation;
class PlayerInfo;
class Skill;
class Unit;
class UnitArg
{
public:
    UnitArg(const char *myName, Unit* myUnit);
    int getVal(int no=0);//获取数值
    inline int valSize() {return val.size();}
    virtual void oneRoundPass();//参数生效，如生命值回复速率，法力回复速率等
    virtual void roundStart();//回合初始，无视所有buff
    virtual void change(int no,int newValue);//数值变化,可能引起事件，如升级等
    virtual void add(int no,int deltaValue);
    virtual void output(ostream &os, bool = false)=0;//输出
    virtual void check(){}

    virtual string toString();
    virtual ~UnitArg(){}
public:
    string getName(){return name;}
protected:
    string name;//变量名称
    vector<int> val;//存储某一属性的多个变量，如hp，会有最大hp值，hp回复速率，剩余hp值等
    Unit* unit;
};
class Hp:public UnitArg
{
public:
    Hp(int Origin, int Rate, Unit* myUnit);
    virtual void roundStart();
    virtual void oneRoundPass();
    virtual void output(ostream &os, bool = false);
    virtual void check();
    virtual ~Hp(){}
};
class Mp:public UnitArg
{
public:
    Mp(int Origin, int Rate, Unit* myUnit);
    virtual void roundStart();
    virtual void oneRoundPass();
    virtual void output(ostream &os, bool = false);
    virtual void check();
    virtual ~Mp(){}
};
class Exp:public UnitArg
{
public:
    Exp(int nextLevel,int level,int skillPoint,int DeadExp,Unit* myUnit);//当前经验值，升一级要达到的经验，当前等级，当前剩余技能点
    virtual void output(ostream &os, bool = false);
    virtual ~Exp(){}
};
class Speed:public UnitArg
{
public:
	Speed(int Origin,Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual ~Speed(){}
};
class View:public UnitArg
{
public:
    View(int Origin,Unit* myUnit,int Detector=0);
    virtual void output(ostream &os, bool = false);
    virtual ~View(){}
};
class Atk:public UnitArg
{
public:
	Atk(int Origin,Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual void add(int no, int deltaValue);
    virtual ~Atk(){}
};
class Def:public UnitArg
{
public:
	Def(int Origin,Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual void add(int no, int deltaValue);
    virtual ~Def(){}
};
class Range:public UnitArg
{
public:
	Range(int Origin,int Fly,Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual ~Range(){}
};
class LastHit:public UnitArg
{
public:
    LastHit(Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual ~LastHit(){}
};
class OnlyTarget:public UnitArg
{
public:
    OnlyTarget(Unit* myUnit);
    virtual void output(ostream &os, bool = false);
    virtual ~OnlyTarget(){}
};
class Gold:public UnitArg
{
public:
    enum {Total = 0, Ability = 1};
    Gold(int Total = 0, int Ability = 0, Unit* = NULL);
    virtual void output(ostream &os, bool = false) {}
    virtual ~Gold() {}
};

class Energy:public UnitArg
{
public:
    enum {ExistTime = 0};
    Energy (Unit* = NULL);
    virtual void output (ostream& os, bool = false);
    virtual void oneRoundPass ();
    virtual void roundStart ();
    virtual ~Energy () {}
};
#endif//UNITARG_H

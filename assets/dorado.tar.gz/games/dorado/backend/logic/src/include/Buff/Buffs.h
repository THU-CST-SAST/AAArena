#ifndef BUFFS_H
#define BUFFS_H

#include "Buff.h"

/*
class Hided:public Buff
{
public:
    virtual bool remove();
    virtual void work();
    virtual void terminate();
    Hided(Unit *myUnit,int Level);
    virtual ~Hided(){}
protected:
    int delta;
    bool end;
};

class Rainy:public Buff
{
public:
    virtual void work();
    virtual void oneRoundPass();
    virtual void terminate();
    Rainy(Unit *myUnit,int Level,int UnitId);
    virtual void overlap(Buff *buff);
    virtual ~Rainy(){}
protected:
    int spd;
    int delta;
    int shooterId;
};
class Yelled:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Yelled(Unit *myUnit,int Level,int ID);
    virtual void overlap(Buff *buff);
    virtual ~Yelled(){}
protected:
    int targetId;
};

class Yelling:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Yelling(Unit *myUnit,int Level);
    virtual ~Yelling(){}
};
*/

class Dizzy:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Dizzy(Unit *myUnit,int Level);
    virtual ~Dizzy(){}
};

/*
class Striking:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Striking(Unit *myUnit,int Level);
    virtual ~Striking(){}
};
*/

class Reviving:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Reviving(Unit *myUnit,int TimeLeft);
    virtual ~Reviving(){}
};


class Slow:public Buff//速度减少当前速度的25%，buff消除后将这部分速度加回
{
public:
    virtual void work();
    virtual void terminate();
    Slow(Unit *myUnit,int Level);
    virtual void overlap(Buff *buff);
    virtual ~Slow(){}
protected:
    int delta;
};
/*
class Cure:public Buff
{
public:
    virtual void oneRoundPass();
    Cure(Unit *myUnit);
    virtual ~Cure(){}
};
*/
int skillReduce(std::string name);
/*
class Icy:public Buff
{
public:
    virtual void work();
    virtual void oneRoundPass();
    virtual void terminate();
    Icy(Unit *myUnit,int Level,int UnitId);
    virtual void overlap(Buff *buff);
    virtual ~Icy(){}
protected:
    int spd;
    int delta;
    int shooterId;
};

class Ice:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Ice(Unit *myUnit,int Level);
    virtual void overlap(Buff *buff);
    virtual ~Ice(){}
protected:
    int delta;
};
*/
class Singing: public Buff
{
    typedef void (*SkillEffect) (Unit*);
public:
    Singing(Unit *myUnit, std::string name, int time, SkillEffect func, Unit* unit);
    virtual ~Singing();
    virtual void work();
    virtual void terminate();
    virtual void output (ostream& os);
protected:
    Unit* unit;
    void (*fp)(Unit*);
    std::string actionName;
};

class WaitRevive: public Buff
{
public:
    WaitRevive(Unit *myUnit,int time);
    virtual ~WaitRevive();
    virtual void work();
    virtual void terminate();
protected:
    int init_atk_times;
};

class WinOrDie: public Buff
{
public:
    WinOrDie (Unit *unit, int time, int hd, int ai);
    virtual ~WinOrDie ();
    virtual void work ();
    virtual void terminate ();
private:
    int hpDecrease;
    int attackIncrease;
};

class BeAttacked: public Buff
{
public:
    BeAttacked(Unit *myUnit, int time);
    virtual void work();
    virtual void terminate();
    virtual ~BeAttacked();
};

//用于跟播放器对接的临时buff

class ChosenByBase:public Buff
{
public:
    ChosenByBase(Unit *myUnit);
    virtual ~ChosenByBase(){}
};

class BuyBackByBase:public Buff
{
public:
    BuyBackByBase(Unit *myUnit);
    virtual ~BuyBackByBase(){}
};

class CallBackByBase:public Buff
{
public:
    CallBackByBase(Unit *myUnit);
    virtual ~CallBackByBase(){}
};

class LevelUpByBase:public Buff
{
public:
    LevelUpByBase(Unit *myUnit);
    virtual ~LevelUpByBase(){}
    virtual void overlap(Buff* buff);
};

class IsMining: public Buff
{
public:
    IsMining (Unit* unit, int inc);
    virtual ~IsMining () {};
    virtual void output (ostream&);
private:
    int inc;
};

#endif//BUFFS_H

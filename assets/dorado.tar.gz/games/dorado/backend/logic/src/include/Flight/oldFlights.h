#ifndef AI9_2015_FLIGHTS_H
#define AI9_2015_FLIGHTS_H

#include "Flight.h"
#include "../Unit/Unit.h"
#include "../Pos.h"
class Game;
class FlightBlade : public Flight
{
public:
    virtual void roundStart();
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    FlightBlade(Game* Gm,int UnitID,int Id,int Camp,Pos Start,int TargetId,int Level);
    virtual ~FlightBlade(){}
protected:
    int level;
    int targetId;
    bool hit;//命中与否
};

class SignalArrow : public Flight
{
public:
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    SignalArrow(Game* Gm,int UnitID,int Id,int Camp,Pos Start,Pos TargetPos,int Level);
    virtual ~SignalArrow(){}
protected:
    int level;
};


class FlightExam : public Flight
{
public:
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    FlightExam(Game* Gm,int UnitID,int Id,int Camp,Pos Start,Pos TargetPos,int Level, Unit* unit, int mp_delta);
    virtual ~FlightExam(){}
protected:
    int level;
    Unit* unit;
    int mp_delta;
};

class FlightIce : public Flight
{
public:
    virtual void roundStart();
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    FlightIce(Game* Gm,int UnitID,int Id,int Camp,Pos Start,int TargetId,int Level);
    virtual ~FlightIce(){}
protected:
    int level;
    int targetId;
    bool hit;//命中与否
};

class FlightWhatever : public Flight
{
public:
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    FlightWhatever(Game* Gm,int UnitID,int Id,int Camp,Pos Start,Pos TargetPos,int Level, Unit* unit);
    virtual ~FlightWhatever(){}
protected:
    int level;
    Unit* unit;
};


#endif//AI9_2015_FLIGHTS_H
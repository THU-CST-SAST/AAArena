#ifndef AI9_2016_ElDorado_H
#define AI9_2016_ElDorado_H

#include "Game.h"

class ElDorado : public Game
{
public:
    ElDorado();
    virtual void getMapAndPlayer(int MaxRound,const char* FileName);
    virtual void init();
    virtual int winnerJudge();
    virtual void setMode(int Mode);
    virtual ~ElDorado(){}
    void setPVCcmd(const Operation &op);
};

#endif//AI9_2016_ElDorado_H
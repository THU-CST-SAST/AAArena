#ifndef FRAME_H
#define FRAME_H

//#include "logic.hh"
#include "Game/Game.h"
#include "PlayerInfo/PlayerInfo.h"
#include "PCommand/PCommand.h"
#include "PCommand/PCommand.h"
#include "ActMaker/ActMaker.h"
#include <vector>
#include <iostream>
#include <fstream>

#define DRAW -2
#define NEXT_TURN -1
// typedef void (*pre_func)(int *config_option, int config_number);
/*
class PrototypeOperation
{
    //empty
};
class PrototypeCmd
{
    int sender_player_id;//发出命令的玩家序号
    std::vector<PrototypeOperation*> _cmds;
public:
    int get_sender_player_id(){return sender_player_id;}
    const std::vector<PrototypeOperation*>*& cmds() {return _cmds;}
};
class PrototypeAI
{
    int ai_id;
    int player_id;
public:
    int get_ai_id(){return ai_id;}
    int get_player_id(){return player_id;}
};

class PrototypePlayer
{
    int player_id;//只知道这是谁= =
    typedef std::vector<PrototypeAI*> ais;//而且手里有ai
public:
    int get_player_id(){return player_id;}
};


class PrototypeInfo//全局信息
{
    int winner_id;

    int round;//回合数 最大回合数留给开发者
    int players_live;//存活玩家数量

    std::vector<PrototypePlayer*> players;//人可控的部分(游戏中一定会有 因此写入框架)
    //由开发者 加入人不可控的部分（例如地图信息 或是 （可能会有的）小兵或NPC）
};
*/
class Loader
{
protected:
    Game* lgc;
public:
    Loader(Game *lgc):lgc(lgc) {}
    virtual void load(int argc,char *argv[])  = 0;
    virtual ~Loader(){}
};
#ifndef _SERVER_
class Loader_local:public Loader
{
public:
    Loader_local(Game* lgc):
        Loader(lgc)
    {
    }
    void load(int argc,char *argv[]);
    virtual ~Loader_local(){}
};
#else
class Loader_web:public Loader
{
public:
    Loader_web(Game* lgc):
        Loader(lgc)
    {
    }
    void load(int argc,char *argv[]);
    virtual ~Loader_web(){}
};
#endif
/*
class Judgement
{
    Game* lgc;
public:
    Judgement(Game *lgc):lgc(lgc) {}
    void judge(const PlayerInfo* info, const PCommand* cmd) ;
};
*/
class Executor
{
public:

    Executor(int Argc, char *Argv[], Game* lgc);
    virtual ~Executor();
    virtual void initLogic(){}//继承之后在此 new 出logic

    void load();//载入ai 做游戏前的准备工作

    void judge();//整个评测过程（就是把logic再封装一遍）
protected:
    Loader *ld;
    //Judgement *jgm;
    // Arranger *arg;
    int argc;
    char **argv;
    Game* lgc;

};

/*
class PrototypeLogic
{
    ofstream fout;
    int player_number;
    int camp_number;
    int max_round;

    // int config_number_before_fight;
    // int* config_option_before_fight;

    std::vector<PrototypePlayer> players;
    std::vector<ActMaker*> actors;
    std::string map_file;

    PrototypeInfo* info;//代表从当前局势中获得的信息
    PrototypeCmd* cmd;//代表从外部代码中获得的信息
public:
    int get_player_number() {return player_number;}
    int get_max_round() {return max_round;}
    int get_camp_number() {return camp_number;}
    std::string get_map_file() {return map_file;}
    // int* get_config_option_before_fight {return config_option_before_fight;}
    // int  get_config_number_before_fight {return config_number_before_fight;}

    std::vector<ActMaker*>*& act_players() {return &actors;}

    PrototypeLogic(int player_number, int max_round, std::string map_file = "map.txt", int camp_number = 0):
        // int config_option_before_fight = NULL, int config_number_before_fight = 0):
        player_number(player_number),
        max_round(max_round),
        map_file(map_file),
        camp_number(camp_number) {}
    // config_option_before_fight(config_option_before_fight),
    // config_number_before_fight(config_number_before_fight) {}

    virtual void init_info();
    //开发者需要在继承游戏逻辑时 new出info 和 cmd
    // 并且修改 config_number_before_fight 和 config_option_before_fight 的值
    //并将info 和 cmd 转换为const

    virtual bool can_move(int ai_id) = 0;
    //开发者必须实现一个讲明ac是否可以执行get_cmd的条件
    virtual void set_mode(int mode);
    //由开发者写入 支持阵营数量和玩家数量的修改

    virtual void write_in_start() = 0;
    virtual void write_in_round() = 0;
    virtual void write_in_end() = 0;
    //由开发者实现 分别在游戏的开始 回合中 结束 向replay里写入信息

    virtual void pre_account() = 0;
    //由开发者实现 在调用选手ai前对全局数值进行修改（如果需要的话）
    virtual void account() = 0;
    //由开发者实现 根据当前info和cmd进行info中某些值的变动
    virtual int winner_id(int now_round) = 0;
    //由开发者写入胜利条件 无人胜利(继续)则返回NEXT_TURN 平局返回DRAW
    void gameover(){fout.close()};
};*/
#endif//FRAME_H

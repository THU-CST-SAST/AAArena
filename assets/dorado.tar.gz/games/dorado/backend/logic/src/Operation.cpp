//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/sdk/const.h"
/*
Operation::Operation(const Operation &_):
	id(_.id)
{
    if (_.typeId >= 0 && _.typeId < OPERATION_NAME_SIZE) {
        typeId = _.typeId;
        type = OPERATION_NAME[typeId];
    } else {
        typeId = -1;
        for (int i=OPERATION_NAME_SIZE-1; i>=0; --i)
            if (_.type == OPERATION_NAME[i]) {
                typeId = i;
                break;
            }
        if (typeId >= 0) type = _.type;
        else type = "Stop";
    }
    targets.clear();
    int _sz = _.targets.size();
    for (int i=0; i<_sz; ++i)
        targets.push_back(_.targets[i]);
}*/

#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Map/Map.h"
#include "include/Game/Game.h"
#include "include/Unit/Heroes.h"
#include "include/Skill/Skills.h"
#include "include/PCommand//Operation.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
#include <vector>
using namespace std;
const int rangeD = 144;

Hero::Hero(Game* Gm,const char* Name,int Camp,int Player,int ID,int Volume,Pos Ps):
    Unit(Gm,Name,Camp,Player,ID,Volume,Ps),beforeDead(-1,-1)
{
    addArg(new LastHit(this));
    addArg(new OnlyTarget(this));
}
void Hero::addBuff(Buff* newBuff)
{
    if(findBuff("Reviving")==NULL)
    {
        int a = ++buffRound[newBuff->getName()];
        if (rand()%a == 0)
            Unit::addBuff(newBuff);
        else delete newBuff;
    }
    else delete newBuff;
}
bool Hero::remove(){return false;}
bool Hero::useSkill()
{
    if(findBuff("Reviving")!=NULL)
        return false;
    if(findBuff("Dizzy")!=NULL && getGame()->getRoundProcess()==1)
        return false;
    if(findBuff("Yelled")!=NULL && getGame()->getRoundProcess()==1)
    {
        Pos foePos = getGame()->findUnitById(findArg("OnlyTarget")->getVal())->getLastPos();
        if( cmd->type=="Attack"
                && cmd->targets.size()==1
                && foePos==cmd->targets[0])
            return Unit::useSkill();
        return false;
    }
    return Unit::useSkill();
}
int Hero::getStatus()
{
    Buff *ptr=findBuff("Reviving");
    if(ptr!=NULL)
        return ptr->getTimeLeft()>0;
    return 0;
}
void Hero::changePos(Pos newPos)
{
    int dx[4] = {1, -1, 0, 0};
    int dy[4] = {0, 0, -1, 1};
    for(int d = 0; true; ++d)
        for (int i = 0; i < 4; ++i)
        {
            Pos tmp(newPos.x + dx[i] * d, newPos.y + dy[i] * d);
            bool ok = true;
            for(auto& ptr: getGame()->getUnits())
            {
                if(ptr->getId() == getId())
                    continue;
                if(dis2(ptr->getPos(), tmp) < (ptr->getVolume() + getVolume() - 1) * (ptr->getVolume() + getVolume() - 1))
                {
                    ok = false;
                    break;
                }
            }
            if (tmp.x < 0 || tmp.x >= MAP_SIZE || tmp.y < 0 || tmp.y >= MAP_SIZE)
                ok = false;
            if (ok)
            {
                if(findBuff("Reviving")!=NULL)
                    beforeDead=pos;
                pos=newPos;
                return;
            }
        }
}
void Hero::output(ostream &os)
{
    bool flag=(beforeDead!=Pos(-1,-1));
    if( flag)
    {
        Pos tmp=pos;
        pos=beforeDead;
        beforeDead=tmp;
    }
    Unit::output(os);
    if(flag)
    {
        Pos tmp=pos;
        pos=beforeDead;
        beforeDead=tmp;
    }
}
void Hero::roundStart()
{
    beforeDead=Pos(-1,-1);
    if(findBuff("Reviving"))
    {
        for(vector<Buff*>::iterator i=buffs.begin();i!=buffs.end();)
            if((*i)->getName()!="Reviving")
                buffs.erase(i);
            else ++i;
    }
    buffRound.clear();
    Unit::roundStart();
}

void Hero::makeOneStep()
{
    if(findBuff("Reviving")||findBuff("Dizzy"))
        return;
    Unit::makeOneStep();
}

void Hero::clean()
{
    if(findBuff("Reviving"))
        for(vector<Buff*>::iterator i=buffs.begin();i!=buffs.end();)
            if((*i)->getName()!="Reviving")
            {
                delete (*i);
                buffs.erase(i);
            }
            else ++i;
    Unit::clean();
}
Dog::Dog(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Dog",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Dog_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Dog_HP, Dog_HP / 100, this));
    addArg(new Atk(Dog_ATK,this));
    addArg(new Def(Dog_DEF,this));
    addArg(new Speed(Dog_SPEED,this));
    addArg(new Range(Dog_RANGE,0,this));
    addArg(new Exp(100,Dog_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}
Bow::Bow(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Bow",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Bow_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Bow_HP, Bow_HP / 100, this));
    addArg(new Atk(Bow_ATK,this));
    addArg(new Def(Bow_DEF,this));
    addArg(new Speed(Bow_SPEED,this));
    addArg(new Range(Bow_RANGE,1,this));
    addArg(new Exp(100,Bow_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}
Wolf::Wolf(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Wolf",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Wolf_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Wolf_HP, Wolf_HP / 100, this));
    addArg(new Atk(Wolf_ATK,this));
    addArg(new Def(Wolf_DEF,this));
    addArg(new Speed(Wolf_SPEED,this));
    addArg(new Range(Wolf_RANGE,0,this));
    addArg(new Exp(100,Wolf_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}
StoneMan::StoneMan(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"StoneMan",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,StoneMan_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(StoneMan_HP, StoneMan_HP / 100, this));
    addArg(new Atk(StoneMan_ATK,this));
    addArg(new Def(StoneMan_DEF,this));
    addArg(new Speed(StoneMan_SPEED,this));
    addArg(new Range(StoneMan_RANGE,0,this));
    addArg(new Exp(100,StoneMan_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}
Dragon::Dragon(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Dragon",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Dragon_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Dragon_HP, Dragon_HP / 100, this));
    addArg(new Atk(Dragon_ATK,this));
    addArg(new Def(Dragon_DEF,this));
    addArg(new Speed(Dragon_SPEED,this));
    addArg(new Range(Dragon_RANGE,1,this));
    addArg(new Exp(100,Dragon_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}
Roshan::Roshan(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Roshan",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Roshan_ATTACK_MAXCD));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Roshan_HP, Roshan_HP / 100, this));
    addArg(new Atk(Roshan_ATK,this));
    addArg(new Def(Roshan_DEF,this));
    addArg(new Speed(Roshan_SPEED,this));
    addArg(new Range(Roshan_RANGE,0,this));
    addArg(new Exp(100,Roshan_LEVEL,0,0,this));
    addArg(new View(rangeD,this));
}

//**************武伟轩 2015.09.23 新增英雄0号,1号,2号,3号****************


Hammerguard::Hammerguard(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Hammerguard",Camp,Player,ID,1,Ps)
{
    addArg(new Hp(HAMMERGUARD_BASE_HP, HAMMERGUARD_BASE_HP / 100, this));
    addArg(new Mp(HAMMERGUARD_MP, HAMMERGUARD_MP / 100, this));
    addArg(new Atk(HAMMERGUARD_BASE_ATK,this));
    addArg(new Def(HAMMERGUARD_BASE_DEF,this));
    addArg(new Speed(HAMMERGUARD_SPEED,this));//20!=9
    addArg(new Range(HAMMERGUARD_RANGE,0,this));
    addArg(new Exp(HERO_ARGS::EXP_FOR_LEVELUP(0),0,1,HERO_ARGS::CURRENT_LEVEL_EXP(0),this));
    addArg(new View(HAMMERGUARD_VIEW,this));
    addArg(new Gold(0, HAMMERGUARD_MINE_ABILITY, this));
    addSkill(new Attack(this,HAMMERGUARD_ATTACK_MAXCD));
    addSkill(new HammerAttack(this));
    addSkill(new Dead(this,Ps));
    addSkill(new Mining(this));
}

Master::Master(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Master",Camp,Player,ID,1,Ps)
{
    addArg(new Hp(MASTER_BASE_HP, MASTER_BASE_HP / 100, this));
    addArg(new Mp(MASTER_MP, MASTER_MP / 100, this));
    addArg(new Atk(MASTER_BASE_ATK,this));
    addArg(new Def(MASTER_BASE_DEF,this));
    addArg(new Speed(MASTER_SPEED,this));
    addArg(new Range(MASTER_RANGE,0,this));
    addArg(new Exp(HERO_ARGS::EXP_FOR_LEVELUP(0),0,1,HERO_ARGS::CURRENT_LEVEL_EXP(0),this));
    addArg(new View(MASTER_VIEW,this));
    addArg(new Gold(0, MASTER_MINE_ABILITY, this));
    addSkill(new Attack(this,MASTER_ATTACK_MAXCD));
    addSkill(new Blink(this));
    addSkill(new Cure(this));
    addSkill(new Mining(this));
    addSkill(new Dead(this,Ps));
}

Berserker::Berserker(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Berserker",Camp,Player,ID,1,Ps)
{
    addArg(new Hp(BERSERKER_BASE_HP, BERSERKER_BASE_HP / 100, this));
    addArg(new Mp(BERSERKER_MP, BERSERKER_MP/ 100, this));
    addArg(new Atk(BERSERKER_BASE_ATK,this));
    addArg(new Def(BERSERKER_BASE_DEF,this));
    addArg(new Speed(BERSERKER_SPEED,this));//20!=9
    addArg(new Range(BERSERKER_RANGE,0,this));
    addArg(new Exp(HERO_ARGS::EXP_FOR_LEVELUP(0),0,1,HERO_ARGS::CURRENT_LEVEL_EXP(0),this));
    addArg(new View(BERSERKER_VIEW,this));
    addArg(new Gold(0, BERSERKER_MINE_ABILITY, this));
    addSkill(new Attack(this, BERSERKER_ATTACK_MAXCD));
    addSkill(new Sacrifice(this));
    addSkill(new SuperDead(this));
    addSkill(new Dead(this, Ps));
    addSkill(new Mining(this));
    //addSkill(new Dead(this,Ps));
}

Scouter::Scouter(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Scouter",Camp,Player,ID,1,Ps)
{
    addArg(new Hp(SCOUTER_BASE_HP, SCOUTER_BASE_HP / 100, this));
    addArg(new Mp(SCOUTER_MP, SCOUTER_MP / 100, this));
    addArg(new Atk(SCOUTER_BASE_ATK,this));
    addArg(new Def(SCOUTER_BASE_DEF,this));
    addArg(new Speed(SCOUTER_SPEED,this));//20!=9
    addArg(new Range(SCOUTER_RANGE,0,this));
    addArg(new Exp(HERO_ARGS::EXP_FOR_LEVELUP(0),0,1,HERO_ARGS::CURRENT_LEVEL_EXP(0),this));
    addArg(new View(SCOUTER_VIEW,this));
    addArg(new Gold(0, SCOUTER_MINE_ABILITY, this));
    addSkill(new Plunder(this,SCOUTER_ATTACK_MAXCD));
    addSkill(new Attack(this,SCOUTER_ATTACK_MAXCD));
    addSkill(new SetObserver(this));
    addSkill(new Mining(this));
    addSkill(new Dead(this,Ps));
}

#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Game/Game.h"
#include "include/Unit/InfoOutPut.h"
#include "include/Skill/Skills.h"
#include "include/PCommand//Operation.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
#include <vector>
#include <iostream>
using namespace std;

InfoOutPut::InfoOutPut(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Unit(Gm,"PlayerInformation",Camp,Player,ID,1,Ps)
{
}

void InfoOutPut::output(ostream &os)
{
    os<<"{";
    os<<"type:Info;";
    os<<"id:"<<id<<";";
    os<<"camp:"<<camp<<";";
    os<<"player:"<<player<<";";
    os<<"name:"<<name<<";";
    os<<"gold:"<<getPlayerInfo()->getGold()<<";";
    os<<"property:"<<getPlayerInfo()->countProperty()<<";";
    os<<"}";
    os<<endl;
}
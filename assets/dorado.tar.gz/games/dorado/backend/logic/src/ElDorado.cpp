#include "include/Game/ElDorado.h"
#include "include/Map/Map.h"
#include "include/Unit/Heroes.h"
#include "include/Unit/Mine.h"
#include "include/Unit/MilitaryBase.h"
#include "include/Unit/InfoOutPut.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/PCommand/PCommand.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Pos.h"
#include "include/sdk/sdk.h"
#define sqr(x) ((x)*(x))
#include "include/sdk/const.h"
#define SIZE(x) (int(x.size()))
void findPVCpath(Map *map, Pos start, Pos dest, std::vector<Pos> &_path)
{
    static int vst[MAP_SIZE][MAP_SIZE];
    static Pos Q[MAP_SIZE * MAP_SIZE + 1], Q_prior[MAP_SIZE][MAP_SIZE];
    static int countF = 0;
    _path.clear();
    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    ++countF;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord+4);

        for (int i=0; i<4; ++i) {
            _1.x = _0.x + dir[dir_ord[i]][0];
            _1.y = _0.y + dir[dir_ord[i]][1];
            if (checkPos(_1) && abs(map->getHeight(_0)- map->getHeight(_1)) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
            }
        }
    }

    if (vst[dest.x][dest.y] == countF) {
        for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    } else _path.push_back(Pos());
}

void ElDorado::setPVCcmd(const Operation &op)
{
//    static Pos b[30000];
//    static int pre[30000];
//    static bool used[160][160];
//    static Pos d[4]={Pos(0,1),Pos(0,-1),Pos(-1,0),Pos(1,0)};
    Unit *unit=findUnitById(op.id);
    if(unit!=NULL)
    {
        if(op.type=="Move")
        {
            if(op.targets.size()==0 || !map->tryPosition(op.targets[0],1))
                return;
            Operation a(op);
            findPVCpath(map,unit->getPos(),op.targets[0],a.targets);
            unit->setCmd(a);
        }
        else if (op.type == "BuyBackHero" || op.type == "CallBackHero")
        {
			int camp = -1;
            for (auto ptr: getUnits())
            {
                if (ptr->getId() == op.id)
                {
                    camp = ptr->getCamp();
                    break;
                }
            }
            if (camp < 0 || camp > 1)
                return;
            Operation a(op);
            Pos newPos = MILITARY_BASE_POS[camp];
            Pos r = newPos;
			
            int dx[4] = {1, -1, 0, 0};
            int dy[4] = {0, 0, -1, 1};
            for(int d = 0; true; ++d)
			{
                for (int i = 0; i < 4; ++i)
                {
                    Pos tmp(newPos.x + dx[i] * d, newPos.y + dy[i] * d);
                    bool ok = true;
                    for(auto ptr: getUnits())
                    {
                        if(dis2(ptr->getPos(), tmp) < ptr->getVolume() * ptr->getVolume())
                        {
                            ok = false;
                            break;
                        }
                    }
                    if (tmp.x < 0 || tmp.x >= MAP_SIZE || tmp.y < 0 || tmp.y >= MAP_SIZE)
                        ok = false;
                    if (ok)
                    {
                        r = tmp;
                        break;
                    }
                }
				if (r != newPos)
					break;
			}
			a.targets.push_back (r);
            unit->setCmd (a);
        }
        else
            unit->setCmd(op);
    }
}
ElDorado::ElDorado():
    Game()
{
    playerNum=3;
    campNum=3;
}

void ElDorado::getMapAndPlayer(int MaxRound,const char* FileName)
{
    map=new Map(MAP_SIZE,MAP_SIZE,FileName);
    maxRound=MaxRound;
    playerCamp.resize(3);
    playerCamp[0]=0;
    playerCamp[1]=1;
    playerCamp[2]=2;
    addCmd(new PCommand());
    addCmd(new PCommand());
    addCmd(new PCommand());
    addInfo(new PlayerInfo(this,0));
    addInfo(new PlayerInfo(this,1));
    addInfo(new PlayerInfo(this,2));
}

void ElDorado::init()
{
    //Mines and militaryBases' position should be given by  map. Here is a temporay solution
    addUnit(new InfoOutPut(this, 0, 0, 0, Pos(-1, -1)));
    addUnit(new InfoOutPut(this, 1, 1, 1, Pos(-1, -1)));
    addUnit(new InfoOutPut(this, 2, 2, 2, Pos(-1, -1)));

    addUnit(new MilitaryBase(this, 0, 0, 3, MILITARY_BASE_POS[0]));
    addUnit(new MilitaryBase(this, 1, 1, 4, MILITARY_BASE_POS[1]));
    //a mine that is always available
    Mine* mine = new Mine(this, 2, 2, 5, MINE_VOLUME, MINE_POS[0]);
    addUnit(mine);
    mine->findArg("Energy")->change(0, MAX_ROUND);
    Mine::availableCount (+1);

    for (int i = 1; i < MINE_NUM; ++i)
        addUnit(new Mine(this, 2, 2, i + 5, MINE_VOLUME, MINE_POS[i]));
    int monsterId=0;//Dog
    /*for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new Dog(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    monsterId++;//Bow
    for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new Bow(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    monsterId++;//Wolf
    for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new Wolf(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    monsterId++;//StoneMan
    for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new StoneMan(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    monsterId++;//Dragon
    */
    for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new Dragon(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    monsterId++;//Roshan
    for(int i=0;i<SIZE(MONSTERS[monsterId].POS_LIST);++i)
        addUnit(new Roshan(this,2,2,-1,MONSTERS[monsterId].POS_LIST[i]));
    for(int i = 0; i < SIZE(infos); ++i)
        infos[i] -> goldInc(BASE_GOLD);
}

int ElDorado::winnerJudge()
{
    if (winner == -1)
    {
        int base0 = 0, base1 = 0;
        for (vector<Unit*>::iterator iter = units.begin(); iter != units.end(); ++iter)
            if ((*iter)->getName() == "MilitaryBase")
            {
                if ((*iter)->getCamp() == 0)
                    base0 = (*iter)->findArg("Hp")->getVal(0);
                else
                    base1 = (*iter)->findArg("Hp")->getVal(0);
            }
        PlayerInfo *camp0, *camp1;
        for (vector<PlayerInfo*>::iterator iter = infos.begin(); iter != infos.end(); ++iter)
        {
            if ((*iter)->getCamp() == 0)
                camp0 = *iter;
            else if ((*iter)->getCamp() == 1)
                camp1 = *iter;
        }
        if (base0 <= 0 && base1 <= 0)
            winner = -2;
        else if (base0 <= 0)
            winner = 1;
        else if (base1 <= 0)
            winner = 0;
        else if (getRound() >= maxRound)
        {
            if (camp0->countProperty() > camp1->countProperty())
                winner = 0;
            else if (camp0->countProperty() < camp1->countProperty())
                winner = 1;
            else
                winner = -2;
        }
    }
    if (winner != -1)
    {
        fout << "winner:" << winner << endl;
    }
    return winner;
}

void ElDorado::setMode(int Mode)
{
    mode=Mode;
    playerCamp.clear();
    if(mode==0 || mode==4)
    {
        playerNum=campNum=3;
        playerCamp.push_back(0);
        playerCamp.push_back(1);
        playerCamp.push_back(2);
    }
    else if(mode==1 || mode==2 || mode==3)
    {
        playerNum=campNum=2;
        playerCamp.push_back(0);
        playerCamp.push_back(1);
    }
}

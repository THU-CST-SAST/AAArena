#include "include/Unit/Mine.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Game/Game.h"
#include "include/sdk/const.h"
#include "include/Buff/Buffs.h"
#include <iostream>
using namespace std;
int Mine::_availableCount = 0;
int Mine::_randomed = 0;
Mine::Mine(Game* Gm, int Camp, int Player, int ID, int Volume, Pos Ps):	Unit(Gm, "Mine", Camp, Player, ID, Volume, Ps)
{
	addArg(new Hp(MINE_HP, 0, this));
	addArg(new Mp(MINE_MP, 0, this));
	addArg(new Atk(MINE_ATK, this));
	addArg(new Def(MINE_DEF, this));
	addArg(new Range(MINE_RANGE, 0, this));
	addArg(new Speed(MINE_SPEED, this));
	addArg(new Gold(MINE_BASE_GOLD, 0, this));
	addArg(new View(MINE_VIEW, this));
	addArg(new LastHit(this));
	addArg(new Energy(this));
}

bool Mine::okToMining(int Camp)
{
	if (findArg("Energy")->getVal(Energy::ExistTime) <= 0)
		return false;
	vector<Unit*> units = getGame()->getUnits();
	for (int i = 0; i < units.size(); ++i)
	{
		if (dis2(getPos(), units[i]->getPos()) > MINING_RANGE || units[i]->getName() == "Mine")
			continue;
		if (units[i]->getCamp() != Camp && !units[i]->findBuff("Reviving"))
			return false;
	}
	return true;
}

int Mine::goldInc(int inc)
{
	int old = findArg("Gold")->getVal(Gold::Total);
	int n = old + inc;
	if (n < 0)
		n = 0;
	this->findArg("Gold")->change(Gold::Total, n);
	return old - findArg("Gold")->getVal(Gold::Total);
}

void Mine::mining(int Camp, int inc, Unit* unit)
{
	if (!okToMining(Camp))
		return;
	mineCamp = Camp;
	if (maxGoldInc < inc)
	{
		maxGoldInc = inc;
		this->miner = unit;
	}
}


void Mine::roundStart()
{
	mineCamp = -1;
	maxGoldInc = 0;
	Unit::roundStart();
}

void Mine::oneRoundPass()
{
	if (maxGoldInc != 0)
	{
		vector<PlayerInfo*> infos = getGame()->getPlayerInfos();
		for (int i = 0; i < infos.size(); ++i)
			if (infos[i]->getCamp() == mineCamp)
			{
				int realInc = this->goldInc(-maxGoldInc);
				miner->addBuff(new IsMining(miner, realInc));
				infos[i]->goldInc(realInc);
				break;
			}
	}
	Unit::oneRoundPass();
}

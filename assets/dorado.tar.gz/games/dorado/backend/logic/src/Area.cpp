//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
void Area::roundStart()
{
}
void Area::oneRoundPass()
{
    if(timeLeft>0)
        --timeLeft;
    if(timeLeft==0)
        terminate();
}
void Area::terminate()
{
}
bool Area::remove()
{
    return timeLeft==0;
}
void Area::work(Unit* unit)
{
    if(!inArea(unit->getPos()))
        return;
}
Area::Area(const char* Name,Game* Gm,int Camp,int TimeLeft,int ID,Pos Center,double Radius):
    name(Name),game(Gm),
    camp(Camp),timeLeft(TimeLeft),
    id(ID),
    center(Center),radius(Radius)
{
    if(id==-1)
        id=game->getNewId(name);
    else game->addId(id,name);
}
bool Area::inArea(Pos Pos)
{
    return (Pos.x-center.x)*(Pos.x-center.x)+(Pos.y-center.y)*(Pos.y-center.y)<=radius*radius;
}
void Area::output(ostream &os)
{
    os<<"{";
    {
        os<<"type:Area;";
        os<<"id:"<<id<<";";
        os<<"camp:"<<camp<<";";
        os<<"name:"<<name<<";";
        os<<"time:"<<timeLeft<<";";
        os<<"center:{"<<center.x<<";"<<center.y<<"};";
        os<<"radius:"<<radius;
    }
    os<<"}\n";
}
string Area::toString()
{
    return name + "&" + ToString(id) + "&" + ToString(camp) + "&" + ToString(timeLeft) + "&" + ToString(center)  + "&" +
            ToString(radius);
}

//#include "logic.hh"
#include "include/frame.h"
#include "include/Game/ElDorado.h"
#ifndef _PVC_//person versus computer
int main(int argc, char *argv[])
{
    const char* aa_arena_seed = getenv("AA_ARENA_GAME_SEED");
    srand(aa_arena_seed ? static_cast<unsigned int>(strtoul(aa_arena_seed, nullptr, 10)) : static_cast<unsigned int>(time(NULL)));//
    int i;
    cout << sizeof(i) << endl;
    Executor executor(argc, argv, new ElDorado());//开发者必由PrototypeExecutor继承实现Executor
    executor.load();//
    executor.judge();
    return 0;
}
#else
#include <iostream>
#include <strstream>
using namespace std;
#include "include/ActMaker/ActMakerLocal.h"
Game* gPVC;
PMap* mapPVC;
#ifdef _AC_WIN_
#define LIBEXPORT_API extern "C" __declspec(dllexport)
#else
#define LIBEXPORT_API extern "C"
#endif//_AC_WIN_
int MAX_ROUND_PVC=1000;
LIBEXPORT_API void SetMaxRound(int MaxRound)
{
	MAX_ROUND_PVC = MaxRound;
}
LIBEXPORT_API void GtoLStartInfo(char *aiName)
{
    //name1 name2
    gPVC=new ElDorado();
    gPVC->getMapAndPlayer(MAX_ROUND_PVC,"map.txt");
    mapPVC=new PMap("map.txt");
    int len=strlen(aiName);
    char a[1000];
    memset(a,0,sizeof(a));
    strcpy(a,aiName);
    int x=0;
    for(;x<len;++x)
        if(a[x]==' ')
            break;
    a[x++]=0;
    ActMakerLocal* a0=new ActMakerLocal();
	a0->setMap(mapPVC);
    ActMakerLocal* a1=new ActMakerLocal();
	a1->setMap(mapPVC);
    ActMakerLocal* a2=new ActMakerLocal();
	a2->setMap(mapPVC);
    a0->load(a);
    gPVC->addActMaker(a0);
    a1->load(a+x);
    gPVC->addActMaker(a1);
#ifdef _AC_WIN_
    a2->load("monsterAi.dll");
#else
    a2->load("monsterAi.so");
#endif//_AC_WIN_
    gPVC->addActMaker(a2);
    gPVC->init();
}

LIBEXPORT_API void LtoGStartInfo(char *startInfo)
{
}

LIBEXPORT_API void GtoLRoundStart()
{
    gPVC->roundStart();
}
LIBEXPORT_API void GtoLRoundEnd()
{
   gPVC->calcTheRound();
}
LIBEXPORT_API void GtoLRoundCmd(char *command)
{
//{id:1;action:Attack;target:{-1;-1};}
    Operation op;
    static char a[100];
    static char cmd[50];
    memset(a,0,sizeof(a));
    memset(cmd,0,sizeof(cmd));
    strcpy(a,command);
    int ptr=0,len=strlen(command);

    for(ptr=0;ptr<len;++ptr)
        if(a[ptr]==':')
            break;
    for(++ptr,op.id=0;ptr<len;++ptr)
        if('0'<=a[ptr] && a[ptr]<='9')
            op.id=op.id*10+a[ptr]-'0';
        else break;
    //=========================
    for(++ptr;ptr<len;++ptr)
        if(a[ptr]==':')
            break;
    int cmdLen=0;
    for(++ptr;ptr<len&&a[ptr]!=';';++ptr)
            cmd[cmdLen++]=a[ptr];
    cmd[cmdLen]=0;
	op.type=cmd;
    //======================
    int x=0,y=0,sign=1;
    while((a[ptr]<'0'||'9'<a[ptr])&&ptr<len)
        ++ptr;
    if(a[ptr-1]=='-')
        sign=-1;
   while('0'<=a[ptr] && a[ptr]<='9' && ptr<len)
       x=x*10+a[ptr++]-'0';
   x*=sign;
   //======================
   while((a[ptr]<'0'||'9'<a[ptr])&&ptr<len)
       ++ptr;
   sign=((a[ptr-1]=='-')?-1:1);
   while('0'<=a[ptr] && a[ptr]<='9' && ptr<len)
       y=y*10+a[ptr++]-'0';
   y*=sign;
   if(x!=-1 || y!=-1)
       op.targets.push_back(Pos(x,y));
   //=================================
   gPVC->setPVCcmd(op);
}

LIBEXPORT_API void LtoGRoundInfo(char *roundInfo)
{
    static char ch[100000];
    static int winner=-1;
    memset(ch,0,sizeof(ch));
    ostrstream os(ch,100000);
    gPVC->outputReplayInfo(os);
    winner=gPVC->winnerJudge();
    if(winner!=-1)
        //sprintf(ch,"winner:%d\n",winner);
        os<<"winner:"<<winner<<'\n';
    strcpy(roundInfo,ch);
    gPVC->clean();
}
/*char bb[100000];
void MR(char* cmd)
{
    memset(bb,0,sizeof(bb));
    GtoLRoundStart();
    GtoLRoundCmd(cmd);
    GtoLRoundEnd();
    LtoGRoundInfo(bb);
    cout<<bb<<'\n';
}
int main()
{
    GtoLStartInfo("a.dll a.dll");
    MR("{id:999;action:Stop;target:{-1;-1};}");
    return 0;
}*/
#endif//_PVC_

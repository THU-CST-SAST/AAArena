//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/Unit/Mine.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#define SIZE(x) (int(x.size()))
void Game::outAiStatus(ostream& os)
{
    os << "AI STATUS:";
    for (int i=0; i<SIZE(actMakers); ++i)
    {
        if (!actMakers[i]->aiStatus() )
        {
            os << "AI(ID:" << i << ")Failed,";
            actMakers[i]->outStatus(os);
        }
    }
    os << '\n';
}

void Game::setMode(int Mode)
{
    mode=Mode;
    playerNum = 3;
    campNum = 3;
    return;
}
void Game::roundStart()//回合开始
{
    roundProcess=0;
    for(int i=0;i<SIZE(units);++i)
        units[i]->roundStart();
    for(int i=0;i<SIZE(flights);++i)
        flights[i]->roundStart();
    for(int i=0;i<SIZE(areas);++i)
        areas[i]->roundStart();
    getPlayerInfo();
    getPlayerCmd();
}
void Game::getPlayerInfo()//获取各阵营（同阵营各选手信息共享）信息，包括视野计算
{
    map->roundInit();
    for(int i=0;i<SIZE(units);++i)
        map->calcView(units[i]);
    for(int i=0;i<SIZE(infos);++i)
        infos[i]->roundInit(round);
    for(int i=0;i<SIZE(units);++i)
    {
        Pos pos=units[i]->getPos();
        for(int j=0;j<campNum;++j)
            if( (map->getDetector(pos)&(1<<j))||
                    ((map->getView(pos)&(1<<j))&& units[i]->findBuff("Hided")==NULL) ||
                    units[i]->getCamp() == j)
                infos[j]->addUnit(units[i]);
    }
    for(int i=0;i<SIZE(flights);++i)
    {
        Pos pos=flights[i]->getPos();
        for(int j=0;j<campNum;++j)
            if( map->getView(pos)&(1<<j) )
                infos[j]->addFlight(flights[i]);
    }
    for(int i=0;i<SIZE(areas);++i)
        for(int j=0;j<campNum;++j)
        {
            bool flag=false;
            for(int x=0;x<map->width()&&!flag;++x)
                for(int y=0;y<map->length()&&!flag;++y)
                    if( areas[i]->inArea(Pos(x,y)) )
                        if(map->getView(x,y)&(1<<j))
                        {
                            infos[j]->addArea(areas[i]);
                            flag=true;
                        }
        }
}
void Game::deduplicateCmd (PCommand* cmd)
{
    vector<Operation>& ops = cmd->cmds;
    bool ids[1000] = {0};
    reverse (begin(ops), end(ops));
    for (vector<Operation>::iterator it = ops.begin(); it != ops.end(); )
    {
        if (ids[it->id] && !(findUnitById(it->id) && findUnitById(it->id)->getName() == "MilitaryBase"))
            ops.erase (it);
        else
        {
            ids[it->id] = true;
            ++it;
        }
    }
}

void Game::getPlayerCmd()//获取选手操作
{
    for(int i=0;i<playerNum;++i)
    {
//        cout<<"........."<<i<<'\n';
        infos[playerCamp[i]]->setPlayer(i);
        if(!actMakers[i]->getCmd(infos[i],cmds[i]))
        {
            actMakers[i]->getWrong();
            if(i!=2)
            {
                if(winner==-1)
                    winner=1-i;
                else winner=-2;
            }
            else winner=-2;
        }
    }
    if(winner!=-1)
    {
        return;
    }
    for(int i=0;i<playerNum;++i)
    {
        deduplicateCmd(cmds[i]);
        for(int j=0;j<SIZE(cmds[i]->cmds);++j)
        {
            Unit* unit=findUnitById(cmds[i]->cmds[j].id);
            if(unit!=NULL && unit->getPlayer()==i)
                unit->setCmd(cmds[i]->cmds[j]);
        }
    }
}
Unit* Game::findUnitById(int ID)
{
    for(int i=0;i<SIZE(units);++i)
        if(units[i]->getId()==ID)
            return units[i];
    return NULL;
}

Unit *Game::findUnitByPos(Pos POS)
{
    for(int i=0;i<SIZE(units);++i)
        if(units[i]->getPos()==POS)
            return units[i];
    return NULL;
}
#define OPR //cout<<"Process:"<<roundProcess<<'\n';
void Game::calcTheRound()//计算回合
{
    roundProcess=0;
    OPR
    for(int i=0;i<SIZE(units);++i)//加技能点等动作生效
        units[i]->useSkill();
OPR
    roundProcess=1;
    for(int i=0;i<SIZE(units);++i)//技能对施术者作用结算
        units[i]->useSkill();
OPR
    roundProcess=2;
    for(int i=0;i<SIZE(units);++i)//瞬间生效技能对外作用结算
        units[i]->useSkill();
OPR
    while(1)//位移类技能冲突处理
    {
        bool flag=false;
        for(int i=0;i<SIZE(units);++i)
            if( units[i]->findCollision() )
                flag=true;
        if(!flag)
            break;
        for(int i=0;i<SIZE(units);++i)
            units[i]->dealCollision();
    }
OPR
    passiveTrigger();//各类被动技能循环结算
OPR
    roundProcess=4;
OPR
    makeMove();//移动处理
OPR
    roundProcess=5;//各对象的oneRoundPass，buff与area的终结效果暂不触发
    for(int i=0;i<SIZE(units);++i)
        units[i]->oneRoundPass();
    for(int i=0;i<SIZE(areas);++i)
        areas[i]->oneRoundPass();
    for(int i=0;i<SIZE(flights);++i)
        flights[i]->oneRoundPass();
OPR
    passiveTrigger();//各类被动技能循环结算
    roundProcess=6;//buff与area的终结效果触发
    for(int i=0;i<SIZE(units);++i)
        units[i]->roundTerminate();
    for(int i=0;i<SIZE(areas);++i)
        areas[i]->terminate();
    for(int i=0;i<SIZE(flights);++i)
        flights[i]->terminate();
    for(int i=0;i<SIZE(units);++i)
        units[i]->checkArg();
OPR
    passiveTrigger();//各类被动技能循环结算
OPR
    roundProcess=7;
    for(int i=0;i<SIZE(units);++i)//瞬间生效技能对外作用结算
        units[i]->useSkill();
}
void Game::clean()//回合结束，多余对象清除
{
    Mine::randomCount(-Mine::randomCount());
    for(int i=0;i<SIZE(units);++i)
        units[i]->clean();
    for(vector<Unit*>::iterator i=units.begin();i!=units.end();)
        if((*i)->remove())
        {
            ids[(*i)->getId()].second=false;
            delete (*i);
            units.erase(i);
        }
        else ++i;
    for(vector<Area*>::iterator i=areas.begin();i!=areas.end();)
        if((*i)->remove())
        {
            ids[(*i)->getId()].second=false;
            delete (*i);
            areas.erase(i);
        }
        else ++i;
    for(vector<Flight*>::iterator i=flights.begin();i!=flights.end();)
        if((*i)->remove())
        {
            ids[(*i)->getId()].second=false;
            delete (*i);
            flights.erase(i);
        }
        else ++i;
}
void Game::passiveTrigger()//各类被动技能循环结算
{
    roundProcess=3;
    while(1)//被动触发技能结算
    {
        bool flag=false;
        for(int i=0;i<SIZE(units);++i)
            if(units[i]->useSkill())
                flag=true;
        if(!flag)
            break;
    }
}
void Game::makeMove()//移动处理
{
    for(int i=0;i<SIZE(units);++i)
        units[i]->checkMoveCmd();
    static vector<Pos> poses;
    poses.resize(units.size());
    //for(int k=0;k<units.size()*10;++k)
    while(true)
    {
        for(int i=0;i<SIZE(units);++i)
        {
            poses[i]=units[i]->getPos();
            units[i]->makeOneStep();
        }
        while(1)
        {
            bool flag=false;
            for(int i=0;i<SIZE(units);++i)
                if(units[i]->findCollision())
                    flag=true;
            if(!flag) break;
            for(int i=0;i<SIZE(units);++i)
                units[i]->stepBack();
        }
        for(int i=0;i<SIZE(areas);++i)
            for(int j=0;j<SIZE(units);++j)
                areas[i]->work(units[j]);
        bool flag=false;
        for(int i=0;i<SIZE(units);++i)
            if(poses[i]!=units[i]->getPos())
            {
                flag=true;
                break;
            }
        if(!flag)
            break;
    }
}
void Game::outputReplayInfo(ostream &os)//输出录像信息
{
    os<<"Round:"<<round<<"\n";
    for (int i = 0;i < SIZE(infos); ++i)
        infos[i]->output(os);
    for(int i=0;i<SIZE(units);++i)
        units[i]->output(os);
    for(int i=0;i<SIZE(flights);++i)
        flights[i]->output(os);
    for(int i=0;i<SIZE(areas);++i)
        areas[i]->output(os);
    os<<"\n";
    ++round;
}
Game::Game():
    round(0),playerNum(0),
    campNum(0),winner(-1),
    map(NULL),
#ifndef _PVC_
    fout("replay.txt"),
#endif
    mode(0)
{
    units.clear();
    flights.clear();
    areas.clear();
    actMakers.clear();
    cmds.clear();
    infos.clear();
    playerCamp.clear();
    ids.clear();

#ifndef _PVC_
    fout<<"**************************\n";
#endif

}
Game::~Game()
{
    outAiStatus(fout);
    fout.close();
#ifdef _SERVER_
    if(winner==-2)
        winner=0;
    else if(winner==0)
        winner=1;
    else if(winner==1)
        winner=-1;
    //===============
    try
    {
        system("make -f makefile.analyse");
        system("./analyse");
        //system("cat replayA.txt > replay.txt");
        system("zip replay.zip replay.txt");
        string syscmd="ruby trans.rb "+ToString(winner);
        system(syscmd.c_str());
    }
    catch(...)
    {
    }
    //==============
//    outAiStatus(fileout);
//    system ("cat ./result.txt  ./replay.txt > ./result_2.txt");
//    system ("cat ./result_2.txt > ./replay.txt");
//    system ("rm ./result.txt ./result_2.txt");
#endif
    for(int i=0;i<units.size();++i)
        delete units[i];
    for(int i=0;i<flights.size();++i)
        delete flights[i];
    for(int i=0;i<areas.size();++i)
        delete areas[i];
    for(int i=0;i<actMakers.size();++i)
        delete actMakers[i];
    for(int i=0;i<infos.size();++i)
        delete infos[i];
    delete map;
}
void Game::oneRoundRun()
{
    roundStart();
    calcTheRound();
    outputReplayInfo(fout);
    clean();
}


int Game::getNewId(string Name)
{
    for(int i=0;i<SIZE(ids);++i)
        if(!ids[i].second && (ids[i].first==Name || ids[i].first=="" ))
        {
            ids[i].second=true;
            ids[i].first=Name;
            return i;
        }
    ids.push_back(make_pair(Name,true));
    return ids.size()-1;
}
void Game::addId(int ID, string Name)
{
    while(ids.size()<ID+1)
    {
        string a="";
        ids.push_back(make_pair(a,false));
    }
    ids[ID]=make_pair(Name,true);
}

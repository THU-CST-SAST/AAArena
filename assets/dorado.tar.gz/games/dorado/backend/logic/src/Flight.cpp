//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
using namespace std;
void Flight::oneRoundPass()//飞行一回合
{
    //pos+=velocity;
    --timeLeft;
    //if(???)teminate();
}
void Flight::terminate()//飞行道具生命终止时发生事件，例如爆炸
{
    if (timeLeft>0) return;
}
bool Flight::remove()
{
    return timeLeft==0;
}
void Flight::output(ostream &os)
{
    os<<"{";
    os<<"type:Flight;";
    os<<"id:"<<id<<';';
    os<<"camp:"<<camp<<';';
    os<<"name:"<<name<<';';
    os<<"lastPos:{"<<lastPos.x<<";"<<lastPos.y<<"};";
    os<<"pos:{"<<pos.x<<";"<<pos.y<<"};";
    os<<"hit:"<<getHit();
    os<<"}\n";
}
void Flight::roundStart()
{
    lastPos=pos;
}
Flight::Flight(Game* Gm,const char* Name,int UnitID,int ID,int Camp,int Time,int Speed,Pos Start):
	 game(Gm),name(Name),unitId(UnitID),
	id(ID),camp(Camp),
    timeLeft(Time),speed(Speed),
    pos(Start),lastPos(Start)
{
	if(id==-1)
		id=game->getNewId(name);
	else game->addId(id,name);
}
string Flight::toString()
{
        return ToString(id) + "&" + name + "&" + ToString(camp) + "&" +
                ToString(speed) + "&" +ToString(pos) + "&" +ToString(target);
}

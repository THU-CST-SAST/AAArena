//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"

static int baseGoldOfHero(string name)
{
	if(name == "Hammerguard") return NEW_HAMMERGUARD_COST;
	if(name == "Master") return NEW_MASTER_COST;
	if(name == "Berserker") return NEW_BERSERKER_COST;
	if(name == "Scouter") return NEW_SCOUTER_COST;
	return 0;
}
void PlayerInfo::roundInit(int Round)
{
    round=Round;
    lastGold=gold;
	property=countProperty();
    units.clear();
    flights.clear();
    areas.clear();
}
PlayerInfo::PlayerInfo(Game* Gm,int Camp):
    game(Gm),camp(Camp), gold(0)
{
    units.clear();
    flights.clear();
    areas.clear();
}
void PlayerInfo::addUnit(Unit* unit)
{
    units.push_back(unit);
}
void PlayerInfo::addFlight(Flight* flight)
{
    flights.push_back(flight);
}
void PlayerInfo::addArea(Area* area)
{
    areas.push_back(area);
}
string PlayerInfo::toString()const
{
    string tmp = ToString(camp) + "#" + ToString(player) + '#' + ToString(round) + '#' + ToString(gold) + '#';
    int _size = units.size();
    for (int i=0; i<_size; ++i)
    {
        tmp += units[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
    _size = flights.size();
    tmp += '#';
    for (int i=0; i<_size; ++i)
    {
        tmp += flights[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
    tmp += '#';
    _size = areas.size();
    for (int i=0; i<_size; ++i)
    {
        tmp += areas[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
    return tmp;
}
bool PlayerInfo::goldInc(int inc)
{
    int newGold = gold + inc;
    if (newGold >= 0)
    {
        gold = newGold;
        return true;
    }
    else
        return false;
}
int PlayerInfo::countProperty()
{
	int property = gold;
	for(int i = 0; i < game->getUnits().size(); ++i)
	{
        Unit* ptr=game->getUnits()[i];
        if((ptr->getName() == "Hammerguard" || ptr->getName() == "Master"
        || ptr->getName() == "Scouter" || ptr->getName() == "Berserker")
		&& ptr->getCamp() == getCamp())
        {
			int lvl = ptr->findArg("Exp")->getVal(2);
			property += lvl * LEVELUP_COST_BASE + (((lvl - 1) * lvl)/2) * LEVELUP_COST_PER_LEVEL
						 + baseGoldOfHero(ptr->getName());
        }
	}
	return property;
}
void PlayerInfo::output(ostream& os)
{
    // os << "{"
         // << "type:info;"
         // << "camp:" << camp << ";"
         // << "gold:" << gold
         // << "}" << endl;
}

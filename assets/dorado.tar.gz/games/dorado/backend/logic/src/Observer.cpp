#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Game/Game.h"
#include "include/Unit/Observer.h"
#include "include/Skill/Skills.h"
#include "include/PCommand//Operation.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
#include <vector>
#include <iostream>
using namespace std;

Observer::Observer(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Unit(Gm,"Observer",Camp,Player,ID,1,Ps)
{
    addArg(new Hp(OBSERVER_HP, 0, this));
    addArg(new Def(OBSERVER_DEF,this));
    addArg(new View(OBSERVER_VIEW,this));
    addArg(new LastHit(this));
}

void Observer::setCmd(const Operation& Cmd)
{
    return;
}

void Observer::addBuff(Buff* newBuff)
{
	delete newBuff;
}

int Observer::getStatus()
{
    return findArg("Hp")->getVal()<=0;
}

bool Observer::remove()
{
    return findArg("Hp")->getVal()<=0;
}

void Observer::oneRoundPass()
{
    findArg("Hp")->add(0,-1);
}

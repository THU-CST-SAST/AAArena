#include "include/Buff/Buffs.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/PCommand/Operation.h"
#include "include/Game/Game.h"
#include "include/Skill/Skills.h"
#include "include/sdk/const.h"
#include <algorithm>
/*
bool Hided::remove()
{
    return end || timeLeft==0;
}
void Hided::work()
{
    UnitArg* ptr=unit->findArg("Speed");
    double x=Hided_speed_delta_rate[level];
    delta=ptr->getVal()*x;
    ptr->add(0,delta);

    ptr=unit->findArg("Atk");
    ptr->add(0,Hided_atk_delta[level]);
}
void Hided::terminate()
{
    if(unit->getCmd()->type=="Attack")
        end=true;
    if(timeLeft>0 && !end)
        return;
    UnitArg* ptr=unit->findArg("Speed");
    ptr->add(0,-delta);

    ptr=unit->findArg("Atk");
    ptr->add(0,-Hided_atk_delta[level]);
}
Hided::Hided(Unit *myUnit,int Level):
    Buff("Hided",myUnit,Hided_time+1,Level),end(false)
{
}
//==========================
void Rainy::work()
{
    UnitArg* ptr=unit->findArg("Speed");
    spd=ptr->getVal();
    //delta=ptr->getVal()*0.5625;
    delta=ptr->getVal()*Rainy_speed_delta_rate;//Rainy_speed_delta_rate<0
    ptr->add(0,delta);
}
void Rainy::oneRoundPass()
{
    --timeLeft;
    UnitArg* ptr=unit->findArg("Hp");
    int x=Rainy_damage[level];
    ptr->add(0,-x);
    unit->findArg("LastHit")->change(shooterId,unit->getGame()->getRound());
}
void Rainy::terminate()
{
    if(timeLeft>0)
        return;
    UnitArg* ptr=unit->findArg("Speed");
    ptr->add(0,-delta);
}
Rainy::Rainy(Unit *myUnit,int Level,int UnitId):
    Buff("Rainy",myUnit,2,Level),shooterId(UnitId)
{
}

void Rainy::overlap(Buff *buff)
{
    Rainy* ptr=(Rainy*)buff;
    level=ptr->level;
    timeLeft=ptr->timeLeft;
    shooterId=ptr->shooterId;
    delete buff;
}
//================
void Yelled::work()
{
    UnitArg* ptr=unit->findArg("OnlyTarget");
    if(ptr!=NULL)
        ptr->change(0,targetId);
}
void Yelled::terminate()
{
    if(timeLeft>0)
        return;
    UnitArg* ptr=unit->findArg("OnlyTarget");
    if(ptr!=NULL)
        ptr->change(0,-1);
}
Yelled::Yelled(Unit *myUnit,int Level,int ID):
    Buff("Yelled",myUnit,1+Yelled_time[Level],Level),targetId(ID)
{
}

void Yelled::overlap(Buff *buff)
{
    Yelled* ptr=(Yelled*)buff;
    level=ptr->level;
    timeLeft=ptr->timeLeft;
    targetId=ptr->targetId;
    work();
    delete buff;
}
//==============
void Yelling::work()
{
    UnitArg* ptr=unit->findArg("Def");
    int x=Yell_def_delta[level];
    ptr->add(0,x);
}
void Yelling::terminate()
{
    if(timeLeft>0)
        return;
    UnitArg* ptr=unit->findArg("Def");
    int x=Yell_def_delta[level];
    ptr->add(0,-x);
}
Yelling::Yelling(Unit *myUnit,int Level):
    Buff("Yelling",myUnit,1+Yelled_time[Level],Level)
{
}
*/
//====================
void Dizzy::work()
{
}
void Dizzy::terminate()
{
}
Dizzy::Dizzy(Unit *myUnit,int Level):
    Buff("Dizzy",myUnit,1+DIZZY_TIME[Level],Level)
{
}
/*
//=====================
void Striking::work()
{
    UnitArg* ptr=unit->findArg("Atk");
    int x=PowerUp_atk_delta[level];
    ptr->add(0,x);
}
void Striking::terminate()
{
    if(timeLeft>0)
        return;
    UnitArg* ptr=unit->findArg("Atk");
    int x=PowerUp_atk_delta[level];
    ptr->add(0,-x);
}
Striking::Striking(Unit *myUnit,int Level):
    Buff("Striking",myUnit,1+Striking_time,Level)
{
}
*/

//=================
Reviving::Reviving(Unit *myUnit,int TimeLeft):
    Buff("Reviving",myUnit,TimeLeft,0)
{
}
void Reviving::work()
{
}
void Reviving::terminate()
{
    if(timeLeft>0)
        return;
    unit->findArg("Hp")->change(0,unit->findArg("Hp")->getVal(1));
    if(unit->findBuff("Mp")!=NULL)
        unit->findArg("Mp")->change(0,unit->findArg("Mp")->getVal(1));
    unit->findArg("Atk")->change(0,unit->findArg("Atk")->getVal(1));
    unit->findArg("Def")->change(0,unit->findArg("Def")->getVal(1));
    unit->findArg("Speed")->change(0,unit->findArg("Speed")->getVal(1));
    unit->findArg("View")->change(0,unit->findArg("View")->getVal(1));
    unit->findArg("Range")->change(0,unit->findArg("Range")->getVal(1));
    unit->findArg("OnlyTarget")->change(0,-1);
}
//======================
WinOrDie::WinOrDie (Unit* unit, int timeLeft, int hd, int ai):Buff("WinOrDie", unit, timeLeft, 0, "Crash"), hpDecrease(hd), attackIncrease(ai)
{

}
WinOrDie::~WinOrDie ()
{
    
}
void WinOrDie::work ()
{
    unit->findArg("Hp")->change(0, 1);
    unit->findArg("Atk")->change(0, unit->findArg("Atk")->getVal(0) + hpDecrease);
}
void WinOrDie::terminate ()
{
	if(timeLeft > 0) return;
    unit->findArg("Hp")->change(0, unit->findArg("Hp")->getVal(0) + hpDecrease);
    unit->findArg("Atk")->change(0, unit->findArg("Atk")->getVal(0) - attackIncrease);
}

BeAttacked::BeAttacked(Unit* myUnit, int timeLeft):Buff("BeAttacked", myUnit, timeLeft)
{
}

BeAttacked::~BeAttacked()
{
}

void BeAttacked::work()
{
}

void BeAttacked::terminate()
{
}

//==================
void Slow::work()
{
    UnitArg* ptr=unit->findArg("Speed");
    delta=ptr->getVal()*SLOW_SPEED_DELTA_RATE;
    ptr->add(0,delta);
}
void Slow::terminate()
{
    if(timeLeft>0)
        return;
    UnitArg* ptr=unit->findArg("Speed");
    ptr->add(0,-delta);
}
Slow::Slow(Unit *myUnit,int Level):
    Buff("Slow",myUnit,SLOW_TIME,Level)
{
}

void Slow::overlap(Buff *buff)
{
    Slow* ptr=(Slow*)buff;
    timeLeft=ptr->timeLeft;
    level=ptr->level;
    delete buff;
}
//======================================================================================
Singing::Singing(Unit* myUnit, string name, int time, SkillEffect func, Unit* PUnit)://用于有吟唱时间的技能实现
    Buff("Singing",myUnit,time), fp(func), unit(PUnit) ,actionName(name)
{}

void Singing::work()
{}

void Singing::terminate()
{
    if(timeLeft>0)
        return;
    fp(unit);
}
void Singing::output (ostream& os)
{
     os << "{";
     {
         os << "name:" << name << ";";
         os << "description:" << des << ";";
         os << "time:" << timeLeft << ";";
         os << "actionName:" << actionName;
     }
     os << "}";

}
Singing::~Singing()
{}


WaitRevive::WaitRevive(Unit* myUnit, int time):
    Buff("WaitRevive",myUnit,time),init_atk_times(unit->findArg("LastHit")->valSize())
{}

void WaitRevive::work()
{
    unit->findArg("Hp")->change(0,unit->findArg("Hp")->getVal(1)/4);
}

void WaitRevive::terminate()
{
//    if(unit->findArg("Hp")->getVal()<)
//    if(unit->findArg("LastHit")->valSize()-init_atk_times >= WaitRevive_atk_times)
//    {
//        unit->findSkill("Dead")->trigger();
     //   return;
//    }
//    if(timeLeft>0) return;
//    unit->findArg("Hp")->change(0,Berserker_base_hp/2);
//    unit->findSkill("Sacrifice")->setUsed(false);
}
WaitRevive::~WaitRevive()
{}

ChosenByBase::ChosenByBase(Unit* myUnit):
    Buff("ChosenByBase",myUnit,1,0)
{}

BuyBackByBase::BuyBackByBase(Unit* myUnit):
    Buff("BuyBackByBase",myUnit,1,0)
{}

CallBackByBase::CallBackByBase(Unit* myUnit):
    Buff("CallBackByBase",myUnit,1,0)
{}

LevelUpByBase::LevelUpByBase(Unit* myUnit):
    Buff("LevelUpByBase",myUnit,1,0)
{}

void LevelUpByBase::overlap(Buff* buff)
{
    LevelUpByBase* ptr = (LevelUpByBase*)buff;
    timeLeft = ptr->timeLeft;
    delete buff;
}

IsMining::IsMining(Unit* unit, int _inc): Buff("IsMining", unit, 1, 0), inc(_inc)
{

}

void IsMining::output (ostream& os)
{
    os<<"{";
    {
        os<<"name:"<<name<<";";
        os<<"description:"<<des<<";";
        os<<"time:"<<timeLeft << ";";
        os << "inc:" << inc;
    }
    os<<"}";
}


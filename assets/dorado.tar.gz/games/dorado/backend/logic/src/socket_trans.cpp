#include "include/socket_trans.h"
#include "include/sdk/const.h"
const int MAP_S = MAP_SIZE;

SocketBase &operator <<(SocketBase &s, const Pos &pos)
{
    s<<pos.x;
    s<<pos.y;
    return s;
}
SocketBase &operator >>(SocketBase &s, Pos &pos)
{
    s>>pos.x;
    s>>pos.y;
    return s;
}
//=============================
SocketBase &operator <<(SocketBase &s, const PMap &map)
{
    s<<map.playerIds;
    for(int i=0;i<MAP_S;++i)
        for(int j=0;j<MAP_S;++j)
            s<<((PMap) map)[i][j];
 //   fprintf(stderr, "\n==============================================\n"
//				"socketin %d\n",map.getHeight(0,0));
    return s;
}
SocketBase &operator >>(SocketBase &s, PMap &map)
{
    s>>map.playerIds;
    for(int i=0;i<MAP_S;++i)
        for(int j=0;j<MAP_S;++j){
 //       	fprintf(stderr, "\nread a height\n");
            s>>map[i][j];
            //fprintf(stderr, "height is %d in %p", map[i][j], &(map[i][j]));
	}    

    return s;
}
//==============================
SocketBase &operator <<(SocketBase &s, const PCommand &cmd)
{
    s<<cmd.cmds;
    return s;
}
SocketBase &operator >>(SocketBase &s, PCommand &cmd)
{
    s>>cmd.cmds;
    return s;
}
//=============================
SocketBase &operator <<(SocketBase &s, const Operation &op)
{
    s<<op.id;
    s<<op.type;
    s<<op.targets;
    return s;
}
SocketBase &operator >>(SocketBase &s, Operation &op)
{
    s>>op.id;
    s>>op.type;
    s>>op.targets;
    return s;
}

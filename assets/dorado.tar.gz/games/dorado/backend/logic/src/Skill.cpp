//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
bool Skill::canBeUse()//是否满足使用条件
{
    return true;
}
bool Skill::trigger()//技能触发
{
    cd=maxCd;
    return true;
}
void Skill::oneRoundPass()
{
    if(cd>0) cd--;
}
bool Skill::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        return true;
    }
    return false;
}
Skill::Skill(const char* Name,const char* Des,Unit* myUnit,int Level,int MaxLevel,int MaxCd,bool TargetNeeded):
    name(Name),des(Des),
    unit(myUnit),cd(0),maxCd(MaxCd),
    level(Level),maxLevel(MaxLevel),
    targetNeeded(TargetNeeded),lastUse(-1)
{
}
void Skill::output(ostream &os, int x)
{
    if(x>0)
        os<<';';
    os<<'{';
    {
        os<<"name:"<<name<<';';
        os<<"description:"<<des<<';';
        os<<"cd:"<<cd<<';';
        os<<"maxCd:"<<maxCd<<';';
        os<<"lvl:"<<level<<';';
        os<<"targetNeeded"<<':'<<targetNeeded;
        //???技能需求
    }
    os<<'}';
}
string Skill::toString()
{
    return name + "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}

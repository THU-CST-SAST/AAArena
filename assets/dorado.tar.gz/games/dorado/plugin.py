"""Dorado legacy AI9 GamePack 插件声明。"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from aa_arena.core import Evaluator, GamePlugin


def _load_evaluator_module():
    evaluator_dir = Path(__file__).resolve().parent / "evaluator"
    package_name = "aa_arena_games_dorado_evaluator"
    spec = importlib.util.spec_from_file_location(
        package_name,
        evaluator_dir / "__init__.py",
        submodule_search_locations=[str(evaluator_dir)],
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load dorado evaluator from {evaluator_dir}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)
    return module


def _make_evaluator(game_dir: Path, **kwargs: object) -> Evaluator:
    module = _load_evaluator_module()
    return module.make_evaluator(game_dir, **kwargs)


PLUGIN = GamePlugin(
    name="dorado",
    evaluator_factory=_make_evaluator,
    display_name="Dorado / 黄金冒险",
    roles=("P0", "P1"),
    roles_symmetric=True,
)

#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>
#include <map>
#include <cmath>
#include <fstream>
using namespace std;
Console* console;
inline string lowerCase(const string& str)
{
    string s(str);
    for (int i = 0; i < s.size(); ++i)
    {
        if (s[i] >= 'A' && s[i] <= 'Z')
            s[i] += ('a' - 'A');
    }
    return move(s);
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    console = new Console(map, info, cmd);
    vector<const PUnit*> Hammerguards;
    for(int i = 0; i < info.units.size(); i++)
    {
        if(lowerCase(info.units[i].name) == std::string("hammerguard"))
        {
            Hammerguards.push_back(&info.units[i]);
        }
    }
    console->chooseHero("Hammerguard");

    for(int i = 0; i < Hammerguards.size(); i++)
    {
        console->selectUnit(Hammerguards[i]);
        console->move(MILITARY_BASE_POS[1-console->camp()]);
    }
    
}

"""Dorado legacy AI9 构建与选手池运行时。"""

from __future__ import annotations

import csv
import hashlib
import subprocess
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.buildcache import published_build_dir
from aa_arena.core.build_sandbox import BUILD_SANDBOX_POLICY_VERSION
from aa_arena.legacy.ai9 import (
    Ai9Error, _run_player_build, _runtime_environment, _validate_player_export,
    _validate_player_tree, _compiler_identity,
)


class DoradoRuntimeError(RuntimeError):
    """Dorado 后端或选手准备失败。"""


SDK_SOURCE_NAMES = (
    "sdk.cpp",
    "Pos.cpp",
    "const.cpp",
    "trans.cpp",
    "Operation.cpp",
)


@dataclass(frozen=True)
class DoradoLayout:
    game_dir: Path
    build_root: Path
    backend_source_root: Path
    manifest_path: Path
    player_pool_root: Path
    sdk_include_root: Path
    sdk_sources: tuple[Path, ...]
    sdk_header_roots: tuple[Path, ...] = ()

    @classmethod
    def from_game_dir(cls, game_dir: str | Path, build_root: str | Path) -> "DoradoLayout":
        game = Path(game_dir).resolve()
        backend = game / "backend"
        return cls(
            game_dir=game,
            build_root=Path(build_root).resolve(),
            backend_source_root=backend,
            manifest_path=game / "players" / "manifest.tsv",
            player_pool_root=game / "players" / "pool",
            sdk_include_root=backend / "logic" / "src" / "include" / "sdk",
            sdk_sources=tuple(backend / "logic" / "src" / name for name in SDK_SOURCE_NAMES),
            # SDK .cpp units also need Pos.h, trans.h and ActMaker headers.
            sdk_header_roots=(backend / "logic" / "src" / "include",),
        )

    def validate(self) -> None:
        required = (
            self.backend_source_root / "Makefile",
            self.backend_source_root / "resources.res",
            self.backend_source_root / "map.txt",
            self.backend_source_root / "logic" / "src" / "main.cpp",
            self.backend_source_root / "ailoader" / "src" / "main.cc",
            self.sdk_include_root,
            self.manifest_path,
            self.player_pool_root,
        )
        for path in required:
            if not path.exists():
                raise FileNotFoundError(path)
        for source in self.sdk_sources:
            if not source.is_file():
                raise FileNotFoundError(source)


@dataclass(frozen=True)
class BackendArtifacts:
    logic: Path
    ailoader: Path


@dataclass(frozen=True)
class PreparedPlayer:
    player_id: str
    package_root: Path
    library_path: Path


def _source_digest(paths: tuple[Path, ...] | list[Path]) -> str:
    digest = hashlib.sha256()
    digest.update(_compiler_identity())
    for root in paths:
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix in {".o", ".d", ".pyc"}:
                continue
            relative = path.relative_to(root).as_posix().encode("utf-8")
            content = path.read_bytes()
            digest.update(len(relative).to_bytes(8, "big"))
            digest.update(relative)
            digest.update(len(content).to_bytes(8, "big"))
            digest.update(content)
    return digest.hexdigest()


def _run_build(arguments: list[str], *, cwd: Path) -> None:
    completed = subprocess.run(
        arguments,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=600.0,
        check=False,
        env=_runtime_environment(),
    )
    if completed.returncode != 0:
        diagnostic = completed.stderr.strip() or completed.stdout.strip()
        raise DoradoRuntimeError(
            f"build failed ({' '.join(arguments)}): {diagnostic}"
        )


def build_backend(layout: DoradoLayout) -> BackendArtifacts:
    digest = _source_digest((layout.backend_source_root,))
    target = layout.build_root / "dorado-backend" / digest
    with published_build_dir(target, source=layout.backend_source_root) as (work, reused):
        if not reused:
            _run_build(["make", "all"], cwd=work)

    logic = target / "build" / "logic"
    ailoader = target / "build" / "ailoader"
    if not logic.is_file() or not ailoader.is_file():
        raise DoradoRuntimeError("backend build did not produce logic and ailoader")
    return BackendArtifacts(logic=logic, ailoader=ailoader)


def read_player_ids(layout: DoradoLayout) -> tuple[str, ...]:
    with layout.manifest_path.open(encoding="utf-8", newline="") as stream:
        return tuple(
            row["player_id"].strip()
            for row in csv.DictReader(stream, delimiter="\t")
            if row.get("player_id", "").strip()
        )


def build_player(
    layout: DoradoLayout,
    player_id: str,
    package_root: Path | None = None,
) -> PreparedPlayer:
    package_root = (
        layout.player_pool_root / player_id
        if package_root is None
        else Path(package_root)
    )
    source = package_root / "ai.cpp"
    if not source.is_file():
        raise FileNotFoundError(source)

    try:
        _validate_player_tree(package_root)
    except Ai9Error as exc:
        raise DoradoRuntimeError(str(exc)) from exc
    digest = _source_digest((package_root, layout.backend_source_root))
    target = (layout.build_root / "dorado-players"
              / f"{player_id}-sandbox-v{BUILD_SANDBOX_POLICY_VERSION}-{digest}")
    with published_build_dir(target, source=package_root) as (work, reused):
        try:
            _validate_player_tree(work)
        except Ai9Error as exc:
            raise DoradoRuntimeError(str(exc)) from exc
        if not reused:
            arguments = [
                "g++",
                "-std=c++14",
                "-O2",
                "-fPIC",
                "-shared",
                "-I",
                str(layout.sdk_include_root),
                "ai.cpp",
                *[str(item) for item in layout.sdk_sources],
                "-o",
                "player.so",
            ]
            header_roots = layout.sdk_header_roots or (layout.sdk_include_root,)
            try:
                _run_player_build(
                    arguments, cwd=work,
                    readonly_paths=(*header_roots, *layout.sdk_sources),
                )
            except Ai9Error as exc:
                raise DoradoRuntimeError(str(exc)) from exc

    library = target / "player.so"
    if not library.is_file():
        raise DoradoRuntimeError(f"player {player_id} build did not produce player.so")
    try:
        _validate_player_export("dorado", library)
    except Ai9Error as exc:
        raise DoradoRuntimeError(str(exc)) from exc
    return PreparedPlayer(
        player_id=player_id,
        package_root=package_root,
        library_path=library,
    )

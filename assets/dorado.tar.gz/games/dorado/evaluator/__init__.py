"""Dorado legacy AI9 对战器。"""

from __future__ import annotations

from pathlib import Path

from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.sandbox import SandboxInfrastructureError
from aa_arena.legacy.ai9 import (Ai9Error, Ai9GameConfig, Ai9Backend,
    Ai9PreparedPlayer, run_ai9_match)

from .runtime import (
    DoradoLayout,
    DoradoRuntimeError,
    PreparedPlayer,
    build_backend,
    build_player,
)


class DoradoMatchError(RuntimeError):
    """Dorado 对局执行失败。"""


class DoradoEvaluator:
    """驱动 legacy AI9 Dorado backend + ailoader + player .so。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
        max_rounds: int = 1000,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "dorado-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "dorado-matches"
        )
        self.timeout_s = float(timeout_s)
        self._max_rounds = int(max_rounds)

    def preflight_candidate(self, strategy_root: Path) -> None:
        layout = DoradoLayout.from_game_dir(self.game_dir, self._build_root)
        layout.validate()
        build_player(layout, "candidate", Path(strategy_root))

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"dorado requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"dorado roles must be [P0, P1], got {roles}",
            )

        layout = DoradoLayout.from_game_dir(self.game_dir, self._build_root)
        try:
            layout.validate()
            backend = build_backend(layout)
            prepared = [
                build_player(
                    layout,
                    player.player_id,
                    Path(player.code_path) if player.code_path is not None else None,
                )
                for player in players
            ]
        except (DoradoRuntimeError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/player preparation failed: {exc}",
            )

        try:
            return self._run_match(layout, backend, prepared, seed, self._max_rounds)
        except (Ai9Error, DoradoMatchError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=str(exc),
            )
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"legacy sandbox infrastructure failed: {exc}",
            )

    def _run_match(
        self,
        layout: DoradoLayout,
        backend: object,
        prepared: list[PreparedPlayer],
        seed: int,
        max_rounds: int,
    ) -> EvaluateResult:
        # Use the same bounded startup, complete replay finalization, cleanup,
        # and official-result validation as the other legacy AI9 games.
        config = Ai9GameConfig(
            name="dorado", backend_source_root=layout.backend_source_root,
            player_sdk_includes=(), player_sdk_sources=(), roles=("P0", "P1"),
            player_count=2, resources_source=layout.backend_source_root / "resources.res",
            map_source=layout.backend_source_root / "map.txt",
        )
        return run_ai9_match(
            config, Ai9Backend(backend.logic, backend.ailoader),
            [Ai9PreparedPlayer(p.player_id, p.library_path) for p in prepared],
            build_root=self._build_root, artifact_root=self._artifact_root,
            seed=seed, timeout_s=self.timeout_s, max_rounds=max_rounds,
        )


def make_evaluator(game_dir: Path, **kwargs: object) -> DoradoEvaluator:
    return DoradoEvaluator(game_dir, **kwargs)  # type: ignore[arg-type]

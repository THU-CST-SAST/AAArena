
//这是一个样例AI

#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "algorithm"
using namespace std;

static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Rank = 0;
static int not_fix=1;
static int get_a=0;
static Pos round_pos[10][1000];
static string ronud_buff[10][1000];
/*
bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}
*/

/*static const Pos MINE_POS[] = {Pos(74, 75), 0
                                 Pos(35, 60), 1
                                 Pos(35, 90), 2
                                 Pos(115, 60), 3
                                 Pos(115, 90), 4
                                 Pos(20, 140), 5
                                 Pos(130, 10)};6 
                                 */
/*static const char* UNIT_NAME[UNIT_NAME_SIZE] = {"MilitaryBase", 
													"Mine",
 													"PlayerInformation", 
 													"Hammerguard",
 													"Master", 
  													"Berserker", 
  													"Scouter",
  													"Dog", 
   													"Bow",
    												"Wolf", 
    												"StoneMan",
     												"Dragon",
 													"Roshan"};
 													*/
/*static const char* BUFF_NAME[BUFF_NAME_SIZE] = {"Dizzy", 
                                                  "Reviving", 
                                                  "WaitRevive", 
                                                  "ChosenByBase", 
                                                  "BuyBackByBase", 
                                                  "CallBackByBase", 
                                                  "levelUpByBase", 
                                                  "IsMining", 
                                                  "BeAttacked", 
                                                  "WinOrDie"};*/


static int masteryan_cout=1;
static int need_it=1;
static int debug=5;
class Log
{
	string iname ;
public:
	Log(string name){iname=name;
		if (need_it==2)
		cout <<"iname is "<<iname<<"()..."<<endl;}
	~Log(){
		if (need_it==2)
			if(iname=="attack_tar")
		cout <<"iname is "<<iname<<"()end!@ "<<endl;
	}
	
};
Pos first_go[2]{{130,10},{20,140}};
Pos second_go[2]{{115,90},{35,60}};
Pos attack_go[2]{{60,124},{884,6}};
/*remember_my_infor   
 check_stop
 attack_tar
 set_eye
 do_blink
 taopao
 saprao


 */
struct dangerous
{
	int enemy_number;
	int enemy_action;
	int enemy_power;
	int ok_aaack;
	int x1,x2;
	int y1,y2;
	Pos pos;
};

static dangerous  area_dangerous[2][4]={{{0,0,0,0,6,46,24,148,{15,39}},   {0,0,0,0,55,95,58,95,{74,75}},{0,0,0,0,96,130,71,113,{105,86}},{0,0,0,0,33,148,1,44,{47,11}}},
					   {{0,0,0,0,110,150,4,133,{138,112}},{0,0,0,0,55,95,58,95,{74,75}},{0,0,0,0,27,53,46,71,{41,36}},   {0,0,0,0,0,108,113,150,{89,145}}}};





struct enemy_pos_valud
{
	Pos pos;
	int dis22;
	double value;
	PUnit* tar;
	int len;
};


void analyse_areaccout(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   dangerous a[],
	                   int ii )
{

	int der1=0;
	int der2=0;
	int der3=0;
	int der4=0;
	int number[4]={0};
	int power[4]={0};

	if (enemy_inc_hero.size()!=0)
	{
		
			for (int ij = 0; ij < 4; ++ij)
			{
				for (int i = 0; i < enemy_inc_hero.size(); ++i)
				{
					if (   enemy_inc_hero[i]->pos.x<=area_dangerous[info.player][ij].x2
						&& enemy_inc_hero[i]->pos.x>=area_dangerous[info.player][ij].x1
						&& enemy_inc_hero[i]->pos.y<=area_dangerous[info.player][ij].y2
						&& enemy_inc_hero[i]->pos.y>=area_dangerous[info.player][ij].y1
						)
					{
						number[ij]++;
						power[ij]+=45+4*enemy_inc_hero[i]->level;
					}
				}

				area_dangerous[info.player][ij].enemy_number=number[ij];
				area_dangerous[info.player][ij].enemy_power=number[ij];

			}
	}
}

double calculate_en(int asd ,Console &console,
			vector<PUnit*> &enemy_inc_hero,
			Pos a,
           	int eye_size=144
          	 )
{
	Log p("calculate_en");
	double sk=0;
	double hero=0;
	for (int i = 0; i < enemy_inc_hero.size(); ++i)
	{
		if (enemy_inc_hero[i]->isHero()&&(dis2(enemy_inc_hero[i]->pos,a)<=eye_size))
		{
			
			if(strcmp(enemy_inc_hero[i]->name,"Hammerguard")==0&&enemy_inc_hero[i]->hp >0)
			{
				hero+=50+6*enemy_inc_hero[i]->level;
				if (enemy_inc_hero[i]->canUseSkill("HammerAttack"))
				{
					hero+=3*enemy_inc_hero[i]->level;
					sk++;
				}
			}

			if (strcmp(enemy_inc_hero[i]->name,"Berserker")==0&&enemy_inc_hero[i]->hp >0)
			{
				hero+=30+4*enemy_inc_hero[i]->level;
				if (enemy_inc_hero[i]->canUseSkill("Sacrifice"))
				{
					hero+=20;
					sk++;
				}
				if (enemy_inc_hero[i]->findBuff("WinOrDie"))
				{
					hero+=30;
					sk++;
				}
			}
			if (strcmp(enemy_inc_hero[i]->name,"Master")==0&&enemy_inc_hero[i]->hp >0)
			{
				hero+=30+3*enemy_inc_hero[i]->level;
			}
			if (strcmp(enemy_inc_hero[i]->name,"Scouter")==0&&enemy_inc_hero[i]->hp >0)
			{
				hero+=30+3*enemy_inc_hero[i]->level;
			}
			
		}
	}
	if (asd==1)
	{
		return sk;
	}
	return hero;
}
double calculate_my(int asd,Console &console,
			vector<PUnit*> &myUnits,
			Pos a,
           	int eye_size=144
          	 )
{
	Log p("calculate_my");
	double sk=0;
	double hero=0;
	for (int i = 0; i < myUnits.size(); ++i)
	{
		if (myUnits[i]->isHero()&&(dis2(myUnits[i]->pos,a)<=eye_size))
		{
			
			if(strcmp(myUnits[i]->name,"Hammerguard")==0&&myUnits[i]->hp >0)
			{
				hero+=50+6*myUnits[i]->level;  
				if (myUnits[i]->canUseSkill("HammerAttack")&&myUnits[i]->hp >0)
				{
					sk++;
					hero+=3*myUnits[i]->level;
				}
			}

			if (strcmp(myUnits[i]->name,"Berserker")==0&&myUnits[i]->hp >0)
			{
				hero+=30+4*myUnits[i]->level;	
				if (myUnits[i]->canUseSkill("Sacrifice"))
				{
					hero+=20;
					sk++;
				}
				if (myUnits[i]->findBuff("WinOrDie"))
				{
					hero+=30;
					sk++;
				}
			}
			if (strcmp(myUnits[i]->name,"Master")==0&&myUnits[i]->hp >0)
			{
				hero+=30+3*myUnits[i]->level;
			}
			if (strcmp(myUnits[i]->name,"Scouter")==0&&myUnits[i]->hp >0)
			{
				hero+=30+3*myUnits[i]->level;
			}
			
		}
	}
	


	if (asd==1)
	{
		return sk;
	}

	return hero;
}
 

PUnit* near(
					   const PMap &map, //  完成刷野，采矿，移动
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,int ii
	                   )
{
	int juli=1000;
	PUnit* need_check;
	if (enemy_inc_hero.size()!=0)
	{
		for (int i = 0; i < enemy_inc_hero.size(); ++i)
		{
			int e_m_juli=dis2(myUnits[ii]->pos,enemy_inc_hero[i]->pos);
			if (e_m_juli<=juli)
			{
				juli=e_m_juli;
				need_check=enemy_inc_hero[i];
			}
		}
	}

	return(need_check);
}


void use_attack_skill(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii,
	                   PUnit *tar
	                   )
{
	Log p("use_attack_skill");



	int can_attack_number=0;
	for (int i = 0; i < myUnits.size(); ++i)
	{
		if (myUnits[i]->canUseSkill("Sacrifice")&&dis2(myUnits[i]->pos,myUnits[ii]->pos)<=144)
		{
			can_attack_number++;
		}
	}

	int juli=100000;
	PUnit* tar_2=NULL;
	if(enemy_inc_hero.size()>1)
	{
		for (int i = 0; i < enemy_inc_hero.size(); ++i)
		{

			int cur_juli = dis2(myUnits[ii]->pos,enemy_inc_hero[i]->pos);
 			if (cur_juli <= juli && enemy_inc_hero[i]->isHero())
			{
				juli = cur_juli;
				tar_2 = enemy_inc_hero[i];
			}
		}
	}


	if (debug==1)
	{
		cout <<"use_attack_skill"<<endl;
	}


		if (myUnits[ii]->canUseSkill("Sacrifice"))
		{	

			if (masteryan_cout==6)
			{

				    if (myUnits[ii]->canUseSkill("Sacrifice")&& dis2(myUnits[ii]->pos,tar->pos)<=4&& tar->hp>=150)
					{			
						console.useSkill( "Sacrifice",NULL);
					}
					else
					{
						console.attack(tar);//cout<<" Scouter do attack "<<endl;
					}

			}
			else
			{
				if (myUnits[ii]->canUseSkill("Sacrifice")&& dis2(myUnits[ii]->pos,tar->pos)<=16&& tar->hp>=150)
						{			
							console.useSkill( "Sacrifice",NULL);
						}
						else
						{
							console.attack(tar);//cout<<" Scouter do attack "<<endl;
						}
			}
		}
		else
	if (strcmp(myUnits[ii]->name,"Hammerguard")==0&&dis2(myUnits[ii]->pos,tar->pos)<=HAMMERATTACK_RANGE&& tar->hp>=75)
		{	




			if (masteryan_cout==6)
			{
				if (tar_2!=NULL)
				{
					if (dis2(myUnits[ii]->pos,tar_2->pos)<=36&&myUnits[ii]->canUseSkill("HammerAttack"))
					{
						console.useSkill( "HammerAttack", tar_2);					
					}
					else
					{
						console.attack(tar);
					}
				}
				else
				{
					console.attack(tar);
				}
			}
			else			
			{
				if (myUnits[ii]->canUseSkill("HammerAttack")&&(!tar->isBase()))
						{			
							console.useSkill( "HammerAttack", tar);
						}
						else
						{
							console.attack(tar);//cout<<" Hammerguard do attack "<<endl;
						}
			}
		}
		else
			console.attack(tar);
}

void remember_my_infor(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii 
	                   )
{
	if (debug==1)
	{
		cout <<"remember_my_infor"<<endl;
	}
	round_pos[ii][info.round]=myUnits[ii]->pos;


}


bool check_stop(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii 
	                   )
{
	if (debug==1)
	{
		cout <<"check_stop"<<endl;
	}

	Pos now=myUnits[ii]->pos;
	for (int i = info.round-15; i < info.round; ++i)
	{
		if(now!=round_pos[ii][i])
			return 0;
	}

	return 1;
}
bool cmp(enemy_pos_valud& v1, enemy_pos_valud& v2)
{
	return (v1.dis22<v2.dis22);
}
 
PUnit* attack_tar(const PMap &map, //  骚扰？          
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii 
	                   )
{
	Log p("attack_tar");

	enemy_pos_valud  value[20],special[20],final_;
		for (int i = 0; i < 20; ++i)
		{
			//cout << "init++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
			value[i].tar=NULL;
			//value[i].dis22=-1;
			special[i].tar=NULL;
			//special[i].diss22=-1;
		}

		final_.tar=NULL;

		int length_value=0,length_special=0;
		for (int i = 0; i < enemy_inc_hero.size(); ++i)
		{
			//cout << enemy_inc_hero[i]->name <<endl;
			int juli=0;
			for (int ij = 0; ij < myUnits.size(); ++ij)
			{
				if (dis2(myUnits[ii]->pos,myUnits[ij]->pos)<=144)
				{
					juli+=dis2(myUnits[ij]->pos,enemy_inc_hero[i]->pos);
				}
			}
			value[i].pos=enemy_inc_hero[i]->pos;
			value[i].tar=enemy_inc_hero[i];
			if(enemy_inc_hero[i]->max_hp>55)
			{
				value[i].dis22=juli;
				if (enemy_inc_hero[i]->findBuff("Dizzy")==NULL)
				{
					juli+=3;
				}
				if (strcmp(enemy_inc_hero[i]->name,"Hammerguard")==0)
				{
					juli-=4;
				}
				if (strcmp(enemy_inc_hero[i]->name,"Master")==0)
				{
					juli-=4;
				}
				if (enemy_inc_hero[i]->hp<=160)
				{
					juli-=5;
				}
				if (dis2(myUnits[0]->pos,enemy_inc_hero[i]->pos)<=64)
				{
					juli-=(250-dis2(myUnits[0]->pos,enemy_inc_hero[i]->pos));
				}

			}
			else
				value[i].dis22=10000000;
			length_value++;

			if (enemy_inc_hero[i]->isBase())
			{

				final_.pos=enemy_inc_hero[i]->pos;
				final_.tar=enemy_inc_hero[i];
				final_.dis22=dis2(myUnits[ii]->pos,enemy_inc_hero[i]->pos);
			}
		}

		if (final_.tar!=NULL)
		{
			return final_.tar;
		}
		
		sort(value, value+length_value, cmp);


		for (int i = 0; i < length_value; ++i)
		{

			//!myUnits[i]->findBuff("WinOrDie")
			if ((strcmp(value[i].tar->name,"Berserker")==0))
			{
				special[length_special]=value[i];
				length_special++;
			}
		}

		if(dis2(myUnits[ii]->pos,myUnits[0]->pos)<=900)
			{
				if (length_special==1)
					{
						if (ii==0)
						{
							return special[0].tar;
						}
					}
					if (length_special==2)
					{
						if (ii==0)
						{
							return special[0].tar;
						}
						if(ii!=3)
						{
							return special[1].tar;
						}
					}
					if (length_special==3)
					{
						if (ii==0)
						{
							return special[0].tar;
						}
						if(ii==4)
						{
							return special[1].tar;
						}
						if(ii==5)
						{
							return special[2].tar;
						}
					}

					else return value[0].tar;
			}


	if (enemy_inc_hero.size()!=0&&enemy_inc_wild.size()==0)
	{
		//cout << "hero _ choose"<<endl;
		if (strcmp(myUnits[ii]->name,"Master")||strcmp(myUnits[ii]->name,"Scouter"))
		{
			if (special[0].tar!=NULL)
			{
				return special[0].tar;
			}

		}
		
		if (strcmp(myUnits[ii]->name,"Scouter")||strcmp(myUnits[ii]->name,"Master"))
		{
			if (special[0].tar!=NULL)
			{
				return special[0].tar;
			}
		}
		
		if(masteryan_cout!=9)
		return value[0].tar;
		else 
			{
				if (final_.tar!=NULL)
				{
					return final_.tar;
				}
				else
				{
					return value[0].tar;
				}
			} 
	}

	if (enemy_inc_hero.size()==0&&enemy_inc_wild.size()!=0)
	{
		for (int i = 0; i < enemy_inc_wild.size(); ++i)
		{
			
			{
				if (enemy_inc_wild[i]->hp>0)
				{
					return enemy_inc_wild[i];
				}
				
			}
		}
	}

	if (enemy_inc_wild.size()!=0&&enemy_inc_hero.size()!=0)
	{
		if (strcmp(myUnits[ii]->name,"Master"))
		{
			if (special[0].tar!=NULL)
			{
				return special[0].tar;
			}

		}
		
		if (strcmp(myUnits[ii]->name,"Scouter"))
		{
			if (special[0].tar!=NULL)
			{
				return special[0].tar;
			}
		}
		if(masteryan_cout!=9)
		return value[0].tar;
		else 
			{
				if (final_.tar!=NULL)
				{
					return final_.tar;
				}
				else
				{
					return value[0].tar;
				}
			} 
	}

	return NULL;
}

int  gather(const PMap &map, //  聚集
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int masteryan_cout,
	                   int team[],
	                   int need_number,
	                   Pos a,
	                   int eye_size=16
	                   )
{ 
	Log p("gather" );

	if (debug==1)
	{
		
		
		cout <<"gather"<<endl;
		cout << team[0] << team[1]<<team[2]<<endl;
		if (need_number>myUnits.size())
		{
			need_number=myUnits.size();
		}
		//cout << myUnits[need_number]->name<<need_number<< endl;
	}

	int gather_number=0;


	for (int i = 0; i < need_number; ++i)

	{	
		if(team[i]<myUnits.size())
		{
			if (myUnits[team[i]]->isHero())
				{
					if (dis2(myUnits[team[i]]->pos,a)<=eye_size)
					{
						gather_number++;
					}
					
				}
		}
	}
	return gather_number;
}

void set_eye(const PMap &map, //  放置眼
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int masteryan_cout,
	                   int ii,
	                   Pos a
	                   )
{
	Log p("set_eye");

	cout << "set_______________________________________________________________________eye" <<endl;


	Pos newp;
	newp.x=a.x+3;
	newp.y=a.y+1;
	int can_set_pop_real=0;
	for (int cx = -3; cx < 2; ++cx)
		{
			for (int cy = -2; cy < 2; ++cy)
			{
				Pos asd;
				asd.x=a.x+cx;
				asd.y=a.y+cy;
				int juli=-1;
				int can_set_pop=1;
				for (int c = 0; c <enemy_inc_mine.size() ; ++c)
				{
					if(enemy_inc_mine[c]->pos.x==asd.x&&enemy_inc_mine[c]->pos.y==asd.y)
					{
						can_set_pop=0;
						break;
					}
				}

				for (int c = 0; c <enemy_inc_hero.size() ; ++c)
				{
					if(enemy_inc_hero[c]->pos.x==asd.x&&enemy_inc_hero[c]->pos.y==asd.y)
					{
						can_set_pop=0;
						break;
					}
				}

				for (int c = 0; c <myUnits.size() ; ++c)
				{
					if(myUnits[c]->pos.x==asd.x&&myUnits[c]->pos.y==asd.y)
					{
						can_set_pop=0;
						break;
					}
				}

				if (can_set_pop)
				{
					can_set_pop_real=1;
					if (dis2(asd,a)>=juli || dis2(asd,a)>=4)
					{
						juli=dis2(asd,a);
						newp=asd;
					}
				}
			}
		}
	if (myUnits[ii]->canUseSkill("SetObserver") 
		&& dis2(newp,myUnits[ii]->pos)<=SET_OBSERVER_RANGE
		&&can_set_pop_real)
		{			
			cout <<"^&^&^&^&^&^&^^&^&^^&&^&^&^&^&%%&^&^^&^&^&^&^&"<<endl;
			console.useSkill( "SetObserver",newp);
			
		}
}

void do_blink(const PMap &map, //  ccout分析
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int masteryan_cout,
	                   Pos a,
	                   int ii
	                   )
{	
			Log p("do_blink");
		
			{
				
	  	 	 	int x= a.x;
	   			int y= a.y;
	   			int c= int(1.1);
	   			Pos Blink_go(x+myUnits[ii]->pos.x,y+myUnits[ii]->pos.y);
	   			//map.getheight(x,y);
				int fly_max_away=dis2(a,myUnits[ii]->pos);
				Pos fly_away_fianl;
				int ok_fly_away_fianl=0;
	   			for (int di = -4; di <= 4; ++di)
					{
						for(int dj=-4; dj<=4; ++dj)
						{
							Pos fly_away;
							int ok_fly_away=1;
							fly_away.x=Blink_go.x+di;
							fly_away.y=Blink_go.y+dj;

							if (dis2(fly_away,a)>fly_max_away&&(checkPos(fly_away)))
							{
								//map.getheight(x,y)
								if (dis2(myUnits[ii]->pos,fly_away)>81&& map.getHeight(fly_away.x,fly_away.y)<=5)
								{
									ok_fly_away=0;
								}

								if (ok_fly_away)
								{
									cout << "我要上天" << endl;
									fly_max_away=dis2(fly_away,a);
									fly_away_fianl=fly_away;
									ok_fly_away_fianl=1;
								}
								
							}
						}
					}
				if(ok_fly_away_fianl)	
	   				{console.useSkill( "Blink",Blink_go);}
	   			else
					console.move(Blink_go);
			}				
					
} 


static      Pos force_go[20];
static 		Pos force_go1[20];

Pos tao_pao(const PMap &map, //  ccout分析
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int masteryan_cout,
	                   Pos a, 
	                   int ii)
{
	Log p("tao_pao");
	Pos run_away_pos(myUnits[0]->pos);	
	int noway_to_go_away=0;							

	if (dis(myUnits[ii]->pos , a)>=1)//  合适的逃跑距离   bool checkPos(Pos A);
	{
		int x= int (8.0*(myUnits[ii]->pos - a).x/(dis(myUnits[ii]->pos , a)));
		int y= int (8.0*(myUnits[ii]->pos - a).y/(dis(myUnits[ii]->pos , a)));
		run_away_pos.x=x;
		run_away_pos.y=y;
		Pos cur_goaway=myUnits[ii]->pos;
		int juli=dis2(myUnits[ii]->pos,a);
		if (!checkPos(run_away_pos))
		{
			for (int cx = -5; cx < 5; ++cx)
			{
				for (int cy = -5; cy < 5; ++cy)
				{
					Pos asd;
					asd.x=myUnits[ii]->pos.x+cx;
					asd.y=myUnits[ii]->pos.y+cy;
					if (checkPos(asd))
					{
						if (dis2(asd,a)>=juli)
						{
							juli=dis2(asd,a);
							cur_goaway=asd;
						}
					}
				}
			}
			run_away_pos=cur_goaway;

			if (run_away_pos.x==myUnits[ii]->pos.x&&run_away_pos.y==myUnits[ii]->pos.y)
			{
				noway_to_go_away=1;
			}
		}
	}
	else
		run_away_pos=myUnits[0]->pos;
	if (dis2(myUnits[ii]->pos,force_go[ii])<=144)
	{
		return(myUnits[0]->pos);
	}
	return run_away_pos;
}


static Pos force_go_t[2]={{107,65},{104,93}};




void tou_kuang(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii 
	                   )
{
	cout << "偷矿" <<endl;
	if (enemy_inc_hero.size()==1)
		
		{


		PUnit* nearist_hero;
		nearist_hero= near(
					   map, 
	                   info, 
	                   cmd,
	                   console,
	                   myUnits,
	                   enemy_inc_hero,
	                   enemy_inc_wild,
	                   enemy_inc_mine,
	                   masteryan_cout, ii
	                   );

			if (dis2(myUnits[ii]->pos,force_go_t[0])<=64)
			{
				if (nearist_hero!=NULL)
				{
					if(dis2(myUnits[ii]->pos,nearist_hero->pos)<=36)
					console.attack(nearist_hero);
				}
				
			}
		}
		else
	if(dis2(myUnits[ii]->pos,force_go_t[0])<=64)
	{
		console.useSkill( "Blink",force_go_t[0]);
	}
	else
	{
		console.move(force_go_t[0]);
	}


}


static 	  int eye_number02=0;
static	  int eye_number04=0;
static	  int eye_number05=0;
static    int eye_number00=0;

static Pos sao_rao_mine[2]={{115,90},{35,60}};
static Pos obsever_eney_base[2]={{135,145},{15,5}};
static Pos force_go2[2][11]={{{63,63},{81,141},{138,126},{125,95},{116,60},{105,79},{75,22},{91,65},{16,10},{34,75},{}},
							 {{91,83},{73,7},{12,32},{31,51},{34,140},{45,68},{63,84},{75,119},{134,140},{122,73},{}}};
static int key=0;
static int key_all=0;


static Pos black[2]={{124,129},{24,20}};
void sao_rao(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii 
	                   )
{

	  Log p("sao_rao");
	  cout << "我在骚扰"<<endl;


	  

	  //三点路线循环
	  {  
	  	
	  	if (dis2(myUnits[ii]->pos,force_go2[info.player][key_all])>=4)
	  	{

	  		console.move(force_go2[info.player][key_all]);
	  		cout << "我在路上" <<endl;
	  		cout << "my_pos  is"<<"<"<< myUnits[ii]->pos.x << "," << myUnits[ii]->pos.y<<">"<<endl;
	  		cout << "i_want  to is"<<"<"<< force_go2[info.player][key_all].x << "," << force_go2[info.player][key_all].y<<">"<<endl;

	  	}
	  	else 
	  		{
	  			key_all++;
	  			key_all=key_all % 10;
				
	  			if (dis2(myUnits[ii]->pos,force_go2[info.player][key])<=4&&eye_number02==0)
	  				{
	  					//set_eye
	 			 		cout << " 第一处" <<endl;
	 			 		if (myUnits[ii]->canUseSkill("SetObserver") )
				  		{
				  			cout <<"我可以放眼)))))))))))))))))))))))))))))"<<endl;
				  		}
				  		if (myUnits[ii]->canUseSkill("SetObserver") )
				  		set_eye(map, //  放置眼
				                info, 
				                cmd,
				                console,
				                myUnits,
				                enemy_inc_hero,
				                enemy_inc_wild,
				                enemy_inc_mine,
				                masteryan_cout,
				                ii,
				                myUnits[ii]->pos
				                   );
				  	key++;
	  			key=key % 3;
					
	  				}
	  			if (dis2(myUnits[ii]->pos,force_go2[info.player][key])<= 4 &&eye_number05==0)
	  				{
				  		cout << "到了第二处" <<endl;
				  		if (myUnits[ii]->canUseSkill("SetObserver") )
				  		{
				  			cout <<"我可以放眼)))))))))))))))))))))))))))))"<<endl;
				  		}
				  		set_eye(map, //  放置眼
				                info, 
				                cmd,
				                console,
				                myUnits,
				                enemy_inc_hero,
				                enemy_inc_wild,
				                enemy_inc_mine,
				                masteryan_cout,
				                ii,
				                myUnits[ii]->pos
				                   );
				  	key++;
	  			key=key % 3;
				  
				  	}
	  			if (dis2(myUnits[ii]->pos,force_go2[info.player][key])<=4&&eye_number04==0)
	  				{
				  		cout << "到了第3处" <<endl;
				  		if (myUnits[ii]->canUseSkill("SetObserver") )
				  		{
				  			cout <<"我可以放眼))))))))))))))))))))))))))))))"<<endl;
				  		}

				  		set_eye(map, //  放置眼
				                info, 
				                cmd,
				                console,
				                myUnits,
				                enemy_inc_hero,
				                enemy_inc_wild,
				                enemy_inc_mine,
				                masteryan_cout,
				                ii,
				                 myUnits[ii]->pos
				                   );
				  	key++;
	  			key=key % 3;
				  	}
				
	  		}
	  }


}


static int need_gather=1;
	static int not_gather=1;
	static Pos before_go_c[2]={{53,53},{104,104}};
	static Pos formal_f[2]={{40,60},{110,88}};
	static Pos formal_s[2]={{20,140},{130,10}};
	static int need_m_2_g=1;
	static int need_m_2_a=1; 
	static int kky=0;
	static int rank_k=0;

static Pos way1[2][4]={{{20,140},{38,149},{103,135},{135,145}},{{20,140},{2,127},{2,40},{15,5}}}; 
static int  kky1[10]={0};
static Pos way2[2][4]={{{130,10},{148,19},{145,103},{135,145}},{{130,10},{111,0},{60,7},{15,5}}};
static int  kky2[10]={0};
static int way=0;
static Pos set_tou_eye[2]={{137,123},{16,35}};
static Pos go_to_defend_final[2]={{15,4},{132,140}};
static Pos stand[2]={{72,73},{76,75}};
static int change=1;
static int reason_number=6; 
void do_master_yan_do_i_not_see_enemy(//////////////////////////////////////001
					   const PMap &map, //  完成刷野，采矿，移动
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,int ii,int size_hero
	                   )
{
	Log p("do_master_yan_do_i_not_see_enemy");	
	PUnit *_tar=attack_tar(map,info,cmd,console,myUnits,
		enemy_inc_hero,enemy_inc_wild,
		enemy_inc_mine,masteryan_cout,ii);
	/*
	1 ~ 5   ：前期
	6 ~ 10	：中期
	10 ~ 15
	15 ~ 20

	*/

	if (size_hero<=5)
	{
		if (_tar!=NULL)
		{
			if (strcmp(_tar->name,"Roshan")==0)
			{
				_tar=NULL;
			}
		}
	}


	if (masteryan_cout==99)
	{
		_tar=NULL;
	}

	if (_tar!=NULL && _tar->hp>0 )
	{
		use_attack_skill(map,info,cmd,console,myUnits,
				enemy_inc_hero,enemy_inc_wild,
				enemy_inc_mine,masteryan_cout,ii,_tar);
				cout << " attack " << endl;
	}
	else
	{

		if (masteryan_cout==0)
		{
			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=stand[info.player];
			}
			console.move(stand[info.player]);

			if (info.gold>=600)
			{
				masteryan_cout=6;
			}

		}

		if (masteryan_cout==1)
		{
			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=MINE_POS[0];
			}
			console.move(MINE_POS[0]);
		}

		if (masteryan_cout==2)
		{

			way=1;	

			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=formal_s[0];
			}
			console.move(formal_s[0]);
		}

		if (masteryan_cout==4)
		{
			way=0;
			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=formal_s[1];
			}
			console.move(formal_s[1]);
		}

		if (masteryan_cout==3)
		{
			if (way==1)
			{
				for (int i = 0; i < myUnits.size(); ++i)
				{
					force_go[i]=  way1[info.player][0];
				}

				int get_there_3_1=0;
				for (int i = 0; i < myUnits.size(); ++i)
				{
					if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,way1[info.player][0])<=16)
					{
						get_there_3_1++;
					}
				}

				if (get_there_3_1>=reason_number)
				{
					for (int i = 0; i < 10; ++i)
					{
						kky1[i]=1;
						kky2[i]=1;
					}
					masteryan_cout=5;			
				}
			}
			if (way==0)
			{
				for (int i = 0; i < myUnits.size(); ++i)
				{
					force_go[i]=way2[info.player][0];
				}

				int get_there_3_2=0;
				for (int i = 0; i < myUnits.size(); ++i)
				{
					if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,way2[info.player][0])<=16)
					{
						get_there_3_2++;
					}
				}

				if (get_there_3_2>=reason_number)
				{
					for (int i = 0; i < 10; ++i)
					{
						kky1[i]=1;
						kky2[i]=1;
					}
					masteryan_cout=5;			
				}

			}

			console.move(force_go[ii]);
		}


		if (masteryan_cout==5)
		{
			
			if (way==1)
			{
				
				if (dis2(myUnits[ii]->pos,way1[info.player][kky1[ii]])<=144&&kky1[ii]<2)
				{
						cout << "yes^^^^^^^^^^^^^^^^^^^^^^___________________^^^^^"<< kky1[ ii] <<"-> "<< kky1[ii] +1<<endl;
					kky1[ii]++;
					//kky1[ii]=kky1[ii]%3;
				}

				int get_there_4_1=0;
				for (int i = 0; i < myUnits.size(); ++i)
				{
					if (myUnits[i]->isHero()&& dis2(myUnits[i]->pos,way1[info.player][2])<=16)
					{
						get_there_4_1++;
					}
				}

				if (get_there_4_1>=reason_number)
				{
					masteryan_cout=6;			
				}
						force_go[ii]=way1[info.player][kky1[ii]];

			
			}
			else
			{
				//kky1[ii]=0;
				if (dis2(myUnits[ii]->pos,way2[info.player][kky2[ii]])<=144&&kky2[ii]<2)
					{

						cout << "yes^^^^^^^^^^^^^^^^^___________________^^^^^^^^^^"<< kky2[ ii] <<"-> "<< kky2[ii]+1 <<endl;
						kky2[ii]++;
						//kky2[ii]=kky2[ii]%3;
					}


					int get_there_4_2=0;
					for (int i = 0; i < myUnits.size(); ++i)
					{
						if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,way2[info.player][2])<=16)
						{
							get_there_4_2++;
						}
					}


					if (get_there_4_2>=reason_number)
					{
						masteryan_cout=6;			
					}
						force_go[ii]=way2[info.player][kky2[ii]];

			
			}


				// cout << "i chhose    ="<< way << endl;
				// cout << dis2(myUnits[ii]->pos,way2[info.player][kky2[ii]])<<" w_2    ="<< kky2[ii] <<endl;
				// cout << dis2(myUnits[ii]->pos,way1[info.player][kky1[ii]])<<" w_!    ="<< kky1[ii] <<endl ;
				// cout << way << " " << " 我要去 " << force_go[ii].x << "," << force_go[ii].y << endl;
				// cout << way << " way1 " << " 我要去 " << way1[info.player][kky1[ii]].x << "," << way1[info.player][kky1[ii]].y << endl;
				// cout << way << " way2 " << " 我要去 " << way2[info.player][kky2[ii]].x << "," << way2[info.player][kky2[ii]].y << endl;
				// cout << way1[info.player][kky1[ii]].x << " , " <<way1[info.player][kky1[ii]].y <<kky1[ii] << endl; 
				// cout << way2[info.player][kky2[ii]].x << " , " <<way2[info.player][kky2[ii]].y <<kky2[ii] << endl; 
				// cout << "我在"<< myUnits[ii]->pos.x << "," << myUnits[ii]->pos.y << endl;

			console.move(force_go[ii]);

		}
		
		if (masteryan_cout==6)
		{

			int get_there_5_2=0;
					for (int i = 0; i < myUnits.size(); ++i)
					{
						if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,way2[info.player][3])<=900)
						{
							get_there_5_2++;
						}
					}


			if (dis2(myUnits[ii]->pos,myUnits[0]->pos)<=400 && get_there_5_2<=1)
			{
				for (int i = 0; i < 10; ++i)
				{
					kky1[i]=0;
					kky2[i]=0;
				}

				way=info.round%2;


				cout << "change^^^^^^^___________________^^^^^" << endl;
				masteryan_cout=0;
			}
			
			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=(way1[info.player][3]);
			}
			console.move(force_go[ii]);
			
		}

		if (masteryan_cout==99)
		{


			int save_number=0;
			for (int i = 0; i < myUnits.size(); ++i)
			{
				if (dis2(myUnits[i]->pos,myUnits[0]->pos)<=144)
				{
					save_number++;
				}

				force_go[i]=go_to_defend_final[info.player];
			}
			console.move(force_go[ii]);


			if (save_number>=6)
			{
				masteryan_cout=3;
			}
		}

		if (masteryan_cout==360)
		{

			int c_360=0; 

			for (int i = 0; i < myUnits.size(); ++i)
			{
				force_go[i]=black[info.player];
				c_360++;
			}
			console.move(force_go[ii]);

			masteryan_cout=6;


		}
	}


}

void do_master_yan_do_i_see_enemy(const PMap &map, //  逃跑？ 打？ 移动？扎堆？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,int ii,int size_hero
	                   )
{
	Log p("do_master_yan_do_i_see_enemy");

	//if(analyse_can_attack())
	if (debug==1)
	{
		cout <<"do_master_yan_do_i_see_enemy"<<endl;
	}

	PUnit *_tar=attack_tar(map,info,cmd,console,myUnits,enemy_inc_hero,enemy_inc_wild,enemy_inc_mine,masteryan_cout,ii);
	{
		int   my_power =  calculate_my(2,console,myUnits,myUnits[ii]->pos,36);
		int   en_power =  calculate_my(2,console,enemy_inc_hero,myUnits[ii]->pos,144);

		if (masteryan_cout==1)
		{
			if (my_power<en_power)
			{
				masteryan_cout=2;
			}
		}

		if (masteryan_cout==2)
		{
			if (my_power<en_power-50&&dis2(myUnits[ii]->pos,formal_s[info.player])<=144)
			{
				masteryan_cout=4;
			}
		}

		if (masteryan_cout==4)
		{
			if (my_power<en_power-50&&dis2(myUnits[ii]->pos,formal_s[(info.player+1)%2])<=144)
			{
				masteryan_cout=2;
			}
		}
		if(masteryan_cout==5)
		{

			if (my_power<en_power-50)
			{

				if (way==1)
				{
					masteryan_cout=4;

					way=0;
				}
				if (way==0)
				{

					masteryan_cout=2;
					way=1;
				}
				
			}


		}
		if (masteryan_cout>=5||masteryan_cout==0)
		{
			if (en_power<my_power-100 && masteryan_cout!=6)
			{
				masteryan_cout=360;
			}
			
		}


		if (masteryan_cout==360)
		{
			if (en_power>my_power-70 )
			{
				masteryan_cout=0;
			}
			if (enemy_inc_hero.size()<=3)
			{
				masteryan_cout=6;
			}
		}

		if (masteryan_cout==0)
		{
			
				//cout << "&Ω≈Ω≈ç√∫µ≤≥œ∑®†¥øπ“åß∂ƒ©˙∆˚¬…æΩ≈ç√∫µ≤≥÷"<<endl;

			{
				for (int i = 0; i < myUnits.size(); ++i)
				{
				force_go[i]=stand[info.player];
				}
			//console.move(MINE_POS[0]);
			}

			if (en_power-40>my_power)
			{
				masteryan_cout=3;
			}

		}

		PUnit* nearist_hero;
		nearist_hero= near(
					   map, 
	                   info, 
	                   cmd,
	                   console,
	                   myUnits,
	                   enemy_inc_hero,
	                   enemy_inc_wild,
	                   enemy_inc_mine,
	                   masteryan_cout, ii
	                   );
		Pos i_shuold_go= tao_pao(map, //  ccout分析
	                   info, 
	                   cmd,
	                   console,
	                   myUnits,
	                   enemy_inc_hero,
	                   enemy_inc_wild,
	                   enemy_inc_mine,
	                   masteryan_cout,
	                   nearist_hero->pos,
	                   ii);


		if (masteryan_cout!=6)
		{
			if (_tar!=NULL)
			{

				//cout << "!!!!!!!!!@#$%^&*()"<<endl;
				cout << dis2(myUnits[ii]->pos,force_go[ii]) << endl;
				if(dis2(_tar->pos,myUnits[0]->pos)>=2000)
				{
					if (masteryan_cout==360)
							{
								if (dis2(myUnits[ii]->pos,way2[info.player][3])<=361)
								{
									console.move(black[info.player]);
								}
								else
								{
				
									use_attack_skill(map,info,cmd,console,myUnits,
											enemy_inc_hero,enemy_inc_wild,
											enemy_inc_mine,masteryan_cout,ii,_tar);
											cout << " attack " << endl;
								}
							}
							else if(masteryan_cout==2||masteryan_cout==4)
							{
								if (dis2(myUnits[ii]->pos,force_go[ii])<=70)
										{
											use_attack_skill(map,info,cmd,console,myUnits,
											enemy_inc_hero,enemy_inc_wild,
											enemy_inc_mine,masteryan_cout,ii,_tar);
											cout << " attack " << endl;
							 			}
							 			else
							 			{
							 				if (en_power<my_power-40)
							 				{
							 					use_attack_skill(map,info,cmd,console,myUnits,
											enemy_inc_hero,enemy_inc_wild,
											enemy_inc_mine,masteryan_cout,ii,_tar);
											cout << " attack " << endl;
							 				}
							 				else
							 				console.move(force_go[ii]);
							 			}
							 }

							 else
							 {

							 				if (en_power-40<my_power)
							 				{
							 					use_attack_skill(map,info,cmd,console,myUnits,
											enemy_inc_hero,enemy_inc_wild,
											enemy_inc_mine,masteryan_cout,ii,_tar);
											cout << " attack " << endl;
							 				}
							 				else
							 				console.move(force_go[ii]);
							 			
							 }

				}
				else
				{
					use_attack_skill(map,info,cmd,console,myUnits,
											enemy_inc_hero,enemy_inc_wild,
											enemy_inc_mine,masteryan_cout,ii,_tar);
											cout << " attack " << endl;
							 				
				}
			}
			else
			{
				console.move(force_go[ii]);
			}
		}
		else
		{

			if (ii==3||ii==2)
			{
				if (_tar!=NULL&&dis2(_tar->pos,myUnits[ii]->pos)<=100)
				
				{
					cout << "!@#!@#!@!@#" << endl;
					if (myUnits[ii]->findBuff("Sacrifice")==NULL && (myUnits[ii]->hp<210 ) && myUnits[ii]->findBuff("BeAttacked") && nearist_hero->isHero() && nearist_hero->findBuff("attack") )
								{
									console.move(i_shuold_go);
								}
								else
								{
									use_attack_skill(map,info,cmd,console,myUnits,
																		enemy_inc_hero,enemy_inc_wild,
																		enemy_inc_mine,masteryan_cout,ii,_tar);
								}
				}
				else
				{
					console.move(way1[info.player][3]);
				}
			}
			else
			{
				if (_tar->pos!=way1[info.player][3])
						{
							console.move(way1[info.player][3]);
						}
						else
						{
							use_attack_skill(map,info,cmd,console,myUnits,
														enemy_inc_hero,enemy_inc_wild,
														enemy_inc_mine,masteryan_cout,ii,_tar);
														cout << " attack " << endl;
						}
			}
		}

		
		
		

	}
}




void analyse_ccout(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   vector<PUnit*> &enemy_inc_hero,
	                   vector<PUnit*> &enemy_inc_wild,
	                   vector<PUnit*> &enemy_inc_mine,
	                   int &masteryan_cout,
	                   int ii ,int size_hero
	                   )
{
	Log p("analyse_ccout");
	if (debug==1)
	{
		cout <<"analyse_ccout"<<endl;
	}


	if (size_hero>=6&&masteryan_cout!=0)
	{
		if(masteryan_cout<5&&masteryan_cout)
		masteryan_cout=3;
	}

}




static Pos go_to_defend[2][9]{{{},{17,10},  {15,10},  {14,11},  {18,9},   {16,9},   {14,9},   {16,7},   {14,7}},
                               {{},{131,139},{133,139},{135,139},{131,141},{133,141},{135,141},{130,142},{133,143}}};


void defend_home_startegy(const PMap &map, //  骚扰？
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   int &masteryan_cout,
	                   int ii 
	                   )


{

			console.selectUnit(myUnits[ii]); //控制台选中
			UnitFilter filter; //建立筛选器
			UnitFilter filter1; //建立筛选器
			UnitFilter filter2; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[ii]->pos, 1600 ), "a"); //筛选视野范围内的敌方单位
			vector<PUnit*> enemy = console.enemyUnits (filter);


			vector<PUnit*> enemy_inc_hero ;

			vector<PUnit*> enemy_inc_mine ;

			vector<PUnit*> enemy_inc_wild ;
			for (int i = 0; i < enemy.size(); ++i)
            {
            	if (enemy[i]->isWild())
            	{
            		enemy_inc_wild.push_back(enemy[i]);
            	}
            	else
            		if (enemy[i]->isMine())
            		{
            			enemy_inc_mine.push_back(enemy[i]);
            		}
            		else
            			enemy_inc_hero.push_back(enemy[i]);
            }

			int   en_power =  calculate_en(2,console,enemy_inc_hero,myUnits[ii]->pos,144);
			if (debug==5)
			{
				cout << "nera _ base _ en_power is "<<en_power<<endl;
				cout << "敌人 有"<<enemy_inc_hero.size()<<"个"<<endl;
			}

	if (en_power>0)
	{
		int   en_power = calculate_my(2,console,enemy_inc_hero,myUnits[ii]->pos,1000);

		if (debug==5)
		{
			cout << " 基地操作……&……&……&……&……&……&"<<endl;
			if (en_power>100)
			{
				cout << "有敌人" << endl;
				masteryan_cout=99;
				cout << " 999999999999999999999999999999999999999999999999999999999999 " <<endl;
			}
		}

		if (en_power>60)
		{
			for (int i = 0; i < myUnits.size()/2; ++i)
			{
				if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,myUnits[0]->pos)>=1600)
				{
						if (strcmp(myUnits[i]->name,"Master")!=0)
						{
							console.callBackHero(myUnits[i],go_to_defend[info.player][i]);
							//back_base_near_hero++;
							cout<<"console.buyBackHero(myUnits[i])"<<myUnits[i]->name<<endl;
						}
						
				}
			}


		}

		if (en_power>100)
		{
			for (int i = 0; i < myUnits.size(); ++i)
			{
				if (myUnits[i]->isHero()&&dis2(myUnits[i]->pos,myUnits[0]->pos)<16)
				{
					
					//console.buyBackHero(myUnits[xi]);
						console.buyBackHero(myUnits[i],go_to_defend[info.player][i]);
						//back_base_near_hero++;
						cout<<"console.buyBackHero(myUnits[i])"<<myUnits[i]->name<<endl;
				}
			}

			
		}
		
		// void baseAttack(const PUnit* = NULL);
		PUnit *_tar=attack_tar(map,info,cmd,console,myUnits,
		enemy_inc_hero,enemy_inc_wild,
		enemy_inc_mine,masteryan_cout,ii);
		if (_tar!=NULL)
		{
			console.baseAttack(_tar);
		}
		
	}
}


void go_mine_strategy(const PMap &map,            //完成，策略，分析，go_mine_strategy(map,info,cmd,console,myUnits,masteryan_cout,ii)
	                   const PPlayerInfo &info, 
	                   PCommand &cmd,
	                   Console &console,
	                   vector<PUnit*> &myUnits,
	                   int &masteryan_cout,
	                   int ii,
	                   int size_hero
	                   )
{
	Log p("go_mine_strategy");
	if (debug==1)
	{
		cout <<"go_mine_strategy"<<endl;
		cout << "i am "<<info.player<<endl;
	}
			console.selectUnit(myUnits[ii]); //控制台选中
			UnitFilter filter; //建立筛选器
			UnitFilter filter1; //建立筛选器
			UnitFilter filter2; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[ii]->pos, 1600 ), "a"); //筛选视野范围内的敌方单位
			vector<PUnit*> enemy = console.enemyUnits (filter);


			vector<PUnit*> enemy_inc_hero ;

			vector<PUnit*> enemy_inc_mine ;

			vector<PUnit*> enemy_inc_wild ;

            for (int i = 0; i < enemy.size(); ++i)
            {
            	if (enemy[i]->isWild())
            	{
            		enemy_inc_wild.push_back(enemy[i]);
            	}
            	else
            		if (enemy[i]->isMine())
            		{
            			enemy_inc_mine.push_back(enemy[i]);
            		}
            		else
            			enemy_inc_hero.push_back(enemy[i]);
            }
              int eye_number4=0;
			  int eye_number2=0;
			  int eye_number5=0;
			  int eye_number0=0;

			   

			  for (int i = 0; i < myUnits.size(); ++i)
			  {
			  	if (myUnits[i]->isHero()==0&&myUnits[i]->isBase()==0)
			  	{
			  		if (dis2(myUnits[i]->pos,MINE_POS[0])<=4)
			  		{
			  			eye_number0++;
			  		}
			  		if (dis2(myUnits[i]->pos,MINE_POS[2])<=4)
			  		{
			  			eye_number2++;
			  		}
			  		if (dis2(myUnits[i]->pos,MINE_POS[4])<=4)
			  		{
			  			eye_number4++;
			  		}
			  		if (dis2(myUnits[i]->pos,MINE_POS[5])<=4)
			  		{
			  			eye_number5++;
			  		}
			  	}			
			  }
	  eye_number00=eye_number0;	
	  eye_number02=eye_number2;
	  eye_number04=eye_number4;
	  eye_number05=eye_number5;
			analyse_ccout(
							 map,
                             info,
                             cmd,
                             console,
                             myUnits,
                             enemy_inc_hero,
                             enemy_inc_wild,
                             enemy_inc_mine,
                             masteryan_cout,ii,size_hero                       
						    );
			
			{	



				if (myUnits[ii]->canUseSkill("SetObserver"))
				{
					if (dis2(myUnits[ii]->pos,force_go[ii])<=4)
					{
						set_eye(map, //  放置眼
				                info, 
				                cmd,
				                console,
				                myUnits,
				                enemy_inc_hero,
				                enemy_inc_wild,
				                enemy_inc_mine,
				                masteryan_cout,
				                ii,
				                myUnits[ii]->pos
				                );
					}
					else
					{
						if(enemy_inc_hero.size()==0)
						{		
							do_master_yan_do_i_not_see_enemy(map, info, cmd,
								                             console,myUnits,enemy_inc_hero,
								                             enemy_inc_wild, enemy_inc_mine,
								                             masteryan_cout,
								                             ii,
								                             size_hero);
			
						}
						else if(enemy_inc_hero.size()!=0)
						{
			
							do_master_yan_do_i_see_enemy(map, info, cmd,
								                             console,myUnits, enemy_inc_hero,
								                             enemy_inc_wild, enemy_inc_mine,
								                             masteryan_cout,
								                             ii,
								                             size_hero);
						}
					}
				}
				else

				{
					if(enemy_inc_hero.size()==0)
						{		
							do_master_yan_do_i_not_see_enemy(map, info, cmd,
								                             console,myUnits,enemy_inc_hero,
								                             enemy_inc_wild, enemy_inc_mine,
								                             masteryan_cout,
								                             ii,
								                             size_hero);
			
						}
						else if(enemy_inc_hero.size()!=0)
						{
			
							do_master_yan_do_i_see_enemy(map, info, cmd,
								                             console,myUnits, enemy_inc_hero,
								                             enemy_inc_wild, enemy_inc_mine,
								                             masteryan_cout,
								                             ii,
								                             size_hero);
						}
				}
			}
			
}




static Pos buy_hero[2][4]={{{20,12},{21,14},{18,13},{19,13}},
							{{128,135},{130,135},{132,135},{134,135}}};

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{




	cout << "masteryan_cout=================="<<masteryan_cout<<endl;

	Console console(map,info,cmd); //初始化控制台
	// {console.chooseHero(HERO_NAME[Rank % 4]);} //依次选择英雄
	// ++ Rank;
	vector<PUnit*> myUnits = console.friendlyUnits(); //获取所有己方单位
	rank_k++;
	cout << rank_k<<endl;
	int size_hero=0;
    int can_do_2=1;
    int number_a=0;
 	int Hammerguard_count=0;
	int Berserker_count=0;
	int Master_count=0;
	int Scouter_count=0;
	int hm[5]={0};
	int ma[5]={0};
	int be[5]={0};
	int sc[5]={0}; 
	PUnit *tar[20];
	
	
	

// cout << console.gold()<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;
// 	cout << "Hammerguard_count="<<Hammerguard_count<<endl;
// 	cout << "Berserker_count="<<Berserker_count<<endl;
// 	cout << "Master_count="<<Master_count<<endl;
// 	cout << "Scouter_count="<<Scouter_count<<endl;

	for (int i = 0; i < myUnits.size(); ++i)
	{
		if (myUnits[i]->isHero())
		{
			size_hero++;

					if (strcmp(myUnits[i]->name,"Hammerguard")==0)
					{
						Hammerguard_count++;
						hm[Hammerguard_count]=i;
					}else
					if (strcmp(myUnits[i]->name,"Berserker")==0)
					{
						Berserker_count++;
						be[Berserker_count]=i;
					}else
					if (strcmp(myUnits[i]->name,"Master")==0)
					{
						Master_count++;
						ma[Master_count]=i;
					}else
					if (strcmp(myUnits[i]->name,"Scouter")==0)
					{
						Scouter_count++;
						sc[Scouter_count]=i;
					}
		}
	}




	if(size_hero!=8)
	{

		if (Hammerguard_count!=4 && (250 * (Hammerguard_count + 1)<=console.gold()))
		{
			console.chooseHero(HERO_NAME[0],buy_hero[info.player][0]);
			//cout << "buy Hammerguard"<<endl;
		} else
		if (Berserker_count<=3 && (250 * (Berserker_count + 1)<=console.gold()))
		{
			console.chooseHero(HERO_NAME[2],buy_hero[info.player][2]);
			cout << "buy Berserker"<<endl;
		} else
		if (Master_count==1 && (250 * (Master_count + 1)<=console.gold()))
		{
			console.chooseHero(HERO_NAME[1],buy_hero[info.player][1]);
			cout <<"buy Master"<<endl;
		} else
		if (Scouter_count==1 && (250 * (Scouter_count + 1)<=console.gold()))
		{
			console.chooseHero(HERO_NAME[3],buy_hero[info.player][3]);
			//cout << "buy Scouter"<<endl;
		}
			
	 }


	if (info.round<=5)
	{
		for (int i = 0; i < 20; ++i)
		{
			force_go1[i]=formal_f[info.player];
		}
	}


	if(info.round > 4&&size_hero>6)
		{
			for(int i = 0; i < myUnits.size(); ++i)
				{	
					console.buyHeroLevel(myUnits[i]); //升级英雄
				}
		}


	for(int ii = 0; ii < myUnits.size(); ++ii)
	{
		if(myUnits[ii]->isHero())	
		{

			go_mine_strategy(map,info,cmd,console,myUnits,masteryan_cout,ii,size_hero);
		}	
		else
			if (myUnits[ii]->isBase())
			{

				cout << "her_我在判断基地" <<endl;
				defend_home_startegy(map, //  骚扰？
	                info, 
	                cmd,
	                console,
	                myUnits,
	                masteryan_cout,
	                ii 
	                   );
			}
	}

	// masteryan_cout   way
}











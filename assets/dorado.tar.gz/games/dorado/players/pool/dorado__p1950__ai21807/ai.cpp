//宸頁匯倖劔箭AI
#include "console.h"
#include <vector>
using namespace std;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
/*
static const char* SKILL_NAME[SKILL_NAME_SIZE] = {"Attack", "ChooseHammerguard", "ChooseBerserker", "ChooseMaster", "ChooseScouter", "BuyHeroLevel", "BuyBackHero", "CallBackHero", "HammerAttack", "Blink", "Sacrifice", "SetObserver"};
*/
void HB(){
	
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console* console = new Console(map, info, cmd);
    Pos mine_pos[] = {Pos(73, 74), Pos(34, 59), Pos(34, 89), Pos(114, 59), Pos(114, 89), Pos(19, 139), Pos(129, 9)};
    vector<const PUnit*> myHeroes, myHealthyHeroes, mySickHeroes, Hammerguards, Masters, Scouters, enemyHeroes, Wilds, Mines; 
    PUnit* myBase = NULL;
    PUnit* enemyBase = NULL;
	for(int i = 0; i < info.units.size(); ++i)
    {
        if(info.units[i].isHero())
        {
            if(info.units[i].camp == info.camp)
			{
				myHeroes.push_back((PUnit*)(&info.units[i]));
				if(console->unitArg("hp", "c", (PUnit*)(&info.units[i])) < console->unitArg("hp", "m", (PUnit*)(&info.units[i])) / 3)
				{
					mySickHeroes.push_back((PUnit*)(&info.units[i]));
				}
				else
				{
					myHealthyHeroes.push_back((PUnit*)(&info.units[i]));
				}
                if(strcmp(info.units[i].name, "Hammerguard") == 0)
                {
                    Hammerguards.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Master") == 0)
                {
                    Masters.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Scouter") == 0)
                {
                    Scouters.push_back((PUnit*)(&info.units[i]));
                }
			}
            else enemyHeroes.push_back((PUnit*)(&info.units[i]));
        }
        else if(info.units[i].isWild())
        {
        	Wilds.push_back((PUnit*)(&info.units[i]));
		}
		else if(strcmp(info.units[i].name, "MilitaryBase") == 0)
		{
			if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]);
			else enemyBase = (PUnit*)(&info.units[i]);
		}
		else if(strcmp(info.units[i].name, "Mine") == 0)
    	{
    		Mines.push_back((PUnit*)(&info.units[i]));
    	}
    }
	for(int i=0;i<4;i++)console->chooseHero(HERO_NAME[i]); //卆肝僉夲哂俛 
	vector<PUnit*> myUnits = console->friendlyUnits(); //資函侭嗤失圭汽了 
	if(info.round > 4)
		for(int i = 0; i < myUnits.size(); ++i)
			console->buyHeroLevel(myUnits[i]); //嗤字氏祥幅雫哂俛 
	
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //孀欺失圭汽了嶄議哂俛汽了 
		{
			console->selectUnit(myUnits[i]); //陣崙岬僉嶄 
			if(dis2(myUnits[i]->pos,MINE_POS[0])<=100){
				vector<Pos> ob;
				ob.push_back(myUnits[i]->pos);
				console->useSkill("SetObserver",ob);
			}
			UnitFilter filter; //秀羨標僉匂 
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //標僉篇勸袈律坪議黍圭哂俛 
			filter.setAvoidFilter ("Mine"); //標僉扮肇茅署嵩 
			vector<PUnit*> enemy = console->enemyUnits (filter); //序佩標僉 
			if(enemy.size() == 0||enemy[0]->isWild()) //泌惚短嗤窟黍繁 
			{
				console->move(MINE_POS[0]); //夸肇寡鹿嶄刹署嵩 
			}
			else //倦夸好似囑欺議atk/hp恷寄議黍繁 
			{
				int id=0;
				for(int j=1;j<enemy.size();j++)if(enemy[j]->atk*enemy[id]->hp>enemy[id]->atk*enemy[j]->hp)id=j;
				console->useSkill("HammerAttack",enemy[id]);
				console->useSkill("Sacrifice",enemy[id]);
				console->attack(enemy[id],myUnits[i]);
			}
		}
	}
}

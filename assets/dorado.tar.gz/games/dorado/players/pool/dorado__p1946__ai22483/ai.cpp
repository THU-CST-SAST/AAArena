#include "console.h"
#include <vector>
#include <string>
using namespace std;
/*
变量区
*/
const int MAX_INT = 100000;
const Pos dir8[8] = {Pos(0, -1), Pos(-1, 0), Pos(1, 0), Pos(0, 1), Pos(-1, -1), Pos(-1, 1), Pos(1, 1), Pos(1, -1)}; // 8联通

const int MONSTER_REVIVE_TIME = 48;
const int SOLDIER_NAME_ID = 3;

const char SOLDIER_SKILL[] = "HammerAttack";
const char BERSERK_SKILL[] = "Sacrifice";
const char SCOUTER_SKILL[] = "SetObserver";
// 技能名称
const char BERSERK_BUFF[] = "WinOrDie";
// buff名称
const int _moving = 1;
const int _preparing = 2;
const int _startToFight = 3;
const int _attacking = 4;
const int _waiting = 5;
const int JOB_NONE = 6;
const int JOB_MINING = 7;
const int JOB_LEVEL_UP = 8;
const int JOB_ADVANCING = 9;
const int JOB_FIGHTING = 10;
const int JOB_DEFENDING = 11;

// 状态名

static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static const char* MONSTER_NAME[] = {"Dragon", "Roshan"};
static int Rank = 0;

/*
函数区
*/

inline PUnit* getEnemyUnitAt( Console& c, Pos p, const char* t = NULL, int error_range = 2 )
{
	UnitFilter f;
	f.setAreaFilter( new Circle( p, error_range ) );
	if (t)
	{
		f.setTypeFilter(t);
	}
	vector<PUnit*> u = c.enemyUnits(f);
	if ( u.empty() )
	{
		return NULL;
	}
	else{
		return u[0];
	}
}
inline PUnit* getFriendlyUnitAt( Console& c, Pos p, const char* t = NULL, int error_range = 2 )
{
	UnitFilter f;
	f.setAreaFilter( new Circle( p, error_range ) );
	if (t)
	{
		f.setTypeFilter(t);
	}
	vector<PUnit*> u = c.friendlyUnits(f);
	if ( u.empty() )
	{
		return NULL;
	}
	else{
		return u[0];
	}
}

/*
定义区
*/

struct Danger
{
	string name;
	int dangerLevel;
};

class Strategy
{
public:
	virtual void control( Console& c, vector<Danger>* d = NULL, int dgLevel = MAX_INT ) = 0;
	// 行动控制函数。根据危机级别dglevel用控制台操控单位行动，并将探寻到的危险push到d里
};

class MainStrategy : Strategy
{
public:
	virtual void control( Console& c, vector<Danger>* d = NULL, int dgLevel = MAX_INT );
	
	MainStrategy();
	~MainStrategy();
	
	// 回合信息设置
	void getRoundInfo( Console& c );
	int nowHeroCount;
	vector<PUnit*> heros[4];
	int heroIdOrder[8];
	bool newHeroBought;
	int heroCurrentJob[1000];
	PUnit *militaryBase, *enemyBase;
	// 开矿相关数据
	struct MiningGroup
	{
		vector<int> unitsId;
		int mineId;
		int miningType;
		int state;
	};
	vector<MiningGroup> groups;
	
	void observerFarmStrategy( Console& c, MainStrategy::MiningGroup& group );
	void roshanFarmStrategy( Console& c, MainStrategy::MiningGroup& group );
	void dragonFarmStrategy( Console& c, MainStrategy::MiningGroup& group );
	void suicideFarmStrategy( Console& c, MainStrategy::MiningGroup& group );
	void farmStrategy( Console& c );
	// 战斗相关
	bool isLinePeriod( Console& c );
	void lineStrategy( Console& c );
	void totalAttack( Console& c );
	int advanceState;
	bool hasDied[2];
	int nowStopId[2];
	void resetTotalAttack( Console& c );
	// 防御相关
	bool baseInDanger( Console& c );
	void defenseStrategy( Console& c );
	int lastEnemyAttackTurn;
	// 购买相关
	void initialBuy( Console& c );
	void initialLevelUp( Console& c );
	void buyStrategy( Console& c );
	int nowLevelUpHeroCount;
	// 调试相关
	void test_control( Console& c );
	MiningGroup g;
};

/*
信息更新
*/
void MainStrategy::getRoundInfo( Console& c )
{
	// 更新英雄的指针，各种重要单位，维护查询表
	if ( c.round() == 0 )
	{
		nowHeroCount = 0;
	}
	vector<PUnit*> fu = c.friendlyUnits();
	for ( int i = 0; i < 4; ++i )
	{
		heros[i].clear();
	}
	newHeroBought = false;
	
	for ( int i = 0; i < fu.size(); ++i )
	{
		if ( fu[i]->typeId == 0 )
		{
			militaryBase = fu[i];
		}
		int heroType = fu[i]->typeId - SOLDIER_NAME_ID;
		if ( heroType >= 0 && heroType < 4 )
		{
			heros[heroType].push_back( fu[i] );
			if ( !nowHeroCount || fu[i]->id > heroIdOrder[nowHeroCount-1] )
			{
				// 新英雄
				newHeroBought = true;
				heroIdOrder[nowHeroCount++] = fu[i]->id;
				heroCurrentJob[ fu[i]->id ] = JOB_NONE;
			}
		}
	}
	
	enemyBase = getEnemyUnitAt( c, MILITARY_BASE_POS[ 1 - c.camp() ], "MilitaryBase" );
}

/*
开矿相关
*/
void MainStrategy::observerFarmStrategy( Console& c, MainStrategy::MiningGroup& group )
{
/*
利用贼的图腾开矿。方法：先在矿区插一个图腾，等嘲讽引到图腾身上时英雄采矿，图腾消失时英雄撤离。
*/
	// 常数点
	Pos START_MINING_POS, OBSERVER_POS, MINING_POS, SAVE_POS, MID_POS;
	switch ( group.mineId )
	{
		case 0:
		case 1:
		{
			MID_POS = Pos(48,65); // 原来是P(47,65)
			START_MINING_POS = Pos(42,65);
			OBSERVER_POS = Pos(39,61);
			MINING_POS = Pos(43,65);
			SAVE_POS = Pos(61,65);
			break;
		}
		case 2:
		{
			MID_POS = Pos(47,85);
			START_MINING_POS = Pos(42,85);
			OBSERVER_POS = Pos(39,89);
			MINING_POS = Pos(43,85);
			SAVE_POS = Pos(61,85);
			break;
		}
		case 3:
		{
			MID_POS = Pos(103,65);
			START_MINING_POS = Pos(108,65);
			OBSERVER_POS = Pos(111,61);
			MINING_POS = Pos(107,64);
			SAVE_POS = Pos(89,64);
			break;
		}
		case 4:
		{
			MID_POS = Pos(103,85);
			START_MINING_POS = Pos(108,85);
			OBSERVER_POS = Pos(111,89);
			MINING_POS = Pos(107,85);
			SAVE_POS = Pos(89,85);
			break;
		}
		case 5:
		case 6:
		default:
			break;
	}
	
	PUnit *unit = c.getUnit( group.unitsId[0] );
	if ( heroCurrentJob[unit->id] != JOB_MINING && heroCurrentJob[unit->id] != JOB_NONE )
	{
		group.state = 0;
		return;
	} // 防止和其他行动冲突
	heroCurrentJob[unit->id] = JOB_MINING;
	
	PUnit *mine = getEnemyUnitAt( c, MINE_POS[ group.mineId ], "mine" );
	PUnit *observer = getFriendlyUnitAt( c, OBSERVER_POS, "Observer" );
	// 策略
	if ( unit->hp <= 0 )
	{
		group.state = 0;
		return;
	}
	switch ( group.state )
	{
		case 0:// 准备态
		{
			if ( unit->pos == MID_POS )
			{
				group.state = 4;
			}
			else
			{
				c.move( MID_POS, unit );
			}
			break;
		}
		case 1:// 插图腾
		{
			if ( unit->canUseSkill( SCOUTER_SKILL ) && mine && c.unitArg( "energy", "c", mine ) > 0 )
			{
				c.useSkill( SCOUTER_SKILL, OBSERVER_POS, unit );
				group.state = 2;
			}
			break;
		}
		case 2:// 采矿
		{
			if ( observer && observer->hp > 5 )
			{
				if ( unit->pos != MINING_POS )
				{
					c.move( MINING_POS, unit );
				}
			}
			else
			{
				group.state = 3;
			}
			break;
		}
		case 3:// 撤离
		{
			if ( unit->pos != SAVE_POS )
			{
				c.move( SAVE_POS, unit );
			}
			UnitFilter f;
			f.setTypeFilter( "Roshan" );
			f.setTypeFilter( "Dragon" );
			f.setAreaFilter( new Circle( unit->pos, unit->view ) );
			vector<PUnit*> mu = c.enemyUnits(f);
			if ( mu.empty() )
			{
				group.state = 0;
			}
			break;
		}
		case 4:// 中间点过度一下
		{
			if ( unit->pos == START_MINING_POS )
			{
				group.state = 1;
			}
			else
			{
				c.move( START_MINING_POS, unit );
			}
			break;
		}
		default:
			break;
	}
	// 稍微考虑一下防gank？
}
void MainStrategy::roshanFarmStrategy( Console& c, MainStrategy::MiningGroup& group )
{}
void MainStrategy::dragonFarmStrategy( Console& c, MainStrategy::MiningGroup& group )
{
	const int reset_time = 4;
	// 关键点寻找
	Pos b1pos, b2pos, spos, mpos, savePos[3];
	switch (group.mineId)
	{
	case 5:
		b1pos = Pos(26, 137);
		b2pos = Pos(25, 136);
		spos = Pos(23, 137);
		mpos = Pos(23, 140);
		savePos[0] = spos + Pos(12,0);
		savePos[1] = b1pos + Pos(12,0);
		savePos[2] = b2pos + Pos(12,0);
	case 6:
		spos = Pos(125, 11);
		b1pos = Pos(124, 13);
		b2pos = Pos(125, 14);
		mpos = Pos(127, 10);
		savePos[0] = spos - Pos(12,0);
		savePos[1] = b1pos - Pos(12,0);
		savePos[2] = b2pos - Pos(12,0);
	default:
		break;
	}
	
	PUnit* soldier = c.getUnit( group.unitsId[0] );
	PUnit* berserk1 = c.getUnit( group.unitsId[1] );
	PUnit* berserk2 = c.getUnit( group.unitsId[2] ); // 注意顺序
	PUnit* dragon = getEnemyUnitAt( c, mpos, "Dragon", 100 );
	if ( berserk1->hp <= 0 || berserk2->hp <= 0 || soldier->hp <= 0 )
	{
		group.state = 0; // 死亡重置状态
	}
	// 防止冲突
	bool stopMining = false;
	for ( int i = 0; i < 3; ++i )
	{
		if ( heroCurrentJob[ group.unitsId[i] ] != JOB_MINING && heroCurrentJob[ group.unitsId[i] ] != JOB_NONE
			&& heroCurrentJob[ group.unitsId[i] ] != JOB_FIGHTING )
		{
			stopMining = true;
			break;
		}
	}
	if (stopMining)
	{
		for ( int i = 0; i < 3; ++i )
		{
			if ( heroCurrentJob[ group.unitsId[i] ] == JOB_MINING )
			{
				c.move( savePos[i], c.getUnit( group.unitsId[i] ) );
			}
		}
		group.state = 0;
		return;
	}
	// 逻辑
	switch (group.state)
	{
	case 0: // 若没达到野区：移动到野区龙的身边
		if (berserk1->pos != b1pos)
			c.move( b1pos, berserk1 );
		if (berserk2->pos != b2pos)
			c.move( b2pos, berserk2 );
		if (soldier->pos != spos)
			c.move( spos, soldier );
		if ( berserk1->pos == b1pos && berserk2->pos == b2pos && soldier->pos == spos
			&& berserk1->canUseSkill(BERSERK_SKILL) && berserk2->canUseSkill(BERSERK_SKILL) && soldier->canUseSkill(SOLDIER_SKILL) )
			group.state = 1;
		for ( int i = 0; i < 3; ++i )
		{
			heroCurrentJob[ group.unitsId[i] ] = JOB_MINING;
		}
		break;
	case 1: // 若到达位置：狂战开技能
		c.useSkill( BERSERK_SKILL, NULL, berserk1);
		c.useSkill( BERSERK_SKILL, NULL, berserk2);
		for ( int i = 0; i < 3; ++i )
		{
			heroCurrentJob[ group.unitsId[i] ] = JOB_FIGHTING;
		}
		group.state = 2;
		break;
	case 2: // 若准备就绪，战士开锤，狂战开始A
		c.attack( dragon, berserk1 );
		c.attack( dragon, berserk2 );
		c.useSkill( SOLDIER_SKILL, dragon, soldier);
		group.state = 3;
		break;
	case 3: // 打龙进行时
		if (berserk1->canUseSkill( "Attack"))
			c.attack( dragon, berserk1 );
		if (berserk2->canUseSkill( "Attack"))
			c.attack( dragon, berserk2 );
		if (soldier->canUseSkill( "Attack"))
			c.attack( dragon, soldier );
		if ( dragon->hp <= 0 )
			group.state = 4;
		break;
	case 4: // 等待龙复活，途中让战士去采矿
		if (dragon)
		{
			const PBuff *b = dragon->findBuff( "Reviving");
			if (b && b->timeLeft > reset_time)
			{
				if (soldier->pos != mpos)
					c.move( mpos, soldier);
			}
			else
			{
				if (soldier->pos != spos)
					c.move( spos, soldier );
			}
			if (berserk1->pos != b1pos)
				c.move( b1pos, berserk1 );
			if (berserk2->pos != b2pos)
				c.move( b2pos, berserk2);
			if ( dragon->hp > 0 )
			{
				group.state = 0;
			}
		}
		for ( int i = 0; i < 3; ++i )
		{
			heroCurrentJob[ group.unitsId[i] ] = JOB_MINING;
		}
		break;
	default:
		break;
	}
}
void MainStrategy::suicideFarmStrategy( Console& c, MainStrategy::MiningGroup& group )
{}
void MainStrategy::farmStrategy( Console& c )
{
	// 不同矿型，不同策略
	for ( int i = 0; i < groups.size(); ++i )
	{
		switch ( groups[i].miningType )
		{
			case 0: //OBSERVER:
			{
				observerFarmStrategy( c, groups[i] );
				break;
			}
			case 1: //ROSHAN:
			{
				roshanFarmStrategy( c, groups[i] );
			}
			case 2: //DRAGON:
			{
				dragonFarmStrategy( c, groups[i] );
			}
			case 3: //SUICIDE:
			{
				suicideFarmStrategy( c, groups[i] );
			}
			default:
				break;
		}
	}
}

/*
战斗相关
*/
bool MainStrategy::isLinePeriod( Console& c )
{
	return 0;
}
void MainStrategy::lineStrategy( Console& c )
{
	
}
void MainStrategy::totalAttack( Console& c )
{
	// 人员：满级战士*2。
	// 冲对面基地，预计冲两次就能拿下。
	// 路径
	const int KEY_STOP_COUNT = 5;
	Pos KEY_STOP[2][5] = {{Pos(14,20),Pos(14,75),Pos(35,125),Pos(75,130),Pos(134,130)},
		{Pos(16,20),Pos(16,75),Pos(34,124),Pos(75,132),Pos(136,130)}};
	if ( c.camp() == 1 )
	{
		for ( int i = 0; i < 2; ++i )
		{
			for ( int j = 0; j < KEY_STOP_COUNT / 2; ++j )
			{
				Pos temp = KEY_STOP[i][j];
				KEY_STOP[i][j] = KEY_STOP[i][ KEY_STOP_COUNT - j - 1 ];
				KEY_STOP[i][ KEY_STOP_COUNT - j - 1 ] = temp;
			}
		}
	}
	
	PUnit *soldier[2];
	soldier[0] = heros[0][0];
	soldier[1] = heros[0][1];
	
	for ( int i = 0; i < 2; ++i )
	{
		if ( heroCurrentJob[ soldier[i]->id ] > JOB_ADVANCING )
		{
			continue;
		}
		heroCurrentJob[ soldier[i]->id ] = JOB_ADVANCING;
		
		switch (advanceState)
		{
			case 0: // 移动
			{
				hasDied[i] = false;
				if ( nowStopId[i] == -1 )
				{
					int minDist = MAX_INT;
					for ( int j = 0; j < KEY_STOP_COUNT; ++j )
					{
						if ( dis2( KEY_STOP[i][j], soldier[i]->pos ) <= minDist )
						{
							minDist = dis2( KEY_STOP[i][j], soldier[i]->pos );
							nowStopId[i] = j;
						}
					}
				}
				if ( nowStopId[i] < KEY_STOP_COUNT && KEY_STOP[i][ nowStopId[i] ] == soldier[i]->pos )
				{
					++nowStopId[i];
				}
				if ( nowStopId[i] < KEY_STOP_COUNT )
				{
					c.move( KEY_STOP[i][ nowStopId[i] ], soldier[i] );
				}
				break;
			}
			case 1: // 攻击
			{
				if ( soldier[i]->hp <= 0 )
				{
					hasDied[i] = true;
				}
				if ( !hasDied[i] && ( !enemyBase || dis2( soldier[i]->pos, enemyBase->pos ) > soldier[i]->range ) )
				{
					c.move( MILITARY_BASE_POS[ 1 - c.camp() ], soldier[i] );
				}
				else
				{
					if ( soldier[i]->canUseSkill("Attack") )
					{
						c.attack( enemyBase, soldier[i] );
					}
					else
					{
						UnitFilter f;
						f.setAvoidFilter( "MilitaryBase" );
						f.setAvoidFilter( "Observer" );
						vector<PUnit*> eus = c.enemyUnits(f);
						for ( int k = 0; k < eus.size(); ++k )
						{
							if ( dis2( soldier[i]->pos, eus[k]->pos ) <= 36 )
							{
								c.useSkill( SOLDIER_SKILL, eus[k], soldier[i] );
								break;
							}
						}
					}
				}
				break;
			}
			case 2: // 浸水泉
				nowStopId[i] = -1;
				break;
			default:
				break;
		}
	}
	
	switch (advanceState)
	{
		case 0: // 若都到达集合点，至攻击状态
		{
			if ( nowStopId[0] == nowStopId[1] && nowStopId[0] == KEY_STOP_COUNT )
			{
				advanceState = 1;
			}
			break;
		}
		case 1: // 若两人都死亡，至待机状态
		{
			if ( hasDied[0] && hasDied[1] )
			{
				advanceState = 2;
			}
			break;
		}
		case 2: // 若两人又复活，则回到移动状态
		{
			if ( soldier[0]->hp > 0 && soldier[1]->hp > 0 )
			{
				advanceState = 0;
			}
			break;
		}
	}
}
void MainStrategy::resetTotalAttack( Console& c )
{
	advanceState = 0;
	hasDied[0] = hasDied[1] = false;
	nowStopId[0] = nowStopId[1] = -1;
}
/*
防御相关
*/
bool MainStrategy::baseInDanger( Console& c )
{
	cout << "jud "; //?
	UnitFilter f;
	f.setAreaFilter( new Circle( militaryBase->pos, militaryBase->view * 2 ) );
	vector<PUnit*> eu = c.enemyUnits(f);
	if ( eu.size() > 0 )
	{
		lastEnemyAttackTurn = c.round();
		for ( int i = 0; i < 4; ++i )
			for ( int j = 0; j < heros[i].size(); ++j )
				heroCurrentJob[ heros[i][j]->id ] = JOB_DEFENDING;
	}
	cout << "jud "; //?
	if ( c.round() - lastEnemyAttackTurn > 10 && !militaryBase->hp < 1000 )
	{
		for ( int i = 0; i < 4; ++i )
			for ( int j = 0; j < heros[i].size(); ++j )
				heroCurrentJob[ heros[i][j]->id ] = JOB_NONE;
		return false;
	}
	else
	{
		return true;
	}
}
void MainStrategy::defenseStrategy( Console& c )
{
	cout << "def ";//?
	UnitFilter f;
	f.setAreaFilter( new Circle( militaryBase->pos, militaryBase->view ) );
	vector<PUnit*> eu = c.enemyUnits(f);
	PUnit *target = eu.size() > 0 ? eu[0] : NULL;
	for ( int i = 0; i < 4; ++i )
	{
		for ( int j = 0; j < heros[i].size(); ++j )
		{
			PUnit *unit = heros[i][j];
			if ( unit->hp <= 0 )
			{
				continue;
			}
			switch (i)
			{
				case 0:
				{
					if (!target)
					{
						c.move( militaryBase->pos, unit );
					}
					else if ( unit->canUseSkill(SOLDIER_SKILL) )
					{
						if ( dis2( target->pos, unit->pos ) <= 36 )
							c.useSkill( SOLDIER_SKILL, target, unit );
						else
							c.move( target->pos, unit );
					}
					else
					{
						c.attack( target, unit );
					}
				}
				case 2:
				{
					if (target)
					{
						bool canCallBack = dis2( target->pos, militaryBase->pos ) < 6;
						Pos callBackPos = target->pos + Pos(-2,2);
						bool berserkReturned = dis2( militaryBase->pos, unit->pos ) <= militaryBase->view;
						if ( !berserkReturned )
						{
							if ( unit->canUseSkill(BERSERK_SKILL) && canCallBack )
								c.useSkill( BERSERK_SKILL, NULL, unit );
							else if ( unit->findBuff(BERSERK_BUFF) != NULL )
								c.callBackHero( unit, callBackPos );
							else
								c.move( militaryBase->pos, unit );
						}
						else
						{
							c.attack( target, unit );
						}
					}
				}
				case 1:
				case 3:
				{
					if (!target)
					{
						c.move( militaryBase->pos, unit );
					}
					else
					{
						c.attack( target, unit );
					}
					break;
				}
			}
		}
	}
	f.setTypeFilter("Berserker");
	vector<PUnit*> b = c.enemyUnits(f);
	if ( b.size() > 0 && dis2( b[0]->pos, militaryBase->pos ) <= militaryBase->range )
	{
		c.baseAttack( b[0] );
	}
	else
	{
		c.baseAttack( target );
	}
}

/*
购买相关
*/
void MainStrategy::initialBuy( Console& c )
{
	const int BUY_HERO_COUNT = 3;
	const int BUY_HERO_LIST[] = {0,2,2}; // 三人组
	
	for ( int i = 0; i < BUY_HERO_COUNT; ++i )
	{
		c.chooseHero( HERO_NAME[ BUY_HERO_LIST[i] ] );
	}
	nowLevelUpHeroCount = 0;
}
void MainStrategy::initialLevelUp( Console& c )
{
	const int LEVEL_UP_COUNT = 0;
	const int LEVEL_UP_TYPE[] = {};
	const int LEVEL_UP_TIMES[] = {}; // 两个贼各升1级
	
	int n[4] = {};
	for ( int i = 0; i < LEVEL_UP_COUNT; ++i )
	{
		for ( int j = 0; j < LEVEL_UP_TIMES[i]; ++j )
		{
			c.buyHeroLevel( heros[ LEVEL_UP_TYPE[i] ][ n[ LEVEL_UP_TYPE[i] ]++ ] );
		}
	}
}
void MainStrategy::buyStrategy( Console& c )
{
	// 优先买英雄。之后攒钱升级，先攒钱，攒够就回家升到指定等级，然后有机会能升级就升级
	const int MONEY_REMAIN[] = {0,0,0,0,200,200,200,200,200,200}; // 前400回合不留钱，之后留200保底
	const int BUY_HERO_COUNT = 5;
	const int BUY_HERO_LIST[] = {0,2,2,3,0}; // 买英雄顺序
	const int LEVEL_UP_HERO_COUNT = 2; // 优先升级英雄数
	const int LEVEL_UP_HERO_ORDER[] = {4,0}; // 优先升级的英雄序号
	const int LEVEL_UP_TIMES[] = {5,5}; // 升级次数
	const int LEVEL_UP_GOLD[] = {1000, 1000}; // 预估需要金钱
	
	if ( nowHeroCount < BUY_HERO_COUNT )
	{
		int nextHero = BUY_HERO_LIST[ nowHeroCount ];
		int cost = 250 * ( 1 + heros[ nextHero ].size() );
		if ( c.gold() >= MONEY_REMAIN[ c.round() / 100 ] + cost )
		{
			c.chooseHero( HERO_NAME[nextHero] );
		}
	}
	else if ( nowLevelUpHeroCount < LEVEL_UP_HERO_COUNT )
	{
		if ( c.gold() >= LEVEL_UP_GOLD[nowLevelUpHeroCount] + MONEY_REMAIN[ c.round() / 100 ] )
		{
			PUnit* unit = c.getUnit( heroIdOrder[ LEVEL_UP_HERO_ORDER[nowLevelUpHeroCount] ] );
			if ( heroCurrentJob[unit->id] == JOB_NONE || heroCurrentJob[unit->id] == JOB_MINING )
			{
				heroCurrentJob[unit->id] = JOB_LEVEL_UP;
			}
			if ( heroCurrentJob[unit->id] == JOB_LEVEL_UP )
			{
				if ( dis2( unit->pos, militaryBase->pos ) <= LEVELUP_RANGE )
				{
					for ( int i = 0; i < LEVEL_UP_TIMES[nowLevelUpHeroCount]; ++i )
					{
						c.buyHeroLevel( unit );
					}
					++nowLevelUpHeroCount;
					heroCurrentJob[unit->id] = JOB_NONE;
				}
				else
				{
					c.move( militaryBase->pos, unit );
				}
			}
		}
	}
	else
	{
		// 不额外升级?
	}
}

/*
主函数
*/
void MainStrategy::control( Console& c, vector<Danger>* d, int dgLevel )
{
	/*
	1H = 3gpt。
	英雄：3000 = 战士+2，术士，盗贼+2，剑士（和术士刷野），战士+2，（贼，剑，剑）
	思路：防守流刷经济。前期占线，然后逐渐分人刷野
	0、买英雄。战士，术士，盗贼+2
	1、三人占线。预计5gpt，100回合内点出剑士。100T：1350
	2、被团灭或点出剑士：剑士术士刷ro，战士盗贼占线，8gpt，200T：2000
	3、点出战士：双战士赖线，贼控小龙，10gpt。攒钱升级，预计350回合把剩余人点出来。300T:3000
	4、战士集中升级。重新分配人手
	5、双战士赖线。双贼刷双野。剑术刷ro。25gpt，点出后续英雄后，主升级战士，而后升级其他。
	0-1、防御策略。30格有大波敌军则提起警惕，超过1级的人员集中。基地受到攻击：剑士传送秒战士，战士后续跟上。
	*/
	getRoundInfo(c);
	
	//battleAlert(c);
	//startBattle(c);
	
	farmStrategy(c);
	
	if ( c.round() == 0 )
	{
		initialBuy(c);
	}
	else if ( c.round() == 1 )
	{
		initialLevelUp(c);
	}
	else
	{
		buyStrategy(c);
	}
}

MainStrategy::MainStrategy()
{
}
MainStrategy::~MainStrategy()
{
}

/*
调试用主函数
*/
void MainStrategy::test_control( Console& c )
{
	static bool ADVANCE = false;
	
	getRoundInfo(c);
	if ( c.round() == 0 )
	{
		initialBuy(c);
		lastEnemyAttackTurn = -100;
	}
	if ( c.round() == 1 )
	{
		initialLevelUp(c);
		
		groups.clear();
		MiningGroup g1;
		g1.miningType = 2;
		g1.unitsId.push_back( heros[0][0]->id );
		g1.unitsId.push_back( heros[2][0]->id );
		g1.unitsId.push_back( heros[2][1]->id );
		g1.mineId = 6;
		g1.state = 0;
		
		groups.push_back(g1); // 5号矿，三人打
	}
	if ( newHeroBought && nowHeroCount == 4 ) // 买出盗贼
	{
		MiningGroup g2;
		g2.miningType = 0;
		g2.unitsId.push_back( heros[3][0]->id );
		g2.mineId = c.camp() == 0 ? 2 : 3;
		g2.state = 0;
		
		groups.push_back(g2);
	}
	if ( c.round() >= 2 )
	{
		if ( !ADVANCE && heros[0].size() == 2 && heros[0][0]->atk == 90 && heros[0][1]->atk == 90 ) // 发起总攻
		{
			resetTotalAttack(c);
			ADVANCE = true;
		}
		if (ADVANCE) // 总攻
		{
			totalAttack(c);
		}
		cout << "before ";//?
		if ( baseInDanger(c) )
		{
			defenseStrategy(c);
		}
		cout << "after "; //?
		farmStrategy(c);
		buyStrategy(c);
	}
}

/*
AI
*/

static MainStrategy s;

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console c(map, info, cmd);
	s.test_control(c);
}

/*
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console console(map,info,cmd); //初始化控制台
	console.chooseHero(HERO_NAME[Rank % 4]); //依次选择英雄
	++ Rank;
	vector<PUnit*> myUnits = console.friendlyUnits(); //获取所有己方单位
	if(info.round > 4)
		for(int i = 0; i < myUnits.size(); ++i)
			console.buyHeroLevel(myUnits[i]); //有机会就升级英雄
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			if(enemy.size() == 0) //如果没有发现敌人
				console.move(MINE_POS[0]); //则去采集中央金矿
			else //否则攻击遇到的id最小的敌人
				console.attack(enemy[0]);
		}
	}
}
*/
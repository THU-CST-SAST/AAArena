#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

static int newHeroFirst = 1;
static int attackArg = 200, supportRange = 1000, monsterAvoid = 1000, enemyAvoid = 300, deltaFightArg = 100;
static int outOfRangeArg = 400, killArg = 800, observerArg = 300, hammerAttackArg = 400, outOfMineArg = 2000;
static int miningArg = 0, sameMineArg = 20, centerMineArg = 150, clearObserverArg = 300, focusArg = 1000;
static int baseThreatArg = 25000, threatArg = 20, skillThreatArg = 400, stopBerserkerArg = 25;
static int goBackHomeHp = 100, goBackHomeArg = 2000, goBackHomeBaseArg = 20, inBattleArg = 200;
static int attackBaseArg = 10000, outOfBaseArg = 500, gatherArg = 500, inplaceRange = 25, spyArg = 1000;
static int hammerDizzy = 500, attackDizzy = 300;
static int strategyDisabled = - 1<<30;
static int helperArg = 200;
static int THREAT_RANGE = 400, BASE_THREAT_RANGE = 1600, ATTACK_RANGE = 25, USE_SACRIFICE_RANGE = 130, maxRange = 36, maxView = 144, maxSpeed = 36;
static int sacrificeThreatArg = 3000, protectBaseArg = 1800, defendBaseHp = 1000, winOrDieAvoidArg = 1500, defendTurnsBegin = 0, defendTurnsEnd = 80;
static int spareGold = 300;
static int goWildArg = 200;
static int totalHeros = 0;
static const int ROUTELENGTH = 4;
static const Pos stealRoute[2][ROUTELENGTH] = {
    {Pos(10, 30), Pos(10, 110), Pos(60, 140), Pos(101, 140)},
    {Pos(50, 10), Pos(92, 5), Pos(140, 50), Pos(145, 120)}
};

static const Pos spyPos[2][3] = {
    {Pos(15, 50), Pos(50, 10), Pos(20, 20)},
    {Pos(100, 135), Pos(135, 100), Pos(120, 120)}
};


static const Pos searchPos[2][3] = {
    {Pos(15, 30), Pos(30, 10)},
    {Pos(120, 135), Pos(135, 120)}
};

static int wildmineNum[2][2] = {
    {1, 5},
    {4, 6}
};

static int checkMine[] = {1, 4};

void myShortestPath(const PMap& map, Pos start, Pos dest, const std::vector<Pos>& blocks, std::vector<Pos>& _path);

enum style {
    NORMAL, STEAL, DEFEND, WILD, UNDEFINED
};

class Strategy;

static const char* HERO_NAME[] = {"Master", "Hammerguard", "Berserker", "Scouter",
                                 "Hammerguard", "Berserker", "Master", "Hammerguard"};

static int costs[] = {1, 1, 1, 1, 2, 2, 2, 3};

bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
    return !strcmp(mySkill->name, "HammerAttack")
        || !strcmp(mySkill->name, "Blink")
        || !strcmp(mySkill->name, "Sacrifice")
        || !strcmp(mySkill->name, "SetObserver");
}

bool isValidPos(Pos p);

class Conductor //历史信息记录
{
private:
    static style strategyHistory[1000];
    static Console* console;
    static Conductor* instance;
    Conductor(Console* console);
public:
    static Conductor* getConductor(Console* console);
    static Conductor* getConductor();
    static void setStrategy(style strategy);
    static void setStrategy(style strategy, int round);
    void setConsole(Console *console);
    static style getStrategy(int round);
    static style getStrategy();
    static int dangerArg(Pos myPos, Pos enemyPos);
};

class History
{
private:
    static int lastAttackedRound[50];
    static int lastOccupyingMine[10];
    static int enemyBaseHp[1000], myBaseHp[1000];
    static Pos nextMove[50];
    static History* instance;
    static Console* console;
    History(Console* console);
    static bool isValidRound(int round) {return round >= 0 && round < MAX_ROUND;}
public:
    static History* getHistory(Console* console);
    static History* getHistory();
    static void setConsole(Console* _console);
    static Console* getConsole(){return console;}
    static void setLastAttackedRound(int heroid, int round);
    static int getLastAttackedRound(int heroid);
    static int getlastOccupyingMine(int minenum = 0);
    static bool isControllingMine(int minenum = 0);
    static void setEnemyBaseHp(int hp) {enemyBaseHp[console->round()] = hp;}
    static int getEnemyBaseHp(int round) {if (isValidRound(round)) return enemyBaseHp[round];}
    static int getEnemyBaseHp() {return enemyBaseHp[console->round()];}
    static void setMyBaseHp(int hp) {myBaseHp[console->round()] = hp;}
    static int getMyBaseHp(int round) {if (isValidRound(round)) return myBaseHp[round];}
    static int getMyBaseHp() {return myBaseHp[console->round()];}
    static void setNextMove(PUnit* hero, Pos nextpos);
    static Pos getNextMove(PUnit* hero);
    static void updateHistory();
};

Console* Conductor::console = 0;
Conductor* Conductor::instance = 0;
style Conductor::strategyHistory[1000] = {NORMAL};

Console* History::console = 0;
History* History::instance = 0;
int History::lastAttackedRound[50] = {0};
int History::lastOccupyingMine[10] = {0};
int History::enemyBaseHp[1000] = {0};
int History::myBaseHp[1000] = {0};
Pos History::nextMove[50] = {};

class AIController //控制ai的主类
{
public:
    AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
    ~AIController();
public:
    void levelupHero();
    void buyNewHero();
    void action();
private:
    vector<Strategy*> normalAction();
    vector<Strategy*> stealAction();
    vector<Strategy*> wildAction();
    vector<Strategy*> defendAction();
    Conductor* conductor;
    History* history;
    Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
    std::vector<PUnit*> myHeros, enemyHeros;
    PUnit *myBase, *enemyBase;
};

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
    virtual int countWorth() = 0; //计算某种策略的实行价值
    virtual void work() = 0; //实现这种策略
public:
    void setWorker(PUnit* worker) {this->worker = worker;}
    int getWorth() {return worth;}
    void setWorth(int worth) {this->worth = worth;}
    PUnit* getWorker() {return worker;}
    string getName() {return name;}
    void setAIHeroList(vector<AIHero*>& AIHeroList)
    {
        for(int i = 0; i < AIHeroList.size(); ++i)
            this->AIHeroList.push_back(AIHeroList[i]);
    }
    void setConsole(Console* console) {this->console = console;}
protected:
    PUnit* worker;
    int worth;
    vector<AIHero*> AIHeroList;
    Console* console;
    string name;
};

class Attack: public Strategy //攻击某个单位的策略
{
public:
    Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(PUnit* target) {this->target = target;}
    PUnit* getTarget() {return target;}
private:
    PUnit* target;
};

class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
    UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(PUnit* target) {this->target = target;}
    PUnit* getTarget() {return target;}
private:
    PUnit* target;
    Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略
{
public:
    GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
    virtual int countWorth();
    virtual void work();
private:
    static int lastBeingAttackedRound;
};

int GoBackHome::lastBeingAttackedRound = -100;

class CallBackHome:public Strategy //召回英雄的策略
{
public:
    static int totalCallback;
public:
    CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
    virtual int countWorth();
    virtual void work();
};

int CallBackHome::totalCallback = 0;

class GoMining:public Strategy //采矿的策略
{
public:
    GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(Pos target) {this->target = target;}
    Pos getTarget() {return target;}
private:
    Pos target;
};

class GoWildMines:public Strategy //采矿的策略
{
public:
    GoWildMines(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoWildMines";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(Pos target) {this->target = target;}
    Pos getTarget() {return target;}
private:
    Pos target;
    static int gotoMine;
};

int GoWildMines::gotoMine = 0;


class CheckMines:public Strategy //抓打野的策略
{
public:
    CheckMines(PUnit* worker) {setWorker(worker);name = "CheckMines";}
public:
    virtual int countWorth();
    virtual void work();
private:
    static int gotoMine;
};

int CheckMines::gotoMine = 0;

class Tempt:public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
    Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(PUnit* target) {this->target = target;}
    PUnit* getTarget() {return target;}
private:
    PUnit* target;
};

class BaseAttack:public Strategy
{
public:
    BaseAttack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "BaseAttack";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(PUnit* target) {this->target = target;}
    PUnit* getTarget() {return target;}
private:
    PUnit* target;
};

class GoGatheringPoint:public Strategy //前往偷家聚集点
{
public:
    GoGatheringPoint(PUnit* worker);
public:
    virtual int countWorth();
    virtual void work();
private:
    static int route;
    static bool isReady;
    bool almostInline(Pos p0, Pos p1, Pos p2);
};

int GoGatheringPoint::route = 0;
bool GoGatheringPoint::isReady = false;

class AttackBase:public Strategy //攻击敌方基地
{
public:
    AttackBase(PUnit* worker) {setWorker(worker);name = "AttackBase";}
public:
    virtual int countWorth();
    virtual void work();
};

class Spy:public Strategy //攻击敌方基地
{
public:
    Spy(PUnit* worker) {setWorker(worker);name = "Spy";}
public:
    virtual int countWorth();
    virtual void work();
};



class SearchEnemy:public Strategy //搜寻偷家队伍
{
public:
    SearchEnemy(PUnit* worker) {setWorker(worker);name = "SearchEnemy";}
public:
    virtual int countWorth();
    virtual void work();
};

class ClearObserver:public Strategy //清除observer
{
public:
    ClearObserver(PUnit* worker) {setWorker(worker);name = "ClearObserver";}
public:
    virtual int countWorth();
    virtual void work();
};

class Avoid: public Strategy //攻击某个单位的策略
{
public:
    Avoid(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Avoid";}
public:
    virtual int countWorth();
    virtual void work();
    void setTarget(PUnit* target) {this->target = target;}
    PUnit* getTarget() {return target;}
private:
    PUnit* target;
};

class Defend: public Strategy //守家
{
public:
    Defend(PUnit* worker) {setWorker(worker);name = "Defend";}
public:
    virtual int countWorth();
    virtual void work();
public:
    static bool hammered[50], attacked[50], winordied[50];
};

bool Defend::hammered[50] = {0};
bool Defend::attacked[50] = {0};
bool Defend::winordied[50] = {0};

class AIHero //对应每个英雄的策略决策
{
public:
    AIHero(PUnit* totalHeros) {mHero = totalHeros; mStrategy = NULL;} //默认选择回家的策略
    ~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
    bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
    void action(); //进行当前的最优策略
    Strategy* getStrategy() {return mStrategy;}
private:
    PUnit* mHero;
    Strategy* mStrategy;
};


AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
//    console->changeShortestPathFunc(myShortestPath);
    conductor = Conductor::getConductor(console);
    history = History::getHistory(console);
    myHeros.clear();
    std::vector<PUnit*> myUnits = console->friendlyUnits();
    std::vector<PUnit*> enemyUnits = console->enemyUnits();
    enemyBase = NULL;
    for(int i = 0; i < myUnits.size(); ++i)
    {
        if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
        || !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
            myHeros.push_back(myUnits[i]);
        else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
            myBase = myUnits[i];
    }
    for(int i = 0; i < enemyUnits.size(); ++i)
    {
        if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
        || !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
        || !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
            enemyHeros.push_back(enemyUnits[i]);
        else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
            enemyBase = enemyUnits[i];
    }
}

AIController::~AIController()
{
    delete console;
}

void AIController::levelupHero()
{
    if (totalHeros <= 6) return ;
    UnitFilter filter;
    filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
    vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);

    int spareGoldUse;
    if (conductor->getStrategy() == DEFEND)
        spareGoldUse = spareGold * 3;
    else
        if (console->round() > 500)
            spareGoldUse = 2*spareGold;
        else
            spareGoldUse = spareGold;
    for(int i = 0; i < heroToLevelUp.size(); ++i) {
        PUnit* hero = heroToLevelUp[i];
        if (lowerCase(hero->name) == lowerCase("Scouter") && hero->level >= 3) continue;
        if (console->round() <= 200 || (console->gold() - console->goldCostCurrentRound() > console->levelUpCost(hero->level) + spareGoldUse))
            console->buyHeroLevel(heroToLevelUp[i]);
    }
}

void AIController::buyNewHero()
{
//    if (console->round() <= 70) {
//        for (int i = 0; i < myHeros.size(); i++) {
//            if (myHeros[i]->findBuff("Reviving") && console->gold() - console->goldCostCurrentRound() >= console->buyBackCost(myHeros[i]->level))
//                console->buyBackHero(myHeros[i]);
//        }
//    }
    int spareGoldUsed = 0;
    if (History::getHistory()->isControllingMine(0) && console->round() > 200)
        spareGoldUsed = spareGold;
    if (console->gold() - console->goldCostCurrentRound() >= NEW_HAMMERGUARD_COST * costs[totalHeros] + spareGoldUsed)
        if (totalHeros >= 0 && totalHeros < 8) {
            if (console->camp() == 0)
                console->chooseHero(HERO_NAME[totalHeros++],
                        console->closestPos(MILITARY_BASE_POS[console->camp()], BUY_NEW_HERO_RANGE, MINE_POS[0]) - Pos(totalHeros, totalHeros));
            else
                console->chooseHero(HERO_NAME[totalHeros++],
                        console->closestPos(MILITARY_BASE_POS[console->camp()], BUY_NEW_HERO_RANGE, MINE_POS[0]) + Pos(totalHeros, totalHeros));
        }
}

vector<Strategy*> AIController::normalAction()
{
    vector<Strategy*> allStrategy;
    for (int i = 0; i < enemyHeros.size(); ++i)
        allStrategy.push_back(new BaseAttack(myBase, enemyHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Avoid(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new ClearObserver(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CheckMines(myHeros[i]));

    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < MINE_NUM; ++j)
            allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]));
    return allStrategy;
}

vector<Strategy*> AIController::stealAction()
{
    vector<Strategy*> allStrategy;

    for (int i = 0; i < enemyHeros.size(); ++i)
        allStrategy.push_back(new BaseAttack(myBase, enemyHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Avoid(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        allStrategy.push_back(new GoGatheringPoint(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        allStrategy.push_back(new AttackBase(myHeros[i]));
    return allStrategy;
}

vector<Strategy*> AIController::defendAction()
{
    vector<Strategy*> allStrategy;
    for (int i = 0; i < enemyHeros.size(); ++i)
        allStrategy.push_back(new BaseAttack(myBase, enemyHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));


    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < MINE_NUM; ++j)
            allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]));

    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new Spy(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new SearchEnemy(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new ClearObserver(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new Defend(myHeros[i]));
    return allStrategy;
}

vector<Strategy*> AIController::wildAction()
{
    vector<Strategy*> allStrategy;
    for (int i = 0; i < enemyHeros.size(); ++i)
        allStrategy.push_back(new BaseAttack(myBase, enemyHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < enemyHeros.size(); ++j)
            allStrategy.push_back(new Avoid(myHeros[i], enemyHeros[j]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new ClearObserver(myHeros[i]));
    for(int i = 0; i < myHeros.size(); ++i)
        for(int j = 0; j < MINE_NUM; ++j)
            allStrategy.push_back(new GoWildMines(myHeros[i],MINE_POS[j]));
    return allStrategy;
}

void AIController::action()
{
    style tstyle = NORMAL;

    history->updateHistory();
    if (conductor->getStrategy() != UNDEFINED) {
        tstyle = conductor->getStrategy();
    }

    cout << totalHeros << endl;


    if (((console->round() == 90) && (totalHeros < 5))
            || (conductor->getStrategy(console->round()-1) == WILD)) {
        tstyle = WILD;
    }

//    if (conductor->getStrategy(console->round()-1) == WILD
//            && console->gold() >= 700 && tstyle != DEFEND)
//        tstyle = STEAL;

//    if (conductor->getStrategy(console->round()-1) == STEAL)
//        tstyle = STEAL;

    for (int i = 0; i < enemyHeros.size(); i++) {
        if (dis2(enemyHeros[i]->pos, myBase->pos) < THREAT_RANGE) {
            tstyle = DEFEND;
            for (int j = defendTurnsBegin; j < defendTurnsEnd; j++)
                conductor->setStrategy(DEFEND, console->round()+j);
        }
    }

    if (myBase->hp < defendBaseHp)
        tstyle = DEFEND;

    conductor->setStrategy(tstyle);


    vector<Strategy*> allStrategy;
    vector<AIHero*> AIHeroList;
    for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
    AIHeroList.push_back(new AIHero(myBase));

    switch (tstyle) {
    case NORMAL:
        allStrategy = normalAction();
        break;
    case STEAL:
        allStrategy = stealAction();
        break;
    case DEFEND:
        allStrategy = defendAction();
        break;
    case WILD:
        allStrategy = wildAction();
        break;
    default:
        break;
    }


    for(int i = 0; i < allStrategy.size(); ++i)
        allStrategy[i]->setAIHeroList(AIHeroList);
    for(int i = 0; i < allStrategy.size(); ++i)
        allStrategy[i]->setConsole(console);
    for(int i = 0; i < allStrategy.size(); ++i)
        for(int j = 0; j < AIHeroList.size(); ++j)
            AIHeroList[j]->setStrategy(allStrategy[i]);
    for(int i = 0; i < AIHeroList.size(); ++i)
        AIHeroList[i]->action();
    for(int i = 0; i < AIHeroList.size(); ++i)
        if(AIHeroList[i] != NULL)
            delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
    if(newStrategy == NULL) return false;
    if(newStrategy->getWorker() != this->mHero) return false;
    if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
    {
        if(mStrategy != NULL)
            delete mStrategy;
        mStrategy = newStrategy;
        return true;
    }
    else
        delete newStrategy;
    return false;
}

void AIHero::action()
{
    if (mStrategy != NULL) mStrategy->work();
}

Conductor* Conductor::getConductor(Console *console)
{
    if (instance != 0)
    {
        instance->setConsole(console);
        return instance;
    }
    else
    {
        instance = new Conductor(console);
        return instance;
    }
}

Conductor *Conductor::getConductor()
{
    return instance;
}

Conductor::Conductor(Console *console)
{
    for (int i = 0; i < MAX_ROUND; i++) {
        this->strategyHistory[i] = UNDEFINED;
    }
    this->console = console;
}

void Conductor::setStrategy(style strategy)
{
    strategyHistory[console->round()] = strategy;
}

void Conductor::setStrategy(style strategy, int round)
{
    if (round >= 0 && round < MAX_ROUND) strategyHistory[round] = strategy;
}

style Conductor::getStrategy(int round)
{
    if (round >= 0 && round <= MAX_ROUND)
        return strategyHistory[round];
    else
        return UNDEFINED;
}

style Conductor::getStrategy()
{
    return strategyHistory[console->round()];
}

static int basicDanger = 150, cantmoveDanger = 20, skillDanger = 250, heroFactor = 8, dangerFactor = 6;

int Conductor::dangerArg(Pos myPos, Pos enemyPos)
{
    int mydangerarg = 0, enemydangerarg = 0;
    UnitFilter myfilter;
    myfilter.setAreaFilter(new Circle(myPos, supportRange), "a");
    vector<PUnit*> myUnits = console->friendlyUnits(myfilter);
    for (int i = 0; i < myUnits.size(); i++) {
        PUnit* myhero = myUnits[i];
        if (!myhero->findBuff("Reviving") && (myhero->isWild() || myhero->isHero())) {
            mydangerarg += basicDanger;
            if (myhero->findBuff("WaitRevive")) {
                mydangerarg -= myhero->findBuff("WaitRevive")->timeLeft * cantmoveDanger;
                continue;
            }

            if (myhero->findBuff("Dizzy")) {
                mydangerarg -= myhero->findBuff("Dizzy")->timeLeft * cantmoveDanger;
                continue;
            }

            if (myhero->canUseSkill("Sacrifice") || myhero->canUseSkill("HammerAttack")) {
                mydangerarg += skillDanger;
            }

            mydangerarg += myhero->atk * myhero->hp / (heroFactor * myhero->findSkill("attack")->maxCd);
        }
    }
    UnitFilter enemyfilter;
    enemyfilter.setAreaFilter(new Circle(enemyPos, supportRange), "a");
    vector<PUnit*> enemyUnits = console->enemyUnits(enemyfilter);
    for (int i = 0; i < enemyUnits.size(); i++) {
        PUnit* enemyhero = enemyUnits[i];
        if (!enemyhero->findBuff("Reviving") && (enemyhero->isWild() || enemyhero->isHero())) {
            enemydangerarg += basicDanger;
            if (enemyhero->findBuff("WaitRevive")) {
                enemydangerarg -= enemyhero->findBuff("WaitRevive")->timeLeft * cantmoveDanger;
                continue;
            }

            if (enemyhero->findBuff("Dizzy")) {
                enemydangerarg -= enemyhero->findBuff("Dizzy")->timeLeft * cantmoveDanger;
                continue;
            }

            if (enemyhero->canUseSkill("Sacrifice") || enemyhero->canUseSkill("HammerAttack")) {
                enemydangerarg += skillDanger;
            }

            enemydangerarg += enemyhero->atk * enemyhero->hp / (heroFactor * enemyhero->findSkill("attack")->maxCd);
        }
    }

//    return (enemydangerarg - mydangerarg) / dangerFactor;
    return 0;
}

void Conductor::setConsole(Console *console)
{
    this->console = console;
}

int Attack::countWorth()
{
    this->worth = 0;
    if(target->findBuff("Reviving") != NULL || target->findSkill("attack")->cd > 1)
        this->worth = strategyDisabled;
    else if(dis2(worker->pos,target->pos) <= supportRange)
    {
        UnitFilter filter;
        filter.setAreaFilter(new Circle(target->pos, THREAT_RANGE), "a");
        vector<PUnit*> helpers = console->friendlyUnits(filter);
        int totalHelpers = 0;
        for (int i = 0; i < helpers.size(); i++)
        {
            PUnit* helper = helpers[i];
            if (helper->range > dis2(helper->pos, target->pos)) {
                totalHelpers++;
            }
        }
        if (totalHelpers > 3) totalHelpers = 3;
        this->worth += totalHelpers * helperArg;

        if (worker->findBuff("WinOrDie")) {
            this->worth += 15 * attackArg * ((double)target->hp / worker->atk + 1);
            if (dis2(worker->pos, target->pos) < worker->range)
                this->worth *= 2;
        }
        else {
            if (!target->findBuff("WinOrDie"))
                this->worth += ((double)(target->max_hp + goBackHomeHp/2)/(double)(target->hp + goBackHomeHp/2)) * (double)attackArg;
        }

        if(dis2(worker->pos,target->pos) > worker->range + worker->speed * 2 && totalHelpers <= 2)
            this->worth -= 3*outOfRangeArg;
        if (dis2(worker->pos,target->pos) > worker->range
                && (worker->speed <= target->speed || (worker->speed > target->speed && worker->hp < goBackHomeHp))
                && target->hp < goBackHomeHp)
            this->worth -= 8*outOfRangeArg;
        if (worker->atk - target->def > target->hp && dis2(worker->pos,target->pos) <= worker->range && !target->canUseSkill("SuperDead"))
            this->worth += killArg;


        if ((target->isWild() && Conductor::getStrategy() != WILD) ||
                (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
                                                  && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
            this->worth -= monsterAvoid;

        if (target->isWild() && (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
             && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
            this->worth += monsterAvoid + goWildArg;

        if (target->findBuff("Dizzy") != NULL)
            this->worth += attackDizzy;
        if (target->findBuff("BeAttacked") != NULL)
            this->worth += focusArg;
        if (dis2(target->pos, MILITARY_BASE_POS[console->camp()]) < BASE_THREAT_RANGE)
            this->worth += 10*protectBaseArg;

        if ((target->findBuff("WinOrDie") && !target->findBuff("WaitRevive"))
                && dis2(worker->pos,target->pos) <= worker->range && dis2(worker->pos,target->pos) > target->range
                && worker->findSkill("attack")->cd == 0)
            this->worth += attackArg * 100;

        if (worker->findSkill("attack")->cd == 0 && worker->range > target->range && ((
                (target->findSkill("Sacrifice") && target->findSkill("Sacrifice")->mp < (target->mp + target->mp * 2.0 * RECOVER_RATE)
                 && (!target->findBuff("Dizzy") || target->findBuff("Dizzy")->timeLeft <= 1)
                 && (!target->findBuff("Reviving") || target->findBuff("Reviving")->timeLeft <= 1)
                 && target->findSkill("Sacrifice")->cd <= 1))
                || (target->findBuff("WinOrDie") && dis2(target->pos, worker->pos) <= worker->range))
                ) {
            int attacked = 0;
            for (int i = 0; i < AIHeroList.size(); i++) {
                AIHero* aihero = AIHeroList[i];
                if (!aihero->getStrategy() || lowerCase(aihero->getStrategy()->getName()) != lowerCase("attack")
                        || ((Attack*)aihero->getStrategy())->getTarget() != target) continue;
                PUnit* otherworker = aihero->getStrategy()->getWorker();
                PUnit* enemy = ((Attack*)aihero->getStrategy())->getTarget();
                if (otherworker == this->worker) continue;
                if (dis2(otherworker->pos, enemy->pos) < otherworker->range && otherworker->canUseSkill("attack"))
                {
                    attacked++;
                }
            }
            if (attacked <= 1) {
                this->worth += stopBerserkerArg * (target->hp + target->atk);
                if (dis2(target->pos, MILITARY_BASE_POS[console->camp()]) < maxRange)
                    this->worth *= 5;
            }
        }

        bool isNearMine = dis2(MINE_POS[0], target->pos) < THREAT_RANGE * 2 / 3;

        for (int i = 0; i < MINE_NUM; i++) {
            if (dis2(MINE_POS[i], target->pos) < 2*inplaceRange) {
                isNearMine = true;
                break;
            }
        }

        bool isNearBase = (dis2(target->pos, MILITARY_BASE_POS[0]) < THREAT_RANGE)
                || (dis2(target->pos, MILITARY_BASE_POS[1]) < THREAT_RANGE);
        if (!isNearMine && !isNearBase)
            this->worth -= outOfMineArg;
    }

    return this->worth;
}

void Attack::work()
{
    console->selectUnit(worker);
    if (worker->range >= dis2(worker->pos, target->pos))
        console->attack(target);
    else
        console->move(target->pos);
}

int UseSkill::countWorth()
{
    this->worth = 0;
    console->selectUnit(worker);
    vector<PSkill*> skillList = console->getSkills();
    for(int i = 0; i < skillList.size(); ++i)
        if(isActiveSkill(skillList[i]))
        {
            if(!worker->canUseSkill(skillList[i]))
                this->worth = strategyDisabled;
            else
            {
                if(!strcmp(skillList[i]->name, "HammerAttack"))
                {
                    this->worth = hammerAttackArg;
                    if (target->findBuff("Reviving") || target->findBuff("WaitRevive"))
                        this->worth = strategyDisabled;
                    if ((target->isWild() && Conductor::getStrategy() != WILD) ||
                            (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
                                                              && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
                        this->worth -= monsterAvoid;

                    if (target->isWild() && (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
                         && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
                        this->worth += monsterAvoid + goWildArg;

                    if (dis2(worker->pos,target->pos) <= THREAT_RANGE)
                    {
                        this->worth += (double)target->atk * (double)threatArg;
                        if (target->canUseSkill("Hammerattack"))
                            this->worth += 3*skillThreatArg;
                        if (target->canUseSkill("Sacrifice"))
                            this->worth += skillThreatArg;
                        if (dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
                            this->worth -= 2*outOfRangeArg;
                        if (dis2(worker->pos,target->pos) > skillList[i]->range() && worker->speed <= target->speed)
                            this->worth -= 5*outOfRangeArg;
                        UnitFilter filter;
                        filter.setAreaFilter(new Circle(worker->pos, ATTACK_RANGE), "a");
                        vector<PUnit*> helpers = console->friendlyUnits(filter);
                        int totalHelpers = helpers.size();
                        if (totalHelpers > 3) totalHelpers = 3;
                        this->worth += helpers.size() * helperArg;
                        if (target->findBuff("Dizzy") != NULL)
                            this->worth -= hammerDizzy;
                        if (target->findBuff("WinOrDie") && target->canUseSkill("SuperDead"))
                            this->worth -= hammerDizzy;
                        for (int j = 0; j < this->AIHeroList.size(); j++) {
                            AIHero* hero = AIHeroList[j];
                            if (hero->getStrategy() && lowerCase(hero->getStrategy()->getName()) == lowerCase("UseSkill")) {
                                PUnit* tworker = hero->getStrategy()->getWorker();
                                if (tworker->findSkill("HammerAttack") && ((UseSkill*)hero->getStrategy())->getTarget() == target)
                                    this->worth -= hammerDizzy;
                            }
                        }
                    }

                    if (dis2(target->pos, MILITARY_BASE_POS[console->camp()]) < BASE_THREAT_RANGE
                            && dis2(target->pos, worker->pos) < USE_SACRIFICE_RANGE)
                        this->worth += 10*protectBaseArg;

                }
                else if(!strcmp(skillList[i]->name, "Sacrifice"))
                {
                    if(target->findBuff("Reviving") || worker->findSkill("Attack")->cd > 1)
                        this->worth = strategyDisabled;

                    if(dis2(worker->pos,target->pos) <= USE_SACRIFICE_RANGE && target->hp > worker->atk)
                    {
                        if (!target->findBuff("WinOrDie"))
                            this->worth += 5 * attackArg * (target->hp / (worker->atk + worker->hp) + 1);
                        else
                            this->worth += 5 * (double)attackArg;

                        if (worker->hp < goBackHomeHp && !worker->canUseSkill("SuperDead")) {
                            this->worth -= 2*killArg;
                        }
                        else if (worker->hp < goBackHomeHp)
                            this->worth -= killArg;

                        if (dis2(worker->pos, target->pos) > 2 * worker->speed && !target->findBuff("Dizzy"))
                            this->worth -= outOfRangeArg * 2;
                        if (dis2(worker->pos, target->pos) > worker->range
                                && (worker->speed < target->speed || (worker->speed >= target->speed && worker->hp < goBackHomeHp))
                                && target->hp < goBackHomeHp && !target->findBuff("Dizzy"))
                            this->worth -= 10*outOfRangeArg;
                        if (target->findBuff("Dizzy") != NULL)
                            this->worth += attackDizzy;
                    }
                    int threats = 0;
                    UnitFilter filter;
                    filter.setAreaFilter(new Circle(worker->pos, maxView), "a");
                    vector<PUnit*> threaters = console->enemyUnits(filter);
                    for (int j = 0; j < threaters.size(); j++)
                    {
                        PUnit* t = threaters[j];
                        if (dis2(worker->pos, t->pos) < t->range + t->speed + worker->speed
                                && (t->isHero() || t->isWild())
                                && (t->findSkill("attack")->cd == 0 || (t->findSkill("attack")->cd == 1 && target->range > worker->range))
                                && (!t->findBuff("Reviving") || t->findBuff("Reviving")->timeLeft <= 1)
                                && (!t->findBuff("Dizzy") || t->findBuff("Dizzy")->timeLeft <= 1)) {
                            threats++;
                        }
                        if (t->canUseSkill("HammerAttack") && dis2(worker->pos, t->pos) < HAMMERATTACK_RANGE + t->speed + worker->speed) {
                            threats++;
                        }
                    }
                    if (worker->findSkill("SuperDead")->cd > 1) {
                        threats *= 2;
                    }

                    this->worth -= threats * sacrificeThreatArg;

                    if (dis2(target->pos, MILITARY_BASE_POS[console->camp()]) < BASE_THREAT_RANGE
                            && dis2(target->pos, worker->pos) < USE_SACRIFICE_RANGE)
                        this->worth += 10*protectBaseArg + threats * sacrificeThreatArg;

                }

                else if(!strcmp(skillList[i]->name, "SetObserver"))
                {
                    if ((target->isWild() && Conductor::getStrategy() != WILD) ||
                            (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
                                                              && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
                        this->worth -= monsterAvoid;

                    if (target->isWild() && (Conductor::getStrategy() == WILD && dis2(target->pos, wildmineNum[console->camp()][0]) > 2*inplaceRange
                         && dis2(target->pos, wildmineNum[console->camp()][1]) > 2*inplaceRange))
                        this->worth += monsterAvoid + goWildArg;

                    if(target->findBuff("Reviving") != NULL)
                        this->worth = strategyDisabled;
                    if(dis2(worker->pos,target->pos) <= supportRange)
                    {
                        this->worth += observerArg;
                        if(target->findBuff("Dizzy") != NULL)
                            this->worth -= hammerDizzy;
                        Pos dpos = (target->pos - worker->pos);
                        Pos npos = worker->pos;
                        while (isValidPos(npos)) npos = npos + dpos;
                        this->targetPos = console->closestPos(worker->pos, skillList[i]->range(), npos);
                        UnitFilter filter;
                        filter.setTypeFilter("Observer", "a");
                        filter.setAreaFilter(new Circle(targetPos, maxView), "a");
                        if (console->friendlyUnits(filter).size() > 0) {
                            this->worth = strategyDisabled;
                        }
                    }
                }
                else if (!strcmp(skillList[i]->name, "Blink"))
                {
                    if (dis2(target->pos, worker->pos) <= skillList[i]->range() + worker->range
                            && dis2(target->pos, worker->pos) > worker->range
                            && target->hp + (target->hp * HP_RECOVER_RATE) < worker->atk - target->def
                            && !target->findBuff("WinOrDie") && !target->findBuff("Reviving")) {
                            this->worth += 10 * killArg;
                            targetPos = target->pos;
                        }
                }
            }
            break;
        }
    return this->worth;
}

void UseSkill::work()
{
    console->selectUnit(worker);
    vector<PSkill*> skillList = console->getSkills();
    for(int i = 0; i < skillList.size(); ++i)
    {
        PSkill* skill = skillList[i];
        if(isActiveSkill(skill))
        {
            if(!strcmp(skill->name, "HammerAttack"))
            {
                if (skill->range() >= dis2(target->pos, worker->pos))
                    console->useSkill(skillList[i], target);
                else
                    console->move(target->pos);
            }
            else if(!strcmp(skillList[i]->name, "Sacrifice"))
            {
                console->useSkill(skillList[i], NULL);
            }
            else
            {
                if (dis2(worker->pos, targetPos) < skillList[i]->range())
                    console->useSkill(skill, targetPos);
                else
                    console->move(targetPos);
            }
            break;
        }
    }
}

int Tempt::countWorth()
{
    this->worth = strategyDisabled;
    return this->worth;
}

void Tempt::work()
{
}

int BaseAttack::countWorth()
{
    this->worth = 0;
    if (dis2(target->pos, worker->pos) > MILITARY_BASE_RANGE)
    {
        return this->worth;
    }
    if(target->findBuff("Reviving") != NULL)
        this->worth = strategyDisabled;
    this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
    if(target->findBuff("Dizzy") != NULL)
        this->worth += attackDizzy;
    return this->worth;
}

void BaseAttack::work()
{
    console->baseAttack(target);
}

int GoMining::countWorth()
{
    this->worth = miningArg;
    if(target == MINE_POS[0])
    {
        for(int i = 0; i < AIHeroList.size(); ++i)
            if(AIHeroList[i]->getStrategy() != NULL)
                if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
                {
                    GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
                    if(otherMining->getTarget() == this->target){
                        this->worth -= sameMineArg;
                        break;
                    }
                }
    }
    this->worth -= dis(worker->pos, target);
    if(target == MINE_POS[0])
        this->worth += centerMineArg;

//    if (dis2(target, worker->pos) < worker->view && target == MINE_POS[0])
//    {
//        int danger = Conductor::dangerArg(worker->pos, target);
//        if (danger > 0)
//            this->worth -= danger;
//    }

    bool inbattle = false;
    UnitFilter filter;
    filter.setAreaFilter(new Circle(worker->pos, THREAT_RANGE), "a");
    vector<PUnit*> t = console->enemyUnits(filter);
    for (int i = 0; i < t.size(); i++) {
        if ((t[i]->isHero() || t[i]->isWild()) && lowerCase(t[i]->name) != lowerCase("Observer"))
            if (!t[i]->findBuff("Reviving"))
                inbattle = true;
    }

    if ((worker->findBuff("BeAttacked") || inbattle) && dis2(worker->pos, target) <= MINING_RANGE) {
        this->worth -= inBattleArg;
    }
    return this->worth;
}

void GoMining::work()
{
    console->selectUnit(worker);

    UnitFilter minefilter;
    minefilter.setTypeFilter("Mine");
    minefilter.setAreaFilter(new Circle(worker->pos, SET_OBSERVER_RANGE + MINING_RANGE), "a");
    vector<PUnit*> mines = console->enemyUnits(minefilter);
    if (mines.size() > 0 && dis2(mines[0]->pos, worker->pos) > MINING_RANGE
            && worker->canUseSkill("setObserver")) {
        Pos tpos = console->closestPos(mines[0]->pos, MINING_RANGE, worker->pos);
        if (tpos != worker->pos && tpos != mines[0]->pos) {
            console->useSkill("setObserver", tpos);
            return;
        }
    }


    if (console->round() < 40 && lowerCase(worker->name) == lowerCase("Master") && worker->canUseSkill("Blink"))
    {
        console->useSkill("Blink", console->closestPos(worker->pos, BLINK_RANGE, target));
        History::getHistory()->setNextMove(worker, console->closestPos(worker->pos, BLINK_RANGE, target));
    }
    else if (lowerCase(worker->name) == lowerCase("Scouter") && console->round() <= 3
             || ((lowerCase(worker->name) == lowerCase("Berserker") || lowerCase(worker->name) == lowerCase("Hammerguard")) && console->round() <= 1))
        ;
    else
        console->move(target);
}

int GoBackHome::countWorth()
{
    this->worth = 0;
    if (worker->hp <= goBackHomeHp && worker->findBuff("WinOrDie") == 0)
        this->worth += goBackHomeArg;
    else
        if (worker->hp <= worker->max_hp / 2 && worker->findBuff("WinOrDie") == 0 && worker->findBuff("BeAttacked"))
            this->worth += goBackHomeArg / 5;
    if (console->round() - History::getHistory()->getLastAttackedRound(worker->id) >= 4)
        this->worth = goBackHomeBaseArg;

    bool thisturn = false;
    UnitFilter filter;
    filter.setAreaFilter(new Circle(spyPos[console->camp()][0], THREAT_RANGE), "a");
    if (console->enemyUnits(filter).size() > 2) {
        lastBeingAttackedRound = console->round();
        thisturn = true;
        for (int i = defendTurnsBegin; i < defendTurnsEnd; i++)
            Conductor::getConductor()->setStrategy(DEFEND, console->round()+i);
    }

    filter.setAreaFilter(new Circle(spyPos[console->camp()][1], THREAT_RANGE), "w");
    if (console->enemyUnits(filter).size() > 2) {
        lastBeingAttackedRound = console->round();
        thisturn = true;
        for (int i = defendTurnsBegin; i < defendTurnsEnd; i++)
            Conductor::getConductor()->setStrategy(DEFEND, console->round()+i);
    }

//    if (lastBeingAttackedRound >= console->round() - 30 && Conductor::getConductor()->getStrategy() == DEFEND
//            && console->getMilitaryBase()->hp > defendBaseHp)
//    {
//        this->worth += goBackHomeArg;
//        if (lowerCase(worker->name) == lowerCase("Scouter"))
//        {
//            this->worth = 0;
//        }
//    }

    if (dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) < 2*inplaceRange) {
        this->worth = strategyDisabled;
    }

    return this->worth;
}

void GoBackHome::work()
{
    console->selectUnit((const PUnit*)worker);
    if (worker->canUseSkill("Blink")) {
        console->useSkill("Blink", console->closestPos(worker->pos, BLINK_RANGE, console->getMilitaryBase()->pos));
    }
    else
        console->move(console->getMilitaryBase()->pos);
}

int CallBackHome::countWorth()
{
    this->worth = 0;
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MILITARY_BASE_POS[console->camp()], maxView), "a");
    vector<PUnit*> enemies = console->enemyUnits(filter);
    if (enemies.size() > 0) {
        this->worth = enemies.size() * baseThreatArg;
        totalCallback++;
    }
    if (dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) < maxView)
    {
        this->worth = strategyDisabled;
    }

    if (totalCallback > enemies.size() + 3)
        this->worth = strategyDisabled;

    return this->worth;
}

void CallBackHome::work()
{
    if (dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) < 2*inplaceRange
            || console->gold() - console->goldCostCurrentRound() <= console->callBackCost(worker->level))
        console->move(MILITARY_BASE_POS[console->camp()], worker);

    else
    {
        UnitFilter filter;
        filter.setAreaFilter(new Circle(MILITARY_BASE_POS[console->camp()], 2*inplaceRange), "a");
        vector<PUnit*> targets = console->enemyUnits(filter);
        Pos dpos[2];
        if (console->camp() == 0)
            dpos[0] = Pos(-1, 0), dpos[1] = Pos(0, -1);
        else
            dpos[0] = Pos(1, 0), dpos[1] = Pos(0, 1);

        bool positionChoose = false;
        for (int i = 0; i < targets.size(); i++) {
            for (int d = 0; d < 2; d++) {
                PUnit* target = targets[i];
                Pos newpos(target->pos + dpos[d]);
                bool hasUsed = false;
                for (int j = 0; j < targets.size(); j++) {
                    if (newpos == targets[j]->pos) {
                        hasUsed = true;
                        break;
                    }
                }
                if (newpos == console->getMilitaryBase()->pos)
                    hasUsed = true;
                vector<PUnit*> heros = console->friendlyUnits();
                for (int j = 0; j < heros.size(); j++) {
                    if (heros[j]->isHero() && History::getHistory()->getNextMove(heros[j]) == newpos)
                    {
                        hasUsed = true;
                        break;
                    }
                }
                if (!hasUsed) {
                    console->callBackHero(worker, newpos);
                    History::getHistory()->setNextMove(worker, newpos);
                    positionChoose = true;
                    break;
                }
            }
        }
        if (!positionChoose) {
            Pos dpos;
            if (console->camp() == 0)
                dpos = Pos(0, 3);
            else
                dpos = Pos(0, -3);
            console->callBackHero(worker, console->randPosInArea(new Circle(console->getMilitaryBase()->pos + dpos, inplaceRange)));
        }
        if (worker->canUseSkill("Sacrifice"))
            console->useSkill("Sacrifice", NULL, worker);
    }
}

GoGatheringPoint::GoGatheringPoint(PUnit* worker)
{
    setWorker(worker);
    name = "GoGatheringPoint";
}

int GoGatheringPoint::countWorth()
{
    this->worth = gatherArg;
    if (isReady) {
        UnitFilter filter;
        filter.setAreaFilter(new Circle(MILITARY_BASE_POS[1-console->camp()], BASE_THREAT_RANGE), "a");
        vector<PUnit*> heros = console->friendlyUnits(filter);
        int livinghero = 0;
        for (int i = 0; i < heros.size(); i++)
        {
            PUnit* hero = heros[i];
            if (!hero->findBuff("WaitRevive") && !hero->findBuff("Reviving")
                    && hero->isHero() && lowerCase(hero->name) != lowerCase("Observer")) {
                livinghero++;
            }
        }

        if (livinghero <= 2) {
            isReady = false;
            if (History::getHistory()->getEnemyBaseHp(console->round()- (defendTurnsBegin - defendTurnsEnd)) - History::getHistory()->getEnemyBaseHp() <= 500)
                Conductor::setStrategy(WILD);
        }
        this->worth = 0;
        return this->worth;
    }

    if (!isReady) {
        int end = console->camp() == 0 ? ROUTELENGTH-1 : 0;
        UnitFilter filter;
        filter.setAreaFilter(new Circle(stealRoute[route][end], maxView), "a");
        vector<PUnit*> enemies = console->enemyUnits(filter);
        if (enemies.size() >= 2) {
            Conductor::setStrategy(WILD);
        }
    }

    if (lowerCase(worker->name) == lowerCase("Master")) {
        this->worth = 0;
    }

    return this->worth;
}

void GoGatheringPoint::work()
{
    console->selectUnit(worker);

    int masters = totalHeros == 8 ? 2 : 1;
    if (console->camp() == 0)
    {
        bool arranged = false;
        for (int i = ROUTELENGTH-2; i >= 0; i--)
        {
            if (almostInline(worker->pos, stealRoute[route][i], stealRoute[route][i+1]) ||
                    dis2(worker->pos, stealRoute[route][i]) < inplaceRange) {
//                cout << "goto:" << i << endl;
                console->move(stealRoute[route][i+1]);
                arranged = true;
                break;
            }
        }
        if (!arranged)
            console->move(stealRoute[route][0]);

        UnitFilter filter;
        filter.setAreaFilter(new Circle(stealRoute[route][ROUTELENGTH-1], inplaceRange), "a");
        vector<PUnit*> inPosUnits = console->friendlyUnits(filter);
        if (inPosUnits.size() >= totalHeros - masters) {
            isReady = true;
            route = rand() % 2;
            console->move(MILITARY_BASE_POS[1-console->camp()]);
        }
    }
    else
    {
        bool arranged = false;
        for (int i = 1; i <= ROUTELENGTH-1; i++)
        {
            if (almostInline(worker->pos, stealRoute[route][i], stealRoute[route][i-1]) ||
                    dis2(worker->pos, stealRoute[route][i]) < inplaceRange) {
                console->move(stealRoute[route][i-1]);
                arranged = true;
                break;
            }
        }
        if (!arranged)
            console->move(stealRoute[route][ROUTELENGTH-1]);

        UnitFilter filter;
        filter.setAreaFilter(new Circle(stealRoute[route][0], inplaceRange), "a");
        vector<PUnit*> inPosUnits = console->friendlyUnits(filter);
        if (inPosUnits.size() >= totalHeros - masters) {
            isReady = true;
            route = rand() % 2;
            console->move(MILITARY_BASE_POS[1-console->camp()]);
        }
    }
}

bool GoGatheringPoint::almostInline(Pos p0, Pos p1, Pos p2)
{
    double t = (p1.x - p2.x)*(p0.y - p2.y) - (p1.y - p2.y)*(p0.x - p2.x);
    t /= sqrt((p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y));
    if (t > 20 || t < -20) return false;
    return true;
}


int AttackBase::countWorth()
{
    if (dis2(worker->pos, MILITARY_BASE_POS[1-console->camp()]) < THREAT_RANGE)
        this->worth = 1000*attackBaseArg;
    else
        this->worth = outOfBaseArg;

    if (lowerCase(worker->name) == lowerCase("Master"))
        this->worth = 0;
    return this->worth;
}

void AttackBase::work()
{
    console->selectUnit(worker);
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MILITARY_BASE_POS[1-console->camp()], 10), "a");
    vector<PUnit*> bases = console->enemyUnits(filter);
    bool arranged = false;
    for (int i = 0; i < bases.size(); i++) {
        if (bases[i]->isBase()) {
            if (worker->canUseSkill("Sacrifice")) {
                console->useSkill("Sacrifice", NULL);
            }
            else
                if (dis2(bases[i]->pos, worker->pos) < worker->range)
                    console->attack(bases[i]);
                else
                    console->move(bases[i]->pos);
            arranged = true;
            break;
        }
    }
    if (!arranged)
        console->move(MILITARY_BASE_POS[1-console->camp()]);
}


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(NULL));
    AIController controller(map,info,cmd);
    if(info.round == 0)
    {
        for(int i = 1; i <= 4; ++i)
            controller.buyNewHero();
        return;
    }
    if(newHeroFirst)
    {
        controller.buyNewHero();
        controller.levelupHero();
    }
    else
    {
        controller.levelupHero();
        controller.buyNewHero();
    }

    cout << info.gold << endl;

    controller.action();

}

History::History(Console *console)
{
    this->console = console;
    for (int i = 0; i < MAX_ROUND; i++) {
        this->enemyBaseHp[i] = MILITARY_BASE_HP;
    }
}

History *History::getHistory(Console *console)
{
    if (instance) {
        instance->setConsole(console);
        return instance;
    }
    else {
        instance = new History(console);
        return instance;
    }
}

History *History::getHistory()
{
    return instance;
}

void History::setConsole(Console *_console)
{
    console = _console;
}

void History::setLastAttackedRound(int heroid, int round)
{
    lastAttackedRound[heroid] = round;
}

int History::getLastAttackedRound(int heroid)
{
    return lastAttackedRound[heroid];
}

int History::getlastOccupyingMine(int minenum)
{
    return lastOccupyingMine[minenum];
}

bool History::isControllingMine(int minenum)
{
    return (lastOccupyingMine[minenum] == console->round());
}


void History::setNextMove(PUnit *hero, Pos nextpos)
{
    if (hero)
        nextMove[hero->id] = nextpos;
}

Pos History::getNextMove(PUnit *hero)
{
    if (hero)
        return nextMove[hero->id];
}


void History::updateHistory()
{
    History* history = History::instance;
    vector<PUnit*> units = console->friendlyUnits();
    for (int i = 0; i < units.size(); i++){
        PUnit* hero = units[i];
        if (hero->isHero() && hero->findBuff("BeAttacked")) {
            history->setLastAttackedRound(hero->id, console->round());
        }
    }

    for (int i = 0; i < MINE_NUM; i++) {
        UnitFilter filter;
        filter.setAreaFilter(new Circle(MINE_POS[i], THREAT_RANGE), "a");
        vector<PUnit*> heros = console->friendlyUnits(filter);
        vector<PUnit*> enemies = console->enemyUnits(filter);
        int totheros = 0, totenemies = 0;
        for (int j = 0; j < heros.size(); j++)
        {
            PUnit* hero = heros[j];
            if (hero->isHero() && !hero->findBuff("Reviving")
                    && !hero->findBuff("WaitRevive") && lowerCase(hero->name) != lowerCase("Observer"))
                totheros++;
        }
        for (int j = 0; j < enemies.size(); j++)
        {
            PUnit* enemy = enemies[j];
            if ((enemy->isHero() || enemy->isWild()) && lowerCase(enemy->name) != lowerCase("Observer")
                    && !enemy->findBuff("Reviving") && !enemy->findBuff("WaitRevive"))
                totenemies++;
        }
        if (totenemies == 0 && totheros != 0)
            history->lastOccupyingMine[i] = console->round();
    }

    UnitFilter filter;
    filter.setTypeFilter("MilitaryBase", "a");
    vector<PUnit*> enemybase = console->enemyUnits(filter);
    if (enemybase.size() > 0) {
        PUnit* ebase = enemybase[0];
        history->setEnemyBaseHp(ebase->hp);
    }
    else
        if (console->round() > 0)
            history->setEnemyBaseHp(history->getEnemyBaseHp(console->round()-1));

    vector<PUnit*> mybase = console->friendlyUnits(filter);
    history->setMyBaseHp(mybase[0]->hp);

    for (int i = 0; i < 50; i++) {
        Defend::hammered[i] = Defend::attacked[i] = Defend::winordied[i] = false;
    }

    CallBackHome::totalCallback = 0;

}



int Spy::countWorth()
{
    this->worth = 0;
    if (lowerCase(worker->name) == lowerCase("Scouter") && !worker->findBuff("Reviving"))
    {
        this->worth = spyArg;
    }
    return this->worth;
}

void Spy::work()
{
    console->selectUnit(worker);
    UnitFilter filter;
    filter.setTypeFilter("Observer", "a");
    filter.setAreaFilter(new Circle(spyPos[console->camp()][0], inplaceRange), "a");
    vector<PUnit*> observer1 = console->friendlyUnits(filter);
    if (observer1.size() == 0) {
        if (dis2(worker->pos, spyPos[console->camp()][0]) > SET_OBSERVER_RANGE)
            console->move(spyPos[console->camp()][0] - Pos(1, 1));
        else
            console->useSkill("SetObserver", spyPos[console->camp()][0]);
        return;
    }
    UnitFilter filter2;
    filter2.setTypeFilter("Observer", "w");
    filter2.setAreaFilter(new Circle(spyPos[console->camp()][1], inplaceRange), "a");
    vector<PUnit*> observer2 = console->friendlyUnits(filter2);
    if (observer2.size() == 0) {
        if (dis2(worker->pos, spyPos[console->camp()][1]) > SET_OBSERVER_RANGE)
            console->move(spyPos[console->camp()][1] - Pos(1, 1));
        else
            console->useSkill("SetObserver", spyPos[console->camp()][1]);
        return;
    }

    console->move(spyPos[console->camp()][2]);

}

int ClearObserver::countWorth()
{
    this->worth = 0;
    for (int i = 0; i < MINE_NUM; i++) {
        if (dis2(MINE_POS[i], worker->pos) < MINING_RANGE && History::isControllingMine(i)) {
            UnitFilter filter;
            filter.setAreaFilter(new Circle(MINE_POS[i], MINING_RANGE), "a");
            filter.setTypeFilter("Observer", "a");
            if (console->enemyUnits(filter).size() > 0)
                this->worth = clearObserverArg;
        }
    }


    if (dis2(MILITARY_BASE_POS[console->camp()], worker->pos) < THREAT_RANGE) {
        UnitFilter filter;
        filter.setAreaFilter(new Circle(dis2(MILITARY_BASE_POS[console->camp()], worker->pos), THREAT_RANGE), "a");
        filter.setTypeFilter("Observer", "a");
        if (console->enemyUnits(filter).size() > 0)
            this->worth = clearObserverArg;
    }

    return this->worth;
}

void ClearObserver::work()
{
    for (int i = 0; i < MINE_NUM; i++) {
        if (dis2(MINE_POS[i], worker->pos) < MINING_RANGE && History::isControllingMine(i)) {
            UnitFilter filter;
            filter.setAreaFilter(new Circle(MINE_POS[i], MINING_RANGE), "a");
            filter.setTypeFilter("Observer", "a");
            vector<PUnit*> enemyobserver = console->enemyUnits(filter);
            if (enemyobserver.size() > 0)
            {
                console->attack(enemyobserver[0], worker);
            }
        }
    }
}


void myShortestPath(const PMap& map, Pos start, Pos dest, const std::vector<Pos>& blocks, std::vector<Pos>& _path)
{
    History* history = History::getHistory();
    Console* console = history->getConsole();
    vector<PUnit*> heros = console->friendlyUnits();
    PUnit* thishero = NULL;
    for (int i = 0; i < heros.size(); i++) {
        if (heros[i]->pos == start)
        {
            thishero = heros[i];
            break;
        }
    }

    vector<Pos> myblocks;
    for (int i = 0; i < blocks.size(); i++) {
        bool ishero = false;
        for (int j = 0; j < heros.size(); j++) {
            PUnit* hero = heros[j];
            if (hero->isHero() && !hero->findBuff("Reviving")
                    && !hero->findBuff("Dizzy") && !hero->findBuff("WaitRevive")
                    && heros[j]->pos == blocks[i])
            {
                if (dis2(history->getNextMove(hero), start) < maxSpeed)
                    myblocks.push_back(history->getNextMove(hero));
                ishero = true;
                break;
            }
        }
        if (ishero) continue;
        myblocks.push_back(blocks[i]);
    }

    findShortestPath(map, start, dest, myblocks, _path);
    for (int i = 0; (i < _path.size() && dis2(_path[i], start) < thishero->speed); i++)
    {
        history->setNextMove(thishero, _path[i]);
    }
}


int Avoid::countWorth()
{
    this->worth = 0;
    int dist = dis2(worker->pos, target->pos);
    if (target->findBuff("WinOrDie") && target->canUseSkill("attack")
            && (!target->findBuff("Dizzy") || target->findBuff("Dizzy")->timeLeft <= 1)
            && dist < 2 * target->range && worker->speed >= target->speed)
        this->worth += winOrDieAvoidArg;
    if (target->atk > worker->hp && target->canUseSkill("attack")
            && dist < 2 * target->range && worker->speed >= target->speed)
        this->worth += 5*killArg;
    if (worker->findBuff("BeAttacked")) this->worth += goBackHomeBaseArg;
    return this->worth;
}

void Avoid::work()
{
    console->selectUnit(worker);
    Pos dpos = worker->pos - target->pos;
    Pos npos = worker->pos;
    while (isValidPos(npos + dpos)) npos = npos + dpos;
    if (worker->canUseSkill("Blink"))
    {
        console->useSkill("Blink", npos);
        History::getHistory()->setNextMove(worker, npos);
    }
    else
        console->move(npos);
}

bool isValidPos(Pos p) {
    return (p.x >= 0 && p.x < MAP_SIZE && p.y >= 0 && p.y < MAP_SIZE);
}

int Defend::countWorth()
{
    this->worth = 0;
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MILITARY_BASE_POS[console->camp()], 2*inplaceRange), "a");
    if (dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) < 2*inplaceRange
            && console->enemyUnits(filter).size() > 0) {
        this->worth = protectBaseArg * 1000;
    }
    return this->worth;
}

void Defend::work()
{
    console->selectUnit(worker);
    if (worker->canUseSkill("Sacrifice")) {
        console->useSkill("Sacrifice", NULL);
        return;
    }
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MILITARY_BASE_POS[console->camp()], 3*maxRange), "a");
    vector<PUnit*> enemies = console->enemyUnits(filter);
    PUnit* target = NULL;
    int maxworth = 0;
    for (int i = 0; i < enemies.size(); i++) {
        PUnit* enemy = enemies[i];
        if (!enemy->isHero() && !enemy->isWild()) continue;
        int tworth = 0;

        if (enemy->canUseSkill("Sacrifice") || enemy->findBuff("WinOrDie") || !attacked[enemy->id])
            tworth += 100000000;
        else
            tworth += enemy->atk * enemy->hp;

        if (enemy->findBuff("BeAttacked"))
            tworth += 100*focusArg;

        if (worker->findBuff("WinOrDie") && dis2(worker->pos, enemy->pos) < 1.5 * worker->range && !winordied[enemy->id])
            tworth += 200000000;

        if (dis2(enemy->pos, MILITARY_BASE_POS[console->camp()]) < enemy->range)
            tworth *= 2;

        if (tworth > maxworth) {
            maxworth = tworth;
            target = enemy;
        }
    }

    if (target == NULL) {
        console->move(console->getMilitaryBase()->pos);
        return;
    }

    if (worker->canUseSkill("HammerAttack") && !hammered[target->id] && !target->findBuff("Dizzy")) {
        if (dis2(worker->pos, target->pos) < HAMMERATTACK_RANGE) {
            console->useSkill("HammerAttack", target);
            hammered[target->id] = true;
            attacked[target->id] = true;
        }
        else
            console->move(target->pos);
    }

    else {
        if (dis2(worker->pos, target->pos) < worker->range) {
            console->attack(target);
            if (worker->canUseSkill("attack"))
                attacked[target->id] = true;
            if (worker->canUseSkill("attack") && worker->findBuff("WinOrDie"))
                winordied[target->id] = true;
        }
        else
            console->move(target->pos);
    }

}

int SearchEnemy::countWorth()
{
    this->worth = 0;
    if (console->getMilitaryBase()->hp < defendBaseHp) {
        this->worth = baseThreatArg * 100;
    }
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MILITARY_BASE_POS[console->camp()], BASE_THREAT_RANGE));
    if (console->enemyUnits(filter).size() > 0 || lowerCase(worker->name) == lowerCase("Scouter"))
        this->worth = 0;
    return this->worth;
}

void SearchEnemy::work()
{
    console->selectUnit(worker);
    if (console->round() % 20 < 10)
        console->move(searchPos[console->camp()][0]);
    else
        console->move(searchPos[console->camp()][1]);
}

int GoWildMines::countWorth()
{
    this->worth = goWildArg;
    return this->worth;
}

void GoWildMines::work()
{
    console->selectUnit(worker);

    HERO_NAME[6] = "Berserker";
    costs[6] = 3;
    if (totalHeros > 6) {
        wildmineNum[0][1] = 2;
        wildmineNum[1][1] = 3;
    }
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MINE_POS[wildmineNum[console->camp()][gotoMine]], inplaceRange), "a");
    filter.setTypeFilter("Mine", "a");
    vector<PUnit*> mines = console->enemyUnits(filter);
    if (mines.size() > 0) {
        PUnit* mine0 = mines[0];
        if (console->unitArg("Energy", "Current", mine0) <= 0 && History::isControllingMine(wildmineNum[console->camp()][gotoMine]) && totalHeros >= 5)
            gotoMine = 1 - gotoMine;
    }

    if (lowerCase(worker->name) == lowerCase("Scouter"))
        console->move(MINE_POS[wildmineNum[console->camp()][1-gotoMine]]);
    else
        console->move(MINE_POS[wildmineNum[console->camp()][gotoMine]]);
}

int CheckMines::countWorth()
{
    this->worth = 0;
    if (History::isControllingMine() && totalHeros >= 7) {
        this->worth = goWildArg;
    }
    if (lowerCase(worker->name) == lowerCase("Scouter"))
        this->worth = 0;

    vector<PUnit*> heros = console->friendlyUnits();
    int livinghero = 0;
    for (int i = 0; i < heros.size(); i++)
    {
        PUnit* hero = heros[i];
        if (!hero->findBuff("WaitRevive") && !hero->findBuff("Reviving")
                && hero->isHero() && lowerCase(hero->name) != lowerCase("Observer")) {
            livinghero++;
        }
    }

    if (livinghero <= 6)
        this->worth = 0;

    return this->worth;
}

void CheckMines::work()
{
    console->selectUnit(worker);
    UnitFilter filter;
    filter.setAreaFilter(new Circle(MINE_POS[checkMine[gotoMine]], inplaceRange), "a");
    filter.setTypeFilter("Mine", "a");
    vector<PUnit*> mines = console->enemyUnits(filter);
    if (mines.size() > 0) {
        PUnit* mine0 = mines[0];
        if (console->unitArg("Energy", "Current", mine0) <= 0 && History::isControllingMine(checkMine[gotoMine]) && totalHeros >= 5)
            gotoMine = 1 - gotoMine;
    }

    console->move(MINE_POS[checkMine[gotoMine]]);
}

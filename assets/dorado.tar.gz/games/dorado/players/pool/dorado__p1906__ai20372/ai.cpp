#include "console.h"
#include<math.h>
#include<fstream> //remember to delete this!!!
using namespace std;

#define MAXHEROS 16
#define STEPMAPSIZE 13
#define STEPMAPMIDPOINTX 6
#define STEPMAPMIDPOINTY 6
#define ROOT5 2.236068774998
#define ROOT8 2.82842712
#define ROOT12 3.4641016151378
#define GROUPDIS 6
#define BLOCKTHRED 20
#define BLINKDIS 9
#define VIEWDIS 12
#define OVERWHELMGAP 3000
#define GENERALDEF 10
//#define MAXNODES 30000

enum GroupingType {
	FourHeroOpening=0,
	TwoberserkerOpening,
	AroundCenter,
	Rat,
};

enum BasicCmd {
	Maneuver=0,
	AttackUnit,
	HammerAttack,
	Sacrifice,
	Blink
};

struct MultiRoundCmd
{
	int index;
	vector<BasicCmd> basicCmds;
	vector<Pos> paramPos;
	vector<int> objIndexes;
	int step;
};

struct FPath
{
	int step;
	Pos originPos;
	Pos prePos;
};

struct TGroup
{
	vector<int> membersIndex;
	enum CmdType {
		Maneuver=0,
		AttackEnemyGroup,
		Form,
		Scout,
		FightForMine,
		//MergeGroup, seems not to be used
		FarmDragon,
		FarmRoshan,
		StealMine, //only roshan
		AttackBase,
		DefendBase,
		Mining,
		Doge,
		Suicide
	}cmdType;
	Pos paramPos;
	int lParam,rParam;
};

typedef double StepMap[STEPMAPSIZE][STEPMAPSIZE];
typedef Pos PreStepMap[STEPMAPSIZE][STEPMAPSIZE];

static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int gameRound = -1;

static int idMyHeros[MAXHEROS]; 
static int nMyHeros;
static int idEnemyHeros[MAXHEROS]; 
static int nEnemyHeros;
static PUnit recordMyHeros[MAXHEROS];
static PUnit recordEnemyHeros[MAXHEROS];
static PUnit* pMyHeros[MAXHEROS];
static PUnit* pEnemyHeros[MAXHEROS];
static FPath fPath[MAP_SIZE][MAP_SIZE];
static StepMap stepMap;
static PreStepMap preStepMap;
static bool openFindPathMap[MAP_SIZE][MAP_SIZE];
static Pos posCentralMine;
static int counterAroundCenterOverwhelm;
static bool flagHighGround[MAP_SIZE][MAP_SIZE];
static double scoreMap[MAP_SIZE][MAP_SIZE];
static int objectEnemyAnger[MAXHEROS];
static int levelEnemyAnger[MAXHEROS];
static int roundEnemyAnger[MAXHEROS];
static bool flagLastTimeHit[MAXHEROS];
static vector <MultiRoundCmd> multiRoundCmds;
static bool actionMark[MAXHEROS];
static double simpleStepMap[STEPMAPSIZE][STEPMAPSIZE];
static Pos posBorn[2]; //player = 0,1
//(last time) false run; true hit; 
//every time attack should refresh this to true


//function
//bool 
bool refreshMove(Pos & originPos, Pos & nowPos, Pos & nextPos, vector<Pos> & activePoints, StepMap & stepMap, PreStepMap & preStepMap, const PMap & map, int speed, double interLength, vector<Pos> & interPath, bool openMap[STEPMAPSIZE][STEPMAPSIZE]) //-1 illegal else return addition length
{
	//check legal
	int sumDelta;
	int realX,realY,realXX,realYY;
	bool legalFlag=1;
	if ((nextPos.x>=0)&&(nextPos.x<STEPMAPSIZE)&&(nextPos.y>=0)&&(nextPos.y<STEPMAPSIZE)) {
		legalFlag=1;
	} else {
		legalFlag=0;
	}
	realX=nextPos.x-STEPMAPMIDPOINTX+originPos.x;
	realY=nextPos.y-STEPMAPMIDPOINTY+originPos.y;
	if ((legalFlag)&&(realX>=0)&&(realX<MAP_SIZE)&&(realY>=0)&&(realY<MAP_SIZE)) {
		legalFlag=1;
	} else {
		legalFlag=0;
	}
	if (legalFlag) {
		for (int i=0;i<interPath.size()-1;i++) {
			realX=interPath[i].x-STEPMAPMIDPOINTX+originPos.x;
			realY=interPath[i].y-STEPMAPMIDPOINTY+originPos.y;
			realXX=interPath[i+1].x-STEPMAPMIDPOINTX+originPos.x;
			realYY=interPath[i+1].y-STEPMAPMIDPOINTY+originPos.y;
			//cout<<"P1:("<<realX<<","<<realY<<")-->P2:("<<realXX<<","<<realYY<<")"<<endl;
			//cout<<"H1:"<<map.getHeight(realX,realY)<<" H2:"<<map.getHeight(realXX,realYY)<<endl;
			if (abs(map.getHeight(realX,realY)-map.getHeight(realXX,realYY))>1){
				legalFlag=0;
				break;
			}
			//cout<<"Flag:"<<legalFlag<<endl;
		}
	}
	//refresh stepmap , premap and activepoints
	if ((legalFlag)&&((stepMap[nowPos.x][nowPos.y]+interLength)*(stepMap[nowPos.x][nowPos.y]+interLength)<speed+0.0001)&&(stepMap[nowPos.x][nowPos.y]+interLength<stepMap[nextPos.x][nextPos.y]))
	{
		stepMap[nextPos.x][nextPos.y]=stepMap[nowPos.x][nowPos.y]+interLength;
		preStepMap[nextPos.x][nextPos.y]=nowPos;
		if (!openMap[nextPos.x][nextPos.y]) {
			activePoints.push_back(nextPos);
			openMap[nextPos.x][nextPos.y]=true;
		}
	}
	return legalFlag;
}

void makeStepMap(Pos & originPos, StepMap & stepMap, PreStepMap & preStepMap, const PMap & map, int speed)
{
	bool openMap[STEPMAPSIZE][STEPMAPSIZE];
	for (int i=0;i<STEPMAPSIZE;i++){
		for (int j=0;j<STEPMAPSIZE;j++){
			stepMap[i][j]=999;
			preStepMap[i][j]=Pos(-1,-1);
			openMap[i][j]=false;
		}
	}
	stepMap[STEPMAPMIDPOINTX][STEPMAPMIDPOINTY]=0;
	openMap[STEPMAPMIDPOINTX][STEPMAPMIDPOINTX]=true;
	Pos nowPos,nextPos;
	Pos midPos;
	double interLength,tempLength;
	midPos=Pos(STEPMAPMIDPOINTX,STEPMAPMIDPOINTY);
	vector<Pos> activePoints;
	activePoints.clear();
	activePoints.push_back(midPos);
	vector<Pos> interPath;
	while (!activePoints.empty()) {
		nowPos=activePoints.back();
		activePoints.pop_back();
		bool checkFlag,fakeFlag;
		nextPos=Pos(nowPos.x+1,nowPos.y);
		interPath.clear(); interPath.push_back(nowPos); interPath.push_back(nextPos);
		checkFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,1,interPath,openMap);
			nextPos=Pos(nowPos.x+2,nowPos.y+1);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x+1,nowPos.y)); interPath.push_back(Pos(nowPos.x+1,nowPos.y+1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
			nextPos=Pos(nowPos.x+2,nowPos.y-1);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x+1,nowPos.y)); interPath.push_back(Pos(nowPos.x+1,nowPos.y-1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
	
		nextPos=Pos(nowPos.x,nowPos.y+1);
		interPath.clear(); interPath.push_back(nowPos); interPath.push_back(nextPos);
		checkFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,1,interPath,openMap);
	
			nextPos=Pos(nowPos.x+1,nowPos.y+2);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x,nowPos.y+1)); interPath.push_back(Pos(nowPos.x+1,nowPos.y+1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
			nextPos=Pos(nowPos.x-1,nowPos.y+2);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x,nowPos.y+1)); interPath.push_back(Pos(nowPos.x-1,nowPos.y+1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
		nextPos=Pos(nowPos.x-1,nowPos.y);
		interPath.clear(); interPath.push_back(nowPos); interPath.push_back(nextPos);
		checkFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,1,interPath,openMap);
		//if (!checkFlag) cout<<"!";
		//if (checkFlag){
			nextPos=Pos(nowPos.x-2,nowPos.y+1);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x-1,nowPos.y)); interPath.push_back(Pos(nowPos.x-1,nowPos.y+1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
			nextPos=Pos(nowPos.x-2,nowPos.y-1);
			interPath.push_back(Pos(nowPos.x-1,nowPos.y)); interPath.push_back(Pos(nowPos.x-1,nowPos.y-1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
		nextPos=Pos(nowPos.x,nowPos.y-1);
		interPath.clear(); interPath.push_back(nowPos); interPath.push_back(nextPos);
		checkFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,1,interPath,openMap);
		//if (!checkFlag) cout<<"!";
		//if (checkFlag){
			nextPos=Pos(nowPos.x+1,nowPos.y-2);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x,nowPos.y-1)); interPath.push_back(Pos(nowPos.x+1,nowPos.y-1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);
			nextPos=Pos(nowPos.x-1,nowPos.y-2);
			interPath.clear(); interPath.push_back(nowPos);
			interPath.push_back(Pos(nowPos.x,nowPos.y-1)); interPath.push_back(Pos(nowPos.x-1,nowPos.y-1));
			interPath.push_back(nextPos);
			fakeFlag=refreshMove(originPos,nowPos,nextPos,activePoints,stepMap,preStepMap,map,speed,ROOT5,interPath,openMap);

		openMap[nowPos.x][nowPos.y]=false;
	}
	
}

bool inRange(const Pos & checkPos,const Pos & originPos,const Pos & targetPos)
{
	bool resFlag=1;
	if (abs(checkPos.x-originPos.x)+abs(checkPos.x-targetPos.x)>abs(originPos.x-targetPos.x)) resFlag=0;
	if (resFlag) if (abs(checkPos.y-originPos.y)+abs(checkPos.y-targetPos.y)>abs(originPos.y-targetPos.y)) resFlag=0;
	return resFlag;
}

//using default findpath

void myPathMove(Pos & targetPos, vector<Pos> & wayPoints, Pos & nowPos,const PMap & map, int speed) 
{//quote:makeStepMap(Pos & originPos, StepMap & stepMap, PreStepMap & preStepMap, const PMap & map, int speed)
	Pos returnPos;
	int stage=0;
	double bestDis;
	targetPos=Pos(-1,-1);
	bestDis=9999;
	for (int i=0;i<wayPoints.size();i++)
	{
		if (dis2(nowPos,wayPoints.back())>dis2(wayPoints[i],wayPoints.back()))
		{
			stage=i;
		}
	}
	if ((dis2(nowPos,wayPoints[stage])<speed)&&(stage!=wayPoints.size()-1)) stage++;
	returnPos=wayPoints[stage];
	makeStepMap(nowPos,stepMap,preStepMap,map,speed);
	int realX,realY;
	for (int i=0;i<STEPMAPSIZE;i++){
		for (int j=0;j<STEPMAPSIZE;j++){
			if ((stepMap[i][j]*stepMap[i][j]<speed+0.0001)) {
				realX=nowPos.x-STEPMAPMIDPOINTX+i;
				realY=nowPos.y-STEPMAPMIDPOINTY+j;
				Pos realPos=Pos(realX,realY);
				if (dis(realPos,returnPos)<bestDis) {
					targetPos=realPos;
					bestDis=dis(realPos,returnPos);
				}
			}
		}
	}
}

//basic execute
void executeHammerAttack(PUnit * & pSubHero, PUnit * & pObjHero, const PMap & map,Console & console)
{
	console.selectUnit(pSubHero);
	console.useSkill(pSubHero->findSkill("HammerAttack"),pObjHero);
}

void executeSacrifice(PUnit * & pSubHero, const PMap & map,Console & console)
{
	console.selectUnit(pSubHero);
	console.useSkill(pSubHero->findSkill("Sacrifice"),NULL);
}

void executeAttackUnit(PUnit* & pSubHero,PUnit* & pObjHero,const PMap & map, Console & console)
{
	console.selectUnit(pSubHero);
	console.attack(pObjHero);
}

void executeManeuver(PUnit* pSubHero, Pos & targetPos, const PMap & map, Console & console)
{//quote:myPathMove(Pos & targetPos, vector<Pos> & wayPoints, Pos & nowPos,const PMap & map, int speed) 
	vector <Pos> maneuverPath;
	double bestDis;
	Pos cmdPos;
	//cout<<pSubHero->name<<endl;
	//cout<<pSubHero->canUseSkill("Blink")<<endl;
	//cout<<dis(pSubHero->pos,targetPos)<<endl;
	if ((!strcmp(pSubHero->name,HERO_NAME[1]))&&(pSubHero->canUseSkill("Blink"))&&(dis(pSubHero->pos,targetPos)>60)){
		bestDis=9999;
		for (int i=pSubHero->pos.x-9;i<=pSubHero->pos.x+9;i++){
			for (int j=pSubHero->pos.y-9;j<=pSubHero->pos.y+9;j++){
				if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1))){
					if ((!flagHighGround[i][j])&&(map.getHeight(i,j)<BLOCKTHRED))
					if (dis(Pos(i,j),pSubHero->pos)<BLINKDIS+0.0001)
					if (dis(Pos(i,j),targetPos)<bestDis){
						bestDis=dis(Pos(i,j),targetPos);
						cmdPos=Pos(i,j);
					}
				}
			}
		}
		//cout<<cmdPos.x<<","<<cmdPos.y;
		console.selectUnit(pSubHero);
		console.useSkill("Blink",cmdPos);
	}
	else {
		maneuverPath.clear();
		maneuverPath.push_back(pSubHero->pos);
		//wait to be meshed, writing!
		maneuverPath.push_back(targetPos);
		myPathMove(cmdPos,maneuverPath,pSubHero->pos,map,pSubHero->speed);
		console.selectUnit(pSubHero);
		console.move(cmdPos);
	}
}
//end basic execute

void tacticMaker(GroupingType & groupingType,const PPlayerInfo & info,const PMap & map) //
{
	if (nEnemyHeros==0) {
		groupingType=FourHeroOpening;
		//groupingType=TwoberserkerOpening;
	} else {
		groupingType=AroundCenter;
	}
}

void enemyGrouping(TGroup enemyGroups[MAXHEROS],int & nEnemyGroups,const PPlayerInfo & info,const PMap & map)
{
	bool openFlags[MAXHEROS];
	memset(openFlags,true,sizeof(openFlags));
	nEnemyGroups=0;
	int iCheck=0;
	int iGroup;
	while (iCheck<nEnemyHeros) {
		if (openFlags[iCheck]) {
			enemyGroups[nEnemyGroups].membersIndex.push_back(iCheck);
			openFlags[iCheck]=false;
			iGroup=0;
			while (iGroup<enemyGroups[nEnemyGroups].membersIndex.size()) {
				int & idTheHero = idEnemyHeros[enemyGroups[nEnemyGroups].membersIndex[iGroup]];
				PUnit & theHero = recordEnemyHeros[idTheHero];
				for (int j=0;j<nEnemyHeros;j++) if (openFlags[j]){
					PUnit & cmpHero = recordEnemyHeros[idEnemyHeros[j]];
					if (dis(theHero.pos,cmpHero.pos)<GROUPDIS+0.0001) {
						openFlags[j]=false;
						enemyGroups[nEnemyGroups].membersIndex.push_back(j);
					}
				}
				iGroup++;
			}
			nEnemyGroups++;
		}
		iCheck++;
	}
}

double calcBattleValue(vector <PUnit> & calcedGroup,const double & oppAvgDef)
{//ultimately should be done by NN
	double res=0;
	for (int i=0;i<calcedGroup.size();i++){
		const PSkill* pSkillAttack = calcedGroup[i].findSkill("Attack");
		res=res+calcedGroup[i].hp*(calcedGroup[i].atk-oppAvgDef)/(pSkillAttack->maxCd);
	}
	return res;
}

bool checkContact(vector <PUnit> & centralAllies,vector <PUnit> & centralEnemies)
{
	bool resFlag,resFlag0,resFlag1;
	resFlag=0; resFlag0=0; resFlag1=0;
	for (int i=0;i<centralAllies.size();i++){
		for (int j=0;j<centralEnemies.size();j++){
			if (dis2(centralAllies[i].pos,centralEnemies[j].pos)<=centralAllies[i].range) {
				resFlag0=1;
			}
			if (dis2(centralEnemies[j].pos,centralAllies[i].pos)<=centralEnemies[j].range) {
				resFlag1=1;
			}
		}
	}
	resFlag=resFlag0&&resFlag1;
	return resFlag;
}

bool checkNotFormed(vector <PUnit> & centralAllies)
{
	bool resFlag=0;
	for (int i=0;i<centralAllies.size();i++){
		for (int j=0;j<centralAllies.size();j++){
			if (dis2(centralAllies[i].pos,centralAllies[j].pos)>centralAllies[i].range) {
				resFlag=1;
				break;
			}
		}
	}
	return resFlag;
}

int findEnemyGroupI(TGroup enemyGroups[MAXHEROS],int & nEnemyGroups,int & id)
{
	int enemyIndex;
	int resInt;
	resInt=-1;
	for (int iGroup=0;iGroup<nEnemyGroups;iGroup++){
		for (int j=0;j<enemyGroups[iGroup].membersIndex.size();j++){
			enemyIndex=enemyGroups[iGroup].membersIndex[j];
			if (recordEnemyHeros[enemyIndex].id=id) {
				resInt=iGroup;
				break;
			}
		}
		if (resInt!=-1) break;
	}
	return resInt;
}

Pos findPosForm(vector <PUnit> & formGroup)
{//weighted gravity center
	Pos resPos;
	double maxWeight=0;
	double thisWeight=0;
	double resRX,resRY;
	resRX=0;
	resRY=0;
	for (int i=0;i<formGroup.size();i++) {
		maxWeight+=100/sqrt(formGroup[i].speed);
	}
	resPos.x=0;
	resPos.y=0;
	for (int i=0;i<formGroup.size();i++) {
		resRX+=100/sqrt(formGroup[i].speed)/maxWeight*double(formGroup[i].pos.x);
		resRY+=100/sqrt(formGroup[i].speed)/maxWeight*double(formGroup[i].pos.y);
	}
	resPos.x=round(resRX);
	resPos.y=round(resRY);
	return resPos;
}
		
void myGrouping(GroupingType & groupingType, TGroup myGroups[MAXHEROS], int & nMyGroups, TGroup enemyGroups[MAXHEROS], int & nEnemyGroups, const PPlayerInfo & info,const PMap & map)
{
	//if it is 1234 opening, then 3 group 1 scout.
	if (groupingType==FourHeroOpening) {
		nMyGroups=2;
		myGroups[0].membersIndex.clear();
		myGroups[1].membersIndex.clear();
		for (int i=0;i<nMyHeros;i++) {
			if (!strcmp(pMyHeros[i]->name,HERO_NAME[3])) {
				myGroups[0].membersIndex.push_back(i);
				//cout<<"true"<<pMyHeros[i]->name<<endl;
			} else {
				myGroups[1].membersIndex.push_back(i);
				//cout<<"false"<<pMyHeros[i]->name<<endl;
			}
		}
		myGroups[0].cmdType=TGroup::Scout;
		myGroups[0].paramPos=posCentralMine;
		myGroups[1].cmdType=TGroup::Maneuver;
		myGroups[1].paramPos=posCentralMine;
	}
	if (groupingType==AroundCenter){//quote:posCentralMine
		//quote:counterAroundCenterOverwhelm
		bool unsettleMyHeros[MAXHEROS];
		for (int i=0;i<nMyHeros;i++) {
			unsettleMyHeros[i]=true;
			const PUnit* pTheHero = pMyHeros[i];
			for (int iBuff=0;iBuff<pTheHero->buffs.size();iBuff++){
				const PBuff & theBuff = pTheHero->buffs[iBuff];
				if ((!strcmp(theBuff.name,"Reviving"))||(!strcmp(theBuff.name,"WaitRevivie"))){
					unsettleMyHeros[i]=false;
					break;
				}
			}
		}
		vector <PUnit> centralEnemies;
		vector <PUnit> centralAllies;
		centralEnemies.clear();
		centralAllies.clear();
		double myAvgDef=0;
		double enemyAvgDef=0;
		double myBattleValue,enemyBattleValue;
		for (int i=0;i<nEnemyHeros;i++){
			const PUnit & theEnemy = recordEnemyHeros[i];
			enemyAvgDef+=theEnemy.def;
			if (dis(posCentralMine,theEnemy.pos)<VIEWDIS+0.0001) {
				centralEnemies.push_back(recordEnemyHeros[i]);
			}
		}
		enemyAvgDef/=nEnemyHeros;
		for (int i=0;i<nMyHeros;i++) {//calc my avg def
			myAvgDef+=pMyHeros[i]->def;
			//by the way form myGroup
			if (dis(posCentralMine,pMyHeros[i]->pos)<VIEWDIS+0.0001) {
				centralAllies.push_back(*pMyHeros[i]);
			}
		}
		myAvgDef/=nMyHeros;
		enemyBattleValue=calcBattleValue(centralEnemies,myAvgDef);
		myBattleValue=calcBattleValue(centralAllies,myAvgDef);
		if (myBattleValue-enemyBattleValue>OVERWHELMGAP+0.0001) {//I overwhelm
			cout<<"My overwhelming"<<endl;
			//remember to update stalemate situation
			counterAroundCenterOverwhelm++;
			// if (counterAroundCenterOverwhelm>5) writing!
			bool flagNotFormed=0;
			bool contactFlag=0;
			contactFlag=checkContact(centralAllies,centralEnemies);
			cout<<"contactFlag="<<contactFlag<<endl;
			flagNotFormed=checkNotFormed(centralAllies);
			if (centralEnemies.size()==0) { //no Enemy detected
				nMyGroups=0; //writing!!
			} 
			else if (contactFlag) {
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							unsettleMyHeros[j]=false;
							break;
						}
					}
				myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::FightForMine;
				myGroups[0].paramPos=posCentralMine;
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
			} else if (flagNotFormed) {
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							unsettleMyHeros[j]=false;
							break;
						}
					}
					myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::Form;
				Pos posForm;
				posForm=findPosForm(centralAllies);
				myGroups[0].paramPos=posForm;//maybe no use
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
			} else { //just attack the nearest group
				int enemyGroupI;
				enemyGroupI=findEnemyGroupI(enemyGroups,nEnemyGroups,centralEnemies[0].id);
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							unsettleMyHeros[j]=false;
							break;
						}
					}
				myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::AttackEnemyGroup;
				myGroups[0].paramPos=posCentralMine;
				myGroups[0].lParam=enemyGroupI;
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
			}
		} else if (enemyBattleValue-myBattleValue>OVERWHELMGAP+0.0001) {//enemy overwhelm
			//Rat or Reinforce , writing!
			cout<<"enemyOverWhelming"<<endl;
			counterAroundCenterOverwhelm=0;
			nMyGroups=0;
			
		} else {//stalemate
			cout<<"stalemate"<<endl;
			counterAroundCenterOverwhelm=0;
			bool flagNotFormed=0;
			bool contactFlag=0;
			contactFlag=checkContact(centralAllies,centralEnemies);
			cout<<"contactFlag="<<contactFlag<<endl;
			flagNotFormed=checkNotFormed(centralAllies);
			cout<<"checkNotFormed"<<endl;
			if (centralEnemies.size()==0) { //no Enemy detected
				nMyGroups=0; //writing!!
			} 
			else if (contactFlag) {
				cout<<"inContactGrouping"<<endl;
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						//cout<<"wrong here"<<endl;
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							
							unsettleMyHeros[j]=false;
							break;
						}
						//cout<<"no"<<endl;
					}
					myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::FightForMine;
				myGroups[0].paramPos=posCentralMine;
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
				if (!myGroups[1].membersIndex.empty()){
					cout<<myGroups[1].membersIndex[0]<<endl;
					cout<<recordMyHeros[myGroups[1].membersIndex[0]].id<<endl;
				}
				cout<<"group2's size:"<<myGroups[1].membersIndex.size()<<endl;
			} else if (flagNotFormed) {
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							unsettleMyHeros[j]=false;
							break;
						}
					}
					myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::Form;
				Pos posForm;
				posForm=findPosForm(centralAllies);
				myGroups[0].paramPos=posForm;//maybe no use
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
			} else { //just attack the nearest
				int enemyGroupI;
				enemyGroupI=findEnemyGroupI(enemyGroups,nEnemyGroups,centralEnemies[0].id);
				nMyGroups=1;
				myGroups[0].membersIndex.clear();
				for (int i=0;i<centralAllies.size();i++){
					int & checkID = centralAllies[i].id;
					int checkIndex;
					for (int j=0;j<nMyHeros;j++){
						if (pMyHeros[j]->id==checkID) {
							checkIndex=j;
							unsettleMyHeros[j]=false;
							break;
						}
					}
				myGroups[0].membersIndex.push_back(checkIndex);
				}
				myGroups[0].cmdType=TGroup::AttackEnemyGroup;
				myGroups[0].paramPos=posCentralMine;
				myGroups[0].lParam=enemyGroupI;
				nMyGroups=2;
				myGroups[1].membersIndex.clear();
				for (int i=0;i<nMyHeros;i++) if (unsettleMyHeros[i]){
					myGroups[1].membersIndex.push_back(i);
				}
				myGroups[1].cmdType=TGroup::Maneuver;
				myGroups[1].paramPos=posCentralMine;
			}
		}
	}
}

bool checkHammerAttackDangerousBerserker(bool uncoveredEnemyBerserkers[MAXHEROS],const PMap & map,Console & console) //mark
{
	bool resFlag=false;
	bool flagWinOrDie=false;
	for (int i=0;i<nEnemyHeros;i++){
		if (uncoveredEnemyBerserkers[i]) {
			const PUnit & theEnemy = recordEnemyHeros[i];
			for (int iBuff=0;iBuff<theEnemy.buffs.size();iBuff++) {
				if (!strcmp(theEnemy.buffs[iBuff].name,"WinOrDie")){
					flagWinOrDie=true;
					break;
				}
			}
			if (flagWinOrDie) for (int j=0;j<nMyHeros;j++) if (actionMark[j]==false) if (!strcmp(recordMyHeros[j].name,HERO_NAME[0])) {
				const PSkill* skillHammerAttack = recordMyHeros[j].findSkill("HammerAttack");
				if  ((skillHammerAttack->cd==0)&&(dis2(recordMyHeros[j].pos,recordEnemyHeros[i].pos)<=36)) {
					executeHammerAttack(pMyHeros[j],pEnemyHeros[i],map,console);
					actionMark[j]=true;
					uncoveredEnemyBerserkers[i]=false;
					resFlag=true;
				}
			}
		}
	}
	return resFlag;
}

bool oneStepHit(PUnit & subHero, PUnit & objHero, const PMap & map)
{
	bool resFlag=false;
	for (int i=0;i<STEPMAPSIZE;i++){
		for (int j=0;j<STEPMAPSIZE;j++){
			if (simpleStepMap[i][j]<sqrt(subHero.speed)+0.001) {
				Pos realPos;
				int realX,realY;
				realX=subHero.pos.x-STEPMAPMIDPOINTX+i;
				realY=subHero.pos.y-STEPMAPMIDPOINTY+j;
				realPos=Pos(realX,realY);
				if ((inRange(realPos,Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1)))&&(!flagHighGround[realX][realY])&&(map.getHeight(realX,realY)<=BLOCKTHRED)){
					if (dis2(realPos,objHero.pos)<=subHero.range) {
						resFlag=true;
						break;
					}
				}	
			}
		}
	}
	return resFlag;
}

bool directlyHit(PUnit & subHero, PUnit & objHero, const PMap & map)
{
	bool resFlag=false;
	if (dis2(subHero.pos,objHero.pos)<=subHero.range) {
		resFlag=true;
	}
	return resFlag;
}

bool checkSafe(PUnit & subHero,vector<int> exceptionalEnemyIndexes,const PMap & map)
{
	bool resFlag=true;
	bool flagExceptionalEnemies[MAXHEROS];
	memset(flagExceptionalEnemies,false,sizeof(flagExceptionalEnemies));
	for (int i=0;i<exceptionalEnemyIndexes.size();i++){
		flagExceptionalEnemies[exceptionalEnemyIndexes[i]]=true;
	}
	for (int i=0;i<nEnemyHeros;i++) if (!flagExceptionalEnemies[i]){
		if (oneStepHit(subHero,recordEnemyHeros[i],map)){
			resFlag=false;
			break;
		}
	}
	return resFlag;
}

bool checkHammerNBerserkerCombo(const PMap & map, Console & console)
{//writing! there is another situation that dont use onestephit, instead, directhit
 // and didn't consider enemy's hammer
	bool resFlag=false;
	for (int iHammer=0;iHammer<nMyHeros;iHammer++){
		PUnit & theHammer = recordMyHeros[iHammer];
		if (!strcmp(theHammer.name,HERO_NAME[0])&&(!actionMark[iHammer])){
			const PSkill* pSkillHammerAttack = theHammer.findSkill("HammerAttack");
			if (pSkillHammerAttack->cd==0)
			for (int iEnemy=0;iEnemy<nEnemyHeros;iEnemy++){
				PUnit & theEnemy = recordEnemyHeros[iEnemy];
				if (dis2(theHammer.pos,theEnemy.pos)<=36) {
					for (int iBerserker=0;iBerserker<nMyHeros;iBerserker++) {
						PUnit & theBerserker = recordMyHeros[iBerserker];
						if ((!strcmp(theBerserker.name,HERO_NAME[2]))&&((!actionMark[iBerserker]))) {
							const PSkill* pSkillSacrifice = theBerserker.findSkill("Sacrifice");
							if (pSkillSacrifice->cd==0) {
								vector<int> exceptionalEnemyIndexes; //writing , not only the object
								exceptionalEnemyIndexes.clear();
								exceptionalEnemyIndexes.push_back(iEnemy);
								if (oneStepHit(theBerserker,theEnemy,map)&&(checkSafe(theBerserker,exceptionalEnemyIndexes,map))){
									//push_in sacrifice action
									executeHammerAttack(pMyHeros[iHammer],pEnemyHeros[iEnemy],map,console);
									executeSacrifice(pMyHeros[iBerserker],map,console);
									MultiRoundCmd berserkerComboCmd;
									berserkerComboCmd.index=iBerserker;
									berserkerComboCmd.basicCmds.clear();
									berserkerComboCmd.basicCmds.push_back(Maneuver);
									berserkerComboCmd.basicCmds.push_back(AttackUnit);
									berserkerComboCmd.paramPos.clear();
									berserkerComboCmd.paramPos.push_back(theEnemy.pos);
									berserkerComboCmd.paramPos.push_back(theEnemy.pos);
									berserkerComboCmd.objIndexes.clear();
									berserkerComboCmd.objIndexes.push_back(iEnemy);
									berserkerComboCmd.objIndexes.push_back(iEnemy);
									berserkerComboCmd.step=0;
									multiRoundCmds.push_back(berserkerComboCmd);
									actionMark[iHammer]=true;
									actionMark[iBerserker]=true;
									resFlag=true;
								}
							}
						}
					}
				}
			}
		}
	}
	return resFlag;
}

Pos randomWalkPos(const Pos & centralPos,int speed,const PMap & map)
{
	Pos resPos;
	resPos=centralPos;
	vector<Pos> plausiblePos;
	plausiblePos.clear();
	Pos checkPos;
	checkPos=Pos(centralPos.x+floor(sqrt(speed)),centralPos.y);
	if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1)))&&(!flagHighGround[checkPos.x][checkPos.y])&&(map.getHeight(checkPos.x,checkPos.y)<=BLOCKTHRED)){
		plausiblePos.push_back(checkPos);
	}
	checkPos=Pos(centralPos.x-floor(sqrt(speed)),centralPos.y);
	if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1)))&&(!flagHighGround[checkPos.x][checkPos.y])&&(map.getHeight(checkPos.x,checkPos.y)<=BLOCKTHRED)){
		plausiblePos.push_back(checkPos);
	}
	checkPos=Pos(centralPos.x,centralPos.y+floor(sqrt(speed)));
	if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1)))&&(!flagHighGround[checkPos.x][checkPos.y])&&(map.getHeight(checkPos.x,checkPos.y)<=BLOCKTHRED)){
		plausiblePos.push_back(checkPos);
	}
	checkPos=Pos(centralPos.x,centralPos.y-floor(sqrt(speed)));
	if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE-1,MAP_SIZE-1)))&&(!flagHighGround[checkPos.x][checkPos.y])&&(map.getHeight(checkPos.x,checkPos.y)<=BLOCKTHRED)){
		plausiblePos.push_back(checkPos);
	}
	if (plausiblePos.size()!=0) {
		resPos=plausiblePos[rand()%plausiblePos.size()];
	}
}

void executeScout(Pos & targetPos,PUnit* pSubHero, const PMap & map, Console & console)
{//quote:executeManeuver(Pos & targetPos,PUnit* pSubHero, const PMap & map, Console & console)
	vector <Pos> scoutPath;
	Pos cmdPos;
	scoutPath.clear();
	//cout<<"11"<<endl;
	//cout<<"id:"<<pSubHero->id<<endl;
	scoutPath.push_back(pSubHero->pos);
	//wait to be meshed, writing!
	//cout<<"12"<<endl;
	scoutPath.push_back(targetPos);
	//cout<<"13"<<endl;
	myPathMove(cmdPos,scoutPath,pSubHero->pos,map,pSubHero->speed);
	//cout<<"14"<<endl;
	console.selectUnit(pSubHero);
	//cout<<"15"<<endl;
	console.move(cmdPos);
}

//
void executeForm(TGroup & executeGroup, const PMap & map, Console & console)
{//quote:executeManeuver(Pos & targetPos,PUnit* pSubHero, const PMap & map, Console & console)
//quote:inRange(const Pos & checkPos,const Pos & originPos,const Pos & targetPos)
	//make blocks map
	int bestDis=999;
	Pos bestPos=Pos(-1,-1);
	double bestScore;
	Pos choosePos;
	cout<<"formPos:("<<executeGroup.paramPos.x<<","<<executeGroup.paramPos.x<<")"<<endl;
	for (int i=0;i<MAP_SIZE;i++) {
		for (int j=0;j<MAP_SIZE;j++) {
			if ((map.getHeight(i,j)>BLOCKTHRED)||(flagHighGround[i][j])){
				scoreMap[i][j]=-999;
			} else {
				scoreMap[i][j]=0;
				if (dis(Pos(i,j),executeGroup.paramPos)<bestDis) {
					bestDis=dis(Pos(i,j),executeGroup.paramPos);
					bestPos=Pos(i,j);
				} else if (abs(dis(Pos(i,j),executeGroup.paramPos)-bestDis)<0.001){
					if (rand()%100>49) {//rand
						bestDis=dis(Pos(i,j),executeGroup.paramPos);
						bestPos=Pos(i,j);
					}
				}
			}
		}
	}
	bool flagBestPosTook=0;
	cout<<"bestPos:"<<bestPos.x<<","<<bestPos.y<<endl;
	//master
	for (int iHero=0;iHero<executeGroup.membersIndex.size();iHero++) {
		PUnit* &pTheHero=pMyHeros[executeGroup.membersIndex[iHero]];
		if (!strcmp(pTheHero->name,HERO_NAME[1])) {
			Pos checkPos;
			if (!flagBestPosTook) {
				executeManeuver(pTheHero,bestPos,map,console);
				scoreMap[bestPos.x][bestPos.y]=-999;
				checkPos=Pos(bestPos.x+1,bestPos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x-1,bestPos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x,bestPos.y+1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x,bestPos.y-1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				flagBestPosTook=1;
			} else {
				Pos choosePos;
				bestScore=-999;
				choosePos=Pos(-1,-1);
				for (int i=bestPos.x-5;i<=bestPos.x+5;i++){
					for (int j=bestPos.y-5;j<=bestPos.y+5;j++)
					if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))
					{
						if (scoreMap[i][j]>bestScore) {
							bestScore=scoreMap[i][j];
							choosePos=Pos(i,j);
						} else if (abs(scoreMap[i][j]-bestScore)<0.001){
							if (rand()%100>49) {
								bestScore=scoreMap[i][j];
								choosePos=Pos(i,j);
							}
						}
					}
				}
				executeManeuver(pTheHero,choosePos,map,console);
				cout<<"Master:"<<choosePos.x<<","<<choosePos.y<<endl;
				scoreMap[choosePos.x][choosePos.y]=-999;
				checkPos=Pos(choosePos.x+1,choosePos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x-1,choosePos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x,choosePos.y+1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x,choosePos.y-1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
			}
		}
	}
	//scouter
	for (int iHero=0;iHero<executeGroup.membersIndex.size();iHero++) {
		PUnit* &pTheHero=pMyHeros[executeGroup.membersIndex[iHero]];
		if (!strcmp(pTheHero->name,HERO_NAME[3])) {
			Pos checkPos;
			if (!flagBestPosTook) {
				executeManeuver(pTheHero,bestPos,map,console);
				cout<<"Scouter:"<<choosePos.x<<","<<choosePos.y<<endl;
				scoreMap[bestPos.x][bestPos.y]=-999;
				checkPos=Pos(bestPos.x+1,bestPos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x-1,bestPos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x,bestPos.y+1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				checkPos=Pos(bestPos.x,bestPos.y-1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[checkPos.x][checkPos.y]+=1;
				}
				flagBestPosTook=1;
			} else {
				Pos choosePos;
				bestScore=-999;
				choosePos=Pos(-1,-1);
				for (int i=bestPos.x-5;i<=bestPos.x+5;i++){
					for (int j=bestPos.y-5;j<=bestPos.y+5;j++)
					if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))
					{
						if (scoreMap[i][j]>bestScore) {
							bestScore=scoreMap[i][j];
							choosePos=Pos(i,j);
						} else if (abs(scoreMap[i][j]-bestScore)<0.001){
							if (rand()%100>49) {
								bestScore=scoreMap[i][j];
								choosePos=Pos(i,j);
							}
						}
					}
				}
				executeManeuver(pTheHero,choosePos,map,console);
				cout<<"Scouter:"<<choosePos.x<<","<<choosePos.y<<endl;
				scoreMap[choosePos.x][choosePos.y]=-999;
				checkPos=Pos(choosePos.x+1,choosePos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x-1,choosePos.y);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x,choosePos.y+1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
				checkPos=Pos(choosePos.x,choosePos.y-1);
				if ((inRange(checkPos,Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))&&(scoreMap[checkPos.x][checkPos.y]>-0.0001)){
					scoreMap[choosePos.x][choosePos.y]+=1;
				}
			}
		}
	}
	//block enemy melee 
	for (int i=bestPos.x-2;i<=bestPos.x+2;i++){
		for (int j=bestPos.y-2;j<=bestPos.y+2;j++) if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))
		{
			for (int iEnemy=0;iEnemy<nEnemyHeros;iEnemy++) {
				if ((recordEnemyHeros[iEnemy].range<=8)&&(dis(Pos(i,j),recordEnemyHeros[iEnemy].pos)<=12)){
					scoreMap[i][j]+=(12-dis(Pos(i,j),recordEnemyHeros[iEnemy].pos));
				}
			}
		}
	}
	for (int iHero=0;iHero<executeGroup.membersIndex.size();iHero++) {
		PUnit* &pTheHero=pMyHeros[executeGroup.membersIndex[iHero]];
		if (!strcmp(pTheHero->name,HERO_NAME[0])) {
			bestScore=-999;
			choosePos=Pos(-1,-1);
			for (int i=bestPos.x-2;i<=bestPos.x+2;i++){
				for (int j=bestPos.y-2;j<=bestPos.y+2;j++) 
				if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))
				{
					if (scoreMap[i][j]>bestScore) {
						bestScore=scoreMap[i][j];
						choosePos=Pos(i,j);
					}
				}
			}
			executeManeuver(pTheHero,choosePos,map,console);
			cout<<"Hammer:"<<choosePos.x<<","<<choosePos.y<<endl;
			scoreMap[choosePos.x][choosePos.y]=-999;
		}
	}
	for (int iHero=0;iHero<executeGroup.membersIndex.size();iHero++) {
		PUnit* &pTheHero=pMyHeros[executeGroup.membersIndex[iHero]];
		if (!strcmp(pTheHero->name,HERO_NAME[2])) {
			bestScore=-999;
			choosePos=Pos(-1,-1);
			for (int i=bestPos.x-2;i<=bestPos.x+2;i++){
				for (int j=bestPos.y-2;j<=bestPos.y+2;j++) if (inRange(Pos(i,j),Pos(0,0),Pos(MAP_SIZE,MAP_SIZE)))
				{
					if (scoreMap[i][j]>bestScore) {
						bestScore=scoreMap[i][j];
						choosePos=Pos(i,j);
					}
				}
			}
			executeManeuver(pTheHero,choosePos,map,console);
			cout<<"Berserker:"<<choosePos.x<<","<<choosePos.y<<endl;
			scoreMap[choosePos.x][choosePos.y]=-999;
		}
	}
}

void executeAttackEnenmyGroup(TGroup & subGroup, TGroup & objGroup, const PMap & map, Console & console)
{//quote:calcBattleValue(vector <PUnit> & calcedGroup,const double & oppAvgDef)
//quote:flagLastTimeHit
	//watch file
	ofstream fout; 
	fout.open("executeFightForMine.txt",ios::app);
	fout<<"gameRound "<<gameRound<<endl;
	//
	vector<PUnit> enemyBerserkers; enemyBerserkers.clear();
	vector<PUnit> enemyHammers; enemyHammers.clear();
	vector<PUnit> enemyMasters; enemyMasters.clear();
	vector<PUnit> enemyScouters; enemyScouters.clear();
	vector<PUnit> myBerserkers; myBerserkers.clear();
	vector<PUnit> myHammers; myHammers.clear();
	vector<PUnit> myMasters; myMasters.clear();
	vector<PUnit> myScouters; myScouters.clear();
	vector<int> indexEnemyH0; indexEnemyH0.clear();
	vector<int> indexEnemyH1; indexEnemyH1.clear();
	vector<int> indexEnemyH2; indexEnemyH2.clear();
	vector<int> indexEnemyH3; indexEnemyH3.clear();
	vector<int> indexMyH0; indexMyH0.clear();
	vector<int> indexMyH1; indexMyH1.clear();
	vector<int> indexMyH2; indexMyH2.clear();
	vector<int> indexMyH3; indexMyH3.clear();
	double myAvgDef,enemyAvgDef;
	myAvgDef=0;	enemyAvgDef=0;
	for (int i=0;i<objGroup.membersIndex.size();i++)
	{
		PUnit & theHero = recordEnemyHeros[objGroup.membersIndex[i]];
		//cout<<"the Index: "<<objGroup.membersIndex[i]<<endl;
		//cout<<"the name: "<<theHero.name<<endl;
		enemyAvgDef+=theHero.def;
		if (!strcmp(theHero.name,HERO_NAME[0])){ //Hammer
			//cout<<"i0"<<endl;
			enemyHammers.push_back(theHero);
			indexEnemyH0.push_back(objGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[1])){ //Master
		//cout<<"i1"<<endl;
			enemyMasters.push_back(theHero);
			indexEnemyH1.push_back(objGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[2])){ //Berserker
		//cout<<"i2"<<endl;
			enemyBerserkers.push_back(theHero);
			indexEnemyH2.push_back(objGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[3])){ //Scouter
		//cout<<"i3"<<endl;
			enemyScouters.push_back(theHero);
			indexEnemyH3.push_back(objGroup.membersIndex[i]);
		}
	}
	if (objGroup.membersIndex.size()==0){
		enemyAvgDef/=GENERALDEF;
	} else{
		enemyAvgDef/=objGroup.membersIndex.size();
	}
	for (int i=0;i<subGroup.membersIndex.size();i++)
	{
		PUnit & theHero = recordMyHeros[subGroup.membersIndex[i]];
		myAvgDef+=theHero.def;
		if (!strcmp(theHero.name,HERO_NAME[0])){ //Hammer
			myHammers.push_back(theHero);
			indexMyH0.push_back(subGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[1])){ //Master
			myMasters.push_back(theHero);
			indexMyH1.push_back(subGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[2])){ //Berserker
			myBerserkers.push_back(theHero);
			indexMyH2.push_back(subGroup.membersIndex[i]);
		}
		if (!strcmp(theHero.name,HERO_NAME[3])){ //Scouter
			myScouters.push_back(theHero);
			indexMyH3.push_back(subGroup.membersIndex[i]);
		}
	}
	
	if (subGroup.membersIndex.size()==0){
		myAvgDef/=GENERALDEF;
	} else {
		myAvgDef/=subGroup.membersIndex.size();
	}
	fout<<"BV calced"<<endl;
	double myRangeBV, myMeleeBV;
	double enemyRangeBV, enemyMeleeBV;
	fout<<"BV calcing"<<endl;
	myMeleeBV=calcBattleValue(myHammers,enemyAvgDef)+calcBattleValue(myBerserkers,enemyAvgDef);
	myRangeBV=calcBattleValue(myMasters,enemyAvgDef)+calcBattleValue(myScouters,enemyAvgDef);
	enemyMeleeBV=calcBattleValue(enemyHammers,myAvgDef)+calcBattleValue(enemyBerserkers,myAvgDef);
	enemyRangeBV=calcBattleValue(enemyMasters,myAvgDef)+calcBattleValue(enemyScouters,myAvgDef);
	//match berserk , complex attack writing!!
	//
	fout<<"BV calced"<<endl;
	if ((myRangeBV>enemyMeleeBV)&&(myMeleeBV<enemyRangeBV)){
		fout<<"safely"<<endl;
		//safely
		//arrow attack and doge
		//writing! melee safely move undone
		for (int i=0;i<indexMyH1.size();i++) {
			int mostAnger=0;
			for (int j=0;j<nEnemyHeros;j++) if (objectEnemyAnger[j]==indexMyH1[i]) {
				if (levelEnemyAnger[j]>mostAnger) mostAnger=levelEnemyAnger[j];
			}
			//fout<<"Anger index "<<indexMyH1[i]<<" :"<<mostAnger<<endl;
			if (mostAnger==1) { 
				if (flagLastTimeHit[indexMyH1[i]]) {
					flagLastTimeHit[indexMyH1[i]]=false;
					//random walk
					Pos randPos;
					randPos=randomWalkPos(pMyHeros[indexMyH1[i]]->pos,pMyHeros[indexMyH1[i]]->speed,map);
					executeManeuver(pMyHeros[indexMyH1[i]],randPos,map,console);
					//cout<<"Execute Master Doge"<<endl;
					actionMark[indexMyH1[i]]=true;
				}
			}
			else if (mostAnger==2) {
				flagLastTimeHit[indexMyH1[i]]=true;
				//cout<<"Execute Master Doge(Hit)"<<endl;
			}
		}
		//no mark arrange attack
		fout<<"uncover calc"<<endl;
		bool uncoveredEnemyBerserkers[MAXHEROS];
		memset(uncoveredEnemyBerserkers,false,sizeof(uncoveredEnemyBerserkers));
		for (int i=0;i<indexEnemyH2.size();i++) {
			PUnit & theEnemy = recordEnemyHeros[indexEnemyH2[i]];
			const PSkill* skillSacrifice = recordEnemyHeros[indexEnemyH2[i]].findSkill("Sacrifice");
			//cout<<"indexEnemyH2[i]"<<indexEnemyH2[i]<<endl;
			//cout<<skillSacrifice->name<<endl;
			if (skillSacrifice->cd==0) {
				uncoveredEnemyBerserkers[indexEnemyH2[i]]=true;
			}
			for (int iBuff=0;iBuff<theEnemy.buffs.size();iBuff++) {
				if(!strcmp(theEnemy.buffs[iBuff].name,"WinOrDie")){
					uncoveredEnemyBerserkers[indexEnemyH2[i]]=true;
				}
			}
			for (int iBuff=0;iBuff<theEnemy.buffs.size();iBuff++) {
				if(!strcmp(theEnemy.buffs[iBuff].name,"WaitRevivie")){
					uncoveredEnemyBerserkers[indexEnemyH2[i]]=false;
				}
			}
		}
		fout<<"scouter"<<endl;
		//Scouter Match and other actions
		for (int iHero=0;iHero<indexMyH3.size();iHero++) {
			PUnit & theHero= recordMyHeros[indexMyH3[iHero]];
			if (!actionMark[indexMyH3[iHero]]) {
				bool flagCovered=false;
				for (int j=0;j<nEnemyHeros;j++){ //need not to check attack cd, for scouter and masters
					if ((uncoveredEnemyBerserkers[j])&&(dis2(recordEnemyHeros[j].pos,theHero.pos)<=theHero.range)){
						executeAttackUnit(pMyHeros[indexMyH3[iHero]],pEnemyHeros[j],map,console);
						fout<<"Execute Scouter Match"<<endl;
						uncoveredEnemyBerserkers[j]=false;
						flagCovered=true;
						break;
					}
				}
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
				if (!flagCovered) {
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH3[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute Scouter Normal Attack"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH3[iHero]],posChosen,map,console);
						fout<<"Execute Scouter Maneuver to random hero"<<endl;
					}
				}
				actionMark[indexMyH3[iHero]]=true;
			}
		}
		//end Scouter
		//Masters match and other action
		for (int iHero=0;iHero<indexMyH1.size();iHero++) {
			PUnit & theHero= recordMyHeros[indexMyH1[iHero]];
			if (!actionMark[indexMyH1[iHero]]) {
				bool flagCovered=false;
				for (int j=0;j<nEnemyHeros;j++){ //need not to check attack cd, for scouter and masters
					if ((uncoveredEnemyBerserkers[j])&&(dis2(recordEnemyHeros[j].pos,theHero.pos)<=theHero.range)){
						executeAttackUnit(pMyHeros[indexMyH1[iHero]],pEnemyHeros[j],map,console);
						fout<<"Execute MasterMatch"<<endl;
						uncoveredEnemyBerserkers[j]=false;
						flagCovered=true;
						break;
					}
				}
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
				if (!flagCovered) {
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH1[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute Master Attack"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH1[iHero]],posChosen,map,console);
						fout<<"Execute Master Attack"<<endl;
					}
				}
				actionMark[indexMyH1[iHero]]=true;
			}
		}
		//end masters
		//melee attack or block
		//special action
		bool flagMagicHammerHitBerserker;
		flagMagicHammerHitBerserker=checkHammerAttackDangerousBerserker(uncoveredEnemyBerserkers,map,console);
		fout<<"checkHammerAttack"<<endl;
		bool flagCombo;
		flagCombo=checkHammerNBerserkerCombo(map,console);
		fout<<"checkCombo"<<endl;		
		//hammer and berserk 
		fout<<indexMyH0.size()<<endl;
		for (int iHero=0;iHero<indexMyH0.size();iHero++) {
			fout<<"iHero:"<<iHero<<endl;
			PUnit & theHero= recordMyHeros[indexMyH0[iHero]];
			if (!actionMark[indexMyH0[iHero]]) {
				fout<<"NoAction"<<endl;
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
					for (int j=0;j<nEnemyHeros;j++) {
						fout<<"dis2:"<<dis2(recordEnemyHeros[j].pos,theHero.pos)<<endl;
						fout<<"theHeroRange:"<<theHero.range<<endl;
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							fout<<"jEnemy in range:"<<j<<endl;
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					fout<<"indexChosen:"<<indexChosen<<endl;
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH0[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"hammer attack unit"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						int iEnemy=rand()%nEnemyHeros;
						posChosen=recordEnemyHeros[iEnemy].pos;
						if ((dis2(posChosen,recordMyHeros[indexMyH0[iHero]].pos)<36)&&(pMyHeros[indexMyH0[iHero]]->canUseSkill("HammerAttack"))) {
							executeHammerAttack(pMyHeros[indexMyH0[iHero]],pEnemyHeros[iEnemy],map,console);
							fout<<"hammer hammer attack"<<endl;
						} else {
							executeManeuver(pMyHeros[indexMyH0[iHero]],posChosen,map,console);
							fout<<"hammer maneuver randomly"<<endl;
						}
						
					}
				actionMark[indexMyH0[iHero]]=true;
			}
		}
		fout<<"berserker step"<<endl;
		fout<<"indexMyH2.size():"<<indexMyH2.size()<<endl;
		for (int iHero=0;iHero<indexMyH2.size();iHero++) {
			fout<<"indexMyH2[iHero]:"<<indexMyH2[iHero]<<endl;
			PUnit & theHero= recordMyHeros[indexMyH2[iHero]];
			fout<<"HeroID"<<theHero.id<<endl;
			fout<<"thePos"<<theHero.pos<<endl;
			if (!actionMark[indexMyH2[iHero]]) {
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH2[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"ber attack unit"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH2[iHero]],posChosen,map,console);
						fout<<"ber maneuver randomly"<<endl;
					}
				actionMark[indexMyH2[iHero]]=true;
			}
		}
		fout<<"endall"<<endl;
		//end all
	} else {
		//writing! delete archer doge??should I??
		fout<<"no-brainer charge situation"<<endl;
		for (int i=0;i<indexMyH1.size();i++) {
			int mostAnger=0;
			for (int j=0;j<nEnemyHeros;j++) if (objectEnemyAnger[j]==indexMyH1[i]) {
				if (levelEnemyAnger[j]>mostAnger) mostAnger=levelEnemyAnger[j];
			}
			if (mostAnger==1) { 
				if (flagLastTimeHit[indexMyH1[i]]) {
					flagLastTimeHit[indexMyH1[i]]=false;
					//random walk
					Pos randPos;
					randPos=randomWalkPos(pMyHeros[indexMyH1[i]]->pos,pMyHeros[indexMyH1[i]]->speed,map);
					executeManeuver(pMyHeros[indexMyH1[i]],randPos,map,console);
					fout<<"Execute Master Doge(Hit)"<<endl;
					actionMark[indexMyH1[i]]=true;
				}
			}
			else if (mostAnger==2) {
				flagLastTimeHit[indexMyH1[i]]=true;
				fout<<"Execute Master Doge(Run)"<<endl;
			}
		}
		//no mark arrange attack
		fout<<"Make Matach List"<<endl;
		bool uncoveredEnemyBerserkers[MAXHEROS];
		memset(uncoveredEnemyBerserkers,false,sizeof(uncoveredEnemyBerserkers));
		for (int i=0;i<indexEnemyH2.size();i++) {
			PUnit & theEnemy = recordEnemyHeros[indexEnemyH2[i]];
			const PSkill* skillSacrifice = recordEnemyHeros[indexEnemyH2[i]].findSkill("Sacrifice");
			//cout<<indexEnemyH2[i]<<endl;
			//cout<<skillSacrifice->name<<endl;
			//cout<<idEnemyHeros[indexEnemyH2[i]]<<endl;
			//cout<<"1"<<endl;
			if (skillSacrifice->cd==0) {
				fout<<indexEnemyH2[i]<<endl;
				uncoveredEnemyBerserkers[indexEnemyH2[i]]=true;
			}
			//cout<<"2"<<endl;
			for (int iBuff=0;iBuff<theEnemy.buffs.size();iBuff++) {
				if(!strcmp(theEnemy.buffs[iBuff].name,"WinOrDie")){
					uncoveredEnemyBerserkers[indexEnemyH2[i]]=true;
				}
			}
			//cout<<"3"<<endl;
			for (int iBuff=0;iBuff<theEnemy.buffs.size();iBuff++) {
				if(!strcmp(theEnemy.buffs[iBuff].name,"WaitRevivie")){
					uncoveredEnemyBerserkers[indexEnemyH2[i]]=false;
				}
			}
			//cout<<"4"<<endl;
		}
		//Scouter Match and other actions
		fout<<"Scouter Matach"<<endl;
		for (int iHero=0;iHero<indexMyH3.size();iHero++) {
			PUnit & theHero= recordMyHeros[indexMyH3[iHero]];
			if (!actionMark[indexMyH3[iHero]]) {
				bool flagCovered=false;
				for (int j=0;j<nEnemyHeros;j++){ //need not to check attack cd, for scouter and masters
					if ((uncoveredEnemyBerserkers[j])&&(dis2(recordEnemyHeros[j].pos,theHero.pos)<=theHero.range)){
						executeAttackUnit(pMyHeros[indexMyH3[iHero]],pEnemyHeros[j],map,console);
						fout<<"Execute Scouter Match"<<endl;
						uncoveredEnemyBerserkers[j]=false;
						flagCovered=true;
						break;
					}
				}
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
				if (!flagCovered) {
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH3[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute Scouter Normal Attack"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH3[iHero]],posChosen,map,console);
						fout<<"Execute Scouter Maneuver to random hero"<<endl;
					}
				}
				actionMark[indexMyH3[iHero]]=true;
			}
		}
		//end Scouter
		//Masters matck and other action
		fout<<"Master Match"<<endl;
		for (int iHero=0;iHero<indexMyH1.size();iHero++) {
			PUnit & theHero= recordMyHeros[indexMyH1[iHero]];
			if (!actionMark[indexMyH1[iHero]]) {
				bool flagCovered=false;
				for (int j=0;j<nEnemyHeros;j++){ //need not to check attack cd, for scouter and masters
					if ((uncoveredEnemyBerserkers[j])&&(dis2(recordEnemyHeros[j].pos,theHero.pos)<=theHero.range)){
						executeAttackUnit(pMyHeros[indexMyH1[iHero]],pEnemyHeros[j],map,console);
						fout<<"Execute master Match"<<endl;
						uncoveredEnemyBerserkers[j]=false;
						flagCovered=true;
						break;
					}
				}
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
				if (!flagCovered) {
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH1[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute master atk"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH1[iHero]],posChosen,map,console);
						fout<<"Execute master random maneuver"<<endl;
					}
				}
				actionMark[indexMyH1[iHero]]=true;
			}
		}
		//end masters
		//melee attack or block
		//special action
		bool flagMagicHammerHitBerserker;
		flagMagicHammerHitBerserker=checkHammerAttackDangerousBerserker(uncoveredEnemyBerserkers,map,console);
		bool flagCombo;
		flagCombo=checkHammerNBerserkerCombo(map,console);
		//hammer and berserk
		for (int iHero=0;iHero<indexMyH0.size();iHero++) {
			PUnit & theHero= recordMyHeros[indexMyH0[iHero]];
			if (!actionMark[indexMyH0[iHero]]) {
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
					for (int j=0;j<nEnemyHeros;j++) {
						fout<<"dis2:"<<dis2(recordEnemyHeros[j].pos,theHero.pos)<<endl;
						fout<<"theHeroRange:"<<theHero.range<<endl;
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH0[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute hammer atk"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						int iEnemy=rand()%nEnemyHeros;
						posChosen=recordEnemyHeros[iEnemy].pos;
						if ((dis2(posChosen,recordMyHeros[indexMyH0[iHero]].pos)<36)&&(pMyHeros[indexMyH0[iHero]]->canUseSkill("HammerAttack"))) {
							executeHammerAttack(pMyHeros[indexMyH0[iHero]],pEnemyHeros[iEnemy],map,console);
							fout<<"hammer hammer attack"<<endl;
						}else{
							executeManeuver(pMyHeros[indexMyH0[iHero]],posChosen,map,console);
							fout<<"Execute hammer random maneuver"<<endl;
						}
					}
				actionMark[indexMyH0[iHero]]=true;
			}
		}
		fout<<"ber act"<<endl;
		for (int iHero=0;iHero<indexMyH2.size();iHero++) {
			fout<<"iHero"<<iHero<<endl;
			PUnit & theHero= recordMyHeros[indexMyH2[iHero]];
			if (!actionMark[indexMyH2[iHero]]) {
				fout<<"in no action mark"<<endl;
				bool flagAttacked=false;
				int indexChosen=-1;
				double defChosen=999;
				double atkChosen=0;
					for (int j=0;j<nEnemyHeros;j++) {
						if (dis2(recordEnemyHeros[j].pos,theHero.pos)<theHero.range){
							if (recordEnemyHeros[j].def<defChosen) {
								indexChosen=j;
								defChosen=recordEnemyHeros[j].def;
								atkChosen=recordEnemyHeros[j].atk;
							} else if (recordEnemyHeros[j].def==defChosen) {
								if (recordEnemyHeros[j].atk>atkChosen){
									indexChosen=j;
									defChosen=recordEnemyHeros[j].def;
									atkChosen=recordEnemyHeros[j].atk;
								}
							}
						}
					}
					fout<<"mid halt"<<endl;
					if (indexChosen!=-1){
						flagAttacked=true;
						executeAttackUnit(pMyHeros[indexMyH2[iHero]],pEnemyHeros[indexChosen],map,console);
						fout<<"Execute ber atk"<<endl;
					}
					if (!flagAttacked) {
						Pos posChosen;
						posChosen=recordEnemyHeros[rand()%nEnemyHeros].pos;
						executeManeuver(pMyHeros[indexMyH2[iHero]],posChosen,map,console);
						fout<<"Execute ber rand maneu"<<endl;
					}
				actionMark[indexMyH2[iHero]]=true;
			}
		}
		fout<<"ber act end"<<endl;
		//aggresive
		//everybody choose closet enemy and go to a random atk_pos
	}
	fout.close();
}

void executeFightForMine(Pos & targetPos,TGroup & executeGroup, TGroup enemyGroups[MAXHEROS], int & nEnemyGroups,const PMap & map, Console & console)
{
	bool contactFlag=0;
	vector <PUnit> centralAllies,centralEnemies;
	centralAllies.clear();
	centralEnemies.clear();
	//cout<<"1"<<endl;
	for (int iMember=0;iMember<executeGroup.membersIndex.size();iMember++) {
		centralAllies.push_back(recordMyHeros[executeGroup.membersIndex[iMember]]);
	}
	//cout<<"2"<<endl;
	for (int i=0;i<nEnemyHeros;i++){
		centralEnemies.push_back(recordEnemyHeros[i]);
	}
	//cout<<"3"<<endl;
	contactFlag=checkContact(centralAllies,centralEnemies);
	//cout<<"4"<<endl;
	if (!contactFlag) {
		//cout<<"5.1"<<endl;
		executeForm(executeGroup,map,console);
		//cout<<"5.2"<<endl;
	}
	else {
		//choose group
		//cout<<"6.1"<<endl;
		int nearestGroup=0;
		int nearestDis=999;
		for (int iGroup=0;iGroup<nEnemyGroups;iGroup++){
			for (int iMember=0;iMember<enemyGroups[iGroup].membersIndex.size();iMember++) {
				PUnit & theEnemy = recordEnemyHeros[enemyGroups[iGroup].membersIndex[iMember]];
				//cout<<"6.11"<<endl;
				if (dis(theEnemy.pos,targetPos)<nearestDis) {
					nearestGroup=iGroup;
					nearestDis=dis(theEnemy.pos,targetPos);
				}
				//cout<<"6.12"<<endl;
			}
		}
		//cout<<"6.13 "<<nearestGroup<<endl;
		//cout<<"nEnemyGroups: "<<nEnemyGroups<<endl;
		//cout<<"myGroupSize: "<<executeGroup.membersIndex.size()<<endl;
		executeAttackEnenmyGroup(executeGroup,enemyGroups[nearestGroup],map,console);
		//cout<<"6.2"<<endl;
	}
}

void executeGroupCmd(TGroup myGroups[MAXHEROS],int & nMyGroups,TGroup enemyGroups[MAXHEROS],int & nEnemyGroups,const PPlayerInfo & info,const PMap & map,Console & console)
{
	//cout<<"why"<<endl;
	//cout<<"GroupCmd"<<endl;
	//cout<<myGroups[0].cmdType<<endl;
	//cout<<myGroups[1].cmdType<<endl;
	for (int iGroup=0;iGroup<nMyGroups;iGroup++){
		//cout<<"you"<<endl;
		if (myGroups[iGroup].cmdType==TGroup::Maneuver){
			for (int iMember=0;iMember<myGroups[iGroup].membersIndex.size();iMember++){
				PUnit* & pSubHero = pMyHeros[myGroups[iGroup].membersIndex[iMember]];
				executeManeuver(pSubHero,myGroups[iGroup].paramPos,map,console);
			}
		}
		//cout<<"crash?"<<endl;
		if (myGroups[iGroup].cmdType==TGroup::Scout){
			for (int iMember=0;iMember<myGroups[iGroup].membersIndex.size();iMember++){
				//cout<<myGroups[iGroup].membersIndex[iMember];
				PUnit* & pSubHero = pMyHeros[myGroups[iGroup].membersIndex[iMember]];
				//cout<<"1"<<endl;
				executeScout(myGroups[iGroup].paramPos,pSubHero,map,console);
				//cout<<"2"<<endl;			
			}
		}
		//cout<<"1"<<endl;
		if (myGroups[iGroup].cmdType==TGroup::Form){
			executeForm(myGroups[iGroup],map,console);
		}
		//cout<<"2"<<endl;	
		if (myGroups[iGroup].cmdType==TGroup::FightForMine){
			executeFightForMine(posCentralMine,myGroups[iGroup],enemyGroups,nEnemyGroups,map,console);
		}
		//cout<<"wtf?"<<endl;
	}
}

void makeHighGroundMap()
{
memset(flagHighGround,false,sizeof(flagHighGround));
flagHighGround[1][1]=true;flagHighGround[1][2]=true;flagHighGround[1][3]=true;flagHighGround[1][4]=true;flagHighGround[1][5]=true;flagHighGround[1][6]=true;flagHighGround[1][7]=true;flagHighGround[1][8]=true;flagHighGround[1][9]=true;flagHighGround[1][10]=true;flagHighGround[2][10]=true;flagHighGround[28][1]=true;flagHighGround[28][2]=true;flagHighGround[30][86]=true;flagHighGround[30][87]=true;flagHighGround[30][88]=true;flagHighGround[30][89]=true;flagHighGround[31][85]=true;flagHighGround[31][86]=true;flagHighGround[31][90]=true;flagHighGround[32][59]=true;flagHighGround[32][85]=true;flagHighGround[33][58]=true;flagHighGround[33][66]=true;flagHighGround[33][84]=true;flagHighGround[33][85]=true;flagHighGround[33][94]=true;flagHighGround[33][95]=true;flagHighGround[34][56]=true;flagHighGround[34][66]=true;flagHighGround[34][67]=true;flagHighGround[34][84]=true;flagHighGround[34][95]=true;flagHighGround[35][56]=true;flagHighGround[35][96]=true;flagHighGround[35][97]=true;flagHighGround[36][53]=true;flagHighGround[36][54]=true;flagHighGround[36][55]=true;flagHighGround[36][97]=true;flagHighGround[36][98]=true;flagHighGround[37][52]=true;flagHighGround[37][98]=true;flagHighGround[38][51]=true;flagHighGround[38][98]=true;flagHighGround[39][51]=true;flagHighGround[39][98]=true;flagHighGround[40][51]=true;flagHighGround[40][68]=true;flagHighGround[40][69]=true;flagHighGround[40][98]=true;flagHighGround[41][51]=true;flagHighGround[41][80]=true;flagHighGround[41][98]=true;flagHighGround[42][51]=true;flagHighGround[42][52]=true;flagHighGround[42][53]=true;flagHighGround[42][80]=true;flagHighGround[42][98]=true;flagHighGround[43][52]=true;flagHighGround[43][53]=true;flagHighGround[43][78]=true;flagHighGround[43][79]=true;flagHighGround[43][97]=true;flagHighGround[45][51]=true;flagHighGround[45][99]=true;flagHighGround[46][52]=true;flagHighGround[50][47]=true;flagHighGround[50][72]=true;flagHighGround[50][73]=true;flagHighGround[50][74]=true;flagHighGround[50][75]=true;flagHighGround[50][76]=true;flagHighGround[50][77]=true;flagHighGround[50][78]=true;flagHighGround[50][79]=true;flagHighGround[50][106]=true;flagHighGround[51][36]=true;flagHighGround[51][37]=true;flagHighGround[51][38]=true;flagHighGround[51][48]=true;flagHighGround[51][71]=true;flagHighGround[51][72]=true;flagHighGround[51][73]=true;flagHighGround[51][74]=true;flagHighGround[51][75]=true;flagHighGround[51][76]=true;flagHighGround[51][77]=true;flagHighGround[51][78]=true;flagHighGround[51][79]=true;flagHighGround[51][80]=true;flagHighGround[51][105]=true;flagHighGround[52][35]=true;flagHighGround[52][40]=true;flagHighGround[52][44]=true;flagHighGround[52][45]=true;flagHighGround[52][48]=true;flagHighGround[52][71]=true;flagHighGround[52][72]=true;flagHighGround[52][73]=true;flagHighGround[52][74]=true;flagHighGround[52][75]=true;flagHighGround[52][76]=true;flagHighGround[52][77]=true;flagHighGround[52][78]=true;flagHighGround[52][79]=true;flagHighGround[52][80]=true;flagHighGround[52][105]=true;flagHighGround[52][110]=true;flagHighGround[52][111]=true;flagHighGround[52][112]=true;flagHighGround[52][113]=true;flagHighGround[52][114]=true;flagHighGround[52][115]=true;flagHighGround[52][116]=true;flagHighGround[53][34]=true;flagHighGround[53][35]=true;flagHighGround[53][46]=true;flagHighGround[53][47]=true;flagHighGround[53][48]=true;flagHighGround[53][71]=true;flagHighGround[53][72]=true;flagHighGround[53][73]=true;flagHighGround[53][74]=true;flagHighGround[53][75]=true;flagHighGround[53][76]=true;flagHighGround[53][77]=true;flagHighGround[53][78]=true;flagHighGround[53][79]=true;flagHighGround[53][80]=true;flagHighGround[53][115]=true;flagHighGround[53][116]=true;flagHighGround[53][117]=true;flagHighGround[54][33]=true;flagHighGround[54][34]=true;flagHighGround[54][71]=true;flagHighGround[54][72]=true;flagHighGround[54][73]=true;flagHighGround[54][74]=true;flagHighGround[54][75]=true;flagHighGround[54][76]=true;flagHighGround[54][77]=true;flagHighGround[54][78]=true;flagHighGround[54][79]=true;flagHighGround[54][80]=true;flagHighGround[54][115]=true;flagHighGround[54][116]=true;flagHighGround[55][32]=true;flagHighGround[55][33]=true;flagHighGround[55][71]=true;flagHighGround[55][72]=true;flagHighGround[55][73]=true;flagHighGround[55][74]=true;flagHighGround[55][75]=true;flagHighGround[55][76]=true;flagHighGround[55][77]=true;flagHighGround[55][78]=true;flagHighGround[55][79]=true;flagHighGround[55][80]=true;flagHighGround[55][115]=true;flagHighGround[56][25]=true;flagHighGround[56][31]=true;flagHighGround[56][32]=true;flagHighGround[56][71]=true;flagHighGround[56][72]=true;flagHighGround[56][73]=true;flagHighGround[56][74]=true;flagHighGround[56][75]=true;flagHighGround[56][76]=true;flagHighGround[56][77]=true;flagHighGround[56][78]=true;flagHighGround[56][79]=true;flagHighGround[56][80]=true;flagHighGround[56][126]=true;flagHighGround[57][26]=true;flagHighGround[57][27]=true;flagHighGround[57][28]=true;flagHighGround[57][29]=true;flagHighGround[57][30]=true;flagHighGround[57][31]=true;flagHighGround[57][124]=true;flagHighGround[58][118]=true;flagHighGround[65][49]=true;flagHighGround[65][50]=true;flagHighGround[65][51]=true;flagHighGround[66][49]=true;flagHighGround[66][50]=true;flagHighGround[66][51]=true;flagHighGround[67][49]=true;flagHighGround[67][50]=true;flagHighGround[67][51]=true;flagHighGround[68][49]=true;flagHighGround[68][50]=true;flagHighGround[68][51]=true;flagHighGround[69][49]=true;flagHighGround[69][50]=true;flagHighGround[69][51]=true;flagHighGround[69][52]=true;flagHighGround[69][53]=true;flagHighGround[70][49]=true;flagHighGround[70][50]=true;flagHighGround[70][51]=true;flagHighGround[70][52]=true;flagHighGround[70][53]=true;flagHighGround[70][54]=true;flagHighGround[70][55]=true;flagHighGround[70][56]=true;flagHighGround[71][48]=true;flagHighGround[71][49]=true;flagHighGround[71][50]=true;flagHighGround[71][51]=true;flagHighGround[71][52]=true;flagHighGround[71][53]=true;flagHighGround[71][54]=true;flagHighGround[71][55]=true;flagHighGround[71][56]=true;flagHighGround[72][52]=true;flagHighGround[72][53]=true;flagHighGround[72][54]=true;flagHighGround[72][55]=true;flagHighGround[72][56]=true;flagHighGround[73][53]=true;flagHighGround[73][54]=true;flagHighGround[73][55]=true;flagHighGround[73][56]=true;flagHighGround[74][51]=true;flagHighGround[74][52]=true;flagHighGround[74][53]=true;flagHighGround[74][54]=true;flagHighGround[74][55]=true;flagHighGround[74][56]=true;flagHighGround[75][51]=true;flagHighGround[75][52]=true;flagHighGround[75][53]=true;flagHighGround[75][54]=true;flagHighGround[75][55]=true;flagHighGround[75][56]=true;flagHighGround[76][51]=true;flagHighGround[76][52]=true;flagHighGround[76][53]=true;flagHighGround[76][54]=true;flagHighGround[76][55]=true;flagHighGround[77][51]=true;flagHighGround[77][52]=true;flagHighGround[77][53]=true;flagHighGround[77][54]=true;flagHighGround[79][98]=true;flagHighGround[79][99]=true;flagHighGround[79][100]=true;flagHighGround[80][97]=true;flagHighGround[80][98]=true;flagHighGround[80][99]=true;flagHighGround[81][97]=true;flagHighGround[81][98]=true;flagHighGround[81][99]=true;flagHighGround[81][101]=true;flagHighGround[81][102]=true;flagHighGround[81][103]=true;flagHighGround[82][97]=true;flagHighGround[82][98]=true;flagHighGround[82][99]=true;flagHighGround[83][98]=true;flagHighGround[83][99]=true;flagHighGround[83][106]=true;flagHighGround[83][107]=true;flagHighGround[83][108]=true;flagHighGround[83][109]=true;flagHighGround[84][98]=true;flagHighGround[84][99]=true;flagHighGround[84][100]=true;flagHighGround[84][101]=true;flagHighGround[84][105]=true;flagHighGround[84][106]=true;flagHighGround[84][107]=true;flagHighGround[84][108]=true;flagHighGround[84][109]=true;flagHighGround[85][98]=true;flagHighGround[85][99]=true;flagHighGround[85][100]=true;flagHighGround[85][101]=true;flagHighGround[85][105]=true;flagHighGround[85][106]=true;flagHighGround[85][107]=true;flagHighGround[85][108]=true;flagHighGround[85][109]=true;flagHighGround[86][97]=true;flagHighGround[86][98]=true;flagHighGround[86][99]=true;flagHighGround[86][100]=true;flagHighGround[86][101]=true;flagHighGround[86][105]=true;flagHighGround[86][106]=true;flagHighGround[86][107]=true;flagHighGround[86][108]=true;flagHighGround[86][109]=true;flagHighGround[87][96]=true;flagHighGround[87][97]=true;flagHighGround[87][98]=true;flagHighGround[87][99]=true;flagHighGround[87][100]=true;flagHighGround[87][101]=true;flagHighGround[87][104]=true;flagHighGround[87][105]=true;flagHighGround[87][106]=true;flagHighGround[87][107]=true;flagHighGround[87][108]=true;flagHighGround[87][109]=true;flagHighGround[88][96]=true;flagHighGround[88][97]=true;flagHighGround[88][98]=true;flagHighGround[88][99]=true;flagHighGround[88][100]=true;flagHighGround[88][103]=true;flagHighGround[88][104]=true;flagHighGround[88][105]=true;flagHighGround[88][106]=true;flagHighGround[89][96]=true;flagHighGround[89][97]=true;flagHighGround[89][98]=true;flagHighGround[89][104]=true;flagHighGround[89][105]=true;flagHighGround[89][106]=true;flagHighGround[90][104]=true;flagHighGround[90][105]=true;flagHighGround[90][106]=true;flagHighGround[91][103]=true;flagHighGround[91][104]=true;flagHighGround[91][105]=true;flagHighGround[91][106]=true;flagHighGround[92][103]=true;flagHighGround[92][104]=true;flagHighGround[92][105]=true;flagHighGround[92][106]=true;flagHighGround[94][26]=true;flagHighGround[94][30]=true;flagHighGround[94][31]=true;flagHighGround[94][120]=true;flagHighGround[94][124]=true;flagHighGround[94][125]=true;flagHighGround[95][31]=true;flagHighGround[95][71]=true;flagHighGround[95][72]=true;flagHighGround[95][73]=true;flagHighGround[95][74]=true;flagHighGround[95][75]=true;flagHighGround[95][76]=true;flagHighGround[95][77]=true;flagHighGround[95][78]=true;flagHighGround[95][79]=true;flagHighGround[95][80]=true;flagHighGround[95][120]=true;flagHighGround[96][32]=true;flagHighGround[96][71]=true;flagHighGround[96][72]=true;flagHighGround[96][73]=true;flagHighGround[96][74]=true;flagHighGround[96][75]=true;flagHighGround[96][76]=true;flagHighGround[96][77]=true;flagHighGround[96][78]=true;flagHighGround[96][79]=true;flagHighGround[96][80]=true;flagHighGround[96][119]=true;flagHighGround[97][33]=true;flagHighGround[97][71]=true;flagHighGround[97][72]=true;flagHighGround[97][73]=true;flagHighGround[97][74]=true;flagHighGround[97][75]=true;flagHighGround[97][76]=true;flagHighGround[97][77]=true;flagHighGround[97][78]=true;flagHighGround[97][79]=true;flagHighGround[97][80]=true;flagHighGround[97][104]=true;flagHighGround[97][119]=true;flagHighGround[98][34]=true;flagHighGround[98][71]=true;flagHighGround[98][72]=true;flagHighGround[98][73]=true;flagHighGround[98][74]=true;flagHighGround[98][75]=true;flagHighGround[98][76]=true;flagHighGround[98][77]=true;flagHighGround[98][78]=true;flagHighGround[98][79]=true;flagHighGround[98][80]=true;flagHighGround[98][105]=true;flagHighGround[98][118]=true;flagHighGround[99][34]=true;flagHighGround[99][71]=true;flagHighGround[99][72]=true;flagHighGround[99][73]=true;flagHighGround[99][74]=true;flagHighGround[99][75]=true;flagHighGround[99][76]=true;flagHighGround[99][77]=true;flagHighGround[99][78]=true;flagHighGround[99][79]=true;flagHighGround[99][80]=true;flagHighGround[99][102]=true;flagHighGround[99][117]=true;flagHighGround[99][118]=true;flagHighGround[100][35]=true;flagHighGround[100][36]=true;flagHighGround[100][37]=true;flagHighGround[100][38]=true;flagHighGround[100][39]=true;flagHighGround[100][71]=true;flagHighGround[100][72]=true;flagHighGround[100][73]=true;flagHighGround[100][74]=true;flagHighGround[100][75]=true;flagHighGround[100][76]=true;flagHighGround[100][77]=true;flagHighGround[100][78]=true;flagHighGround[100][79]=true;flagHighGround[100][80]=true;flagHighGround[100][103]=true;flagHighGround[100][113]=true;flagHighGround[100][114]=true;flagHighGround[100][115]=true;flagHighGround[100][116]=true;flagHighGround[100][117]=true;flagHighGround[100][146]=true;flagHighGround[100][147]=true;flagHighGround[100][148]=true;flagHighGround[100][149]=true;flagHighGround[100][150]=true;flagHighGround[101][45]=true;flagHighGround[101][46]=true;flagHighGround[101][47]=true;flagHighGround[101][72]=true;flagHighGround[101][73]=true;flagHighGround[101][74]=true;flagHighGround[101][75]=true;flagHighGround[101][76]=true;flagHighGround[101][77]=true;flagHighGround[101][78]=true;flagHighGround[101][79]=true;flagHighGround[101][146]=true;flagHighGround[101][147]=true;flagHighGround[101][148]=true;flagHighGround[101][149]=true;flagHighGround[101][150]=true;flagHighGround[102][147]=true;flagHighGround[102][148]=true;flagHighGround[102][149]=true;flagHighGround[102][150]=true;flagHighGround[103][95]=true;flagHighGround[103][96]=true;flagHighGround[103][97]=true;flagHighGround[103][147]=true;flagHighGround[103][148]=true;flagHighGround[103][149]=true;flagHighGround[104][55]=true;flagHighGround[104][96]=true;flagHighGround[104][97]=true;flagHighGround[105][51]=true;flagHighGround[105][54]=true;flagHighGround[106][97]=true;flagHighGround[106][100]=true;flagHighGround[106][149]=true;flagHighGround[107][53]=true;flagHighGround[107][70]=true;flagHighGround[107][71]=true;flagHighGround[107][98]=true;flagHighGround[107][143]=true;flagHighGround[107][149]=true;flagHighGround[108][52]=true;flagHighGround[108][53]=true;flagHighGround[108][80]=true;flagHighGround[108][81]=true;flagHighGround[108][98]=true;flagHighGround[108][99]=true;flagHighGround[108][143]=true;flagHighGround[109][51]=true;flagHighGround[109][52]=true;flagHighGround[109][99]=true;flagHighGround[109][142]=true;flagHighGround[109][143]=true;flagHighGround[110][100]=true;flagHighGround[110][142]=true;flagHighGround[111][143]=true;flagHighGround[112][143]=true;flagHighGround[112][144]=true;flagHighGround[112][145]=true;flagHighGround[113][100]=true;flagHighGround[113][143]=true;flagHighGround[113][144]=true;flagHighGround[113][145]=true;flagHighGround[114][99]=true;flagHighGround[114][143]=true;flagHighGround[114][144]=true;flagHighGround[114][145]=true;flagHighGround[115][69]=true;flagHighGround[115][97]=true;flagHighGround[115][98]=true;flagHighGround[115][143]=true;flagHighGround[116][53]=true;flagHighGround[116][54]=true;flagHighGround[116][55]=true;flagHighGround[116][69]=true;flagHighGround[116][83]=true;flagHighGround[116][96]=true;flagHighGround[116][97]=true;flagHighGround[117][54]=true;flagHighGround[117][55]=true;flagHighGround[117][67]=true;flagHighGround[117][68]=true;flagHighGround[117][83]=true;flagHighGround[117][84]=true;flagHighGround[117][95]=true;flagHighGround[118][53]=true;flagHighGround[118][55]=true;flagHighGround[118][56]=true;flagHighGround[118][66]=true;flagHighGround[118][84]=true;flagHighGround[118][85]=true;flagHighGround[118][86]=true;flagHighGround[118][94]=true;flagHighGround[118][142]=true;flagHighGround[119][61]=true;flagHighGround[119][65]=true;flagHighGround[119][66]=true;flagHighGround[119][87]=true;flagHighGround[119][91]=true;flagHighGround[119][138]=true;flagHighGround[119][139]=true;flagHighGround[119][140]=true;flagHighGround[119][141]=true;flagHighGround[119][142]=true;flagHighGround[119][143]=true;flagHighGround[119][144]=true;flagHighGround[120][87]=true;flagHighGround[120][138]=true;flagHighGround[120][139]=true;flagHighGround[120][140]=true;flagHighGround[120][141]=true;flagHighGround[120][142]=true;flagHighGround[120][143]=true;flagHighGround[121][139]=true;flagHighGround[121][140]=true;flagHighGround[122][150]=true;
}

void initSimpleStepMap()
{
	simpleStepMap[1][7]=6;simpleStepMap[2][5]=5.472140;simpleStepMap[2][6]=5.236070;simpleStepMap[2][7]=5;simpleStepMap[2][8]=5.236070;simpleStepMap[2][9]=5.472140;simpleStepMap[3][4]=5.472140;simpleStepMap[3][5]=4.472140;simpleStepMap[3][6]=4.236070;simpleStepMap[3][7]=4;simpleStepMap[3][8]=4.236070;simpleStepMap[3][9]=4.472140;simpleStepMap[3][10]=5.472140;simpleStepMap[4][3]=5.472140;simpleStepMap[4][4]=4.472140;simpleStepMap[4][5]=4.236070;simpleStepMap[4][6]=3.236070;simpleStepMap[4][7]=3;simpleStepMap[4][8]=3.236070;simpleStepMap[4][9]=4.236070;simpleStepMap[4][10]=4.472140;simpleStepMap[4][11]=5.472140;simpleStepMap[5][2]=5.472140;simpleStepMap[5][3]=4.472140;simpleStepMap[5][4]=4.236070;simpleStepMap[5][5]=3.236070;simpleStepMap[5][6]=2.236070;simpleStepMap[5][7]=2;simpleStepMap[5][8]=2.236070;simpleStepMap[5][9]=3.236070;simpleStepMap[5][10]=4.236070;simpleStepMap[5][11]=4.472140;simpleStepMap[5][12]=5.472140;simpleStepMap[6][2]=5.236070;simpleStepMap[6][3]=4.236070;simpleStepMap[6][4]=3.236070;simpleStepMap[6][5]=2.236070;simpleStepMap[6][6]=2;simpleStepMap[6][7]=1;simpleStepMap[6][8]=2;simpleStepMap[6][9]=2.236070;simpleStepMap[6][10]=3.236070;simpleStepMap[6][11]=4.236070;simpleStepMap[6][12]=5.236070;simpleStepMap[7][1]=6;simpleStepMap[7][2]=5;simpleStepMap[7][3]=4;simpleStepMap[7][4]=3;simpleStepMap[7][5]=2;simpleStepMap[7][6]=1;simpleStepMap[7][7]=0;simpleStepMap[7][8]=1;simpleStepMap[7][9]=2;simpleStepMap[7][10]=3;simpleStepMap[7][11]=4;simpleStepMap[7][12]=5;simpleStepMap[7][13]=6;simpleStepMap[8][2]=5.236070;simpleStepMap[8][3]=4.236070;simpleStepMap[8][4]=3.236070;simpleStepMap[8][5]=2.236070;simpleStepMap[8][6]=2;simpleStepMap[8][7]=1;simpleStepMap[8][8]=2;simpleStepMap[8][9]=2.236070;simpleStepMap[8][10]=3.236070;simpleStepMap[8][11]=4.236070;simpleStepMap[8][12]=5.236070;simpleStepMap[9][2]=5.472140;simpleStepMap[9][3]=4.472140;simpleStepMap[9][4]=4.236070;simpleStepMap[9][5]=3.236070;simpleStepMap[9][6]=2.236070;simpleStepMap[9][7]=2;simpleStepMap[9][8]=2.236070;simpleStepMap[9][9]=3.236070;simpleStepMap[9][10]=4.236070;simpleStepMap[9][11]=4.472140;simpleStepMap[9][12]=5.472140;simpleStepMap[10][3]=5.472140;simpleStepMap[10][4]=4.472140;simpleStepMap[10][5]=4.236070;simpleStepMap[10][6]=3.236070;simpleStepMap[10][7]=3;simpleStepMap[10][8]=3.236070;simpleStepMap[10][9]=4.236070;simpleStepMap[10][10]=4.472140;simpleStepMap[10][11]=5.472140;simpleStepMap[11][4]=5.472140;simpleStepMap[11][5]=4.472140;simpleStepMap[11][6]=4.236070;simpleStepMap[11][7]=4;simpleStepMap[11][8]=4.236070;simpleStepMap[11][9]=4.472140;simpleStepMap[11][10]=5.472140;simpleStepMap[12][5]=5.472140;simpleStepMap[12][6]=5.236070;simpleStepMap[12][7]=5;simpleStepMap[12][8]=5.236070;simpleStepMap[12][9]=5.472140;simpleStepMap[13][7]=6;
}

void roundInit(vector<PUnit*> myUnits, vector<PUnit*> enemyUnits, const PPlayerInfo & info, const PMap & map, Console & console)
{
	memset(actionMark,false,sizeof(actionMark));
	//myUnits
	for (int i=0;i<myUnits.size();++i) if(myUnits[i]->isHero()){
		bool newHeroFlag=1;
		PUnit* & thisUnit = myUnits[i];
		for (int j=0;j<nMyHeros;j++) {
			if (thisUnit->id == idMyHeros[j]) {
				newHeroFlag=0;
				pMyHeros[j]=thisUnit;
				recordMyHeros[j]=*thisUnit;
				break;
			}
		}
		if (newHeroFlag) {
			idMyHeros[nMyHeros]=thisUnit->id;
			pMyHeros[nMyHeros]=thisUnit;
			recordMyHeros[nMyHeros]=*thisUnit;
			nMyHeros++;
		}
	}
	//enemyUnitsRefresh	//btw, refreshAnger 
	for (int i=0;i<enemyUnits.size();i++) if(enemyUnits[i]->isHero()){
		bool newHeroFlag=1;
		PUnit* & thisUnit = enemyUnits[i];	
		for (int j=0;j<nEnemyHeros;j++) {
			if (thisUnit->id == idEnemyHeros[j]) {
				newHeroFlag=0;
				pEnemyHeros[j]=thisUnit;
				recordEnemyHeros[j]=*thisUnit;
				//rule out the dead
				ofstream fout;
				fout.open("executeFightForMine.txt",ios::app);
				fout<<"Enemy "<<j<<"'s buffs: "<<endl;
				for (int iBuff=0;iBuff<recordEnemyHeros[j].buffs.size();iBuff++) {
					fout<<recordEnemyHeros[j].buffs[iBuff].name<<endl;
					if (!strcmp(recordEnemyHeros[j].buffs[iBuff].name,"Reviving")) {
						recordEnemyHeros[j].pos=posBorn[1-info.player];	
						fout<<"dead people and his pos"<<j<<" ; "<<recordEnemyHeros[j].pos<<endl;
					}
				}
				fout<<"Enemy "<<j<<"'s hp: "<<recordEnemyHeros[j].hp<<endl;
				fout.close();
				//refresh anger
				int roundBeAttacked;
				for (int iMyHero=0;iMyHero<nMyHeros;iMyHero++){
					string paramString;
					char buffer[10];
					sprintf(buffer,"%d",idEnemyHeros[j]);
					paramString=buffer;
					console.selectUnit(pMyHeros[iMyHero]);
					roundBeAttacked=console.unitArg("lastHit",paramString);
					/*//there is sdk bug here.
					if (!strcmp(pMyHeros[iMyHero]->name,"Master")) {
						cout<<buffer<<endl;
						cout<<"currentHP:"<<console.unitArg("Hp","Current")<<endl;
						cout<<"roundBeAttacked by "<<j<<" :"<<roundBeAttacked<<endl;
					}
					//*/
					if (roundBeAttacked==gameRound) { //attack detected
						if ((objectEnemyAnger[j]==iMyHero)&&(levelEnemyAnger[j]==1)){
							levelEnemyAnger[j]=2;
							roundEnemyAnger[j]=roundBeAttacked;
						}
						if ((objectEnemyAnger[j]!=iMyHero)) {
							objectEnemyAnger[j]=iMyHero;
							levelEnemyAnger[j]=1;
							roundEnemyAnger[j]=roundBeAttacked;
						}
					} 
				}
				//end refresh anger
				break;
			}
		}
		if (newHeroFlag) {
			//cout<<"new Hero"<<endl;
			//cout<<thisUnit->name<<endl;
			//cout<<"index: "<<nEnemyHeros<<endl;
			//cout<<"id: "<<thisUnit->id<<endl;
			//system("pause");
			idEnemyHeros[nEnemyHeros]=thisUnit->id;
			pEnemyHeros[nEnemyHeros]=thisUnit;
			recordEnemyHeros[nEnemyHeros]=*thisUnit;
			nEnemyHeros++;
		}
	}
	ofstream fout;
	fout.open("executeFightForMine.txt",ios::app);
	for (int i=0;i<nEnemyHeros;i++) {
		fout<<"Enemies Pos:"<<endl;
		fout<<recordEnemyHeros[i].pos<<endl;
	}
	fout.close();
	//clear over time anger
	for (int i=0;i<nEnemyHeros;i++){
		if (roundEnemyAnger[i]<gameRound-5) {
			objectEnemyAnger[i]=-1;
			levelEnemyAnger[i]=0;
			roundEnemyAnger[i]=gameRound;
		}
	}
	// init multiRoundCmds and refresh actionMark[MAXHEROS];
	for (int i=0;i<multiRoundCmds.size();i++) {
		BasicCmd & theCmd = multiRoundCmds[i].basicCmds[multiRoundCmds[i].step];
		PUnit* & pSubHero = pMyHeros[multiRoundCmds[i].index];
		if (theCmd==Maneuver) {
			executeManeuver(pSubHero,multiRoundCmds[i].paramPos[multiRoundCmds[i].step],map,console);
		}
		if (theCmd==AttackUnit) {
			executeAttackUnit(pSubHero,pEnemyHeros[multiRoundCmds[i].objIndexes[multiRoundCmds[i].step]],map,console);
		}
		if (theCmd==HammerAttack) {
			executeHammerAttack(pSubHero,pEnemyHeros[multiRoundCmds[i].objIndexes[multiRoundCmds[i].step]],map,console);
		}
		if (theCmd==Sacrifice) {
			executeSacrifice(pSubHero,map,console);
		}
		if (theCmd==Blink) {
			// executeBlink
		}
		multiRoundCmds[i].step++;
		actionMark[multiRoundCmds[i].index]=true;
	}
	int i=0;
	while(i<multiRoundCmds.size()){
		if (multiRoundCmds[i].step>=multiRoundCmds[i].basicCmds.size()) {
			multiRoundCmds.erase(multiRoundCmds.begin()+i);
		}
		else {
			i++;
		}
	}//clear those end cmds
	//end init multiRoundCmds
}

void gameInit(Console & console, const PPlayerInfo & info) 
{
	ofstream fout;
	fout.open("Watches.txt");
	fout.close();
	fout.open("executeFightForMine.txt");
	fout.close();
	posBorn[0]=Pos(15,5);
	posBorn[1]=Pos(135,145);
	nMyHeros=0;
	nEnemyHeros=0;
	posCentralMine=Pos(75,75);
	counterAroundCenterOverwhelm=0;
	memset(objectEnemyAnger,-1,sizeof(objectEnemyAnger));
	memset(levelEnemyAnger,0,sizeof(levelEnemyAnger));
	memset(roundEnemyAnger,0,sizeof(roundEnemyAnger));
	multiRoundCmds.clear();
	
	memset(simpleStepMap,999,sizeof(simpleStepMap));
	initSimpleStepMap();
	
	//remember that the edge point of birth is (22,14) for player0 and (128,136) for player1
	if (info.player==0){
	console.chooseHero(HERO_NAME[1],Pos(21,14));
	console.chooseHero(HERO_NAME[3],Pos(22,14));
	console.chooseHero(HERO_NAME[0],Pos(20,14));
	console.chooseHero(HERO_NAME[2],Pos(19,14));
	}
	else {
		console.chooseHero(HERO_NAME[3],Pos(128,136));
		console.chooseHero(HERO_NAME[1],Pos(129,136));
		console.chooseHero(HERO_NAME[0],Pos(130,136));
		console.chooseHero(HERO_NAME[2],Pos(131,136));
	}
}

void fprintOutWatch(GroupingType & groupingType, TGroup myGroups[MAXHEROS], int & nMyGroups, TGroup enemyGroups[MAXHEROS], int & nEnemyGroups)
{
	ofstream fout;
	fout.open("Watches.txt",ios::app);
	fout<<"Round "<<gameRound<<endl;
	fout<<"GroupingType : "<<groupingType<<endl;
	fout<<"nMyGroups : "<<nMyGroups<<endl;
	if (nMyGroups>MAXHEROS) {
		fout<<"Too Large nMyGroups!"<<endl;
	} else
	for (int iGroup=0;iGroup<nMyGroups;iGroup++){
		fout<<"Group "<<iGroup<<"'s Cmd: "<<myGroups[iGroup].cmdType<<endl;
	}
	fout.close();
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	//random seed
	 srand((int)time(0));
	//timer
	int start_time_=clock();
	gameRound++;
	//cout<<"1"<<endl;
	//Console Init
	Console console(map,info,cmd);
	vector<PUnit*> myUnits = console.friendlyUnits();
	vector<PUnit*> enemyUnits = console.enemyUnits();
	//end Console Init
	//GameInit
	if (gameRound == 0) {
		gameInit(console,info);
		makeHighGroundMap();
	}
	//cout<<"1#"<<endl;
	//end GameInit
	//Round init
	TGroup myGroups[MAXHEROS],enemyGroups[MAXHEROS];
	int nMyGroups,nEnemyGroups;
	roundInit(myUnits,enemyUnits,info,map,console);
	//end Round init
	//testPath.push_back(Pos(14,27));
	
	//cout<<"1@"<<endl;
	
	if (nMyHeros!=0) {
		enemyGrouping(enemyGroups,nEnemyGroups,info,map);
		GroupingType groupingType;
		tacticMaker(groupingType,info,map);
		myGrouping(groupingType,myGroups,nMyGroups,enemyGroups,nEnemyGroups,info,map);
		cout<<"finish Grouping"<<endl;
		fprintOutWatch(groupingType,myGroups,nMyGroups,enemyGroups,nEnemyHeros);
		cout<<"finish fprintOutWatch"<<endl;
		executeGroupCmd(myGroups,nMyGroups,enemyGroups,nEnemyGroups,info,map,console);	
	}
	/*
	if (gameRound==0)
	{
	ofstream fout;
	fout.open("consoleRes.txt");
	for (int i=0;i<MAP_SIZE;i++){
		for (int j=0;j<MAP_SIZE;j++){
			fout<<map.getHeight(i,j)<<" ";
		}
		fout<<endl;
	}
	fout.close();
	}
	*/
	
	int end_time_=clock();
	double timeUsed;
	timeUsed=(end_time_-start_time_)*1000/CLOCKS_PER_SEC;
//cout<<timeUsed<<" ms"<<endl;
}
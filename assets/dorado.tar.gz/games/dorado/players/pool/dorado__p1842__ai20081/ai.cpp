#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include<algorithm>
#include <string>
#include<queue>
#include<map>
using namespace std;

static int heroRank = 1234;
static int newHeroFirst = 1;
static int attackArg = 250, supportRange = 800, monsterAvoid = 0, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100;
static int miningArg = 150, sameMineArg = 10, centerMineArg = 80;
static int goBackHomeHp = 150, goBackHomeArg = 10000;
static int hammerDizzy = 50;
static int strategyDisabled = -1 << 30;
static int protectBaseArg = 1000000, stayBaseArg = 50000, killBaseArg = 100000;

static const char* HERO_NAME[] = { "Hammerguard", "Master", "Berserker", "Scouter" };
static const char* Tactics[] = { "GATHER","PREPARE","WAIT","STEALHOME","ATTACKHOME","FORWILD","WAITWILD","GOWILD" ,"URGENT","STRANDED" ,"NORMAL" };
static string current_mode[101];
static Pos heading[101];

static int base_history_hp[1001];
static int hero_history_hp[101][1001];
static Pos hero_history_pos[101][1001];
static int current_round;
static int each_hero_sum[5];
static Pos myBasePos, enemyBasePos;

static int lastattack;

bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack") || !strcmp(mySkill->name, "Blink") || !strcmp(mySkill->name, "Sacrifice") || !strcmp(mySkill->name, "SetObserver");
}
bool isStranded(int t_id)
{
	/*if (current_round < 3) return false;
	if (hero_history_pos[t_id][current_round] == hero_history_pos[t_id][current_round - 1] && hero_history_pos[t_id][current_round] == hero_history_pos[t_id][current_round - 2])
		return true;*/
	return false;
}

struct updateStr
{
	bool mode;//0 levelup  1 buynew
	char* ifBuy;
	PUnit* ifLevelUp;
	int tid;
	double v;
};
bool cmp(updateStr m, updateStr n)
{
	return m.v < n.v;
}

void findPath(const PMap &map, Pos start, Pos dest, const vector<Pos> &blocks, vector<Pos> &path)
{
	struct Node {
		int x, y;
		int level;
		int priority;

		Node() :x(0), y(0), level(0), priority(0) {}
		Node(int xp, int yp, int d, int p) :x(xp), y(yp), level(d), priority(p) {}
		void updatePriority(int xDest, int yDest)
		{
			priority = level + estimate(xDest, yDest) * 9;//version 25 changed
		}
		void nextLevel()
		{
			level += 10;
		}
		int estimate(const int & xDest, const int & yDest) const {
			int xd = xDest - x, yd = yDest - y;
			return static_cast<int>(sqrt(xd * xd + yd * yd));
		}
		bool operator < (const Node &b) const
		{
			return priority > b.priority;
		}
	};
	const int dx[] = { 1, 0, -1, 0 };
	const int dy[] = { 0, 1, 0, -1 };
	static int open_nodes_map[MAP_SIZE][MAP_SIZE];
	static unsigned char closed_nodes_map[MAP_SIZE][MAP_SIZE];
	static unsigned char dir_map[MAP_SIZE][MAP_SIZE];
	priority_queue<Node> pq[2];
	int pqi;
	int i, j, x, y, xdx, ydy;

	memset(closed_nodes_map, 0, sizeof(closed_nodes_map));
	memset(open_nodes_map, 0, sizeof(open_nodes_map));
	if (start == dest)
		return;
	for (size_t i = 0; i < blocks.size(); ++i)
		if (blocks[i].x >= 0 && blocks[i].x < MAP_SIZE && blocks[i].y >= 0 && blocks[i].y < MAP_SIZE)
			closed_nodes_map[blocks[i].x][blocks[i].y] = 1;
	if (closed_nodes_map[dest.x][dest.y] == 1) {
		xdx = start.x < dest.x ? -1 : 1;
		ydy = start.y < dest.y ? -1 : 1;
		x = dest.x; y = dest.y;
		while (closed_nodes_map[x][y] == 1) {
			if (checkOnLine(start, dest, Pos(x + xdx, y)))
				x += xdx;
			else
				y += ydy;
		}
		dest = Pos(x, y);
	}
	Node n0(start.x, start.y, 0, 0);
	n0.updatePriority(dest.x, dest.y);
	pqi = 0;
	pq[pqi].push(n0);
	open_nodes_map[start.x][start.y] = n0.priority;
	while (!pq[pqi].empty()) {
		n0 = pq[pqi].top();
		pq[pqi].pop();
		x = n0.x;
		y = n0.y;
		open_nodes_map[x][y] = 0;
		closed_nodes_map[x][y] = 1;
		if (x == dest.x && y == dest.y) {
			while (!(x == start.x && y == start.y)) {
				j = dir_map[x][y];
				path.push_back(Pos(x, y));
				x += dx[j];
				y += dy[j];
			}
			path.push_back(start);
			reverse(path.begin(), path.end());
			return;
		}
		for (i = 0; i < 4; i++) {
			xdx = x + dx[i]; ydy = y + dy[i];
			if (!(xdx < 0 || xdx >= MAP_SIZE || ydy < 0 || ydy >= MAP_SIZE
				|| map.getHeight(xdx, ydy) - map.getHeight(x, y) > 1 || map.getHeight(xdx, ydy) - map.getHeight(x, y) < -1
				|| closed_nodes_map[xdx][ydy] == 1)) {
				Node m0(n0);
				m0.x = xdx;
				m0.y = ydy;
				m0.nextLevel();
				m0.updatePriority(dest.x, dest.y);
				if (open_nodes_map[xdx][ydy] == 0) {
					open_nodes_map[xdx][ydy] = m0.priority;
					pq[pqi].push(m0);
					dir_map[xdx][ydy] = (i + 2) % 4;
				}
				else if (open_nodes_map[xdx][ydy] > m0.priority) {
					open_nodes_map[xdx][ydy] = m0.priority;
					dir_map[xdx][ydy] = (i + 2) % 4;
					while (!(pq[pqi].top().x == xdx && pq[pqi].top().y == ydy)) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pq[pqi].pop();
					if (pq[pqi].size() > pq[1 - pqi].size())
						pqi = 1 - pqi;
					while (!pq[pqi].empty()) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pqi = 1 - pqi;
					pq[pqi].push(m0);
				}
			}
		}
	}
}

class AIController //控制ai的主类
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
	{
		//必要的初始化
		console = new Console(map, info, cmd);
		//console->changeShortestPathFunc(findPath);
		this->map = &(map); this->info = &(info); this->cmd = &(cmd);
		myHeros.clear(); enemyHeros.clear(); wildHeros.clear();
		std::vector<PUnit*> myUnits = console->friendlyUnits();
		std::vector<PUnit*> enemyUnits = console->enemyUnits();
		myBase = NULL; enemyBase = NULL;
		for (int i = 0; i < myUnits.size(); ++i)
		{
			if (!strcmp(myUnits[i]->name, "Hammerguard") || !strcmp(myUnits[i]->name, "Master")
				|| !strcmp(myUnits[i]->name, "Berserker") || !strcmp(myUnits[i]->name, "Scouter"))
				myHeros.push_back(myUnits[i]);
			else if (!strcmp(myUnits[i]->name, "MilitaryBase"))
				myBase = myUnits[i];
		}
		for (int i = 0; i < enemyUnits.size(); ++i)
		{
			if (!strcmp(enemyUnits[i]->name, "Hammerguard") || !strcmp(enemyUnits[i]->name, "Master")
				|| !strcmp(enemyUnits[i]->name, "Berserker") || !strcmp(enemyUnits[i]->name, "Scouter"))
				enemyHeros.push_back(enemyUnits[i]);
			else if (!strcmp(enemyUnits[i]->name, "MilitaryBase"))
				enemyBase = enemyUnits[i], enemyHeros.push_back(enemyUnits[i]);
			else if (!strcmp(enemyUnits[i]->name, "Dragon") || !strcmp(enemyUnits[i]->name, "Roshan"))
				wildHeros.push_back(enemyUnits[i]);
		}
		//记忆化局面信息
		base_history_hp[info.round] = myBase->hp;
		for (int i = 0; i < myHeros.size(); i++)
		{
			hero_history_hp[myHeros[i]->id][info.round] = myHeros[i]->hp;
			hero_history_pos[myHeros[i]->id][info.round] = myHeros[i]->pos;
		}
		myBasePos = console->getMilitaryBase()->pos; enemyBasePos = Pos(150 - myBasePos.x, 150 - myBasePos.y);
		//评判当前战术,状态转移
		if (current_round == 1)
		{
			for (int i = 0; i < myHeros.size(); i++)current_mode[myHeros[i]->id] = "NORMAL";
			return;
		}
		else
		{
			for (int i = 0; i < myHeros.size(); i++)
			{
				if (myHeros[i]->findBuff("Reviving") != NULL || current_mode[myHeros[i]->id] == "")
				{
					current_mode[myHeros[i]->id] = "NORMAL";
					//cout << "reset a status" << endl;
					continue;
				}

				if (isStranded(myHeros[i]->id))
				{
					current_mode[myHeros[i]->id] = "STRANDED";
					continue;
				}
				else if (current_mode[myHeros[i]->id] == "STRANDED")
				{
					current_mode[myHeros[i]->id] = "NORMAL";
				}

				if (console->getMilitaryBase()->hp < 800 || base_history_hp[current_round] < base_history_hp[current_round - 1] - 50)
				{
					current_mode[myHeros[i]->id] = "URGENT";
					continue;
				}
				else if (current_mode[myHeros[i]->id] == "URGENT")
				{
					current_mode[myHeros[i]->id] = "NORMAL";
				}

				if (current_mode[myHeros[i]->id] == "STEALHOME" || current_mode[myHeros[i]->id] == "GOWILD")
				{
					if (dis2(myHeros[i]->pos, enemyBasePos) < 100)
						current_mode[myHeros[i]->id] = "ATTACKHOME";
					for (int j = 0; j < myHeros.size(); j++)
						if (dis2(myHeros[i]->pos, myHeros[j]->pos) < 50)
						{
							current_mode[myHeros[j]->id] = current_mode[myHeros[i]->id];
							heading[myHeros[j]->id] = heading[myHeros[i]->id];
						}
				}
				else if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "WAIT")
				{
					if (dis2(heading[myHeros[i]->id], myHeros[i]->pos) >= 25 && current_mode[myHeros[i]->id] == "WAIT")
						current_mode[myHeros[i]->id] == "PREPARE";
					if (dis2(heading[myHeros[i]->id], myHeros[i]->pos) < 25)
					{
						UnitFilter filter; filter.setAreaFilter(new Circle(myHeros[i]->pos, 100), "a");
						vector<PUnit*> temp =	console->friendlyUnits(filter);
						if (temp.size() > 4)
						{
							for (int j = 0; j < myHeros.size(); j++)
							{
								if (dis2(myHeros[i]->pos, myHeros[j]->pos) < 100)current_mode[myHeros[j]->id] = "STEALHOME";
							}
						}
						else current_mode[myHeros[i]->id] = "WAIT";
					}
				}
				else if (current_mode[myHeros[i]->id] == "GATHER")
				{
					int cnt1, cnt2 = 0;
					for (int j = 0; j < myHeros.size(); j++)
						if ((i != j) && dis2(myHeros[i]->pos, myHeros[j]->pos) < 200)cnt1++;
					for (int j = 0; j < enemyHeros.size(); j++)
						if (enemyHeros[j]->isBase() == 0 && dis2(myHeros[i]->pos, enemyHeros[j]->pos) < 200)cnt2++;
					if (cnt1 >= cnt2 - 1)
					{
						current_mode[myHeros[i]->id] = "NORMAL";
					}
				}
				else if (current_mode[myHeros[i]->id] == "FORWILD" || current_mode[myHeros[i]->id] == "WAITWILD")
				{
					if (dis2(heading[myHeros[i]->id], myHeros[i]->pos) >= 25 && current_mode[myHeros[i]->id] == "WAITWILD")
						current_mode[myHeros[i]->id] = "FORWILD";
					if (dis2(heading[myHeros[i]->id], myHeros[i]->pos) < 25)
					{
						UnitFilter filter; filter.setAreaFilter(new Circle(myHeros[i]->pos, 100), "a");
						vector<PUnit*> temp = console->friendlyUnits(filter);
						if (temp.size() > 2)
						{
							int mindis = 2147483647, pos = -1;
							for (int j = 1; j < MINE_NUM; j++)
							{
								if (dis2(heading[myHeros[i]->id], MINE_POS[j]) < mindis)
								{
									mindis = dis2(heading[myHeros[i]->id], MINE_POS[j]);
									pos = j;
								}
							}
							for (int j = 0; j < myHeros.size(); j++)
							{
								if (dis2(myHeros[i]->pos, myHeros[j]->pos) < 100)
								{
									current_mode[myHeros[j]->id] = "GOWILD";
									heading[myHeros[j]->id] = MINE_POS[pos];
								}
							}
						}
						else current_mode[myHeros[i]->id] = "WAITWILD";
					}
				}
			}
			int countt = 0;//偷家
			Pos tar(0, 0);
			for (int j = 0; j < myHeros.size(); j++)
			{
				if ((current_mode[myHeros[j]->id] == "NORMAL"|| current_mode[myHeros[j]->id] == "GOWILD") && myHeros[j]->hp > 20)
				{
					countt++;
					tar.x = (tar.x *(countt - 1) + myHeros[j]->pos.x) / countt;
					tar.y = (tar.y *(countt - 1) + myHeros[j]->pos.y) / countt;
				}
			}
			if (myHeros.size() > 6 && countt > 4 && current_round - lastattack > 150)
			{
				current_round = lastattack;
				for (int j = 0; j < myHeros.size(); j++)
				{
					if ((current_mode[myHeros[j]->id] == "NORMAL" || current_mode[myHeros[j]->id] == "GOWILD") && myHeros[j]->hp > 20)
					{
						current_mode[myHeros[j]->id] = "PREPARE";
						heading[myHeros[j]->id] = tar;
					}
				}
			}

			if (current_round > 4 && current_round < 600)
			{
				Pos tar(0, 0), tar1(0, 0);
				vector<PUnit*>availble;
				bool check = false;
				for (int i = 0; i < myHeros.size(); i++)
				{
					UnitFilter filter; filter.setAreaFilter(new Circle(myHeros[i]->pos,supportRange), "a");
					vector<PUnit*>tempp = console->enemyUnits(filter);
					int tsize = 0;
					for (int j = 0; j < tempp.size(); j++)
						if (tempp[j]->isMine() == 0 && tempp[j]->isWild() == 0)tsize++;
					if (tsize > 0|| myHeros[i]->findBuff("Reviving") != NULL)continue;
					if (current_mode[myHeros[i]->id] == "NORMAL")
					{
						availble.push_back(myHeros[i]);
						tar.x += myHeros[i]->pos.x, tar.y += myHeros[i]->pos.y;
					}
					else if(current_mode[myHeros[i]->id] == "GOWILD")
					{
						check = true;
						tar1 = myHeros[i]->pos;
					}
				}
				if (availble.size() > 2)
				{
					tar.x /= availble.size(); tar.y /= availble.size();
					for (int i = 0; i < availble.size(); i++)
					{
						current_mode[availble[i]->id] = "FORWILD";
						heading[availble[i]->id] = tar;
					}
				}
				else if (check)
				{
					for (int i = 0; i < availble.size(); i++)
					{
						current_mode[availble[i]->id] = "GOWILD";
						for (int j = 1; j < MINE_NUM; j++)
						{
							if (dis2(tar1, MINE_POS[j]) < 100)
								heading[availble[i]->id] = MINE_POS[j];
						}
					}
				}
			}
			else if (current_round >= 600)
			{
				for (int i = 0; i < myHeros.size(); i++)
					if (current_mode[myHeros[i]->id] == "GOWILD" || current_mode[myHeros[i]->id] == "WAITWILD" || current_mode[myHeros[i]->id] == "FORWILD")
						current_mode[myHeros[i]->id] = "NORMAL";
			}

			for (int i = 0; i < myHeros.size(); i++)//聚团
			{
				if (current_mode[myHeros[i]->id] != "NORMAL" && current_mode[myHeros[i]->id] != "STEALHOME" && current_mode[myHeros[i]->id] != "GOWILD" || current_mode[myHeros[i]->id] != "WAIT" || current_mode[myHeros[i]->id] != "WAITWILD")continue;
				int cnt1 = 0, cnt2 = 0;
				for (int j = 0; j < myHeros.size(); j++)
					if ((i != j) && dis2(myHeros[i]->pos, myHeros[j]->pos) < 200)cnt1++;
				for (int j = 0; j < enemyHeros.size(); j++)
					if (enemyHeros[j]->isBase() == 0 && dis2(myHeros[i]->pos, enemyHeros[j]->pos) < 200)cnt2++;
				if (cnt1 < cnt2 - 1)
				{
					current_mode[myHeros[i]->id] = "GATHER";
					for (int j = 0; j < myHeros.size(); j++)
						if (dis2(myHeros[i]->pos, myHeros[j]->pos) > 200) { heading[myHeros[i]->id] = myHeros[j]->pos; break; }
				}
			}
			for (int i = 0; i < myHeros.size(); i++)
			{
				//cout<<"hero "<<myHeros[i]->id<<" "<<current_mode[myHeros[i]->id]<<endl;
			}
		}
	}
	~AIController() { delete console; }
public:
	void updateHero()
	{
		int newHero = heroRank % 10 - 1;
		if (newHero >= 0 && newHero < 4)
		{
			console->chooseHero(HERO_NAME[newHero]);
			each_hero_sum[newHero]++;
			heroRank /= 10;
			return;
		}
		if (current_mode[0] == "URGENT"&&console->gold() < 500)return;
		updateStr dp[20];
		int sum = 0, size = 0;
		PUnit* heroToLevelUp[10];
		UnitFilter filter; filter.setAreaFilter(new Circle(myBase->pos, LEVELUP_RANGE), "a");
		for (int i = 0; i <= info->units.size() - 1; i++)
		{
			if (info->units[i].camp == info->camp && filter.valid(&(info->units[i])) && !PUnit::unitMask(info->units[i].name) && info->units[i].isBase() == 0) heroToLevelUp[size] = (PUnit*)(&(info->units[i])), size++;
		}
		for (int i = 0; i < size; i++)
		{
			sum++;
			double t1, t2, res;
			if (heroToLevelUp[i]->typeId == 3)
			{
				t1 =(400 + (heroToLevelUp[i]->level + 1)*30)* (5.0 / 6.0)*(50 + (heroToLevelUp[i]->level + 1) * 8) + 1.0 / 6.0 * (80 + (heroToLevelUp[i]->level + 1) * 30);
				t2 = (400 + (heroToLevelUp[i]->level) * 30)* (5.0 / 6.0)*(50 + (heroToLevelUp[i]->level ) * 8) + 1.0 / 6.0 * (80 + (heroToLevelUp[i]->level ) * 30);
			}
			else if (heroToLevelUp[i]->typeId == 4)
			{
				t1 = (270 + (heroToLevelUp[i]->level +1)* 30)*(25 + (heroToLevelUp[i]->level + 1) * 4 + (heroToLevelUp[i]->level + 1) * 50 );
				t2 = (270 + heroToLevelUp[i]->level * 30)*(40 + (heroToLevelUp[i]->level) * 4 + (heroToLevelUp[i]->level ) * 50); 
			}
			else if (heroToLevelUp[i]->typeId == 5)
			{
				t1 = (300 + (heroToLevelUp[i]->level + 1) * 40)*(9.0 / 10.0*(30 + (heroToLevelUp[i]->level + 1) * 8) + 20);
				t2 = (300 + (heroToLevelUp[i]->level ) * 40)*(9.0 / 10.0*(30 + (heroToLevelUp[i]->level ) * 8) + 20);
			}
			else if (heroToLevelUp[i]->typeId == 6)
			{
				t1 = (250 + (heroToLevelUp[i]->level + 1) * 30)*(125 + 4 * (heroToLevelUp[i]->level + 1));
				t2 = (250 + (heroToLevelUp[i]->level ) * 30)*(125 + 4 * (heroToLevelUp[i]->level));
			}
			res = (LEVELUP_COST_PER_LEVEL + LEVELUP_COST_PER_LEVEL * heroToLevelUp[i]->level) / (t1 - t2);
			dp[sum].mode = 0, dp[sum].ifLevelUp = heroToLevelUp[i], dp[sum].v = res , dp[sum].tid = heroToLevelUp[i]->typeId;
		}
		for (int i = 0; i <= 3; i++)
		{
			sum++;
			double res;
			if (i == 0)res = 250 * (each_hero_sum[i] + 1) / (55*400);
			else if (i == 1) res = 250 * (each_hero_sum[i] + 1) / (40 * 270);
			else if (i == 2) res = 250 * (each_hero_sum[i] + 1) / (47 * 300);
			else if (i == 3) res = 250 * (each_hero_sum[i] + 1) / (125);
			dp[sum].mode = 1; 
			dp[sum].ifBuy = new char[strlen(HERO_NAME[i]) + 1];
			strcpy(dp[sum].ifBuy, HERO_NAME[i]); dp[sum].v = res;
			dp[sum].tid = i+3;
		}
		sort(dp + 1, dp + sum + 1, cmp);
		for (int i = 1; i <= sum; i++)
		{
			if (console->friendlyUnits().size() > 6 && console->gold()  < 300)return;
			if (console->friendlyUnits().size() > 7 && console->gold()  < 500)return;
			if (console->friendlyUnits().size() > 8 && console->gold()  < 800)return;
			if (dp[i].mode == 0)
			{
				console->buyHeroLevel(dp[i].ifLevelUp);
			}
			else
			{
				console->chooseHero(dp[i].ifBuy);
				each_hero_sum[dp[i].tid - 3]++;
			}
		}
	}
	void action();
private:
	Console* console;
	const PMap* map;
	const PPlayerInfo* info;
	PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;//bases included.
	std::vector<PUnit*> wildHeros;
	PUnit *myBase, *enemyBase;
};
class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual int countWorth() = 0; //计算某种策略的实行价值
	virtual void work() = 0; //实现这种策略
public:
	//	virtual ~Strategy();	 
	void setWorker(PUnit* worker) { this->worker = worker; }
	int getWorth() { return worth; }
	void setWorth(int worth) { this->worth = worth; }
	PUnit* getWorker() { return worker; }
	string getName() { return name; }
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for (int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) { this->console = console; }
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) { mHero = newHero; mStrategy = NULL; } //默认选择回家的策略
	~AIHero() { if (mStrategy != NULL) delete mStrategy; }
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() { return mStrategy; }
	int getid() { return mHero->id; }
	int getvalue() { return mStrategy->getWorth(); }
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

class Attack :public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "Attack"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (target->findBuff("Reviving") != NULL) this->worth = strategyDisabled;
		else if (dis2(worker->pos, target->pos) <= supportRange)
		{
			/*UnitFilter filter;
			filter.setAreaFilter(new Circle(target->pos, supportRange), "a");*/
			this->worth += ((double)20000 / dis2(worker->pos, target->pos));
			this->worth += ((double)5000 / (target->hp/10 + 1));
			if (dis2(worker->pos, target->pos) > worker->range) this->worth -= outOfRangeArg;
			if (target->isWild()) this->worth -= monsterAvoid;
			if (dis2(myBasePos, target->pos) < 1600)  this->worth += protectBaseArg;
			if(target->isBase())this->worth = killBaseArg;
		}
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit(worker);
		console->attack(target);
	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
};

class UseSkill :public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "UseSkill"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		console->selectUnit(worker);
		vector<PSkill*> skillList = console->getSkills();
		for (int i = 0; i < skillList.size(); ++i)
			if (isActiveSkill(skillList[i]))//CHANGED==================================================
			{
				if (!worker->canUseSkill(skillList[i])) this->worth = strategyDisabled;
				else
				{
					if (!strcmp(skillList[i]->name, "HammerAttack"))
					{
						if (target->findBuff("Reviving") != NULL) this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) < supportRange)
						{
							this->worth += ((double)40000 / dis2(worker->pos, target->pos)) ;
							//this->worth += ((double)10000 / (target->hp / 10 + 1));
							if (dis2(worker->pos, target->pos) > HAMMERATTACK_RANGE) this->worth -= outOfRangeArg * 2;
							if (target->findBuff("Dizzy") != NULL) this->worth -= hammerDizzy;
							if (dis2(myBasePos, target->pos) < 1600)//if base being attacked and you can attack the emeny
								this->worth += protectBaseArg * 2;
							if (target->isBase()) this->worth += killBaseArg * 2;
						}
					}
					else if (!strcmp(skillList[i]->name, "Sacrifice"))
					{
						if (target->findBuff("Reviving") != NULL) this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) <= supportRange)
						{
							UnitFilter filter;
							filter.setAreaFilter(new Circle(target->pos, supportRange), "a");
							vector<PUnit*>temp = console->enemyUnits(filter);
							this->worth += ((double)10000 * temp.size() / dis2(worker->pos, target->pos)) ;
							this->worth += ((double)5000 / (target->hp / 10 + 1));
							if (dis2(worker->pos, target->pos) > worker->view) this->worth -= outOfRangeArg * 2;
							if (target->findBuff("Dizzy") != NULL) this->worth += hammerDizzy;
							if (dis2(target->pos, myBasePos) < 1600 )//if base being attacked and you can attack the emeny
								this->worth += protectBaseArg * 2;
							if (target->isBase()) this->worth += killBaseArg * 4;
						}
					}
					else if (!strcmp(skillList[i]->name, "SetObserver"))
					{
						if (target->findBuff("Reviving") != NULL) this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) <= supportRange)
						{
							this->worth += 2 * attackArg;
							if (dis2(worker->pos, target->pos) > worker->view) this->worth -= outOfRangeArg * 2;
							if (target->findBuff("Dizzy") != NULL) this->worth -= hammerDizzy;
							this->targetPos = console->randPosInArea(worker->pos, skillList[i]->range());
						}
					}
				}
				break;
			}
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit(worker);
		vector<PSkill*> skillList = console->getSkills();
		for (int i = 0; i < skillList.size(); ++i)
			if (isActiveSkill(skillList[i]))
			{
				if (!strcmp(skillList[i]->name, "HammerAttack"))
					console->useSkill(skillList[i], target);
				else if (!strcmp(skillList[i]->name, "Sacrifice"))
					console->useSkill(skillList[i], NULL);
				else
					console->useSkill(skillList[i], targetPos);
				break;
			}
	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
	Pos targetPos;
};

class Escape :public Strategy //英雄逃跑的战略 
{
public:
	Escape(PUnit* worker) { setWorker(worker); name = "Escape"; }
public:
	virtual int countWorth()
	{

	}
	virtual void work()
	{

	}
};

class GetOut :public Strategy
{
public:
	GetOut(PUnit* worker) { setWorker(worker); name = "GetOut"; }
	virtual int countWorth() { return 0; }
	virtual void work()
	{
		console->selectUnit((const PUnit*)worker);
		console->move(console->randPosInArea(worker->pos, 9));
	}
};

class GoBackHome :public Strategy //英雄步行回家的策略
{
public:
	GoBackHome(PUnit* worker) { setWorker(worker); name = "GoBackHome"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		//if (worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0) this->worth += goBackHomeArg;
		if (current_mode[worker->id] == "URGENT")this->worth = 500;
		if (dis2(worker->pos, myBasePos) < 100 || dis2(worker->pos, myBasePos) > supportRange * 9) this->worth = 0;
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit((const PUnit*)worker);
		console->move(console->getMilitaryBase()->pos);
	}
};

class CallBackHome :public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) { setWorker(worker); name = "CallBackHome"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (console->gold() > this->getWorker()->level * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE)
		{
			if (current_mode[worker->id] == "URGENT ")this->worth = 2 * goBackHomeArg;
			if (dis2(getWorker()->pos, console->getMilitaryBase()->pos) < supportRange)this->worth = 0;
		}
		return this->worth;
	}
	virtual void work()
	{
		console->callBackHero(worker);
	}
};

class GoToEnemyBase :public Strategy
{
public:
	GoToEnemyBase(PUnit* worker) { setWorker(worker); name = "GoToEnemyBase"; }
public:
	virtual int countWorth()
	{
		this->worth = 10000;
		return this->worth;
	}
	virtual void work()
	{
		Pos res;
		int tempx = (150 - console->getMilitaryBase()->pos.x - worker->pos.x);
		int tempy = (150 - console->getMilitaryBase()->pos.y - worker->pos.y);
		if (tempx > 0)res.x = 20;
		else res.x = -20;
		if (tempx == 0)
		{
			if (150 - console->getMilitaryBase()->pos.y - worker->pos.y > 0)res.y = 20;
			else res.y = -20;
		}
		else res.y = res.x * tempy / tempx;
		res.x += worker->pos.x;
		res.y += worker->pos.y;
		if (myBasePos.x == 15 && res.x > 135)res.x = 135;
		if (myBasePos.x == 135 && res.x < 15)res.x = 15;
		if (myBasePos.y == 5 && res.y > 145)res.y = 145;
		if (myBasePos.y == 145 && res.y< 5)res.y = 5;
		console->selectUnit((const PUnit*)worker);
		console->move(res);
	}
};

class GoMining :public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target) { setWorker(worker); setTarget(target); name = "GoMining"; }
public:
	virtual int countWorth()
	{
		this->worth = miningArg;
		if (target == MINE_POS[0])
		{
			for (int i = 0; i < AIHeroList.size(); ++i)
				if (AIHeroList[i]->getStrategy() != NULL)
					if (AIHeroList[i]->getStrategy()->getName() == "GoMining")
					{
						GoMining* otherMining = (GoMining*)(AIHeroList[i]->getStrategy());
						if (otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;
					}
		}
		this->worth -= dis(worker->pos, target);
		if (target == MINE_POS[0])
			this->worth += centerMineArg;
		this->worth /= 2;
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit(worker);
		console->move(target);
	}
	void setTarget(Pos target) { this->target = target; }
	Pos getTarget() { return target; }
private:
	Pos target;
};

class StayHomeProtect :public Strategy
{
public:
	StayHomeProtect(PUnit* worker) { setWorker(worker); name = "StayHomeProtect"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (dis2(worker->pos, console->getMilitaryBase()->pos) < supportRange * 4 && current_mode[worker->id] == "URGENT")
		{
			this->worth = stayBaseArg;
			vector<PUnit*> temp = console->enemyUnits();
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i]->isHero() && dis2(temp[i]->pos, worker->pos) < supportRange)
				{
					this->worth = 0; break;
				}
			}
		}
		return this->worth;
	}
	virtual void work()
	{
		if (dis2(worker->pos, console->getMilitaryBase()->pos) > 100)
		{
			console->selectUnit((const PUnit*)worker);
			console->move(console->getMilitaryBase()->pos);
		}
		else
		{
			console->selectUnit((const PUnit*)worker);
			console->move(console->randPosInArea(console->getMilitaryBase()->pos , 100));
		}
		return;
	}
};

class Tempt :public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
	Tempt(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "Tempt"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		return this->worth;
	}
	virtual void work()
	{

	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
};

void AIController::action()
{
	//必要的初始化
	vector<Strategy*> allStrategy; vector<AIHero*> AIHeroList;

	bool ifmoved[101];
	for (int j = 0; j < 101; j++)ifmoved[j] = false;

	for (int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	//将决策加入列表之中
	{
		for (int i = 0; i < myHeros.size(); i++)
		{
			if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "GATHER")
			{
				if (ifmoved[myHeros[i]->id])continue;
				console->selectUnit(myHeros[i]);
				console->move(heading[myHeros[i]->id]);
				ifmoved[myHeros[i]->id] = true;
				continue;
			}
			if (current_mode[myHeros[i]->id] == "STRANDED")
			{
				if (ifmoved[myHeros[i]->id])continue;
				console->selectUnit(myHeros[i]);
				console->move(console->randPosInArea(myHeros[i]->pos, 16));
				ifmoved[myHeros[i]->id] = true;
				continue;
			}
			if (current_mode[myHeros[i]->id] == "GOWILD")
			{
				bool check = false;
				for (int j = 0; j < enemyHeros.size(); j++)
					if (dis2(myHeros[i]->pos, enemyHeros[j]->pos) < 100)check = true;
				if (!check)
				{
					if (dis2(myHeros[i]->pos, heading[myHeros[i]->id]) > 100)
					{
						console->selectUnit(myHeros[i]);
						console->move(heading[myHeros[i]->id]);
						continue;
					}
					else
					{
						for (int j = 0; j < wildHeros.size(); j++)
						{
							if (wildHeros[j]->findBuff("Reviving") == NULL)
							{
								allStrategy.push_back(new Attack(myHeros[i], wildHeros[j]));
								allStrategy.push_back(new UseSkill(myHeros[i], wildHeros[j]));
							}
							else
							{
								UnitFilter filter; filter.setAreaFilter(new Circle(heading[myHeros[i]->id], 100), "a");
								vector<PUnit*>tempp = console->friendlyUnits(filter);
								if (tempp.size() <= 5)
								{
									for (int k = 0; k < tempp.size(); k++)
									{
										if (ifmoved[tempp[k]->id])continue;
										console->selectUnit(tempp[k]);
										console->move(heading[tempp[k]->id]);
										ifmoved[tempp[k]->id] = true;
										continue;
									}
								}
								else
								{
									int minlen = 2147483647, tpos = -1;
									for (int k = 1; k < MINE_NUM; k++)
									{
										UnitFilter filterr; filterr.setAreaFilter(new Circle(MINE_POS[k], 100), "a");
										vector<PUnit*>temppp = console->friendlyUnits(filterr);
										if (MINE_POS[k] != heading[myHeros[i]->id] && temppp.size() == 0 && minlen > dis2(MINE_POS[k], heading[myHeros[i]->id]))
										{
											tpos = k;
											minlen = dis2(MINE_POS[k], heading[myHeros[i]->id]);
										}
									}
									for (int k = 3; k < tempp.size(); k++)
										heading[tempp[k]->id] = MINE_POS[tpos];
								}
							}
						}
					}
				}
			}
			for (int j = 0; j < enemyHeros.size(); ++j)
			{
				if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "GATHER")continue;
				if (dis2(myHeros[i]->pos,enemyBasePos) > 100)
				{
					if (enemyHeros[j]->isBase() == 0)allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
					if (enemyHeros[j]->isBase() == 0)allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
					allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
				}
				else
				{
					if (enemyHeros[j]->isBase())allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
				}
			}
			for (int j = 0; j < wildHeros.size(); ++j)
			{
				if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "GATHER")continue;
				if (dis2(myHeros[i]->pos, enemyBasePos) > 100)
				{
					allStrategy.push_back(new UseSkill(myHeros[i], wildHeros[j]));
					allStrategy.push_back(new Tempt(myHeros[i], wildHeros[j]));
					allStrategy.push_back(new Attack(myHeros[i], wildHeros[j]));
				}
			}
			if (current_mode[myHeros[i]->id] == "NORMAL" || current_mode[myHeros[i]->id] == "URGENT")
			{
				allStrategy.push_back(new GoBackHome(myHeros[i]));
				allStrategy.push_back(new CallBackHome(myHeros[i]));
			}
			if (current_mode[myHeros[i]->id] == "URGENT")allStrategy.push_back(new StayHomeProtect(myHeros[i]));
			if (current_mode[myHeros[i]->id] == "STEALHOME")
			{
				int countt = 0;
				for (int j = 0; j < enemyHeros.size(); j++)
				{
					if ((enemyHeros[j]->isBase() == 0) && dis2(enemyHeros[j]->pos, myHeros[i]->pos) < 100) countt++;
				}
				if (countt < 1 ) allStrategy.push_back(new GoToEnemyBase(myHeros[i]));
			}
			for (int j = 0; j < MINE_NUM; ++j)
			{
				if (current_mode[myHeros[i]->id] == "NORMAL")
					allStrategy.push_back(new GoMining(myHeros[i], MINE_POS[j]));
			}
		}
	}
	for (int i = 0; i < allStrategy.size(); ++i)allStrategy[i]->setAIHeroList(AIHeroList);
	for (int i = 0; i < allStrategy.size(); ++i)allStrategy[i]->setConsole(console);
	//选择并执行战术
	for (int i = 0; i < AIHeroList.size(); ++i)
		for (int j = 0; j < allStrategy.size(); ++j)
		{
			bool check = AIHeroList[i]->setStrategy(allStrategy[j]);
		}
	for (int i = 0; i < AIHeroList.size(); ++i)
	{
		if (AIHeroList[i]->getStrategy() != 0)
		{
			AIHeroList[i]->action();
		}
	}
	for (int i = 0; i < AIHeroList.size(); ++i)if (AIHeroList[i] != NULL)delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if (newStrategy == NULL) return false;
	if (newStrategy->getWorker() != this->mHero) return false;
	if (mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if (mStrategy != NULL)delete mStrategy;
		mStrategy = newStrategy;
	}
	else delete newStrategy;
	return true;
}

void AIHero::action()
{
	mStrategy->work();
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	//freopen("res.txt","a",stdout);
	current_round = info.round;
	srand(time(NULL));
	AIController controller(map, info, cmd);
	controller.updateHero();
	controller.action();
}
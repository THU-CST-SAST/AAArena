#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
#include <cmath>
using namespace std;


Pos randPos(){
	return Pos(rand()%16-8,rand()%16-8);
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    Console* console = new Console(map, info, cmd);
    Pos mine_pos[] = {Pos(73, 74), Pos(34, 59), Pos(34, 89), Pos(114, 59), Pos(114, 89), Pos(19, 139), Pos(129, 9)};
    Pos mine_pos2[] = {Pos(73, 74),Pos(114, 89),Pos(34, 89), Pos(34, 59), Pos(114, 59),  Pos(19, 139), Pos(129, 9)};
    Pos mine_p[]={Pos(19, 139), Pos(129, 9)};
    vector<const PUnit*> myHeroes, myHealthyHeroes, mySickHeroes, Hammerguards, Masters, Scouters, enemyHeroes, Wilds, Mines,Enemies; 
    PUnit* myBase = NULL;
    PUnit* enemyBase = NULL;
	for(int i = 0; i < info.units.size(); ++i)
    {
        if(info.units[i].isHero())
        {
            if(info.units[i].camp == console->camp())
			{
				myHeroes.push_back((PUnit*)(&info.units[i]));
				if(console->unitArg("hp", "c", (PUnit*)(&info.units[i])) < console->unitArg("hp", "m", (PUnit*)(&info.units[i])) / 3)
				{
					mySickHeroes.push_back((PUnit*)(&info.units[i]));
				}
				else
				{
					myHealthyHeroes.push_back((PUnit*)(&info.units[i]));
				}
                if(strcmp(info.units[i].name, "Hammerguard") == 0)
                {
                    Hammerguards.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Master") == 0)
                {
                    Masters.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Scouter") == 0)
                {
                    Scouters.push_back((PUnit*)(&info.units[i]));
                }
			}
            else enemyHeroes.push_back((PUnit*)(&info.units[i])),
				Enemies.push_back((PUnit*)(&info.units[i]));
        }
        else if(info.units[i].isWild()&&info.units[i].hp>0)
        {
        	Wilds.push_back((PUnit*)(&info.units[i]));
			Enemies.push_back((PUnit*)(&info.units[i]));
		}
		else if(strcmp(info.units[i].name, "MilitaryBase") == 0)
		{
			if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]);
			else enemyBase = (PUnit*)(&info.units[i]);
		}
		else if(strcmp(info.units[i].name, "Mine") == 0)
    	{
    		Mines.push_back((PUnit*)(&info.units[i]));
    	}
    }
    
    if(myHeroes.size() < HERO_LIMIT)
    {
		if(myHeroes.size()==0)console->chooseHero("Hammerguard");
		if(myHeroes.size()==1)console->chooseHero("Master");
		if(myHeroes.size()==2)console->chooseHero("Scouter");
		if(myHeroes.size()==3)console->chooseHero("Hammerguard");
		if(myHeroes.size()==4)console->chooseHero("Master");
		if(myHeroes.size()==5)console->chooseHero("Hammerguard");
		if(myHeroes.size()==6)console->chooseHero("Hammerguard");
		if(myHeroes.size()==7)console->chooseHero("Hammerguard");
	}

	if(myHeroes.size() == HERO_LIMIT)
	{
		PUnit lowest_level_hero;
		int tmp_min_level = HERO_LEVEL_LIMIT;
		for(int i = 0; i < myHeroes.size(); ++i)
		{
			console->selectUnit(myHeroes[i]);
			if(console->unitArg("level", "c") < tmp_min_level)
			{
				 tmp_min_level = console->unitArg("level", "c");
				 lowest_level_hero = (*myHeroes[i]);
			}
		}
		Pos lowest_level_hero_pos = lowest_level_hero.pos;
		if(console->gold() - console->goldCostCurrentRound() > console->levelUpCost(tmp_min_level))
		{
			if(dis2(MILITARY_BASE_POS[console->camp()], lowest_level_hero_pos) < LEVELUP_RANGE)
			{
				console->buyHeroLevel(&lowest_level_hero);
			}
			else
			{
				Pos target_pos = console->closestPos(MILITARY_BASE_POS[console->camp()], LEVELUP_RANGE, lowest_level_hero_pos);
				console->selectUnit(&lowest_level_hero);
				console->move(target_pos);
			}
		}	
	}
    
	for(int i = 0; i < Hammerguards.size(); ++i)
	{
		
		bool existenemy = false;

		console->selectUnit(Hammerguards[i]);
		for(int j = 0; j < Enemies.size(); ++j)
		{
			if(dis2(Hammerguards[i]->pos, MILITARY_BASE_POS[1-console->camp()]) < HAMMERGUARD_RANGE)
			{
				if(enemyBase) console->attack(enemyBase);
				else console->move(MILITARY_BASE_POS[1-console->camp()]);
			}
			if(dis2(Hammerguards[i]->pos, Enemies[j]->pos) < HAMMERATTACK_RANGE&&Hammerguards[i]->canUseSkill("HammerAttack"))
			{
				console->useSkill("HammerAttack", Enemies[j]);
				console->attack(Enemies[j]);
				existenemy = true;
				break;
			}
			if(dis2(Hammerguards[i]->pos, Enemies[j]->pos) < HAMMERGUARD_RANGE)
			{
				console->attack(Enemies[j]);
				break;
			}			
		}
	}
	
    
    for(int i = 0; i < Scouters.size(); ++i)
    {
        console->selectUnit(Scouters[i]);
        for(int j = 0; j < Enemies.size(); ++j)
        {
            if(dis2(Scouters[i]->pos, MILITARY_BASE_POS[1-console->camp()]) < SCOUTER_RANGE)
			{
                vector<Pos> target_pos;
                target_pos.push_back(Scouters[i]->pos);
                console->useSkill("SetObserver", target_pos);
				if(enemyBase) console->attack(enemyBase);
				else console->move(MILITARY_BASE_POS[1-console->camp()]);
			}
            if(dis2(Scouters[i]->pos, Enemies[j]->pos) < SCOUTER_RANGE)
			{
				console->attack(Enemies[j]);
				break;
			}
        }
    }
	
    for(int i = 0; i < Masters.size(); ++i)
    {
        console->selectUnit(Masters[i]);
        for(int j = 0; j < Enemies.size(); ++j)
        {
            if(dis2(Masters[i]->pos, Enemies[j]->pos) < MASTER_RANGE)
			{
				console->attack(Enemies[j]);
				break;
			}
        }
    }	
    
	Pos Master_Pos;
	for(int j=0;j<myHeroes.size();j++)
		if(strcmp(myHeroes[j]->name, "Master") == 0){
			Master_Pos=myHeroes[j]->pos;
			break;
		}
			
	for(int i = 0; i < mySickHeroes.size(); ++i)
	{
		console->selectUnit(mySickHeroes[i]);
		if(strcmp(mySickHeroes[i]->name, "Master") == 0)
			console->move(MILITARY_BASE_POS[console->camp()]);
		else console->move(Master_Pos);
	}
	
	for(int i = 0; i < mySickHeroes.size(); ++i)
	{
		console->selectUnit(mySickHeroes[i]);
		for(int j = 0; j < enemyHeroes.size(); ++j)
		{
            if(strcmp(mySickHeroes[i]->name, "Hammerguard") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < HAMMERATTACK_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->useSkill("HammerAttack", enemyHeroes[j]);
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
            else if(strcmp(mySickHeroes[i]->name, "Scouter") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < SCOUTER_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
            else if(strcmp(mySickHeroes[i]->name, "Master") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < MASTER_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
			
		}
	}
	
	if(myBase->hp < 3 * MILITARY_BASE_HP / 4)
	{
		for(int i = 0; i < myHealthyHeroes.size(); ++i)
		{
            if(dis2(myHealthyHeroes[i]->pos, MILITARY_BASE_POS[console->camp()]) > MILITARY_BASE_RANGE)
            {
                console->callBackHero(myHealthyHeroes[i]);
                console->move(MILITARY_BASE_POS[console->camp()], myHealthyHeroes[i]);
            }
		}
	}
	else
	{
		int high_level_hero_count = 0;
		for(int i = 0; i < myHeroes.size(); ++i)
		{
			if(myHeroes[i]->level >= HERO_LEVEL_LIMIT - 3) high_level_hero_count++;
		}
		//if(high_level_hero_count >= 1 && (info.round >= 250 && info.round <= 350 || info.round >= 600 && info.round <= 700))
		if(high_level_hero_count >= 3&&info.round >= 250 && info.round <= 350 || info.round >= 600 && info.round <= 700)
        {
            //cout << "xxn";
			for(int i = 0; i < myHeroes.size(); ++i)
			{
				if(enemyBase) console->attack(enemyBase, myHeroes[i]);
				else console->move(MILITARY_BASE_POS[1-console->camp()], myHeroes[i]);
			}
		}
		else
		{
			Pos target;
			for(int i = 0; i < myHealthyHeroes.size(); ++i)
			{
				
				if(info.round<=100){
					if(console->camp() == 0) target=mine_pos[0]+randPos();
					if(console->camp() == 1) target=mine_pos2[0]+randPos();
				}else{
					if(console->camp() == 0) target=mine_pos[myHealthyHeroes[i]->id%2]+randPos();
					if(console->camp() == 1) target=mine_pos2[myHealthyHeroes[i]->id%2]+randPos();
				}
		if(info.round>100)target=mine_p[0];
				int flag=0;
				int mn=999999,k=-1;
				for(int j=0;j<Enemies.size();j++)
					if(dis2(Enemies[j]->pos,myHealthyHeroes[i]->pos)<mn)
						mn=dis2(Enemies[j]->pos,myHealthyHeroes[i]->pos),k=j;
				if(k!=-1&&mn>HAMMERGUARD_RANGE){
					console->move(Enemies[k]->pos, myHealthyHeroes[i]);
					flag=1;
					break;
				}
				if(!flag&&mn>HAMMERGUARD_RANGE&&dis2(myHealthyHeroes[i]->pos,target)>=64)
					console->move(target, myHealthyHeroes[i]);
			}
		}
	}
	delete console;
}

#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include<bits/stdc++.h>
using namespace std;


//=======================================トウノトオトムーツキコッハ=========================================================================================
const int INF=0x3fffffff;
const double eps=1e-8;
const vector<Pos>EmptyPosVector;
const Pos EmptyPos=Pos();
class QYMap//喘噐繍聞喘自葎訓末鹸墫議PMap窃廬算葎距喘酒準議窃
{
	public :
	QYMap& operator=(const PMap &a)
	{
		playerIds=a.playerIds;
		for(int i=0;i<MAP_SIZE;i++)
			for(int j=0;j<MAP_SIZE;j++)
				height[i][j]=a.getHeight(i,j);
		return *this;
	}
    int height[MAP_SIZE][MAP_SIZE];      //仇夕嶄光倖泣議互業
    std::vector<int> playerIds;          //螺社園催双燕潮範0、1葎嗄老褒圭2葎勸講

    QYMap() {
        playerIds.clear();
    }
}MAP;
bool PosLenCMP(const Pos &a,const Pos &b){return a.x*a.x+a.y*a.y<b.x*b.x+b.y*b.y;}//曳熟楚庁海
struct Legal_Path_Logical//楚貸辞駅将泣鹿
{
	int offset;
	Legal_Path_Logical():offset(8){}
	struct Node{Pos a,b;bool type;}nd;//貸辞潤泣type=1旗燕a葎駅将泣,type=0旗燕a,b嶄将狛匯倖軸辛
	vector<Node>a[17][17];
	vector<Node>* operator()(int x,int y){return &a[x+offset][y+offset];}//距喘圭隈
	vector<Pos>SpeedRange[100];//耽倖堀業汽了扮寂岷鉦宣侭嬬欺器議泣議陶卞楚(峪嗤12,25,36頁嗤喘議)
	static int cmp(const Pos &a,const Pos &b){return a.x*a.x+a.y*a.y<b.x*b.x+b.y*b.y;}
	void init()//圓侃尖
	{
		//柴麻SpeedRange
		Pos O;
		for(int speed=0;speed<100;speed++)
			//if(speed==MASTER_SPEED || speed==HAMMERGUARD_SPEED || speed==SCOUTER_SPEED)
			{
				for(O.x=-(int)sqrt(speed);O.x<=(int)sqrt(speed);O.x++)
					for(O.y=-(int)sqrt(speed-O.x*O.x);O.y<=(int)sqrt(speed-O.x*O.x);O.y++)
						SpeedRange[speed].push_back(O);
				sort(SpeedRange[speed].begin(),SpeedRange[speed].end(),PosLenCMP);
			}

		vector<Pos>b;
		int i;
		Pos S(0,0),T,M;
		for(T.x=-8;T.x<=8;T.x++)
			for(T.y=-8;T.y<=8;T.y++)
			{
				//柴麻楚T議貸辞准泣
				b.clear();
				for(M.x=min(T.x,0);M.x<=max(T.x,0);M.x++)
					for(M.y=min(T.y,0);M.y<=max(T.y,0);M.y++)
						if((M.x==0&&M.y==0)||checkOnLine(S,T,M))b.push_back(M);
				sort(b.begin(),b.end(),cmp);
				for(i=0;i<b.size();)
				{
					if(i+1<b.size() && dis2(b[i],b[i+1])>1)
					{
						//貸辞辛僉泣
						nd.a=b[i];
						nd.b=b[i+1];
						nd.type=0;
						a[T.x+offset][T.y+offset].push_back(nd);
						i+=2;
					}
					else
					{
						//貸辞駅将泣
						nd.a=b[i];
						nd.type=1;
						a[T.x+offset][T.y+offset].push_back(nd);
						i++;
					}
				}
			}
	}
}LPL;
class Shortest_Path_Class//柴麻恷玉揃麼悶窃
{
	private:
		short _index,round_index;//index炎芝嚥round_index炎芝
		Pos q[30010];//BFS錦双
		Pos Scheme[MAP_SIZE][MAP_SIZE];//芝村揃抄議念駁
		Pos Scheme_OneStep[MAP_SIZE][MAP_SIZE];//芝村揃抄議販吭匯倖軟泣
		double dist[MAP_SIZE][MAP_SIZE];
		short pd_inq[MAP_SIZE][MAP_SIZE];//_index炎芝
		short pd_round[MAP_SIZE][MAP_SIZE];//round_index炎芝

		//宥狛仇夕a議互業餓崙登協S嬬倦岷器T
		bool connection(const Pos &S,const Pos &T,const QYMap &a)
		{
			vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
			//printf("  connection:(%d,%d)->(%d,%d)n",S.x,S.y,T.x,T.y);
			//for(int i=0;i<b->size();i++)printf("   type=%d a(%d,%d) b(%d,%d)n",(*b)[i].type,(*b)[i].a.x,(*b)[i].a.y,(*b)[i].b.x,(*b)[i].b.y);
			bool Pa=true,Pb=false;
			for(int i=1;i<b->size();i++)
			{
				//printf("   i=%dn",i);
				if((*b)[i].type==1)
				{
					if(Pa && abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
					}
					else if(Pb && abs(a.height[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
					}
					else return false;
				}
				else
				{
					Pa=(abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
					Pb=(abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
					if(!(Pa||Pb))return false;
				}
			}
			return true;
		}

		//公竃匯訳宥狛仇夕a議互業餓崙喇S岷器T議膨銭宥揃抄
		vector<Pos> connectionScheme(const Pos &S,const Pos &T,const QYMap &a)
		{
			vector<Pos>re;
			vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
			bool Pa=true,Pb=false;
			re.push_back(S);
			for(int i=1;i<b->size();i++)
			{
				if((*b)[i].type==1)
				{
					if(Pa && abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
						if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].a);
						re.push_back(S+(*b)[i].a);
					}
					else if(Pb && abs(a.height[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
						if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].b);
						re.push_back(S+(*b)[i].a);
					}
					else return EmptyPosVector;
				}
				else
				{
					Pa=(abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
					Pb=(abs(a.height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a.height[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
					if(!(Pa||Pb))return EmptyPosVector;
				}
			}
			return re;
		}

		//深打block嬾悪參Start葎0鉦宣軟泣斤 畠夕/朕炎泣Target 恂BFS繍揃抄軟泣佚連贋崛Scheme才Scheme_OneStep(單枠僉夲涙block泣,涙揃辛恠頁辛參僉block泣)侭嗤BFS欺議泣鹿贋刈噐pb_inq[]==_index
		void findGoodPath(const vector<Pos>Start,const vector<Pos> &block,Pos Target=Pos(-1,-1))
		{
			vector<Pos>Block_Start_Save;//贋刈短嗤制婢議嬾悪泣潤崩朔嶷仟制婢
			Pos S,T;
			++_index;
			for(int i=0;i<block.size();i++)
				if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
				MAP.height[block[i].x][block[i].y]+=100;
			int l=0,r=-1,dir_ord[4]={0,1,2,3};
			for(int i=0;i<Start.size();i++)
			{
				pd_inq[Start[i].x][Start[i].y]=_index;
				Scheme_OneStep[Start[i].x][Start[i].y]=Start[i];
				q[++r]=Start[i];
			}
			while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
			{
				S=q[l++];
				if(MAP.height[S.x][S.y]>=99)
				{
					Block_Start_Save.push_back(S);
					continue;
				}
				random_shuffle(dir_ord, dir_ord+4);
				for(int k=0;k<4;k++)
				{
					T.x=S.x+dir[dir_ord[k]][0];
					T.y=S.y+dir[dir_ord[k]][1];
					if(checkPos(T) && pd_inq[T.x][T.y]!=_index)
						if(MAP.height[T.x][T.y]>=99 || abs(MAP.height[S.x][S.y]-MAP.height[T.x][T.y])<=MOVE_HEIGHT_DELTA)
						{
							pd_inq[T.x][T.y]=_index;
							Scheme[T.x][T.y]=S;
							Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
							q[++r]=T;
						}
				}
			}
			for(int i=0;i<block.size();i++)
				if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
				MAP.height[block[i].x][block[i].y]-=100;
			if((Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
				if(Block_Start_Save.size())
				{
					l=0,r=-1;
					for(int i=0;i<Block_Start_Save.size();i++)q[++r]=Block_Start_Save[i];
						while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))//嶷仟斤block泣BFS
						{
							S=q[l++];
							random_shuffle(dir_ord, dir_ord+4);
							for(int k=0;k<4;k++)
							{
								T.x=S.x+dir[dir_ord[k]][0];
								T.y=S.y+dir[dir_ord[k]][1];
								if(checkPos(T) && pd_inq[T.x][T.y]!=_index)
									if(abs(MAP.height[S.x][S.y]-MAP.height[T.x][T.y])<=MOVE_HEIGHT_DELTA)
									{
										pd_inq[T.x][T.y]=_index;
										Scheme[T.x][T.y]=S;
										Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
										q[++r]=T;
									}
							}
						}
				}
		}

		//儖孀匯訳喇Start欺Target匯化嬬欺器議膨銭宥揃抄(駅倬隠屬基宛贋壓才Scheme栽隈)
		vector<Pos> findOneStepScheme(Pos Start,Pos Target,const vector<Pos> &block)
		{
			vector<Pos>re;
			for(int i=0;i<block.size();i++)
				if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
				MAP.height[block[i].x][block[i].y]+=100;

			for(;Target!=Start;Target=Scheme[Target.x][Target.y])
			{
				vector<Pos>a=connectionScheme(Target,Scheme[Target.x][Target.y],MAP);
				a.pop_back();
				for(int i=0;i<a.size();i++)re.push_back(a[i]);
				if(re.size()>20000)
				{
					printf("findOneStepScheme Error!!! Start=(%d,%d) Target=(%d,%d) ",Start.x,Start.y,Target.x,Target.y);
					printf("  vector:");for(int j=0;j<20;j++)printf("(%d,%d)",re[j].x,re[j].y);
					printf("nScheme:n");
					for(int x=Start.x-5;x<=Start.x+5;x++,cout<<endl)
						for(int y=Start.y-5;y<=Start.y+5;y++)
							if(checkPos(Pos(x,y)))printf("(% 3d,% 3d)",Scheme[x][y].x,Scheme[x][y].y);
							else printf("(///,///)");
				}
			}
			re.push_back(Start);
			reverse(re.begin(),re.end());
			for(int i=0;i<block.size();i++)
				if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
				MAP.height[block[i].x][block[i].y]-=100;
			return re;
		}

	public:
		vector<Pos>a;//喘噐贋刈巓円泣恫炎
		int round[MAP_SIZE][MAP_SIZE];//卆象輝念軟泣欺器恫炎議圓柴指栽方

		//卦指軟泣S竃窟speed堀業岻坪嬬欺器議泣鹿旺芝村崛a方怏(深打嬾悪泣鹿block)
		vector<Pos> findOneStepRange(Pos Start,int speed,const vector<Pos> &block)
		{
			++_index;
			for(int i=0;i<block.size();i++)
			{
				if(block[i].x!=Start.x||block[i].y!=Start.y)
					MAP.height[block[i].x][block[i].y]+=100;
			}
			int l=0,r=0;
			Pos S,T,O;
			vector<Pos>&OList=LPL.SpeedRange[speed];//Speed袈律坪嬬欺器議侭嗤泣議陶卞楚

			for(int TOT=0;TOT<OList.size();TOT++)
			{
				O=OList[TOT];
				T=Start+O;
				if(checkPos(T))dist[T.x][T.y]=INF;
			}
			dist[Start.x][Start.y]=0;
			q[0]=Start;pd_inq[Start.x][Start.y]=_index;
			while(l<=r)
			{
				S=q[l++];
				if(MAP.height[S.x][S.y]>=99)continue;
				pd_inq[S.x][S.y]=0;
				
				for(int TOT=0;TOT<OList.size();TOT++)
				{
					O=OList[TOT];
					T=S+O;
					if(checkPos(T))
					{
						if(dist[S.x][S.y]+sqrt(dis2(S,T))<=sqrt(speed)+eps && dist[S.x][S.y]+sqrt(dis2(S,T))<dist[T.x][T.y]-eps)
						{
							bool isBlock=(MAP.height[T.x][T.y]>=99);
							if(isBlock)MAP.height[T.x][T.y]-=100;
							if(connection(S,T,MAP))
							{
								dist[T.x][T.y]=dist[S.x][S.y]+sqrt(dis2(S,T));
								Scheme[T.x][T.y]=S;
								if(pd_inq[T.x][T.y]!=_index)
								{
									pd_inq[T.x][T.y]=_index;
									q[++r]=T;
								}
							}
							if(isBlock)MAP.height[T.x][T.y]+=100;
						}
					}
				}
			}
			a.clear();
			for(int i=0;i<=r;i++)if(MAP.height[q[i].x][q[i].y]<=99)a.push_back(q[i]);
			for(int i=0;i<block.size();i++)
			{
				if(block[i].x!=Start.x||block[i].y!=Start.y)
					MAP.height[block[i].x][block[i].y]-=100;
			}
			random_shuffle(a.begin(),a.end());
			return a;
		}

		//卦指喇Start欺Target堀業葎Speed扮音辛将block,音辛壓BanStays唯藻輝念指栽議卞強揃抄
		vector<Pos> findShortestPath(Pos Start,Pos Target,int speed,const vector<Pos> &block,const vector<Pos>&BanStays=EmptyPosVector)
		{
			int i;
			vector<Pos>around=findOneStepRange(Start,speed,block);
			for(i=0;i<around.size();i++)
				if(around[i]==Target)
					break;
			if(i<around.size())
			{
				//匯化辛器
				return findOneStepScheme(Start,Target,block);
			}
			else
			{
				//匯化音辛器
				vector<Pos>around_save=around;
				vector<Pos>scheme_save(around);
				for(i=0;i<scheme_save.size();i++)scheme_save[i]=Scheme[scheme_save[i].x][scheme_save[i].y];
//				map<Pos,bool>hash;
				int hash[160][160];
				memset(hash,0,sizeof(hash));
				
				for(i=0;i<BanStays.size();i++) hash[BanStays[i].x][BanStays[i].y]=1;
				for(i=0;i<around.size();)
				if(around[i]!=Start&&around[i]!=Target)
				{
//					printf("%d %dn",around[i].x,around[i].y);
					if(0<=around[i].x&&around[i].x<160 && 0<=around[i].y&&around[i].y<160 && hash[around[i].x][around[i].y])
					{
						swap(around[i],around[(int)around.size()-1]);
						around.pop_back();
					}
					else i++;
				}
				else i++;
				vector<Pos> block_save(block);
				for(i=0;i<BanStays.size();i++)block_save.push_back(BanStays[i]);
				findGoodPath(around,block_save,Target);
				if(pd_inq[Target.x][Target.y]!=_index)return EmptyPosVector;
				Pos OneStep=Scheme_OneStep[Target.x][Target.y];
				for(i=0;i<around_save.size();i++)Scheme[around_save[i].x][around_save[i].y]=scheme_save[i];
				return findOneStepScheme(Start,OneStep,block);
			}
		}
		
		//功象軟泣堀業才嬾悪更夛畠蕉佚連
		void build(Pos Start,int speed,const vector<Pos> &block=EmptyPosVector)
		{
//			for (int i=0;i<block.size();++i) {
//				printf("%d %dn",block[i].x,block[i].y);
//			}
			for(int i=0;i<MAP_SIZE;i++)
				for(int j=0;j<MAP_SIZE;j++)
					Scheme[i][j]=EmptyPos;
			round_index++;
			vector<Pos>around;
			findOneStepRange(Start,speed,block);
			around.push_back(Start);
			pd_round[Start.x][Start.y]=round_index;
			round[Start.x][Start.y]=0;
			findGoodPath(around,block);
			Scheme[Start.x][Start.y]=Pos(-100,-100);
		}

		//O(n)柴麻輝念軟泣欺朕炎泣議浩柴指栽方,飛涙隈欺器卦指10000(距喘念駅倬build())
		int distance(Pos Target,int speed)
		{
			if(Scheme[Target.x][Target.y]==EmptyPos)return 10000;
			if(pd_round[Target.x][Target.y]==round_index)return round[Target.x][Target.y];
			int re=0;
			Pos last;
			for(Pos now=Target;checkPos(now);last=now,now=Scheme[now.x][now.y])
			{
				if(dis2(Target,now)>speed)
				{
					re=distance(last,speed)+1;
					pd_round[Target.x][Target.y]=round_index;
					round[Target.x][Target.y]=re;
					return re;
				}
			}
			pd_round[Target.x][Target.y]=round_index;
			round[Target.x][Target.y]=1;
			return 1;
		}
}SPC;
//=======================================蝶舞トオトムーツキコッハ=========================================================================================




Console* console;
vector<const PUnit*> Observers,enemyHeroes,myHeroes;
const PPlayerInfo *INFO;

int cntBerserker,noEnemyLast,fighting;

int lastRush=-1,lastGold,sumLevel,lastChange,Round,levelupId[100],Sick[100],lastDanger,changeMineTimes,moveToEnemy[100][1000];
int Dizzy[100],Danger[100];
int enemyAround(Pos pos,int dis) {
	int res=0;
	for (int i=0;i<enemyHeroes.size();++i) {
		if (dis2(pos,enemyHeroes[i]->pos)<=dis) ++res;
	}
	return res;
}
int myAround(Pos pos,int dis) {
	int res=0;
	for (int i=0;i<myHeroes.size();++i) {
		if (dis2(pos,myHeroes[i]->pos)<=dis) ++res;
	}
	return res;
}
int minesAround(Pos pos,int dis) {
	int res=0;
	for (int i=0;i<7;++i) {
		if (dis2(pos,MINE_POS[i])<=dis) ++res;
	} 
	return res;
}
int sweep(const PUnit* Hero) {
	if (dis2(Hero->pos,MINE_POS[0])<=8) {
		for (int j=0;j<Observers.size();++j) {
			if (dis2(Hero->pos,Observers[j]->pos) <= Hero->range) {
				console->selectUnit(Hero);
				console->attack(Observers[j]);
				return 0;
			}
		}
	}
}
Pos last_pos=MINE_POS[0];
vector<Pos> Mines; int Cur,COUNT;

int MoveToEnemy(const PUnit* Hero,int cho) {
	if (moveToEnemy[Hero->id][Round-1] && moveToEnemy[Hero->id][Round-2]) return 0;
	moveToEnemy[Hero->id][Round]=1;
	console->move(enemyHeroes[cho]->pos,Hero);
}
int lastBeAttack(const PUnit* Hero) {
	const PBuff* Buff = Hero->findBuff("BeAttacked");
	return Buff && Buff->timeLeft>=2;
}
int inMap(Pos p) {return 0<=p.x&&p.x<150&&0<=p.y&&p.y<150;}
int X[]={1,-1,0,0}, Y[]={0,0,1,-1};
int myMove(Pos target,const PUnit* Hero) {
	Pos start=Hero->pos;
	
	
//	
//	
	vector<Pos> path,blocks,BanStays; path.clear(),blocks.clear(),BanStays.clear(); 
	
	for(int j = 0; j < INFO->units.size(); ++j)
        if (INFO->units[j].id != Hero->id)
        	if (inMap(INFO->units[j].pos)) blocks.push_back(INFO->units[j].pos);
    for(int k = 0; k < MINE_NUM; ++k)
        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
        blocks.push_back(MILITARY_BASE_POS[k]);
	
	if(Hero->canUseSkill("Blink")) {
//		printf("speed %dn",Hero->speed);
		SPC.build(start,81,blocks);
//		return 0;
		path=SPC.findOneStepRange(start,81,blocks);
		if (path.size()) {
			Pos tmp=path[0];
			for (int i=0;i<path.size();++i) {
				if (dis2(path[i],target)<dis2(tmp,target)) tmp=path[i];
//				printf("%d %dn",path[i].x,path[i].y);
			}
			console->selectUnit(Hero);
//			printf("tmp %d %dn",tmp.x,tmp.y);
			console->useSkill("Blink",tmp);
			return 0;
		}
	}	
	int speed = Hero->speed;
	if (speed>25 && myAround(Hero->pos,144)>1) speed=25; 
 	
	SPC.build(start,speed,blocks);
	path = SPC.findShortestPath(start,target,speed,blocks,BanStays);
	console->move(path,Hero);
//	if (Round<=25) {
//		vector<Pos> path; path.clear();
//		for (int i=1;i<=68;++i) {
//			if (i>=Hero->pos.x && i>=Hero->pos.y) {
//				console->move(Pos(i+6,i+6),Hero);
//				return 0;
//			}
//		}
//		console->move(target,Hero);
//		return 0;
//	}
//	console->move(target,Hero);

}
Pos outEnemyBase,posEnemyBase;
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
    console = new Console(map, info, cmd);
    INFO = &info;
    
    Round=info.round;
    vector<const PUnit*> myHealthyHeroes, mySickHeroes, Hammerguards, Masters, Berserkers, Scouters, Wilds; 
    Observers.clear(), enemyHeroes.clear(), myHeroes.clear();
    memset(Dizzy,0,sizeof(Dizzy));
    
    PUnit* myBase = NULL;
    PUnit* enemyBase = NULL;
    
    
    if (Mines.size() && (Mines[Cur]==MINE_POS[5] || Mines[Cur]==MINE_POS[6])) 
		outEnemyBase = console->camp()==0? (Mines[Cur]==MINE_POS[6]? Pos(147,110):Pos(118,134)):(Mines[Cur]==MINE_POS[6]? Pos(32,17):Pos(8,25));
    
    posEnemyBase = console->camp()==0? Pos(135,145):Pos(15,5);
    
    ++COUNT;
    ++noEnemyLast; 
//	blocks.clear();
//	for(int j = 0; j < info.units.size(); ++j)
//		blocks.push_back(info->units[j].pos);
//    for(int k = 0; k < MINE_NUM; ++k)
//        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
//            for(int j = - MINE_VOLUME + 1; j <= MINE_VOLUME; ++j)
//                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
//    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
//        blocks.push_back(MILITARY_BASE_POS[k]);
    
	sumLevel=0;
	
	for(int i = 0; i < info.units.size(); ++i)
    {
        if(info.units[i].isHero())
        {
            if(info.units[i].camp == info.camp)
			{
				sumLevel+=info.units[i].level;
				myHeroes.push_back((PUnit*)(&info.units[i]));
				if(info.units[i].hp<60 && info.units[i].hp < info.units[i].max_hp/3 && info.units[i].atk < 100 && !info.units[i].canUseSkill("HammerAttack") && !info.units[i].canUseSkill("SuperDead") && Mines[Cur]!=posEnemyBase)
				{
					mySickHeroes.push_back((PUnit*)(&info.units[i]));
					Sick[info.units[i].id]=1;
				} 
				else {
					myHealthyHeroes.push_back((PUnit*)(&info.units[i]));
					Sick[info.units[i].id]=0;
				}
				
                if(strcmp(info.units[i].name, "Hammerguard") == 0)
                {
                    Hammerguards.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Master") == 0)
                {
                    Masters.push_back((PUnit*)(&info.units[i]));
                }
				else if(strcmp(info.units[i].name, "Berserker") == 0)
                {
                    Berserkers.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Scouter") == 0)
                {
                    Scouters.push_back((PUnit*)(&info.units[i]));
                }
			}
            else {
            	noEnemyLast=0;
            	if (info.units[i].findBuff("Dizzy")) Dizzy[info.units[i].id] = 1;
            	if (info.units[i].canUseSkill("Sacrifice") || info.units[i].atk>100) Danger[info.units[i].id] = 1;
            	
            	enemyHeroes.push_back((PUnit*)(&info.units[i]));
            	
            	if (dis2(Mines[Cur],info.units[i].pos)<=64) COUNT=0;
            }
        }
        else if(info.units[i].isWild() && info.units[i].hp>0)
        {
        	enemyHeroes.push_back((PUnit*)(&info.units[i]));
        	Wilds.push_back((PUnit*)(&info.units[i]));
        }
		else if(strcmp(info.units[i].name, "MilitaryBase") == 0)
		{
			if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]);
			else enemyBase = (PUnit*)(&info.units[i]);
		} 
		else if (strcmp(info.units[i].name, "Observer")==0 && info.units[i].camp != info.camp) {
			Observers.push_back((PUnit*)(&info.units[i]));
		}
    }

   
    if(info.round==0) {
    	MAP = map;
		LPL.init(); 
    	
    	memset(levelupId,-1,sizeof(levelupId));
    	Mines.push_back(MINE_POS[0]);
    	Mines.push_back(MINE_POS[(console->camp()==0? 1:4)]);
    	Mines.push_back(MINE_POS[0]);
    	
    	Mines.push_back(MINE_POS[2]);
    	Mines.push_back(MINE_POS[0]);
    	
    	Mines.push_back(MINE_POS[(console->camp()==0? 4:1)]);
    	Mines.push_back(MINE_POS[0]);

    	last_pos=Mines[0];
    	console->chooseHero("Hammerguard");
    	console->chooseHero("Berserker");
    	console->chooseHero("Master");
    	console->chooseHero("Scouter");
    	delete console;
    	return;
    }
	if(myHeroes.size() < HERO_LIMIT)
    {
    	
    	if (myHeroes.size()==4) {
    		console->chooseHero("Hammerguard");
    	}
    	if (myHeroes.size()==5) {
    		console->chooseHero("Berserker");
    	}
    	if (myHeroes.size()==6) {
    		console->chooseHero("Scouter");
    	}
    	if (myHeroes.size()==7) {
    		console->chooseHero("Hammerguard");
    	}
	}
	
	
	
	if(myHeroes.size() == HERO_LIMIT)
	{
		int cho=-1;
		for (int i=0;i<myHeroes.size();++i) if (myHeroes[i]->level<5) {			
			if (dis2(myHeroes[i]->pos, myBase->pos) <= LEVELUP_RANGE) {
				if (cho==-1 || myHeroes[i]->level < myHeroes[cho]->level) cho=i;
			}
		}
		if (cho!=-1 && console->gold()-console->goldCostCurrentRound()-300>console->levelUpCost(myHeroes[cho]->level)) console->buyHeroLevel(myHeroes[cho]), levelupId[myHeroes[cho]->id]=info.round;

	
		if (console->gold() - console->goldCostCurrentRound() -300> 1000) {	
			int cho=-1;	
			for (int i=0;i<myHeroes.size();++i) if (myHeroes[i]->level<5) {
				if (cho==-1 || myHeroes[i]->level < myHeroes[cho]->level) cho=i;
			}

			if (cho!=-1) console->callBackHero(myHeroes[cho]);
		}
		
	}
	
//    if (info.round>=150 && info.round%30==0 && !enemyHeroes.size() && (Mines[Cur]!=MINE_POS[0]||COUNT>30)) 
	
	if (myAround(Mines[Cur],144)<=myHeroes.size()-2 && myAround(Mines[Cur],144)<=5) COUNT=0;
	int holdLast = info.round>200? 5+minesAround(Mines[Cur],144)*5:30;
	if (COUNT<40) holdLast += (Mines[Cur]==MINE_POS[0])*10;
	holdLast += (Mines[Cur]==posEnemyBase)*20;
	
	int lose=(info.round-lastChange>20+holdLast*2 && enemyAround(Mines[Cur],144)-myAround(Mines[Cur],144)>=2);
	
	
	if (info.round>=150 && COUNT>holdLast || lose || (lastRush!=-1 && !enemyBase && Round-lastRush>20 && Mines[Cur]==posEnemyBase))
	{
		lastChange=info.round;
		
		if (lose) {
			Pos goal = MINE_POS[rand()%2+5];
			Cur=Mines.size();
			for (int i=0;i<100;++i) Mines.push_back(goal);
			fighting=1;
		} else {
			if (fighting && myHeroes.size()==8) {
	    		if (Mines[Cur]==MINE_POS[6] || Mines[Cur]==MINE_POS[5]) {
	    			Mines.push_back(outEnemyBase);
	    			Cur=Mines.size()-1;
	    		}
	    		else if (Mines[Cur]==outEnemyBase) {
	    			lastRush=Round;
	    			Mines.push_back(posEnemyBase);
	    			Cur=Mines.size()-1;
	    		} 
				else {
					lastRush=-1;
	    			Mines.push_back(MINE_POS[rand()%2+5]);
	    			Cur=Mines.size()-1;
	    			last_pos=Mines[Cur];
	    		}
	    	} else {
	    		last_pos=Mines[Cur];
	    		Cur=(Cur+1)%Mines.size();
	    		COUNT=0;
	    	}
		}
//    	/(Mines[Cur]!=MINE_POS[0] && lastGold==console->gold() && myAround(Mines[Cur],25)>=myHeroes.size()-1 && !enemyAround(Mines[Cur],144))
//    	if (Mines[Cur]==MINE_POS[6] || Mines[Cur]==MINE_POS[5]) {
//    		Mines.erase(Mines.begin()+Cur,Mines.begin()+Cur+1);
//    		Cur%=Mines.size();
//    	}
//    	else Cur=(Cur+1)%Mines.size();
    	
    	
    	
    }
//    if (info.round-lastChange>25+holdLast && !myAround(Mines[Cur],100)) {
//    	lastChange=info.round;
//    	COUNT=0;
//    	Pos goal=MINE_POS[rand()%2+5];
//    	last_pos=goal;
//    	Cur=Mines.size();
//    	for (int i=0;i<100;++i) Mines.push_back(goal);
//    }
	
	int enemyAroundBase=0;
	for(int j = 0; j < enemyHeroes.size(); ++j) 
		if (dis2(myBase->pos,enemyHeroes[j]->pos)<=144) ++enemyAroundBase;
	
//	if (!enemyAroundBase) {
		
//		if(info.round >= 600 && info.round <= 700)
//        {
//            //cout << "xxn";
//			for(int i = 0; i < myHeroes.size(); ++i)
//			{
//				console->selectUnit(myHeroes[i]);
//				if(enemyBase) {
//					console->attack(enemyBase);
//					if(strcmp(myHeroes[i]->name, "Hammerguard") == 0) {		
//						console->useSkill("HammerAttack", enemyBase);
//					}
//					if(strcmp(myHeroes[i]->name, "Berserker") == 0) {
//						if (dis2(myHeroes[i]->pos, enemyBase->pos) <= 64
//						&& myHeroes[i]->canUseSkill("Sacrifice")) 
//							console->useSkill("Sacrifice",myHeroes[i]);
//					}
//				}
//				else console->move(MILITARY_BASE_POS[1-console->camp()], myHeroes[i]);
//			}
//			delete console;
//			return;
//		}
//	}
	

//	Pos MID=Scouters[0]->pos; int t=-1;
//	for (int i=0;i<myHealthyHeroes.size();++i) {
//		int cnt=0;
//		for (int j=0;j<myHealthyHeroes.size();++j) if (dis2(myHealthyHeroes[i]->pos,myHealthyHeroes[j]->pos)<=64) ++cnt;
//		if (cnt>t) t=cnt,MID=myHealthyHeroes[i]->pos;
//	}
	
	//====================================Master
	for(int i = 0; i < Masters.size(); ++i) if (!Sick[Masters[i]->id] && levelupId[Masters[i]->id]!=info.round)
	{
		console->selectUnit(Masters[i]);
		
		int fg=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) if (dis2(Masters[i]->pos,enemyHeroes[j]->pos)<=Masters[i]->range && Danger[enemyHeroes[j]->id]) {
			console->attack(enemyHeroes[j]);
			Danger[enemyHeroes[j]->id]=0;
			fg=1; break;
		}
		if (fg) continue;
		
		
		myMove(last_pos,Masters[i]);
		if (Mines[Cur]==posEnemyBase) {			
 			if (dis2(Masters[i]->pos,posEnemyBase)<=Masters[i]->range) if (enemyBase) console->attack(enemyBase);
			continue;
		}
//		console->move(MINE_POS[0]);
		int cho=-1;
		for(int j = 0; j < enemyHeroes.size(); ++j)
		{
			if(dis2(Masters[i]->pos, enemyHeroes[j]->pos) <= MASTER_RANGE)
			{
				if (enemyHeroes[j]->canUseSkill("Sacrifice") && i==0) {cho=j;break;}
				if (cho==-1||(strcmp(enemyHeroes[j]->name,"Berserker") && enemyHeroes[j]->hp<enemyHeroes[cho]->hp)) cho=j;
			}
		}
		if (cho==-1) {
			sweep(Masters[i]);
//			console->useSkill("Blink",MINE_POS[0]);
			continue;
		}
		console->attack(enemyHeroes[cho]);
	}
	
	//====================================Scouter
	for(int i = 0; i < Scouters.size(); ++i) if (!Sick[Scouters[i]->id] && levelupId[Scouters[i]->id]!=info.round)
	{
		console->selectUnit(Scouters[i]);
		int fg=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) if (dis2(Scouters[i]->pos,enemyHeroes[j]->pos)<=Scouters[i]->range && Danger[enemyHeroes[j]->id]) {
			console->attack(enemyHeroes[j]);
			Danger[enemyHeroes[j]->id]=0;
			fg=1; break;
		}
		if (fg) continue;
		
		myMove(Mines[Cur],Scouters[i]);
		if (Mines[Cur]==posEnemyBase) {
			if (dis2(Scouters[i]->pos,posEnemyBase)<=Scouters[i]->range) if (enemyBase) console->attack(enemyBase);
			continue;
		}
//		if (Scouters[i]->canUseSkill("SetObserver") && dis2(Scouters[i]->pos, MINE_POS[0]) <= 25) 
//		{
//			vector<Pos> target_pos;
//            target_pos.push_back(Scouters[i]->pos);
//            console->useSkill("SetObserver", target_pos);
////			console->useSkill("SetObserver", Scouters[i]->pos);
//			continue;
//		}

		
		int cho=-1;
		
		for(int j = enemyHeroes.size()-1; j >= 0; --j)
		{
			
			if(dis2(Scouters[i]->pos, enemyHeroes[j]->pos) <= SCOUTER_RANGE)
			{
				if (strcmp(enemyHeroes[j]->name, "Berserker") == 0 && enemyHeroes[j]->canUseSkill("Sacrifice")) {cho=j;break;}
				if (cho==-1||(strcmp(enemyHeroes[j]->name,"Berserker") && enemyHeroes[j]->hp<enemyHeroes[cho]->hp)) cho=j;
			}
		}
		if (cho==-1) {
			sweep(Scouters[i]);
			continue;
		}
		console->attack(enemyHeroes[cho]);
	}
	
	//====================================Hammerguarda
	for(int i = 0; i < Hammerguards.size(); ++i) if (!Sick[Hammerguards[i]->id] && levelupId[Hammerguards[i]->id]!=info.round)
	{
		
		
		console->selectUnit(Hammerguards[i]);
		
		
		
		
		if (Hammerguards[i]->canUseSkill("HammerAttack")) {
			int cho=-1;
			for(int j = 0; j < enemyHeroes.size(); ++j) {
				if(dis2(Hammerguards[i]->pos, enemyHeroes[j]->pos) <= 36 && !Dizzy[enemyHeroes[j]->id] && (strcmp(enemyHeroes[j]->name, "Berserker") || Danger[enemyHeroes[j]->id])) {
					if (cho==-1||enemyHeroes[j]->hp<enemyHeroes[cho]->hp) cho=j;
				} 
			}
			if (cho!=-1) {
				Dizzy[enemyHeroes[cho]->id] = 1;
				Danger[enemyHeroes[cho]->id] = 0;
				console->useSkill("HammerAttack", enemyHeroes[cho]);
				continue;
			}
		}
		
		

		
		myMove(Mines[Cur],Hammerguards[i]);
		
		if (Mines[Cur]==posEnemyBase) {
			if (dis2(Hammerguards[i]->pos,posEnemyBase) <= Hammerguards[i]->range) {
				if (enemyBase) console->attack(enemyBase);
			}
			continue;
		}
		
		int fg=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) if (dis2(Hammerguards[i]->pos,enemyHeroes[j]->pos)<=Hammerguards[i]->range && Danger[enemyHeroes[j]->id]) {
			console->attack(enemyHeroes[j]);
			Danger[enemyHeroes[j]->id]=0;
			fg=1; break;
		}
		if (fg) continue;
		
//		console->move(Mines[Cur]);
	
		int cho=-1;
		for(int j = 0; j < enemyHeroes.size(); ++j)
		{
			if(dis2(Hammerguards[i]->pos, enemyHeroes[j]->pos) <= 36)
			{
				
				if (cho==-1||(strcmp(enemyHeroes[j]->name,"Berserker") && enemyHeroes[j]->hp<enemyHeroes[cho]->hp)) cho=j;
			}
		}
		
//		if (cho!=-1 && Hammerguards[i]->canUseSkill("HammerAttack")) {
//			
//			continue;
//		}
//		
		
		
		
		
		
		
		if (cho==-1) continue;
		
		if (dis2(Hammerguards[i]->pos, enemyHeroes[cho]->pos) > 8) {
			MoveToEnemy(Hammerguards[i],cho); 
			continue;
		}
		console->attack(enemyHeroes[cho]);
//		console->useSkill("HammerAttack", enemyHeroes[cho]);
	}
	
	
	
	
	//====================================Berserker
    for(int i = 0; i < Berserkers.size(); ++i) if (!Sick[Berserkers[i]->id] && levelupId[Berserkers[i]->id]!=info.round)
	{
		console->selectUnit(Berserkers[i]);
		myMove(Mines[Cur],Berserkers[i]);
		
		
		
//		console->move(Mines[Cur]);
		if (Mines[Cur]==posEnemyBase) {
			if (dis2(Berserkers[i]->pos,posEnemyBase)<=Berserkers[i]->range) {
				if (Berserkers[i]->canUseSkill("Sacrifice") && !lastBeAttack(Berserkers[i])) {
					console->useSkill("Sacrifice",Berserkers[i]);
				}
				else if (enemyBase) console->attack(enemyBase);
			}
			continue;
		}

		int fg=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) if (dis2(Berserkers[i]->pos,enemyHeroes[j]->pos)<=Berserkers[i]->range && Danger[enemyHeroes[j]->id]) {
			console->attack(enemyHeroes[j]);
			Danger[enemyHeroes[j]->id]=0;
			fg=1; break;
		}
		if (fg) continue;
		
		
		int cho=-1;
		for(int j = 0; j < enemyHeroes.size(); ++j)
		{
			if(dis2(Berserkers[i]->pos, enemyHeroes[j]->pos) <= Berserkers[i]->range)
			{
				if (Berserkers[i]->atk>100) {
					if (cho==-1||enemyHeroes[j]->hp>enemyHeroes[cho]->hp) cho=j;
				} else {
					if (cho==-1||enemyHeroes[j]->hp<enemyHeroes[cho]->hp) cho=j;
				}
				
			}
		}
		if (Berserkers[i]->atk>100 && cho!=-1) {
			console->attack(enemyHeroes[cho]);
			continue;
		}
		
		int willBeAttack=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) {
			if(dis2(Berserkers[i]->pos, enemyHeroes[j]->pos) <= enemyHeroes[j]->range && enemyHeroes[j]->canUseSkill("Attack")) willBeAttack=1;
			
		}
		if (enemyAround(Berserkers[i]->pos,36)) cntBerserker++;
		else cntBerserker=0;
		if (lastBeAttack(Berserkers[i])) cntBerserker=0;
		
		
		if ((!willBeAttack || cntBerserker>=3) && Berserkers[i]->canUseSkill("Sacrifice")) {
			for(int j = 0; j < enemyHeroes.size(); ++j) {
				if(dis2(Berserkers[i]->pos, enemyHeroes[j]->pos) <= 36) {
					if (cho==-1||enemyHeroes[j]->hp>enemyHeroes[cho]->hp) cho=j;
				}
			}
			if (cho==-1) {sweep(Berserkers[i]);continue;}
			if (dis2(Berserkers[i]->pos,enemyHeroes[cho]->pos)<=Berserkers[i]->range) {
				console->useSkill("Sacrifice",Berserkers[i]);
			} else {
				MoveToEnemy(Berserkers[i],cho);
			}
			continue;
		}
		
		
		//========close to enemy
		if (cho==-1) {
			for(int j = 0; j < enemyHeroes.size(); ++j) {
				if(dis2(Berserkers[i]->pos, enemyHeroes[j]->pos) <= 36) {		
					if (cho==-1||(strcmp(enemyHeroes[j]->name,"Berserker") && enemyHeroes[j]->hp<enemyHeroes[cho]->hp)) cho=j;
				}
			}
			if (cho==-1) {sweep(Berserkers[i]);continue;}
			MoveToEnemy(Berserkers[i],cho);
		}
//		moveToEnemy[Berserkers[i]->id]=0;
//		if (Berserkers[i]->canUseSkill("Sacrifice")) {
//			console->useSkill("Sacrifice",Berserkers[i]);
//			continue;
//		}
		//chose MAX_HP
//		for (int j = 0; j < enemyHeroes.size(); ++j) {
//			if(dis2(Berserkers[i]->pos, enemyHeroes[j]->pos) <= 8+(Berserkers[i]->level)*4) {
//				if (enemyHeroes[j]->hp - Berserkers[i]->atk + enemyHeroes[j]->def <=0 && enemyHeroes[j]->hp > enemyHeroes[cho]->hp) cho=j;
//			}
//		}
		console->attack(enemyHeroes[cho]);
	}
	
	
	
//	
	for(int i = 0; i < mySickHeroes.size(); ++i) if (levelupId[mySickHeroes[i]->id]!=info.round)
	{
//		if(strcmp(mySickHeroes[i]->name, "Berserker") == 0 && mySickHeroes[i]->canUseSkill("Sacrifice")) continue;		
		if(mySickHeroes[i]->canUseSkill("HammerAttack")) continue;		
		console->selectUnit(mySickHeroes[i]);
		int enemy_around=0;
		for(int j = 0; j < enemyHeroes.size(); ++j) if (enemyHeroes[j]->isHero() && dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) <= 100) {
			enemy_around=1; break;
		}
		if (!enemy_around) 
		{
			console->move(Mines[1]);
//			console->move(mySickHeroes[i]->pos);
		}
		else {
			myMove(myBase->pos,mySickHeroes[i]);

//			else console->move(myBase->pos);
		}
	}
	
	
	

//	if (enemyAroundBase>=4) lastDanger=info.round;
//	if (!enemyAroundBase && lastDanger && myBase->hp < myBase->max_hp/5*4) {
//		Mines.push_back(MINE_POS[5+(changeMineTimes+1)%2]);
//		Cur=Mines.size()-1;
//		++changeMineTimes;
//		lastDanger=0;
//	}
	
//	if (myBase->hp < myBase->max_hp/4*3) ++enemyAroundBase;
//	if (myBase->hp < myBase->max_hp/4*2) ++enemyAroundBase;
//	if (myBase->hp < myBase->max_hp/4*1) ++enemyAroundBase;

	for(int i = 0; i < myHealthyHeroes.size() && enemyAroundBase; ++i) 
	{
		--enemyAroundBase;
        if(dis2(myHealthyHeroes[i]->pos, MILITARY_BASE_POS[console->camp()]) > MILITARY_BASE_RANGE)
        {	
			
            console->callBackHero(myHealthyHeroes[i]);
            console->move(MILITARY_BASE_POS[console->camp()], myHealthyHeroes[i]);
        }
	}
	
	lastGold=console->gold();
	delete console;
}




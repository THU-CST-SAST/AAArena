#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

static int heroRank = 0;
static int newHeroFirst = 1;
static int attackArg = 400, supportRange = 1000, monsterAvoid = 10000, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100;
static int miningArg = 150, sameMineArg = 10, centerMineArg = 50;
static int goBackHomeHp = 50, goBackHomeArg = 10000;
static int hammerDizzy = 50;
static int strategyDisabled = - 1<<30;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter","Hammerguard", "Master", "Berserker", "Scouter"};
static const Pos Hero_Pos[8] = {Pos(19,16),Pos(24,12),Pos(22,14),Pos(21,15),Pos(19,16),Pos(24,12),Pos(22,14),Pos(21,15)};


bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //控制ai的主类
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();
	void buyNewHero();
	void action();
	void mymove(const Pos& target, const PUnit* ptr);
	void myfindShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path);
	int myHeros_size,homeenemy;
	PUnit *myBase, *enemyBase;
    const PPlayerInfo* info;

private:
	Console* console;
    const PMap* map;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;
};
static AIController *controller;

void AIController::mymove(const Pos& target, const PUnit* ptr)
{
    //if(ptr == NULL)  ptr = console->selected;
    if(ptr == NULL)
    {
        std::cout << "Error:Do not select a unit when using Console." << std::endl;
        return;
    }
    vector<Pos> blocks,path;
    blocks.clear();
    path.clear();
    for(int j = 0; j < info->units.size(); ++j)
        if (info->units[j].id != ptr->id)
            blocks.push_back(info->units[j].pos);
    for(int k = 0; k < MINE_NUM; ++k)
        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
        blocks.push_back(MILITARY_BASE_POS[k]);
    Pos destination = (Pos)target;
   myfindShortestPath(*map, ptr->pos, destination, blocks, path);
   

   console->move (path, ptr);
}

void  AIController::myfindShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径
{
	static int vst[MAP_SIZE][MAP_SIZE];
	static Pos Q[MAP_SIZE * MAP_SIZE + 1], Q_prior[MAP_SIZE][MAP_SIZE];
	static int last_dir[MAP_SIZE*MAP_SIZE+1];
	static int countF = 0;
    
    PMap map0 = map;
    int _sz = blocks.size();

    ++countF;
    _path.clear();
    int min = 1000000;
    Pos nearest = start;
    for (int i=0; i<_sz; ++i)
    {
        if (checkPos(blocks[i]))
            vst[blocks[i].x][blocks[i].y] = countF;
    }
    if (!checkPos(start) || !checkPos(dest))
    {
        _path.push_back(Pos());
        return;
    }
    vst[start.x][start.y] = vst[dest.x][dest.y] = countF - 1;

    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    last_dir[0]=0;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) dir_ord[i] = i;
        swap(dir_ord[last_dir[front]],dir_ord[3]);
        //random_shuffle(dir_ord, dir_ord+4);

        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                last_dir[rear] = dir_ord[i];
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }

    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }
}

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual int countWorth() = 0; //计算某种策略的实行价值
	virtual void work() = 0; //实现这种策略
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class Attack:public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};


class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class AvoidAttack:public Strategy 
{
public:
	AvoidAttack(PUnit* worker,Pos target) {setWorker(worker);setTarget(target);name = "AvoidAttack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
private:
	Pos target;
};


class CallBackHome:public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

/*
class StealHome:public Strategy 
{
public:
	StealHome(PUnit* worker) {setWorker(worker);name = "StealBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};
*/

class GoMining:public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};

class Tempt:public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //默认选择回家的策略
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	homeenemy = 0;
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
		{
			enemyHeros.push_back(enemyUnits[i]);
			if (dis2(enemyUnits[i]->pos,myBase->pos)<=50)
				homeenemy++;
		}
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
	myHeros_size = myHeros.size();
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		if (!strcmp(heroToLevelUp[i]->name,"Hammerguard") || !strcmp(heroToLevelUp[i]->name,"Master")) 
		console->buyHeroLevel(heroToLevelUp[i]);
}

void AIController::buyNewHero()
{
	//没有判断是否召唤成功，故如果没成功召唤顺序就会乱掉
	if (heroRank >= 8)
	{
		newHeroFirst = 0;
		return;
	}
	int newHero = heroRank % 8;
	Pos pos = Hero_Pos[newHero];
	if (info->player==1)
		pos = Pos(150,150) - pos;
	console->chooseHero(HERO_NAME[newHero],pos);
	heroRank ++ ;
}

void AIController::action()
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
	{
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
		if (enemyBase!=NULL)
			allStrategy.push_back(new Attack(myHeros[i], enemyBase));
	}
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));

	//for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new StealBackHome(myHeros[i]));
	//for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new AvoidAttack(myHeros[i],MINE_POS[0]));

	Pos deta(0,0);
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < 1;++j)//MINE_NUM; ++j)
		{
		//	if (info->round>800)
		//	{
	//			allStrategy.push_back(new GoMining(myHeros[i],MILITARY_BASE_POS[1-info->player]));
	//		}
	//		else
				allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]+deta));
		}
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setConsole(console);

	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)
			AIHeroList[j]->setStrategy(allStrategy[i]);

	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	mStrategy->work();
}

int AvoidAttack::countWorth()
{
	this->worth = 0;

	if(worker->canUseSkill("Attack"))
	{
		this->worth = strategyDisabled;
		return this->worth;
	}
	/*else if(dis2(worker->pos,target->pos) <= supportRange)
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
		if(dis2(worker->pos,target->pos) > worker->range)
			this->worth -= outOfRangeArg;
		if(target->isWild()) this->worth -= monsterAvoid;
	}*/
	return this->worth;
}

void AvoidAttack::work()
{
	console->selectUnit(worker);
	controller->mymove(target, worker);
}

int Attack::countWorth()
{
	this->worth = 150;
	if (!strcmp(target->name,"MilitaryBase"))
	{
		this->worth ++;
		return this->worth;
	}
	if(target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
	//if (!worker->canUseSkill("Attack"))
	//	this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos) <= supportRange)
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		if ((worker->speed>=target->speed || dis2(worker->pos,target->pos) <= worker->range)&&worker->canUseSkill("attack"))
			this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
		
		//if (worker->canUseSkill("attack"))
		//	this->worth += 50;
		

		this->worth += (800-target->hp);

		if (!strcmp(target->name,"Hammerguard")) this->worth+=150;

		if(dis2(worker->pos,target->pos) > worker->range)
			this->worth -= outOfRangeArg;
		if(target->isWild()) this->worth -= monsterAvoid;
		//this->worth+=144-dis2(target->pos,MINE_POS[0]);
		if (controller->info->round<20)
			this->worth-=dis2(target->pos,MINE_POS[0])*20;

	}
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

int UseSkill::countWorth()
{
	this->worth = 0;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	if (target->isWild())
		this->worth -= monsterAvoid;
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				//此处写对技能的处理，由于样例ai故非常简略
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
						if(!strcmp(target->name, "HammerAttack")) 
							this->worth+=150;
						if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
							this->worth -= outOfRangeArg;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
					}
				}
				/*else if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos)>target->range && dis2(worker->pos,target->pos)<= 100)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 2 * attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
				}*/
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

int Tempt::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void Tempt::work()
{
}

int GoMining::countWorth()
{
	this->worth = miningArg;
	if(target == MINE_POS[0] && controller->info->round>20)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			if(AIHeroList[i]->getStrategy() != NULL)
				if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
				{
					GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
					if(otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;
				}
	}
	this->worth -= dis(worker->pos, target);
	if(target == MINE_POS[0])
		this->worth += centerMineArg;
	return this->worth;
}

void GoMining::work()
{
	console->selectUnit(worker);
	controller->mymove(target,worker);
}

int GoBackHome::countWorth()
{
	this->worth = 0;
	if(worker->hp <= goBackHomeHp && !strcmp(worker->name, "Scouter") != 0) this->worth += goBackHomeArg;
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	//controller->mymove(Pos(115,90),worker);
	controller->mymove(console->getMilitaryBase()->pos,worker);

	//if (dis2(worker->pos,Pos(35,60))<dis2(worker->pos,Pos(115,90)))
	//	controller->mymove(Pos(35,60),worker);
	//else 
	//	controller->mymove(Pos(115,90),worker);
}


/*int StealBackHome::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void StealBackHome::work()
{
	console->callBackHero(worker);
}
*/
int CallBackHome::countWorth()
{
	this->worth = 0;
	if (controller->homeenemy>=2 && !strcmp(worker->name, "Hammerguard") && dis2(worker->pos,controller->myBase->pos)>144)
	{
		controller->homeenemy--;
		this->worth += 10000;
	}
	return this->worth;
}

void CallBackHome::work()
{
	console->callBackHero(worker);
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{

	srand(5);
	controller = new AIController(map,info,cmd);

	heroRank = controller->myHeros_size;
	
	if(info.round == 0)
	{
		for(int i = 1; i <= 4; ++i)
			controller->buyNewHero();
		return;
	}
	if(newHeroFirst)
	{
		controller->buyNewHero();
	}
	else
	{
		controller->levelupHero();
	}
	controller->action();
	delete controller;
}
#include "console.h"
#include "sdk.h"
#include "filter.h"
#include <iterator>
#include <vector>
#include <iterator>
#include <array>
#include <map>
#include <sstream>
#include <cassert>
#include <cstdlib>
#include <iostream>
using namespace std;
/****************************************
*这是一个很长但是很弱的样例AI
*我只是试图寻找一种更好的控制代码的方案，而不是展示一个很强大的AI。根据以往的经验，到了决赛前后选手们的代码长度都在数千行。这么多代码在同一个文件中显然非常难以管理。到了那个时候你可能已经忘记了每一段代码到底是干什么的，可能会出现很多奇怪的bug。
*因此我选择尝试构建一个框架来组织起AI的整个行为。
*********************************************
*Condutor是全局的分析器，它在整场游戏中只创建一个，作为一个静态对象存在。这会带来一个问题就是不能在本地运行同一个AI文件进行一场对战，不过这应该并不关键。如果你真的想要同一个AI对战，你可以复制一份，重命名一下就解决了。
*Soldier表示一个英雄。正如文档中所述，每一回合同一个单位Logic传来的PUnit都是全新的，所以我需要另外写一个类来表示一个单位，这个类的对象是全局不变的。
*Team表示若干个Soldier组成的集合，我的设想中AI行动的基本单位都是Team。你可以预先写好一个Team如何去移动而不互相冲突，如何进行一场团队作战。然后在更高的层面上你就可以简单地反复调用这些函数。这可以让你把更多的精力花在思考战略上同时还不会引入很多bug。
*Team中有一个成员叫action。这个是用来干什么的呢？在以往的AI中，往往都是每回合分析局面，然后做出新的决策。而你上一回合所做的决策很难被一以贯之。这个action就是用来记录你所做的决策，然后在之后的考虑中你就可以知道之前的决策是什么，是要继续还是重新决策。使用在Global Function那一部分，我已经实现了一些方法帮助你分析它。
*GoldField是金矿，Base是基地。他们的作用和soldier一致。
*Field是我设想的关键。他表示一个事件，比如发现敌人，发现金矿等等，你可以更加细化它们。首先在每一回合分析出所有的Filed。然后你的决策就是针对这些Field来进行反应。你可以不断细化产生Field的条件，通过这种方式来引入新的决策。在这个过程中，你的代码都是在一个固定的框架下增加，引入新bug，破坏之前代码成果的可能性将大大降低。
*没有Field的时候怎么办呢？在Condutor有一个explore函数，表示没有去应对Field的单位将做什么。
********************************************
*如果你觉得这份样例不合你的胃口，那么我希望它能给你一种新的思维方式，帮助你找到更好的AI编写方法。
*如果你想要在这份框架的基础上改动来创造你自己的AI，我的建议是修改Soldier和Team的move和attack，让他们变得复杂起来，这里决定着你的AI的战术水平。另外就是Condutor中分析Field和应对Field，以及explore，这是体现决策的地方。
*****************************************/
/*********************************************************************
 *                              Some const variable
**********************************************************************/
const int HeroTypeNum = 4;//英雄种类
const int MonsterTypeNum = 2;//野怪种类
const int UnitTypeNum = 8;//单位种类
const int GeneralView = 144;//普遍单位的视野都是144，这里我用它来做一些大致的估计。
const int GeneralSpeed = 15;
const int GeneralOneStepReach = 144;//同上，只是用来做一个大概的估计。
enum UnitType:int {Hammerguard = 0, Master = 1, Berserker, Scouter, Mine, MilitaryBase, Dragon, Roshan, Unknown};//定义了单位的类型。只是为了避免一直使用字符串，
enum {NORMAL, DIRECT, FASTMOVE};//移动的模式，在Team：：move中用到。NORMAL表示简单的移动，下一回合不继续。DIRECT表示下一回合无论如何都将继续向原定的一步走不完的那个目标前进。你可以定义更多的移动方案，或者去掉这个奇怪的机制。
const array<string, UnitTypeNum> unitName{{"Hammerguard", "Master", "Berserker", "Scouter", "Mine", "MilitaryBase", "Dragon", "Roshan"}};//枚举单位类型的字符串，和上面定义的数值对应。
const array<int, HeroTypeNum> cost{{NEW_HAMMERGUARD_COST, NEW_MASTER_COST, NEW_BERSERKER_COST, NEW_SCOUTER_COST}};//和UnitType对应。
#define SIZE(x) (int(x.size()))//为了方便地把size（）返回的无符号值转化为有符号值。
bool operator< (const Pos&, const Pos&);//为了使用std::map<Pos,*>,并没有实际的意义。
//#define LOCAL//所有系统调用最好都用这个宏包起来，就像下面定义fout那样。当你想要向网站上提交时，只要注释掉这一行就可以了。
#ifdef LOCAL
#include <fstream>
static ofstream fout("log.txt");
#endif
#ifdef LOCAL
/*****************************************************
*               Log Declarotion
******************************************************/
class Log
//一个用来输出调试的类。
{
public:
    Log (const string& _str, ostream& = cout);
    ~Log ();
private:
    int startTime;
    ostream& os;
    string str;
};
#endif
/************************************************************
 *                              Soldier Declaration
************************************************************/
struct Soldier
{
    Soldier (PUnit* = nullptr);
    void move(const Pos& pos);
    void attack (const Soldier& target, const string& command = "attack");//command表示攻击的模式，因为我设想的是Soldier 的攻击都是在Team中进行，Team可能希望这个单位实现某种目的比如眩晕，引开等等，通过这个字符串就可以告知这个Soldier。

    UnitType type;
    PUnit* ptr;
    int id;
};
/*********************************************************************
 *                              GoldField Declaration
**********************************************************************/
struct GoldField
{
    int id;
    int energy;//-1 unknown
    Pos pos;//the pos of the mine
    vector<Soldier*> myUnits;//附近的己方单位
    vector<Soldier*> otherUnits;
    Soldier* monster;
};
/*********************************************************************
 *                              Base Declaration
**********************************************************************/
struct Base
{
    PUnit* ptr;
    Pos pos;
    int hp;
};
/*********************************************************************
 *                              Team Declaration
**********************************************************************/
struct Team
{
    Team (const vector<Soldier*>&);
    ~Team ();
    void move (Geometry*, int mode = NORMAL);//后面的表示移动模式。
    void attack (Soldier*);
    void attack (vector<Soldier*>&);
    void defence (Geometry*);

    vector<string> action;
    Geometry* target;//set by move();上回合移动的目标
    //mine:id 在采矿，矿的id
    //offense 在进攻对方基地
    //defence 在防守己方基地
    //moveMode:mode 在移动，移动模式
    //round:round 上一个action的回合数。
    vector<Soldier*> soldiers;
};
/*********************************************************************
 *                              Field Declaration
**********************************************************************/
struct Field
{
    vector<Geometry*> geos;//发生的的区域
    bool contain (const Pos&);

    vector<string> event;//描述发生的事件
};
/*********************************************************************
 *                              Soldier Declaration
**********************************************************************/
class Condutor
{
public:
    Condutor ();
    void updateSituation();
    void start ();
protected:
    //根据当前局面分析出所有的Field
    void analyseSituation ();
    //判断上一回合的操作是否继续下去
    void goingOn ();
    //组织新的Team来应对Field
    void organizeNewTeamsForField();
    //尝试购买新英雄。
    void buyNewSoldier ();
    //尝试去升级。
    void levelUp ();
    //called in updateSituation
    void updateMyUnits ();
    void updateGoldFieldAndMonsterStatus ();
    void updateEnemyStatus ();
    void explore ();
    //about team
    Team* buildTeam (const vector<Soldier*>&);//组建新Team，组入Team的Soldier会被移出availSoldiers;
    Team* buildTeam (const Soldier*);
    //解散一个Team,soldier重新进入availSoldiers;
    void breakUpTeam (Team*&);
    //解散所有的这一回合还没有执行action的Team。你需要及时更新action中的round。
    void breakUpOldTeams ();
    //把一些单位按特定条件（现在是只看距离）划分进一些Team中。
    vector<Team*> buildIntoTeams (const vector<Soldier*>&);
protected:
    //clear every round
    vector<Field*> fields;//当前回合的Field
    vector<string> status;//记录当前回合的一些状态。
    //因为你的决策是顺序执行的，但是你之前的决策也许希望去影响之后的决策，比如你在一开始决定需要攒一点钱而不是全花光，你就在其中加入remain:1000，之后买英雄的时候就知道需要留下这么多钱。
    //blockLevelUp:id 不希望离开战场回去升级的英雄
    //remain:gold 需要攒下的钱

    //static
    map<Pos, GoldField*> pos2mine;//通过pos得到一个Mine*
    map<int, Soldier*> id2soldier;//通过id得到一个Soldier*

    vector<GoldField*> mines;
    vector<Team*> teams;
    vector<Soldier*> availSoldiers;
    vector<Soldier*> enemys;
    vector<Soldier*> monsters;
    Base* base;
    Base *enemyBase;
    vector<Soldier*> allSoldiers;
};
/*********************************************************************
 *                              Global
**********************************************************************/
//Warning: You can't define a variable here. Only pointer is accepted.
//Eg. if you write "static Condutor consutor;", logic won't load your ai successfully.
static Condutor* condutor = nullptr;
static Console* console = nullptr;
//在下面的函数中，表示没有找到一个数值时的默认返回值是1<<30,而不是0.因为0可能有意义。
//在一个字符串列表中寻找key为str的第一个value
int value (const string& str, const vector<string>& status);
//在一个字符串列表中寻找key为str的所有value
vector<int> values (const string& str, const vector<string>& status);
//列表中更新key为str的第一个value，没有则加入之。
void updateValue (const string& name, vector<string>& status, int newValue);
//删除列表中前n个key为name的项，默认全部删除。
void removeEntry (const string& name, vector<string>& status, int n = -1);
//删除列表中key为name，value为value的特定一项
void removeEntry (const string& name, int value, vector<string>& status);
//插入一个新的项，默认没有value
void insertEntry (const string& key, vector<string>& status, int value = 1 << 30);
//判断对应键值的项是否存在
bool exist (const string&, std::vector<string>& );
/*********************************************************************
 *                              main
**********************************************************************/
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
#ifdef LOCAL
    fout << "round:" << info.round << " start" << endl;
#endif
    console = new Console (map, info, cmd);
    if (console->round() == 0)
        condutor = new Condutor();
    condutor->updateSituation ();
    condutor->start();
    delete console;
#ifdef LOCAL
    for (auto op: cmd.cmds)
    {
        fout << "id:" << op.id << ";type:" << op.type << ";targets:";
        for (auto pos: op.targets)
            fout << pos << " ";
        fout << endl;
    }
    fout << "round:" << info.round << " end" << endl;
#endif
}
/*********************************************
*           Global function
**********************************************/
bool operator< (const Pos& a, const Pos& b)
{
     return a.x + a.y < b.x + b.y;
}
UnitType name2type (const string& name)
{
    if (lowerCase(name) == lowerCase("Hammerguard"))
        return Hammerguard;
    else if (lowerCase(name) == lowerCase("Master"))
        return Master;
    else if (lowerCase(name) == lowerCase("Berserker"))
        return Berserker;
    else if (lowerCase(name) == lowerCase("Scouter"))
        return Scouter;
    else if (lowerCase(name) == lowerCase("GoldField"))
        return Mine;
    else if (lowerCase(name) == lowerCase("MilitaryBase"))
        return MilitaryBase;
    else if (lowerCase(name) == lowerCase("Dragon"))
        return Dragon;
    else if (lowerCase(name) == lowerCase("Roshan"))
        return Roshan;
}
//假定一个字符串是round:12 那么冒号前的round就是key，冒号后的12就是value
string getKey (const string& str)
{
    string res;
    for (auto c: str)
        if (c != ':')
            res += c;
        else
            break;
    return move(res);
}
string getValue (const string& str)
{
    string s = str;
    for (int i = 0; i < SIZE(s); ++i)
    {
        char tmp = s[i];
        s.erase(begin(s) + i--);
        if (tmp == ':')
            break;
    }
    return move(s);
}
//简单地实现字符串和数值的相互转换。
int string2int (const string& str)
{
    if (str.empty())
        return 1 << 30;
    int res = 1 << 30;
    stringstream in(str);
    in >> res;
    return res;
}
string int2string (int v)
{
    stringstream in;
    in << v;
    return move(in.str());
}
//在一个字符串列表中寻找key为str的第一个value
int value (const string& str, const vector<string>& status)
{
    int res = 1 << 30;
    for (auto s: status)
        if (getKey(s) == str)
        {
            res = string2int(getValue(s));
            break;
        }
    return res;
}
//在一个字符串列表中寻找key为str的所有value
vector<int> values (const string& str, const vector<string>& status)
{
    vector<int> res;
    for (auto s:status)
        if (getKey(s) == str)
            res.push_back(string2int(getValue(str)));
    return move(res);
}
//在一个字符串列表中更新key为str的第一个value，没有则加入之。
void updateValue (const string& name, vector<string>& status, int newValue)
{
    bool find = false;
    for (auto str: status)
    {
        if (getKey(str) == name)
        {
            str = name + int2string(newValue);
            find = true;
            break;
        }
    }
    if (!find)
        status.push_back (name + ":" + int2string(newValue));
}
void removeEntry (const string& name, vector<string>& status, int maxNum)
{
    if (maxNum < 0)
        maxNum = status.size();
    for (auto iter = begin(status); iter != end(status);)
    {
        if (maxNum == 0)
            return;
        if (getKey(*iter) == name)
        {
            --maxNum;
            status.erase (iter);
        }
        else
            ++iter;
    }
}
void removeEntry (const string& name, int value, vector<string>& status)
{
    string entry;
    if (value != 1 << 30)
        entry = name + ":" + int2string(value);
    else
        entry = name;
    for (auto iter = begin(status); iter != end(status); ++iter)
    {
        if (*iter == entry)
        {
            status.erase (iter);
            return;
        }
    }
}
void insertEntry (const string& key, vector<string>& status, int value)
{
    if (value < 1 << 30)
        status.push_back (key + ":" + int2string(value));
    else
        status.push_back (key);
}
bool exist (const string& name, vector<string>& status)
{
    for (auto str: status)
    {
        if (getKey(str) == name)
        {
            return true;
        }
    }
    return false;
}
#ifdef LOCAL
/**********************************************
*                 Log Definition
***********************************************/
Log::Log (const string& _str, ostream& _os): str(_str), os(_os)
{
    os << str << " " << "start" << endl;
    startTime = clock ();
}
Log::~Log ()
{
    os << str << " " << "end, time cost:" << clock() - startTime <<  endl;
}
#endif
/*********************************************************************
 *                              Condutor Definition
**********************************************************************/
Condutor::Condutor ()
{
    //clear
    fields.clear();
    status.clear();
    teams.clear();
    availSoldiers.clear();
    enemys.clear();
    base = new Base;
    enemyBase = new Base;
    enemyBase->hp = base->hp = 5000;
    base->pos = MILITARY_BASE_POS[console->camp()];
    enemyBase->pos = MILITARY_BASE_POS[1-console->camp()];
    //add mine
    for (int i = 0; i < MINE_NUM; ++i)
    {
        GoldField* mine = new GoldField;
        mine->id = i;
        mine->energy = -1;
        mine->pos = MINE_POS[i];
        pos2mine[mine->pos] = mine;
        mine->monster = nullptr;
        mine->myUnits.clear();
        mine->otherUnits.clear();
        mines.push_back(mine);
    }
    for (int i = 0; i < 100; ++i)
        id2soldier[i] = nullptr;
}
void Condutor::updateSituation ()
{
    //the order of calling these three function is important and shouldn'd be changed
    updateMyUnits ();
    updateEnemyStatus ();
    updateGoldFieldAndMonsterStatus ();
}
void Condutor::start()
{
    //analyse the situation and build filelds
    analyseSituation ();
#ifdef LOCAL
    fout << "fileds" << endl;
    for (auto f:fields)
    {
        for (auto g: f->geos)
            g->output (fout);
        for (auto e: f->event)
            fout << e << ";";
        fout << endl;
     //
    }
#endif
    goingOn ();
    //break up teams without new action
    breakUpOldTeams ();
#ifdef LOCAL
    fout << "teams" << endl;
    for (auto team: teams)
    {
        fout << "id:";
        for (auto s: team->soldiers)
            fout << s->id << " ";
        fout << "; action:";
        for (auto a:team->action)
            fout << a << ";";
        fout << endl;
    }
#endif
    //organize the availble heros to new Teams to respound to events
    organizeNewTeamsForField();
    //get new Soldiers
    buyNewSoldier ();
     //make teams for upgrading
    levelUp ();
    //available units to explore
    explore ();
}
void Condutor::analyseSituation ()
{
    fields.clear();
    vector<Soldier*> es = enemys;
    for (auto e: monsters)
        es.push_back (e);
    for (auto enemy: es)//遍历敌人
    {
        if (enemy->ptr == nullptr || (console->getBuff("Reviving", enemy->ptr) != 0))
            continue;
        //不重复发现事件
        bool found = false;
        for (auto field: fields)
        {
            if (field->contain (enemy->ptr->pos))
            {
                found = true;
                break;
            }
        }
        if (found)
            continue;
        Field* field = new Field;
        //如果不在基地
        if (dis2(base->pos, enemy->ptr->pos) > GeneralView)
        {
            field->geos.push_back(new Circle(enemy->ptr->pos, GeneralView * 2));
            insertEntry ("enemyFound", field->event);
        }
        //否则
        else
        {
            field->geos.push_back (new Circle(base->pos, GeneralView * 2));
            insertEntry ("baseAttacked", field->event);
        }
        fields.push_back (field);
    }
    //遍历金矿
    for (auto mine: mines)
    {
        if (mine->myUnits.size() && !mine->otherUnits.size() && mine->monster != nullptr && mine->monster->ptr == nullptr && mine->energy > 0)
        {
            Field* field = new Field;
            field->geos.push_back(new Circle(mine->pos, GeneralView));
            insertEntry ("mineClear", field->event, mine->id);
            insertEntry ("mineId", field->event, mine->id);
            fields.push_back (field);
        }
    }
    UnitFilter filter;
    filter.setTypeFilter("militarybase");
    if (console->enemyUnits(filter).size())
    {
        Field* field = new Field;
        field->geos.push_back (new Circle(enemyBase->pos, GeneralView * 2));
        insertEntry ("offense", field->event);
        fields.push_back (field);
    }
}
void Condutor::goingOn ()
{
    //还只会决定是否继续上一回合的移动。
    for (auto team: teams)
    {
        if (team->target == nullptr || value("modeMode", team->action) == 1 << 30 || value("round", team->action) == console->round() || value("moveMode", team->action) == NORMAL)
            continue;
        team->move (team->target, DIRECT);
    }
}
void Condutor::organizeNewTeamsForField ()
{
    for (auto f: fields)
    {
        if (exist("enemyFound", f->event))
        {
            vector<Soldier*> s, e;
            for (auto ptr: availSoldiers)
            {
                if (f->contain(ptr->ptr->pos))
                    s.push_back (ptr);
            }
            if (s.size() == 0)
            {
                cout << "warning: no myUnits found in field area" << endl;
                continue;
            }
            Team* t = buildTeam (s);
            for (auto ptr: enemys)
            {
                if (ptr->ptr != nullptr && f->contain(ptr->ptr->pos))
                    e.push_back (ptr);
            }
            for (auto ptr: monsters)
            {
                if (ptr->ptr != nullptr && f->contain(ptr->ptr->pos))
                    e.push_back (ptr);
            }
            t->attack (e);
        }
        else if (value ("mineClear", f->event) != 1 << 30)
        {
            Team* t = buildTeam (availSoldiers.front());
            if (t == nullptr)
                break;
            t->move (new Circle(mines[value("mineId", f->event)]->pos, MINING_RANGE));
            insertEntry ("mine", t->action, value ("mineClear", f->event));
        }
        else if (exist ("baseAttacked", f->event))
        {
            Team* t = buildTeam (availSoldiers);
            t->move(f->geos.front());
            insertEntry ("moveMode", t->action, FASTMOVE);
            insertEntry ("modeRoundLimit", t->action, 3);
        }
        else if (exist("offense", f->event))
        {
            vector<Soldier*> s, e;
            for (auto ptr: availSoldiers)
            {
                if (f->contain(ptr->ptr->pos))
                    s.push_back (ptr);
            }
            if (s.size() == 0)
            {
                cout << "warning: no myUnits found in field area" << endl;
                continue;
            }
            Team* t = buildTeam (s);
            insertEntry ("offense", t->action);
            Soldier* eBase = new Soldier (enemyBase->ptr);
            t->attack (eBase);
            delete eBase;
        }
    }
}
void Condutor::buyNewSoldier ()
{
    array<int, HeroTypeNum> heroNum{{0, 0, 0, 0}};
    for (auto soldier: allSoldiers)
        ++heroNum[soldier->type];
    int sum = 0;
    for (auto num: heroNum)
        sum += num;
    while (sum < HERO_LIMIT)
    {
        int remain = value("remainGold", status);
        if (remain == 1 << 30)
            remain = 0;
        UnitType toBuy = Unknown;
        int minNum = 1 << 30;
        for (int i = 0; i < SIZE(heroNum); ++i)
            if (heroNum[i] < minNum)
            {
                toBuy = UnitType(i);
                minNum = heroNum[i];
            }
        if (console->gold() - console->goldCostCurrentRound() > cost[toBuy] * (heroNum[toBuy] + 1) + remain)
        {
            console->chooseHero (unitName[toBuy]);
            ++heroNum[toBuy];
            ++sum;
        }
        else
            break;
    }
}
void Condutor::levelUp ()
{
    vector<int> levelUpBlocks = values("blockLevelUp", status);
    for (auto ptr = begin(availSoldiers); ptr != end(availSoldiers); )
    {
        int remain = value("remainGold", status);
        if (remain == 1 << 30)
            remain = 0;
        if (find(begin(levelUpBlocks), end(levelUpBlocks), (*ptr)->id) != end(levelUpBlocks))
            continue;
        int level = console->unitArg("level", "c", (*ptr)->ptr);
        bool erased = false;
        while (level < HERO_LEVEL_LIMIT && console->gold() - console->goldCostCurrentRound() > remain + console->levelUpCost(level))
        {
            if (dis2((*ptr)->ptr->pos, base->pos) > LEVELUP_RANGE)
            {
                Team* newTeam = buildTeam ((*ptr));
                erased = true;
                newTeam->move (new Circle(base->pos, LEVELUP_RANGE), NORMAL);
                break;
            }
            ++level;
            console->buyHeroLevel((*ptr)->ptr);
        }
        if (!erased)
            ++ptr;
    }
}
void Condutor::explore ()
{
    vector<int> blocks;
    vector<Soldier*> toExplore = availSoldiers;
    for (auto iter = begin(toExplore); iter != end(toExplore); ++iter)
    {
        if (find(begin(blocks), end(blocks), (*iter)->id) != end(blocks))
            toExplore.erase(iter);
    }
    map<int, bool> freeMine;
    for (int i = 0; i < MINE_NUM; ++i)
    {
        if (mines[i]->energy < 0 || mines[i]->energy > 0)
            freeMine[i] = true;
        else
            freeMine[i] = false;
    }
    for (auto team: teams)
    {
        int id;
        if ((id = value("mine", team->action)) < MINE_NUM)
            freeMine[id] = false;
    }

    vector<Team*> exploreTeams = buildIntoTeams(toExplore);

    for (auto team = begin(exploreTeams); team != end(exploreTeams); )
    {
        int rank = -1;
        for (int i = 0; i < MINE_NUM; ++i)
            if (freeMine[i])
            {
                rank = i;
                break;
            }
        if (rank < 0)
            break;
        (*team)->move (new Circle(MINE_POS[rank], GeneralView - 1), DIRECT);
        freeMine[rank] = false;
        exploreTeams.erase (team);
    }
    int ls = 0;
    for (auto t: exploreTeams)
    {
        for (auto s: t->soldiers)
            ls += s->ptr->level;
    } 
    for (auto team = begin(exploreTeams); team != end(exploreTeams); )
    {
        if (ls > 10)
            (*team)->move (new Circle(MILITARY_BASE_POS[1-console->camp()], GeneralView), DIRECT);
        else
            (*team)->move (new Circle(MILITARY_BASE_POS[1-console->camp()], GeneralView), NORMAL);
        exploreTeams.erase (team);
    }
}

//===============update=================
void Condutor::updateMyUnits ()
{
    for (auto hero: allSoldiers)//clear the ptrs to PUnit*
        hero->ptr = nullptr;
    base->ptr = nullptr;
    vector<PUnit*> units = console->friendlyUnits();
    for (auto ptr: units)
    {
        //if we find a militarybase
        if (lowerCase(ptr->name) == lowerCase("militaryBase"))
        {
            base->ptr = ptr;
            base->hp = ptr->hp;
        }
        //or we find a hero
        else if (ptr->isHero())
        {
            //if we find it first time
            if (id2soldier[ptr->id] == nullptr)
            {
                Soldier* soldier = new Soldier;
                soldier->id = ptr->id;
                soldier->ptr = ptr;
                soldier->type = name2type (ptr->name);
                id2soldier[ptr->id] = soldier;
                allSoldiers.push_back(soldier);
                availSoldiers.push_back(soldier);
            }
            else
                id2soldier[ptr->id]->ptr = ptr;
        }
        //or something else
        else
            cout << "warning: unknown friendly unit:" << ptr->id << " " << ptr->name << endl;
    }
    for (auto ptr: allSoldiers)
    {
        if (ptr->ptr == nullptr)
        {
            cout << "error" << endl;
            for (auto p: units)
                cout << p->id << " ";
            cout << endl;
            for (auto q: allSoldiers)
                cout << q->id << " ";
            cout << endl;
        }
    }
}
void Condutor::updateGoldFieldAndMonsterStatus ()
{
    for (auto mine: mines)
        if (mine->energy > 0)
            --mine->energy;
    UnitFilter filter;
    filter.setTypeFilter("mine");
    vector<PUnit*> units = console->enemyUnits(filter);
    for (auto ptr: units)
    {
        GoldField *mine;
        try
        {
            mine = pos2mine.at(ptr->pos);
        }
        catch (std::exception& e)
        {
            cout << "warning: unknown mine " << ptr->pos << " " << ptr->id << endl;
            continue;
        }
        mine->myUnits.clear();
        mine->otherUnits.clear();
        mine->energy = console->unitArg("energy", "c", ptr);
        UnitFilter nearby;
        nearby.setAvoidFilter("mine");
        nearby.setAreaFilter(new Circle(ptr->pos, GeneralView));
        vector<PUnit*> fs = console->friendlyUnits (nearby);
        vector<PUnit*> es = console->enemyUnits (nearby);
        for (auto f: fs)
        {
            if (id2soldier[f->id] == nullptr)
                cout << "error: undiscovered friendly unit, " << f->name << " " << f->id << endl;
            else
                mine->myUnits.push_back (id2soldier[f->id]);
        }
        for (auto e: es)
        {
            if (id2soldier[e->id] == nullptr)
                cout << "error: undiscovered enemy unit, " << e->name << " " << e->id << endl;
            else if (e->isHero())
                mine->otherUnits.push_back(id2soldier[e->id]);
            else if (e->isWild())
                mine->monster = id2soldier[e->id];
        }
    }
}
void Condutor::updateEnemyStatus ()
{
    for (auto e:enemys)
        e->ptr = nullptr;
    for (auto e: monsters)
        e->ptr = nullptr;
    enemyBase->ptr = nullptr;
    UnitFilter filter;
    filter.setAvoidFilter("mine");
    vector<PUnit*> es = console->enemyUnits (filter);
    for (auto ptr: es)
    {
        if (ptr->isHero())
        {
            if (id2soldier[ptr->id])
                id2soldier[ptr->id]->ptr = ptr;
            else
            {
                id2soldier[ptr->id] = new Soldier(ptr);
                enemys.push_back (id2soldier[ptr->id]);
            }
        }
        else if (ptr->isWild())
        {
            if (id2soldier[ptr->id])
                id2soldier[ptr->id]->ptr = ptr;
            else
            {
                id2soldier[ptr->id] = new Soldier(ptr);
                monsters.push_back (id2soldier[ptr->id]);
            }
        }
        else if (ptr->isBase ())
        {
            enemyBase->hp = ptr->hp;
            enemyBase->ptr = ptr;
        }
        else
            cout << "warning: unknown PUnit type, " << ptr->name << " " << ptr->id << ", in Condutor::updateEnemyStatus" << endl;
    }
}
void Condutor::breakUpOldTeams ()
{
    for (auto team: teams)
    {
        if (team == nullptr)
            continue;
        if (value ("round", team->action) != console->round ())
        {
            breakUpTeam (team);
        }
    }
}

void Condutor::breakUpTeam (Team*& t)
{
    if (t == nullptr)
        return;
    auto iter = find (begin(teams), end(teams), t);
    if (iter == end (teams))
        return;
    else
        teams.erase (iter);
    for (auto ptr: t->soldiers)
        availSoldiers.push_back (ptr);
    t = nullptr;
    delete t;
}

Team* Condutor::buildTeam (const vector<Soldier*>& s)
{
    vector<Soldier*> soldiers;
    for (auto soldier = begin(s); soldier != end(s); ++soldier)
    {
        auto iter = find (begin(availSoldiers), end(availSoldiers), (*soldier));
        if (iter != end(availSoldiers))
        {
            availSoldiers.erase (iter);
            soldiers.push_back ((*soldier));
        }
        else
        {
            cout << "warning: you tried to get a unavailable unit to a team, id:" << (*soldier)->id << endl;
        }
    }
    if (soldiers.size())
    {
        Team *team = new Team (soldiers);
        teams.push_back (team);
        return team;
    }
    else
    {
        return nullptr;
    }
}
Team* Condutor::buildTeam (const Soldier* s)
{
    auto as = find(begin(availSoldiers), end(availSoldiers), s);
    if (as == end(availSoldiers))
        return nullptr;
    else
    {
        availSoldiers.erase (as);
        vector<Soldier*> soldiers;
        soldiers.push_back ((Soldier*)s);
        Team* team = new Team (soldiers);
        teams.push_back (team);
        return team;
    }
}
vector<Team*> Condutor::buildIntoTeams (const vector<Soldier*>& s)
{
    vector<Soldier*> toBuild = s;
    vector<Team*> teams;
    while (toBuild.size())
    {
        vector<Soldier*> thisTerm;
        thisTerm.push_back (toBuild.back());
        toBuild.pop_back();
        for (auto iter = begin(toBuild); iter != end (toBuild); )
        {
            if (dis2 ((*iter)->ptr->pos, thisTerm.front()->ptr->pos) < GeneralOneStepReach)
            {
                thisTerm.push_back (*iter);
                toBuild.erase (iter);
            }
            else
                ++iter;
        }
        Team* t = buildTeam(thisTerm);
        if (t != nullptr)
            teams.push_back(t);
    }
    return teams;
}
//==========================================


/*********************************************************************
 *                              Soldier Definition
**********************************************************************/
Soldier::Soldier (PUnit* p)
{
    if (p == nullptr)
    {
        type = Unknown;
        ptr = nullptr;
        id = -1;
    }
    else
    {
        type = name2type(p->name);
        ptr = p;
        id = p->id;
    }
}
void Soldier::move (const Pos& pos)
{
    //可以变得更复杂，比如像attack一样传入一个命令，实现包抄之类的。
    if (ptr == nullptr)
        return;
    console->move (pos, ptr);
}

void Soldier::attack (const Soldier& target, const string& command)
{
    //只是直接攻击，不放技能。
    if (ptr == nullptr)
    {
        cout << "ptr is nullptr" << endl;
        return;
    }
    if (lowerCase (command) == lowerCase("attack"))
    {
        if (target.ptr == nullptr)
        {
            cout << "target's ptr is nullptr" << endl;
            return;
        }
        console->attack (target.ptr, ptr);
    }
    else if (lowerCase (command) == lowerCase ("fastKill"))
    {
        //to do
    }
}
/*****************************************************
*             Team Definition
******************************************************/
Team::Team (const vector<Soldier*>& s):soldiers (s)
{
    action.clear();
    target = nullptr;
}

Team::~Team ()
{
    try
    {
        delete target;
    }
    catch (exception& e)
    {
        //do nothing
    }
}

void Team::move (Geometry* geo, int mode)
{
    //这里想办法保证了同一个队伍的单位不会互相卡住。不过没有考虑的是已经到达目的地在等待的单位是否可以干些其他的事情。
    bool occupiedByPartner[MAP_SIZE][MAP_SIZE] = {0};
    for (auto ptr: soldiers)
         if (geo->contain (ptr->ptr->pos))
         {
            removeEntry ("onWay", ptr->id, action);
            occupiedByPartner[ptr->ptr->pos.x][ptr->ptr->pos.y] = true;
         }
    int counter = 0;
    for (auto ptr: soldiers)
    {
        if (geo->contain (ptr->ptr->pos))
            continue;
        ++counter;
        Pos pos;
        do
        {
            pos = console->randPosInArea (geo);
        }
        while (occupiedByPartner[pos.x][pos.y]);
        if (mode == FASTMOVE && dis2 (ptr->ptr->pos, pos) > value("modeRoundLimit", action) * GeneralSpeed && console->gold() - console->goldCostCurrentRound() > console->callBackCost(ptr->ptr->level))
        {
            console->callBackHero (ptr->ptr);
        }
        else
            console->move (pos, ptr->ptr);
        occupiedByPartner[pos.x][pos.y] = true;
        updateValue ("onWay", action, ptr->id);
    }
    if (counter == 0)
    {
        removeEntry ("moveMode", action);
        target = nullptr;
        return;
    }
    updateValue ("round", action, console->round());
    updateValue ("moveMode", action, mode);
    target = geo;
}

void Team::attack (Soldier* target)
{
    vector<int> onWay = values ("onWay", action);
    for (auto s: soldiers)
    {
        if (find (begin(onWay), end(onWay), s->id) != end(onWay))
        {
            cout << "infomation: a soldier is still on his way, so the attack command in Team::attack is ignored, id:" << s->id << endl;
            continue;
        }
        console->attack (target->ptr, s->ptr);
    }
}

void Team::attack (vector<Soldier*>& t)
{
    if (t.size() == 0)
        return;
    vector<int> onWay = values ("onWay", action);
    vector<Soldier*> target(t);
    for (auto s: soldiers)
    {
        if (find (begin(onWay), end(onWay), s->id) != end(onWay))
        {
            cout << "infomation: a soldier is still on his way, so the attack command in Team::attack is ignored, id:" << s->id << endl;
            continue;
        }
        int min = 1 << 30;
        Soldier* r = nullptr;
        for (auto e: target)
        {
            if (dis2 (e->ptr->pos, s->ptr->pos) < console->unitArg("range", "c", s->ptr))
                continue;
            if (console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr) < min)
            {
                min = console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr);
                r = e;
            }
        }
        if (r != nullptr)
            console->attack (r->ptr, s->ptr);
        else
        {
            int _min = 1 << 30;
            Soldier* _r = nullptr;
            for (auto e: target)
            {
                if (console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr) < min)
                {
                    _min = console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr);
                    _r = e;
                }
            }
            console->attack (_r->ptr, s->ptr);
        }//on enemy in range
    }//for: soldiers
}
/******************************************8
*         Field Definition
*******************************************/
bool Field::contain (const Pos& _p)
{
    Pos p(_p);
    for (auto g: geos)
    {
        if (g->contain(p))
            return true;
    }
    return false;
}

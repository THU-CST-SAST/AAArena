#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include<algorithm>
#include <string>
#include<queue>
#include<map>
using namespace std;

static int heroRank = 1234;
static int newHeroFirst = 1;
static int attackArg = 250, supportRange = 800, monsterAvoid = 0, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100;
static int miningArg = 150, sameMineArg = 10, centerMineArg = 80;
static int goBackHomeHp = 150, goBackHomeArg = 10000;
static int hammerDizzy = 50;
static int strategyDisabled = -1 << 30;
static const char* HERO_NAME[] = { "Hammerguard", "Master", "Berserker", "Scouter" };
static const char* Tactics[] = { "GATHER","PREPARE","STEALHOME","WAIT","URGENT","KILLWILD","CATCHWILDER" ,"NORMAL"};
static string current_mode[101];
static Pos heading[101];

static int protectBaseArg = 1000000, stayBaseArg = 50000 , killBaseArg=100000;

//***************version20 changed*******************
static int base_history_hp[1001];
static int hero_history_hp[101][1001];
static Pos hero_history_pos[101][1001];
static int current_round;

bool isActiveSkill(PSkill* mySkill) //登僅室嬬頁倦葎麼強室嬬
{
	return !strcmp(mySkill->name, "HammerAttack")|| !strcmp(mySkill->name, "Blink")|| !strcmp(mySkill->name, "Sacrifice")|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //陣崙ai議麼窃
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();void buyNewHero();void action();
private:
	Console* console;
	const PMap* map;
	const PPlayerInfo* info;
	PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;//bases included.
	std::vector<PUnit*> wildHeros;
	PUnit *myBase, *enemyBase;
};

class AIHero; //念哈喘蕗苧

class Strategy //貨待児窃
{
public:
	virtual int countWorth() = 0; //柴麻蝶嶽貨待議糞佩勺峙
	virtual void work() = 0; //糞宸嶽貨待
public:
//	virtual ~Strategy();	 
	void setWorker(PUnit* worker) { this->worker = worker; }
	int getWorth() { return worth; }
	void setWorth(int worth) { this->worth = worth; }
	PUnit* getWorker() { return worker; }
	string getName() { return name; }
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for (int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) { this->console = console; }
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class AIHero //斤哘耽倖哂俛議貨待畳貨
{
public:
	AIHero(PUnit* newHero) { mHero = newHero; mStrategy = NULL; } //潮範僉夲指社議貨待
	~AIHero() { if (mStrategy != NULL) delete mStrategy; }
public:
	bool setStrategy(Strategy* newStrategy); //功象貨待議勺峙登僅頁倦僉夲仟議貨待
	void action(); //序佩輝念議恷單貨待
	Strategy* getStrategy() { return mStrategy; }
	int getid() { return mHero->id; }
	int getvalue() { return mStrategy->getWorth(); }
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

class Attack :public Strategy //好似蝶倖汽了議貨待
{
public:
	Attack(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "Attack"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
		else if (dis2(worker->pos, target->pos) <= supportRange)
		{
			UnitFilter filter;
			filter.setAreaFilter(new Circle(target->pos, supportRange), "a");
			this->worth += ((double)20000 / dis2(worker->pos, target->pos)) ;
			if (dis2(worker->pos, target->pos) > worker->range)
				this->worth -= outOfRangeArg;
			if (target->isWild()) this->worth -= monsterAvoid;
			if (dis2(console->getMilitaryBase()->pos,target->pos)<1600 && dis2(worker->pos, target->pos) < supportRange)
			{
				this->worth += protectBaseArg;
			}
		}
		Pos temp(150 - console->getMilitaryBase()->pos.x, 150 - console->getMilitaryBase()->pos.y);
		if (dis2(worker->pos, temp) < supportRange)
		{
			if (target->isBase() && base_history_hp[current_round] > base_history_hp[current_round - 1] - 30)
				this->worth= killBaseArg;
		}
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit(worker);
		console->attack(target);
	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
};

class UseSkill :public Strategy //斤蝶倖汽了瞥慧室嬬議貨待
{
public:
	UseSkill(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "UseSkill"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		console->selectUnit(worker);
		vector<PSkill*> skillList = console->getSkills();
		for (int i = 0; i < skillList.size(); ++i)
			if (isActiveSkill(skillList[i]))//CHANGED==================================================
			{
				if (!worker->canUseSkill(skillList[i]))
					this->worth = strategyDisabled;
				else
				{
					if (!strcmp(skillList[i]->name, "HammerAttack"))
					{
						if (target->findBuff("Reviving") != NULL)
							this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) < supportRange)
						{						
							this->worth += ((double)20000 / dis2(worker->pos, target->pos)) *2* 0.9;
							if (dis2(worker->pos, target->pos) > HAMMERATTACK_RANGE)
								this->worth -= outOfRangeArg*2;
							if (target->findBuff("Dizzy") != NULL)
								this->worth -= hammerDizzy;
							if (dis2(console->getMilitaryBase()->pos, target->pos)<1600 && dis2(worker->pos, target->pos) < supportRange)//if base being attacked and you can attack the emeny
							{
								this->worth += protectBaseArg*2;
							}
							if (target->isBase() && base_history_hp[current_round] > base_history_hp[current_round - 1] - 30)
							{
								this->worth += killBaseArg * 2;
							}
						}
					}
					else if (!strcmp(skillList[i]->name, "Sacrifice"))
					{
						if (target->findBuff("Reviving") != NULL)
							this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) <= supportRange)
						{					
							this->worth += ((double)20000/ dis2(worker->pos, target->pos)) *4*  0.9;
							if (dis2(worker->pos, target->pos) > worker->view)
								this->worth -= outOfRangeArg *4;
							if (target->findBuff("Dizzy") != NULL)
								this->worth += hammerDizzy;
							if (dis2(console->getMilitaryBase()->pos, target->pos)<1600 && dis2(worker->pos, target->pos) < supportRange)//if base being attacked and you can attack the emeny
							{
								this->worth += protectBaseArg * 4;
							}
							if (target->isBase() && base_history_hp[current_round] > base_history_hp[current_round - 1] - 30)
							{
								this->worth += killBaseArg * 4;
							}
						}
					}
					else if (!strcmp(skillList[i]->name, "SetObserver"))
					{
						if (target->findBuff("Reviving") != NULL)
							this->worth = strategyDisabled;
						if (dis2(worker->pos, target->pos) <= supportRange)
						{
							this->worth += 2 * attackArg;
							if (dis2(worker->pos, target->pos) > worker->view)
								this->worth -= outOfRangeArg * 2;
							if (target->findBuff("Dizzy") != NULL)
								this->worth -= hammerDizzy;
							this->targetPos = console->randPosInArea(worker->pos, skillList[i]->range());
						}
					}
				}
				break;
			}
		return this->worth;
	}
	virtual void work()
	{
		console->selectUnit(worker);
		vector<PSkill*> skillList = console->getSkills();
		for (int i = 0; i < skillList.size(); ++i)
			if (isActiveSkill(skillList[i]))
			{
				if (!strcmp(skillList[i]->name, "HammerAttack"))
					console->useSkill(skillList[i], target);
				else if (!strcmp(skillList[i]->name, "Sacrifice"))
					console->useSkill(skillList[i], NULL);
				else
					console->useSkill(skillList[i], targetPos);
				break;
			}
	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
	Pos targetPos;
};

class Escape:public Strategy //哂俛毛怒議媾待 
{
public:
	Escape(PUnit* worker) { setWorker(worker); name = "Escape"; }
public:
	virtual int countWorth()
	{
		
	}
	virtual void work()
	{
		
	}
};

class GoBackHome :public Strategy //哂俛化佩指社議貨待
{
public:
	GoBackHome(PUnit* worker) { setWorker(worker); name = "GoBackHome"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (dis2(worker->pos, console->getMilitaryBase()->pos) < supportRange || dis2(worker->pos, console->getMilitaryBase()->pos) > supportRange * 9)
		{
			this->worth = 0;
			return 0;
		}
		if (worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0) this->worth += goBackHomeArg;
		if (current_mode[worker->id]=="URGENT")this->worth += 500;
		return this->worth;
	} 
	virtual void work()
	{
		console->selectUnit((const PUnit*)worker);
		console->move(console->getMilitaryBase()->pos);
	} 
};

class CallBackHome :public Strategy //孰指哂俛議貨待
{
public:
	CallBackHome(PUnit* worker) { setWorker(worker); name = "CallBackHome"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		if (console->gold() > this->getWorker()->level * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE)
		{
			if (current_mode[worker->id]=="URGENT")this->worth = 2 * goBackHomeArg;
			if (dis2(getWorker()->pos, console->getMilitaryBase()->pos) < supportRange)this->worth = 0;
		}
		return this->worth;
	} 
	virtual void work()
	{
		console->callBackHero(worker);
	} 
};

class GoToEnemyBase :public Strategy
{
public:
	GoToEnemyBase(PUnit* worker) { setWorker(worker); name = "GoToEnemyBase"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		vector<PUnit*>temp = console->friendlyUnits();
		if (temp.size() > 8&& base_history_hp[current_round]>base_history_hp[current_round-1] - 10)  
			this->worth = 10000;
		return this->worth;
	} 
	virtual void work()
	{
		Pos res;
		int tempx = (150 - console->getMilitaryBase()->pos.x - worker->pos.x);
		int tempy = (150 - console->getMilitaryBase()->pos.y - worker->pos.y);
		if (tempx > 0)res.x = 20;
		else res.x = -20;
		if (tempx == 0)
		{
			if (150 - console->getMilitaryBase()->pos.y - worker->pos.y > 0)res.y = 20;
			else res.y = -20;
		}
		else res.y = res.x * tempy / tempx;
		res.x += worker->pos.x;
		res.y += worker->pos.y;
		if (console->getMilitaryBase()->pos.x == 15 && res.x > 135)res.x = 135;
		if (console->getMilitaryBase()->pos.x == 135 && res.x < 15)res.x = 15;
		if (console->getMilitaryBase()->pos.y == 5 && res.y > 145)res.y = 145;
		if (console->getMilitaryBase()->pos.y == 145 && res.y< 5)res.y = 5;
		console->selectUnit((const PUnit*)worker);
		console->move(res);
	} 
};

class GoMining :public Strategy //寡嵩議貨待
{
public:
	GoMining(PUnit* worker, Pos target) { setWorker(worker); setTarget(target); name = "GoMining"; }
public:
	virtual int countWorth()
	{
		this->worth = miningArg;
		if (target == MINE_POS[0])
		{
			for (int i = 0; i < AIHeroList.size(); ++i)
				if (AIHeroList[i]->getStrategy() != NULL)
					if (AIHeroList[i]->getStrategy()->getName() == "GoMining")
					{
						GoMining* otherMining = (GoMining*)(AIHeroList[i]->getStrategy());
						/*if (otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;*/
					}
		}
		this->worth -= dis(worker->pos, target);
		if (target == MINE_POS[0])
			this->worth += centerMineArg;
		this->worth /= 2;
		return this->worth;
	} 
	virtual void work()
	{
		console->selectUnit(worker);
		console->move(target);
	} 
	void setTarget(Pos target) { this->target = target; }
	Pos getTarget() { return target; }
private:
	Pos target;
};

class GoWild :public Strategy //嬉勸議貨待
{
public:
	GoWild(PUnit* worker, Pos target) { setWorker(worker); setTarget(target); name = "GoWild"; }
public:
	virtual int countWorth()
	{
	} 
	virtual void work()
	{
	} 
	void setTarget(Pos target) { this->target = target; }
	Pos getTarget() { return target; }
private:
	Pos target;
};
class StayHomeProtect :public Strategy
{
public:
	StayHomeProtect(PUnit* worker) { setWorker(worker); name = "StayHomeProtect"; }
public:
	virtual int countWorth()
	{
		if (dis2(worker->pos, console->getMilitaryBase()->pos) < supportRange * 4 && base_history_hp[current_round] < 500)
		{
			vector<PUnit*> temp = console->enemyUnits();
			for (int i = 0; i < temp.size(); i++)
			{
				if (temp[i]->isHero() && dis2(temp[i]->pos, worker->pos) < supportRange)return 0;
			}
			return stayBaseArg;
		}
		else return 0;
	} 
	virtual void work() 
	{
		if (dis2(worker->pos, console->getMilitaryBase()->pos) > 100)
		{
			console->selectUnit((const PUnit*)worker);
			console->move(console->getMilitaryBase()->pos);
		}
		return;
	} 
};

class Tempt :public Strategy //哈嗾黍繁勸講議貨待-軸叱窄隠屬徭失音鞭彬議秤趨和序佩hit-and-run
{
public:
	Tempt(PUnit* worker, PUnit* target) { setWorker(worker); setTarget(target); name = "Tempt"; }
public:
	virtual int countWorth()
	{
		this->worth = 0;
		return this->worth;
	}
	virtual void work()
	{
		
	}
	void setTarget(PUnit* target) { this->target = target; }
private:
	PUnit* target;
};

void findPath(const PMap &map, Pos start, Pos dest, const vector<Pos> &blocks, vector<Pos> &path)
{
	struct Node {
		int x, y;
		int level;
		int priority;

		Node() :x(0), y(0), level(0), priority(0) {}
		Node(int xp, int yp, int d, int p) :x(xp), y(yp), level(d), priority(p) {}
		void updatePriority(int xDest, int yDest)
		{
			priority = level + estimate(xDest, yDest) * 9;//version 25 changed
		}
		void nextLevel()
		{
			level += 10;
		}
		int estimate(const int & xDest, const int & yDest) const {
			int xd = xDest - x, yd = yDest - y;
			return static_cast<int>(sqrt(xd * xd + yd * yd));
		}
		bool operator < (const Node &b) const
		{
			return priority > b.priority;
		}
	};
	const int dx[] = { 1, 0, -1, 0 };
	const int dy[] = { 0, 1, 0, -1 };
	static int open_nodes_map[MAP_SIZE][MAP_SIZE];
	static unsigned char closed_nodes_map[MAP_SIZE][MAP_SIZE];
	static unsigned char dir_map[MAP_SIZE][MAP_SIZE];
	priority_queue<Node> pq[2];
	int pqi;
	int i, j, x, y, xdx, ydy;

	memset(closed_nodes_map, 0, sizeof(closed_nodes_map));
	memset(open_nodes_map, 0, sizeof(open_nodes_map));
	if (start == dest)
		return;
	for (size_t i = 0; i < blocks.size(); ++i)
		if (blocks[i].x >= 0 && blocks[i].x < MAP_SIZE && blocks[i].y >= 0 && blocks[i].y < MAP_SIZE)
			closed_nodes_map[blocks[i].x][blocks[i].y] = 1;
	if (closed_nodes_map[dest.x][dest.y] == 1) {
		xdx = start.x < dest.x ? -1 : 1;
		ydy = start.y < dest.y ? -1 : 1;
		x = dest.x; y = dest.y;
		while (closed_nodes_map[x][y] == 1) {
			if (checkOnLine(start, dest, Pos(x + xdx, y)))
				x += xdx;
			else
				y += ydy;
		}
		dest = Pos(x, y);
	}
	Node n0(start.x, start.y, 0, 0);
	n0.updatePriority(dest.x, dest.y);
	pqi = 0;
	pq[pqi].push(n0);
	open_nodes_map[start.x][start.y] = n0.priority;
	while (!pq[pqi].empty()) {
		n0 = pq[pqi].top();
		pq[pqi].pop();
		x = n0.x;
		y = n0.y;
		open_nodes_map[x][y] = 0;
		closed_nodes_map[x][y] = 1;
		if (x == dest.x && y == dest.y) {
			while (!(x == start.x && y == start.y)) {
				j = dir_map[x][y];
				path.push_back(Pos(x, y));
				x += dx[j];
				y += dy[j];
			}
			path.push_back(start);
			reverse(path.begin(), path.end());
			return;
		}
		for (i = 0; i < 4; i++) {
			xdx = x + dx[i]; ydy = y + dy[i];
			if (!(xdx < 0 || xdx >= MAP_SIZE || ydy < 0 || ydy >= MAP_SIZE
				|| map.getHeight(xdx, ydy) - map.getHeight(x, y) > 1 || map.getHeight(xdx, ydy) - map.getHeight(x, y) < -1
				|| closed_nodes_map[xdx][ydy] == 1)) {
				Node m0(n0);
				m0.x = xdx;
				m0.y = ydy;
				m0.nextLevel();
				m0.updatePriority(dest.x, dest.y);
				if (open_nodes_map[xdx][ydy] == 0) {
					open_nodes_map[xdx][ydy] = m0.priority;
					pq[pqi].push(m0);
					dir_map[xdx][ydy] = (i + 2) % 4;
				}
				else if (open_nodes_map[xdx][ydy] > m0.priority) {
					open_nodes_map[xdx][ydy] = m0.priority;
					dir_map[xdx][ydy] = (i + 2) % 4;
					while (!(pq[pqi].top().x == xdx && pq[pqi].top().y == ydy)) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pq[pqi].pop();
					if (pq[pqi].size() > pq[1 - pqi].size())
						pqi = 1 - pqi;
					while (!pq[pqi].empty()) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pqi = 1 - pqi;
					pq[pqi].push(m0);
				}
			}
		}
	}
}

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	//駅勣議兜兵晒
	console = new Console(map, info, cmd);
	//console->changeShortestPathFunc(findPath);
	this->map = &(map);this->info = &(info);this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	for (int i = 0; i < myUnits.size(); ++i)
	{
		if (!strcmp(myUnits[i]->name, "Hammerguard") || !strcmp(myUnits[i]->name, "Master")
			|| !strcmp(myUnits[i]->name, "Berserker") || !strcmp(myUnits[i]->name, "Scouter"))
			myHeros.push_back(myUnits[i]);
		else if (!strcmp(myUnits[i]->name, "MilitaryBase"))
			myBase = myUnits[i];
	}
	for (int i = 0; i < enemyUnits.size(); ++i)
	{
		if (!strcmp(enemyUnits[i]->name, "Hammerguard") || !strcmp(enemyUnits[i]->name, "Master")
			|| !strcmp(enemyUnits[i]->name, "Berserker") || !strcmp(enemyUnits[i]->name, "Scouter"))
			enemyHeros.push_back(enemyUnits[i]);
		else if (!strcmp(enemyUnits[i]->name, "MilitaryBase"))
			enemyBase = enemyUnits[i], enemyHeros.push_back(enemyUnits[i]);
		else if (!strcmp(enemyUnits[i]->name, "Dragon") || !strcmp(enemyUnits[i]->name, "Roshan"))
			wildHeros.push_back(enemyUnits[i]);
	}
	//芝吮晒蕉中佚連
	base_history_hp[info.round] = myBase->hp;
	for (int i = 0; i < myHeros.size(); i++)
	{
		hero_history_hp[myHeros[i]->id][info.round] = myHeros[i]->hp;
		hero_history_pos[myHeros[i]->id][info.round] = myHeros[i]->pos;
	}
	//得登輝念媾宝,彜蓑廬卞
	if (current_round == 1)
	{
		for (int i = 0; i < myHeros.size(); i++)current_mode[myHeros[i]->id] = "NORMAL";
		return;
	}
	else
	{
		for (int i = 0; i < myHeros.size(); i++)
		{
			if (myHeros[i]->hp < 1 )
			{	
				current_mode[myHeros[i]->id] = "NORMAL";
				continue;
			}
			if(current_mode[myHeros[i]->id]=="")
			{
				current_mode[myHeros[i]->id]="NORMAL";
				continue; 
			}
			if (console->getMilitaryBase()->hp < 500 || base_history_hp[current_round] < base_history_hp[current_round - 1] - 50)
			{
				current_mode[myHeros[i]->id] = "URGENT";
				continue;
			}
			else if(current_mode[myHeros[i]->id] == "URGENT")
			{
				current_mode[myHeros[i]->id] = "NORMAL";
			}

			if (current_mode[myHeros[i]->id] == "STEALHOME")
			{
				for (int j = 0; j < myHeros.size(); j++)
					if (dis2(myHeros[i]->pos, myHeros[j]->pos) < 50)
					{
						current_mode[myHeros[j]->id] = "STEALHOME";
					}
			}
			else if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "WAIT")
			{
				if (dis2(heading[myHeros[i]->id], myHeros[i]->pos) < 25)
				{
					int countt = 0;
					for (int j = 0; j < myHeros.size(); j++)
						if ((i != j) && dis2(myHeros[i]->pos, myHeros[j]->pos) < 100)countt++;
					if (countt > 3)
					{
						for (int j = 0; j < myHeros.size(); j++)
						{
							if (dis2(myHeros[i]->pos, myHeros[j]->pos) < 100)current_mode[myHeros[j]->id] = "STEALHOME";
							else if (current_mode[myHeros[j]->id] == "PREPARE")
							{
								current_mode[myHeros[j]->id] = "PREPARE";
							}
						}

					}
					else
						{
						current_mode[myHeros[i]->id] = "WAIT";
					}
				}
			}
			else if (current_mode[myHeros[i]->id] == "GATHER")
			{
				int cnt1, cnt2 = 0;
				for (int j = 0; j < myHeros.size(); j++)
					if ((i != j) && dis2(myHeros[i]->pos, myHeros[j]->pos) < 200)cnt1++;
				for (int j = 0; j < enemyHeros.size(); j++)
					if (enemyHeros[j]->isBase() == 0 && dis2(myHeros[i]->pos, enemyHeros[j]->pos) < 200)cnt2++;
				if (cnt1 >= cnt2 - 1)
				{
					current_mode[myHeros[i]->id] = "NORMAL";
				}
			}
		}
		int countt = 0;
		Pos tar(0, 0);
		for (int j = 0; j < myHeros.size(); j++)
		{
			if (current_mode[myHeros[j]->id] == "NORMAL" && myHeros[j]->hp > 20)
			{
				countt++;
				tar.x = (tar.x *(countt-1)+ myHeros[j]->pos.x) / countt;
				tar.y = (tar.y *(countt-1)+ myHeros[j]->pos.y) / countt;
			}
		}
		if (myHeros.size() > 6 && countt > 4)
		{
			for (int j = 0; j < myHeros.size(); j++)
			{
				if (current_mode[myHeros[j]->id] == "NORMAL" && myHeros[j]->hp > 20)
				{
					current_mode[myHeros[j]->id] = "PREPARE";
					heading[myHeros[j]->id]=tar;
				}
			}
		}
		for (int i = 0; i < myHeros.size(); i++)
		{
			if (current_mode[myHeros[i]->id] != "NORMAL")continue;
			int cnt1=0, cnt2 = 0;
			for (int j = 0; j < myHeros.size(); j++)
				if ((i != j) && dis2(myHeros[i]->pos, myHeros[j]->pos) < 200)cnt1++;
			for (int j = 0; j < enemyHeros.size(); j++)
				if (enemyHeros[j]->isBase() == 0 && dis2(myHeros[i]->pos, enemyHeros[j]->pos) < 200)cnt2++;
			if (cnt1 < cnt2 - 1)
			{
				current_mode[myHeros[i]->id] = "GATHER";
				for (int j = 0; j < myHeros.size();j++)
					if (dis2(myHeros[i]->pos, myHeros[j]->pos) > 200) { heading[myHeros[i]->id] = myHeros[j]->pos; break; }
			}
		}
	}
}

AIController::~AIController()
{
	delete console;
}

struct  sort_temp
{
	int v; int  idd;
};
bool cmp(sort_temp m, sort_temp n)
{
	return m.v < n.v;
}
void AIController::levelupHero()
{
	if (current_mode[0] == "URGENT"&&console->gold() < 500)return;
	UnitFilter filter ; filter.setAreaFilter(new Circle(myBase->pos, LEVELUP_RANGE), "a");
	int size = 0 ; PUnit* heroToLevelUp[100];
	for (int i = 0; i <= info->units.size() - 1; i++)
	{
		if (info->units[i].camp == info->camp && filter.valid(&(info->units[i])) && !PUnit::unitMask(info->units[i].name) && info->units[i].isBase()==0 ) heroToLevelUp[size] = (PUnit*)(&(info->units[i])), size++;
	}
	sort_temp tempp[100 + 1];
	for (int i = 0; i < size; i++)
	{
		int dp = 0;
		if (heroToLevelUp[i] == 0)continue;
		if (heroToLevelUp[i]->typeId == 3)dp = heroToLevelUp[i]->level* LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE + 200;
		else if (heroToLevelUp[i]->typeId == 4)dp = heroToLevelUp[i]->level* LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE + 100;
		else if (heroToLevelUp[i]->typeId == 5)dp = heroToLevelUp[i]->level* LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE;
		else if (heroToLevelUp[i]->typeId == 6)dp = heroToLevelUp[i]->level* LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE;
		tempp[i].v = dp, tempp[i].idd = i;
	}
	sort(tempp, tempp + size, cmp);
	for (int i = 0; i < size; i++)
	{
		int need = LEVELUP_COST_BASE + heroToLevelUp[tempp[i].idd]->level*LEVELUP_COST_PER_LEVEL;
		if (size > 5 && console->gold() - need< 150)break;
		if (size > 6 && console->gold() - need < 250)break;
		if (size > 7 && console->gold () - need< 400)break;
		console->buyHeroLevel(heroToLevelUp[tempp[i].idd]);
	}
}

void AIController::buyNewHero()
{
	//短嗤登僅頁倦孰蚕撹孔絞泌惚短撹孔孰蚕乏會祥氏岱渠
	int newHero = heroRank % 10 - 1;
	if (newHero >= 0 && newHero < 4) console->chooseHero(HERO_NAME[newHero]);
	else
	{
		if (current_mode[0] == "URGENT"&&console->gold() < 500)return;
		int dp[4];
		for (int i = 0; i <= 3; i++)
		{
			UnitFilter filter;
			filter.setTypeFilter(HERO_NAME[i]);
			int num = console->friendlyUnits(filter).size();
			if (i == 0)dp[i] = NEW_HAMMERGUARD_COST * (num + 1);
			else if (i == 1)dp[i] = NEW_MASTER_COST * (num + 1) + 1300;
			else if (i == 2)dp[i] = NEW_BERSERKER_COST * (num + 1) + 750;
			else dp[i] = NEW_SCOUTER_COST * (num + 1) + 270;
		}
		int maxn = 0, pos = -1;
		for (int i = 0; i <= 3; i++)
		{
			if (maxn<dp[i])pos = i,maxn = dp[i];
		}
		newHero = pos; 
		UnitFilter filter ; filter.setTypeFilter(HERO_NAME[newHero]);
		int num = console->friendlyUnits(filter).size(), need = 0;
		int size = console->friendlyUnits().size() - 1;
		if (newHero == 0) need = NEW_HAMMERGUARD_COST*(num + 1);
		else if (newHero == 1)need = NEW_MASTER_COST*(num + 1);
		else if (newHero == 2)need = NEW_MASTER_COST*(num + 1);
		else if (newHero == 3)need = NEW_MASTER_COST*(num + 1);

		if (size > 5 && console->gold() - need < 150)return;
		if (size > 6 && console->gold() - need < 250)return;
		if (size > 7 && console->gold() - need < 400)return;
		console->chooseHero(HERO_NAME[newHero]);
	}
	heroRank /= 10;
}

void AIController::action()
{
	//駅勣議兜兵晒
	vector<Strategy*> allStrategy; vector<AIHero*> AIHeroList;
	for (int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	//繍畳貨紗秘双燕岻嶄
	{
		for (int i = 0; i < myHeros.size(); i++)
		{
			if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "GATHER")
			{
				console->selectUnit(myHeros[i]);
				console->move(heading[myHeros[i]->id]);
			}
		}
		for (int i = 0; i < myHeros.size(); ++i)
			for (int j = 0; j < enemyHeros.size(); ++j)
			{
				if (current_mode[myHeros[i]->id] == "PREPARE" || current_mode[myHeros[i]->id] == "GATHER")continue;
				if (enemyHeros[j]->isBase() == 0)allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
				if (enemyHeros[j]->isBase() == 0)allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
				allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
			}
		for (int i = 0; i < myHeros.size(); i++)//***************************************** 
			for (int j = 0; j < wildHeros.size(); j++)
			{
				//if (current_mode[myHeros[i]->id] == "STEALHOME" || current_mode[myHeros[i]->id] == "PREPARE")continue;
				//if(current_mode[myHeros[i]->id] == "NORMAL")
				//{
				//	allStrategy.push_back(new Attack(myHeros[i], wildHeros[j]));
				//	allStrategy.push_back(new UseSkill(myHeros[i], wildHeros[j]));
				//}
			}
		for (int i = 0; i < myHeros.size(); ++i)
		{
			if (current_mode[myHeros[i]->id] == "NORMAL" || current_mode[myHeros[i]->id] == "URGENT")
			{
				allStrategy.push_back(new GoBackHome(myHeros[i]));
				allStrategy.push_back(new CallBackHome(myHeros[i]));
			}
			if(current_mode[myHeros[i]->id] == "URGENT")allStrategy.push_back(new StayHomeProtect(myHeros[i]));
			if(current_mode[myHeros[i]->id] == "STEALHOME")
			{
				int countt = 0;
				for(int j = 0; j < enemyHeros.size() ;j++)
				{
					if((enemyHeros[j]->isBase() == 0) && dis2(enemyHeros[j]->pos, myHeros[i]->pos) < 100)
					{
						countt++;
					}
				}
				if(countt < 1)allStrategy.push_back(new GoToEnemyBase(myHeros[i]));
			}
		}
		for (int i = 0; i < myHeros.size(); ++i)
			for (int j = 0; j < MINE_NUM; ++j)
			{
				if(current_mode[myHeros[i]->id] == "NORMAL")
				allStrategy.push_back(new GoMining(myHeros[i], MINE_POS[j]));
			}
	}
	for (int i = 0; i < allStrategy.size(); ++i)allStrategy[i]->setAIHeroList(AIHeroList);
	for (int i = 0; i < allStrategy.size(); ++i)allStrategy[i]->setConsole(console);
	//僉夲旺峇佩媾宝
	for (int i = 0; i < AIHeroList.size(); ++i)
		for (int j = 0; j < allStrategy.size(); ++j)
		{
			bool check=AIHeroList[i]->setStrategy(allStrategy[j]);
		}
	for (int i = 0; i < AIHeroList.size(); ++i)
	{
		if (AIHeroList[i]->getStrategy() != 0)
		{
			AIHeroList[i]->action();
		}
	}
	for (int i = 0; i < AIHeroList.size(); ++i)if (AIHeroList[i] != NULL)delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if (newStrategy == NULL) return false;
	if (newStrategy->getWorker() != this->mHero) return false;
	if (mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if (mStrategy != NULL)delete mStrategy;
		mStrategy = newStrategy;
	}
	else delete newStrategy;
	return true;
}

void AIHero::action()
{
	mStrategy->work();
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	current_round = info.round;
	srand(time(NULL));
	AIController controller(map, info, cmd);
	if (info.round == 0)
	{
		for (int i = 1; i <= 4; ++i)
			controller.buyNewHero();
		return;
	}
	if (newHeroFirst)
	{
		controller.buyNewHero();
		controller.levelupHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	newHeroFirst++;
	controller.action();
}
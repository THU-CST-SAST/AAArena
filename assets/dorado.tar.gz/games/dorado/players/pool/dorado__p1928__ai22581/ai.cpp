#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

static int heroRank = 3131;
static int newHeroFirst = 1 ;
static int attackArg = 200, supportRange = 1000, monsterAtk = 200,enemyAvoid = 30, deltaFightArg = 100 ,ConcentrateArg = 5 ,ObserverAtk = 135;
static int outOfRangeArg = 300 ;
static int AtkBaseRange = dis2(MINE_POS[5],Pos(15,5)) ,AtkBaseArg= 500,HeroLevel=50 ,Herobase=0 ;
static int miningArg = 135, sameMineArg1 = 0, sameMineArg2 = 0, centerMineArg = 40 ,nearMineArg = 30 , Ability = 4 ,KeepMining = 10;
static int DIS1[24]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24};
static int DIS2[25]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,0};
static Pos goCenterMine[]={Pos(20,15),Pos(25,25),Pos(34,34),Pos(39,39),Pos(45,44),Pos(49,49),Pos(54,55),Pos(57,58),Pos(61,62),Pos(64,64),Pos(67,67),Pos(72,72),Pos(77,78),Pos(81,81),Pos(85,85),Pos(89,88),Pos(95,95),Pos(100,100),Pos(103,102),Pos(106,106),Pos(111,111),Pos(116,115),Pos(121,122),Pos(126,131)};
static int goBackHomeHp = 200, goBackHomeArg = 300;
static int DefenceHomeArg = 300 , DefenceRange = 5,DefenceGroup = 0 ,StayBaseDefenceArg = 1<<15;
static int callBackHomeHp = 100, callBackHomeArg = 200;
static int hammerDizzy = 5,firstkill = 50 ,nowkill = 50;
static int strategyDisabled = - 1<<30;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int RANK=0;
static int StealRank = -100 ,StealRankInterval = 30 , StealPlus = 20 , enemybasehp = 3000 ,haveSteal = 0 ,theRank=0;
static int DefenceRank = 0 ,DefenceRankInterval = 40 , DefencePlus = 15,basehp=3000 ,haveDefence = 0;
static PMap themap;
static Pos goout , AtkBasePos;
bool isActiveSkill(PSkill* mySkill) //登僅室嬬頁倦葎麼強室嬬
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //陣崙ai議麼窃
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();
	void buyNewHero();
	void action();
private:
	Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;
	PUnit *myBase, *enemyBase;
	int remain=0;
};

class AIHero; //念哈喘蕗苧

class Strategy //貨待児窃
{
public:
	virtual int countWorth() = 0; //柴麻蝶嶽貨待議糞佩勺峙
	virtual void work() = 0; //糞宸嶽貨待
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	void setTarget(PUnit* target) {this->target = target;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	PUnit* getTarget() {return target;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
	PUnit* target;
};

class Attack:public Strategy //好似蝶倖汽了議貨待
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void attack(const PUnit* target, const PUnit* ptr);
private:
	Pos enemybasepos;
	int k;
	int q;
};

class Steal:public Strategy//裕社蝶倖汽了議貨待
{
public:
	Steal(PUnit* worker) {setWorker(worker);name = "Steal";}
public:
	virtual int countWorth();
	virtual void work();
private:
	int way;
	int StealSize;
	int WaitSize;
	int WaitTime;
	int AtkSize;
	Pos enemybasepos;
	Pos enemyBaseExit;
	Pos gopos;
};
class Defence:public Strategy//便社蝶倖汽了議貨待
{
public:
	Defence(PUnit* worker) {setWorker(worker);name = "Defence";}
public:
	virtual int countWorth();
	virtual void work();
private:
	int DefenceGroup;
	int r;
	int k;
	int q;
	Pos BaseExit;
};

class UseSkill:public Strategy //斤蝶倖汽了瞥慧室嬬議貨待
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
private:
	Pos targetPos;
};

class GoBackHome:public Strategy //哂俛化佩指社議貨待
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class CallBackHome:public Strategy //孰指哂俛議貨待
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
private:
	int DefenceGroup;
	int k;
};
class BuyBackHome:public Strategy //択試哂俛議貨待
{
public:
	BuyBackHome(PUnit* worker) {setWorker(worker);name = "BuyBackHome";}
public:
	virtual int countWorth();
	virtual void work();
private:
	int k;
	int q;
};

class GoMining:public Strategy //寡嵩議貨待
{
public:
	GoMining(PUnit* worker, Pos targetpos) {setWorker(worker);setTargetpos(targetpos);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	Pos getTarget() {return targetpos;}
	void setTargetpos(Pos targetpos) {this->targetpos = targetpos;}
	void movein(const Pos& target);
private:
	Pos enemybasepos;
	Pos crossingPos;
	Pos targetpos;
	int sameMineArg;
	int NearMineGroup;
	int CenterMineGroup;
};

class Tempt:public Strategy //哈嗾黍繁勸講議貨待-軸叱窄隠屬徭失音鞭彬議秤趨和序佩hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual int countWorth();
	virtual void work();
private:
};

class AIHero //斤哘耽倖哂俛議貨待畳貨
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //潮範僉夲指社議貨待
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //功象貨待議勺峙登僅頁倦僉夲仟議貨待
	void action(); //序佩輝念議恷單貨待
	Strategy* getStrategy() {return mStrategy;}
	PUnit* getMyhero(){return mHero;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;	
	if(RANK>=300 && RANK<=500)
		remain = 3 * (0 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	if(RANK>=500)
		remain = 3 * (1 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	if(RANK>=700)
		remain = 3 * (2 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	if(RANK>=800)
		remain = 3 * (3 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	if(RANK>=850)
		remain = 3 * (4 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	if(RANK>=900)
		remain = 3 * (5 * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE);
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan")||!strcmp(enemyUnits[i]->name,"MilitaryBase")||!strcmp(enemyUnits[i]->name,"Observer"))
			enemyHeros.push_back(enemyUnits[i]);
		if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()
{
	int enemyatkbase = 0;
	int DefenceBase = 0;
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, 400000 ), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	vector<PUnit*> ENEMY_HEROS = console->enemyUnits();
	filter.setAvoidFilter ("MilitaryBase");
	filter.setAvoidFilter ("Observer");
	for(int i = 0; i < ENEMY_HEROS.size(); ++i)
		if(dis2(ENEMY_HEROS[i]->pos,myBase->pos)<=144)
			enemyatkbase++;
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		{
			if(dis2(heroToLevelUp[i]->pos,myBase->pos)<=144)
				DefenceBase++;
			if(((heroToLevelUp.size() >= 7 && heroToLevelUp[i]->level <= 1) || (heroToLevelUp.size()>=9 && heroToLevelUp[i]->level <= 4)) && dis2(heroToLevelUp[i]->pos,myBase->pos) <= LEVELUP_RANGE && enemyatkbase<DefenceBase )
				if(console->gold () >= console->levelUpCost(heroToLevelUp[i]->level) + remain)
					if(heroToLevelUp[i]->name != "Scouter")
				console->buyHeroLevel(heroToLevelUp[i]);
		}
}

void AIController::buyNewHero()
{
	if(console->getMilitaryBase()->pos==Pos(15,5))
		goout = goCenterMine[0];
	else
		goout = goCenterMine[23];
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, 400000 ), "a");
	vector<PUnit*> MYhero = console->friendlyUnits (filter);
	filter.setAvoidFilter ("MilitaryBase");
	filter.setAvoidFilter ("Observer");
	Pos startpos[4]={console->closestPos(console->getMilitaryBase()->pos,36, goout)};
	startpos[1]=startpos[0]+Pos(1,0);
	startpos[2]=startpos[0]+Pos(0,1);
	startpos[3]=startpos[0]+Pos(-1,1);
	if(MYhero.size()==1 && console->gold () >= 250 + remain)
		 console->chooseHero (HERO_NAME[0],startpos[0]);	
	else if(MYhero.size()==2 && console->gold () >= 250 + remain)
		 console->chooseHero (HERO_NAME[2],startpos[1]);	
	else if(MYhero.size()==3 && console->gold () >= 500 + remain)
		 console->chooseHero (HERO_NAME[2],startpos[2]);
	else if(MYhero.size()==4 && console->gold () >= 250 + remain)
		 console->chooseHero (HERO_NAME[3],startpos[0]);
	else if(MYhero.size()==5 && console->gold () >= 500 + remain)
		 console->chooseHero (HERO_NAME[0],startpos[0]);
	else if(MYhero.size()==6 && console->gold () >= 500 + remain)
		 console->chooseHero (HERO_NAME[3],startpos[0]);
	else if(MYhero.size()==7 && console->gold () >= 750 + remain)
		 console->chooseHero (HERO_NAME[2],startpos[0]);
	else if(MYhero.size()==8 && console->gold () >= 750 + remain)
		 console->chooseHero (HERO_NAME[0],startpos[0]);
}

void AIController::action()
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
	if(theRank+100>RANK)
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new Defence(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new Steal(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new BuyBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < MINE_NUM; ++j)
			allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]));
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setConsole(console);
	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)
			AIHeroList[j]->setStrategy(allStrategy[i]);
	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	mStrategy->work();
}

int Attack::countWorth()
{
	this->worth = 0;			
	if(target->findBuff("Reviving") != NULL || (target->findBuff("WaitRevive") != NULL &&(target->findBuff("WinOrDie")!=NULL|| target->hp<=0)))
		this->worth = strategyDisabled;
	else if(!strcmp(target->name,"Observer"))
		this->worth = ObserverAtk;
	else if(dis2(worker->pos,target->pos) <= supportRange)
	{
		if(console->getMilitaryBase()->pos==Pos(135,145))
			{	
			enemybasepos=Pos(15,5);
			}
		else
			{		
			enemybasepos=Pos(135,145);
			}
		k=0;q=0;
		for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getStrategy() != NULL)
			if((AIHeroList[i]->getStrategy()->getName() == "Attack"|| AIHeroList[i]->getStrategy()->getName() == "UsingSkill")&& AIHeroList[i]->getStrategy()->getTarget()==target && target->name!="Observer" && !(target->findBuff("WaitRevive") != NULL))
					this->worth += ConcentrateArg;
		if(target->name == "Hammerguard")
			this->worth += target->atk;
		if(target->name == "Master"||target->name == "Scouter")
			this->worth += 2*target->atk;
		if(target->name == "Berserker")
			this->worth += 0.6*target->atk;
		if(worker->findBuff("WinOrDie")!=NULL && target->name == "Berserker")
			this->worth +=  15 * (double)attackArg;
		if((worker->name == "Master"||worker->name == "Scouter") && target->name == "Berserker" && !(target->findBuff("WaitRevive") != NULL)&&(!(target->findBuff("beAttack") != NULL&&console->getBuff("beAttack",target)->timeLeft == 3)))
			this->worth +=  15 * (double)attackArg;		
		if(target->hp>50)
			this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg - (target->atk-worker->def)/(double)console->getSkill("Attack",target)->maxCd * target->hp/(double)(worker->atk-target->def)/3;
		else
			this->worth += ((double)target->max_hp/(double)50) * (double)attackArg - (target->atk-worker->def)/(double)console->getSkill("Attack",target)->maxCd * target->hp/(double)(worker->atk-target->def)/3;
		//if(dis2(worker->pos,target->pos) > worker->range && dis2(target->pos,console->getMilitaryBase()->pos)>dis2(Pos(80,80),Pos(15,5)) && !target->isWild())
		//{
		//	this->worth -= outOfRangeArg * pow(dis2(target->pos,console->getMilitaryBase()->pos)/(double)dis2(Pos(75,75),Pos(15,5)),3.5);
		//	if(!strcmp(target->name,"Scouter")||!strcmp(target->name,"Master"))
		//		this->worth -= outOfRangeArg * pow(dis2(target->pos,console->getMilitaryBase()->pos)/(double)dis2(Pos(75,75),Pos(15,5)),3.5);
		//	else if((worker->name == "Hammerguard"||worker->name == "Berserker" )&& dis2(worker->pos,target->pos) > worker->range)
		////		this->worth -=  outOfRangeArg;
		//}
		if(dis2(target->pos,enemybasepos)<3000 && !target->isWild()&&target->name!="MilitaryBase")
		{
			this->worth -= StayBaseDefenceArg  ;
		}
		if(target->findBuff("Dizzy") != NULL)
			this->worth += (worker->atk-target->def)*3;
		if(dis2(target->pos,enemybasepos)>=1000&&!target->isWild()&&dis2(worker->pos,enemybasepos)>=1000&&worker->hp<50)
			if(RANK>theRank)
			{
				theRank=RANK;
				if(haveSteal==0)
					haveSteal=1;
				else
					haveSteal=0;
			}
		if(!strcmp(target->name,"MilitaryBase")&&dis2(worker->pos,enemybasepos)<=1500)
		{	
			if(RANK>theRank)
			{
				theRank=RANK;
				if(haveSteal==0)
					haveSteal=1;
				else
					haveSteal=0;
			}
			enemybasehp = target->hp;
			this->worth = RANK*RANK/300+(double)console->getMilitaryBase()->hp/(double)enemybasehp * AtkBaseArg ;
			//for(int size=0;size<ENEMY_HEROS.size();size++)
				//if(ENEMY_HEROS[size]->isHero() && !(ENEMY_HEROS[size]->findBuff("Reviving")!=NULL))
					//this->worth -= ENEMY_HEROS[size]->level * HeroLevel + Herobase;
			//if(target->hp <= console->getMilitaryBase()->hp)
				this->worth = StayBaseDefenceArg + ((double)target->max_hp/(double)target->hp) * (double)AtkBaseArg;
			this->worth += ((double)target->max_hp/(double)target->hp) * (double)AtkBaseArg;
		}
		if(target->name == "Dragon") 
			this->worth = monsterAtk + 2*RANK*RANK/300+2* AtkBaseArg;
		if(dis2(worker->pos,console->getMilitaryBase()->pos) <= 144)
		{
			if(dis2(target->pos,console->getMilitaryBase()->pos) <= supportRange-144 && dis2(target->pos,console->getMilitaryBase()->pos) > 144)
			{
				this->worth = 0;
				//DefenceRank =RANK;
				//for(int size=0;size<ENEMY_HEROS.size();size++)
				//	if(ENEMY_HEROS[size]->isHero() && !(ENEMY_HEROS[size]->findBuff("Reviving")!=NULL))
				////		this->worth -= ENEMY_HEROS[size]->level;
				//for(int size=0;size<MY_HEROS.size();size++)
				//	if(MY_HEROS[size]->isHero() && !(MY_HEROS[size]->findBuff("Reviving")!=NULL))
				//		this->worth += MY_HEROS[size]->level + 3 ;
				//this->worth += (this->worth>=0) * StayBaseDefenceArg  *  (double)144/(double)dis2(target->pos,console->getMilitaryBase()->pos);

			}
			if( dis2(target->pos,console->getMilitaryBase()->pos) <= 144)
			{
				if(target->findBuff("Dizzy") != NULL)
					this->worth -= 100 * StayBaseDefenceArg  ;
				DefenceRank =RANK;
				this->worth += 100 * StayBaseDefenceArg  ;
				if(target->name == "Master"||target->name == "Scouter"||(target->name == "Berserker"&&target->findBuff("WinOrDie")!=NULL))
				this->worth += 10*StayBaseDefenceArg  ;
				if(RANK<theRank+100)
				{
					theRank=RANK-100;
					StealRank = RANK-StealRankInterval;
				}
			}
		}
	}
	if(dis2(target->pos,console->getMilitaryBase()->pos) <= 144)
		DefenceRank =RANK;
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	if(worker->canUseSkill("Attack") && dis2(target->pos,worker->pos)<=worker->range)
		if(worker->name == "Master"||worker->name == "Scouter")
		{
			UnitFilter filter;
			filter.setAreaFilter (new Circle (worker->pos,worker->range), "a");
			vector<PUnit*> ENEMY_HEROS = console->enemyUnits();
			for(int size=0;size<ENEMY_HEROS.size();size++)
				if(ENEMY_HEROS[size]->isHero() && !(ENEMY_HEROS[size]->findBuff("Reviving")!=NULL)&&dis2(ENEMY_HEROS[size]->pos,worker->pos)<=target->range&&target->name != "Master"&&target->name != "Scouter")
					console->move(console->closestPos(target->pos, worker->speed, console->getMilitaryBase()->pos));
		}
		else
			console->attack(target);
	else
		 console->move(console->closestPos(target->pos, worker->range-3, console->getMilitaryBase()->pos));
}
int Steal::countWorth()
{
	int k=0;
	StealSize=0;
	if(console->getMilitaryBase()->pos==Pos(135,145))
	{	
			enemybasepos=Pos(15,5);
			enemyBaseExit=MINE_POS[6-haveSteal];
			way = 2;
	}
	else
	{		
			enemybasepos=Pos(135,145);
			enemyBaseExit=MINE_POS[5+haveSteal];
			way = 1;
	}
	gopos=console->closestPos(enemybasepos,2000, enemyBaseExit);
	this->worth = RANK*RANK/300+(double)console->getMilitaryBase()->hp/(double)enemybasehp * AtkBaseArg ;
	//way=(RANK/100)%2+1;
	UnitFilter filter;
	filter.setAreaFilter (new Circle (enemybasepos, 1500 ), "a");
	filter.setAvoidFilter ("MilitaryBase");
	filter.setAvoidFilter ("Observer");
	vector<PUnit*> enemies = console->enemyUnits();
	for(int size=0;size<enemies.size();size++)
		if(enemies[size]->isHero() && !(enemies[size]->findBuff("Reviving") != NULL)&&dis2(enemies[size]->pos,enemybasepos)>144)
			k++;
    if(enemybasehp>1000)
	{
	if(StealRank + StealRankInterval < RANK )
	{
		//if(k>=4)
		//{
		//	StealRank = RANK;
		//	if(StealRankInterval<90)
		//	StealRankInterval += StealPlus;
		//	cout<<"stealRANK="<<StealRank;
		//}
	}
	else
		this->worth = strategyDisabled;
	}
	WaitSize = 0;AtkSize=0;
	for(int i = 0; i < AIHeroList.size(); ++i)
	{
	if(AIHeroList[i]->getStrategy() != NULL)
			if(AIHeroList[i]->getStrategy()->getName() == "Steal"||AIHeroList[i]->getStrategy()->getName() == "GoMining")
				StealSize++;
	if(dis2(AIHeroList[i]->getMyhero()->pos,enemybasepos)<dis2(enemybasepos,enemyBaseExit)+1000)
				WaitSize++;
	if(dis2(AIHeroList[i]->getMyhero()->pos,enemybasepos)<dis2(enemybasepos,gopos)+144)
				AtkSize++;
	}
	if(dis2(worker->pos,enemybasepos)<= worker->range || (WaitSize<6 && dis2(worker->pos,enemybasepos)>3000) )
		this->worth = strategyDisabled;
	return this->worth;
}


void Steal::work()
{
	console->selectUnit(worker);
	if(way==1)
	{
		if(dis2(worker->pos, enemybasepos) >= AtkBaseRange+36)
			console->move(console->closestPos(enemybasepos, AtkBaseRange, enemyBaseExit));
		else 
		{
			if(StealSize > WaitSize)
				console->move(console->closestPos(enemybasepos, AtkBaseRange ,enemyBaseExit));
			else
			{
				if(StealSize <= AtkSize)
					console->move(console->closestPos(enemybasepos,worker->range-3, Pos(75,75)));
				else
					console->move(gopos);
			}
		}
	}
	if(way==3)
	{
			console->move(console->randPosInArea(enemybasepos,worker->range));
	}
	if(way==2)
	{
		if(dis2(worker->pos, enemybasepos) >= AtkBaseRange+36)
			console->move(console->closestPos(enemybasepos, AtkBaseRange, enemyBaseExit));
		else
		{
			if( StealSize>WaitSize )
			 console->move(console->closestPos(enemybasepos ,AtkBaseRange , enemyBaseExit));
			else
			{
			 	if(StealSize <= AtkSize)
					console->move(console->closestPos(enemybasepos,worker->range-3, Pos(75,75)));
				else
					console->move(gopos);
			}
		}
	}
}
int Defence::countWorth()
{
	if(console->getMilitaryBase()->hp<3000)
		DefenceGroup = 3+0.1;
	else
		DefenceGroup = 0;
	if(DefenceRank + DefenceRankInterval >RANK)
		DefenceGroup += 2;
	r = 0;
	k = 0;
	q = 0;
	this->worth = 0;
	if( RANK >= 100)
	{
		this ->worth -= dis(worker->pos,console->getMilitaryBase()->pos);
		UnitFilter filter;
		filter.setAreaFilter (new Circle (console->getMilitaryBase()->pos, supportRange ), "a");
		filter.setAvoidFilter ("MilitaryBase");
		filter.setAvoidFilter ("Observer");
		vector<PUnit*> enemies = console->enemyUnits();
		vector<PUnit*> MY_HEROS = console->friendlyUnits();
		for(int size=0;size<MY_HEROS.size();size++)
			if(MY_HEROS[size]->isHero() && !(MY_HEROS[size]->findBuff("Reviving") != NULL))
				k++;
		for(int size=0;size<enemies.size();size++)
			 if(enemies[size]->isHero() && !(enemies[size]->findBuff("WaitRevive") != NULL)) 
				 q++;
		for(int i = 0; i < AIHeroList.size(); ++i)
			if(AIHeroList[i]->getStrategy() != NULL)
				if(AIHeroList[i]->getStrategy()->getName() == "Defence"|| ((AIHeroList[i]->getStrategy()->getName() == "Attack"||AIHeroList[i]->getStrategy()->getName() == "UseSkill") && dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,console->getMilitaryBase()->pos)<=supportRange))
					{r++;}
		if(dis2(worker->pos, console->getMilitaryBase()->pos) <= 144*4)
			this->worth += DefenceHomeArg + StayBaseDefenceArg * (1-r/(double)DefenceGroup);
		///if(dis2(worker->pos, console->getMilitaryBase()->pos) >= DefenceRange*4 && r >= DefenceGroup)
				//this->worth = 0;
	}
	return this->worth;
}


void Defence::work()
{
	if(console->getMilitaryBase()->pos == Pos(135,145))
			BaseExit=Pos(133,137);
	else
			BaseExit=Pos(15,15);		
	console->selectUnit(worker);
	if(q==0)
	   { 
		   if(!strcmp(worker->name,"Scouter")||!strcmp(worker->name,"Master"))
				 console->move(console->randPosInArea(console->closestPos(console->getMilitaryBase()->pos, 36, BaseExit),5));
		   else
			   console->move(console->randPosInArea(console->closestPos(console->getMilitaryBase()->pos, DefenceRange, BaseExit),5));
		   	if(DefenceRank + DefenceRankInterval == RANK)
			DefenceRankInterval += DefencePlus;
		}
	else
		{
			console->move(console->randPosInArea(console->closestPos(console->getMilitaryBase()->pos, 36, BaseExit),5));
			haveDefence=1;
		}
}

int UseSkill::countWorth()
{
	this->worth = 0;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(target->findBuff("Reviving") != NULL || target->findBuff("WaitRevive") != NULL && target->hp<=0||!strcmp(target->name,"MilitaryBase")||!strcmp(target->name,"Observer"))
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						for(int i = 0; i < AIHeroList.size(); ++i)
						if(AIHeroList[i]->getStrategy() != NULL)
							if((AIHeroList[i]->getStrategy()->getName() == "Attack"|| AIHeroList[i]->getStrategy()->getName() == "UsingSkill")&& AIHeroList[i]->getStrategy()->getTarget()==target && !target->isWild()&&target->name!="Observer")
								this->worth += ConcentrateArg;
						this->worth += ((double)target->max_hp / (double)target->hp) * (double)attackArg;
						if(target->name == "Hammerguard")
							this->worth += target->atk;
						if(target->name == "Master"||target->name == "Scouter")
							this->worth += 2*target->atk;
						if(target->name == "Berserker")
							this->worth += 0.6*target->atk;
						if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						if(!strcmp(target->name,"Master") || !strcmp(target->name,"Berserker"))
							this->worth += firstkill;
						if(target->hp<HAMMERATTACK_DAMAGE[worker->level] && target->hp>0.5*HAMMERATTACK_DAMAGE[worker->level])
							this->worth += nowkill;
						if(dis2(target->pos,console->getMilitaryBase()->pos) <= 144)
						{
							if(target->findBuff("Dizzy") != NULL)
								this->worth -= 100 * StayBaseDefenceArg  ;
							DefenceRank =RANK;
							this->worth += 50 * StayBaseDefenceArg  *  (double)144/(double)dis2(target->pos,console->getMilitaryBase()->pos);
						}
						if(target->name == "Dragon") 
							this->worth = monsterAtk + 2*RANK*RANK/300+2* AtkBaseArg;
					}
				}
				else if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					if(target->findBuff("Reviving") != NULL || target->findBuff("WaitRevive") != NULL||(worker->findBuff("beAttack") != NULL&&console->getBuff("beAttack",worker)->timeLeft == 3)||dis2(worker->pos,target->pos) > worker->range-3||!worker->canUseSkill("Attack"))
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						if(target->name!="MilitaryBase" && !target->isWild() || dis2(worker->pos,target->pos) > worker->range-3)
							this->worth = strategyDisabled;
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 3;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy*2;
						if(!strcmp(target->name,"MilitaryBase")&&dis2(worker->pos,target->pos) <= worker->range)
						{		
							if(RANK>theRank)
								{
								theRank=RANK;
								if(haveSteal==0)
									haveSteal=1;
								else
									haveSteal=0;
								}
							enemybasehp = target->hp;
							this->worth = 2*RANK*RANK/300+(double)console->getMilitaryBase()->hp/(double)enemybasehp * AtkBaseArg ;
								this->worth = 2*StayBaseDefenceArg + ((double)target->max_hp/(double)target->hp) * (double)AtkBaseArg;
								this->worth += 2*((double)target->max_hp/(double)target->hp) * (double)AtkBaseArg;
						}
						if(dis2(target->pos,console->getMilitaryBase()->pos) <= 144)
						{
							if(target->findBuff("Dizzy") != NULL)
								this->worth -= 100 * StayBaseDefenceArg  ;
							DefenceRank =RANK;
							this->worth += StayBaseDefenceArg  *  (double)144/(double)dis2(target->pos,console->getMilitaryBase()->pos);
						}
						if(target->name == "Dragon") 
							this->worth = monsterAtk + 2*RANK*RANK/300+2* AtkBaseArg;
					}
				}
				else if(!strcmp(skillList[i]->name, "SetObserver") && (dis2(worker->pos,console->getMilitaryBase()->pos) <= supportRange||dis2(worker->pos,Pos(75,75)) <= 144))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 3*attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
				}				
				else if(!strcmp(skillList[i]->name, "Blink"))
				{
					if(!(worker->findBuff("BeAttacked") != NULL) || target->findBuff("Reviving") != NULL || target->findBuff("WaitRevive") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= target->range)
					{
						this->worth += 3*( target->atk-worker->def)*pow((double)worker->max_hp/(double)worker->hp,3);
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy * 2;
						this->targetPos = console->closestPos(worker->pos, BLINK_RANGE, console->getMilitaryBase()->pos);
					}
					if(dis2(worker->pos,target->pos) <= BLINK_RANGE && dis2(worker->pos,target->pos) > target->range && target->hp <= worker->atk - target->def)
					{	
						this->worth += target->atk * ((double)target->max_hp / (double)target->hp);
						this->targetPos = console->closestPos(target->pos , worker->range , worker->pos);
					}
					if(target->pos.x < 0 || target->pos.x >= MAP_SIZE || target->pos.y < 0 || target->pos.y > MAP_SIZE)
						this->worth=0;
					else if(themap.getHeight(this->targetPos.x,this->targetPos.y)>=3)
						this->worth=0;	
				}			
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

int Tempt::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void Tempt::work()
{
}

int GoMining::countWorth()
{
	if(console->getMilitaryBase()->pos==Pos(135,145))
			{	
			enemybasepos=Pos(15,5);
			}
	else
			{		
			enemybasepos=Pos(135,145);
			}
	if(console->getMilitaryBase()->pos == Pos(15,5) )
		crossingPos = Pos(43,43);
	else
		crossingPos = Pos(107,107);
	CenterMineGroup=0;
	NearMineGroup=0;
	if( RANK <= 600)
		sameMineArg = sameMineArg1;
	else
		sameMineArg = sameMineArg2;
	this->worth = miningArg;
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getStrategy() != NULL)
			if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
			{
				GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
				if(otherMining->getTarget() == this->targetpos)
					this->worth -= sameMineArg;
				if((otherMining->getTarget() == MINE_POS[1]||otherMining->getTarget() == MINE_POS[4])&&(dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[1])<=169||dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[4])<=169))
					NearMineGroup++;
				if((otherMining->getTarget() == MINE_POS[0])&&(dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[0])<=169))
					CenterMineGroup++;
			}
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getStrategy() != NULL)
			if(AIHeroList[i]->getStrategy()->getName() == "Attack")
				if(dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[0])<=169)
					CenterMineGroup++;
				else if(dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[1])<=169||dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,MINE_POS[4])<=169)
					NearMineGroup++;
	//this->worth -= dis(worker->pos, targetpos);
	if(targetpos == MINE_POS[0])
		this->worth += -10*centerMineArg;
	  if( (targetpos == MINE_POS[5+haveSteal]))//||targetpos == MINE_POS[5]) ||( RANK>=500 && targetpos == MINE_POS[6]) )
	  {
		  if(console->getMilitaryBase()->pos == Pos(15,5) )
			this->worth += nearMineArg;
		  else
			this->worth -= 10*nearMineArg;
		  	if(RANK<0)
					this->worth -= 10*centerMineArg;
		}
	if ( (targetpos == MINE_POS[6-haveSteal]))//||targetpos == MINE_POS[6])||( RANK>=500 && targetpos == MINE_POS[5]) )
		{
			if(console->getMilitaryBase()->pos != Pos(15,5) )
				this->worth += nearMineArg;
			else
				this->worth -= 10*nearMineArg;
			if(RANK<0 )
					this->worth -= 10*centerMineArg;
		}
	if((targetpos == MINE_POS[1]||targetpos == MINE_POS[4]))
		this->worth += -10*nearMineArg;
	if(targetpos == MINE_POS[2]||targetpos == MINE_POS[3])
		this->worth -= nearMineArg * 10;
//	UnitFilter filter;
//	filter.setAreaFilter (new Circle (worker->pos, 144), "a");
//	vector<PUnit*> ENEMY_HEROS = console->enemyUnits();
//    for(int size=0;size<ENEMY_HEROS.size();size++)
//		if(ENEMY_HEROS[size]->isHero() && !(ENEMY_HEROS[size]->findBuff("Reviving") != NULL))
//			this->worth = 0;
//	for(int size=0;size<ENEMY_HEROS.size();size++)
//		if(ENEMY_HEROS[size]->isHero())
//			if(ENEMY_HEROS[size]->findBuff("Reviving") != NULL && worker->name!= "Scouter")
//			this->worth -= nearMineArg;
	return this->worth;
}
//void GoMining::moveinline(const Pos& target,int speed)
//{
//	vector<Pos> symbols;
//    symbols.clear();
//	symbols.push_back(worker->pos);
//	for(int i=0;dis2(symbols[i],target)>speed;i++)
//	{symbols.push_back(console->closestPos(symbols[i],speed,target));}
//	symbols.push_back(target);
//	vector<Pos> blocks,path;
//    blocks.clear();
 //   path.clear();
//    for(int j = 0; j < AIHeroList.size(); ++j)
//        if (AIHeroList[j]->getMyhero()->id != worker->id)
 //           blocks.push_back(AIHeroList[j]->getMyhero()->pos);
//    for(int k = 0; k < MINE_NUM; ++k)
 //       for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
//            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
//                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
//    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
 //       blocks.push_back(MILITARY_BASE_POS[k]);
//	findShortestPathWithSymbols(themap,symbols,blocks,path);
//	console->move(path,worker);
//}

void GoMining::movein(const Pos& target)
{
    vector<Pos> blocks,path;
    blocks.clear();
    path.clear();
     for(int i = -40; i <=40; ++i)
	{
		blocks.push_back(Pos(abs(enemybasepos.x-75)+i, abs(enemybasepos.y-75)+i));
	}
    Pos destination = (Pos)target;
    findShortestPath(themap, worker->pos, destination, blocks, path);
    console->move (path,worker);
}

void GoMining::work()
{
	console->selectUnit(worker);
	//if(worker->canUseSkill("Blink") && RANK<=200 && dis2(worker->pos,Pos(75,75))>=BLINK_RANGE && targetpos==MINE_POS[0]&&themap.getHeight(console->closestPos(worker->pos, BLINK_RANGE, Pos(75,75)).x,console->closestPos(worker->pos, BLINK_RANGE, Pos(75,75)).y)<5)
	//		console->useSkill("Blink", console->closestPos(worker->pos, BLINK_RANGE, Pos(75,75)));
	//else
	//{
	//if(targetpos == MINE_POS[1] || targetpos == MINE_POS[4])
	//	if(NearMineGroup<2 && worker->level<5)
	//		console->move(console->closestPos(targetpos, 144 ,Pos(75,75)));
	//	else
	//		console->move(targetpos);
	//else if(targetpos == MINE_POS[0])
		///if(CenterMineGroup>=3)
	//		console->move(targetpos);
		//else
		//	console->move(console->closestPos(targetpos, 144 ,console->getMilitaryBase()->pos));
	//else if(dis2(worker->pos,Pos(135,15))<=dis(crossingPos,Pos(135,15))-worker->speed &&dis2(worker->pos,targetpos)>=dis2(crossingPos,targetpos)+worker->speed && targetpos==MINE_POS[0])
		//moveinline(console->randPosInArea(crossingPos,16),worker->speed);
	//else if(targetpos==MINE_POS[0])
	//	if(dis2(worker->pos,Pos(75,75))>256)
	//		moveinline();
	//	else console->move(console->closestPos(targetpos, 9 ,console->getMilitaryBase()->pos));
	//else
		movein(targetpos);
	//}
}

int GoBackHome::countWorth()
{
		this->worth = 0;
		//if((worker->name == "Master"||worker->name == "Scouter") && (worker->findBuff("beAttack") != NULL&&console->getBuff("beAttack",worker)->timeLeft == 3))
		//	this->worth = goBackHomeArg * goBackHomeHp/(double)worker->hp ;
		 if(worker->hp <= goBackHomeHp && (strcmp(worker->name, "Berserker") != 0) && (worker->findBuff("beAttack") != NULL&&console->getBuff("beAttack",worker)->timeLeft >= 2)) 
			this->worth = goBackHomeArg * goBackHomeHp/(double)worker->hp ;
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	UnitFilter filter;
	filter.setAreaFilter (new Circle (worker->pos, 144), "a");
	filter.setAvoidFilter ("Mine");
	filter.setAvoidFilter ("Observer");
	vector<PUnit*> ENEMY_HEROS = console->enemyUnits();
	if(ENEMY_HEROS.size()!=0)
		console->move(console->closestPos(worker->pos, worker->speed ,console->getMilitaryBase()->pos));
	else
		console->move(worker->pos);
}

int CallBackHome::countWorth()
{
	
	DefenceGroup = 8*( 3000 - console->getMilitaryBase()->hp ) / (double)3000 + 0.1 ;
	if(DefenceRank + DefenceRankInterval >RANK)
		DefenceGroup += 2;
	this->worth = 0;
	if(RANK>200 )
	{
		k=0;
		if( dis2(worker->pos, console->getMilitaryBase()->pos) >= 144*4)
			if(dis2(worker->pos, console->getMilitaryBase()->pos) <= AtkBaseRange || console->gold () >= console->callBackCost(worker->level))
			this ->worth += dis(worker->pos,console->getMilitaryBase()->pos) + StayBaseDefenceArg;
		this->worth += callBackHomeArg;
		for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getStrategy() != NULL)
			if(AIHeroList[i]->getStrategy()->getName() == "Defence"|| AIHeroList[i]->getStrategy()->getName() == "CallBackHome" || ((AIHeroList[i]->getStrategy()->getName() == "Attack"||AIHeroList[i]->getStrategy()->getName() == "UseSkill")&&dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,console->getMilitaryBase()->pos)<=supportRange))
			{this->worth -= StayBaseDefenceArg/(double)DefenceGroup;k++;}
		if(console->getMilitaryBase()->hp >= basehp)
			this->worth = 0 ;
		//if(dis2(worker->pos, console->getMilitaryBase()->pos) <= DefenceRange*4 &&  k >= DefenceGroup)
				//this->worth = 0;
		//if( k >= DefenceGroup)
			//this->worth = 0;
	}
	return this->worth;
}

void CallBackHome::work()
{
	Pos startpos[8]={console->closestPos(console->getMilitaryBase()->pos,20, Pos(15,135))};
	startpos[1]=startpos[0]+Pos(1,0);
	startpos[2]=startpos[0]+Pos(0,1);
	startpos[3]=startpos[0]+Pos(-1,1);
	startpos[4]=startpos[0]+Pos(1,-1);
	startpos[5]=startpos[0]+Pos(0,2);
	startpos[6]=startpos[0]+Pos(2,0);
	startpos[7]=startpos[0]+Pos(1,1);
	basehp = console->getMilitaryBase()->hp;
	if(console->gold () >= console->callBackCost(worker->level))
	console->callBackHero(worker,console->randPosInArea(startpos[k-1],19));
	else
	{
	console->selectUnit((const PUnit*)worker);
	console->move(console->getMilitaryBase()->pos);
	}
	StealRank = RANK-StealRankInterval;
}
int BuyBackHome::countWorth()
{
	q=0;
	DefenceGroup = 8*( 3000 - console->getMilitaryBase()->hp ) / (double)3000 + 0.1 ;
	if(DefenceRank + DefenceRankInterval >RANK)
		DefenceGroup += 2;
	this->worth = 0;
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getMyhero()->findBuff("Reviving")!=NULL)
			q++;
	if(RANK>150 && worker->findBuff("Reviving") != NULL)
	{
		k=0;
		this->worth += callBackHomeArg;
		for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i]->getStrategy() != NULL)
			if(AIHeroList[i]->getStrategy()->getName() == "Defence"|| AIHeroList[i]->getStrategy()->getName() == "CallBackHome" || ((AIHeroList[i]->getStrategy()->getName() == "Attack"||AIHeroList[i]->getStrategy()->getName() == "UseSkill")&&dis2(AIHeroList[i]->getStrategy()->getWorker()->pos,console->getMilitaryBase()->pos)<=supportRange))
			{this->worth -= StayBaseDefenceArg/(double)DefenceGroup;k++;}
		if(console->getMilitaryBase()->hp >= basehp)
			this->worth = 0 ;
		if( k < DefenceGroup && q>k)
			this ->worth += dis(worker->pos,console->getMilitaryBase()->pos) + StayBaseDefenceArg;
		//if(dis2(worker->pos, console->getMilitaryBase()->pos) <= DefenceRange*4 &&  k >= DefenceGroup)
				//this->worth = 0;
		//if( k >= DefenceGroup)
			//this->worth = 0;
	}
	
	return this->worth;
}

void BuyBackHome::work()
{
	if(console->gold () >= console->buyBackCost(worker->level))
		console->buyBackHero(worker,console->randPosInArea(console->getMilitaryBase()->pos,36));
}


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController controller(map,info,cmd);
	RANK++;
	themap=map;
	//if(info.player==0)
	//{
	if(info.round == 0)
	{
		for(int i = 1; i <= 3; ++i)
			controller.buyNewHero();
		return;
	}
	else if(info.round >= 3)
	{
	if(newHeroFirst)
	{
		controller.buyNewHero();
		controller.levelupHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	}
	controller.action();
	//}
}
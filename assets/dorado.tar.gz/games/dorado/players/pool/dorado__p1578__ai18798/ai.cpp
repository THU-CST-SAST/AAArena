#include "console.h"
#include "sdk.h"
#include "filter.h"
#include <iterator>
#include <vector>
#include <iterator>
#include <array>
#include <map>
#include <sstream>
#include <cassert>
#include <cstdlib>
#include <iostream>
using namespace std;
/****************************************
*杩欐槸涓€涓緢闀夸絾鏄緢寮辩殑鏍蜂緥AI
*鎴戝彧鏄瘯鍥惧鎵句竴绉嶆洿濂界殑鎺у埗浠ｇ爜鐨勬柟妗堬紝鑰屼笉鏄睍绀轰竴涓緢寮哄ぇ鐨凙I銆傛牴鎹互寰€鐨勭粡楠岋紝鍒颁簡鍐宠禌鍓嶅悗閫夋墜浠殑浠ｇ爜闀垮害閮藉湪鏁板崈琛屻€傝繖涔堝浠ｇ爜鍦ㄥ悓涓€涓枃浠朵腑鏄剧劧闈炲父闅句互绠＄悊銆傚埌浜嗛偅涓椂鍊欎綘鍙兘宸茬粡蹇樿浜嗘瘡涓€娈典唬鐮佸埌搴曟槸骞蹭粈涔堢殑锛屽彲鑳戒細鍑虹幇寰堝濂囨€殑bug銆?
*鍥犳鎴戦€夋嫨灏濊瘯鏋勫缓涓€涓鏋舵潵缁勭粐璧稟I鐨勬暣涓涓恒€?
*********************************************
*Condutor鏄叏灞€鐨勫垎鏋愬櫒锛屽畠鍦ㄦ暣鍦烘父鎴忎腑鍙垱寤轰竴涓紝浣滀负涓€涓潤鎬佸璞″瓨鍦ㄣ€傝繖浼氬甫鏉ヤ竴涓棶棰樺氨鏄笉鑳藉湪鏈湴杩愯鍚屼竴涓狝I鏂囦欢杩涜涓€鍦哄鎴橈紝涓嶈繃杩欏簲璇ュ苟涓嶅叧閿€傚鏋滀綘鐪熺殑鎯宠鍚屼竴涓狝I瀵规垬锛屼綘鍙互澶嶅埗涓€浠斤紝閲嶅懡鍚嶄竴涓嬪氨瑙ｅ喅浜嗐€?
*Soldier琛ㄧず涓€涓嫳闆勩€傛濡傛枃妗ｄ腑鎵€杩帮紝姣忎竴鍥炲悎鍚屼竴涓崟浣峀ogic浼犳潵鐨凱Unit閮芥槸鍏ㄦ柊鐨勶紝鎵€浠ユ垜闇€瑕佸彟澶栧啓涓€涓被鏉ヨ〃绀轰竴涓崟浣嶏紝杩欎釜绫荤殑瀵硅薄鏄叏灞€涓嶅彉鐨勩€?
*Team琛ㄧず鑻ュ共涓猄oldier缁勬垚鐨勯泦鍚堬紝鎴戠殑璁炬兂涓瑼I琛屽姩鐨勫熀鏈崟浣嶉兘鏄疶eam銆備綘鍙互棰勫厛鍐欏ソ涓€涓猅eam濡備綍鍘荤Щ鍔ㄨ€屼笉浜掔浉鍐茬獊锛屽浣曡繘琛屼竴鍦哄洟闃熶綔鎴樸€傜劧鍚庡湪鏇撮珮鐨勫眰闈笂浣犲氨鍙互绠€鍗曞湴鍙嶅璋冪敤杩欎簺鍑芥暟銆傝繖鍙互璁╀綘鎶婃洿澶氱殑绮惧姏鑺卞湪鎬濊€冩垬鐣ヤ笂鍚屾椂杩樹笉浼氬紩鍏ュ緢澶歜ug銆?
*Team涓湁涓€涓垚鍛樺彨action銆傝繖涓槸鐢ㄦ潵骞蹭粈涔堢殑鍛紵鍦ㄤ互寰€鐨凙I涓紝寰€寰€閮芥槸姣忓洖鍚堝垎鏋愬眬闈紝鐒跺悗鍋氬嚭鏂扮殑鍐崇瓥銆傝€屼綘涓婁竴鍥炲悎鎵€鍋氱殑鍐崇瓥寰堥毦琚竴浠ヨ疮涔嬨€傝繖涓猘ction灏辨槸鐢ㄦ潵璁板綍浣犳墍鍋氱殑鍐崇瓥锛岀劧鍚庡湪涔嬪悗鐨勮€冭檻涓綘灏卞彲浠ョ煡閬撲箣鍓嶇殑鍐崇瓥鏄粈涔堬紝鏄缁х画杩樻槸閲嶆柊鍐崇瓥銆備娇鐢ㄥ湪Global Function閭ｄ竴閮ㄥ垎锛屾垜宸茬粡瀹炵幇浜嗕竴浜涙柟娉曞府鍔╀綘鍒嗘瀽瀹冦€?
*GoldField鏄噾鐭匡紝Base鏄熀鍦般€備粬浠殑浣滅敤鍜宻oldier涓€鑷淬€?
*Field鏄垜璁炬兂鐨勫叧閿€備粬琛ㄧず涓€涓簨浠讹紝姣斿鍙戠幇鏁屼汉锛屽彂鐜伴噾鐭跨瓑绛夛紝浣犲彲浠ユ洿鍔犵粏鍖栧畠浠€傞鍏堝湪姣忎竴鍥炲悎鍒嗘瀽鍑烘墍鏈夌殑Filed銆傜劧鍚庝綘鐨勫喅绛栧氨鏄拡瀵硅繖浜汧ield鏉ヨ繘琛屽弽搴斻€備綘鍙互涓嶆柇缁嗗寲浜х敓Field鐨勬潯浠讹紝閫氳繃杩欑鏂瑰紡鏉ュ紩鍏ユ柊鐨勫喅绛栥€傚湪杩欎釜杩囩▼涓紝浣犵殑浠ｇ爜閮芥槸鍦ㄤ竴涓浐瀹氱殑妗嗘灦涓嬪鍔狅紝寮曞叆鏂癰ug锛岀牬鍧忎箣鍓嶄唬鐮佹垚鏋滅殑鍙兘鎬у皢澶уぇ闄嶄綆銆?
*娌℃湁Field鐨勬椂鍊欐€庝箞鍔炲憿锛熷湪Condutor鏈変竴涓猠xplore鍑芥暟锛岃〃绀烘病鏈夊幓搴斿Field鐨勫崟浣嶅皢鍋氫粈涔堛€?
********************************************
*濡傛灉浣犺寰楄繖浠芥牱渚嬩笉鍚堜綘鐨勮儍鍙ｏ紝閭ｄ箞鎴戝笇鏈涘畠鑳界粰浣犱竴绉嶆柊鐨勬€濈淮鏂瑰紡锛屽府鍔╀綘鎵惧埌鏇村ソ鐨凙I缂栧啓鏂规硶銆?
*濡傛灉浣犳兂瑕佸湪杩欎唤妗嗘灦鐨勫熀纭€涓婃敼鍔ㄦ潵鍒涢€犱綘鑷繁鐨凙I锛屾垜鐨勫缓璁槸淇敼Soldier鍜孴eam鐨刴ove鍜宎ttack锛岃浠栦滑鍙樺緱澶嶆潅璧锋潵锛岃繖閲屽喅瀹氱潃浣犵殑AI鐨勬垬鏈按骞炽€傚彟澶栧氨鏄疌ondutor涓垎鏋怓ield鍜屽簲瀵笷ield锛屼互鍙奺xplore锛岃繖鏄綋鐜板喅绛栫殑鍦版柟銆?
*****************************************/
/*********************************************************************
 *                              Some const variable
**********************************************************************/
const int HeroTypeNum = 4;//鑻遍泟绉嶇被
const int MonsterTypeNum = 2;//閲庢€绫?
const int UnitTypeNum = 8;//鍗曚綅绉嶇被
const int GeneralView = 144;//鏅亶鍗曚綅鐨勮閲庨兘鏄?44锛岃繖閲屾垜鐢ㄥ畠鏉ュ仛涓€浜涘ぇ鑷寸殑浼拌銆?
const int GeneralSpeed = 15;
const int GeneralOneStepReach = 144;//鍚屼笂锛屽彧鏄敤鏉ュ仛涓€涓ぇ姒傜殑浼拌銆?
enum UnitType:int {Hammerguard = 0, Master = 1, Berserker, Scouter, Mine, MilitaryBase, Dragon, Roshan, Unknown};//瀹氫箟浜嗗崟浣嶇殑绫诲瀷銆傚彧鏄负浜嗛伩鍏嶄竴鐩翠娇鐢ㄥ瓧绗︿覆锛?
enum {NORMAL, DIRECT, FASTMOVE};//绉诲姩鐨勬ā寮忥紝鍦═eam锛氾細move涓敤鍒般€侼ORMAL琛ㄧず绠€鍗曠殑绉诲姩锛屼笅涓€鍥炲悎涓嶇户缁€侱IRECT琛ㄧず涓嬩竴鍥炲悎鏃犺濡備綍閮藉皢缁х画鍚戝師瀹氱殑涓€姝ヨ蛋涓嶅畬鐨勯偅涓洰鏍囧墠杩涖€備綘鍙互瀹氫箟鏇村鐨勭Щ鍔ㄦ柟妗堬紝鎴栬€呭幓鎺夎繖涓鎬殑鏈哄埗銆?
const array<string, UnitTypeNum> unitName{{"Hammerguard", "Master", "Berserker", "Scouter", "Mine", "MilitaryBase", "Dragon", "Roshan"}};//鏋氫妇鍗曚綅绫诲瀷鐨勫瓧绗︿覆锛屽拰涓婇潰瀹氫箟鐨勬暟鍊煎搴斻€?
const array<int, HeroTypeNum> cost{{NEW_HAMMERGUARD_COST, NEW_MASTER_COST, NEW_BERSERKER_COST, NEW_SCOUTER_COST}};//鍜孶nitType瀵瑰簲銆?
#define SIZE(x) (int(x.size()))//涓轰簡鏂逛究鍦版妸size锛堬級杩斿洖鐨勬棤绗﹀彿鍊艰浆鍖栦负鏈夌鍙峰€笺€?
bool operator< (const Pos&, const Pos&);//涓轰簡浣跨敤std::map<Pos,*>,骞舵病鏈夊疄闄呯殑鎰忎箟銆?
#define LOCAL//鎵€鏈夌郴缁熻皟鐢ㄦ渶濂介兘鐢ㄨ繖涓畯鍖呰捣鏉ワ紝灏卞儚涓嬮潰瀹氫箟fout閭ｆ牱銆傚綋浣犳兂瑕佸悜缃戠珯涓婃彁浜ゆ椂锛屽彧瑕佹敞閲婃帀杩欎竴琛屽氨鍙互浜嗐€?
#ifdef LOCAL
#include <fstream>
static ofstream fout("log.txt");
#endif
#ifdef LOCAL
/*****************************************************
*               Log Declarotion
******************************************************/
class Log
//涓€涓敤鏉ヨ緭鍑鸿皟璇曠殑绫汇€?
{
public:
    Log (const string& _str, ostream& = cout);
    ~Log ();
private:
    int startTime;
    ostream& os;
    string str;
};
#endif
/************************************************************
 *                              Soldier Declaration
************************************************************/
struct Soldier
{
    Soldier (PUnit* = nullptr);
    void move(const Pos& pos);
    void attack (const Soldier& target, const string& command = "attack");//command琛ㄧず鏀诲嚮鐨勬ā寮忥紝鍥犱负鎴戣鎯崇殑鏄疭oldier 鐨勬敾鍑婚兘鏄湪Team涓繘琛岋紝Team鍙兘甯屾湜杩欎釜鍗曚綅瀹炵幇鏌愮鐩殑姣斿鐪╂檿锛屽紩寮€绛夌瓑锛岄€氳繃杩欎釜瀛楃涓插氨鍙互鍛婄煡杩欎釜Soldier銆?

    UnitType type;
    PUnit* ptr;
    int id;
};
/*********************************************************************
 *                              GoldField Declaration
**********************************************************************/
struct GoldField
{
    int id;
    int energy;//-1 unknown
    Pos pos;//the pos of the mine
    vector<Soldier*> myUnits;//闄勮繎鐨勫繁鏂瑰崟浣?
    vector<Soldier*> otherUnits;
    Soldier* monster;
};
/*********************************************************************
 *                              Base Declaration
**********************************************************************/
struct Base
{
    PUnit* ptr;
    Pos pos;
    int hp;
};
/*********************************************************************
 *                              Team Declaration
**********************************************************************/
struct Team
{
    Team (const vector<Soldier*>&);
    ~Team ();
    void move (Geometry*, int mode = NORMAL);//鍚庨潰鐨勮〃绀虹Щ鍔ㄦā寮忋€?
    void attack (Soldier*);
    void attack (vector<Soldier*>&);
    void defence (Geometry*);

    vector<string> action;
    Geometry* target;//set by move();涓婂洖鍚堢Щ鍔ㄧ殑鐩爣
    //mine:id 鍦ㄩ噰鐭匡紝鐭跨殑id
    //offense 鍦ㄨ繘鏀诲鏂瑰熀鍦?
    //defence 鍦ㄩ槻瀹堝繁鏂瑰熀鍦?
    //moveMode:mode 鍦ㄧЩ鍔紝绉诲姩妯″紡
    //round:round 涓婁竴涓猘ction鐨勫洖鍚堟暟銆?
    vector<Soldier*> soldiers;
};
/*********************************************************************
 *                              Field Declaration
**********************************************************************/
struct Field
{
    vector<Geometry*> geos;//鍙戠敓鐨勭殑鍖哄煙
    bool contain (const Pos&);

    vector<string> event;//鎻忚堪鍙戠敓鐨勪簨浠?
};
/*********************************************************************
 *                              Soldier Declaration
**********************************************************************/
class Condutor
{
public:
    Condutor ();
    void updateSituation();
    void start ();
protected:
    //鏍规嵁褰撳墠灞€闈㈠垎鏋愬嚭鎵€鏈夌殑Field
    void analyseSituation ();
    //鍒ゆ柇涓婁竴鍥炲悎鐨勬搷浣滄槸鍚︾户缁笅鍘?
    void goingOn ();
    //缁勭粐鏂扮殑Team鏉ュ簲瀵笷ield
    void organizeNewTeamsForField();
    //灏濊瘯璐拱鏂拌嫳闆勩€?
    void buyNewSoldier ();
    //灏濊瘯鍘诲崌绾с€?
    void levelUp ();
    //called in updateSituation
    void updateMyUnits ();
    void updateGoldFieldAndMonsterStatus ();
    void updateEnemyStatus ();
    void explore ();
    //about team
    Team* buildTeam (const vector<Soldier*>&);//缁勫缓鏂癟eam锛岀粍鍏eam鐨凷oldier浼氳绉诲嚭availSoldiers;
    Team* buildTeam (const Soldier*);
    //瑙ｆ暎涓€涓猅eam,soldier閲嶆柊杩涘叆availSoldiers;
    void breakUpTeam (Team*&);
    //瑙ｆ暎鎵€鏈夌殑杩欎竴鍥炲悎杩樻病鏈夋墽琛宎ction鐨凾eam銆備綘闇€瑕佸強鏃舵洿鏂癮ction涓殑round銆?
    void breakUpOldTeams ();
    //鎶婁竴浜涘崟浣嶆寜鐗瑰畾鏉′欢锛堢幇鍦ㄦ槸鍙湅璺濈锛夊垝鍒嗚繘涓€浜汿eam涓€?
    vector<Team*> buildIntoTeams (const vector<Soldier*>&);
protected:
    //clear every round
    vector<Field*> fields;//褰撳墠鍥炲悎鐨凢ield
    vector<string> status;//璁板綍褰撳墠鍥炲悎鐨勪竴浜涚姸鎬併€?
    //鍥犱负浣犵殑鍐崇瓥鏄『搴忔墽琛岀殑锛屼絾鏄綘涔嬪墠鐨勫喅绛栦篃璁稿笇鏈涘幓褰卞搷涔嬪悗鐨勫喅绛栵紝姣斿浣犲湪涓€寮€濮嬪喅瀹氶渶瑕佹敀涓€鐐归挶鑰屼笉鏄叏鑺卞厜锛屼綘灏卞湪鍏朵腑鍔犲叆remain:1000锛屼箣鍚庝拱鑻遍泟鐨勬椂鍊欏氨鐭ラ亾闇€瑕佺暀涓嬭繖涔堝閽便€?
    //blockLevelUp:id 涓嶅笇鏈涚寮€鎴樺満鍥炲幓鍗囩骇鐨勮嫳闆?
    //remain:gold 闇€瑕佹敀涓嬬殑閽?

    //static
    map<Pos, GoldField*> pos2mine;//閫氳繃pos寰楀埌涓€涓狹ine*
    map<int, Soldier*> id2soldier;//閫氳繃id寰楀埌涓€涓猄oldier*

    vector<GoldField*> mines;
    vector<Team*> teams;
    vector<Soldier*> availSoldiers;
    vector<Soldier*> enemys;
    vector<Soldier*> monsters;
    Base* base;
    Base *enemyBase;
    vector<Soldier*> allSoldiers;
};
/*********************************************************************
 *                              Global
**********************************************************************/
//Warning: You can't define a variable here. Only pointer is accepted.
//Eg. if you write "static Condutor consutor;", logic won't load your ai successfully.
static Condutor* condutor = nullptr;
static Console* console = nullptr;
//鍦ㄤ笅闈㈢殑鍑芥暟涓紝琛ㄧず娌℃湁鎵惧埌涓€涓暟鍊兼椂鐨勯粯璁よ繑鍥炲€兼槸1<<30,鑰屼笉鏄?.鍥犱负0鍙兘鏈夋剰涔夈€?
//鍦ㄤ竴涓瓧绗︿覆鍒楄〃涓鎵緆ey涓簊tr鐨勭涓€涓獀alue
int value (const string& str, const vector<string>& status);
//鍦ㄤ竴涓瓧绗︿覆鍒楄〃涓鎵緆ey涓簊tr鐨勬墍鏈塿alue
vector<int> values (const string& str, const vector<string>& status);
//鍒楄〃涓洿鏂発ey涓簊tr鐨勭涓€涓獀alue锛屾病鏈夊垯鍔犲叆涔嬨€?
void updateValue (const string& name, vector<string>& status, int newValue);
//鍒犻櫎鍒楄〃涓墠n涓猭ey涓簄ame鐨勯」锛岄粯璁ゅ叏閮ㄥ垹闄ゃ€?
void removeEntry (const string& name, vector<string>& status, int n = -1);
//鍒犻櫎鍒楄〃涓璳ey涓簄ame锛寁alue涓簐alue鐨勭壒瀹氫竴椤?
void removeEntry (const string& name, int value, vector<string>& status);
//鎻掑叆涓€涓柊鐨勯」锛岄粯璁ゆ病鏈塿alue
void insertEntry (const string& key, vector<string>& status, int value = 1 << 30);
//鍒ゆ柇瀵瑰簲閿€肩殑椤规槸鍚﹀瓨鍦?
bool exist (const string&, std::vector<string>& );
/*********************************************************************
 *                              main
**********************************************************************/
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
#ifdef LOCAL
    fout << "round:" << info.round << " start" << endl;
#endif
    console = new Console (map, info, cmd);
    if (console->round() == 0)
        condutor = new Condutor();
    condutor->updateSituation ();
    condutor->start();
    delete console;
#ifdef LOCAL
    for (auto op: cmd.cmds)
    {
        fout << "id:" << op.id << ";type:" << op.type << ";targets:";
        for (auto pos: op.targets)
            fout << pos << " ";
        fout << endl;
    }
    fout << "round:" << info.round << " end" << endl;
#endif
}
/*********************************************
*           Global function
**********************************************/
bool operator< (const Pos& a, const Pos& b)
{
     return a.x + a.y < b.x + b.y;
}
UnitType name2type (const string& name)
{
    if (lowerCase(name) == lowerCase("Hammerguard"))
        return Hammerguard;
    else if (lowerCase(name) == lowerCase("Master"))
        return Master;
    else if (lowerCase(name) == lowerCase("Berserker"))
        return Berserker;
    else if (lowerCase(name) == lowerCase("Scouter"))
        return Scouter;
    else if (lowerCase(name) == lowerCase("GoldField"))
        return Mine;
    else if (lowerCase(name) == lowerCase("MilitaryBase"))
        return MilitaryBase;
    else if (lowerCase(name) == lowerCase("Dragon"))
        return Dragon;
    else if (lowerCase(name) == lowerCase("Roshan"))
        return Roshan;
}
//鍋囧畾涓€涓瓧绗︿覆鏄痳ound:12 閭ｄ箞鍐掑彿鍓嶇殑round灏辨槸key锛屽啋鍙峰悗鐨?2灏辨槸value
string getKey (const string& str)
{
    string res;
    for (auto c: str)
        if (c != ':')
            res += c;
        else
            break;
    return move(res);
}
string getValue (const string& str)
{
    string s = str;
    for (int i = 0; i < SIZE(s); ++i)
    {
        char tmp = s[i];
        s.erase(begin(s) + i--);
        if (tmp == ':')
            break;
    }
    return move(s);
}
//绠€鍗曞湴瀹炵幇瀛楃涓插拰鏁板€肩殑鐩镐簰杞崲銆?
int string2int (const string& str)
{
    if (str.empty())
        return 1 << 30;
    int res = 1 << 30;
    stringstream in(str);
    in >> res;
    return res;
}
string int2string (int v)
{
    stringstream in;
    in << v;
    return move(in.str());
}
//鍦ㄤ竴涓瓧绗︿覆鍒楄〃涓鎵緆ey涓簊tr鐨勭涓€涓獀alue
int value (const string& str, const vector<string>& status)
{
    int res = 1 << 30;
    for (auto s: status)
        if (getKey(s) == str)
        {
            res = string2int(getValue(s));
            break;
        }
    return res;
}
//鍦ㄤ竴涓瓧绗︿覆鍒楄〃涓鎵緆ey涓簊tr鐨勬墍鏈塿alue
vector<int> values (const string& str, const vector<string>& status)
{
    vector<int> res;
    for (auto s:status)
        if (getKey(s) == str)
            res.push_back(string2int(getValue(str)));
    return move(res);
}
//鍦ㄤ竴涓瓧绗︿覆鍒楄〃涓洿鏂発ey涓簊tr鐨勭涓€涓獀alue锛屾病鏈夊垯鍔犲叆涔嬨€?
void updateValue (const string& name, vector<string>& status, int newValue)
{
    bool find = false;
    for (auto str: status)
    {
        if (getKey(str) == name)
        {
            str = name + int2string(newValue);
            find = true;
            break;
        }
    }
    if (!find)
        status.push_back (name + ":" + int2string(newValue));
}
void removeEntry (const string& name, vector<string>& status, int maxNum)
{
    if (maxNum < 0)
        maxNum = status.size();
    for (auto iter = begin(status); iter != end(status);)
    {
        if (maxNum == 0)
            return;
        if (getKey(*iter) == name)
        {
            --maxNum;
            status.erase (iter);
        }
        else
            ++iter;
    }
}
void removeEntry (const string& name, int value, vector<string>& status)
{
    string entry;
    if (value != 1 << 30)
        entry = name + ":" + int2string(value);
    else
        entry = name;
    for (auto iter = begin(status); iter != end(status); ++iter)
    {
        if (*iter == entry)
        {
            status.erase (iter);
            return;
        }
    }
}
void insertEntry (const string& key, vector<string>& status, int value)
{
    if (value < 1 << 30)
        status.push_back (key + ":" + int2string(value));
    else
        status.push_back (key);
}
bool exist (const string& name, vector<string>& status)
{
    for (auto str: status)
    {
        if (getKey(str) == name)
        {
            return true;
        }
    }
    return false;
}
#ifdef LOCAL
/**********************************************
*                 Log Definition
***********************************************/
Log::Log (const string& _str, ostream& _os): str(_str), os(_os)
{
    os << str << " " << "start" << endl;
    startTime = clock ();
}
Log::~Log ()
{
    os << str << " " << "end, time cost:" << clock() - startTime <<  endl;
}
#endif
/*********************************************************************
 *                              Condutor Definition
**********************************************************************/
Condutor::Condutor ()
{
    //clear
    fields.clear();
    status.clear();
    teams.clear();
    availSoldiers.clear();
    enemys.clear();
    base = new Base;
    enemyBase = new Base;
    enemyBase->hp = base->hp = 5000;
    base->pos = MILITARY_BASE_POS[console->camp()];
    enemyBase->pos = MILITARY_BASE_POS[1-console->camp()];
    //add mine
    for (int i = 0; i < MINE_NUM; ++i)
    {
        GoldField* mine = new GoldField;
        mine->id = i;
        mine->energy = -1;
        mine->pos = MINE_POS[i];
        pos2mine[mine->pos] = mine;
        mine->monster = nullptr;
        mine->myUnits.clear();
        mine->otherUnits.clear();
        mines.push_back(mine);
    }
    for (int i = 0; i < 100; ++i)
        id2soldier[i] = nullptr;
}
void Condutor::updateSituation ()
{
    //the order of calling these three function is important and shouldn'd be changed
    updateMyUnits ();
    updateEnemyStatus ();
    updateGoldFieldAndMonsterStatus ();
}
void Condutor::start()
{
    //analyse the situation and build filelds
    analyseSituation ();
#ifdef LOCAL
    fout << "fileds" << endl;
    for (auto f:fields)
    {
        for (auto g: f->geos)
            g->output (fout);
        for (auto e: f->event)
            fout << e << ";";
        fout << endl;
     //
    }
#endif
    goingOn ();
    //break up teams without new action
    breakUpOldTeams ();
#ifdef LOCAL
    fout << "teams" << endl;
    for (auto team: teams)
    {
        fout << "id:";
        for (auto s: team->soldiers)
            fout << s->id << " ";
        fout << "; action:";
        for (auto a:team->action)
            fout << a << ";";
        fout << endl;
    }
#endif
    //organize the availble heros to new Teams to respound to events
    organizeNewTeamsForField();
    //get new Soldiers
    buyNewSoldier ();
     //make teams for upgrading
    levelUp ();
    //available units to explore
    explore ();
}
void Condutor::analyseSituation ()
{
    fields.clear();
    vector<Soldier*> es = enemys;
    for (auto e: monsters)
        es.push_back (e);
    for (auto enemy: es)//閬嶅巻鏁屼汉
    {
        if (enemy->ptr == nullptr || (console->getBuff("Reviving", enemy->ptr) != 0))
            continue;
        //涓嶉噸澶嶅彂鐜颁簨浠?
        bool found = false;
        for (auto field: fields)
        {
            if (field->contain (enemy->ptr->pos))
            {
                found = true;
                break;
            }
        }
        if (found)
            continue;
        Field* field = new Field;
        //濡傛灉涓嶅湪鍩哄湴
        if (dis2(base->pos, enemy->ptr->pos) > GeneralView)
        {
            field->geos.push_back(new Circle(enemy->ptr->pos, GeneralView * 2));
            insertEntry ("enemyFound", field->event);
        }
        //鍚﹀垯
        else
        {
            field->geos.push_back (new Circle(base->pos, GeneralView * 2));
            insertEntry ("baseAttacked", field->event);
        }
        fields.push_back (field);
    }
    //閬嶅巻閲戠熆
    for (auto mine: mines)
    {
        if (mine->myUnits.size() && !mine->otherUnits.size() && mine->monster != nullptr && mine->monster->ptr == nullptr && mine->energy > 0)
        {
            Field* field = new Field;
            field->geos.push_back(new Circle(mine->pos, GeneralView));
            insertEntry ("mineClear", field->event, mine->id);
            insertEntry ("mineId", field->event, mine->id);
            fields.push_back (field);
        }
    }
    UnitFilter filter;
    filter.setTypeFilter("militarybase");
    if (console->enemyUnits(filter).size())
    {
        Field* field = new Field;
        field->geos.push_back (new Circle(enemyBase->pos, GeneralView * 2));
        insertEntry ("offense", field->event);
        fields.push_back (field);
    }
}
void Condutor::goingOn ()
{
    //杩樺彧浼氬喅瀹氭槸鍚︾户缁笂涓€鍥炲悎鐨勭Щ鍔ㄣ€?
    for (auto team: teams)
    {
        if (team->target == nullptr || value("modeMode", team->action) == 1 << 30 || value("round", team->action) == console->round() || value("moveMode", team->action) == NORMAL)
            continue;
        team->move (team->target, DIRECT);
    }
}
void Condutor::organizeNewTeamsForField ()
{
    for (auto f: fields)
    {
        if (exist("enemyFound", f->event))
        {
            vector<Soldier*> s, e;
            for (auto ptr: availSoldiers)
            {
                if (f->contain(ptr->ptr->pos))
                    s.push_back (ptr);
            }
            if (s.size() == 0)
            {
                cout << "warning: no myUnits found in field area" << endl;
                continue;
            }
            Team* t = buildTeam (s);
            for (auto ptr: enemys)
            {
                if (ptr->ptr != nullptr && f->contain(ptr->ptr->pos))
                    e.push_back (ptr);
            }
            for (auto ptr: monsters)
            {
                if (ptr->ptr != nullptr && f->contain(ptr->ptr->pos))
                    e.push_back (ptr);
            }
            t->attack (e);
        }
        else if (value ("mineClear", f->event) != 1 << 30)
        {
            Team* t = buildTeam (availSoldiers.front());
            if (t == nullptr)
                break;
            t->move (new Circle(mines[value("mineId", f->event)]->pos, MINING_RANGE));
            insertEntry ("mine", t->action, value ("mineClear", f->event));
        }
        else if (exist ("baseAttacked", f->event))
        {
            Team* t = buildTeam (availSoldiers);
            t->move(f->geos.front());
            insertEntry ("moveMode", t->action, FASTMOVE);
            insertEntry ("modeRoundLimit", t->action, 3);
        }
        else if (exist("offense", f->event))
        {
            vector<Soldier*> s, e;
            for (auto ptr: availSoldiers)
            {
                if (f->contain(ptr->ptr->pos))
                    s.push_back (ptr);
            }
            if (s.size() == 0)
            {
                cout << "warning: no myUnits found in field area" << endl;
                continue;
            }
            Team* t = buildTeam (s);
            insertEntry ("offense", t->action);
            Soldier* eBase = new Soldier (enemyBase->ptr);
            t->attack (eBase);
            delete eBase;
        }
    }
}
void Condutor::buyNewSoldier ()
{
    array<int, HeroTypeNum> heroNum{{0, 0, 0, 0}};
    for (auto soldier: allSoldiers)
        ++heroNum[soldier->type];
    int sum = 0;
    for (auto num: heroNum)
        sum += num;
    while (sum < HERO_LIMIT)
    {
        int remain = value("remainGold", status);
        if (remain == 1 << 30)
            remain = 0;
        UnitType toBuy = Unknown;
        int minNum = 1 << 30;
        for (int i = 0; i < SIZE(heroNum); ++i)
            if (heroNum[i] < minNum)
            {
                toBuy = UnitType(i);
                minNum = heroNum[i];
            }
        if (console->gold() - console->goldCostCurrentRound() > cost[toBuy] * (heroNum[toBuy] + 1) + remain)
        {
            console->chooseHero (unitName[toBuy]);
            ++heroNum[toBuy];
            ++sum;
        }
        else
            break;
    }
}
void Condutor::levelUp ()
{
    vector<int> levelUpBlocks = values("blockLevelUp", status);
    for (auto ptr = begin(availSoldiers); ptr != end(availSoldiers); )
    {
        int remain = value("remainGold", status);
        if (remain == 1 << 30)
            remain = 0;
        if (find(begin(levelUpBlocks), end(levelUpBlocks), (*ptr)->id) != end(levelUpBlocks))
            continue;
        int level = console->unitArg("level", "c", (*ptr)->ptr);
        bool erased = false;
        while (level < HERO_LEVEL_LIMIT && console->gold() - console->goldCostCurrentRound() > remain + console->levelUpCost(level))
        {
            if (dis2((*ptr)->ptr->pos, base->pos) > LEVELUP_RANGE)
            {
                Team* newTeam = buildTeam ((*ptr));
                erased = true;
                newTeam->move (new Circle(base->pos, LEVELUP_RANGE), NORMAL);
                break;
            }
            ++level;
            console->buyHeroLevel((*ptr)->ptr);
        }
        if (!erased)
            ++ptr;
    }
}
void Condutor::explore ()
{
    vector<int> blocks;
    vector<Soldier*> toExplore = availSoldiers;
    for (auto iter = begin(toExplore); iter != end(toExplore); ++iter)
    {
        if (find(begin(blocks), end(blocks), (*iter)->id) != end(blocks))
            toExplore.erase(iter);
    }
    map<int, bool> freeMine;
    for (int i = 0; i < MINE_NUM; ++i)
    {
        if (mines[i]->energy < 0 || mines[i]->energy > 0)
            freeMine[i] = true;
        else
            freeMine[i] = false;
    }
    for (auto team: teams)
    {
        int id;
        if ((id = value("mine", team->action)) < MINE_NUM)
            freeMine[id] = false;
    }

    vector<Team*> exploreTeams = buildIntoTeams(toExplore);

    for (auto team = begin(exploreTeams); team != end(exploreTeams); )
    {
        int rank = -1;
        for (int i = 0; i < MINE_NUM; ++i)
            if (freeMine[i])
            {
                rank = i;
                break;
            }
        if (rank < 0)
            break;
        (*team)->move (new Circle(MINE_POS[rank], GeneralView - 1), DIRECT);
        freeMine[rank] = false;
        exploreTeams.erase (team);
    }
    int ls = 0;
    for (auto t: exploreTeams)
    {
        for (auto s: t->soldiers)
            ls += s->ptr->level;
    } 
    for (auto team = begin(exploreTeams); team != end(exploreTeams); )
    {
        if (ls > 10)
            (*team)->move (new Circle(MILITARY_BASE_POS[1-console->camp()], GeneralView), DIRECT);
        else
            (*team)->move (new Circle(MILITARY_BASE_POS[1-console->camp()], GeneralView), NORMAL);
        exploreTeams.erase (team);
    }
}

//===============update=================
void Condutor::updateMyUnits ()
{
    for (auto hero: allSoldiers)//clear the ptrs to PUnit*
        hero->ptr = nullptr;
    base->ptr = nullptr;
    vector<PUnit*> units = console->friendlyUnits();
    for (auto ptr: units)
    {
        //if we find a militarybase
        if (lowerCase(ptr->name) == lowerCase("militaryBase"))
        {
            base->ptr = ptr;
            base->hp = ptr->hp;
        }
        //or we find a hero
        else if (ptr->isHero())
        {
            //if we find it first time
            if (id2soldier[ptr->id] == nullptr)
            {
                Soldier* soldier = new Soldier;
                soldier->id = ptr->id;
                soldier->ptr = ptr;
                soldier->type = name2type (ptr->name);
                id2soldier[ptr->id] = soldier;
                allSoldiers.push_back(soldier);
                availSoldiers.push_back(soldier);
            }
            else
                id2soldier[ptr->id]->ptr = ptr;
        }
        //or something else
        else
            cout << "warning: unknown friendly unit:" << ptr->id << " " << ptr->name << endl;
    }
    for (auto ptr: allSoldiers)
    {
        if (ptr->ptr == nullptr)
        {
            cout << "error" << endl;
            for (auto p: units)
                cout << p->id << " ";
            cout << endl;
            for (auto q: allSoldiers)
                cout << q->id << " ";
            cout << endl;
        }
    }
}
void Condutor::updateGoldFieldAndMonsterStatus ()
{
    for (auto mine: mines)
        if (mine->energy > 0)
            --mine->energy;
    UnitFilter filter;
    filter.setTypeFilter("mine");
    vector<PUnit*> units = console->enemyUnits(filter);
    for (auto ptr: units)
    {
        GoldField *mine;
        try
        {
            mine = pos2mine.at(ptr->pos);
        }
        catch (std::exception& e)
        {
            cout << "warning: unknown mine " << ptr->pos << " " << ptr->id << endl;
            continue;
        }
        mine->myUnits.clear();
        mine->otherUnits.clear();
        mine->energy = console->unitArg("energy", "c", ptr);
        UnitFilter nearby;
        nearby.setAvoidFilter("mine");
        nearby.setAreaFilter(new Circle(ptr->pos, GeneralView));
        vector<PUnit*> fs = console->friendlyUnits (nearby);
        vector<PUnit*> es = console->enemyUnits (nearby);
        for (auto f: fs)
        {
            if (id2soldier[f->id] == nullptr)
                cout << "error: undiscovered friendly unit, " << f->name << " " << f->id << endl;
            else
                mine->myUnits.push_back (id2soldier[f->id]);
        }
        for (auto e: es)
        {
            if (id2soldier[e->id] == nullptr)
                cout << "error: undiscovered enemy unit, " << e->name << " " << e->id << endl;
            else if (e->isHero())
                mine->otherUnits.push_back(id2soldier[e->id]);
            else if (e->isWild())
                mine->monster = id2soldier[e->id];
        }
    }
}
void Condutor::updateEnemyStatus ()
{
    for (auto e:enemys)
        e->ptr = nullptr;
    for (auto e: monsters)
        e->ptr = nullptr;
    enemyBase->ptr = nullptr;
    UnitFilter filter;
    filter.setAvoidFilter("mine");
    vector<PUnit*> es = console->enemyUnits (filter);
    for (auto ptr: es)
    {
        if (ptr->isHero())
        {
            if (id2soldier[ptr->id])
                id2soldier[ptr->id]->ptr = ptr;
            else
            {
                id2soldier[ptr->id] = new Soldier(ptr);
                enemys.push_back (id2soldier[ptr->id]);
            }
        }
        else if (ptr->isWild())
        {
            if (id2soldier[ptr->id])
                id2soldier[ptr->id]->ptr = ptr;
            else
            {
                id2soldier[ptr->id] = new Soldier(ptr);
                monsters.push_back (id2soldier[ptr->id]);
            }
        }
        else if (ptr->isBase ())
        {
            enemyBase->hp = ptr->hp;
            enemyBase->ptr = ptr;
        }
        else
            cout << "warning: unknown PUnit type, " << ptr->name << " " << ptr->id << ", in Condutor::updateEnemyStatus" << endl;
    }
}
void Condutor::breakUpOldTeams ()
{
    for (auto team: teams)
    {
        if (team == nullptr)
            continue;
        if (value ("round", team->action) != console->round ())
        {
            breakUpTeam (team);
        }
    }
}

void Condutor::breakUpTeam (Team*& t)
{
    if (t == nullptr)
        return;
    auto iter = find (begin(teams), end(teams), t);
    if (iter == end (teams))
        return;
    else
        teams.erase (iter);
    for (auto ptr: t->soldiers)
        availSoldiers.push_back (ptr);
    t = nullptr;
    delete t;
}

Team* Condutor::buildTeam (const vector<Soldier*>& s)
{
    vector<Soldier*> soldiers;
    for (auto soldier = begin(s); soldier != end(s); ++soldier)
    {
        auto iter = find (begin(availSoldiers), end(availSoldiers), (*soldier));
        if (iter != end(availSoldiers))
        {
            availSoldiers.erase (iter);
            soldiers.push_back ((*soldier));
        }
        else
        {
            cout << "warning: you tried to get a unavailable unit to a team, id:" << (*soldier)->id << endl;
        }
    }
    if (soldiers.size())
    {
        Team *team = new Team (soldiers);
        teams.push_back (team);
        return team;
    }
    else
    {
        return nullptr;
    }
}
Team* Condutor::buildTeam (const Soldier* s)
{
    auto as = find(begin(availSoldiers), end(availSoldiers), s);
    if (as == end(availSoldiers))
        return nullptr;
    else
    {
        availSoldiers.erase (as);
        vector<Soldier*> soldiers;
        soldiers.push_back ((Soldier*)s);
        Team* team = new Team (soldiers);
        teams.push_back (team);
        return team;
    }
}
vector<Team*> Condutor::buildIntoTeams (const vector<Soldier*>& s)
{
    vector<Soldier*> toBuild = s;
    vector<Team*> teams;
    while (toBuild.size())
    {
        vector<Soldier*> thisTerm;
        thisTerm.push_back (toBuild.back());
        toBuild.pop_back();
        for (auto iter = begin(toBuild); iter != end (toBuild); )
        {
            if (dis2 ((*iter)->ptr->pos, thisTerm.front()->ptr->pos) < GeneralOneStepReach)
            {
                thisTerm.push_back (*iter);
                toBuild.erase (iter);
            }
            else
                ++iter;
        }
        Team* t = buildTeam(thisTerm);
        if (t != nullptr)
            teams.push_back(t);
    }
    return teams;
}
//==========================================


/*********************************************************************
 *                              Soldier Definition
**********************************************************************/
Soldier::Soldier (PUnit* p)
{
    if (p == nullptr)
    {
        type = Unknown;
        ptr = nullptr;
        id = -1;
    }
    else
    {
        type = name2type(p->name);
        ptr = p;
        id = p->id;
    }
}
void Soldier::move (const Pos& pos)
{
    //鍙互鍙樺緱鏇村鏉傦紝姣斿鍍廰ttack涓€鏍蜂紶鍏ヤ竴涓懡浠わ紝瀹炵幇鍖呮妱涔嬬被鐨勩€?
    if (ptr == nullptr)
        return;
    console->move (pos, ptr);
}

void Soldier::attack (const Soldier& target, const string& command)
{
    //鍙槸鐩存帴鏀诲嚮锛屼笉鏀炬妧鑳姐€?
    if (ptr == nullptr)
    {
        cout << "ptr is nullptr" << endl;
        return;
    }
    if (lowerCase (command) == lowerCase("attack"))
    {
        if (target.ptr == nullptr)
        {
            cout << "target's ptr is nullptr" << endl;
            return;
        }
        console->attack (target.ptr, ptr);
    }
    else if (lowerCase (command) == lowerCase ("fastKill"))
    {
        //to do
    }
}
/*****************************************************
*             Team Definition
******************************************************/
Team::Team (const vector<Soldier*>& s):soldiers (s)
{
    action.clear();
    target = nullptr;
}

Team::~Team ()
{
    try
    {
        delete target;
    }
    catch (exception& e)
    {
        //do nothing
    }
}

void Team::move (Geometry* geo, int mode)
{
    //杩欓噷鎯冲姙娉曚繚璇佷簡鍚屼竴涓槦浼嶇殑鍗曚綅涓嶄細浜掔浉鍗′綇銆備笉杩囨病鏈夎€冭檻鐨勬槸宸茬粡鍒拌揪鐩殑鍦板湪绛夊緟鐨勫崟浣嶆槸鍚﹀彲浠ュ共浜涘叾浠栫殑浜嬫儏銆?
    bool occupiedByPartner[MAP_SIZE][MAP_SIZE] = {0};
    for (auto ptr: soldiers)
         if (geo->contain (ptr->ptr->pos))
         {
            removeEntry ("onWay", ptr->id, action);
            occupiedByPartner[ptr->ptr->pos.x][ptr->ptr->pos.y] = true;
         }
    int counter = 0;
    for (auto ptr: soldiers)
    {
        if (geo->contain (ptr->ptr->pos))
            continue;
        ++counter;
        Pos pos;
        do
        {
            pos = console->randPosInArea (geo);
        }
        while (occupiedByPartner[pos.x][pos.y]);
        if (mode == FASTMOVE && dis2 (ptr->ptr->pos, pos) > value("modeRoundLimit", action) * GeneralSpeed && console->gold() - console->goldCostCurrentRound() > console->callBackCost(ptr->ptr->level))
        {
            console->callBackHero (ptr->ptr);
        }
        else
            console->move (pos, ptr->ptr);
        occupiedByPartner[pos.x][pos.y] = true;
        updateValue ("onWay", action, ptr->id);
    }
    if (counter == 0)
    {
        removeEntry ("moveMode", action);
        target = nullptr;
        return;
    }
    updateValue ("round", action, console->round());
    updateValue ("moveMode", action, mode);
    target = geo;
}

void Team::attack (Soldier* target)
{
    vector<int> onWay = values ("onWay", action);
    for (auto s: soldiers)
    {
        if (find (begin(onWay), end(onWay), s->id) != end(onWay))
        {
            cout << "infomation: a soldier is still on his way, so the attack command in Team::attack is ignored, id:" << s->id << endl;
            continue;
        }
        console->attack (target->ptr, s->ptr);
    }
}

void Team::attack (vector<Soldier*>& t)
{
    if (t.size() == 0)
        return;
    vector<int> onWay = values ("onWay", action);
    vector<Soldier*> target(t);
    for (auto s: soldiers)
    {
        if (find (begin(onWay), end(onWay), s->id) != end(onWay))
        {
            cout << "infomation: a soldier is still on his way, so the attack command in Team::attack is ignored, id:" << s->id << endl;
            continue;
        }
        int min = 1 << 30;
        Soldier* r = nullptr;
        for (auto e: target)
        {
            if (dis2 (e->ptr->pos, s->ptr->pos) < console->unitArg("range", "c", s->ptr))
                continue;
            if (console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr) < min)
            {
                min = console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr);
                r = e;
            }
        }
        if (r != nullptr)
            console->attack (r->ptr, s->ptr);
        else
        {
            int _min = 1 << 30;
            Soldier* _r = nullptr;
            for (auto e: target)
            {
                if (console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr) < min)
                {
                    _min = console->unitArg("hp", "c", e->ptr) * console->unitArg("def", "c", e->ptr);
                    _r = e;
                }
            }
            console->attack (_r->ptr, s->ptr);
        }//on enemy in range
    }//for: soldiers
}
/******************************************8
*         Field Definition
*******************************************/
bool Field::contain (const Pos& _p)
{
    Pos p(_p);
    for (auto g: geos)
    {
        if (g->contain(p))
            return true;
    }
    return false;
}
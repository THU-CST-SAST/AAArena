// 防偷家需要加强
// 寻路函数要好好写 
// 战斗还需要优化 
#include "console.h"
#include<ctime>
#include <vector>
using namespace std ;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int __Rank = 0;
static int Mine_Distance[7][2] ;

static vector<PUnit*> enemy, enemy_hero, base_enemy ; 
static vector<PUnit*> myUnits; //获取所有己方单位
static vector<PUnit*> Myhero, Hero[4]; // 各个英雄单位 
static vector<bool> Moved[4] ; // 各英雄是否还能活动 
static vector<bool> Outcast ; // 神行太保的状态函数: 0->抱团,1->插眼,2->撤退,3->一个人采矿 
static vector<Pos> __path, M_Point, Blocks, Path ; // 用来存贮路径 
static int Perfect, Camp, flag[4][10], attacked[20], War[20], Danger, Careful ;
static int Tou[10], LevelCnt, cnt, Hammer ;
static int Best_Mine = 0 ; // 战略点 
static int Goodness, Longlyness ; // 占领0号矿的情况 
static int Strategy, Flag ; // 实施的策略 
static int Missing ; // 敌军失踪情况 
static int Count1, Count2, Clock, Rush ; // 计数器 
static int D[8][2] = {(0,1),(1,0),(0,-1),(-1,0),(1,1),(-1,1),(-1,1),(-1,-1)} ;
//

void Mypath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径
{
    PMap map0 = map;
    int x ;
    if(Camp == 0)
    {
    	for(x = 19; x <= 60; x ++)
    		if(start.x < x || start.y < x+3) 
    			break ;
    	if(x == 61) 
    	{
			findShortestPath(map, start, dest, blocks, _path) ;
    		return ;
		}
    	findShortestPath(map, start, Pos(x, x+3), blocks, _path) ;
    	for(x ++; x <= 60; x ++)
    		_path.push_back(Pos(x, x+2)), _path.push_back(Pos(x, x+3)) ;
    	findShortestPath(map, Pos(x-1, x+2), dest, blocks, Path) ;
	}
	else     
    {
    	for(x = 127; x >= 80; x --)
    		if(start.x > x || start.y > x) 
    			break ;    	
		if(x == 79) 
    	{
			findShortestPath(map, start, dest, blocks, _path) ;
    		return ;
		}
    	findShortestPath(map, start, Pos(x, x), blocks, _path) ;
    	for(x --; x >= 80; x --)
    		_path.push_back(Pos(x, x+1)), _path.push_back(Pos(x, x)) ;
    	findShortestPath(map, Pos(x+1, x+1), dest, blocks, Path) ;
	}
	for(int i = 1; i < Path.size(); i ++)
		_path.push_back(Path[i]) ;
}

inline int Dis(const PUnit* a, const PUnit* b)
{
	return dis2(a->pos, b->pos) ;
}
inline int Damage(const PUnit* a, const PUnit* b)
{
	return max(5, a->atk-b->def) ;
}
inline bool Bad(const int& x) 
{
	//cout << ".!.!" << x << endl ;
	return (Camp?(x<54):(x>96)) ;
}
inline int Value(const PUnit* a, int t)
{
	if(enemy[t]->findBuff("WaitRevive"))
		return 0x7ffffff ;
	/*if(Hammer && enemy[t]->findBuff("Dizzy"))
		return 0x7ffffff ;*/
	int tmp = enemy[t]->hp*60/Damage(a, enemy[t]) ;
	if(enemy[t]->hp <= Damage(a, enemy[t]) && a->atk > 100)
		tmp -= 1000000 ;
	if(t == Perfect)
		tmp -= 15000 ;
	if(enemy[t]->hp < Damage(a, enemy[t]) && Dis(enemy[t], a) <= a->range)
		tmp -= 200 ;
	if(Dis(enemy[t], a) > a->range) 
		tmp += (Dis(enemy[t], a)-a->range)*(Dis(enemy[t], a)-a->range)*3 ;
	tmp -= enemy[t]->atk*4 ;
	tmp -= attacked[t]*(Strategy==0?1300:100000) ;
	return tmp ;
	//if(Strategy == 0) tmp += dis2(enemy[t]->pos, MINE_POS[0])*4 ;
}
inline Pos Blink(Pos a, Pos p, double len)
{				
	int k = (len<0?-1:1) ;
	len = fabs(len) ;
	double x = a.x+k*(p.x-a.x)*sqrt(len/dis2(a, p)) ;
	double y = a.y+k*(p.y-a.y)*sqrt(len/dis2(a, p)) ;
	return Pos((int)x, (int)y) ;
}
/*const Path& Move(Pos to, PUnit* a)
{
	int best = -1, tmp, mn = 0x7fffffff; 
	if(__Rank >= 10) return to ;
	else return Camp?Pos(100, 100):Pos(50, 50) ;
	Pos Dir[8] = {Pos(-1, -1), Pos(-1, 0), Pos(-1, 1), 
	Pos(0, -1), Pos(0, 1), Pos(1, -1), Pos(1, 0), Pos(1, 1)} ;
	for(int i = 0; i < 7; i ++)
		if((tmp=dis2(a->pos+Dir[i], to)) < mn)
			mn = tmp, best = i ;
	return a->pos+Dir[best]*a->speed*2 ;
}*/
int Search_Best_Enemy(const PUnit* a, bool Need_Range) // 选择最适合进攻的单位，有英雄选英雄 
{
	int Best_Enemy = -1, mn = 0x7fffffff, tmp ;
	if(Careful < 0) return -1 ;
	for(int t = 0; t < enemy.size(); t ++)
	{
		if(enemy[t]->hp == 0 || (enemy[t]->hp <= 1 && enemy[t]->isWild())) continue ;
		if(!enemy[t]->isHero() && !enemy[t]->isWild() && !enemy[t]->isBase()) continue ;
		if(enemy[t]->isWild() && Strategy >= 0) continue ;
		if(enemy[t]->isWild() || Need_Range)
			if(Dis(enemy[t], a) > (a->range==8?150:250)*(attacked[t]?3:1) || dis2(enemy[t]->pos, M_Point[Best_Mine]) > 200)
				continue ;
		if(abs(Strategy) <= 1 && Bad(enemy[t]->pos.x) && Bad(enemy[t]->pos.y))
		{
			cout << "...." << enemy[t]->pos.x << enemy[t]->pos.y << endl ;
			continue ;
		} 
		if(enemy[t]->isBase()) return t ;
		if(Best_Enemy == -1 || enemy[Best_Enemy]->isHero() < enemy[t]->isHero()) 
			mn = Value(a, t), Best_Enemy = t ;
		if(Value(a, t) < mn && enemy[Best_Enemy]->isHero() <= enemy[t]->isHero())
			mn = Value(a, t), Best_Enemy = t ;
	}
	/*if(Best_Enemy == -1)
		cout << "!!" << a->range << endl ;*/
	return Best_Enemy ;
}
inline bool Special(int a, int b) //要不要先撤一下 
{
	if(Hero[a][b]->hp <= 100 && !flag[a][b])
	{
		for(int i = 0; i < enemy_hero.size(); i ++)
			if(Dis(enemy_hero[i], Hero[a][b]) <= 50)
				flag[a][b] = 5 ;
	}
	if(flag[a][b] > 0) 
	{
		flag[a][b]--, Moved[a][b] = 1 ;
		if(!flag[a][b]) flag[a][b] = -5 ;
		return 1 ;
	}
	if(flag[a][b] < 0) flag[a][b] ++ ;
	return 0 ;
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console console(map,info,cmd); //初始化控制台
	srand(time(NULL)) ;
	//if(__Rank == 500) Strategy = 2 ;
	if(!__Rank) // 首回合预处理 
	{
		Camp = console.camp() ; // 目前所属阵营 
		for(int i = 0; i < 7; i ++)
		{
			M_Point.push_back(MINE_POS[i]) ;
			Outcast.push_back(0) ;
			findShortestPath(map, MILITARY_BASE_POS[0], MINE_POS[i], __path) ;
			Mine_Distance[i][0] = __path.size() ;			
			findShortestPath(map, MILITARY_BASE_POS[1], MINE_POS[i], __path) ;
			Mine_Distance[i][1] = __path.size() ;
		} 
		M_Point.push_back(MILITARY_BASE_POS[Camp]) ; // 两个基地的地址 
		M_Point.push_back(MILITARY_BASE_POS[Camp^1]) ;
		M_Point.push_back(Pos(25, 25)) ;
		M_Point.push_back(Pos(125, 125)) ;
		M_Point.push_back(Pos(45, 16)) ;
		M_Point.push_back(Pos(119, 135)) ;
		M_Point.push_back(Pos(15, 15)) ;
		M_Point.push_back(Pos(132, 132)) ;
		M_Point[0] = M_Point[0]+(Camp*2-1)*Pos(2, 2) ;
		//Bad_Strategy = 100 ;
	}
	if(__Rank == 0) 
	{
		console.chooseHero(HERO_NAME[2], Camp?Pos(131, 132):Pos(17,18));
		console.chooseHero(HERO_NAME[0], Camp?Pos(134, 132):Pos(14,18));
		console.chooseHero(HERO_NAME[1], Camp?Pos(135, 130):Pos(13,16)); //初始购买英雄	
		console.chooseHero(HERO_NAME[3], Camp?Pos(129, 132):Pos(19,18));

	}
	//if(__Rank >= 400)Strategy = 2 ;
	++ __Rank;
	myUnits = console.friendlyUnits(); //获取所有己方单位	
	for(int i = 0; i < 4; i ++) Hero[i].clear(), Moved[i].clear() ;
	Myhero.clear() ;
	for(int i = 0; i < myUnits.size(); i ++) // 英雄分类 
		if(myUnits[i]->isHero())
		{
			Myhero.push_back(myUnits[i]) ;
			Hero[myUnits[i]->typeId-3].push_back(myUnits[i]) ;	
			Moved[myUnits[i]->typeId-3].push_back(0) ;
		}
	if(__Rank <= 30) 
		console.changeShortestPathFunc(Mypath) ;	
	//cout << "Part1" << endl ;
	//*******************升级英雄及购买英雄模块 *******************
	if(info.round >= 5)
	{
		vector< pair<int, int> > Cost ;
		if(Myhero.size() >= 8) for(int i = 0; i < Myhero.size(); ++i)
			if(dis2(Myhero[i]->pos, MILITARY_BASE_POS[Camp]) <= 140)
				Cost.push_back(make_pair(console.levelUpCost(Myhero[i]->level), i+1)) ;
		for(int i = 0; i < 4; i ++)
			Cost.push_back(make_pair(250*(Hero[i].size()+1), -i-1)) ;
		sort(Cost.begin(), Cost.end()) ;
		// 按照价格大小随机选择购买任务，不包括买活。 
		while(Cost.size())
		{
			while(Cost.size() && Cost.back().first > console.gold()) Cost.pop_back() ;
			if(!Cost.size()) break ;
			int i ;
			for(i = 0; i < Cost.size()-1; i ++)
				if(rand()%(Cost[i].first+Cost[i+1].first) > Cost[i].first) 
					break ;
			if(Cost[i].second > 0) 	console.buyHeroLevel(Myhero[Cost[i].second-1]) ; // 英雄升级
			else console.chooseHero(HERO_NAME[-Cost[i].second-1]) ;// 英雄召唤 
			break ;
			for(i++; i < Cost.size(); i ++)
				Cost[i-1] = Cost[i] ;
			Cost.pop_back() ;
		}
		for(int i = 0; i < Myhero.size(); i ++)
			if(console.gold() >= 1000 && __Rank%3 == 0)
				console.buyBackHero(Myhero[i], Camp?Pos(142,145):Pos(7,5)) ;
	}		
	myUnits = console.friendlyUnits(); //获取所有己方单位
	for(int i = 0; i < 4; i ++) Hero[i].clear(), Moved[i].clear() ;
	Myhero.clear() ;
	for(int i = 0; i < myUnits.size(); i ++)
		if(myUnits[i]->isHero())
		{
			Myhero.push_back(myUnits[i]) ;
			Hero[myUnits[i]->typeId-3].push_back(myUnits[i]) ;
			Moved[myUnits[i]->typeId-3].push_back(0) ;
		}
	enemy_hero.clear() ;
	// 重新获得单位名单	
	UnitFilter filter;// 获取所有敌方单位 
	filter.setAvoidFilter ("Mine"); //筛选时去除金矿
	enemy = console.enemyUnits (filter); //筛选出敌军
	filter.setAreaFilter (new Circle (MILITARY_BASE_POS[Camp], MILITARY_BASE_VIEW ), "a"); 
	base_enemy = console.enemyUnits (filter); //杩涜绛涢€?
	cout << enemy.size() << endl ;
	for(int i = 0; i < enemy.size(); i ++)
		if(enemy[i]->isHero()) enemy_hero.push_back(enemy[i]) ;
	//cout << "Part2" << endl ;
	//cout << "Hero number:" << Hero[0].size() << Hero[1].size() << Hero[2].size() << Hero[3].size() << endl ;
	 
	//cout << "Part3" << endl ;
	//*******************各英雄第一次行动----攻击*******************  	
	memset(attacked, 0, sizeof(attacked)) ;
	int tmp, mx = -0x7fffffff ;
	Perfect = -1 ;
	for(int i = 0; i < enemy_hero.size(); i ++)
	{
		tmp = 0 ;
		for(int j = 0; j < Myhero.size(); j ++)
			if(Myhero[j]->hp >= 5 && Dis(enemy_hero[i], Myhero[j]) <= Myhero[j]->range)
				tmp += Damage(Myhero[j], enemy_hero[i]) ;
		if(tmp >= 30)
			if(Perfect == -1 || enemy_hero[i]->typeId == 3) // 先打锤子 
				Perfect = i ; 
	}
	int Best_Enemy = -1, Cnt = 0 ;
	for(int i = 0; i < Hero[2].size(); i ++)// 绝命武士 
		if(1)
		{			
			/*if(Special(2,i) && Hero[2][i]->atk < 100) 
			{
				console.move(MILITARY_BASE_POS[Camp], Hero[2][i]), Moved[2][i] = 1 ;
				continue ;
			}*/
			Best_Enemy = Search_Best_Enemy(Hero[2][i], Strategy <= 0 && Strategy >= -2) ; 
			if(Best_Enemy != -1)
			{
				if(enemy[Best_Enemy]->isHero()) Cnt ++ ;
				cout << "!!!!!!!2" << endl ;
				int j ;
				for(j = 0; j < enemy_hero.size(); j ++)
					if(Dis(Hero[2][i], enemy_hero[j]) <= 40) 
						break ;				
				if(enemy[Best_Enemy]->hp <= Damage(Hero[2][i], enemy[Best_Enemy]))
					console.attack(enemy[Best_Enemy], Hero[2][i]) ; // 干干干！ 
				else if(Hero[2][i]->canUseSkill("Sacrifice") && j == enemy_hero.size() && Dis(Hero[2][i], enemy[Best_Enemy]) <= 100)
						console.useSkill("Sacrifice", Hero[2][i], Hero[2][i]) ;
				else console.attack(enemy[Best_Enemy], Hero[2][i]) ;
				attacked[Best_Enemy] ++, War[Best_Enemy] = __Rank ;
				Moved[2][i] = 1 ;
			}
		}		
	for(int i = 0; i < Hero[1].size(); ++i) // 通灵术士 
		if(1)
		{
			if(Special(1,i)) 
			{
				console.move(MILITARY_BASE_POS[Camp], Hero[1][i]), Moved[1][i] = 1 ;
				continue ;
			}
			Best_Enemy = Search_Best_Enemy(Hero[1][i], Strategy <= 0 && Strategy >= -2) ; 
			if(Best_Enemy != -1)
			{
				if(enemy[Best_Enemy]->isHero()) Cnt ++ ;
				cout << "!!!!!!!1" << endl ;
				if(!enemy[Best_Enemy]->isHero() || enemy[Best_Enemy]->hp <= Damage(Hero[1][i], enemy[Best_Enemy])*10)
					console.attack(enemy[Best_Enemy], Hero[1][i]) ; // 干干干！ 
				else if(Hero[1][i]->canUseSkill("Blink") && Dis(Hero[1][i], enemy[Best_Enemy]) <= 10 && enemy[Best_Enemy]->range == 8)
					console.useSkill("Blink", Blink(Hero[1][i]->pos, enemy[Best_Enemy]->pos, -32.0), Hero[1][i]) ; // 往回跳，奶人！ 
				else console.attack(enemy[Best_Enemy], Hero[1][i]) ;
				attacked[Best_Enemy] ++, War[Best_Enemy] = __Rank ;
				Moved[1][i] = 1 ;
			}
			else if(__Rank >= 10 && Hero[1][i]->canUseSkill("Blink"))
			{
				console.useSkill("Blink", Blink(Hero[1][i]->pos, M_Point[Best_Mine], 50.0),  Hero[1][i]) ;
				Moved[1][i] = 1 ;
			}
		}		
	for(int i = 0; i < Hero[0].size(); ++i) // 重锤卫士 
		if(1)
		{
			if(Special(0,i)) 
			{
				console.move(MILITARY_BASE_POS[Camp], Hero[0][i]), Moved[0][i] = 1  ;
				continue ;
			}
			Hammer = 1 ;
			Best_Enemy = Search_Best_Enemy(Hero[0][i], Strategy <= 0 && Strategy >= -2) ;
			Hammer = 0 ;
			if(Best_Enemy != -1)
			{
				if(enemy[Best_Enemy]->isHero()) Cnt ++ ;
				cout << "!!!!!!!0" << endl ;
				if(!enemy[Best_Enemy]->isHero() || enemy[Best_Enemy]->hp <= Damage(Hero[0][i], enemy[Best_Enemy]))
					console.attack(enemy[Best_Enemy], Hero[0][i]) ; // 干干干！ 
				else if(Hero[0][i]->canUseSkill("HammerAttack") && Dis(Hero[0][i], enemy[Best_Enemy]) <= 36 && !enemy[Best_Enemy]->findBuff("Dizzy"))
					console.useSkill("HammerAttack", enemy[Best_Enemy], Hero[0][i]) ;
				else console.attack(enemy[Best_Enemy], Hero[0][i]) ;
				attacked[Best_Enemy] ++, War[Best_Enemy] = __Rank ;
				Moved[0][i] = 1 ;
			}
		}
	for(int i = 0; i < Hero[3].size(); i ++)// 神行太保 
		if(1)
		{
			if(Special(3,i)) 
			{
				console.move(MILITARY_BASE_POS[Camp], Hero[3][i]), Moved[3][i] = 1  ;
				continue ;
			}
			Pos tp ;
			Best_Enemy = Search_Best_Enemy(Hero[3][i], 1) ;
			if(__Rank <= 30 && Hero[3][i]->canUseSkill("SetObserver") && dis2(Hero[3][i]->pos, tp=(MINE_POS[0]+Pos(Camp?-1:1, Camp?-1:1))) <= 20)
			{
				console.useSkill("SetObserver", tp+(1-2*Camp)*Pos(0, rand()%2), Hero[3][i]) ;
				Moved[3][i] = 1 ;
			}
			else if(Best_Enemy != -1)
			{			
				if(enemy[Best_Enemy]->isHero()) Cnt ++ ;
				console.attack(enemy[Best_Enemy], Hero[3][i]), Moved[3][i] = 1 ;
				attacked[Best_Enemy] ++, War[Best_Enemy] = __Rank ;
			}
			else if(Strategy == 1)		
				if(i == 1)
				{	
					if(Hero[3][i]->canUseSkill("SetObserver"))
					{
						cout << "!!!!!!!!!!!!!!!!!!!!!!!" << endl ;
						if(dis2(Hero[3][i]->pos, tp=(Camp?Pos(75, 37):Pos(75, 105))) <= 20)
							console.useSkill("SetObserver", tp-Pos(0, 2), Hero[3][i]) ;
						else console.move(tp, Hero[3][i]) ;		
					}
					else if(Best_Enemy != -1)
						console.attack(enemy[Best_Enemy], Hero[3][i]) ;
					else console.move(MINE_POS[0], Hero[3][i]) ;
					Moved[3][i] = 1 ;
				}
				else 
				{	
					if(Hero[3][i]->canUseSkill("SetObserver"))
						if(dis2(Hero[3][i]->pos, tp=(Camp?Pos(25+rand()%3, 75+rand()%3):Pos(125+rand()%3, 75+rand()%3))) <= 20)
							console.useSkill("SetObserver", tp-Pos(0, 2), Hero[3][i]) ;
						else console.move(tp, Hero[3][i]) ;
					else if(Best_Enemy != -1)
						console.attack(enemy[Best_Enemy], Hero[3][i]) ;
					else console.move(Camp?Pos(39,67):Pos(104,82), Hero[3][i]) ;
					Moved[3][i] = 1 ;
				}
			else if(Strategy == 2)
			if(i == 0)
			{
				if(Hero[3][i]->pos.x < 60 || Hero[3][i]->pos.x > 90)
					console.move(tp=(Camp?Pos(87, 126):Pos(81, 36)), Hero[3][i]) ;
				else if(Hero[3][i]->canUseSkill("SetObserver"))
					console.useSkill("SetObserver", Hero[3][i]->pos+Pos(1, 0), Hero[3][i]) ;
				else console.move(MINE_POS[0], Hero[3][i]) ;
				Moved[3][i] = 1 ;
			}
			else
			{				
				if(Hero[3][i]->pos.y < 60 || Hero[3][i]->pos.y > 90)
					console.move(tp=(Camp?Pos(130, 86):Pos(15, 80)), Hero[3][i]) ;
				else if(Hero[3][i]->canUseSkill("SetObserver"))
					console.useSkill("SetObserver", Hero[3][i]->pos+Pos(1, 0), Hero[3][i]) ;
				else console.move(MINE_POS[0], Hero[3][i]) ;
				Moved[3][i] = 1 ;
			}
		} 
	
	
	//cout << "Part4" << endl ;
	//*******************各英雄第二次行动----战略******************* 
	//if(__Rank >= 300) Strategy = 2 ;
	Count1 = 0 ;
	for(int i = 0; i < Myhero.size(); i ++)
		if(dis2(Myhero[i]->pos, MINE_POS[0]) <= 50) 
			Count1 ++ ;
	if(Count1 >= 4) Count2 ++ ;
	if(Cnt*3+2 <= enemy_hero.size()) Goodness -- ; // 如果战线上我军比敌军少很多 
	if(enemy_hero.size() > 0 && enemy_hero.size()*5 <= Cnt) 
		Goodness ++ ;// 如果战线上敌军比我军少很多 
	if(enemy_hero.size() == 0) Longlyness ++ ;
	else if(enemy_hero.size() == 1) Longlyness /= 2 ;
	else Longlyness = 0 ;
	if(Cnt*2+2 <= enemy_hero.size()) Danger ++ ;	
	if(enemy_hero.size() > 0 && enemy_hero.size()*5 <= Cnt) 
		Danger -- ;// 如果战线上敌军比我军少很多 
	//cout << "Goodness:" << Goodness << endl ;
	if(base_enemy.size() >= 3 && Strategy < 2) Strategy = 2, Clock = 0, Flag = 5 ;
	if(Strategy < 2)
	{
		if((Goodness >= 15 || Count2 >= 40) && Longlyness >= 40 && Strategy < 1) 
			Goodness = 15, Strategy = 1, Clock = Count2 = 0 ; // 0矿占有的很好, 采用主动出击 
		if((Goodness <= -15 || Danger >= 40) && Strategy > -1) Strategy = -1, Clock = 0 ;// 0矿基本被对面占有 
		if(Goodness <= -70 && Strategy > -2) Strategy = -2, Clock = 0 ;// 0矿基本被对面占有 
		if(Goodness == 0 && Strategy != 0) Strategy = 0, Clock = 0 ;
		if(Strategy == 1 && Danger >= 15) Strategy = Goodness = 0, Clock = 0 ;
	}
	cout << "STRATEGY>>>>>>>" << Strategy << endl ;
	if(Strategy == 0) Best_Mine = 0 ;
	else if(Strategy > 0)
	{	
		/*if(enemy_hero.size() == 0) Missing ++ ;
		else if(enemy_hero.size() == 1) Missing /= 2 ;
		else Missing = 0 ;*/
		if(Strategy == 2) 
		{
			if(Flag)
			{
				Flag -- ;
				for(int i = 0; i < Myhero.size(); i ++)
					if(dis2(Myhero[i]->pos, MILITARY_BASE_POS[Camp]) > 1600 && Myhero[i]->typeId != 6)
						console.callBackHero(Myhero[i]) ;
			}
			int i ;
			for(i = 0; i < enemy.size(); i ++)
				if(dis2(enemy[i]->pos, MILITARY_BASE_POS[Camp]) <= 2000)
					break ;
			if(i == enemy.size()) Clock ++ ;
			else Clock = 0 ;
			if(Clock == 100) Strategy = 1, Clock = 0 ;
			Best_Mine = Camp?14:13 ;
		}
		else if(Strategy == 3)
		{
			Rush -- ;
			if(Rush >= 80) 
			Best_Mine = 0 ;
			else Best_Mine = 8 ;
			if(!Rush) Strategy = 2 ;
		}
		else
		{
			if(Careful >= 30) Careful = -5 ;
			else if(Careful < 0) Careful ++ ;
			else 
			{
				tmp = 0 ;
				for(int i = 0; i < Myhero.size(); i ++)
					if(dis2(MINE_POS[0], Myhero[i]->pos) <= 100)
						tmp ++ ;
				if(tmp <= 2) Careful ++ ;
			}
			Best_Mine = 0 ;
		}
	}
	else 
	{
		if(Strategy == -2) 
			if(!Clock) Clock = 55 ;
			else if(Clock > 0)
			{
				Clock -- ;
				if(Clock >= 45) Best_Mine = 7 ;
				else Best_Mine = (Camp?6:5) ;
				if(!Clock) Clock = -100 ;
			}
			else 
			{
				Clock ++ ;
				if(Clock > -50) Best_Mine = 8 ;
				else Best_Mine = (Camp?11:12) ;
			}
		else
			if(!Clock) 
				if(Count1 >= 5) Strategy = 0 ;
				else Clock = 200 ;
			else if(Clock > 0)
			{
				Clock --, Best_Mine = (Camp?5:6) ;
				if(!Clock) Clock = -50 ;
			}
			else Clock ++, Best_Mine = 0 ;
	}
	if(Strategy == 2)
	{
		int x = (Camp?116:12), y = (Camp?125:32) ;
		for(int t = 0; t < 4; t ++)
			for(int i = 0; i < Hero[t].size(); i ++)
				if(!Moved[t][i]) 
				{
					console.move(Pos(x, y), Hero[t][i]) ;
					x += 3, y -= 3 ;
				}
		if(!enemy_hero.size()) Strategy = 2, Rush = 100 ;
	}
	else 
	{
		for(int t = 0; t < 4; t ++)
			for(int i = 0; i < Hero[t].size(); i ++)
				if(!Moved[t][i]) console.move(M_Point[Best_Mine], Hero[t][i]) ;	
	}
	/*
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			if(enemy.size() == 0) //如果没有发现敌人
				console.move(MINE_POS[Best_Mine]); //则去采集中央金矿
			else //否则攻击遇到的id最小的敌人
				console.attack(enemy[0]);
		}
	}*/
}
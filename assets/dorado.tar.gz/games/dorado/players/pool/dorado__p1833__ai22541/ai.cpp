#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstdlib>
#define LOCAL

#ifdef LOCAL

#include <iostream>
#include <cstdio>




#endif
using namespace std;
//ai test,233333

PUnit* myBase=NULL,*enemyBase=NULL;
vector<PUnit*> myUnits,eUnits;
Console *csl=NULL;
bool sign=false;
int aTarget[100][100];
int attackwho[1000];
int randnum=0;
bool isused[100];

int tomine[1000];
int herocnt,lastrnd;
int minec=1;

void attack(const PUnit* who,const PUnit * eU)
{
	csl->selectUnit(who);
	if(eU->hp<=0)
	{
		csl->move(MINE_POS[tomine[who->id]]);
		return;
	}
	attackwho[who->id]=eU->id;
	// printf("%s*************)
	if(strcmp(who->name,"Hammerguard")==0)
	{
		if(who->canUseSkill("HammerAttack"))
		{
			csl->useSkill("HammerAttack",eU,who);
			printf("useSkilln");
		}
		else
			csl->attack(eU);
	}
	else if(strcmp(who->name,"Master")==0)
	{
		csl->attack(eU);
	}
	else if(strcmp(who->name,"Berserker")==0)
	{
		csl->attack(eU);
	}
	else if(strcmp(who->name,"Scouter")==0)
	{
		csl->attack(eU);
	}
	else
		csl->attack(eU);
}

void getUnits();
int findEnemy(PUnit* which);
void attackBegin();

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	#ifdef	LOCAL
	
	#endif
	csl=new Console(map,info,cmd);
	
	Pos mine_pos[] = {Pos(74, 75), Pos(35, 60), Pos(35, 90), Pos(115, 60), Pos(115, 90), Pos(20, 140), Pos(130, 10)};
	if(csl->round()==0)
	{
		for(int i=0;i<1000;i++)
			tomine[i]=1;
		csl->chooseHero("Hammerguard");
		csl->chooseHero("Master");
		csl->chooseHero("Berserker");
		csl->chooseHero("Scouter");
	}
	getUnits();
	memset(aTarget,0,sizeof(aTarget));
	memset(isused,0,sizeof(isused));
	herocnt=0;
	for(int i=0;i<myUnits.size();i++)
	{
		if(!myUnits[i]->isHero())
			continue;
		herocnt++;
		csl->selectUnit(myUnits[i]);
		UnitFilter filter;
		filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a");
		filter.setAvoidFilter ("Mine");
		vector<PUnit*> te = csl->enemyUnits (filter);
		if(te.size()==0)
			csl->move(mine_pos[1]);
		else//有敌人的话，标记他，然后到时候一起攻击同一个
		{
			for(int j=0;j<te.size();j++)
			{
				if(te[j]->hp!=0&&te[j]->id==attackwho[myUnits[i]->id])
				{
					attack(myUnits[i],te[j]);
					isused[i]=true;
					continue;
				}
				int tord=findEnemy(te[j]);
				if(!tord)
					continue;
				aTarget[tord][++aTarget[tord][0]]=i;
			}
		}
	}
	if(herocnt%4==0&&herocnt!=lastrnd&&herocnt!=4)
	{
		lastrnd=herocnt;
		int tcnt=0;
		minec++;
		for(int i=0;i<myUnits.size();i++)
		{
			if(tcnt==4)
				break;
			if(myUnits[i]->isHero()&&tomine[myUnits[i]->id]==1)
			{
				tcnt++;
				tomine[myUnits[i]->id]=minec;
			}
		}
	}
	if(herocnt>=8)
	{
		for(int i=0;i<myUnits.size();i++)
		{
			if(myUnits[i]->isHero())
			{
				csl->selectUnit(myUnits[i]);
				csl->buyHeroLevel(myUnits[i]);
			}
		}
	}
	attackBegin();
	if(csl->round()>2)
	{
		randnum++;
		int tt=randnum%4;
		switch(tt)
		{
			case 0:
				csl->chooseHero("Hammerguard");
				break;
			case 1:
				csl->chooseHero("Master");
				break;
			case 2:
				csl->chooseHero("Berserker");
				break;
			case 3:
				csl->chooseHero("Scouter");
		}
	}
	delete csl;
}

bool cmp(int a,int b)
{
	return (eUnits[a]->id)<(eUnits[b]->id);
}

void attackBegin()
{
	printf("attackbegin!n");
	int sizen=eUnits.size();
	if(!sizen)
		return;
	int sortn[100];
	memset(sortn,0,sizeof(sortn));
	for(int i=0;i<eUnits.size();i++)
		sortn[i]=i;
	sort(sortn,sortn+sizen-1,cmp);
	// printf("sort over %dn",sizen);
	for(int i=0;i<sizen;i++)
	{
		int nord=sortn[i];
		for(int j=1;j<=aTarget[nord][0];j++)
		{
			int who=aTarget[nord][j];
			if(!isused[who]&&eUnits[i]->hp!=0)
			{
				isused[who]=true;
				attack(myUnits[who],eUnits[nord]);
			}
		}
	}
	// printf("moven");
	for(int i=0;i<myUnits.size();i++)
		if(!isused[i])
		{
			csl->selectUnit(myUnits[i]);
			// printf("tomine:%dn",myUnits[i]->id);
			csl->move(MINE_POS[tomine[myUnits[i]->id]]);
		}
}

int findEnemy(PUnit* which)
{
	if(eUnits.size()<1)
		return 0;
	for(int i=0;i<eUnits.size();i++)
		if(eUnits[i]==which)
			return i;
	return 0;
}

void getUnits()
{
	myUnits=csl->friendlyUnits();
	eUnits=csl->enemyUnits();
	for(int i=0;i<myUnits.size();i++)
	{
		if(strcmp(myUnits[i]->name,"MilitaryBase"))
		{
			myBase=myUnits[i];
		}
	}
	for(int i=0;i<eUnits.size();i++)
	{
		// printf("%sn",eUnits[i]->name);
		if(strcmp(eUnits[i]->name,"MilitaryBase"))
		{
			enemyBase=eUnits[i];
		}
	}
}

// static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
// static int Rank = 0;
// void player_ai2(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
// {
	// Console console(map,info,cmd); //初始化控制台
	// console.chooseHero(HERO_NAME[Rank % 4]); //依次选择英雄
	// ++ Rank;
	// vector<PUnit*> myUnits = console.friendlyUnits(); //获取所有己方单位
	// if(info.round > 4)
		// for(int i = 0; i < myUnits.size(); ++i)
			// console.buyHeroLevel(myUnits[i]); //有机会就升级英雄
	// for(int i = 0; i < myUnits.size(); ++i)
	// {
		// if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
		// {
			// console.selectUnit(myUnits[i]); //控制台选中
			// UnitFilter filter; //建立筛选器
			// filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			// filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			// vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			// if(enemy.size() == 0) //如果没有发现敌人
				// console.move(MINE_POS[0]); //则去采集中央金矿
			// else //否则攻击遇到的id最小的敌人
				// console.attack(enemy[0]);
		// }
	// }
// }

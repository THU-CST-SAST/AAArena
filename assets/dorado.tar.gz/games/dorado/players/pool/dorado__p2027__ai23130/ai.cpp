#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

static const int Mining_anger = 5;
static const int Attacked_anger = 10;

static const int MAXN = 1000; //粗略的最大id数

static int anger[MAXN][MAXN];

static int protect[MAXN];
static Pos originPos[MAXN];

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand ((unsigned int)time(0));
    if(info.camp < 2) return;
    Console console(map, info, cmd);
	if(info.round == 0)
	{
		for(int i = 0; i < info.units.size(); ++i)
		{
			if(info.units[i].isWild() && info.units[i].camp == info.camp)
			{
				originPos[info.units[i].id] = info.units[i].pos;
				for(int j = 0; j < info.units.size(); ++j)
				{
					if(!strcmp(info.units[j].name,"Mine") && dis2(info.units[j].pos,info.units[i].pos) <= info.units[i].view)
					{
						protect[info.units[i].id] = info.units[j].id;
						break;
					}
				}
			}
		}
	}
    for(int i = 0; i < info.units.size(); ++i)
	{
        if(info.units[i].isWild() && info.units[i].camp == info.camp)
        {
			for(int j = 0; j < info.units.size(); ++j)
			{
				if(info.units[j].id == protect[info.units[i].id])
				{
					UnitFilter filter;
					filter.setAreaFilter (new Circle (info.units[j].pos, MINING_RANGE ), "a");
					vector<PUnit*> enemy = console.enemyUnits (filter);
					if (enemy.size() > 0)
					{
						for(int k = 0; k < enemy.size(); ++k)
							anger[info.units[i].id][enemy[k]->id] += Mining_anger;
					}
				}
			}
			for(int j = 0; j < info.units.size(); ++j)
			{
				if(info.units[j].id < info.units[i]["LastHit"]->val.size() && info.units[i]["LastHit"]->val[info.units[j].id]==info.round-1)
					anger[info.units[i].id][info.units[j].id] += Attacked_anger;
			}
        }
	}
    for(int i = 0; i < info.units.size(); ++i)
	{
        if(info.units[i].isWild() && info.units[i].camp == info.camp)
        {
            int minDis = -1, maxAnger = 1, target = -1;
            for(int j = 0; j < info.units.size(); ++j)
            {
                if(info.units[j].camp != info.units[i].camp)
                {
                    if(anger[info.units[i].id][info.units[j].id] > maxAnger
                    ||(anger[info.units[i].id][info.units[j].id] == maxAnger
                     &&minDis < dis2(info.units[i].pos, info.units[j].pos)))
                    {
                        maxAnger = anger[info.units[i].id][info.units[j].id];
                        target = j;
                        minDis = dis2(info.units[i].pos, info.units[j].pos);
                    }
                }
            }
            if(target == -1)
			{
                memset(anger[info.units[i].id],0,MAXN * sizeof(int));
                console.selectUnit(&info.units[i]);
				if(info.units[i].pos != originPos[info.units[i].id])
					console.move(originPos[info.units[i].id]);
			}
            else
            {
                console.selectUnit(&info.units[i]);
                console.attack(&info.units[target]);
            }
        }
    }
}

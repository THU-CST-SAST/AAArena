#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <queue>
#include <stack>
#include <algorithm>
using namespace std;
void Find_best_pos(Pos start_pos,int enemyRange,int myRange,Pos & bestPos,const PMap &map,Console &console,const PUnit* My_hero,const PUnit* enemyUnit=NULL,int enemyAtk=81,int def=10){
	//the best point is the point that i have the best battle profit 
	int *dir=new int[2*myRange];
	int init=myRange;
    enemyAtk=enemyUnit==NULL?enemyAtk:enemyUnit->atk;
	for(int i=0;i<2*myRange;i++){
			dir[i]=init-i;
		}
	for(int i=0;i<2*myRange;i++){
		for(int j=0;j<2*myRange;j++){
			if (dis2(Pos(start_pos.x+dir[i],start_pos.y+dir[j]),start_pos)<=myRange){
			int bestPoint=0;
		    int delta_h= map.getHeight(start_pos.x+dir[i],start_pos.y+dir[j])-map.getHeight(start_pos.x,start_pos.y);
		    int s=dis2(start_pos,Pos(start_pos.x+dir[i],start_pos.y+dir[j]))<=enemyRange?1:0;
			int  Damage=delta_h*(My_hero->atk-enemyAtk*s)+(My_hero->def-def); 
			if(Damage>bestPoint){
			vector<Pos> path;
			findShortestPath(map,start_pos,Pos(start_pos.x+dir[i],start_pos.y+dir[j]),path);
			if(path[path.size()-1].x==start_pos.x+dir[i]&&path[path.size()-1].y==start_pos.y+dir[j]){
			     bestPos=Pos(start_pos.x+dir[i],start_pos.y+dir[j]);
			     bestPoint=Damage;
			 }
			 
			}
		}
	}
}
}
int Monster_hash(Pos a){
	
	return (a.x+a.y)%11;
}
void Monster_attack_profit(Console &console,vector<const PUnit*> My_hero,const PMap &map){
	    static int Max_round=25;
		int G[50][11];
     	for(int i=0;i<My_hero.size()-2;i++){
			for(int j=0;j<sizeof(Dragon_pos)/sizeof(Dragon_pos[0]);j++){
				//time on the road 
				int Time_on_road=(abs(Dragon_pos[j].x-My_hero[i]->pos.x)+abs(Dragon_pos[j].y-My_hero[i]->pos.y))/(My_hero[i]->speed);
				if(Time_on_road>=50)  G[My_hero[i]->id][Monster_hash(Dragon_pos[j])]=0;
                else {
                 int Current_round=Max_round-Time_on_road;
                 Pos bestPos; 
				 Find_best_pos(Dragon_pos[j],81,My_hero[i]->range,bestPos,map,console,My_hero[i]);
				 if(bestPos.x!=-1){
				 	console.move(bestPos,My_hero[i]);
				 	continue;
				 } 	
				}				
			}
		}
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
	//static int c=1;
	Console console(map,info,cmd); //初始化控制台
//	static My_hero[50];
//	static vector<Hash_hero> All_hero;
	//Base My_base(console.getMilitaryBase()->pos);
	//int father[150][150];
//	My_base.If_Enemy_Around(&console,info.round);
	//My_base.Attack_Enemy(&console);
	const Pos a(75,74);
	vector<const PUnit *> My_hero;
//	Controller controller(console.getMilitaryBase()->pos);
	//controller.Buy_hero(console,info);
	if(info.round==0){
		console.chooseHero("Berserker");
		console.chooseHero("Hammerguard");
		console.chooseHero("Scouter");
		  return ;
	}
	else {
		for(int i=0;i<info.units.size();i++){
			if(info.units[i].camp==info.camp&&info.units[i].isHero()){
				My_hero.push_back(&info.units[i]);
			}
		}
		Monster_attack_profit(console,My_hero,map);
	}
}

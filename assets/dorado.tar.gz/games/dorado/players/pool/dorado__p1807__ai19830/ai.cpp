#include "console.h"
#include <vector>
using namespace std;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Rank = 0;

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console console(map,info,cmd); //初始化控制台
	console.chooseHero(HERO_NAME[Rank % 4]); //依次选择英雄
	++ Rank;
	vector<PUnit*> myUnits = console.friendlyUnits(); //获取所有己方单位
	if(info.round > 4)
		for(int i = 0; i < myUnits.size(); ++i)
			console.buyHeroLevel(myUnits[i]); //有机会就升级英雄
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			if(enemy.size() == 0) //如果没有发现敌人
				console.move(MINE_POS[0]); //则去采集中央金矿
			else //否则攻击遇到的id最小的敌人
				console.attack(enemy[0]);
		}
	}
}
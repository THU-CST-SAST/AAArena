
#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <cmath>
#include <climits>
#include <algorithm>
#include <time.h>
#include <vector>
#include <utility>
using namespace std;

static int StrategyLog = 0;
static int heroRank = 1234;
static int newHeroFirst = 1;
static int defaultHp = 500;
static int attackArg = 200, defendHomeArg = 500, supportRange = 1000, monsterAvoid = 30, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 300;
static int miningArg = 150, sameMineArg = 0, centerMineArg = 50;
static int goBackHomeHp = 50, goBackHomeArg = 500, callBackHomeHp = 30, temptArg = 450;
static int hammerDizzy = 50;
static int strategyDisabled = - 1<<30;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int roundCount = 0;

bool isActiveSkill(PSkill* mySkill) //登僅室嬬頁倦葎麼強室嬬
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //陣崙ai議麼窃
{
private:
	typedef void (*shortestPathFunc)(const PMap&, Pos, Pos, const std::vector<Pos>&, std::vector<Pos>&);
	Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;
	PUnit *myBase, *enemyBase;
	int gold;
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void changeShortestPathFunc(shortestPathFunc newSPFunc);
	void levelupHero();
	int buyNewHero(const PPlayerInfo &info);
	void buyNewHero();
	void action();
	int goldCostCurrentRound() {return console->goldCostCurrentRound();}
};

class AIHero; //念哈喘蕗苧


static int vst[MAP_SIZE][MAP_SIZE];
static Pos Q[MAP_SIZE * MAP_SIZE + 1], Q_prior[MAP_SIZE][MAP_SIZE];
static int countF = 0;



class Strategy //貨待児窃
{
public:
	virtual int countWorth() = 0; //柴麻蝶嶽貨待議糞佩勺峙
	virtual void work() = 0; //糞宸嶽貨待
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
	void display (void)	{cerr << worker->name << ' ' << this->name << endl;}
	int goldCostCurrentRound() {return console->goldCostCurrentRound();}
	int gold()	{return console->gold();}
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class Attack:public Strategy //好似蝶倖汽了議貨待
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class UseSkill:public Strategy //斤蝶倖汽了瞥慧室嬬議貨待
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //哂俛化佩指社議貨待
{
public:
	GoBackHome(PUnit* worker,const int &sum_) {setWorker(worker); sum = sum_; name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
private:
	int sum;
};

class CallBackHome:public Strategy //孰指哂俛議貨待
{
public:
	CallBackHome(PUnit* worker, const int &sum_) 
		{setWorker(worker); sum = sum_; name = "CallBackHome";}
public:
	inline int callBackCost (int _level) const  {return _level * CALLBACK_COST_PER_LEVEL + CALLBACK_COST_BASE;}
	virtual int countWorth();
	virtual void work();
private:
	int sum;
};

class GoMining:public Strategy //寡嵩議貨待
{
public:
	GoMining(PUnit* worker, Pos target, int enemySum_) 
	{setWorker(worker); setTarget(target); enemySum = enemySum_; name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
	int enemySum;
};

class Tempt:public Strategy //哈嗾黍繁勸講議貨待-軸叱窄隠屬徭失音鞭彬議秤趨和序佩hit-and-run
{
public:
	Tempt(PUnit* worker, Pos ea, Pos ma) 
	{setWorker(worker); name = "Tempt"; enemyAve = ea; myAve = ma;}
public:
	virtual int countWorth();
	virtual void work();
private:
	Pos enemyAve, myAve;
};

class AIHero //斤哘耽倖哂俛議貨待畳貨
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //潮範僉夲指社議貨待
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //功象貨待議勺峙登僅頁倦僉夲仟議貨待
	void action(); //序佩輝念議恷單貨待
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};




AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
    gold = console->gold();
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	countF = 0;
	memset(vst, 0, sizeof(vst));
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
		{
			myHeros.push_back(myUnits[i]);
			//vst[(myUnits[i]->pos).x][(myUnits[i]->pos).y] = -1;
		}
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
		{
			enemyHeros.push_back(enemyUnits[i]);
			vst[(enemyUnits[i]->pos).x][(enemyUnits[i]->pos).y] = -1;
		}
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::changeShortestPathFunc(shortestPathFunc newSPFunc)
{
	console->changeShortestPathFunc(newSPFunc);
}

void AIController::levelupHero()
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		console->buyHeroLevel(heroToLevelUp[i]);
}

void AIController::buyNewHero()
{
	//短嗤登僅頁倦孰蚕撹孔絞泌惚短撹孔孰蚕乏會祥氏岱渠
	int newHero = heroRank % 10 - 1;
	if(newHero >= 0 && newHero < 4) console->chooseHero(HERO_NAME[newHero]);
	else
	{
		newHero = rand() % 4;
		console->chooseHero(HERO_NAME[newHero]);
	}
	heroRank /= 10;
}

int AIController::buyNewHero(const PPlayerInfo &info)
{
	//短嗤登僅頁倦孰蚕撹孔絞泌惚短撹孔孰蚕乏會祥氏岱渠
	int newHero = heroRank % 10 - 1;
	if(newHero >= 0 && newHero < 4) console->chooseHero(HERO_NAME[newHero]);
	else
	{
		newHero = rand() % 4;
		console->chooseHero(HERO_NAME[newHero]);
	}
	
	heroRank /= 10;
	return newHero;
}

void AIController::action()
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	int sum = 0;
	Pos enemyAve(0, 0), myAve(0, 0);
	//if (StrategyLog)
	//	cerr << "INACTION" << endl;
	for(int i = 0; i < myHeros.size(); ++i)
	{
		myAve.x += myHeros[i]->pos.x;
		myAve.y += myHeros[i]->pos.y;
	}
	if (myHeros.size() != 0)
	{
		myAve.x /= myHeros.size();
		myAve.y /= myHeros.size();
	}
	else
		myAve = myBase->pos;
	//if (StrategyLog)
	//	cerr << myAve.x << ' ' << myAve.y << endl ;
	for(int j = 0; j < enemyHeros.size(); j++)
	{
		if (dis2(myBase->pos, enemyHeros[j]->pos) <= myBase->view)
			sum++;
		enemyAve.x += enemyHeros[j]->pos.x;
		enemyAve.y += enemyHeros[j]->pos.y;
	}
	if (enemyHeros.size() != 0)
	{
		enemyAve.x /= enemyHeros.size();
		enemyAve.y /= enemyHeros.size();
	}
	//if (StrategyLog)
	//	cerr << enemyAve.x << ' ' << enemyAve.y << endl;
	
	if (StrategyLog)
		cerr << "SUM:" << sum << endl;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		allStrategy.push_back(new Tempt(myHeros[i], enemyAve, myAve));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i], sum));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i], sum));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < MINE_NUM; ++j)
			allStrategy.push_back(new GoMining(myHeros[i], MINE_POS[j], enemyHeros.size()));
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setConsole(console);
	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)
			AIHeroList[j]->setStrategy(allStrategy[i]);
	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}
bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	if (StrategyLog)
		mStrategy->display();
	mStrategy->work();
}



int Attack::countWorth()
{
	this->worth = 0;
	if(target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos) <= supportRange)
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		
		//this->worth += ((double)defaultHp/(double)target->hp) * (double)attackArg;
		double tmp = min(((double)target->max_hp/(double)target->hp), 10.0);
		this->worth += sqrt(sqrt((double)target->max_hp/(double)target->hp)) * (double)attackArg;
		if(dis2(worker->pos,target->pos) > worker->range)
			this->worth -= (double) outOfRangeArg * 2 / 5 * sqrt (sqrt ((double) dis2(worker->pos,target->pos) / (double)worker->range));
		if(target->isWild()) this->worth -= monsterAvoid;
	}
	return this->worth;
}


void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}


int CallBackHome::countWorth()
{
	this->worth = 0;
	if (dis2 (worker->pos, console->getMilitaryBase()->pos) > CALLBACK_RANGE)
		this->worth = strategyDisabled;
	else if (callBackCost (worker->level) + goldCostCurrentRound() > gold())
		this->worth = strategyDisabled;
	if(sum >= 3)
		this->worth += defendHomeArg * sum;
	return this->worth;
}

void CallBackHome::work()
{
	console->callBackHero(worker);
}


//ofstream fout("err.txt");

/*void findOut (Pos p)
{
	fout << p.x << ' ' << p.y << endl;
}*/

void findShortestPathAdvanced(const PMap &map, Pos start, Pos dest, std::vector<Pos> &_path)
//儖揃卦指貫了崔start欺dest議匯訳恷玉揃抄深打傅兮音深打凪万汽了飛揃抄音贋壓卦指欺宣朕炎泣恷除議匯倖泣議揃抄
{
	//fout << "p1checkpoint1" << endl;
	
    PMap map0 = map;
    _path.clear();
    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    ++countF;
    vst[start.x][start.y] = countF;
    int min = INT_MAX;
    Pos nearest = start;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        
        //fout << "p1checkpoint3 " << front << endl; 
    	
		Pos _t[4];
        int min_d[4];
        for (int i=0; i<4; i++)	_t[i] = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]), min_d[i] = i;
        for (int i=0; i<4; i++)
        	for (int j=2; j>=i; j--)
        		if (dis2(start, _t[j]) + dis2(_t[j], dest) > dis2(start, _t[j+1]) + dis2(_t[j+1], dest))
        		{
        			Pos tmp = _t[j]; _t[j] = _t[j+1]; _t[j+1] = tmp;
        			int k = min_d[j]; min_d[j] = min_d[j+1]; min_d[j+1] = k;
        		}
        for (int i=0; i<4; ++i) dir_ord[i] = min_d[i];
        
		//for (int i=0; i<4; i++) fout << dir_ord[i] << ' ';
        //fout << endl;


        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF && vst[_1.x][_1.y] != -1) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }
    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }

    //fout.close();
}

void findShortestPathAdvanced(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//揮触了議儖揃卦指貫了崔start欺dest議匯訳恷玉揃抄blocks嶄議了崔音辛将狛深打傅兮飛揃抄音贋壓卦指欺宣朕炎泣恷除議匯倖泣議揃抄
{
	/*fout << "p2checkpoint1" << endl;
    
    fout << "start: "; findOut(start);
    fout << "dest: "; findOut(dest);
    */
    
    PMap map0 = map;
    int _sz = blocks.size();

    ++countF;
    _path.clear();
    int min = INT_MAX;
    Pos nearest = start;
    for (int i=0; i<_sz; ++i)
    {
        if (checkPos(blocks[i]))
            vst[blocks[i].x][blocks[i].y] = countF;
    }
    
    if (!checkPos(start) || !checkPos(dest))
    {
        _path.push_back(Pos());
        return;
    }
    vst[start.x][start.y] = vst[dest.x][dest.y] = countF - 1;

    //fout << "p2checkpoint2" << endl;
	
	Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        
        /*fout << "p2checkpoint3 " << front << endl; 
    	findOut (_0);*/
    	
        Pos _t[4];
        int min_d[4];
        for (int i=0; i<4; i++)	_t[i] = _0 + Pos(dir[i][0], dir[i][1]), min_d[i] = i;
        
		/*for (int i=0; i<4; i++)
        {
        	fout << i << ' '; findOut(_t[i]); fout << dis2(start, _t[i]) + dis2(_t[i], dest) << endl;
        }*/
		
		for (int i=0; i<4; i++)
        	for (int j=2; j>=i; j--)
        		if (dis2(start, _t[j]) + dis2(_t[j], dest) > dis2(start, _t[j+1]) + dis2(_t[j+1], dest))
        		{
        			Pos tmp = _t[j]; _t[j] = _t[j+1]; _t[j+1] = tmp;
        			int k = min_d[j]; min_d[j] = min_d[j+1]; min_d[j+1] = k;
        		}
        for (int i=0; i<4; ++i) dir_ord[i] = min_d[i];
        
		/*for (int i=0; i<4; i++) fout << dir_ord[i] << ' ';
        fout << endl;*/

        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF && vst[_1.x][_1.y] != -1) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }

    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }
    
    //fout.close();
}


int GoBackHome::countWorth()
{
	this->worth = 0;
	if(worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0) this->worth += goBackHomeArg;
	if(sum >= 1)
		this->worth += goBackHomeArg * sum;
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(console->getMilitaryBase()->pos);
}


int GoMining::countWorth()
{
	this->worth = miningArg;
	if(target == MINE_POS[0])
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			if(AIHeroList[i]->getStrategy() != NULL)
				if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
				{
					GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
					if(otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;
				}
	}
	this->worth -= dis(worker->pos, target);
	if(AIHeroList.size() <= 8)
	{
		if(target == MINE_POS[0])
			this->worth += centerMineArg;
		else this->worth -= 2 * centerMineArg;
	}
	else
	{
		if(target == MINE_POS[0])
			this->worth += centerMineArg;
	}
	this->worth /= 4;
	return this->worth;
}

void GoMining::work()
{
	console->selectUnit(worker);
	console->move(target);
}



int Tempt::countWorth()
{
	this->worth = 0;
	if (dis2 (worker->pos, myAve) <= 30 || dis2 (worker->pos, enemyAve) >= 50)
		this->worth = strategyDisabled;
	if (strcmp(worker->name, "Scouter") != 0)
		this->worth = strategyDisabled;
	if (3 * worker->hp < 1 * worker->max_hp)
		this->worth += temptArg;
	return this->worth;
}

void Tempt::work()
{
	console->selectUnit(worker);
	console->move(myAve);
}


int UseSkill::countWorth()
{
	this->worth = 0;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				//緩侃亟斤室嬬議侃尖喇噐劔箭ai絞掲械酒待
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= HAMMERATTACK_RANGE)
					{
						//this->worth += ((double)defaultHp/(double)target->hp) * (double)attackArg;
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
						if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
							this->worth -= outOfRangeArg;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(worker->hp < goBackHomeHp)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						//this->worth += ((double)defaultHp/(double)target->hp) * (double)attackArg * 2;
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(dis2(worker->pos,target->pos) > worker->range)
							this->worth = strategyDisabled;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 2 * attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
				}
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}



void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController controller(map,info,cmd);
	controller.changeShortestPathFunc(findShortestPathAdvanced);
	
	roundCount++;
	
	if (StrategyLog)
	{
		freopen ("StrategyLog.txt", "a", stderr);
		cerr << roundCount << endl;
	}
	
	if(info.round == 0)
	{
		/*if(info.player == 1)
		{
			ofstream fout("err1.txt");
			for(int i = 1; i <= 4; ++i)
				fout << controller.buyNewHero(info) << endl;
		}
		else
		{
			ofstream fout("err0.txt");
			for(int i = 1; i <= 4; ++i)
				fout << controller.buyNewHero(info) << endl;
		}*/
		for(int i = 1; i <= 4; ++i)
			controller.buyNewHero(info);
		return;
	}
	if(newHeroFirst)
	{
		controller.buyNewHero();
		controller.levelupHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	controller.action();
	
	if (StrategyLog)
		cerr << endl;
}



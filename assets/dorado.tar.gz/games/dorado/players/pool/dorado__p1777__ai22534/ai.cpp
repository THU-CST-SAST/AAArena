#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <stack>

//#define TEST

#ifdef TEST
#include <ctime>
#include <cstdio>
#include "Pos.h"
#include <iomanip>
#include <iostream>
#endif

using namespace std;


static const char*	HERO_NAME[] = {"Hammerguard", "Berserker", "Scouter", "Master"};
static const Pos	TASK_POS[] = {Pos(15, 5), Pos(133, 127), Pos(74, 75), Pos(43, 61), Pos(43, 89), Pos(107, 61), Pos(107, 89), Pos(20, 140), Pos(130, 10), Pos(135, 145), Pos(17, 20), Pos(15, 10), Pos(135, 140)};
static const Pos	OBSERVER_POS[] = {Pos(25, 25), Pos(80, 20), Pos(20, 60)};
static const double	MINE_VALUE = 300;
static const double KILL_VALUE = 6000;
static const double LIVE_VALUE = 12000;
static const double	DISABLE_VALUE = -10000000;
static const double CHECK_UNIT = 400;
static const double CHECK_MEDIUM_UNIT = 225;
static const double	CHECK_CLOSE_UNIT = 100;
static const double CHECK_NEAR_UNIT = 64;
static const double	SUGGEST_WORTH = 1000;
static const double SUGGEST_STRONG_WORTH = 2000;
static const double SUGGEST_EMERGENCY_WORTH = 4000;
static const double SUGGEST_PUSH_WORTH = 100000;
static const double	RETREAT_HP = 0.3;
static const double BACK_FROM_RE_HP = 0.4;
static const double ATTACK_BASE = 1500;
static const double	BACK_POWER = 10000;
static const double ESCAPE_WORTH = 200;
static const int	TEAM_LARGE_RANGE = 525;
static const int	TEAM_RANGE = 225;
static const int	TEAM_CLOSE_RANGE = 64;
static const int	TEAM_DEPLOY_RANGE = 4;

class Hero;
class Strategy;
class Controller;
class Team;

enum Task{tMove, tGather, tEmergency, tPush, tDefence};
enum HeroState{hsRetreat, hsGather, hsTarget, hsFree};


static vector<Hero*>		myHero;
static vector<PUnit*>		enemyHero;
static vector<int>			enemyHeroID;
static PUnit*				myBase;
static PUnit*				enemyBase;
static bool					taskPoint[9];
static int					occupy;
static map<int, int>		reEnemy;

//譜崔徊蓑1葎近函嶄刹署嵩2葎好似児仇3葎裕社及匯化4葎裕社及屈化 
static int					position = 1;

#ifdef TEST
FILE* pf;

void printPos(Pos pos)
{
	cout<<pos.x<<" "<<pos.y;
}
#endif
double comparePower(vector<Hero*> &myUnits, vector<PUnit*> &enemyUnits);
double comparePower(vector<PUnit*> &myUnits, vector<PUnit*> &enemyUnits);
bool isHero(PUnit* unit);
void getHero(vector<PUnit*> &enemyUnits);

//俶勣枠 updatePunit 聞喘厮孀欺議汽了炎芝

#ifdef A_STAR_MOVE
class Node
{
public:
	Node():pos(0 ,0), F(0), G(0){}
	Node(int a, int b, double g, double h): pos(a, b), G(g), F(g + h){}
	Node(Pos mpos, double g, double h): pos(mpos), G(g), F(g + h){}
	void setFather(Node* f){father = f;}
	Node* getFather(){return father;}
	Pos pos;
	double F;
	double G;
private:
	Node* father;
};
struct cmpNodeF
{
	bool operator()(const Node *a, const Node *b) const
	{
		if(a->F == b->F)
		{
			if(a->pos.x == b->pos.x)
				return a->pos.y < b->pos.y;
			else
				return a->pos.x < b->pos.y;
		}
		else
			return a->F < b->F;
	}
};

struct cmpPos
{
	bool operator()(const Pos &a,const Pos &b)
	{
		if(a.x == b.x)
			return a.y > b.y;
		else
			return a.x > b.x;
	}
};

class Map
{
public:
	Map(){};
	void			update(const PMap &pTheMap);
	set<int>		obstacle;
	vector<Pos>		path;
	const PMap*		theMap;
	bool			find;
	void			findWay(Pos &start, Pos &dest);
};
#endif

Pos getDirPos(double len, Pos &b, Pos &a)
{
	double X = a.x - b.x;
	double Y = a.y - b.y;
	double k = len/(X*X + Y*Y);
	k = sqrt(k);
	X = k*X;
	Y = k*Y;
	if(X < 0)
		X ++;
	if(Y < 0)
		Y ++;
	return Pos(b.x + X, b.y + Y);
}

class Strategy
{
public:
	Strategy(Console* console, Hero* hero):console(console), hero(hero), targetPos(Pos(-1, -1)), worth(0), appointed(false){};
	void			setHero(Hero* hero){this->hero = hero;}
	void			updateConsole(Console* console){this->console = console;}
	void			setWorth(int worth){this->worth = worth;}
	double			comparePower(PUnit* enemy);
	int				getTargetID(){return targetID;}
	double			getWorth(){return worth;}
	Pos				targetPos;
	string			name;
	string			skillName;
	virtual void	updateTarget(PUnit* target){}
	virtual void	setTargetID(){}
#ifdef TEST
	virtual void	printTarget(FILE* pf) = 0;
#endif
	virtual void	perform() = 0;
	virtual double	countWorth() = 0;
	bool			appointed;
protected:
	Console*		console;
	Hero*			hero;
	int				targetID;
	double			worth;
};

//炎芝弌錦嶄撹埀議彜蓑
//伏凋峙曳楕詰噐 RETREAT_HP 扮資誼 Retreating 彜蓑旺資誼勺峙葎 LIVE_VALUE - 100 議児仇侃碍曜議貨待。
//		輝伏凋峙曳楕互噐 BACK_FROM_RE_HP 扮乎彜蓑盾茅
//Gathering Targeting Free 彜蓑塘栽弌錦聞喘
//弌錦窟僕 sendStrategyGather() 扮撹埀資誼 Gathering 彜蓑緩彜蓑和窟僕 team->pos 侃卞強議貨待
//		輝撹埀嚥 team->pos 議鉦宣弌噐 TEAM_DEPLOY_RANGE 扮緩彜蓑盾茅
//弌錦窟僕 sendStrategyTarget() 扮撹埀資誼 Targeting 彜蓑緩彜蓑和窟僕 team->target 侃卞強議貨待
//		輝撹埀嚥 team->target 議鉦宣弌噐 TEAM_DEPLOY_RANGE 扮緩彜蓑盾茅

//inDanger 軸葎巓律黍繁媾況薦嚥厘圭媾況薦議曳峙
//Hero功象 inDanger 唹畳貨inDanger熟寄扮好似貨待勺峙和週
class Hero
{
public:
	Hero(PUnit* unit):state(hsFree), unit(unit), strategy(NULL), ID(unit->id), inDanger(-1), lastTargetID(0), canUseSacrifice(false),lastPos(0, 0){}
	Strategy*		getStrategy(){return strategy;}
	int				getID(){return ID;}
	void			changeID(int ID){this->ID = ID;}
	void			changePUnit(PUnit* unit){this->unit = unit;}
	void			setStrategy(Strategy* strategy);
	double			calInDanger(Console* console);
	Pos				target;
	int				lastTargetID;
	Team*			team;
	PUnit*			unit;
	HeroState		state;
	bool			canUseSacrifice;//Berserker廨奉延楚壓巓律議黍繁脅堽慂扮嘉辛好似
	static int		observer[3];	//Scouter廨奉延楚喘參芝村貧匯肝壓眉倖了崔峨凛頁焚担扮昨
	int				dis;
	Pos				lastPos;
	double			inDanger;
private:
	Strategy*		strategy;
	int				ID;
};

int Hero::observer[3] = {-50, 0, 0};
double Hero::calInDanger(Console* console)
{
	if(unit->findBuff("WinOrDie"))
		inDanger = 0;
	vector<PUnit*> tempEnemy;
	vector<PUnit*> tempMy;
	UnitFilter filter;
	filter.setAreaFilter (new Circle (unit->pos, CHECK_NEAR_UNIT), "a");
	tempMy = console->friendlyUnits(filter);
	getHero(tempMy);

	tempEnemy = console->enemyUnits(filter);
	getHero(tempEnemy);

	if(this->unit->canUseSkill("Sacrifice"))
	{
		this->canUseSacrifice = true;
		for(auto i = tempEnemy.begin(); i != tempEnemy.end(); i ++)
		{
			if(dis2(this->unit->pos, (*i)->pos) < (*i)->range + (*i)->speed && (*i)->findBuff("Dizzy") == NULL)
				this->canUseSacrifice = false;
		}
	}

	inDanger = (inDanger < 2.0) ? inDanger : 2.0;
	double tempInDanger = comparePower(tempMy, tempEnemy);
	inDanger -= 0.5;
	inDanger = (inDanger > tempInDanger)? inDanger:tempInDanger;
	return inDanger;
}
void Hero::setStrategy(Strategy* strategy)
{
#ifdef TEST
	//printf("%d set strategy", ID);
	//cout<<strategy->getName()<<endl;
#endif
	if(this->strategy == NULL)
	{
		this->strategy = strategy;
		strategy->setHero(this);
	}
	else
	{
		if(this->strategy->countWorth() < strategy->countWorth())
		{
			delete this->strategy;
			this->strategy = strategy;
			strategy->setHero(this);
			if(strategy->name == "Attack")
				strategy->setTargetID();
			strategy->appointed = true;
		}
		else
		{
			delete strategy;
		}
	}
}

#ifdef A_STAR_MOVE
void Map::update(const PMap &pTheMap)
{
	obstacle.clear();
	path.clear();
	for(auto i = enemyHero.begin(); i != enemyHero.end(); i ++)
		obstacle.insert((*i)->pos.x * 1000 + (*i)->pos.y);
	for(auto i = myHero.begin(); i != myHero.end(); i ++)
		obstacle.insert((*i)->unit->pos.x * 1000 + (*i)->unit->pos.y);

	theMap = &pTheMap;
}


int nextX[8] = {1, 1, 0, -1, -1, -1, 0, 1};
int nextY[8] = {0, 1, 1, 1, 0, -1, -1, -1};
void Map::findWay(Pos &start, Pos &dest)
{
	set<Node*, cmpNodeF> openList;
	set<Node*, cmpNodeF> closeList;
	map<Pos, Node*, cmpPos> posNodeList;
	find = false;
	path.clear();

	Node* pTempNode = new Node(start.x, start.y, 0, dis(start, dest));
	Node* nextNode;
	Pos nextPos;
	openList.insert(pTempNode);
	posNodeList[start] = pTempNode;


	int t1 = clock();

	while(!openList.empty())
	{
		auto tempNode = openList.begin();
		pTempNode = *tempNode;
		openList.erase(pTempNode);
		closeList.insert(pTempNode);

		//cout<<"check ";
		//printPos(pTempNode->pos);
		//cout<<endl;
		//system("pause");

		for(int i = 0; i < 8; i++)
		{
			nextPos = Pos(pTempNode->pos.x + nextX[i], pTempNode->pos.y + nextY[i]);
			if(nextPos == dest)
			{
				find = true;
				goto mark;
			}

			int heightDelta = theMap->getHeight(nextPos.x, nextPos.y) - theMap->getHeight(nextPos.x, nextPos.y);
			if(heightDelta > 2 || heightDelta < -2)
				continue;

			if(posNodeList.find(nextPos) == posNodeList.end())
			{
				nextNode = new Node(nextPos, pTempNode->G + dis(nextPos, pTempNode->pos), dis(nextPos, dest));
				posNodeList[nextPos] = nextNode;
			}
			else
				nextNode = posNodeList[nextPos];

			if(closeList.find(nextNode) == closeList.end())
			{
				if(openList.find(nextNode) == openList.end())
				{
					nextNode->setFather(pTempNode);
					openList.insert(nextNode);		
				}
				else
				{
					if(nextNode->G > pTempNode->G + dis(nextNode->pos, pTempNode->pos))
					{
						openList.erase(nextNode);
						delete nextNode;
						nextNode = new Node(nextPos, pTempNode->G + dis(nextNode->pos, pTempNode->pos), dis(nextNode->pos, dest));
						nextNode->setFather(pTempNode);
						posNodeList[nextPos] = nextNode;		
					}
				}
			}
		}
	}
mark:
	cout<<clock() - t1<<endl;
	if(find)
	{
		stack<Pos> staPos;
		staPos.push(pTempNode->pos);
		while(pTempNode->getFather()->pos != start)
		{
			pTempNode = pTempNode->getFather();
			staPos.push(pTempNode->pos);
		}
		while(!staPos.empty())
		{
			path.push_back(staPos.top());
			staPos.pop();
		}
	}

	
	for(auto i = path.begin(); i != path.end(); i ++)
	{
		printPos(*i);
		cout<<endl;
	}
	system("pause");
}


static Map	mMap;
#endif

double Strategy::comparePower(PUnit* enemy)
{
	return enemy->hp * (enemy->atk - hero->unit->def)/hero->unit->hp * (hero->unit->atk - enemy->def);
}

double calculatePower(vector<PUnit*> units)
{
	double power = 0;
	int size = units.size();
	for(int i = 0; i < size; i++)
		power += units[i]->hp * (units[i]->atk + units[i]->def);
}

bool isHero(PUnit* unit)
{
	return (!strcmp(unit->name,"Hammerguard") || !strcmp(unit->name,"Master")
				|| !strcmp(unit->name,"Berserker") || !strcmp(unit->name,"Scouter"));
}
void getHero(vector<PUnit*> &enemyUnits)
{
	for(auto i = enemyUnits.begin();i != enemyUnits.end();)
	{
		if(!isHero(*i))
			i = enemyUnits.erase(i);
		else
			i++;
	}
}
double comparePower(vector<Hero*> &myUnits, vector<PUnit*> &enemyUnits)
{
	vector<PUnit*> myTempUnits;
	for(auto i = myUnits.begin(); i != myUnits.end(); i ++)
	{
		myTempUnits.push_back((*i)->unit);
	}
	return comparePower(myTempUnits, enemyUnits);
}
double comparePower(vector<PUnit*> &myUnits, vector<PUnit*> &enemyUnits)
{
	if(enemyUnits.empty())
		return 0;
	if(myUnits.empty())
		return 10000;
	double enemyPower = 0, myPower = 0;
	double myDef = 0, enemyDef = 0;
	int enemySize = enemyUnits.size(), mySize = myUnits.size();
	for(int i = 0; i < enemySize; i ++)
		enemyDef += enemyUnits[i]->def;
	enemyDef /= enemySize;
	for(int i = 0; i < mySize; i ++)
		myDef += myUnits[i]->def;
	myDef /= mySize;
	for(int i = 0; i < enemySize; i ++)
	{
		if(enemyUnits[i]->findBuff("Dizzy") != NULL)
			enemyPower += ((enemyUnits[i]->hp > 0) ? enemyUnits[i]->hp : 0) * (enemyUnits[i]->atk - myDef);
		else
			enemyPower += ((enemyUnits[i]->hp > 0) ? enemyUnits[i]->hp : 0) * (enemyUnits[i]->atk - myDef) / 3.0;
	}
	for(int i = 0; i < mySize; i ++)
		myPower += ((myUnits[i]->hp > 0) ? myUnits[i]->hp : 0) * (myUnits[i]->atk - enemyDef);
	return enemyPower / myPower;	
}



class Skill:public Strategy
{
public:
	Skill(Console* console, Hero* hero, PUnit* target):Strategy(console, hero)
	{name = "Skill"; this->target = target;}
	Skill(Console* console, Hero* hero):Strategy(console, hero)
	{name = "Skill"; this->target = NULL; skillName = "Blink";}
	Skill(Console* console, Hero* hero, int pos):Strategy(console, hero)
	{name = "Skill"; targetPos = OBSERVER_POS[pos]; posx = pos; target = NULL; skillName = "SetObserver";}
	void		perform();
	int			posx;
	double		countWorth();
#ifdef TEST
	void		printTarget(FILE* pf);
#endif
private:
	PUnit*		target;
};
bool isActiveSkill(PSkill* Skill) //登僅室嬬頁倦葎麼強室嬬
{
	return !strcmp(Skill->name, "HammerAttack")
		|| !strcmp(Skill->name, "Blink")
		|| !strcmp(Skill->name, "Sacrifice")
		|| !strcmp(Skill->name, "SetObserver");
}
#ifdef TEST
void Skill::printTarget(FILE* pf)
{
	//cout<<"skill pt"<<endl;
	if(skillName == "HammerAttack")
		fprintf(pf,"HammerAttack Hero:%d", target->id);
	else if(skillName == "Sacrifice")
		fprintf(pf,"Sacrifice Hero:%d", target->id);
	else if(skillName == "SetObserver")
		fprintf(pf, "SetObserver (%d, %d)", targetPos.x, targetPos.y);
	else
		fprintf(pf, "Blink (%d, %d)", targetPos.x, targetPos.y);
	//cout<<"pt"<<endl;
}
#endif
void Skill::perform()
{
	//printf("%d perform ", hero->getID());
	//cout<<skillName<<endl;
	console->selectUnit(hero->unit);
	if(skillName == "HammerAttack")
		console->useSkill("HammerAttack", target);
	else if(skillName == "Sacrifice")
		console->useSkill("Sacrifice", NULL);
	else if(skillName == "SetObserver")
	{
		int temp = dis2(targetPos, hero->unit->pos);
		if(temp < 4)
		{
			targetPos = console->randPosInArea(targetPos, 2);
			Hero::observer[posx] = console->round();
			console->useSkill("SetObserver", targetPos);
		}
		else if(temp < 25)
		{
			console->useSkill("SetObserver", targetPos);
			Hero::observer[posx] = console->round();
		}
		else
			console->move(targetPos);
	}
	else if(skillName == "Blink")
		console->useSkill("Blink", targetPos);
	//cout<<"skill performed"<<endl;
}

//晦編斑憾徨怦峭黍繁berserker慧室嬬廣吭勣癖輝距屁歌方聞誼室嬬議勺峙互噐峠A
//berserker壓徭附隆鞭欺好似扮圭辛聞喘sacrifice
//壓現除窟嗤berserker真除扮深打好似麿
double Skill::countWorth()
{
	if(appointed)
		return worth;
	worth = 0;
	console->selectUnit(hero->unit);
	if(hero->unit->canUseSkill("HammerAttack")
		&& target->findBuff("Reviving") == NULL
		&& dis2(hero->unit->pos,target->pos) < HAMMERATTACK_RANGE)
	{
		skillName = "HammerAttack";
		if(!strcmp(target->name, "Scouter"))
		{
			worth = 0;
			return worth;
		}
		if(target->canUseSkill("Sacrifice"))
		{
			worth = SUGGEST_PUSH_WORTH;
			return worth;
		}
		if(target->isBase())
		{
			worth = 0;
			return worth;
		}
		if(dis2(hero->unit->pos,target->pos) < hero->unit->range)
		{
			worth = 0;
			return worth;
		}
		int skillLevel = (hero->unit->findSkill("HammerAttack"))->level;
		worth += (max((double)HAMMERATTACK_DAMAGE[skillLevel] / (double)(target->hp), 2.0) + 2.0 * (double)target->atk/ATTACK_BASE) * KILL_VALUE;
		//if(dis2(hero->unit->pos,target->pos) > HAMMERATTACK_RANGE)
		//	worth -= 10 * (dis2(hero->unit->pos,target->pos) - HAMMERATTACK_RANGE);
		if(hero->unit->findBuff("Dizzy") != NULL)
			worth *= 0.80;
		if(!strcmp(target->name, "Hammerguard"))
			worth *= 4;
		else if(!strcmp(target->name, "Berserker"))
			worth *= 4;
		else if(!strcmp(target->name, "Master"))
			worth /= 2;
		//cout<<"hm atk wh"<<worth<<endl;
	}
	else if(hero->unit->canUseSkill("Sacrifice")
		&& hero->canUseSacrifice
		&& target->findBuff("Reviving") == NULL
		&& dis2(hero->unit->pos, target->pos) < hero->unit->range
		&& (target->findBuff("BeAttacked") == NULL || target->findBuff("BeAttacked")->timeLeft < 1))
	{
		skillName = "Sacrifice";
		if(target->isBase())
		{
			worth = SUGGEST_PUSH_WORTH * 2;
			return worth;
		}
		worth += (max((double)hero->unit->hp / target->hp, 1.0) + 3.0 * (double)target->atk/ATTACK_BASE) * KILL_VALUE;
		worth -= 50 * (dis2(hero->unit->pos, target->pos) - hero->unit->range);
		if(target->findBuff("Dizzy") != NULL)
			worth *= 0.7;
		if(!strcmp(target->name, "Hammerguard") || !strcmp(target->name, "Berserker"))
			worth *= 4;
	}
	else if(skillName == "SetObserver" && hero->unit->canUseSkill("SetObserver"))
	{
		//cout<<"ewqrgfe "<<posx<<endl;
		skillName = "SetObserver";
		worth = (console->round() - Hero::observer[posx]) * 50 + 100 * (3 - posx);
		//cout<<"so wh"<<worth<<endl;
	}
	return worth;
}



class Move:public Strategy
{
public:
	Move(Console* console, Hero* hero, Pos target):Strategy(console, hero)
	{name = "Move"; targetPos = target;}
	void		perform();
#ifdef TEST
	void		printTarget(FILE* pf);
#endif
	double		countWorth();
private:
};
#ifdef TEST
void Move::printTarget(FILE* pf)
{
	//cout<<"Move printTarget"<<endl;
	fprintf(pf, "Move(%3d, %3d)", targetPos.x, targetPos.y);
	//cout<<"pt"<<endl;
}
#endif
void Move::perform()
{
	console->selectUnit(hero->unit);

#ifdef A_STAR_MOVE
	mMap.findWay(hero->unit->pos, targetPos);
	console->move(mMap.path);
#else
	console->move(targetPos);
#endif
}
double Move::countWorth()
{
	if(appointed)
		return worth;
	double dist = dis(targetPos, hero->unit->pos);
	worth = MINE_VALUE - dist;
	if(dist < MINING_RANGE - 6)
		worth = 0;
	return worth;
}



class Attack:public Strategy
{
public:
	Attack(Console* console, Hero* hero, PUnit* enemy):Strategy(console, hero)
	{name = "Attack"; target = enemy; targetPos = enemy->pos;}
	void		perform();
	void		setTargetID(){targetID = target->id;}
	double		countWorth();
#ifdef TEST
	void		printTarget(FILE* pf);
#endif
	void		updateTarget(PUnit* target){this->target = target;}
private:
	PUnit*		target;
};
#ifdef TEST
void Attack::printTarget(FILE* pf)
{
	fprintf(pf, "Attack Hero:%4d", target->id);
}
#endif
void Attack::perform()
{
	console->selectUnit(hero->unit);
	console->attack(target);
	hero->dis = dis2(target->pos, hero->unit->pos);
	hero->lastTargetID = target->id;
	//cout<<"atk wh"<<worth<<endl;
	//fprintf(pf, "%d atkwh %.2lfn",hero->getID() ,getWorth());
}
double Attack::countWorth()
{
	if(appointed)
		return worth;
	if(target->isBase() && dis2(hero->unit->pos, target->pos) < CHECK_UNIT)
	{
		worth = SUGGEST_PUSH_WORTH * 1.5;
		return worth;
	}
	worth = 0;
	if(target->findBuff("Reviving") != NULL || target->hp < 0)
		worth = DISABLE_VALUE;
	else
	{
		//似姫紗撹
		worth += (min((double)(hero->unit->atk - target->def) / (double)target->hp, 1.1) + (double)target->atk/ATTACK_BASE)
			* KILL_VALUE;

		//侃噐裡受撹
		worth /= max(1.0, hero->inDanger);
	
		//階狛符殻受撹
		if(hero->unit->findBuff("WinOrDie"))
		{
			worth -= 100 * (dis2(hero->unit->pos, target->pos) - hero->unit->range)/target->speed;
			if(!strcmp(target->name, "Hammerguard") || !strcmp(target->name, "Berserker"))
				worth *= 2;
		}
		else
			worth -= 60 * (dis2(hero->unit->pos, target->pos) - hero->unit->range)/target->speed;

		//弖似音式受撹
		//弖似音式扮氏擬崑距屁貨待緩扮lastPos, lastTargetID吉払丼宸氏擬崑壅和匯指栽嗽嶷仟好似毛怒汽了
		if(reEnemy[target->id] < 1)
		{
			if(target->id == hero->lastTargetID && dis2(target->pos, hero->unit->pos) > hero->unit->range)
			{
				if((dis2(target->pos, hero->lastPos) > hero->dis
				&& target->speed >= hero->unit->speed))
				//cout<<hero->unit->id<<" 弖似音式 "<<target->id<<" lastPos "<<hero->lastPos.x<<hero->lastPos.y<<" hero->dis "<<hero->dis<<endl;
				worth /= 4;
				reEnemy[target->id] += 5;
			}
		}
		else
		{
			if(dis2(target->pos, hero->unit->pos) > hero->unit->range && target->speed >= hero->unit->speed)
			{
				//cout<<hero->unit->id<<" 弖似音式 "<<target->id<<endl;
				worth /= 4;
			}
		}

		if(!strcmp(hero->unit->name, "Master"))
		{
			if(!strcmp(target->name, "Master"))
				worth *= 2;
			else if(!strcmp(target->name, "Berserker") && target->canUseSkill("Sacrifice"))
				worth *= 4;
		}

		//cout<<"atk wh"<<worth<<endl;
	}
	return worth;
}



class Retreat:public Strategy
{
public:
	Retreat(Console* console, Hero* hero):Strategy(console, hero){name = "Retreat";}
#ifdef TEST
	void		printTarget(FILE* pf);
#endif
	void		perform();
	double		countWorth();
private:
};
#ifdef TEST
void Retreat::printTarget(FILE* pf)
{
	fprintf(pf, "Retreat");
}
#endif
double Retreat::countWorth()
{
	if(appointed)
		return worth;
	if(dis2(myBase->pos, hero->unit->pos) < 35 && myBase->hp < myBase->max_hp)
	{
		worth = 0;
		return worth;
	}
	if(hero->state != hsRetreat)
	{
		worth = ESCAPE_WORTH * (hero->inDanger) * (hero->inDanger) * (hero->inDanger);
		if((double)hero->unit->hp / (double)hero->unit->max_hp < 0.25 && !hero->unit->findBuff("WinOrDie"))
		{
			worth += LIVE_VALUE;
		}
	}
	else
	{
		worth = ESCAPE_WORTH * (hero->inDanger) * (hero->inDanger) * (hero->inDanger);
		worth += LIVE_VALUE;
		//cout<<hero->unit->id<<"indanger "<<hero->inDanger;
		//cout<<" "<<worth<<endl;
	}
	return worth;
}
void Retreat::perform()
{
	console->selectUnit(hero->unit);
	if(hero->unit->canUseSkill("Blink"))
		console->useSkill("Blink", getDirPos(81, hero->unit->pos, targetPos));
	console->move(myBase->pos);
	hero->state = hsRetreat;
	if((double)hero->unit->hp/(double)hero->unit->max_hp > BACK_FROM_RE_HP)
		hero->state = hsFree;
}


//哘戟源販暦窃侏
//哘喘歌方宙峰弌錦議媾宝泌壓褒圭脅鹿潤麼薦扮哘峺幣撹埀弌錦嶄伉真贈壓媾況窟伏扮光撹埀哘揖扮誘秘媾況
//哘閲窒汽倖撹埀溝嘱侮秘
//深打喘壓弌錦嶄柴麻光撹埀議貨待函旗圻嗤議寄何蛍貨待柴麻圭塀
class Team
{
public:
	Team():target(Pos(74, 75)), pos(Pos(74, 75)), needNewMember(true), attackBase(false){task = tMove; teamNum ++;}
	void			addMember(Hero* hero){member.push_back(hero);}
	void			removeMember(int id);
	void			sendStrategyPos(vector<Hero*>::iterator mem, Pos pos, int dis);
	void			sendStrategyTarget();//撹埀窟僕壓朕炎侃鹿潤議凋綜
	void			sendStrategyGather();//撹埀窟僕壓pos侃鹿潤議凋綜
	void			countSuggestWorth();
	void			setTarget(Pos pos, Task tas);
	void			updatePos();
	static int		teamNum;
	bool			needNewMember;
	bool			attackBase;
	Task			task;
	void			calGatherIndex(Console* console);
	int				gatherIndex;
	vector<Hero*>	member;
	Pos				target;
	Pos				pos;
private:
	int				suggestWorth;
	int				ID;
};

void Team::setTarget(Pos pos, Task tas)
{
	if(task == tGather)
	{
		target = this->pos;
		if(gatherIndex >= 2)
			task = tMove;
	}
	else
	{
		target = pos;
		task = tas;
	}
}

//麼勣厚仟阻calGatherIndex, setTeamTask, isHero, getHero 賓隆序佩霞編2016.4.20 0:53
void Team::calGatherIndex(Console* console)
{
	//僉函pos現除議弌錦撹埀
	if(this->member.size() == 0)
		return;
	vector<Hero*> tempHero = this->member;
	double averageDis = 0;
	for(auto i = tempHero.begin(); i != tempHero.end(); i++)
		averageDis += dis((*i)->unit->pos, pos);
	averageDis /= tempHero.size();
	for(auto i = tempHero.begin(); i != tempHero.end();)
	{
		if(dis((*i)->unit->pos, pos) > 1.5 * averageDis)
			i = tempHero.erase(i);
		else
			i ++;
	}
	int x = 0, y = 0;
	for(auto i = tempHero.begin(); i != tempHero.end(); i++)
	{
		x += (*i)->unit->pos.x;
		y += (*i)->unit->pos.y;
	}
	x /= tempHero.size();
	y /= tempHero.size();
	Pos pos2(x, y);

	int num = 0;
	for(auto i = tempHero.begin(); i != tempHero.end(); i++)
	{
		if(dis((*i)->unit->pos, pos2) < 8)
			num ++;
	}

	if((double)num/(double)member.size() < 0.3)
		gatherIndex = 0;
	else if((double)num/(double)member.size() < 0.7)
		gatherIndex = 1;
	else if((double)num/(double)member.size() < 0.8)
		gatherIndex = 2;
	else
		gatherIndex = 3;
}

void Team::countSuggestWorth()
{
	switch(task)
	{
	case tMove:
		suggestWorth = SUGGEST_WORTH;
		break;
	case tGather:
	case tEmergency:
	case tDefence:
		suggestWorth = SUGGEST_EMERGENCY_WORTH;
		break;
	case tPush:
		suggestWorth = SUGGEST_PUSH_WORTH;
	}
}

void Team::updatePos()
{
	int x = 0, y = 0;
	for(auto i = member.begin(); i != member.end(); i++)
	{
		x += (*i)->unit->pos.x;
		y += (*i)->unit->pos.y;
	}
	if(member.empty())
		pos = Pos(0, 0);
	else
		pos = Pos(x/member.size(), y/member.size());
}

void Team::removeMember(int id)
{
	for(auto i = member.begin(); i != member.end();)
	{
		if((*i)->getID() == id)
			i = member.erase(i);
		else
			i ++;
	}
}



int Team::teamNum = 0;

static vector<Team*> team;

class Controller
{
public:
	Controller():myHeroNum(0), heroRank(0), enemyHeroNum(0){this->console = NULL;}
	Controller(Console* console):myHeroNum(0), heroRank(0), enemyHeroNum(0){this->console = console;}
#ifdef TEST
	void		printHero(FILE* pf);
	void		printEnemyHero(FILE* pf);
	FILE*		pf;
#endif
	void		buyNewHero();
	void		levelUpHero();
	void		updatePUnit();
	void		setTeamTask();
	void		updateConsole(Console* console){this->console = console;}
	Hero*		findMyHero(int ID);
	PUnit*		findEnemyHero(int ID);
	void		setStrategy();//壓宸倖痕方嶄綜耽倖哂俛幟倖標僉strategy哘廣吭strategy嶄議Hero才Hero嶄議strategy勣稜栽
	void		perform();	
	void		calInDanger();
	Console*	console;
private:
	int			myHeroNum;
	int			enemyHeroNum;
	int			heroRank;
};

void Controller::calInDanger()
{
	for(int i = 0; i < myHeroNum; i ++)
		myHero[i]->calInDanger(console);
}

//得浩媾魁蕉米譜崔team->task才team->target。
void Controller::setTeamTask()
{
	vector<PUnit*> tempEnemy;
	vector<PUnit*> tempMy;
	UnitFilter filter;
	//光弌錦卆肝窟下光嵩卞強議販暦廣吭柴麻光販暦議勺峙旺拝譜崔販暦窃侏娩幡好似勸講
	for(int j = 0; j < 7; j ++)
	{
		taskPoint[j] = false;
	}
	//壓宸戦奐紗仟秀弌錦
	for(int i = 0; i < Team::teamNum; i ++)
	{
		//柴麻弌錦鹿栽業 gatherIndex
		team[i]->updatePos();
		team[i]->calGatherIndex(console);
		for(int j = 0; j < 1; j ++)
		{
			if(!taskPoint[j])
			{
				//僉函target現除曝囃乎曝囃黍繁薦楚熟膿拝弌錦隆鹿栽扮弌錦窟下gather販暦

				filter.cleanAll();
				filter.setAreaFilter (new Circle (MINE_POS[j], CHECK_MEDIUM_UNIT), "a");

				tempEnemy = console->enemyUnits (filter);
				getHero(tempEnemy);

				taskPoint[j] = true;
				double relativePower = comparePower(team[i]->member, tempEnemy);


				if(position != 2 && dis2(team[i]->pos, TASK_POS[2]) < CHECK_NEAR_UNIT)
				{
					for(auto k = team[i]->member.begin(); k != team[i]->member.end(); k++)
						if((*k)->inDanger != 0)
						{
							occupy = 0;
						}
					occupy ++;
				}
				else
				{
					occupy = 0;
				}

				if(occupy > 30)
					position = 2;

				if(myHeroNum < enemyHeroID.size() + 2)
					position = 1;

				filter.cleanAll();
				if(myBase->pos.x < 50)
					filter.setAreaFilter (new Circle (TASK_POS[1], CHECK_UNIT), "a");
				else
					filter.setAreaFilter (new Circle (TASK_POS[11], CHECK_UNIT), "a");
				if(console->friendlyUnits(filter).empty())
					position = 1;

				if(position == 2)
				{
					if(myBase->pos.x < 50)
					{
						if(dis2(team[i]->pos, TASK_POS[1]) > CHECK_CLOSE_UNIT || team[i]->gatherIndex < 3)
						{
							if(team[i]->attackBase)
							{
								team[i]->setTarget(TASK_POS[9], tPush);
							}
							else
							{
								team[i]->setTarget(TASK_POS[1], tDefence);
							}
						}
						else
							team[i]->attackBase = true;
							
					}
					else
					{
						team[i]->setTarget(TASK_POS[10], tDefence);
						/*
						if(dis2(team[i]->pos, TASK_POS[10]) > CHECK_CLOSE_UNIT || team[i]->gatherIndex < 2)
						{
							if(dis2(team[i]->pos, TASK_POS[0]) < 160 && team[i]->gatherIndex >= 2)
								team[i]->setTarget(TASK_POS[0], tPush);
							else
								team[i]->setTarget(TASK_POS[10], tMove);
						}
						else
							team[i]->setTarget(TASK_POS[0], tPush);
							*/
					}
				}
				else if(relativePower < 0.5)
				{
					team[i]->setTarget(MINE_POS[j], tMove);
				}
				else if(relativePower < 2)
				{
					if(team[i]->gatherIndex >= 1)
						team[i]->setTarget(MINE_POS[j], tMove);
					else
						team[i]->setTarget(team[i]->pos, tGather);
				}
				else
				{
					if(team[i]->gatherIndex == 2)
						team[i]->setTarget(MINE_POS[j], tMove);
					else
						team[i]->setTarget(team[i]->pos, tGather);
				}
				break;
			}
		}
	}
	//壓緩侃殊臥児仇現除頁倦嗤黍繁泌惚嗤柴麻黍繁議媾況薦輝黍繁媾況薦熟互扮光弌錦窟下指址販暦
	//單枠孰指除峇佩販暦音嶷勣議弌錦
	//廣吭譜崔販暦窃侏葎 emergency諸識孰指
	//哘乎壓 setTarget 嶄奐紗匯倖 Task 窃侏議歌方圭宴譜崔Task歌方
	//壓児仇僮楚寄噐0.7扮窟僕 move / back 孰指販暦音僅孰指岷崛涙辛喘弌錦賜弌錦議媾況薦器欺黍繁媾況薦議1.5蔚
	//壓児仇僮楚富噐0.7扮窟僕 emergency 孰指販暦音僅孰指岷崛涙辛喘弌錦賜弌錦議媾況薦器欺黍繁媾況薦議2蔚

	filter.cleanAll();
	filter.setAreaFilter (new Circle (myBase->pos, 400), "a");
	tempEnemy = console->enemyUnits (filter);
	if(myBase->hp / myBase->max_hp > 0.8)
	{
		if(calculatePower(tempEnemy) > BACK_POWER)
		{
			int nearTeam = 0;
			int nearestDis = 1000000;
			for(int i = 0; i < team.size(); i ++)
			{
				int tempDis;
				if(myBase->pos.x < 50)
					tempDis = dis2(team[i]->pos, TASK_POS[11]);
				else
					tempDis = dis2(team[i]->pos, TASK_POS[12]);
				if(tempDis < nearestDis)
				{
					nearTeam = i;
					nearestDis =  tempDis;
				}
			}
			team[nearTeam]->setTarget(myBase->pos, tMove);
		}
	}
	else
	{
		for(int i = 0; i < team.size(); i ++)
		{
			if(myBase->pos.x < 50)
				team[i]->setTarget(TASK_POS[11], tDefence);
			else
				team[i]->setTarget(TASK_POS[12], tDefence);
		}
	}

	for(int i = 0; i < team.size(); i ++)
		team[i]->sendStrategyTarget();
	//壓厘圭函誼熟寄單米黍圭屎壓鹸試黍圭朔圭腎倡吉秤趨和惣除議弌錦窟下好似黍繁児仇議販暦。
}

Hero*	Controller::findMyHero(int ID)
{
	int size = myHero.size();
	for(int i = 0; i < size; i ++)
	{
		if(myHero[i]->getID() == ID)
			return myHero[i];
	}
	return NULL;
}
PUnit*	Controller::findEnemyHero(int ID)
{
	for(int i = 0; i < enemyHero.size(); i ++)
		if(ID == enemyHero[i]->id)
			return enemyHero[i];
	return NULL;
}
void Controller::buyNewHero()
{
	static int buyPos = 0;
	buyPos++;
	buyPos %= 4;
	if(myBase->pos.x < 50)
	{
		if(console->round() == 0 && !strcmp(HERO_NAME[heroRank],"Scouter"))
			console->chooseHero(HERO_NAME[heroRank], Pos(3, 3));
		else
			console->chooseHero(HERO_NAME[heroRank], Pos(20 - buyPos, 14));
	}
	else
	{
		if(console->round() == 0 && !strcmp(HERO_NAME[heroRank],"Scouter"))
			console->chooseHero(HERO_NAME[heroRank], Pos(140, 140));
		else
			console->chooseHero(HERO_NAME[heroRank], Pos(128 + buyPos, 134));
	}
	heroRank ++;
	heroRank %= 4;
}
void	Controller::levelUpHero()
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
	vector<PUnit*> HeroToLvUp = console->friendlyUnits(filter);
	for(int i = 0; i < HeroToLvUp.size(); i ++)
		console->buyHeroLevel(HeroToLvUp[i]);
}

bool findAllEnemyHero(int id)
{
	int i = 0;
	for(;i < enemyHeroID.size(); i++)
		if(enemyHeroID[i] == id)
			break;
	if(i == enemyHero.size())
		return false;
	return true;
}
void	Controller::updatePUnit()
{
	vector<PUnit*> myUnits = console->friendlyUnits();
	enemyHero.clear();
	enemyHero = console->enemyUnits();
	for(int i = 0; i < enemyHero.size(); i++)
	{
		if(!findAllEnemyHero(enemyHero[i]->id))
			enemyHeroID.push_back(enemyHero[i]->id);
		if(reEnemy.find(enemyHero[i]->id) == reEnemy.end())
		{
			reEnemy[enemyHero[i]->id] = 0;
		}
		else
		{
			reEnemy[enemyHero[i]->id] --;
			reEnemy[enemyHero[i]->id] = (reEnemy[enemyHero[i]->id] > 0)? reEnemy[enemyHero[i]->id]:0;
		}
	}
	int size = myUnits.size();
	for(int i = 0; i < size; i ++)
	{
		Hero* thisHero = findMyHero(myUnits[i]->id);
		if(thisHero != NULL)
		{
			thisHero->unit = myUnits[i];
			if(thisHero->unit->hp < 0)
			{
				thisHero->lastTargetID = 0;
			}
		}
		else if(isHero(myUnits[i]))
		{
			thisHero = new Hero(myUnits[i]);
			myHero.push_back(thisHero);
			myHeroNum ++;
			for(int i = 0; i < Team::teamNum; i ++)
			{
				if(team[i]->needNewMember)
				{
					team[i]->addMember(thisHero);
					thisHero->team = team[i];
					team[i]->updatePos();
					break;
				}
			}
		}
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))//壓myBase坪贋刈厘圭児仇
			myBase = myUnits[i];
	}
}
void Controller::setStrategy()
{	
	for(int i = 0; i <myHeroNum; i ++)
	{
		if(myHero[i]->getStrategy() != NULL)
		{
			myHero[i]->getStrategy()->setWorth(DISABLE_VALUE);
			myHero[i]->getStrategy()->appointed = true;
		}
	}
	
	//cout<<"set Attack"<<endl;
	for(int i = 0; i < myHeroNum; i ++)
	{
		for(int j = 0; j < enemyHero.size(); j ++)
		{
			if(enemyHero[j]->isHero())
			{
				myHero[i]->setStrategy(new Attack(console, myHero[i], enemyHero[j]));
				myHero[i]->setStrategy(new Skill(console, myHero[i], enemyHero[j]));
			}
			if(enemyHero[j]->isBase())
			{
				Strategy* apStr = new Attack(console, myHero[i], enemyHero[j]);
				apStr->appointed = true;
				apStr->setWorth(150000);
				myHero[i]->setStrategy(apStr);

				if(!strcmp(myHero[i]->unit->name, "Hammerguard") || !strcmp(myHero[i]->unit->name, "Berserker"))
				{
					apStr = new Skill(console, myHero[i], enemyHero[j]);
					//apStr->appointed = true;
					//apStr->setWorth(200000);
					myHero[i]->setStrategy(apStr);
				}
			}
		}
	}
	if(Team::teamNum == 1 && position == 2)
	{
		//cout<<"gasgre"<<endl;
		team.push_back(new Team);
		team[1]->needNewMember = false;
		//cout<<"gredsf"<<endl;
		for(auto m = team[0]->member.begin(); m != team[0]->member.end();)
		{
			if(!strcmp((*m)->unit->name, "Scouter"))
			{
				team[1]->member.push_back(*m);
				m = team[0]->member.erase(m);
			}
			else m ++;
		}
	}
	if(Team::teamNum > 1)
	{
		Hero* thisHero = team[1]->member[0];
		if(console->round() - Hero::observer[0] > 45)
			thisHero->setStrategy(new Skill(console, thisHero, 0));
		else if(console->round() - Hero::observer[1] > 40 && myHeroNum > enemyHeroID.size())
			thisHero->setStrategy(new Skill(console, thisHero, 1));
		else if(console->round() - Hero::observer[2] > 40 && myHeroNum > enemyHeroID.size())
			thisHero->setStrategy(new Skill(console, thisHero, 2));
	}

	//cout<<"set Retreat Skill"<<endl;

	for(int i = 0; i < myHeroNum; i ++)
	{
		myHero[i]->setStrategy(new Retreat(console, myHero[i]));
	}
	//cout<<"setted"<<endl;
}
void Controller::perform()
{
	//cout<<"perform"<<endl;
	for(int i = 0; i < myHeroNum; i ++)
	{
		myHero[i]->getStrategy()->perform();
		myHero[i]->lastPos = myHero[i]->unit->pos;
	}
}

#ifdef TEST
void Controller::printHero(FILE* pf)
{
	fprintf(pf, "round:%3d myHero size: %dn", console->round(), myHero.size());
	for(int i = 0; i < myHero.size(); i ++)
	{
		fprintf(pf, "Hero:%4d hp:%4d Pos(%3d, %3d) ", myHero[i]->getID(), myHero[i]->unit->hp, myHero[i]->unit->pos.x, myHero[i]->unit->pos.y);
		if(myHero[i]->getStrategy() == NULL)
			fprintf(pf,"NULL");
		else
		{
			if(myHero[i]->getStrategy()->appointed)
				fprintf(pf, "ap ");
			fprintf(pf, "%ft", (float)myHero[i]->getStrategy()->getWorth());
			fprintf(pf, "inDanger:%f state:%dt", (float)myHero[i]->inDanger, myHero[i]->state);
			myHero[i]->getStrategy()->printTarget(pf);
		}
		fprintf(pf, "n");
	}
}
void Controller::printEnemyHero(FILE* pf)
{
	for(int i = 0; i < enemyHero.size(); i ++)
	{
		fprintf(pf, "enemyHero:%4d %d hp:%3d Pos(%3d, %3d)n", enemyHero[i]->id, (int)enemyHero[i], enemyHero[i]->hp, enemyHero[i]->pos.x, enemyHero[i]->pos.y);
	}
}
#endif

static Controller controller;

void Team::sendStrategyPos(vector<Hero*>::iterator mem, Pos pos, int dis)
{
	Strategy* appointedStrategy = new Move(controller.console, (*mem), pos);
	appointedStrategy->setWorth(0);
	switch((*mem)->state)
	{
	case hsTarget:
	case hsGather:

		//輝撹埀嚥Move朕炎俊除扮貨待勺峙和週參緩戻工徭喇業
		if(task == tDefence)
		{
			if(dis > TEAM_DEPLOY_RANGE)
				appointedStrategy->setWorth(suggestWorth);
		}
		if(dis > TEAM_LARGE_RANGE)
		{
			appointedStrategy->setWorth(4 * suggestWorth);
		}
		else if(dis > TEAM_RANGE)
		{
			appointedStrategy->setWorth(suggestWorth);
			if((*mem)->unit->canUseSkill("Blink"))
			{
				delete appointedStrategy;
				appointedStrategy = new Skill(controller.console, (*mem));
				appointedStrategy->skillName = "Blink";
				appointedStrategy->targetPos = Pos(getDirPos(81,(*mem)->unit->pos, pos));
				appointedStrategy->setWorth(suggestWorth);
			}
		}
		else if(dis > TEAM_CLOSE_RANGE)
			appointedStrategy->setWorth(suggestWorth / 5);
		else if(dis > TEAM_DEPLOY_RANGE)
			appointedStrategy->setWorth(suggestWorth / 15);
		else
		{
			appointedStrategy->setWorth(0);
			(*mem)->state = hsFree;
		}
		break;
	}
	appointedStrategy->appointed = true;
	(*mem)->setStrategy(appointedStrategy);
}

void Team::sendStrategyTarget()
{
	countSuggestWorth();
	for(auto i = member.begin(); i != member.end(); i++)
	{
		int dis = dis2((*i)->unit->pos, target);
		if(dis > TEAM_CLOSE_RANGE)
			(*i)->state = hsTarget;
		sendStrategyPos(i, target, dis);
	}
#ifdef TEST
	fprintf(pf, "team%dt Target(%d, %d)n", (int)this, target.x, target.y);
#endif
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
#ifdef TEST
	pf = fopen("1master.txt", "a+");
	fprintf(pf, "n");
	controller.pf = pf;
#endif
	Console* console = new Console(map, info, cmd);
	controller.updateConsole(console);
	controller.updatePUnit();
#ifdef A_STAR_MOVE
	mMap.update(map);
#endif
	if(info.round == 0)
	{
		for(int i = 0; i < 4; i ++)
			controller.buyNewHero();
		team.push_back(new Team());
	}
	else
	{
		controller.buyNewHero();
		controller.levelUpHero();
	}
	//cout<<"set strategy"<<endl;
	controller.calInDanger();
	controller.setStrategy();
	controller.setTeamTask();
	//cout<<"set team task"<<endl;
	controller.perform();
#ifdef TEST
	controller.printHero(pf);
	controller.printEnemyHero(pf);
	fclose(pf);
#endif
	delete console;
}

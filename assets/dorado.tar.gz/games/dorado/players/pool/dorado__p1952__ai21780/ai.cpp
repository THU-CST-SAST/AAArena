//宸頁匯倖劔箭AI
#include "console.h"
#include <vector>

static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Rank = 0;

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Console console(map,info,cmd); //兜兵晒陣崙岬
	console.chooseHero(HERO_NAME[Rank % 4]); //卆肝僉夲哂俛
	++ Rank;
	vector<PUnit*> myUnits = console.friendlyUnits(); //資函侭嗤失圭汽了
	if(info.round > 4)
		for(int i = 0; i < myUnits.size(); ++i)
			console.buyHeroLevel(myUnits[i]); //嗤字氏祥幅雫哂俛
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //孀欺失圭汽了嶄議哂俛汽了
		{
			console.selectUnit(myUnits[i]); //陣崙岬僉嶄
			UnitFilter filter; //秀羨標僉匂
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //標僉篇勸袈律坪議黍圭汽了
			filter.setAvoidFilter ("Mine"); //標僉扮肇茅署嵩
			vector<PUnit*> enemy = console.enemyUnits (filter); //序佩標僉
			if(enemy.size() == 0) //泌惚短嗤窟黍繁
				console.move(MINE_POS[0]); //夸肇寡鹿嶄刹署嵩
			else //倦夸好似囑欺議id恷弌議黍繁
				console.attack(enemy[0]);
		}
	}
}

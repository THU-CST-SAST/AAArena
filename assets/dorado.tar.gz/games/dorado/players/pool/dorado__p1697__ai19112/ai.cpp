#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

static int heroRank = 42314231;
static int newHeroFirst = 1;
static int attackArg = 200, supportRange = 1000, monsterAvoid = 0, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100;
static int miningArg = 150, sameMineArg = 10, centerMineArg = 50;
static int goBackHomeHp = 100, goBackHomeArg = 300;
static int hammerDizzy = 50;
static int strategyDisabled = - 1<<30;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};

void findPath(const PMap &map, Pos start, Pos dest, const vector<Pos> &blocks, vector<Pos> &path) //A*揃抄朴沫
{
	struct Node {
		int x, y;
		int level;
		int priority;

		Node() :x(0), y(0), level(0), priority(0) {}
		Node(int xp, int yp, int d, int p) :x(xp), y(yp), level(d), priority(p) {}
		void updatePriority(int xDest, int yDest)
		{
			priority = level + estimate(xDest, yDest) * 10;
		}
		void nextLevel()
		{
			level += 10;
		}
		int estimate(const int & xDest, const int & yDest) const
		{
			int xd = xDest - x, yd = yDest - y;
			return static_cast<int>(sqrt(xd * xd + yd * yd));
		}
		bool operator < (const Node &b) const
		{
			return priority > b.priority;
		}
	};
	const int dx[] = {1, 0, -1, 0};
	const int dy[] = {0, 1, 0, -1};
	static int closed_nodes_map[MAP_SIZE][MAP_SIZE];
	static int open_nodes_map[MAP_SIZE][MAP_SIZE];
	static int dir_map[MAP_SIZE][MAP_SIZE];
	priority_queue<Node> pq[2];
	int pqi;
	int i, j, x, y, xdx, ydy;
	memset(closed_nodes_map, 0, sizeof(closed_nodes_map));
	memset(open_nodes_map, 0, sizeof(open_nodes_map));
	if (start == dest)
		return;
	for (size_t i = 0; i < blocks.size(); ++i)
		if (blocks[i].x >= 0 && blocks[i].x < MAP_SIZE && blocks[i].y >= 0 && blocks[i].y < MAP_SIZE)
			closed_nodes_map[blocks[i].x][blocks[i].y] = 1;
	if (closed_nodes_map[dest.x][dest.y] == 1) {
		xdx = start.x < dest.x ? -1 : 1;
		ydy = start.y < dest.y ? -1 : 1;
		x = dest.x;
		y = dest.y;
		while (closed_nodes_map[x][y] == 1) {
			if (checkOnLine(start, dest, Pos(x + xdx, y)))
				x += xdx;
			else
				y += ydy;
		}
		dest = Pos(x, y);
	}
	Node n0(start.x, start.y, 0, 0);
	n0.updatePriority(dest.x, dest.y);
	pqi=0;
	pq[pqi].push(n0);
	open_nodes_map[start.x][start.y] = n0.priority;
	while(!pq[pqi].empty()) {
		n0 = pq[pqi].top();
		pq[pqi].pop();
		x = n0.x;
		y = n0.y;
		open_nodes_map[x][y] = 0;
		closed_nodes_map[x][y] = 1;
		if(x == dest.x && y == dest.y) {
			while(!(x == start.x && y == start.y)) {
				j = dir_map[x][y];
				path.push_back(Pos(x, y));
				x += dx[j];
				y += dy[j];
			}
			path.push_back(start);
			reverse(path.begin(), path.end());
			return;
		}
		for(i = 0; i < 4; i++) {
			xdx=x+dx[i];
			ydy=y+dy[i];
			if(!(xdx < 0 || xdx >= MAP_SIZE || ydy < 0 || ydy >= MAP_SIZE
					|| map.getHeight(xdx, ydy) - map.getHeight(x, y) > 1
					|| map.getHeight(xdx, ydy) - map.getHeight(x, y) < -1
					|| closed_nodes_map[xdx][ydy] == 1)) {
				Node m0(n0);
				m0.x = xdx;
				m0.y = ydy;
				m0.nextLevel();
				m0.updatePriority(dest.x, dest.y);
				if(open_nodes_map[xdx][ydy] == 0) {
					open_nodes_map[xdx][ydy] = m0.priority;
					pq[pqi].push(m0);
					dir_map[xdx][ydy] = (i + 2) % 4;
				} else if(open_nodes_map[xdx][ydy] > m0.priority) {
					open_nodes_map[xdx][ydy] = m0.priority;
					dir_map[xdx][ydy] = (i + 2) % 4;
					while(!(pq[pqi].top().x == xdx && pq[pqi].top().y == ydy)) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pq[pqi].pop();
					if(pq[pqi].size() > pq[1 - pqi].size())
						pqi=1 - pqi;
					while(!pq[pqi].empty()) {
						pq[1 - pqi].push(pq[pqi].top());
						pq[pqi].pop();
					}
					pqi=1 - pqi;
					pq[pqi].push(m0);
				}
			}
		}
	}
}

bool isActiveSkill(PSkill* mySkill) //登僅室嬬頁倦葎麼強室嬬
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //陣崙ai議麼窃
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();
	void buyNewHero();
	void action();
private:
	Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;
	PUnit *myBase, *enemyBase;
};

class AIHero; //念哈喘蕗苧

class Strategy //貨待児窃
{
public:
	virtual int countWorth() = 0; //柴麻蝶嶽貨待議糞佩勺峙
	virtual void work() = 0; //糞宸嶽貨待
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class Attack:public Strategy //好似蝶倖汽了議貨待
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class UseSkill:public Strategy //斤蝶倖汽了瞥慧室嬬議貨待
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //哂俛化佩指社議貨待
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class CallBackHome:public Strategy //孰指哂俛議貨待
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class GoMining:public Strategy //寡嵩議貨待
{
public:
	GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};

class Tempt:public Strategy //哈嗾黍繁勸講議貨待-軸叱窄隠屬徭失音鞭彬議秤趨和序佩hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class AIHero //斤哘耽倖哂俛議貨待畳貨
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //潮範僉夲指社議貨待
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //功象貨待議勺峙登僅頁倦僉夲仟議貨待
	void action(); //序佩輝念議恷單貨待
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
	console->changeShortestPathFunc(findPath);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
			enemyHeros.push_back(enemyUnits[i]);
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		console->buyHeroLevel(heroToLevelUp[i]);
}

void AIController::buyNewHero()
{
	//短嗤登僅頁倦孰蚕撹孔絞泌惚短撹孔孰蚕乏會祥氏岱渠
	int newHero = heroRank % 10 - 1;
	if(newHero >= 0 && newHero < 4) console->chooseHero(HERO_NAME[newHero]);
	else
	{
		newHero = rand() % 4;
		console->chooseHero(HERO_NAME[newHero]);
	}
	heroRank /= 10;
}

void AIController::action()
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < MINE_NUM; ++j)
			allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]));
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setConsole(console);
	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)
			AIHeroList[j]->setStrategy(allStrategy[i]);
	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	mStrategy->work();
}

int Attack::countWorth()
{
	this->worth = 0;
	if(target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos) <= supportRange)
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
		if(dis2(worker->pos,target->pos) > worker->range)
			this->worth -= outOfRangeArg;
		if(target->isWild()) this->worth -= monsterAvoid;
	}
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

int UseSkill::countWorth()
{
	this->worth = 0;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				//緩侃亟斤室嬬議侃尖喇噐劔箭ai絞掲械酒待
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
						if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
							this->worth -= outOfRangeArg;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 2 * attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
				}
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

int Tempt::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void Tempt::work()
{
}

int GoMining::countWorth()
{
	this->worth = miningArg;
	if(target == MINE_POS[0])
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			if(AIHeroList[i]->getStrategy() != NULL)
				if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
				{
					GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
					if(otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;
				}
	}
	this->worth -= dis(worker->pos, target);
	if(target == MINE_POS[0])
		this->worth += centerMineArg;
	return this->worth;
}

void GoMining::work()
{
	console->selectUnit(worker);
	console->move(target);
}

int GoBackHome::countWorth()
{
	this->worth = 0;
	if(worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0) this->worth += goBackHomeArg;
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(console->getMilitaryBase()->pos);
}

int CallBackHome::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void CallBackHome::work()
{
	console->callBackHero(worker);
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController controller(map,info,cmd);
	if(info.round == 0)
	{
		for(int i = 1; i <= 4; ++i)
			controller.buyNewHero();
		return;
	}
	if(newHeroFirst)
	{
		controller.buyNewHero();
		controller.levelupHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	controller.action();
}
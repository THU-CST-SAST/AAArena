#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>//引用了一堆头文件
using namespace std;
int BeInferior = 0, BeHomeStolen = 0, theRound = 0, theBegin = 0,BeginSteal = 0, BeginGather = 0, myHerosNum = 4, needToDefence = 0,theRound1 = 0, theBegin1 = 0, needToGather = 1, BeInGood = 0, BeginAttack = 0;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};//初始化四个英雄的名字
static int heroRank = 4312,heroRank1 = 3131,heroNum = 5322;//这个是个买英雄的顺序
static int newHeroFirst = 1;
static int attackArg = 200, supportRange = 100, monsterAvoid = 10000*200, enemyAvoid = 30, deltaFightArg = 100, ScouterAvoid = 1,SacrificeAvoid = 1000, homeDefence = 50000000;
static int outOfRangeArg = 100;
static int miningArg = 1, sameMineArg = 0, centerMineArg = 30;
static int goBackHomeHp = 100, goBackHomeArg = 300000, CallBackHomeHp = 50, CallBackHomeArg = 5000000;
static int hammerDizzy = 50, BerserkerKill = 100;
static int strategyDisabled = - 1<<30;
static int Dizzy = 500 * 200;
static const Pos PLACE_POS[] = {Pos(74, 75), Pos(50, 10), Pos(10, 40), Pos(100, 140), Pos(140, 110), Pos(20,140), Pos(109,137), Pos(9,32), Pos(135,145), Pos(15,5), Pos(72,73), Pos(99,87), Pos(107,89), Pos(75,77), Pos(51,63), Pos(43,61)};//将这个固定的地方彻底改变

bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

//建立console后一定要delete console
class AIController //控制ai的主类，各种各样的ai函数
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();//升级英雄
	void buyNewHero();//买新的英雄
	void action();//英雄的活动
private:
	Console* console;//建立一个console
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;//声明两个vector 
	PUnit *myBase, *enemyBase;//定义单元，自己的基地和敌人的基地
};

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual int countWorth() = 0; //计算某种策略的实行价值  定义一个虚函数
	virtual void work() = 0; //实现这种策略
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class Attack:public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class CallBackHome:public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class GoMining:public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};

class Tempt:public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //默认选择回家的策略
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();//将myHero清空
	std::vector<PUnit*> myUnits = console->friendlyUnits();//获取己方的单位
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	enemyBase = NULL;
	for(int i = 0; i < myUnits.size(); ++i)//对于myUnits中的成员进行判断
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);//判断这个是一个英雄，将其加入myHero中
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan") || !strcmp(enemyUnits[i]->name, "Observer"))
			enemyHeros.push_back(enemyUnits[i]);//同样的手法判断对方英雄
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;//删除，释放空间
}

void AIController::levelupHero()
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");//取一个基地周围的英雄，
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
	{
		// if(heroToLevelUp[i]->findBuff("Reviving") != NULL)//这个合不合理有待商讨
		// 	return;
		if(!strcmp(heroToLevelUp[i]->name,"Scouter") && heroToLevelUp[i]->level >= 2)
			return;
		if(myHerosNum >= 5)
			console->buyHeroLevel(heroToLevelUp[i]);
	}	
}

void AIController::buyNewHero()
{
	//没有判断是否召唤成功，故如果没成功召唤顺序就会乱掉
	int newHero = heroRank % 10 - 1;
	//cout << "newHero" << newHero << endl;
	if(newHero >= 0 && newHero < 4 && heroRank != 0) 
	{
		if (console->camp() == 0)
		{
			if(newHero == 0)
				console->chooseHero(HERO_NAME[newHero], Pos(22,14));
			if(newHero == 1)
				console->chooseHero(HERO_NAME[newHero], Pos(24,12));
			if(newHero == 2)
				console->chooseHero(HERO_NAME[newHero], Pos(21,15));
			if(newHero == 3)
				console->chooseHero(HERO_NAME[newHero], Pos(19,16));
		}
		else if (console->camp() == 1)
		{
			if(newHero == 0)
				console->chooseHero(HERO_NAME[newHero], Pos(129,135));
			if(newHero == 1)
				console->chooseHero(HERO_NAME[newHero], Pos(128,136));
			if(newHero == 2)
				console->chooseHero(HERO_NAME[newHero], Pos(127,137));
			if(newHero == 3)
				console->chooseHero(HERO_NAME[newHero], Pos(127,138));
		}
	}
	else if(info->gold > 250 * (heroNum % 10) && myHeros.size() < 8)
	{
		cout << "买英雄啊！买英雄啊！！买英雄啊啊啊！！！newHero" << newHero << endl;
		newHero = heroRank1 % 10 - 1;
		if (console->camp() == 0)
		{
			console->chooseHero(HERO_NAME[newHero],Pos(24,12));
			myHerosNum++;
		}
		else if (console->camp() == 1)
		{
			console->chooseHero(HERO_NAME[newHero], Pos(128,136));
			myHerosNum++;
		}
		heroRank1 /= 10;
		heroNum /= 10;
	}
	//cout << "newHero" << newHero << endl;
	heroRank /= 10;
}

void AIController::action()//在团战时如何打
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	cout << console->getMilitaryBase()->hp << endl;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
	if(enemyBase != NULL)
	{
		for(int i = 0; i < myHeros.size(); ++i)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyBase));//推家
	}
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
	if(enemyBase != NULL)
	{
		for(int i = 0; i < myHeros.size(); ++i)
			allStrategy.push_back(new Attack(myHeros[i], enemyBase));//推家
	}
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < 16; ++j)
			allStrategy.push_back(new GoMining(myHeros[i],PLACE_POS[j]));//去金矿的策略是在这几个金矿中找的,改成自己的了
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)
		allStrategy[i]->setConsole(console);
	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)
			AIHeroList[j]->setStrategy(allStrategy[i]);
	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)//选出最优的策略
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	mStrategy->work();
}

int Attack::countWorth()
{
	this->worth = 0;
	std::vector<PUnit*> myUnits = console->friendlyUnits();//获取己方的单位
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	if(target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos) <= supportRange)//在一定范围外就不会去打了
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
		if(target->findBuff("Dizzy") != NULL)
			this->worth += Dizzy;
		if(target->findBuff("WaitRevive" != NULL) && (double)target->max_hp/(double)target->hp > 2)
			this->worth += Dizzy + 1;
		// if(dis2(worker->pos,target->pos) > worker->range)
		// 	this->worth -= outOfRangeArg;
		if(target->isWild() && dis2(Pos(20,140), worker->pos) > 144 && BeginAttack == 0) 
			this->worth = strategyDisabled;
		if (!strcmp(target->name, "Berserker"))//更多的去打剑士
		 	this->worth += BerserkerKill;
		if(!strcmp(target->name, "Berserker") && ((!strcmp(worker->name, "Scouter")) || !strcmp(worker->name, "Master")) && target->findBuff("WinOrDie"))
			this->worth += BerserkerKill * 10000;
		if(BeInGood == 0)
		{
			if(dis2(Pos(74,75), target->pos) >= 36 && dis2(MILITARY_BASE_POS[1 - console->camp()], target->pos) <= 8000 && dis2(worker->pos, Pos(74,75)) <= 400)//敌人跑远了就不打了
				this->worth -= monsterAvoid;
		}
		if(BeInGood == 1)//在优势打野的时候也要有死线
		{
			if(console->camp() == 0)
			{
				if(dis2(Pos(107,89), target->pos) >= 100)
					this->worth -=monsterAvoid;
			}
			if(console->camp() == 1)
			{
				if(dis2(Pos(43,61), target->pos) >= 100)
					this->worth -=monsterAvoid;
			}
		}
		if(dis2(worker->pos, MILITARY_BASE_POS[1 - console->camp()]) <= 144 && strcmp(target->name, "MilitaryBase") == 0)//偷家强打
				this->worth += 400000000;
		if(BeginAttack == 1)//在外作战，先打人再打野
		{
			if(target->isWild())
				this->worth -= monsterAvoid;
			if(console->camp() == 0)
			{
				int tmp = 0;
				for(int i = 0; i < enemyUnits.size(); ++i)
				{
					if(dis2(enemyUnits[i]->pos, Pos(107,89)) <= 144 && strcmp(enemyUnits[i]->name, "Mine") && !enemyUnits[i]->isWild())
						tmp++;
				}
				if(tmp == 0)
					this->worth += monsterAvoid;
			}
			if(console->camp() == 1)
			{
				int tmp = 0;
				for(int i = 0; i < enemyUnits.size(); ++i)
				{
					if(dis2(enemyUnits[i]->pos, Pos(43,61)) <= 144 && strcmp(enemyUnits[i]->name, "Mine") && !enemyUnits[i]->isWild())
						tmp++;
				}
				if(tmp == 0)
					this->worth += monsterAvoid;
			}
		}
		int tmp = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)//在中圈没人的时候打野
		{
			if(dis2(enemyUnits[i]->pos, Pos(74,75)) <= 400 && strcmp(enemyUnits[i]->name, "Mine") && strcmp(enemyUnits[i]->name, "Observer"))
				tmp++;
		}
		if(tmp == 0 && target->isWild())
			this->worth += monsterAvoid;
		if(!strcmp(target->name, "Observer"))
			this->worth -= monsterAvoid;
		int tmp1 = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)//在中圈没人的时候打野
		{
			if(dis2(enemyUnits[i]->pos, target->pos) <= 400 && strcmp(enemyUnits[i]->name, "Mine") && strcmp(enemyUnits[i]->name, "Observer") && !strcmp(target->name, "Observer"))
				tmp1++;
		}
		if(tmp1 == 0 && !strcmp(target->name, "Observer"))
			this->worth += monsterAvoid;
		// if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) < 1250)//偷家防守
		// 	this->worth += homeDefence;
		// if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(target->name, "Berserker") && target->findSkill("Sacrifice")->cd == 0)//在家的时候疯狂打剑士
		//  	this->worth += BerserkerKill * 100000;
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && target->findBuff("WinOrDie") != NULL && !strcmp(worker->name, "Berserker"))//如果对方放大，死也要打下来
			this->worth += 700000000;
		if(!strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) >= 144)//在这种状态下，谁近打谁
			this->worth += 20000000 / (dis2(worker->pos, target->pos));
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && !strcmp(target->name, "Hammerguard") && worker->id <= 24 && target->id <= 24)//在这种状态下，大打大
			this->worth += 20000000 ;
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && !strcmp(target->name, "Hammerguard") && worker->id >=24 && target->id > 24)//在这种状态下，小打小
			this->worth += 20000000 ;
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && (!strcmp(worker->name, "Berserker") || !strcmp(worker->name, "Scouter")) && !strcmp(target->name, "Hammerguard"))//剑士和太保全力敲锤兵
			this->worth += 2000000;
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && (!strcmp(worker->name, "Hammerguard") || !strcmp(worker->name, "Master")) && !strcmp(target->name, "Berserker"))//锤兵和术士全力打剑士
			this->worth += 2000000 / dis2(target->pos, MILITARY_BASE_POS[console->camp()]);
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(target->name, "Hammerguard"))//没人的时候去优先打锤兵
			this->worth += 200000;
		if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(target->name, "Berserker") && (target->findSkill("Sacrifice")->cd == 0 || target->findBuff("WaitRevive") == NULL))//没人的时候去打剑士
			this->worth += 100000;
		if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 144)
			this->worth += 500100;
		if(needToDefence == 1)
		{
			if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && target->findBuff("WinOrDie") != NULL && !strcmp(worker->name, "Berserker"))//如果对方放大，死也要打下来
				this->worth += 700000000;
			if(!strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) >= 144)//在这种状态下，谁近打谁
				this->worth += 20000000 / (dis2(worker->pos, target->pos));
			// if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && !strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && !strcmp(target->name, "Hammerguard") && worker->id <= 24 && target->id <= 24)//在这种状态下，大打大
			// 	this->worth += 20000000 ;
			// if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && !strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") != NULL && !strcmp(target->name, "Hammerguard") && worker->id >=24 && target->id > 24)//在这种状态下，小打小
			// 	this->worth += 20000000 ;
			if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && (!strcmp(worker->name, "Berserker") || !strcmp(worker->name, "Scouter")) && !strcmp(target->name, "Hammerguard"))//剑士和太保全力敲锤兵
				this->worth += 2000000;
			if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && (!strcmp(worker->name, "Hammerguard") || !strcmp(worker->name, "Master")) && !strcmp(target->name, "Berserker"))//锤兵和术士全力打剑士
				this->worth += 2000000 / dis2(target->pos, MILITARY_BASE_POS[console->camp()]);
			if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && !strcmp(target->name, "Hammerguard"))//没人的时候去优先打锤兵
				this->worth += 200000;
			if(dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && !strcmp(target->name, "Berserker") && (target->findSkill("Sacrifice")->cd == 0 || target->findBuff("WaitRevive") == NULL))//没人的时候去打剑士
				this->worth += 100000;
			if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)
				this->worth += 500100;
		}
	}
	else if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)//在守家时要冲上去打
			this->worth += 500100;
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

int UseSkill::countWorth()
{
	this->worth = 0;
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				//此处写对技能的处理，由于样例ai故非常简略
				if(!strcmp(skillList[i]->name, "HammerAttack"))//锤子的目标是否需要特定
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= HAMMERATTACK_RANGE)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
						// if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
						// 	this->worth -= outOfRangeArg;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= monsterAvoid;
						if(!(strcmp(target->name, "Berserker")) && target->findBuff("WinOrDie") != NULL)//在剑士大招时直接打断
							this->worth += 1000000;
						if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 144 && !strcmp(target->name, "Berserker"))
							this->worth += 600000001;
						if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) >= 144 && dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)
							this->worth += 600000001 / dis2(target->pos, worker->pos);
					}
				}
				if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					
					if(target->findBuff("Reviving") != NULL )
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
						if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)//先落地，再开大
						this->worth += 500000000;
					}
					int tmp = 0;
					for(int i = 0; i < enemyUnits.size(); ++i)
						tmp++;
					if(worker->findBuff("BeAttacked") != NULL)//被别人打的时候就不要打了
						this->worth = strategyDisabled;
					if(!strcmp(target->name, "MilitaryBase") && dis2(worker->pos, MILITARY_BASE_POS[1 - console->camp()]) <= 8 && worker->findBuff("BeAttacked") == NULL) 
						this->worth += 500000000;
					// if(dis2(target->pos, MILITARY_BASE_POS[console->camp()]) <= 2250 && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)//先落地，再开大
					// 	this->worth += 500000000;
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))//插眼的策略//还要改的
				{
					int tmp = 0;
					for(int j = 0; j < enemyUnits.size(); ++j)//见到敌方在自己家门口，立即放眼
					{
						if(dis2(enemyUnits[j]->pos, worker->pos) < 380 && dis2(worker->pos,MILITARY_BASE_POS[console->camp()]) < 3250 && dis2(worker->pos,MILITARY_BASE_POS[console->camp()]) > 144)
						{
							this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
							this->worth += 200000000;
					     	return this->worth;
						}
						if(dis2(enemyUnits[j]->pos, Pos(72,76)) == 0)
							tmp = 1;
					}
					if(dis2(worker->pos,Pos(72,76)) < skillList[i]->range() && dis2(worker->pos,Pos(72,76)) > 0 && tmp == 0)//中矿插眼
					{
						this->targetPos = Pos(72,76);
						this->worth += 20000000;
					}
				}
				else if(!strcmp(skillList[i]->name, "Blink"))//术士Blink的策略(差一个回家加速的策略)
				{
					if(worker->hp < 150 && worker->findBuff("BeAttacked"))
					{
						this->targetPos = console->closestPos(worker->pos, skillList[i]->range(), MILITARY_BASE_POS[console->camp()]);
						this->worth += 1000000;
					}
					
				}
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else if(!strcmp(skillList[i]->name, "SetObserver"))
				console->useSkill(skillList[i], targetPos);
			else if(!strcmp(skillList[i]->name, "Blink"))
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

int Tempt::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void Tempt::work()
{
}

int GoMining::countWorth()//在这里的前面加上对于形势的判断//在这里加入太保走位的方案,并且有各种对于不同形势的打法
{
	this->worth = miningArg;
	std::vector<PUnit*> myUnits = console->friendlyUnits();//获取己方的单位
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	//对于形势的判断
	
	if(BeInferior == 0)//判断己方劣势//对手在金矿是否有>=6个英雄
	{
		int tmp = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, Pos(74,75)) < 400 && strcmp(enemyUnits[i]->name, "Mine"))
				tmp++;
		}
		int tmp1 = 0;
		for(int i = 0; i < myUnits.size(); ++i)
		{
			if(dis2(myUnits[i]->pos, Pos(74,75)) < 2000)
				tmp1++;
		}
		if(tmp >= 5 && tmp1 < 3)
			BeInferior = 1;
	}
	if(BeInferior == 1)//翻盘策略//只有在对方要偷家的时候进行判断//一被偷家就算自己不是劣势
	{
		int tmp = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, worker->pos) <= 144 && strcmp(enemyUnits[i]->name, "Mine"))
				tmp++;
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) < 144)
				BeInferior = 0;
		}
		int tmp1 = 0;
		for(int i = 0; i < myUnits.size(); ++i)
		{
			if(dis2(myUnits[i]->pos, MILITARY_BASE_POS[1 - console->camp()]) >= 144 && dis2(myUnits[i]->pos, MILITARY_BASE_POS[1 - console->camp()]) <= 2500)
				tmp1++;
		}
		if(tmp >= 3 && tmp1 >= 6)//如果在进入对方基地之前见到对方3个人以上，则对方守家，算己方不劣势
			BeInferior = 0;
	}
	if(BeHomeStolen == 0)//判断己方是否被偷家
	{
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) < 144)
				BeHomeStolen = 1;
		}
	}
	if(BeHomeStolen == 1 && BeInferior == 1 && console->round() >= 150)//若对方放弃偷家，150回合没有对方人马身影出现
	{
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) > 3250 && theBegin == 0 && strcmp(enemyUnits[i]->name, "Mine"))
			{
				theRound = console->round();
				theBegin = 1;
			}
		}
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) < 2250 && theBegin == 1)
			{
				theRound = console->round();
				theBegin = 0;
			}
		}
		if(console->round() - theRound >= 150)
			BeHomeStolen = 0;
	}
	if(needToDefence == 0 && console->getMilitaryBase()->hp < 1500)
		needToDefence = 1;
	if(BeInferior == 1)
	{
		BeInGood = 0;
		needToGather = 0;
		BeginAttack = 0;
	}
	if(needToDefence == 1)//对方偷过家后150回合内没在来偷就可以视为对方不再偷了
	{
		//int tmp = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) > 3250 && theBegin1 == 0)
			{
				theRound1 = console->round();
				theBegin1 = 1;
			}
			// if(dis2(enemyUnits[i]->pos, Pos(74,75)) <= 400)
			// 	tmp++;
		}
		// if(tmp >= 3)
		// 	needToDefence = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) < 2250 && theBegin1 == 1)
			{
				theRound1 = console->round();
				theBegin1 = 0;
			}
		}
		if(console->round() - theRound1 >= 150)
			needToDefence = 0;
	}
	int tmp = 0;
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) <= 144)
			tmp++;
	}
	if(BeInferior == 0 && tmp == 0)
	{
		if(BeInGood == 0)//这样是否打得过，需要测试一下
		{
			BeginAttack = 0;
			int tmp = 0;
			for(int i = 0; i < enemyUnits.size(); ++i)
			{
				if(dis2(enemyUnits[i]->pos, Pos(74,75)) <= 400 && strcmp(enemyUnits[i]->name, "Mine"))
					tmp++;
			}
			int tmp1 = 0;
			for(int i = 0; i < myUnits.size(); ++i)
			{
				if(dis2(myUnits[i]->pos, Pos(74,75)) <= 36 && strcmp(myUnits[i]->name, "Observer"))
					tmp1++;
			}
			if(tmp == 0 && tmp1 >= 5)
				BeInGood = 1;
		}
		if(BeInGood == 1)
		{
			int tmp = 0;
			for(int i = 0; i < enemyUnits.size(); ++i)
			{
				if(dis2(enemyUnits[i]->pos, Pos(74,75)) <= 400 && strcmp(enemyUnits[i]->name, "Mine"))
					tmp++;
			}
			if(tmp > 0)
				BeInGood = 0;
			if(myHerosNum >= 8 && console->round() >= 300)
				BeInGood = 2;
		}
		if(needToGather == 0)
		{
			int tmp = 0,tmp1 = 0;
			for(int i = 0; i < enemyUnits.size(); ++i)
			{
				if(dis2(enemyUnits[i]->pos, Pos(74,75)) < 400 && strcmp(enemyUnits[i]->name, "Mine"))
					tmp++;
				if(dis2(enemyUnits[i]->pos, Pos(74,75)) <= 36 && strcmp(enemyUnits[i]->name, "Mine") && strcmp(enemyUnits[i]->name, "Observer"))
					tmp1++;
			}
			if(tmp1 == 0 && BeInGood == 0)
				needToGather = 1;
			if(tmp == 0 && BeInGood == 1 && BeginAttack == 0)
				needToGather = 2;
		}
		if(needToGather == 1)//有一个人接近到了36就开打
		{
			int tmp = 0;
			for(int i = 0; i < enemyUnits.size(); ++i)
			{
				if(dis2(enemyUnits[i]->pos, worker->pos) <= 36 && dis2(worker->pos, Pos(74,75)) <= 400 && !enemyUnits[i]->isWild() && strcmp(enemyUnits[i]->name, "Mine"))//金矿的名字叫Mine
					needToGather = 0;
				if(dis2(enemyUnits[i]->pos, Pos(74,75)) < 400 && strcmp(enemyUnits[i]->name, "Mine"))
					tmp++;
			}
			if(tmp == 0 && BeInGood == 1 && BeginAttack == 0)
				needToGather = 2;
		}	
		if(needToGather == 2)//要求必须分清是在打人还是在打野
		{
			if(console->camp() == 0)
			{
				UnitFilter filter3;
				filter3.setAreaFilter (new Circle (Pos(99,87), 36 ), "a");//w代表重写，把之前的覆盖掉
				vector<PUnit*> tmp = console->friendlyUnits (filter3);
				int tmp1 = 0;
				for(int i = 0; i < enemyUnits.size(); ++i)
				{
					if(!enemyUnits[i]->isWild() && dis2(enemyUnits[i]->pos, worker->pos) <= 36 && strcmp(enemyUnits[i]->name, "Mine"))
						tmp1++;
					if(enemyUnits[i]->isWild() && enemyUnits[i]->findBuff("Reviving") == NULL)
						tmp1++;
				}
				if(tmp.size() >= 5 || tmp1 > 0)//只要集合好了，或有人比较近，就开始打，打完了就去金矿
				{
					needToGather = 0;
					BeginAttack = 1;//开始打
				}
					
			}
			if(console->camp() == 1)
			{
				UnitFilter filter4;
				filter4.setAreaFilter (new Circle (Pos(51,63), 36 ), "a");//w代表重写，把之前的覆盖掉
				vector<PUnit*> tmp = console->friendlyUnits (filter4);
				int tmp1 = 0;
				for(int i = 0; i < enemyUnits.size(); ++i)
				{
					if(!enemyUnits[i]->isWild() && dis2(enemyUnits[i]->pos, worker->pos) <= 36 && strcmp(enemyUnits[i]->name, "Mine"))
						tmp1++;
					if(enemyUnits[i]->isWild() && enemyUnits[i]->findBuff("Reviving") == NULL)
						tmp1++;
				}
				if(tmp.size() >= 5 || tmp1 > 0)//只要集合好了，或有人比较近，就开始打，打完了就去金矿
				{
					needToGather = 0;
					BeginAttack = 1;//开始打
				}
			}
			
		}
	}
	
	// if(BeginAttack == 1)
	// {
	// 	int tmp = 0;
	// 	for(int i = 0; i < myUnits.size(); ++i)
	// 	{
	// 		if(dis2(myUnits[i]->pos, Pos(43,61)) <= 36 || dis2(myUnits[i]->pos, Pos(107,89)) <= 36)
	// 			tmp++;
	// 	}
	// 	int tmp1 = 0;
	// 	if(console->camp() == 0)
	// 	{
	// 		for(int i = 0; i < enemyUnits.size(); ++i)
	// 		{
	// 			if(dis2(enemyUnits[i]->pos, Pos(107,89)) <= 144 && enemyUnits[i]->findBuff("Reviving") == NULL && strcmp(enemyUnits[i]->name, "Mine"))
	// 				tmp1++;
	// 		}
	// 	}
	// 	if(console->camp() == 1)
	// 	{
	// 		for(int i = 0; i < enemyUnits.size(); ++i)
	// 		{
	// 			if(dis2(enemyUnits[i]->pos, Pos(43,61)) <= 144 && enemyUnits[i]->findBuff("Reviving") == NULL && strcmp(enemyUnits[i]->name, "Mine"))
	// 				tmp1++;
	// 		}
	// 	}
	// 	if(tmp >= 5 && tmp1 == 0)
	// 		BeginAttack = 0;
	// }
	if(myHerosNum == 8)
		BeInGood = 2;
	//下面是走位方法
	if(BeInGood != 2)
	{
		if(BeInferior == 0)
		{
			if(target == PLACE_POS[0])
			{
				for(int i = 0; i < AIHeroList.size(); ++i)
					if(AIHeroList[i]->getStrategy() != NULL)
						if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
						{
							GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
							if(otherMining->getTarget() == this->target)
								this->worth -= sameMineArg;
						}
			}
			if(target == PLACE_POS[0])
				this->worth += centerMineArg;
			if(needToDefence == 1)//在家快守不住时插眼回防//双太保，一人防一个区域
			{
				if(worker->id <= 25)
				{
					for(int i = 0; i < enemyUnits.size(); ++i)
					{
						if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[1] && console->camp() == 0 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144 )
							this->worth += 10000000;
						else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[3] && console->camp() == 1 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144 )
							this->worth += 10000000;
						// else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[2] && console->camp() == 0 && console->round() > 300 && console->round() % 50 >= 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144)
						// 	this->worth += 10000000;
						// else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[4] && console->camp() == 1 && console->round() > 300 && console->round() % 50 >= 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144)
						// 	this->worth += 10000000;
					}
				}
				if(worker->id > 24)
				{
					for(int i = 0; i < enemyUnits.size(); ++i)
					{
						// if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[1] && console->camp() == 0 && console->round() > 300 && console->round() % 50 >= 0 && console->round() % 50 < 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144 )
						// 	this->worth += 10000000;
						// else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[3] && console->camp() == 1 && console->round() > 300 && console->round() % 50 >= 0 && console->round() % 50 < 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144 )
						// 	this->worth += 10000000;
						if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[2] && console->camp() == 0 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144)
							this->worth += 10000000;
						else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[4] && console->camp() == 1 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144)
							this->worth += 10000000;
					}
				}
			}
		}
		if(BeInferior == 1)//劣势就去打野，这样对方推过来的时候不会太弱//里面再判断会不会被偷家
		{
			if(BeHomeStolen == 0)//先打野，再偷家
			{
				if(target == PLACE_POS[5])
				{
					for(int i = 0; i < AIHeroList.size(); ++i)
						if(AIHeroList[i]->getStrategy() != NULL)
							if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
							{
								GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
								if(otherMining->getTarget() == this->target)
									this->worth -= sameMineArg;
							}
				}
				if(target == PLACE_POS[5])
					this->worth += centerMineArg;
				//偷家
				UnitFilter filter;
				filter.setAreaFilter (new Circle (Pos(20,140), 36 ), "a");
				vector<PUnit*> heroToGather1 = console->friendlyUnits (filter);
				if(heroToGather1.size() >= 8)
					BeginGather = 1;
				if(BeginGather == 1)
				{
					if(target == PLACE_POS[console->camp() + 6] && dis2(worker->pos, PLACE_POS[console->camp() + 6]) >= 9)
						this->worth += 300000000;
				}

				UnitFilter filter1;
				filter1.setAreaFilter (new Circle (PLACE_POS[console->camp() + 6], 36 ), "a");//w代表重写，把之前的覆盖掉
				vector<PUnit*> heroToGather2 = console->friendlyUnits (filter1);
				if(heroToGather2.size() >= 6)
				{
					BeginGather = 0;
					BeginSteal = 1;
				}
				if(BeginSteal == 1)
				{
					if(dis2(worker->pos, PLACE_POS[console->camp() + 8]) >= 64 && target == PLACE_POS[console->camp() + 8])
						this->worth += 300000000;
				}
				UnitFilter filter2;
				filter2.setAreaFilter (new Circle (PLACE_POS[console->camp() + 6], 2000 ), "a");
				vector<PUnit*> heroToGather3 = console->friendlyUnits (filter2);
				if(heroToGather3.size() <= 3)
					BeginSteal = 0;
			}
			else if(BeHomeStolen == 1)
			{
				if(target == PLACE_POS[5])
				{
					for(int i = 0; i < AIHeroList.size(); ++i)
						if(AIHeroList[i]->getStrategy() != NULL)
							if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
							{
								GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
								if(otherMining->getTarget() == this->target)
									this->worth -= sameMineArg;
							}
				}
				if(target == PLACE_POS[5])
					this->worth += centerMineArg;
				if(needToDefence == 1)
				{
					for(int i = 0; i < enemyUnits.size(); ++i)
					{
						if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[1] && console->camp() == 0 && console->round() > 300 && console->round() % 50 >= 25 && console->round() % 50 < 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144 && dis2(enemyUnits[i]->pos,Pos(74,75)) > 400)
							this->worth += 10000000;
						else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[3] && console->camp() == 1 && console->round() > 300 && console->round() % 50 >= 25 && console->round() % 50 < 25 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144 && dis2(enemyUnits[i]->pos,Pos(74,75)) > 400)
							this->worth += 10000000;
						else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[2] && console->camp() == 0 && console->round() > 300 && console->round() % 50 >= 0 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[0]) > 144 && dis2(enemyUnits[i]->pos,Pos(74,75)) > 400)
							this->worth += 10000000;
						else if(!strcmp(worker->name, "Scouter") && target == PLACE_POS[4] && console->camp() == 1 && console->round() > 300 && console->round() % 50 >= 0 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[1]) > 144 && dis2(enemyUnits[i]->pos,Pos(74,75)) > 400)
							this->worth += 10000000;
					}
				}
			}
		}
		int tmp = 0;
		for(int i = 0; i < enemyUnits.size(); ++i)//要保证家里没人的时候在出击
		{
			if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) <= 144)
				tmp++;
		}
		if(needToGather == 1 && tmp == 0)
		{
			if(console->camp() == 0)
			{
				if(target == PLACE_POS[10])
					this->worth += 10000000;
			}
			if(console->camp() == 1)
			{
				if(target == PLACE_POS[13])
					this->worth += 10000000;
			}
		}
		if(needToGather == 2 && tmp == 0 && BeInGood == 1)
		{
			if(console->camp() == 0 && !(worker->id <= 25 && !strcmp(worker->name, "Scouter")) && BeInGood == 1)
			{
				if(target == PLACE_POS[11])
					this->worth += 10000000;
			}
			// if(console->camp() == 0 && !(worker->id <= 24 && !strcmp(worker->name, "Scouter")) && BeInGood == 2)
			// {
			// 	if(target == PLACE_POS[14])
			// 		this->worth += 10000000;
			// }
			if(console->camp() == 1 && !(worker->id <= 25 && !strcmp(worker->name, "Scouter")) && BeInGood == 1)
			{
				if(target == PLACE_POS[14])
					this->worth += 10000000;
			}
			// if(console->camp() == 1 && !(worker->id <= 24 && !strcmp(worker->name, "Scouter")) && BeInGood == 2)
			// {
			// 	if(target == PLACE_POS[14])
			// 		this->worth += 10000000;
			// }
		}
		if(needToGather == 0 && BeginAttack == 1 && BeInGood == 1)
		{
			if(console->camp() == 0 && !(worker->id <= 25 && !strcmp(worker->name, "Scouter")))
			{
				if(target == PLACE_POS[12])
					this->worth += centerMineArg * 2;
			}
			if(console->camp() == 1 && !(worker->id <= 25 && !strcmp(worker->name, "Scouter")))
			{
				if(target == PLACE_POS[15])
					this->worth += centerMineArg * 2;
			}
		}
	}
	
	if(BeInGood == 2)
	{
		if(target == PLACE_POS[5])
		{
			for(int i = 0; i < AIHeroList.size(); ++i)
				if(AIHeroList[i]->getStrategy() != NULL)
					if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
					{
						GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
						if(otherMining->getTarget() == this->target)
							this->worth -= sameMineArg;
					}
		}
		if(target == PLACE_POS[5] && dis2(worker->pos, Pos(74,75)) <= 1500)
			this->worth += centerMineArg * 1000000;
		if(target == PLACE_POS[5] && dis2(worker->pos, Pos(74,75)) >= 1500)
			this->worth += centerMineArg;
		//偷家
		UnitFilter filter5;
		filter5.setAreaFilter (new Circle (Pos(20,140), 144 ), "a");
		vector<PUnit*> heroToGather5 = console->friendlyUnits (filter5);
		if(heroToGather5.size() >= 6)
			BeginGather = 1;
		if(BeginGather == 1)
		{
			if(target == PLACE_POS[console->camp() + 6] && dis2(worker->pos, PLACE_POS[console->camp() + 6]) >= 9)
				this->worth += 300000000;
		}
			UnitFilter filter6;
		filter6.setAreaFilter (new Circle (PLACE_POS[console->camp() + 6], 144 ), "a");//w代表重写，把之前的覆盖掉
		vector<PUnit*> heroToGather6 = console->friendlyUnits (filter6);
		if(heroToGather6.size() >= 6)
		{
			BeginGather = 0;
			BeginSteal = 1;
		}
		if(BeginSteal == 1)
		{
			if(dis2(worker->pos, PLACE_POS[console->camp() + 8]) >= 64 && target == PLACE_POS[console->camp() + 8])
				this->worth += 300000000;
		}
		UnitFilter filter7;
		filter7.setAreaFilter (new Circle (PLACE_POS[console->camp() + 6], 3000 ), "a");
		vector<PUnit*> heroToGather7 = console->friendlyUnits (filter7);
		if(heroToGather7.size() <= 3)
			BeginSteal = 0;
	}
	return this->worth;
}

void GoMining::work()
{
	console->selectUnit(worker);
	if(!strcmp(worker->name, "Master") && console->round() == 1)
		console->useSkill("Blink", console->closestPos(worker->pos, 81, Pos(74,75)));
	else
		console->move(target);
}

int GoBackHome::countWorth()//补写防偷家函数
{
	this->worth = 0;
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	if(worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0 && worker->findBuff("BeAttacked"))
		this->worth += goBackHomeArg;
	if(!strcmp(worker->name, "Berserker") && worker->findBuff("WinOrDie") == NULL && worker->hp <= goBackHomeHp)
		this->worth += goBackHomeArg;
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		// if((dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[console->camp()]) < 3250) && (dis2(worker->pos,MILITARY_BASE_POS[console->camp()]) > 1250 ))
		// 	this->worth += 10 * goBackHomeArg;
		if(needToDefence == 1 && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) > 144 && dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[console->camp()]) > 2250 && !(!strcmp(worker->name, "Master") && worker->id <= 25))
			this->worth += 10 * goBackHomeArg;
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(dis2(enemyUnits[i]->pos, MILITARY_BASE_POS[console->camp()]) <= 2250)
			this->worth = 1;
	}
	if (dis2(worker->pos,MILITARY_BASE_POS[console->camp()]) < 144)
		this->worth = 1;
	
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(console->getMilitaryBase()->pos);
}

int CallBackHome::countWorth()
{
	this->worth = 0;
	std::vector<PUnit*> enemyUnits = console->enemyUnits();//获取对方的单位
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if (dis2(enemyUnits[i]->pos,MILITARY_BASE_POS[console->camp()]) <= 144 && dis2(worker->pos, MILITARY_BASE_POS[console->camp()]) > 2250)//在不会攻击到的范围内直接买回
			this->worth += CallBackHomeArg;
	}
	
	return this->worth;
}

void CallBackHome::work()
{
	if(console->camp() == 0)
	{
		if(!strcmp(worker->name, "Hammerguard") && worker->id <= 20)
			console->callBackHero(worker, Pos(14,10));
		if(!strcmp(worker->name, "Hammerguard") && worker->id > 20)
			console->callBackHero(worker, Pos(15,10));
		if(!strcmp(worker->name, "Berserker") && worker->id <= 25)
			console->callBackHero(worker, Pos(16,10));
		if(!strcmp(worker->name, "Berserker") && worker->id > 25)
			console->callBackHero(worker, Pos(13,10));
		if(!strcmp(worker->name, "Master") && worker->id <= 25)
			console->callBackHero(worker, Pos(15,9));
		if(!strcmp(worker->name, "Master") && worker->id > 25)
			console->callBackHero(worker, Pos(14,9));
		// if(!strcmp(worker->name, "Scouter") && worker->id <= 25)
		// 	console->callBackHero(worker, Pos(18,8));
		if(!strcmp(worker->name, "Scouter") && worker->id > 25)
			console->callBackHero(worker, Pos(16,9));
	}
	if(console->camp() == 1)
	{
		if(!strcmp(worker->name, "Hammerguard") && worker->id <= 20)
			console->callBackHero(worker, Pos(134,141));
		if(!strcmp(worker->name, "Hammerguard") && worker->id > 20)
			console->callBackHero(worker, Pos(135,141));
		if(!strcmp(worker->name, "Berserker") && worker->id <= 25)
			console->callBackHero(worker, Pos(136,141));
		if(!strcmp(worker->name, "Berserker") && worker->id > 25)
			console->callBackHero(worker, Pos(133,141));
		if(!strcmp(worker->name, "Master") && worker->id <= 25)
			console->callBackHero(worker, Pos(137,142));
		if(!strcmp(worker->name, "Master") && worker->id > 25)
			console->callBackHero(worker, Pos(132,142));
		// if(!strcmp(worker->name, "Scouter") && worker->id <= 25)
		// 	console->callBackHero(worker, Pos(138,143));
		if(!strcmp(worker->name, "Scouter") && worker->id > 25)
			console->callBackHero(worker, Pos(131,142));
	}
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController controller(map,info,cmd);
	cout << "myHerosNum:" << myHerosNum << endl;
	cout << "BeInGood:" << BeInGood << endl;
	cout << "BeginGather:" << BeginGather << endl;
	cout << "BeginSteal:" << BeginSteal << endl;
	if(info.round == 0)
	{
		for(int i = 1; i <= 4; ++i)
			controller.buyNewHero();
		return;
	}
	if(newHeroFirst)//判定是先买英雄还是先升级
	{
		controller.buyNewHero();
		controller.levelupHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	controller.action();
}
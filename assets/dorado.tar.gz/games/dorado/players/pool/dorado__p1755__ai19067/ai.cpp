#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

static int heroRank = 1234;
static int newHeroFirst = 1;
static int attackArg = 200, supportRange = 1000, monsterAvoid = 0, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100;
static int miningArg = 150, sameMineArg = 10, centerMineArg = 50;
static int goBackHomeHp = 100, goBackHomeArg = 300, goBackBattleHp = 120, goBackBattleArg = 310;
static int hammerDizzy = 50;
static int strategyDisabled = - 1<<30;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};

bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")  //重锤打击
		|| !strcmp(mySkill->name, "Blink")         //闪烁
		|| !strcmp(mySkill->name, "Sacrifice")     //绝命一击
		|| !strcmp(mySkill->name, "SetObserver");  //插眼
}

class AIController //控制ai的主类
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);  //初始化控制台
	~AIController();
public:
	void buyNewHero();    //购买新英雄
	void levelupHero();   //升级英雄
	void action();
private:
	Console* console;   //初始化一个类
    const PMap* map;    //地图信息
    const PPlayerInfo* info;  //ai信息
    PCommand* cmd;    
	std::vector<PUnit*> myHeros, enemyHeros;    //建立动态数组 我方英雄 敌方英雄
	PUnit *myBase, *enemyBase;
};

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual int countWorth() = 0; //计算某种策略的实行价值
	virtual void work() = 0; //实现这种策略
public:
	void setWorker(PUnit* worker) {this->worker = worker;}  //获得我方单位
	int getWorth() {return worth;}                          //返回价值
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}                         //获得名字
	void setAIHeroList(vector<AIHero*>& AIHeroList)       //建立英雄列表
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}    //控制台
protected:
	PUnit* worker;
	int worth;
	vector<AIHero*> AIHeroList;  
	Console* console;
	string name;
};

class Attack:public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}   //找目标
private:
	PUnit* target;
};

/*class GoBackBattle
{
public: 
	GoBackBattle(Punit* worker, Punit* target) { setWorker(worker); setTarget(target); name = "GobackBattle"}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}   //找目标
private:
	PUnit* target;
};*/

/*class Support1:public Strategy
{
public:
	Support1(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Support1";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};*/

class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略      这个策略有问题
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

/*class GoBackBattle:public Strategy  //返回战场的策略  此处更改
{
public:
	GoBackBattle(PUnit* worker){setWorker(worker); name = "GoBackBattle";}
public:
	virtual int countWorth();
	virtual void work();
};*/

class CallBackHome:public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class GoMining:public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};

class Tempt:public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //默认选择回家的策略
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);      //更新地图
    this->info = &(info);    //更新信息
    this->cmd = &(cmd);
	myHeros.clear();         //清空英雄
	std::vector<PUnit*> myUnits = console->friendlyUnits();     //获取己方单位
	std::vector<PUnit*> enemyUnits = console->enemyUnits();     //获取敌方单位
	enemyBase = NULL;  
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);       
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];  
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
			enemyHeros.push_back(enemyUnits[i]);   //敌方英雄
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()  //升级英雄
{
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a"); // 筛选器
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		console->buyHeroLevel(heroToLevelUp[i]);
}

void AIController::buyNewHero()   
{
	//没有判断是否召唤成功，故如果没成功召唤顺序就会乱掉
	int newHero = heroRank % 10 - 1;   //此处更改
	if(newHero >= 0 && newHero < 4) console->chooseHero(HERO_NAME[newHero]);
	else
	{
		newHero = rand() % 4;
		console->chooseHero(HERO_NAME[newHero]);
	}
	heroRank /= 10;
}

void AIController::action()
{
	vector<Strategy*> allStrategy;
	vector<AIHero*> AIHeroList;
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
//	for(int i = 0; i < enemyHeros.size(); ++i)
//		for(int j = 0; j < myHeros.size(); ++j)
//			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));    //此处更改

	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));     //此处更改
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < enemyHeros.size(); ++j)
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
	//for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new GoBackHome(myHeros[i]));   //此处是否能添加返回战场策略

	for(int i = 0; i < myHeros.size(); ++i) allStrategy.push_back(new CallBackHome(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
		for(int j = 0; j < MINE_NUM; ++j)
			allStrategy.push_back(new GoMining(myHeros[i],MINE_POS[j]));
	for(int i = 0; i < allStrategy.size(); ++i)         //英雄列表
		allStrategy[i]->setAIHeroList(AIHeroList);
	for(int i = 0; i < allStrategy.size(); ++i)         //所有策略
		allStrategy[i]->setConsole(console);
	for(int i = 0; i < allStrategy.size(); ++i)
		for(int j = 0; j < AIHeroList.size(); ++j)      //英雄对应策略
			AIHeroList[j]->setStrategy(allStrategy[i]);
	for(int i = 0; i < AIHeroList.size(); ++i)
		AIHeroList[i]->action();
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;       //无新策略
	if(newStrategy->getWorker() != this->mHero) return false;    //新策略不是我方英雄
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}                                          //应用新策略
	else
		delete newStrategy;
	return false;
}

void AIHero::action()                          //实行新策略
{
	mStrategy->work();
}

int Attack::countWorth()                      //计算价值
{
	this->worth = 0;
	if(target->findBuff("Reviving") != NULL)        //英雄已死
		this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos) <= supportRange)     //目标距离合适
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange ), "a");
		this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;   //计算价值的方法
		if(dis2(worker->pos,target->pos) > worker->range)      //超出距离
			this->worth -= outOfRangeArg;       
		if(target->isWild()) this->worth -= monsterAvoid;      //避免野怪
	}
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

/*int Support1::countWorth()
{
	this->worth = 0;
	if(dis2(worker->pos,target->pos > supportRange))
		this->worth = strategyDisabled;
	else if(dis2(worker->pos,target->pos <= supportRange))
	{
		UnitFilter filter;
		filter.setAreaFilter (new Circle (target->pos, supportRange), "a");
		if(dis2(worker->pos,target->pos) > worker->range)      //超出距离       
		this->worth += attackArg;
		if(target->isWild()) this->worth -= monsterAvoid; 
	}
	return this->worth;
}

void Support1::work()
{
	console->selectUnit(worker);
	console->move(target);
}*/

int UseSkill::countWorth()
{
	this->worth = 0;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();   //获得技能列表
	for(int i = 0; i < skillList.size(); ++i)        
		if(isActiveSkill(skillList[i]))                 //先判断是否为主动技
		{
			if(!worker->canUseSkill(skillList[i]))      //再判断当前对象是否可用
				this->worth = strategyDisabled;
			else
			{
				//此处写对技能的处理，由于样例ai故非常简略
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(target->findBuff("Reviving") != NULL)    //目标已死
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)   //距离合适
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg;
						if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)   //距离大于重锤打击距离
							this->worth -= outOfRangeArg;                        //距离过大
						if(target->findBuff("Dizzy") != NULL)                    //目标已眩晕
							this->worth -= hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "Sacrifice"))                //绝命一击
				{
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)attackArg * 2;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
					}
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))
				{
					//if(target->findBuff("Reviving") != NULL)                   //此处更改
					//	this->worth = strategyDisabled;
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 2 * attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)    
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
				}
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

int Tempt::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void Tempt::work()
{
}

int GoMining::countWorth()
{
	this->worth = miningArg;
	if(target == MINE_POS[0])
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			if(AIHeroList[i]->getStrategy() != NULL)
				if(AIHeroList[i]->getStrategy()->getName() == "GoMining")
				{
					GoMining* otherMining = (GoMining*)AIHeroList[i]->getStrategy();
					if(otherMining->getTarget() == this->target)
						this->worth -= sameMineArg;
				}
	}
	this->worth -= dis(worker->pos, target);
	if(target == MINE_POS[0])
		this->worth += centerMineArg;
	return this->worth;
}

void GoMining::work()
{
	console->selectUnit(worker);
	console->move(MINE_POS[0]);
//	console->move(target);
}

/*int GoBackBattle::countWorth()
{
	this->worth = 0;								//otherMining->getTarget() == this->target
	if(worker->hp >= goBackBattleHp)//if(dis2(worker->pos, target->pos) > worker->view)  this->worth
		this->worth += goBackBattleArg;
	return this->worth;
}

void GoBackBattle::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(MINE_POS[0]);
}*/

/*int GoBackHome::countWorth()
{
	this->worth = 0;
	if(worker->hp <= goBackHomeHp && strcmp(worker->name, "Berserker") != 0) this->worth += goBackHomeArg;
	return this->worth;
}

void GoBackHome::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(console->getMilitaryBase()->pos);
}*/

int CallBackHome::countWorth()
{
	this->worth = 0;
	return this->worth;
}

void CallBackHome::work()
{
	console->callBackHero(worker);
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController controller(map,info,cmd);
	if(info.round == 0)                                      //nownow
	{
		for(int i = 1; i <= 4; ++i)
			controller.buyNewHero();
		return;
	}
	if(newHeroFirst)
	{
		controller.levelupHero();
		controller.buyNewHero();
	}
	else
	{
		controller.levelupHero();
		controller.buyNewHero();	
	}
	controller.action();
}
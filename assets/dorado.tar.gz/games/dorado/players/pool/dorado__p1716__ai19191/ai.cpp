#include "console.h"
#include <vector>
using namespace std;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Ranksxy = 0;
Console* console;

//========估价函数部分========

//威胁计算
const float Threat_HP = 3.0;
const float Threat_MP = 1.0;
const float Threat_Att = 6.0;
const float Threat_Deft = 5.0;
const float Threat_Dist = 20.0;

//威胁指数
float ThreatPoint(PUnit* ptr)
{
    return (ptr->hp * Threat_HP + ptr->mp * Threat_MP + ptr->atk * Threat_Att + ptr->def * Threat_Deft);
}


//基地威胁指数
float BaseThreatPoint(PUnit* ptr , Pos Basepos)
{
    return (Threat_Dist / dis(ptr->pos , Basepos) + ThreatPoint(ptr));
}

//攻击指数
float EasyAttackPoint(PUnit* ptr)
{
    return (ptr->hp * Threat_HP + ptr->def * Threat_Deft);
}


//========实现部分（尚未OOP化）========


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map , info , cmd); //初始化控制台
	console->chooseHero(HERO_NAME[Ranksxy % 4]); //依次选择英雄
	++ Ranksxy;
	vector<PUnit*> myUnits = console->friendlyUnits(); //获取所有己方单位
	if(info.round > 4)
    {
        if ((rand() % 2) || (myUnits.size() >= 7))
        {
            console->buyHeroLevel(myUnits[Ranksxy % myUnits.size()]);
            ++ Ranksxy;
        }
        else
        {
            console->chooseHero(HERO_NAME[Ranksxy % 4]); //依次选择英雄
            ++ Ranksxy;
        }
    }

    Pos gravity = MINE_POS[0];
    //if (info.round > 400)
    //{
    //    gravity = MILITARY_BASE_POS[1 - info.player];
    //}


	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
		{
			console->selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console->enemyUnits (filter); //进行筛选
			if(enemy.size() == 0) //如果没有发现敌人
				console->move(gravity); //则去采集中央金矿
			else
            {
                int Weakest = 0 , Strongest = 0;
                for (int j = 1; j < enemy.size(); j++)
                {
                    if (EasyAttackPoint(enemy[Weakest]) > EasyAttackPoint(enemy[j]))
                        Weakest = j;
                    if (EasyAttackPoint(enemy[Strongest]) < EasyAttackPoint(enemy[j]))
                        Strongest = j;
                }
                console->attack(enemy[Weakest]);
                //对Strongest使用技能
                if (myUnits[i]->canUseSkill("HammerAttack"))
                    console->useSkill("HammerAttack" , enemy[Strongest]->pos);
            }
		}
	}

	delete console;
}
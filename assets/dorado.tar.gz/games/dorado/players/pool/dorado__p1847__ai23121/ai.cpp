//
//  main.cpp
//  simplist
//
//  Created by ZouXu on 2016/4/3.
//  Copyright © 2016年 ZouXu. All rights reserved.
//

#include <iostream>
#include "console.h"
#include <vector>
#include "sdk.h"
#include<ctime>
#include<cmath>
#include<string.h>
int eigen[50];
int havenum[7];
int nowhero;
int dayestatus[50];
int qinding[50];
const Pos EMPTYPOS = Pos();
Pos DEFAULFPOS=Pos(73, 76);
const Pos zpos=Pos(15,11);
Pos sugpos[]={Pos(32,58),Pos(31,90),Pos(117,58),Pos(117,92)};
const int debugmode=0;
int base_id;
int isdamed[50];
Pos origin_pos[50];
int dangerousblock[151][151];
int dangerousblock2[151][151];
bool dangerb,dangerb2;
int defaultbfs[151][151];
int maph[151][151];
int mapbl[151][151];
int mapar[151][151][2];
int mapbfs[151][151];
int blocked[151][151];
int status[50];
int expectedhp[50];
int cannotstay[151][151];
int escape[50];
int canmine[151][151];
int atkvalue[151][151];
int defvalue[151][151];
int hurtvalue[151][151];
int herobfs[8][151][151];
int hasaim[100];
int twindanger[2];
int nowcolleague[8];
int moved[50];
int enemyrev[8];
int distotw[2][151][151];
int ambushtw;
Pos basepos,enbasepos;
Pos aim[50];
int basebfs[151][151];
int insight[3][151][151];
int minevalue[2][7];
int enemygold;
int enemyeyeplace[40][2];
int wilmove[50];
using namespace std;
vector<PUnit> monster;
vector<PUnit> enemyunit;
vector<int> myunit;
int nodamage[151][151];
bool minecontrol;
struct mine
{
    Pos pos,suggestpos;
    int id,value,lastsee,havegold,monp,energy,prob,enemyvalue,animalvalue;
};
struct mon
{
    Pos pos,base_pos;
    int id,typeId,protectnum,aim,lastsee,hp,range,atk,def,cd,speed,atk_speed,max_hp,rev_time;
    int anger[100];
};
struct my
{
    Pos aim;
    int status,aim_id;//0 走路 1 寻死 2 撤退 3 战斗 4 追击 5 采矿 6 拉野 7 打野  8 SACRIFICE to Defend
};
my myu[40];
struct enemy
{
    Pos pos;
    int id,typeId,hp,mp,range,atk,def,speed,atk_speed,skill_num,skill_cd,rev_time,lvl,lastsee,lastatk,cd;
    
};
mon mons[6];
mine gold[7];
vector<enemy> enemyu;
PPlayerInfo info2;

void findUnitInArea(PPlayerInfo w,Pos _, int _range, vector<const PUnit*> &_unitList)
{
    int _sz = w.units.size(); _unitList.clear();
    for (int i=0; i<_sz; ++i)
        if (dis2(w.units[i].pos, _) <= _range)
            _unitList.push_back(&w.units[i]);
}
/*void calcuresult(Operation op)
 {
 int i,j;
 
 if (op.type=="HammerAttack")
 {
 for (i=0;i<enemyunit.size();i++)
 if (dis2(op.targets[0],enemyunit[i]].pos)==0)
 {
 PBuff buff("Dizzy");
 buff.timeLeft=4;
 enemyunit[i]].buffs.push_back(buff);
 enemyunit[i]].hp-=80+;
 }
 }
 }*/
bool willmove(PUnit a)
{
    
    int i,j;
    for (i=0;i<info2.units.size();i++)
        if (dis2(info2.units[i].pos,a.pos)<=36)
            if (info2.units[i].camp!=a.camp)
            {
                if (dis2(a.pos,info2.units[i].pos)<=a.range&&a.skills[0].cd==0)
                    return false;
                for (j=0;j<a.skills.size();j++)
                {
                    PSkill u=a.skills[j];
                    if (dis2(a.pos,info2.units[i].pos)<=36&&u.cd==0&&u.typeId==8&&a.mp>=100)
                        return false;
                }
            }
    return true;
}
void findUnitById(PPlayerInfo w,int id, vector<const PUnit*> &_unitList)
{
    int _sz = w.units.size(); _unitList.clear();
    for (int i=0; i<_sz; ++i)
        if (w.units[i].id == id)
            _unitList.push_back(&w.units[i]);
}
void daye(PUnit j,mon k)
{
    if (k.anger[j.id]==0)
    {
        if (j.typeId==5)
        {
            
        }
    }
}
void sight()//calculate nowsight & enemy sight
{
    int k2=myunit.size();
    for (int i=0;i<k2;i++)
    {
        PUnit u=info2.units[myunit[i]];
        if (!u.findBuff("Reviving"))
        {
            int j,k,w;
            int x,y;
            x=u.pos.x;
            y=u.pos.y;
            w=12;
            if (u.view==400) w=20;
            for (j=x-w;j<x+w+1;j++)
                if (j>=0&&j<150)
                    for (k=y-w;k<y+w+1;k++)
                        if (k>=0&&k<150)
                            if ((k-y)*(k-y)+(j-x)*(j-x)<=info2.units[myunit[i]].view)
                                if (maph[j][k]-maph[x][y]<=1)
                                {
                                    insight[0][j][k]=info2.round;// 更新此点最新看到的时间
                                }
        }
    }
    k2=enemyunit.size();//使用exp作为敌人是否在我方视野的依据
    for (int i=0;i<k2;i++)
    {
        PUnit u=enemyunit[i];
        if (!u.findBuff("Reviving"))
            if (u.hp>0)
                if (u.exp==info2.round||u.view==400)
                {
                    int j,k,w;
                    int x,y;
                    x=u.pos.x;
                    y=u.pos.y;
                    w=12;
                    if (u.view==400) w=20;
                    for (j=x-w;j<x+w+1;j++)
                        if (j>=0&&j<150)
                            for (k=y-w;k<y+w+1;k++)
                                if (k>=0&&k<150)
                                    if ((j-x)*(j-x)+(k-y)*(k-y)<=enemyunit[i].view)
                                        if (maph[j][k]-maph[x][y]<=1)
                                        {
                                            insight[1][j][k]=info2.round;// 更新此点最新被敌人看到的时间
                                        }
                }
    }
    k2=6;
    for (int i=0;i<k2;i++)
    {
        mon u=mons[i];
        if (u.rev_time==0)
            if (u.lastsee==info2.round)
            {
                int j,k,w;
                int x,y;
                x=u.pos.x;
                y=u.pos.y;
                w=12;
                for (j=x-w;j<x+w+1;j++)
                    if (j>=0&&j<150)
                        for (k=y-w;k<y+w+1;k++)
                            if (k>=0&&k<150)
                                if ((k-y)*(k-y)+(j-x)*(j-x)<=144)
                                    if (maph[j][k]-maph[x][y]<=1)
                                    {
                                        insight[2][j][k]=info2.round;// 更新此点最新被怪兽看到的时间
                                    }
            }
    }
    for (int i=0;i<150;i++)
        for (int j=0;j<150;j++)
            if (canmine[i][j]!=0) insight[2][i][j]=info2.round;
    
    //更新仇恨
    
}
void angerevalu()
{
    int i;
    for (i=0;i<info2.units.size();i++)
        if (canmine[info2.units[i].pos.x][info2.units[i].pos.y]>1)
        {
            mons[canmine[info2.units[i].pos.x][info2.units[i].pos.y]-2].anger[info2.units[i].id]+=5;
        }
    for (i=0;i<info2.units.size();i++)
        if (info2.units[i].camp==2&&info2.units[i].max_hp<5000)
        {
            int sp=-1;
            for (int k=0;k<6;k++)
                if (mons[k].id==info2.units[i].id) sp=k;
            int maxanger=5;
            if (sp!=-1)
            for (int k=0;k<50;k++)
                if (mons[sp].anger[k]>maxanger) maxanger=mons[sp].anger[k];
            if (sp!=-1)
                for(int j = 0; j < info2.units.size(); j++)
                {
                    if(info2.units[j].id < info2.units[i]["LastHit"]->val.size() && info2.units[i]["LastHit"]->val[info2.units[j].id]==info2.round-1)
                        mons[sp].anger[info2.units[j].id] += 10;
                    if (info2.units[j].isHero())
                   if (info2.units[i].id<info2.units[j]["LastHit"]->val.size())
                    if (info2.units[j]["LastHit"]->val[info2.units[i].id]==info2.round-1)
                        if (mons[sp].anger[info2.units[j].id] <maxanger)
                                   mons[sp].anger[info2.units[j].id] = 5+maxanger;
                }
        }
    int sk[6];
    memset(sk,0,sizeof(sk));
    for (int k=0;k<6;k++)
        for (i=0;i<info2.units.size();i++)
            if (insight[2][info2.units[i].pos.x][info2.units[i].pos.y]==info2.round)
                if (mons[k].anger[info2.units[i].id]>0)
                {
                    sk[k]+=1;
                }
    for (int k=0;k<6;k++)
        if (sk[k]==0)
            for (i=0;i<50;i++)
                mons[k].anger[i]=0;
}
int calcusightvalue(Pos i,int range)
{
    int w,ww;
    double value;
    Pos k;
    value=0;
    for (w=-20;w<21;w++)
        for (ww=-20;ww<21;ww++)
            if (i.x+w>=0&&i.x+w<=149&&i.y+ww>=0&&i.y+ww<=149)
                if (w*w+ww*ww<=range)
                    if (maph[i.x+w][i.y+ww]-maph[i.x][i.y]<2)
                    {
                        k.x=i.x+w;
                        k.y=i.y+ww;
                        value+=1-exp(-0.2*(info2.round-insight[0][k.x][k.y]));
                        if (canmine[k.x][k.y]>0)
                            value+=0.5*(1-exp(-0.2*(info2.round-insight[0][k.x][k.y])));
                        
                    }
    for (w=0;w<7;w++)
        if (dis2(gold[w].pos,i)<=range+2*sqrt(range)+1)
            value+=12*(1-exp(-0.2*(info2.round-gold[w].lastsee)));
    return int(value);
}
/*int calcuatkvalue(Pos a)
 {
 int ll;
 if (mons[i].rev_time==0)
 return ll;
 }
 int calcudefvalue(Pos a)
 {
 int ml;
 if (
 return ml;
 }*/
bool checkifpass(Pos a,Pos b)
{
    if (a.x<0||b.x<0||a.y<0||b.y<0) return false;
    if (a.x>150||b.x>150||a.y>150||b.y>150) return false;
    if (dis2(a,b)>1) return false;
    if (maph[a.x][a.y]-maph[b.x][b.y]>1||maph[b.x][b.y]-maph[a.x][a.y]>1) return false;
    if (mapbl[b.x][b.y]>0) return false;
    if (minecontrol&&canmine[b.x][b.y]>1)
        if (mons[canmine[b.x][b.y]-2].rev_time==0&&dis2(mons[canmine[b.x][b.y]-2].pos,mons[canmine[b.x][b.y]-2].base_pos)<121)
            return false;
    if (dangerb&&dangerousblock[b.x][b.y]>0)
        return false;
    if (dangerb2&&dangerousblock2[b.x][b.y]>0)
        return false;
    return true;
}
bool calcuroute(Pos a,Pos b,std::vector<Pos>&path)
{
    path.clear();
    if (a.x==b.x&&a.y==b.y) return false;
    int i,j,z;
    i=a.x;j=a.y;
    double k,l,p,r,q,q2;
    k=a.x+0.5;l=a.y+0.5;
    Pos w,w2,w3;
    p=b.x+0.5;r=b.y+0.5;
    if (a.x<b.x)
        for (i=a.x+1;i<=b.x;i++)
        {
            q=(r-l)/(p-k)*(i-k)+l;
            q2=(r-l)/(p-k)*(i-k+1)+l;
            if (b.y>a.y)
            {
                q+=0.00002;
                z=floor(q);
                w.x=i-1;w.y=z-1;
                w2.x=i-1;w2.y=z;
                w3.x=i;w3.y=z;
                if (((!checkifpass(w,w2))||(!checkifpass(w2,w3)))&&(q-z<0.00004)) z-=1;
            }
            if (b.y<a.y)
            {
                q-=0.00002;
                z=ceil(q);
                w.x=i-1;w.y=z;
                w2.x=i-1;w2.y=z-1;
                w3.x=i;w3.y=z-1;
                if (((!checkifpass(w,w2))||(!checkifpass(w2,w3)))&&z-q<0.00004) z+=1;
                z-=1;
            }
            while ((j<z&&b.y>a.y)||(j>z&&b.y<a.y))
            {
                w.x=i-1;w.y=j;
                w2.x=i-1;w2.y=j+1;
                if (b.y<a.y) w2.y=j-1;
                if (!checkifpass(w,w2)) return false;
                path.push_back(w2);
                j=w2.y;
            }
            w.x=i-1;w.y=j;
            w2.x=i;w2.y=j;
            if (!checkifpass(w,w2)) return false;
            path.push_back(w2);
            
        }
    if (a.x>b.x)
    {
        for (i=a.x;i>=b.x+1;i-=1)
        {
            q=(r-l)/(p-k)*(i-k)+l;
            if (b.y>a.y)
            {
                q+=0.00002;
                z=floor(q);
                w.x=i;w.y=z-1;
                w2.x=i;w2.y=z;
                w3.x=i-1;w3.y=z;
                if (((!checkifpass(w,w2))||(!checkifpass(w2,w3)))&&(q-z<0.00004)) z-=1;
            }
            if (b.y<a.y)
            {
                q-=0.00002;
                z=ceil(q);
                w.x=i;w.y=z;
                w2.x=i;w2.y=z-1;
                w3.x=i-1;w3.y=z-1;
                if (((!checkifpass(w,w2))||(!checkifpass(w2,w3)))&&(ceil(q)-q<0.00004)) z+=1;
                z-=1;
            }
            while ((j<z&&b.y>a.y)||(j>z&&b.y<a.y))
            {
                w.x=i;w.y=j;
                w2.x=i;w2.y=j+1;
                if (b.y<a.y) w2.y=j-1;
                if (!checkifpass(w,w2)) return false;
                path.push_back(w2);
                j=w2.y;
            }
            w.x=i;w.y=j;
            w2.x=i-1;w2.y=j;
            if (!checkifpass(w,w2)) return false;
            path.push_back(w2);
        }
    }
    while (j!=b.y)
    {
        w.x=b.x;w.y=j;
        w2.x=b.x;w2.y=j+1;
        if (b.y<j) w2.y=j-1;
        if (!checkifpass(w,w2)) return false;
        path.push_back(w2);
        j=w2.y;
    }
    return true;
}
void calcumayarrive(int speed, Pos po)
{
    memset(mapar,0,sizeof(mapar));
    
    
    Pos point[150];
    double dis[150][150];
    int t,i,j;
    if (canmine[po.x][po.y]>1)
        minecontrol=false;
    t=0;
    point[0]=po;
    for (i=-6;i<=6;i++)
        for (j=-6;j<=6;j++)
            if (po.x+i>=0&&po.x+i<150&&po.y+j>=0&&po.y+j<150)
                if (i*i+j*j<=speed)
                    if (i*i+j*j!=0)
                        if (mapbl[po.x+i][po.y+j]<=0)
                        {
                            t++;
                            point[t]=po;
                            point[t].x+=i;point[t].y+=j;
                        }
    int w,rr;
    for (i=0;i<=t;i++)
        for (j=0;j<=t;j++)
            dis[i][j]=10000;
    
    std::vector<Pos> b2;
    for (i=1;i<=t;i++)
        if (calcuroute(point[0],point[i],b2))
            dis[0][i]=sqrt(dis2(point[0],point[i]));
    
    int isinqueue[150];
    int queue[10000];
    double nowsum=0;
    memset(isinqueue,0,sizeof(isinqueue));
    memset(queue,0,sizeof(queue));
    int p;
    p=0;
    for (i=1;i<=t;i++)
        if (dis[0][i]<100)
        {
            p++;
            isinqueue[i]=1;
            queue[1999+p]=i;
            nowsum+=dis[0][i];
            mapar[point[i].x][point[i].y][0]=po.x;
            mapar[point[i].x][point[i].y][1]=po.y;
        }
    int now=2000;
    int end;
    end=1999+p;
    while (now<=end)
    {
        while ((dis[0][queue[now]]>nowsum/(end+1-now)+0.01)&&(now<9000))
        {
            end++;queue[end]=queue[now];
            now++;
        }
        while (queue[now]==0) now++;
        int sk,set;
        sk=-1;set=-10;
        for (i=1;i<=t;i++)
            if(i!=queue[now])
                if (dis[0][queue[now]]+sqrt(dis2(point[queue[now]],point[i]))<sqrt(speed)+0.00001)
                    if (dis[0][queue[now]]+sqrt(dis2(point[queue[now]],point[i]))<dis[0][i]-0.00001)
                        if (dis[queue[now]][i]>-0.001)
                        {
                            if ((dis[queue[now]][i]>0.00001&&dis[queue[now]][i]<10)||calcuroute(point[queue[now]],point[i],b2))
                            {
                                dis[queue[now]][i]=sqrt(dis2(point[queue[now]],point[i]));
                                if (isinqueue[i]) nowsum-=dis[0][i];
                                dis[0][i]=sqrt(dis2(point[queue[now]],point[i]))+dis[0][queue[now]];
                                mapar[point[i].x][point[i].y][0]=point[queue[now]].x;
                                mapar[point[i].x][point[i].y][1]=point[queue[now]].y;
                                nowsum+=dis[0][i];
                                if (!isinqueue[i])
                                {
                                    
                                    isinqueue[i]=1;
                                    if (dis[0][i]<dis[0][queue[now+1]])
                                    {
                                        sk+=1;if (sk!=0) queue[now-sk]=i;
                                        if (sk==0) set=i;
                                    }
                                    if (dis[0][i]>=dis[0][queue[now+1]])
                                    {
                                        end++;queue[end]=i;
                                    }
                                }
                                
                            }
                            else
                                dis[queue[now]][i]=-1;
                        }
        isinqueue[queue[now]]=0;
        nowsum-=dis[0][queue[now]];
        if (set>0) queue[now]=set;
        now-=sk;
    }
    
}
void findbfsdis(Pos w)
{
    memset(mapbfs,0,sizeof(mapbfs));
    int queue[25000][3];
    int isinqueue[151][151];
    memset(queue,0,sizeof(queue));
    memset(isinqueue,0,sizeof(isinqueue));
    isinqueue[w.x][w.y]=1;
    int now,end;
    now=0;end=0;
    queue[0][0]=w.x;queue[0][1]=w.y;queue[0][2]=0;
    int i,j,k;
    mapbl[w.x][w.y]-=1;
    for (k=0;k<7;k++)
        if (dis2(gold[k].pos,w)==0)
            for (i=-1;i<2;i++)
                for (j=-1;j<2;j++)
                    if(w.x+i>=0&&w.x+i<=149&&w.y+j>=0&&w.y+j<=149&&i*i+j*j<=1)
                        if (dis2(Pos(w.x+i,w.y+j),enbasepos)>144)
                            mapbl[w.x+i][w.y+j]-=1;
    while (now<=end)
    {
        Pos z,z2;
        mapbfs[queue[now][0]][queue[now][1]]=queue[now][2];
        z.x=queue[now][0];
        z.y=queue[now][1];
        z2=z;
        z.x-=1;
        if (z.x>=0)
            if (isinqueue[z.x][z.y]==0)
                if (checkifpass(z2,z))
                {
                    end++;
                    queue[end][0]=queue[now][0]-1;
                    queue[end][1]=queue[now][1];
                    queue[end][2]=queue[now][2]+1;
                    isinqueue[queue[now][0]-1][queue[now][1]]=1;
                }
        z.x+=2;
        if (z.x<=149)
            if (isinqueue[z.x][z.y]==0)
                if (checkifpass(z2,z))
                {
                    end++;
                    queue[end][0]=queue[now][0]+1;
                    queue[end][1]=queue[now][1];
                    queue[end][2]=queue[now][2]+1;
                    isinqueue[queue[now][0]+1][queue[now][1]]=1;
                }
        z.x-=1;z.y-=1;
        if (z.y>=0)
            if (isinqueue[z.x][z.y]==0)
                if (checkifpass(z2,z))
                {
                    end++;
                    queue[end][0]=queue[now][0];
                    queue[end][1]=queue[now][1]-1;
                    queue[end][2]=queue[now][2]+1;
                    isinqueue[queue[now][0]][queue[now][1]-1]=1;
                }
        z.y+=2;
        if (z.y<=149)
            if (isinqueue[z.x][z.y]==0)
                if (checkifpass(z2,z))
                {
                    end++;
                    queue[end][0]=z.x;
                    queue[end][1]=z.y;
                    queue[end][2]=queue[now][2]+1;
                    isinqueue[z.x][z.y]=1;
                }
        now+=1;
    }
    for (k=0;k<7;k++)
        if (dis2(gold[k].pos,w)==0)
            for (i=-1;i<2;i++)
                for (j=-1;j<2;j++)
                    if (w.x+i>=0&&w.x+i<=149&&w.y+j>=0&&w.y+j<=149)
                        if (i*i+j*j<=1)
                            if (dis2(Pos(w.x+i,w.y+j),enbasepos)>144)
                                mapbl[w.x+i][w.y+j]+=1;
    mapbl[w.x][w.y]+=1;
}
void routeca(Pos a,Pos b,std::vector<Pos>&_path)
{
    std::vector<Pos> stl1;
    std::vector<Pos> stl2;
    stl1.clear();
    stl2.clear();
    _path.clear();
    _path.push_back(a);
    if (a.x==b.x&&a.y==b.y) return;
    stl2.push_back(b);
    while (stl2[stl2.size()-1].x!=a.x||stl2[stl2.size()-1].y!=a.y)
    {
        Pos z;
        z.x=mapar[stl2[stl2.size()-1].x][stl2[stl2.size()-1].y][0];
        z.y=mapar[stl2[stl2.size()-1].x][stl2[stl2.size()-1].y][1];
        stl2.push_back(z);
    }
    int i;
    for (i=stl2.size()-1;i>0;i-=1)
    {
        Pos w,w2;
        w=stl2[i];w2=stl2[i-1];
        stl1.clear();
        calcuroute(w,w2,stl1);
        for (int j=0;j<stl1.size();j++)
            _path.push_back(stl1[j]);
    }
}
void findroutine(Pos a,Pos b,int speed,std::vector<Pos> &cd)
{
    cd.clear();
    if (b.x>=150||b.x<0||b.y>=150||b.y<0) { cout<<"isudfhsi";return;}
    if (b.x==a.x&&b.y==a.y) {cd.push_back(a);return;}
    mapbl[a.x][a.y]=0;
    findbfsdis(b);
    if (mapbfs[a.x][a.y]==0) {cd.push_back(a);return;}
    calcumayarrive(speed,a);
    if (mapar[b.x][b.y][0]+mapar[b.x][b.y][1]>0)
    {
        routeca(a,b,cd);
        return;
    }
    Pos t,t2;
    t=a;
    int nowdis;
    nowdis=100000;
    int i,j;
    int max=1000000;
    for (i=-6;i<=6;i++)
        for (j=-6;j<=6;j++)
            if (a.x+i>=0&&a.x+i<150&&a.y+j>=0&&a.y+j<150)
                if (i*i+j*j<=speed)
                    if (i*i+j*j!=0)
                    {
                        Pos w;
                        w=a;
                        w.x+=i;
                        w.y+=j;
                        if (mapar[w.x][w.y][0]+mapar[w.x][w.y][1]>0)
                        {
                            if (mapbfs[w.x][w.y]-defvalue[w.x][w.y]<max)
                            {
                                max=mapbfs[w.x][w.y]-defvalue[w.x][w.y];
                                t=w;
                                nowdis=dis2(w,b);
                            }
                            if ((mapbfs[w.x][w.y]-defvalue[w.x][w.y]==max)&&(dis2(w,b)<nowdis))
                            {
                                max=mapbfs[w.x][w.y]-defvalue[w.x][w.y];
                                t=w;
                                nowdis=dis2(w,b);
                            }
                        }
                    }
    routeca(a,t,cd);
    if (t.x==a.x&&t.y==a.y)
        mapbl[a.x][a.y]=1;
    if (dis2(a,enbasepos)<=144) mapbl[a.x][a.y]=1;
}
int calcumaydamage(Pos i)
{
    int j,w,dam,k;
    dam=0;
    for (j=0;j<info2.units.size();j++)
        if (info2.units[j].player==1-info2.player)
            if (info2.units[j].isHero())
                if (!info2.units[j].findBuff("Dizzy"))
                    if (!info2.units[j].findBuff("Reviving"))
                        if (!info2.units[j].findBuff("WaitRevive"))
                            for (w=0;w<info2.units[j].skills.size();w++)
                            {
                                const PSkill *ptr=&info2.units[j].skills[w];
                                if (ptr->typeId==0)
                                    if (ptr->cd==0)
                                        if (info2.units[j].range>=dis2(info2.units[j].pos,i))
                                        {
                                            dam+=info2.units[j].atk;
                                        }
                                
                                if (ptr->typeId==8)
                                    if (info2.units[j].mp>=100)
                                        if (ptr->cd==0)
                                            if (36>=dis2(info2.units[j].pos,i))
                                                dam+=80+30*ptr->level;
                            }
    return dam;
}
int calcucandamage(Pos i)
{
    
    int j,w,dam,k;
    dam=0;
    for (j=0;j<info2.units.size();j++)
        if (info2.units[j].player==info2.player)
            if (info2.units[j].isHero())
                if (!info2.units[j].findBuff("Dizzy"))
                    if (!info2.units[j].findBuff("Reviving"))
                        if (!info2.units[j].findBuff("WaitRevive"))
                            for (w=0;w<info2.units[j].skills.size();w++)
                            {
                                const PSkill *ptr=&info2.units[j].skills[w];
                                if (ptr->typeId==0)
                                    if (ptr->cd==0)
                                        if (info2.units[j].range>=dis2(info2.units[j].pos,i))
                                        {
                                            dam+=info2.units[j].atk;
                                        }
                                
                                if (ptr->typeId==8)
                                    if (info2.units[j].mp>=100)
                                        if (ptr->cd==0)
                                            if (36>=dis2(info2.units[j].pos,i))
                                                dam+=80+30*ptr->level;
                            }
    return dam;
}
int calcumtdamage(Pos i,int hpc)
{
    int j,w,dam,k;
    dam=0;
    for (j=0;j<info2.units.size();j++)
        if (info2.units[j].player==1-info2.player)
            if (info2.units[j].isHero())
                if (!info2.units[j].findBuff("Dizzy"))
                    if (!info2.units[j].findBuff("Reviving"))
                        if (!info2.units[j].findBuff("WaitRevive"))
                            for (w=0;w<info2.units[j].skills.size();w++)
                            {
                                const PSkill *ptr=&info2.units[j].skills[w];
                                if (ptr->typeId==0)
                                    if (ptr->cd==0)
                                        if (info2.units[j].range>=dis2(info2.units[j].pos,i))
                                        {
                                            int rank=0;
                                            for (k=0;k<info2.units.size();k++)
                                                if (info2.units[k].player==info2.player)
                                                    if (info2.units[k].isHero())
                                                        if (info2.units[j].range>=dis2(info2.units[j].pos,info2.units[k].pos))
                                                            if (hpc>info2.units[k].hp||info2.units[k].isBase())
                                                                rank++;
                                            if (rank==0)  dam+=info2.units[j].atk;
                                        }
                                
                                if (ptr->typeId==8)
                                    if (info2.units[j].mp>=100)
                                        if (ptr->cd==0)
                                            if (36>=dis2(info2.units[j].pos,i))
                                                if (info2.units[j].range>=dis2(info2.units[j].pos,i))
                                                {
                                                    int rank=0;
                                                    for (k=0;k<info2.units.size();k++)
                                                        if (info2.units[k].player==info2.player)
                                                            if (info2.units[k].isHero())
                                                                if (info2.units[j].range>=dis2(info2.units[j].pos,info2.units[k].pos))
                                                                    if (hpc>info2.units[k].hp)
                                                                        rank++;
                                                    if (rank==0) dam+=80+30*ptr->level;
                                                }
                                
                            }
    return dam;
}
double unitatkvalue(PUnit j)
{
    int i;
    double value;
    value=0;
    value=j.atk*exp(log(j.range)/4)*7;
    if (j.typeId==3||j.typeId==11||j.typeId==12)
    {
        value=value/1.5;
    }
    if (j.typeId==5)
    {
        value=(30+j.level*8)*exp(log(j.range/4))*3.5;
    }
    for (i=0;i<j.skills.size();i++)
    {
        PSkill ptr=j.skills[i];
        if (ptr.typeId==0)
            if (ptr.cd>0)
            {
                value-=j.atk*exp(log(j.range)/4)*ptr.cd/2;
            }
        if (ptr.typeId==8&&ptr.cd==0&&j.mp>=100)
        {
            if (j.camp==1-info2.camp)
                value+=80+30*j.level+9*j.atk;
            else
                value+=80+30*j.level;
        }
        if (ptr.typeId==11&&ptr.cd==0)
        {
            
            value+=j.hp*0.6;
        }
        
    }
    if (j.findBuff("WinOrDie"))
        value+=j.atk*0.9;
    value=value*exp(log(j.speed)/8);
    int multi=0;
    int multi2=0;
    if (j.findBuff("WaitRevive"))
        multi=j.findBuff("WaitRevive")->timeLeft+1;
    if (j.findBuff("Dizzy"))
    {
        multi2=j.findBuff("Dizzy")->timeLeft+1;
        if (multi2>multi) multi=multi2;
    }
    value=value*(1-multi*0.05);
    //if (j.isBase()) return 9000;
    return value;
}
double unitdefvalue(PUnit j)
{
    double value;
    value=0;
    value=j.def*9+j.hp;
    if (j.isHero())
        value=value*exp(log(j.speed)/6);
    int i;
    for (i=0;i<j.skills.size();i++)
    {
        PSkill ptr=j.skills[i];
        
        if (ptr.typeId==8&&ptr.cd==0&&j.mp>=100)
        {
            value+=j.speed;
        }
        if (ptr.typeId==9&&j.mp>=50-ptr.cd*2)
        {
            value+=exp(-ptr.cd*0.3)*130;
        }
        if (ptr.typeId==10)
        {
            value+=5*ptr.level;
        }
        if (ptr.typeId==12&&ptr.cd==0)
        {
            value+=j.hp/8;
        }
    }
    int multi=0;
    int multi2=0;
    if (j.findBuff("WaitRevive"))
        multi=j.findBuff("WaitRevive")->timeLeft+1;
    if (j.findBuff("Dizzy"))
    {
        multi2=j.findBuff("Dizzy")->timeLeft+1;
        if (multi2>multi) multi=multi2;
    }
    value=value*(1-multi*0.05);
    return value;
}
int xt;
int calcuvalue(PUnit j)
{
    int zm=int(unitatkvalue(j)+unitdefvalue(j));
    if (j.findBuff("Reviving")) zm=0;
    if (j.hp<=0&&j.typeId!=5) zm=0;
    // if (j.isBase()) zm+=5000;
    if (xt==0)
        if (dayestatus[j.id]>0) return 0;
    //  cout<<j.id<<' '<<unitatkvalue(j)<<' '<<unitdefvalue(j)<<' '<<zm<<endl;
    return zm;
}

void calcuallvalue(Pos i2,int &myvalue,int &enemyvalue)
{
    int i,k;
    double value,value2;
    value=0;value2=0;
    for (i=0;i<info2.units.size();i++)
    {
        
        PUnit j=info2.units[i];
        if (!j.findBuff("Reviving"))
        {
            double zm=sqrt(dis2(j.pos,i2));
            double zt;
            zt=0;
            if (j.typeId==3||j.typeId==5)
            {
                zt=1-(zm-3)/12;
                if (zm>15) zt=0;
                if (zm<3) zt=1;
                
            }
            if (j.typeId==6||j.typeId==4)
            {
                zt=1-(zm-6)/14;
                if (zm>20) zt=0;
                if (zm<6) zt=1;
            }
            if (j.isBase()&&dis2(i2,basepos)<=144&&j.camp==info2.camp)
            {
                zt=1;
            }
            if (zt>0)
                zm=calcuvalue(j);
            if (j.camp==info2.camp) value+=zm*zt;
            if (j.camp==1-info2.camp) value2+=zm*zt;
        }
    }
    for (i=0;i<enemyunit.size();i++)
        if (enemyunit[i].exp!=info2.round)
        {
            PUnit j=enemyunit[i];
            int zm;
            if (!j.findBuff("Reviving"))
                if (j.hp>0)
                    if (dis2(j.pos,i2)<900)
                    {
                        double zm=sqrt(dis2(j.pos,i2));
                        double zt;
                        zt=0.9-(zm-6)/14*0.75;
                        if (zm>20) zt=0.15;
                        if (zm<6) zt=0.9;
                        zm=calcuvalue(j)*exp(0.05*(j.exp-info2.round));
                        value2+=zt*zm;
                    }
        }
    myvalue=int(value);
    enemyvalue=int(value2);
}
int calcuenvalue(Pos i,int range)
{
    int k;
    double value;
    value=0;
    for (k=0;k<enemyunit.size();k++)
        if (enemyunit[k].isHero())
            if (dis2(enemyunit[k].pos,i)<=range)
            {
                value+=calcuvalue(enemyunit[k])*exp(0.05*(enemyunit[k].exp-info2.round));
                
            }
    return int(value);
}
double calcuatkvalue(Pos i,int range)
{
    //10区格以内准许开启攻击模式
    int k,t;
    double value;
    value=0;
    for (k=0;k<enemyunit.size();k++)
    {
        int pr=dis2(i,enemyunit[k].pos);
        if (pr==0) pr=1;
        if (enemyunit[k].isHero())
            if (!enemyunit[k].findBuff("Reviving"))
                if (enemyunit[k].hp>0)
                    if (dis2(i,enemyunit[k].pos)<=400)
                    {
                        double base=1.8-enemyunit[k].hp/400;
                        double nowvalue=0;
                        if (enemyunit[k].findBuff("Dizzy")||enemyunit[k].findBuff("WaitRevive")) base*=1.5;
                        if (dis2(i,enemyunit[k].pos)<=range)
                        {
                            nowvalue+=1.2*base;
                            if (wilmove[enemyunit[k].id]==0) nowvalue+=base;
                        }
                        if (sqrt(dis2(i,enemyunit[k].pos))+sqrt(enemyunit[k].speed)<=sqrt(range))
                        {
                            nowvalue+=1.8*base;
                            if (wilmove[enemyunit[k].id]==0) nowvalue-=base;
                        }
                        else
                            nowvalue+=base*(1.6-0.5*exp(log(pr)/4)/sqrt(sqrt(range)));
                        nowvalue*=exp(0.25*(enemyunit[k].exp-info2.round));
                        if (nowvalue>0) value+=nowvalue;
                    }
    }
    return value;
}
double calcudefvalue(Pos i)
{
    int j,k;
    double value,multi;
    // value=maph[i.x][i.y]*10;
    for (k=0;k<enemyunit.size();k++)
        if (dis2(i,enemyunit[k].pos)<=400)
        {
            if (enemyunit[k].isHero())
                if (!enemyunit[k].findBuff("Reviving"))
                    if (enemyunit[k].hp>0)
                    {
                        multi=1;
                        if (enemyunit[k].findBuff("Dizzy")) multi=multi*(1-0.23*(enemyunit[k].findBuff("Dizzy")->timeLeft+1));
                        if (enemyunit[k].exp!=info2.round) multi=multi*exp(0.25*(enemyunit[k].exp-info2.round));
                        //  if (enemyunit[k].skills[0].cd==0&&enemyunit[k].typeId<6) multi=multi*0.75;
                        if (enemyunit[k].skills[0].cd==2) multi=multi*0.25;
                        if (!enemyunit[k].findBuff("WaitRevive"))
                        {
                            int pr=dis2(i,enemyunit[k].pos);
                            if (pr==0) pr=1;
                            double nowvalue=-1.6*enemyunit[k].atk;
                            if (dis2(i,enemyunit[k].pos)<=enemyunit[k].range)
                            {
                                nowvalue-=enemyunit[k].atk;
                                if (maph[i.x][i.y]-maph[enemyunit[k].pos.x][enemyunit[k].pos.y]>=2) value+=2*enemyunit[k].atk/3;
                                if (wilmove[enemyunit[k].id]==0) nowvalue-=enemyunit[k].atk*0.8;
                                if (enemyunit[k].typeId==5&&isdamed[enemyunit[k].id]==0)
                                {
                                    for (int mm=0;mm<enemyunit[k].skills.size();mm++)
                                        if (enemyunit[k].skills[mm].typeId==11)
                                            if (enemyunit[k].skills[mm].cd==0)
                                                nowvalue-=enemyunit[k].atk*2;
                                }
                            }
                            
                            if (enemyunit[k].typeId==4)
                                if (enemyunit[k].mp>=100)
                                    
                                {
                                    for (int mm=0;mm<enemyunit[k].skills.size();mm++)
                                        if (enemyunit[k].skills[mm].typeId==8)
                                            if (enemyunit[k].skills[mm].cd==0)
                                            {
                                                if (dis2(i,enemyunit[k].pos)<=36)
                                                    nowvalue-=40+enemyunit[k].level*15;
                                                if (dis2(i,enemyunit[k].pos)<=121)
                                                    nowvalue-=40+enemyunit[k].level*15;
                                                
                                            }
                                    
                                }
                            if (sqrt(dis2(i,enemyunit[k].pos))<=sqrt(enemyunit[k].speed)+sqrt(enemyunit[k].range))
                                if (wilmove[enemyunit[k].id]==1)
                                {
                                    nowvalue-=enemyunit[k].atk;
                                    if (maph[i.x][i.y]-maph[enemyunit[k].pos.x][enemyunit[k].pos.y]>=2) value+=2*enemyunit[k].atk/3;
                                }
                            double nt=0.5*enemyunit[k].atk*exp(log(pr)/4)/sqrt(sqrt(enemyunit[k].range));
                            if (nt<0.4*enemyunit[k].atk) nt=0.4*enemyunit[k].atk;
                            nowvalue+=nt;
                            nowvalue=nowvalue*multi;
                            
                            if (nowvalue<0) value+=nowvalue;
                            
                        }
                    }
        }
    for (k=0;k<info2.units.size();k++)
        if (info2.units[k].camp==info2.camp)
            if (info2.units[k].typeId==4)
                if(dis2(i,info2.units[k].pos)<=121)
                {
                    value+=info2.units[k].level*4;
                }
    if (insight[1][i.x][i.y]==0)
        value*=0.75;
    if (dis2(basepos,i)<=144)
        value*=0.5;
    return value;
}
void calcuposvalue(Pos i,int &atkvalue, int &defvalue,int &sightvalue)
{
    int w1,w2,w3;
    calcuallvalue(i,w1,w2);
    
}
int calcubonusdefvalue(PUnit j,Pos i)
{
    int k,p,pl,p6;
    int allvalue=0;
    if (insight[2][i.x][i.y]!=info2.round) return 0;
    for (k=0;k<info2.units.size();k++)
    {
        if (info2.units[k].camp==2)
            for (p=0;p<6;p++)
                if (info2.units[k].id==mons[p].id)
                    if (!info2.units[k].findBuff("Reviving"))
                        if (insight[2][i.x][i.y])
                        {
                            int nowmax=-1;
                            int nownum=-1;
                            for (pl=0;pl<50;pl++)
                                if (mons[p].anger[pl]>nowmax)
                                {
                                    nowmax=mons[p].anger[pl];
                                    nownum=pl;
                                }
                            if (nownum==j.id)
                            {
                                int sk=0;
                                if (dis2(j.pos,mons[p].pos)<=mons[p].range&&info2.units[k].skills[0].cd==0)//注定被打，MON不会动
                                {
                                    sk=0;
                                }
                                else
                                {
                                    Pos maypos=mons[p].pos;
                                    int tl=0;
                                    if (dis2(j.pos,mons[p].pos)<=mons[p].speed&&(info2.units[k].skills[0].cd>0||dis2(j.pos,mons[p].pos)>mons[p].range))
                                    {
                                        maypos=j.pos;tl=1;
                                    }
                                    if (dis2(maypos,i)<=mons[p].range)
                                    {
                                        sk=mons[p].atk-j.def;
                                        if (tl==0) sk+=(mons[p].atk-j.def)/2;
                                    }
                                    if (tl==0&&sqrt(dis2(maypos,i))<=sqrt(mons[p].range)+3)
                                    {
                                        sk=mons[p].atk-j.def;
                                    }
                                }
                                allvalue+=sk;
                            }
                        }
    }
    return allvalue;
    
}
bool calcumayham(Pos i)
{
    int ii,j;
    for (ii=0;ii<enemyunit.size();ii++)
        if (insight[1][i.x][i.y]==info2.round)
            if (enemyunit[ii].typeId==3)
                if (enemyunit[ii].exp==info2.round)
                    for (j=0;j<enemyunit[ii].skills.size();j++)
                        if (enemyunit[ii].skills[j].typeId==8)
                            if (dis2(i,enemyunit[ii].pos)<=36)
                                if (enemyunit[ii].skills[j].cd==0)
                                    if (enemyunit[ii].mp>=100)
                                        return true;
    return false;
    
}
Pos calcucenter(Pos i)
{
    int j;
    double xsum,ysum,val,valsum;
    xsum=0;ysum=0;valsum=0;
    for (j=0;j<info2.units.size();j++)
        if (info2.units[j].isHero())
            if (dis2(info2.units[j].pos,i)<=256)
            {
                val=calcuvalue(info2.units[j]);
                xsum+=info2.units[j].pos.x*val;
                ysum+=info2.units[j].pos.y*val;
                valsum+=val;
            }
    /*for (j=0;j<enemyunit.size();j++)
     if (enemyunit[j].isHero())
     if (enemyunit[j].exp!=info2.round)
     if (dis2(info2.units[j].pos,i)<=256)
     {
     val=calcuvalue(info2.units[j]);
     xsum+=info2.units[j].pos.x*val;
     ysum+=info2.units[j].pos.y*val;
     valsum+=val;
     }*/
    if (valsum==0) return i;
    return Pos(int(xsum/valsum),int(ysum/valsum));
}
int isdizzed[50];
void fighting(PUnit &j,PCommand &cmd)
{
    xt=0;
    Pos center=calcucenter(j.pos);
    dayestatus[j.id]=0;
    qinding[j.id]=0;
    vector <const PUnit*> st;
    Operation op;
    int min=1000;
    int maxvalue=0;
    Pos tgpos;
    tgpos=DEFAULFPOS;
    int n1,n2,iil;
    iil=0;
    calcuallvalue(center,n1,n2);
    if (n1*3<n2*2||((j.hp<65+10*j.level||j.hp<2*calcumaydamage(origin_pos[j.id]))&&j.atk<100)) status[j.id]=3;
    if (dis2(j.pos,basepos)<=81) status[j.id]=0;
    double p1,p2,p3;
    p1=calcuatkvalue(j.pos,j.range)*j.atk;
    p2=calcudefvalue(j.pos)*(3+j.level)/3;
    p3=calcubonusdefvalue(j,j.pos);
    findUnitInArea(info2,j.pos,225,st);
    int i,w,z;
    for (i=0;i<enemyunit.size();i++)
        if (enemyunit[i].exp==info2.round)
        {
            // if (info2.units[i].isHero())
            if (!enemyunit[i].findBuff("Reviving"))
                if (enemyunit[i].hp>0)
                    for (w=0;w<j.skills.size();w++)
                    {
                        const PSkill* ptr=&j.skills[w];
                        if (j.range>=dis2(j.pos,enemyunit[i].pos))
                            if (ptr->typeId==0)
                                if (ptr->cd==0)
                                {
                                    int value;
                                    value=j.atk-enemyunit[i].def;
                                    if (value<5) value=5;
                                    if (enemyunit[i].hp<value) value=enemyunit[i].hp+250;
                                    else
                                    {
                                        value=value*400/(enemyunit[i].hp+100);
                                        if (status[j.id]>0) value=value/5;
                                    }
                                    value*=0.8+0.1*enemyunit[i].level;
                                    if (enemyunit[i].typeId==5&&isdamed[enemyunit[i].id]==0)
                                    {
                                        for (z=0;z<enemyunit[i].skills.size();z++)
                                        {
                                            if (enemyunit[i].skills[z].cd==0&&enemyunit[i].skills[z].typeId==11) value+=55;
                                        }
                                    }
                                    
                                    if (!enemyunit[i].isHero()) value=5;
                                    if (value>maxvalue)
                                    {
                                        maxvalue=value;
                                        op.type="Attack";
                                        op.targets.clear();
                                        op.targets.push_back(enemyunit[i].pos);
                                    }
                                }
                        if (ptr->typeId==8)
                            if (j.mp>=100)
                                if (enemyunit[i].isHero())
                                    if (ptr->cd==0)
                                        if (36>=dis2(j.pos,enemyunit[i].pos))
                                        {
                                            int value;
                                            value=80+ptr->level*30;
                                            value=value*250/(enemyunit[i].hp+100);
                                            if (status[j.id]>0) value=value/10;
                                            if (enemyunit[i].hp<value) value=enemyunit[i].hp+80;
                                           
                                            value*=0.8+0.1*enemyunit[i].level;
                                            if (enemyunit[i].findBuff("Dizzy")||isdizzed[enemyunit[i].id]==1)
                                                value=value/10;
                                            /* if (enemyunit[i].typeId==5)
                                             for (z=0;z<enemyunit[i].skills.size();z++)
                                             if (enemyunit[i].skills[z].cd==0&&enemyunit[i].skills[z].typeId==11) value*=2;*/
                                            if (!enemyunit[i].isHero()) value=0;
                                            if (value>maxvalue)
                                            {
                                                maxvalue=value;
                                                op.type="HammerAttack";
                                                op.targets.clear();
                                                op.targets.push_back(enemyunit[i].pos);
                                            }
                                            
                                        }
                        if (ptr->typeId==9)
                            if (ptr->cd==0)
                                if (j.mp>=80)
                                {
                                    int i8;
                                    int val=calcumaydamage(origin_pos[j.id]);
                                    if (val<j.hp) val=calcumtdamage(origin_pos[j.id],j.hp);
                                    for (i8=-9;i8<10;i8++)
                                        for (w=-9;w<10;w++)
                                            if (j.pos.x+i8>=0&&j.pos.x+i8<=149&&j.pos.y+w>=0&&j.pos.y+w<=149)
                                                if(defaultbfs[j.pos.x+i8][j.pos.y+w]!=0)
                                                    if (i8*i8+w*w<=81)
                                                        if (mapbl[j.pos.x+i8][j.pos.y+w]==0)
                                                            if (i8*i8+w*w>64)
                                                            {
                                                                
                                                                double i1,i2,i3,i4;
                                                                int iv;
                                                                Pos ww;
                                                                ww.x=j.pos.x+i8;ww.y=j.pos.y+w;
                                                                i1=calcuatkvalue(ww,j.range)*j.atk;
                                                                i2=calcudefvalue(ww)*(3+j.level)/3;
                                                                i4=0;//    i4=calcusightvalue(ww,144);
                                                                i3=(i2-p2+i1-p1+i4/3)/5;
                                                                if (canmine[ww.x][ww.y]>0) i3+=10;
                                                                if (canmine[j.pos.x][j.pos.y]>0) i3-=10;
                                                                if (n1*2<n2||val>=j.hp) i3=(i2-p2)*2;
                                                                if (insight[1][ww.x][ww.y]!=info2.round) i3+=60;
                                                                if (insight[1][j.pos.x][j.pos.y]!=info2.round) i3-=60;
                                                                if (n1>n2*3||(j.hp==j.max_hp&&n1>n2)) i3=(i1-p1)*1.5;
                                                                if (calcumayham(j.pos))i3+=60*n2/n1;
                                                                iv=int(i3/6);
                                                                if (val>=j.hp||(calcumayham(j.pos)&&status[j.id]>0)) {iv+=val+200;}else iv+=val-120;
                                                                
                                                                if (iv>maxvalue)
                                                                {
                                                                    maxvalue=iv;
                                                                    op.type="Blink";
                                                                    op.targets.clear();
                                                                    op.targets.push_back(ww);
                                                                }
                                                            }
                                    
                                    
                                }
                        if (ptr->typeId==11)
                            if (ptr->cd==0)
                                if (calcumtdamage(origin_pos[j.id],j.hp/2)==0)
                                    if (dis2(j.pos,enemyunit[i].pos)<=j.range)
                                    {
                                        int value;
                                        value=j.hp*5;
                                        if (status[j.id]!=0) value=j.hp/2;
                                        if (value>maxvalue)
                                        {
                                            maxvalue=value;
                                            op.type="Sacrifice";
                                            op.targets.clear();
                                            //op.targets.push_back(j.pos);
                                        }
                                        
                                    }
                        if (ptr->typeId==13)
                            if (j.mp>=50)
                                if (ptr->cd==0)
                                {
                                    
                                    int i8;
                                    for (i8=-5;i8<6;i8++)
                                        for (w=-5;w<6;w++)
                                            if (j.pos.x+i8>=0&&j.pos.x+i8<=149&&j.pos.y+w>=0&&j.pos.y+w<=149)
                                                if (i8*i8+w*w<=25)
                                                    if (maph[j.pos.x+i8][j.pos.y+w]-maph[j.pos.x][j.pos.y]<2)
                                                        if (mapbl[j.pos.x+i8][j.pos.y+w]<=0)
                                                        {
                                                            int value;
                                                            
                                                            double i1,i2,i3,i4;
                                                            int iv;
                                                            Pos ww;
                                                            ww.x=j.pos.x+i8;ww.y=j.pos.y+w;
                                                            i4=calcusightvalue(ww,400);
                                                            i3=i4/20-12;
                                                            if (canmine[ww.x][ww.y]==1) i3+=5;
                                                            value=i3;
                                                            if (status[j.id]>0) value=value/5;
                                                            if (value>maxvalue)
                                                            {
                                                                maxvalue=value;
                                                                op.type="SetObserver";
                                                                op.targets.clear();
                                                                op.targets.push_back(ww);
                                                            }
                                                        }
                                }
                        if (enemyunit[i].isHero()&&dis2(enemyunit[i].pos,j.pos)<min&&dis2(enemyunit[i].pos,enbasepos)>169) {min=dis2(enemyunit[i].pos,j.pos);tgpos=enemyunit[i].pos;}
                    }
            
        }
    for (i=0;i<info2.units.size();i++)
        if (info2.units[i].camp==info2.camp)
            if (info2.units[i].isHero())
                if (info2.units[i].id!=j.id)
                    if (info2.units[i].hp<=(j.atk-info2.units[i].def))
                        if (dis2(origin_pos[info2.units[i].id],j.pos)<=j.range)
                            if (info2.units[i].atk<100)
                                if (calcumaydamage(info2.units[i].pos)==0)
                                {
                                    const PSkill* ptr=&j.skills[0];
                                    if (ptr->cd==0)
                                    {
                                        int value=160-j.atk-30*info2.units[i].level;
                                        if (value>maxvalue)
                                        {
                                            maxvalue=value;
                                            op.type="Attack";
                                            op.targets.clear();
                                            op.targets.push_back(origin_pos[info2.units[i].id]);
                                        }
                                    }
                                }
    if (min==1000) tgpos=aim[j.id];
    calcumayarrive(j.speed,j.pos);
    
    int nowhint=0;
    srand(time(0));
    if (min<j.range+j.speed+5||status[j.id]!=0||n1<n2)
        for (i=-6;i<7;i++)
            for (w=-6;w<7;w++)
                if (j.pos.x+i>=0&&j.pos.x+i<=149&&j.pos.y+w>=0&&j.pos.y+w<=149)
                    if (mapar[j.pos.x+i][j.pos.y+w][0]+mapar[j.pos.x+i][j.pos.y+w][1]>0)
                    {
                        int value;
                        value=0;
                        double i1,i2,i3,i4,i5,i6,cs;
                        int iv;
                        Pos ww;
                        ww.x=j.pos.x+i;ww.y=j.pos.y+w;
                        i1=calcuatkvalue(ww,j.range)*j.atk;
                        i2=calcudefvalue(ww)*(j.level+3)/3;
                        i6=calcubonusdefvalue(j,ww);
                        i4=calcusightvalue(ww,144);
                        cs=2;
                        if (n1>n2||j.atk>90) cs=5;
                        cs=cs*4/sqrt(j.range);
                        if (dis2(ww,basepos)<=144)
                        {
                            i4=(144-dis2(ww,basepos))/2;
                        }
                        i5=0;
                        if (dis2(aim[j.id],ww)>400)
                        {
                            i5=dis2(aim[j.id],ww);
                            i5=int(sqrt(i5));
                        }
                        i3=(i2-p2+i1*cs-p1*cs+i4/10-i5/2)/5/(0.5+cs/2);
                        if (canmine[ww.x][ww.y]>0) i3+=60;
                        if (canmine[j.pos.x][j.pos.y]>0) i3-=60;
                        if (status[j.id]>0) i3=(i2-p2)*3;
                        if (insight[1][ww.x][ww.y]!=info2.round&&j.hp<300+12*sqrt(sqrt(info2.round))&&j.atk<100) i3+=6000/j.hp;
                        if (insight[1][j.pos.x][j.pos.y]!=info2.round&&j.hp<300+12*sqrt(sqrt(info2.round))&&j.atk<100) i3-=6000/j.hp;
                        if (n1>n2*3) i3=(i1-p1)*2;
                        i3+=p3-i6;
                        //i3+=dis2(aim[j.id],j.pos)-dis2(ww,j.pos)
                        iv=int(i3/12);
                        if (iv>maxvalue) nowhint=1;
                        if (iv==maxvalue)
                        {nowhint+=1;
                            if (rand()%nowhint==0)
                                maxvalue-=1;
                        }
                        //cout<<j.id<<' '<<status[j.id]<<' '<<n1<<' '<<n2<<' '<<j.pos.x<<' '<<j.pos.y<<' '<<i1<<' '<<i2<<' '<<ww.x<<' '<<ww.y<<' '<<iv<<endl;
                        if (iv>maxvalue)
                        {
                            maxvalue=iv;
                            op.type="Move";
                            tgpos=ww;
                            iil=1;
                        }
                    }
    // if (i1*2<i2) {maxvalue=0;tgpos=basepos;}
    if (maxvalue==0||iil==1)
        
    {
        //  tgpos=Pos(73+4*info2.player,72+4*info2.player);
        op.type="Move";
        op.targets.clear();
        op.targets.push_back(j.pos);
        findroutine(j.pos,tgpos,j.speed,op.targets);
        if (op.targets.size()>0)
        {
            j.pos=op.targets[op.targets.size()-1];
            mapbl[op.targets[op.targets.size()-1].x][op.targets[op.targets.size()-1].y]=1;
            mapbl[j.pos.x][j.pos.y]=0;
        }
        
    }
    op.id=j.id;
    
    cmd.cmds.push_back(op);
    if (op.type=="Blink") {mapbl[op.targets[0].x][op.targets[0].y]=1;mapbl[j.pos.x][j.pos.y]=0;j.pos=op.targets[0];}
    if (op.type=="SetObserver") mapbl[op.targets[0].x][op.targets[0].y]=1;
    if (op.type=="Attack") {
        for (i=0;i<enemyunit.size();i++)
            if (dis2(enemyunit[i].pos,op.targets[0])==0)
            {
                int val=j.atk-enemyunit[i].def;
                if (maph[j.pos.x][j.pos.y]<maph[op.targets[0].x][op.targets[0].y]-1) val=val/2;
                if (val<5) val=5;
                enemyunit[i].hp-=val;
                isdamed[enemyunit[i].id]=1;
            }
    }
        if (op.type=="HammerAttack"){
            for (i=0;i<enemyunit.size();i++)
            if (dis2(enemyunit[i].pos,op.targets[0])==0)
            {
                int val=80+30*j.level;
                enemyunit[i].hp-=val;
                isdamed[enemyunit[i].id]=1;
                isdizzed[enemyunit[i].id]=1;
            }

        }

}
int isgrouped[50];


void mining2(PUnit j,Pos minepos,int monnum,PCommand &cmd)
{
    int i,ii;
    Operation op;
    op.id=j.id;
    int mindist=100000;
    Pos choosepos=DEFAULFPOS;
    Pos animalpos=mons[monnum].pos;
    if (mons[monnum].rev_time<5)
        dayestatus[j.id]=0;
    cout<<info2.round<<' '<<mons[monnum].id<<' '<<mons[monnum].rev_time<<"arp";
    
    if (mons[monnum].rev_time>4||(mons[monnum].hp<=0&&mons[monnum].rev_time==0))
        dayestatus[j.id]=1;
    if (mons[monnum].rev_time>0||(mons[monnum].hp<=0&&mons[monnum].rev_time==0))
        minecontrol=false;
    
    if (dayestatus[j.id]==0)
    {
        findbfsdis(j.pos);
        for (i=-6;i<7;i++)
            for (ii=-6;ii<7;ii++)
            {
                Pos ww;
                ww.x=mons[monnum].base_pos.x+i;
                ww.y=mons[monnum].base_pos.y+ii;
                if  (nodamage[ww.x][ww.y]>0)
                    if (mapbl[ww.x][ww.y]==0||dis2(j.pos,ww)==0)
                        if (mapbfs[ww.x][ww.y]>0||dis2(j.pos,ww)==0)
                            if (dis2(ww,j.pos)+mapbfs[ww.x][ww.y]*mapbfs[ww.x][ww.y]*3<mindist)
                            {
                                mindist=dis2(ww,j.pos)+mapbfs[ww.x][ww.y]*mapbfs[ww.x][ww.y]*3;
                                choosepos=ww;
                            }
            }
        if (choosepos.x==38&&choosepos.y==66&&mapbl[37][66]==0) choosepos.x=37;
        
        if (dis2(j.pos,choosepos)!=0)
        {
            op.type="Move";
            op.targets.clear();
            findroutine(j.pos,choosepos,j.speed,op.targets);
        }
        mapbl[choosepos.x][choosepos.y]=1;
    }
    if (dayestatus[j.id]==0&&mons[monnum].rev_time>0) cout<<"Poses:"<<j.pos.x<<' '<<j.pos.y<<' '<<choosepos.x<<' '<<choosepos.y<<endl;
    if (dis2(j.pos,choosepos)==0&&dayestatus[j.id]==0)
        dayestatus[j.id]=4;
    if (dayestatus[j.id]==4)
    {
        
        op.type="Attack";
        op.targets.clear();
        op.targets.push_back(animalpos);
        mons[monnum].hp-=j.atk-mons[monnum].def;
    }
    if (dayestatus[j.id]==1)
    {
        
        op.type="Move";
        op.targets.clear();
        findroutine(j.pos,minepos,j.speed,op.targets);
    }
    cmd.cmds.push_back(op);
    
}
void mining3(PUnit j,Pos minepos,Pos animalpos,PCommand &cmd)
{
    int i,ii,i2;
    dayestatus[j.id]=0;
    Pos duiweipos;
    int zmp=0;
    duiweipos=animalpos;
    if (dis2(j.pos,animalpos)<=25&&dis2(j.pos,minepos)<=49)
        for (int w=0;w<j.skills.size();w++)
            if (j.skills[w].typeId==13&&j.skills[w].cd==0)
                dayestatus[j.id]=3;
    for (i=0;i<myunit.size();i++)
        if (info2.units[myunit[i]].max_hp==50)
            if (dis2(info2.units[myunit[i]].pos,minepos)<=16)
            {
                minecontrol=false;
                if (info2.units[myunit[i]].hp>6)
                    dayestatus[j.id]=6;
                zmp=1;
            }
    Operation op;
    op.id=j.id;
    if (zmp==1) duiweipos=basepos;
    for (i=0;i<7;i++)
        if (dis2(gold[i].pos,minepos)==0)
            if (gold[i].energy<=1)
                dayestatus[j.id]=0;
    if (dayestatus[j.id]==0)
    {
        op.type="Move";
        op.targets.clear();
        findroutine(j.pos,duiweipos,j.speed,op.targets);
        cmd.cmds.push_back(op);
        return;
    }
    if (dayestatus[j.id]==3)
    {
        for (i=-4;i<5;i++)
            for (ii=-4;ii<5;ii++)
            {
                Pos ww;
                ww.x=minepos.x+i;
                ww.y=minepos.y+ii;
                if (dis2(ww,minepos)<=16&&dis2(ww,j.pos)<=25&&dis2(ww,animalpos)==1)
                    if (maph[ww.x][ww.y]-maph[j.pos.x][j.pos.y]<=1)
                        
                    {
                        
                        op.type="SetObserver";
                        op.targets.clear();
                        op.targets.push_back(ww);
                        cmd.cmds.push_back(op);
                        return;
                    }
            }
    }
    if (dayestatus[j.id]==6)
    {
        op.type="Move";
        op.targets.clear();
        findroutine(j.pos,minepos,j.speed,op.targets);
        cmd.cmds.push_back(op);
        return;
    }
    
}
void mining(PUnit j,Pos minepos, Pos animalpos,PCommand &cmd)
{
    //先判断人是否齐了
    
    int i,ii,i2;
    
    int stack=0;
    int support=0;
    Pos teammatepos=DEFAULFPOS;
    Operation op;
    for (i=0;i<6;i++)
        if (dis2(mons[i].base_pos,animalpos)==0)
            if (dis2(mons[i].pos,animalpos)!=0)
            {
                dayestatus[j.id]=0;
                qinding[j.id]=0;
                op.id=j.id;
                op.type="Move";
                findroutine(j.pos,basepos,j.speed,op.targets);
                cmd.cmds.push_back(op);
                return;
            }
    int mateid=0;
    op.id=j.id;
    for (i=0;i<info2.units.size();i++)
        if (info2.units[i].camp==info2.camp)
            if (info2.units[i].isHero())
            {
                if (dis2(info2.units[i].pos,animalpos)<=49)
                {
                    stack++;
                }
                if (info2.units[i].id!=j.id)
                    if (dis2(aim[info2.units[i].id],minepos)<100)
                    {
                        teammatepos=info2.units[i].pos;
                        mateid=info2.units[i].id;
                    }
            }
    if (qinding[j.id]==0||qinding[j.id]+qinding[mateid]!=3)
    {
        qinding[j.id]=1;
        qinding[mateid]=2;
    }
    if (mateid==0)
    {
        qinding[j.id]=0;
        dayestatus[j.id]=0;
        op.type="Move";
        findroutine(j.pos,basepos,j.speed,op.targets);
        cmd.cmds.push_back(op);
        return;
    }
    /*    for (i=0;i<7;i++)
     if (dis2(minepos,gold[i].pos)==0)
     if (gold[i].lastsee==info2.round&&gold[i].energy==1)
     {
     dayestatus[j.id]=0;
     qinding[j.id]=0;
     dayestatus[mateid]=0;
     qinding[mateid]=0;
     }*/
    Pos suggestpos,p1pos,p1pos2,p2pos,p2pos1,up1pos,up2pos,up1pos2,pp1pos,pp2pos,up2pos1;
    if (qinding[j.id]==1) {pp1pos=j.pos;pp2pos=teammatepos;}
    if (qinding[j.id]==2){pp1pos=teammatepos;pp2pos=j.pos;}
    
    int value=100000;
    for (i=-4;i<5;i++)
        for (ii=-4;ii<5;ii++)
        {
            Pos ww;
            ww.x=minepos.x+i;ww.y=minepos.y+ii;
            if (dis2(ww,minepos)==17&&dis2(ww,animalpos)==2)
            {
                up1pos=ww;
                int jj,kk;
                for (jj=-2;jj<3;jj++)
                    for (kk=-2;kk<3;kk++)
                    {
                        Pos zw;
                        zw.x=ww.x+jj;
                        zw.y=ww.y+kk;
                        if (dis2(zw,minepos)==5&&dis2(zw,ww)==4)
                            up2pos=zw;
                        if (dis2(zw,minepos)==16&&dis2(zw,ww)==1)
                            up1pos2=zw;
                        if (dis2(zw,minepos)==18&&dis2(zw,ww)==5)
                            up2pos1=zw;
                    }
                
                
                int zm=0;
                if (dis2(up1pos,pp1pos)>zm) zm=dis2(up1pos,pp1pos);
                if(dis2(up2pos,pp2pos)>zm) zm=dis2(up2pos,pp2pos);
                if (zm<value) {
                    value=zm;p1pos=up1pos;p2pos=up2pos;p1pos2=up1pos2;p2pos1=up2pos1;
                }
                
            }
        }
    if (stack<2) {
        op.type="Move";
        op.targets.clear();
        findroutine(j.pos,animalpos,j.speed,op.targets);
        cmd.cmds.push_back(op);
        return;
    }
    //    cout<<endl<<j.pos.x<<' '<<j.pos.y<<' '<<teammatepos.x<<' '<<teammatepos.y;
    if (dayestatus[j.id]!=2) dayestatus[j.id]=0;
    if (qinding[j.id]==2&&dis2(j.pos,p2pos)<=12&&dis2(teammatepos,p1pos)<=12)
    {
        dayestatus[j.id]=1;
        dayestatus[mateid]=2;
    }
    if (qinding[j.id]==1&&dis2(j.pos,p1pos)==0&&dis2(origin_pos[mateid],minepos)<=16)
    {
        dayestatus[j.id]=1;
        dayestatus[mateid]=2;
    }
    if (qinding[j.id]==1)
        if (dayestatus[j.id]==0||dayestatus[j.id]==2)
        {
            op.type="Move";
            op.targets.clear();
            findroutine(j.pos,p1pos,j.speed,op.targets);
        }
    if (qinding[j.id]==2)
        if (dayestatus[j.id]==0)
        {
            op.type="Move";
            op.targets.clear();
            findroutine(j.pos,p2pos1,j.speed,op.targets);
        }
    minecontrol=false;
    if (qinding[j.id]==1)
        if (dayestatus[j.id]==1)
        {
            op.type="Move";
            op.targets.clear();
            op.targets.push_back(p1pos);
            op.targets.push_back(p1pos2);
            op.targets.push_back(Pos(p1pos2.x*2-p1pos.x,p1pos2.y*2-p1pos.y));
        }
    
    if (qinding[j.id]==2)
        if (dayestatus[j.id]>0)
        {
            op.type="Move";
            op.targets.clear();
            findroutine(j.pos,p2pos,j.speed,op.targets);
        }
    cmd.cmds.push_back(op);
    /*if (mateid==0)//单人亦可绕ROSHAN而行
     if canmine[
     
     /* for (i=0;i<7;i++)
     if (dis2(minepos,gold[i].pos)==0)
     if (gold[i].lastsee==info2.round&&gold[i].energy<=1)
     {
     dayestatus[j.id]=0;
     qinding[j.id]=0;
     }*/
    
}

int findenemy;
void decideapp(PUnit &j,PCommand &cmd)
{
    dangerb=true;
    dangerb2=false;
    vector <const PUnit*> st;
    Operation op;
    minecontrol=true;
    if (canmine[j.pos.x][j.pos.y]>1) minecontrol=false;
    if (canmine[aim[j.id].x][aim[j.id].y]>1) minecontrol=false;
    if (dangerousblock[j.pos.x][j.pos.y]>0) dangerb=false;
    if (dangerousblock[aim[j.id].x][aim[j.id].y]>0) dangerb=false;
    findUnitInArea(info2,basepos,2500,st);
    int radius=0;
    /* for (i=0;i<6;i++)
     if (dis2(gold[i].pos,aim[j.id])>400)
     if (gold[i].enemyvalue>20000)
     if (dis2(j.pos,gold[i].pos)>169)
     {
     int w1,w2;
     for (w1=-12;w1<13;w1++)
     for (w2=-12;w2<13;w2++)
     if (w1*w1+w2*w2<=144)
     {
     mapbl[gold[i].pos.x+w1][gold[i].pos.y+w2]=1;
     }
     }*/
    int i,ii,k,kk;
    for (i=0;i<6;i++)
        if (mons[i].anger[j.id]>0&&dayestatus[j.id]<=0)
            if (mons[i].rev_time==0)
                if (dis2(mons[i].pos,j.pos)<=144)
                {
                    int zp=0;
                    for (k=0;k<info2.units.size();k++)
                        if (mons[i].anger[info2.units[k].id]>mons[i].anger[j.id])
                        {
                            zp=1;
                        }
                    if (zp==0)
                    {
                        op.id=j.id;
                        op.type="Move";
                        op.targets.clear();
                        findroutine(j.pos,basepos,j.speed,op.targets);
                        cmd.cmds.push_back(op);
                        return;
                    }
                }
    for (i=0;i<info2.units.size();i++)
        if (dis2(basepos,info2.units[i].pos)<2500)
            if (info2.units[i].player==1-info2.player)
                if (info2.units[i].isHero())
                {
                    //    if (info2.round>50) aim[j.id]=info2.units[i].pos;
                    findenemy=5;
                }
    
    findUnitInArea(info2,j.pos,225,st);
    
    if (insight[1][j.pos.x][j.pos.y]==info2.round)
    {
        //    if (dis2(info2.units[i].pos,enbasepos)>169)aim[j.id]=info2.units[i].pos;
        findenemy=5;
        eigen[j.id]=1;
        dayestatus[j.id]=0;
        qinding[j.id]=0;
        return;
    }
    if (dangerousblock[aim[j.id].x][aim[j.id].y]==0)dangerb=true;
    for (i=0;i<info2.units.size();i++)
        if (dis2(j.pos,info2.units[i].pos)<=64)
            if (info2.units[i].player==1-info2.player)
                if (info2.units[i].isHero())
                {
                    findenemy=5;
                    eigen[j.id]=1;
                    dayestatus[j.id]=0;
                    qinding[j.id]=0;
                    return;
                }
    if (dis2(j.pos,aim[j.id])<=225)
    {
        for (i=0;i<7;i++)
            //   if (gold[i].energy>0)
            if (dis2(gold[i].pos,aim[j.id])<100)
            {
                if (i>0)
                {
                    if (mons[i-1].max_hp==1200&&dis2(mons[i-1].pos,mons[i-1].base_pos)==0)
                    {
                        mining(j,gold[i].pos,mons[i-1].pos,cmd);
                        return;
                    }
                    if (j.speed==36&&mons[i-1].rev_time==0){
                        
                        int zm=0;
                        if (gold[i].energy>0)
                            for (ii=0;ii<j.skills.size();ii++)
                                if (j.skills[ii].typeId==13&&j.skills[ii].cd==0)
                                {zm=1;
                                    for (k=0;k<myunit.size();k++)
                                        if (dis2(info2.units[myunit[k]].pos,gold[i].pos)<=16)
                                            zm=0;
                                }
                        
                        if (dayestatus[j.id]==6||dayestatus[j.id]==3)
                            if (j.typeId==6)
                                zm=1;
                        if (havenum[i]>0) zm=0;
                        if (gold[i].energy>0)
                            if (zm==1)
                            {
                                mining3(j,gold[i].pos,mons[i-1].pos,cmd);
                                havenum[i]++;
                                return;
                            }
                    }
                    if (j.range>25&&gold[i].pos.x<120&&gold[i].pos.y<120)
                    {
                        mining2(j,gold[i].pos,i-1,cmd);
                        return;
                    }
                }
                
            }
    }
    
    vector<Pos> path;
    op.id=j.id;
    op.type="Move";
    op.targets.clear();
    op.targets.push_back(j.pos);
    findroutine(j.pos,aim[j.id],j.speed,op.targets);
    for (i=0;i<j.skills.size();i++)
        if (j.skills[i].typeId==9)
            if (dis2(j.pos,aim[j.id])>2500)
                if (j.skills[i].cd==0)
                    if (j.mp==200)
                    {
                        int k,l;
                        findbfsdis(aim[j.id]);
                        int nowmin=10000;
                        for (k=-9;k<10;k++)
                            for (l=-9;l<10;l++)
                                if (k*k+l*l<=81)
                                    if (j.pos.x+k>=0&&j.pos.x+k<=149&&j.pos.y+l>=0&&j.pos.y+l<=149)
                                        if (mapbfs[j.pos.x+k][j.pos.y+l]!=0)
                                            if (nowmin>mapbfs[j.pos.x+k][j.pos.y+l])
                                            {
                                                op.type="Blink";
                                                op.targets.clear();
                                                op.targets.push_back(Pos(j.pos.x+k,j.pos.y+l));
                                                nowmin=mapbfs[j.pos.x+k][j.pos.y+l];
                                            }
                    }
    cmd.cmds.push_back(op);
    //  cmd.cmds.push_back(op);
}
void decideapp2(PUnit &j,PCommand &cmd)
{
    dangerb=false;
    
    minecontrol=true;
    if (canmine[j.pos.x][j.pos.y]>1) minecontrol=false;
    if (canmine[aim[j.id].x][aim[j.id].y]>1) minecontrol=false;
    fighting(j,cmd);
}
void goldinit()
{
    int i,p,evalu;
    double eel;
    evalu=0;
    for (i=0;i<7;i++)
    {
        if (gold[i].lastsee==info2.round)
            gold[i].enemyvalue=calcuenvalue(gold[i].pos,225);
        if (gold[i].lastsee!=info2.round)
            gold[i].enemyvalue=gold[i].enemyvalue*99/100;
        eel=1;
        int zip=gold[i].energy;
        if (i>0)
            if (mons[i-1].max_hp==800)
                if (gold[i].pos.x<110&&gold[i].pos.y<110)
                    zip-=mons[i-1].hp/20;
        if (zip>0)
            eel=2-exp(-zip*0.1);
        if (zip<0)
        {
            eel=2-exp(zip*0.05);
            if (eel>1.5) eel=1.5;
        }
        evalu=int(25*eel);
        // if (evalu>38) evalu=38;
        if (i==0) evalu=50;
        gold[i].value=gold[i].enemyvalue/50+evalu;
        if (i>0)
            if (mons[i-1].max_hp==800)
                if (gold[i].pos.x<110&&gold[i].pos.y<110)
                    eel+=mons[i-1].hp/800*0.56;
        
    }
    
}
void turninit(PCommand &cmd)
{
    xt=1;
    memset(isdizzed,0,sizeof(isdizzed));
    memset(dangerousblock,0,sizeof(dangerousblock));
    memset(havenum,0,sizeof(havenum));
    memset(isdamed,0,sizeof(isdamed));
    memset(mapbl,0,sizeof(mapbl));
    for (int i=0;i<50;i++)
        if (status[i]>0)  status[i]-=1;
    for (int i=0;i<150;i++)
        for (int k=0;k<150;k++)
        {
            /*   if (canmine[i][k]>1)
             if (mons[canmine[i][k]-1].rev_time==0)
             mapbl[i][k]=1;*/
            //        if (dis2(Pos(i,k),Pos(74,75))<400) mapbl[i][k]=1;
            if (dis2(Pos(i,k),enbasepos)<=144) mapbl[i][k]=1;
        }
    minecontrol=true;
    dangerb=false;
    dangerb2=true;
    if (findenemy>0) findenemy-=1;
    myunit.clear();
    int i2;
    for(int i=0;i<info2.units.size();i++)
    {
        PUnit j=info2.units[i];
        origin_pos[j.id]=j.pos;
        mapbl[j.pos.x][j.pos.y]=1;
        if (/*j.isBase()||*/j.isMine())
        {
            for (int k=-1;k<2;k++)
                for (int w=-1;w<2;w++)
                    if(j.pos.x+k>=0&&j.pos.x+k<=149&&j.pos.y+w>=0&&j.pos.y+w<=149)
                        mapbl[j.pos.x+k][j.pos.y+w]=1;
        }
        j.buffs=info2.units[i].buffs;
        j.args=info2.units[i].args;
        j.pos=info2.units[i].pos;
        j.skills=info2.units[i].skills;
        if (j.player==info2.player)
        {
            myunit.push_back(i);
            if (j.isHero())
            {
                if (j.findBuff("Reviving"))
                    aim[j.id]=Pos(73,76);
                
                if (dayestatus[j.id]>0)
                {
                    int zm=0;
                    for (i2=0;i2<6;i2++)
                        if (dis2(mons[i2].base_pos,j.pos)<324&&mons[i2].rev_time<5) zm=1;
                    if (zm==0) {
                        aim[j.id]=Pos(73,76);
                        dayestatus[j.id]=0;
                        qinding[j.id]=0;
                    }
                }
            }
        }
        if (j.player==1-info2.player)
        {
            int m=0;
            for (int ii=0;ii<enemyunit.size();ii++)
            {
                if (enemyunit[ii].id==j.id)
                {
                    enemyunit[ii]=j;
                    enemyunit[ii].exp=info2.round;
                    m=1;
                }
            }
            if (m==0) {enemyunit.push_back(j);
                enemyunit[enemyunit.size()-1].exp=info2.round;
                
            }
        }
        if (j.player==2)
        {
            if (j.max_hp>5000)
            {
                for (int k=0;k<7;k++)
                    if (dis2(gold[k].pos,j.pos)==0)
                    {
                        gold[k].lastsee=info2.round;
                        for (int m=0;m<j.args.size();m++)
                            if (j.args[m].typeId==11)
                                gold[k].energy=j.args[m].val[0];
                        
                    }
                
            }
            else
            {
                for (int k=0;k<6;k++)
                    if (j.id==mons[k].id)
                    {
                        mons[k].lastsee=info2.round;
                        mons[k].pos=j.pos;
                        mons[k].hp=j.hp;
                        mons[k].cd=j.skills[0].cd;
                        mons[k].rev_time=0;
                        if (j.findBuff("Reviving")) mons[k].rev_time=j.findBuff("Reviving")->timeLeft;
                    }
            }
        }
    }
    
    //对没有视野的敌人，给予反复操作
    for (int ii=0;ii<enemyunit.size();ii++)
    {
        if (enemyunit[ii].exp!=info2.round)
            if (enemyunit[ii].isHero())
                if (enemyunit[ii].hp>0)
                {
                    enemyunit[ii].hp+=enemyunit[ii].max_hp/100;
                    enemyunit[ii].mp+=enemyunit[ii].max_mp/100;
                    int jj;
                    for (jj=0;jj<enemyunit[ii].buffs.size();jj++)
                    {
                        enemyunit[ii].buffs[jj].timeLeft-=1;
                        
                        if (enemyunit[ii].buffs[jj].timeLeft==0)
                        {
                            if(strcmp(enemyunit[ii].buffs[jj].name,"WinOrDie"))
                            {
                                enemyunit[ii].hp+=enemyunit[ii].atk-30-8*enemyunit[ii].level;
                                enemyunit[ii].atk=30+8*enemyunit[ii].level;
                            }
                            enemyunit[ii].buffs.erase(enemyunit[ii].buffs.begin()+jj);
                            jj-=1;
                        }
                        if (strcmp(enemyunit[ii].buffs[jj].name,"Reviving")==0)
                        {
                            enemyunit[ii].hp=enemyunit[ii].max_hp;
                            enemyunit[ii].mp=enemyunit[ii].max_mp;
                            enemyunit[ii].pos=enbasepos;
                        }
                        
                    }
                    for (jj=0;jj<enemyunit[ii].skills.size();jj++)
                    {
                        if  (enemyunit[ii].skills[jj].cd>0) enemyunit[ii].skills[jj].cd-=1;
                    }
                }
        if (enemyunit[ii].max_hp==3000)
        {
            enemyunit[ii].hp+=1;
        }
        if (enemyunit[ii].max_hp==50)
        {
            enemyunit[ii].hp-=1;
        }
        if (enemyunit[ii].hp>enemyunit[ii].max_hp)
        {
            enemyunit[ii].hp=enemyunit[ii].max_hp;
        }
        if (enemyunit[ii].mp>enemyunit[ii].max_mp)
            enemyunit[ii].mp=enemyunit[ii].max_mp;
        if (enemyunit[ii].hp<=0&&enemyunit[ii].max_hp==50)
        {
            enemyunit.erase(enemyunit.begin()+ii);
            ii-=1;//删除眼
        }
    }
    for (int i=0;i<enemyunit.size();i++)
        if (enemyunit[i].isHero())
            if (!enemyunit[i].findBuff("Reviving"))
                if (enemyunit[i].hp>0)
                {
                    int eew=0;
                    if (enemyunit[i].findBuff("BeAttacked"))
                        eew=1;
                    for (int ii=0;ii<enemyunit.size();ii++)
                        if (enemyunit[ii].typeId==6)
                            if (dis2(enemyunit[i].pos,enemyunit[ii].pos)<=121)
                                if (!enemyunit[ii].findBuff("Reviving"))
                                {
                                    int zw=enemyunit[i].max_hp/100;
                                    if (eew==0) enemyunit[i].hp+=zw*(1+(1+enemyunit[ii].level)/2);
                                    if (eew==1)
                                    {
                                        enemyunit[i].hp+=zw*(enemyunit[ii].level/2);
                                        if (enemyunit[ii].level<2) enemyunit[i].hp+=1;
                                    }
                                    
                                }
                    if (enemyunit[i].hp>enemyunit[i].max_hp) enemyunit[i].hp=enemyunit[i].max_hp;
                }
    for (int i=0;i<myunit.size();i++)
        if (info2.units[myunit[i]].isHero())
            if (!info2.units[myunit[i]].findBuff("Reviving"))
            {
                int eew=0;
                if (info2.units[myunit[i]].findBuff("BeAttacked"))
                    eew=1;
                for (int ii=0;ii<myunit.size();ii++)
                    if (info2.units[myunit[ii]].typeId==6)
                        if (dis2(info2.units[myunit[i]].pos,info2.units[myunit[ii]].pos)<=121)
                            if (!info2.units[myunit[ii]].findBuff("Reviving"))
                            {
                                int zw=info2.units[myunit[i]].max_hp/100;
                                if (eew==0) info2.units[myunit[i]].hp+=zw*(1+(1+info2.units[myunit[ii]].level)/2);
                                if (eew==1)
                                {
                                    info2.units[myunit[i]].hp+=zw*(info2.units[myunit[ii]].level/2);
                                    if (info2.units[myunit[ii]].level<2) info2.units[myunit[i]].hp+=1;
                                }
                                
                            }
                if (info2.units[myunit[i]].hp>info2.units[myunit[i]].max_hp) info2.units[myunit[i]].hp=info2.units[myunit[i]].max_hp;
            }
    
    for (int i=0;i<7;i++)
        if (gold[i].lastsee!=info2.round)
        {
            gold[i].energy-=1;
        }
    for (int i=0;i<6;i++)
        if (mons[i].lastsee!=info2.round)
        {
            if (mons[i].cd>0)mons[i].cd-=1;
            if (mons[i].rev_time>0) {
                mons[i].pos=mons[i].base_pos;
                mons[i].rev_time-=1;
                mons[i].hp=mons[i].max_hp;
            }
            
            mons[i].hp+=mons[i].max_hp/100;
            if (mons[i].hp>mons[i].max_hp) mons[i].hp=mons[i].max_hp;
        }
    sight();
    for (int ii=0;ii<enemyunit.size();ii++)
    {
        if (enemyunit[ii].exp!=info2.round)
            if (insight[0][enemyunit[ii].pos.x][enemyunit[ii].pos.y]==info2.round)
            {
                findbfsdis(enemyunit[ii].pos);
                Pos minpos=enbasepos;
                int min=1000000;
                for (int i=0;i<150;i++)
                    for (int iii=0;iii<150;iii++)
                        if (mapbfs[i][iii]>0)
                            if (insight[0][i][iii]!=info2.round)
                                if (dis2(Pos(i,iii),enemyunit[ii].pos)+mapbfs[i][iii]*mapbfs[i][iii]*4<min)
                                {
                                    min=dis2(Pos(i,iii),enemyunit[ii].pos)+mapbfs[i][iii]*mapbfs[i][iii]*4;
                                    minpos=Pos(i,iii);
                                }
                enemyunit[ii].pos=minpos;
            }
    }//对于没有视野的敌人，将其位置移到最近的无视野点,若没有，则重置为对方基地。
    for (int ii=0;ii<6;ii++)
    {
        if (mons[ii].lastsee!=info2.round)
            if (insight[0][mons[ii].pos.x][mons[ii].pos.y]==info2.round)
            {
                findbfsdis(mons[ii].base_pos);
                Pos minpos=mons[ii].pos;
                int min=1000000;
                for (int i=0;i<150;i++)
                    for (int iii=0;iii<150;iii++)
                        if (mapbfs[i][iii]>0)
                            if (insight[0][i][iii]!=info2.round)
                                if (dis2(Pos(i,iii),mons[ii].pos)<12)
                                    if (dis2(Pos(i,iii),mons[ii].base_pos)+mapbfs[i][iii]*mapbfs[i][iii]*4<min)
                                    {
                                        min=dis2(Pos(i,iii),mons[ii].base_pos)+mapbfs[i][iii]*mapbfs[i][iii]*4;
                                        minpos=Pos(i,iii);
                                    }
                mons[ii].pos=minpos;
            }
    }
    angerevalu();
    goldinit();
    memset(wilmove,0,sizeof(wilmove));
    for (int i=0;i<info2.units.size();i++)
        if (willmove(info2.units[i]))
            wilmove[info2.units[i].id]=1;
    int p,pp,ppp;
    for (p=0;p<150;p++)
        for (pp=0;pp<150;pp++)
        {
            Pos ww;
            ww.x=p;
            ww.y=pp;
            for (int i=0;i<enemyunit.size();i++)
            {
                if (enemyunit[i].typeId==3)
                    if (dis2(enemyunit[i].pos,ww)<=121)
                        if (maph[enemyunit[i].pos.x][enemyunit[i].pos.y]-maph[p][pp]>-2)
                            if (enemyunit[i].mp>=100)
                                if (enemyunit[i].exp-info2.round>-7)
                                    for (ppp=0;ppp<enemyunit[i].skills.size();ppp++)
                                        if (enemyunit[i].skills[ppp].typeId==8)
                                            if (enemyunit[i].skills[ppp].cd==0)
                                                dangerousblock[p][pp]=1;
                if (enemyunit[i].typeId>3&&enemyunit[i].typeId<7)
                    if (dis2(enemyunit[i].pos,ww)<=enemyunit[i].range)
                        if (maph[enemyunit[i].pos.x][enemyunit[i].pos.y]-maph[p][pp]>-2)
                          if (enemyunit[i].exp-info2.round>-7)
                      /*          for (ppp=0;ppp<enemyunit[i].skills.size();ppp++)
                                    if (enemyunit[i].skills[ppp].typeId==11)
                                        if (enemyunit[i].skills[ppp].cd==0)*/
                                            dangerousblock[p][pp]=1;
            }
        }
    memset(dangerousblock2,0,sizeof(dangerousblock2));
    for (p=0;p<150;p++)
        for (pp=0;pp<150;pp++)
        {
            Pos ww;
            ww.x=p;
            ww.y=pp;
            for (int i=0;i<enemyunit.size();i++)
            {
                if (enemyunit[i].typeId==3)
                    if (dis2(enemyunit[i].pos,ww)<=36)
                        if (maph[enemyunit[i].pos.x][enemyunit[i].pos.y]-maph[p][pp]>-2)
                            if (enemyunit[i].mp>=100)
                                if (enemyunit[i].exp-info2.round>-7)
                                    for (ppp=0;ppp<enemyunit[i].skills.size();ppp++)
                                        if (enemyunit[i].skills[ppp].typeId==8)
                                            if (enemyunit[i].skills[ppp].cd==0)
                                                dangerousblock2[p][pp]=1;
                if (enemyunit[i].typeId==5)
                    if (dis2(enemyunit[i].pos,ww)<=enemyunit[i].range)
                        if (maph[enemyunit[i].pos.x][enemyunit[i].pos.y]-maph[p][pp]>-2)
                             if (enemyunit[i].exp-info2.round>-7)
                         for (ppp=0;ppp<enemyunit[i].skills.size();ppp++)
                         if (enemyunit[i].skills[ppp].typeId==11)
                         if (enemyunit[i].skills[ppp].cd==0)
                            dangerousblock2[p][pp]=1;
            }
        }
    //memset(dangerousblock,0,sizeof(dangerousblock));
}
void goldevalu()
{
    int i,j;
    for (i=0;i<7;i++)
    {
        if (gold[i].lastsee==info2.round)
        {
            for (j=0;j<info2.units.size();j++)
            {
                
            }
        }
    }
}

struct aimst
{
    Pos pos;
    int enemyvalue,animalvalue,value,needpeople,needtype,haspeople;
};
void calcuaim()
{
    aimst allaim[50];
    int heroaim[50];
    int i,k,o,p,q,l,st;
    l=0;
    //  for (i=0;i<50;i++)
    //     aim[i]=DEFAULFPOS;
    for (i=0;i<7;i++)
    {
        allaim[l].pos=gold[i].suggestpos;
        allaim[l].enemyvalue=gold[i].enemyvalue;
        if (gold[i].enemyvalue<100) gold[i].enemyvalue=0;
        allaim[l].needtype=0;
        allaim[l].needpeople=0;
        allaim[l].haspeople=0;
        allaim[l].value=gold[i].value;
        if (i>0)
        {
            if (mons[i-1].max_hp==1200&&mons[i-1].rev_time<5)
            {
                allaim[l].needpeople=2;
                if (dis2(mons[i-1].pos,mons[i-1].pos)>0)
                    if (allaim[l].enemyvalue==0)
                        allaim[l].enemyvalue=100000;
            }
            else
            {
                if (gold[i].pos.x<110&&gold[i].pos.y<110&&mons[i-1].rev_time<5)
                    allaim[l].needtype=1;//1:ranged
                if (gold[i].pos.x>110||gold[i].pos.y>110)
                {
                    allaim[l].needtype=2;
                    allaim[l].needpeople=1;
                }//2:SCOUTER ONLY
            }
        }
        if (i==0)
            allaim[i].needpeople=1;
        if (i>0)
            if (mons[i-1].rev_time>=5||dis2(mons[i-1].pos,mons[i-1].base_pos)>121)
            {
                allaim[i].needpeople=1;
                allaim[i].pos=gold[i].pos;
                allaim[i].pos.x-=2;
            }
        cout<<allaim[l].pos.x<<' '<<allaim[l].pos.y<<' '<<allaim[l].value<<' '<<allaim[l].enemyvalue<<endl;
        l++;
        
    }
  /*  allaim[l].pos=basepos;
    allaim[l].enemyvalue=calcuenvalue(allaim[l].pos,144);
    allaim[l].value=allaim[l].enemyvalue/10;
    allaim[l].enemyvalue=1;//保家卫国，视死如归。
    l++;*/
    for (i=0;i<enemyunit.size();i++)
        if (enemyunit[i].exp-info2.round>-10||enemyunit[i].max_hp==50)
    {
        bool zl;
        zl=true;
        for (int jj=0;jj<l;jj++)
            if (dis2(enemyunit[i].pos,allaim[jj].pos)<225) zl=false;
        if (dis2(enemyunit[i].pos,enbasepos)<=225) zl=false;
        if (dis2(enemyunit[i].pos,basepos)<=225) zl=false;
        if (zl)
        {
            allaim[l].pos=enemyunit[i].pos;
            allaim[l].enemyvalue=calcuenvalue(enemyunit[i].pos,225);
            allaim[l].value=allaim[l].enemyvalue/50;
            if (enemyunit[i].max_hp==50) allaim[l].value+=5;
            allaim[l].needtype=0;
            allaim[l].needpeople=0;
            allaim[l].haspeople=0;
            cout<<allaim[l].pos.x<<' '<<allaim[l].pos.y<<' '<<allaim[l].value<<' '<<allaim[l].enemyvalue<<endl;
            l++;
            
        }
    }
    
    allaim[l].pos=enbasepos;
    allaim[l].value=50000;
    allaim[l].enemyvalue=100000;
    allaim[l].needpeople=8;
    l++;
    memset(heroaim,0,sizeof(heroaim));
    int nowcuse=4+nowhero;
    for (i=0;i<50;i++)
        heroaim[i]=-1;
    int nearby[50];
    memset(nearby,0,sizeof(nearby));
    for (i=0;i<myunit.size();i++)
    {
        PUnit j=info2.units[myunit[i]];
        if (j.isHero())
        {
            if (dayestatus[j.id]>0)
                for ( k=0;k<l;k++)
                    if (dis2(allaim[k].pos,j.pos)<225)
                    {
                        allaim[k].haspeople++;
                        aim[j.id]=allaim[k].pos;
                        heroaim[j.id]=k;
                        allaim[k].enemyvalue-=calcuvalue(j);
                        if (allaim[k].enemyvalue<0) allaim[k].enemyvalue=0;
                        nowcuse-=1;
                    }
            if (dayestatus[j.id]==0)
                for ( k=0;k<l;k++)
                    if (dis2(allaim[k].pos,j.pos)<225)
                    {
                        nearby[k]++;
                    }
        }
        if (j.findBuff("Reviving"))
        {
            nowcuse-=1;
            aim[j.id]=basepos;
            dayestatus[j.id]=0;
            qinding[j.id]=0;
        }
    }
    
    for ( i=myunit.size()-1;i>=0;i-=1)
    {
        PUnit j=info2.units[myunit[i]];
        
        if (j.isHero())// 第一步，选择一个目标
            if (dayestatus[j.id]==0) //选择没有
                if (!j.findBuff("Reviving"))
                {
                    int v=calcuvalue(j);
                    int nowvalue;
                    int nowpeople;
                    int nowmaxvalue=0;
                    int nowchoose=-1;
                    int ischose[50];
                    memset(ischose,0,sizeof(ischose));
                    for (k=0;k<l;k++)
                        if (allaim[k].needtype==0||(allaim[k].needtype==1&&j.range>=25)||(allaim[k].needtype==2&&j.speed==36)||allaim[k].enemyvalue>0)
                            if (allaim[k].haspeople<allaim[k].needpeople||allaim[k].needpeople==0||allaim[k].enemyvalue>1)
                                if (allaim[k].enemyvalue==0||j.hp>j.level*10+55)
                                    if (heroaim[j.id]==-1)
                                           if (allaim[k].needpeople!=1||dis2(allaim[k].pos,j.pos)<400||nearby[k]<=0||allaim[k].enemyvalue>0)
                                        {
                                            double nowusevalue=0;
                                            nowvalue=v;
                                            int thisvalue;
                                            nowpeople=1;
                                            nowusevalue=1+0.2*j.level;
                                            if (j.speed==36) nowusevalue+=0.3;
                                            int ischosen[50];
                                            memset(ischosen,0,sizeof(ischosen));
                                            ischosen[j.id]=1;
                                            int nowtime=dis2(j.pos,allaim[k].pos)/j.speed;
                                            while ((nowpeople+allaim[k].haspeople<allaim[k].needpeople||nowvalue<allaim[k].enemyvalue*3/2)&&nowpeople<nowcuse)
                                            {//无脑添加估计用时比当前少的对象
                                                int mintime=1000000;
                                                int nowman=-1;
                                                PUnit j3;
                                                for (p=i+1;p<myunit.size();p++)
                                                {
                                                    PUnit j2=info2.units[myunit[p]];
                                                    if (j2.isHero())
                                                        if (allaim[k].enemyvalue==0||j2.hp>j2.level*10+55)
                                                            if (!j2.findBuff("Reviving"))
                                                                if (heroaim[j2.id]==-1)
                                                                    if (dayestatus[j2.id]==0)
                                                                        if (ischosen[j2.id]==0)
                                                                            if (dis2(j2.pos,allaim[k].pos)/j2.speed<mintime)
                                                                            {
                                                                                mintime=dis2(j2.pos,allaim[k].pos)/j2.speed;
                                                                                nowman=p;
                                                                            }
                                                }
                                                if (nowman>-1)
                                                {
                                                    j3=info2.units[myunit[nowman]];
                                                    if (mintime>nowtime) nowtime=mintime;
                                                    nowpeople+=1;
                                                    nowusevalue+=1+0.2*j3.level;
                                                    if (j3.speed==36) nowusevalue+=0.3;
                                                    nowvalue+=calcuvalue(j3);
                                                    ischosen[j3.id]=1;
                                                }
                                                if (nowman==-1) {
                                                    nowpeople=nowcuse+1;
                                                }
                                            }
                                            double th=100*exp(-sqrt(nowtime)*0.01)*allaim[k].value/nowusevalue/(1+0.02*sqrt(nowtime));
                                            if (allaim[k].needtype==1) th=th*0.8*(j.atk-10)/25;
                                            if (allaim[k].needtype==2)
                                            {
                                                for (int w=0;w<j.skills.size();w++)
                                                    if (j.skills[w].typeId==13)
                                                        if (j.skills[w].cd*j.skills[w].cd>nowtime)
                                                            nowtime=j.skills[w].cd*j.skills[w].cd;
                                            }
                                            if (allaim[k].needtype==2) th=th*15/(15+sqrt(nowtime));
                                            thisvalue=int(th);
                                            if (thisvalue>nowmaxvalue&&nowpeople<=nowcuse&&nowvalue>allaim[k].enemyvalue*6/5&&nowpeople>=allaim[k].needpeople) {
                                                nowmaxvalue=thisvalue;
                                                nowchoose=k;
                                                for (p=0;p<50;p++)
                                                    ischose[p]=ischosen[p];
                                            }
                                            
                                        }
                    for (p=0;p<myunit.size();p++)
                        if (ischose[info2.units[myunit[p]].id]>0)
                        {
                            if (heroaim[info2.units[myunit[p]].id]!=-1) {allaim[heroaim[info2.units[myunit[p]].id]].haspeople-=1;}
                            else
                            {
                            for (k=0;k<l;k++)
                                if (dis2(info2.units[myunit[p]].pos,allaim[k].pos)<225)
                                    nearby[k]-=1;
                            }
                            heroaim[info2.units[myunit[p]].id]=nowchoose;
                            aim[info2.units[myunit[p]].id]=allaim[nowchoose].pos;
                            allaim[nowchoose].haspeople++;
                            nowcuse-=1;
                        }
                    
                    
                }
    }
    /*for (p=0;p<myunit.size();p++)
        if (allaim[heroaim[p]].needpeople==2&&allaim[heroaim[p]].haspeople)*/
    for (int i=17;i<35;i++)
        cout<<i<<' '<<aim[i].x<<' '<<aim[i].y<<endl;
}
void doing(PCommand &cmd)
{
    calcuaim();
    memset(eigen,0,sizeof(eigen));
    for(int i=myunit.size()-1;i>=0;i-=1)
    {
        PUnit j=info2.units[myunit[i]];
        if (j.isHero()&&j.player==info2.player)
            if (!j.findBuff("Reviving"))
                if (!j.findBuff("Dizzy"))
                    if (!j.findBuff("WaitRevive"))
                        decideapp(info2.units[myunit[i]],cmd);
    }
    for(int i=myunit.size()-1;i>=0;i-=1)
    {
        PUnit j=info2.units[myunit[i]];
        if (j.isHero()&&j.player==info2.player)
            if (eigen[j.id]==1)
                if (!j.findBuff("Reviving"))
                    if (!j.findBuff("Dizzy"))
                        if (!j.findBuff("WaitRevive"))
                            decideapp2(info2.units[myunit[i]],cmd);
    }
    
}
void overalldec()
{
    
}
void buyhero(int i,Pos w,PCommand &cmd)
{
    Operation op;
    op.id=base_id;
    if (i==1) op.type="ChooseHammerguard";
    if (i==2) op.type="ChooseMaster";
    if (i==3) op.type="ChooseBerserker";
    if (i==4) op.type="ChooseScouter";
    op.targets.clear();
    op.targets.push_back(w);
    cmd.cmds.push_back(op);
    mapbl[w.x][w.y]=1;
}
void upgradehero(PUnit j,PCommand &cmd)
{
    Operation op;
    op.id=base_id;
    op.type="BuyHeroLevel";
    op.targets.clear();
    op.targets.push_back(j.pos);
    cmd.cmds.push_back(op);
}

void init(PCommand &cmd)
{
    DEFAULFPOS=Pos(73,76);
    memset(dayestatus,0,sizeof(dayestatus));
    memset(qinding,0,sizeof(qinding));
    memset(status,0,sizeof(status));
    findenemy=0;
    myunit.clear();
    enemyunit.clear();
    memset(mapbl,0,sizeof(mapbl));
    int i,j,k;
    for (i=0;i<50;i++)
        aim[i]=DEFAULFPOS;
    for(i=0;i<info2.units.size();i++)
    {
        PUnit jj=info2.units[i];
        if (jj.hp==3000)
        {
            base_id=jj.id;
            basepos=jj.pos;
            enbasepos.x=150-jj.pos.x;
            enbasepos.y=150-jj.pos.y;
        }
    }
    memset(canmine,0,sizeof(canmine));
    
    for (i=0;i<7;i++)
    {
        mine emptymine;
        emptymine.pos=MINE_POS[i];
        emptymine.havegold=-1;
        if (i==0) emptymine.havegold=1;
        emptymine.lastsee=0;
        if (i!=0)emptymine.monp=i-1;
        emptymine.suggestpos=emptymine.pos;
        emptymine.suggestpos.x+=1;
        gold[i]=emptymine;
        for (j=-4;j<5;j++)
            for (k=-4;k<5;k++)
                if (k*k+j*j<=16)
                    if (k*k+j*j>2)
                        canmine[emptymine.pos.x+j][emptymine.pos.y+k]=i+1;
    }
    gold[0].suggestpos=Pos(73+4*info2.player,72+4*info2.player);
    for (i=0;i<6;i++)
    {
        mon emptymon;
        Pos mpos=gold[i+1].pos;
        for (j=0;j<4;j++)
            if (dis2(mpos,Dragon_pos[j])<=25)
            {
                emptymon.typeId=11;
                emptymon.base_pos=Dragon_pos[j];
                emptymon.max_hp=800;
                emptymon.atk=80;
                emptymon.speed=12;
                emptymon.def=10;
                emptymon.range=81;
            }
        for (j=0;j<2;j++)
            if (dis2(mpos,Roshan_pos[j])<=25)
            {
                emptymon.typeId=12;
                emptymon.base_pos=Roshan_pos[j];
                emptymon.max_hp=1200;
                emptymon.atk=65;
                emptymon.speed=12;
                emptymon.def=25;
                emptymon.range=9;
                
            }
        emptymon.pos=emptymon.base_pos;
        emptymon.hp=emptymon.max_hp;
        emptymon.protectnum=i+1;
        emptymon.rev_time=0;
        emptymon.aim=0;
        for (j=0;j<50;j++)
            emptymon.anger[j]=0;
        if (i==0)
            emptymon.id=12;
        if (i==1)
            emptymon.id=16;
        if (i==2)
            emptymon.id=17;
        if (i==3)
            emptymon.id=13;
        if (i==4)
            emptymon.id=14;
        if (i==5)
            emptymon.id=15;
        mons[i]=emptymon;
        
        gold[i+1].suggestpos=mons[i].pos;
    }
    findbfsdis(DEFAULFPOS);
    for (i=0;i<150;i++)
        for (j=0;j<150;j++)
            defaultbfs[i][j]=mapbfs[i][j];
    memset(nodamage,0,sizeof(nodamage));
    for (i=0;i<150;i++)
        for (j=0;j<150;j++)
            if (defaultbfs[i][j]>0)
                for (k=0;k<6;k++)
                    if (dis2(Pos(i,j),mons[k].base_pos)<=36)
                        if (maph[i][j]-maph[mons[k].base_pos.x][mons[k].base_pos.y]>=2)
                            nodamage[i][j]=dis2(Pos(i,j),mons[k].base_pos);
    
    Pos w;
    for (k=4;k>0;k-=1)
    {
        int min=1000;
        for (i=-12;i<13;i++)
            for (j=-12;j<13;j++)
                if (i*i+j*j<=144)
                    if (basepos.x+i>=0&&basepos.x+i<=149&&basepos.y+j>=0&&basepos.y+j<=149)
                        if (mapbl[basepos.x+i][basepos.y+j]==0)
                            if (defaultbfs[basepos.x+i][basepos.y+j]>0)
                                if (defaultbfs[basepos.x+i][basepos.y+j]<min)
                                {
                                    min=defaultbfs[basepos.x+i][basepos.y+j];
                                    w.x=basepos.x+i;
                                    w.y=basepos.y+j;
                                }
        buyhero(k,w,cmd);
    }
}

void baseoper(PCommand &cmd)
{
    vector<const PUnit *> cd;
    
    findUnitInArea(info2,basepos,144,cd);
    int i,hasenemy,hashero;
    hasenemy=0;hashero=0;
    for (i=0;i<cd.size();i++)
    {
        const PUnit* j=cd[i];
        if (j->camp==1-info2.camp)
            hasenemy++;
        if (j->camp==info2.camp)
            if (j->isHero())
                hashero++;
    }
    int minhp=1000;
    int mindis=200;
    Pos tar=DEFAULFPOS;
    if (hasenemy>0)
    {
        for (i=0;i<cd.size();i++)
        {
            const PUnit* j=cd[i];
            if (j->camp!=info2.camp)
                if (j->hp<minhp)
                    if (dis2(j->pos,basepos)<=144)
                    {
                        minhp=j->hp;
                        tar=j->pos;
                    }
        }
        
        Operation op;
        op.id=base_id;
        op.type="Attack";
        op.targets.clear();
        op.targets.push_back(tar);
        cmd.cmds.push_back(op);
        for (i=0;i<cd.size();i++)
        {
            const PUnit* j=cd[i];
            if (j->camp!=info2.camp)
                if (dis2(j->pos,basepos)<mindis)
                    if (dis2(j->pos,basepos)<=144)
                    {
                        mindis=dis2(j->pos,basepos);
                        tar=j->pos;
                    }
        }
    }
    
    /*if (hasenemy*2-hashero>0)
    {
        int yizhao=0;
        while (info2.gold>=50&&hashero<hasenemy*2&&yizhao+1<myunit.size())
        {
            int min=1000;
            int i,j;Pos w,ww;
            
            for (i=-12;i<13;i++)
                for (j=-12;j<13;j++)
                    if (i*i+j*j<=144)
                        if (i*i+j*j>2)
                        if (basepos.x+i>=0&&basepos.x+i<=149&&basepos.y+j>=0&&basepos.y+j<=149)
                            if (mapbl[basepos.x+i][basepos.y+j]==0)
                            {
                                
                                ww.x=basepos.x+i;
                                ww.y=basepos.y+j;
                                if (dis2(tar,ww)<min)
                                {
                                    min=dis2(tar,ww);
                                    w=ww;
                                }
                            }
            mapbl[w.x][w.y]=1;
            int nl=0;
            for (i=yizhao;i<myunit.size();i++)
            {
                if (nl==0) yizhao=i;
                if (info2.units[myunit[i]].isHero())
                    if (dis2(basepos,info2.units[myunit[i]].pos)>60*info2.units[myunit[i]].speed)
                        if (hashero<2*hasenemy&&info2.gold>=50+info2.units[myunit[i]].level*30)
                            if (nl==0)
                                if (!info2.units[myunit[i]].findBuff("BeAttacked"))
                                    
                                {
                                    
                                    
                                    Operation op;
                                    op.id=base_id;
                                    op.type="CallBackHero";
                                    op.targets.clear();
                                    op.targets.push_back(info2.units[myunit[i]].pos);
                                    op.targets.push_back(w);
                                    info2.gold-=50+info2.units[myunit[i]].level*30;
                                    info2.units[myunit[i]].pos=w;
                                    cmd.cmds.push_back(op);
                                    hashero++;
                                    nl=1;
                                    
                                }
            }
            
        }
    }*/
    for (i=0;i<myunit.size();i++)
        if (info2.units[myunit[i]].isHero())
            if (!info2.units[myunit[i]].findBuff("Reviving"))
                if (!info2.units[myunit[i]].findBuff("BeAttacked"))
                    if (info2.gold>=info2.units[myunit[i]].level*30+50)
                        if (dis2(info2.units[myunit[i]].pos,basepos)>1000)
                        {
                            int m,n,w2,oo;
                            oo=0;
                            calcuallvalue(info2.units[myunit[i]].pos,m,n);
                            if (info2.units[myunit[i]].typeId==4)
                                for (w2=0;w2<info2.units[myunit[i]].skills.size();w2++)
                                    if (info2.units[myunit[i]].skills[w2].typeId==9)
                                        if (info2.units[myunit[i]].skills[w2].cd==0)
                                            if (info2.units[myunit[i]].mp>=80)
                                                oo=1;
                            if (info2.units[myunit[i]].findBuff("WinOrDie"))
                                for (w2=0;w2<enemyunit.size();w2++)
                                    if (enemyunit[w2].exp==info2.round)
                                        if (dis2(info2.units[myunit[i]].pos,enemyunit[w2].pos)<=info2.units[myunit[i]].range)
                                            if (info2.units[myunit[i]].skills[0].cd==0)
                                            oo=1;
                            dangerb2=true;
                            dangerb=false;
                            mapbl[info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]=0;
                            findbfsdis(basepos);
                            mapbl[info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]=1;
                        //    cout<<basepos.x<<' '<<basepos.y<<' '<<mapbfs[basepos.x-1][basepos.y-1]<<endl;
                          //  cout<<info2.units[myunit[i]].pos.x<<' '<<info2.units[myunit[i]].pos.y<<' '<<mapbfs[info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]<<endl;
                            if (oo==0)
                                if ((m*7/3<n&&(calcumayham(info2.units[myunit[i]].pos)||(mapbfs[info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]==0&&calcumaydamage(info2.units[myunit[i]].pos))))||calcumaydamage(info2.units[myunit[i]].pos)>info2.units[myunit[i]].hp)
                                    if (insight[1][info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]==info2.round)
                                    {
                                        Operation op;
                                        op.id=base_id;
                                        op.type="CallBackHero";
                                        op.targets.clear();
                                        op.targets.push_back(info2.units[myunit[i]].pos);
                                        int min=1000;
                                        int i2,j;Pos w=basepos;
                                        for (i2=-12;i2<13;i2++)
                                            for (j=-12;j<13;j++)
                                                if (i2*i2+j*j<=144)
                                                    if (basepos.x+i2>=0&&basepos.x+i2<=149&&basepos.y+j>=0&&basepos.y+j<=149)
                                                        if (mapbl[basepos.x+i2][basepos.y+j]==0)
                                                            if (defaultbfs[basepos.x+i2][basepos.y+j]>0)
                                                                if (defaultbfs[basepos.x+i2][basepos.y+j]<min)
                                                                {
                                                                    min=defaultbfs[basepos.x+i2][basepos.y+j];
                                                                    w.x=basepos.x+i2;
                                                                    w.y=basepos.y+j;
                                                                }
                                        mapbl[w.x][w.y]=1;
                                        op.targets.push_back(w);
                                        info2.gold-=info2.units[myunit[i]].level*30+50;
                                        info2.units[myunit[i]].pos=w;
                                        mapbl[info2.units[myunit[i]].pos.x][info2.units[myunit[i]].pos.y]=0;
                                        cmd.cmds.push_back(op);
                                        dayestatus[info2.units[myunit[i]].id]=0;
                                        qinding[info2.units[myunit[i]].id]=0;
                                    }
                        }
    if ((info2.gold>=500&&nowhero<3)||(info2.gold>=750&&nowhero==3))
    {
        nowhero++;
        int min=1000;
        int j;Pos w;
        for (i=-12;i<13;i++)
            for (j=-12;j<13;j++)
                if (i*i+j*j<=144)
                    if (basepos.x+i>=0&&basepos.x+i<=149&&basepos.y+j>=0&&basepos.y+j<=149)
                        if (mapbl[basepos.x+i][basepos.y+j]==0)
                            if (defaultbfs[basepos.x+i][basepos.y+j]>0)
                                if (defaultbfs[basepos.x+i][basepos.y+j]<min)
                                {
                                    min=defaultbfs[basepos.x+i][basepos.y+j];
                                    w.x=basepos.x+i;
                                    w.y=basepos.y+j;
                                }
        mapbl[w.x][w.y]=1;
        int nowren;
        if (nowhero==1) nowren=4;
        if (nowhero==2||nowhero==4) nowren=1;
        if (nowhero==3) nowren=2;
        buyhero(nowren,w,cmd);
        info2.gold-=500;
        if (nowhero==4) info2.gold-=250;
    }
    
    info2.gold-=info2.round/2+200;
    if (hashero>0)
        if (nowhero>=4)
        {
            for (i=0;i<myunit.size();i++)
            {
                PUnit j=info2.units[myunit[i]];
                if (dis2(basepos,j.pos)<=144)
                    if (j.isHero())
                        if (info2.gold>=50*j.level+100)
                        {
                            int t=j.level;
                            while (info2.gold>=50*t+100&&t<=5)
                            {
                                info2.gold-=50*t+100;
                                t++;
                                upgradehero(j,cmd);
                            }
                            
                        }
            }
            
        }
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    
    cmd.cmds.clear();
    memset(defvalue,0,sizeof(defvalue));
    info2=info;
    if (info.round==0) {
        nowhero=0;
        int i,j;
        for (i=0;i<150;i++)
            for (j=0;j<150;j++)
            {
                maph[i][j]=map.getHeight(i,j);
            }
        init(cmd);
    }
    turninit(cmd);
    // doing(cmd);
    if (info.round>0)baseoper(cmd);
    
    doing(cmd);
    cout<<"sb";
    /*if(info.round%120>60) DEFAULFPOS=enbasepos;
     if (info.round%120<=60) DEFAULFPOS=Pos(73,76);*/
    /* if (info.round==300) {
     
     enbasepos.x+=3-6*info.player;
     enbasepos.y+=15-30*info.player;
     }*/
}
int main(int argc, const char * argv[]) {
    
    Pos i=DEFAULFPOS;
    Pos j;
    vector<Pos> path;
    j.x=1;j.y=1;
    memset(maph,0,sizeof(maph));
    memset(mapbl,0,sizeof(mapbl));
    memset(defvalue,0,sizeof(defvalue));
    mapbl[72][76]=1;
    mapbl[72][74]=1;
    mapbl[70][71]=1;
    mapbl[73][77]=1;
    mapbl[73][75]=1;
    mapbl[74][75]=1;
    mapbl[75][76]=1;
    PCommand cmd;
    //  cout<<mapar[69][72][0]<<' '<<mapar[69][72][1];
    findroutine(i,j,36,path);
    for (int w=0;w<path.size();w++)
    {
        cout<<path[w].x<<' '<<path[w].y<<endl;
    }
    
    // insert code here...
    std::cout << "Hello, World!n";
    return 0;
}

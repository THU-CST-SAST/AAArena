#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <queue> 
#include <map>

using namespace std;
const int DEBUG = 0;
const char* FILE_NAME = "DEBUG_1.txt";
char HiddenTime[]="2016:5:2:17:30:00";    //緩扮寂岻朔喟垓膿佩烏危
int cute = 0;
const int cute_rate = 2;

//_______________________蕗苧_____________________________ 

bool large(double a,double b);
//登僅 a>b 
bool equal(double a,double b);
//登僅 a==b 
int getSkill(const string& name, const PUnit* ptr);
//資函室嬬和炎 
int getBuff(const string& name, const PUnit* ptr);
//資函buff和炎 
int getLon(Pos a, Pos b);
//卦指凧込禽鉦宣 
int longestDis(Pos p,int camp);
//卦指專唔camp嶄鉦p恷除議鉦宣 
int attackHp (const PUnit* target, const PUnit*);
//峺協汽了好似方峙 
int getHeroNum(int t);
//柴麻厘圭乎哂俛倖方 
double getRecoverRate(const PUnit* target);
//柴麻乎哂俛和指栽指僮曳箭 
int getRecoverHp(const PUnit* target);
//柴麻乎哂俛和指栽指僮 
int checkPos2(Pos p,PUnit* worker);
//殊臥毛怒円順
Pos runawayPos(PUnit* target);
//卦指target議speed袈律坪毛怒恷煮泣 
Pos jockeyPos(PUnit* target);
//卦指target議膨選宥触了泣 短嗤夸卦指-100-100 
bool operator<(Pos A,Pos B);
//弌噐 
Pos shrinkPos(Pos a,Pos b);
//b恠欺a 卦指仇夕坪泣a 
int checkHill(Pos p);
//殊臥p泣頁倦壓表貧 
int dangerRange(PUnit* ptr);
//辛嬬瓜蒸凋寄議袈律 
int inBaseRange(Pos p);
//児仇袈律坪 
int inBaseAttackRange(Pos p);
//契便児仇袈律坪 
int checkHammerAttack(PUnit* target,PUnit* ptr);
//殊臥頁倦勣聞喘嶷憾匯似 
int checkSacrifice(PUnit* target,PUnit* ptr);
//殊臥頁倦勣聞喘溝廣匯崟 
int moveTime(PUnit* ptr,double lon);
//ptr卞強lon俶勣指栽 
int moveTime(PUnit* ptr,Pos p);
//ptr卞強欺p俶勣指栽 
int greedWorth(PUnit* worker, PUnit* ptr);
//柴麻粍伉峙 
int getAtk(Pos p, PUnit* ptr);
//ptr壓p泣氏鞭欺議好似 

//_______________________窃&潤更悶_____________________________ 

struct Hidden_Strength_Class//咨茄/崙糞薦
{
	int Hidden_Type;
	int EndYear,EndMonth,EndDay,EndHour,EndMinute,EndSecond;//嶄峭扮寂
	int Year,Month,Day,Hour,Minute,Second;//喘噐芝村狼由扮寂号協扮粁坪塋俯聞喘寔糞糞薦
	void Stop(){while(true);}//嶄峭凋綜
	bool inHiddenTime()//登僅輝念扮寂頁倦壓咨茄糞薦扮寂岻坪
	{
		if(!cute)return false;
		if(Year!=EndYear)return Year>EndYear;
		if(Month!=EndMonth)return Month>EndMonth;
		if(Day!=EndDay)return Day>EndDay;
		if(Hour!=EndHour)return Hour>EndHour;
		if(Minute!=EndMinute)return Minute>EndMinute;
		return Second>EndSecond;
	}
	void getTime() 
	{ 
		Hidden_Type=rand()%100;
		time_t t = time(0); 
		char tmp[64];  
		strftime( tmp, sizeof(tmp), "%Y %m %d %X",localtime(&t) ); 
		sscanf(tmp,"%d %d %d %d:%d:%dn",&Year,&Month,&Day,&Hour,&Minute,&Second);
		sscanf(HiddenTime,"%d:%d:%d:%d:%d:%dn",&EndYear,&EndMonth,&EndDay,&EndHour,&EndMinute,&EndSecond);
	} 
	void check()//距喘議麼痕方
	{
		if(cute)
		{
			if(inHiddenTime()) cute=2;//Stop();;
		}
	}
}Hidden_;

struct Legal_Path_Logical{    //楚貸辞駅将泣鹿 
	int offset;
	Legal_Path_Logical():offset(8){}
	struct Node{Pos a,b;bool type;}nd;
	//貸辞潤泣type=1旗燕a葎駅将泣,type=0旗燕a,b嶄将狛匯倖軸辛 
	vector<Node>a[17][17];
	
	vector<Node>* operator()(int x,int y){ return &a[x+offset][y+offset]; }
	//距喘圭隈 
	static int cmp(const Pos &a,const Pos &b);
	void init();
	//圓侃尖 
}LPL;

class Shortest_Path_Class{//柴麻恷玉揃麼悶窃 
	private:
		short _index,round_index;    //index炎芝嚥round_index炎芝
		Pos q[30010];    //BFS錦双 
		Pos Scheme[MAP_SIZE][MAP_SIZE];    //芝村揃抄議念駁
		Pos Scheme_OneStep[MAP_SIZE][MAP_SIZE];    //芝村揃抄議販吭匯倖軟泣
		double dist[MAP_SIZE][MAP_SIZE];
		short pd_inq[MAP_SIZE][MAP_SIZE];    //_index炎芝
		short pd_round[MAP_SIZE][MAP_SIZE];    //round_index炎芝

		bool connection(const Pos &S,const Pos &T,PMap &a);
		//宥狛仇夕a議互業餓崙登協S嬬倦岷器T
		vector<Pos> connectionScheme(const Pos &S,const Pos &T,PMap &a);
		//公竃匯訳宥狛仇夕a議互業餓崙喇S岷器T議膨銭宥揃抄
		Pos findGoodPath(const vector<Pos>Start,const vector<Pos> &block,Pos Target=Pos(-1,-1));
		//深打block嬾悪參Start葎0鉦宣軟泣斤 畠夕/朕炎泣Target 恂BFS繍揃抄軟泣佚連贋崛Scheme才Scheme_OneStep
		//(單枠僉夲涙block泣,涙揃辛恠頁辛參僉block泣)侭嗤BFS欺議泣鹿贋刈噐pb_inq[]==_index
		vector<Pos> findOneStepScheme(Pos Start,Pos Target,const vector<Pos> &block);
		//儖孀匯訳喇Start欺Target匯化嬬欺器議膨銭宥揃抄(駅倬隠屬基宛贋壓才Scheme栽隈)

	public:
		vector<Pos>a;//喘噐贋刈巓円泣恫炎
		int round[MAP_SIZE][MAP_SIZE];//卆象輝念軟泣欺器恫炎議圓柴指栽方

		vector<Pos> findOneStepRange(Pos Start,int speed,const vector<Pos> &block);
		//卦指軟泣S竃窟speed堀業岻坪嬬欺器議泣鹿旺芝村崛a方怏(深打嬾悪泣鹿block)
		vector<Pos> findShortestPath(Pos Start,Pos Target,int speed,const vector<Pos> &block,const vector<Pos>&BanStays);
		//卦指喇Start欺Target堀業葎Speed扮音辛将block,音辛壓BanStays唯藻輝念指栽議卞強揃抄
		void build(Pos Start,int speed,const vector<Pos> &block);
		//功象軟泣堀業才嬾悪更夛畠蕉佚連(Hero喘)
		int distance(Pos Target,int speed);
		//O(n)柴麻輝念軟泣欺朕炎泣議浩柴指栽方,飛涙隈欺器卦指10000(距喘念駅倬build())
}SPC;

class Move_Control{
    //卞強陣崙窃(麼勣喘噐陣崙寄楚汽了卞強擬崑議触了)
	//聞喘圭隈耽指栽蝕兵扮init()繍僉夲卞強議汽了參式朕議仇push()指栽潤崩扮solve()揖匯窟僕凋綜
	private:
		struct Move_{const PUnit *p;Pos target;};
		vector<Move_>Heros;
		vector<vector<Pos>>blocks;
		vector<vector<Pos>>banstays;
	public:
		void init();
		//兜兵晒 
		void push(const PUnit *p,Pos target,const vector<Pos> &block,const vector<Pos> &ban);
		//紗泣 
		void InBanStay(Pos target,int dist);
		//繍俶箔双燕戦議侭嗤汽了現紗協鋤峭併秘target現除dist
		void solve();
		//峇佩 
}Move_C;

class Operations{    //荷恬窃
public:
	void opMining();
	//寡嶄嵩 
	void opAttack();
	//好似 
	void opAttackWild();
	//嬉勸 
	void opAttackObserver();
	//嬉凛 
	void opAttackWOD();
	//WinOrDie和好似 
	void opBaseAttack();
	//児仇好似 
	void opRunaway();
	//毛怒 
	void opRunawayWOD();
	//毛怒 
	void opLevelup();
	//幅雫 
	void opHammerAttack();
	//嶷憾匯似 
	void opHammerAttackWild();
	//斤勸講嶷憾匯似 
	void opSacrifice();
	//溝廣匯崟 
	void opSacrificeWild();
	//斤勸講溝廣匯崟 
	void opHammerAttackAndSacrifice();
	//嶷憾匯似塘栽溝廣匯崟 
	void opHammerAttackAndSacrifice2();
	//嶷憾匯似塘栽溝廣匯崟圭宛屈 
	void opBlink();
	//描 
	void action();
	//荷恬 
	void opBlinkDown();
	//描 
	void opGuardBase();
	//便社 
	void opGoDie();
	//僕棒 
	void opSetObserver();
	//峨凛 
	void opGuardMine();
	//便嵩 
}OPT;

class Strategy{    //貨待児窃 
public:
	virtual int countWorth() = 0;      //柴麻蝶嶽貨待議糞佩勺峙 
	virtual void work() = 0;           //糞宸嶽貨待 
	
	void setWorker(PUnit* worker);
	void setWorth(int worth);
	void setName(int name);
	
	PUnit* worker;
	PUnit* target;
	Pos targetP;
	
	int imp; 
	int worth;
	string name;
};

class StgAttack:public Strategy{    //好似蝶倖汽了議貨待 
public:
	StgAttack(PUnit* worker,PUnit* target,string name = "Attack");
	StgAttack(PUnit* worker,PUnit* target,Pos targetP,string name = "Attack");
	
	int countWorth();
	void work();
};

class StgAttackWild:public Strategy{    //好似蝶倖汽了議貨待 
public:
	StgAttackWild(PUnit* worker,PUnit* target,string name = "AttackWild");
	
	int countWorth();
	void work();
};

class StgAttackObserver:public Strategy{    //好似蝶倖汽了議貨待 
public:
	StgAttackObserver(PUnit* worker,PUnit* target,string name = "AttackObserver");
	
	int countWorth();
	void work();
};

class StgAttackWOD:public Strategy{    //溝廣匯崟彜蓑和好似蝶倖汽了議貨待 
public:
	StgAttackWOD(PUnit* worker,PUnit* target,string name = "AttackWOD");
	
	int countWorth();
	void work();
};

class StgBaseAttack:public Strategy{    //児仇好似蝶倖汽了議貨待 
public:
	StgBaseAttack(PUnit* worker,PUnit* target,string name = "BaseAttack");
	
	int countWorth();
	void work();
};

class StgMove:public Strategy{    //卞強蝶倖汽了議貨待 
public:
	StgMove(PUnit* worker,Pos targetP,string name = "Move");
	
	int countWorth();
	void work();
};

class StgGuardMine:public Strategy{    //便嵩議貨待 
public:
	StgGuardMine(PUnit* worker,Pos targetP,string name = "GuardMine");
	
	int countWorth();
	void work();
};

class StgGoDie:public Strategy{    //卞強蝶倖汽了議貨待 
public:
	StgGoDie(PUnit* worker,Pos targetP,string name = "GoDie");
	
	int countWorth();
	void work();
};

class StgRunaway:public Strategy{    //卞強蝶倖汽了議貨待 
public:
	StgRunaway(PUnit* worker,Pos targetP,string name = "Runaway");
	
	int countWorth();
	void work();
};

class StgRunawayWOD:public Strategy{    //卞強蝶倖汽了議貨待 
public:
	StgRunawayWOD(PUnit* worker,Pos targetP,string name = "RunawayWOD");
	
	int countWorth();
	void work();
};

class StgLevelup:public Strategy{    //幅雫蝶倖汽了議貨待 
public:
	StgLevelup(PUnit* worker,string name = "Levelup");
	
	int countWorth();
	void work();
};

class StgHammerAttack:public Strategy{    //聞喘 嶷憾嬉似 議貨待 
public:
	StgHammerAttack(PUnit* worker,PUnit* target,string name = "HammerAttack");
	StgHammerAttack(PUnit* worker,PUnit* target,Pos targetP, string name = "HammerAttack");
	
	int countWorth();
	void work();
};

class StgHammerAttackWild:public Strategy{    //聞喘 嶷憾嬉似勸講 議貨待 
public:
	StgHammerAttackWild(PUnit* worker,PUnit* target,string name = "HammerAttackWild");
	
	int countWorth();
	void work();
};

class StgSacrifice:public Strategy{    //聞喘 溝廣匯崟 議貨待 
public:
	StgSacrifice(PUnit* worker,string name = "Sacrifice");
	
	int countWorth();
	void work();
};

class StgSacrificeWild:public Strategy{    //聞喘 斤勸講溝廣匯崟 議貨待 
public:
	StgSacrificeWild(PUnit* worker,string name = "SacrificeWild");
	
	int countWorth();
	void work();
};

class StgBlink:public Strategy{    //聞喘 描 議貨待 
public:
	StgBlink(PUnit* worker,PUnit* target,string name = "Blink");
	StgBlink(PUnit* worker,Pos targetP,string name = "Blink");
	
	int countWorth();
	void work();
};

class StgBlinkDown:public Strategy{    //聞喘 和描 議貨待 
public:
	StgBlinkDown(PUnit* worker,Pos targetP,string name = "BlinkDown");
	
	int countWorth();
	void work();
};

class StgSetObserver:public Strategy{    //聞喘 峨凛 議貨待 
public:
	StgSetObserver(PUnit* worker,Pos targetP,string name = "SetObserver");
	
	int countWorth();
	void work();
};

class State{    //彜蓑窃 
public:
	int hp[10];       //飛孤指栽朔僮楚(瓜好似袈律坪黍繁) 
	int hp2[10];      //飛孤指栽朔僮楚(畠夕黍繁) 
	int restore;      //耽指栽指鹸僮楚 
	PUnit* mHero;
	
	State(PUnit* newHero,Pos p);
};

class HeroState{    //哂俛彜蓑窃 
public:
	vector<State*> heros;
	
	void clean();                                     //賠茅哂俛双燕 
	void addHero(PUnit* newHero);                     //耶紗仟哂俛 
	int getHp(PUnit* ptr, int round);                 //資函round指栽朔ptr僮楚 
	int deadRound(PUnit* ptr);                        //資函ptr鉦棒蘭指栽 10葎音棒 
	int deadRound(Pos p,PUnit* ptr);                  //資函ptr壓p泣棒蘭指栽 
	int getHp2(PUnit* ptr, int round);                //資函round指栽朔ptr僮楚 
	int deadRound2(PUnit* ptr);                       //資函ptr鉦棒蘭指栽 10葎音棒 
	int deadRound2(Pos p,PUnit* ptr);                 //資函ptr壓p泣棒蘭指栽 
}heroState;

class AIHero{     //斤哘耽倖哂俛議貨待畳貨
public:
	PUnit* mHero;
	vector<Strategy*> mStrategy;
	
	AIHero(PUnit* newHero);
	bool addStrategy(Strategy* newStrategy);      //耶紗仟議貨待 
	Shortest_Path_Class SPC;                      //恷玉揃狼由
	
	Strategy* getStrategy();         //卦指恷單貨待 
	void action();                   //序佩輝念議恷單貨待
	void move(Pos target,const vector<Pos>&block,const vector<Pos>&BanStays);
	//親僥卞強狼由block鋤峭将狛,BanStays鋤峭唯藻 
};

struct Gword{    //児云荷恬
public:
    const PMap &map;
	const PPlayerInfo *info;
	PCommand *cmd;
    const PUnit* selected;       //瓜僉嶄議汽了
	
	Gword(const PMap &_map, const PPlayerInfo&, PCommand &);
	//更夛痕方 
	~Gword();
	
	void pretreatment();
	//圓侃尖 
	void buyHero();
	//杭択哂俛 
    void selectUnit(const PUnit*);
	//僉嶄蝶匯倖汽了岻朔議荷恬辛參音勧汽了議歌方岷俊聞喘宸倖汽了 
	void move(Pos target, const PUnit* ptr);
	//卞強 
    void attack(const PUnit* target, const PUnit* = NULL);
    void attack(const int target, const PUnit* = NULL);
    //峺協蝶匯黍圭哂俛好似 
    void attackWild(const PUnit* target, const PUnit* = NULL);
    void attackWild(const int target, const PUnit* = NULL);
    //峺協蝶匯勸講好似 
    void hammerAttack(const PUnit* target, const PUnit* = NULL);
    void hammerAttack(const int target, const PUnit* = NULL);
    //峺協蝶匯黍圭哂俛聞喘嶷憾嬉似 
    void hammerAttackWild(const PUnit* target, const PUnit* = NULL);
    void hammerAttackWild(const int target, const PUnit* = NULL);
    //峺協蝶匯勸講聞喘嶷憾嬉似 
	Pos getCore(vector<PUnit*> &ptrs);
	//柴麻錦礼嶄伉泣 
	void bfsET(PUnit* ptr);
	//bfs黍繁錦礼 
    void buildET();
    //秀羨黍圭錦礼 
    void buildMT();
    //秀羨厘圭錦礼 
    void action();
    //侭嗤哂俛峇佩恷單貨待 
    
    void stgAttack(PUnit* target, PUnit* ptr);
    //耶紗好似畳貨 
    void stgAttack(PUnit* target, Pos targetP, PUnit* ptr);
    //耶紗児仇好似蒸凋畳貨 
    void stgAttackWild(PUnit* target, PUnit* ptr);
    //耶紗嬉勸貨待 
    void stgAttackObserver(PUnit* target, PUnit* ptr);
    //耶紗好似凛畳貨 
    void stgAttackWOD(PUnit* target, PUnit* ptr);
    //耶紗溝廣匯崟彜蓑好似畳貨 
    void stgBaseAttack(PUnit* target, PUnit* ptr);
    //耶紗児仇好似畳貨 
    void stgMove(const Pos target, PUnit* ptr);
    //耶紗卞強畳貨 
    void stgGuardMine(const Pos target, PUnit* ptr);
    //耶紗便嵩畳貨 
    void stgGoDie(const Pos target, PUnit* ptr);
    //耶紗僕棒貨待 
    void stgRunaway(const Pos target, PUnit* ptr);
    //耶紗毛怒畳貨 
    void stgRunawayWOD(const Pos target, PUnit* ptr);
    //耶紗毛蒸凋畳貨 
    void stgLevelup(PUnit* ptr);
    //耶紗幅雫畳貨 
    void stgHammerAttack(PUnit* target, PUnit* ptr);
    //耶紗嶷憾嬉似畳貨 
    void stgHammerAttack(PUnit* target, Pos targetP, PUnit* ptr);
    //耶紗嶷憾嬉似塘栽畳貨 
    void stgHammerAttackWild(PUnit* target, PUnit* ptr);
    //耶紗嶷憾嬉似勸講畳貨 
    void stgSacrifice(PUnit* ptr);
    //耶紗溝廣匯崟畳貨 
    void stgSacrificeWild(PUnit* ptr);
    //耶紗斤勸講溝廣匯崟畳貨 
    void stgBlink(PUnit* target, PUnit* ptr);
    void stgBlink(Pos target, PUnit* ptr);
    //耶紗描畳貨 
    void stgBlinkDown(Pos target, PUnit* ptr);
    //耶紗和描畳貨 
    void stgSetObserver(Pos target, PUnit* ptr);
    //耶紗峨凛貨待 
};

class Team{    //錦礼児窃 
public:
	Pos core;     //錦礼嶄伉 
	int worth;    //媾況薦
	vector<PUnit*> mHero;
	
	virtual void addHero(PUnit* ptr) = 0;
	virtual void countworth() = 0;
	virtual void clean() = 0;
};

class EnemyTeam:public Team{    //黍圭錦礼 
public:
	EnemyTeam(Pos p, vector<PUnit*> &newTeam);
	
	void addHero(PUnit* ptr);
	void countworth();
	void clean();
};

class MyTeam:public Team{    //厘圭錦礼 
public:
	EnemyTeam* target;
	
	MyTeam(EnemyTeam* targ, vector<PUnit*> &newTeam);
	
	void addHero(PUnit* ptr);
	void countworth();
	void runaway();
	int checkDanger(int t);
	void action();
	void clean();
};

class HisUnit{    //煽雰佚連 
public:
	int round;
	PUnit p;
	
	HisUnit():round(-1){} 
	void newUnit(const PUnit* ptr);
};

class Debuger{   //距編窃 
public:
	ofstream output;
	Debuger();
	
	void draw(int a);
	void draw(Pos a);
	void draw(const char *s);
	void draw(const string s);
	void draw(const PBuff &p);
	void draw(const PUnit &p);
	void draw(const PSkill &p);
	void draw(const Strategy *p);
	void draw(const AIHero *p);
	void draw(const PUnit *p, std::vector<Pos> &path);
	void draw(const PPlayerInfo *INFO);
	void draw(State *p);
	void draw(HeroState *p);
	void draw(vector<EnemyTeam> &p);
	void draw(vector<MyTeam> &p);
}debuger;

//_______________________畠蕉延楚協吶_____________________________

Gword* gword;   //糞箭晒 
Console* console;

const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
const int ObserverId = 13;
const int Hero_worth[6] = {250, 350, 500, 700, 950, 1250};
const int HERO_ID[] = {3, 4, 5, 6};
const int BUY_HERO[8] = {3, 0, 2, 1, 0, 2, 0, 0}; //哂俛杭択乏會 
const Pos BUY_HERO_POS[2][8] = {{Pos(19,16),Pos(18,16),Pos(17,16),Pos(16,16),Pos(19,16),Pos(19,16),Pos(19,16),Pos(19,16)},
								{Pos(129,135),Pos(130,135),Pos(131,135),Pos(132,135),Pos(129,135),Pos(129,135),Pos(129,135),Pos(129,135)}};
								
const double zero = 1e-6;
const int MAX_DIST = MAP_SIZE*MAP_SIZE*MAP_SIZE;  //恷寄鉦宣 
const int MAX_ID = 100;
const int MAX_STEP = 20;
const int Round_runaway = 10;
const int Alert_range = 36;
const int Alert_range_mine = 400;
const int callBackRange = 1000;
const int MILITARY_BASE_LARGE_RANGE = 2500;
const int SetOberverRange = 16;
const int MineRange = 16; 

const int imp_StgMove = 1;
const int imp_StgAttackObserver = 2;
const int imp_StgAttackWild = 3;
const int imp_StgHammerAttackWild = 4;
const int imp_StgSacrificeWild = 5; 
const int imp_StgGuardMine = 6; 
const int imp_StgAttackWaitRevive = 7;
const int imp_StgAttack = 8;
const int imp_StgAttackHammer = 9;
const int imp_StgAttackBerserker = 10;
const int imp_StgAttackInRange = 11;
const int imp_StgAttackHammerInRange = 12;
const int imp_StgSetObserver = 13;
const int imp_StgGoDie = 14;
const int imp_StgHammerAttack = 15;
const int imp_StgHammerAttackCooperate = 16;
const int imp_StgSacrifice = 17;
const int imp_StgBlinkDown = 18;
const int imp_StgBlink = 19;
const int imp_StgLevelup = 20;
const int imp_StgRunawayWOD = 21;
const int imp_StgRunaway = 22;
const int imp_StgBlink_Runaway = 23;
const int imp_StgBlink_Runaway_Hill = 24;
const int imp_StgAttack_WinOrDie = 25;
const int imp_StgAttack_WinOrDie_InRange = 26;
const int imp_StgAttack_WinOrDie_InRange_Kill = 27;
const int imp_StgBaseAttack = 28;
const int imp_StgBaseAttack_WinOrDie = 29;
//貨待嶷勣業及匯購囚忖 

const int num_cute = 1;
const int cute_imp[num_cute] = {19};
//沢暖貨待鹿栽 

Pos mine_pos[] = {Pos(74, 75), Pos(43, 61), Pos(43, 89), Pos(107, 61), Pos(107, 89), Pos(20, 140), Pos(130, 10)};
Pos patrol_pos[2][2] = {{Pos(10, 40), Pos(40, 10)}, {Pos(140, 110), Pos(110, 140)}};
Pos Step[9] = {Pos(-1,0), Pos(0,1), Pos(0,-1), Pos(1,0), Pos(0,0), Pos(-1,1), Pos(-1,-1), Pos(1,-1), Pos(1,1)};

int countF = 0, countR = 0, countB = 0;
int countRound = 0;                                            //輝念指栽 
int GuardingMine;                                              //嶄嵩頁倦嗤繁契便 
int baseWeak;                                                  //児仇頁倦火僮 
int myHeroWorth, enemyHeroWorth;                               //褒圭哂俛悳勺峙 
int exploitMine[2];                                            //繍蝕寡議嵩 
int blockMap[MAP_SIZE][MAP_SIZE];                              //嬾悪泣仇夕 countR*2-1 葎輝念指栽嬾悪 countR*2 葎和指栽嬾悪 
int bfsMap2[MAP_SIZE][MAP_SIZE];                               //鴻朴仇夕2 
Pos bfsQ2[MAP_SIZE * MAP_SIZE + 1];                            //鴻朴錦双2 
int round_runaway[MAX_ID];                                     //複噫毛怒指栽 
int calledBack[MAX_ID];                                        //頁倦厮瓜孰指 
int Dying[MAX_ID];                                             //頁倦肇僕棒 
int beloneTeam[MAX_ID];                                        //奉噐錦礼 
int runawayRound[MAX_ID];                                      //貧肝毛怒指栽 
int HammerAttackRound[MAX_ID];                                 //貧肝嶷憾嬉似指栽 
int SacrificeRound[MAX_ID];                                    //貧肝溝廣匯崟指栽 
int attackedRound[MAX_ID];                                     //貧肝裡蒸凋瓜好似指栽 
int attackedRound2[MAX_ID];                                    //貧肝好似裡蒸凋指栽 
HisUnit hisUnit[MAX_ID];                                       //煽雰佚連 
HisUnit hisUnit2[MAX_ID];                                      //煽雰佚連 

PUnit myBase;
vector<AIHero> aiHeros;              //厘圭哂俛畳貨 
vector<PUnit> myHeros;               //厘圭哂俛 
vector<PUnit> enemyHis;              //煽雰黍圭哂俛 
vector<PUnit> enemyHeros;            //黍圭哂俛 
vector<PUnit> enemyObserver;         //黍圭凛 
vector<PUnit> nextEnemy;             //和指栽黍繁彜蓑 
vector<PUnit> wild;                  //勸講彜蓑 
vector<PUnit> nextWild;              //和指栽勸講彜蓑 
vector<PUnit> mines;                 //嵩 
vector<MyTeam> myTeam;               //厘圭錦礼 
vector<EnemyTeam> enemyTeam;         //黍圭錦礼 
vector<Strategy*> allStrategy;       //畠何畳貨 

const int INF=0x3fffffff;
const double eps=1e-8;
const vector<Pos> EmptyPosVector;
const Pos EmptyPos = Pos();
vector<Pos> BLOCK,BanStay;    //嬾悪鯉嚥鋤峭併秘鯉 
PMap MAP;

//_______________________Legal_Path_Logical_____________________________

int Legal_Path_Logical::cmp(const Pos &a,const Pos &b){
	return a.x*a.x+a.y*a.y<b.x*b.x+b.y*b.y;
}

void Legal_Path_Logical::init(){
	vector<Pos>b;
	int i;
	Pos S(0,0),T,M;
	for(T.x=-8;T.x<=8;T.x++)
		for(T.y=-8;T.y<=8;T.y++){
			//柴麻楚T議貸辞准泣
			b.clear();
			for(M.x=min(T.x,0);M.x<=max(T.x,0);M.x++)
				for(M.y=min(T.y,0);M.y<=max(T.y,0);M.y++)
					if((M.x==0&&M.y==0)||checkOnLine(S,T,M))b.push_back(M);
			sort(b.begin(),b.end(),cmp);
			a[T.x+offset][T.y+offset].clear();
			for(i=0;i<b.size();){
				int bo=1;
				if(i+1<b.size()) 
				if (dis2(b[i],b[i+1])>1){
					//貸辞辛僉泣
					bo=0;
					nd.a=b[i];
					nd.b=b[i+1];
					nd.type=0;
					a[T.x+offset][T.y+offset].push_back(nd);
					i+=2;
				}
				if (bo){
					//貸辞駅将泣
					nd.a=b[i];
					nd.type=1;
					a[T.x+offset][T.y+offset].push_back(nd);
					i++;
				}
			}
		}
}

//_______________________Shortest_Path_Class_____________________________

bool Shortest_Path_Class::connection(const Pos &S,const Pos &T,PMap &a)
{
	if (!checkPos(T)) return 0;
	vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
	//printf("  connection:(%d,%d)->(%d,%d)n",S.x,S.y,T.x,T.y);
	//for(int i=0;i<b->size();i++)printf("   type=%d a(%d,%d) b(%d,%d)n",(*b)[i].type,(*b)[i].a.x,(*b)[i].a.y,(*b)[i].b.x,(*b)[i].b.y);
	bool Pa=true,Pb=false;
	for(int i=1;i<b->size();i++)
	{
		//printf("   i=%dn",i);
		if((*b)[i].type==1)
		{
			if(Pa && abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
			{
				Pa=true;
				Pb=false;
			}
			else if(Pb && abs(a[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
			{
				Pa=true;
				Pb=false;
			}
			else return false;
		}
		else
		{
			Pa=(abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
			Pb=(abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
			if(!(Pa||Pb))return false;
		}
	}
	return true;
}

vector<Pos> Shortest_Path_Class::connectionScheme(const Pos &S,const Pos &T,PMap &a)
{
	vector<Pos>re;
	re.clear();
	vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
	//printf("LPL: %d,%d %dn",(T-S).x,(T-S).y,b->size());
	bool Pa=true,Pb=false;
	re.push_back(S);
	for(int i=1;i<b->size();i++)
	{
		if((*b)[i].type==1)
		{
			if(Pa && abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
			{
				Pa=true;
				Pb=false;
				if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].a);
				re.push_back(S+(*b)[i].a);
			}
			else if(Pb && abs(a[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
			{
				Pa=true;
				Pb=false;
				if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].b);
				re.push_back(S+(*b)[i].a);
			}
			else return EmptyPosVector;
		}
		else
		{
			Pa=(abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
			Pb=(abs(a[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-a[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
			if(!(Pa||Pb))return EmptyPosVector;
		}
	}/*
	printf("S:%d,%d T:%d,%dn",S.x,S.y,T.x,T.y);
	printf("b size:%dn",b->size());
	printf("re2 size:%dn",re.size());*/
	return re;
}

Pos Shortest_Path_Class::findGoodPath(const vector<Pos>Start,const vector<Pos> &block,Pos Target)
{
	vector<Pos>Block_Start_Save;//贋刈短嗤制婢議嬾悪泣潤崩朔嶷仟制婢
	Pos S,T,res;
	int min_dis = MAP_SIZE*MAP_SIZE*MAP_SIZE;
	++_index;
	for(int i=0;i<block.size();i++)
	if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
		MAP[block[i].x][block[i].y]+=100;
	int l=0,r=-1,dir_ord[4]={0,1,2,3};
	for(int i=0;i<Start.size();i++)
	{
		pd_inq[Start[i].x][Start[i].y]=_index;
		Scheme_OneStep[Start[i].x][Start[i].y]=Start[i];
		q[++r]=Start[i];
	}
	while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
	{
		S=q[l++];
		if(MAP[S.x][S.y]>=99)
		{
			Block_Start_Save.push_back(S);
			continue;
		}
		if (dis2(S, Target) < min_dis){
			res = S;
			min_dis = dis2(S, Target);
		}
		random_shuffle(dir_ord, dir_ord+4);
		for(int k=0;k<4;k++)
		{
			T.x=S.x+dir[dir_ord[k]][0];
			T.y=S.y+dir[dir_ord[k]][1];
			if(checkPos(T))
			  if (pd_inq[T.x][T.y]!=_index)
				if(MAP[T.x][T.y]>=99 || abs(MAP[S.x][S.y]-MAP[T.x][T.y])<=MOVE_HEIGHT_DELTA)
				{
					pd_inq[T.x][T.y]=_index;
					Scheme[T.x][T.y]=S;
					Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
					q[++r]=T;
				}
		}
	}
	for(int i=0;i<block.size();i++)
		if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
		MAP[block[i].x][block[i].y]-=100;
	/*	
	if((Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
		if(Block_Start_Save.size())
		{
			l=0,r=-1;
			for(int i=0;i<Block_Start_Save.size();i++)q[++r]=Block_Start_Save[i];
				while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))//嶷仟斤block泣BFS
				{
					S=q[l++];
					if (dis2(S, Target) < min_dis)
					{
						res = S;
						min_dis = dis2(S, Target);
					}
					random_shuffle(dir_ord, dir_ord+4);
					for(int k=0;k<4;k++)
					{
						T.x=S.x+dir[dir_ord[k]][0];
						T.y=S.y+dir[dir_ord[k]][1];
						if(checkPos(T) && pd_inq[T.x][T.y]!=_index)
							if(abs(MAP[S.x][S.y]-MAP[T.x][T.y])<=MOVE_HEIGHT_DELTA)
							{
								pd_inq[T.x][T.y]=_index;
								Scheme[T.x][T.y]=S;
								Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
								q[++r]=T;
							}
					}
				}
		}*/
	return res;
}

vector<Pos> Shortest_Path_Class::findOneStepScheme(Pos Start,Pos Target,const vector<Pos> &block)
{
	vector<Pos>re;
	re.clear();
	for(int i=0;i<block.size();i++)
		if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
		MAP[block[i].x][block[i].y]+=100;

	for(;Target!=Start;Target=Scheme[Target.x][Target.y])
	{
		vector<Pos>a=connectionScheme(Target,Scheme[Target.x][Target.y],MAP);
		//printf("%d,%d:%d ",Target.x,Target.y,a.size());
		a.pop_back();
		for(int i=0;i<a.size();i++)re.push_back(a[i]);/*
		if(re.size()>20000)
		{
			printf("findOneStepScheme Error!!! Start=(%d,%d) Target=(%d,%d) ",Start.x,Start.y,Target.x,Target.y);
			printf("  vector:");for(int j=0;j<20;j++)printf("(%d,%d)",re[j].x,re[j].y);
			printf("nScheme:n");
			for(int x=Start.x-5;x<=Start.x+5;x++,cout<<endl)
				for(int y=Start.y-5;y<=Start.y+5;y++)
					if(checkPos(Pos(x,y)))printf("(% 3d,% 3d)",Scheme[x][y].x,Scheme[x][y].y);
					else printf("(///,///)");
		}*/
	}
	//puts("");
	re.push_back(Start);
	reverse(re.begin(),re.end());
	//printf("re size: %dn",re.size());
	for(int i=0;i<block.size();i++)
		if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
		MAP[block[i].x][block[i].y]-=100;
	return re;
}
		
vector<Pos> Shortest_Path_Class::findOneStepRange(Pos Start,int speed,const vector<Pos> &block)
{
	++_index;
	for(int i=0;i<block.size();i++)
	{
		if(block[i].x!=Start.x||block[i].y!=Start.y)
			MAP[block[i].x][block[i].y]+=100;
	}
	int l=0,r=0;
	Pos S,T,O;
	for(O.x=-(int)sqrt(speed);O.x<=(int)sqrt(speed);O.x++)
		for(O.y=-(int)sqrt(speed-O.x*O.x);O.y<=(int)sqrt(speed-O.x*O.x);O.y++)
		{
			T=Start+O;
			if(checkPos(T))dist[T.x][T.y]=INF;
		}
	dist[Start.x][Start.y]=0;
	q[0]=Start;pd_inq[Start.x][Start.y]=_index;
	while(l<=r)
	{
		S=q[l++];
		if(MAP[S.x][S.y]>=99)continue;
		pd_inq[S.x][S.y]=0;
		for(O.x=-(int)sqrt(speed);O.x<=(int)sqrt(speed);O.x++)
			for(O.y=-(int)sqrt(speed-O.x*O.x);O.y<=(int)sqrt(speed-O.x*O.x);O.y++)
			{
				T=S+O;
				if(checkPos(T))
				if (connection(S, T, MAP))//!!!connection?
				{
					if(dist[S.x][S.y]+sqrt(dis2(S,T))<=sqrt(speed)+eps && dist[S.x][S.y]+sqrt(dis2(S,T))<dist[T.x][T.y]-eps)
					{
						//bool isBlock=(MAP[T.x][T.y]>=99);
						//if(isBlock)MAP[T.x][T.y]-=100;
						if(connection(S,T,MAP))
						{
							dist[T.x][T.y]=dist[S.x][S.y]+sqrt(dis2(S,T));
							Scheme[T.x][T.y]=S;
							if(pd_inq[T.x][T.y]!=_index)
							{
								pd_inq[T.x][T.y]=_index;
								q[++r]=T;
							}
						}
						//if(isBlock)MAP[T.x][T.y]+=100;
					}
				}
			}
	}
	a.clear();
	for(int i=0;i<=r;i++)
	if(MAP[q[i].x][q[i].y]<=99) a.push_back(q[i]);
	for(int i=0;i<block.size();i++)
	{
		if(block[i].x!=Start.x||block[i].y!=Start.y)
			MAP[block[i].x][block[i].y]-=100;
	}
	random_shuffle(a.begin(),a.end());
	return a;
}

vector<Pos> Shortest_Path_Class::findShortestPath(Pos Start,Pos Target,int speed,const vector<Pos> &block,const vector<Pos>&BanStays=EmptyPosVector)
{
	int i;
	vector<Pos>around=findOneStepRange(Start,speed,block);
	//printf("around size:%dn",around.size());
	for(i=0;i<around.size();i++)
		if(around[i]==Target)
			break;
	if(i<around.size())
	{
		//匯化辛器
		return findOneStepScheme(Start,Target,block);
	}
	else
	{
		//匯化音辛器
		vector<Pos>around_save=around;
		vector<Pos>scheme_save(around);
		for(i=0;i<scheme_save.size();i++)scheme_save[i]=Scheme[scheme_save[i].x][scheme_save[i].y];
		map<Pos,bool>hash;
		for(i=0;i<BanStays.size();i++)hash[BanStays[i]]=true;
		for(i=0;i<around.size();)
		if(around[i]!=Start&&around[i]!=Target)
		{
			if(hash.find(around[i])!=hash.end())
			{
				swap(around[i],around[(int)around.size()-1]);
				around.pop_back();
			}else i++;
		}else i++;
		
		vector<Pos> block_save(block);
		for(i=0;i<BanStays.size();i++)block_save.push_back(BanStays[i]);
		Target = findGoodPath(around,block_save,Target);
		if(pd_inq[Target.x][Target.y]!=_index) return EmptyPosVector;
		Pos OneStep=Scheme_OneStep[Target.x][Target.y];
		
		for(i=0;i<around_save.size();i++)Scheme[around_save[i].x][around_save[i].y]=scheme_save[i];
		//printf("%d,%d %d,%dn",Start.x,Start.y,OneStep.x,OneStep.y);
		return findOneStepScheme(Start,OneStep,block);
	}
}
		
void Shortest_Path_Class::build(Pos Start,int speed,const vector<Pos> &block=EmptyPosVector)
{
	for(int i=0;i<MAP_SIZE;i++)
		for(int j=0;j<MAP_SIZE;j++)
			Scheme[i][j]=EmptyPos;
	round_index++;
	vector<Pos>around;
	findOneStepRange(Start,speed,block);
	around.push_back(Start);
	pd_round[Start.x][Start.y]=round_index;
	round[Start.x][Start.y]=0;
	findGoodPath(around,block);
	Scheme[Start.x][Start.y]=Pos(-100,-100);
}

int Shortest_Path_Class::distance(Pos Target,int speed)
{
	if(Scheme[Target.x][Target.y]==EmptyPos)return 10000;
	if(pd_round[Target.x][Target.y]==round_index)return round[Target.x][Target.y];
	int re=0;
	Pos last;
	for(Pos now=Target;checkPos(now);last=now,now=Scheme[now.x][now.y])
	{
		if(dis2(Target,now)>speed)
		{
			re=distance(last,speed)+1;
			pd_round[Target.x][Target.y]=round_index;
			round[Target.x][Target.y]=re;
			return re;
		}
	}
	pd_round[Target.x][Target.y]=round_index;
	round[Target.x][Target.y]=1;
	return 1;
}

//_______________________Operations_____________________________

void Operations::opMining(){
    for (int i=0;i<myHeros.size();i++){
    	if (baseWeak){
    		if (countRound%20<10) gword->stgMove(patrol_pos[console->camp()][0], &myHeros[i]);
    		else gword->stgMove(patrol_pos[console->camp()][1], &myHeros[i]);
    	}else{
    		if (myHeros.size()>=7 && GuardingMine) gword->stgMove(mine_pos[exploitMine[console->camp()]], &myHeros[i]);
    		else gword->stgMove(mine_pos[0], &myHeros[i]);
		}
    	//gword->stgMove(Pos(MAP_SIZE-1,75), &myHeros[i]);
    }
}

void Operations::opGuardMine(){
    for (int i=0;i<myHeros.size();i++){
		if (myHeros[i].typeId==HERO_ID[3]){
			gword->stgGuardMine(mine_pos[0], &myHeros[i]);
	    }
	    if (myHeros[i].typeId==HERO_ID[1]){
	    	
	    }
	}
}

void Operations::opGoDie(){
    for (int i=0;i<myHeros.size();i++)
    if (Dying[myHeros[i].id]){
    	for (int j=1;j<7;j++) gword->stgGoDie(mine_pos[j], &myHeros[i]);
    }
}

void Operations::opAttack(){/*
    for (int i=0;i<myHeros.size();i++)
    for (int j=0;j<nextEnemy.size();j++)
	if (dis2(myHeros[i].pos,nextEnemy[j].pos) <= Alert_range || inBaseAttackRange(nextEnemy[j].pos)){
    	for (int k=0;k<myHeros.size();k++) gword->stgAttack(&nextEnemy[j], &myHeros[k]);
	}*/
}

void Operations::opAttackWild(){
    for (int i=0;i<myHeros.size();i++)
    for (int j=0;j<nextWild.size();j++){
    	gword->stgAttackWild(&nextWild[j], &myHeros[i]);
    }
}

void Operations::opAttackObserver(){
    for (int i=0;i<myHeros.size();i++)
    for (int j=0;j<enemyObserver.size();j++)
    if (dis2(myHeros[i].pos, enemyObserver[j].pos)<=myHeros[i].view){
    	gword->stgAttackObserver(&enemyObserver[j], &myHeros[i]);
    }
}

void Operations::opAttackWOD(){
    for (int i=0;i<myHeros.size();i++)
	if (console->getBuff("WinOrDie", &myHeros[i]) != NULL){
		int inRange = 0;
		int min_dis = MAX_DIST;
		PUnit* targ = NULL;
    	for (int j=0;j<nextEnemy.size();j++)
    	if (dis2(myHeros[i].pos, nextEnemy[j].pos) <= myHeros[i].range){
			gword->stgAttackWOD(&nextEnemy[j], &myHeros[i]);
			inRange = 1;
		}else if (dis2(myHeros[i].pos, nextEnemy[j].pos) < min_dis){
			min_dis = dis2(myHeros[i].pos, nextEnemy[j].pos);
			targ = &nextEnemy[j];
		}
		if (targ != NULL)
		if (!inRange/* && targ->range <= myHeros[i].range*/) gword->stgAttackWOD(targ, &myHeros[i]);   //delete range<?
	}
}

void Operations::opBaseAttack(){
    for (int i=0;i<nextEnemy.size();i++)
    if (inBaseRange(nextEnemy[i].pos)){
    	gword->stgBaseAttack(&nextEnemy[i], &myBase);
    }
}

void Operations::opRunaway(){/*
	for (int i=0;i<myHeros.size();i++)
	if (!inBaseRange(myHeros[i].pos)){
		int dead = heroState.deadRound(&myHeros[i]);
	    if (dead <= 3 || (round_runaway[myHeros[i].id] && myHeros[i].hp < myHeros[i].max_hp/3)){
	    	if (dead <= 3 && myHeros[i].hp < myHeros[i].max_hp/3){
				round_runaway[myHeros[i].id] = Round_runaway;
				Dying[myHeros[i].id] = 1;
			}
    		for (int j=0;j*j<=myHeros[i].speed;j++)
    		for (int k=0;k*k<=myHeros[i].speed;k++)
			if (dis2(Pos(0, 0), Pos(j, k)) <= myHeros[i].speed){
    			if (checkPos2(myHeros[i].pos + Pos(j, k), &myHeros[i]))
					gword->stgRunaway(myHeros[i].pos + Pos(j, k), &myHeros[i]);
    			if (checkPos2(myHeros[i].pos + Pos(j, -k), &myHeros[i]))
					gword->stgRunaway(myHeros[i].pos + Pos(j, -k), &myHeros[i]);
    			if (checkPos2(myHeros[i].pos + Pos(-j, k), &myHeros[i]))
					gword->stgRunaway(myHeros[i].pos + Pos(-j, k), &myHeros[i]);
    			if (checkPos2(myHeros[i].pos + Pos(-j, -k), &myHeros[i]))
					gword->stgRunaway(myHeros[i].pos + Pos(-j, -k), &myHeros[i]);
			}
   		}
    }*/
}

void Operations::opRunawayWOD(){
	for (int i=0;i<nextEnemy.size();i++)
	if (console->getBuff("WinOrDie", &nextEnemy[i])!=NULL && console->getBuff("Dizzy", &nextEnemy[i])==NULL && 
	console->getBuff("WaitRevive", &nextEnemy[i])==NULL){
		int bo=1;
		for (int j=0;j<myHeros.size();j++)
		if (dis2(nextEnemy[i].pos, myHeros[j].pos)<=nextEnemy[i].range) bo=0;
		
		if (bo)
    	for (int j=0;j<myHeros.size();j++)
		if (!inBaseRange(myHeros[j].pos))
    	if (dis2(nextEnemy[i].pos, myHeros[j].pos)<=dangerRange(&nextEnemy[i])){
    		for (int k=-sqrt(myHeros[j].speed);k<=sqrt(myHeros[j].speed);k++)
    		for (int l=-sqrt(myHeros[j].speed);l<=sqrt(myHeros[j].speed);l++)
    		if (dis2(Pos(0,0), Pos(k,l))<=myHeros[j].speed && checkPos(myHeros[j].pos+Pos(k,l)))
    			gword->stgRunawayWOD(myHeros[j].pos+Pos(k,l),&myHeros[j]);
    	}
    }
}

void Operations::opLevelup(){
    if(myHeros.size() == HERO_LIMIT){/*
        PUnit* lowest_level_hero=NULL;
        int tmp_level = HERO_LEVEL_LIMIT - 1,mindis = MAX_DIST;
        for(int i = 0; i < myHeros.size(); ++i){
            if(myHeros[i].level < tmp_level || (myHeros[i].level == tmp_level && dis2(MILITARY_BASE_POS[console->camp()], myHeros[i].pos)<mindis))
            {
                 tmp_level = myHeros[i].level;
                 mindis=dis2(MILITARY_BASE_POS[console->camp()], myHeros[i].pos);
                 lowest_level_hero = &myHeros[i];
            }
        }
        if (lowest_level_hero != NULL && console->gold() > console->levelUpCost(tmp_level)){
    		gword->stgLevelup(lowest_level_hero);
        }*/
        int gold=console->gold();
        if (myBase.hp<myBase.max_hp) gold-=1200;
        for(int i = 0; i < myHeros.size(); ++i)
        if (dis2(MILITARY_BASE_POS[console->camp()], myHeros[i].pos) < MILITARY_BASE_RANGE)
		for (int j=0;myHeros[i].level+j<5;j++)
		if (gold>=console->levelUpCost(myHeros[i].level+j)){
			console->buyHeroLevel(&myHeros[i]);
			gold-=console->levelUpCost(myHeros[i].level+j);
		}
    }
}

void Operations::opHammerAttack(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[0] && myHeros[i].canUseSkill("HammerAttack")){
    	for (int j=0;j<nextEnemy.size();j++){
    		if(dis2(myHeros[i].pos, nextEnemy[j].pos) <= HAMMERATTACK_RANGE && checkHammerAttack(&nextEnemy[j], &myHeros[i])){
    			//puts("666");
    			gword->stgHammerAttack(&nextEnemy[j], &myHeros[i]);
    		}
    	}
	}
}

void Operations::opHammerAttackWild(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[0] && myHeros[i].canUseSkill("HammerAttack")){
    	for (int j=0;j<nextWild.size();j++){
    		if(dis2(myHeros[i].pos, nextWild[j].pos) <= HAMMERATTACK_RANGE){
    			gword->stgHammerAttackWild(&nextWild[j], &myHeros[i]);
    		}
    	}
	}
}

void Operations::opSacrifice(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[2] && myHeros[i].canUseSkill("Sacrifice")){
		int safe = 1;
    	for (int j=0;j<enemyHeros.size() && safe;j++)  //殊臥頁倦芦畠 
    	if (dis2(myHeros[i].pos, enemyHeros[j].pos) <= enemyHeros[j].range)
    	if (console->getBuff("Dizzy", &enemyHeros[j]) == NULL && console->getBuff("WaitRevive", &enemyHeros[j]) == NULL){
    		for (int k=0;k<enemyHeros[j].skills.size();k++)
			if (enemyHeros[j].skills[k].typeId == 0){
				if (enemyHeros[j].skills[k].cd == 0){
					safe = 0;
					break;
				}
			}
    	}
    	
    	int nEnemy=0;
    	if (safe || inBaseRange(myHeros[i].pos))
		for (int j=0;j<myHeros[i].skills.size();j++)
		if (myHeros[i].skills[j].typeId == 0 && myHeros[i].skills[j].cd <= 1){
    		for (int k=0;k<nextEnemy.size();k++){
    			if(dis2(myHeros[i].pos, nextEnemy[k].pos) <= myHeros[i].range) ++nEnemy;
    			
    			if (checkSacrifice(&nextEnemy[k], &myHeros[i])){
    				gword->stgSacrifice(&myHeros[i]);
    				break;
    			}
    		}
    		break;
		}
		
		if (SacrificeRound[myHeros[i].id]!=countR && nEnemy>1) gword->stgSacrifice(&myHeros[i]);
	}
}

void Operations::opHammerAttackAndSacrifice(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[2] && myHeros[i].canUseSkill("Sacrifice") && SacrificeRound[myHeros[i].id]!=countRound && 
	runawayRound[myHeros[i].id]!=countRound){
		int bo=1;
		for (int j=0;j<myHeros[i].skills.size();j++)
		if (myHeros[i].skills[j].typeId == 0 && myHeros[i].skills[j].cd <= 1) bo=0;
		if (bo) continue;
		
		int nDanger = 0;   //好堀1繁方
		PUnit* pDanger;
		 
    	for (int j=0;j<enemyHeros.size();j++)  //殊臥頁倦芦畠 
    	if (dis2(myHeros[i].pos, enemyHeros[j].pos) <= enemyHeros[j].range)
    	if (console->getBuff("Dizzy", &enemyHeros[j]) == NULL && console->getBuff("WaitRevive", &enemyHeros[j]) == NULL){
    		for (int k=0;k<enemyHeros[j].skills.size();k++)
			if (enemyHeros[j].skills[k].typeId == 0 && enemyHeros[j].skills[k].maxCd == 1){
				++nDanger;
				pDanger=&enemyHeros[j];
			}
    	}
    	
    	if (nDanger==1){
    		for (int j=0;j<myHeros.size() && SacrificeRound[myHeros[i].id]!=countR;j++)
			if (myHeros[j].typeId == HERO_ID[0] && myHeros[j].canUseSkill("HammerAttack") && HammerAttackRound[myHeros[j].id]!=countRound && 
			runawayRound[myHeros[j].id]!=countRound && dis2(myHeros[j].pos, pDanger->pos) <= HAMMERATTACK_RANGE){
    			int nEnemy=0;
    			for (int k=0;k<nextEnemy.size() && SacrificeRound[myHeros[i].id]!=countR;k++)
    			if(dis2(myHeros[i].pos, nextEnemy[k].pos) <= myHeros[i].range){
					++nEnemy;
					if (heroState.deadRound(&nextEnemy[k])>2){
    					gword->stgSacrifice(&myHeros[i]);
    					gword->stgHammerAttack(pDanger, Pos(1,1),&myHeros[j]);
    				}
    			}
    			
				if (SacrificeRound[myHeros[i].id]!=countR && nEnemy>1){
					gword->stgSacrifice(&myHeros[i]);
    				gword->stgHammerAttack(pDanger, Pos(1,1),&myHeros[j]);
				}
			}
    	}
	}
}

void Operations::opHammerAttackAndSacrifice2(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[2] && myHeros[i].canUseSkill("Sacrifice") && SacrificeRound[myHeros[i].id]!=countRound && 
	runawayRound[myHeros[i].id]!=countRound){
		int safe = 1;
    	for (int j=0;j<enemyHeros.size() && safe;j++)  //殊臥頁倦芦畠 
    	if (dis2(myHeros[i].pos, enemyHeros[j].pos) <= enemyHeros[j].range)
    	if (console->getBuff("Dizzy", &enemyHeros[j]) == NULL && console->getBuff("WaitRevive", &enemyHeros[j]) == NULL){
    		for (int k=0;k<enemyHeros[j].skills.size();k++)
			if (enemyHeros[j].skills[k].typeId == 0){
				if (enemyHeros[j].skills[k].cd == 0){
					safe = 0;
					break;
				}
			}
    	}
    	
    	if (safe){
    		int max_hp=0;
    		PUnit* target=NULL;
    		for (int k=0;k<nextEnemy.size();k++)
    		if (moveTime(&myHeros[i], nextEnemy[k].pos)<=2)
    		for (int j=0;j<myHeros.size();j++)
			if (myHeros[j].typeId == HERO_ID[0] && myHeros[j].canUseSkill("HammerAttack") && HammerAttackRound[myHeros[j].id]!=countRound && 
			runawayRound[myHeros[j].id]!=countRound && dis2(myHeros[j].pos, nextEnemy[k].pos) <= HAMMERATTACK_RANGE){
				if (max_hp<nextEnemy[k].hp){
					max_hp=nextEnemy[k].hp;
					target=&nextEnemy[k];
				}
			}
			
			if (target!=NULL)
    		for (int j=0;j<myHeros.size();j++)
			if (myHeros[j].typeId == HERO_ID[0] && myHeros[j].canUseSkill("HammerAttack") && HammerAttackRound[myHeros[j].id]!=countRound && 
			runawayRound[myHeros[j].id]!=countRound && dis2(myHeros[j].pos, target->pos) <= HAMMERATTACK_RANGE){
				gword->stgSacrifice(&myHeros[i]);
    			gword->stgHammerAttack(target, Pos(1,1), &myHeros[j]);
			}
    	}
	}
}

void Operations::opSacrificeWild(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[2] && myHeros[i].canUseSkill("Sacrifice")){
		int safe = 1; 
    	for (int j=0;j<nextWild.size() && safe;j++)  //殊臥頁倦芦畠 
    	if (dis2(myHeros[i].pos, nextWild[j].pos) <= nextWild[j].range)
    	if (console->getBuff("Dizzy", &nextWild[j]) == NULL && console->getBuff("WaitRevive", &nextWild[j]) == NULL){
    		for (int k=0;k<nextWild[j].skills.size();k++)
			if (nextWild[j].skills[k].typeId == 0 && nextWild[j].skills[k].cd == 0){
				safe = 0;
				break;
			}
    	}
    	
    	if (safe)
		for (int j=0;j<myHeros[i].skills.size();j++)
		if (myHeros[i].skills[j].typeId == 0 && myHeros[i].skills[j].cd <= 1){
    		for (int k=0;k<nextWild.size();k++)
    		if(dis2(myHeros[i].pos, nextWild[k].pos) <= myHeros[i].range){
    			gword->stgSacrificeWild(&myHeros[i]);
    			break;
    		}
    		break;
		}
	}
}

void Operations::opBlink(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[1] && myHeros[i].canUseSkill("Blink")){
		if (heroState.deadRound(&myHeros[i])>1){   //触了 
			int min_hp = 10000;
			PUnit* target = NULL;
    		for (int j=0;j<nextEnemy.size();j++)
    		if (nextEnemy[j].hp < min_hp && nextEnemy[j].hp > 0){
    			min_hp = nextEnemy[j].hp;
    			target = &nextEnemy[j];
    		}
    		if (target != NULL)
			if (min_hp < target->max_hp/3){
    			//printf("%dn",dis2(target->pos, myHeros[i].pos));
    			if (dis2(target->pos, myHeros[i].pos) <= BLINK_RANGE/* && dis2(target->pos, myHeros[i].pos) > myHeros[i].range*/){
    				//puts("233");
    				gword->stgBlink(target, &myHeros[i]);
    			}
    		}
    	}else{   //毛怒 
    		for (int j=-sqrt(BLINK_RANGE);j<=sqrt(BLINK_RANGE);j++)
    		for (int k=-sqrt(BLINK_RANGE);k<=sqrt(BLINK_RANGE);k++)
			if (dis2(Pos(0, 0), Pos(j, k)) <= BLINK_RANGE){
				Pos targ = myHeros[i].pos + Pos(j, k);
    			if (checkPos(targ) && MAP[targ.x][targ.y]<50) gword->stgBlink(myHeros[i].pos + Pos(j, k), &myHeros[i]);/*
    			gword->stgBlink(myHeros[i].pos + Pos(j, -k), &myHeros[i]);
    			gword->stgBlink(myHeros[i].pos + Pos(-j, k), &myHeros[i]);
    			gword->stgBlink(myHeros[i].pos + Pos(-j, -k), &myHeros[i]);*/
    		}
    	}
	}
}

void Operations::opBlinkDown(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[1] && myHeros[i].canUseSkill("Blink") && checkHill(myHeros[i].pos)){
		for (int j=-sqrt(BLINK_RANGE);j<=sqrt(BLINK_RANGE);j++)
		for (int k=-sqrt(BLINK_RANGE);k<=sqrt(BLINK_RANGE);k++)
		if (checkPos(myHeros[i].pos+Pos(j,k)) && dis2(Pos(0,0),Pos(j,k))<=BLINK_RANGE){
			Pos targ=myHeros[i].pos+Pos(j,k);
			if (MAP[targ.x][targ.y]==0) gword->stgBlinkDown(myHeros[i].pos + Pos(j, k), &myHeros[i]);
		}
	}
}

void Operations::opGuardBase(){
	int num=0;
    for (int i=0;i<nextEnemy.size();i++)
    if (inBaseRange(nextEnemy[i].pos)) ++num;
    for (int i=0;i<myHeros.size();i++)
    if (inBaseRange(myHeros[i].pos)) --num;
    
    for (;num>0;--num){
    	int maxhp=0;
    	PUnit* targ=NULL;
    	for (int j=0;j<myHeros.size();j++)
    	if (!calledBack[myHeros[j].id] && dis2(myHeros[j].pos, MILITARY_BASE_POS[console->camp()])>=callBackRange && maxhp<myHeros[j].hp){
    		maxhp=myHeros[j].hp;
    		targ=&myHeros[j];
    	}
    	if (targ!=NULL){
			console->callBackHero(targ);
			calledBack[targ->id]=1;
		}
    }
}

void Operations::opSetObserver(){
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId == HERO_ID[3] && myHeros[i].canUseSkill("SetObserver")){
    	for (int j=-sqrt(SET_OBSERVER_RANGE);j<=sqrt(SET_OBSERVER_RANGE);j++)
    	for (int k=-sqrt(SET_OBSERVER_RANGE);k<=sqrt(SET_OBSERVER_RANGE);k++)
    	if (checkPos(myHeros[i].pos+Pos(j,k)) && dis2(mine_pos[0],myHeros[i].pos+Pos(j,k))<=SetOberverRange && 
		dis2(Pos(0,0),Pos(j,k))<=SET_OBSERVER_RANGE && blockMap[myHeros[i].pos.x+j][myHeros[i].pos.y+k]!=countR*2-1 && 
		MAP[myHeros[i].pos.x][myHeros[i].pos.y]+1>=MAP[myHeros[i].pos.x+j][myHeros[i].pos.y+k]){
			gword->stgSetObserver(myHeros[i].pos + Pos(j, k), &myHeros[i]);
		}
	}
}
 
void Operations::action(){
	opMining();
	opGuardMine();
	opGoDie();
	opAttack();
	opAttackObserver();
	opAttackWOD();
	opBaseAttack();
	opRunaway();
	opRunawayWOD();
	opLevelup();
	opHammerAttack();
	opSacrifice();
	opBlink();
	opBlinkDown();
	opGuardBase();
	opSetObserver(); 
	//if (GuardingMine){   !!!
	opAttackWild();
	opHammerAttackWild();
	opSacrificeWild(); 
	//}
	
	for (int i=0;i<myTeam.size();i++) myTeam[i].action();
	opHammerAttackAndSacrifice();
	opHammerAttackAndSacrifice2();
}

//_______________________Strategy_____________________________

void Strategy::setWorker(PUnit* worker){ this->worker = worker; }
void Strategy::setWorth(int worth){ this->worth = worth; }
void Strategy::setName(int name){ this->name = name; }

//_______________________StgAttack_____________________________

StgAttack::StgAttack(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

StgAttack::StgAttack(PUnit* worker,PUnit* target,Pos targetP,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgAttack::countWorth(){
	imp = imp_StgAttack;
	if (console->getBuff("WaitRevive", target) != NULL && target->hp>target->max_hp/3){
		int timeLeft;
		int buf = getBuff("WinOrDie",target);
		if (buf!=-1) timeLeft = target->buffs[buf].timeLeft;
		
		if (buf!=-1 && heroState.deadRound(target)>timeLeft) imp = imp_StgAttackWaitRevive;
	}
	
	if (target->typeId==HERO_ID[0] && inBaseRange(target->pos)) imp=imp_StgAttackHammer;
	if (targetP==Pos(1,1)) imp=imp_StgAttackBerserker;
	/*
	if (imp == imp_StgAttack && inBaseRange(worker->pos)){
		int ski = getSkill("Attack",worker);
		int cd = worker->skills[ski].cd;
		if (cd==0 && dis2(worker->pos, target->pos)<=worker->range){
			imp=imp_StgAttackInRange;
			if (target->typeId==HERO_ID[0] && inBaseRange(target->pos)) imp=imp_StgAttackHammerInRange;
		}
	}*/
	
	if (target->hp >= 0) worth = greedWorth(worker, target);//10000-target->hp;
	else imp = worth = 0;
	
	if (dis2(target->pos, worker->pos) > worker->range){
		if (console->getBuff("WinOrDie", target) != NULL) imp = worth = 0;
	}
}

void StgAttack::work(){
	gword->attack(target, worker);
}

//_______________________StgAttackWild_____________________________

StgAttackWild::StgAttackWild(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgAttackWild::countWorth(){
	imp = imp_StgAttackWild;
	if (target->hp >= 0) worth = 10000-target->hp;
	else imp = worth = 0;
}

void StgAttackWild::work(){
	gword->attackWild(target, worker);
}

//_______________________StgAttackObserver_____________________________

StgAttackObserver::StgAttackObserver(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgAttackObserver::countWorth(){
	imp = imp_StgAttackObserver;
	if (target->hp >= 0) worth = 10000-target->hp;
	else imp = worth = 0;
}

void StgAttackObserver::work(){
	console->attack(target, worker);
}

//_______________________StgAttackWOD_____________________________

StgAttackWOD::StgAttackWOD(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgAttackWOD::countWorth(){
	if (dis2(target->pos, worker->pos) <= worker->range){
		imp = imp_StgAttack_WinOrDie_InRange;
		if (target->hp <= attackHp(target, worker)) imp = imp_StgAttack_WinOrDie_InRange_Kill;
		if (target->hp >= 0){
			if (imp==imp_StgAttack_WinOrDie_InRange) worth = 10000-target->hp;
			else worth = target->hp;
		}else imp = worth = 0;
	}else{
		imp = imp_StgAttack_WinOrDie;
		worth = MAX_DIST - dis2(target->pos, worker->pos);
		if (console->getBuff("WinOrDie", target) != NULL) imp = worth = 0;
	}
}

void StgAttackWOD::work(){
	gword->attack(target, worker);
}

//_______________________StgBaseAttack_____________________________

StgBaseAttack::StgBaseAttack(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgBaseAttack::countWorth(){
	imp = imp_StgBaseAttack;
	
	int ski=getSkill("Sacrifice", target);
	if (ski!=-1)
	if (!target->skills[ski].cd && attackedRound[target->id]!=countRound && 
	console->getBuff("Dizzy",target) == NULL && console->getBuff("WaitRevive",target) == NULL) imp=imp_StgBaseAttack_WinOrDie;
	
	if (target->hp >= 0) worth = 10000-target->hp;
	else imp = worth = 0;
}

void StgBaseAttack::work(){
	console->baseAttack(target);
	//gword->baseAttack(target, worker);
}

//_______________________StgMove_____________________________

StgMove::StgMove(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgMove::countWorth(){
	imp = imp_StgMove;
	worth = 1;
}

void StgMove::work(){
	gword->move(targetP, worker);
}

//_______________________StgGuardMine_____________________________

StgGuardMine::StgGuardMine(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgGuardMine::countWorth(){
	imp = imp_StgGuardMine;
	worth = 1;
}

void StgGuardMine::work(){
	gword->move(targetP, worker);
}

//_______________________StgGoDie_____________________________

StgGoDie::StgGoDie(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgGoDie::countWorth(){
	imp = imp_StgGoDie;
	worth = MAX_DIST-dis2(worker->pos, targetP);
}

void StgGoDie::work(){
	gword->move(targetP, worker);
}

//_______________________StgRunaway_____________________________

StgRunaway::StgRunaway(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgRunaway::countWorth(){
	imp = imp_StgRunaway;/*
	worth = MAX_DIST;
	for (int i=0;i<nextEnemy.size();i++)
	if (nextEnemy[i].hp > 0)
	if (worth > dis2(target, nextEnemy[i].pos)) worth = dis2(target, nextEnemy[i].pos);*/
	worth = longestDis(targetP, console->camp()^1);
	//if (worth > 300) imp=worth=0;
	int bo=1;
	for (int i=0;i<nextEnemy.size();i++)
	if (nextEnemy[i].hp > 0 && worker->view > dis2(worker->pos, nextEnemy[i].pos)) bo=0;
	if (bo) imp=worth=0;
}

void StgRunaway::work(){
	if (worth > 300){
		gword->move(MILITARY_BASE_POS[console->camp()], worker);
	}else{
		//puts("WARING");
		Pos targ = targetP - worker->pos;
		targ = worker->pos + targ*3;
		gword->move(shrinkPos(targ, worker->pos), worker);
	}
}

//_______________________StgRunawayWOD_____________________________

StgRunawayWOD::StgRunawayWOD(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgRunawayWOD::countWorth(){
	imp = imp_StgRunawayWOD;
	worth = MAX_DIST;
	for (int i=0;i<nextEnemy.size();i++)
	if (console->getBuff("WinOrDie", &nextEnemy[i])!=NULL && console->getBuff("Dizzy", &nextEnemy[i])==NULL && 
	console->getBuff("WaitRevive", &nextEnemy[i])==NULL){
		int bo=1;
		for (int j=0;j<myHeros.size();j++)
		if (dis2(nextEnemy[i].pos, myHeros[j].pos)<=nextEnemy[i].range) bo=0;
		
		if (bo)
		if (worth>dis2(targetP, nextEnemy[i].pos)) worth=dis2(targetP, nextEnemy[i].pos);
	}
}

void StgRunawayWOD::work(){
	gword->move(targetP, worker);
}

//_______________________StgLevelup_____________________________

StgLevelup::StgLevelup(PUnit* worker,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgLevelup::countWorth(){
	imp = imp_StgLevelup;
	worth = 1;
}

void StgLevelup::work(){
    Pos target = MILITARY_BASE_POS[console->camp()];
    if(dis2(MILITARY_BASE_POS[console->camp()], worker->pos) >= LEVELUP_RANGE)
	gword->move(target, worker);
	//printf("%d!n",dis2(MILITARY_BASE_POS[console->camp()], worker->pos));
    if(dis2(MILITARY_BASE_POS[console->camp()], worker->pos) < LEVELUP_RANGE) //勣幅雫議哂俛壓児仇現除岷俊幅雫 
    {
        console->buyHeroLevel(worker);
    }
}

//_______________________StgHammerAttack_____________________________

StgHammerAttack::StgHammerAttack(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

StgHammerAttack::StgHammerAttack(PUnit* worker,PUnit* target,Pos targetP, string name){
	this->worker = worker;
	this->target = target;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgHammerAttack::countWorth(){
	imp = imp_StgHammerAttack;
	if (targetP!=Pos(-100, -100)) imp = imp_StgHammerAttackCooperate;
	if (target->hp >= 0 && console->getBuff("Dizzy", target) == NULL && console->getBuff("WaitRevive", target) == NULL)
		worth = greedWorth(worker, target); //10000 - target->hp;
	else imp = worth = 0;
}

void StgHammerAttack::work(){
	//puts("XD");
	gword->hammerAttack(target, worker);
}

//_______________________StgHammerAttackWild_____________________________

StgHammerAttackWild::StgHammerAttackWild(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgHammerAttackWild::countWorth(){
	imp = imp_StgHammerAttackWild;
	if (target->hp >= 0 && console->getBuff("Dizzy", target) == NULL) worth = 10000 - target->hp;
	else imp = worth = 0;
}

void StgHammerAttackWild::work(){
	gword->hammerAttackWild(target, worker);
}

//_______________________StgSacrifice_____________________________

StgSacrifice::StgSacrifice(PUnit* worker,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgSacrifice::countWorth(){
	imp = imp_StgSacrifice;
	worth = 1;
	int bo=1;
    for (int k=0;k<nextEnemy.size();k++)
    if(dis2(worker->pos, nextEnemy[k].pos) <= worker->range && nextEnemy[k].hp>0) bo=0;
    if (bo) imp=worth=0;
}

void StgSacrifice::work(){
	console->useSkill("Sacrifice", NULL, worker);
}

//_______________________StgSacrificeWild_____________________________

StgSacrificeWild::StgSacrificeWild(PUnit* worker,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

int StgSacrificeWild::countWorth(){
	imp = imp_StgSacrificeWild;
	worth = 1;
	int bo=1;
    for (int k=0;k<nextWild.size();k++)
    if(dis2(worker->pos, nextWild[k].pos) <= worker->range && nextWild[k].hp>0) bo=0;
    if (bo) imp=worth=0;
}

void StgSacrificeWild::work(){
	console->useSkill("Sacrifice", NULL, worker);
}

//_______________________StgBlink_____________________________

StgBlink::StgBlink(PUnit* worker,PUnit* target,string name){
	this->worker = worker;
	this->target = target;
	this->targetP = Pos(-100, -100);
	this->name = name;
	countWorth();
}

StgBlink::StgBlink(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgBlink::countWorth(){
	if (target != NULL){
		if (target->hp>0 && target->typeId != HERO_ID[1] && console->getBuff("Dizzy", target) == NULL && 
		console->getBuff("WaitRevive", target) == NULL && console->getBuff("WinOrDie", target) == NULL){
			imp = imp_StgBlink;
			worth = 1;
			targetP = jockeyPos(target);
			if (targetP.x == -100 || blockMap[targetP.x][targetP.y] == countR*2 || dis2(targetP, worker->pos) > BLINK_RANGE) imp = 0;
			/*
			for (int i=0;i<4;i++){
				Pos targ=target->pos + Step[i];
				int save = longestDis(targ, console->camp());
				if (save > worth){
					worth = save;
					targetP = targ;
				}
			}
			if (!worth || dis2(targetP, worker->pos) > BLINK_RANGE) imp = 0;*/
		}else imp = worth = 0;
	}else{
		if (checkHill(targetP)) imp = imp_StgBlink_Runaway_Hill;
		else imp = imp_StgBlink_Runaway;/*
		worth = MAX_DIST;
		for (int i=0;i<nextEnemy.size();i++)
		if (nextEnemy[i].hp > 0)
		if (worth > dis2(targetP, nextEnemy[i].pos)) worth = dis2(targetP, nextEnemy[i].pos);*/
		
		worth = longestDis(targetP, console->camp()^1);
		//worth = MAP[targetP.x][targetP.y];
	}
}

void StgBlink::work(){/*
	Pos targ;
	if (target !=NULL){
		Pos tag = target->pos - worker->pos;
		//printf("%d,%dn",tag.x,tag.y);
		tag.x = (double)tag.x * sqrt((double)BLINK_RANGE) / dis(target->pos, worker->pos);
		tag.y = (double)tag.y * sqrt((double)BLINK_RANGE) / dis(target->pos, worker->pos);
		//printf("%d,%dn",tag.x,tag.y);
		tag = worker->pos + tag;
		int max_dis = 0;
		for (int i=0;i<9;i++){
			int dist = dis2(worker->pos, tag + Step[i]);
			//printf("%d ",dist);
			if (dist <= BLINK_RANGE && dist > max_dis){
				max_dis = dist;
				targ = tag + Step[i];
			}
		}
		//printf("n%dn",max_dis);
		//targ = target->pos;
	}else targ = targetP;
	targ = targetP;*/
	blockMap[targetP.x][targetP.y] = countR*2;
	console->useSkill("Blink", targetP, worker);
}


//_______________________StgBlinkDown_____________________________

StgBlinkDown::StgBlinkDown(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgBlinkDown::countWorth(){
	imp = imp_StgBlinkDown;
	worth = rand()%10;
}

void StgBlinkDown::work(){
	console->useSkill("Blink", targetP, worker);
}

//_______________________StgSetObserver_____________________________
	
StgSetObserver::StgSetObserver(PUnit* worker,Pos targetP,string name){
	this->worker = worker;
	this->target = NULL;
	this->targetP = targetP;
	this->name = name;
	countWorth();
}

int StgSetObserver::countWorth(){
	imp = imp_StgSetObserver;
	worth = rand()%10;
}

void StgSetObserver::work(){
	console->useSkill("SetObserver", targetP, worker);
}
//_______________________State_____________________________

State::State(PUnit* newHero,Pos p = Pos(-1,-1)){
	if (p.x == -1) p = newHero->pos;
	mHero = newHero;
	hp[0] = newHero->hp;
	hp2[0] = newHero->hp;
	restore = getRecoverHp(newHero);
	for (int i=1;i<10;i++) hp[i]=hp2[i]=0;
	
	if (newHero->camp == console->camp()){  //厘圭 
		for (int j=0;j<enemyHeros.size();j++){
			int range = enemyHeros[j].range;
			if (newHero->hp < newHero->max_hp/3) range = newHero->view;
			if (enemyHeros[j].hp > 0 && dis2(enemyHeros[j].pos, p) <= range){
				int timeLeft = 0;  //傳堽、嶷伏扮寂 
				int buf = getBuff("Dizzy",&enemyHeros[j]);
				if (buf!=-1) timeLeft = enemyHeros[j].buffs[buf].timeLeft;
				buf = getBuff("WaitRevive",&enemyHeros[j]);
				if (buf!=-1)
				if (timeLeft < enemyHeros[j].buffs[buf].timeLeft) timeLeft = enemyHeros[j].buffs[buf].timeLeft;
				
				int ski = getSkill("Attack",&enemyHeros[j]);
				int cd = enemyHeros[j].skills[ski].cd-timeLeft;
				if (cd<0) cd = 0;
				for (int i = timeLeft+1; i<10; i++,cd--){
					if (!cd){
						hp[i] += attackHp(newHero, &enemyHeros[j]);
						cd = enemyHeros[j].skills[ski].maxCd;
					}
				}
			}
			if (enemyHeros[j].hp > 0){
				int timeLeft = 0;  //傳堽、嶷伏扮寂 
				int buf = getBuff("Dizzy",&enemyHeros[j]);
				if (buf!=-1) timeLeft = enemyHeros[j].buffs[buf].timeLeft;
				buf = getBuff("WaitRevive",&enemyHeros[j]);
				if (buf!=-1)
				if (timeLeft < enemyHeros[j].buffs[buf].timeLeft) timeLeft = enemyHeros[j].buffs[buf].timeLeft;
				timeLeft+=moveTime(&enemyHeros[j],dis(enemyHeros[j].pos, p)-sqrt(enemyHeros[j].range));
				
				int ski = getSkill("Attack",&enemyHeros[j]);
				int cd = enemyHeros[j].skills[ski].cd-timeLeft;
				if (cd<0) cd = 0;
				for (int i = timeLeft+1; i<10; i++,cd--){
					if (!cd){
						hp2[i] += attackHp(newHero, &enemyHeros[j]);
						cd = enemyHeros[j].skills[ski].maxCd;
					}
				}
			}
		}
		
		for (int i=1;i<10;i++){
			hp[i] = hp[i-1]+restore-hp[i];
			if (hp[i]>newHero->max_hp) hp[i] = newHero->max_hp;
			hp2[i] = hp2[i-1]+restore-hp2[i];
			if (hp2[i]>newHero->max_hp) hp2[i] = newHero->max_hp;
		}
	}else{  //黍圭 
		for (int j=0;j<myHeros.size();j++){
			if (myHeros[j].hp > 0 && dis2(myHeros[j].pos, p) <= myHeros[j].range){
				int timeLeft = 0;  //傳堽、嶷伏扮寂 
				int buf = getBuff("Dizzy",&myHeros[j]);
				if (buf!=-1) timeLeft = myHeros[j].buffs[buf].timeLeft;
				buf = getBuff("WaitRevive",&myHeros[j]);
				if (buf!=-1)
				if (timeLeft < myHeros[j].buffs[buf].timeLeft) timeLeft = myHeros[j].buffs[buf].timeLeft;
			
				int ski = getSkill("Attack",&myHeros[j]);
				int cd = myHeros[j].skills[ski].cd-timeLeft;
				if (cd<0) cd = 0;
				for (int i = timeLeft+1; i<10; i++,cd--){
					if (!cd){
						hp[i] += attackHp(newHero, &myHeros[j]);
						cd = myHeros[j].skills[ski].maxCd;
					}
				}
			}
			int bo=1;
			if (console->getBuff("WinOrDie",&myHeros[j])!=NULL){
				for (int i=0;i<enemyHeros.size();i++)
				if (dis2(enemyHeros[i].pos,myHeros[j].pos)<=myHeros[j].range) bo=0;
			}
			if (myHeros[j].hp > 0 && bo){
				int timeLeft = 0;  //傳堽、嶷伏扮寂 
				int buf = getBuff("Dizzy",&myHeros[j]);
				if (buf!=-1) timeLeft = myHeros[j].buffs[buf].timeLeft;
				buf = getBuff("WaitRevive",&myHeros[j]);
				if (buf!=-1)
				if (timeLeft < myHeros[j].buffs[buf].timeLeft) timeLeft = myHeros[j].buffs[buf].timeLeft;
				timeLeft+=moveTime(&myHeros[j],dis(myHeros[j].pos, p)-sqrt(myHeros[j].range));
				
				int ski = getSkill("Attack",&myHeros[j]);
				int cd = myHeros[j].skills[ski].cd-timeLeft;
				if (cd<0) cd = 0;
				for (int i = timeLeft+1; i<10; i++,cd--){
					if (!cd){
						hp2[i] += attackHp(newHero, &myHeros[j]);
						cd = myHeros[j].skills[ski].maxCd;
					}
				}
			}
		}
		
		for (int i=1;i<10;i++){
			hp[i] = hp[i-1]+restore-hp[i];
			if (hp[i]>newHero->max_hp) hp[i] = newHero->max_hp;
			hp2[i] = hp2[i-1]+restore-hp2[i];
			if (hp2[i]>newHero->max_hp) hp2[i] = newHero->max_hp;
		}
	}
}

//_______________________HeroState_____________________________

void HeroState::clean(){
	for (int i=0;i<heros.size();i++){
		delete heros[i];
		heros[i]=NULL;
	}
	heros.clear();
}

void HeroState::addHero(PUnit* newHero){
	heros.push_back(new State(newHero));
}

int HeroState::getHp(PUnit* ptr, int round){
	for (int i=0;i<heros.size();i++)
	if (heros[i]->mHero->id == ptr->id) return heros[i]->hp[round];
}

int HeroState::deadRound(PUnit* ptr){
	//puts("");
	//if (ptr==NULL) puts("ptr:WARING!");
	for (int i=0;i<heros.size();i++)
	if (heros[i]->mHero->id == ptr->id){
		for (int j=0;j<10;j++){
			//printf("%d ",j);
			if (heros[i]->hp[j] <= 0) return j;
		}
		return 10;
	}
	//puts("deadRound:WARING!");
	//return 0;
}

int HeroState::deadRound(Pos p,PUnit* ptr){
	State save = State(ptr, p);
	for (int j=0;j<10;j++)
	if (save.hp[j] <= 0) return j;
	return 10;
}

int HeroState::getHp2(PUnit* ptr, int round){
	for (int i=0;i<heros.size();i++)
	if (heros[i]->mHero->id == ptr->id) return heros[i]->hp2[round];
}

int HeroState::deadRound2(PUnit* ptr){
	for (int i=0;i<heros.size();i++)
	if (heros[i]->mHero->id == ptr->id){
		for (int j=0;j<10;j++){
			//printf("%d ",j);
			if (heros[i]->hp2[j] <= 0) return j;
		}
		return 10;
	}
}

int HeroState::deadRound2(Pos p,PUnit* ptr){
	State save = State(ptr, p);
	for (int j=0;j<10;j++)
	if (save.hp2[j] <= 0) return j;
	return 10;
}

//_______________________AIHero_____________________________

AIHero::AIHero(PUnit* newHero){
	mHero = newHero;
	//SPC.build(mHero->pos, mHero->speed, BLOCK);
}

bool AIHero::addStrategy(Strategy* newStrategy){
	if (newStrategy == NULL) return 0;
	if (newStrategy->worker->id != mHero->id) return 0;
	mStrategy.push_back(newStrategy);
	return 1;
}

Strategy* AIHero::getStrategy(){
	int maxval = 0, maximp = 0, sz = mStrategy.size();
	Strategy* res = NULL;
	for (int i=0;i<sz;i++){
		mStrategy[i]->countWorth();
		
		int bcute = 0;
		for (int j=0;j<num_cute;j++)
		if (mStrategy[i]->imp == cute_imp[j]) bcute=1;
		if (bcute && cute) continue;
		
		if (mStrategy[i]->imp>1 && rand()%cute_rate==0 && cute==2) continue;
		
		if (mStrategy[i]->imp > maximp || (mStrategy[i]->imp == maximp && mStrategy[i]->worth > maxval)){
			maximp = mStrategy[i]->imp;
			maxval = mStrategy[i]->worth;
			res=mStrategy[i];
		}
	}
	return res;
}

void AIHero::action(){
	Strategy* str = getStrategy();
	debuger.draw(this);
	//debuger.draw(*this->mHero);
	if (str != NULL){
		//printf("%dn",str->imp);
		if (str->imp){
			debuger.draw("naction:n");
			debuger.draw(str);
			str->work();
		}
	}
}

void AIHero::move(Pos target,const vector<Pos>&block=BLOCK,const vector<Pos>&BanStays=BanStay){
	vector<Pos>path = SPC.findShortestPath(mHero->pos,target,mHero->speed,block,BanStays);
	//printf("%dn",path.size());
	debuger.draw(mHero,path);
	console->move(path, mHero);
}

//_______________________G_word_____________________________

Gword::Gword(const PMap &_map, const PPlayerInfo &_info, PCommand &_cmd):map(_map){
	//map = _map;
	info = &_info;
	cmd = &_cmd;
}

Gword::~Gword(){
	debuger.draw("/*************************************************************************************/nnnnnn");
	Move_C.solve();
	
	for (int i=0;i<aiHeros.size();i++) aiHeros[i].mStrategy.clear();
	aiHeros.clear();
	myHeros.clear();
	enemyHis.clear();
	enemyHeros.clear();
	enemyObserver.clear();
	nextEnemy.clear();
	wild.clear();
	mines.clear(); 
	nextWild.clear();
	for (int i=0;i<allStrategy.size();i++){
		delete allStrategy[i];
		allStrategy[i]=NULL;
	}
	allStrategy.clear();
	heroState.clean();
	for (int i=0;i<myTeam.size();i++) myTeam[i].clean();
	myTeam.clear();
	for (int i=0;i<enemyTeam.size();i++) enemyTeam[i].clean();
	enemyTeam.clear();
}
	
void Gword::pretreatment(){
	srand(time(0));    //昧字蝕購嬉蝕
    console = new Console(map, *info, *cmd);
    //console->changeShortestPathFunc(findShortestPath2);
    countRound = info->round;
    MAP = map;
    
    if (countRound == 0){
		exploitMine[0] = 1;
		exploitMine[1] = 4;
    }
    
    for(int i = 0; i < info->units.size(); ++i){
        if (info->units[i].isHero()){
        	if (info->units[i].camp == info->camp){            //厘圭哂俛 
        		myHeros.push_back((PUnit)(info->units[i]));
        		aiHeros.push_back(AIHero(&myHeros[myHeros.size()-1]));
        	}else{                                             //黍圭哂俛 
				nextEnemy.push_back((PUnit)(info->units[i]));
				enemyHeros.push_back((PUnit)(info->units[i]));
			}
        }
        
        if (info->units[i].isBase() && info->units[i].camp == info->camp){            //厘圭児仇 
        	myBase=(PUnit)(info->units[i]);
        	aiHeros.push_back(AIHero(&myBase));
        }
        
        if (info->units[i].typeId==ObserverId && info->units[i].camp != info->camp){    //黍圭凛 
        	enemyObserver.push_back((PUnit)(info->units[i]));
        }
        
        if (info->units[i].isWild()){    //勸講 
			wild.push_back((PUnit)(info->units[i]));
			nextWild.push_back((PUnit)(info->units[i]));
        }
        
        if (info->units[i].isMine()){    //嵩 
        	mines.push_back((PUnit)(info->units[i]));
		}
    }
    
	GuardingMine=0;    //頁倦嗤繁便嵩 
    for (int i=0;i<myHeros.size();i++)
	if (myHeros[i].typeId==HERO_ID[3] && dis2(myHeros[i].pos, mine_pos[0])<=MineRange) GuardingMine=1;
	
    for (int i=0; i<mines.size();i++){    //恠欺嗤嬬楚議嵩 
    	if (console->unitArg("Energy","Current",&mines[i])>0){
			for (int j=1;j<7;j++)
			if (mines[i].pos==mine_pos[j]) exploitMine[console->camp()]=j;
		}
    	if (mines[i].pos==mine_pos[exploitMine[0]] && console->unitArg("Energy","Current",&mines[i])<=0){
    		while (mines[i].pos==mine_pos[exploitMine[0]]) exploitMine[0]=rand()%4+1;
    	}
    	if (mines[i].pos==mine_pos[exploitMine[1]] && console->unitArg("Energy","Current",&mines[i])<=0){
    		while (mines[i].pos==mine_pos[exploitMine[1]]) exploitMine[1]=rand()%4+1;
    	}
    }
    
    for(int i = 0; i < info->units.size(); ++i)
	if (info->units[i].camp != info->camp){
		hisUnit[info->units[i].id].newUnit(&info->units[i]);     //厚仟煽雰汽了佚連 
		hisUnit2[info->units[i].id].newUnit(&info->units[i]);
	}
	
    for (int i = 0;i<MAX_ID;i++)    //煽雰黍圭哂俛 
    if (hisUnit[i].round!=-1){
    	//printf("%d,%d %d,%dn",myHeros[0].pos.x,myHeros[0].pos.y,hisUnit[i].p.pos.x,hisUnit[i].p.pos.y);
    	if (hisUnit[i].round!=console->round())
    	for(int j = 0; j < myHeros.size(); ++j)
    	if (dis2(myHeros[j].pos,hisUnit[i].p.pos)<=myHeros[j].view && 
		MAP[myHeros[j].pos.x][myHeros[j].pos.y]+1>=MAP[hisUnit[i].p.pos.x][hisUnit[i].p.pos.y]){
    		hisUnit[i].round=-1;
    		break;
    	}
    	
    	if (hisUnit[i].round!=-1)
		if(hisUnit[i].p.isHero() && hisUnit[i].p.camp!=info->camp){
			enemyHis.push_back((PUnit)(hisUnit[i].p));
		}
	}
	
	myHeroWorth = enemyHeroWorth = 0;
    for (int i=0;i<myHeros.size();++i) myHeroWorth+=Hero_worth[myHeros[i].level];
    for (int i=0;i<MAX_ID;++i)
    if (hisUnit2[i].round!=-1)
	if (hisUnit2[i].p.isHero() && hisUnit2[i].p.camp!=info->camp) enemyHeroWorth+=Hero_worth[hisUnit2[i].p.level];
	
    for(int i = 0; i < myHeros.size(); ++i) heroState.addHero(&myHeros[i]);       //哂俛彜蓑 
    for(int i = 0; i < enemyHeros.size(); ++i) heroState.addHero(&enemyHeros[i]);
	
    for(int i = 0; i < nextEnemy.size(); ++i){   //黍圭指鹸柴麻 
		nextEnemy[i].hp += getRecoverHp(&nextEnemy[i]);
		if (nextEnemy[i].hp > nextEnemy[i].max_hp) nextEnemy[i].hp = nextEnemy[i].max_hp;
	}
	
	++countR;   //炎芝怦悪泣 
	BLOCK.clear();
    for(int j = 0; j < info->units.size(); ++j)
	if (checkPos(info->units[j].pos)){
		blockMap[info->units[j].pos.x][info->units[j].pos.y] = countR*2-1;
		BLOCK.push_back(info->units[j].pos);
		//printf("(%d,%d):%d ",info->units[j].pos.x, info->units[j].pos.y,blockMap[info->units[j].pos.x][info->units[j].pos.y]);
	}
	//puts("");
    for(int k = 0; k < MINE_NUM; ++k)
        for(int i = -1; i <= 1; ++i)
            for(int j = -1; j <= 1; ++j){
                blockMap[MINE_POS[k].x+i][MINE_POS[k].y+j] = countR*2-1;
				BLOCK.push_back(MINE_POS[k]+Pos(i,j));
            }
    for(int k = 0; k < MILITARY_BASE_NUM; ++k){
        blockMap[MILITARY_BASE_POS[k].x][MILITARY_BASE_POS[k].y] = countR*2-1;
		BLOCK.push_back(MILITARY_BASE_POS[k]);
    }
    
    for (int i=0;i<100;i++)    //柴麻複噫毛怒指栽 
	if (round_runaway[i]>0) --round_runaway[i];
	
    for(int i = 0; i < myHeros.size(); ++i)    //柴麻頁倦函僕棒 
	if (Dying[myHeros[i].id] && myHeros[i].hp>myHeros[i].max_hp/3) Dying[myHeros[i].id]=0;
    
    if (myBase.hp < myBase.max_hp/2) baseWeak = 1;
    else baseWeak = 0;
    
    for (int i=0;i<MAX_ID;i++) beloneTeam[i]=-1;
    buildET();
    buildMT();
    
    LPL.init();
	Move_C.init();
    buyHero();
    debuger.draw(info);
    memset(calledBack,0,sizeof(calledBack));
}

void Gword::buyHero(){
	int buyNum[4]={0, 0, 0, 0};
	for (int i=myHeros.size();i<HERO_LIMIT;i++)
    if(console->gold() - console->goldCostCurrentRound() >= NEW_HAMMERGUARD_COST * (getHeroNum(BUY_HERO[i]+1) + buyNum[BUY_HERO[i]])){
		console->chooseHero(HERO_NAME[BUY_HERO[i]], BUY_HERO_POS[info->camp][i]);
		++buyNum[BUY_HERO[i]];
	}
}

void Gword::selectUnit(const PUnit* selectedUnit){
    selected = selectedUnit;
    console->selectUnit(selectedUnit);
}

void Gword::move(Pos target, const PUnit* ptr){
	//Move_C.push(ptr,target);
	PUnit* ptr2=(PUnit*)&ptr;
	if (console->getBuff("Dizzy",ptr) == NULL && console->getBuff("WaitRevive",ptr) == NULL){
		/*int Nban = 0;
		if (heroState.deadRound(ptr2)>3){    //泌惚輝念芦畠 繍裡曝ban渠 
			for (int i=-sqrt(ptr->speed); i<=sqrt(ptr->speed); i++)
			for (int j=-sqrt(ptr->speed); j<=sqrt(ptr->speed); j++)
			if (dis2(Pos(0,0), Pos(i,j)) <= ptr->speed){
				Pos now = ptr->pos+Pos(i,j);
				if (heroState.deadRound2(ptr2, now) <= 3){
					BanStay.push_back(now);
					++Nban;
				}
			}
		}*/
		//console->move(target,ptr);
		Move_C.push(ptr,target,BLOCK,BanStay);
		//for (int i=1;i<=Nban;i++) BanStay.pop_back();
	}
	/*
	for (int i=0;i<aiHeros.size();i++)
	if (ptr->id == aiHeros[i].mHero->id) aiHeros[i].move(target);*/
}

void Gword::attack(const PUnit* target, const PUnit* ptr){
	int bo=0;
    for (int i = 0; i < nextEnemy.size(); i++)
    if (nextEnemy[i].pos.x == target->pos.x && nextEnemy[i].pos.y == target->pos.y){
		attack(i,ptr);
		bo=1;
	}
	
	if (!bo){
    	for (int i = 0; i < enemyHis.size(); i++)
    	if (enemyHis[i].pos == target->pos){
			gword->move(enemyHis[i].pos, ptr);
    	}
	}
}

void Gword::attack(const int target, const PUnit* ptr){
    if(ptr == NULL)  ptr = selected;
    if(ptr == NULL){
        std::cout << "Error:Do not select a unit when using Gword." << std::endl;
        return;
    }
    if(dis2(ptr->pos, nextEnemy[target].pos) <= ptr->range && ptr->canUseSkill("Attack")){
        Operation op;
        op.id = ptr->id;
		op.type = "Attack";
        op.targets.push_back(nextEnemy[target].pos);
        cmd->cmds.push_back(op);
		nextEnemy[target].hp -= attackHp(&nextEnemy[target], ptr);
    }else{
    	vector<Pos> rang=SPC.findOneStepRange(ptr->pos, ptr->speed, BLOCK);
    	int bo=1;
    	int min_hp=INF;  //鞭彬恷富 
    	int max_dis=0;   //宣圻了崔恷垓
		Pos targ;
    	for (int i=0;i<rang.size();i++)
		if (dis2(rang[i], nextEnemy[target].pos)<=ptr->range){
			bo=0;
			int save=getAtk(rang[i], (PUnit*)&ptr);
			if (min_hp>save || min_hp==save && max_dis<dis2(ptr->pos, rang[i])){
				min_hp=save;
				max_dis=dis2(ptr->pos, rang[i]);
				targ=rang[i];
			}
		}
		if (bo) gword->move(nextEnemy[target].pos, ptr);
		else gword->move(targ, ptr);
		/*
    	Pos targ = nextEnemy[target].pos - ptr->pos;
    	if (dis2(nextEnemy[target].pos, ptr->pos) < ptr->speed) targ = ptr->pos + targ*2;
    	else targ = ptr->pos + targ;
		gword->move(shrinkPos(targ, ptr->pos), ptr);*/
	}
}

void Gword::attackWild(const PUnit* target, const PUnit* ptr){
	int bo=0;
    for (int i = 0; i < nextWild.size(); i++)
    if (nextWild[i].pos.x == target->pos.x && nextWild[i].pos.y == target->pos.y){
		attackWild(i,ptr);
		bo=1;
	}
}

void Gword::attackWild(const int target, const PUnit* ptr){
    if(dis2(ptr->pos, nextWild[target].pos) <= ptr->range && ptr->canUseSkill("Attack")){
        Operation op;
        op.id = ptr->id;
		op.type = "Attack";
        op.targets.push_back(nextWild[target].pos);
        cmd->cmds.push_back(op);
		nextWild[target].hp -= attackHp(&nextWild[target], ptr);
    }else{
		gword->move(nextWild[target].pos, ptr);
	}
}

void Gword::hammerAttack(const PUnit* target, const PUnit* ptr){
    for (int i = 0; i < nextEnemy.size(); i++)
    if (nextEnemy[i].pos.x == target->pos.x && nextEnemy[i].pos.y == target->pos.y) hammerAttack(i,ptr);
}

void Gword::hammerAttack(const int target, const PUnit* ptr){
    if(ptr == NULL)  ptr = selected;
    if(ptr == NULL){
        std::cout << "Error:Do not select a unit when using Gword." << std::endl;
        return;
    }
    if(dis2(ptr->pos, nextEnemy[target].pos) <= HAMMERATTACK_RANGE && ptr->canUseSkill("HammerAttack")){
    	if (dis2(ptr->pos, nextEnemy[target].pos) <= ptr->range && nextEnemy[target].hp <= attackHp(&nextEnemy[target], ptr)){
    		gword->attack(target, ptr);
    	}else{
    		Operation op;
        	op.id = ptr->id;
			op.type = "HammerAttack";
        	op.targets.push_back(nextEnemy[target].pos);
        	cmd->cmds.push_back(op);
			nextEnemy[target].hp -= HAMMERATTACK_DAMAGE[ptr->level] - nextEnemy[target].def;
			nextEnemy[target].buffs.push_back(PBuff(0,2,3));
		}
    }else gword->move(nextEnemy[target].pos, ptr);
}

void Gword::hammerAttackWild(const PUnit* target, const PUnit* ptr){
    for (int i = 0; i < nextWild.size(); i++)
    if (nextWild[i].pos == target->pos) hammerAttackWild(i,ptr);
}

void Gword::hammerAttackWild(const int target, const PUnit* ptr){
    if(dis2(ptr->pos, nextWild[target].pos) <= HAMMERATTACK_RANGE && ptr->canUseSkill("HammerAttack")){
    	if (dis2(ptr->pos, nextWild[target].pos) <= ptr->range && nextWild[target].hp <= attackHp(&nextWild[target], ptr)){
    		gword->attackWild(target, ptr);
    	}else{
    		Operation op;
        	op.id = ptr->id;
			op.type = "HammerAttack";
        	op.targets.push_back(nextWild[target].pos);
        	cmd->cmds.push_back(op);
			nextWild[target].hp -= HAMMERATTACK_DAMAGE[ptr->level] - nextWild[target].def;
			nextWild[target].buffs.push_back(PBuff(0,2,3));
		}
    }else gword->move(nextWild[target].pos, ptr);
}

Pos Gword::getCore(vector<PUnit*> &ptrs){
	Pos minp=Pos(MAX_DIST,MAX_DIST),maxp=Pos(0,0);
	for (int i=0;i<ptrs.size();i++){
		if (minp.x>ptrs[i]->pos.x) minp.x=ptrs[i]->pos.x;
		if (minp.y>ptrs[i]->pos.y) minp.y=ptrs[i]->pos.y;
		if (maxp.x<ptrs[i]->pos.x) maxp.x=ptrs[i]->pos.x;
		if (maxp.y<ptrs[i]->pos.y) maxp.y=ptrs[i]->pos.y;
	}
	return minp+Pos((maxp.x-minp.x)/2,(maxp.y-minp.y)/2);
}

void Gword::bfsET(PUnit* ptr){
	vector<PUnit*> shero;
	shero.clear();
	shero.push_back(ptr);
	beloneTeam[ptr->id]=enemyTeam.size();
	int l=0;
	for (;l<shero.size();l++){
		PUnit* now=shero[l];
		for (int j=0;j<enemyHis.size();j++)
		if (beloneTeam[enemyHis[j].id]==-1 && dis2(now->pos, enemyHis[j].pos)<=now->view){
			shero.push_back(&enemyHis[j]);
			beloneTeam[enemyHis[j].id]=enemyTeam.size();
		}
	}
	enemyTeam.push_back(EnemyTeam(getCore(shero), shero));
}

void Gword::buildET(){
	for (int i=0;i<enemyHis.size();i++)
	if (beloneTeam[enemyHis[i].id]==-1) bfsET(&enemyHis[i]);
}

void Gword::buildMT(){
	for (int i=0;i<myHeros.size();i++){    //贋壓黍繁壓少巡袈律坪 
		for (int j=0;j<nextEnemy.size();j++)
		if (dis2(myHeros[i].pos, nextEnemy[j].pos)<=Alert_range){
			int bo=1;
			for (int k=0;k<myTeam.size();k++)    //紗秘錦礼 
			if (myTeam[k].target->core == enemyTeam[beloneTeam[nextEnemy[j].id]].core){
				myTeam[k].addHero(&myHeros[i]);
				beloneTeam[myHeros[i].id]=k;
				bo=0;
				break;
			}
			
			if (bo){    //仟秀錦礼 
				vector<PUnit*> shero;
				shero.clear();
				shero.push_back(&myHeros[i]);
				myTeam.push_back(MyTeam(&enemyTeam[beloneTeam[nextEnemy[j].id]], shero));
				beloneTeam[myHeros[i].id]=myTeam.size()-1;
			}
			break; 
		}
	}
	
	if (myTeam.size()){
		for (int i=0;i<myHeros.size();i++)
		if (beloneTeam[myHeros[i].id]==-1){
			int min_dis=MAX_DIST;
			int steam;
			for (int j=0;j<myTeam.size();j++)
			if (dis2(myHeros[i].pos, myTeam[j].target->core)<min_dis){
				min_dis = dis2(myHeros[i].pos, myTeam[j].target->core);
				steam = j;
			}
			myTeam[steam].addHero(&myHeros[i]);
			beloneTeam[myHeros[i].id] = steam;
		}
	}else{    //音贋壓黍繁壓少巡袈律坪 
		int minWorth=INF;
		EnemyTeam* target=NULL;
		for (int i=0;i<enemyTeam.size();i++)
		if (minWorth>enemyTeam[i].worth){
			minWorth>enemyTeam[i].worth;
			target=&enemyTeam[i];
		}
	
		if (target!=NULL){
			vector<PUnit*> shero;
			shero.clear(); 
			for (int i=0;i<myHeros.size();i++){
				shero.push_back(&myHeros[i]);
				beloneTeam[myHeros[i].id]=myTeam.size()+1;
			}
			myTeam.push_back(MyTeam(target, shero));
		}
	}
}

void Gword::action(){
	int hsz=aiHeros.size(),ssz=allStrategy.size();
	//for (int j=0;j<ssz;j++) debuger.draw(allStrategy[j]);
	for (int i=0;i<hsz;i++)
	if (aiHeros[i].mHero->hp >= 0){
		//printf("%d ",i);
		for (int j=0;j<ssz;j++) aiHeros[i].addStrategy(allStrategy[j]);
		aiHeros[i].action();
	}
	//puts("");
}

void Gword::stgAttack(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgAttack(ptr, target));
}

void Gword::stgAttack(PUnit* target, Pos targetP, PUnit* ptr){
	allStrategy.push_back(new StgAttack(ptr, target, targetP));
}
void Gword::stgAttackWild(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgAttackWild(ptr, target));
}

void Gword::stgAttackObserver(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgAttackObserver(ptr, target));
}

void Gword::stgAttackWOD(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgAttackWOD(ptr, target));
}

void Gword::stgBaseAttack(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgBaseAttack(ptr,target));
}

void Gword::stgMove(const Pos target, PUnit* ptr){
	allStrategy.push_back(new StgMove(ptr, target));
}

void Gword::stgGuardMine(const Pos target, PUnit* ptr){
	allStrategy.push_back(new StgGuardMine(ptr, target));
}

void Gword::stgGoDie(const Pos target, PUnit* ptr){
	allStrategy.push_back(new StgGoDie(ptr, target));
}

void Gword::stgRunaway(const Pos target, PUnit* ptr){
	runawayRound[ptr->id]=countRound; 
	allStrategy.push_back(new StgRunaway(ptr, target));
}

void Gword::stgRunawayWOD(const Pos target, PUnit* ptr){
	runawayRound[ptr->id]=countRound; 
	allStrategy.push_back(new StgRunawayWOD(ptr, target));
}

void Gword::stgLevelup(PUnit* ptr){
	allStrategy.push_back(new StgLevelup(ptr));
}

void Gword::stgHammerAttack(PUnit* target, PUnit* ptr){
	HammerAttackRound[ptr->id]=countRound; 
	allStrategy.push_back(new StgHammerAttack(ptr, target));
}

void Gword::stgHammerAttack(PUnit* target, Pos targetP, PUnit* ptr){
	HammerAttackRound[ptr->id]=countRound; 
	allStrategy.push_back(new StgHammerAttack(ptr, target, targetP));
}

void Gword::stgHammerAttackWild(PUnit* target, PUnit* ptr){
	HammerAttackRound[ptr->id]=countRound; 
	allStrategy.push_back(new StgHammerAttackWild(ptr, target));
}

void Gword::stgSacrifice(PUnit* ptr){
	SacrificeRound[ptr->id]=countRound;
	allStrategy.push_back(new StgSacrifice(ptr));
}

void Gword::stgSacrificeWild(PUnit* ptr){
	SacrificeRound[ptr->id]=countRound;
	allStrategy.push_back(new StgSacrificeWild(ptr));
}

void Gword::stgBlink(PUnit* target, PUnit* ptr){
	allStrategy.push_back(new StgBlink(ptr, target));
}

void Gword::stgBlink(Pos target, PUnit* ptr){
	allStrategy.push_back(new StgBlink(ptr, target));
}

void Gword::stgBlinkDown(Pos target, PUnit* ptr){
	allStrategy.push_back(new StgBlinkDown(ptr, target));
}

void Gword::stgSetObserver(Pos target, PUnit* ptr){
	allStrategy.push_back(new StgSetObserver(ptr, target));
}

//_______________________Move_Control_____________________________

void Move_Control::init(){
	Heros.clear();
	blocks.clear();
	banstays.clear();
}

void Move_Control::push(const PUnit *p,Pos target,const vector<Pos> &block=BLOCK,const vector<Pos> &ban=BanStay){
	Move_ M;
	M.p=p;
	M.target=target;
	Heros.push_back(M);
	blocks.push_back(block);
	banstays.push_back(ban);
}

void Move_Control::InBanStay(Pos target,int dist){
	//if(DEBUG)DEBUGER.output<<"InBanStay:("<<target.x<<','<<target.y<<") dist="<<dist<<endl;
	Pos pos;
	for(pos.x=target.x-sqrt(dist)+eps;pos.x<=target.x+sqrt(dist)+eps;pos.x++)
		for(pos.y=target.y-sqrt(dist)+eps;pos.y<=target.y+sqrt(dist)+eps;pos.y++)
			if(checkPos(pos) && dis2(pos,target)<=dist)
				for(int j=0;j<Heros.size();j++)banstays[j].push_back(pos);
}

void Move_Control::solve(){
	//勿茅厘圭卞強汽了斤block議唹 耶紗卞強欺議泣唹 
	for(int k=0;k<Heros.size();k++){
		for(int i=0;i<blocks[k].size();){
			bool pd=false;
			for(int j=0;j<Heros.size();j++)
				if(Heros[j].p->pos == blocks[k][i])
					pd=true;
			if(pd){
				swap(blocks[k][i],blocks[k][(int)blocks[k].size()-1]);
				blocks[k].pop_back();
			}
			else i++;
		}
		
		for(int i=0;i<Heros.size();i++)
		if (i!=k) blocks[k].push_back(Heros[i].target);
	}
	
	//卞強畳貨
	/*if(DEBUG)
	{
		for(int i=0;i<Heros.size();i++)
		DEBUGER.output<<"Move_C(ID:"<<Heros[i].p->id<<",target:("<<Heros[i].target.x<<","<<Heros[i].target.y<<")n";
	}*/
	for(int i=0;i<Heros.size();i++){
		vector<Pos>target=SPC.findShortestPath(Heros[i].p->pos,Heros[i].target,Heros[i].p->speed,blocks[i],banstays[i]);
		//printf("%dn",target.size());
		/*
		for (int j=0;j<target.size();j++){
			debuger.draw(target[j]);
			debuger.draw(" ");
		}
		debuger.draw("n");*/
		//SendCommander(Heros[i].p->id,Move,target);
		Operation op;
		op.id = Heros[i].p->id;
		op.type = "Move";
		op.targets = target;
		gword->cmd->cmds.push_back(op);
	}
}

//_______________________EnemyTeam_____________________________

EnemyTeam::EnemyTeam(Pos p, vector<PUnit*> &newTeam){
	core = p;
	for (int i=0;i<newTeam.size();i++) addHero(newTeam[i]);
	countworth();
}

void EnemyTeam::addHero(PUnit* ptr){
	mHero.push_back(ptr);
	countworth();
}

void EnemyTeam::countworth(){
	worth = mHero.size();
}

void EnemyTeam::clean(){
	mHero.clear();
}

//_______________________MyTeam_____________________________

MyTeam::MyTeam(EnemyTeam* targ, vector<PUnit*> &newTeam){
	core = Pos(-1, -1);
	target = targ;
	for (int i=0;i<newTeam.size();i++) addHero(newTeam[i]);
	countworth();
}

void MyTeam::addHero(PUnit* ptr){
	mHero.push_back(ptr);
	countworth();
}

void MyTeam::countworth(){
	worth = 0;
	for (int i=0;i<mHero.size();i++)
	if (dis2(mHero[i]->pos, target->core)<=mHero[i]->speed*9) ++worth;
}

void MyTeam::runaway(){
	for (int i=0;i<mHero.size();i++){
		int bo=0;
		for (int j=0;j<nextEnemy.size();j++)
		if (dis2(mHero[i]->pos,nextEnemy[j].pos)<mHero[i]->view) bo=1;
			
		if (bo)
    	for (int j=-sqrt(mHero[i]->speed);j<=sqrt(mHero[i]->speed);j++)
    	for (int k=-sqrt(mHero[i]->speed);k<=sqrt(mHero[i]->speed);k++)
		if (dis2(Pos(0, 0), Pos(j, k)) <= mHero[i]->speed && checkPos2(mHero[i]->pos + Pos(j, k), mHero[i])){
			gword->stgRunaway(mHero[i]->pos + Pos(j, k), mHero[i]);
		}
   	}
}

int MyTeam::checkDanger(int t){
	int num=0;  //壓匯協袈律坪黍繁倖方 
	for (int i=0;i<mHero.size();i++)
	if (dis2(mHero[i]->pos, target->core)<=mHero[i]->speed*16/* && dis2(mHero[i]->pos, target->core)>=mHero[i]->speed*/) ++num;
	if (num==myHeros.size()) return 0; 
	return worth<target->worth-t;
}

void MyTeam::action(){/*
    for (int i=0;i<mHero.size();i++)
    for (int j=0;j<target->mHero.size();j++)
	gword->stgAttack(target->mHero[j], mHero[i]);*/
	int bo=0;
    for (int i=0;i<mHero.size();i++)    //好似少巡袈律坪黍繁 
    for (int j=0;j<target->mHero.size();j++)
	if (dis2(mHero[i]->pos,target->mHero[j]->pos) <= Alert_range || inBaseAttackRange(target->mHero[j]->pos)){
		bo=1;
    	for (int k=0;k<mHero.size();k++) gword->stgAttack(target->mHero[j], mHero[k]);
	}
	
	if (!bo)    //好似匯協袈律篇勸坪黍繁 
    for (int i=0;i<mHero.size();i++)
    for (int j=0;j<target->mHero.size();j++)
	if (dis2(mine_pos[0],target->mHero[j]->pos)<=Alert_range_mine){
    	for (int k=0;k<mHero.size();k++) gword->stgAttack(target->mHero[j], mHero[k]);
	}
	
	bo=0;
    for (int i=0;i<mHero.size();i++)
    for (int j=0;j<target->mHero.size();j++){
		if (!bo && dis2(mHero[i]->pos,target->mHero[j]->pos) <= mHero[i]->range) bo=1;    //壓斤媾 
		if (inBaseRange(target->mHero[j]->pos)) bo=2;    //黍繁壓介社 
	}
	
	if (!bo && checkDanger(1)) runaway();    //涙斤媾扮毛怒 
	else if (myHeroWorth>enemyHeroWorth+250 && bo==1 && checkDanger(2)) runaway();    //斤媾扮毛怒 
	
    for (int j=0;j<target->mHero.size();j++)    //好似児仇坪裡蒸凋 
    if (inBaseRange(target->mHero[j]->pos)){
    	int ski=getSkill("Sacrifice", target->mHero[j]);
		if (ski!=-1)
		if (!target->mHero[j]->skills[ski].cd && console->getBuff("Dizzy",target->mHero[j]) == NULL && 
		console->getBuff("WaitRevive",target->mHero[j]) == NULL){
    		int max_imp=0;
    		PUnit* wor=NULL;
    		for (int i=0;i<mHero.size();i++)
			if (attackedRound2[mHero[i]->id]!=countRound && console->getBuff("Dizzy",mHero[i]) == NULL && 
			console->getBuff("WaitRevive",mHero[i]) == NULL){
				int imp=0;
    			if (mHero[i]->typeId==HERO_ID[1] || mHero[i]->typeId==HERO_ID[3]){
    				if (dis2(mHero[i]->pos, target->mHero[j]->pos)<=mHero[i]->range && mHero[i]->canUseSkill("Attack")) imp=4;
    				else imp=2;
    			}else{
    				if (dis2(mHero[i]->pos, target->mHero[j]->pos)<=mHero[i]->range && mHero[i]->canUseSkill("Attack")) imp=3;
    				else imp=1;
    			}
    			if (max_imp<imp){
    				max_imp=imp;
    				wor=mHero[i];
    			}
    		}
    		if (max_imp){
    			gword->stgAttack(target->mHero[j], Pos(1,1), wor);
    			attackedRound2[wor->id]=countRound;
    			if (max_imp>=3) attackedRound[target->mHero[j]->id]=countRound;
    		}
		}
	}
}

void MyTeam::clean(){
	mHero.clear();
}

//_______________________HisUnit_____________________________

void HisUnit::newUnit(const PUnit* ptr){
	p = *ptr;
	round = console->round();
}

//_______________________Debuger_____________________________

Debuger::Debuger(){
	if (DEBUG) output.open(FILE_NAME);
}

void Debuger::draw(int a){
	if(!DEBUG) return;
	output<<a;
}

void Debuger::draw(const char *s){
	if(!DEBUG) return;
	string S(s);
	output<<S;
}

void Debuger::draw(const string s){
	if(!DEBUG) return;
	output<<s;
}

void Debuger::draw(Pos a){
	if(!DEBUG) return;
	output<<'('<<a.x<<','<<a.y<<')';
}

void Debuger::draw(const PBuff &p){
	if(!DEBUG) return;
	char s[100];
	sprintf(s,"Buff:  typeID=%d  name=%s  level=%d  timeLeft=%d",p.typeId,p.name,p.level,p.timeLeft);
	draw(s);
}

void Debuger::draw(const PSkill &p){
	if(!DEBUG) return;
	char s[100];
	sprintf(s,"Skill:  typeID=%d  name=%s  mp=%d  level=%d  maxLevel=%d  cd=%d  maxCd=%d",p.typeId,p.name,p.mp,p.level,p.maxLevel,p.cd,p.maxCd);
	draw(s);
}

void Debuger::draw(const PUnit &p){
	if(!DEBUG) return;
	char s[500];
	sprintf(s,"Unit: ID=%d name:%s typeID=%d player=%d camp=%d pos:(%d,%d) max_hp=%d hp=%d mp=%d atk=%d def=%d speed=%d exp=%d range=%d view=%d level=%dn",
		p.id,p.name,p.typeId,p.player,p.camp,p.pos.x,p.pos.y,p.max_hp,p.hp,p.mp,p.atk,p.def,p.speed,p.exp,p.range,p.view,p.level);
	draw(s);
	for(int i=0;i<p.buffs.size();i++){output<<"     ";draw(p.buffs[i]);output<<endl;}
	for(int i=0;i<p.skills.size();i++){output<<"     ";draw(p.skills[i]);output<<endl;}
	if (p.isMine()){
		output<<"     Energy:  ";
		draw(console->unitArg("Energy","Current",&p));
		output<<endl;
	}
	output<<endl;
}

void Debuger::draw(const Strategy *p){
	if(!DEBUG) return;
	draw("Strategy: name:");
	draw(p->name);
	char s[500];
	if (p->target != NULL)
		sprintf(s," workerId=%d imp=%d worth=%d targetId=%d targetP:", p->worker->id, p->imp, p->worth, p->target->id);
	else
		sprintf(s," workerId=%d imp=%d worth=%d targetId=NULL targetP:", p->worker->id, p->imp, p->worth);
	draw(s);
	draw(p->targetP);
	output<<endl;
}

void Debuger::draw(const AIHero *p){
	if(!DEBUG) return;
	output<<"/-------------------------------------------------------------------------------------/n";
	char s[500];
	sprintf(s,"AIHero mHeroId:%dn",p->mHero->id);
	draw(s);
	for (int i=0;i<p->mStrategy.size();i++) draw(p->mStrategy[i]);
}

void Debuger::draw(const PUnit *p, std::vector<Pos> &path){
	if(!DEBUG) return;
	char s[500];
	sprintf(s,"nMOVE Id:%dn",p->id);
	draw(s);
	for (int i=0;i<path.size();i++){
		draw(path[i]);
		output<<" ";
	}
	output<<endl;
}

void Debuger::draw(const PPlayerInfo *INFO){
	if(!DEBUG) return;
	char s[1010];
	memset(s,0,sizeof(s));
	if(INFO->round==0){
		sprintf(s,"MyCamp=%dn",INFO->camp);
		draw(s);
		output<<endl<<endl<<endl<<endl<<endl;
	}
	output<<"Round="<<INFO->round<<endl;
	output<<"/*************************************************************************************/n";
	output<<"myHeroWorth="<<myHeroWorth<<endl;
	output<<"enemyHeroWorth="<<enemyHeroWorth<<endl;
	
	for(int i=0;i<INFO->units.size();i++) draw(INFO->units[i]);
	draw(&heroState);
	draw(enemyTeam);
	draw(myTeam);
}

void Debuger::draw(State *p){
	if(!DEBUG) return;
	char s[50];
	sprintf(s,"State Id:%d restore:%d HP: ",p->mHero->id,p->restore);
	draw(s);
	for (int i=0;i<10;i++) output<<i<<":"<<p->hp[i]<<" ";
	output<<"n   hp2";
	for (int i=0;i<10;i++) output<<i<<":"<<p->hp2[i]<<" ";
	output<<"n";
}

void Debuger::draw(HeroState *p){
	if(!DEBUG) return;
	output<<"_______________________________________________________________________________________n";
	output<<"HeroState:n";
	for (int i=0;i<p->heros.size();i++) draw(p->heros[i]);
}

void Debuger::draw(vector<EnemyTeam> &p){
	if(!DEBUG) return;
	output<<"_______________________________________________________________________________________n";
	output<<"EnemyTeam:n";
	for (int i=0;i<p.size();i++){
		output<<"No.";
		draw(i);
		output<<": Core: ";
		draw(p[i].core);
		output<<" Worth: ";
		draw(p[i].worth);
		output<<" Member: ";
		for (int j=0;j<p[i].mHero.size();j++){
			draw(p[i].mHero[j]->id);
			output<<" ";
		}
		output<<"n";
	}
}

void Debuger::draw(vector<MyTeam> &p){
	if(!DEBUG) return;
	output<<"_______________________________________________________________________________________n";
	output<<"MyTeam:n";
	for (int i=0;i<p.size();i++){
		output<<"No.";
		draw(i);
		output<<": Core: ";
		draw(p[i].core);
		output<<" Worth: ";
		draw(p[i].worth);
		output<<" Target: ";
		draw(p[i].target->core);
		output<<" Member: ";
		for (int j=0;j<p[i].mHero.size();j++){
			draw(p[i].mHero[j]->id);
			output<<" ";
		}
		output<<"n";
	}
}

//_______________________狛殻&痕方_____________________________

bool operator<(Pos A,Pos B){
	return A.x!=B.x?A.x<B.x:A.y<B.y;
}

bool large(double a,double b){
	return a-zero>b;
}

bool equal(double a,double b){
	return !large(a,b) && !large(b,a);
}

int getLon(Pos a, Pos b){
	return abs(a.x-b.x) + abs(a.y-b.y);
}

int getSkill(const string& name, const PUnit* ptr){
    vector<PSkill> skills = ptr->skills;
    for (int i=0;i<ptr->skills.size();i++)
        if (lowerCase(ptr->skills[i].name) == lowerCase(name))
            return i;
    return -1;
}

int getBuff(const string& name, const PUnit* ptr){
    vector<PBuff> buffs = ptr->buffs;
    for (int i=0;i<ptr->buffs.size();i++)
        if (lowerCase(ptr->buffs[i].name) == lowerCase(name))
            return i;
    return -1;
}

int longestDis(Pos p,int camp){
	int res = MAX_DIST;
	if (camp == console->camp()){
		for (int i=0;i<myHeros.size();i++)
		if (myHeros[i].hp > 0){
			if (res>dis2(p, myHeros[i].pos)) res=dis2(p, myHeros[i].pos);
		}
	}else{
		for (int i=0;i<nextEnemy.size();i++)
		if (nextEnemy[i].hp > 0){
			if (res>dis2(p, nextEnemy[i].pos)) res=dis2(p, nextEnemy[i].pos);
		}
	}
	return res;
}

int attackHp(const PUnit* target, const PUnit* ptr){
	int res=ptr->atk - target->def;
	if (res<5) res = 5;
	return res;
}

int getHeroNum(int t){
    int sz = myHeros.size(), res=0;
    for (int i=0;i<sz;i++)
    if (HERO_ID[t] == myHeros[i].typeId) ++res;
    return res;
}

double getRecoverRate(const PUnit* target){
	double res = HP_RECOVER_RATE;
	if (target->camp != gword->info->camp){
		for (int i=0;i<enemyHeros.size();i++)
		if (HERO_ID[1] == enemyHeros[i].typeId && dis2(target->pos, enemyHeros[i].pos) <= CURE_RANGE){
			if (console->getBuff("BeAttacked", &enemyHeros[i])!=NULL) res += SICK_HP_CURE_RATE[enemyHeros[i].level];
			else res += HEALTHY_HP_CURE_RATE[enemyHeros[i].level];
		}
	}else{
		for (int i=0;i<myHeros.size();i++)
		if (HERO_ID[1] == myHeros[i].typeId && dis2(target->pos, myHeros[i].pos) <= CURE_RANGE){
			if (console->getBuff("BeAttacked", &myHeros[i])!=NULL) res += SICK_HP_CURE_RATE[myHeros[i].level];
			else res += HEALTHY_HP_CURE_RATE[myHeros[i].level];
		}
	}
	return res;
}

int getRecoverHp(const PUnit* target){
	double rate = getRecoverRate(target);
	double res = (double)target->max_hp*rate;
	int sres = res;
	if (large(res-(double)sres, 0.4)) ++sres;
	return sres;
}

int checkPos2(Pos p,PUnit* worker){
	if (!checkPos(p)) return 0;
	if (dis(worker->pos, p) < (double)sqrt(worker->speed)-1) return 0;
	return 1;
}

Pos runawayPos(PUnit* target){
	Pos targ;
	int max_dis = 0;
   	for (int j=0;j*j<=target->speed;j++)
   	for (int k=0;k*k<=target->speed;k++)
	if (dis2(Pos(0, 0), Pos(j, k)) <= target->speed){
   		if (checkPos(target->pos + Pos(j, k)) && max_dis < longestDis(target->pos + Pos(j, k), target->camp^1)){
   			max_dis = longestDis(target->pos + Pos(j, k), target->camp^1);
   			targ = target->pos + Pos(j, k);
   		}
   		if (checkPos(target->pos + Pos(j, -k)) && max_dis < longestDis(target->pos + Pos(j, -k), target->camp^1)){
   			max_dis = longestDis(target->pos + Pos(j, -k), target->camp^1);
   			targ = target->pos + Pos(j, -k);
   		}
   		if (checkPos(target->pos + Pos(-j, k)) && max_dis < longestDis(target->pos + Pos(-j, k), target->camp^1)){
   			max_dis = longestDis(target->pos + Pos(-j, k), target->camp^1);
   			targ = target->pos + Pos(-j, k);
   		}
   		if (checkPos(target->pos + Pos(-j, -k)) && max_dis < longestDis(target->pos + Pos(-j, -k), target->camp^1)){
   			max_dis = longestDis(target->pos + Pos(-j, -k), target->camp^1);
   			targ = target->pos + Pos(-j, -k);
   		}
   	}
   	return targ;
}

Pos jockeyPos(PUnit* target){
	Pos targ = runawayPos(target);
	Pos res = Pos(-100, -100);
	int min_dis = MAX_DIST;
	for (int i=0;i<4;i++){
		Pos starg=target->pos + Step[i];
		if (dis2(targ, starg) < min_dis && blockMap[starg.x][starg.y] != countR*2-1){
			min_dis = dis2(targ, starg);
			res = starg;
		}
	}
	return res;
}

Pos shrinkPos(Pos a,Pos b){
	if (checkPos(a)) return a;
	Pos res=a-b;
	if (a.x<0){
		res.y=-res.y*b.x/res.x;
		res.x=-b.x;
	}else if (a.x>=MAP_SIZE){
		res.y=res.y*(MAP_SIZE-b.x-1)/res.x;
		res.x=MAP_SIZE-b.x-1;
	}else if (a.y<0){
		res.x=-res.x*b.y/res.y;
		res.y=-b.y;
	}else if (a.y>=MAP_SIZE){
		res.x=res.x*(MAP_SIZE-b.y-1)/res.y;
		res.y=MAP_SIZE-b.y-1;
	}
	res=b+res;
	//printf("a: %d,%d b:%d,%d res:%d,%dn",a.x,a.y,b.x,b.y,res.x,res.y);
	return shrinkPos(res,b);
}

int checkHill(Pos p){
	bfsMap2[p.x][p.y] = ++countB;
	bfsQ2[1] = p;
	int l = 1, r = 1;
	Pos _0,_1;
	for (;l<=r && r<100;++l){
        _0 = bfsQ2[l];
        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[i][0], dir[i][1]);
            if (checkPos(_1))
			if (abs(MAP[_0.x][_0.y] - MAP[_1.x][_1.y]) <= 1 && bfsMap2[_1.x][_1.y] != countB){
				bfsQ2[++r] = _1;
				bfsMap2[_1.x][_1.y] = countB;
			}
		}
	}
	//if (r<100) printf("hill:%dn",r);
	return r<100;
}

int dangerRange(PUnit* ptr){
	return (sqrt(ptr->speed)+sqrt(ptr->range)+1.0)*(sqrt(ptr->speed)+sqrt(ptr->range)+1.0);
}

int inBaseRange(Pos p){
	return dis2(p,MILITARY_BASE_POS[console->camp()])<=MILITARY_BASE_RANGE;
}

int inBaseAttackRange(Pos p){
	if (baseWeak) return dis2(p,MILITARY_BASE_POS[console->camp()]) <= MILITARY_BASE_LARGE_RANGE;
	else return dis2(p,MILITARY_BASE_POS[console->camp()]) <= MILITARY_BASE_RANGE;
}

int checkHammerAttack(PUnit* target,PUnit* ptr){
	int res=heroState.getHp2(target, 4);
	res-=HAMMERATTACK_DAMAGE[ptr->level] - target->def;
	//if (dis2(target->pos, ptr->pos)>ptr->range) res-=ptr->atk - target->def*2;
	return res<=0;
}

int checkSacrifice(PUnit* target,PUnit* ptr){
	if (heroState.deadRound(target)<=2) return 0;
    if (dis2(ptr->pos, target->pos) <= ptr->range) return 1;
    if (moveTime(ptr, target->pos)>2) return 0;
    
	int timeLeft; 
	int buf = getBuff("Dizzy",target);
	if (buf!=-1){
		timeLeft = target->buffs[buf].timeLeft;
    	if (timeLeft>=moveTime(ptr, target->pos)) return 1;
    }
    
	buf = getBuff("WaitRevive",target);
	if (buf!=-1){
		timeLeft = target->buffs[buf].timeLeft;
    	if (timeLeft>=moveTime(ptr, target->pos)) return 1;
    }
    
    return 0;
}

int moveTime(PUnit* ptr,double lon){
	if (large(0,lon)) return 0;
	double tim=lon/sqrt(ptr->speed);
	int res=tim;
	if (large(tim-(double)res,0)) ++res;
	return res;
}

int moveTime(PUnit* ptr,Pos p){
	return moveTime(ptr,dis(p,ptr->pos));
}

int greedWorth(PUnit* worker, PUnit* ptr){
	double res=heroState.deadRound2(ptr);
	double def=0;
	int num=0;
	int ski = getSkill("Attack",ptr);
	
	for (int i=0;i<myHeros.size();i++)
	if (dis2(worker->pos, myHeros[i].pos)<=worker->view) ++num;
	if (num<3) return 10000-ptr->hp;
	
	num=0;
	for (int i=0;i<myHeros.size();i++)
	if (dis2(ptr->pos, myHeros[i].pos)<=ptr->range){
		++num;
		def+=myHeros[i].def;
	}
	
	if (!num) def=10;
	else def=def/(double)num;
	
	double atk=((double)ptr->atk / (double)ptr->skills[ski].maxCd - def);
	if (large(0.1,atk)) atk=0.1;
	res=100.0-res/atk;
	return res*1000.0;
}

int getAtk(Pos p, PUnit* ptr){
	int res=0;
	for (int i=0;i<nextEnemy.size();i++)
	if (nextEnemy[i].hp>0 && dis2(p,nextEnemy[i].pos)<=nextEnemy[i].range && nextEnemy[i].canUseSkill("Attack")){
		res+=attackHp(ptr, &nextEnemy[i]);
	}
	return res;
}
//_______________________麼狛殻_____________________________

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
	//Hidden_.getTime();//資函狼由扮寂
	//Hidden_.check();
	//cout<<time(0)<<" ";
    gword = new Gword(map,info,cmd);
	gword->pretreatment();
    
    OPT.action();
	gword->action();
    //printf("%.5fn",time(0)-x);
    delete console;
    delete gword;
}

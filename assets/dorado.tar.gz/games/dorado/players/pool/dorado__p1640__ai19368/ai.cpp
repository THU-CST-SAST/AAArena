//歌方譜崔児仇僮楚受富欺謹富議扮昨指契、焚担扮昨好似斤圭議児仇、焚担扮昨寡嵩

//哂俛議啾糊峙31
//契便峙152

#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

Console* console;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Rank = 0;
Pos mine_pos[] = {Pos(74, 75), Pos(35, 60), Pos(35, 90), Pos(115, 60), Pos(115, 90), Pos(20, 140), Pos(130, 10)};

void findShortestPath2(const PMap &, Pos, Pos, const std::vector<Pos> &, std::vector<Pos> &);

struct Gword{
    const PMap *map;
	const PPlayerInfo *info;
	PCommand *cmd; 
	vector<PUnit> nextEnemy;       //和指栽黍繁彜蓑 
    const PUnit* selected;         //瓜僉嶄議汽了
	
	Gword(const PMap &, const PPlayerInfo&, PCommand &);
	//更夛痕方 
	//~Gword();
	
	void pretreatment();
	//圓侃尖 
    void selectUnit(const PUnit*);
	//僉嶄蝶匯倖汽了岻朔議荷恬辛參音勧汽了議歌方岷俊聞喘宸倖汽了 
    void attack (const PUnit* target, const PUnit* = NULL);
    void attack (const int target, const PUnit* = NULL);
    //峺協蝶匯汽了好似
    int attackHp (const PUnit* target, const PUnit*);
    //峺協汽了好似方峙 
};

Gword* gword;
int vst[MAP_SIZE][MAP_SIZE];                                   //鴻朴仇夕 
Pos Q[MAP_SIZE * MAP_SIZE + 1], Q_prior[MAP_SIZE][MAP_SIZE];   //鴻朴錦双 
int countF = 0;

Gword::Gword(const PMap &_map, const PPlayerInfo &_info, PCommand &_cmd){
	map = &_map;
	info = &_info;
	cmd = &_cmd;
}

void Gword::pretreatment(){
    console = new Console(*map, *info, *cmd);
    console->changeShortestPathFunc(findShortestPath2);
    
    for(int i = 0; i < info->units.size(); ++i){
        if(info->units[i].isHero()){
            if(info->units[i].camp == info->camp^1){
				nextEnemy.push_back((PUnit)(info->units[i]));   //黍圭哂俛
				nextEnemy[nextEnemy.size()-1].hp += (int)((double)nextEnemy[nextEnemy.size()-1].max_hp*HP_RECOVER_RATE);
			}
        }
    }
}

void Gword::selectUnit(const PUnit* selectedUnit){
    selected = selectedUnit;
    console->selectUnit(selectedUnit);
}

void Gword::attack(const PUnit* target, const PUnit* ptr){
    for (int i = 0; i < nextEnemy.size(); i++)
    if (nextEnemy[i].pos.x == target->pos.x && nextEnemy[i].pos.y == target->pos.y) attack(i,ptr);
}

void Gword::attack(const int target, const PUnit* ptr){
    if(ptr == NULL)  ptr = selected;
    if(ptr == NULL){
        std::cout << "Error:Do not select a unit when using Gword." << std::endl;
        return;
    }
    if(dis2(ptr->pos, nextEnemy[target].pos) <= ptr->range && ptr->canUseSkill("Attack")){
        Operation op;
        op.id = ptr->id;
		op.type = "Attack";
        op.targets.push_back(nextEnemy[target].pos);
        cmd->cmds.push_back(op);
		nextEnemy[target].hp -= attackHp(&nextEnemy[target], ptr);
    }else console->move(nextEnemy[target].pos, ptr);
}

int Gword::attackHp(const PUnit* target, const PUnit* ptr){
	int res=ptr->atk - target->def;
	if (res<5) res = 5;
	return res;
}
//_______________________G_word_____________________________

void findShortestPath2(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//個序儖揃
{
    PMap map0 = map;
    int _sz = blocks.size();

    ++countF;
    _path.clear();
    int min = MAP_SIZE*MAP_SIZE*MAP_SIZE;
    Pos nearest = start;
    for (int i=0; i<_sz; ++i)
    {
        if (checkPos(blocks[i]))
            vst[blocks[i].x][blocks[i].y] = countF;
    }
    if (!checkPos(start) || !checkPos(dest))
    {
        _path.push_back(Pos());
        return;
    }
    vst[start.x][start.y] = vst[dest.x][dest.y] = countF - 1;

    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        if (!front) {
			for (int i=0;i<4;i++) dir_ord[i]=i;
			random_shuffle(dir_ord, dir_ord+4);
		}else if (_0.y == Q_prior[_0.x][_0.y].y) {
        	dir_ord[0]=0;
        	dir_ord[1]=3;
        	dir_ord[2]=1;
        	dir_ord[3]=2;
        }else{
        	dir_ord[0]=1;
        	dir_ord[1]=2;
        	dir_ord[2]=0;
        	dir_ord[3]=3;
        }

        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map0[_0.x][_0.y] - map0[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (dis2(_1, dest) < min || (dis2(_1, dest) == min && dis2(_1, start) > dis2(nearest, start)))
                {
                    min = dis2(_1, dest);
                    nearest = _1;
                }
            }
        }
    }

    if (vst[nearest.x][nearest.y] == countF) {
        for (_0 = nearest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    }
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    gword = new Gword(map,info,cmd);
    gword->pretreatment();
    //厘議哂俛厘僮楚熟謹議哂俛厘僮楚熟富議哂俛黍圭哂俛署嵩 
    vector<const PUnit*> myHeroes, myHealthyHeroes, mySickHeroes, Wilds, Mines; 
    PUnit* myBase = NULL;
    PUnit* enemyBase = NULL;
    for(int i = 0; i < info.units.size(); ++i) //繍unit蛍窃
    {
        if(info.units[i].isHero()) //哂俛
        {
            if(info.units[i].camp == info.camp) //厘圭哂俛
            {
                myHeroes.push_back((PUnit*)(&info.units[i]));
                if(console->unitArg("hp", "c", (PUnit*)(&info.units[i])) < console->unitArg("hp", "m", (PUnit*)(&info.units[i])) / 3) //厘圭僮楚熟富哂俛
                {
                    mySickHeroes.push_back((PUnit*)(&info.units[i]));
                }
                else //厘圭僮楚熟謹議哂俛
                {
                    myHealthyHeroes.push_back((PUnit*)(&info.units[i]));
                }
            }
            //else if(info.units[i].camp == info.camp^1)
			//	enemyHeroes.push_back((PUnit*)(&info.units[i])); //黍圭哂俛
        }
        else if(info.units[i].isWild()) //勸講
        {
            Wilds.push_back((PUnit*)(&info.units[i]));
        }
        else if(strcmp(info.units[i].name, "MilitaryBase") == 0) //児仇
        {
            if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]); //厘圭児仇
            else enemyBase = (PUnit*)(&info.units[i]); //黍圭児仇
        }
        else if(strcmp(info.units[i].name, "Mine") == 0) //署嵩
        {
            Mines.push_back((PUnit*)(&info.units[i]));
        }
    }
    

	console->chooseHero(HERO_NAME[0]);
	console->chooseHero(HERO_NAME[1]);
	console->chooseHero(HERO_NAME[2]);
	console->chooseHero(HERO_NAME[3]);
    
    bool existenemy = false;
    //僮楚熟謹議哂俛壓囑欺黍繁扮辛參麼強好似枠慧室嬬壅噸宥好似 
    for(int i = 0; i < myHealthyHeroes.size(); ++i)
    {
    	int target;
		int minhp=100000; 
        gword->selectUnit(myHealthyHeroes[i]);
        for(int j = 0; j < gword->nextEnemy.size(); ++j)
        if (gword->nextEnemy[j].hp>=0)
        {
            existenemy = true;
            if (minhp>gword->nextEnemy[j].hp){
            	minhp=gword->nextEnemy[j].hp;
            	target=j;
            }
        }
    	if (minhp<100000)
		{
        	if(dis2(myHealthyHeroes[i]->pos, gword->nextEnemy[target].pos) <= myHealthyHeroes[i]->range)
        	{
            	//console->useSkill("HammerAttack", gword->nextEnemy[j]);
            	gword->attack(&gword->nextEnemy[target]);
        	}else console->move(gword->nextEnemy[target].pos);
    	}
    }
    
    //*********************************************
    
    
    //綜僮楚熟詰議哂俛指欺児仇俚連 
    for(int i = 0; i < mySickHeroes.size(); ++i)
    {
        gword->selectUnit(mySickHeroes[i]);
        console->move(MILITARY_BASE_POS[console->camp()]);
    }
    
    //僮楚熟詰議哂俛峪嗤了噐児仇好似袈律坪嘉氏麼強好似巓律議黍繁 
    for(int i = 0; i < mySickHeroes.size(); ++i)
    {
        gword->selectUnit(mySickHeroes[i]);
        for(int j = 0; j < gword->nextEnemy.size(); ++j)
        if (gword->nextEnemy[j].hp>=0)
        {
            if(dis2(mySickHeroes[i]->pos, gword->nextEnemy[j].pos) <= HAMMERATTACK_RANGE 
                && dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
            {
                //console->useSkill("HammerAttack", gword->nextEnemy[j]);
                gword->attack(&gword->nextEnemy[j]);
                break;
            }
        }
    }
    
    //児仇壟欺好似扮侭嗤哂俛指社隠擦児仇倦夸寡嵩賜好似斤圭児仇 
    /*
    if(myBase->hp < 3 * MILITARY_BASE_HP / 4)
    {
        for(int i = 0; i < myHealthyHeroes.size(); ++i)
        {
            console->callBackHero(myHealthyHeroes[i]);
            console->move(MILITARY_BASE_POS[console->camp()], myHealthyHeroes[i]);
        }
    }
    else //倦夸輝嗤熟謹議諾雫宗慎哂俛扮岷俊容斤圭児仇輝諾雫哂俛方音謹扮祥寡嵩 
    {*/
	if(!existenemy){
        for(int i = 0; i < myHealthyHeroes.size(); ++i)
		{
			console->move(mine_pos[0], myHealthyHeroes[i]);
			//move(myHealthyHeroes[i]->pos+Pos(4,4), myHealthyHeroes[i]);
		}
    }

    //哂俛方厮将器欺貧祥幅雫哂俛 勝辛嬬枠幅雫吉雫熟詰議哂俛 
    if(myHeroes.size() == HERO_LIMIT)
    {
        PUnit lowest_level_hero;
        int tmp_level = HERO_LEVEL_LIMIT,mindis = MAP_SIZE*MAP_SIZE*MAP_SIZE;
        for(int i = 0; i < myHeroes.size(); ++i)
        {
            gword->selectUnit(myHeroes[i]);
            if(console->unitArg("level", "c") < tmp_level || (console->unitArg("level", "c") == tmp_level && dis2(MILITARY_BASE_POS[console->camp()], myHeroes[i]->pos)<mindis))
            {
                 tmp_level = console->unitArg("level", "c");
                 mindis=dis2(MILITARY_BASE_POS[console->camp()], myHeroes[i]->pos);
                 lowest_level_hero = (*myHeroes[i]);
            }
        }
        Pos lowest_level_hero_pos = lowest_level_hero.pos;
        //console->callBackHero(&lowest_level_hero);
        //printf("%d-%d<=%dn",console->gold(),console->goldCostCurrentRound(),console->levelUpCost(tmp_level));
        if(console->gold() > console->levelUpCost(tmp_level))
        {
        	//勣幅雫議哂俛鉦宣児仇曳熟垓枠綜凪指欺児仇 
        	//puts("233");
            Pos target_pos = MILITARY_BASE_POS[console->camp()];
            gword->selectUnit(&lowest_level_hero);
            console->move(target_pos);
            if(dis2(MILITARY_BASE_POS[console->camp()], lowest_level_hero_pos) < LEVELUP_RANGE) //勣幅雫議哂俛壓児仇現除岷俊幅雫 
            {
                console->buyHeroLevel(&lowest_level_hero);
            }
        }   
    }
    delete console;
}

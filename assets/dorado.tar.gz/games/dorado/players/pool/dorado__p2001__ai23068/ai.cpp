#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"

#include <assert.h>
#include <map>
#include <cmath>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <functional>

using namespace std;

enum Plan {None = 0, WeiSuo = 1, Running = 2, GoMining = 3, Mining = 4, Fighting = 5, GoTarget = 6, GoWinning = 7, GoDefence = 8};

static const double PI = acos(-1.0);
static const int NEW_HERO_COST = NEW_SCOUTER_COST;
static const int TEAM_RANGE = 144;
static const int TEAM_GATHER_RANGE = 81;
static const double Dragon_POWER = (Dragon_HP + 50) * (1.0 * Dragon_ATK / Dragon_ATTACK_MAXCD + 2 * Dragon_DEF);
static const double Roshan_POWER = (Roshan_HP + 50) * (1.0 * Roshan_ATK / Roshan_ATTACK_MAXCD + 2 * Roshan_DEF);
static const vector<Pos> EmptyPosVector;
static const Pos EmptyPos = Pos();

Console* console;
PCommand* CMD;
const PPlayerInfo* INFO;
PMap MAP;
bool used[99];
bool dizzy[99];
int hp[99];
static bool canReach[MAP_SIZE][MAP_SIZE];
static int height[MAP_SIZE][MAP_SIZE];
static int mineLastVisit[MINE_NUM];
static const double eps = 1e-8;
double SQRT[1005];
vector<Pos> BLOCK, BANSTAY;
bool inBlock[MAP_SIZE][MAP_SIZE];
vector<PUnit*> goMiningHeros;

bool canSee(Pos a, Pos b, int view = 144) {return dis2(a, b) <= view && height[b.x][b.y] - height[a.x][a.y] <= 2;}
bool isDizzy(const PUnit* unit) {return dizzy[unit->id];}
bool canUse(const PUnit* unit) {return !used[unit->id] && !isDizzy(unit);}
void setUsed(const PUnit* unit) {used[unit->id] = true;}
int getHp(const PUnit* unit) {return unit->id == 98 ? unit->hp : hp[unit->id];}
void loseHp(const PUnit* unit, int d) {hp[unit->id] -= d;}
bool isWeak(const PUnit* unit) {return (double)getHp(unit) / unit->max_hp <= 0.2;}
bool isWinOrDie(const PUnit* unit) {return unit->findBuff("WinOrDie") && !unit->findBuff("WaitRevive") && !isDizzy(unit);}
int getDamage(int atk, PUnit* unit) {return max(atk - unit->def, 5);}
int getRevivingTime(const PUnit* unit)
{
	if (!unit || unit->id == 98) return -1; 
	const PBuff* buff = unit->findBuff("Reviving");
	if (!buff) return -1;
	return buff->timeLeft;
}
bool isAlive(const PUnit* unit)
{
	if (!unit) return false;
	if (getHp(unit) <= 0 || getRevivingTime(unit) >= 0) return false;
	if (unit->isMine()) return true;
	return unit->atk > 0;
}
int getHeroType(const PUnit* unit)
{
	if (lowerCase(unit->name) == lowerCase("Hammerguard")) return 1;
	if (lowerCase(unit->name) == lowerCase("Berserker")) return 2;
	if (lowerCase(unit->name) == lowerCase("Master")) return 3;
	if (lowerCase(unit->name) == lowerCase("Scouter")) return 4;
	return 0;
}
int getMineId(Pos pos)
{
	for (int i = 0; i < MINE_NUM; i++) if (MINE_POS[i] == pos) return i;
	return -1;
}
Pos wildPosNearMinePos(Pos pos)
{
	int id = getMineId(pos);
	switch (id)
	{
	case 0:
		return MINE_POS[0];
	case 1:
		return Dragon_pos[0];
	case 2:
		return Roshan_pos[0];
	case 3:
		return Roshan_pos[1];
	case 4:
		return Dragon_pos[1];
	case 5:
		return Dragon_pos[2];
	case 6:
		return Dragon_pos[3];
	default:
		return Pos();
	}
}
Pos center(const vector<Pos>& heros)
{
	Pos s(0, 0);
	for (auto i : heros) s = s + i;
	return Pos((double)s.x / heros.size() + 0.5, (double)s.y / heros.size() + 0.5);
}
string intToString(int a)
{
    char ch[20];
    sprintf(ch,"%d",a);
    return ch;
}
namespace Rand
{
	static unsigned int rand(unsigned int m)
	{
#ifdef WIN32
		return ((rand() << 15) + rand()) % m;
#else
		return ::rand() % m;
#endif
	}
	static double randomDouble(double l, double r) {return l + rand(2147483648U) / 2147483648.0 * (r - l);}
	static int randomWithProbability(int n, double* prob, bool weisuo = true)
	{
		if (!n) return 0;
		double max1 = 0, max2 = 0;
		int p1, p2;
		for (int i = 0; i < n; i++)
		{
			if (prob[i] > max1) max2 = max1, p2 = p1, max1 = prob[i], p1 = i;
			else if (prob[i] > max2) max2 = prob[i], p2 = i;
		}
		if (weisuo && max1 >= max2 * 2) return p1;
		unsigned int m = 2147483648U;
		int x = rand(m);
		double p = 0;
		for (int i = 0; i < n; i++)
		{
			p += prob[i];
			if (x < p * m) return i;
		}
		return p1;
	}
};
//#define DEBUG
class Debuger
{
#ifdef DEBUG
	ofstream fout;
#endif
	
public:
#ifdef DEBUG
	Debuger() : fout("myAiLog.txt") {}
#endif

	Debuger& operator <<(const char& x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const char* x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const string& x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const size_t& x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const int& x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const double& x)
	{
#ifdef DEBUG
		fout<<x;
#endif
		return *this;
	}
	Debuger& operator <<(const Pos& pos)
	{
#ifdef DEBUG
		fout<<"("<<pos.x<<", "<<pos.y<<")";
#endif
		return *this;
	}
	void flush()
	{
#ifdef DEBUG
		fout.flush();
#endif	
	}
	void print()
	{
#ifdef DEBUG
		
		for (int i = 0; i <CMD->cmds.size(); ++i)
		{
			//Operation a = cc.cmds[i];
			//PUnit* b =console->getUnit(17);
			fout << "round:" << console->round() << 'n';

			fout << CMD->cmds[i].type << ' ' << CMD->cmds[i].id<<' ' << console->getUnit(CMD->cmds[i].id)->name << 'n';
			for (int j = 0; j < CMD->cmds[i].targets.size(); ++j)
				fout << CMD->cmds[i].targets[j] << "  ";
			fout << 'n';
			fout << 'n';
		}
#endif
	}
} debuger;
/*	
#include <fstream>
static ofstream debuger("myAiLog.txt");

void print()
{
	PCommand cc = *CMD;
	for (int i = 0; i <cc.cmds.size(); ++i)
	{
		//Operation a = cc.cmds[i];
		//PUnit* b =console->getUnit(17);
		debuger << "round:" << console->round() << 'n';

		debuger << cc.cmds[i].type << ' ' << cc.cmds[i].id<<' ' << console->getUnit(cc.cmds[i].id)->name << 'n';
		for (int j = 0; j < cc.cmds[i].targets.size(); ++j)
			debuger << cc.cmds[i].targets[j] << "  ";
		debuger << 'n';
		debuger << 'n';
	}
}
*/
// 747929791's findShortestPath() %%%
struct Legal_Path_Logical//向量逻辑必经点集
{
	int offset;
	Legal_Path_Logical():offset(8){}
	struct Node{Pos a,b;bool type;}nd;//逻辑结点，type=1代表a为必经点,type=0代表a,b中经过一个即可
	vector<Node>a[17][17];
	vector<Node>* operator()(int x,int y){return &a[x+offset][y+offset];}//调用方法
	static int cmp(const Pos &a,const Pos &b){return a.x*a.x+a.y*a.y<b.x*b.x+b.y*b.y;}
	void init()//预处理
	{
		vector<Pos>b;
		int i;
		Pos S(0,0),T,M;
		for(T.x=-8;T.x<=8;T.x++)
			for(T.y=-8;T.y<=8;T.y++)
			{
				//计算向量T的逻辑节点
				b.clear();
				for(M.x=min(T.x,0);M.x<=max(T.x,0);M.x++)
					for(M.y=min(T.y,0);M.y<=max(T.y,0);M.y++)
						if((M.x==0&&M.y==0)||checkOnLine(S,T,M))b.push_back(M);
				sort(b.begin(),b.end(),cmp);
				for(i=0;i<b.size();)
				{
					if(i+1<b.size() && dis2(b[i],b[i+1])>1)
					{
						//逻辑可选点
						nd.a=b[i];
						nd.b=b[i+1];
						nd.type=0;
						a[T.x+offset][T.y+offset].push_back(nd);
						i+=2;
					}
					else
					{
						//逻辑必经点
						nd.a=b[i];
						nd.type=1;
						a[T.x+offset][T.y+offset].push_back(nd);
						i++;
					}
				}
			}
	}
} LPL;
class Shortest_Path_Class//计算最短路主体类
{
	public:
		short _index,round_index;//index标记与round_index标记
		Pos q[30010];//BFS队列
		Pos Scheme[MAP_SIZE][MAP_SIZE];//记录路径的前驱
		Pos Scheme_OneStep[MAP_SIZE][MAP_SIZE];//记录路径的任意一个起点
		double dist[MAP_SIZE][MAP_SIZE];
		short pd_inq[MAP_SIZE][MAP_SIZE];//_index标记
		short pd_round[MAP_SIZE][MAP_SIZE];//round_index标记

		//通过地图a的高度差限制判定S能否直达T
		bool connection(const Pos &S,const Pos &T)
		{
			vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
			//printf("  connection:(%d,%d)->(%d,%d)n",S.x,S.y,T.x,T.y);
			//for(int i=0;i<b->size();i++)printf("   type=%d a(%d,%d) b(%d,%d)n",(*b)[i].type,(*b)[i].a.x,(*b)[i].a.y,(*b)[i].b.x,(*b)[i].b.y);
			bool Pa=true,Pb=false;
			for(int i=1;i<b->size();i++)
			{
				//printf("   i=%dn",i);
				if((*b)[i].type==1)
				{
					if(Pa && abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
					}
					else if(Pb && abs(height[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
					}
					else return false;
				}
				else
				{
					Pa=(abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
					Pb=(abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
					if(!(Pa||Pb))return false;
				}
			}
			return true;
		}

		//给出一条通过地图a的高度差限制由S直达T的四连通路径
		vector<Pos> connectionScheme(const Pos &S,const Pos &T)
		{
			vector<Pos>re;
			vector<Legal_Path_Logical::Node> *b=LPL((T-S).x,(T-S).y);
			bool Pa=true,Pb=false;
			re.push_back(S);
			for(int i=1;i<b->size();i++)
			{
				if((*b)[i].type==1)
				{
					if(Pa && abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
						if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].a);
						re.push_back(S+(*b)[i].a);
					}
					else if(Pb && abs(height[S.x+(*b)[i-1].b.x][S.y+(*b)[i-1].b.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA)
					{
						Pa=true;
						Pb=false;
						if((*b)[i-1].type==0)re.push_back(S+(*b)[i-1].b);
						re.push_back(S+(*b)[i].a);
					}
					else return EmptyPosVector;
				}
				else
				{
					Pa=(abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].a.x][S.y+(*b)[i].a.y])<=MOVE_HEIGHT_DELTA);
					Pb=(abs(height[S.x+(*b)[i-1].a.x][S.y+(*b)[i-1].a.y]-height[S.x+(*b)[i].b.x][S.y+(*b)[i].b.y])<=MOVE_HEIGHT_DELTA);
					if(!(Pa||Pb))return EmptyPosVector;
				}
			}
			return re;
		}

		//考虑block障碍以Start为0距离起点对 全图/目标点Target 做BFS将路径起点信息存至Scheme和Scheme_OneStep(优先选择无block点,无路可走是可以选block点)，所有BFS到的点集存储于pb_inq[]==_index
		Pos findGoodPath(const vector<Pos>Start,const vector<Pos> &block,Pos Target=Pos(-1,-1))
		{
			int minD = 1e9;
			Pos returnTarget;
			vector<Pos>Block_Start_Save;//存储没有扩展的障碍点，结束后重新扩展
			Pos S,T;
			++_index;
			for(int i=0;i<block.size();i++)
				if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
				height[block[i].x][block[i].y]+=100;
			int l=0,r=-1,dir_ord[4]={0,1,2,3};
			for(int i=0;i<Start.size();i++)
			{
				pd_inq[Start[i].x][Start[i].y]=_index;
				Scheme_OneStep[Start[i].x][Start[i].y]=Start[i];
				q[++r]=Start[i];
			}
			while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
			{
				S=q[l++];
				if(height[S.x][S.y]>=99)
				{
					Block_Start_Save.push_back(S);
					continue;
				}
				random_shuffle(dir_ord, dir_ord+4);
				for(int k=0;k<4;k++)
				{
					T.x=S.x+dir[dir_ord[k]][0];
					T.y=S.y+dir[dir_ord[k]][1];
					if(checkPos(T) && pd_inq[T.x][T.y]!=_index)
						if(height[T.x][T.y]>=99 || abs(height[S.x][S.y]-height[T.x][T.y])<=MOVE_HEIGHT_DELTA)
						{
							pd_inq[T.x][T.y]=_index;
							Scheme[T.x][T.y]=S;
							Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
							q[++r]=T;
							int dis = dis2(T, Target); 
							if (Target.x != -1)
								if (dis < minD) minD = dis, returnTarget = T;
						}
				}
			}
			for(int i=0;i<block.size();i++)
				if(Target.x==-1||block[i].x!=Target.x||block[i].y!=Target.y)
				height[block[i].x][block[i].y]-=100;
			if((Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))
				if(Block_Start_Save.size())
				{
					l=0,r=-1;
					for(int i=0;i<Block_Start_Save.size();i++)q[++r]=Block_Start_Save[i];
						while(l<=r && (Target.x==-1 || pd_inq[Target.x][Target.y]!=_index))//重新对block点BFS
						{
							S=q[l++];
							random_shuffle(dir_ord, dir_ord+4);
							for(int k=0;k<4;k++)
							{
								T.x=S.x+dir[dir_ord[k]][0];
								T.y=S.y+dir[dir_ord[k]][1];
								if(checkPos(T) && pd_inq[T.x][T.y]!=_index)
									if(abs(height[S.x][S.y]-height[T.x][T.y])<=MOVE_HEIGHT_DELTA)
									{
										pd_inq[T.x][T.y]=_index;
										Scheme[T.x][T.y]=S;
										Scheme_OneStep[T.x][T.y]=Scheme_OneStep[S.x][S.y];
										q[++r]=T;
									}
							}
						}
				}
			return returnTarget;
		}

		//寻找一条由Start到Target一步能到达的四连通路径(必须保证答案存在和Scheme合法)
		vector<Pos> findOneStepScheme(Pos Start,Pos Target,const vector<Pos> &block)
		{
			vector<Pos>re;
			for(int i=0;i<block.size();i++)
				if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
				height[block[i].x][block[i].y]+=100;

			for(;Target!=Start;Target=Scheme[Target.x][Target.y])
			{
				vector<Pos>a=connectionScheme(Target,Scheme[Target.x][Target.y]);
				a.pop_back();
				for(int i=0;i<a.size();i++)re.push_back(a[i]);
				if(re.size()>20000)
				{
					printf("findOneStepScheme Error!!! Start=(%d,%d) Target=(%d,%d) ",Start.x,Start.y,Target.x,Target.y);
					printf("  vector:");for(int j=0;j<20;j++)printf("(%d,%d)",re[j].x,re[j].y);
					printf("nScheme:n");
					for(int x=Start.x-5;x<=Start.x+5;x++,cout<<'n')
						for(int y=Start.y-5;y<=Start.y+5;y++)
							if(checkPos(Pos(x,y)))printf("(% 3d,% 3d)",Scheme[x][y].x,Scheme[x][y].y);
							else printf("(///,///)");
				}
			}
			re.push_back(Start);
			reverse(re.begin(),re.end());
			for(int i=0;i<block.size();i++)
				if((block[i].x!=Start.x||block[i].y!=Start.y)&&(block[i].x!=Target.x||block[i].y!=Target.y))
				height[block[i].x][block[i].y]-=100;
			return re;
		}

		vector<Pos>a;//用于存储周边点坐标
		int round[MAP_SIZE][MAP_SIZE];//依据当前起点到达坐标的预计回合数

		//返回起点S出发speed速度之内能到达的点集并记录至a数组(考虑障碍点集block)
		vector<Pos> findOneStepRange(Pos Start,int speed,const vector<Pos> &block)
		{
			++_index;
			for(int i=0;i<block.size();i++)
			{
				if(block[i].x!=Start.x||block[i].y!=Start.y)
					height[block[i].x][block[i].y]+=100;
			}
			int l=0,r=0;
			Pos S,T,O;
			for(O.x=-(int)SQRT[speed];O.x<=(int)SQRT[speed];O.x++)
				for(O.y=-(int)SQRT[speed-O.x*O.x];O.y<=(int)SQRT[speed-O.x*O.x];O.y++)
				{
					T=Start+O;
					if(checkPos(T))dist[T.x][T.y]=1e9;
				}
			dist[Start.x][Start.y]=0;
			q[0]=Start;pd_inq[Start.x][Start.y]=_index;
			while(l<=r)
			{
				S=q[l++];
				if(height[S.x][S.y]>=99)continue;
				pd_inq[S.x][S.y]=0;
				for(O.x=-(int)SQRT[speed];O.x<=(int)SQRT[speed];O.x++)
					for(O.y=-(int)SQRT[speed-O.x*O.x];O.y<=(int)SQRT[speed-O.x*O.x];O.y++)
					{
						T=S+O;
						if(checkPos(T))
						{
							if(dist[S.x][S.y]+SQRT[dis2(S,T)]<=SQRT[speed]+eps && dist[S.x][S.y]+SQRT[dis2(S,T)]<dist[T.x][T.y]-eps)
							{
								bool isBlock=(height[T.x][T.y]>=99);
								if(isBlock)height[T.x][T.y]-=100;
								if(connection(S,T))
								{
									dist[T.x][T.y]=dist[S.x][S.y]+SQRT[dis2(S,T)];
									Scheme[T.x][T.y]=S;
									if(pd_inq[T.x][T.y]!=_index)
									{
										pd_inq[T.x][T.y]=_index;
										q[++r]=T;
									}
								}
								if(isBlock)height[T.x][T.y]+=100;
							}
						}
					}
			}
			a.clear();
			for(int i=0;i<=r;i++)if(height[q[i].x][q[i].y]<=99)a.push_back(q[i]);
			for(int i=0;i<block.size();i++)
			{
				if(block[i].x!=Start.x||block[i].y!=Start.y)
					height[block[i].x][block[i].y]-=100;
			}
			random_shuffle(a.begin(),a.end());
			return a;
		}

		//返回由Start到Target速度为Speed时不可经block,不可在BanStays停留当前回合的移动路径
		vector<Pos> findShortestPath(Pos Start,Pos Target,int speed,const vector<Pos> &block=EmptyPosVector,const vector<Pos>&BanStays=EmptyPosVector)
		{
			int i;
			//cout<<"===========AAA=========="<<'n';
			vector<Pos>around=findOneStepRange(Start,speed,block);
			for(i=0;i<around.size();i++)
				if(around[i]==Target)
					break;
			if(i<around.size())
			{
				//一步可达
				return findOneStepScheme(Start,Target,block);
			}
			else
			{
				//一步不可达
				vector<Pos>around_save=around;
				vector<Pos>scheme_save(around);
				for(i=0;i<scheme_save.size();i++)scheme_save[i]=Scheme[scheme_save[i].x][scheme_save[i].y];
				map<int,bool>hash;
				bool fuck = false;
				for(i=0;i<BanStays.size();i++)
					if (BanStays[i]!=Start&&BanStays[i]!=Target) hash[BanStays[i].x*MAP_SIZE+BanStays[i].y]=true;
					else fuck = true;
				for(i=0;i<around.size();)
				if(around[i]!=Start&&around[i]!=Target)
				{
					if(hash.find(around[i].x*MAP_SIZE+around[i].y)!=hash.end())
					{
						swap(around[i],around[(int)around.size()-1]);
						around.pop_back();
					}
					else i++;
				}
				else i++;
				bool empty = true;
				for (auto i : around) if (i!=Start&&i!=Target) empty=false;
				if (empty || fuck) around = around_save;
				debuger<<"===========000==========  "<<Start<<' '<<Target<<' '<<empty<<' '<<fuck<<'n';
				//for (auto i : around) debuger<<i<<' ';debuger<<'n';
				vector<Pos> block_save(block);
				if (!empty && !fuck) for(i=0;i<BanStays.size();i++)block_save.push_back(BanStays[i]);
				Target = findGoodPath(around,block_save,Target);
				if (!checkPos(Target) || pd_inq[Target.x][Target.y]!=_index) return EmptyPosVector;
				//cout<<"===========1111=========="<<' '<<Target<<'n';
				//if(pd_inq[Target.x][Target.y]!=_index) Target = newTarget;//return EmptyPosVector;
				Pos OneStep=Scheme_OneStep[Target.x][Target.y];
				for(i=0;i<around_save.size();i++)Scheme[around_save[i].x][around_save[i].y]=scheme_save[i];
				//cout<<"===========222=========="<<'n';
				return findOneStepScheme(Start,OneStep,block);
				//cout<<"===========333=========="<<'n';
			}
		}
		
		//根据起点速度和障碍构造全局信息(Hero用)
		void build(Pos Start,int speed,const vector<Pos> &block=EmptyPosVector)
		{
			for(int i=0;i<MAP_SIZE;i++)
				for(int j=0;j<MAP_SIZE;j++)
					Scheme[i][j]=EmptyPos;
			round_index++;
			vector<Pos>around;
			findOneStepRange(Start,speed,block);
			around.push_back(Start);
			pd_round[Start.x][Start.y]=round_index;
			round[Start.x][Start.y]=0;
			findGoodPath(around,block);
			Scheme[Start.x][Start.y]=Pos(-100,-100);
		}

		//O(n)计算当前起点到目标点的估计回合数,若无法到达返回10000(调用前必须build())
		int distance(Pos Target,int speed)
		{
			if(Scheme[Target.x][Target.y]==EmptyPos)return 10000;
			if(pd_round[Target.x][Target.y]==round_index)return round[Target.x][Target.y];
			int re=0;
			Pos last;
			for(Pos now=Target;checkPos(now);last=now,now=Scheme[now.x][now.y])
			{
				if(dis2(Target,now)>speed)
				{
					re=distance(last,speed)+1;
					pd_round[Target.x][Target.y]=round_index;
					round[Target.x][Target.y]=re;
					return re;
				}
			}
			pd_round[Target.x][Target.y]=round_index;
			round[Target.x][Target.y]=1;
			return 1;
		}

} SPC;
class Move_Control//移动控制类(主要用于控制大量单位移动导致的卡位)
{
	//使用方法：每回合开始时init()，将选择移动的单位以及目的地push()，回合结束时solve()同一发送命令
	private:
		bool type; //type=0:normal, type=1:together
		struct Move_{const PUnit *p;int speed;Pos target;};
		vector<Move_>Heros;
		vector<vector<Pos>>blocks;
		vector<vector<Pos>>banstays;
	public:
		Move_Control(int t): type(t) {}
		void init(){Heros.clear();blocks.clear();banstays.clear();}
		void push(const PUnit *p,Pos target,const vector<Pos> &block=BLOCK,const vector<Pos> &ban=BANSTAY)
		{
			Move_ M;
			M.p=p;
			M.speed=p->speed;
			M.target=target;
			Heros.push_back(M);
			blocks.push_back(block);
			banstays.push_back(ban);
		}

		//将需求列表里的所有单位附加限定：禁止驶入target附近dist
		void InBanStay(Pos target,int dist)
		{
			//if(DEBUG)DEBUGER.output<<"InBanStay:("<<target.x<<','<<target.y<<") dist="<<dist<<'n';
			Pos pos;
			for(pos.x=target.x-SQRT[dist]+eps;pos.x<=target.x+SQRT[dist]+eps;pos.x++)
				for(pos.y=target.y-SQRT[dist]+eps;pos.y<=target.y+SQRT[dist]+eps;pos.y++)
					if(checkPos(pos) && dis2(pos,target)<=dist)
						for(int j=0;j<Heros.size();j++)banstays[j].push_back(pos);
		}

		void solve()
		{
			if (!type)
			{
				for(int i=0;i<Heros.size();i++)
				{
					//debuger<<Heros[i].p->pos<<' '<<Heros[i].p->name<<' '<<Heros[i].target<<' '<<Heros[i].speed<<'n';
					vector<Pos>target=SPC.findShortestPath(Heros[i].p->pos,Heros[i].target,Heros[i].speed,blocks[i],banstays[i]);
					//debuger<<target.size()<<'n';
					console->move(target, Heros[i].p);
					//SendCommander(Heros[i].p->id,Move,target);
				}
			}
			else
			{	
				int speed = 1e9;
				for(int i=0;i<Heros.size();i++) speed = min(speed, Heros[i].speed);
				//debuger<<speed<<' '<<endl
				for(int i=0;i<Heros.size();i++)
				{
					debuger<<Heros[i].p->pos<<' '<<Heros[i].p->name<<' '<<Heros[i].target<<' '<<speed<<'n';
					vector<Pos>target=SPC.findShortestPath(Heros[i].p->pos,Heros[i].target,speed,blocks[i],banstays[i]);
					//debuger<<target.size()<<'n';
					console->move(target, Heros[i].p);
					//SendCommander(Heros[i].p->id,Move,target);
				}
			}
		}
} MC(0), TMC(1);

class Ai
{
public:
	Ai();
	
	static vector<PUnit*> enemyUnits(const UnitFilter& filter = UnitFilter())
	{
		auto e = console->enemyUnits(filter);
		decltype(e) enemys;
		for (auto i : e) if (isAlive(i)) enemys.push_back(i);//,cout<<i->name<<' '<<i->id<<'n';
		return enemys;
	}
	static vector<PUnit*> friendlyUnits(const UnitFilter& filter = UnitFilter()) // filter observers
	{
		auto f = console->friendlyUnits(filter);
		decltype(f) heros;
		for (auto i : f) if (i->isHero()) heros.push_back(i);//,cout<<i->name<<' '<<i->id<<'n';
		return heros;
		//return console->friendlyUnits(filter);
	}
	static double getAttackSpeed(const PUnit* unit)
	{
		if (unit->isWild() || getHeroType(unit) == 1) return 2;
		else if (getHeroType(unit) == 2) return 3;
		else return 1;
	}
	static int goldAvailble() {return console->gold() - console->goldCostCurrentRound();}

	static Plan getPlan(const PUnit* unit) {return plan[unit->id];}
	static Pos getTmpPos(const PUnit* unit) {return tmpPos[unit->id];}

	static void setPlanAndTmpPos(const PUnit* unit, Plan p) {plan[unit->id] = p;}
	static void setPlanAndTmpPos(const PUnit* unit, Plan p, Pos pos)
	{
		plan[unit->id] = p;
		tmpPos[unit->id] = pos;
	}
	
	static int getMineEnergy(const PUnit* mine) {return console->unitArg("energy", "c", mine);}
	static int getMineEnergy(int id)
	{
		UnitFilter filter;
		filter.setTypeFilter("Mine");
		auto mines = enemyUnits(filter);
		for (auto mine : mines)
			if (getMineId(mine->pos) == id)
				return getMineEnergy(mine);
		return 0;
	}
	
	static bool canSee(Pos p)
	{
		auto friendly = console->friendlyUnits();
		for (auto f : friendly)
			if (::canSee(f->pos, p, f->view)) return true;
		return false;
	} 

	static bool canCallBackHero(const PUnit* hero)
	{
		return goldAvailble() >= console->callBackCost(hero->level) && !hero->findBuff("BeAttacked");
	}
	
	static bool getPowerArgs(const PUnit* unit, double& hp, double& atk, double& def, bool dizzy = true)
	{
		if (!unit->atk) return false;
		if (unit->findBuff("Dizzy") && dizzy)
			atk = unit->atk / (unit->findBuff("Dizzy")->timeLeft / 5.0 + 1);
		else
			atk = unit->atk;
		if (getHeroType(unit) == 1)
		{
			auto skill = unit->findSkill("HammerAttack");
			double a = HAMMERATTACK_DAMAGE[skill->level] * 0.5;
			a *= min(1.0 * (skill->maxCd - skill->cd) / skill->maxCd, max(1.0 * unit->mp / skill->mp, 1.0));
			atk = max(atk, a);
		}
		if (getHeroType(unit) == 2)
		{
			auto skill = unit->findSkill("Sacrifice");
			auto skill2 = unit->findSkill("SuperDead");
			double a = (getHp(unit) - 1) * 0.2;
			a *= 0.5 * (skill->maxCd - skill->cd) / skill->maxCd + 0.5 * (skill2->maxCd - skill2->cd) / skill2->maxCd;
			atk = max(atk, a);
		}
		atk -= 15;
		atk /= getAttackSpeed(unit);
		hp = getHp(unit), def = unit->def;
		if (hp) hp += 50;
		if (unit->canUseSkill("SuperDead")) hp += unit->max_hp / 4;
		//cout<<unit->name<<' '<<atk<<' '<<hp<<' '<<def<<'n';
		//if (unit->findBuff("WinOrDie")) hp = unit->max_hp / 2;
		return true;
	}
	static double getPower(const PUnit* unit, bool alive = true)
	{
		double hp, atk, def;
		//cout<<(int)unit<<endl;
		//assert(unit != 0);
		if (!unit) return 0;
		//cout<<unit->name<<' '<<unit->id<<endl;
		if ((!alive || isAlive(unit)) && getPowerArgs(unit, hp, atk, def))
			return (double)hp * (atk + def);
		else
			return 0;
	}
	static double getPower(const vector<PUnit*>& team, bool alive = true)
	{
		if (!team.size()) return 0;
		int hpSum = 0, atkSum = 0, n = 0;
		//cout<<team.size()<<'n';
		double defAve = 0, atkSpdAve = 0;
		bool wild = true;
		for (PUnit* i : team) if (i->isHero()) wild = false;
		for (PUnit* i : team) if (!alive || isAlive(i))
		{
			if (!wild && i->isWild()) continue;
			double hp, atk, def;
			if (getPowerArgs(i, hp, atk, def))
			{
				hpSum += hp, atkSum += atk, defAve += i->def;
				n++;
			}
		}
		if (!n) return 0;
		defAve /= n, atkSpdAve /= n;
		return hpSum * (atkSum + 2 * defAve);
	}
	static double getMaxPower(int camp, bool about = true, bool fliterCanBeSeen = false)
	{
		static PUnit units[99];
		static int lastSee;
		bool canSee[99] = {0};
		vector<PUnit*> e;
		if (camp == console->camp())
			e = friendlyUnits();
		else
			e = enemyUnits();
		if (fliterCanBeSeen) for (auto enemy : e) canSee[enemy->id] = true;
		int s = 0; 
		for (auto i : e) if (i->isHero())
		{
			s++;
			PUnit tmp = units[i->id];
			PUnit x = *i;
			//cout<<"  "<<i->name<<' '<<i->id<<' '<<i->camp<<'n';
			x.id = 98;
			x.buffs.clear();
			if (getHeroType(i) == 1)
			{
				x.hp = HAMMERGUARD_BASE_HP + x.level * HAMMERGUARD_HP_DELTA;
				x.mp = 200;
				for (auto& skill : x.skills) skill.cd = 0;
			}
			else if (getHeroType(i) == 2)
			{
				x.hp = BERSERKER_BASE_HP + x.level * BERSERKER_HP_DELTA;
				x.atk = BERSERKER_BASE_ATK + x.level * BERSERKER_ATK_DELTA;
				for (auto& skill : x.skills) skill.cd = 0;
			}
			else if (getHeroType(i) == 3)
			{	
				x.hp = MASTER_BASE_HP + x.level * MASTER_HP_DELTA;
				x.mp = 200;
			}
			else if (getHeroType(i) == 4)
			{
				x.hp = SCOUTER_BASE_HP + x.level * SCOUTER_HP_DELTA;
				x.mp = 200;
			}
			units[i->id] = x;
		}
		if (s >= 4 && camp != console->camp()) lastVisitEnemy = console->round();
		decltype(e) enemys;
		for (int i = 0; i < 99; i++) if (units[i].max_hp && units[i].camp == camp && !canSee[i])
		{
			//cout<<' '<<i<<' '<<units[i].name<<' '<<units[i].hp<<' '<<units[i].atk<<' '<<units[i].def<<'n';
			enemys.push_back(&units[i]);
		}
		double p = getPower(enemys);
		if (console->round() > 200 && about && camp != console->camp())
		{
			if (p * 1.3 < herosMaxPower)
				p += (console->round() - lastVisitEnemy) * 2000;
			else
				p += (console->round() - lastVisitEnemy) * 3000;
		}
		return p;
	}
	static double getFriendlyPowerNearPos(Pos pos, vector<PUnit*> extra = vector<PUnit*>())
	{
		double power = 0;
		auto f = friendlyUnits();
		decltype(f) heros;
		for (auto i : f) if (i->isHero() && dis2(i->pos, pos) <= TEAM_RANGE) heros.push_back(i);
		for (auto i : extra) if (i->isHero() && dis2(i->pos, pos) > TEAM_RANGE) heros.push_back(i);
		return getPower(heros, false);
	}
	static double getEnemyPowerNearPos(Pos pos)
	{
		UnitFilter filter;
		filter.setAvoidFilter("Mine");
		filter.setAreaFilter(new Circle(pos, TEAM_RANGE));
		auto enemys = enemyUnits(filter);
		double power = getPower(enemys);
		//for (auto i : enemys) if (i->isWild() && dis2(pos, i->pos) <= i->view) return getPower(i);
		if (!enemys.size() && !canSee(wildPosNearMinePos(pos)))
		{
			int id = getMineId(pos);
			if (!id) power = getMaxPower(1 - console->camp(), true, true);
			else if (id == 2 || id == 3) power = Roshan_POWER;
			else power = Dragon_POWER;
		}
		return power;
	}
	static PUnit* unitAtPos(Pos pos)
	{
		auto e = console->enemyUnits();
		auto f = console->friendlyUnits();
		for (auto i : e) if (i->pos == pos) return i;
		for (auto i : f) if (i->pos == pos) return i;
		return 0;
	}
	static Pos getClosestPosWithoutUnit(Pos pos)
	{
		static vector<Pos> list[1005];
		int minD = 1e9;
		Pos res;
		for (int x = -9; x <= 9; x++)
			for (int y = -9; y <= 9; y++) if (!unitAtPos(pos + Pos(x, y)) && !inBlock[pos.x+x][pos.y+y])
			{
				bool ok = true;
				for (auto u : list[console->round()]) if (pos + Pos(x, y) == u) ok = false;
				if (!ok) continue;
				int d = x * x + y * y;
				if (d < minD || (d == minD && Rand::rand(2))) minD = d, res = pos + Pos(x, y);
			}
		list[console->round()].push_back(res);
		return res;
	}
	static int getMaxDamageAtHero(PUnit* hero, int camp)
	{
		vector<PUnit*> enemys;
		UnitFilter filter;
		filter.setAvoidFilter("Mine");
		filter.setAreaFilter(new Circle(hero->pos, TEAM_RANGE));
		if (camp == console->camp())
			enemys = enemyUnits(filter);
		else
			enemys = friendlyUnits(filter); 
		int damage = 0; 
		for (auto enemy : enemys) if (canUse(enemy))
		{
			//debuger<<"   getMaxDamageAtHero  "<<enemy->name<<' '<<enemy->id<<' '<<enemy->canUseSkill("Attack")<<' '<<'n';
			if (enemy->canUseSkill("HammerAttack"))
			{
				auto pskill = enemy->findSkill("HammerAttack");
				if (dis2(hero->pos, enemy->pos) <= pskill->range())
					damage += getDamage(HAMMERATTACK_DAMAGE[pskill->level], hero);
			}
			else if (enemy->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= enemy->range)
				damage += getDamage(enemy->atk, hero);
		}
		return damage;
	}
	static bool canBeKilled(PUnit* hero)
	{
		UnitFilter filter;
		filter.setAvoidFilter("Mine");
		filter.setAreaFilter(new Circle(hero->pos, TEAM_RANGE));
		auto enemys = enemyUnits(filter); 
		
		if (getMaxDamageAtHero(hero, console->camp()) >= getHp(hero))
		{
			auto f = friendlyUnits(filter);
			if (f.size() == 1) return true;
		}
		if (!enemys.size()) return false;
		if (!canReach[hero->pos.x][hero->pos.y]) return false;
		if (1.0 * getHp(hero) / hero->max_hp > 0.6) return false;
		if (isWeak(hero)) return true;
		
		int damage = 0;
		for (auto enemy : enemys) if (canUse(enemy))
		{
			if (getHeroType(enemy) == 1)
			{
				auto pskill = enemy->findSkill("HammerAttack");
				if (pskill->cd <= 3 && enemy->mp >= 90 && dis2(hero->pos, enemy->pos) <= pskill->range())
					damage += getDamage(HAMMERATTACK_DAMAGE[pskill->level], hero);
				else if (dis2(hero->pos, enemy->pos) <= enemy->range)
					damage += getDamage(enemy->atk, hero);
			}
			else if (dis2(hero->pos, enemy->pos) <= enemy->range)
				damage += getDamage(enemy->atk, hero);
			if (damage * 1.1 >= getHp(hero)) return true;
		}
		return false;
	}
	static void setObserver(PUnit* hero, Pos center)
	{
		if (!hero->canUseSkill("SetObserver")) return;// || console->round() <= 80) return;
		auto pskill = hero->findSkill("SetObserver");
		Pos target;
		int minD = 1e9;
		for (int x = -4; x <= 4; x++)
			for (int y = -4; y <= 4; y++) if (x * x + y * y <= 16)
			{
				Pos pos = center + Pos(x, y);
				if (dis2(pos, hero->pos) <= pskill->range() && !unitAtPos(pos))
				{
					int d = x * x + y * y;
					if (d < minD || (d == minD && Rand::rand(2))) minD = d, target = pos;
				}
			}
		debuger<<"   SETO "<<hero->id<<' '<<hero->pos<<' '<<center<<' '<<target<<'n';
		if (checkPos(target))
		{
			console->useSkill("SetObserver", target, hero);
			setUsed(hero);
		}
	}

	static void heroMove(Pos target, PUnit* hero, bool togetherMove = false);	// 移动
	static void heroRun(PUnit* hero);											// 逃跑

	void start();																// AI主进程

private:
	class Team;

	static double herosMaxPower, lastHerosPower;
	static int lastEnemyBaseHpLost, lastVisitEnemy;
	static int heroNum, buyOrder[99];
	static int lastInDanger, inDangerTimes;
	static PUnit *enemyBase, *base;
	static int minGoldLeft, lastAttack;
	static bool canBeDestroied, attackEnemyBase;
	static bool occupyCenter, centerInDanger;
	vector<PUnit*> heros;
	vector<Team*> teams;
	static Plan plan[99];
	static Pos tmpPos[99], birthPos[99];
	static bool inDanger, goWinning, maybeInDanger, maybeMaybeInDanger, killTheWeak, weiSuo, canBeCaught;

	void updatePlan();					// 更新计划
	void upgradeCamp();					// 升级阵营
	void tryDefence();					// 是否需要回防
	void tryDestroyBase();				// 尝试拆基地
	void tryKillTheWeak();				// 尝试收人头
	void tryMining();					// 尝试挖矿
	void makePlan();					// 下一步的计划
};

int Ai::minGoldLeft = 0, Ai::heroNum = 0, Ai::lastEnemyBaseHpLost = 0;
int Ai::lastInDanger = 0, Ai::inDangerTimes = 0, Ai::lastVisitEnemy = 0;
double Ai::herosMaxPower = 0, Ai::lastHerosPower = 0;
bool Ai::canBeDestroied = false, Ai::attackEnemyBase = false;
bool Ai::centerInDanger = false;
bool Ai::occupyCenter = false;
Plan Ai::plan[99] = {Plan::None};
Pos Ai::tmpPos[99];
Pos Ai::birthPos[99];
int Ai::buyOrder[99], Ai::lastAttack;
bool Ai::weiSuo = false;
bool Ai::inDanger = false, Ai::goWinning = false, Ai::maybeInDanger = false, Ai::maybeMaybeInDanger = false, Ai::killTheWeak = false;
PUnit* Ai::enemyBase = 0;
PUnit* Ai::base = 0;
bool Ai::canBeCaught = false;

class Ai::Team		// 团队
{
public:
	Team(Ai* ai)
	{
		heros.clear();
		this->ai = ai;
	}
	Team(PUnit* unit, Ai* ai)
	{
		heros.clear();
		heros.push_back(unit);
		this->ai = ai;
	}

	void add(PUnit* unit) {heros.push_back(unit);}
	int size() {return heros.size();}
	PUnit* operator [](int i) {return heros[i];}

	Pos center();
	double getPower();																		// 能力
	void gather();																			// 聚集
	void move();									
	void move(Pos target, bool together = false);											// 移动
	void attack(vector<PUnit*> enemys);														// 进攻
	void trySetObserver(bool canAttack);													// 设置或拆除Observer
	bool tryFight(Team* parent, bool otherPlan);												// 尝试战斗，返回是否战斗或逃跑
	bool tryRunning();																		// 尝试逃跑，返回是否逃跑
	void updatePlanAndTmpPos();																// 更新计划
	void makePlan();																		// 下一步的计划
	double getSurvivalTime(const vector<PUnit*>& enemys);									// 获得存活时间
	vector<PUnit*> getNearEnemyUnit(UnitFilter filter = UnitFilter(), int range = 144);		// 附近的单位
	vector<PUnit*> getNearObserver(int camp, const PUnit* mine, int range = 144);			// 附近的Observer
	vector<PUnit*> heros;

private:
	Ai* ai;
};

Pos Ai::Team::center()
{
	vector<Pos> a;
	for (auto i : heros) a.push_back(i->pos);
	return ::center(a);
}

void Ai::Team::gather()
{
	Pos c = center();
	for (auto i : heros)
		if (dis2(i->pos, c) > TEAM_GATHER_RANGE) heroMove(c, i);
}

void Ai::Team::move()
{
	for (auto i : heros)
		if (getPlan(i) == Plan::GoTarget) heroMove(getTmpPos(i), i);
}

void Ai::Team::move(Pos target, bool together)
{
	debuger<<"  MOVE "<<target<<' '<<together<<'n';
	if (!together)
	{
		for (auto i : heros) heroMove(target, i);
	}
	else
	{
		Pos c = center();
		int d = 0;
		for (auto i : heros)
			for (auto j : heros) d = max(d, dis2(i->pos, j->pos));
		cout<<"  TOGETHER  !!!   "<<d<<endl;
		for (auto i : heros) if (d > TEAM_GATHER_RANGE)
			heroMove(c, i);
		else
			heroMove(target, i, true);
	}
}

double Ai::Team::getPower()
{
	return Ai::getPower(heros);
}

void Ai::Team::updatePlanAndTmpPos()
{
	Plan plan = Plan::None;
	Pos pos;
	for (auto hero : heros) if (getPlan(hero) != Plan::GoTarget && getPlan(hero) > plan)
	{
		plan = getPlan(hero);
		pos = getTmpPos(hero);
	}
	for (auto hero : heros) if (getPlan(hero) != Plan::GoTarget && getPlan(hero) != Plan::Running)
	{
		if (plan != getPlan(hero))
		{
			if (plan == Plan::WeiSuo || plan == Plan:: Running || plan == Plan::Mining) continue;
			if (plan < Plan::GoWinning && getPlan(hero) == Plan::Mining) continue;
			if (plan == Plan::GoWinning && getPlan(hero) == Plan::Fighting) continue;
			setPlanAndTmpPos(hero, plan, pos);
			if (isWinOrDie(hero)) setPlanAndTmpPos(hero, Plan::Fighting, pos);
		}
	}
}

vector<PUnit*> Ai::Team::getNearEnemyUnit(UnitFilter filter, int range)
{
	for (auto i: heros) filter.setAreaFilter(new Circle(i->pos, range));
	return enemyUnits(filter);
}

vector<PUnit*> Ai::Team::getNearObserver(int camp, const PUnit* mine, int range)
{
	UnitFilter filter;
	filter.setTypeFilter("Observer");
	for (auto i: heros) filter.setAreaFilter(new Circle(i->pos, range));
	vector<PUnit*> observers, o;
	if (camp == console->camp())
		o = console->friendlyUnits(filter);
	else
		o = console->enemyUnits(filter);
	for (auto i : o) if (dis2(i->pos, mine->pos) <= MINE_VIEW) observers.push_back(i);
	return observers;
}

double Ai::Team::getSurvivalTime(const vector<PUnit*>& enemys)
{
	return 0;
	for (auto hero : heros)
	{
		int totalDamage = 0;
		for (auto enemy : enemys) if (dis2(hero->pos, enemy->pos) <= enemy->range)
		{
			totalDamage += enemy->atk / getAttackSpeed(enemy);
		}
	}
}

void Ai::Team::attack(vector<PUnit*> enemys)
{
	double power = Ai::getPower(enemys);
	auto _e = enemys, sortedHeros = heros;
	double fuck[99];
	bool beAttacked[99];
	bool isWild = true;
	static struct {int id, time;} focus[99];
	memset(beAttacked, 0, sizeof(beAttacked));
	for (auto hero : heros) if (console->round() - focus[hero->id].time >= 10) focus[hero->id].time = -1;
	for (auto hero : heros) debuger<<"  FOCUS "<<hero->name<<' '<<hero->id<<' '<<focus[hero->id].id<<'n';
	for (auto enemy : enemys) if (enemy->isHero()) isWild = false;
	auto attack = [&](PUnit* a, PUnit* b)
	{
		console->attack(b, a);
		loseHp(b, getDamage(a->atk, b));
		beAttacked[b->id] = true;
		focus[a->id] = {b->id, console->round()};
		setUsed(a);
		if (b->isHero()) lastAttack = console->round();		
	};
	auto func = [&](PUnit* x)
	{
		if (!x) return 0.0;
		if (!isAlive(x)) return 0.0;
		if (x->isBase()) return 1e9;
		if (isWinOrDie(x)) return 2e9;
		
		if (inDanger)
		{
			double atk, hp, def;
			getPowerArgs(x, hp, atk, def, false);
			double k = atk;
			if (dis2(x->pos, base->pos) > x->range) k /= dis2(x->pos, base->pos);
			if (x->findBuff("WinOrDie")) k *= 10;
			if (x->canUseSkill("SuperDead")) k /= 2;
			if (x->findBuff("WaitRevive")) k *= 2;
			else if (x->findBuff("Dizzy") && x->findBuff("Dizzy")->timeLeft >= 4) k /= 2;
			return k;
			/*double hp, atk, def;
			getPowerArgs(x, hp, atk, def);
			return atk;*/
		}
		int leftHp = max(getHp(x) - getMaxDamageAtHero(x, 1 - console->camp()), 0);
		int deltaHp = getHp(x) - leftHp; 
		decltype(_e) e;
		PUnit tmp = *x;
		//int leftHp = max(getHp(x) - getMaxDamageAtHero(x, 1 - console->camp()), 0);
		tmp.id = 98, tmp.hp = leftHp;
		for (auto i : _e) if (i == x) e.push_back(&tmp); else e.push_back(i);
		//for (auto i : e) debuger<<"   FFFFFuck  "<<x->name<<"    "<<i->name<<' '<<i->id<<' '<<getHp(i)<<' '<<i->atk<<' '<<' '<<leftHp<<'n'; 
		double k = power - Ai::getPower(e);
		
		//double atk, hp, def;
		//getPowerArgs(x, hp, atk, def, false);
		//double k = atk / (hp + def * 5);
		
		//if (deltaHp) k *= deltaHp * (atk + def);
		
		//if (!deltaHp) return 0.0;
		
		//k /= 1.0 * getHp(x) / deltaHp;// (x->max_hp - leftHp) / x->max_hp; 
		//cerr<<"   WOCAO   "<<Ai::getPower(enemys) <<' '<<Ai::getPower(e)<<"   "<<tmp.hp<<' '<<getHp(x)<<'n';
		
		if (deltaHp) k *= 1.0 * deltaHp / getHp(x);
		if (leftHp == 0 && !x->canUseSkill("SuperDead")) k *= 5;
		if (isWinOrDie(x)) k *= 10;
		if (x->canUseSkill("SuperDead")) k /= 2;
		if (x->findBuff("WaitRevive")) k *= 2;
		
		if (x->isWild()) k /= 100;
		//else if (x->findBuff("Dizzy") && x->findBuff("Dizzy")->timeLeft > 5) k /= 2;
		
		int s = 0;
		for (auto hero : heros) if (focus[hero->id].id == x->id) s++;
		k *= 2 + 1.0 * s / heros.size();
		//if (x->isWild()) k *= 0.7;
		
		return k;
	};
	for (auto enemy : enemys) fuck[enemy->id] = func(enemy); 
	sort(enemys.begin(), enemys.end(), [&](PUnit* x, PUnit* y) {return fuck[x->id] > fuck[y->id];});
	cout<<"FUCK!!"<<endl;
	sort(sortedHeros.begin(), sortedHeros.end(), [&](PUnit* x, PUnit* y) {return Ai::getPower(x) < Ai::getPower(y);});
	
	debuger<<"        #######   Attack   "<<enemys.size()<<' '<<this->getPower()<<' '<<Ai::getPower(enemys)<<'n';
	for (auto i : enemys) debuger<<"        ENEMY: "<<i->id<<' '<<i->pos<<' '<< i->name<<' '<<isDizzy(i)<<' '<<fuck[i->id]<<' '<<getHp(i)<<' '<<getMaxDamageAtHero(i, 1 - console->camp())<<'n';

	// cerr<<getMaxDamageAtHero(enemyBase, 1-console->camp())<<' '<<getHp(enemyBase)<<'n';
	// if (getMaxDamageAtHero(enemyBase, 1-console->camp()) >= getHp(enemyBase))
	// {
	// 	PUnit* a;
	// 	cout<<a->hp<<'n';
	// }
	
	// 打基地
	if (attackEnemyBase)
	{
		// 先攻击 Berserker
		for (auto enemy : enemys) if (isAlive(enemy) && getHeroType(enemy) == 2 && !isDizzy(enemy) && !beAttacked[enemy->id] && enemy->canUseSkill("Sacrifice"))
		{
			if (enemy->findBuff("BeAttacked") && enemy->findBuff("BeAttacked")->timeLeft > 1) continue;
			int minAtk = 1e9, maxD = 0;
			PUnit* p = 0;
			for (auto hero : sortedHeros) if (canUse(hero))// && getHeroType(hero) >= 3)
			{
				if (isWeak(hero) || (canBeKilled(hero) && heros.size() * 2 < enemys.size())) continue;
				if (hero->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= hero->range && (hero->atk < minAtk || (hero->atk == minAtk && dis2(hero->pos, enemy->pos) > maxD)))
				{
					minAtk = hero->atk;
					maxD =dis2(hero->pos, enemy->pos);
					p = hero;
				}
			}
			//cout<<enemy->id<<' '<<p<<'n';
			if (p) attack(p, enemy);
		}
		// 攻击 WinOrDie
		for (auto enemy : enemys) if (isAlive(enemy) && isWinOrDie(enemy))
		{
			int minAtk = 1e9, maxD = 0;
			PUnit* p = 0;
			for (auto hero : sortedHeros) if (canUse(hero))
				if (hero->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= hero->range && (hero->atk < minAtk || (hero->atk == minAtk && dis2(hero->pos, enemy->pos) > maxD)))
				{
					minAtk = hero->atk;
					maxD =dis2(hero->pos, enemy->pos);
					p = hero;
				}
			if (p) attack(p, enemy);
		}
		for (auto hero : sortedHeros) if (canUse(hero))
		{
			// 使用HammerAttack
			if (hero->canUseSkill("HammerAttack") && !hero->canUseSkill("Attack"))
			{
				auto pskill = hero->findSkill("HammerAttack");
				decltype(enemys) q;
				for (auto enemy : enemys) if (dis2(hero->pos, enemy->pos) <= pskill->range() && isAlive(enemy)) q.push_back(enemy);
				sort(q.begin(), q.end(), [&](PUnit* x, PUnit* y)
				{
					double xx = fuck[x->id], yy = fuck[y->id];
					if (getHeroType(x) == 2 && x->findSkill("Sacrifice")->cd <= 1 && !beAttacked[x->id]) xx *= 2;
					if (getHeroType(y) == 2 && y->findSkill("Sacrifice")->cd <= 1 && !beAttacked[y->id]) yy *= 2;
					if (getHeroType(x) == 1 && x->findSkill("HammerAttack")->cd <= 1 && x->mp >= 98) xx *= 2;
					if (getHeroType(y) == 1 && y->findSkill("HammerAttack")->cd <= 1 && y->mp >= 98) yy *= 2;
					return xx > yy;
				});
				for (auto enemy : q) if (!enemy->isBase() && !isDizzy(enemy))
				{
					console->useSkill("HammerAttack", enemy, hero);
					loseHp(enemy, getDamage(HAMMERATTACK_DAMAGE[pskill->level], enemy));
					beAttacked[enemy->id] = true;
					dizzy[enemy->id] = true;
					setUsed(hero);
					break;
				}
				if (!canUse(hero)) continue;
			}
			//debuger<<"   0  "<<hero->name<<' '<<getHp(hero)<<' '<<getMaxDamageAtHero(hero, console->camp())<<' '<<canBeKilled(hero, console->camp())<<'n';
			// 逃跑
			if (!isWinOrDie(hero) && canCallBackHero(hero) && (isWeak(hero) || (canBeKilled(hero) && heros.size() * 2 < enemys.size())))
			{
				setPlanAndTmpPos(hero, Plan::GoTarget, base->pos);
				console->callBackHero(hero, birthPos[hero->id]);
				setUsed(hero);
				continue;
			}
			// 使用 Sacrifice
			if (hero->canUseSkill("Sacrifice") && dis2(hero->pos, enemyBase->pos) <= hero->range && getHp(hero) > 100 && !hero->findBuff("BeAttacked"))
			{
				console->useSkill("Sacrifice", NULL, hero);
				setUsed(hero);
				continue;
			}
			// 普通攻击
			if (dis2(hero->pos, enemyBase->pos) <= hero->range && hero->canUseSkill("Attack"))
			{
				attack(hero, enemyBase);
				//console->attack(enemyBase, hero);
				//beAttacked[enemyBase->id] = true;
				//setUsed(hero);
			}
			else
			{
				heroMove(console->randPosInArea(enemyBase->pos, hero->range), hero);
				setUsed(hero);
			}
		}
		return;
	}
	
	//for (auto enemy : enemys) debuger<<"  !!!  "<<enemy->name<<' '<<getHp(enemy)<<' '<<'n';
	//const string skillList[4] = {"HammerAttack", "Blink", "Sacrifice", "SetObserver"};

	// 先判断 WinOrDie
	for (auto hero : sortedHeros) if (canUse(hero) && isWinOrDie(hero))// && hero->canUseSkill("Attack"))
	{
		//assert(hero->canUseSkill("Attack"));
		setPlanAndTmpPos(hero, Plan::Fighting, hero->pos);
		decltype(enemys) q;
		for (auto enemy : enemys) if (dis2(enemy->pos, hero->pos) <= hero->speed + hero->range && isAlive(enemy)) q.push_back(enemy);
		auto value = [&](PUnit* x)
		{
			double v = fuck[x->id];
			if (dis(x->pos, hero->pos) > hero->range) v -= dis2(x->pos, hero->pos) * 1e5;
			if (!x->canUseSkill("SuperDead"))
			{
				if (getHp(x) <= getDamage(hero->atk, x)) v += getHp(x) * 1e8;
				else v += getDamage(hero->atk, x) * 1e7;
			}
			return v;
		};
		sort(q.begin(), q.end(), [&](PUnit* x, PUnit* y) {return value(x) > value(y);});
		for (auto enemy : q) if (dis2(enemy->pos, hero->pos) <= hero->speed + hero->range)
		{
			if (dis2(hero->pos, enemy->pos) <= hero->range && hero->canUseSkill("Attack"))
			{
				attack(hero, enemy);
				break;
			}
			//else
			//	heroMove(console->closestPos(enemy->pos, hero->range, hero->pos), hero);
		}
		if (canUse(hero))
		{
			for (auto enemy : q)
				if (dis2(enemy->pos, hero->pos) <= hero->speed + hero->range)
					//heroMove(console->closestPos(enemy->pos, hero->range, hero->pos), hero);
					heroMove(enemy->pos, hero);
		}
	}
	// 先攻击 Berserker
	for (auto enemy : enemys) if (isAlive(enemy) && getHeroType(enemy) == 2 && !isDizzy(enemy) && !beAttacked[enemy->id] && enemy->canUseSkill("Sacrifice"))
	{
		if (enemy->findBuff("BeAttacked") && enemy->findBuff("BeAttacked")->timeLeft > 1) continue;
		int minAtk = 1e9, maxD = 0;
		PUnit* p = 0;
		for (auto hero : sortedHeros) if (canUse(hero))// && getHeroType(hero) >= 3)
		{
			if (canBeKilled(hero)) continue;
			if (hero->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= hero->range && (hero->atk < minAtk || (hero->atk == minAtk && dis2(hero->pos, enemy->pos) > maxD)))
			{
				minAtk = hero->atk;
				maxD =dis2(hero->pos, enemy->pos);
				p = hero;
			}
		}
		//debuger<<enemy->id<<' '<<(int)p<<'n';
		if (p) attack(p, enemy);
		else if (dis2(enemy->pos, base->pos) <= MILITARY_BASE_RANGE) attack(base, enemy);
	}
	// 攻击 WinOrDie
	for (auto enemy : enemys) if (isAlive(enemy) && isWinOrDie(enemy))
	{
		int minAtk = 1e9, maxD = 0;
		PUnit* p = 0;
		for (auto hero : sortedHeros) if (canUse(hero))
			if (hero->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= hero->range && (hero->atk < minAtk || (hero->atk == minAtk && dis2(hero->pos, enemy->pos) > maxD)))
			{
				minAtk = hero->atk;
				maxD =dis2(hero->pos, enemy->pos);
				p = hero;
			}
		if (p) attack(p, enemy);
		else if (canUse(base) && dis2(enemy->pos, base->pos) <= MILITARY_BASE_RANGE) attack(base, enemy);
	}
	// 使用 HammerAttack
	for (auto hero : heros) if (canUse(hero) && hero->canUseSkill("HammerAttack"))
	{
		auto pskill = hero->findSkill("HammerAttack");
		decltype(enemys) q;
		for (auto enemy : enemys) if (dis2(hero->pos, enemy->pos) <= pskill->range() && isAlive(enemy)) q.push_back(enemy);
		sort(q.begin(), q.end(), [&](PUnit* x, PUnit* y)
		{
			double xx = fuck[x->id], yy = fuck[y->id];
			if (getHeroType(x) == 2 && x->findSkill("Sacrifice")->cd <= 1 && !beAttacked[x->id]) xx *= 2;
			if (getHeroType(y) == 2 && y->findSkill("Sacrifice")->cd <= 1 && !beAttacked[y->id]) yy *= 2;
			if (getHeroType(x) == 1 && x->findSkill("HammerAttack")->cd <= 1 && x->mp >= 98) xx *= 2;
			if (getHeroType(y) == 1 && y->findSkill("HammerAttack")->cd <= 1 && y->mp >= 98) yy *= 2;
			return xx > yy;
		});
		for (auto enemy : q) debuger<<"   HammerAttack"<<enemy->name<<' '<<enemy->id<<' '<<enemy->pos<<'n';
		for (auto enemy : q) if (!enemy->isBase() && !isDizzy(enemy))
		{
			double a = getMaxDamageAtHero(enemy, 1 - console->camp()), b = a - getDamage(HAMMERATTACK_DAMAGE[pskill->level], enemy);
			if (hero->canUseSkill("Attack")) b += getDamage(hero->atk, enemy);
			if ((b < getHp(enemy) && getHp(enemy) <= a) || (getHeroType(enemy) == 1 && enemy->findSkill("HammerAttack")->cd <= 1 && enemy->mp >= 98))
			{
				console->useSkill("HammerAttack", enemy, hero);
				beAttacked[enemy->id] = true;
				loseHp(enemy, getDamage(HAMMERATTACK_DAMAGE[pskill->level], enemy));
				focus[hero->id] = {enemy->id, console->round()};
				dizzy[enemy->id] = true;
				setUsed(hero);
				break;
			}
		}
		if (hero->canUseSkill("Attack") || !canUse(hero)) continue;
		for (auto enemy : q) if (!enemy->isBase() && !isDizzy(enemy))
		{
			console->useSkill("HammerAttack", enemy, hero);
			beAttacked[enemy->id] = true;
			loseHp(enemy, getDamage(HAMMERATTACK_DAMAGE[pskill->level], enemy));
			dizzy[enemy->id] = true;
			setUsed(hero);
			break;
		}
	}
	// 使用 Sacrifice
	for (auto hero : sortedHeros) if (canUse(hero) && hero->canUseSkill("Sacrifice"))
	{
		//cout<<hero->findSkill("Attack")->cd<<'n';
		if (hero->findSkill("Attack")->cd >= 1) continue;
		auto pskill = hero->findSkill("Sacrifice");
		if (getHp(hero) <= 100) continue;
		debuger<<"  SACRIFICE "<<hero->id<<' '<<hero->pos<<' '<<getMaxDamageAtHero(hero, console->camp())<<'n';
		//if (getMaxDamageAtHero(hero, console->camp()) > 0) continue;
		
		bool fuck = false;
		for (auto enemy : enemys)
		{	
			if (getHeroType(enemy) >= 3 && dis2(hero->pos, enemy->pos) <= enemy->range && enemy->canUseSkill("Attack")) fuck = true;
			vector<PUnit*> v;
			for (auto i : heros)
			{
				if (enemy->canUseSkill("HammerAttack"))
				{
					auto pskill = enemy->findSkill("HammerAttack");
					if (dis2(i->pos, enemy->pos) <= pskill->range() && !isDizzy(i))
						v.push_back(i);
				}
				else if (enemy->canUseSkill("Attack") && dis2(enemy->pos, i->pos) <= enemy->range)
					v.push_back(i);
			}
			if (v.size() == 1 && v[0] == hero) fuck = true;
		}
		if (!getMaxDamageAtHero(hero, console->camp())) fuck = false;
		if (fuck) continue;
		
		decltype(enemys) q;
		for (auto enemy : enemys) if (getHp(enemy) >= getDamage(hero->atk + getHp(hero) - 1, enemy) * 0.5) q.push_back(enemy);
		sort(q.begin(), q.end(), [&](PUnit* x, PUnit* y) {return dis2(x->pos, hero->pos) < dis2(y->pos, hero->pos);});
		for (auto enemy : q) if (dis2(enemy->pos, hero->pos) <= hero->range + hero->speed)
		{
			if (getPlan(hero) == Plan::Mining)
				setPlanAndTmpPos(hero, Plan::Fighting, hero->pos);
			if (getPlan(hero) == Plan::Mining)
			{
				if (dis2(enemy->pos, console->closestPos(getTmpPos(hero), MINE_VIEW, enemy->pos)) > hero->range) continue;
				setPlanAndTmpPos(hero, Plan::Fighting, hero->pos);
			}
			console->useSkill("Sacrifice", NULL, hero);
			setUsed(hero);
			break;
		}
	}
	for (auto enemy : enemys) fuck[enemy->id] = func(enemy); 
	sort(enemys.begin(), enemys.end(), [&](PUnit* x, PUnit* y) {return fuck[x->id] > fuck[y->id];});
	// 普通攻击
	for (auto enemy : enemys) if (isAlive(enemy))
	{
		// 基地攻击
		if (canUse(base) && dis2(enemy->pos, base->pos) <= MILITARY_BASE_RANGE)
		{
			attack(base, enemy);
		}
		for (auto hero : sortedHeros) if (isAlive(enemy) && canUse(hero))
		{
			if (hero->canUseSkill("Attack") && dis2(hero->pos, enemy->pos) <= hero->range)
			{
				debuger<<"   1  "<<enemy->name<<' '<<hero->name<<' '<<getHp(hero)<<' '<<getMaxDamageAtHero(hero, console->camp())<<' '<<canBeKilled(hero)<<'n';
				if (!inDanger && !isWinOrDie(hero) && canBeKilled(hero))
				{
					double a = getMaxDamageAtHero(enemy, 1 - console->camp()), b = a - getDamage(hero->atk, enemy);
					if (a >= getHp(enemy) && b < getHp(enemy));
					else 
					{
						heroRun(hero);
						continue;
					}
				}
				attack(hero, enemy);
			}/*
			else if (!goWinning)
			{
				if (inDanger)
				{
					if (dis(enemy->pos, base->pos) <= dis(hero->pos, base->pos))
						heroMove(base->pos, hero);
					else	
						continue;
				}
				else if (getPlan(hero) == Plan::Mining)
					heroMove(console->closestPos(getTmpPos(hero), MINE_VIEW, enemy->pos), hero);
				else if (Ai::getPower(enemy) * 1.5 <= Ai::getPower(hero))
					heroMove(enemy->pos, hero);
				else if (hero->range > enemy->range)
					heroMove(console->closestPos(enemy->pos, enemy->range + 8, hero->pos), hero);
				else
					heroMove(console->closestPos(enemy->pos, hero->range, hero->pos), hero);
				setUsed(hero);
			}*/
		}
	}
	//for (auto enemy : enemys) debuger << enemy->name<<' '<<getHp(enemy) <<'n';
	if (goWinning) return;
	for (auto hero : sortedHeros) if (canUse(hero))
	{
		debuger<<"   2  "<<hero->name<<' '<<getHp(hero)<<' '<<getMaxDamageAtHero(hero, console->camp())<<' '<<canBeKilled(hero)<<'n';
		if (!inDanger && !isWinOrDie(hero) && canBeKilled(hero))
		{
			heroRun(hero);
			setUsed(hero);
			continue;
		}
		for (auto enemy : enemys) if (isAlive(enemy))
		{
			if (inDanger)
			{
				if (dis(enemy->pos, base->pos) <= dis(hero->pos, base->pos))
					heroMove(base->pos, hero);
				else	
					continue;
			}
			else if (getPlan(hero) == Plan::Mining)
				heroMove(console->closestPos(getTmpPos(hero), MINE_VIEW, enemy->pos), hero);
			else if (Ai::getPower(enemy) * 1.5 <= Ai::getPower(hero))
				heroMove(enemy->pos, hero);
			else if (hero->range > enemy->range)
				heroMove(console->closestPos(enemy->pos, enemy->range + 8, hero->pos), hero);
			else
				heroMove(console->closestPos(enemy->pos, hero->range, hero->pos), hero);
			setUsed(hero);
			break;
		}
	}
}

void Ai::Team::trySetObserver(bool canAttack)
{
	UnitFilter filter;
	filter.setTypeFilter("Mine");
	auto mines = this->getNearEnemyUnit(filter);
	if (!mines.size()) return;
	auto mine = mines[0];

	
	auto enemyObservers = this->getNearObserver(1 - console->camp(), mine);
	auto friendlyObservers = this->getNearObserver(console->camp(), mine);
	if (canAttack && enemyObservers.size())
	{
		auto observer = enemyObservers[0];
		for (auto hero : heros)
			if (dis2(hero->pos, observer->pos) <= TEAM_RANGE && hero->findBuff("BeAttacked")) canAttack = false;
		if (canAttack) for (auto hero : heros) if (canUse(hero) && dis2(hero->pos, observer->pos) <= hero->range)
		{
			console->attack(observer, hero);
			setUsed(hero);
		}
	}
	if (!friendlyObservers.size())
	{
		for (auto hero : heros)
			if (canUse(hero) && hero->canUseSkill("SetObserver"))
				setObserver(hero, mine->pos);
	}
}

bool Ai::Team::tryFight(Team* parent, bool otherPlan)
{
	//debuger<<"   tryFight begin"<<' '<<'n';
	UnitFilter filter;
	filter.setAvoidFilter("Mine");
	auto enemys = this->getNearEnemyUnit(filter, maybeInDanger ? 400 : TEAM_RANGE);
	double friendlyPower = getFriendlyPowerNearPos(this->center(), this->heros);
	
	if (weiSuo)
	{
		for (auto hero : heros)
			if (dis2(hero->pos, MINE_POS[5]) > TEAM_RANGE && dis2(hero->pos, MINE_POS[6]) > TEAM_RANGE) return false;
	}
	
	if (centerInDanger)// || killTheWeak || (occupyCenter && dis2(this->center(), MINE_POS[0]) > TEAM_RANGE))
	{
		for (int i = 0; i < enemys.size(); i++)
			for (;i < enemys.size() && enemys[i]->isWild();)
			{
				swap(enemys[i], enemys[enemys.size() - 1]);
				enemys.pop_back();
			}
	}
	
	debuger<<"        @@@@@@@@@@@@@@@ FIGHT   "<<enemys.size()<<' '<<friendlyPower<<' '<<Ai::getPower(enemys)<<'n';
	for (auto enemy : enemys) debuger<<"   @@@@@@@@@@@@@@@FIGHT "<<enemy->name<<' '<<enemy->id<<' '<<enemy->pos<<'n';
	if (!enemys.size())
	{
		for (auto hero : heros)
			if (getPlan(hero) == Plan::Fighting)
				setPlanAndTmpPos(hero, Plan::None, Pos());
		return false;
	}
	
	Pos wildPos;
	bool winOrDie = false, beAttacked = false, isWild = true, inFighting = false, tooWeak = false;
	for (auto enemy : enemys) if (!enemy->isWild()) isWild = false; else wildPos = enemy->pos;
	for (auto hero : heros)
	{
		if (isWinOrDie(hero)) winOrDie = true;
		if (hero->findBuff("BeAttacked")) beAttacked = true;
	}
	if (!isWild) inFighting = beAttacked;
	for (auto enemy : enemys)
		for (auto hero : parent->heros)
			if (console->round() - console->unitArg("lastHit", intToString(hero->id), enemy) <= 3) inFighting = true;
			
	if (friendlyPower * 3 <= Ai::getPower(enemys) || (heros.size() < enemys.size() * 2 && friendlyPower * 1.5 <= Ai::getPower(enemys)))
		tooWeak = true;
	
	debuger<<"     FIGHT  "<<winOrDie<<' '<<isWild<<"  "<<beAttacked<<' '<<inFighting<<' '<<tooWeak<<'n';
	
	// 遇到弱的轻松打
	if (friendlyPower >= Ai::getPower(enemys) * 1.5)
	{
		// 附近有金矿就尝试不打
		bool unFight = false;
		
		UnitFilter f;
		f.setTypeFilter("Mine");
		auto m = this->getNearEnemyUnit(f);
		auto friends = friendlyUnits();
		if (m.size())
		{
			auto mine = m.front();
			if (mine && getMineEnergy(mine))
			{
				bool fuck = false;
				PUnit* miningHero = 0;
				for (auto hero : friends) if (hero->isHero() && dis2(hero->pos, mine->pos) <= MINE_VIEW) fuck = true, miningHero = hero;
				for (auto enemy : enemys) if (dis2(enemy->pos, mine->pos) <= MINE_VIEW) fuck = true;
				debuger<<" fuck:  "<<fuck<<' '<<mine->pos<<'n';
				if (!fuck && !goWinning)
				{
					for (auto hero : heros) if (!isWinOrDie(hero))
					{
						if (dis2(hero->pos, mine->pos) <= MINE_VIEW)
							setPlanAndTmpPos(hero, Plan::Mining, mine->pos);
						else
							setPlanAndTmpPos(hero, Plan::GoMining, mine->pos);
					}
					unFight = true;
				}
			}
		}
		debuger << "unFight:  " << unFight <<'n';
		if (!unFight) for (auto hero : heros)
			if (getPlan(hero) != Plan::Fighting && (getPlan(hero) != Plan::Mining || console->round() <= 80))
				setPlanAndTmpPos(hero, Plan::Fighting, hero->pos);
		if (!otherPlan) this->attack(enemys);
		return true;
	}
	
	// 遇到强的就逃
	if (!inFighting && !goWinning && !winOrDie && (friendlyPower * 1.3 < Ai::getPower(enemys) || tooWeak))
	{
		// 看不到或是野怪就不逃
		bool canSee = false;
		for (auto enemy : enemys)
			for (auto hero : heros) if (::canSee(enemy->pos, hero->pos)) canSee = true;
		if (!canSee || (isWild && dis2(getTmpPos(heros[0]), wildPos) > TEAM_RANGE))
		{
			for (auto hero : heros)
				if (getPlan(hero) == Plan::Fighting)
					setPlanAndTmpPos(hero, Plan::None, Pos());
			return false;
		}
		else if (isWild && dis2(getTmpPos(heros[0]), wildPos) <= TEAM_RANGE)
		{
			if (!otherPlan) this->attack(enemys);
		}
		// 能收人头就打
		bool canKillWeak = false;
		for (auto enemy : enemys) if (getMaxDamageAtHero(enemy, 1 - console->camp()) >= getHp(enemy)) canKillWeak = true;
		//debuger<<canKillWeak<<'n';
		// for (auto hero : heros)
		// {
		// 	int d = dis2(hero->pos, enemy->pos);
		// 	if (hero->canUseSkill("HammerAttack") && d <= hero->findSkill("HammerAttack")->range())
		// 		canKillWeak = true;
		// 	if (d <= hero->range && !isWeak(hero) || (isWeak(hero) && hero->canUseSkill("Attack") && getHp(enemy) <= getDamage(hero->atk, enemy)))
		// 		canKillWeak = true;
		// }
		if (!canKillWeak && tryRunning()) return true;
		//if (tryRunning()) return true;
	}
	
	// 支援
	Pos c = this->center();
	if (!isWild && heros.size() * 2 >= heroNum)
	{
		debuger<<"   HELP  !!"<<' '<<c<<'n';
		if (killTheWeak || occupyCenter || centerInDanger)
		{
			for (auto hero : ai->heros) if (canUse(hero) && dis2(hero->pos, c) > TEAM_RANGE)
			{
				heroMove(MINE_POS[0], hero);
				setPlanAndTmpPos(hero, Plan::GoTarget, MINE_POS[0]);
				setUsed(hero);
			}
			return false;
		}
		for (auto hero : ai->heros) if (canUse(hero) && (getPlan(hero) == Plan::GoMining || getPlan(hero) == Plan::Mining))
		{
			if (dis2(hero->pos, c) > TEAM_RANGE && dis2(hero->pos, c) <= TEAM_RANGE * 9)
			{
				heroMove(c, hero);
				setPlanAndTmpPos(hero, Plan::GoTarget, c);
				setUsed(hero);
			}
		}
	}
	
	for (auto hero : heros)
		if (getPlan(hero) != Plan::Fighting)
			setPlanAndTmpPos(hero, Plan::Fighting, hero->pos);
	if (!otherPlan) this->attack(enemys);
	return true;
	//debuger<<"   tryFight end"<<'n';
}

bool Ai::Team::tryRunning()
{
	// 不能逃跑
	//return false;
	if (inDanger || maybeInDanger || goWinning)
	{
		for (auto hero : heros) if (getPlan(hero) == Plan::Running)
			setPlanAndTmpPos(hero, Plan::None, Pos());
		return false;
	}
	
	//debuger<<"   RUNNING "<<'n';
	trySetObserver(false);

	UnitFilter filter;
	filter.setAvoidFilter("Mine");
	auto enemys = enemyUnits(filter);
	
	if (killTheWeak)
	{
		for (auto hero : heros) if (canUse(hero)) heroMove(MINE_POS[0], hero);
		return true;
	}

	//for (auto i:enemy) cout<<i->name<<' '<<i->pos<<' '<<i->camp<<' '<<heros[0]->pos<<' '<<i->id<<'n';
	//int t = 0;
	//if (t * 1.5 > enemy.size()) return false;

	// 跑掉了
	int minD = 1e9;
	for (auto enemy : enemys) if (!enemy->isBase())
		for (auto hero : heros) if (::canSee(enemy->pos, hero->pos)) minD = min(minD, dis2(enemy->pos, hero->pos));
	for (auto hero : heros) if (canUse(hero) && getPlan(hero) == Plan::Running)
	{
		if (dis(hero->pos, base->pos) <= MILITARY_BASE_VIEW || (minD >= TEAM_RANGE * 1.5 && dis2(hero->pos, getTmpPos(hero)) >= TEAM_RANGE * 1.5))
			if (getHeroType(hero) != 3 || canReach[hero->pos.x][hero->pos.y])
			{
				heroMove(base->pos, hero);
				setPlanAndTmpPos(hero, Plan::None, Pos());
			}
	}
	
	for (auto hero : heros) if (isWinOrDie(hero)) return false;

	/*bool beAttacked = false;
	for (auto hero : heros) if (hero->findBuff("BeAttacked")) beAttacked = true;
	if (!beAttacked)
	{
		for (auto hero : heros) if (getPlan(hero) == Plan::Running || getPlan(hero) == Plan::Fighting)
		{
			setPlanAndTmpPos(hero, Plan::None, Pos());
			if (canUse(hero)) heroMove(base->pos, hero);
		}
		return true;
	}*/
	
	// 没跑掉
	for (auto hero : heros) if (canUse(hero) && getPlan(hero) == Plan::Running)
	{
		Pos pos = hero->pos, origin = getTmpPos(hero), dir = pos - origin;
		if (dis2(origin, pos) >= TEAM_RANGE * 1.5)
		{
			heroMove(base->pos, hero);
			continue;
		}
		
		// 计算敌人最少的方向
		vector<double> angle;
		for (auto enemy : enemys) if (dis2(enemy->pos, pos) <= TEAM_RANGE * 1.5) angle.push_back(atan2((enemy->pos - pos).y, (enemy->pos - pos).x));
		angle.push_back(atan2(-dir.y, -dir.x));

		sort(angle.begin(), angle.end());
		angle.push_back(angle.front());
		double maxAngle = 0, dirAngle;
		for (int i = 0; i < angle.size() - 1; i++)
		{
			double x = angle[i+1] - angle[i];
			if (i == angle.size() - 2) x += 2*PI;
			if (x > maxAngle) maxAngle = x, dirAngle = angle[i] + x / 2;
			//debuger<<"    ~~~~ "<<i<<' '<<angle[i]<<' '<<x<<'n';
		}
		
		int len = min(min(min(pos.x, pos.y), min(149 - pos.x, 149 - pos.y)), 20);
		Pos target = pos + Pos(len * cos(dirAngle) + 0.5, len * sin(dirAngle) + 0.5);
		if (!checkPos(target))
		{
			int maxD = 0;
			for (int x = -9; x <= 9; x++)
				for (int y = -9; y <= 9; y++) if (abs(fmod(atan2(y, x) - dirAngle, 2*PI)) <= PI/6)
				{
					int d = x * x + y * y;
					Pos p = pos + Pos(x,y);
					if (checkPos(p))
						if (d > maxD || (d == maxD && Rand::rand(2))) maxD = d, target = p;
				}
		}
		heroMove(target, hero);
	}
	else if (canUse(hero))
		heroRun(hero);
		
	return true;
}

void Ai::Team::makePlan()
{
	bool goMining[99] = {0};
	for (int t = 0; t < 2; t++)
	{
		vector<PUnit*> q;
		q.clear();
		//debuger<<"  ROUND  ==== "<<t<<" ===="<<'n';
		int planList[9] = {0, 1, 2, 3, 4, 7, 8, 6, 5};
		for (int it = 0; it < 9; it++)
		{
			int i = planList[it];
			Team subTeam(ai);
			for (auto hero : heros) if (!used[hero->id])
				if (getPlan(hero) == i || (i == Plan::GoMining && getPlan(hero) == Plan::None)) subTeam.add(hero);
			if (i == Plan::Fighting)
				for (auto hero : q) subTeam.add(hero);
			if (!subTeam.size()) continue;
			for (int i=0; i<subTeam.size(); i++) debuger<<"         "<<subTeam[i]->name<<' '<<subTeam[i]->pos<<' '<<subTeam[i]->id<<' '<<getPlan(subTeam[i])<<' '<<getTmpPos(subTeam[i])<<'n';
			debuger<<'n';
			switch (i)
			{
				case None:
				{
					if (goWinning)
					{
						for (auto hero : heros) setPlanAndTmpPos(hero, Plan::GoWinning, enemyBase->pos);
						break;
					}
				}
				case GoMining:
				{
					if (tryFight(this, true)) break;
					trySetObserver(true);
					for (auto hero : heros) if (!goMining[hero->id])
					{
						goMiningHeros.push_back(hero);
						goMining[hero->id] = true;
					}
					break;
				}
				case Running:
				{
					subTeam.tryRunning();
					break;
				}
				case Mining:
				{
					for (int i = 0; i < subTeam.size(); i++) q.push_back(subTeam[i]);
					//trySetObserver(true);
					break;
				}
				case Fighting:
				{
					subTeam.tryFight(this, false);
					break;
				}
				case GoTarget:
				{
					//if (tryFight(this, true)) break;
					subTeam.move();
					break;
				}
				case GoWinning:
				{
					subTeam.tryFight(this, false);
					/*for (int i = 0; i < subTeam.size(); i++)
						if (dis2(subTeam[i]->pos, enemyBase->pos) <= MILITARY_BASE_VIEW)
						{
							subTeam.tryFight(this, false);
							break;
						}*/
					break;
				}
				case GoDefence:
				{
					for (int i = 0; i < subTeam.size(); i++)
						if (dis2(subTeam[i]->pos, base->pos) <= MILITARY_BASE_VIEW)
						{
							subTeam.tryFight(this, false);
							break;
						}
					break;
				}
				case WeiSuo:
				{
					assert(subTeam.size() == 1);
					auto hero = subTeam[0];
					if (hero->pos == getTmpPos(hero))
					{
						setObserver(hero, hero->pos + Pos(0, -5));
						setPlanAndTmpPos(hero, Plan::GoMining, MINE_POS[5]);
					}
					else
						heroMove(getTmpPos(hero), hero);
					break;
				}
			}
		}
	}
	for (auto hero : heros) if (canUse(hero) && getPlan(hero) == Plan::Mining) trySetObserver(true);
	for (auto hero : heros)
		if ((getPlan(hero) == Plan::GoMining || getPlan(hero) == Plan::Mining) && !goMining[hero->id])
			goMiningHeros.push_back(hero);
}

Ai::Ai()
{
	auto _f = console->friendlyUnits();
	auto _e = console->enemyUnits();
	for (auto i : _f) hp[i->id] = i->hp, dizzy[i->id] = i->findBuff("Dizzy");
	for (auto i : _e) hp[i->id] = i->hp, dizzy[i->id] = i->findBuff("Dizzy");
	
	// 获取己方信息
	teams.clear();
	heros.clear();
	base = const_cast<PUnit*>(console->getMilitaryBase());
	auto friendly = friendlyUnits();
	int s = 0;
	for (auto i : friendly) if (i->isHero())
	{
		//debuger<<"  ^^^^  "<<i->name<<' '<<'n';
		if (isAlive(i)) heros.push_back(i);
		else setPlanAndTmpPos(i, Plan::None, Pos());
		s += console->callBackCost(i->level);
		//cout<<"   &&&  "<<i->id<<' '<<getTarget(i)<<'n';
	}
	minGoldLeft = max(minGoldLeft, s);
	for (auto hero : heros) if (!checkPos(birthPos[hero->id])) birthPos[hero->id] = hero->pos, buyOrder[hero->id] = ++this->heroNum;
	//this->heroNum = max(this->heroNum, (int)heros.size());
	sort(heros.begin(), heros.end(), [](PUnit* x, PUnit* y)
	{
		return  x->level < y->level || (x->level == y->level && getHeroType(x) < getHeroType(y));
	});
	//cerr<<"OK"<<'n';

	// 获取敌方基地信息
	UnitFilter filter;
	filter.setTypeFilter("MilitaryBase");
	auto enemys = enemyUnits(filter);
	if (enemys.size()) enemyBase = new PUnit(), *enemyBase = *enemys.front();
	else if (!enemyBase)
	{
		enemyBase = new PUnit();
		strcpy(enemyBase->name, "MilitaryBase"); 
		enemyBase->camp = 1 - console->camp();
		enemyBase->id = 3 + enemyBase->camp;
		enemyBase->hp = MILITARY_BASE_HP;
		enemyBase->max_hp = MILITARY_BASE_HP;
		enemyBase->atk = MILITARY_BASE_ATK;
		enemyBase->def = MILITARY_BASE_DEF;
		enemyBase->pos = MILITARY_BASE_POS[enemyBase->camp];
	}
	else enemyBase->hp = min(enemyBase->hp + MILITARY_RATE_HP, MILITARY_BASE_HP);
	hp[enemyBase->id] = enemyBase->hp;

	// 组成团队
	bool a[HERO_LIMIT][HERO_LIMIT] = {0};
	int hero2id[99] = {0}, b[HERO_LIMIT] = {0}, heroNum = 0, teamNum = 0;
	for (auto i : heros) if (!hero2id[i->id]) hero2id[i->id] = heroNum++;
	for (auto i : heros)
		for (auto j : heros) if (dis2(i->pos, j->pos) <= TEAM_RANGE) a[hero2id[i->id]][hero2id[j->id]] = true;
	function<void(int)> dfs = [&](int u)
	{
		b[u] = teamNum;
		for (int v = 0; v < heroNum; v++) if (a[u][v] && b[v] != teamNum) dfs(v);
	};
	for (int i = 0; i < heroNum; i++) if (!b[i]) teamNum++, dfs(i);
	for (int i = 1; i <= teamNum; i++)
	{
		Team* team = new Team(this);
		for (auto j : heros) if (b[hero2id[j->id]] == i) team->add(j);
		teams.push_back(team);
	}
	
	// 预处理障碍格
	BLOCK.clear();
	memset(inBlock, 0, sizeof(inBlock));
	for (int i = 0; i < INFO->units.size(); i++) BLOCK.push_back(INFO->units[i].pos), inBlock[INFO->units[i].pos.x][INFO->units[i].pos.y] = true;
	for(int k = 0; k < MINE_NUM; ++k)
		for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
			for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
				BLOCK.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j)), inBlock[MINE_POS[k].x+i][MINE_POS[k].y+j] = true;;
    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
		BLOCK.push_back(MILITARY_BASE_POS[k]), inBlock[MILITARY_BASE_POS[k].x][MILITARY_BASE_POS[k].y] = true;;
	
	// 更新金矿访问时间
	filter.cleanAll();
	filter.setTypeFilter("Mine");
	auto mines = enemyUnits(filter);
	for (auto mine : mines) mineLastVisit[getMineId(mine->pos)] = console->round();
	
	// 其他
	//getMaxPower(1 - console->camp());
	if (getHp(base) <= 2800) canBeDestroied = true;
	
	herosMaxPower = getMaxPower(console->camp());
	cout<<getMaxPower(1 - console->camp())<<' '<<getPower(enemyBase)<<' '<<enemyBase->hp<<"   "<<herosMaxPower<<' '<<getPower(heros)<<'n';
	debuger<<getMaxPower(1 - console->camp())<<' '<<getPower(enemyBase)<<' '<<enemyBase->hp<<"   "<<herosMaxPower<<' '<<getPower(heros)<<'n';
	MC.init();
	TMC.init();
	
	
	filter.cleanAll();
	filter.setAvoidFilter("Mine");
	enemys = enemyUnits(filter);
	int d = 1e9;
	static int maybeInDanger_alarm;
	debuger<<"  MAYBE "<<maybeInDanger_alarm<<' '<<maybeInDanger<<'n';
	//if (console->round() - lastInDanger <= 20) maybeInDanger = false;
	if (maybeInDanger_alarm) maybeInDanger_alarm--;
	if (!maybeInDanger_alarm) maybeInDanger = false;
	for (auto enemy : enemys) if (enemy->isHero()) d = min(d, dis2(enemy->pos, base->pos));
	if (canBeDestroied && d <= MILITARY_BASE_VIEW * 8)
		maybeInDanger = true, maybeInDanger_alarm = 20;
	
	static int lastEnemyBaseHp;
	static int attackEnemyBase_alarm;
	if (attackEnemyBase_alarm) attackEnemyBase_alarm--;
	if (!attackEnemyBase_alarm) attackEnemyBase = false;
	for (auto hero : heros) if (dis2(hero->pos, enemyBase->pos) <= MILITARY_BASE_VIEW)
		attackEnemyBase = true, attackEnemyBase_alarm = 20;
	if (!attackEnemyBase)
	{
		if (!lastEnemyBaseHpLost)
		{
			lastEnemyBaseHpLost = lastEnemyBaseHp - getHp(enemyBase);
			goWinning = false;
		}
		lastEnemyBaseHp = getHp(enemyBase);
		lastHerosPower = getPower(heros);
	}
	else
		lastEnemyBaseHpLost = 0;
	
	bool atCenter = false;
	occupyCenter = false;
	centerInDanger = false;
	for (auto hero : heros) if (dis2(hero->pos, MINE_POS[0]) <= MINE_VIEW * 2) atCenter = true;
	if (canSee(MINE_POS[0]) && herosMaxPower > getMaxPower(1 - console->camp()) * 1.5) atCenter = true;
	if (atCenter)
	{
		occupyCenter = true;
		for (auto enemy : enemys) if (enemy->isHero() && dis2(enemy->pos, MINE_POS[0]) <= MINE_VIEW) occupyCenter = false;
		if (getFriendlyPowerNearPos(MINE_POS[0]) < getPower(heros) * 0.5)
		{
			int minD = 1e9;
			for (auto enemy : enemys) if (enemy->isHero()) minD = min(minD, dis2(enemy->pos, MINE_POS[0])); 
			if (minD <= 400) centerInDanger = true;
			
			int s = 0;
			for (auto hero : heros) if (dis2(hero->pos, MINE_POS[0]) < 900) s++; 
			if (s == 1) centerInDanger = true;
		}
	}
	
	if (weiSuo)
	{
		for (auto enemy : enemys) if (enemy->isHero())
			if (dis2(enemy->pos, MINE_POS[5]) <= TEAM_RANGE || dis2(enemy->pos, MINE_POS[6]) <= TEAM_RANGE)
		canBeCaught = true;
	}
}

void Ai::heroMove(Pos target, PUnit* hero, bool togetherMove)
{
	if (!checkPos(target))
	{
		//target = console->closestPos(Pos(74 75), 74, target)
		cout<<"   !@#$%^&*()~@$^*)!#%&(?<>:   "<<target<<'n';
		//target.x = max(min(target.x, 149), 0);
		//target.y = max(min(target.y, 149), 0);
		target = base->pos;
	}//target = console->closestPos(Pos(75, 75), 5000, target);
	if (!canUse(hero)) return;
	setUsed(hero);	 
	
	if (hero->pos == target) return;
	if (getMineId(target) >= 0)
	{
		if (dis2(hero->pos, target) <= 4) return;
		target = getClosestPosWithoutUnit(target);
	}
	/*if (inDanger)
	{
		auto enemys = enemyUnits();
		int d = 0;
		for (auto enemy : enemys) if (dis2(base->pos, enemy->pos) <= enemy->range) d = max(d, dis2(base->pos, enemy->pos));  
		if (d <= 2 && dis2(hero->pos, base->pos) <= 2) return;
	}*/
		//if(p==NULL)return;
		//if(&block==&BLOCK && &BanStays==&BanStay)
		//Move_C.push(p,target);
		//else SendCommander(p->id,Move,SPC.findShortestPath(p->pos,target,p->speed,block,BanStays));
		
		//console->move(target, hero);
		//MC.push(hero, target);
	//if (speed == -1) speed = hero->speed;
	//speed = min(speed, hero->speed);
	vector<Pos> banstays;
	UnitFilter filter;
	filter.setAreaFilter(new Circle(hero->pos, hero->view));
	auto near = friendlyUnits(filter);
	if (getEnemyPowerNearPos(MINE_POS[0]) > getFriendlyPowerNearPos(MINE_POS[0], near) * 1.3)
	{
		double d = 25;
		if (dis2(hero->pos, MINE_POS[0]) <= d*d) d = 15;
		for (int i = -25; i <= 25; i++)
			for (int j = -25; j <= 25; j++) if (i*i + j*j <= 25*25) banstays.push_back(MINE_POS[0] + Pos(i, j));
	} 
	if (togetherMove)
		TMC.push(hero, target, BLOCK, banstays);
	else 
		MC.push(hero, target, BLOCK, banstays);
	//	console->move(SPC.findShortestPath(hero->pos, target, hero->speed), hero);
}

void Ai::heroRun(PUnit* hero)
{
	if (!canUse(hero) || inDanger) return;
	
	//debuger<<" HERO_RUN   "<<' '<<hero->name<<' '<<hero->id<<'n';
	
	Pos pos = hero->pos;
	UnitFilter filter;
	filter.setAvoidFilter("Mine");
	auto enemys = enemyUnits(filter);
	//vector<PUnit*> enemys = Team(hero).getNearEnemyUnit(filter);
	if (!enemys.size()) return;
	
	
	bool isWild = true;
	for (auto i : enemys) if (i->isHero() && dis2(i->pos, pos) <= 36) isWild = false;
	if (isWild && hero->level <= 3) return;

	// 计算敌人最少的方向
	vector<double> angle;
	for (auto enemy : enemys) if (dis2(enemy->pos, pos) <= TEAM_RANGE * 1.5) angle.push_back(atan2((enemy->pos - pos).y, (enemy->pos - pos).x));
	if (!angle.size()) return;
	
	sort(angle.begin(), angle.end());
	angle.push_back(angle.front());
	double maxAngle = 0, dirAngle;
	for (int i = 0; i < angle.size() - 1; i++)
	{
		double x = angle[i+1] - angle[i];
		if (i == angle.size() - 2) x += 2*PI;
		if (x > maxAngle) maxAngle = x, dirAngle = angle[i] + x / 2;
		//debuger<<"    ~~~~ "<<i<<' '<<angle[i]<<' '<<x<<'n';
	}
	//for (auto i : enemy) debuger<<"     ~~~~~~~!! "<<i->name<<' '<<i->pos<<'n';

	//debuger<<dirAngle<<'n';
	
	// Master使用Blink
	if (getHeroType(hero) == 3 && hero->canUseSkill("Blink") && canBeKilled(hero))
	{
		bool highland = false;
		int maxD = 0, minD = 1e9;
		Pos target;
		for (int x = -9; x <= 9; x++)
			for (int y = -9; y <= 9; y++)
			{
				int d = x * x + y * y;
				Pos p = pos + Pos(x,y);
				if (!checkPos(p) || unitAtPos(p) || d > BLINK_RANGE || abs(height[pos.x][pos.y] - height[p.x][p.y]) >= 50) continue;
				//debuger<<" BLINK00 "<<p.x<<' '<<p.y<<'n';
				//debuger<<" BLINK01 "<<canReach[p.x][p.y]<<'n';
				if (!canReach[p.x][p.y])
				{
					if (d < minD || (d == minD && Rand::rand(2))) minD = d, target = p;
					highland = true;
				}
				if (abs(fmod(atan2(y, x) - dirAngle, 2*PI)) <= PI/6)
					if (d > maxD || (d == maxD && Rand::rand(2))) maxD = d, target = p;
			}
		if (!highland) setPlanAndTmpPos(hero, Plan::Running, pos);
		console->useSkill("Blink", target, hero);
		setUsed(hero);
		//debuger<<" BLINK "<<'n';
		return;
	}
		
	// 会被杀掉就回城
	//debuger<<getMaxDamageAtHero(hero, console->camp()) <<' '<< getHp(hero)<<'n';
	if (canBeKilled(hero) && isWeak(hero))
	{
		if (!isWild && dis2(pos, base->pos) > MILITARY_BASE_VIEW && canCallBackHero(hero))
		{
			setPlanAndTmpPos(hero, Plan::GoTarget, base->pos);
			console->callBackHero(hero, birthPos[hero->id]);
			setUsed(hero);
			return;
		}
	}
	
	// 朝敌人最少的方向跑
	int len = min(min(min(pos.x, pos.y), min(149 - pos.x, 149 - pos.y)), 20);
	Pos target = pos + Pos(len * cos(dirAngle) + 0.5, len * sin(dirAngle) + 0.5);
	if (!checkPos(target))
	{
		int maxD = 0;
		for (int x = -9; x <= 9; x++)
			for (int y = -9; y <= 9; y++) if (abs(fmod(atan2(y, x) - dirAngle, 2*PI)) <= PI/6)
			{
				int d = x * x + y * y;
				Pos p = pos + Pos(x,y);
				if (checkPos(p))
					if (d > maxD || (d == maxD && Rand::rand(2))) maxD = d, target = p;
			}
	}
	//debuger<<target<<'n';
	setPlanAndTmpPos(hero, Plan::Running, pos);
	heroMove(target, hero);
	setUsed(hero);
}

void Ai::updatePlan()
{
	UnitFilter filter;
	//filter.setAreaFilter(new Circle(base->pos, MILITARY_BASE_VIEW));
	//auto enemy = console->enemyUnits(filter);
	//if (enemy.size()) console->baseAttack(enemy[0]), setUsed(base);

	// Master Blink
	for (auto hero : heros) if (getHeroType(hero) == 3 && !canReach[hero->pos.x][hero->pos.y] && hero->canUseSkill("Blink"))
	{
		Pos pos = hero->pos, dir = base->pos - pos, target;
		double dirAngle = atan2(dir.y, dir.x);
		int minA = 1e9;
		for (int x = -9; x <= 9; x++)
			for (int y = -9; y <= 9; y++)
			{
				int d = x * x + y * y;
				Pos p = pos + Pos(x,y);
				if (!checkPos(p) || unitAtPos(p) || d > BLINK_RANGE || abs(height[pos.x][pos.y] - height[p.x][p.y]) >= 50) continue;
				if (canReach[p.x][p.y])
				{
					double a =  abs(abs(fmod(atan2(y, x) - dirAngle, 2*PI)) - PI/6);
					if (a < minA || (a == minA && Rand::rand(2))) minA = a, target = p;
					//if (d > maxD || (d == maxD && Rand::rand(2))) maxD = d, target = p;
				}
			}
		console->useSkill("Blink", target, hero);
		setPlanAndTmpPos(hero, Plan::None, Pos());
		setUsed(hero);
	}
	for (PUnit* hero : heros) switch (getPlan(hero))
	{
		case None:
		{
			if (goWinning) setPlanAndTmpPos(hero, Plan::GoWinning, enemyBase->pos);
			// if (hero->findBuff("IsMining"))
			// {
			// 	UnitFilter filter;
			// 	filter.setTypeFilter("Mine");
			// 	auto mine = enemyUnits(filter);
			// 	setPlanAndTmpPos(hero, Plan::Mining, mine.front()->pos);
			// }
			// else
			// 	setPlanAndTmpPos(hero, Plan::None, Pos());
			break;
		}
		case GoMining:
		{
			if (killTheWeak) break;
			UnitFilter filter;
			filter.setTypeFilter("Mine");
			auto mines = enemyUnits(filter);
			//auto mine = enemy.front();
			//if (mine) debuger<<mine && getMineEnergy(mine) && dis2(hero->pos, mine->pos) <= MINE_VIEW
			for (auto mine : mines)
				if (dis2(hero->pos, mine->pos) <= MINE_VIEW && getMineEnergy(mine))
				{
					if (console->round() <= 80 && mine->pos != MINE_POS[0]) continue;
					if (weiSuo && getMineId(mine->pos) < 5) continue;
					setPlanAndTmpPos(hero, Plan::Mining, mine->pos);
				}
			/*if (hero->findBuff("IsMining"))
			{
				UnitFilter filter;
				filter.setTypeFilter("Mine");
				auto mine = enemyUnits(filter);
				setPlanAndTmpPos(hero, Plan::Mining, mine.front()->pos);
			}*/
			break;
		}
		case Mining:
		{
			//setTarget(hero, Pos());
			UnitFilter filter;
			filter.setTypeFilter("Mine");
			auto mines = enemyUnits(filter);
			bool ok = false;
			for (auto mine : mines)
				if (dis2(hero->pos, mine->pos) <= MINE_VIEW && getMineEnergy(mine)) ok = true;
			if (!ok) setPlanAndTmpPos(hero, Plan::None, Pos());
			//if (!hero->findBuff("IsMining")) setPlanAndTmpPos(hero, Plan::None, Pos());
			break;
		}
		case Fighting:
		{
			UnitFilter filter;
			//filter.setCampFilter(enemyBase->camp);
			filter.setAvoidFilter("Mine");
			filter.setAreaFilter(new Circle(hero->pos, hero->view));
			//cout<<console->enemyUnits(filter).size()<<'n';
			auto enemys = enemyUnits(filter);
			if (!enemys.size())
				setPlanAndTmpPos(hero, Plan::None, Pos());
			bool canCatch = false;
			bool isWeak = false;
			bool isWild = true;
			for (auto enemy : enemys) if (enemy->speed <= hero->speed) canCatch = true;
			for (auto enemy : enemys) if (!enemy->isWild()) isWild = false;
			if (getPower(enemys) * 2 <= getFriendlyPowerNearPos(hero->pos)) isWeak = true;
			//if (!goWinning && (!canCatch || !isWeak))
				//setPlanAndTmpPos(hero, Plan::None, Pos());
			if ((occupyCenter && dis2(getTmpPos(hero), MINE_POS[0]) > 400 && console->round() - lastAttack < 100) || (goWinning && dis2(hero->pos, enemyBase->pos) > dis2(getTmpPos(hero), enemyBase->pos) + 10))
				setPlanAndTmpPos(hero, Plan::None, Pos());
			if (centerInDanger && isWild)
				setPlanAndTmpPos(hero, Plan::GoMining, MINE_POS[0]);
			break;
		}
		case GoTarget:
		{
			if (dis2(hero->pos, getTmpPos(hero)) <= TEAM_RANGE)
				setPlanAndTmpPos(hero, Plan::None, Pos());
			break;
		}
		case GoWinning:
		{
			if (!goWinning) setPlanAndTmpPos(hero, Plan::None, Pos());
			break;
		}
		case GoDefence:
		{
			if (!inDanger) setPlanAndTmpPos(hero, Plan::None, Pos());
			break;
		}
	}
	for (auto team : teams) team->updatePlanAndTmpPos();
}

void Ai::upgradeCamp()
{
	//int num = console->friendlyUnits().size() - 1;
	static int num = 0;
	const string heroList[HERO_LIMIT] = {"Hammerguard", "Berserker", "Master", "Scouter", "Hammerguard", "Berserker", "Master", "Hammerguard"};
	const Pos pos[HERO_LIMIT] = {Pos(4, 9), Pos(2, 11), Pos(4, 11), Pos(2, 9), Pos(0, 9), Pos(-2, 11), Pos(0, 11), Pos(-2, 9)};

	double ave = 0;
	int minLevel = 1e9;
	for (PUnit* hero : heros) ave += hero->level, minLevel = min(minLevel, hero->level);
	ave /= heros.size();
	
	auto factor = [](int num)
	{
		return num <= 3 ? 1 : num <= 6 ? 2 : 3;
	};

	// 能买就买
	if (num < HERO_LIMIT)// && (num != 4 || ave >= 2.2))
	{
		//debuger<<num<<' '<<HERO_LIMIT<<' '<<goldAvailble()<<'n';
		for (;num < HERO_LIMIT && goldAvailble() >= NEW_HERO_COST * factor(num);)
		{
			//cerr<<heroList[num]<<'n';
			//debuger<<num<<"   "<<goldAvailble()<<'n';
			if (base->camp == 0)
				console->chooseHero(heroList[num], base->pos + pos[num]);
			else
				console->chooseHero(heroList[num], base->pos - pos[num]);
			num++;
		}
		//debuger<<console->round()<<' '<<num<<' '<<console->gold()<<' '<<console->goldCostCurrentRound()<<'n';
		return;
	}
	
	if ((inDanger || goWinning) && goldAvailble() < minGoldLeft * 1.2) return;
	// 能直接升级就升级
	for (PUnit* hero : heros)
	{
		int level = hero->level;
		for (;level < HERO_MAX_LEVEL && level - minLevel <= 2 && dis2(base->pos, hero->pos) <= LEVELUP_RANGE && goldAvailble() >= console->levelUpCost(level);)
		{
			console->buyHeroLevel(hero);
			setPlanAndTmpPos(hero, Plan::None, Pos());
			//setUsed(hero);
			level++;
		}
	}
	
	if (killTheWeak) return;
	
	// 土豪回城升级
	static int lastCallBack = -1e9;
	if (goldAvailble() >= minGoldLeft * 2) for (PUnit* hero : heros) if (!hero->findBuff("BeAttacked"))
	{
		Plan p = getPlan(hero);
		if (p == Plan::Fighting || p == Plan::GoTarget) continue;
		if (p == Plan::Mining)
		{
			auto f = friendlyUnits();
			vector<PUnit*> v;
			for (auto i : f) if (dis2(i->pos, hero->pos) <= MINE_VIEW * 2) v.push_back(i);
			debuger<<hero->name<<' '<<hero->id<<' '<<v.size()<<'n';
			if (v.size() == 1 && v[0] == hero) continue;
		}
		int level = hero->level;
		if (level < HERO_MAX_LEVEL && level - minLevel <= 2 && dis2(base->pos, hero->pos) > LEVELUP_RANGE * 4)
		{
			if (goldAvailble() < console->levelUpCost(level) * 10) continue;
			if (console->round() - lastCallBack < 20) continue;
			//debuger<<"  %%%%%%%  "<<' '<<hero->name<<' '<<getPlan(hero)<<'n';
			setPlanAndTmpPos(hero, Plan::GoTarget, base->pos);
			console->callBackHero(hero, birthPos[hero->id]);
			setUsed(hero);
			lastCallBack = console->round();
		}
	}
	
	// 不能直接升级就回家升级
	static int lastLevelUp = -1e9;
	int gold = goldAvailble();
	for (PUnit* hero : heros)// if (canUse(hero))
	{
		debuger<<hero->name<<' '<<hero->id<<' '<<hero->pos<<'n';
		Plan p = getPlan(hero);
		if (p == Plan::Fighting || p == Plan::GoTarget) continue;
		if (p == Plan::Mining)
		{
			auto f = friendlyUnits();
			vector<PUnit*> v;
			for (auto i : f) if (dis2(i->pos, hero->pos) <= MINE_VIEW * 2) v.push_back(i);
			debuger<<hero->name<<' '<<hero->id<<' '<<v.size()<<'n';
			if (v.size() == 1 && v[0] == hero) continue;
		}
		int level = hero->level;
		if (level < HERO_MAX_LEVEL && level - minLevel <= 2 && gold >= console->levelUpCost(level))// && dis2(base->pos, hero->pos) <= LEVELUP_RANGE * 64)
		{
			if (gold < console->levelUpCost(level) * 5) continue;
			if (console->round() - lastLevelUp < 30) continue;
			heroMove(base->pos, hero);
			setPlanAndTmpPos(hero, Plan::GoTarget, base->pos);
			setUsed(hero);
			lastLevelUp = console->round();
			//debuger<<"  &&&&&&&&  "<<' '<<hero->name<<' '<<getPlan(hero)<<'n';
			//for (;gold >= console->levelUpCost(level); level++)
			//gold -= console->levelUpCost(level);
		}
	}
}

void Ai::tryDefence()
{
//	cout<<" DANGER: "<<inDanger<<'n';
	//debuger<<" DANGER: "<<inDanger<<'n';
	
	UnitFilter filter;
	filter.setAreaFilter(new Circle(base->pos, MILITARY_BASE_VIEW));
	auto enemys = enemyUnits(filter);
	auto near = friendlyUnits(filter);
	double enemyPower = getPower(enemys);
	//cout<<"getPower(enemy)"<<'n';
	//if (enemy.size()) console->baseAttack(enemy[0]);

	if (goWinning && getHp(base) > getHp(enemyBase) && (getHp(enemyBase) <= 500 || getFriendlyPowerNearPos(enemyBase->pos) > getEnemyPowerNearPos(base->pos))) return;
	
	//if (getHp(base) <= 500 && getHp(enemyBase) >= 1500) inDanger = true;
	//else
	{
		if (!enemys.size()) {inDanger = false; return;}
		if (!inDanger && getHp(base) * 3 > base->max_hp && enemys.size() <= 3 && enemyPower* 5 <= getPower(near)) return;
	}
	inDanger = true;
	if (lastInDanger != console->round() - 1) inDangerTimes++;
	lastInDanger = console->round();
	for (auto hero : near) setPlanAndTmpPos(hero, Plan::GoDefence, base->pos);
	
	cout<<getPower(enemys)<<"  "<< getPower(near)<<'n';

	// 中等距离走回来
	for (auto hero : heros)
		if (canUse(hero) && !filter.valid(hero) && dis2(hero->pos, base->pos) <= MILITARY_BASE_VIEW * 4)
		{
			heroMove(base->pos, hero);
			setPlanAndTmpPos(hero, Plan::GoDefence, base->pos);
		}

	// 远距离召回
	decltype(near) far;
	for (auto hero : heros) if (dis2(hero->pos, base->pos) > MILITARY_BASE_VIEW * 4) far.push_back(hero);
	int n = far.size();
	// 搜索最佳召回方案
	int minCost = 1e9, p = -1;
	double maxPower = 0, maxPower2 = 0;
	for (int i = 0; i < 1<<n; i++)
	{
		int cost = 0;
		auto myHeros = near; 
		for (int j = 0; j < n; j++) if ((i>>j)&1)
		{
			auto hero = far[j];
			if (canCallBackHero(hero))
			{
				cost += console->callBackCost(hero->level);
				myHeros.push_back(hero);
			}
		}
		if (cost > goldAvailble()) continue;
		double power = getPower(myHeros);
		if (power > maxPower || (power == maxPower && cost < minCost))
		{
			maxPower = power, minCost = cost, p = i;
		}
		else if (power > enemyPower * 2)
		{
			if (cost < minCost || (cost == minCost && power > maxPower2))
				maxPower2 = power, minCost = cost, p = i;	
		}
	}
	if (p != -1)
	{
		for (int j = 0; j < n; j++) if ((p>>j)&1)
		{
			auto hero = far[j];
			if (canCallBackHero(hero))
			{
				console->callBackHero(hero, getClosestPosWithoutUnit(base->pos));
				setPlanAndTmpPos(hero, Plan::GoDefence, base->pos);
				setUsed(hero);
			}
		}
	}
	if (maxPower <= enemyPower * 2)
	{
		for (auto hero : far) if (canUse(hero))
		{
			heroMove(base->pos, hero);
			setPlanAndTmpPos(hero, Plan::GoDefence, base->pos);
		}
	}

	// 买活
	/*if (getPower(enemy) <= getPower(near)) return;
	decltype(near) dead;
	for (PUnit* i : friendlyUnits()) if (i->isHero() && !isAlive(i)) dead.push_back(i);
	sort(dead.begin(), dead.end(), [](PUnit* a, PUnit* b) {return getPower(a, false) > getPower(b, false);});
	for (PUnit* i : dead)
	{
		if (getRevivingTime(i) > 5 && goldAvailble() >= console->buyBackCost(i->level))
		{
			console->buyBackHero(i, getClosestPosWithoutUnit(base->pos));
			setPlanAndTmpPos(i, Plan::GoDefence, base->pos);
			setUsed(i);
			near.push_back(i);
		}
		if (getPower(enemy) <= getPower(near, false)) break;
	}*/
	//UnitFilter filter;
	//filter.setAreaFilter(new Circle(base->pos, MILITARY_BASE_VIEW));
	//auto enemy = console->enemyUnits(filter);
	//if (enemy.size()) console->baseAttack(enemy[0]), setUsed(base);
}

void Ai::tryDestroyBase()
{	
	bool LastGoWinning = goWinning; 
	if (inDanger || maybeInDanger)
	{
		if (getHp(base) > getHp(enemyBase) && (getHp(enemyBase) <= 500 || getFriendlyPowerNearPos(enemyBase->pos) > getEnemyPowerNearPos(base->pos))); 
		else {goWinning = false; return;}
	}
	
	if (!goWinning && lastEnemyBaseHpLost && 1.0 * getPower(heros) / lastHerosPower < 1.0 * getHp(enemyBase) / lastEnemyBaseHpLost) return;
	
	// 有零钱以便及时召回
	if (!goWinning && canBeDestroied && goldAvailble() < minGoldLeft * 0.8 && getHp(enemyBase) > 500) return;
	
	//for (auto i : heros) if (getPlan(i) == Plan::Fighting || isWinOrDie(i)) return;
	
	double enemysMaxPower = getMaxPower(1 - console->camp());
	double power = (getPower(enemyBase) + enemysMaxPower) * 1.1;
	double value = power;
	if (getHp(enemyBase) <= 100) value *= 0.10;
	else if (getHp(enemyBase) <= 250) value *= 0.40;
	else if (getHp(enemyBase) <= 500) value *= 0.55;
	else if (getHp(enemyBase) <= 1000) value *= 0.70;
	else if (getHp(enemyBase) <= 1500) value *= 0.85;
	
	// 已经goWinning了
	if (herosMaxPower * 1.5 < value) {goWinning = false; return;}
	
	if (weiSuo && console->round() - lastAttack > 100) return;
	
	vector<PUnit*> q;
	int closestMaster = 1e9;
	for (auto hero : heros)
	{
		if (dis2(hero->pos, enemyBase->pos) <= MILITARY_BASE_VIEW * 6) q.push_back(hero);
		if (getHeroType(hero) == 3) closestMaster = min(closestMaster, dis2(hero->pos, enemyBase->pos));
	}
	int t = q.size();
	double p = getPower(q);
	double aveD = 0;
	for (auto hero : heros) aveD += dis2(hero->pos, enemyBase->pos);
	aveD /= heros.size();
	// 推不掉了
	if (console->round() > 950 && p < value * 0.5 && (aveD > MILITARY_BASE_VIEW * 64 || getHp(enemyBase) > 800)) {goWinning = false; return;}
	// 实力相差不大，容易被翻盘
	if (!LastGoWinning && enemysMaxPower >= herosMaxPower * 0.8) {goWinning = false; return;}
	
	// 快结束
	if (console->round() >= 600 && getPower(heros) >= value * 0.9) goWinning = true;
	if (console->round() >= 800 && getPower(heros) >= value * 0.7) goWinning = true;
	//if (getHp(enemyBase) * 3 <= enemyBase->max_hp) goWinning = true;
	// 正常
	//cout<<"   ####  6  "<<getPower(heros)<<' '<<value<<' '<<canBeDestroied<<'n';
	if (!goWinning && ((getPower(heros) <= max(value, 1.2e6) && getPower(heros) <= power * 2.5) || (canBeDestroied && goldAvailble() < minGoldLeft * 1.2))) return;
	goWinning = true;

	cout<<"   WIN  My:"<<getPower(heros)<<"    enemyBase:"<<getPower(enemyBase) <<" enemys:"<< getMaxPower(1 - console->camp())<<"    "<<power<<' '<<value<<'n';
	
	for (auto hero : heros) debuger<<hero->name<<' '<<hero->id<<' '<<hero->pos<<' '<<canUse(hero)<<'n';
	static Pos s1, s2, s3;
	static int plan;
	if (!LastGoWinning)
	{
		double p[2] = {0};
		for (auto hero : heros) if (hero->pos.x < hero->pos.y) p[1]++; else p[0]++;
		double s = p[0] + p[1];
		p[0] /= s, p[1] /= s;
		int x = Rand::randomWithProbability(2, p);
		if (!x)
		{
			s1 = console->camp() ? Pos(105, 30) : Pos(120, 45);
			s2 = console->camp() ? Pos(35, 20) : Pos(140, 120);
		}
		else
		{
			s1 = console->camp() ? Pos(30, 105) : Pos(45, 120); 
			s2 = console->camp() ? Pos(10, 30) : Pos(115, 130);
		}
		s3 = console->camp() ? Pos(15, 25) : Pos(135, 125);
		if (getPower(heros) > power) plan = 0; else plan = 1;
	}
	
	debuger<<"  WIN2  "<<teams.size()<<' '<<s1<<' '<<s2<<'n';
	if (weiSuo)
	{
		for (auto team : teams)
		{
			Pos c = team->center();
			debuger<<"   CENTER  "<<c<<"n";
			if (dis2(c, enemyBase->pos) > MILITARY_BASE_VIEW)
			{
				if ((dis2(c, enemyBase->pos) <= MILITARY_BASE_VIEW * 6) && (t >= heroNum * 0.7 || p >= value * 0.7))
				{
					if (console->round() <= 900 && p < value * 1.5 && (getHp(enemyBase) >= enemyBase->max_hp * 0.7 && closestMaster <= MILITARY_BASE_VIEW * 36 && closestMaster > MILITARY_BASE_VIEW * 8))
						team->move(s3, true);
					else
						team->move(enemyBase->pos, true);
				}
				else
					team->move(s3, true);
			}
		}
	}
	else if (!plan)
	{
		if (heros.size() < heroNum * 0.9) {goWinning = false; return;}
		static bool gathered;
		if (!LastGoWinning) gathered = false;
		int s = 0;
		for (auto hero : heros) if (dis2(hero->pos, base->pos) <= 8000) s++;
		if (s > heroNum * 0.7) gathered = false; 
		debuger<<"  gather "<<' '<<LastGoWinning<<' '<<s<<' '<<gathered<<'n';
		s = 0;
		for (auto hero : heros) if (dis2(hero->pos, MINE_POS[0]) <= TEAM_GATHER_RANGE) s++;
		if (s >= heroNum) gathered = true;
		debuger<<"  gather "<<' '<<s<<' '<<gathered<<'n';
		if (!gathered)
		{
			for (auto team : teams) team->move(MINE_POS[0]);
			//for (auto hero : heros) if (canUse(hero))
			//	heroMove(MINE_POS[0], hero);
		}
		else
		{
			for (auto team : teams)
			{
				Pos c = team->center();
				debuger<<"   CENTER  "<<c<<"n";
				if (dis2(c, enemyBase->pos) > MILITARY_BASE_VIEW)
				{
					if ((dis2(c, enemyBase->pos) <= MILITARY_BASE_VIEW * 6) && (t >= heroNum * 0.7 || p >= value * 0.7))
					{
						if (console->round() <= 900 && p < value * 1.5 && (getHp(enemyBase) >= enemyBase->max_hp * 0.7 && closestMaster <= MILITARY_BASE_VIEW * 36 && closestMaster > MILITARY_BASE_VIEW * 8))
							team->move(s3, true);
						else
							team->move(enemyBase->pos, true);
					}
					else
						team->move(s3, true);
				}
			}
			//for (auto team : teams) team->move(enemyBase->pos, true);
			/*for (auto hero : heros) if (canUse(hero))
			{
				
				heroMove(enemyBase->pos, hero, true);
				setUsed(hero);
			}*/
		}
	}
	else
	{
	//	cout<<"  WIN  "<<teams.size()<<'n';
		//for (auto i : heros) setPlanAndTmpPos(i, Plan::GoWinning, enemyBase->pos);
		
		// 集合团队
		for (auto team : teams)
		{
			Pos c = team->center();
			if (dis2(c, enemyBase->pos) > MILITARY_BASE_VIEW)
			{
				if ((dis2(c, enemyBase->pos) <= MILITARY_BASE_VIEW * 6) && (t >= heroNum * 0.7 || p >= value * 0.7))
				{
					cerr<<t<<' '<<' '<<heroNum<<"     "<<p<<' '<<value<<'n';
					if (console->round() <= 900 && p < value * 1.5 && (getHp(enemyBase) >= enemyBase->max_hp * 0.7 && closestMaster <= MILITARY_BASE_VIEW * 36 && closestMaster > MILITARY_BASE_VIEW * 8))
						team->move(s2, true);
					else
						team->move(enemyBase->pos, true);
						//heroMove(enemyBase->pos, hero, true);
				}
				else if (dis2(c, s2) <= TEAM_RANGE)
					team->move(s2, true);
					//heroMove(s2, hero, true);
				else if (dis2(c, s1) <= TEAM_RANGE)
					team->move(s2, true);
					//heroMove(s2, hero, true);
				else
				{
					if (!console->camp())
					{
						if (c.x < 110 && c.y < 110)
							team->move(s1);
							//heroMove(s1, hero);
						else
							team->move(s2, true);
							//heroMove(s2, hero, true);
					}
					else
					{
						if (c.x > 40 && c.y > 40)
							//heroMove(s1, hero);
							team->move(s1);
						else
							team->move(s2, true);
							//heroMove(s2, hero, true);
					}
				}
			}
		}
	}
	for (auto hero : heros) if (getPlan(hero) != Plan::Fighting) setPlanAndTmpPos(hero, Plan::GoWinning, enemyBase->pos);
}

void Ai::tryKillTheWeak()
{
	bool lastKillTheWeak = killTheWeak;
	static Pos target;
	static int prt;
	//if (heroNum < 8) return;
	debuger<<occupyCenter <<"  "<< centerInDanger<<" "<<"!!!n";
	if (!occupyCenter || centerInDanger || goWinning || inDanger) {killTheWeak = false; return;}
	debuger<<"!!!n";
	UnitFilter filter;
	filter.setAvoidFilter("Mine");
	filter.setAreaFilter(new Circle(MINE_POS[0], TEAM_RANGE));
	auto enemys = enemyUnits(filter);
	if (enemys.size())  {killTheWeak = false; return;}
	debuger<<"!!!n";
	
	if (!lastKillTheWeak)
	{
		debuger<<"  KILLTW "<<getMaxPower(1 - console->camp(), false)<<' '<<getFriendlyPowerNearPos(MINE_POS[0])<<'n';
		if (getMaxPower(1 - console->camp(), false) * 1.2 > getFriendlyPowerNearPos(MINE_POS[0])) return;
		if (console->round() <= 100) return;
		auto f = friendlyUnits();
		int s = 0;
		for (auto hero : f) if (dis2(hero->pos, MINE_POS[0]) <= TEAM_RANGE && canUse(hero)) s++;
		debuger<<"  KILLTW "<<s<<' '<<heros.size()<<'n';
		if (s < heros.size() * 0.9) return;
	}
	
	if (lastKillTheWeak && canSee(target) && getEnemyPowerNearPos(target) && !getMineEnergy(getMineId(target)))  {killTheWeak = false; return;}
	
	killTheWeak = true;
	
	if (!lastKillTheWeak)
	{
		//double p[7] = {0, 0.2, 0.2, 0.2, 0.2, 0, 0}, pp[7];
		//Pos minePos[7];
		//int n = 0; double s = 0;
		//if (console->camp()) p[1] = 0.4; else p[4] = 0.4;
		//for (int i = 0; i < 7; i++) if (console->round() - mineLastVisit[i] > 20)
		//	pp[n] = p[i], minePos[n] = MINE_POS[i], n++, s += p[i];
		//for (int i = 0; i < k; i++) priority[i] = 1 / priority[i] / s, debuger<< priority[i]<<' '<<minePos[i]<<'n';
		//cout<< n << s <<endl;
		//if (!n || s == 0) return;
		//for (int i = 0; i < n; i++) pp[i] /= s;
		//target = minePos[Rand::randomWithProbability(n, pp, false)];
		
		if (console->round() - lastAttack > 100) target = Rand::rand(2) ? MINE_POS[5] : MINE_POS[6];
		else target = MINE_POS[prt + 1], prt = (prt + 1) % 4;  
		//if (goWinning) target = console->camp() ? MINE_POS[1] : MINE_POS[4];
	}
	
	if (killTheWeak) debuger<<"  killTheWeak   "<<target<<'n';
	
	for (auto hero : heros) if (canUse(hero) && getHeroType(hero) != 4)
	{
		debuger<<"   "<<hero->name<<' '<<hero->id<<' '<<hero->pos<<'n';
		setPlanAndTmpPos(hero, Plan::GoMining, target);
		heroMove(target, hero);
		setUsed(hero);
		//goMiningHeros.push_back(hero);
		//heroMove(target, hero);
	}
}

void Ai::tryMining()
{
	vector<PUnit*> h;
	for (auto hero : heros) if (getPlan(hero) == Plan::None || getPlan(hero) == Plan::GoMining || getPlan(hero) == Plan::Mining) h.push_back(hero);
	goMiningHeros.clear();
	for (auto i : h) debuger<<"  ("<<i->name<<' '<<i->id<<' '<<canUse(i)<<")   ";debuger<<'n';
	
	static int lastSpy;
	cout<<lastVisitEnemy<<' '<<lastSpy<<endl;
	debuger<<lastVisitEnemy<<' '<<lastSpy<<'n';
	if (goWinning || inDanger) {weiSuo = false; return;}
	debuger<<"  tryMining  "<<' '<<occupyCenter<<' '<<centerInDanger<<"  "<<'n';
	static bool canWeiSuo = true;
	
	if ((canBeCaught || (getPower(heros) > 1.5e6 && getMaxPower(1 - console->camp()) < herosMaxPower * 1.2)) && weiSuo)
	{
		for (auto hero : h) if (canUse(hero))
		{
			Pos target = console->camp() ? MINE_POS[4] : MINE_POS[1]; 
			setPlanAndTmpPos(hero, Plan::GoMining, target);
			heroMove(target, hero);
			setUsed(hero);
		}
		weiSuo = false;
		canWeiSuo = false;
		return;
	}
	
	if (weiSuo && console->round() - lastVisitEnemy > 100 && console->round() - lastSpy > 100 && !occupyCenter)
	{
		PUnit *p = 0;
		for (auto hero : heros) if (getHeroType(hero) == 4) p = hero;
		Pos target = Pos(74, 98);
		if (p && canUse(p) && p->findSkill("SetObserver")->cd <= 10)
		{
			debuger << p->name<<' '<<p->id<<' '<<p->pos<<' '<<getPlan(p)<<'n';
			setPlanAndTmpPos(p, Plan::WeiSuo, target);
			heroMove(target ,p);
			setUsed(p);
			lastSpy = console->round();
		}
	}
	
	if (canWeiSuo && (weiSuo || (getMaxPower(1 - console->camp(), false) * 1.3 > herosMaxPower && console->round() > 100 && !occupyCenter)))
	{
		debuger<<"  WEISUOn";
		weiSuo = true;
		vector<PUnit*> a, b;
		Pos pa = MINE_POS[5], pb = MINE_POS[6];
		int t = heroNum <= 6 ? 3 : 4;
		for (auto hero : heros)
		{
			if (buyOrder[hero->id] <= t) a.push_back(hero);
			else b.push_back(hero);
		}
		if (a.size() < b.size()) swap(a, b), swap(pa, pb);
		if (heroNum <= 5)
		{
			for (auto i : b) a.push_back(i);
			b.clear();
		}
		for (auto hero : a) if (canUse(hero))
		{
			setPlanAndTmpPos(hero, Plan::GoMining, pa);
			heroMove(pa, hero);
			setUsed(hero);
		}
		for (auto hero : b) if (canUse(hero))
		{
			setPlanAndTmpPos(hero, Plan::GoMining, pb);
			heroMove(pb, hero);
			setUsed(hero);
		}
		return;
	}
	
	UnitFilter filter;
	filter.setTypeFilter("Mine");
	auto mines = enemyUnits(filter);

	if (!killTheWeak) for (auto hero : h) if (canUse(hero))
	{
		if (getPlan(hero) == Plan::Mining && centerInDanger)
		{
			setPlanAndTmpPos(hero, Plan::GoMining, MINE_POS[0]);
			goMiningHeros.push_back(hero);
			continue;
		}
		double maxEnergy = 0;
		Pos target;
		for (auto mine : mines)
		{
			if (dis2(hero->pos, mine->pos) > 144) continue;
			if (getEnemyPowerNearPos(mine->pos) > getFriendlyPowerNearPos(mine->pos) * 1.3) continue;
			if (heroNum <= 6 && (getMineId(mine->pos) == 2 || getMineId(mine->pos) == 3)) continue;
			double t = sqrt(max(dis2(hero->pos, mine->pos) - MINE_VIEW, 0) / hero->speed);
			t = getMineEnergy(mine) - t;
			if (t > 0 && t > maxEnergy) maxEnergy = t, target = mine->pos;
		}
		if (maxEnergy > 0 && console->round() > 80)
		{
			debuger<<target<<' '<<getFriendlyPowerNearPos(MINE_POS[0])<<' '<<getPower(heros)<<'n';
			if (centerInDanger && target != MINE_POS[0]);
			else
			{
				setPlanAndTmpPos(hero, Plan::GoMining, target);
				heroMove(target, hero);
				setUsed(hero);
				continue;
			}
		}
		goMiningHeros.push_back(hero);
	}
	if (!goMiningHeros.size()) return;
	for (auto i : goMiningHeros) debuger<<"  ("<<i->name<<' '<<i->id<<")   ";debuger<<'n';
	
	Pos target;
	double priority[MINE_NUM] = {0}, s = 0;
	Pos minePos[MINE_NUM];
	int k = 0;
	for (int i = 0; i < MINE_NUM; i++)// if (console->round() - mineLastVisit[i] > 20)
	{
		//if )
		auto friendly = goMiningHeros;
		for (auto hero : h)
			if ((!canUse(hero) || getPlan(hero) == Plan::Mining) && getMineId(getTmpPos(hero)) == i)
				friendly.push_back(hero);
		double enemyPower = getEnemyPowerNearPos(MINE_POS[i]);
		double friendlyPower = getFriendlyPowerNearPos(MINE_POS[i], friendly);
		debuger<<i<<' '<<' '<<enemyPower<<' '<<friendlyPower<<'n';
		if (enemyPower > friendlyPower * 1.3) continue;
		if (heroNum <= 6 && (i == 2 || i == 3)) continue;
		double ave = 0;
		for (auto hero : friendly)
		{
			double t = sqrt(max(dis2(hero->pos, MINE_POS[i]) - MINE_VIEW, 0) / hero->speed);
			if (getMineId(getTmpPos(hero)) == i)
			{
				 if (getPlan(hero) == Plan::Mining) t = 0;
				 else if (getPlan(hero) == Plan::GoMining) t /= 2;
			}
			ave += t;
		}
		ave /= friendly.size();
		ave += 5;
		ave *= enemyPower / friendlyPower + 5;
		if (!i) ave *= 0.5; // middle mine
		if (!i && console->round() <= 80) ave = 0; // middle mine
		if (ave == 0) ave = 0.005;
		priority[k] = pow(ave, 2);
		minePos[k] = MINE_POS[i];
		debuger<<ave <<"      "<<MINE_POS[i]<<' '<<priority[k]<<'n';
		s += 1.0 / priority[k];
		k++;
	}

	for (int i = 0; i < k; i++) priority[i] = 1 / priority[i] / s, debuger<< priority[i]<<' '<<minePos[i]<<'n';
	if (k) target = minePos[Rand::randomWithProbability(k, priority)];
	if (occupyCenter || maybeMaybeInDanger) target = MINE_POS[0];
	debuger<<target<<'n';
	if (!checkPos(target))
	{
		int minS = 1e9;
		for (int i = 0; i < MINE_NUM; i++)
		{
			int s = 0;
			for (auto hero : heros) s += dis2(MINE_POS[i], hero->pos);
			if (s < minS) minS = s, target = MINE_POS[i];
		}
		// for (auto hero : goMiningHeros) if (canUse(hero))
		// {
		// 	setPlanAndTmpPos(hero, Plan::None, Pos());
		// 	heroMove(base->pos, hero);
		// 	setUsed(hero);
		// }
	}
	for (auto hero : goMiningHeros) if (canUse(hero))
	{
		setPlanAndTmpPos(hero, Plan::GoMining, target);
		heroMove(target, hero);
		setUsed(hero);
	}
}

void Ai::makePlan()
{
	for (auto team : teams)
	{
		debuger<<team->size()<<'n';
		for (int i=0; i<team->size(); i++)
		{
			PUnit* a = (*team)[i];
			debuger<<a->name<<' '<<a->id<<' '<<a->pos<<' '<<getPlan(a)<<' '<<getTmpPos(a)<<' '<<canUse(a)<<"    "<<getPower(a)<<'n';
		}
		debuger<<"  "<<team->getPower()<<'n';
	}
	//return;
	for (auto team : teams) team->makePlan();
	if (maybeMaybeInDanger)
	{
		for (auto hero : heros) if (canUse(hero) && hero->canUseSkill("SetObserver"))
		{
			Pos pos = !console->camp() ? Pos(27, 33) : Pos(123, 117);
			bool nearObservers = false;
			UnitFilter filter;
			filter.setTypeFilter("Observer");
			vector<PUnit*> observers = console->friendlyUnits(filter);
			for (auto i: observers) if (dis2(i->pos, pos) <= TEAM_RANGE) nearObservers = true;
			if (!nearObservers)
			{
				if (dis2(hero->pos, pos) == 0)
					setObserver(hero, pos);
				else
					heroMove(pos, hero);
				continue;
			}
		}
	}
	if (!inDanger)
	{
		if (maybeInDanger || ((inDangerTimes >= 2 || getHp(base) <= 800) && console->round() - lastInDanger <= 150))
		{
			maybeMaybeInDanger = true;
			Pos p[2];
			static int k;
			if (!console->camp())
				p[0] = Pos(8, 15), p[1] = Pos(25, 15);
			else 
				p[0] = Pos(125, 135), p[1] = Pos(140, 135);
			int s = 0, n = 0;
			for (auto hero : heros)
			{
				if (dis2(hero->pos, p[k]) <= 64) s++;
				if (dis2(hero->pos, base->pos) <= MILITARY_BASE_VIEW * 2) n++;
			}
			if (s >= n * 0.8) k = 1 - k;
			for (auto hero : heros) if (canUse(hero))
			{
				Pos pos = !console->camp() ? Pos(27, 33) : Pos(123, 117);
				if (getHeroType(hero) == 4 && hero->findSkill("SetObserver")->cd <= 1.0 * dis2(pos, hero->pos) / hero->speed + 1)
				{
					bool nearObservers = false;
					UnitFilter filter;
					filter.setTypeFilter("Observer");
					vector<PUnit*> observers = console->friendlyUnits(filter);
					for (auto i: observers) if (dis2(i->pos, pos) <= TEAM_RANGE) nearObservers = true;
					if (!nearObservers)
					{
						if (dis2(hero->pos, pos) == 0)
							setObserver(hero, pos);
						else
							heroMove(pos, hero);
						continue;
					}
				}
				heroMove(p[k], hero);
			}
		}
	}
	
	tryKillTheWeak();
	tryDestroyBase();
	tryMining();
	//debuger<<"tryDestroyBase"<<'n';
	
	for (auto hero : heros) debuger<<"  @@@@@ "<<hero->name<<' '<<hero->id<<' '<<getPlan(hero)<<' '<<getTmpPos(hero)<<' '<<canUse(hero)<<'n';
	for (auto hero : heros) if (canUse(hero))
	{
		Plan plan = getPlan(hero);
		Pos pos = getTmpPos(hero);
		if (plan == Plan::Running) heroMove(base->pos, hero);
		else if (checkPos(pos)) heroMove(pos, hero);
	}
}

void Ai::start()
{
	debuger<<"============= ROUND "<<console->round()<<"=============="<<'n';
	debuger<<"start"<<'n';
	debuger.flush();
	updatePlan();
	debuger<<"updatePlan"<<'n';
	debuger.flush();
	upgradeCamp();
	debuger<<"upgradeCamp"<<'n';
	debuger.flush();
	tryDefence();
	debuger<<"tryDefence"<<'n';
	debuger.flush();
	makePlan();
	debuger<<"makePlan"<<'n';
	debuger.flush();
	MC.solve();
	TMC.solve();
	debuger<<lastInDanger<<' '<<inDangerTimes<<"        "<<lastEnemyBaseHpLost<<' '<<maybeInDanger<<' '<<killTheWeak<<'n';
	if (inDanger || goWinning) cout<<"   DANGER  "<<inDanger<<"   WINNING  "<<goWinning<<'n';
	debuger.print();
	debuger.flush();
	debuger<<"complete"<<'n';
}

void getCanReach()						// 每个点是否可以到达
{
	Pos q[155*155];
	q[1] = MILITARY_BASE_POS[console->camp()];
	canReach[q[1].x][q[1].y] = true;
	for (int i = 0; i < MAP_SIZE; i++)
		for (int j = 0; j < MAP_SIZE; j++) height[i][j] = MAP[i][j];
	for (int l = 1, r = 1; l <= r; l++)
	{
		Pos u = q[l];
		for (int i = 0; i < 4; i++)
		{
			Pos v = u + Pos(dir[i][0], dir[i][1]);
			if (checkPos(v) && abs(MAP[v.x][v.y] - MAP[u.x][u.y]) <= 1 && !canReach[v.x][v.y])
			{
				canReach[v.x][v.y] = true;
				q[++r] = v;
			}
		}
	}
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(0) + rand());
	::MAP = map;
	::CMD = &cmd;
	::INFO = &info;
	
	console = new Console(map, info, cmd);
	//if (console->round() == 999) for (;;);
	// Initialization at Round 0
	if (!console->round())
	{
		getCanReach();
		for (int i = 0; i < 1005; i++) SQRT[i]=sqrt((double)i);
		for (int i= 0; i < 7; i++) mineLastVisit[i] = -1e9;
		LPL.init();
	}
	// Initialization at every Round
	memset(used, 0, sizeof(used));
	goMiningHeros.clear();
	
	Ai* ai = new Ai();
	ai->start();

	delete console;
	delete ai;
}

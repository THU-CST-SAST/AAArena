#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
using namespace std;
static int newHeroFirst = 1, supportRange = 300, AttackRange = 1000;
static int monsterAvoid = 500, ObserverAvoid = 3000, enemyAvoid = 30, deltaFightArg = 100;
static int outOfRangeArg = 100, FollowArg = 160, attackArg = 1000, beatArg = 1000;
static int miningArg = 300, sameMineArg = 25, centerMineArg = 50, EmptyMining = 300;
static int goBackHomeHp = 100, goBackHomeArg = 300, TemptArg = 2000;
static int hammerDizzy = 50, sacrify = 500, superdead=200;
static int strategyDisabled = - 1<<30;
const double minv=1e-10;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int Mine_Danger[7]={500,500,500,500,0,0};
bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Blink")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}
class Strategy; //前向引用声明

class AIController //控制ai的主类
{
public:
	AIController(){};
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	void levelupHero();
	void buyNewHero(int k);
	void action();
	Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	std::vector<PUnit*> myHeros, enemyHeros;
	PUnit *myBase, *enemyBase;
	vector<Strategy*> Decided;
};
AIController Con;

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual double countWorth() = 0; //计算某种策略的实行价值
	virtual void work() = 0; //实现这种策略
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	double getWorth() {return worth;}
	void setWorth(double worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
	string name;
	Pos Position;
protected:
	PUnit* worker;
	double worth;
	vector<AIHero*> AIHeroList;
	Console* console;
};

class Attack:public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual double countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual double countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual double countWorth();
	virtual void work();
};

class CallBackHome:public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual double countWorth();
	virtual void work();
};

class GoMining:public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target, int code) {setWorker(worker);setTarget(target);setcode(code);this->Position=target;name = "GoMining";}
public:
	virtual double countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	void setcode(int code) {this->code = code;}
	Pos getTarget() {return target;}
private:
	int code;
	Pos target;
};

class Tempt:public Strategy //引诱敌人（野怪）的策略-即几乎保证自己不受伤的情况下进行hit-and-run
{
public:
	Tempt(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Tempt";}
public:
	virtual double countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class Follow:public Strategy //跟随的策略 
{
public:
	Follow(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Follow";}
public:
	virtual double countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //默认选择回家的策略
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() {return mStrategy;}
	PUnit* mHero;
private:
	Strategy* mStrategy;
};

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan") 
		|| !strcmp(enemyUnits[i]->name,"Observer"))
			enemyHeros.push_back(enemyUnits[i]);
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()
{
	if(Con.myHeros.size()<8)
		return;
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE ), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(int i = 0; i < heroToLevelUp.size(); ++i)
		console->buyHeroLevel(heroToLevelUp[i]);
}

void AIController::buyNewHero(int k)
{
	if(k != -1)
	{
		console->chooseHero(HERO_NAME[k]);
		return;
	}
	 
	int Num[4] = {0};

	for(int i = 0; i < myHeros.size(); ++i)
	{
		if(!strcmp(myHeros[i]->name,"Hammerguard"))
			Num[0]++;
		if(!strcmp(myHeros[i]->name,"Berserker"))
			Num[1]++;		
		if(!strcmp(myHeros[i]->name,"Master"))
			Num[2]++;		
		if(!strcmp(myHeros[i]->name,"Scouter"))
			Num[3]++;	
	}	
	
	for(int i=0; i < 4; ++i)
		if(Num[i] == 1)
			console->chooseHero(HERO_NAME[i]);
}

void AIController::action()
{
	vector<AIHero*> AIHeroList;
	for(int i = 0; i < myHeros.size(); ++i) 
	AIHeroList.push_back(new AIHero(myHeros[i]));
		
	for(int i = 0; i < MINE_NUM; ++i)
		if(Mine_Danger[i])
		Mine_Danger[i]--;
		
	for(int i = 0; i < myHeros.size(); ++i)
	{
		vector<Strategy*> allStrategy;
		for(int j = 0; j < enemyHeros.size(); ++j)
		{
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
			allStrategy.push_back(new Tempt(myHeros[i], enemyHeros[j]));
		}
		for(int j = 0; j < MINE_NUM; ++j)
			if(!Mine_Danger[j])
				allStrategy.push_back(new GoMining(myHeros[i], MINE_POS[j], j));
		if(enemyBase != NULL)
		{
			allStrategy.push_back(new Attack(myHeros[i], enemyBase));
			allStrategy.push_back(new UseSkill(myHeros[i], enemyBase));
		}
		allStrategy.push_back(new GoBackHome(myHeros[i]));
		allStrategy.push_back(new CallBackHome(myHeros[i]));
		for(int j = 0; j < allStrategy.size(); ++j)
		{
			allStrategy[j]->setAIHeroList(AIHeroList);
			allStrategy[j]->setConsole(console);
			AIHeroList[i]->setStrategy(allStrategy[j]);
		}
		AIHeroList[i]->action();
	}
	
	
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	newStrategy->countWorth();
	if(mStrategy == NULL || newStrategy->getWorth() > this->mStrategy->getWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	Con.Decided.push_back(mStrategy); 
	mStrategy->work();
}

void CalcDefence(int &Attack,PUnit* target)
{
	if(!strcmp(target->name,"Hammerguard"))
		Attack-=10+target->level*2;
	if(!strcmp(target->name,"Berserker"))
		Attack-=10+target->level*3;
	if(!strcmp(target->name,"Scouter"))
		Attack-=10+target->level*3;
	if(!strcmp(target->name,"Master"))
		Attack-=5+target->level*1;
	if(!strcmp(target->name,"Dragon"))
		Attack-=10;
	if(!strcmp(target->name,"Roshan"))
		Attack-=25;
	if(!strcmp(target->name,"Observer"))
		Attack-=200;
	if(!strcmp(target->name,"MilitaryBase"))
		Attack-=20;
}

int Calc(Pos pos)//对当前局面的估计 
{
	double a=minv,b=minv;
	int c=0;
	for(int i = 0; i < Con.myHeros.size(); ++i)
		if(dis2(Con.myHeros[i]->pos, pos)<= supportRange)
		{
			a += 0.5;
			a += Con.myHeros[i]->level / 20.0;
			a += (double)Con.myHeros[i]->hp / (double)Con.myHeros[i]->max_hp * 0.25;
		}
			
	for(int i = 0; i < Con.enemyHeros.size(); ++i)
		if(dis2(Con.enemyHeros[i]->pos, pos)<= supportRange 
		&& strcmp(Con.enemyHeros[i]->name, "Observer")
		&& Con.enemyHeros[i]->findBuff("Reviving") == NULL)
		{
			if(Con.enemyHeros[i]->isWild())
				b += 2;
			b += 0.5;
			b += Con.enemyHeros[i]->level / 20.0;
			b += (double)Con.enemyHeros[i]->hp / (double)Con.enemyHeros[i]->max_hp * 0.25;
		}
		
	if(a-b>=1||b==minv)
		return 1;
	if(b-a>=1||a==minv)
		return -1;
	return 0;
} 

void Move1(PUnit* worker, Pos target)
{
	Console* console = Con.console;
	console->selectUnit(worker);
	
	if(!strcmp(worker->name,"Master") && worker->canUseSkill("Blink"))
	{
		int x1,y1;
		x1=target.x-worker->pos.x;
		y1=target.y-worker->pos.y;
		double d=dis2(worker->pos, target);
		d=sqrt(d/81);
		x1=x1/d;
		y1=y1/d;
		Pos nt;
		nt.x=worker->pos.x+x1;
		nt.y=worker->pos.y+y1;
			
		vector<PSkill*> skillList = console->getSkills();
	
		for(int i = 0; i < skillList.size(); ++i)
			if(!strcmp(skillList[i]->name, "Blink"))
				console->useSkill(skillList[i], nt);
	}
	else
		console->move(target);
}

double Attack::countWorth()
{
	this->worth = 0;
	int t=Calc(target->pos);
	
	if(dis2(worker->pos,target->pos) <= AttackRange)
	{
		int Attack;
		
		if(!strcmp(worker->name,"Hammerguard"))
			Attack=50+worker->level*8;
		if(!strcmp(worker->name,"Berserker"))
			Attack=30+worker->level*8;
		if(!strcmp(worker->name,"Scouter"))
			Attack=25+worker->level*4;
		if(!strcmp(worker->name,"Master"))
			Attack=25+worker->level*4;
			
		CalcDefence(Attack, target);
		Attack=max(Attack,5)*10;		
			
		this->worth += ((double)target->max_hp/(double)target->hp) * (double)Attack ;
		
		if(target->isWild()) 
			this->worth -= monsterAvoid;
		if(!strcmp(target->name,"Observer")&&Con.enemyHeros.size()!=1) 
			this->worth -= ObserverAvoid;
		if(!strcmp(target->name,"Berserker")&&dis2(Con.myBase->pos,target->pos)<=supportRange) 
			this->worth += beatArg;
							
		if(target->findBuff("Dizzy") != NULL)
			this->worth += hammerDizzy;
		if(target->findBuff("WinOrDie") != NULL)
			this->worth += sacrify;
	}
	
	if(target->findBuff("Reviving") != NULL)
		this->worth = strategyDisabled;
	if(t==-1)
		this->worth = strategyDisabled;
	if(t==0)
		this->worth += attackArg;	
	return this->worth;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

double UseSkill::countWorth()
{
	this->worth = 0;
	
	int t=Calc(target->pos);
	
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!worker->canUseSkill(skillList[i]))
				this->worth = strategyDisabled;
			else
			{
				if(!strcmp(skillList[i]->name, "HammerAttack"))
				{
					if(dis2(worker->pos,target->pos) <= HAMMERATTACK_RANGE)
					{
						int Attack=80+worker->level*30;
						CalcDefence(Attack, target);
						Attack=max(Attack,5)*10;
						this->worth += ((double)target->max_hp/(double)target->hp) * (double)Attack ;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						if(target->findBuff("WinOrDie") != NULL)
							this->worth += sacrify;
						if(t==0)
							this->worth += attackArg;	
					}
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(t==-1)
						this->worth=strategyDisabled;
				}
				else if(!strcmp(skillList[i]->name, "Sacrifice"))
				{
					
					int Attack=worker->hp-1;
					CalcDefence(Attack, target);
					Attack=max(Attack,5)*20;
					if(dis2(worker->pos,target->pos) <= worker->range)
					{
						this->worth += this->worth += ((double)target->max_hp/(double)target->hp) * (double)Attack ;
						if(target->findBuff("Dizzy") != NULL)
							this->worth += hammerDizzy;
						if(target->findBuff("WinOrDie") != NULL)
							this->worth += sacrify;
						if(worker->findSkill("SuperDead")->cd > 0)
							this->worth -= superdead;
						if(t==0)
							this->worth += attackArg;	
					}
					
					for(int j = 0; j < Con.enemyHeros.size(); ++j)
					{
						if(Con.enemyHeros[j]!=target&& (Con.enemyHeros[j]->findBuff("Dizzy") !=NULL
						||Con.enemyHeros[j]->findBuff("WaitRevive") !=NULL) )
								this->worth = strategyDisabled;
						
						for(int k = 0; k < Con.enemyHeros[j]->skills.size(); ++k)
						{
							if(!strcmp(worker->skills[k].name, "Attack") && worker->skills[k].cd == 0)
								this->worth = strategyDisabled;
							if(!strcmp(worker->skills[k].name, "HammerAttack") && worker->skills[k].cd == 0)
								this->worth = strategyDisabled;
						}
					}
								
					for(int k = 0; k < worker->skills.size(); ++k)
						if(!strcmp (worker->skills[k].name, "Attack") && worker->skills[k].cd > 1) 
							this->worth = strategyDisabled;
					
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(t==-1)
						this->worth=strategyDisabled;
				}
				else if(!strcmp(skillList[i]->name, "SetObserver"))
				{
					if(dis2(worker->pos,target->pos) <= supportRange)
					{
						this->worth += 2 * attackArg;
						if(dis2(worker->pos,target->pos) > worker->view)
							this->worth -= outOfRangeArg * 2;
						if(target->findBuff("Dizzy") != NULL)
							this->worth -= hammerDizzy;
						this->targetPos = console->randPosInArea(worker->pos,skillList[i]->range());
					}
					if(target->findBuff("Reviving") != NULL)
						this->worth = strategyDisabled;
					if(skillList[i]->cd != 0)
						this->worth = strategyDisabled;
				}
			}
			break;
		}
	return this->worth;
}

void UseSkill::work()
{
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
				console->useSkill(skillList[i], target);
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
				console->useSkill(skillList[i], NULL);
			else
				console->useSkill(skillList[i], targetPos);
			break;
		}
}

double Tempt::countWorth()
{
	this->worth = 0;
	int t=Calc(worker->pos);
	if(t==-1) 
		this->worth += TemptArg;
	return this->worth;
}

void Tempt::work()
{
	Move1(worker, worker->pos+worker->pos-target->pos);
}

double Follow::countWorth()
{
	this->worth = 0;
	if(worker->typeId > target->typeId)
		this->worth = FollowArg;
	if(dis2(worker->pos, target->pos)<= worker->view/2)
		this->worth = strategyDisabled;
	this->worth -= dis(worker->pos, target->pos);
	return this->worth;
}

void Follow::work()
{
	console->selectUnit((const PUnit*)worker);
	console->move(target->pos);
}

double GoMining::countWorth()
{
	this->worth = miningArg;
	int t=Calc(target);
	if(target == MINE_POS[0])
		this->worth += centerMineArg;
					
	int p=0,q=1,k=0,o=0;
	for(int i = 0; i < Con.enemyHeros.size(); ++i)
	{
			if(dis2(Con.enemyHeros[i]->pos, target) <= supportRange
			&& Con.enemyHeros[i]->findBuff("Reviving") == NULL)
			{
				p++;
				if(!Con.enemyHeros[i]->isWild())
					k++;
			}
			if(Con.enemyHeros[i]->isWild() && Con.enemyHeros[i]->findBuff("Reviving") != NULL)
					q=0;
	}

	/*for(int i = 0; i < Con.myHeros.size(); ++i)
			if(dis2(Con.myHeros[i]->pos, target) <= MINING_RANGE)
					p++;	

	if(t==1)
	{		
		for(int i = 0; i < Con.Decided.size(); ++i)
			if(!strcmp(Con.Decided[i]->name.c_str(), "GoMining") 
			&& Con.Decided[i]->Position==target && 
			dis2(Con.myHeros[i]->pos,target)<=supportRange)
				this->worth -=sameMineArg;
	}	
		
	else */
		if(t==-1 && k!=0)
		{
			this->worth = strategyDisabled;
			Mine_Danger[code]+=100;
		}
		else
			for(int i = 0; i < Con.Decided.size(); ++i)
				if(!strcmp(Con.Decided[i]->name.c_str(), "GoMining") 
				&& Con.Decided[i]->Position==target)
					this->worth += sameMineArg;

	
	if(p==0 && (code==0 || q==0))
	{
		
		for(int i = 0; i < Con.Decided.size(); ++i)
			if(!strcmp(Con.Decided[i]->name.c_str(), "GoMining") 
			&& Con.Decided[i]->Position==target)
			{
					this->worth = strategyDisabled;
					o=1;
			}
		if(!o)
		this->worth += EmptyMining;	
	}
			
	for(int i = 0; i < Con.enemyHeros.size(); ++i)
			if(dis2(Con.enemyHeros[i]->pos, target)<= supportRange
			&& dis2(worker->pos, target)<= supportRange 
			&& Con.enemyHeros[i]->findBuff("Reviving") == NULL)
					this->worth = strategyDisabled;
										
	return this->worth;
}

void GoMining::work()
{
	Move1(worker, target);
}

double GoBackHome::countWorth()
{
	this->worth = 0;
	if(worker->hp <= goBackHomeHp && Con.enemyHeros.size() != 0) 
		this->worth += goBackHomeArg*log(goBackHomeHp-worker->hp);
			
	if(worker->findBuff("WinOrDie") != NULL)
		this->worth = strategyDisabled;
		
	return this->worth;
}

void GoBackHome::work()
{
	Move1(worker, Con.myBase->pos);
}

double CallBackHome::countWorth()
{
	this->worth = 3000-Con.myBase->hp;
	if(dis2(Con.myBase->pos, worker->pos) <= Con.myBase->range/2)
		this->worth = strategyDisabled;
	
	int ok=(3250-Con.myBase->hp)/500;	
		for(int i = 0; i < Con.Decided.size(); ++i)
			if(!strcmp(Con.Decided[i]->name.c_str(), "CallBackHome"))
				ok--;
	for(int i = 0; i < Con.enemyHeros.size(); ++i)
		if(dis2(Con.enemyHeros[i]->pos, Con.myBase->pos) <= supportRange)
			ok++;
	if(ok<=0)
		this->worth = strategyDisabled;
		
	return this->worth;
}

void CallBackHome::work()
{
	if(CALLBACK_COST_BASE+CALLBACK_COST_PER_LEVEL*worker->level>Con.info->gold||
	dis2(worker->pos,Con.myBase->pos) <= supportRange)
		Move1(worker, Con.myBase->pos);
	else
		console->callBackHero(worker);
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	srand(time(NULL));
	AIController c(map,info,cmd);
	Con=c;

	if(info.round == 0)
	{
		for(int i = 1; i <= 4; ++i)
			Con.buyNewHero(i-1);
		return;
	}
	if(newHeroFirst)
	{
		Con.buyNewHero(0);
		Con.buyNewHero(1);
		Con.levelupHero();
	}
	else
	{
		Con.levelupHero();
		Con.buyNewHero(-1);
	}
	Con.action();
}

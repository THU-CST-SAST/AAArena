#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
#include <cmath>
using namespace std;
const int INF = 1000000000;
const int MAX_LIFE = 2000;
const int NAME_NU = 6;
const int HERO_COST = 250;

const int VICINITY = 36;            //To define if choose to attack when solitary
const int FORCE_BACK = 400;            //The money to act forced back
const int WALK_BACK = 270;           //The range to choose walk back
const int GO_WILD = 50;              //To set the probability to give life to animal
static const int heroRank = 11214321;
static const int SICK = 110;  //To define how much life is sick
static const int HALF = 150;
static const int LEVEL_UP_RANK[] = {4, 2, 1, 3};          //Min means first choose
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter", "Dragon", "Roshan"};
static const int ONSET_POINTA[] = {10, 5, 8, 8}, ONSET_DIST_MAX = 100, ONSET_DIST_PER = 8, ONSET_DIST_ADMIT = 8;
static const int ONSET_POINTB[] = {7, 10, 10, 5, 1, 1};
static const int ONSET_LIFE_MAX = 500, ONSET_LIFE_PER = 1;
static const int DIG_POINTA[] = {5, 5, 5, 5}, DIG_DIST_MAX = 100, DIG_DIST_PER = 2, DIG_DIST_ADMIT = 50; 
static const int DIG_POINTB[] = {40, 0, 0, 0, 0, 0, 0}, DIG_MINE_BASE[] = {100, 0, 0, 0, 0, 0, 0, 0};

void UOnset(Console* console, PUnit* myaim, PUnit* enemy);
void UDig(Console* console, PUnit* myaim, int mine);
void UBack(Console*, PUnit* myaim);

int Namenum(PUnit* aim)
{
    char *s=aim->name;
    for(int i=0; i<NAME_NU; ++i)
        if(strcmp(s, HERO_NAME[i]) == 0)
            return i;
}

int Health(PUnit* aim, Console* console)
{
    //0:dizzy 1:sick 2:healthy
    if(aim->findBuff("Reviving"))return 0;
    if(aim->findBuff("Dizzy"))return 0;
    if(aim->findBuff("WaitRevive"))return 0;
    if(aim->findBuff("WinOrDie"))return 2;

    console->selectUnit(aim);
    if(console->unitArg("hp","c") < SICK ) return 1;
    return 2;
}

int Halfhealth(PUnit* aim, Console* console)
{
    console->selectUnit(aim);
    if(console->unitArg("hp","c") < HALF ) return 1;
    return 0;
}

class Strategy;
class AIController
{
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();

    //Player Function
	void Buyhero();
    void Leveluphero();
    void Setstrategy();
    void Work();
    
    bool Permit_level(PUnit*);
    
    //Unit Function
    void UOnset(PUnit*, PUnit*);
    void UDig(PUnit*, int);
    void UBack(PUnit*, bool = true);
    void USolitude(PUnit*);
    void ULevelup(PUnit*);

private:
	Console* console;
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
    std::vector<PUnit*> myHeros, enemyHeros, Mines;
    std::vector<Strategy*> stg;
    Strategy* best_stg = NULL;
	PUnit *myBase, *enemyBase;
    // No consider final attack and defend
    
};

class Strategy
{
public:
	virtual int Countworth(){} 
	virtual void Work(){} 
protected:
    friend void AIController::Setstrategy();
    friend void AIController::Leveluphero();
    friend void AIController::Work();

	int worth;
    int manipulate[ HERO_LIMIT ];
    //To record what should a hero do, In this array, 1 go back home, 2 dig, 3 onset
    Console* console;
    vector<PUnit*>& myHeros;
    AIController* desk;

    Strategy(Console* console, vector<PUnit*>& myHeros, AIController* controller): console(console), myHeros(myHeros), desk(controller){}
    void Groupwork(vector<PUnit*>& myHeros, int mine_aim, PUnit* enemy_aim = NULL);
};

class SOnset: public Strategy
{
public:
	int Countworth();
	void Work();

    SOnset(Console* console, vector<PUnit*>& myHeros, AIController* desk, PUnit* aimer): Strategy(console, myHeros, desk), aimer(aimer){};
private:
    PUnit* aimer;
};

class SDig: public Strategy
{
public:
	int Countworth();
	void Work();

    SDig(Console* console, vector<PUnit*>& myHeros, AIController* desk, int aimer): Strategy(console, myHeros, desk), aimer(aimer){};
private:
    int aimer;
};

//We can calculate how much turns later can go back to battlefield
int SDig::Countworth()
{
    int fin=0, health, battlepoints=DIG_MINE_BASE[aimer], dist, walktime, speed, enemybase;
    for(int i=0;i<myHeros.size();++i)
    {
        health = Health(myHeros[i], console);
        dist = dis2(myHeros[i]->pos, MINE_POS[aimer]);
        speed = myHeros[i]->speed;
        if(speed)
            walktime = dist/speed;
        else
            walktime = INF;
        switch(health)
        {
            case 0:
                manipulate[i] = 2;
                break;
            case 1:
                manipulate[i] = 1;
                break;
            case 2:
                manipulate[i] = 2;
                if(walktime <= DIG_DIST_ADMIT)
                    battlepoints += DIG_POINTA[Namenum(myHeros[i])] * max((DIG_DIST_MAX - DIG_DIST_PER * walktime), 0);
        }
    }
    enemybase = DIG_POINTB[aimer];
    //printf("%d %dn", battlepoints , enemybase);
    return battlepoints * enemybase;
}


int SOnset::Countworth()
{
    int fin=0, health, battlepoints=0, dist, walktime, speed, enemybase;
    for(int i=0;i<myHeros.size();++i)
    {
        health = Health(myHeros[i], console);
        dist = dis2(myHeros[i]->pos, aimer->pos);
        speed = myHeros[i]->speed;
        if(speed)
            walktime = dist/speed;
        else
            walktime = INF;
        switch(health)
        {
            case 0:
                manipulate[i] = 3;
                break;
            case 1:
                manipulate[i] = 1;
                break;
            case 2:
                if(walktime <= ONSET_DIST_ADMIT)
                {
                    battlepoints += ONSET_POINTA[Namenum(myHeros[i])] * max(0, (ONSET_DIST_MAX - ONSET_DIST_PER * walktime));
                    manipulate[i] = 3;
                }
                else 
                    manipulate[i] = 4;              //We can set : Wait for ask
        }
    }
    enemybase = ONSET_POINTB[Namenum(aimer)] * (ONSET_LIFE_MAX - ONSET_LIFE_PER * aimer->hp);
    //printf("%d %dn", battlepoints , enemybase);
    return battlepoints * enemybase;
}

void SOnset::Work()
{
    //printf("Onset %s %dn", aimer->name, worth);
    Groupwork(myHeros, 0, aimer);
}

void SDig::Work()
{
    //printf("Dig %d %dn",aimer, worth);
    Groupwork(myHeros, aimer);
}

//Build new controller, Get some original info
AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
			myHeros.push_back(myUnits[i]);
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan"))
			enemyHeros.push_back(enemyUnits[i]);
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::Setstrategy()
{
    for(int i=0;i<enemyHeros.size();++i)
    {
        stg.push_back(dynamic_cast<Strategy*>(new SOnset(console, myHeros, this, enemyHeros[i]))); 
    }
    for(int i=0;i<MINE_NUM;++i)
    {
        stg.push_back(dynamic_cast<Strategy*>(new SDig(console, myHeros, this, i)));
    }
    for(int i=0;i<stg.size();++i)
    {
     //   printf("fuck it ");
        stg[i]->worth = stg[i]->Countworth();
    }
    int max_count = -1;
    for(int i=0;i<stg.size();++i)
    {
        if(stg[i]->worth > max_count)
        {
            max_count = stg[i]->worth;
            best_stg = stg[i];
        }
    }
}

void AIController::Work()
{
    if(best_stg!=NULL)best_stg->Work();                   //You'd never let it be NULL!
    for(int i=0;i<stg.size();++i)
        if(stg[i]!=NULL)
            delete stg[i];
}

//Check if a hore is permitted to level up
bool AIController::Permit_level(PUnit* aim)
{
    if(dis2(aim->pos, MILITARY_BASE_POS[console->camp()]) > LEVELUP_RANGE) return false;
    if(HERO_LEVEL_LIMIT == aim-> level) return false;
    return true;
}

void AIController::Leveluphero()
{
    int tmp_min_level = HERO_LEVEL_LIMIT, min_type = 4, num=-1;
    for(int i = 0; i < myHeros.size(); ++i)
    {
        if(!Permit_level(myHeros[i]))continue;

        console->selectUnit(myHeros[i]);
        if(console->unitArg("level", "c") < tmp_min_level || console->unitArg("level", "c") == tmp_min_level && LEVEL_UP_RANK[Namenum(myHeros[i])] < min_type)
        {
             tmp_min_level = console->unitArg("level", "c");
             min_type = LEVEL_UP_RANK[Namenum(myHeros[i])];
             num = i;
        }
    }

    if(~num && console->gold() - console->goldCostCurrentRound() > console -> levelUpCost( myHeros[num]->level ))
    {
        this->best_stg->manipulate[num] = 5;               //Change to level up
        return;
    }

    if(myHeros.size() < 8 || console->gold() - console->goldCostCurrentRound() < FORCE_BACK) return;

    int min_value = INF, cur;
    for(int i = 0; i < myHeros.size(); ++i)
        if(!myHeros[i]->findBuff("BeAttacked"))
        {
            console->selectUnit(myHeros[i]);
            cur = dis2(MILITARY_BASE_POS[console->camp()], myHeros[i]->pos) * myHeros[i]->hp;
            if(cur < min_value)
            {
                min_value = cur;
                num = i;
            }
        }

    if(~num)
    {
        this->best_stg->manipulate[num] = 5;               //Change to level up
        return;
    }

}

void AIController::Buyhero()
{
    if(info->round == 0)
    {
        for(int i=0;i<4;++i)
            console->chooseHero(HERO_NAME[i]);
        return;
    }
	int newHero, rank=heroRank;
    for(int i=0;i<myHeros.size();++i)
        rank/=10;
    newHero = rank % 10 - 1;
    puts("bf");
	if(newHero < 0 || newHero > 3)
    {
        //this->Leveluphero();
        return;
    }
    printf("af");
    console->chooseHero(HERO_NAME[newHero]);
}

//Main Function
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
   // printf("Doesn");
	srand(time(NULL));
	AIController controller(map,info,cmd);
	controller.Buyhero();
	controller.Setstrategy();
    controller.Leveluphero();
    controller.Work();
}

void Strategy::Groupwork(vector<PUnit*>& myHeros, int mine_aim, PUnit* enemy_aim)
{
    //printf("Groupworkn");
    for(int i=0;i<myHeros.size();++i)
    {
        switch(manipulate[i])
        {
            case 1:
                desk->UBack(myHeros[i]);
                break;
            case 2:
                if(mine_aim>-1 && mine_aim<MINE_NUM)
                    desk->UDig( myHeros[i], mine_aim);
                break;
            case 3:
                if(enemy_aim)
                    desk->UOnset( myHeros[i], enemy_aim);
                break;
            case 4:
                desk->USolitude( myHeros[i]);
                break;
            case 5:
                desk->ULevelup(myHeros[i]);
        }
    }
}

//Can record cd and adjust attack or walk
void AIController::UOnset(PUnit* self, PUnit* enemy)
{
    int id = Namenum(self);
    console->selectUnit(self);
    console->move(enemy->pos);
    console->attack(enemy);
    switch(id)
    {
        case 0:
            if(self->canUseSkill("Hammerattack") && dis2(self->pos, enemy->pos) <= HAMMERATTACK_RANGE)
                console->useSkill("HammerAttack", enemy);
            break;
        case 2:
            if(dis2(self->pos, enemy->pos) <= self->range && self->canUseSkill("Sacrifice") && self->canUseSkill("Attack"))
                console->useSkill("Sacrifice", NULL);
    }
}

void AIController::UDig(PUnit* self, int mine)
{
    console->selectUnit(self);
    console->move(MINE_POS[mine]);
}

void AIController::UBack(PUnit* self, bool danger)
{
    int id = Namenum(self);
    //if dangerous, hero will wild, or go back home
    Pos dis_pos;
    int min_dis = INF, min_num = -1, cur;
    if(danger)
    {
        if(rand() % 100 >= GO_WILD)
            danger = false;
    }
    if(danger)
    {
        for(int i=1; i<MINE_NUM; i++)
        {
            cur = dis2(self->pos, MINE_POS[i]);
            if(cur < min_dis)
            {
                min_dis = cur;
                min_num = i;
            }
        }
        if(~min_num)
            dis_pos = MINE_POS[min_num];
        else
            dis_pos = MILITARY_BASE_POS[console->camp()];

        //Then check if there's animal
        PUnit* animal = NULL;
        for(int i=0;i<enemyHeros.size();++i)
        {
            int d=dis2(self->pos, enemyHeros[i]->pos);
            if(Namenum(enemyHeros[i]) > 3 && d <= self ->range)
            {
                animal = enemyHeros[i];
                break;
            }
        }
        if(animal)
        {
            this->UOnset(self, animal);
            return;
        }
    }
    else
        dis_pos = MILITARY_BASE_POS[console->camp()];
    console->selectUnit(self);
    console->move(dis_pos);
    //Blink
    switch (id)
    {
        case 1:
            
            break;
    }
}

void AIController::USolitude(PUnit* self)
{
    if(Halfhealth(self, console))
        this->UBack(self, false);
    else
    {
        console->selectUnit(self);
        console->move(MINE_POS[0]);
        int min_dist = INF, min_num = -1;
        for(int i=0;i<enemyHeros.size();++i)
        {
            int d=dis2(self->pos, enemyHeros[i]->pos);
            if(d<min_dist)
            {
                min_dist = d;
                min_num = i;
            }
        }
        if(~min_num && min_dist <= VICINITY)
            this->UOnset(self, enemyHeros[min_num]);
    }
}

void AIController::ULevelup(PUnit* self)
{
    if(dis2(self->pos, MILITARY_BASE_POS[console->camp()]) <= LEVELUP_RANGE)
    {
        console->buyHeroLevel(self);
    }
    else if(dis2(self->pos, MILITARY_BASE_POS[console->camp()]) <= WALK_BACK)
    {
        this->UBack(self, false);
        return;
    }
    else
    {
        console->callBackHero(self);
        console->buyHeroLevel(self);
    }
}    


#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <cstring>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

Console* console;
static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
const int SAFE_HP = 140;
const int SAFE_RANGE = 25;
const int POS_NUM = 10;
const int HELP_RANGE = 1300;
static const Pos Dragon__pos[] = {Pos(43, 61), Pos(107, 89), Pos(20, 140), Pos(130, 10)};
static const Pos Roshan__pos[] = {Pos(43, 89), Pos(107, 61)};
static const Pos scouter_pos[] = {Pos(143, 33), Pos(17, 117)};
//static const Pos scouter_run_pos[] = {Pos(114, 15), Pos(47, 132)};
static const Pos observer_pos[] = {Pos(133, 132), Pos(17, 20)};
static const Pos base_attack_pos[] = {Pos(34, 130), Pos(114, 17), Pos(109, 133), Pos(44, 12)};
static const Pos home_pos[] = {Pos(51, 10), Pos(80, 142)};
static const int scouter_y[] = {35, 112};

vector<const PUnit*> myHeroes, myHealthyHeroes, mySickHeroes, Hammerguards, Masters, Berserkers, Scouters, enemyHeroes, Wilds, Mines; 
PUnit* myBase = NULL;
PUnit* enemyBase = NULL;	//能否看到对方的基地

bool hit_wild = true;
bool base_attacked = false;
bool middle_mine = false;
bool base_attack = false;
bool disturb = false;
int disturbround = 0;
int disturbfail = 0;
bool enemy_exist = false;
bool disturbing = true;
bool attack1 = false;
bool attack2 = false;

void initialize(const PPlayerInfo &info);
void choosehero(const PPlayerInfo &info);
void buyherolevel(const PPlayerInfo &info);
bool enemyexist(Pos p, int range);
PUnit* nearest_enemy(Pos p);
PUnit* nearest_wild(Pos p);
PUnit* nearby_leasthp_enemy(Pos p, int range);
PUnit* nearby_leasthp_enemy(PUnit* myhero, int range = 0);
PUnit* who_need_help(PUnit* myhero);
vector<const PUnit*> nearby_enemyheros(Pos p, int range);
vector<const PUnit*> nearby_enemyheros(PUnit* hero, int range);
vector<const PUnit*> nearby_myheros(Pos p, int range);
vector<const PUnit*> nearby_myheros(PUnit* hero, int range);
void freetimetodo(PUnit* myhero, int num);
void Hammerguards_action();
void Masters_action();
void Scouters_action();
void Berserkers_action();
void Sickheroes_action();
void base_attack_action();

Pos whereissafer(PUnit* myhero, int range);	//返回一个相对安全的位置  供通灵术师闪烁使用
Pos betterplace(PUnit* hero);	//返回一个相对“好”的位置  供近战英雄走砍使用  优势时边走边进  劣势时边走边跑


void situation()
{
	bool weak = true;
	for(int i = 0; i < myHeroes.size(); ++i)
	{
		if(myHeroes[i]->hp >= myHeroes[i]->max_hp * 3 / 4)
		{
			weak = false;
		}
	}

	if(console->round() >= 70)
	{
		middle_mine = false;
		for(int i = 0; i < myHeroes.size(); ++i)
			if(dis2(myHeroes[i]->pos, MINE_POS[0]) < 70)
				middle_mine = true;

	}
	if(weak && !middle_mine)
	{
		hit_wild = true;
	}
	if(middle_mine && myHeroes.size() >= 6)
		hit_wild = true;
	if(myHeroes.size() >= 7 && console->round() % 150 == 0 && console->round() >= 400)
	{
		if(!base_attack)
		{
			base_attack = true;
			attack1 = false;
			attack2 = false;
		}
	}
	if(nearest_enemy(MILITARY_BASE_POS[console->camp()]) != NULL)
		base_attacked = true;
	if(disturb)
	{
		if(disturbround > 11)
		{
			for(int i = 0; i < enemyHeroes.size(); ++i)
			{
				if(dis2(enemyHeroes[i]->pos, Scouters[1]->pos) <= 1300)
				{
					enemy_exist = true;
					break;
				}
			}
		}
		else if(disturbround == 11)
		{
			if(!enemy_exist)
			{
				if(++disturbfail >= 3)
					disturbing = false;
			}
		}
	}
	if(base_attack && !disturbing)
	{
		if(!attack1)
		{
			int howmany = 0;
			for(int i = 0; i < myHeroes.size(); ++i)
			{
				if(dis2(base_attack_pos[console->camp()], myHeroes[i]->pos) < 144)
					++howmany;
			}
			if(howmany >= 7)
			{
				attack1 = true;
			}
		}
		else if(!attack2)
		{
			int howmany = 0;
			for(int i = 0; i < myHeroes.size(); ++i)
			{
				if(dis2(base_attack_pos[console->camp() + 2], myHeroes[i]->pos) < 144)
					++howmany;
			}
			if(howmany >= 7)
			{
				attack2 = true;
			}
		}
	}

	if(attack2)
	{
		int i;
		for(i = 0; i < myHeroes.size(); ++i)
		{
			if(dis2(MILITARY_BASE_POS[1 - console->camp()], myHeroes[i]->pos) < 2500)
				break;
		}
		if(i >= myHeroes.size())
		{
			base_attack = false;
			attack1 = false;
			attack2 = false;
		}
	}
}





void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
//	cout << disturbing;
	//cout << disturb << " ";
    console = new Console(map, info, cmd);
    initialize(info);
    choosehero(info);
    buyherolevel(info);
    
    if(info.round >= 60)
    	situation();
    if(!attack2)
    {
    	Hammerguards_action();
    	Masters_action();
   		Scouters_action();
   		Berserkers_action();
    //////////////////////////////////////////////////////////////////////////
    Sickheroes_action();
    }
    if(base_attack && !disturbing)
    {
    	base_attack_action();
    }
    delete console;
}












void initialize(const PPlayerInfo &info)	//初始化操作
{
	myHeroes.clear();
	myHealthyHeroes.clear();
	mySickHeroes.clear();
	Hammerguards.clear();
	Masters.clear();
	Berserkers.clear();
	Scouters.clear();
	enemyHeroes.clear();
	Wilds.clear();
	Mines.clear();
	enemyBase = NULL;
	base_attacked = false;
	for(int i = 0; i < info.units.size(); ++i)
    {
        if(info.units[i].isHero())
        {
            if(info.units[i].camp == info.camp)
			{
				myHeroes.push_back((PUnit*)(&info.units[i]));
				if(console->unitArg("hp", "c", (PUnit*)(&info.units[i])) < console->unitArg("hp", "m", (PUnit*)(&info.units[i])) / 3)	//血量低列入虚弱英雄
				{
					mySickHeroes.push_back((PUnit*)(&info.units[i]));
				}
				else
				{
					myHealthyHeroes.push_back((PUnit*)(&info.units[i]));		//健康英雄
				}
                if(strcmp(info.units[i].name, "Hammerguard") == 0)		//归类英雄
                {
                    Hammerguards.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Master") == 0)
                {
                    Masters.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Scouter") == 0)
                {
                    Scouters.push_back((PUnit*)(&info.units[i]));
                }
                else if(strcmp(info.units[i].name, "Berserker") == 0)
                {
                    Berserkers.push_back((PUnit*)(&info.units[i]));
                }
			}
            else if(info.units[i].hp > 0)
            	enemyHeroes.push_back((PUnit*)(&info.units[i]));	//敌方英雄
        }
        else if(info.units[i].isWild())		//野怪列入
        {
        	if(info.units[i].hp > 0)
        		Wilds.push_back((PUnit*)(&info.units[i]));
		}
		else if(strcmp(info.units[i].name, "MilitaryBase") == 0)	//基地
		{
			if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]);
			else enemyBase = (PUnit*)(&info.units[i]);
		}
		else if(strcmp(info.units[i].name, "Mine") == 0)	//金矿
    	{
    		Mines.push_back((PUnit*)(&info.units[i]));
    	}
    }
}

void choosehero(const PPlayerInfo& info)
{
	if(info.round == 0)
	{
		console->chooseHero("Hammerguard");
		console->chooseHero("Berserker");
		console->chooseHero("Master");
		console->chooseHero("Scouter");
		return;
	}
	if(myHeroes.size() < HERO_LIMIT)		//选择英雄 在数量相同的情况下 重锤>绝命>通灵>神行
    {
    	if(Hammerguards.size() <= Scouters.size())
        	console->chooseHero("Hammerguard");
        if(Berserkers.size() < Hammerguards.size())
            console->chooseHero("Berserker");
        if(Masters.size() < Berserkers.size())
            console->chooseHero("Master");
        if(Scouters.size() < Masters.size())
            console->chooseHero("Scouter");
	}
}
void buyherolevel(const PPlayerInfo& info)
{
	if(info.round >= 150 && myHeroes.size() >= 6)
		for(int i = 0; i < myHeroes.size(); ++i)
			console->buyHeroLevel(myHeroes[i]);
}

bool enemyexist(Pos p, int range)
{
	for(int i = 0; i < enemyHeroes.size(); ++i)
	{
		if(dis2(p, enemyHeroes[i]->pos) < range)
			return true;
	}
	return false;
}

vector<const PUnit*> nearby_enemyheros(Pos p, int range)
{
	vector<const PUnit*> nearby_enemyheros;
	for(int i = 0; i < enemyHeroes.size(); ++i)
	{
		if(dis2(p, enemyHeroes[i]->pos) < range)
		{
			nearby_enemyheros.push_back(enemyHeroes[i]);
		}
	}
	return nearby_enemyheros;
}

vector<const PUnit*> nearby_enemyheros(PUnit* hero, int range)
{
	vector<const PUnit*> nearby_enemyheros;
	for(int i = 0; i < enemyHeroes.size(); ++i)
	{
		if(dis2(hero->pos, enemyHeroes[i]->pos) < range)
		{
			nearby_enemyheros.push_back(enemyHeroes[i]);
		}
	}
	return nearby_enemyheros;
}

vector<const PUnit*> nearby_myheros(Pos p, int range)
{
	vector<const PUnit*> nearby_myheros;
	for(int i = 0; i < myHeroes.size(); ++i)
	{
		if(dis2(p, myHeroes[i]->pos) < range)
		{
			nearby_myheros.push_back(myHeroes[i]);
		}
	}
	return nearby_myheros;
}

vector<const PUnit*> nearby_myheros(PUnit* hero, int range)
{
	vector<const PUnit*> nearby_myheros;
	for(int i = 0; i < myHeroes.size(); ++i)
	{
		if(dis2(hero->pos, myHeroes[i]->pos) < range)
		{
			if((PUnit*)myHeroes[i] != hero)
				nearby_myheros.push_back(myHeroes[i]);
		}
	}
	return nearby_myheros;
}

PUnit* nearest_enemy(Pos p)
{
	vector<const PUnit*> nearby_enemy = nearby_enemyheros(p, 144);
	PUnit* nearestenemy = NULL;
	for(int i = 0; i < nearby_enemy.size(); ++i)
	{
		if(nearestenemy == NULL)
		{
			nearestenemy = (PUnit*)nearby_enemy[i];
		}
		else
		{
			if(dis2(p, nearby_enemy[i]->pos) < dis2(p, nearestenemy->pos))
				nearestenemy = (PUnit*)nearby_enemy[i];
		}
	}
	return nearestenemy;
}

PUnit* nearest_wild(Pos p)
{
	PUnit* nearestwild = NULL;
	for(int i = 0; i < Wilds.size(); ++i)
	{
		if(dis2(p, Wilds[i]->pos) <= 144)
			nearestwild = (PUnit*)Wilds[i];
	}
	return nearestwild;
}

Pos whereissafer(PUnit* myhero, int range)	//返回一个相对安全的位置  供通灵术师闪烁使用
{
	vector<const PUnit*> nearby_myfriends = nearby_myheros(myhero, myhero->range);
	vector<const PUnit*> nearby_enemy = nearby_enemyheros(myhero, myhero->range);
	Pos position[POS_NUM];
	
	for(int i = 0; i < POS_NUM; ++i)
	{
		position[i] = Circle(myhero->pos, range).randPosInArea();
	}
	
	int safest, leastenemynum, mostmyherosnum, nearestmybase;
	bool g = false;
	for(int i = 0; i < POS_NUM; ++i)
	{
		int enemynum = 0;
		int myherosnum = 0;
		int distomybase;
		for(int j = 0; j < nearby_enemy.size(); ++j)
		{
			if(dis2(position[i], nearby_enemy[j]->pos) < SAFE_RANGE)
				++enemynum;
		}
		for(int j = 0; j < nearby_myfriends.size(); ++j)
		{
			if(dis2(position[i], nearby_myfriends[j]->pos) < SAFE_RANGE)
					++myherosnum;
		}
		distomybase = dis2(MILITARY_BASE_POS[myhero->camp], position[i]);
		if(g)
		{
			if(enemynum > leastenemynum)
				continue;
			if(myherosnum < mostmyherosnum)
				continue;
			if(distomybase > nearestmybase)
				continue;
			safest = i;
			leastenemynum = enemynum;
			mostmyherosnum = myherosnum;
			nearestmybase = distomybase;
		}
		else
		{
			g = true;
			safest = i;
			leastenemynum = enemynum;
			mostmyherosnum = myherosnum;
			nearestmybase = distomybase;
		}
	}
	return position[safest];
}

Pos betterplace(PUnit* myhero)
{
	vector<const PUnit*> enemycansee = nearby_enemyheros(myhero, myhero->view);
	vector<const PUnit*> friendscansee = nearby_myheros(myhero->pos, myhero->view);
	vector<const PUnit*> nearby_enemy = nearby_enemyheros(myhero, myhero->range);
	Pos position[POS_NUM];
	int best = 0;
	bool goodsituation = friendscansee.size() >= enemycansee.size();
	
	for(int i = 0; i < POS_NUM; ++i)
	{
		position[i] = Circle(myhero->pos, myhero->range).randPosInArea();
	}

	int leasthp, leastenemynum, nearestmybase;
		bool g = false;
	for(int i = 0; i < POS_NUM; ++i)
	{
		bool h = false;
		int enemynum = 0;
		int lesshp;
		int distomybase;
		for(int j = 0; j < nearby_enemy.size(); ++j)
		{
			if(dis2(position[i], nearby_enemy[j]->pos) < myhero->range)
			{
				++enemynum;
				if(h)
				{
					if(nearby_enemy[j]->hp < lesshp)
						lesshp = nearby_enemy[j]->hp;
				}
				else
				{
					h = true;
					lesshp = nearby_enemy[j]->hp;
				}
			}
		}

		if(enemynum == 0)
			continue;
		
		distomybase = dis2(MILITARY_BASE_POS[myhero->camp], position[i]);
		if(g)
		{
			if(lesshp > leasthp)
				continue;
			if(enemynum > leastenemynum)
				continue;
			if(goodsituation)
			{
				if(distomybase < nearestmybase)
					continue;
			}
			else
			{
				if(distomybase > nearestmybase)
					continue;
			}
			best = i;
			leastenemynum = enemynum;
			leasthp = lesshp;
			nearestmybase = distomybase;
		}
		else
		{
			g = true;
			best = i;
			leastenemynum = enemynum;
			leasthp = lesshp;
			nearestmybase = distomybase;
		}
	}
	return position[best];
}

void freetimetodo(PUnit* myhero, int num)
{
	console->selectUnit(myhero);
	console->move(MINE_POS[0]);
	
	if(hit_wild && !middle_mine)
	{
		if(num < 1)
			console->move(Dragon__pos[console->camp()]);
		else
			console->move(Roshan__pos[console->camp()]);
	}
	else if(hit_wild)
	{
		if(num >= 1)
			console->move(Dragon__pos[console->camp()]);
	}
	if(myhero->hp > myhero->max_hp * 3 / 4 && who_need_help(myhero) != NULL)
		console->move(who_need_help(myhero)->pos);
	if(base_attacked)
		console->callBackHero(myhero);

	if(strcmp(myhero->name, "Scouter") == 0 && num > 0 && disturbing)
	{
		if(dis2(myhero->pos, MILITARY_BASE_POS[console->camp()]) < dis2(myhero->pos, MILITARY_BASE_POS[1 - console->camp()]))
			console->move(scouter_pos[console->camp()]);
		else
		{
			if(dis2(myhero->pos, MILITARY_BASE_POS[1 - console->camp()]) < 144 || nearest_enemy(myhero->pos) != NULL)
			{
				disturb = true;
				enemy_exist = false;
				disturbround = 22;
			//	cout << 0;
			}
			if(disturb)
			{
			//	cout << 1;
				disturbround = disturbround - 1;
				if(disturbround <= 0)
				{
			//		cout << 3;
					disturb = false;
				}
				if((console->camp() == 0 && myhero->pos.y > 34) || (console->camp() == 1 && myhero->pos.y < 107))
					console->move(scouter_pos[console->camp()]);
				else
					console->move(home_pos[console->camp()]);
			}
			else	
			{
			//	cout << 2;
				console->move(MILITARY_BASE_POS[1 - console-> camp()]);
				if(dis2(myhero->pos, observer_pos[console->camp()]) <= 25)
					console->useSkill("SetObserver", observer_pos[console->camp()]);
			}
		}
	}


}

PUnit* who_need_help(PUnit* myhero)
{
	PUnit* who = NULL;
	if(strcmp(myhero->name, "Scouter") != 0)
		for(int i = 0; i < myHeroes.size(); ++i)
		{
			if(dis2(myhero->pos, myHeroes[i]->pos) < HELP_RANGE && myHeroes[i]->findBuff("BeAttacked") != NULL)
			{
				who = (PUnit*)myHeroes[i];
				break;
			}
		}
	return who;
}

void Hammerguards_action()
{
	for(int i = 0; i < Hammerguards.size(); ++i)
	{
		console->selectUnit(Hammerguards[i]);
		vector<const PUnit*> nearby_enemy = nearby_enemyheros((PUnit*)Hammerguards[i], HAMMERGUARD_VIEW);
		vector<const PUnit*> nearby_friends = nearby_myheros((PUnit*)Hammerguards[i], HAMMERGUARD_VIEW);
		if(nearby_enemy.size() > 0)
		{
			vector<const PUnit*> enemy_berserkers;
			vector<const PUnit*> enemy_masters;
			vector<const PUnit*> enemy_scouters;
			for(int j = 0; j < nearby_enemy.size(); ++j)
			{
				if(strcmp(nearby_enemy[j]->name, "Berserker") == 0)
				{
					enemy_berserkers.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Master") == 0)
				{
					enemy_masters.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Scouter") == 0)
				{
					enemy_scouters.push_back(nearby_enemy[j]);
				}
			}
			//对攻击的处理  优先级较小
			if(Hammerguards[i]->findSkill("Attack")->cd == 0)
			{
				PUnit* target = NULL;
				PUnit* subtarget = NULL;
				int leasthp, subleasthp;
				for(int j = 0; j < nearby_enemy.size(); ++j)
				{
					
						if(subtarget == NULL && nearby_enemy[j]->hp > 0)
						{
							subtarget = (PUnit*)nearby_enemy[j];
							subleasthp = nearby_enemy[j]->hp;
						}
						else
						{
							if(nearby_enemy[j]->hp < subleasthp && nearby_enemy[j]->hp > 0)
							{
								subtarget = (PUnit*)nearby_enemy[j];
								subleasthp = nearby_enemy[j]->hp;
							}
						}
					
					if(dis2(Hammerguards[i]->pos, nearby_enemy[j]->pos) < HAMMERGUARD_RANGE)
					{
						if(target == NULL && nearby_enemy[j]->hp > 0)
						{
							target = (PUnit*)nearby_enemy[j];
							leasthp = nearby_enemy[j]->hp;
						}
						else
						{
							if(nearby_enemy[j]->hp < leasthp && nearby_enemy[j]->hp > 0)
							{
								target = (PUnit*)nearby_enemy[j];
								leasthp = nearby_enemy[j]->hp;
							}
						}
					}
				}
				if(target != NULL)
				{
					console->attack(target);
					if(dis2(target->pos, Hammerguards[i]->pos) < HAMMERATTACK_RANGE)
						console->useSkill("HammerAttack", target);
				}
				else if(subtarget != NULL)
				{
					console->attack(subtarget);
					if(dis2(subtarget->pos, Hammerguards[i]->pos) < HAMMERATTACK_RANGE)
						console->useSkill("HammerAttack", subtarget);
				}
			}
			else
			{
				console->move(betterplace((PUnit*)Hammerguards[i]));
			}
			//对技能的处理  应该放在后面   优先级大
			if(enemy_berserkers.size() > 0)				
			{

				for(int j = 0; j < enemy_berserkers.size(); ++j)		
				{
					if(enemy_berserkers[j]->findBuff("WinOrDie") != NULL && enemy_berserkers[j]->hp > 0)
					{
						if(Hammerguards[i]->canUseSkill("HammerAttack") && dis2(Hammerguards[i]->pos, enemy_berserkers[j]->pos) < HAMMERATTACK_RANGE)
							console->useSkill("HammerAttack", enemy_berserkers[j]);
						else if(enemy_berserkers[j]->findBuff("Dizzy") != NULL)
						{
							console->move(MILITARY_BASE_POS[console->camp()]);
						}
					}
				}
			}
			else if(enemy_masters.size() > 0 && nearby_enemy.size() <= 2)
			{
				for(int j = 0; j < enemy_masters.size(); ++j)
				{
					if(dis2(enemy_masters[j]->pos, Hammerguards[i]->pos) < HAMMERATTACK_RANGE)
					{
						console->useSkill("HammerAttack", enemy_masters[j]);
					}
				}
			}
			else if(enemy_scouters.size() > 0 && nearby_enemy.size() < 2)
			{
				console->useSkill("HammerAttack", enemy_scouters[0]);
			}

			//对逃命的处理  优先级最大
			if(Hammerguards[i]->hp < Hammerguards[i]->max_hp / 3)
			{
				if(nearest_enemy(Hammerguards[i]->pos) != NULL)
				{
					if(dis2(Hammerguards[i]->pos, nearest_enemy(Hammerguards[i]->pos)->pos) < nearest_enemy(Hammerguards[i]->pos)->range)
					{
						if((nearby_enemy.size() >= 2) || (nearest_enemy(Hammerguards[i]->pos)->hp > Hammerguards[i]->hp))
							console->move(MILITARY_BASE_POS[console->camp()]);
					}
				}
			}
			if(Hammerguards[i]->hp < Hammerguards[i]->max_hp / 5)
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}
			if((nearby_enemy.size() > (nearby_friends.size() + 2) && Hammerguards[i]->hp < (Hammerguards[i]->max_hp / 2)) ||
				(nearby_enemy.size() > (nearby_friends.size() + 1) && Hammerguards[i]->hp < (Hammerguards[i]->max_hp * 2 / 3)))
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}

		}
		else
		{
			freetimetodo((PUnit*)Hammerguards[i], i);
			if(Hammerguards[i]->hp < Hammerguards[i]->max_hp / 5)
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}
			if(hit_wild && nearest_enemy(Hammerguards[i]->pos) == NULL)
			{
				if(nearest_wild(Hammerguards[i]->pos) != NULL)
				{
					PUnit* targetwild = nearest_wild(Hammerguards[i]->pos);
					console->attack(targetwild);
					if(targetwild->findBuff("Dizzy") == NULL && dis2(Hammerguards[i]->pos, targetwild->pos) <= HAMMERATTACK_RANGE)
						console->useSkill("HammerAttack", targetwild);
				}
			}
		}
	}
}

void Masters_action()
{
	for(int i = 0; i < Masters.size(); ++i)
	{
		console->selectUnit(Masters[i]);
		vector<const PUnit*> nearby_enemy = nearby_enemyheros((PUnit*)Masters[i], MASTER_VIEW);
		vector<const PUnit*> nearby_friends = nearby_myheros((PUnit*)Masters[i], MASTER_VIEW);
		if(nearby_enemy.size() > 0)
		{
			vector<const PUnit*> enemy_berserkers;
			vector<const PUnit*> enemy_hammerguards;
			for(int j = 0; j < nearby_enemy.size(); ++j)
			{
				if(strcmp(nearby_enemy[j]->name, "Hammerguard") == 0)
				{
					enemy_hammerguards.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Berserker") == 0)
				{
					enemy_berserkers.push_back(nearby_enemy[j]);
				}

			}
			//对攻击的处理
			PUnit* target = NULL;
			int leasthp;
			for(int j = 0; j < enemy_berserkers.size(); ++j)
			{
				if((enemy_berserkers[j]->findBuff("WinOrDie") != NULL && enemy_berserkers[j]->hp > 0) &&
					dis2(enemy_berserkers[j]->pos, Masters[i]->pos) < MASTER_RANGE)
				{
					if(target != NULL)
					{
						if(enemy_berserkers[j]->hp < leasthp)
						{
							target = (PUnit*)enemy_berserkers[j];
							leasthp = enemy_berserkers[j]->hp;
						}
					}
					else
					{
						target = (PUnit*)enemy_berserkers[j];
						leasthp = enemy_berserkers[j]->hp;
					}
				}
			}
			if(target == NULL)
			{
				for(int j = 0; j < nearby_enemy.size(); ++j)
				{
					if((nearby_enemy[j]->hp > 0 && dis2(nearby_enemy[j]->pos, Masters[i]->pos) < MASTER_RANGE) &&
						nearby_enemy[j]->findBuff("BeAttacked") != NULL)
					{
						if(target != NULL)
						{
							if(nearby_enemy[j]->hp < leasthp)
							{
								target = (PUnit*)nearby_enemy[j];
								leasthp = nearby_enemy[j]->hp;
							}
						}
						else
						{
							target = (PUnit*)nearby_enemy[j];
							leasthp = nearby_enemy[j]->hp;
						}
					}
				}
			}
			if(target == NULL)
			{
				target = nearest_enemy(Masters[i]->pos);
			}
			if(target != NULL)
				console->attack(target);
			//对逃命的处理
			if(Masters[i]->findBuff("BeAttacked") != NULL)
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
				console->useSkill("Blink", whereissafer((PUnit*)Masters[i], BLINK_RANGE));
			}
			if((nearby_enemy.size() > (nearby_friends.size() + 2) && Masters[i]->hp < (Masters[i]->max_hp * 2 / 3)) || 
				(nearby_enemy.size() > (nearby_friends.size() + 1) && Masters[i]->hp < (Masters[i]->max_hp / 2)) ||
				(Masters[i]->hp < (Masters[i]->max_hp / 3)))
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}
		}
		else
		{
			freetimetodo((PUnit*)Masters[i], i);
			if(Masters[i]->hp < (Masters[i]->max_hp / 3))
				console->move(MILITARY_BASE_POS[console->camp()]);
			if(hit_wild && nearest_enemy(Masters[i]->pos) == NULL)
			{
				if(nearest_wild(Masters[i]->pos) != NULL)
				{
					PUnit* targetwild = nearest_wild(Masters[i]->pos);
					console->attack(targetwild);
				}
			}
		}
	}
}

void Scouters_action()
{
	for(int i = 0; i < Scouters.size(); ++i)
	{
		console->selectUnit(Scouters[i]);
		vector<const PUnit*> nearby_enemy = nearby_enemyheros((PUnit*)Scouters[i], SCOUTER_VIEW);
		vector<const PUnit*> nearby_friends = nearby_myheros((PUnit*)Scouters[i], SCOUTER_VIEW);
		if(nearby_enemy.size() > 0 && (!disturbing || i < 1))
		{
			vector<const PUnit*> enemy_berserkers;
			vector<const PUnit*> enemy_hammerguards;
			for(int j = 0; j < nearby_enemy.size(); ++j)
			{
				if(strcmp(nearby_enemy[j]->name, "Hammerguard") == 0)
				{
					enemy_hammerguards.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Berserker") == 0)
				{
					enemy_berserkers.push_back(nearby_enemy[j]);
				}

			}
			//对攻击的处理
			PUnit* target = NULL;
			int leasthp;
			for(int j = 0; j < enemy_berserkers.size(); ++j)
			{
				if((enemy_berserkers[j]->findBuff("WinOrDie") != NULL && enemy_berserkers[j]->hp > 0) &&
					dis2(enemy_berserkers[j]->pos, Scouters[i]->pos) < SCOUTER_RANGE)
				{
					if(target != NULL)
					{
						if(enemy_berserkers[j]->hp < leasthp)
						{
							target = (PUnit*)enemy_berserkers[j];
							leasthp = enemy_berserkers[j]->hp;
						}
					}
					else
					{
						target = (PUnit*)enemy_berserkers[j];
						leasthp = enemy_berserkers[j]->hp;
					}
				}
			}
			if(target == NULL)
			{
				for(int j = 0; j < nearby_enemy.size(); ++j)
				{
					if((nearby_enemy[j]->hp > 0 && dis2(nearby_enemy[j]->pos, Scouters[i]->pos) < SCOUTER_RANGE) &&
						nearby_enemy[j]->findBuff("BeAttacked") != NULL)
					{
						if(target != NULL)
						{
							if(nearby_enemy[j]->hp < leasthp)
							{
								target = (PUnit*)nearby_enemy[j];
								leasthp = nearby_enemy[j]->hp;
							}
						}
						else
						{
							target = (PUnit*)nearby_enemy[j];
							leasthp = nearby_enemy[j]->hp;
						}
					}
				}
			}
			if(target == NULL)
			{
				target = nearest_enemy(Scouters[i]->pos);
			}
			if(target != NULL)
				console->attack(target);
			//对逃命的处理
			if((Scouters[i]->findBuff("BeAttacked") != NULL) && (Scouters[i]->hp < (Scouters[i]->max_hp * 2 / 3)))
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}
			if(((nearby_enemy.size() > (nearby_friends.size() + 1)) && Scouters[i]->hp < Scouters[i]->max_hp * 2 / 3) || 
				(Scouters[i]->hp < Scouters[i]->max_hp / 3))
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
				//console->useSkill("SetObserver", betterplace((PUnit*)Scouters[i]));
			}
		}
		else
		{
			freetimetodo((PUnit*)Scouters[i], i);
			if(Scouters[i]->hp < Scouters[i]->max_hp / 3 && (i < 1 || !disturbing))
				console->move(MILITARY_BASE_POS[console->camp()]);

			if(hit_wild && nearest_enemy(Scouters[i]->pos) == NULL)
			{
				if(nearest_wild(Scouters[i]->pos) != NULL)
				{
					PUnit* targetwild = nearest_wild(Scouters[i]->pos);
					console->attack(targetwild);
				}
			}
		}
	}
}

void Berserkers_action()
{
	for(int i = 0; i < Berserkers.size(); ++i)
	{
		console->selectUnit(Berserkers[i]);
		vector<const PUnit*> nearby_enemy = nearby_enemyheros((PUnit*)Berserkers[i], BERSERKER_VIEW);
		vector<const PUnit*> nearby_friends = nearby_myheros((PUnit*)Berserkers[i], BERSERKER_VIEW);
		if(nearby_enemy.size() > 0)
		{
			vector<const PUnit*> enemy_berserkers;
			vector<const PUnit*> enemy_masters;
			vector<const PUnit*> enemy_scouters;
			for(int j = 0; j < nearby_enemy.size(); ++j)
			{
				if(strcmp(nearby_enemy[j]->name, "Berserker") == 0)
				{
					enemy_berserkers.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Master") == 0)
				{
					enemy_masters.push_back(nearby_enemy[j]);
				}
				if(strcmp(nearby_enemy[j]->name, "Scouter") == 0)
				{
					enemy_scouters.push_back(nearby_enemy[j]);
				}
			}
			//对攻击的处理  优先级较小
			if(Berserkers[i]->findSkill("Attack")->cd == 0)
			{
				PUnit* target = NULL;
				PUnit* subtarget = NULL;
				int leasthp, subleasthp;
				for(int j = 0; j < nearby_enemy.size(); ++j)
				{
					
						if(subtarget == NULL && nearby_enemy[j]->hp > 0)
						{
							subtarget = (PUnit*)nearby_enemy[j];
							subleasthp = nearby_enemy[j]->hp;
						}
						else
						{
							if(nearby_enemy[j]->hp < subleasthp && nearby_enemy[j]->hp > 0)
							{
								subtarget = (PUnit*)nearby_enemy[j];
								subleasthp = nearby_enemy[j]->hp;
							}
						}
					
					if(dis2(Berserkers[i]->pos, nearby_enemy[j]->pos) < BERSERKER_RANGE)
					{
						if(target == NULL && nearby_enemy[j]->hp > 0)
						{
							target = (PUnit*)nearby_enemy[j];
							leasthp = nearby_enemy[j]->hp;
						}
						else
						{
							if(nearby_enemy[j]->hp < leasthp && nearby_enemy[j]->hp > 0)
							{
								target = (PUnit*)nearby_enemy[j];
								leasthp = nearby_enemy[j]->hp;
							}
						}
					}
				}
				if(target != NULL)
				{
					console->attack(target);
				}
				else if(subtarget != NULL)
				{
					console->attack(subtarget);
				}
			}
			else
			{
				console->move(betterplace((PUnit*)Berserkers[i]));
			}
			//对技能的处理
			if(nearby_enemy.size() <= (nearby_friends.size() + 1))
			{
				if(Berserkers[i]->findBuff("BeAttacked") == NULL)
				{
					console->attack(nearest_enemy(Berserkers[i]->pos));
					if((dis2(nearest_enemy(Berserkers[i]->pos)->pos, Berserkers[i]->pos) < Berserkers[i]->speed) && Berserkers[i]->hp > Berserkers[i]->max_hp * 2 / 3)
						console->useSkill("Sacrifice", NULL);
				}
			}

			//对开大的绝命剑客的处理  应该放在后面   优先级大
			if(enemy_berserkers.size() > 0 && Berserkers[i]->findBuff("WinOrDie") == NULL)				
			{

				for(int j = 0; j < enemy_berserkers.size(); ++j)		
				{
					if(enemy_berserkers[j]->findBuff("WinOrDie") != NULL && enemy_berserkers[j]->hp > 0)
					{
						if(dis2(Berserkers[i]->pos, enemy_berserkers[j]->pos) < BERSERKER_RANGE)
							console->attack(enemy_berserkers[j]);
						else
						{
							console->move(MILITARY_BASE_POS[console->camp()]);
						}
					}
				}
			}


			//对逃命的处理  优先级最大
			if((Berserkers[i]->hp < Berserkers[i]->max_hp / 3) && Berserkers[i]->findBuff("WinOrDie") == NULL)
			{
				if(nearest_enemy(Berserkers[i]->pos) != NULL)
				{
					
						console->move(MILITARY_BASE_POS[console->camp()]);

				}
			}
			if(nearby_enemy.size() > (nearby_friends.size() + 2) && (Berserkers[i]->findBuff("WinOrDie") == NULL))
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}

			if(Berserkers[i]->findBuff("WinOrDie") != NULL)
			{
				if(nearest_enemy(Berserkers[i]->pos) != NULL)
					console->attack(nearest_enemy(Berserkers[i]->pos));
			}
		}
		else
		{
			freetimetodo((PUnit*)Berserkers[i], i);
			if(Berserkers[i]->hp < Berserkers[i]->max_hp / 5)
			{
				console->move(MILITARY_BASE_POS[console->camp()]);
			}
			if(hit_wild && nearest_enemy(Berserkers[i]->pos) == NULL)
			{
				if(nearest_wild(Berserkers[i]->pos) != NULL)
				{
					PUnit* targetwild = nearest_wild(Berserkers[i]->pos);
					console->attack(targetwild);
					if(Berserkers[i]->hp > Berserkers[i]->max_hp * 2 / 3 && Berserkers[i]->findBuff("BeAttacked") == NULL)
						console->useSkill("Sacrifice", NULL);
				}
			}
		}
	}
}

void Sickheroes_action()
{
	for(int i = 0; i < mySickHeroes.size(); ++i)
	{
		console->selectUnit(mySickHeroes[i]);
		for(int j = 0; j < enemyHeroes.size(); ++j)
		{
            if(strcmp(mySickHeroes[i]->name, "Hammerguard") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < HAMMERATTACK_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->useSkill("HammerAttack", enemyHeroes[j]);
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
            else if(strcmp(mySickHeroes[i]->name, "Scouter") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < SCOUTER_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
            else if(strcmp(mySickHeroes[i]->name, "Master") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < MASTER_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
			else if(strcmp(mySickHeroes[i]->name, "Berserker") == 0)
            {
                if(dis2(mySickHeroes[i]->pos, enemyHeroes[j]->pos) < BERSERKER_RANGE 
				&& dis2(MILITARY_BASE_POS[console->camp()], mySickHeroes[i]->pos) < MILITARY_BASE_RANGE)
                {
                    console->attack(enemyHeroes[j]);
                    break;
                }
            }
		}
	}
}

void base_attack_action()
{
	//cout << 0;
	if(!attack1)
	{
		for(int i = 0; i < myHeroes.size(); ++i)
		{
			console->selectUnit(myHeroes[i]);
			console->move(base_attack_pos[console->camp()]);
		}
	}
	else if(attack1 && !attack2)
	{
		for(int i = 0; i < myHeroes.size(); ++i)
		{
			console->selectUnit(myHeroes[i]);
			console->move(base_attack_pos[console->camp() + 2]);
		}
	}
	else if(attack2)
	{
			for(int i = 0; i < myHeroes.size(); ++i)
			{
				console->selectUnit(myHeroes[i]);
				console->move(MILITARY_BASE_POS[1 - console->camp()]);
				if(enemyBase != NULL)
					console->attack(enemyBase);
			}	

			for(int i = 0; i < Berserkers.size(); ++i)
			{ 
				console->selectUnit(Berserkers[i]);
				if(enemyBase != NULL && Berserkers[i]->findBuff("BeAttacked") == NULL)
				{
					console->attack(enemyBase);
					if((dis2(enemyBase->pos, Berserkers[i]->pos) < Berserkers[i]->speed) && Berserkers[i]->hp > Berserkers[i]->max_hp * 1 / 3)
						console->useSkill("Sacrifice", NULL);
				}		
			}
	}
}
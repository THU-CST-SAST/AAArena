#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <queue>
using namespace std;

#ifdef MEKTPOY
FILE* F = fopen("mektpoy.log", "w");
#endif
namespace Mektpoy10
{
	static long long heroRank = 31203120LL;
	static int Dead = 0;

	PMap MAP;

	// =========================== 通用策略 ========================================

	static int strategyDisabled = - 1<<30; // 排除该策略参数

	// =========================== 攻击类策略 ======================================

	static int attackArg = 2200; // 攻击默认参数
	static int skillArg = 3000; // 技能默认参数

	static int supportRange = 2500; // 敏感范围
	static int outOfRangeArg = 800; // 超过范围参数
	static int hammerDizzy = 300; // 眩晕类BUFF参数
	static int like_scouter = 150; // 对scouter的优先级
	static int like_master = 175; // 对master的优先级
	static int like_hammerguard = 200; // 对hammer的优先级
	static int like_berserker = 125; // 对berserker的优先级
	static int like_roshan = -1500;
	static int like_dragon = -250;
	static int like_observer = -1200; // 对observer的优先级
	static int Defence_Base = 50000; // 守家参数
	static int attacked_berserker[100];
	static int attacked[100];

	// =========================== 移动类策略 ======================================

	static int miningArg = 500; // 挖矿默认参数
	static int centerMineArg = 300; // 中心矿区参数
	static int wildMineArg = 70; // 野矿参数
	static int Def_MINE = 4000; // 守矿参数
	static int addedMineArg = 15;
	static int sameMineArg = 30;

	static int callBackArg = 1000000; // 召回参数

	static int goBackHomeHp = 0; // 英雄危险血量
	static int goBackHomeArg = 400; // 回家默认参数
	static int levelupArg = 5000; // 回家升级参数

	static int dangerBaseHp = 800; // 基地危险血量
	static int dangerArg = 2200; // 基地危险回家参数

	static int attackBaseArg = 1200; // 拆家默认参数
	static int attackBaseMoney = 4000;

	static bool avoid_Mine[10][1210];
	static bool cancallback[152][152];

	// =========================== 统计值 ==========================================

	static int player; // 当前玩家编号
	static int property = 0; // 财产
	static int Gold = 0;
	static int def[100];
	static int enemyBaseHp = 3000;
	static int callbackcost = 0;
	static int like_mine[10];
	static int ROUND;
	static int Death = 0;
	static int goback = -1;

	static int lastT = 0;
	static int strategy = 0; // 1表示顺风策略 -1表示逆风策略

	static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};

	static Pos z0_0(42, 110), z0_1(107, 128), z0_2(135, 139); // 偷家三个坐标
	static Pos z1_0(110, 30), z1_1(48, 17), z1_2(15, 11); // 偷家三个坐标

	// =========================== 寻路 =============================================

	const int dx[8] = {0, 0, -1, 1, 1, 1, -1, -1};
	const int dy[8] = {1, -1, 0, 0, -1, 1, -1, 1};
	int vis[160][160];
	Pos pre[160][160];
	int MP[20][160][160];
	int Dis[160][160];
	int Dis2[160][160];
	int inq[160][160];

	// =========================== 装死开关 ==========================================
#ifdef MEKTPOY
	static int weak_switch = 0;
#else
	static int weak_switch = 0;
#endif
}

using namespace Mektpoy10;

bool isActiveSkill(PSkill* mySkill) //判断技能是否为主动技能
{
	return !strcmp(mySkill->name, "HammerAttack")
		|| !strcmp(mySkill->name, "Sacrifice")
		|| !strcmp(mySkill->name, "SetObserver");
}

class AIController //控制ai的主类
{
private:
    const PMap* map;
    const PPlayerInfo* info;
    PCommand* cmd;
	int Round;
public:
	AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
	~AIController();
public:
	Console* console;
	void levelupHero();
	void buyNewHero(Pos Target);
	void action();
public:
	PUnit *myBase, *enemyBase;
	std::vector<PUnit*> myHeros, enemyHeros;
};

PUnit *myBase, *enemyBase;
std::vector<PUnit*> myHeros, enemyHeros;

bool Danger1 (PUnit *worker, Console *console)
{
	return 0;
	int cnt = 0;
	if (player == 0 && worker->pos.x >= 120 && worker->pos.y >= 120) return 1;
	if (player == 1 && worker->pos.x <= 30 && worker->pos.y <= 30) return 1;
	for (auto kt : enemyHeros)
	{
		if (!strcmp (kt->name, "Observer")) continue;
		if (kt->findBuff("Reviving") == NULL && dis2 (kt->pos, worker->pos) <= 144)
		{
			if (kt->isWild()) cnt ++;
			cnt ++;
		}
	}
	for (auto kt : myHeros)
	{
		//if (kt->hp <= goBackHomeHp && kt->findBuff("WinOrDie") == NULL) continue;
		if (kt->findBuff("Reviving") == NULL && dis2 (kt->pos, worker->pos) <= 144) cnt --;
	}
	if (cnt >= 2 && console->round() > 100 && dis2(worker->pos, myBase->pos) >= 400) return 1;
	return 0;
}

class AIHero; //前向引用声明

class Strategy //策略基类
{
public:
	virtual int countWorth() = 0; //计算某种策略的实行价值
	virtual void work() = 0; //实现这种策略
	void move(PUnit* worker, PUnit* target);
	void move(PUnit* worker, Pos target);
	void callbackhome(PUnit* worker);
public:
	void setWorker(PUnit* worker) {this->worker = worker;}
	int getWorth() {return worth;}
	void setWorth(int worth) {this->worth = worth;}
	PUnit* getWorker() {return worker;}
	string getName() {return name;}
	void setAIHeroList(vector<AIHero*>& AIHeroList)
	{
		for(int i = 0; i < AIHeroList.size(); ++i)
			this->AIHeroList.push_back(AIHeroList[i]);
	}
	void setConsole(Console* console) {this->console = console;}
public:
	int worth;
	int TARGET;
protected:
	PUnit* worker;
	vector<AIHero*> AIHeroList;
	Console* console;
	string name;
};

class Attack:public Strategy //攻击某个单位的策略
{
public:
	Attack(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "Attack";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
};

class UseSkill:public Strategy //对某个单位释放技能的策略
{
public:
	UseSkill(PUnit* worker,PUnit* target) {setWorker(worker);setTarget(target);name = "UseSkill";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(PUnit* target) {this->target = target;}
private:
	PUnit* target;
	Pos targetPos;
};

class GoBackHome:public Strategy //英雄步行回家的策略
{
public:
	GoBackHome(PUnit* worker) {setWorker(worker);name = "GoBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class CallBackHome:public Strategy //召回英雄的策略
{
public:
	CallBackHome(PUnit* worker) {setWorker(worker);name = "CallBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class BuyBackHome:public Strategy
{
public:
	BuyBackHome(PUnit* worker) {setWorker(worker);name = "BuyBackHome";}
public:
	virtual int countWorth();
	virtual void work();
};

class AttackBase:public Strategy //偷家策略
{
public:
	AttackBase(PUnit* worker) {setWorker(worker); name = "AttackBase";}
public:
	virtual int countWorth();
	virtual void work();
private:
	PUnit* target;
};

class GoMining:public Strategy //采矿的策略
{
public:
	GoMining(PUnit* worker, Pos target) {setWorker(worker);setTarget(target);name = "GoMining";}
public:
	virtual int countWorth();
	virtual void work();
	void setTarget(Pos target) {this->target = target;}
	Pos getTarget() {return target;}
private:
	Pos target;
};

class AIHero //对应每个英雄的策略决策
{
public:
	AIHero(PUnit* newHero) {mHero = newHero; mStrategy = NULL;} //默认选择回家的策略
	~AIHero() {if(mStrategy != NULL) delete mStrategy;}
public:
	bool setStrategy(Strategy* newStrategy); //根据策略的价值判断是否选择新的策略
	void action(); //进行当前的最优策略
	Strategy* getStrategy() {return mStrategy;}
private:
	PUnit* mHero;
	Strategy* mStrategy;
};

int getheight (Pos worker)
{
	return MAP.getHeight(worker.x, worker.y);
}

bool checkpos (Pos k)
{
	if (k.x < 0 || k.y < 0 || k.x >= 150 || k.y >= 150) return 0;
	if (getheight(k) > 5) return 0;
	return 1;
}

int Abs (int x)
{
	return x < 0 ? -x : x;
}

void FindShortestPath(const PMap &map, Pos start, Pos dest, PUnit *worker, const std::vector<Pos> &blocks, std::vector<Pos> &path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回到离目标点最近的一个点的路径
{
	int SPEED;
	SPEED = worker->speed;
	if (!strcmp(worker->name, "Master") && worker->findSkill("Blink")->cd == 0 && worker->mp >= 80 && dis2(worker->pos, dest) > 12) SPEED = 81;
	PMap map0 = map;
	path.clear();
	if (start == dest) return;
	memset (vis, 0, sizeof(vis));
	for (int x = 0; x < 150; x ++)
		for (int y = 0; y < 150; y ++)
		{
			Dis2[x][y] = 1e9;
			pre[x][y] = Pos(-1, -1);
		}
	int Min = 2147483647;
	Pos nearest = start;
	Pos p, q;
	queue <Pos> Q;
	Q.push (dest); Dis2[dest.x][dest.y] = 0; vis[dest.x][dest.y] = 1;
	while (!Q.empty())
	{
		p = Q.front(); Q.pop(); 
		for (int i = 0; i < 4; i ++) 
		{
			q = p + Pos(dx[i], dy[i]);
			if (checkpos(q) && abs(map0[p.x][p.y] - map0[q.x][q.y]) <= 1)
			if (!vis[q.x][q.y]) 
			{
				Dis2[q.x][q.y] = Dis2[p.x][p.y] + 1;
				Q.push(q);
				vis[q.x][q.y] = 1;
			}
		}
	}
	memset (vis, 0, sizeof(vis));
	memset (Dis, 0, sizeof(Dis));
	for (int i = 0; i < blocks.size(); ++i)
	{
		vis[blocks[i].x][blocks[i].y] = 1;
	}
	vis[start.x][start.y] = 1;
	int dir_ord[4];
	int LOCK;
	if (SPEED == 12) LOCK = 4;
	if (SPEED == 25) LOCK = 7;
	if (SPEED == 36) LOCK = 8;
	if (SPEED == 81)
	{
		for (int i = 0; i < 20; i ++)
			path.push_back(Pos(0, 0));
		int MINP = 100000;
		Pos TARGET_;
		for (int x = 0; x < 150; x ++)
			for (int y = 0; y < 150; y ++)
				if (Dis2[x][y] <= MINP && dis2(Pos(x, y), worker->pos) <= 81 && !vis[x][y])
				{
					MINP = Dis2[x][y];
					TARGET_ = Pos(x, y);
				}
		path.push_back(TARGET_);
		return;
	}
	Q.push (start);
	while (!Q.empty()) 
	{
		p = Q.front(); Q.pop(); // fprintf (F, "(%d, %d)n", p.x, p.y);
		for (int i = 0; i < 4; i ++) dir_ord[i] = i;
		int Dx = Abs(start.x - dest.x);
		int Dy = Abs(start.y - dest.y);
		if (Dy < Dx)
		{
			reverse (dir_ord, dir_ord + 4);
			//fprintf (F, "sn");
		}
		else
		{
			//fprintf (F, "kn");
		}
		if (Dis[p.x][p.y] & 1)
			reverse (dir_ord, dir_ord + 4);
		for (int i = 0; i < 4; i ++) 
		{
			q = p + Pos(dx[dir_ord[i]], dy[dir_ord[i]]);
			if (checkpos(q) && abs(map0[p.x][p.y] - map0[q.x][q.y]) <= 1 && !vis[q.x][q.y]) 
			{
				int TT = Dis[p.x][p.y] + 1;
				if (MP[TT][q.x][q.y]) continue;
				Dis[q.x][q.y] = Dis[p.x][p.y] + 1;
				vis[q.x][q.y] = 1;
				pre[q.x][q.y] = p;
				// if (dis2(q, start) > SPEED) continue;
				if (Dis2[q.x][q.y] < Min)
				{
					Min = Dis2[q.x][q.y];
					nearest = q;
				}
				if (TT < LOCK) Q.push(q);
			}
		}
	}
	for (p = nearest; p != start; p = pre[p.x][p.y])
		path.push_back(p);
	path.push_back(p);
	reverse(path.begin(), path.end());
}

void Strategy::move (PUnit* worker, Pos target)
{
	int MIN_T = 1000000; Pos Target;
	vector <Pos> path;
	vector <Pos> block;
	block.push_back(Pos(myBase->pos.x, myBase->pos.y));
	for (int k = 0; k < 7; k ++)
	{
		for (int x = 1; x <= 150; x ++)
			for (int y = 1; y <= 150; y ++)
			{
				if (dis2(Pos(x, y), MINE_POS[k]) <= 2) block.push_back(Pos(x, y));
				else if ((k == 2 || k == 3) && dis2(Pos(x, y), MINE_POS[k]) <= 16) block.push_back(Pos(x, y));
			}
		if (target == MINE_POS[k])
		{
			if (player == 0) target = target + Pos(-2, -2);
			else target = target - Pos(2, 2);
		}
	}
	for (auto kt : console->friendlyUnits())
	{
		//MP[1][kt->pos.x][kt->pos.y] = 1;
		if (!strcmp(kt->name, "Observer")) block.push_back(kt->pos);
		if (console->round() >= 15) block.push_back(kt->pos);
	}
	for (auto kt : console->enemyUnits())
	{
		if (!strcmp(kt->name, "Observer")) block.push_back(kt->pos);
		if (console->round() >= 15) block.push_back(kt->pos);
	}
	FindShortestPath(MAP, worker->pos, target, worker, block, path);
	console->selectUnit(worker);
	if (path.size() > 10) 
	{
		Pos p;
		for (auto kt : path)
			p = kt;
		if (ROUND <= 1 && player == 1) p = Pos (121, 131);
		console->useSkill("Blink", p);
		for (int k = 0; k < 10; k ++) 
			MP[k][p.x][p.y] = 1;
		return;
	}
	console->move(path);
	int X = 0, Y = 0;
	#ifdef MEKTPOY
	fprintf (F, "%sn", worker->name);
	#endif
	for (int k = 0; k < path.size(); k ++)
	{
		MP[k][path[k].x][path[k].y] = 1;
		X = path[k].x, Y = path[k].y;
		#ifdef MEKTPOY
		fprintf (F, "(%d,%d)", path[k].x, path[k].y);
		#endif
	}
	for (int k = path.size(); k < 10; k ++)
		MP[k][X][Y] = 1;
	#ifdef MEKTPOY
	fprintf (F, "n");
	#endif
}

void Strategy::move (PUnit* worker, PUnit* target)
{
	move (worker, target->pos);
}

void Strategy::callbackhome (PUnit* worker)
{
	if (dis2(worker->pos, myBase->pos) <= 500) return;
	for (auto kt : myHeros)
		cancallback[kt->pos.x][kt->pos.y] = 1;
	for (auto kt : enemyHeros)
		cancallback[kt->pos.x][kt->pos.y] = 1;
	int MINP = 10000; Pos Target;
	for (int x = 0; x <= 150; x ++)
		for (int y = 0; y <= 150; y ++)
			if (dis2(Pos(x, y), myBase->pos) <= MINP && dis2(Pos(x, y), myBase->pos) > 1 && !cancallback[x][y])
			{
				MINP = dis2(Pos(x, y), myBase->pos);
				Target = Pos(x, y);
			}
	console->selectUnit(myBase);
	console->callBackHero(worker, Target);
	cancallback[Target.x][Target.y] = 1;
}

AIController::AIController(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map,info,cmd);
	Round = console->round();
    this->map = &(map);
    this->info = &(info);
    this->cmd = &(cmd);
	myHeros.clear();
	std::vector<PUnit*> myUnits = console->friendlyUnits();
	std::vector<PUnit*> enemyUnits = console->enemyUnits();
	enemyBase = NULL;
	for(int i = 0; i < myUnits.size(); ++i)
	{
		if(!strcmp(myUnits[i]->name,"Hammerguard") || !strcmp(myUnits[i]->name,"Master")
		|| !strcmp(myUnits[i]->name,"Berserker") || !strcmp(myUnits[i]->name,"Scouter"))
		{
			myHeros.push_back(myUnits[i]);
		}
		else if(!strcmp(myUnits[i]->name,"MilitaryBase"))
			myBase = myUnits[i];
	}
	for(int i = 0; i < enemyUnits.size(); ++i)
	{
		if(!strcmp(enemyUnits[i]->name,"Hammerguard") || !strcmp(enemyUnits[i]->name,"Master")
		|| !strcmp(enemyUnits[i]->name,"Berserker") || !strcmp(enemyUnits[i]->name,"Scouter")
		|| !strcmp(enemyUnits[i]->name,"Dragon") || !strcmp(enemyUnits[i]->name,"Roshan")
		|| !strcmp(enemyUnits[i]->name,"Observer"))
			enemyHeros.push_back(enemyUnits[i]);
		else if(!strcmp(enemyUnits[i]->name,"MilitaryBase"))
			enemyBase = enemyUnits[i];
	}
}

AIController::~AIController()
{
	delete console;
}

void AIController::levelupHero()
{
	console->selectUnit(myBase);
	UnitFilter filter;
	filter.setAreaFilter (new Circle (myBase->pos, LEVELUP_RANGE), "a");
	vector<PUnit*> heroToLevelUp = console->friendlyUnits (filter);
	for(auto kt : heroToLevelUp)
	{
		if (strategy == -1 && (!strcmp(kt->name, "Scouter") || !strcmp(kt->name, "Master"))) continue;
		if (myHeros.size() < 8 /*&& strcmp(heroToLevelUp[i]->name, "Hammerguard")*/) continue;
		int LEVEL = kt->level;
		for (int k = 0; k < 5; k ++)
		{
			if (Gold - console->goldCostCurrentRound() - console->levelUpCost(LEVEL) >= callbackcost) 
			{
				LEVEL ++;
				console->buyHeroLevel(kt);
			}
		}
	}
}

void AIController::buyNewHero(Pos Target)
{
	console->selectUnit(myBase);
	int newHero = heroRank % 10;
	if (myHeros.size() == 4) newHero = 0;
	if (myHeros.size() == 5) 
	{
		if (strategy != -1) newHero = 3; else newHero = 2;
	}
	if (myHeros.size() == 6) newHero = 0;
	if (myHeros.size() == 7) 
	{
		if (strategy != -1) newHero = 2; else newHero = 3;
	}
	if (myHeros.size() == 8) return;
	if (console->round() == 0) console->chooseHero(HERO_NAME[newHero], Target);
	if (console->round() > 1 && Gold - console->goldCostCurrentRound() >= 500) console->chooseHero(HERO_NAME[newHero], Target);
	heroRank /= 10;
}

void AIController::action()
{
	vector<AIHero*> AIHeroList;
	if (ROUND >= 15)
	{
		random_shuffle (myHeros.begin(), myHeros.end());
		int n = myHeros.size() - 1;
		for(int i = 0; i < myHeros.size(); i ++)
		{
			if (i >= n) break;
			while (!strcmp(myHeros[n]->name, "Berserker")) n--;
			if (!strcmp(myHeros[i]->name, "Berserker")) swap(myHeros[i], myHeros[n]);
		}
		int j = 0;
		for(int i = n; i >= 0; i --)
		{
			if (i <= j) break;
			while (!strcmp(myHeros[j]->name, "Scouter")) j ++;
			if (!strcmp(myHeros[i]->name, "Scouter")) swap(myHeros[i], myHeros[j]);
		}
		for(int i = myHeros.size() - 1; i >= 0; i --)
		{
			if (i <= j) break;
			while (!strcmp(myHeros[j]->name, "Berserker") && myHeros[j]->findBuff("WinOrDie") != NULL) j ++;
			if (!strcmp(myHeros[i]->name, "Berserker") && myHeros[i]->findBuff("WinOrDie") != NULL) swap (myHeros[i], myHeros[j]);
		}
	}
	else
	{
		random_shuffle (myHeros.begin(), myHeros.end());
		int n = myHeros.size() - 1;
		for(int i = 0; i < myHeros.size(); i ++)
		{
			if (i >= n) break;
			while (!strcmp(myHeros[n]->name, "Scouter")) n--;
			if (!strcmp(myHeros[i]->name, "Scouter")) swap(myHeros[i], myHeros[n]);
		}
		int j = 0;
		for(int i = n; i >= 0; i --)
		{
			if (i <= j) break;
			while (!strcmp(myHeros[j]->name, "Berserker")) j ++;
			if (!strcmp(myHeros[i]->name, "Berserker")) swap(myHeros[i], myHeros[j]);
		}
	}
	for(int i = 0; i < myHeros.size(); ++i) AIHeroList.push_back(new AIHero(myHeros[i]));
	for(int i = 0; i < myHeros.size(); ++i)
	{
		vector<Strategy*> allStrategy;
		for(int j = 0; j < enemyHeros.size(); ++j)
		{
			allStrategy.push_back(new Attack(myHeros[i], enemyHeros[j]));
			allStrategy.push_back(new UseSkill(myHeros[i], enemyHeros[j]));
		}
		allStrategy.push_back(new UseSkill(myHeros[i], NULL));
		for(int j = 0; j < MINE_NUM; ++j)
			allStrategy.push_back(new GoMining(myHeros[i], MINE_POS[j]));
		allStrategy.push_back(new AttackBase(myHeros[i]));
		if (enemyBase != NULL)
		{
			allStrategy.push_back(new Attack(myHeros[i], enemyBase));
			allStrategy.push_back(new UseSkill(myHeros[i], enemyBase));
		}
		// allStrategy.push_back(new AttackBase (myHeros[i], enemyBase));
		allStrategy.push_back(new GoBackHome(myHeros[i]));
		allStrategy.push_back(new CallBackHome(myHeros[i]));
		allStrategy.push_back(new BuyBackHome(myHeros[i]));
		for(int j = 0; j < allStrategy.size(); ++j)
		{
			allStrategy[j]->setAIHeroList(AIHeroList);
			allStrategy[j]->setConsole(console);
			AIHeroList[i]->setStrategy(allStrategy[j]);
		}
		AIHeroList[i]->action();
	}
	for(int i = 0; i < AIHeroList.size(); ++i)
		if(AIHeroList[i] != NULL)
			delete AIHeroList[i];
}

bool AIHero::setStrategy(Strategy* newStrategy)
{
	if(newStrategy == NULL) return false;
	if(newStrategy->getWorker() != this->mHero) return false;
	if(mStrategy == NULL || newStrategy->countWorth() > this->mStrategy->countWorth())
	{
		if(mStrategy != NULL)
			delete mStrategy;
		mStrategy = newStrategy;
		return true;
	}
	else
		delete newStrategy;
	return false;
}

void AIHero::action()
{
	mStrategy->work();
}

int Attack::countWorth()
{ 
	if (target->isWild() && !strcmp(worker->name, "Scouter") && strategy == 1) return this->worth = strategyDisabled;
	// if (avoid_Mine[0][console->round()] == 0 && console->round() <= 100 && target->isWild())
	//	return this->worth = strategyDisabled;
	// 打不过就跑
	if (player == 0 && target->pos.x >= 130 && target->pos.y >= 130) return this->worth = strategyDisabled;
	if (player == 1 && target->pos.x <= 20 && target->pos.y <= 20) return this->worth = strategyDisabled;
	if(target->findBuff("Reviving") != NULL || target->hp <= 0)
		return this->worth = strategyDisabled;
	if(worker->findBuff("Reviving") != NULL || worker->findBuff("Dizzy") != 0)
		return this->worth = strategyDisabled;
	// 在探测范围内
	this->worth = 0;
	if(dis2(worker->pos,target->pos) <= supportRange)
	{
		this->worth = attackArg;
		// 如果没开牺牲 则残血优先
		// 如果对方不在攻击范围内
		if (worker->findBuff("WinOrDie") != NULL && !strcmp(target->name, "Observer")) return this->worth = strategyDisabled;
		if(dis2(worker->pos, target->pos) > worker->range)
		{
			// 强策略 如果敌方均在我方射程之外 不打
			int can_gank = 0;
			for (auto kt : myHeros)
			{
				if (kt->findBuff("Dizzy") != NULL || kt->findBuff("Reviving") != NULL) continue;
				if (strcmp(kt->name, "Scouter") && dis2(kt->pos, target->pos) <= kt->speed) can_gank = 1;
			}
			if (worker->speed > target->speed && strcmp(target->name, "Observer") && can_gank)
			{
				outOfRangeArg = 400;
			}
			else
			{
				outOfRangeArg = 800;
			}
			this->worth -= 700;
			int enemy_num = 0;
			for (auto kt : enemyHeros)
				if (dis2(target->pos, kt->pos) <= 144)
					enemy_num ++;
			if (enemy_num == 1) this->worth -= 400;
			int FLAG = 0;
			for (auto k : myHeros)
				if (k->findBuff("Dizzy") == NULL && k->findBuff("Reviving") == NULL && k->findSkill("Attack")->cd == 0 && dis2(k->pos, target->pos) <= k->range)
				{
					FLAG = 1;
				}
			if (target->findBuff("Dizzy") != NULL) FLAG = 1;
			if (strategy == 1 && target->isWild() && dis2(worker->pos, target->pos) > 144) return this->worth -= outOfRangeArg;
			if (!FLAG)
			{
				int cnt = 0;
				for (auto kt : enemyHeros)
				if (dis2 (kt->pos, target->pos) <= 144)
				{
					if (!strcmp(kt->name, "Observer")) continue;
					if (!strcmp(kt->name, "Dragon") && !kt->findBuff("Reviving")) cnt --;
					if (kt->findBuff("Reviving") != NULL) continue;
					cnt ++;
				}
				if (property <= 1250) this->worth -= outOfRangeArg;
				else if (target->isWild()) this->worth -= outOfRangeArg;
				else if (myHeros.size() - cnt <= 2) this->worth -= outOfRangeArg;
				else
				{
					int MIND = 10000;
					for (int k = 0; k < 7; k ++)
						MIND = min (MIND, dis2(target->pos, MINE_POS[k]));
					if (MIND > 900) this->worth -= outOfRangeArg;
				}
				if (worker->findBuff("WinOrDie") != NULL)
				{
					int flag = 0;
					for (auto kt : enemyHeros)
						if (kt->findBuff("Reviving") == NULL && kt->findBuff("Dizzy") == NULL && dis2(worker->pos, kt->pos) <= worker->range)
							flag = 1;
					if (flag) this->worth -= outOfRangeArg;
				} // 如果发动了牺牲 超过范围尽量不打
				if (!strcmp (target->name, "Scouter") && target->findBuff("Dizzy") == NULL) this->worth -= outOfRangeArg / 2.0; // 跑的快尽量不追
			}
		}
		int can_attack = 0;
		for (auto kt : myHeros)
			if (dis2(kt->pos, target->pos) <= kt->range)
				can_attack = 1;
		if(dis2(worker->pos, target->pos) <= worker->range || can_attack)
		{
			if (!strcmp(target->name, "Berserker") && target->findSkill("Sacrifice")->cd == 0 && target->findBuff("Dizzy") == NULL) this->worth -= outOfRangeArg;
			if (attacked[target->id] && strcmp(worker->name, "Berserker")) this->worth += 400;
			if (strcmp(target->name, "Berserker")) this->worth += (double)500 * (1.0 - (double)target->hp / (double)target->max_hp);
			//else if (target->findSkill("Sacrifice")->cd == 0 && target->hp >= 150) 
			//	this->worth += ((double)target->hp / (double) target->max_hp) * (double)500;
			// 对各种生物的优先级
			if(!strcmp(target->name, "Scouter")) this->worth += like_scouter;
			if(!strcmp(target->name, "Master")) this->worth += like_master;
			if(!strcmp(target->name, "Hammerguard")) this->worth += like_hammerguard;
			if(target->findSkill("Sacrifice") != NULL && (target->findSkill("Sacrifice")->cd == 0 && target->hp >= 150) || target->atk > 150) 
			{ 
				if (!attacked_berserker[target->id] && dis2(worker->pos, target->pos) <= worker->range) this->worth += like_berserker * 6;
				this->worth += like_berserker;
			}
			if(!strcmp(target->name, "Dragon")) this->worth += like_dragon;
			if(!strcmp(target->name, "Roshan")) this->worth += like_roshan;
			if(!strcmp(target->name, "Observer")) this->worth += like_observer;
		}
		// 如果对方正在拆家
		if(dis2(target->pos, myBase->pos) <= 1600 && dis2(worker->pos, myBase->pos) <= 144)
		{
			// if (target->findSkill("Sacrifice") != NULL && target->findSkill("Sacrifice")->cd == 0 && target->hp >= 150) this->worth += like_berserker;
			this->worth += Defence_Base;
		}
	}
	return this->worth;
}

bool berserker_attack (PUnit *worker, PUnit *target)
{
	int flag = 0;
	return 0;
	if (worker->findBuff("WinOrDie") != NULL) return 0;
	if (strcmp (worker->name, "Berserker")) return 0;
	if (worker->findSkill("Sacrifice")->cd > 0) return 0;
	for (auto kt : enemyHeros)
		if (!strcmp(kt->name, "Berserker") && kt->findSkill("Sacrifice")->cd == 0 && !attacked_berserker[kt->id])
		{
			flag = 1;
		}
	return 1; // 以前是return 0;
	if (flag == 0) return 0;
	if (strcmp(target->name, "Berserker")) return 1;
}

void Attack::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d Attackn", console->round(), worker->id, this->worth);
	#endif
	console->selectUnit(worker);
	if (dis2(worker->pos, target->pos) <= worker->range && worker->findSkill("Attack")->cd == 0)
	{
		if (console->round() <= 25 && berserker_attack(worker, target)) return;
		target->hp -= max (5, worker->atk - target->def);
		console->attack(target);
		if (!target->isWild()) lastT = ROUND;
		if (!strcmp(target->name, "Berserker")) attacked_berserker[target->id] = 1;
		attacked[target->id] = 1;
		if (target->hp <= 0)
		{
			if (target->findSkill("SuperDead") != NULL && target->findSkill("SuperDead")->cd == 0) return;
			if (!target->isWild()) Death --;
		}
	}
	else move(worker, target);
}

int UseSkill::countWorth()
{
	this->worth = skillArg;
	if (target == NULL && strcmp("Scouter", worker->name)) return this->worth = strategyDisabled;
	if (target == NULL)
	{
		if (strategy) return this->worth = strategyDisabled;
		if (worker->findSkill("SetObserver")->cd > 0) return this->worth = strategyDisabled;
		if (console->round() <= 80) return this->worth = strategyDisabled;
		if (console->round() - lastT <= 20) return this->worth = strategyDisabled;
		int FLAG = 0;
		for (auto kt : enemyHeros)
		{
			if (kt->isWild()) continue;
			if (!strcmp(kt->name, "Observer")) continue;
			FLAG = 1;
		}
		if (FLAG) return this->worth = strategyDisabled;
		Pos pos1 = Pos(52, 63), pos2 = Pos(96, 83), pos3;
		if (player == 0) pos3 = pos1, pos1 = pos2, pos2 = pos3;
		if (worker->id <= 25) this->targetPos = pos1;
		else this->targetPos = pos2;
		return this->worth;
	}
	if(target->findBuff("Reviving") != NULL || target->hp <= 0)
		return this->worth = strategyDisabled;
	if(worker->findBuff("Reviving") != NULL || worker->findBuff("Dizzy") != 0)
		return this->worth = strategyDisabled;
	// 打不过就跑
	/*
	if (avoid_Mine[0][console->round()] == 0 && console->round() <= 100 && target->isWild())
		return this->worth = strategyDisabled;
	*/
	if (player == 0 && target->pos.x >= 120 && target->pos.y >= 120) return this->worth = strategyDisabled;
	if (player == 1 && target->pos.x <= 30 && target->pos.y <= 30) return this->worth = strategyDisabled;
	//if (Danger1(worker, console)) return this->worth = strategyDisabled;
	//if (Danger2(target, console)) return this->worth = strategyDisabled;
	// 死了还放啥子技能
	if(!strcmp(worker->name, "Scouter") || !strcmp (worker->name, "Master"))
		return this->worth = strategyDisabled;
	this->worth = skillArg;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
	// 是主动技能
		if(isActiveSkill(skillList[i]))
		{
			// this->worth += skillArg / 2.0 * (1.0 - (double)target->hp / (double)target->max_hp);
			// 在CD中还放啥子技能
			if (skillList[i]->cd > 0)
				return this->worth = strategyDisabled;
			if(!strcmp(target->name, "Scouter")) this->worth += like_scouter + 100;
			if(!strcmp(target->name, "Master")) this->worth += like_master;
			if(!strcmp(target->name, "Hammerguard")) this->worth += like_hammerguard + 100;
			if(target->findSkill("Sacrifice") != NULL && target->findSkill("Sacrifice")->cd == 0 && target->hp >= 150)
			{ 
				if (!attacked_berserker[target->id]) this->worth += 1000;
				this->worth += like_berserker;
			}
			if(!strcmp(target->name, "Roshan")) this->worth += like_roshan;
			if(!strcmp(target->name, "Dragon")) this->worth += like_dragon;
			if(!strcmp(target->name, "Observer")) return this->worth = strategyDisabled;
			if(!worker->canUseSkill(skillList[i]))
				return this->worth = strategyDisabled;
			// 锤子
			if(!strcmp(skillList[i]->name, "HammerAttack"))
			{
				/*
				if(target->isWild())
				{
					if (worker->mp != 200) return this->worth = strategyDisabled;
				}
				*/
				// 丢失目标
				if(dis2(worker->pos,target->pos) > HAMMERATTACK_RANGE)
					return this->worth = strategyDisabled;
				if(target->findBuff("Dizzy") != NULL) // 如果对方已被眩晕 则不锤
					return this->worth = strategyDisabled;
				if(console->round() <= 23 && strcmp(target->name, "Berserker")) return this->worth = strategyDisabled;
				if(worker->hp <= goBackHomeArg) this->worth += skillArg * 10; // 如果自己残血 该锤就锤吧
				if(worker->mp == 200) this->worth += hammerDizzy; // 如果蓝是满的 锤了也不浪费
				if(worker->findSkill("Attack")->cd > 0) this->worth += skillArg; // 如果现在还不能普通攻击 为什么不锤呢
				// if(target->findBuff("WaitRevive") != NULL && target->hp <= 100) this->worth += skillArg; // 如果对方在涅槃 为什么不锤呢
			}
			// 牺牲
			if(!strcmp(skillList[i]->name, "Sacrifice"))
			{
				// 计算涅槃参数 没涅槃绝对不放牺牲
				auto t = worker->findSkill("SuperDead");
				if (t != NULL && t->cd > 0)
				{
					this->worth -= skillArg;
				}
				int FLAG = 1;
				for (auto kt : enemyHeros)
				{
					if (!strcmp(kt->name, "Observer")) continue;
					if (kt->findBuff("Reviving") != NULL) continue; // 没有眩晕和死亡BUFF
					if (kt->findBuff("Dizzy") != NULL && kt->findBuff("Dizzy")->timeLeft < 10) continue;
					if (kt->findSkill("Attack")->cd == 0) // 如果可以普通攻击
					{
						if (dis2(worker->pos, kt->pos) <= kt->range)
							FLAG = 0;
					}
					if ((ROUND <= 16 || ROUND >= 22) && kt->findSkill("HammerAttack") != NULL && kt->findSkill("HammerAttack")->cd == 0)
					{
						if (dis2(worker->pos, kt->pos) <= HAMMERATTACK_RANGE)
							FLAG = 0;
					}
				}
				if (worker->findSkill("Attack")->cd > 1) // 如果自己不能普通攻击
				{
					FLAG = 0;
				}
				// 新加策略 稳定性待测
				for (auto kt : enemyHeros)
					if (kt->atk > 100 && dis2(kt->pos, worker->pos) <= kt->range && worker->findSkill("SuperDead")->cd == 0)
					{
						return this->worth = skillArg;
					}
				if (!FLAG) return this->worth = strategyDisabled;

				// 太远不放牺牲
				if(dis(worker->pos, target->pos) > sqrt(worker->range) + (ROUND <= 20 ? 5 : 0))
				{
					for (auto kt : enemyHeros)
					{
						if (!strcmp(kt->name, "Observer")) continue;
						if (kt->range <= worker->range) continue;
						if (kt->findBuff("Reviving")) continue;
						if (kt->findBuff("Dizzy")) continue;
						if (dis2(worker->pos, kt->pos) <= 40) return this->worth = strategyDisabled;
					}
					if (dis2(worker->pos, target->pos) > 40) return this->worth = strategyDisabled;
					if (ROUND > 30) return this->worth = strategyDisabled;
				}
				else
				{
					//this->worth += (1.0 - (double)target->hp/(double)target->max_hp) * (double)skillArg;
				}
			}
		}
	if(dis2(target->pos, myBase->pos) <= 1600 && dis2(worker->pos, myBase->pos) <= 144)
	{
		if (target->findSkill("Sacrifice") != NULL && target->findSkill("Sacrifice")->cd == 0 && target->hp >= 150) this->worth += like_berserker;
		this->worth += Defence_Base;
	}
	return this->worth;
}

void UseSkill::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d UseSkilln", console->round(), worker->id, this->worth);
	#endif
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); ++i)
		if(isActiveSkill(skillList[i]))
		{
			if(!strcmp(skillList[i]->name, "HammerAttack"))
			{
				console->useSkill(skillList[i], target);
				if (!strcmp(target->name, "Berserker")) attacked_berserker[target->id] = 1;
				attacked[target->id] = 1;
				target->hp -= HAMMERATTACK_DAMAGE[worker->level];
				target->buffs.push_back(PBuff (0, 3, 10));
				if (target->hp <= 0)
				{
					if (target->findSkill("SuperDead") != NULL && target->findSkill("SuperDead")->cd == 0) return;
					if (!target->isWild()) Death--;
				}
			}
			else if(!strcmp(skillList[i]->name, "Sacrifice"))
			{
				console->useSkill(skillList[i], NULL);
			}
			else if(!strcmp(skillList[i]->name, "SetObserver"))
			{
				if (dis2(targetPos, worker->pos) <= 25)
				{
					Pos Target = worker->pos;
					while (1)
					{
						int FLAG = 0;
						for (auto kt : console->friendlyUnits())
							if (kt->pos == Target) FLAG = 1;
						for (auto kt : console->enemyUnits())
							if (kt->pos == Target) FLAG = 1;
						if (dis2(Target, worker->pos) > worker->findSkill("SetObserver")->range()) FLAG = 1;
						if (FLAG == 1)
						{
							Target = worker->pos + Pos (rand() % 5 - 2, rand() % 5 - 2);
							continue;
						}
						console->useSkill("SetObserver", Target);
						break;
					}
				}
				else move (worker, targetPos);
			}
			break;
		}
}

int AttackBase::countWorth()
{
	//if (!strcmp(worker->name, "Berserker") || !strcmp(worker->name, "Hammerguard")) return this->worth = strategyDisabled;
	//if (strategy != -1) return this->worth = strategyDisabled;
	//if (ROUND <= 500) return this->worth = strategyDisabled;
	return this->worth = 3000;
}

void AttackBase::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d AttackBasen", console->round(), worker->id, this->worth);
	#endif
	console->selectUnit(worker);
	int HP = worker->hp;
	for (auto kt : enemyHeros)
	{
		if (!strcmp(kt->name, "Observer")) continue;
		if (kt->findSkill("HammerAttack") != NULL && kt->findSkill("HammerAttack")->cd == 0 && dis2(kt->pos, worker->pos) <= HAMMERATTACK_RANGE)
			HP -= HAMMERATTACK_DAMAGE[kt->level];
		else if (kt->findSkill("Attack")->cd == 0 && dis2(kt->pos, worker->pos) <= kt->range)
			HP -= max (5, kt->atk - worker->def);
	}
	if (enemyBase != NULL && dis2(enemyBase->pos, worker->pos) <= 144) HP -= max (5, enemyBase->atk - worker->def);
	if (HP <= 0) { callbackhome(worker); return; }
	if (player == 0)
	{
		if (dis2 (myBase->pos, worker->pos) <= 8000) move(worker, z0_0);
		else
		{
			move(worker, z0_2);
			if (enemyBase != NULL && dis2(worker->pos, enemyBase->pos) <= 36) console->attack(enemyBase);
		}
	}
	else
	{
		if (dis2 (myBase->pos, worker->pos) <= 8000) move(worker, z1_0);
		else
		{
			move(worker, z1_2);
			if (enemyBase != NULL && dis2(worker->pos, enemyBase->pos) <= 36) console->attack(enemyBase);
		}
	}
}

int GoMining::countWorth()
{
	this->worth = 0;
	int k;
	// 计算金矿编号
	for (int i = 0; i < 7; i ++)
		if (target == MINE_POS[i]) k = i;
	if (strategy == -1 && k == 0) return this->worth = strategyDisabled;
	if (strategy == -1 && avoid_Mine[k][ROUND]) return this->worth = strategyDisabled;
	// 默认采矿参数
	bool defence_Mine[10];
	memset (defence_Mine, 0, sizeof(defence_Mine));
	for (auto k : myHeros)
		if (def[k->id] != -1) defence_Mine[def[k->id]] = 1;
	this->worth = miningArg;
	if (player == 0)
	{
		if (k == 0) this->worth += centerMineArg;
		if (k == 1) 
		{
			this->worth += wildMineArg;
			if (strategy == 1)
			{
				if (worker->id <= 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg; 
			}
		}
		if (k == 4) 
		{
			this->worth += wildMineArg - addedMineArg;
			if (strategy == 1)
			{
				if (worker->id > 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg; 
			}
		}
		if (k == 5) this->worth += wildMineArg - 10;
		if (k == 6) this->worth += wildMineArg - 1;
		if (strategy == -1)
		{
			if (k == 5 && (worker->id > 25 || !strcmp(worker->name, "Scouter"))) this->worth += centerMineArg;
			if (k == 6 && worker->id <= 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg;
		}
	}
	if (player == 1)
	{
		if (k == 0) this->worth += centerMineArg;
		if (k == 1) 
		{
			this->worth += wildMineArg - addedMineArg;
			if (strategy == 1)
			{
				if (worker->id > 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg; 
			}
		}
		if (k == 4) 
		{
			this->worth += wildMineArg;
			if (strategy == 1)
			{
				if (worker->id <= 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg; 
			}
		}
		if (k == 5) this->worth += wildMineArg - 1;
		if (k == 6) this->worth += wildMineArg - 10;
		if (strategy == -1)
		{
			if (k == 5 && worker->id <= 25 && strcmp(worker->name, "Scouter")) this->worth += centerMineArg;
			if (k == 6 && (worker->id > 25 || !strcmp(worker->name, "Scouter"))) this->worth += centerMineArg;
		}
	}
	if (worker->id <= 25 && !strcmp(worker->name, "Scouter") && k == 0 && strategy != -1 && property >= 2000)
	{
		int can = 1;
		for (auto kt : enemyHeros)
			if (dis2(kt->pos, worker->pos) <= 144)
				can = 0;
		if (can) this->worth += 2000;
	}
	return this->worth;
}


void GoMining::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d GoMinningn", console->round(), worker->id, this->worth);
	#endif
	int k;
	// 计算金矿编号
	for (int i = 0; i < 7; i ++)
		if (target == MINE_POS[i]) k = i;
	this->TARGET = k;
	if (k == 0)
	{
		if (player == 0)
		{
			if (!strcmp(worker->name, "Scouter")) move (worker, Pos(72, 73));
			else move(worker, Pos(72, 72));
		}
		else 
		{
			if (!strcmp(worker->name, "Scouter")) move (worker, Pos(76, 77));
			else move(worker, Pos(76, 75));
		}
	}
	else move(worker, target);
}

int GoBackHome::countWorth()
{
	this->worth = 0;
	// 打不过就跑
	//if (Danger1(worker, console)) return this->worth = goBackHomeArg * 20;
	// 如果已经在家了 则使用默认参数 （低于攻击策略的参数）
	if(dis2 (myBase->pos, worker->pos) <= 500)
	{
		if (myBase->hp <= dangerBaseHp) return this->worth = goBackHomeArg * 2;
		return this->worth = goBackHomeArg;
	}
	// 如果该英雄残血 并且不是因为在牺牲 则计算参数 （高于攻击策略的参数）
	if (!strcmp(worker->name, "Master"))
	{
		goBackHomeHp = 0;
		for (auto kt : enemyHeros)
		{
			if (!strcmp(kt->name, "Observer")) continue;
			if (kt->findSkill("Attack")->cd > 0) continue;
			if (dis2(kt->pos, worker->pos) > kt->range) continue;
			goBackHomeHp += max(5, kt->atk - worker->def);
		}
	}
	else
		goBackHomeHp = -10000;
	if(worker->hp > goBackHomeHp && worker->hp <= goBackHomeHp + 50 && worker->findBuff("WinOrDie") == NULL)
	{
		int flag = 0;
		for (auto kt : enemyHeros)
		{
			if (!strcmp (kt->name, "Observer")) continue;
			if (dis2(kt->pos, worker->pos) <= 144 && worker->findBuff("Dizzy") == NULL && worker->findBuff("Reviving") == NULL)
				flag = 1;
		}
		if (flag) this->worth += goBackHomeArg * 20;
	}
	// 如果家的血量非常危险
	return this->worth;
}

void GoBackHome::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d GoBackHomen", console->round(), worker->id, this->worth);
	#endif
	// 撤离策略
	if (player == 0) move(worker, Pos(18, 20));
	else move (worker, Pos(127, 132));
}

int CallBackHome::countWorth()
{
	if(console->gold() >= 3000 && worker->level < 5 && console->round() % 20 == 0 && dis2(worker->pos, myBase->pos) >= 500)
	{
		int ID = 50;
		for (auto k : myHeros)
			if (!strcmp(k->name, "Hammerguard") && k->level < 5 && k->id < ID)
			{
				if (strategy == -1 && (!strcmp(worker->name, "Scouter") || !strcmp (worker->name, "Master"))) continue;
				ID = k->id;
			}
		if (ID == 50)
			for (auto k : myHeros)
				if (k->level < 5 && k->id < ID)
				{
					if (strategy == -1 && (!strcmp(worker->name, "Scouter") || !strcmp (worker->name, "Master"))) continue;
					ID = k->id;
				}
		if (strategy == -1 && (!strcmp(worker->name, "Scouter") || !strcmp (worker->name, "Master")))
		{

		}
		else if (ID == worker->id) return this->worth = 100000;
	}
	if (strategy == -1)
	{
		int MIND = 10000;
		int k;
		for (int i = 0; i < 7; i ++)
			if (dis2(worker->pos, MINE_POS[i]) <= MIND)
			{
				MIND = dis2(worker->pos, MINE_POS[i]);
				k = i;
			}
		if (MIND <= 144 && avoid_Mine[k][ROUND]) return this->worth = 100000;
	}
	this->worth = 0;
	int cnt = 0;
	for (auto k : enemyHeros)
		if (dis2 (k->pos, myBase->pos) <= 144 && strcmp(worker->name, "Observer") && k->atk >= 30)
		{
			cnt ++;
		}
	// 如果有3个以上单位在偷家 且该英雄离家较远则callback
	if (cnt >= 2 && dis2 (worker->pos, myBase->pos) >= 500) this->worth = callBackArg;
	// if (enemyBase != NULL && dis2(worker->pos, enemyBase->pos) <= 2000 && myBase->hp > enemyBase->hp) this->worth = strategyDisabled;
	return this->worth;
}

void CallBackHome::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d CallBackHomen", console->round(), worker->id, this->worth);
	#endif
	int MINP = 10000; Pos Target;
	if (dis2(worker->pos, myBase->pos) <= 500) return;
	for (auto kt : myHeros)
		cancallback[kt->pos.x][kt->pos.y] = 1;
	for (auto kt : enemyHeros)
		cancallback[kt->pos.x][kt->pos.y] = 1;
	for (int x = 0; x <= 150; x ++)
		for (int y = 0; y <= 150; y ++)
			if (dis2(Pos(x, y), myBase->pos) <= MINP && dis2(Pos(x, y), myBase->pos) > 2 && !cancallback[x][y])
			{
				MINP = dis2(Pos(x, y), myBase->pos);
				Target = Pos(x, y);
			}
	console->selectUnit(myBase);
	console->callBackHero(worker, Target);
	cancallback[Target.x][Target.y] = 1;
	if (this->worth == 100000) return;
	console->selectUnit(worker);
	if (!strcmp(worker->name, "Berserker") && this->worth != 100000)
		console->useSkill(worker->findSkill("Sacrifice"), NULL);
}
int BuyBackHome::countWorth()
{
	this->worth = 0;
	int cnt = 0;
	if (worker->level > 0) return this->worth = strategyDisabled;
	if (worker->findBuff("Reviving") == NULL) return this->worth = strategyDisabled;
	if (worker->findBuff("Reviving")->timeLeft < 10) return this->worth = strategyDisabled;
	if (strategy != 0) return this->worth = strategyDisabled;
	if (Gold - console->goldCostCurrentRound() <= 100) return this->worth = strategyDisabled;
	if (!strcmp(worker->name, "Hammerguard") || !strcmp(worker->name, "Scouter")) this->worth = 2000;
	return this->worth;
}

void BuyBackHome::work()
{
	#ifdef MEKTPOY
	fprintf (F, "Round = %d id = %d Worth = %d BuyBackHomen", console->round(), worker->id, this->worth);
	#endif
	console->selectUnit(myBase);
	if (player == 0)
	{
		console->buyBackHero(worker, worker->pos);
		console->selectUnit(worker);
		move (worker, Pos(77, 76));
	}
	else
	{
		console->buyBackHero(worker, worker->pos);
		console->selectUnit(worker);
		move (worker, Pos(77, 76));
	}
}

void init(const PMap &map, const PPlayerInfo &info, PCommand &cmd, AIController &controller)
{
// 装死
	#ifndef MEKTPOY
		// if (player == 1) { int k = 0; k = k / k; while(1); }
	#endif
	srand(time(NULL));
	memset(cancallback, 0, sizeof(cancallback));
	memset(attacked, 0, sizeof(attacked));
	memset(attacked_berserker, 0, sizeof(attacked_berserker));
	memset (MP, 0, sizeof(MP));
	memset (def, -1, sizeof(def));
	ROUND = info.round;
	MAP = map; 
	myBase = controller.myBase;
	enemyBase = controller.enemyBase;
	player = info.player;
	myHeros.clear();
	enemyHeros.clear();
	myHeros.assign(controller.myHeros.begin(), controller.myHeros.end());
	enemyHeros.assign(controller.enemyHeros.begin(), controller.enemyHeros.end());
	Gold = info.gold;

	// 上次见到敌人的回合数

	// 统计财产
	property = 0;
	callbackcost = 0;
	for (auto kt : myHeros)
	{
		callbackcost += controller.console->callBackCost (kt->level);
		property += 250;
		for (auto i = 0; i < kt->level; i ++)
			property += i * LEVELUP_COST_PER_LEVEL + LEVELUP_COST_BASE;
	}
	if (property <= 2000) callbackcost = 0;
	// 统计死亡次数
	for (auto kt : myHeros)
	{
		if (ROUND - lastT >= 10) continue;
		if (kt->findBuff("Reviving") == NULL) continue;
		if (kt->findBuff("Reviving")->timeLeft == (2 + kt->level) * 7 - 1) Death ++;
	}
	centerMineArg = 300;

	strategy = 0;
	if (Death >= 4) { strategy = -1; supportRange = 2500; }
	else
	{
		if (ROUND - lastT >= 50 && property >= 2000) strategy = 1;
	}

	if (strategy != -1)
		for (auto kt : myHeros)
			if (dis(kt->pos, myBase->pos) > 60 && dis(kt->pos, MINE_POS[0]) > 60 && enemyHeros.size() > 3) 
			{
				miningArg = 1000;
				goback = ROUND + 5;
			}

	if (ROUND == goback) miningArg = 500;

	if (strategy == -1)
	{
		for (int k = 0; k < 7; k ++)
		{
			int cnt = 0;
			for (auto kt : enemyHeros)
			{
				if (kt->isWild()) continue;
				if (dis2(kt->pos, MINE_POS[k]) <= 144) cnt ++;
			}
			if (cnt)
			{
				for (int i = 1; i < 7; i ++)
					for (int j = 0; j <= 200; j ++)
					{
						if (i == k) avoid_Mine[i][ROUND + j] = 1;
						else avoid_Mine[i][ROUND + j] = 0;
					}
			}
		}
	}

	// 清零死亡次数
	if (Death < 0) Death = 0;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
#ifdef MEKTPOY
	fprintf (F, "Death = %dnn", Death);
#endif
	AIController controller(map, info, cmd);
	init (map, info, cmd, controller);
	if(info.round == 0)
	{
		if (player == 1)
		{
			controller.buyNewHero(Pos (131, 134));
			controller.buyNewHero(Pos (130, 135));
			controller.buyNewHero(Pos (129, 135));
			controller.buyNewHero(Pos (128, 136));
		}
		else
		{
			controller.buyNewHero(Pos (24, 12));
			controller.buyNewHero(Pos (21, 15));
			controller.buyNewHero(Pos (19, 16));
			controller.buyNewHero(Pos (22, 14));

		}
		return;
	} 
	if (player == 0) controller.buyNewHero(Pos (24, 12));
	else controller.buyNewHero(Pos (128, 136));
	controller.action();
	controller.levelupHero();
}
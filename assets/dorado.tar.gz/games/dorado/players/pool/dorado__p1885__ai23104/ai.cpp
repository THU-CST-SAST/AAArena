#include "sdk.h"
#include "const.h"
#include "console.h"
#include "filter.h"

#include <iostream>
#include <fstream>
//#include <strstream>

#include <vector>
#include <list>
#include <queue>

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <cassert>

#include <numeric>		// accumulate
#include <algorithm>	// copy_if
#include <functional>

using namespace std;
static const char* HERO_NAME[] = {"Hammerguard", "Berserker", "Master", "Scouter"};
static bool chong = false;
const int atkvalue = 500, normalmove = 200;
static const int movetox[4] = {0, 0, 1, -1};
static const int movetoy[4] = {1, -1, 0, 0};
static int hasrun[100];
static int notbother = 0;
static int scout = 0;
static int mydeath = 0;
static int enemydeath = 0;
static int camp = 0;
static vector<int> togetherlast;
static const PMap* ditu;
static const PPlayerInfo* xinxi;
static int isfind = 2;
static bool start = false;
static int howmanytime = 0;
static bool slow = false;
static int jihao[180][180];
static int juli1[180][180];
static int juli2[180][180];
static Pos lastone[180][180];
static int djh[180][180][25];//prevent overlay

//ofstream ferr("write.txt");
//寻找最短路径
void fsw(Pos start, Pos dest,const PUnit *my, const std::vector<Pos> &blocks, std::vector<Pos> &path)
{
	int sudu;
	sudu = my ->speed;
	memset (jihao, 0, sizeof(jihao));
	memset (juli2, 1000000000, sizeof(juli2));
	path.clear();	
	int Min = 2000000000;
	Pos mengmeng = start;
	Pos a, b;
	queue <Pos> duilie;
	PMap map = *ditu;
	duilie.push (dest); juli2[dest.x][dest.y] = 0; jihao[dest.x][dest.y] = 1;
	while (!duilie.empty())
	{
		a = duilie.front(); duilie.pop(); 
		for (int pi = 0; pi < 4; pi ++) 
		{
			b = a + Pos(movetox[pi], movetoy[pi]);
			if (checkPos(b) && abs(map[a.x][a.y] - map[b.x][b.y]) <= 1 && !jihao[b.x][b.y]) 
			{
				juli2[b.x][b.y] = juli2[a.x][a.y] + 1;
				duilie.push(b);
				jihao[b.x][b.y] = 1;
			}
		}
	}
	memset (jihao, 0, sizeof(jihao));
	memset (juli1, 0, sizeof(juli1));
	for (int i = 0; i < 150; i ++)
	{
		for (int j = 0; j < 150; j ++)
		{
			lastone[i][j] = Pos(-1, -1);
		}
	}
	for (int i = 0; i < blocks.size(); ++i)
	{
		jihao[blocks[i].x][blocks[i].y] = 1;
	}
	jihao[start.x][start.y] = 1;
	int random[4];
	int maxstep;
	for (int i = 0; i * i <= sudu / 2; i ++)
	{
		int j = i;
		for (; j * j + i * i <= sudu; j ++)
		{
			;
		}
		if (maxstep < i + j - 1)
		{
			maxstep = i + j - 1;
		}
	}
	duilie.push (start);
	while (!duilie.empty()) 
	{
		a = duilie.front(); duilie.pop(); 
		for (int i = 0; i < 4; i ++) random[i] = i;
		int zhengx = abs(start.x - dest.x);
		int zhengy = abs(start.y - dest.y);
		if (zhengy < zhengx)
		{
			reverse (random, random + 4);
			
		}
		if (juli1[a.x][a.y] % 2 == 1)
			reverse (random, random + 4);
		for (int pi = 0; pi < 4; pi ++) 
		{
			b = a + Pos(movetox[random[pi]], movetoy[random[pi]]);
			if (abs(map[a.x][a.y] - map[b.x][b.y]) <= 1) 
			{
				if (jihao[b.x][b.y]) continue;
				if (!checkPos(b)) continue;
				int temp = juli1[a.x][a.y] + 1;
				if (djh[b.x][b.y][temp]) continue;
				juli1[b.x][b.y] = juli1[a.x][a.y] + 1;
				jihao[b.x][b.y] = 1;
				lastone[b.x][b.y] = a;
				if (juli2[b.x][b.y] < Min)
				{
					Min = juli2[b.x][b.y];
					mengmeng = b;
				}
				if (temp < maxstep) duilie.push(b);
			}
		}
	}
	for (a = mengmeng; a != start; a = lastone[a.x][a.y])
	{
		path.push_back(a);
	}
	path.push_back(a);
	reverse(path.begin(), path.end());
}
void movement (Pos target, const PUnit* my, Console* console)
{
	if(strcmp(my->name, "Master") == 0 && my->canUseSkill("Blink") && dis2(target, my -> pos) > 100
			&& (my -> mp == my -> max_mp || (my -> mp != my -> max_mp && my -> findBuff("BeAttacked"))))
	{
		vector<Pos> blocks,path;
	    blocks.clear();
	    path.clear();
	    for(int j = 0; j < xinxi->units.size(); ++j)
	    {
	        if (xinxi->units[j].id != my->id)
	        {
	            blocks.push_back(xinxi->units[j].pos);
	        }
	    }
	    for(int k = 0; k < MINE_NUM; ++k)
	    {
	        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
	        {
	            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
	            {
	                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
	            }
	        }
	    }
	    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
	    {
	        blocks.push_back(MILITARY_BASE_POS[k]);
	    }
	    findShortestPath(*ditu, my->pos, target, blocks, path);
	    int farest = path.size() - 1;
	    for (int i = 0; i < path.size(); i ++)
	    {
	    	if (dis2(path[i], my -> pos) > BLINK_RANGE)
	    	{
	    		farest = i - 1;
	    		break;
	    	}

	    }
		for (int ee = 0; ee < 10; ee ++) 
		{
				djh[path[farest].x][path[farest].y][ee] = 1;
		}
		console -> useSkill("Blink", path[farest], my);
		
	}
	else
	{
		int MIN_T = 1000000; Pos Target;
		vector <Pos> path;
		vector <Pos> block;
		block.push_back(MILITARY_BASE_POS[camp]);
		for (int p = 0; p < 7; p ++)
		{
			for (int x = 1; x <= 150; x ++)
				for (int y = 1; y <= 150; y ++)
				{
					if (dis2(Pos(x, y), MINE_POS[p]) <= 2) block.push_back(Pos(x, y));
					else if ((p == 2 || p == 3) && dis2(Pos(x, y), MINE_POS[p]) <= 16) block.push_back(Pos(x, y));
				}
			if (target == MINE_POS[p])
			{
				if (camp == 0) target = target + Pos(-2, -2);
				else target = target - Pos(2, 2);
			}
		}
		std::vector<PUnit*> aaa = console->friendlyUnits();
		std::vector<PUnit*> bbb = console->enemyUnits();
		for (int i = 0; i < aaa.size(); i ++)
		{
			if (!strcmp(aaa[i]->name, "Observer"))
			{
				block.push_back(aaa[i] -> pos);
			} 
			if (xinxi->round >= 15)
			{
				block.push_back(aaa[i]->pos);
			} 
		}
		for (int i = 0; i < bbb.size(); i ++)
		{
			if (!strcmp(bbb[i] -> name, "Observer"))
			{
				block.push_back(bbb[i] -> pos);
			} 
			if (xinxi->round >= 15)
			{
				block.push_back(bbb[i] -> pos);
			} 
		}
		fsw(my->pos, target, my, block, path);
		console->move(path, my);
		int X = 0, Y = 0;
		for (int k = 0; k < path.size(); k ++)
		{
			djh[path[k].x][path[k].y][k] = 1;
			X = path[k].x, Y = path[k].y;
		}
		for (int k = path.size(); k < 10; k ++)
			djh[X][Y][k] = 1;
	}
	
}















// 找射程内血量最多的敌人
int findthelarge(const PUnit* my, vector<const PUnit*> enemy, vector<int> enemyhp)				 
{
	int number = -1, hp = 0; 
	
	for (int i = 0; i < enemy.size(); i ++)
	{
		if (dis2(my-> pos, enemy[i]-> pos) <= my -> range)
		{
			if (enemyhp[i] > hp)
			{
				hp = enemyhp[i];
				number = i;
			}
		}
	}
	return number;
}

int findthesmall(const PUnit* my, vector<const PUnit*> enemy, vector<int> enemyhp)				 
{
	int number = -1, hp = 1000000; 
	
	for (int i = 0; i < enemy.size(); i ++)
	{
		if (dis2(my-> pos, enemy[i]-> pos) <= my -> range)
		{
			if (enemyhp[i] < hp)
			{
				hp = enemyhp[i];
				number = i;
			}
		}
	}
	return number;
}

//攻击函数
void assault(const PUnit* my, int &value, const PUnit* enemy, int &enemyhp, Console* console)
{
	int sign = -1;
	if(strcmp(my->name, "Hammerguard") == 0)
  {
  	sign = 0;
  	if(dis2(my->pos, enemy->pos) < HAMMERGUARD_RANGE)
		{
			if(my->canUseSkill("HammerAttack"))
			{
				if (value < 1000)
				{
					console->useSkill("HammerAttack", enemy, my);
					value = 1000;
					enemyhp = enemyhp - HAMMERATTACK_DAMAGE[my -> level];
				}
				//........
				//ferr << "Hammerguard" << "round:" << info.round << endl;
			}
			else if (value < atkvalue && my -> canUseSkill("attack"))
			{
				console->attack(enemy, my);
				value = atkvalue;
				enemyhp = enemyhp - max(my -> atk - enemy -> def, 5);
			}
			else
			{
				if (value < normalmove)
				{
					value = normalmove;
					movement(enemy->pos, my, console);
				}
			}
		}
		else if(dis2(my->pos, enemy->pos) < HAMMERATTACK_RANGE && my->canUseSkill("HammerAttack"))
		{				
				if (value < 1000)
				{
					console->useSkill("HammerAttack", enemy, my);
					value = 1000;
					enemyhp = enemyhp - HAMMERATTACK_DAMAGE[my -> level];
				}
				else
				{
					if (value < normalmove)
					{
						value = normalmove;
						movement(enemy->pos, my, console);
					}
				}
		}
				
		else
		{
			//Pos target_pos = console->closestPos(enemyHeroes[closest]->pos, HAMMERGUARD_RANGE, Hammerguards[i]->pos);
			if (value < normalmove)
			{
				value = normalmove;
				movement(enemy->pos, my, console);
			}
			
			
		}
  }
  else if(strcmp(my->name, "Master") == 0)
  {
    sign = 1;
    if(dis2(my->pos, enemy->pos) < MASTER_RANGE && my->canUseSkill("attack"))
		{
			if (value < atkvalue)
			{
				console->attack(enemy, my);
				value = atkvalue;
				enemyhp = enemyhp - max(my -> atk - enemy -> def, 5);
			}
		}
		else
		{
			//Pos target_pos = console->closestPos(enemyHeroes[closest]->pos, MASTER_RANGE, Masters[i]->pos);
			if (value < normalmove)
			{
				value = normalmove;
				movement(enemy->pos, my, console);
			}
		}
  }
  else if(strcmp(my->name, "Scouter") == 0)
  {
    sign = 2;
    if(dis2(my->pos, enemy->pos) < SCOUTER_RANGE && my->canUseSkill("attack"))
		{
			if (value < atkvalue)
			{
				console->attack(enemy, my);
				value = atkvalue;
				enemyhp = enemyhp - max(my -> atk - enemy -> def, 5);
			}
		}
		else
		{
			//Pos target_pos = console->closestPos(enemyHeroes[closest]->pos, MASTER_RANGE, Masters[i]->pos);
			if (value < normalmove)
			{
				value = normalmove;
				movement(enemy->pos, my, console);
			}
		}
  }
  else if(strcmp(my->name, "Berserker") == 0)
  {
    sign = 3;
    int brange = my->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
    bool beat = false, windie = false;
		for (int j = 0; j < my->buffs.size(); j ++)
		{
			if (strcmp(my->buffs[j].name, "BeAttacked") == 0)
			beat = true;
			if (strcmp(my->buffs[j].name, "WinOrDie") == 0)
			windie = true;
		}
    if(dis2(my->pos, enemy->pos) < brange && my->canUseSkill("attack"))
		{
			int temp = atkvalue;
			if (windie)
			{
				temp = temp * 20;
			}
			if (value < temp)
			{
				
				console->attack(enemy, my);
				value = temp;
				enemyhp = enemyhp - max(my -> atk - enemy -> def, 5);
			}
		}
		else
		{
			//Pos target_pos = console->closestPos(enemyHeroes[closest]->pos, MASTER_RANGE, Masters[i]->pos);
			
			int temp = normalmove;
			if (windie)
			{
				temp = temp * 10;
			}
			if (value < temp)
			{
				value = temp;
				movement(enemy->pos, my, console);
			}
		}                
  }
  
} 


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    Console* console = new Console(map, info, cmd);
    Pos mine_pos[] = {Pos(73, 74), Pos(34, 59), Pos(34, 89), Pos(114, 59), Pos(114, 89), Pos(19, 139), Pos(129, 9)};
    vector<const PUnit*> myHeroes, myHealthyHeroes, mySickHeroes, enemyHeroes, Wilds,  Mines ; 
    PUnit* myBase = NULL;
    PUnit* enemyBase = NULL;
    PUnit* Observers = NULL;
    vector<Pos> jinkuang;
    vector<Pos> weakjinkuang;
    ditu = &map;
    xinxi = &info;
    camp = info.camp;
    memset(djh, 0, sizeof(djh));
    if (info.camp == 0)
    {
    	jinkuang.push_back(MINE_POS[0]);jinkuang.push_back(MINE_POS[1]);jinkuang.push_back(MINE_POS[4]);jinkuang.push_back(MINE_POS[5]);
    	jinkuang.push_back(MINE_POS[6]);jinkuang.push_back(MINE_POS[2]);jinkuang.push_back(MINE_POS[3]);
    	weakjinkuang.push_back(MINE_POS[0]);weakjinkuang.push_back(MINE_POS[5]);weakjinkuang.push_back(MINE_POS[1]);weakjinkuang.push_back(MINE_POS[2]);
    	weakjinkuang.push_back(MINE_POS[3]);weakjinkuang.push_back(MINE_POS[4]);weakjinkuang.push_back(MINE_POS[6]);
    }
    if (info.camp == 1)
    {
    	jinkuang.push_back(MINE_POS[0]);jinkuang.push_back(MINE_POS[4]);jinkuang.push_back(MINE_POS[1]);jinkuang.push_back(MINE_POS[6]);
    	jinkuang.push_back(MINE_POS[5]);jinkuang.push_back(MINE_POS[2]);jinkuang.push_back(MINE_POS[3]);
    	weakjinkuang.push_back(MINE_POS[0]);weakjinkuang.push_back(MINE_POS[6]);weakjinkuang.push_back(MINE_POS[4]);weakjinkuang.push_back(MINE_POS[2]);
    	weakjinkuang.push_back(MINE_POS[3]);weakjinkuang.push_back(MINE_POS[1]);weakjinkuang.push_back(MINE_POS[5]);
    }
		vector<int> myHscore; 
		vector<int> enemyhp; 
		vector<int> together;
		vector<int> Wildshp;
		vector<int> Wildsbelong;
		vector<bool> isrun;
		int runman = 0;
		int bigtogether = -10000;
		int bigtsign = -1;
		bool weak = false;
		bool fire = false;
    //将单位分类
    
	 	for(int i = 0; i < info.units.size(); ++i)
	    {
    		if (strcmp(info.units[i].name, "Observer") == 0 && info.units[i].camp != info.camp)
    		{
    			Observers = ((PUnit*)(&info.units[i]));
    		}
	        if(info.units[i].isHero())
	        {
	            if(info.units[i].camp == info.camp)
				{
					myHeroes.push_back((PUnit*)(&info.units[i]));
					myHscore.push_back(0);
					if(console->unitArg("hp", "c", (PUnit*)(&info.units[i])) < console->unitArg("hp", "m", (PUnit*)(&info.units[i])) / 3)
					{
							mySickHeroes.push_back((PUnit*)(&info.units[i]));
					}
					else
					{
							myHealthyHeroes.push_back((PUnit*)(&info.units[i]));
					}
        
				}
	            else enemyHeroes.push_back((PUnit*)(&info.units[i]));
	        }
	        else if(info.units[i].isWild() && strcmp(info.units[i].name, "Roshan") != 0)
	        {
		    	Wilds.push_back((PUnit*)(&info.units[i]));
		    	Wildshp.push_back(info.units[i].hp);
			}
			else if(strcmp(info.units[i].name, "MilitaryBase") == 0)
			{
				if(info.units[i].camp == console->camp()) myBase = (PUnit*)(&info.units[i]);
				else enemyBase = (PUnit*)(&info.units[i]);
			}
			else if(strcmp(info.units[i].name, "Mine") == 0)
	  	  	{
    			Mines.push_back((PUnit*)(&info.units[i]));
   		 	}
	    }

    //删掉没有能量的金矿
    /*for (int i = 0; i < Mines.size(); i ++)
    {
    	if (console -> unitArg("energy", "c", Mines[i]) == 0)
    	{
    		for (int j = 0; j < jinkuang.size(); j ++)
    		{
    			if (dis2(Mines[i] -> pos, jinkuang[j]) == 0)
    			{

    				vector<Pos>::iterator ppp = jinkuang.begin();
    				ppp = ppp + j;
    				jinkuang.erase(ppp);
    			}
    		}
    		for (int j = 0; j < weakjinkuang.size(); j ++)
    		{
    			if (dis2(Mines[i] -> pos, weakjinkuang[j]) == 0)
    			{

    				vector<Pos>::iterator ppp = weakjinkuang.begin();
    				ppp = ppp + j;
    				weakjinkuang.erase(ppp);
    			}
    		}
    	}
    }*/

    // 骚扰策略
    if (start = true && myHeroes.size() > 3 && mydeath > enemydeath + 4 && myHeroes.size() < 8)
    {

    	if (enemyHeroes.size() == 0)
    	{
    		if (myHscore[3] < 2000)
    		{
    			myHscore[3] = 2000;
    			movement (MILITARY_BASE_POS[1 - console->camp()], myHeroes[3], console);
    		}
    	}
    	int total = 0;
    	int  yan = 0;
    	if (enemyHeroes.size() != 0)
    	{
    		
    		bool exist = false;
    		for (int i = 0; i < enemyHeroes.size(); i ++)
    		{
    			int subtotal = 0;
    			for(int j = 0; j < myHeroes.size(); j ++)
    			{
    				if (j != 3)
    				{
    					if (dis2(myHeroes[j] -> pos, enemyHeroes[i] -> pos) > 50)
    					{
    						subtotal ++;
    					}
    				}
    			}
    			if (subtotal == myHeroes.size() - 1 && dis2(enemyHeroes[i] -> pos, MILITARY_BASE_POS[console->camp()]) > 144)
    			{
    				total ++;
    			}
    			if (dis2(enemyHeroes[i] -> pos, myHeroes[3] -> pos) < 144)
    			{
    				exist = true;
    			}
    		}
    		for (int i = 0; i < myHeroes.size(); i ++)
    		{
    			if (i != 3 && Observers != NULL)
    			{
    				if (dis2(myHeroes[i] -> pos, Observers -> pos) > 400)
    				{
    					yan ++;
    				}
    			}
    		}
    		if (yan == myHeroes.size() - 1)
    		{
    			Observers = NULL;
    		}
    		if (total == enemyHeroes.size() && exist)
    		{
    			int many[4] = {0, 0, 0, 0};
    			Pos destination[4] = {MILITARY_BASE_POS[console->camp()], Pos(15, 146), Pos(146, 15), MILITARY_BASE_POS[1 - console->camp()]};
    			for (int cnm = 0; cnm < 4; cnm ++)
    			{
    				if (dis2(myHeroes[3] -> pos, destination[cnm]) < 144)
    				{
    					many[cnm] = -100000;
    					break;
    				}
    				vector<Pos> blocks,path;
				    blocks.clear();
				    path.clear();
				    for(int j = 0; j < xinxi->units.size(); ++j)
				    {
				        if (xinxi->units[j].id != myHeroes[3]->id)
				        {
				            blocks.push_back(xinxi->units[j].pos);
				        }
				    }
				    for(int k = 0; k < MINE_NUM; ++k)
				    {
				        for(int i = - MINE_VOLUME + 1; i < MINE_VOLUME; ++i)
				        {
				            for(int j = - MINE_VOLUME + 1; j < MINE_VOLUME; ++j)
				            {
				                blocks.push_back(Pos(MINE_POS[k].x+i, MINE_POS[k].y+j));
				            }
				        }
				    }
				    for(int k = 0; k < MILITARY_BASE_NUM; ++k)
				    {
				        blocks.push_back(MILITARY_BASE_POS[k]);
				    }
				    findShortestPath(*ditu, myHeroes[3] -> pos, destination[cnm], blocks, path);
				    int ii = 0;
				    for (; ii < path.size(); ii ++)
				    {
				    	if (dis2(path[ii], myHeroes[3] -> pos) >SCOUTER_SPEED)
				    	{
				    		break;
				    	}
				    }

    				Pos pp = path[ii - 1];
    				for (int i = 0; i < enemyHeroes.size(); i ++)
	    			{
	    				many[cnm] = many[cnm] + dis2(pp, enemyHeroes[i] -> pos);
	    				if (strcmp(enemyHeroes[i]->name, "Hammerguard") == 0 && dis2(pp, enemyHeroes[i] -> pos) < 36)
	    				{
	    					many[cnm] = many[cnm] - 100000;
	    				}
	    			}
	    			for (int i = 0; i < myHeroes.size(); i ++)
	    			{
	    				many[cnm] = many[cnm] + dis2(pp, myHeroes[i] -> pos);
	    			}
    			}
    			int thelarge = 0;
    			for (int cnm = 0; cnm < 4; cnm ++)
    			{
    				if (many[cnm] > many[thelarge])
    				{
    					thelarge = cnm;
    				}
    			}
    			if (myHscore[3] < 2000)
	    		{
	    			myHscore[3] = 2000;
	    			console -> move(console -> closestPos(myHeroes[3] -> pos, 36, destination[thelarge]), myHeroes[3]);
	    		}

    			//ferr << info.round << ":" << enemyHeroes.size();
    		}
    		else if (total == enemyHeroes.size() && !exist)
    		{
    			if (myHscore[3] < 2000)
	    		{
	    			myHscore[3] = 2000;
	    			movement (MILITARY_BASE_POS[1 - console->camp()], myHeroes[3], console);
	    		}
    		}
    		
    		
    	}
    	if (!slow && enemyHeroes.size() != 0)
		{
			slow = true;
		}
		else if (slow && enemyHeroes.size() == 0)
		{
			slow = false;
		}
    	if (enemyHeroes.size() != 0 && total == enemyHeroes.size())
    	{
    		while(enemyHeroes.size() != 0)
			{
				vector<const PUnit*>::iterator x = enemyHeroes.begin();
				enemyHeroes.erase(x);
			}
    	}
    	
    }






    //购买英雄 
    if(myHeroes.size() < HERO_LIMIT)
    {
    	if (info.round == 0)
    	{
    		for (int i = 0; i <= 3; i ++)
	    	{
	    		if (info.camp == 1)
	    		{
	    			if (i == 0)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(127, 137));
	    			}
	    			if (i == 1)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(129, 135));
	    			}
	    			if (i == 2)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(128, 136));
	    			}
	    			if (i == 3)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(130, 135));
	    			}
	    		}
	    		if (info.camp == 0)
	    		{
	    			if (i == 0)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(22, 14));
	    			}
	    			if (i == 1)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(21, 15));
	    			}
	    			if (i == 2)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(19, 16));
	    			}
	    			if (i == 3)
	    			{
	    				console->chooseHero(HERO_NAME[i], Pos(18, 16));
	    			}
	    		}
	    	}
    	}
    	if (myHeroes.size() == 4)
    	{
    		console->chooseHero(HERO_NAME[0]);
    	}
    	if (myHeroes.size() == 5)
    	{
    		if (mydeath <= enemydeath)
    		{
    			console->chooseHero(HERO_NAME[0]);
    		}
    		else
    		{
    			console->chooseHero(HERO_NAME[0]);
    		}
    		
    	}
    	if (myHeroes.size() == 6)
    	{
    		console->chooseHero(HERO_NAME[0]);
    	}
    	if (myHeroes.size() == 7)
    	{
    		console->chooseHero(HERO_NAME[0]);
    	}
    }
    

    if (mydeath > enemydeath + 4 && enemyHeroes.size() == 0 )
    {
    	if (Wilds.size() != 0)
    	{
    		if (Wilds[0] -> findBuff("Reviving"))
    		{
    			start = true;
    		}
    	}
    	
    }

    if (start)
    {
    	if  (enemyHeroes.size() != 0)
    	{
    		howmanytime ++;
    	}
    }




    // 劣势打野
    if (mydeath > enemydeath + 4 && enemyHeroes.size() == 0 && myHeroes.size() < 8)
    {
    	weak = true;
    	for (int i = 0; i< Wilds.size(); i ++)
    	{
    		int near = 0;
    		int dist = 1000000;
    		for (int j = 0; j < 7; j ++)
    		{
    			if (dis2(Wilds[i] -> pos , weakjinkuang[j]) < dist)
    			{
    				dist = dis2(Wilds[i] -> pos , weakjinkuang[j]);
    				near = j;
    			}
    		}
    		Wildsbelong.push_back(near);
    	}

    	if (Wilds.size() == 0)
		{
			for(int i = 0 ; i < myHeroes.size() ; i ++)
			{
				if (myHscore[i] < 160)
				{
					myHscore[i] = 160;
					movement (weakjinkuang[1] , myHeroes[i] , console);
				}
				
			}
		}
		else 
		{
			int a1 = 0;
			int haspower = 0;
			int hastake = 0;
			for (int pppp = 0; pppp < Wilds.size(); pppp ++)
			{
				if (Wilds[pppp] -> findBuff("Reviving"))
				{
					if (myHscore[Wildsbelong[pppp] - 1] < 160)
					{
						myHscore[Wildsbelong[pppp] - 1] = 160;
						movement (weakjinkuang[Wildsbelong[pppp]] , myHeroes[Wildsbelong[pppp] - 1], console);
					}
					hastake ++;
				}
			}
			for (; a1 < Wilds.size(); a1 ++)
			{
				if (Wildsbelong[a1] <= hastake + 1 && !Wilds[a1] -> findBuff("Reviving"))
				{
					
					if (Wildsbelong[a1] == 1 && hastake >= 1)
					{
						for (int i = 0; i < myHeroes.size(); i ++)
						{
							if (i == 1)	
							{
								if (myHscore[i] == 160)
								{
									continue;
								}

							}
							if(strcmp(myHeroes[i]->name, "Berserker") == 0)
				        	{
				      			//ferr << "find!" << endl;
				        		int brange = myHeroes[i]->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
								bool beat = false, windie = false;
								for (int j = 0; j < myHeroes[i]->buffs.size(); j ++)
								{
									if (strcmp(myHeroes[i]->buffs[j].name, "BeAttacked") == 0)
									beat = true;
									if (strcmp(myHeroes[i]->buffs[j].name, "WinOrDie") == 0)
									windie = true;
								}
								
								bool nottheone = false;
								for (int j = 0; j < myHeroes.size(); j ++)
								{
									if (j != i )
									{
										if (myHeroes[j] -> findBuff("BeAttacked"))
										{
											nottheone = true;
										}
									}
								}
								
								if (dis2(Wilds[a1]->pos, myHeroes[i]->pos) <  brange && !beat 
										&& myHeroes[i]->canUseSkill("Sacrifice") && myHscore[i] < 600
										&& nottheone && myHeroes[i] -> canUseSkill("Attack"))
								{
									myHscore[i] = 600;
									console->useSkill("Sacrifice", NULL, myHeroes[i]);
									//ferr << "round" << info.round << ":" << "sac" << endl;
									
								}
								else
								{
									assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
								}
								
					    	}
					    	else
					    	{
					    		assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
					    	}
							
						}
						break;
					}
					else
					{
						for (int i = hastake; i < myHeroes.size(); i ++)
						{
							if(strcmp(myHeroes[i]->name, "Berserker") == 0)
				        	{
				      			//ferr << "find!" << endl;
				        		int brange = myHeroes[i]->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
								bool beat = false, windie = false;
								for (int j = 0; j < myHeroes[i]->buffs.size(); j ++)
								{
									if (strcmp(myHeroes[i]->buffs[j].name, "BeAttacked") == 0)
									beat = true;
									if (strcmp(myHeroes[i]->buffs[j].name, "WinOrDie") == 0)
									windie = true;
								}
								
								bool nottheone = false;
								for (int j = 0; j < myHeroes.size(); j ++)
								{
									if (j != i )
									{
										if (myHeroes[j] -> findBuff("BeAttacked"))
										{
											nottheone = true;
										}
									}
								}
								
								if (dis2(Wilds[a1]->pos, myHeroes[i]->pos) <  brange && !beat 
										&& myHeroes[i]->canUseSkill("Sacrifice") && myHscore[i] < 600
										&& nottheone && myHeroes[i] -> canUseSkill("Attack"))
								{
									myHscore[i] = 600;
									console->useSkill("Sacrifice", NULL, myHeroes[i]);
									//ferr << "round" << info.round << ":" << "sac" << endl;
									
								}
								else
								{
									assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
								}
								
					    	}
					    	else
					    	{
					    		assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
					    	}
							
						}
						break;
					}
				}
				
					
				
			}
			if (a1 == Wilds.size())
			{
				int signa = 0;
				for (int i = 0; i < a1; i ++)
				{
					
					if (dis2(myHeroes[i] -> pos , weakjinkuang[i + 1]) < 144)
					{
						signa ++;
					}
					//ferr << info.round << ":" << "p1" << endl;
					
				}
				//ferr << info.round << ":" << signa << endl;
				if (signa == a1 && a1 == isfind - 1)
				{
					for(int i = a1 ; i < myHeroes.size(); i ++)
					{
						if (myHscore[i] < 160)
						{
							myHscore[i] = 160;
							movement (weakjinkuang[a1 + 1] , myHeroes[i], console);
						}
						//ferr << info.round << ":" << "p2" << endl;
					}
				}
				else 
				{
					for(int i = a1 - 1 ; i < myHeroes.size(); i ++)
					{
						if (myHscore[i] < 160)
						{
							myHscore[i] = 160;
							movement (weakjinkuang[a1] , myHeroes[i], console);
						}
						//ferr << info.round << ":" << "p3" << endl;
					}
				}
				
			}
			
		}
    }


    
    //判断该打谁 
    int best = 1000000, closest = -1;
    int farenemy = 0;
    for(int cao = 0; cao < enemyHeroes.size(); cao ++)
    {
    	enemyhp.push_back(enemyHeroes[cao]->hp);
    	int mark = 0;
    	int can = 0;
    	int kill = 10;
    	if (mydeath > enemydeath + 5)
    	{
    		kill = kill * 10;
    	}
    	if (strcmp(enemyHeroes[cao]->name, "Berserker") == 0)
    	{
    		if (enemyHeroes[cao] -> canUseSkill("Sacrifice") || enemyHeroes[cao] ->findBuff("WinOrDie"))
    		{
    			mark = -50000;
    		}
    		if (!(enemyHeroes[cao] -> canUseSkill("Sacrifice") || enemyHeroes[cao] ->findBuff("WinOrDie")))
    		{
    			mark = 5000;
    		}
    	}
    	if(strcmp(enemyHeroes[cao]->name, "Hammerguard") == 0 && enemyHeroes[cao] -> canUseSkill("HammerAttack"))
    	{
    		mark = -3000;
    	}
    	for (int x = 0; x < myHeroes.size(); x ++)
    	{
    		if (dis2(myHeroes[x] -> pos , enemyHeroes[cao] -> pos) > enemyHeroes[cao] -> range)
    		{
    			can ++;
    		}
    	}
    	if (can == myHeroes.size())
    	{
    		mark = mark + 20000;
    	}
    	int tem =enemyhp[cao] * kill + mark;
    	for (int nm = 0; nm < myHeroes.size(); nm ++)
    	{
    		if (dis2(enemyHeroes[cao] -> pos, myHeroes[nm] -> pos) < 144)
    		tem = tem + dis2(enemyHeroes[cao] -> pos, myHeroes[nm] -> pos) * 15;
    	}
    	if (dis2(enemyHeroes[cao] -> pos, MILITARY_BASE_POS[1 - console->camp()]) < 800)
    	{
    		farenemy ++;
    	}
    	if (tem < best && enemyhp[cao] > 0)
    	{
    		best = tem;
    		closest = cao;
    	}
    }
    if (farenemy == enemyHeroes.size() && enemyHeroes.size() != 0)
    {
    	closest = -1;
    	notbother = 3;
    }
    if (notbother != 0)
    {
    	closest = -1;
    	notbother -- ;
    }
    //ferr << info.round << ":" << closest << endl;
   // ferr << "Round: " << info.round << endl;
    //ferr << BerSerkers.size();
    
    

    
    
    //撤退
    if (info.round == 0)
    {
    	memset(hasrun, 0, sizeof(hasrun));
    }
    if (scout < 15 && !weak && mydeath + 3 < enemydeath)
    {
    	isrun.assign(myHeroes.size(), false); // change to sign last round
	    for (int i = 0; i < sizeof(hasrun); i++)
	  	{
	  		if (hasrun[i] != 0)
	  		{
	  			for (int j = 0; j < myHeroes.size(); j ++)
	  			{
	  				if (myHeroes[j] -> id == i)
	  				{
	  					isrun[j] = true;
	  				}
	  			}
	  		}
	  	}
	  	memset(hasrun, 0, sizeof(hasrun));
	    for (int i = 0; i < myHeroes.size(); i ++)
	    {
				if ((strcmp(myHeroes[i]->name, "Berserker") != 0 || (strcmp(myHeroes[i]->name, "Berserker") == 0 && !myHeroes[i] -> canUseSkill("SuperDead"))) 
							&& myHeroes[i]->hp < 100 && myHscore[i] < 600)
				{
					
					myHscore[i] = 600;
					movement(MILITARY_BASE_POS[console->camp()], myHeroes[i], console);
					hasrun[myHeroes[i]->id] = 1;
					runman ++;
				}
				else if ((strcmp(myHeroes[i]->name, "Berserker") != 0 || (strcmp(myHeroes[i]->name, "Berserker") == 0 && !myHeroes[i] -> canUseSkill("SuperDead"))) 
							&& myHeroes[i]->hp < 150 && myHscore[i] < 600 && isrun[i])
				{
					myHscore[i] = 600;
					movement(MILITARY_BASE_POS[console->camp()], myHeroes[i], console);
					hasrun[myHeroes[i]->id] = 1;
					runman ++;
				}
	    }
    }
    
		
    
   	
    
    
    
    
    
    
    //sasibibi
    if((myBase -> hp < 1000 && info.round < 800) && closest == -1)
    {
    	chong = true;
    	
    }
    
    //防守城堡
    int enemynearbase = 0;
    if (closest != -1)
    {
    	for (int i = 0; i < enemyHeroes.size(); i ++)
    	{
    		if (dis2(MILITARY_BASE_POS[console->camp()], enemyHeroes[i] -> pos) < MILITARY_BASE_RANGE)
    		{
    			enemynearbase ++;
    		}
    	}
    }
    if (enemynearbase != 0)
		{
			int mm = 2 * enemynearbase;
			for (int i = 0; i < myHeroes.size(); i ++)
			{
				if (dis2(myHeroes[i]->pos, MILITARY_BASE_POS[console->camp()]) > 400)
				{
					console -> callBackHero(myHeroes[i]);
					
				}
				mm --;
				if (mm == 0)
				{
					break;
				}
			}
		} 
    
    //抱团 && 评估局势 
    for (int i = 0; i < myHeroes.size(); i ++)
    {
    	int temp = 0;
    	int mynum = 0;
    	int enemynum = 0;
    	if (myHeroes[i] -> findBuff("Dizzy") && !myHeroes[i] -> findBuff("Reviving"))
    	{
    		fire = true;
    	}
    	for (int j = 0; j < enemyHeroes.size(); j ++)
    	{
    		if (dis2(enemyHeroes[j]->pos, myHeroes[i]->pos) < 150)
    		{
    			temp = temp - enemyHeroes[j] -> hp;
    		}
    		enemynum ++;
    	}
    	for (int j = 0; j < myHeroes.size(); j ++)
    	{
    		if (mydeath > enemydeath)
    		{
    			if (dis2(myHeroes[j]->pos, myHeroes[i]->pos) < 50)
	    		{
	    			temp = temp + myHeroes[i] -> hp;
	    			mynum ++;
	    		}
    		}
    		else
    		{
    			if (dis2(myHeroes[j]->pos, myHeroes[i]->pos) < 80)
	    		{
	    			temp = temp + myHeroes[i] -> hp;
	    			mynum ++;
	    		}
    		}
    		
    	}
    	temp = temp - (enemynum - mynum) * 100;
    	if (temp > bigtogether)
    	{
    		bigtogether = temp;
    		bigtsign = i;
    	}
    	if (mynum == myHeroes.size() - runman)
    	{
    		temp = 10000;
    	}
    	if (togetherlast.size() > i)
    	{
    		if (togetherlast[i] < -200 && temp != 10000)
    		{
    			temp = (temp + togetherlast[i] * 2) / 3;
    			togetherlast[i] = temp;
    		}
    		else
    		{
    			togetherlast[i] = temp;
    		}
    	}
    	else
    	{
    		togetherlast.push_back(temp);
    	}
    	together.push_back(temp);
    }
    if (enemynearbase == 0 )
    {
    	for (int i = 0; i < myHeroes.size(); i ++)
	    {
	    	if (together[i] == 10000)
	    	{
	    		break;
	    	}
	    	else if ((together[i] < -200 || info.round < 40 && together[i] < 50) && myHscore[i] < 1100 && (!fire || (fire && together[i] < -400)))
	    	{
	    		myHscore[i] = 1100;
	    		movement (myHeroes[bigtsign]->pos, myHeroes[i], console);
	    	}
	    }
    }
    
    
    // 升级英雄 
    if(myHeroes.size() == HERO_LIMIT && enemynearbase == 0)
	{
		
		for (int i = 0; i < myHeroes.size(); i ++)
		{
			if (start && i == 3 && myHeroes.size() < 8)
			{
				continue;
			}

			console->buyHeroLevel(myHeroes[i]);
	    }
	}
    
    //进攻城堡 
   	/*if (chong && (enemyBase != NULL || (enemyBase == NULL && closest == -1)))
    {
    	
    	for (int i = 0; i < myHeroes.size(); i ++)
    	{
    		if (myHscore[i] < 700)
    		{
    			//ferr << info.round << ":yes" << endl;
    			myHscore[i] = 700;
    			if (enemyBase != NULL  )
	    		{
	    			
	    			console->attack(enemyBase, myHeroes[i]);
	    			if (strcmp(myHeroes[i]->name, "Berserker") == 0)
	    			{
	    				int brange = myHeroes[i]->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
	    				bool beat = false;
							for (int j = 0; j < myHeroes[i]->buffs.size(); j ++)
							{
								if (strcmp(myHeroes[i]->buffs[j].name, "BeAttacked") == 0)
								beat = true;
							}
							if (dis2(MILITARY_BASE_POS[1 - console->camp()], myHeroes[i]->pos) < BERSERKER_SPEED * 3 + brange && !beat 
									&& myHeroes[i]->canUseSkill("Sacrifice") )
							{
								console->useSkill("Sacrifice", NULL, myHeroes[i]);
								//ferr << "round" << info.round << ":" << "sac" << endl;
						
							}
	    			}
	    		}
	    		else
	    		{
	    			console->move(MILITARY_BASE_POS[1 - console->camp()], myHeroes[i]);
	    			//ferr << info.round << ":go" << endl;
	    		}
    		}
    		
    	}
    }*/
    
    
    //拆眼
		if (closest == -1 && notbother == 0 && Observers != NULL)
		{
			for (int i = 0; i < myHeroes.size(); i ++)
			{
				if (myHscore[i] < 180)
				{
					myHscore[i] = 180;
					console->attack(Observers, myHeroes[i]);
				}
				
			}
		} 
		/*else if (mydeath > enemydeath + 5 && Observers != NULL)
		{
			for (int i = 0; i < myHeroes.size(); i ++)
			{
				if (myHscore[i] < 1000)
				{
					myHscore[i] = 1000;
					console->attack(Observers, myHeroes[i]);
				}
				
			}
		}*/
    
    //不巡逻,打野 
		if (closest == -1 && notbother == 0 && scout < 12)
		{
			int sum = 0;
			for (int jiba = 0; jiba < myHeroes.size(); jiba ++)
			{
				if (dis2(myHeroes[jiba] -> pos , Pos(74, 75)) < 50)
				{
					sum ++;
				}
				
			}
			if (sum != 0)
			{
				scout ++;
			}
			else if (scout > 0)
			{
				scout --;
			}
		}
		else if (closest == -1 && notbother == 0 && scout == 12)
		{
			//ferr << 123;
			if (Wilds.size() == 0)
			{
				for(int i = 0 ; i < myHeroes.size() - 1; i ++)
				{
					if (myHscore[i] < 160)
					{
						myHscore[i] = 160;
						movement (jinkuang[1] , myHeroes[i], console);
					}
					
				}
			}
			else 
			{
				int a1 = 0;
				int haspower = 0;
				for (; a1 < Wilds.size(); a1 ++)
				{
					if (Wilds[a1] -> findBuff("Reviving"))
					{
						if (myHscore[myHeroes.size() - (a1 + 2)] < 160)
						{
							myHscore[myHeroes.size() - (a1 + 2)] = 160;
							movement (jinkuang[a1 + 1] , myHeroes[myHeroes.size() - (a1 + 2)], console);
						}
					}
					else
					{
						for (int i = 0; i < myHeroes.size() - (a1 + 1); i ++)
						{
							if(strcmp(myHeroes[i]->name, "Berserker") == 0)
				        	{
				      			//ferr << "find!" << endl;
				        		int brange = myHeroes[i]->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
								bool beat = false, windie = false;
								for (int j = 0; j < myHeroes[i]->buffs.size(); j ++)
								{
									if (strcmp(myHeroes[i]->buffs[j].name, "BeAttacked") == 0)
									beat = true;
									if (strcmp(myHeroes[i]->buffs[j].name, "WinOrDie") == 0)
									windie = true;
								}
								
								bool nottheone = false;
								for (int j = 0; j < myHeroes.size(); j ++)
								{
									if (j != i )
									{
										if (myHeroes[j] -> findBuff("BeAttacked"))
										{
											nottheone = true;
										}
									}
								}
								
								if (dis2(Wilds[a1]->pos, myHeroes[i]->pos) <  brange && !beat 
										&& myHeroes[i]->canUseSkill("Sacrifice") && myHscore[i] < 600
										&& nottheone && myHeroes[i] -> canUseSkill("Attack"))
								{
									myHscore[i] = 600;
									console->useSkill("Sacrifice", NULL, myHeroes[i]);
									//ferr << "round" << info.round << ":" << "sac" << endl;
									
								}
								else
								{
									assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
								}
								
					    	}
					    	else
					    	{
					    		assault(myHeroes[i], myHscore[i], Wilds[a1], Wildshp[a1], console);
					    	}
							
						}
						break;
					}
				}
				if (a1 == Wilds.size())
				{
					int signa = 0;
					for (int i = myHeroes.size() - 2; i >  myHeroes.size() - (a1 + 2); i --)
					{
						
						if (dis2(myHeroes[i] -> pos , jinkuang[myHeroes.size() - i - 1]) < 144)
						{
							signa ++;
						}
						//ferr << info.round << ":" << "p1" << endl;
						
					}
					//ferr << info.round << ":" << signa << endl;
					if (signa == a1)
					{
						for(int i = 0 ; i < myHeroes.size() - (a1 + 1); i ++)
						{
							if (myHscore[i] < 160)
							{
								myHscore[i] = 160;
								movement (jinkuang[a1 + 1] , myHeroes[i], console);
							}
							//ferr << info.round << ":" << "p2" << endl;
						}
					}
					else 
					{
						for(int i = 0 ; i < myHeroes.size() - a1; i ++)
						{
							if (myHscore[i] < 160)
							{
								myHscore[i] = 160;
								movement (jinkuang[a1] , myHeroes[i], console);
							}
							//ferr << info.round << ":" << "p3" << endl;
						}
					}
					
				}
				
			}
		} 
		else if (scout > 0)
		{
			scout --;
		}
    
	//用把绝命武士的血变成两滴的方法来每回合只有一个人打他
	int bernumber = 0;
	for (int i = 0; i < enemyHeroes.size(); i ++)
	{
		if (strcmp(enemyHeroes[i]->name, "Berserker") == 0)
		{
			bernumber ++;
		}
	}
	if (bernumber < enemyHeroes.size())
	{
		for (int i = 0; i < enemyHeroes.size(); i ++)
		{
			if (strcmp(enemyHeroes[i]->name, "Berserker") == 0)
			{
				enemyhp[i] = 2;
			}
		}
	}
	



    // 普通进攻 
    
    for (int i = 0; i < myHeroes.size(); i ++)//throw to the last 
    {
    	if (closest != -1)
    	{
			if (enemyhp[closest] <= -5 )
	    	{
				best = 1000000; closest = -1;
	    		for(int cao = 0; cao < enemyHeroes.size(); cao ++)
			    {
			    	int mark = 0;
			    	int can = 0;
			    	int kill = 10;
			    	if (mydeath > enemydeath + 5)
			    	{
			    		kill = kill * 10;
			    	}
			    	if (strcmp(enemyHeroes[cao]->name, "Berserker") == 0)
			    	{
			    		if (enemyHeroes[cao] -> canUseSkill("Sacrifice") || enemyHeroes[cao] ->findBuff("WinOrDie"))
			    		{
			    			mark = -20000;
			    		}
			    		if (!(enemyHeroes[cao] -> canUseSkill("Sacrifice") || enemyHeroes[cao] ->findBuff("WinOrDie")))
			    		{
			    			mark = 5000;
			    		}
			    	}
			    	if(strcmp(enemyHeroes[cao]->name, "Hammerguard") == 0 && enemyHeroes[cao] -> canUseSkill("HammerAttack"))
			    	{
			    		mark = -3000;
			    	}
			    	if(strcmp(enemyHeroes[cao]->name, "Hammerguard") == 0 && !enemyHeroes[cao] -> canUseSkill("HammerAttack"))
			    	{
			    		mark = 3000;
			    	}
			    	for (int x = 0; x < myHeroes.size(); x ++)
			    	{
			    		if (dis2(myHeroes[x] -> pos , enemyHeroes[cao] -> pos) > enemyHeroes[cao] -> range)
			    		{
			    			can ++;
			    		}
			    	}
			    	if (can == myHeroes.size())
			    	{
			    		mark = mark + 50000;
			    	}
			    	int tem =enemyhp[cao] * kill + mark;
			    	for (int nm = 0; nm < myHeroes.size(); nm ++)
			    	{
			    		if (dis2(enemyHeroes[cao] -> pos, myHeroes[nm] -> pos) < 144)
			    		tem = tem + dis2(enemyHeroes[cao] -> pos, myHeroes[nm] -> pos) * 15;
			    	}
			    	if (tem < best && enemyhp[cao] > -5)
			    	{
			    		best = tem;
			    		closest = cao;
			    	}
	   		    }
	    	}
    		
    	}
    	
    	if(strcmp(myHeroes[i]->name, "Hammerguard") == 0)
	    {
	    	
	        if(closest != -1)
	        {
	        	if (dis2(enemyHeroes[closest] -> pos, myHeroes[i] -> pos) > myHeroes[i] -> range && myHeroes[i] -> canUseSkill("Attack"))
		    	{
		    		int tt = findthesmall(myHeroes[i], enemyHeroes, enemyhp);
		    		if (tt == -1)
		    		{
		    			assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
		    		}
		    		else
		    		{
		    			assault(myHeroes[i], myHscore[i], enemyHeroes[tt], enemyhp[tt], console);
		    		}

		    	}
		    	else
		    	{
					assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
		    	}
	        	
	        }
	        if(closest == -1 && myHscore[i] < 150)
			{
				myHscore[i] = 150;
				movement(MINE_POS[0], myHeroes[i], console);
			}
	    }
       else if(strcmp(myHeroes[i]->name, "Master") == 0)
       {
         if(closest != -1)
         {
         	assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
         }
         if(closest == -1 && myHscore[i] < 150)
				{
					myHscore[i] = 150;
					movement(MINE_POS[0], myHeroes[i], console);
				}
       }
      else if(strcmp(myHeroes[i]->name, "Scouter") == 0)
      {
        if(closest != -1)
        {
         	assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
        }
        if(closest == -1 && myHscore[i] < 150)
				{
					myHscore[i] = 150;
					movement(MINE_POS[0], myHeroes[i], console);
				}
      }
      else if(strcmp(myHeroes[i]->name, "Berserker") == 0)
      {
      	//ferr << "find!" << endl;
        int brange = myHeroes[i]->level * BERSERKER_RANGE_DELTA + BERSERKER_RANGE;
				bool beat = false, windie = false;
				for (int j = 0; j < myHeroes[i]->buffs.size(); j ++)
				{
					if (strcmp(myHeroes[i]->buffs[j].name, "BeAttacked") == 0)
					beat = true;
					if (strcmp(myHeroes[i]->buffs[j].name, "WinOrDie") == 0)
					windie = true;
				}
				if(closest != -1)
				{
					bool nottheone = false;
					for (int j = 0; j < myHeroes.size(); j ++)
					{
						if (j != i )
						{
							if (myHeroes[j] -> findBuff("BeAttacked"))
							{
								nottheone = true;
							}
						}
					}
					if (windie)
					{
						int j = findthelarge(myHeroes[i], enemyHeroes, enemyhp);
						if (j != -1)
						{
							myHscore[i] = myHscore[i] / 5;
							assault(myHeroes[i], myHscore[i], enemyHeroes[j], enemyhp[j], console);
							myHscore[i] = myHscore[i] * 5;
						}
						else
						{
							assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
						}
					}
					else
					{
						int cannot = 0;
						for (int hh = 0; hh < enemyHeroes.size(); hh ++)
						{
							if (!enemyHeroes[hh] -> canUseSkill("Attack"))
							{
								cannot ++;
							}
							else if (dis2(myHeroes[i] -> pos , enemyHeroes[hh] -> pos) > enemyHeroes[hh] -> range)
							{
								cannot ++;
							}
						}
						if (dis2(enemyHeroes[closest]->pos, myHeroes[i]->pos) <  brange && myHeroes[i]->canUseSkill("Sacrifice") 
							&& myHscore[i] < 600 && nottheone && (cannot == enemyHeroes.size() || enemyHeroes.size() <= 1)
							&& myHeroes[i] -> findSkill("Attack") -> cd <= 1 && myHeroes[i] -> canUseSkill("SuperDead"))	
						{
							myHscore[i] = 600;
							console->useSkill("Sacrifice", NULL, myHeroes[i]);
							//ferr << "round" << info.round << ":" << "sac" << endl;
							
						}
						assault(myHeroes[i], myHscore[i], enemyHeroes[closest], enemyhp[closest], console);
						
					}
					
					
				}
				if(closest == -1 && myHscore[i] < 150)
				{
					myHscore[i] = 150;
					movement(MINE_POS[0], myHeroes[i], console);
				}
	          
	    }
	    if (closest == -1 && myBase -> hp < 1500 && info.round > 800)
	    {
	    	if (myHscore[i] < 170)
	    	{
	    		myHscore[i] = 170;
	    		movement(MILITARY_BASE_POS[console->camp()], myHeroes[i], console);
	    	}
	    }
    }
    
    
    
    //基地攻击
		if(enemynearbase != 0)
		{
			best = 1000000; closest = -1;
			for(int i = 0; i < enemyHeroes.size(); i ++)
	    {
	    	int mark = 0;
	    	if (strcmp(enemyHeroes[i]->name, "Berserker") == 0 && enemyHeroes[i] -> canUseSkill("Sacrifice"))
	    	{
	    		mark = -2000;
	    	}
	    	if(strcmp(enemyHeroes[i]->name, "Hammerguard") == 0 && enemyHeroes[i] -> canUseSkill("HammerAttack"))
	    	{
	    		mark = -2000;
	    	}
	    	int tem = dis2(enemyHeroes[i]->pos, MILITARY_BASE_POS[console->camp()]) + enemyhp[i] * 10 + mark;
	    	if (tem < best && enemyhp[i] > -20 
						&& dis2(enemyHeroes[i]->pos, MILITARY_BASE_POS[console->camp()]) < MILITARY_BASE_RANGE)
	    	{
	    		best = tem;
	    		closest = i;
	    	}
 		  }
 		  if (closest != -1)
 		  {
 		  	console -> baseAttack(enemyHeroes[closest]);
 		  }
	    
		} 

	//插眼
	for (int i = 0 ; i < myHeroes.size(); i ++)
	{
		if(strcmp(myHeroes[i]->name, "Scouter") == 0 && dis2(myHeroes[i] -> pos, MILITARY_BASE_POS[console->camp()]) > 3600 && info.round > 30)
		{
		  	Pos pop = console -> randPosInArea(myHeroes[i] -> pos, 16);
			if(myHeroes[i]->canUseSkill("SetObserver") && dis2(pop, myHeroes[i]-> pos) < SET_OBSERVER_RANGE 
				&& closest == -1 && myHscore[i] < 400)
			{
				myHscore[i] = 400;
				console->useSkill("SetObserver", pop, myHeroes[i]);
				
			}
		}
	}
	
	//统计自己、敌人死的次数
    for (int i = 0; i < myHeroes.size(); i ++)
    {
    	if (myHeroes[i] -> findBuff("Reviving"))
        {
    		if (myHeroes[i] -> findBuff("Reviving") -> timeLeft == (myHeroes[i] -> level + 2) * 7 - 5)
    		{
    			mydeath ++;
    			//ferr << info.round << ":" << mydeath;
    		} 
    	}
    }
    for (int i = 0; i < enemyHeroes.size(); i ++)
    {
    	if (enemyhp[i] < 0 && strcmp(enemyHeroes[i]->name, "Berserker") != 0)
    	{
    		enemydeath ++;
    		//ferr << info.round << ":" << enemydeath << endl;
    	}
    }

    delete console;
    
    
    
    
    
    
    
    
    
}
#include "console.h"
#include <vector>
#include <cstring>
#include <iostream>
#include <map>
#include <ctime>
#include <cstdlib>
#include <algorithm>
#include <queue>

using namespace std;

static const char* HERO_NAME[] = {"Hammerguard", "Master", "Berserker", "Scouter"};
static int minePre = 4;
static int mineGo[4];
static int mineNo = 0;
const int MAXN = 30;
const int MAXM = 200;
const int STEP = 15;
int myCnt[ MAXN ];
bool checkMap[ STEP ][ MAXM ][ MAXM ];
bool checkBack[ MAXN ];
int checkRun[ MAXN * 10 ];
static bool orzorz = 0;
static Pos tarBack;
Pos roundTar;
static Pos tarOther;
static int yzround = 50;   
int injury[ MAXM ];
static Pos heroBorn[4];
int tmpMap[ MAXM ][ MAXM ];
queue<Pos> fP;
int imp[4] = {4, 1, 3, 0};
int limp[4] = {5, 2, 4, 3};
int attimp[4] = {1, 1, 80, 0};
static Pos myMinePos[7] = {Pos(74, 75), Pos(35, 63), Pos(37, 92), Pos(113, 60), Pos(114, 87), MINE_POS[5], MINE_POS[6]};
static int lp = -1;

class YD
{
public:
	PUnit now;
	Pos T;
	YD(const PUnit A, const Pos B);
	// bool operator < (const YD &A) const
	// 	{
	// 		return imp[now.typeId - 3] > imp[A.now.typeId - 3];
	// 	}
	YD() {}
};

YD::YD(const PUnit A, const Pos B)
{
	now = A;
	T = B;
}

bool cmp(const YD &A, const YD &B)
{
	return imp[A.now.typeId - 3] > imp[B.now.typeId - 3];
}

bool cmplu(const YD &A, const YD &B)
{
	return limp[A.now.typeId - 3] > limp[B.now.typeId - 3];
}

/*
static const char* AREA_NAME[] = {};
static const char* ARGS_NAME[] = {"Hp", "Mp", "Exp", "Speed", "View", "Atk", "Def", "Range", "LastHit", "OnlyTarget", "Gold", "Energy"};
static const char* BUFF_NAME[] = {"Dizzy", "Reviving", "WaitRevive", "ChosenByBase", "BuyBackByBase", "CallBackByBase", "LevelUpByBase", "IsMining", "BeAttacked"};
static const char* FLIGHT_NAME[] = {};
static const char* SKILL_NAME[] = {"Attack", "ChooseHammerguard", "ChooseBerserker", "ChooseMaster", "ChooseScouter", "BuyHeroLevel", "BuyBackHero", "CallBackHero", "HammerAttack", "Blink", "Sacrifice", "SetObserver"};
static const char* UNIT_NAME[] = {"MilitaryBase", "Mine", "PlayerInformation", "Hammerguard", "Master", "Berserker", "Scouter", "Dog", "Bow", "Wolf", "StoneMan", "Dragon", "Roshan"};
static const char* OPERATION_NAME[] = {"Attack", "Stop", "Move", "ChooseHammerguard", "ChooseMaster", "ChooseBerserker", "ChooseScouter", "BuyHeroLevel", "BuyBackHero", "CallBackHero", "HammerAttack", "Sacrifice", "Blink", "SetObserver"};
*/

void GetMyUnitsCnt(const vector<PUnit*> &myUnits)	// 对单位进行统计
{
	memset(myCnt, 0, sizeof(myCnt));
	for(int i = 0; i < myUnits.size(); ++i)
		myCnt[ myUnits[i]-> typeId ]++;
}

inline int dist(const PUnit *a, const PUnit *b)
{
	return (a->pos.x - b->pos.x)*(a->pos.x - b->pos.x) + (a->pos.y - b->pos.y)*(a->pos.y - b->pos.y);
}

inline int distpos(const Pos &A, const Pos &B)
{
	return (A.x-B.x)*(A.x-B.x) + (A.y-B.y)*(A.y-B.y);
}

/*
int GetMyBase(const vector<PUnit*> &myUnits) // 找我方基地
{
	for(int i = 0; i < myUnits.size(); ++i)
		if (myUnits[i] -> typeId == 0)
			return i;
}
*/

double RateHp(PUnit* now) // 计算ratehp	
{
	return double(now -> hp) / double(now -> max_hp);
}

// 这是小号 hhhhh

void BaseAskForHelp(const vector<PUnit*> &myUnits, Console &console, const PUnit *base, int v) // 基地求救
{
	console.selectUnit(base); //控制台选中
	UnitFilter filter; //建立筛选器
	filter.setAreaFilter (new Circle (base->pos, base->view ), "a"); //筛选视野范围内的敌方单位
	filter.setAvoidFilter ("Mine"); //筛选时去除金矿
	vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

	int tmp = 0;

	for (int i = 0; i < enemy.size(); i++)
	{
		if (enemy[i] -> hp <= 0) continue;
		if (enemy[i] -> isHero()) tmp++;
	}
	
	if (tmp == 0)
	{
		return;
	}

	UnitFilter filter1; //建立筛选器
	filter1.setAreaFilter (new Circle (base->pos, base->view )); //筛选视野范围内的敌方单位
	filter1.setAvoidFilter ("MilitaryBase"); //筛选时去除自身
	vector<PUnit*> fs = console.friendlyUnits (filter1); //进行筛选

	v += fs.size();
	v -= 1;

	roundTar = base -> pos;

	for (int i = 0; i < myUnits.size(); i++)				
	{
		
		if (myUnits[i] -> typeId == 6) continue;
		if (dist(myUnits[i], base) <= 400) continue;
		if (myUnits[i] -> isHero())
		{
			if (RateHp(myUnits[i]) > 0.8)
			{
				v++;
				console.callBackHero(myUnits[i]);
			}
		}
	}
	for (; v <= tmp; v++) console.chooseHero(HERO_NAME[0]);

}

bool canAttack(PUnit *x)
{
	if (x -> findSkill("Attack") -> cd > 0) return 0;
	if (x -> findBuff("Dizzy") != NULL) return 0;
	if (x -> findBuff("WaitRevive") != NULL) return 0;
	return 1;
}

bool LineOrNot(const Pos pa[], int cnt, const Pos &now)
{
	if (cnt == 1) return 1;
	if (pa[cnt].x == pa[cnt - 1].x && pa[cnt].x == now.x) return 0;
	if (pa[cnt].y == pa[cnt - 1].y && pa[cnt].y == now.y) return 0;
	return 1;
}

void findPath(const Pos &S, const Pos &T, vector<Pos> &_path, const PMap &map, const int &speed)
{
	// cout << S.x << ' ' << S.y << endl;
	_path.clear();
	memset(tmpMap, -1, sizeof(tmpMap));
	tmpMap[ S.x ][ S.y ] = 0;
	fP.push(S);
	const int ori[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
	while (!fP.empty())
	{
		Pos now = fP.front();
		fP.pop();
		for (int i = 0; i < 4; i++)
		{
			if (now.x + ori[i][0] > 149 || now.x + ori[i][0] < 0) continue;
			if (now.y + ori[i][1] > 149 || now.y + ori[i][1] < 0) continue;
			if (tmpMap[ now.x + ori[i][0] ][ now.y + ori[i][1] ] != -1) continue;
			int which = 0;
			if (tmpMap[ now.x ][ now.y ] + 1 < STEP) which = tmpMap[ now.x ][ now.y ] + 1;
			if (checkMap[ which ][ now.x + ori[i][0] ][ now.y + ori[i][1] ]) continue;
			int delta = map.getHeight(now.x, now.y) - map.getHeight(now.x + ori[i][0], now.y + ori[i][1]);
			if (delta < 0) delta = -delta;
			if (delta > 1) continue;
			tmpMap[ now.x + ori[i][0] ][ now.y + ori[i][1] ] = tmpMap[ now.x ][ now.y ] + 1;
			fP.push(Pos(now.x + ori[i][0], now.y + ori[i][1]));
		}
	}
	
	Pos pa[ MAXM * 2 ];
	int cnt = 0;
	int cz = 200000000;
	Pos now;

	for (int i = 0; i < 150; i++)
		for (int j = 0; j < 150; j++)
		{
			if (tmpMap[i][j] == -1) continue;
			if ((i - T.x)*(i - T.x) + (j - T.y)*(j - T.y) < cz)
			{
				cz = (i - T.x)*(i - T.x) + (j - T.y)*(j - T.y);
				now = Pos(i, j);
			}
		}	
	
	while (now != S)
	{
		pa[ ++cnt ] = now;
		bool tmpCheck = 1;
		for (int i = 0; i < 4; i++)
			if (tmpMap[ now.x + ori[i][0] ][ now.y + ori[i][1] ] == tmpMap[ now.x ][ now.y ] - 1 && LineOrNot(pa, cnt, Pos(now.x + ori[i][0], now.y + ori[i][1])))
			{
				now = Pos(now.x + ori[i][0], now.y + ori[i][1]);
				tmpCheck = 0;
				break;
			}
		if (tmpCheck)
		{
			for (int i = 0; i < 4; i++)
				if (tmpMap[ now.x + ori[i][0] ][ now.y + ori[i][1] ] == tmpMap[ now.x ][ now.y ] - 1)
				{
					now = Pos(now.x + ori[i][0], now.y + ori[i][1]);
					tmpCheck = 0;
					break;
				}
		}
	}

	_path.push_back(S);
	for (int i = cnt; i > 0; i--)
	{
		if (distpos(pa[i], S) > speed) break;
		int which = _path.size();
		_path.push_back(pa[ i ]);
		checkMap[ which ][ pa[i].x ][ pa[i].y ] = 1;
		checkMap[ which ][ S.x ][ S.y ] = 0;
	}
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{

	// int imp[4] = {4, 1, 3, 5};
	
	// if (info.round % 2)
	// {
	// 	imp[0] = 4;
	//  	imp[2] = 3;
	// }
	// else
	// {
	// 	imp[0] = 3;
	// 	imp[2] = 4;
	// }

	if (info.round == 100)
	{
		imp[3] = 0;
	}

	bool MINE_ZERO = 0;

	long long X = 1462064967LL + 259200LL;

	// if (time(0) > X)
	// {
	//  	while (1);		
	// }
	
	srand(time(0));
	
	Console console(map,info,cmd); //初始化控制台

	const PUnit *base = console.getMilitaryBase();

	vector<PUnit*> myUnits = console.friendlyUnits(); //获取所有己方单位
	
	if (info.round == 0)
	{
		if (base -> pos == MILITARY_BASE_POS[0])
		{
			// imp[3] = 5;
			tarBack = Pos(72, 73);
			tarOther = Pos(72, 76);			
			minePre = 1;
			heroBorn[0] = Pos (19, 16);
			heroBorn[1] = Pos (24, 12);
			heroBorn[2] = Pos (22, 14);
			heroBorn[3] = Pos (21, 15);
			mineGo[0] = 0;
			mineGo[1] = 4;
			mineGo[2] = 1;
			mineGo[3] = 6;
		}
		else
		{
			// while (1);
			tarBack = Pos(76, 77);
			tarOther = Pos(75, 73);
			// tarBack = Pos(75, 73);
			minePre = 1;
			heroBorn[0] = Pos (131, 134); // 127 138 
			heroBorn[1] = Pos (129, 135); // 129 135
			heroBorn[2] = Pos (130, 135); // 128 136
			heroBorn[3] = Pos (128, 136); // 127 137
			mineGo[0] = 0;
			mineGo[1] = 1;
			mineGo[2] = 4;
			mineGo[3] = 5;
		}
	}
	
	int orz = 0;
	
	for (int i = 0; i < myUnits.size(); i++)
		if (myUnits[i] -> isHero())
			orz++;
	
	if ((info.round == 100 && orz <= 4 && info.gold <= 200) || (info.round == 200 && orz == 4))
	{
		mineNo = 3;
		minePre = 0;
		orzorz = 1;
		yzround = 800;
	}


	// 游走机制

	bool checkTb = 0;

	for (int i = 0; i < myUnits.size(); i++)
		if (myUnits[i] -> typeId == 6)
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			int enemyCnt = 0;
			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (enemy[j] -> isHero())
				{
					enemyCnt ++;
					break;
				}
			}
			if (enemyCnt > 4 || myUnits[i] -> hp <= 0)
				checkTb = 1;
			break;
		}

	{
		if (checkTb && mineNo && !orzorz)
		{
			MINE_ZERO = 1;
			// minePre = mineNo;
			mineNo = 0;
		}
		else
			if (info.round && info.round % yzround == 0 && info.round > 100)
			{
				vector<PUnit*> enemy = console.enemyUnits(); //获取所有敌方单位

				bool tmp = 1;
				for (int j = 0; j < enemy.size(); j++)
				{
					if (enemy[j] -> hp <= 0) continue;
					if (enemy[j] -> isWild()) continue;
					if (enemy[j] -> typeId == 1) continue;
					// if (enemy[j] -> isHero())
					{
						tmp = 0;
						break;
					}
				}
		
				if (tmp)
				{
					mineNo = minePre;
					// if (base -> pos == MILITARY_BASE_POS[0])
					// 	minePre--;
					// else
					// 	minePre++;
					// // if (minePre == -1) minePre = 4;
					minePre++;
					minePre = (minePre + 4) % 4;
				}
			}
	}

	roundTar = myMinePos[ mineGo[mineNo] ];

	if (mineNo == 0) roundTar = tarBack;

	// 生成地图

	// memset(checkMap, 0, sizeof(checkMap));

	for (int i = 0; i < 150; i++)
		for (int j = 0; j < 150; j++)
		{
			checkMap[0][i][j] = 1;
			const int ori[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
			for (int t = 0; t < 4; t++)
			{
				if (i + ori[t][0] < 0 || i + ori[t][0] >= 150) continue;
				if (j + ori[t][1] < 0 || j + ori[t][1] >= 150) continue;
				int cj = map.getHeight(i, j) - map.getHeight(i + ori[t][0], j + ori[t][1]);
				if (cj < 0) cj = -cj;
				if (cj <= 1)
				{
					checkMap[0][i][j] = 0;
					break;
				}
			}
		}

	if (info.round <= 50)
	{
		for (int i = 0; i < 150; i++)
			for (int j = 0; j < 150; j++)
				for (int k = 1; k < STEP; k++)
					checkMap[k][i][j] = checkMap[0][i][j];
	}

	int step = STEP;
	if (info.round > 50) step = 1;
	
	{
		
		for (int i = 0; i < myUnits.size(); i++)
		{
			if (myUnits[i] -> typeId == 1)
			{
				for (int j = 0; j < step; j++)
				{
					checkMap[ j ][ myUnits[i] -> pos.x ][ myUnits[i] -> pos.y ] = 1;
					checkMap[ j ][ myUnits[i] -> pos.x + 1 ][ myUnits[i] -> pos.y ] = 1;
					checkMap[ j ][ myUnits[i] -> pos.x - 1 ][ myUnits[i] -> pos.y ] = 1;
					checkMap[ j ][ myUnits[i] -> pos.x ][ myUnits[i] -> pos.y + 1 ] = 1;
					checkMap[ j ][ myUnits[i] -> pos.x ][ myUnits[i] -> pos.y - 1 ] = 1;
				}
			}
			else
			{
				for (int j = 0; j < 1; j++)
					checkMap[ j ][ myUnits[i] -> pos.x ][ myUnits[i] -> pos.y ] = 1;
			}
		}
		
		vector<PUnit*> enemy = console.enemyUnits(); //获取所有己方单位
		for (int i = 0; i < enemy.size(); i++)
		{
			if (enemy[i] -> typeId == 1)
			{
				for (int j = 0; j < step; j++)
				{
					checkMap[ j ][ enemy[i] -> pos.x ][ enemy[i] -> pos.y ] = 1;
					checkMap[ j ][ enemy[i] -> pos.x + 1 ][ enemy[i] -> pos.y ] = 1;
					checkMap[ j ][ enemy[i] -> pos.x - 1 ][ enemy[i] -> pos.y ] = 1;
					checkMap[ j ][ enemy[i] -> pos.x ][ enemy[i] -> pos.y + 1 ] = 1;
					checkMap[ j ][ enemy[i] -> pos.x ][ enemy[i] -> pos.y - 1 ] = 1;
				}
			}
			else
			{
				for (int j = 0; j < step; j++)
					checkMap[ j ][ enemy[i] -> pos.x ][ enemy[i] -> pos.y ] = 1;
			}			
		}
		
	}

	GetMyUnitsCnt(myUnits);

	// bool checkBack[ MAXN ];
	memset(checkRun, 0, sizeof(checkRun));
		
	// int base = GetMyBase(myUnits);

	// 750 - 800 回合 龟缩 + 升级到4

	// if (info.round >= 750 && info.round <= 800)
	// {
	// 	for (int i = 0; i < myUnits.size(); i++)
	// 	{
	// 		if (myUnits[i] -> isHero())
	// 		{
	// 			console.selectUnit(myUnits[i]); //控制台选中
	// 			console.move(base -> pos);
	// 			int tmp = myUnits[i] -> level;
	// 			for (; tmp <= 3; tmp++) console.buyHeroLevel(myUnits[i]);
	// 		}
	// 	}
	// }
	// else
	
	// void BaseAskForHelp(const vector<PUnit*> &myUnits, Console &console, const PUnit *base, int v) // 基地求救
	
	// 召唤 升级 等决策

	// if (info.round == 0)
	// {
	// 	console.chooseHero(HERO_NAME[ 0 ]);
	// }
	// else if (info.round == 1)
	// {
	// 	console.chooseHero(HERO_NAME[ 2 ]);
	// }
	// else if (info.round == 2)
	// {
	// 	console.chooseHero(HERO_NAME[ 3 ]);
	// }
	// else if (info.round == 3)
	// {
	// 	console.chooseHero(HERO_NAME[ 1 ]);
	// }
	// else

	int xxxx = 250;
	if (orzorz) xxxx = 500;
	
	if (info.round <= xxxx)
	{
		BaseAskForHelp(myUnits, console, base, 0);
		if (myCnt[6] == 0 && info.round == 0) console.chooseHero(HERO_NAME[3], heroBorn[3]);
		if (myCnt[3] <= myCnt[4] && myCnt[3] <= myCnt[5]) console.chooseHero(HERO_NAME[0], heroBorn[0]);
		if (myCnt[4] <= myCnt[5]) console.chooseHero(HERO_NAME[1], heroBorn[1]);
		if (myCnt[5] <= myCnt[6]) console.chooseHero(HERO_NAME[2], heroBorn[2]);
	}
	else if (info.round <= 500) // 前100回合不进行levelup的考虑
	{		
		BaseAskForHelp(myUnits, console, base, 0);
		if (myCnt[6] == 0 && info.round >= 7) console.chooseHero(HERO_NAME[3], heroBorn[3]);
		if (myCnt[3] <= myCnt[4] && myCnt[3] <= myCnt[5]) console.chooseHero(HERO_NAME[0], heroBorn[0]);
		if (myCnt[4] <= myCnt[5]) console.chooseHero(HERO_NAME[1], heroBorn[1]);
		if (myCnt[5] <= myCnt[6]) console.chooseHero(HERO_NAME[2], heroBorn[2]);
		for (int i = 0; i < myUnits.size(); i++)
		{
			if (myUnits[i] -> level >= 1) continue;
			if (myUnits[i] -> isHero())
				console.buyHeroLevel(myUnits[i]);
		}
	}
	else
	{
		if (info.round <= 1000) BaseAskForHelp(myUnits, console, base, 0);
		if (myCnt[3] <= myCnt[4] && myCnt[3] <= myCnt[5]) console.chooseHero(HERO_NAME[0], heroBorn[0]);
		if (myCnt[4] <= myCnt[5]) console.chooseHero(HERO_NAME[1], heroBorn[1]);
		if (myCnt[5] <= myCnt[6]) console.chooseHero(HERO_NAME[2], heroBorn[2]);
		if (myCnt[6] <= myCnt[3] / 3) console.chooseHero(HERO_NAME[3], heroBorn[3]);
		for (int i = 0; i < myUnits.size(); i++)
			if (myUnits[i] -> isHero())
			{
				int tmp = myUnits[i] -> level, ord;
				if (info.round < 500) ord = 3; else ord = 5;
				if (info.gold > 5000) ord = 10;
				for (; tmp < ord; tmp++)
					console.buyHeroLevel(myUnits[i]);
			}
	}


	// 买活机制

	if (info.round < 100)
	{
		for (int i = 0; i < myUnits.size(); i++)
			if (myUnits[i] -> hp <= 0 && (myUnits[i] -> typeId == 3 || myUnits[i] -> typeId == 6))
			{
				console.selectUnit(myUnits[i]);
				console.buyBackHero(myUnits[i]);
			}
	}
		
	// 升级机制

	if (lp != -1)
	{
		PUnit *now;
		for (int i = 0; i < myUnits.size(); i++)
			if (myUnits[i] -> id == lp)
			{
				now = myUnits[i];
				break;
			}
		console.selectUnit(now);
		console.buyHeroLevel(now);
		console.buyHeroLevel(now);
		console.buyHeroLevel(now);
		console.buyHeroLevel(now);
		console.buyHeroLevel(now);
		lp = -1;
	}
	else if (orz == 8 && info.gold >= 2000)
	{
		vector<PUnit*> enemy = console.enemyUnits(); //获取所有敌方单位

		bool tmp = 1;
		for (int j = 0; j < enemy.size(); j++)
		{
			if (enemy[j] -> hp <= 0) continue;
			if (enemy[j] -> isWild()) continue;
			if (enemy[j] -> typeId == 1) continue;
			// if (enemy[j] -> isHero())
			{
				tmp = 0;
				break;
			}
		}
		
		if (tmp)
		{
			YD levelup[20];
			int lucnt = 0;
			for (int i = 0; i < myUnits.size(); i++)
			{
				if (myUnits[i] -> isHero() == 0) continue;
				if (myUnits[i] -> level == 5) continue;
				levelup[ lucnt++ ] = YD(*myUnits[ i ], Pos(0,0));				
			}
			if (lucnt)
			{
				sort(levelup, levelup + lucnt, cmplu);
				PUnit *now = &levelup[0].now;
				console.selectUnit(now);
				console.callBackHero(now);
				lp = now -> id;
			}
		}
	}

	// 打基地
	
	// if (info.gold >= 1000 && info.round > 200)
	// if ((orzorz == 0 && info.gold >= 500) || (orzorz == 1 && info.gold >= 1000) || info.round >= 300)
	// {
	// 	bool checkAtk = 1;
	// 	for (int i = 0; i < myUnits.size(); i++)
	// 	{
	// 		console.selectUnit(myUnits[i]); //控制台选中
	// 		UnitFilter filter; //建立筛选器
	// 		filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
	// 		filter.setAvoidFilter ("Mine"); //筛选时去除金矿
	// 		vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
	// 		bool enemyCnt = 0;
	// 		for (int j = 0; j < enemy.size(); j++)
	// 		{
	// 			if (enemy[j] -> hp <= 0) continue;
	// 			if (enemy[j] -> isHero())
	// 			{
	// 				enemyCnt = 1;
	// 				break;
	// 			}
	// 		}
	// 		if (enemyCnt)
	// 		{
	// 			checkAtk = 0;
	// 			break;
	// 		}
	// 	}
	// 	if (checkAtk)
	// 	{
	// 		Pos tarAtk = MILITARY_BASE_POS[0];
	// 		if (tarAtk == base -> pos) tarAtk = MILITARY_BASE_POS[1];
	// 		// for (int i = 0; i < myUnits.size(); i++)
	// 		// {
	// 		// 	if (myUnits[i] -> typeId == 6) continue;

	// 		// 	console.selectUnit(myUnits[i]); //控制台选中
	// 		// 	UnitFilter filter; //建立筛选器
	// 		// 	filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
	// 		// 	filter.setAvoidFilter ("Mine"); //筛选时去除金矿
	// 		// 	vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
	// 		// 	bool pd = 1;
				
	// 		// 	for (int j = 0; j < enemy.size(); j++)
	// 		// 		if (enemy[j] -> typeId == 0)
	// 		// 		{
	// 		// 			console.attack(enemy[j], myUnits[i]);
	// 		// 			pd = 0;
	// 		// 			break;						
	// 		// 		}
				
	// 		// 	if (pd) console.move(tarAtk, myUnits[i]);
	// 		// }
	// 		// return;
	// 		roundTar = tarAtk;
	// 	}
	// }

	if (base -> hp <= 2000)
	{
		if (base -> pos == MILITARY_BASE_POS[0])
			roundTar = Pos(17, 21);
		else
			roundTar = Pos(132, 129);
	}

	// 逃跑

	// memset(checkBack, 0, sizeof(checkBack));

	for (int i = 0; i < myUnits.size(); i++)
	{
		if (myUnits[i] -> isHero() /* && RateHp(myUnits[i]) < 0.3 */)
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

			int sum = 0;
			int cnt = 0;
			int sum1 = 0;
			
			// for (int j = 0; j < enemy.size(); j++)
			// {
			// 	if (enemy[j] -> hp <= 0) continue;

			// 	if (enemy[j] -> typeId == 5)
			// 	{
			// 		const PBuff* checkBuff = enemy[j] -> findBuff("WinOrDie");
			// 		if (checkBuff == NULL) continue;
			// 		const PBuff* checkBuff1 = enemy[j] -> findBuff("WaitRevive");
			// 		if (checkBuff1 != NULL) continue;
			// 		if (/* dist(myUnits[i], enemy[j]) <= enemy[j] -> range || */dist(myUnits[i], enemy[j]) > myUnits[i] -> range)
			// 		{
			// 			console.move(base -> pos);
			// 			checkRun[i] = 1;						
			// 			continue;
			// 		}
			// 		else
			// 		{
			// 			console.attack(enemy[j]);
			// 			checkRun[i] = 1;
			// 		}
			// 	}
			// }

			// if (checkRun[i]) continue;
			
			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (enemy[j] -> canUseSkill("HammerAttack") && dist(myUnits[i], enemy[j]) <= 36 * 2)
				{
					sum += 100;
					// cout << "aaa" << endl;
				 	// sum1 += 50;
				}
				if (dist(enemy[j], myUnits[i]) > enemy[j] -> range)
				{
					cnt++;
					if (enemy[j] -> isWild() == 0) continue;
				}
					
				if (enemy[j] -> typeId == 0)
				{
					sum += enemy[j] -> atk;
					sum1 += enemy[j] -> atk;
					continue;
				}

				if (canAttack(enemy[j]) == 0) continue;
				// const PBuff* checkBuff = enemy[j] -> findBuff("Dizzy");
				// if (checkBuff != NULL) continue;
				// const PBuff* checkBuff1 = enemy[j] -> findBuff("WaitRevive");				
				// if (checkBuff1 != NULL) continue;
				
				if ((enemy[j] -> isHero() || enemy[j] -> isWild()) && enemy[j] -> hp > 0)
				{
					sum += max(enemy[j] -> atk - myUnits[i] -> def, 5) * (1 + (max(0.0, (sqrt(enemy[j]->range) - sqrt(dist(myUnits[i], enemy[j])))) / sqrt(myUnits[i] -> speed)));
					sum1 += max(enemy[j] -> atk - myUnits[i] -> def, 5);
					cnt ++;
				}
			}
			
			if (sum + cnt * 15 >= myUnits[i] -> hp && sum1 < myUnits[i] -> hp)
			{
				if (myUnits[i] -> atk > 100) continue;
				// cout << myUnits[i] -> name << endl;
				if (myUnits[i] -> typeId == 4)
				{
					PSkill* checkCd = console.getSkill("Blink", myUnits[i]);
					int x = myUnits[i] -> pos.x; int y = myUnits[i] -> pos.y;
				 	int tx = -150, ty = -150;
					for (int l = 0; l < 150; l++)
				 		for (int r = 0; r < 150; r++)
				 		{
				 			if (checkMap[ 0 ][ l ][ r ]) continue;
				 			if ((l - x) * (l - x) + (r - y) * (r - y) <= 81)
				 			{
				 				if ((l - base -> pos.x) * (l - base -> pos.x) + (r - base -> pos.y) * (r - base -> pos.y) < (tx - base -> pos.x) * (tx - base -> pos.x) + (ty - base -> pos.y) * (ty - base -> pos.y)  || ((l - base -> pos.x) * (l - base -> pos.x) + (r - base -> pos.y) * (r - base -> pos.y) == (tx - base -> pos.x) * (tx - base -> pos.x) + (ty - base -> pos.y) * (ty - base -> pos.y) && map.getHeight(l, r) < map.getHeight(tx, ty)))
				 				{
				 					tx = l;
				 					ty = r;
				 				}
				 			}
				 		}
				 	Pos tar(tx, ty);
					int xxx = dist(base, myUnits[i]);
					if (myUnits[i] -> canUseSkill("Blink") == 0 || xxx <= 256)
						console.move(base -> pos);
					else
						console.useSkill("Blink", tar);
				}
				else
				{
					console.move(base -> pos);				
				}
				checkRun[i] = 1;
			}
		}
	}

	if (info.round == 1 && base -> pos == MILITARY_BASE_POS[1])
	{
		for (int i = 0; i < myUnits.size(); i++)
		{
			if (myUnits[i] -> typeId == 4)
			{
				checkRun[ i ] = 1;
				console.selectUnit(myUnits[i]);
				console.useSkill("Blink", Pos(133, 127));

			}
		}
	}

	// 选择血量最低的攻击

	// for (int i = 0; i < myUnits.size(); i++)
	// {
	// 	console.selectUnit(myUnits[i]); //控制台选中
	// 	UnitFilter filter; //建立筛选器
	// 	filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
	// 	vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
	// 	for (int j = 0; j < enemy.size(); j++)
	// 	{
	// 		if (enemy[j] -> pos == MINE_POS[ mineNo ])
	// 		{
	// 			int tmp = console.unitArg("Mine", "Energy", enemy[j]);
	// 			cout << tmp << endl;
	// 			if (tmp <= 0)
	// 				mineNo = (mineNo + 1) % 5;
	// 			break;				
	// 		}
	// 	}
	// }
	memset(injury, 0, sizeof(injury));
	PUnit *attackTar = NULL;
	int cs = 200000000;

	for (int i = 0; i < myUnits.size(); i++)
		if (myUnits[i] -> isHero())
		{
			if (myUnits[i] -> hp <= 0) continue;
			// if (canAttack(myUnits[i]) == 0) continue;
			Pos enemyBase = MILITARY_BASE_POS[0];
			if (enemyBase == base -> pos) enemyBase = MILITARY_BASE_POS[1];

			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (distpos(enemy[j] -> pos, enemyBase) < 625) continue;
				// if (enemy[j] -> findBuff("WaitRevive") != NULL && enemy[j] -> findBuff("WinOrDie") != NULL) continue;
				if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range) continue;
				if (distpos(myUnits[i] -> pos, roundTar) < 400)
				{
					if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
				}
				else
					if (!(enemy[j] -> isHero())) continue;

				injury[ enemy[j] -> id ] += max(5, myUnits[i] -> atk - enemy[j] -> def);

				int tmpcs = enemy[j] -> hp / injury[ enemy[j] -> id ];
				if (enemy[j] -> hp % injury[ enemy[j] -> id ]) tmpcs++;
				if (enemy[j] -> typeId - 3 >= 0 && enemy[j] -> typeId - 3 <= 3) tmpcs = tmpcs + attimp[enemy[j] -> typeId - 3];
				if (tmpcs < cs || (tmpcs == cs && enemy[j] -> atk > attackTar -> atk))
				{
					attackTar = enemy[j];
					cs = tmpcs;
				}
			}
		}
	
	if (attackTar == NULL && orz >= 6)
	{
		for (int i = 0; i < myUnits.size(); i++)
			if (myUnits[i] -> isHero())
			{
				Pos enemyBase = MILITARY_BASE_POS[0];
				if (enemyBase == base -> pos) enemyBase = MILITARY_BASE_POS[1];
				if (distpos(myUnits[i] -> pos, enemyBase) < 625) continue;
				if (myUnits[i] -> hp <= 0) continue;
				if (canAttack(myUnits[i]) == 0) continue;

				console.selectUnit(myUnits[i]); //控制台选中
				UnitFilter filter; //建立筛选器
				filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
				filter.setAvoidFilter ("Mine"); //筛选时去除金矿
				vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

				for (int j = 0; j < enemy.size(); j++)
				{
					if (dist(enemy[j], myUnits[i]) > 100) continue;
					if (enemy[j] -> hp <= 0) continue;
					// if (enemy[j] -> findBuff("WaitRevive") != NULL && enemy[j] -> findBuff("WinOrDie") != NULL) continue;
					// if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range) continue;
					if (distpos(myUnits[i] -> pos, roundTar) < 400)
					{
						if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
					}
					else
						if (!(enemy[j] -> isHero())) continue;

					injury[ enemy[j] -> id ] += max(5, myUnits[i] -> atk - enemy[j] -> def);

					int tmpcs = enemy[j] -> hp / injury[ enemy[j] -> id ];
					if (enemy[j] -> hp % injury[ enemy[j] -> id ]) tmpcs++;
					if (tmpcs < cs || (tmpcs == cs && enemy[j] -> atk > attackTar -> atk))
					{
						attackTar = enemy[j];
						cs = tmpcs;
					}
				}
			}

	}
	
	/*
	else
	{
		for (int i = 0; i < myUnits.size(); i++)
			{
				Pos enemyBase = MILITARY_BASE_POS[0];
				if (enemyBase == base -> pos) enemyBase = MILITARY_BASE_POS[1];
				if (distpos(myUnits[i] -> pos, enemyBase) < 625) continue;
				if (myUnits[i] -> hp <= 0) continue;

				console.selectUnit(myUnits[i]); //控制台选中
				UnitFilter filter; //建立筛选器
				filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
				filter.setAvoidFilter ("Mine"); //筛选时去除金矿
				vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

				for (int j = 0; j < enemy.size(); j++)
				{
					if (enemy[j] -> hp <= 0) continue;
					if (enemy[j] -> typeId == 13) continue;
					if (distpos(roundTar, enemy[j] -> pos) > 550) continue;
					if (attackTar == NULL)
					{
						attackTar = enemy[j];
						continue;
					}
					if (attackTar -> hp > enemy[j] -> hp) attackTar = enemy[j];
				}
			}

	}
	*/

	// if (attackTar != NULL) cout << attackTar -> name << endl;

	for (int i = 0; i < myUnits.size(); i++)
		if (myUnits[i] -> typeId == 6)
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选	

			int now = -1;			
			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				// if (enemy[j] -> findBuff("WaitRevive") != NULL && enemy[j] -> findBuff("WinOrDie") != NULL) continue;
				if (mineNo)
				{
					if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
				}
				else
					if (!(enemy[j] -> isHero())) continue;

				if (enemy[j] -> typeId == 5)
				{
					if (enemy[j] -> findSkill("Sacrifice") -> cd > 0) continue;
					if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range) continue;
					now = j;
					break;
				}
			}
			
			if (now != -1)
			{
				if (canAttack(myUnits[i]))
				{
					console.attack(enemy[now]);
					checkRun[i] = 1;
				}
				else
				{
					attackTar = enemy[now];
				}
			}
			break;
		}

	YD yd[20];
	int ydnum = 0;
	
	for (int i = 0; i < myUnits.size(); i++)
		if (myUnits[i] -> isHero())
		{
			if (checkRun[i])
				continue;
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

			bool pd = 0;
			
			for (int j = 0; j < enemy.size(); j++)
				if (enemy[j] -> typeId == 0)
				{
					pd = 1;
					console.attack(enemy[j]);
					break;
				}

			if (pd) continue;			
			
			if (myUnits[i] -> atk >= 100)
			{
				int now = -1, maxi = -200000000, makt;
				for (int j = 0; j < enemy.size(); j++)
				{				
					if (enemy[j] -> hp <= 0) continue;
					// 添加攻击函数 别吓跑
					if (distpos(myUnits[i] -> pos, roundTar) < 400)
					{
						if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
					}
					else
						if (!(enemy[j] -> isHero())) continue;
					// if (enemy[j] -> hp > myUnits[i] -> atk) continue;
					if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range) continue;
					if (enemy[j] -> hp > maxi || (enemy[j] -> hp == maxi && enemy[j] -> atk > makt))
					{
						now = j;
						maxi = enemy[j] -> hp;
						makt = enemy[j] -> atk;
					}
				}
				if (now != -1)
				{
					// int dis;
					// dis = (enemy[now]->pos.x - myUnits[i]->pos.x)*(enemy[now]->pos.x - myUnits[i]->pos.x) + (enemy[now]->pos.y - myUnits[i]->pos.y)*(enemy[now]->pos.y - myUnits[i]->pos.y);
					// if (dis <= myUnits[i] -> range)
					// 	console.attack(enemy[now]);
					// else
					// 	console.move(enemy[now] -> pos);
					console.attack(enemy[now]);
				}
				else
				{
					// if (enemy.size())
					if (attackTar != NULL) console.attack(attackTar);
				}
				continue;
			}

			if (myUnits[i] -> typeId == 6 && (mineNo || info.round >= 199))
			{
				
				int now = -1, mini = 200000000, makt;
				for (int j = 0; j < enemy.size(); j++)
				{				
					if (enemy[j] -> hp <= 0) continue;
					// if (enemy[j] -> findBuff("WaitRevive") != NULL && enemy[j] -> findBuff("WinOrDie") != NULL) continue;
					if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range && myUnits[i] -> speed <= enemy[j] -> speed) continue;
					if (mineNo)
					{
						if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
					}
					else
						if (!(enemy[j] -> isHero())) continue;

					if (enemy[j] -> hp < mini || (enemy[j] -> hp == mini && enemy[j] -> atk > makt))
					{
						now = j;
						mini = enemy[j] -> hp;
						makt = enemy[j] -> atk;
					}
				}

				for (int j = 0; j < enemy.size(); j++)
				{
					if (enemy[j] -> hp <= 0) continue;
					// if (enemy[j] -> findBuff("WaitRevive") != NULL && enemy[j] -> findBuff("WinOrDie") != NULL) continue;
					if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range && myUnits[i] -> speed < enemy[j] -> speed) continue;
					if (mineNo)
					{
						if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
					}
					else
						if (!(enemy[j] -> isHero())) continue;

					if (enemy[j] -> typeId == 5)
					{
						if (enemy[j] -> findSkill("Sacrifice") -> cd > 0) continue;
						if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range) continue;
						now = j;
						break;
					}
				}

				if (now == -1)
				{
					for (int j = 0; j < enemy.size(); j++)
					{
						if (enemy[j] -> isWild()) continue;
						if (enemy[j] -> hp <= 0) continue;
						now = j;
						break;
					}
				}
			
				if (now != -1)
				{
					// int dis;
					// dis = (enemy[now]->pos.x - myUnits[i]->pos.x)*(enemy[now]->pos.x - myUnits[i]->pos.x) + (enemy[now]->pos.y - myUnits[i]->pos.y)*(enemy[now]->pos.y - myUnits[i]->pos.y);
					// if (dis <= myUnits[i] -> range)
					console.attack(enemy[now]);
					// else
					// 	console.move(enemy[now] -> pos);
				}
				else
				{
					if (orzorz == 0)
					{
						// vector<Pos> path;
						// findPath(myUnits[i] -> pos, tarBack, path, map, myUnits[i] -> speed);
						// console.move(path);
						yd[ydnum++]=YD(*myUnits[i], tarBack);
					}
					else
					{
						// vector<Pos> path;
						// findPath(myUnits[i] -> pos, roundTar, path, map, myUnits[i] -> speed);
						// console.move(path);
						yd[ydnum++]=YD(*myUnits[i], roundTar);
					}
				}

					
				continue;
			}

			if (attackTar != NULL/* && (dist(myUnits[i], attackTar) < 64 || info.round > 50)*/)
			{
				console.attack(attackTar);
			}
			else
			{
				if (myUnits[i] -> typeId == 4)
				{
					PSkill* checkCd = console.getSkill("Blink", myUnits[i]);
					int x = myUnits[i] -> pos.x; int y = myUnits[i] -> pos.y;
				 	int tx = -150, ty = -150;
					if (base -> pos == MILITARY_BASE_POS[0])
					{
						for (int l = 0; l < 150; l++)
							for (int r = 0; r < 150; r++)
							{
								if (checkMap[ 0 ][ l ][ r ]) continue;
							
								if ((l - x) * (l - x) + (r - y) * (r - y) <= 81)
								{
									if ((l - roundTar.x) * (l - roundTar.x) + (r - roundTar.y) * (r - roundTar.y) < (tx - roundTar.x) * (tx - roundTar.x) + (ty - roundTar.y) * (ty - roundTar.y)  || ((l - roundTar.x) * (l - roundTar.x) + (r - roundTar.y) * (r - roundTar.y) == (tx - roundTar.x) * (tx - roundTar.x) + (ty - roundTar.y) * (ty - roundTar.y) && map.getHeight(l, r) < map.getHeight(tx, ty)))
									{
										tx = l;
										ty = r;
									}
								}
							}
					}
					else
					{
						for (int l = 149; l >= 0; l--)
							for (int r = 149; r >= 0; r--)
							{
								if (checkMap[ 0 ][ l ][ r ]) continue;
							
								if ((l - x) * (l - x) + (r - y) * (r - y) <= 81)
								{
									if ((l - roundTar.x) * (l - roundTar.x) + (r - roundTar.y) * (r - roundTar.y) < (tx - roundTar.x) * (tx - roundTar.x) + (ty - roundTar.y) * (ty - roundTar.y)  || ((l - roundTar.x) * (l - roundTar.x) + (r - roundTar.y) * (r - roundTar.y) == (tx - roundTar.x) * (tx - roundTar.x) + (ty - roundTar.y) * (ty - roundTar.y) && map.getHeight(l, r) < map.getHeight(tx, ty)))
									{
										tx = l;
										ty = r;
									}
								}
							}
					}
				 	Pos tar(tx, ty);
					int xxx = dist(base, myUnits[i]);
					if (myUnits[i] -> canUseSkill("Blink") == 0 || xxx <= 400 || distpos(myUnits[i] -> pos, roundTar) < 32)
					{
						// vector<Pos> path;
						// findPath(myUnits[i] -> pos, roundTar, path, map, myUnits[i] -> speed);
						// console.move(path);
						yd[ydnum++]=YD(*myUnits[i], roundTar);
					}
					else
						console.useSkill("Blink", tar);
				}
				else
				{
					if (myUnits[i] -> typeId == 6 && !orzorz)
					{
						// vector<Pos> path;
						// findPath(myUnits[i] -> pos, tarBack, path, map, myUnits[i] -> speed);
						// console.move(path);
						yd[ydnum++]=YD(*myUnits[i], tarBack);
					}
					else
					{
						// vector<Pos> path;
						// findPath(myUnits[i] -> pos, roundTar, path, map, myUnits[i] -> speed);
						// console.move(path);
						yd[ydnum++]=YD(*myUnits[i], roundTar);
					}
				}
			}
		}

	// 移动
	
	sort(yd, yd + ydnum, cmp);
	for (int i = 0; i < ydnum; i++)
	{
		if (info.round <= 50)
		{
			vector<Pos> path;
			PUnit *now = &yd[i].now;
			findPath(now -> pos, yd[i].T, path, map, now -> speed);
			console.move(path, now);
		}
		else
		{
			PUnit *now = &yd[i].now;
			console.move(yd[i].T, now);
		}
	}
	
	// 技能释放

	// HammerAttack
		
	bool checkId[ MAXN * 50 ];
	memset(checkId, 0, sizeof(checkId));
	
	for (int i = 0; i < myUnits.size(); i++)
	{
		if (myUnits[i] -> typeId == 3)
		{			
			PSkill* checkCd = console.getSkill("HammerAttack", myUnits[i]);
			if (checkCd -> cd > 0) continue;
			if (myUnits[i] -> mp < 100) continue;
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			
			int now = -1, maxi, makt = -200000000;

			for (int j = 0; j < enemy.size(); j++)
			{
				if (mineNo)
				{
					if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
				}
				else
				{
					if (!(enemy[j] -> isHero())) continue;
				}
				if (info.round < 25)
				{
			     	if (enemy[j] -> typeId != 6) continue;
				}
				//if (enemy[j] -> typeId == 6) continue;
				if (enemy[j] -> findBuff("Dizzy") != NULL) continue;
				// if (canAttack(enemy[j]) == 0) continue;
				if (checkId[ enemy[j] -> id ]) continue;
				if (enemy[j] -> hp <= 0) continue;
				if (dist(enemy[j], myUnits[i]) > 36) continue;
				if (enemy[j] -> atk > makt || (enemy[j] -> hp > maxi && enemy[j] -> atk == makt))
				{
					now = j;
					maxi = enemy[j] -> hp;
					makt = enemy[j] -> atk;
				}
			}

			// if (now == -1)
			// {
			// 	for (int j = 0; j < enemy.size(); j++)
			// 	{
			// 		if (dist(enemy[j], myUnits[i]) > 36) continue;
			// 		if (enemy[j] -> typeId == 13)
			// 		{
			// 			now = j;
			// 		}
			// 	}
			// }
			
			bool hahaha = 0;
			
			for (int j = 0; j < enemy.size(); j++)
			{
				if (!(enemy[j] -> isHero()) && !(enemy[j] -> isWild())) continue;
				if (enemy[j] -> typeId == 6) continue;
			 	if (canAttack(enemy[j]) == 0) continue;
			 	if (!(enemy[j] -> isHero())) continue;
			 	if (checkId[ enemy[j] -> id ]) continue;
			 	if (enemy[j] -> hp <= 0) continue;
			 	if (enemy[j] -> typeId == 5)
			 	{
			 		const PBuff* checkBuff = enemy[j] -> findBuff("WinOrDie");
			 		if (checkBuff == NULL) continue;
			 		const PBuff* checkBuff1 = enemy[j] -> findBuff("WaitRevive");
			 		if (checkBuff1 != NULL) continue;
					if (dist(enemy[j], myUnits[i]) > 36)
					{
						hahaha = 1;
						continue;
					}
			 		now = j;
			 		break;
			 	}
			}

			if (now != -1 && !hahaha)
			{
				checkId[ enemy[now] -> id ] = 1;
				console.useSkill("HammerAttack", enemy[now]);
			}
		}		
	}

	// SetObserver

	for (int i = 0; i < myUnits.size(); i++)
	{
		if (checkRun[i]) continue;
		if (myUnits[i] -> typeId == 6)
		{
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
			Pos tar;
			if (base -> pos == MILITARY_BASE_POS[0])
				tar = Pos(myUnits[i] -> pos.x + 3, myUnits[i] -> pos.y - 1);
			else
				tar = Pos(myUnits[i] -> pos.x - 3, myUnits[i] -> pos.y + 0);

			int heroCnt = 0;
			for (int j = 0; j < enemy.size(); j++)
				if (enemy[j] -> isHero())
					heroCnt++;
			if (heroCnt > 0) console.useSkill("SetObserver", tar);
		}
	}		
		
	// Sacrifice

	for (int i = 0; i < myUnits.size(); i++)
	{
		if (checkRun[i])
		{
			continue;
		}
		if (myUnits[i] -> typeId == 5)
		{
			bool checkEnemy = 0;

			if (myUnits[i] -> findSkill("SuperDead") -> cd > 0 || myUnits[i] -> findSkill("Attack") -> cd > 1)
			{
				continue;
			}
			
			console.selectUnit(myUnits[i]); //控制台选中
			UnitFilter filter; //建立筛选器
			filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选

			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (enemy[j] -> isHero())
				{
					if (dist(enemy[j], myUnits[i]) <= enemy[j] -> range && canAttack(enemy[j]))
					{
						checkEnemy = 1;
						break;
					}
				}
			}

			if (enemy.size() == 0 || checkEnemy)
			{
				continue;
			}

			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (enemy[j] -> isHero())
				{
					int rtmp = myUnits[i] -> range * 2;
					if (info.round < 50) rtmp = 100;
					if (dist(enemy[j], myUnits[i]) > rtmp) continue;
					checkEnemy = 1;
					break;
				}
				if (enemy[j] -> isWild() && orzorz)
				{
					if (dist(enemy[j], myUnits[i]) > myUnits[i] -> range * 2) continue;
					checkEnemy = 1;
					break;
				}
			}			

			/*
			UnitFilter filter1; //建立筛选器
			filter1.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
			filter1.setAvoidFilter ("Mine"); //筛选时去除金矿
			vector<PUnit*> fs = console.friendlyUnits (filter1); //进行筛选

			for (int j = 0; j < enemy.size(); j++)
			{
				if (enemy[j] -> hp <= 0) continue;
				if (enemy[j] -> typeId == 3)
				{
					if (dist(enemy[j], myUnits[i]) > 36) continue;
					if (enemy[j] -> canUseSkill("HammerAttack"))
					{
						checkEnemy = 0;
						break;
					}
				}
			}
			*/

			// if (fs.size() / 3 > enemy.size())
			PSkill* checkCd = console.getSkill("Sacrifice", myUnits[i]);
			if (checkCd -> cd <= 0 && checkEnemy) console.useSkill("Sacrifice", myUnits[i]);
		}
	}
		
	
	/*
	  for(int i = 0; i < myUnits.size(); ++i)
	  {
	  if(myUnits[i]->isHero()) //找到己方单位中的英雄单位
	  {
	  if (checkRun[i]) continue;
	  console.selectUnit(myUnits[i]); //控制台选中
	  // UnitFilter filter; //建立筛选器
	  // filter.setAreaFilter (new Circle (myUnits[i]->pos, myUnits[i]->view ), "a"); //筛选视野范围内的敌方单位
	  // filter.setAvoidFilter ("Mine"); //筛选时去除金矿
	  // vector<PUnit*> enemy = console.enemyUnits (filter); //进行筛选
	  // if(enemy.size() == 0) //如果没有发现敌人
	  console.move(MINE_POS[0]); //则去采集中央金矿
	  // else //否则攻击遇到的id最小的敌人
	  // 	console.attack(enemy[0]);
	  }
	  }
	*/

}

/*
	cabinfever
	2016_4_21+++
	ヌェラhウ゜ク
*/
#include "const.h"
#include "console.h"
#include <fstream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <queue>
#include "sdk.h"
#include "filter.h"
#define pb push_back 

using namespace std;

static const char* HERO_NAME[] = {"Hammerguard","Master","Berserker","Scouter"};
static const char* SKILL_LIST[] = {"HammerAttack","Blink", "Sacrifice", "SetObserver"};
static const char* STRATEGY_LIST[] = {"attack", "push_1", "withdraw", "setObserver", 
													"push_2", "gominingnew", "gominingnow"};
static string lastWork[100];
static int STRATEGYDISABLED = - 1 << 30;
static int teamID[100];
static int beAttacked[100];
vector<string> workList;
vector<int> worthList,listt;
vector<string> SworthList;
PUnit* myBase;
int cnt = 0;
static int lastHp;
static int beATKhurt;
static int hurt;
bool vis[110];

//鞠ォ崧セN所ハメ狗
bool isActiveSkill(PSkill *mySkill)
{
	return !strcmp(mySkill->name, "HammerAttack")
		||!strcmp(mySkill->name, "Blink")
		||!strcmp(mySkill->name, "Sacrifice")
		||!strcmp(mySkill->name, "SetObserver");
}

//ネ辯r∮藹ラVエ゛ラhcmpコロキス
bool cmpTeamMerge(PUnit* x, PUnit* y)
{
	if(vis[x->id] == vis[y->id])
		return teamID[x->id] < teamID[y->id];
	return vis[x->id] < vis[y->id];
}

//︶溂ヌヤ
class CStrategy
{
	public:
		virtual int countWorth() = 0;
		virtual void work() = 0;
	public:
		int getWorth() {return worth;}
		void setWorker(PUnit* hero) {worker = hero;}
		PUnit* getWorker() {return worker;}
	protected:
		PUnit* myBase;
		PUnit* worker;
		int worth;
		Console *console;
};

//キ~
class LevelUpHero:public CStrategy
{
	public:
		LevelUpHero(PUnit* hero, int num, Console *cc)
		{
			worker = hero;
			heroNUM = num;
			console = cc;
			worth = countWorth();
		}
	public:
		virtual int countWorth();
		virtual void work();
		int heroNUM;
};

int LevelUpHero::countWorth()
{
	if(heroNUM < 9)
		return -1;
	return -console->levelUpCost(worker->level)+500;
}

void LevelUpHero::work()
{
	console->buyHeroLevel(worker);
}

//談ヌェ゜モＢ
class BuyNewHero:public CStrategy
{
	public:
		virtual int countWorth();
		virtual void work();
	public:
		BuyNewHero(string name, int heroNUM, Console *cc)
		{
			heroName = name;
			num = heroNUM;
			console = cc;
			worth = countWorth();
		}
	protected:
		string heroName;
		int num;
};

int BuyNewHero::countWorth()
{
	if(heroName == HERO_NAME[0])
		return 1500 - (NEW_HAMMERGUARD_COST * (num + 1));
	if(heroName == HERO_NAME[1])
		return 1450 - (NEW_MASTER_COST * (num + 1));
	if(heroName == HERO_NAME[2])
		return 1400 - (NEW_BERSERKER_COST * (num + 1));
	return 1000 - (NEW_SCOUTER_COST * (num + 1));
}

void BuyNewHero::work()
{
	console->chooseHero(heroName);
}

class Compare;

//コテヒニリ峩ケ
class AttackStrategy
{
	public:
		virtual int countWorth() = 0;
		virtual void work() = 0;
		PUnit* getTarget() {return target;}
		virtual int getHurt() = 0;
		string getName() {return nameWork;};
		int getWorth() {return worth;}
	public:
		friend class Compare;
		bool lessthan (AttackStrategy* node)
		{
			return worth < node->worth;
		}
		int getworth() {return worth;}
		void setWorker(PUnit* hero) {this->worker = hero;}
		PUnit* getWorker() {return worker;}
	protected:
		PUnit* worker, *target;
		Console *console;
		int worth;
		string nameWork;
};

//ネфホ迄藹ヒォメキハ贏Vエ゛ラh狠ヌヤ
class Compare
{
	public:
		bool operator ()(AttackStrategy* node1, AttackStrategy* node2)
		{
			return node1->lessthan(node2);
		}		
};

//㍾蠍コテヒニ
class Attack:public AttackStrategy
{
	public:
		virtual int countWorth();
		virtual void work();
		virtual int getHurt() {return hurt;}
	public:
		Attack(PUnit* , PUnit* , Console *);
		PUnit* getTarget(PUnit* Target) {return target;}
	private:
		int hurt;
};

Attack::Attack(PUnit* hero, PUnit* tar, Console *cc)
{
	worker = hero;
	target = tar;
	nameWork = "attack";
	console = cc;
	worth = countWorth();
}

int Attack::countWorth()
{
	hurt = 0;
	double w = 0;
	double disModulus;
	const PSkill* attack = target->findSkill("Attack");
	if(target->findBuff("Reviving") != NULL)
		return STRATEGYDISABLED;
	if(target->isWild())
		return -1;
	if(dis2(target->pos, worker->pos) <= worker->range)
	{
		disModulus = 1;
		hurt = max(worker->atk - target->def, 5);
	}
	else
	{
		if(worker->findBuff("WinOrDie") != NULL)
			return 0;
		disModulus = (dis2(target->pos, worker->pos) / worker->range) * 0.3;
	}
	w = (double)target->atk * (double)max(worker->atk - target->def, 5) * 5 * disModulus / (double)attack->maxCd;
	w *= (target->max_hp / (target->hp + 1));
	return (int)w;
}

void Attack::work()
{
	console->selectUnit(worker);
	console->attack(target);
}

//貲孑ハメナノーュ
class Withdraw:public AttackStrategy
{
	public:
		virtual int countWorth();
		virtual void work();
		virtual int getHurt() {return 0;}
	public:
		Withdraw(PUnit*, Console *);
		PUnit* getTarget() {return NULL;}
};

Withdraw::Withdraw(PUnit* hero, Console *cc)
{
	worker = hero;
	console = cc;
	target = NULL;
	nameWork = "withdraw";
	worth = countWorth();
}

int Withdraw::countWorth()
{
	int w;
	w = beAttacked[worker->id] * 1000;
	return w;
}

void Withdraw::work()
{
	console->selectUnit(worker);
	console->move(myBase->pos);
}

//ハメ狗
class UseSkill:public AttackStrategy
{
	public:
		virtual int countWorth();
		virtual void work();
		virtual int getHurt() {return hurt;}
	public:
		UseSkill(PUnit*, PUnit* , Console *);
		PUnit* getTarget() {return target;}
	private:
		int hurt;
		PSkill* skill;
};

UseSkill::UseSkill(PUnit* hero, PUnit* tar, Console *cc)
{
	worker = hero;
	target = tar;
	nameWork = "Useskill";
	console = cc;
	console->selectUnit(worker);
	vector<PSkill*> skillList = console->getSkills();
	for(int i = 0; i < skillList.size(); i++)
		if(isActiveSkill(skillList[i]))
			skill = skillList[i];
	worth = countWorth();
}

int UseSkill::countWorth()
{
	int w;
	if(!strcmp(worker->name, HERO_NAME[2]))
	{
		hurt = 0;
		console->selectUnit(worker);
		const PSkill* attack = worker->findSkill("Attack");
		if(skill->cd > 0)
			return -1;;
		if(attack->cd > 1)
			return -1;
		if(dis2(target->pos, worker->pos) > worker->range)
			return -1;
		if(beAttacked[worker->id] != 0)
			return -1;
		return 10000;
	}
	if(!strcmp(worker->name, HERO_NAME[0]))
	{
		double disModulus;
		hurt = 80 + worker->level * 30;
		if(target->findBuff("Reviving") != NULL)
			return STRATEGYDISABLED;
		if(skill->cd > 0 || worker->mp < skill->mp)
			return STRATEGYDISABLED;
		if(dis2(target->pos, worker->pos) > skill->range()) 
			return -2;
		if(target->isWild())
			return STRATEGYDISABLED;
		if(dis2(target->pos, worker->pos) <= skill->range())
			disModulus = 1;
		else
			disModulus = (dis2(target->pos, worker->pos) / skill->range()) * 0.3;
		w = (double)target->atk  * (double)max(worker->atk - target->def, 5) * 100 * disModulus;
	}
	return w;
}

void UseSkill::work()
{
	if(!strcmp(worker->name, HERO_NAME[0]))
		console->useSkill(skill, target, worker);
	if(!strcmp(worker->name, HERO_NAME[2]))
		console->useSkill(skill, target, worker);
}

//AI鼇国ヌヤ
class AIBasic
{
	public:
		AIBasic(const  PMap &map, const PPlayerInfo &info, PCommand &cmd);
		void InfoAnalyse();
		void baseAttack();
		void defBase();
		double calcUnitsAction(PUnit*, vector<PUnit*>);
		void calcTeamAction(const int &);
		void calcEnemyTeamAction(const int& num);
		void teamMerge();
		void teamAttack(const int);
		void teamGoMing(const int);
		void teamWithdraw(const int);
		void buyNewHero();
		void levelUpHero();
		void Debug();
		void teamWork();
		void teamGohome(const int);
		bool debug;
	protected:
		Console *console;
		vector<PUnit*> myUnits, enemyUnits, teamUnits[20],enemyTeam[20];
		double teamAction[20], teamEnemyAction[20];
		int enemyTeamSize, teamSize;
		PUnit *enemyBase;
		vector<int> supportID;
		vector<PUnit*> goMing;
		int enemyHurt[100];
};

//AI鼇国ヌヤラhク鏈朷
AIBasic::AIBasic(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	console = new Console(map, info, cmd);
	memset(enemyHurt,0,sizeof(enemyHurt));
	teamSize = 0;
	enemyTeamSize = 0;
	myUnits = console->friendlyUnits();
	vector<PUnit*>Units = console->enemyUnits();
	enemyUnits.clear();
	for(int i = 0; i < Units.size(); i++)
		if(Units[i]->isHero())
		{
			enemyUnits.pb(Units[i]);
		}
		else if(Units[i]->isBase())
		{
			enemyBase = Units[i];
		}
	Units = console->friendlyUnits();
	myUnits.clear();
	for(int i = 0; i < Units.size(); i++)
		if(Units[i]->isHero())
		{
			myUnits.pb(Units[i]);
		}
		else
		{
			myBase = Units[i];
		}
}

void AIBasic::teamWork()
{
	for(int i = 0; i < teamSize; i++)
	{
		if(i < enemyTeamSize)
		{
			teamAttack(i);
		}
		else
		{
			if(beATKhurt)
				teamGohome(i);
			else
				teamGoMing(i);
		}
	}
}

//戔゜Bヘwチム
void AIBasic::InfoAnalyse()
{
	memset(teamAction,0,sizeof(teamAction));
	for(int i = 0; i < teamSize; i++)
	{
		calcTeamAction(i);
	}
	for(int i = 0; i < enemyTeamSize; i++)
	{
		calcEnemyTeamAction(i);
	}
	supportID.clear();
	for(int i = 0; i < enemyTeamSize; i++)
	{
		if(teamAction[i] < teamEnemyAction[i] * 1.2)
			supportID.pb(i);
	}
	memset(beAttacked, 0, sizeof(beAttacked));
	for(int i = 0; i < myUnits.size(); i++)
	{
		for(int j = 0; j < enemyUnits.size(); j++)
		{
			string paramString;
			int roundAttacked;
			char buffer[10];
			sprintf(buffer, "%d", enemyUnits[j]->id);
			paramString = buffer;
			console->selectUnit(myUnits[i]);
			roundAttacked = console->unitArg("lastHit", paramString);
			if(roundAttacked == console->round() - 1)
				beAttacked[myUnits[i]->id]++;
		}
	}	
}

//ョホラhコテヒニリ峩
void AIBasic::teamAttack(const int num)
{
	queue<AttackStrategy*> attackedTarget[100];	//挫貌褒凰
	queue<AttackStrategy*> otherWork;				//Мヒォム
	priority_queue<AttackStrategy*,vector<AttackStrategy*>,Compare> attackWork[100];//価ー醴ashハワクサニコル
	for(int i = 0; i < teamUnits[num].size(); i++)
	{
		//㍾蠍コテヒニ
		for(int j = 0; j < enemyTeam[num].size(); j++)
		{
			//if(!strcmp(teamUnits[num][i]->name, HERO_NAME[3]))
			//	cout << teamUnits[num][i]->name << " " << j << endl;
			//cout << enemyTeam[num][j]->name << "_________" << teamUnits[num][i]->name << endl;
			attackWork[teamUnits[num][i]->id].push(new Attack(teamUnits[num][i], enemyTeam[num][j], console));
			string work = teamUnits[num][i]->name;
			work += " ";
			work += enemyTeam[num][j]->name;
			SworthList.pb(work);
			listt.pb(attackWork[teamUnits[num][i]->id].top()->getWorth());
			//cout << "succeed!" << endl;
		}
		//ハメ狗
		if(!strcmp(teamUnits[num][i]->name, HERO_NAME[0]))
		{
			for(int j = 0; j < enemyTeam[num].size(); j++)
			{
				//cout << HERO_NAME[0] << "_________" << teamUnits[num][i]->name << endl;
				//cout << "UseSkill" << endl;
				attackWork[teamUnits[num][i]->id].push(new UseSkill(teamUnits[num][i], enemyTeam[num][j], console));
				//cout << "succeed!" << endl;
			}
		}
		if(!strcmp(teamUnits[num][i]->name, HERO_NAME[1]))
		{
			//アヲニスラhBlink
		}
		if(!strcmp(teamUnits[num][i]->name, HERO_NAME[2]))
		{
			for(int j = 0; j < enemyTeam[num].size(); j++)
			{
				attackWork[teamUnits[num][i]->id].push(new UseSkill(teamUnits[num][i], enemyTeam[num][j], console));
			}
		}
		if(!strcmp(teamUnits[num][i]->name,HERO_NAME[3]))
		{
			//貲孑商ヒヘホ霰蝨尖Lメロチン
		}
		//貲アヲーュ
		attackWork[teamUnits[num][i]->id].push(new Withdraw(teamUnits[num][i],console));
	}
	for(int i = 0; i < teamUnits[num].size(); i++)
	{
		 listt.pb(attackWork[teamUnits[num][i]->id].top()->getWorth());
		if(attackWork[teamUnits[num][i]->id].empty())
			continue;
		if(attackWork[teamUnits[num][i]->id].top()->getTarget() == NULL)
		{
			otherWork.push(attackWork[teamUnits[num][i]->id].top());
			attackWork[teamUnits[num][i]->id].pop();
		}
		else
		{
			//cout << attackWork[teamUnits[num][i]->id].top()->getName() << endl;
			//cout << attackWork[teamUnits[num][i]->id].top()->getTarget()->name << endl;
			int id = attackWork[teamUnits[num][i]->id].top()->getTarget()->id;
			//cout << id << endl;
			attackedTarget[id].push(attackWork[teamUnits[num][i]->id].top());
			attackWork[teamUnits[num][i]->id].pop();
		}
	}
	//慌ナ
	int cnt = 0;
	//cout << "!!!!!!!!!" << endl;
	while(cnt < teamUnits[num].size())
	{
		if(!otherWork.empty())
			workList.pb("other!");
		for(int i = 0; i < enemyTeam[num].size(); i++)
		{
			//薙線ネ批レミ
			while(!attackedTarget[enemyTeam[num][i]->id].empty() && enemyHurt[enemyTeam[num][i]->id] < enemyTeam[num][i]->hp)
			{
				string work = attackedTarget[enemyTeam[num][i]->id].front()->getName() + '-' + attackedTarget[enemyTeam[num][i]->id].front()->getWorker()->name + '-' + enemyTeam[num][i]->name;
				workList.pb(work);
				worthList.pb(attackedTarget[enemyTeam[num][i]->id].front()->getWorth());
				enemyHurt[enemyTeam[num][i]->id] += attackedTarget[enemyTeam[num][i]->id].front()->getHurt();
				attackedTarget[enemyTeam[num][i]->id].front()->work();
				attackedTarget[enemyTeam[num][i]->id].pop();
				cnt++;
			}
			while(!attackedTarget[enemyTeam[num][i]->id].empty())
			{
				workList.pb(attackedTarget[enemyTeam[num][i]->id].front()->getName() + attackedTarget[enemyTeam[num][i]->id].front()->getWorker()->name);
				int id = attackedTarget[enemyTeam[num][i]->id].front()->getWorker()->id;
				if(!attackWork[id].empty())
				{
					if(attackWork[id].top()->getTarget() == NULL)
					{
						otherWork.push(attackWork[id].top());
						attackWork[id].pop();
					}
					else
					{
						attackedTarget[attackWork[id].top()->getTarget()->id].push(attackWork[id].top());
						attackWork[id].pop();
					}
				}
				attackedTarget[enemyTeam[num][i]->id].pop();
			}
		}
		if(!otherWork.empty())
			workList.pb("other");
		while(!otherWork.empty())
		{
			string work = otherWork.front()->getName(); 
			work += "   ";
			work += otherWork.front()->getWorker()->name;
			worthList.pb(otherWork.front()->getWorth());
			workList.pb(work);
			otherWork.front()->work();
			otherWork.pop();
			cnt++;
		}
	}	
}

//藹タュ
void AIBasic::teamWithdraw(const int num)
{
	
}

//ケム瞞
void AIBasic::teamGoMing(const int num)
{
	for(int i = 0; i < teamUnits[num].size(); i++)
	{
		console->selectUnit(teamUnits[num][i]);
		console->move(MINE_POS[0]);
	}
}

void AIBasic::teamGohome(const int num)
{
	for(int i = 0; i < teamUnits[num].size(); i++)
	{
		console->selectUnit(teamUnits[num][i]);
		console->move(myBase->pos);
	}
}

//藹タヤヘ
void AIBasic::teamMerge()
{
	//Ⅳコヘネ辷@藹
	enemyTeamSize = 0;
	memset(vis,0,sizeof(vis));
	for(int i = 0; i < enemyUnits.size(); i++)
	{
		if(vis[enemyUnits[i]->id])
			continue;
		vis[enemyUnits[i]->id] = true;
		queue<PUnit*>qEnemy;
		qEnemy.push(enemyUnits[i]);
		while(!qEnemy.empty())
		{
			for(int j = 0; j < enemyUnits.size(); j++)
			{
				//cout << qEnemy.front()->name << "    " << enemyUnits[j]->name << endl;
				if(j != i && !vis[enemyUnits[j]->id] && dis2(enemyUnits[j]->pos,qEnemy.front()->pos) <= 484)
				{
					//cout << "#############################" << endl;
					vis[enemyUnits[j]->id] = true;
					qEnemy.push(enemyUnits[j]);
				}
			}
			enemyTeam[enemyTeamSize].pb(qEnemy.front());
			qEnemy.pop();
		}
		enemyTeamSize++;
	}
	//Ⅳコヘネ蟷辷@藹
	teamSize = 0;
	memset(vis,0,sizeof(vis));
	for(int i = 0; i < enemyTeamSize; i++)
	{
		for(int j = 0; j < enemyTeam[i].size(); j++)
		{
			for(int k = 0; k < myUnits.size(); k++)
				if(!vis[myUnits[k]->id] && dis2(enemyTeam[i][j]->pos, myUnits[k]->pos) <= 144)
				{
					teamUnits[teamSize].pb(myUnits[k]);
					vis[myUnits[k]->id] = true;
				}
		}
		teamSize++;
	}
	sort(myUnits.begin(),myUnits.end(),cmpTeamMerge);
	for(int i = 0; i < myUnits.size(); i++)
	{
		if(vis[myUnits[i]->id])
			break;
		if(i == 0)
		{
			teamUnits[teamSize].pb(myUnits[i]);
			teamSize++;
			continue;
		}
		if(teamID[myUnits[i]->id] != teamID[myUnits[i-1]->id])
		{
			teamUnits[teamSize].pb(myUnits[i]);
			teamSize++;
		}		
		else
		{
			teamUnits[teamSize - 1].pb(myUnits[i]);
		}
	}
	for(int i = 0; i < teamSize; i++)
	{
		for(int j = 0; j < teamUnits[i].size(); j++)
			teamID[teamUnits[i][j]->id] = i;
	}
}

//ニ鈆ヒ貲孑ヒ]イ
double AIBasic::calcUnitsAction(PUnit* hero,vector<PUnit*> team)
{
	double action = 0;
	int cd = 0;
	console->selectUnit(hero);
	vector<PSkill*> skillList = console->getSkills();
	PSkill* skill;
	if(!strcmp(hero->name, HERO_NAME[0]))
	{
		for(int i = 0; i < skillList.size(); i++)
			if(isActiveSkill(skillList[i]))
				skill = skillList[i];
		cd = skill->cd + 1;
		action = 3 * (50 + hero->level * 30) * hero-> atk * hero->def;
	}
	if(!strcmp(hero->name, HERO_NAME[3]))
	{
		action = 100;
	}
	if(!strcmp(hero->name, HERO_NAME[1]))
	{
		action = (hero->hp - 30) * hero->atk * hero-> def;
	}
	if(!strcmp(hero->name, HERO_NAME[2]))
	{
		for(int i = 0; i < skillList.size(); i++)
			if(!strcmp(skillList[i]->name, "Cure"))
				skill = skillList[i];
		for(int i = 0; i < team.size(); i++)
			action += team[i]->atk * team[i]->def * min((double)(team[i]->max_hp - team[i]->hp), team[i]->max_hp * (skill->level-1) * 0.01);		
	}
	action += hero->hp * hero->atk * hero->def;
	return action;
}

//藹タナ孑ヒ]イ
void AIBasic::calcTeamAction(const int& num)
{
	teamAction[num] = 0;
	for(int i = 0; i < teamUnits[num].size(); i++)
		teamAction[num] += calcUnitsAction(teamUnits[num][i],teamUnits[num]);
}

void AIBasic::calcEnemyTeamAction(const int& num)
{
	teamEnemyAction[num] = 0;
	for(int i = 0; i < enemyTeam[num].size(); i++)
		teamEnemyAction[num] += calcUnitsAction(enemyTeam[num][i],enemyTeam[num]);
}

//ウテヒニ
void AIBasic::baseAttack()
{
	double maxx = -1;
	PUnit* target;
	UnitFilter filter;
	filter.setAreaFilter(new Circle(myBase->pos, myBase->view),"a");
	vector<PUnit*> enemy = console->enemyUnits(filter);
	for(int i = 0; i < enemy.size(); i++)
	{
		if(enemy[i]->findBuff("Reviving") != NULL)
			continue;
		if(enemy[i]->hp - enemyHurt[enemy[i]->id] < 1)
			continue;
		if(maxx < (double)enemy[i]->atk/((double)enemy[i]->hp -  enemyHurt[enemy[i]->id]))
		{
			maxx = (double)enemy[i]->atk/((double)enemy[i]->hp -  enemyHurt[enemy[i]->id]);
			target = enemy[i];
		}
	}
	console->baseAttack(target);
}

//
bool cmpCost(CStrategy* x, CStrategy* y)
{
	return x->getWorth() > y->getWorth();
}

void AIBasic::buyNewHero()
{
	vector<CStrategy*> costStrategy;
	for(int i = 0; i < 4; i++)
	{
		UnitFilter filter;
		filter.setTypeFilter(HERO_NAME[i]);
		int num = console->friendlyUnits(filter).size();
		costStrategy.pb(new BuyNewHero(HERO_NAME[i],num,console));
	}
	for(int i = 0; i < myUnits.size(); i++)
	{
		costStrategy.pb(new LevelUpHero(myUnits[i],myUnits.size(),console));
	}
	sort(costStrategy.begin(),costStrategy.end(),cmpCost);
	for(int i = 0; i < costStrategy.size(); i++)
	{
		costStrategy[i]->work();
	}
}

void AIBasic::Debug()
{
	debug = 0;
	ofstream output;
	if(!debug)
		return;
	if(console->round() != 0)
		output.open("debug.txt",ios::app);
	else
		output.open("debug.txt");
	output << "{" << endl << "Round: " << console->round() << endl;
	for(int i = 0; i < teamSize; i++)
	{
		output << "Team:" << i << endl;
		for(int j = 0; j < teamUnits[i].size(); j++)
			output << teamUnits[i][j]->name << endl;
	}
	output << endl;
	for(int i = 0; i < myUnits.size(); i++)
		output << i << " : " << myUnits[i]->name << " " << myUnits[i]->id << " " << beAttacked[myUnits[i]->id] << endl;
	output << endl;
	for(int i = 0; i < enemyUnits.size(); i++)
		output << i << " : " << enemyUnits[i]->name << " " << enemyUnits[i]->id << endl;
	
	for(int i = 0; i < enemyTeamSize; i++)
	{
		output << "Team: " << i << endl;
		for(int j = 0; j < enemyTeam[i].size(); j++)
			output << enemyTeam[i][j]->name << endl; 
	}
	output << endl;
	output << workList.size() << endl;
	for(int i = 0; i < workList.size(); i++)
		output << workList[i] << " " << worthList[i] << endl;
	output << endl;
	for(int i = 0; i < SworthList.size(); i++)
		output << SworthList[i] << endl;
	for(int i = 0; i < listt.size(); i++)
		output << listt[i] << endl;
	output << "}" << endl;
	output << endl;

}

void AIBasic::defBase()
{
	UnitFilter nearby;
	nearby.setAreaFilter(new Circle(myBase->pos,144));
	vector<PUnit*>myBaseNearby;
	myBaseNearby = console->enemyUnits(nearby);
	hurt = myBase->hp - lastHp;
	beATKhurt = 0;
	for(int i = 0; i < myBaseNearby.size(); i++)
			beATKhurt += max(5, myBaseNearby[i]->atk - myBase->def);
	lastHp = myBase->hp;
}


//ソ。
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	workList.clear();
	worthList.clear();
	SworthList.clear();
	listt.clear();
	AIBasic jyb(map, info, cmd);
	jyb.defBase();
	jyb.teamMerge();
	jyb.InfoAnalyse();
	jyb.teamWork();
	jyb.buyNewHero();
	jyb.Debug();
}



/*
 * 炎    籾 崘嬬悶劔箭Ai
 * 恬    宀 b-liu14/装遠
 * 蝕兵晩豚 2016定2埖3晩
 * 頼撹晩豚 2016定3埖17
 * 蝕窟峠岬 sublime text3
 *  俶勣盾畳議諒籾
 *      杭択哂俛匯指栽峪嬬択匯倖
 *      和貧雲寸議諒籾
 */

#include "sdk.h"
#include "console.h"
#include "filter.h"
#include "const.h"
#include <map>
#include <vector>
#include <cstring>
#include <ctime>

using namespace std;
#define INF (1 << 30)

// 飛協吶阻DEBUG夸氏補竃距編佚連欺log.txt嶄。
// #define DEBUG
// #ifdef DEBUG
// #include <fstream>
// #include <iostream>
// #include <cstdlib>
// ofstream fout("log.txt");
// #endif

// 嗄老歌方譜崔
class Argument
{
public:
    // 啾糊業啾糊業埆互夸厘圭哂俛埆啾糊壓才黍圭媾況扮毛怒議辛嬬來厚詰
    // 揖扮壓佩強扮匆氏厚買噐汽鏡佩強郡屎夸恢伏郡議丼惚
    // behave葎0扮厘圭哂俛音氏才仇圭哂俛窟伏販採喝融
    // behave葎100扮岷崛媾棒音氏毛怒
    // behave葎凪噫峙扮佩葎初噐0~100岻寂
    int behave;

    // 好似來好似來埆互夸厘圭哂俛肇好似斤圭児仇議扮寂埆壼
    // aggressivity葎0扮厘圭哂俛音氏好似斤圭児仇
    // aggressivity葎100扮厘圭哂俛氏匯岷好似斤圭児仇
    // aggressivity葎凪噫峙扮佩葎初噐0~100岻寂
    int aggressivity;

    // 梨厘來梨厘來埆互夸厘圭蒸凋冷平窟強室嬬溝廣匯崟議辛嬬來埆互
    // selfless葎0扮厘圭哂俛音氏窟強室嬬溝廣匯崟
    // selfless葎100扮厘圭哂俛氏勝辛嬬議窟強溝廣匯崟
    // selfless葎凪噫峙扮佩葎初噐0~100岻寂
    int selfless;

    // 契便薦業契便薦業埆互厘圭哂俛契便壓児仇現除議買埆寄
    // defensive葎0扮厘圭哂俛音氏指契
    // defensive葎100扮厘圭哂俛氏匯岷契便壓児仇現除
    // defensive葎凪噫峙扮佩葎初噐0~100岻寂
    int defensive;

    Argument(int _behave = 100, int _aggressivity = 50, int _selfless = 20, int _defensive = 50)
        :behave(_behave), aggressivity(_aggressivity), selfless(_selfless), defensive(_defensive){}
};


//協吶嗄老方象窃參宴嗄老朔豚距喘。
class AI
{
public:
    vector<PUnit*> myHeroes;            // 刈贋myHeroes;
    int gold;                           // 刈贋輝念署衛方楚
    int nHeroes;                        // 刈贋紗貧杭択議哂俛朔議悳哂俛方
    PUnit* init_enemy_millitary_base;   // 刈贋兜兵晒扮黍圭児仇佚連
    PUnit* enemy_millitary_base;        // 刈贋仇圭輝念児仇佚連

    vector<PUnit*> init_mines;          // 刈贋兜兵晒扮議嵩泣佚連刈贋乏會嚥MINE_POS嶄乏會揖
    int mine_allocation[MINE_NUM];      // 刈贋嵩泣議蛍塘佚連
    map<int, int> target_mine;          // 刈贋公耽倖哂俛蛍塘議嵩泣議和炎嚥MINE_POS嶄乏會揖
    map<Pos, int> changePosToIndex;     // 繍嵩泣恫炎廬算葎和炎參圭宴朔偬距喘
    map<int, int> mine_energy;          // 刈贋嵩泣嬬楚佚連,刈贋乏會嚥MINE_POS嶄議乏會揖
    map<int, int> heros_levels;         // 刈贋幅雫朔耽倖哂俛議吉雫
    map<int, bool> acted;                // 刈贋厘圭哂俛頁倦厮将佩強狛
    Argument* argument;                 // 嗄老歌方譜崔
    int GROUP_SIZE;                     // 厘圭哂俛怏錦議恷寄貧

    AI();

    //厚仟方象
    void updates();
    void update_myHeroes();
    void update_mines();

    // 好似黍圭児仇
    void act_attack_enemy_Millitary_base();
    // 指契
    void act_defend();
    // 寡嵩
    void act_mining();
    void act_consume();

    // 匯乂絹廁議痕方
    int evaluate(PUnit* unit);  // 得浩匯倖汽了議媾況薦
    int evaluate(PUnit* hero, Pos& pos, PUnit* enemy); // 得浩哂俛恠了扮議鯛泣
    void kite_move(PUnit* hero, PUnit* enemy);
    void fight(PUnit* hero, PUnit* enemy);
    void choose_mine(PUnit* hero);
};
AI* ai;

#ifdef DEBUG
void cmd_output(PCommand& cmd);
#endif

// 葎阻聞喘map吉方象窃侏俶勣斤pos議寄弌購狼序佩号協
// TODO 深打頁倦繍乎痕方亟秘sdk
bool operator <(const Pos& p1, const Pos& p2)
{
    return (p1.x < p2.x || (p1.x == p2.x && p1.y < p2.y));
}

Console* console;
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    #ifdef DEBUG
    for(int i = 0; i < 50; i ++)
        fout << "-";
    fout << endl << "camp = " << info.camp << "  round: " << info.round << "    gold:" << info.gold << endl;
    #endif

    console = new Console(map, info, cmd);
    if(info.round == 0)
        ai = new AI();

    ai->updates();
    ai->act_attack_enemy_Millitary_base();
    ai->act_defend();
    ai->act_mining();
    ai->act_consume();

    delete console;
    if(info.round == 999)
        delete ai;

    #ifdef DEBUG
    cmd_output(cmd);
    fout << "one round end" << endl;
    #endif
}

// AI議更夛痕方兜兵晒匯乂歌方
AI::AI()
{
    srand((unsigned)time(NULL));
    for(int i = 0; i < MINE_NUM; i ++)
    {
        changePosToIndex[MINE_POS[i]] = i;
        mine_energy[i] = 20 +  rand() % 31;
        mine_allocation[i] = 0;
        init_mines.push_back(new PUnit(0, 0, 2, 2, MINE_POS[i].x, MINE_POS[i].y));
    }

    // 兜兵晒扮黍圭児仇議奉來
    init_enemy_millitary_base = new PUnit();
    init_enemy_millitary_base->hp = MILITARY_BASE_HP;
    init_enemy_millitary_base->atk = MILITARY_BASE_ATK;
    init_enemy_millitary_base->def = MILITARY_BASE_DEF;
    init_enemy_millitary_base->range = MILITARY_BASE_RANGE;
    init_enemy_millitary_base->view = MILITARY_BASE_VIEW;
    init_enemy_millitary_base->pos = MILITARY_BASE_POS[1 - console->camp()];

    // 兜兵晒匯乂歌方
    argument = new Argument;
    GROUP_SIZE = min(((argument->behave * HERO_LIMIT) / 100) + 1, 5);
}

void AI::updates()
{
    #ifdef DEBUG
    fout << "AI::updates() start" << endl;
    #endif

    gold = console->gold();
    update_myHeroes();
    update_mines();

    // 厚仟黍圭児仇佚連
    UnitFilter filter;
    filter.setTypeFilter("MilitaryBase");
    auto enemys = console->enemyUnits(filter);
    if(enemys.size())
        enemy_millitary_base = enemys[0];
    else
        enemy_millitary_base = init_enemy_millitary_base;

    #ifdef DEBUG
    fout << "AI::updates() end" << endl;
    #endif
}

// 厚仟厘圭哂俛佚連
void AI::update_myHeroes()
{
    #ifdef DEBUG
    fout << "AI::update_myHeroes() start" << endl;
    #endif

    myHeroes.clear();
    UnitFilter filter;
    filter.setAvoidFilter("MilitaryBase");
    myHeroes = console->friendlyUnits(filter);
    nHeroes = myHeroes.size();
    for(auto& hero: myHeroes)
    {
        heros_levels[hero->id] = hero->level;
        acted[hero->id] = false;
    }

    #ifdef DEBUG
    fout << "AI::update_myHeroes() end" << endl;
    #endif
}

// 厚仟嵩泣佚連
void AI::update_mines()
{
    #ifdef DEBUG
    fout << "AI::update_mines() begin" << endl;
    #endif

    for(auto& it : mine_energy)
    {
        it.second --;
        // 邪譜噴指栽朔嵩泣指鹸嬬楚
        if(it.second <= -10)
            it.second = 20 + rand() % 31;
    }
    UnitFilter filter;
    filter.setTypeFilter("Mine");
    auto mines_visual = console->enemyUnits(filter);
    for(auto& mine : mines_visual)
    {
        int index = changePosToIndex[mine->pos];
        mine_energy[index] = console->unitArg("energy", "c", mine);
    }

    #ifdef DEBUG
    fout << "AI::update_mines() end" << endl;
    #endif
}

void AI::act_attack_enemy_Millitary_base()
{
    bool should_attack = false;
    if(console->round() > 10 * (100 - argument->aggressivity))
        should_attack = true;
    else
    {
        int our_evaluation = 0;
        for(auto& hero : myHeroes)
        {
            if(acted[hero->id] == true)
                continue;
            our_evaluation += evaluate(hero);
        }
        int enemy_evaluation = evaluate(enemy_millitary_base);
        if(our_evaluation * argument->aggressivity > enemy_evaluation * (100 - argument->aggressivity))
            should_attack = true;
    }

    if(should_attack)
    {
        for(auto& hero: myHeroes)
        {
            if(acted[hero->id] == true)
                continue;
            console->attack(enemy_millitary_base, hero);
            acted[hero->id] = true;
        }
    }
}

void AI::act_defend()
{
    UnitFilter filter;
    filter.setTypeFilter("MilitaryBase");
    auto bases = console->friendlyUnits(filter);
    if(bases.size() == 0)
    {
        return;
    }
    auto base = bases.front();
    int our_evaluation = evaluate(base);

    filter.cleanAll();
    Geometry* area = new Circle(base->pos, base->view);
    filter.setAreaFilter(area);
    filter.setHpFilter(1, INF);
    auto enemys = console->enemyUnits(filter);
    int enemy_evaluation = 0;
    for(auto& enemy : enemys)
    {
        enemy_evaluation += evaluate(enemy);
    }

    // 蝕兵指契
    int hero_index = 0;
    while((enemy_evaluation * argument->defensive >= our_evaluation * (100 - argument->defensive))
        && hero_index < myHeroes.size())
    {
        // 奐紗指契議醤悶荷恬
        auto& hero = myHeroes[hero_index ++];
        if(acted[hero->id] == true)
            continue;
        if(dis2(base->pos, hero->pos) > base->view * 3 && gold > console->callBackCost(hero->level))
        {
            console->callBackHero(hero);
            gold -= console->callBackCost(hero->level);
        }
        else if(dis2(base->pos, hero->pos) > base->view)
            console->move(base->pos, hero);
        else
        {
            if(enemys.size())
                console->attack(enemys[0]);
            else
                console->move(base->pos, hero);
        }
        acted[hero->id] = true;
        our_evaluation += evaluate(hero);
    }
}

// TODO
void AI::act_mining()
{
    #ifdef DEBUG
    fout << "act_mining() start" << endl;
    #endif

    for(auto& hero: myHeroes)
    {
        if(acted[hero->id] == true)
            continue;
        acted[hero->id] = true;
        console->selectUnit(hero);

        // 飛輝念哂俛隆瓜蛍塘署嵩
        if(target_mine.count(hero->id) == 0)
        {
            choose_mine(hero);
            continue;
        }
        // 念吏嵩泣寡嵩
        else
        {
            int mine_index = target_mine[hero->id];
            Pos mine_pos = MINE_POS[mine_index];
            // 飛署嵩嬬楚厮将債勝夸儖孀恷除辛寡議署嵩吏凪卞強
            if((dis2(mine_pos, hero->pos) < hero->view && mine_energy[mine_index] <= 0))
            {
                choose_mine(hero);
                continue;
            }

            // 孀竃哂俛好似袈律坪議侭嗤試強黍圭汽了
            UnitFilter filter;
            Geometry* area = new Circle(hero->pos, hero->range * hero->range);
            filter.setAreaFilter(area);
            filter.setAvoidFilter("Mine");
            filter.setHpFilter(1, INF);
            auto enemys = console->enemyUnits(filter);
            // 飛侃噐辛寡袈律坪徽署嵩現除嗤黍繁
            if(dis2(mine_pos, hero->pos) < MINE_VIEW && enemys.size())
            {
                fight(hero, enemys[0]);
            }
            else
            {
                console->move(mine_pos);
            }
        }
    }
}

void AI::act_consume()
{
    #ifdef DEBUG
    fout << "act_consume() start" << endl;
    #endif

    if (nHeroes < HERO_LIMIT && gold > NEW_MASTER_COST)
    {
        const char* hero_name = UNIT_NAME[rand() % 4 + 3];
        // console->chooseHero(hero_name);
        // console->chooseHero("Hammerguard");
        console->chooseHero(UNIT_NAME[nHeroes % 4 + 3]);
        gold -= NEW_MASTER_COST;
        nHeroes ++;
    }
    for(auto& hero : myHeroes)
    {
        int gold_buylvl = console->levelUpCost(heros_levels[hero->id]);
        if (gold > gold_buylvl && hero->level < HERO_MAX_LEVEL
            && dis2(hero->pos, MILITARY_BASE_POS[console->camp()]) < LEVELUP_RANGE)
        {
            console->buyHeroLevel(hero);
            int id = hero->id;
            gold -= console->levelUpCost(heros_levels[id]);
            heros_levels[id] ++;
        }
    }

    #ifdef DEBUG
    fout << "act_consume() end" << endl;
    #endif
}

// 得浩匯倖汽了議媾況薦廣緩井云載間華
int AI::evaluate(PUnit* unit)
{
    return unit->hp * (unit->atk + unit->def);
}

// 得浩哂俛恠了扮議鯛泣
int AI::evaluate(PUnit* hero, Pos& pos, PUnit* enemy)
{
    if(pos.x < 0 || pos.x > 150 || pos.y < 0 || pos.x > 150
        || dis2(pos, enemy->pos) > hero->range
        || dis2(pos, hero->pos) > hero->speed)
        return 1000;
    int value = 0;
    auto enemys = console->enemyUnits();
    for(auto& e: enemys)
    {
        if(dis2(pos, e->pos) < e->range)
            value += e->atk;
    }
    return value;
}

// 欠黥恠了
void AI::kite_move(PUnit* hero, PUnit* enemy)
{
    #ifdef DEBUG
    fout << "kite_move() start" << endl;
    #endif
    Pos suitable_pos = hero->pos;
    int min_evaluation = 1000;
    int L = int(ceil(sqrt(hero->range)));
    for(int x = -L; x <= L; x ++)
    {
        for(int y = -L; y <= L; y ++)
        {
            Pos pos(hero->pos.x + x, hero->pos.y + y);
            int evaluation = evaluate(hero, pos, enemy);
            if(evaluation < min_evaluation)
            {
                min_evaluation = evaluation;
                suitable_pos = pos;
            }
        }
    }
    console->move(suitable_pos, hero);
    #ifdef DEBUG
    fout << "kite_move() end" << endl;
    #endif
}

// 才黍圭恬媾飛嬉誼狛夸嬉嬉音狛祥怒
void AI::fight(PUnit* hero, PUnit* enemy)
{
    #ifdef DEBUG
    fout << "fight(" << hero->name << " " << hero->id << ") start" << endl;
    #endif
    console->selectUnit(hero);
    // 範葎嬉誼狛蝕兵媾況
    if(evaluate(hero) * argument->behave > evaluate(enemy) * (100 - argument->behave))
    {
        auto skills = console->getAvailableSkills();
        // 壙協峪嗤Hammerguard嬬聞喘室嬬
        if(hero->name == "Hammerguard" && skills.size() > 0)
        {
            console->useSkill(skills[0]->name, enemy);
        }
        else if(hero->canUseSkill("Attack"))
        {
            console->attack(enemy);
        }
        else
        {
            kite_move(hero, enemy);
        }
    }
    // 範葎嬉音狛夸毛怒
    else
    {
        console->move(MILITARY_BASE_POS[console->camp()], hero);
    }
}

void AI::choose_mine(PUnit* hero)
{
    // 飛輝念哂俛厮瓜蛍塘狛署嵩夸俶勣繍蛍塘佚連賠茅
    if(target_mine.count(hero->id) > 0)
    {
        mine_allocation[target_mine[hero->id]] --;
    }
    int min_dist = INF;
    int index_min = rand() % MINE_NUM;
    for(int i = 0; i < MINE_NUM; i ++)
    {
        if(mine_allocation[i] < GROUP_SIZE)
        {
            int dist = dis2(MINE_POS[i], hero->pos);
            if((dist / hero->speed < mine_energy[i]) && dist < min_dist)
            {
                min_dist = dist;
                index_min = i;
            }
        }
    }
    const Pos pos = MINE_POS[index_min];
    int index = changePosToIndex[pos];
    console->move(pos, hero);
    mine_allocation[index] ++;
    target_mine[hero->id] = index;
}

#ifdef DEBUG
void cmd_output(PCommand& cmd)
{
    fout << "commands: " << endl;
    for(auto c : cmd.cmds)
    {
        fout << "   id = " << c.id << " typeid = " << c.typeId << " type = " << c.type << " target = ";

        // 叙叙峪補竃揃抄嶄議念叱了才朔中叱了
        if(c.targets.size() < 5)
        {
            for(auto t: c.targets)
            {
                fout << t << " ";
            }
        }
        else
        {
            for(int i = 0; i < 3; i ++)
                fout << c.targets[i] << " ";
            fout << "......";
            fout << *c.targets.rbegin();
        }
        fout << endl;
    }
}
#endif
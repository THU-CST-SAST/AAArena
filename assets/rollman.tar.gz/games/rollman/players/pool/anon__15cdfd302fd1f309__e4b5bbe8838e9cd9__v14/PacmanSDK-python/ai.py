from core.gamedata import *
import numpy as np
from enum import Enum
from collections import deque
import sys

class AIState(Enum):
    COLLECT = "COLLECT"  # 收集普通豆子模式
    ESCAPE = "ESCAPE"  # 逃离幽灵模式
    BONUS = "BONUS"  # 收集特殊豆子模式
    GETOUT = "GETOUT"  # 逃离传送门模式


class PacmanAI:
    def __init__(self):
        self.board_size = None
        self.current_state = AIState.COLLECT
        self.path = []
        # 历史记录
        self.history = deque(maxlen=20)
        self.init_bean_num = 0

        # 动态参数
        self.GHOST_DANGER_DISTANCE = 5

        # 状态权重
        self.weights = {
            AIState.COLLECT: {"ghost": 1.0, "bean": 1.5, "bonus": 1.5},
            AIState.ESCAPE: {"ghost": 3.0, "bean": 0.8, "bonus": 1.0},
            AIState.BONUS: {"ghost": 0.8, "bean": 1.5, "bonus": 2.0},
            AIState.GETOUT: {"ghost": 1, "bean": 1, "bonus": 1},
        }

        self.threshold = [[0,0],[20,10],[15,9],[10,8]]

        # 特殊豆子价值
        self.bean_values = {
            3: 1.0,  # BONUS_BEAN
            4: 2.0,  # SPEED_BEAN
            5: 2.5,  # MAGNET_BEAN
            6: 3.0,  # SHIELD_BEAN
            7: 2.5,  # DOUBLE_BEAN
            8: 3.0,  # FROZE_BEAN
        }

    def calc(self,p1,p2):
        return abs(p1[0]-p2[0])+abs(p1[1]-p2[1])

    def calc_pos(self,game_state: GameState):
        return self.calc(game_state.pacman_pos,game_state.ghosts_pos[0]),self.calc(game_state.pacman_pos,game_state.ghosts_pos[1]),self.calc(game_state.pacman_pos,game_state.ghosts_pos[2])

    def calc_posxy(self,game_state: GameState,x,y):
        return self.calc([x,y],game_state.ghosts_pos[0]),self.calc([x,y],game_state.ghosts_pos[1]),self.calc([x,y],game_state.ghosts_pos[2])

    def same_side(self,game_state: GameState,x,y):
        if game_state.ghosts_pos[0][0] < x and game_state.ghosts_pos[1][0] < x and game_state.ghosts_pos[2][0] < x:
            return True
        if game_state.ghosts_pos[0][0] > x and game_state.ghosts_pos[1][0] > x and game_state.ghosts_pos[2][0] > x:
            return True
        if game_state.ghosts_pos[0][1] < y and game_state.ghosts_pos[1][1] < y and game_state.ghosts_pos[2][1] < y:
            return True
        if game_state.ghosts_pos[0][1] > y and game_state.ghosts_pos[1][1] > y and game_state.ghosts_pos[2][1] > y:
            return True
        return False

    def valid_direction(self,game_state: GameState,direct:Direction):
        level = game_state.level
        minthreshold = self.threshold[level][1]
        for i in range(0, minthreshold):
            nx,ny = self.getNewPos(game_state,direct,i)
            if nx >= game_state.board_size or ny >= game_state.board_size or nx <= 0 or ny <= 0:
                return False
            if game_state.board[nx][ny] == 0:
                return False
        return True

    def getNewPos(self,game_state: GameState,direct:Direction,value):
        y = game_state.pacman_pos[0]
        x = game_state.pacman_pos[1]
        nx = x
        ny = y
        if direct == Direction.DOWN:
            nx = x
            ny = y - value
        if direct == Direction.UP:
            nx = x
            ny = y + value
        if direct == Direction.LEFT:
            nx = x - value
            ny = y
        if direct == Direction.RIGHT:
            nx = x + value
            ny = y
        return nx,ny

    def value_direction(self,game_state: GameState,direct:Direction):
        if not self.valid_direction(game_state,direct):
            return -1000

        y = game_state.pacman_pos[0]
        x = game_state.pacman_pos[1]
        level = game_state.level
        minthreshold = self.threshold[level][1]
        nx,ny = self.getNewPos(game_state,direct,minthreshold)
        d1,d2,d3 = self.calc_posxy(game_state,y,x)
        nd1,nd2,nd3 = self.calc_posxy(game_state,ny,nx)
        leave_count = min(nd1,nd2,nd3) - min(d1,d2,d3)
        return leave_count

    def select_direction(self,game_state: GameState):
        d = Direction.STAY
        value = -10000
        print("round:"+str(game_state.round),file=sys.stderr)
        print("round:"+str(game_state.pacman_pos[0])+","+str(game_state.pacman_pos[1]),file=sys.stderr)
        for item in range(1,5):
            dv = self.value_direction(game_state,Direction(item))
            print(str(item) + ":" + str(dv),file=sys.stderr)
            if dv > value:
                value = dv
                d = Direction(item)
        return d

    def choose_move(self, game_state: GameState):
        """选择移动方向"""
        return [self.select_direction(game_state).value]  # 默认停留

# TODO: 你需要实现一个ai函数

ai_func = PacmanAI().choose_move # TODO: 你需要把ai_func替换为自己的ai函数
__all__ = ["ai_func"]

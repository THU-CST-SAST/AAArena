from core.gamedata import *
import numpy as np
from enum import Enum
from collections import deque
from typing import List, Tuple, Optional
import random

class AIState(Enum):
    COLLECT = "COLLECT"  # 收集普通豆子模式
    ESCAPE = "ESCAPE"  # 逃离幽灵模式
    BONUS = "BONUS"  # 收集特殊豆子模式
    GETOUT = "GETOUT"  # 逃离传送门模式


class PacmanAI:
    def __init__(self):
        self.board_size = None
        self.current_state = AIState.COLLECT
        self.path = []
        self.history = deque(maxlen=10)  # 减少历史记录长度
        self.init_bean_num = 0
        self.special_beans = []  # 缓存特殊豆子位置

        # 动态参数
        self.GHOST_DANGER_DISTANCE = 5
        self.ESCAPE_DISTANCE = 3  # 幽灵接近时的紧急躲避距离
        self.CORNER_PENALTY = -10  # 进入死角的惩罚
        self.OPEN_AREA_BONUS = 5  # 进入开阔区域的奖励

        # 状态权重
        self.weights = {
            AIState.COLLECT: {"ghost": 1.0, "bean": 1.5, "bonus": 1.5},
            AIState.ESCAPE: {"ghost": 3.0, "bean": 0.8, "bonus": 1.0},
            AIState.BONUS: {"ghost": 0.8, "bean": 1.5, "bonus": 2.0},
            AIState.GETOUT: {"ghost": 1, "bean": 1, "bonus": 1},
        }

        # 特殊豆子价值
        self.bean_values = {
            3: 1.0,  # BONUS_BEAN
            4: 2.0,  # SPEED_BEAN
            5: 2.5,  # MAGNET_BEAN
            6: 3.0,  # SHIELD_BEAN
            7: 2.5,  # DOUBLE_BEAN
            8: 3.0,  # FROZE_BEAN
        }

    def count_remaining_bean(self, game_state: GameState) -> int:
        """计算剩余豆子数量"""
        return sum(
            1
            for row in game_state.board
            for cell in row
            if cell in range(2, 8)
        )

    def manhattan_distance(self, pos1, pos2) -> int:
        """曼哈顿距离"""
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def is_corner(self, pos, game_state: GameState) -> bool:
        """判断位置是否是死角（只有一个出口）"""
        valid_moves = self.get_valid_moves(pos, game_state)
        return len(valid_moves) <= 1  # 只有一个或没有有效移动方向

    def is_open_area(self, pos, game_state: GameState) -> bool:
        """判断位置是否处于开阔区域（有多个出口）"""
        valid_moves = self.get_valid_moves(pos, game_state)
        return len(valid_moves) >= 3  # 有三个或更多有效移动方向

    def update_state(self, game_state: GameState):
        """更新游戏状态"""
        pacman_pos = np.array(game_state.pacman_pos)
        ghost_distances = [self.manhattan_distance(pacman_pos, np.array(ghost_pos)) for ghost_pos in game_state.ghosts_pos]
        min_ghost_distance = min(ghost_distances)
        has_shield = game_state.pacman_skill_status[Skill.SHIELD.value] > 0

        if min_ghost_distance < self.GHOST_DANGER_DISTANCE and not has_shield:
            if (
                game_state.level < 3
                and self.count_remaining_bean(game_state) < self.init_bean_num * 0.5
                and game_state.portal_available
            ):
                self.current_state = AIState.GETOUT
            else:
                self.current_state = AIState.ESCAPE
        elif (
            game_state.level < 3
            and game_state.portal_available
            and self.count_remaining_bean(game_state) < self.init_bean_num * 0.5
        ):
            self.current_state = AIState.GETOUT
        elif self.special_beans:  # 使用缓存的特豆子列表
            self.current_state = AIState.BONUS
        else:
            self.current_state = AIState.COLLECT

    def evaluate_position(self, pos, game_state: GameState) -> float:
        """评估位置的价值"""
        pacman_pos = np.array(game_state.pacman_pos)
        weights = self.weights[self.current_state]
        ghost_distances = [self.manhattan_distance(pos, np.array(ghost_pos)) for ghost_pos in game_state.ghosts_pos]
        min_ghost_distance = min(ghost_distances)
        ghost_score = (-4) * weights["ghost"] / (min_ghost_distance + 1)

        # 计算周围豆子的价值
        bean_value = 0
        scan_range = 3 if self.current_state == AIState.ESCAPE else 5  # 动态调整扫描范围
        for dx in range(-scan_range, scan_range + 1):
            for dy in range(-scan_range, scan_range + 1):
                new_x, new_y = int(pos[0] + dx), int(pos[1] + dy)
                if 0 <= new_x < game_state.board_size and 0 <= new_y < game_state.board_size:
                    bean_type = game_state.board[new_x][new_y]
                    if bean_type in BEANS_ITERATOR:
                        distance = abs(dx) + abs(dy)
                        if bean_type in SPECIAL_BEANS_ITERATOR:
                            bean_value += self.bean_values[bean_type] / (distance + 1)
                        elif bean_type == Space.REGULAR_BEAN.value:
                            bean_value += 1 / (distance + 1)

        # 避免重复访问
        pos_tuple = tuple(pos)
        repeat_penalty = -8 * self.history.count(pos_tuple)

        # 增加对死角的惩罚和对开阔区域的奖励
        if self.is_corner(pos, game_state):
            corner_penalty = self.CORNER_PENALTY
        else:
            corner_penalty = 0

        if self.is_open_area(pos, game_state):
            open_area_bonus = self.OPEN_AREA_BONUS
        else:
            open_area_bonus = 0

        final_score = ghost_score + bean_value * weights["bean"] + repeat_penalty + corner_penalty + open_area_bonus

        if self.current_state == AIState.ESCAPE and min_ghost_distance < self.ESCAPE_DISTANCE:
            final_score -= (self.ESCAPE_DISTANCE - min_ghost_distance) * 20  # 增加紧急躲避的权重

        if self.current_state == AIState.GETOUT:
            portal_pos = np.array(game_state.portal_coord)
            dist_to_portal = self.manhattan_distance(pos, portal_pos)
            final_score += 30 / (dist_to_portal + 1)

        return final_score

    def get_valid_moves(self, pos, game_state: GameState) -> List[Tuple[np.ndarray, int]]:
        """获取有效的移动方向"""
        moves = []
        directions = [
            (np.array(list(Update.UP.value)), Direction.UP.value),
            (np.array(list(Update.LEFT.value)), Direction.LEFT.value),
            (np.array(list(Update.DOWN.value)), Direction.DOWN.value),
            (np.array(list(Update.RIGHT.value)), Direction.RIGHT.value),
        ]
        for direction, move_num in directions:
            new_pos = pos + direction
            if self.is_valid_position(new_pos, game_state):
                moves.append((new_pos, move_num))
        return moves

    def is_valid_position(self, pos, game_state: GameState) -> bool:
        """检查位置是否有效"""
        x, y = int(pos[0]), int(pos[1])
        return (
            0 <= x < game_state.board_size
            and 0 <= y < game_state.board_size
            and game_state.board[x][y] != Space.WALL.value
            and (self.current_state == AIState.GETOUT or game_state.board[x][y] != Space.PORTAL.value)
        )

    def choose_move(self, game_state: GameState) -> List[int]:
        """选择移动方向"""
        if game_state.round == 1:
            self.init_bean_num = self.count_remaining_bean(game_state)
            self.special_beans = []  # 重置特殊豆子缓存

        self.board_size = game_state.board_size
        self.update_state(game_state)
        pacman_pos = np.array(game_state.pacman_pos)
        valid_moves = self.get_valid_moves(pacman_pos, game_state)

        move_scores = [(self.evaluate_position(new_pos, game_state), move_num) for new_pos, move_num in valid_moves]
        if move_scores:
            best_score = max(move_scores, key=lambda x: x[0])[0]
            best_moves = [move for score, move in move_scores if score == best_score]
            best_move = random.choice(best_moves)  # 随机选择一个最佳移动
            self.history.append(tuple(pacman_pos))
            return [best_move]

        return [Direction.STAY.value]


ai_func = PacmanAI().choose_move
__all__ = ["ai_func"]
from core.gamedata import *
import random
import numpy as np


def parse(x: tuple):
    if x == (0, 0):
        return Direction.STAY.value
    if x == (1, 0):
        return Direction.UP.value
    if x == (-1, 0):
        return Direction.DOWN.value
    if x == (0, 1):
        return Direction.RIGHT.value
    if x == (0, -1):
        return Direction.LEFT.value


class GhostAI:
    def __init__(self):
        self.position_history = {0: [], 1: [], 2: []}  
        self.pacman_history = []  # 新增Pacman历史轨迹记录  
        self.history_length = 5  
        self.history_length_pacman = 5  # Pacman历史记录长度  
        self.ghost_roles = {}
        self.isclose = False
        self.bias = np.ndarray([0, 0])
        self.pacman_target = np.ndarray([0, 0])
        self.ghost_path = []

    def manhattan_distance(self, pos1, pos2):
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def get_valid_moves(self, pos, game_state):
        valid_moves = []
        directions = [
            ([1, 0], 1),  # UP
            ([-1, 0], 3),  # DOWN
            ([0, -1], 2),  # LEFT
            ([0, 1], 4),  # RIGHT
        ]

        for direction, move_value in directions:
            new_pos = [pos[0] + direction[0], pos[1] + direction[1]]
            if (
                0 <= new_pos[0] < game_state.board_size
                and 0 <= new_pos[1] < game_state.board_size
                and game_state.board[new_pos[0]][new_pos[1]] != Space.WALL.value
            ):
                valid_moves.append((new_pos, move_value))
        return valid_moves

    def a_star_search(self, start: np.ndarray, goal: np.ndarray, game_state: GameState):
        open_set = set()
        open_set.add(tuple(start))
        came_from = {}

        g_score = {tuple(start): 0}
        f_score = {tuple(start): self.manhattan_distance(start, goal)}

        while open_set:
            current = min(open_set, key=lambda x: f_score.get(x, float("inf")))
            if current == tuple(goal):
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.reverse()
                return path

            open_set.remove(current)
            for direction, _ in self.get_valid_moves(list(current), game_state):
                neighbor = tuple(direction)
                tentative_g_score = g_score[current] + 1

                if tentative_g_score < g_score.get(neighbor, float("inf")):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.manhattan_distance(
                        neighbor, goal
                    )
                    if neighbor not in open_set:
                        open_set.add(neighbor)

        return []    

    def my_search(self, start: np.ndarray, goal: np.ndarray, game_state: GameState):  
        def calculate_cost(position):  
            """计算当前位置的综合成本，包括与幽灵和障碍物的距离"""  
            cost = 0  
            
            # 计算与其他幽灵的接近成本  
            for gid, ghost_pos in enumerate(game_state.ghosts_pos):  
                if np.array_equal(position, ghost_pos):  
                    continue  # 忽略自身位置  
                
                distance = self.manhattan_distance(position, ghost_pos)  
                if distance <= 6:  # 只对邻近的幽灵计算成本  
                    cost += max(0, 6 - distance)  # 脸接近惩罚，更强的惩罚  
            
            # 计算与障碍物的接近成本  
            terrain_cost = 0 
            for(x , y) in [(1, -1), (1, 0), (1, 1), (0, -1), (0, 1), (-1, -1), (-1, 0), (-1, 1)]:  
                if game_state.board[position[0] + x][position[1] + y] == Space.WALL.value:    
                    cost +=  1  # 障碍物的额外成本  

            return cost  

        open_set = set()  
        open_set.add(tuple(start))  
        came_from = {}  

        g_score = {tuple(start): 0}  
        f_score = {tuple(start): self.manhattan_distance(start, goal)}  

        while open_set:  
            current = min(open_set, key=lambda x: f_score.get(x, float("inf")))  
            if current == tuple(goal):  
                path = []  
                while current in came_from:  
                    path.append(current)  
                    current = came_from[current]  
                path.reverse()  
                return path  

            open_set.remove(current)  
            for direction, _ in self.get_valid_moves(list(current), game_state):  
                neighbor = tuple(direction)  
                
                # 计算基础移动成本  
                terrain_cost = 1  
                if game_state.board[neighbor[0]][neighbor[1]] == Space.WALL.value:  
                    terrain_cost = float("inf")  # 障碍物无法穿越

                # 添加幽灵和墙壁接近权重  
                proximity_penalty = 0.5 * calculate_cost(neighbor)  
                
                # 综合成本  
                tentative_g_score = g_score[current] + terrain_cost + proximity_penalty  

                if tentative_g_score < g_score.get(neighbor, float("inf")):  
                    came_from[neighbor] = current  
                    g_score[neighbor] = tentative_g_score  
                    f_score[neighbor] = tentative_g_score + self.manhattan_distance(neighbor, goal)  
                    if neighbor not in open_set:  
                        open_set.add(neighbor)  

        return []  

    def calculate_stagnation_penalty(self, new_pos, ghost_id):
        if not self.position_history[ghost_id]:
            return 0
        repeat_count = sum(
            1
            for pos in self.position_history[ghost_id]
            if pos[0] == new_pos[0] and pos[1] == new_pos[1]
        )
        return repeat_count * 2

    def update_history(self, ghost_id, new_pos):
        self.position_history[ghost_id].append(new_pos)
        if len(self.position_history[ghost_id]) > self.history_length:
            self.position_history[ghost_id].pop(0)

    def line_intersection(self, line1, line2): 
        # 解包线段坐标 (p1, p2) 和 (p3, p4)  
        p1, p2 = line1  
        p3, p4 = line2  
        
        # 转换为向量元组  
        a = np.array(p1)  
        b = np.array(p2)  
        c = np.array(p3)  
        d = np.array(p4)  
        
        # 快速排斥实验  
        if max(a[0], b[0]) < min(c[0], d[0]) or \
        max(c[0], d[0]) < min(a[0], b[0]) or \
        max(a[1], b[1]) < min(c[1], d[1]) or \
        max(c[1], d[1]) < min(a[1], b[1]):  
            return False  
        
        # 跨立实验  
        def cross(o, a, b):  
            return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])  
        
        # 判断c,d在ab两侧  
        c1 = cross(a, b, c)  
        c2 = cross(a, b, d)  
        # 判断a,b在cd两侧  
        c3 = cross(c, d, a)  
        c4 = cross(c, d, b)  
        
        # 处理共线情况（曼哈顿网格中较少出现）  
        if c1 == 0 and self.on_segment(a, c, b):  
            return True  
        if c2 == 0 and self.on_segment(a, d, b):  
            return True  
        if c3 == 0 and self.on_segment(c, a, d):  
            return True  
        if c4 == 0 and self.on_segment(c, b, d):  
            return True  
        
        # 标准相交判断  
        return (c1 * c2 < 0) and (c3 * c4 < 0)  

    def on_segment(self, a, p, b): 
        # 由于网格移动都是离散的，直接比较坐标差值即可  
        min_x = min(a[0], b[0])  
        max_x = max(a[0], b[0])  
        min_y = min(a[1], b[1])  
        max_y = max(a[1], b[1])  
        return (min_x <= p[0] <= max_x) and (min_y <= p[1] <= max_y)    

    def select_chase_ghost(self, game_state):  
        candidates = []  
        for gid in range(3):  
            # 计算当前幽灵到Pacman的路径  
            path = self.ghost_path[gid] 
            path_len = len(path)  

            # 计算与其他幽灵的曼哈顿距离之和  
            other_ghosts = [pos for i, pos in enumerate(game_state.ghosts_pos) if i != gid]  
            total_distance = sum(self.manhattan_distance(game_state.ghosts_pos[gid], ghost) for ghost in other_ghosts)  

            # 添加到候选列表（幽灵ID, 路径长度, 曼哈顿距离总和）  
            candidates.append((gid, path_len, total_distance))  

        # 按路径长度排序，如果路径长度相同则按曼哈顿距离总和排序  
        candidates.sort(key=lambda x: (x[1], x[2]))  # 按（路径长度, 曼哈顿距离的总和）排序  

        # 返回路径长度最小的鬼ID  
        return candidates[0][0]    

    def update_pacman_history(self, current_pos):  
        self.pacman_history.append(tuple(current_pos))  
        # 保持历史记录长度不超过设定值  
        if len(self.pacman_history) > self.history_length_pacman:  
            self.pacman_history.pop(0)

    def predict_pacman_move(self, game_state):  
        """改进的轨迹预测算法"""  
        
        # 获取Pacman的当前位置  
        pacman_pos = game_state.pacman_pos  
        x, y = pacman_pos[0], pacman_pos[1]  

        # 检查Pacman上下左右的位置  
        surroundings = [  
            np.array([x - 1, y], dtype=int),  # 上  
            np.array([x + 1, y], dtype=int),  # 下  
            np.array([x, y - 1], dtype=int),  # 左  
            np.array([x, y + 1], dtype=int)   # 右  
        ]  

        # 用于存储有效移动  
        valid_moves = []  
        wall_or_ghost_count = 0  

        for pos in surroundings:   
            if game_state.board[pos[0]][pos[1]] == Space.WALL.value: 
                wall_or_ghost_count += 1  
                continue
            if any(np.array_equal(pos, ghost) for ghost in game_state.ghosts_pos):  
                wall_or_ghost_count += 1  
                continue
            valid_moves.append(pos)  # 记录有效位置  

        # 根据基于有效移动的数量来选择返回值
        if len(valid_moves) == 1:
            return valid_moves[0] - pacman_pos  # 向量差（np.ndarray）

        if len(valid_moves) > 1:  
            trend_scores = [  
                (self.calculate_movement_trend(move, game_state), move)  
                for move in valid_moves  
            ]  
            best_move = max(trend_scores, key=lambda x: x[0])[1]  
            return best_move - pacman_pos      

        # 如果都不能移动，则返回当前位置  
        return np.array([0, 0], dtype=int)  # 零向量 

    def calculate_movement_trend(self, move, game_state):  
        """计算候选移动方向与历史趋势的匹配度"""  
        if len(self.pacman_history) < 2:  
            return 0  # 历史不足无法计算趋势  

        # 计算加权动量向量（与原逻辑一致）  
        weights = np.linspace(0.1, 1.0, len(self.pacman_history) - 1)  
        total_weight = np.sum(weights)  
        dx = np.sum(  
            [(self.pacman_history[i][0] - self.pacman_history[i-1][0]) * weights[i - 1]  
            for i in range(1, len(self.pacman_history))]  
        ) / total_weight  
        dy = np.sum(  
            [(self.pacman_history[i][1] - self.pacman_history[i-1][1]) * weights[i - 1]  
            for i in range(1, len(self.pacman_history))]  
        ) / total_weight 

        # 趋势方向与移动方向的点积（越大表示方向越接近）  
        return dx * (move[0] - game_state.pacman_pos[0]) + dy * (move[1] - game_state.pacman_pos[1])

    def cooperative_pathing(self, ghost_id, game_state):  
        chase_gid = self.ghost_roles['chase']  
        if ghost_id == chase_gid:  
            # 主追击者直接使用A*  
            return self.my_search(game_state.ghosts_pos[ghost_id],  
                                     self.pacman_target,  
                                     game_state)  
        else:  
            # 协同者路径规划 
            pacman_target = self.pacman_target
            if self.isclose:
                pacman_target += self.bias
            base_path = self.my_search(game_state.ghosts_pos[chase_gid],  
                                          pacman_target,  
                                          game_state)  
            
            # 确保路径形成包围网  
            intercept_points = []  
            for step in base_path:  
                other_ghosts = [pos for i, pos in enumerate(game_state.ghosts_pos)   
                               if i not in [ghost_id, chase_gid]]  
                if len(other_ghosts) == 1:  
                    if self.line_intersection( (step, self.pacman_target),   
                                             (game_state.ghosts_pos[ghost_id], other_ghosts[0]) ):  
                        intercept_points.append(step)  
            
            # 优先选择拦截点  
            if intercept_points:  
                return self.my_search(game_state.ghosts_pos[ghost_id],  
                                         random.choice(intercept_points),  
                                         game_state)  
            else:  
                return self.my_search(game_state.ghosts_pos[ghost_id],  
                                         self.pacman_target,  
                                         game_state)          

    def choose_moves(self, game_state: GameState): 
        self.isclose = False
        moves = []
        planned_pos = []  
        pacman_pos = game_state.pacman_pos
        self.update_pacman_history(pacman_pos)
        self.ghost_path.append(self.a_star_search(game_state.ghosts_pos[0], pacman_pos, game_state))
        self.ghost_path.append(self.a_star_search(game_state.ghosts_pos[1], pacman_pos, game_state))
        self.ghost_path.append(self.a_star_search(game_state.ghosts_pos[2], pacman_pos, game_state))
        self.ghost_roles['chase'] = self.select_chase_ghost(game_state)
        self.bias = 2 * (pacman_pos - game_state.ghosts_pos[self.ghost_roles['chase']])
        self.pacman_target = pacman_pos
        predict_move = self.predict_pacman_move(game_state)
        for gid in range(4):
            self.pacman_target += predict_move
            if game_state.board[self.pacman_target[0]][self.pacman_target[1]] == Space.WALL.value:
                self.pacman_target -= predict_move
                break

        for ghost_id in range(3):  
            current_pos = game_state.ghosts_pos[ghost_id]  
            valid_moves = self.get_valid_moves(current_pos, game_state)  
            
            if not valid_moves:
                moves.append(Direction.STAY.value)
                continue
            # 计算到吃豆人的距离
            a_star_path = self.ghost_path[ghost_id] #当鬼与pacman重合时为空
            my_path = self.my_search(current_pos, pacman_pos, game_state)
            distance_to_pacman = len(a_star_path) if a_star_path else float("inf")
            
            # 如果距离很近（比如小等于2），直接追击
            if distance_to_pacman <= 2:
                if ghost_id != self.ghost_roles['chase'] or \
                    distance_to_pacman == 0: 
                    my_path = self.my_search(current_pos, self.pacman_target, game_state)
                    if not my_path: my_path.append(current_pos)
                best_move = (
                    my_path[0],
                    parse(
                        (
                            my_path[0][0] - current_pos[0],
                            my_path[0][1] - current_pos[1],
                        )
                    ),
                )
                #self.update_history(ghost_id, best_move[0])
                moves.append(best_move[1])
                continue  
            # 稍微远一点则提前堵在对角线 
            if distance_to_pacman <= 4:  
                # 定义Pacman周围的对角格  
                diagonals = [  
                    (game_state.pacman_pos[0] - 1, game_state.pacman_pos[1] - 1),    
                    (game_state.pacman_pos[0] - 1, game_state.pacman_pos[1] + 1),  
                    (game_state.pacman_pos[0] + 1, game_state.pacman_pos[1] - 1),  
                    (game_state.pacman_pos[0] + 1, game_state.pacman_pos[1] + 1)   
                ]  
                
                # 过滤掉障碍物的对角格  
                valid_diagonals = []  
                for diag in diagonals:  
                    if game_state.board[diag[0]][diag[1]] != Space.WALL.value:  # 确保对角格位于有效范围  
                        valid_diagonals.append(diag)  

                # 检查Pacman的上下左右格子，去掉无法在两步内到达的对角格  
                pacman_surroundings = [  
                    (game_state.pacman_pos[0] - 1, game_state.pacman_pos[1]),  
                    (game_state.pacman_pos[0] + 1, game_state.pacman_pos[1]),   
                    (game_state.pacman_pos[0], game_state.pacman_pos[1] - 1),   
                    (game_state.pacman_pos[0], game_state.pacman_pos[1] + 1)    
                ]  

                unreachable_diagonals = []  
                if game_state.board[game_state.pacman_pos[0] - 1][game_state.pacman_pos[1]] == Space.WALL.value:
                    if game_state.board[game_state.pacman_pos[0]][game_state.pacman_pos[1] - 1] == Space.WALL.value:
                        unreachable_diagonals.append(diagonals[0])
                        if game_state.board[game_state.pacman_pos[0] + 1][game_state.pacman_pos[1]] == Space.WALL.value:
                            unreachable_diagonals.append(diagonals[2])
                    if game_state.board[game_state.pacman_pos[0]][game_state.pacman_pos[1] + 1] == Space.WALL.value:
                        unreachable_diagonals.append(diagonals[1])
                        if game_state.board[game_state.pacman_pos[0] + 1][game_state.pacman_pos[1]] == Space.WALL.value: 
                            unreachable_diagonals.append(diagonals[3])

                # 从可行的对角格中移除无法到达的格子  
                valid_diagonals = [diag for diag in valid_diagonals if diag not in unreachable_diagonals]  

                # 如果还有剩余的有效对角格，选择最优的  
                if valid_diagonals:
                    best_diag = min(valid_diagonals, key=lambda d: len(self.a_star_search(current_pos, d, game_state)))  
                    path = self.my_search(current_pos, best_diag, game_state)  # 重新计算到最佳对角格的路径
                    best_move = (
                            path[0],
                            parse(
                                (path[0][0] - current_pos[0], path[0][1] - current_pos[1])
                            ),
                        )  
                else: 
                    best_move = (
                        my_path[0],
                        parse(
                            (
                                my_path[0][0] - current_pos[0],
                                my_path[0][1] - current_pos[1],
                            )
                        ),
                    ) 
            else:        
                if ghost_id == self.ghost_roles['chase']:  
                    # 主追击者策略  
                    path = self.my_search(current_pos,   
                                            self.pacman_target,  
                                            game_state)  
                else:  
                    # 协同者策略  
                    path = self.cooperative_pathing(ghost_id, game_state)  
                
                # 路径选择逻辑  
                if path:  
                    best_move = (
                            path[0],
                            parse(
                                (path[0][0] - current_pos[0], path[0][1] - current_pos[1])
                            ),
                        )  
                else:  
                    best_move = min(
                            valid_moves,
                            key=lambda x: self.manhattan_distance(x[0], pacman_pos),
                        ) 
                
            #self.update_history(ghost_id, best_move[0])
            for pos in planned_pos:  
                if np.array_equal(best_move[0], pos):  
                    best_move = random.choice(valid_moves)
                    break
            moves.append(best_move[1])
            planned_pos.append(best_move[0])
        
        return moves

# TODO: 你需要实现一个ai函数

ai_func = GhostAI().choose_moves # TODO: 你需要把ai_func替换为自己的ai函数
__all__ = ["ai_func"]

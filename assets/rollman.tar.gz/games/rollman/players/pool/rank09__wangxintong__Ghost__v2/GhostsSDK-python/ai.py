from core.gamedata import *
import random
import numpy as np
class GhostAI:
    def __init__(self):
        self.position_history = {0: [], 1: [], 2: []}
        self.history_length = 5
        self.previous_pacman_pos = None  # 记录吃豆人上一回合的位置

    def manhattan_distance(self, pos1, pos2):
        return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

    def get_valid_moves(self, pos, game_state):
        valid_moves = []
        directions = [
            ([1, 0], 1),   # UP
            ([-1, 0], 3),  # DOWN
            ([0, -1], 2),  # LEFT
            ([0, 1], 4),   # RIGHT
        ]

        for direction, move_value in directions:
            new_pos = [pos[0] + direction[0], pos[1] + direction[1]]
            if (0 <= new_pos[0] < game_state.board_size and
                0 <= new_pos[1] < game_state.board_size and
                game_state.board[new_pos[0]][new_pos[1]] != 0):
                valid_moves.append((new_pos, move_value))
        return valid_moves

    def a_star_search(self, start, goal, game_state):
        open_set = {tuple(start)}
        came_from = {}

        g_score = {tuple(start): 0}
        f_score = {tuple(start): self.manhattan_distance(start, goal)}

        while open_set:
            current = min(open_set, key=lambda x: f_score.get(x, float("inf")))

            if current == tuple(goal):
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.reverse()
                return path

            open_set.remove(current)
            for direction, _ in self.get_valid_moves(list(current), game_state):
                neighbor = tuple(direction)
                tentative_g_score = g_score[current] + 1

                if tentative_g_score < g_score.get(neighbor, float("inf")):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = tentative_g_score + self.manhattan_distance(neighbor, goal)
                    open_set.add(neighbor)

        return []

    def predict_pacman_path(self, game_state, steps=4):
        """
        预测吃豆人未来 steps 步的位置
        """
        pacman_pos = game_state.pacman_pos

        if self.previous_pacman_pos is None:
            self.previous_pacman_pos = pacman_pos
            return [pacman_pos]

        # 计算吃豆人的方向
        pacman_direction = (pacman_pos[0] - self.previous_pacman_pos[0], pacman_pos[1] - self.previous_pacman_pos[1])
        self.previous_pacman_pos = pacman_pos  # 更新历史位置

        predicted_positions = [tuple(pacman_pos)]
        pos = np.array(pacman_pos)

        for _ in range(steps):
            pos = pos + np.array(pacman_direction)
            if (0 <= pos[0] < game_state.board_size and 0 <= pos[1] < game_state.board_size):
                predicted_positions.append(tuple(pos))
            else:
                break  # 避免超出边界

        return predicted_positions

    def find_closest_wall(self, pos, game_state):
        """
        找到距离 pos 最近的墙，若找不到，则返回地图边界点
        """
        queue = [pos]
        visited = set()

        while queue:
            current = queue.pop(0)
            if game_state.board[current[0]][current[1]] == 0:
                return current  # 找到墙

            for direction, _ in self.get_valid_moves(list(current), game_state):
                neighbor = tuple(direction)
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        # 兜底返回最近的地图边界
        return (max(0, min(pos[0], game_state.board_size - 1)),
                max(0, min(pos[1], game_state.board_size - 1)))

    def choose_moves(self, game_state):
        moves = []
        pacman_pos = game_state.pacman_pos
        ghost_positions = game_state.ghosts_pos

        predicted_positions = self.predict_pacman_path(game_state, 4)
        predicted_target = predicted_positions[-1] if predicted_positions else pacman_pos

        for ghost_id in range(3):
            current_pos = ghost_positions[ghost_id]
            valid_moves = self.get_valid_moves(current_pos, game_state)

            if not valid_moves:
                moves.append(0)  # STAY
                continue

            if ghost_id == 0:  # 追击幽灵
                target_pos = pacman_pos
                path = self.a_star_search(current_pos, target_pos, game_state)

            elif ghost_id == 1:  # 围堵幽灵
                target_pos = predicted_target
                path = self.a_star_search(current_pos, target_pos, game_state)

            else:  # 封锁幽灵
                escape_routes = self.get_valid_moves(pacman_pos, game_state)
                if escape_routes:
                    wall_positions = [self.find_closest_wall(x[0], game_state) for x in escape_routes]
                    wall_positions = [w for w in wall_positions if w]  # 过滤掉 None
                    if wall_positions:
                        target_pos = min(
                            escape_routes,
                            key=lambda x: self.manhattan_distance(x[0], self.find_closest_wall(x[0], game_state))
                        )[0]
                    else:
                        target_pos = pacman_pos
                else:
                    target_pos = pacman_pos

                path = self.a_star_search(current_pos, target_pos, game_state)

            if path:
                best_move = path[0]
                move_value = self.get_direction(current_pos, best_move)
            else:
                best_move = min(valid_moves, key=lambda x: self.manhattan_distance(x[0], pacman_pos))
                move_value = best_move[1]

            self.update_history(ghost_id, best_move[0])
            moves.append(move_value)

        return moves

    def get_direction(self, start, end):
        """
        计算幽灵从 start 到 end 的方向
        """
        delta = (end[0] - start[0], end[1] - start[1])
        direction_map = {
            (1, 0): 1,   # UP
            (-1, 0): 3,  # DOWN
            (0, -1): 2,  # LEFT
            (0, 1): 4,   # RIGHT
        }
        return direction_map.get(delta, 0)

    def update_history(self, ghost_id, new_pos):
        self.position_history[ghost_id].append(new_pos)
        if len(self.position_history[ghost_id]) > self.history_length:
            self.position_history[ghost_id].pop(0)


ai_func = GhostAI().choose_moves # TODO: 你需要把ai_func替换为自己的ai函数
__all__ = ["ai_func"]

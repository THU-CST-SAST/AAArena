from core.gamedata import *
import random

def ai_rand(game_state: GameState):
    """
    Args:
        game_state (GameState): 当前的游戏局面对象

    Returns:
        list: 包含一个操作序号的数组，范围在[0, 4]之间
    """
    action = random.randint(0, 4)
    return [action]

ai_func = ai_rand
__all__ = ["ai_func"]

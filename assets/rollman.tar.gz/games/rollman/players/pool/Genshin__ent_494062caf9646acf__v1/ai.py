from core.gamedata import *
import numpy as np


class PacmanAI:
    def __init__(self):
        # 阈值与权重
        self.GHOST_DANGER_DIST = 6          # 幽灵威胁阈值
        self.weights = {
            "escape": 5.0,   # 逃离得分权重
            "bean":   1.2,   # 普通豆权重
            "bonus":  2.0,   # 特殊豆权重
            "shield": 4.0,   # 护盾优先权
            "freeze": 4.0,   # 冰冻优先权
        }
        # 特殊豆值（收集价值）
        self.bean_values = {
            Space.BONUS_BEAN.value: 2.0,
            Space.SPEED_BEAN.value: 1.5,
            Space.MAGNET_BEAN.value: 1.5,
            Space.SHIELD_BEAN.value: 3.0,
            Space.DOUBLE_BEAN.value: 2.5,
            Space.FROZE_BEAN.value: 3.5,
        }
        self.init_total_beans = 0
        self.history = []

    def count_beans(self, gs: GameState):
        cnt = 0
        for i in range(gs.board_size):
            for j in range(gs.board_size):
                if gs.board[i][j] in range(2, 9):
                    cnt += 1
        return cnt

    def get_valid_moves(self, pos, gs: GameState):
        moves = []
        for d, mv in [(np.array(Update.UP.value), Direction.UP.value),
                      (np.array(Update.LEFT.value), Direction.LEFT.value),
                      (np.array(Update.DOWN.value), Direction.DOWN.value),
                      (np.array(Update.RIGHT.value), Direction.RIGHT.value)]:
            np2 = pos + d
            x, y = int(np2[0]), int(np2[1])
            if 0 <= x < gs.board_size and 0 <= y < gs.board_size:
                if gs.board[x][y] != Space.WALL.value:
                    moves.append((np2, mv))
        return moves

    def predict_ghosts(self, pac_pos, gs: GameState):
        """贪心模拟：每个幽灵向 pac_pos 最近方向移动一步"""
        next_ghosts = []
        for gpos in gs.ghosts_pos:
            best = gpos
            best_d = self.mdist(gpos, pac_pos)
            for npg, _ in self.get_valid_moves(np.array(gpos), gs):
                d = self.mdist(npg, pac_pos)
                if d < best_d:
                    best_d, best = d, npg
            next_ghosts.append(best)
        return next_ghosts

    def mdist(self, a, b):
        return abs(int(a[0])-int(b[0])) + abs(int(a[1])-int(b[1]))

    def score_move(self, new_pos, move_num, gs: GameState):
        score = 0.0
        # 一：逃离得分 —— 模拟幽灵最优追击后的最小距离
        future_ghosts = self.predict_ghosts(new_pos, gs)
        min_d = min(self.mdist(new_pos, g) for g in future_ghosts)
        score += self.weights["escape"] * min_d

        # 二：特殊豆子优先
        cell = gs.board[int(new_pos[0])][int(new_pos[1])]
        # 若是护盾豆或冰冻豆且当前无护盾/冰冻，就给大额加分
        if cell == Space.SHIELD_BEAN.value and gs.pacman_skill_status[Skill.SHIELD.value] == 0:
            score += self.weights["shield"] * self.bean_values[cell]
        elif cell == Space.FROZE_BEAN.value and gs.pacman_skill_status[Skill.FROZE.value] == 0:
            score += self.weights["freeze"] * self.bean_values[cell]
        # 三：磁铁效果下，3×3 范围内额外拾取
        if gs.pacman_skill_status[Skill.MAGNET.value] > 0:
            for dx in (-1,0,1):
                for dy in (-1,0,1):
                    xx, yy = int(new_pos[0]+dx), int(new_pos[1]+dy)
                    if 0<=xx<gs.board_size and 0<=yy<gs.board_size:
                        v = gs.board[xx][yy]
                        if v in self.bean_values:
                            score += self.weights["bonus"] * self.bean_values[v] / (abs(dx)+abs(dy)+1)
        # 四：普通或双倍豆权重
        if cell == Space.REGULAR_BEAN.value:
            w = 2.0 if gs.pacman_skill_status[Skill.DOUBLE_SCORE.value]>0 else 1.0
            score += self.weights["bean"] * w
        elif cell in (Space.BONUS_BEAN.value, Space.SPEED_BEAN.value, Space.DOUBLE_BEAN.value):
            score += self.weights["bonus"] * self.bean_values[cell]

        # 五：传送门策略
        rem = self.count_beans(gs)
        used = (self.init_total_beans - rem) / max(1, self.init_total_beans)
        if gs.portal_available and used>0.5 and gs.level<3:
            # 更靠近传送门得分
            pd = self.mdist(new_pos, gs.portal_coord)
            score -= pd  # 距离越小越好

        return score

    def choose_move(self, gs: GameState):
        # 初始化总豆数
        if gs.round == 1:
            self.init_total_beans = self.count_beans(gs)
            self.history.clear()

        pac = np.array(gs.pacman_pos)
        best, best_score = Direction.STAY.value, -1e9
        for npac, mv in self.get_valid_moves(pac, gs):
            sc = self.score_move(npac, mv, gs)
            if sc > best_score:
                best_score, best = sc, mv

        # 更新历史
        self.history.append(tuple(gs.pacman_pos))
        return [best]

# 最终将 ai_func 指向新 AI
ai_func = PacmanAI().choose_move
__all__ = ["ai_func"]

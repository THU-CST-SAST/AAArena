# Rollman 角色（Pacman）Python 模板

本目录是 Rollman 非对称对局中 **rollman/Pacman** 角色的历史恢复模板。它只能用于
`rollman` 角色，不能作为 Ghost 模板；Ghost 必须使用同 GamePack 中的
`public_sdk-ghost/`。来源和恢复哈希见 `SDK_PROVENANCE.json`。

## 使用

先在 AA-Arena 环境安装 Rollman 的固定依赖：

```bash
python3 -m pip install -e '.[rollman]'
cp -R games/rollman/public_sdk-rollman ./my-rollman-player
```

选手根目录必须保留 `main.py`。默认策略钩子在 `ai.py` 末尾的 `ai_func`：它接收
`GameState`，并返回一个 Pacman 方向。可以替换 `ai_func`，但不要将 Ghost 的三方向
返回值接入此入口。

AA-Arena 启动选手时会设置 `AGENTBENCH_ROLE=rollman`，作为角色语境。此模板的协议
代码本身已固定调用 `pacman_to_judger`，因此环境变量不会将它自动转换为 Ghost；
模板目录必须与角色保持一致。

```python
from agentbench.core import PlayerRef

rollman = PlayerRef("my-rollman-ai", code_path="/absolute/path/to/my-rollman-player")
```

该目录复制后可独立运行 `python main.py`，不需要导入 AA-Arena 内部模块。

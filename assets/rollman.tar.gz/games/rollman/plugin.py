"""Rollman 游戏插件声明 —— 被框架 Core 的注册表发现。

框架通过本文件顶层的 `PLUGIN` 发现 rollman，无需修改框架源码。

可运行对战器落在本目录同级的 `evaluator/`（游戏资产，属 A）：定位本 GamePack 的
官方 **Python** 后端 `backend/`，用官方长度
前缀 stdio 判题协议驱动一名吃豆人 (rollman) 与一名幽灵 (ghost) 选手（来自统一池
`games/rollman/players/pool/`）对战，解析 JSONL 回放后返回契约要求的 `EvaluateResult`。
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from aa_arena.core import Evaluator, GamePlugin


def _load_evaluator_module():
    """把本目录的 `evaluator/` 作为独立包加载（plugin.py 非包上下文，无法相对 import）。"""

    evaluator_dir = Path(__file__).resolve().parent / "evaluator"
    package_name = "aa_arena_games_rollman_evaluator"
    spec = importlib.util.spec_from_file_location(
        package_name,
        evaluator_dir / "__init__.py",
        submodule_search_locations=[str(evaluator_dir)],
    )
    if spec is None or spec.loader is None:  # pragma: no cover - defensive
        raise ImportError(f"cannot load rollman evaluator from {evaluator_dir}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)
    return module


def _make_evaluator(game_dir: Path) -> Evaluator:
    module = _load_evaluator_module()
    return module.make_evaluator(game_dir)


PLUGIN = GamePlugin(
    name="rollman",
    evaluator_factory=_make_evaluator,
    display_name="Rollman / 卷王吃豆人",
    roles=("rollman", "ghost"),
    roles_symmetric=False,  # 非对称：吃豆人 vs 幽灵，规则与目标完全不同
)

"""Rollman role placement and terminal result interpretation."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]

ROLE_PACMAN = 0
ROLE_GHOST = 1


class RollmanMatchError(RuntimeError):
    """The Rollman terminal payload is malformed."""


class RollmanBackendError(RollmanMatchError):
    """The game backend or its runtime failed before producing a terminal frame."""


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if self.role not in ("rollman", "ghost"):
            raise ValueError("match role must be 'rollman' or 'ghost'")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise TypeError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or not self.error:
                raise ValueError("incomplete match requires an error and no outcome")
        else:
            raise ValueError(f"unknown match status: {self.status}")


def run_native_match(
    *,
    game: ProcessSpec,
    pacman_process: ProcessSpec,
    ghost_process: ProcessSpec,
    pacman_player: int,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    players = (
        (pacman_process, ghost_process)
        if pacman_player == 0
        else (ghost_process, pacman_process)
    )
    try:
        judged = run_stdio_match(
            backend=game,
            players=players,
            config={"random_seed": case.seed},
            replay_path=replay_path,
            events_path=events_path,
            timeout_s=timeout_s,
        )
    except SaibloJudgerError as exc:
        raise RollmanBackendError(str(exc)) from exc
    return _result_from_end(
        case,
        dict(judged.end_message),
        replay_path,
        events_path,
        tuple(judged.process_returncodes[:3]),
    )


def _result_from_end(
    case: MatchCase,
    end_message: dict[str, Any],
    replay_path: Path,
    events_path: Path,
    returncodes: tuple[int, int, int],
) -> MatchResult:
    raw_scores = end_message.get("end_info")
    if isinstance(raw_scores, str):
        try:
            raw_scores = json.loads(raw_scores)
        except json.JSONDecodeError as exc:
            raise RollmanMatchError("terminal end_info is not valid JSON") from exc
    if not isinstance(raw_scores, dict):
        raise RollmanMatchError("terminal end_info missing scores")
    try:
        score0 = float(raw_scores["0"])
        score1 = float(raw_scores["1"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RollmanMatchError("terminal scores are malformed") from exc
    winner_player = 0 if score0 >= score1 else 1
    won = winner_player == 0
    return MatchResult(
        case=case,
        status="complete",
        result="win" if won else "loss",
        rounds=_count_replay_rounds(replay_path),
        payload={
            "terminal_scores": (score0, score1),
            "winner_player": winner_player,
            "end_state": end_message.get("end_state"),
        },
        replay_path=replay_path,
        events_path=events_path,
        process_returncodes=returncodes,
    )


def _count_replay_rounds(replay_path: Path) -> int:
    try:
        from .replay import load_replay, round_count

        return round_count(load_replay(replay_path))
    except Exception:  # noqa: BLE001 - rounds are best-effort
        return 0


class RollmanArena:
    def __init__(
        self,
        *,
        game: ProcessSpec,
        pacman: ProcessSpec,
        ghost: ProcessSpec,
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
    ) -> None:
        self.game = game
        self.pacman = pacman
        self.ghost = ghost
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)

    def run_case(self, case: MatchCase) -> MatchResult:
        pacman_player = 0 if case.role == "rollman" else 1
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role
            / f"seed-{case.seed}"
        )
        try:
            return run_native_match(
                game=self.game,
                pacman_process=self.pacman,
                ghost_process=self.ghost,
                pacman_player=pacman_player,
                case=case,
                replay_path=root / "replay.jsonl",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except RollmanBackendError:
            raise
        except (RollmanMatchError, TimeoutError, OSError, subprocess.TimeoutExpired) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                rounds=None,
                error=str(exc),
            )

"""Rollman 官方回放解码（游戏资产），属仓库 A。

Rollman 后端每回合把 ``env.render()`` 的状态字典逐行写入回放文件（**JSONL**，见
`main.py`：``replay_file.write(json.dumps(state)+"\n")``）：

- 第一行：``env.reset()`` 的初始局面（含 ``board`` / ``pacman_coord`` / ``ghosts_coord``
  / ``pacman_skill_status`` / ``portal_coord`` 等，均已 ``.tolist()`` 化）。
- 之后每行：一次 ``env.step`` 后的 ``new_state``（含 ``round`` / ``level`` / ``score``
  / 坐标 / 事件等）。
- 关卡切换(``level_change``)时会再写一行新的 reset 局面。
- 末行：带 ``StopReason`` 的终局状态。

本模块把 JSONL 逐行解析为字典列表，并抽取评测所需摘要（不依赖框架层）。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class RollmanReplayError(RuntimeError):
    """回放文件缺失或无法解析。"""


def load_replay(path: Path) -> list[dict[str, Any]]:
    replay_path = Path(path)
    if not replay_path.is_file():
        raise RollmanReplayError(f"replay file not found: {replay_path}")
    frames: list[dict[str, Any]] = []
    with replay_path.open(encoding="utf-8", errors="strict") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                # 末尾可能夹带 traceback 文本（后端异常分支），跳过非 JSON 行。
                continue
            if isinstance(obj, dict):
                frames.append(obj)
    if not frames:
        raise RollmanReplayError("replay contains no decodable state frames")
    return frames


def round_count(frames: list[dict[str, Any]]) -> int:
    """对局进行的回合数：取回放中出现的最大 ``round`` 字段；缺失时退化为状态帧数。"""
    rounds = [int(frame["round"]) for frame in frames if isinstance(frame.get("round"), (int, float))]
    if rounds:
        return max(rounds)
    return len(frames)


def final_scores(frames: list[dict[str, Any]]) -> tuple[float, float] | None:
    """回放末帧的 ``score`` = ``[pacman_score, ghosts_score]``（若存在）。"""
    for frame in reversed(frames):
        score = frame.get("score")
        if isinstance(score, list) and len(score) == 2:
            return float(score[0]), float(score[1])
    return None


def stop_reason(frames: list[dict[str, Any]]) -> str | None:
    for frame in reversed(frames):
        reason = frame.get("StopReason")
        if isinstance(reason, str):
            return reason
    return None


def summarize(path: Path) -> dict[str, Any]:
    frames = load_replay(path)
    scores = final_scores(frames)
    last = frames[-1]
    return {
        "state_frames": len(frames),
        "rounds": round_count(frames),
        "final_level": last.get("level"),
        "pacman_ghost_score": scores,
        "stop_reason": stop_reason(frames),
    }

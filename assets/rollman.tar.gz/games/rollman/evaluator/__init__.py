"""Rollman 对战器 —— 满足 `aa_arena.core.Evaluator` 协议的可运行实现。

Rollman 是**非对称**双人博弈：``roles=["rollman","ghost"]`` —— ``players[0]`` 扮吃豆人
(pacman)、``players[1]`` 扮幽灵 (ghost)，或按传入 roles 互换。本包对外暴露
`RollmanEvaluator`，其 `evaluate(players, roles, seed) -> EvaluateResult` 遵循
`docs/evaluator-contract.md`：

- 定位本 GamePack 的官方 **Python** 后端（`backend/`，需 numpy），
  无需编译，直接 `python main.py` 启动，可复现于全新 checkout；
- 用官方长度前缀 stdio 判题协议驱动后端与一名 pacman + 一名 ghost 选手完成一局；
- 解析 JSONL 回放，返回可解析、可复现的 `EvaluateResult`；
- 三态：后端/环境/依赖(numpy)故障 = `infra_error`；选手超时/非法/崩溃 = `game_error`；
  正常终局 = `complete`。

由于统一池中选手多为**单角色特化**，evaluator 会依据 roles 把两名 PlayerRef 分别解析为
实现 pacman / ghost 的可运行选手。
"""

from __future__ import annotations

import sys
from pathlib import Path

from aa_arena.core.buildcache import backend_run_dir
from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError, player_command
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    ROLE_GHOST,
    ROLE_PACMAN,
    MatchCase,
    MatchResult,
    ProcessSpec,
    RollmanArena,
    RollmanBackendError,
    RollmanMatchError,
    run_native_match,
)
from .replay import RollmanReplayError, load_replay, summarize
from .runtime import (
    CppBuildError,
    Opponent,
    RollmanLayout,
    RollmanRuntimeError,
    audit_human_pool,
    build_player,
    first_runnable_with_role,
    has_cpp_build,
    resolve_opponent,
    tree_sha256,
)

__all__ = [
    "MatchCase",
    "MatchResult",
    "Opponent",
    "ProcessSpec",
    "RollmanArena",
    "RollmanEvaluator",
    "RollmanLayout",
    "RollmanMatchError",
    "RollmanReplayError",
    "RollmanRuntimeError",
    "audit_human_pool",
    "load_replay",
    "make_evaluator",
    "resolve_opponent",
    "run_native_match",
    "summarize",
    "tree_sha256",
]

_ROLE_NAME = {ROLE_PACMAN: "pacman", ROLE_GHOST: "ghost"}


def _python_entry_root(package_root: Path) -> Path | None:
    candidates = sorted(
        package_root.rglob("main.py"),
        key=lambda path: (len(path.relative_to(package_root).parts), path.as_posix()),
    )
    for candidate in candidates:
        if "__pycache__" in candidate.parts:
            continue
        return candidate.parent
    return None


def _resolve_role_player(
    player: PlayerRef,
    *,
    wanted_role: int,
    pool: tuple[Opponent, ...],
) -> Path:
    """把一个 PlayerRef 解析为实现 ``wanted_role`` 的可运行选手入口目录。"""

    if player.code_path is not None:
        root = Path(player.code_path).resolve()
        entry = _python_entry_root(root)
        if entry is not None:
            return entry
        if has_cpp_build(root):
            return root
        raise RollmanMatchError(f"player code path has no runnable entry: {root}")

    opponent = resolve_opponent(pool, player.player_id, required_role=wanted_role)
    if opponent is not None and (opponent.role == wanted_role or opponent.role is None):
        return opponent.entry_root
    # 回退：池中任意实现该角色的可运行选手（保证一局能真正跑起来）。
    fallback = first_runnable_with_role(pool, wanted_role)
    if fallback is not None:
        return fallback.entry_root
    raise RollmanMatchError(
        f"cannot resolve a runnable {_ROLE_NAME[wanted_role]} player for "
        f"{player.player_id!r} in the frozen human pool"
    )


class RollmanEvaluator:
    """Rollman 对战器：给定两名选手、角色 (rollman/ghost) 与种子，跑一局并返回契约结果。"""

    def __init__(
        self,
        game_dir: Path,
        *,
        artifact_root: Path | None = None,
        build_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        self.aa_arena_root = self.game_dir.parents[1]
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "rollman-matches"
        )
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "rollman-build"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(
        self,
        players: list[PlayerRef],
        roles: list[str],
        seed: int,
    ) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"rollman requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"rollman", "ghost"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"rollman roles must be a permutation of [rollman, ghost], got {roles}",
            )

        layout = RollmanLayout.from_game_dir(self.game_dir)
        try:
            layout.validate()
            pool = audit_human_pool(layout)
        except (RollmanRuntimeError, FileNotFoundError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        # roles[0] 对应 players[0]（judger 玩家 0）。rollman==pacman。
        role0 = ROLE_PACMAN if roles[0] == "rollman" else ROLE_GHOST
        role1 = ROLE_PACMAN if roles[1] == "rollman" else ROLE_GHOST
        try:
            entry0 = _resolve_role_player(players[0], wanted_role=role0, pool=pool)
            entry1 = _resolve_role_player(players[1], wanted_role=role1, pool=pool)
        except RollmanMatchError as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))

        # 组装 pacman / ghost 进程（判题器玩家 0 用 entry0，玩家 1 用 entry1）。
        #
        # 显式把**角色**告诉选手进程。这是 rollman 独有的必需品：判题器开局只下发
        # 座位号（0/1），而官方 SDK 里 `id == 0` 与 `else` 两个分支调用的是**同一个**
        # 提交函数——座位号只决定"先发还是后发"，角色是选手自己在协议里声明的
        # （`pacman_to_judger` 发 role=0、`ghost_to_judger` 发 role=1）。
        # 人类选手当年知道自己交的是吃豆人还是幽灵；LLM 候选在一个 run 里要用
        # **同一份代码**打两个角色，必须有人告诉它这一局坐哪边，否则只能瞎猜。
        # 注意选手环境走白名单（见 arena._safe_environment），不显式传就传不进去。
        # 注意传的是**契约角色名**（roles[i]，取值 "rollman"/"ghost"），不是内部的
        # ROLE_PACMAN/ROLE_GHOST 整数编号（0/1）。候选包里的 SDK 子目录是按契约
        # 角色名命名的（rollman_sdk / ghost_sdk），传 0/1 会让候选拿到 "0" 而认不出角色。
        try:
            command = player_command()
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )
        def player_spec(entry: Path, role: str) -> ProcessSpec:
            environment = {"AA_ARENA_ROLE": role}
            python_root = _python_entry_root(entry)
            if python_root is not None:
                return ProcessSpec(command, python_root, environment)
            if has_cpp_build(entry):
                executable = build_player(entry, self._build_root / "players")
                bridge = executable.parent / "rollman_bridge.py"
                if bridge.is_file():
                    return ProcessSpec(
                        player_command(bridge.name),
                        executable.parent,
                        environment,
                    )
                return ProcessSpec((str(executable),), executable.parent, environment)
            raise RollmanRuntimeError(f"player has no runnable entry: {entry}")

        try:
            spec0 = player_spec(entry0, roles[0])
        except CppBuildError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=roles[1],
                diagnostic=f"candidate build failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"candidate build infrastructure failed: {exc}",
            )
        try:
            spec1 = player_spec(entry1, roles[1])
        except CppBuildError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=roles[0],
                diagnostic=f"opponent build failed: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"opponent build infrastructure failed: {exc}",
            )
        if role0 == ROLE_PACMAN:
            pacman_spec, ghost_spec = spec0, spec1
        else:
            pacman_spec, ghost_spec = spec1, spec0

        case = MatchCase(players[0].player_id, players[1].player_id, roles[0], seed)
        # 后端必须在**可写、每局独占**的目录里跑，不能直接用 A 仓源码树
        # （详见 aa_arena.core.buildcache.backend_run_dir）。
        # 注意 rollman 没有 build_root，artifact_root 的默认值还落在 A 仓里，
        # 所以这里依赖 backend_run_dir 的降级链：artifact_root 不可写就用系统临时目录。
        try:
            with backend_run_dir(
                layout.backend_source_root, parent=self._artifact_root, tag="rollman-backend"
            ) as backend_cwd:
                arena = RollmanArena(
                    game=ProcessSpec((sys.executable, "main.py"), backend_cwd),
                    pacman=pacman_spec,
                    ghost=ghost_spec,
                    artifact_root=self._artifact_root,
                    timeout_s=self.timeout_s,
                )
                result = arena.run_case(case)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )
        except RollmanBackendError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend runtime/dependency fault: {exc}",
            )
        except OSError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend run dir preparation failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        return self._to_evaluate_result(result, roles)

    def _to_evaluate_result(self, result: MatchResult, roles: list[str]) -> EvaluateResult:
        scores_tuple = result.payload.get("terminal_scores")
        if not (isinstance(scores_tuple, tuple) and len(scores_tuple) == 2):
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic="complete match missing terminal_scores payload",
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )
        # terminal_scores 为 judger 玩家 (0, 1) 顺序；roles[0]/roles[1] 是其角色名。
        scores = {roles[0]: float(scores_tuple[0]), roles[1]: float(scores_tuple[1])}
        winner_player = int(result.payload.get("winner_player", 0))
        winner = roles[0] if winner_player == 0 else roles[1]
        return EvaluateResult(
            status=EvaluationStatus.COMPLETE,
            winner=winner,
            scores=scores,
            rounds=result.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
        )


def make_evaluator(game_dir: Path) -> RollmanEvaluator:
    """插件工厂：供 `games/rollman/plugin.py` 装配对战器。"""

    return RollmanEvaluator(game_dir)

"""Frozen Rollman (Pacman) backend location and human-pool audit.

Rollman(29 号，吃豆人对抗)对战器内核（游戏资产），属仓库 A。官方后端是 **Python**
（本 GamePack 的 `backend/`，依赖 numpy），无需编译，以 `python main.py`
（cwd 指向 `backend/`）启动。本模块负责：

- 定位官方 Python 后端源码目录（可复现于全新 checkout）；
- 审计冻结的人类天梯选手池（`games/rollman/players/pool/`）。

Rollman 是**非对称**双人博弈：一名玩家扮 **吃豆人 (pacman, role=0)**，另一名扮
**幽灵 (ghost, role=1)**。池中选手多为**单角色特化**（要么只会 pacman，要么只会 ghost），
因此本模块在审计时会**探测每个选手实际实现的角色**，供 evaluator 按角色匹配。

本模块不依赖任何框架层。
"""

from __future__ import annotations

import ast
import csv
import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    CppBuildError as CppBuildError,
    build_player as build_player,
    has_cpp_build as has_cpp_build,
)


class RollmanRuntimeError(RuntimeError):
    """A frozen runtime resource failed an integrity requirement."""


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)


def tree_sha256(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RollmanRuntimeError(f"runtime tree contains a symlink: {path}")
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return digest.hexdigest()


@dataclass(frozen=True)
class RollmanLayout:
    """Rollman 后端与人类池在仓库内的物理布局。"""

    aa_arena_root: Path
    backend_source_root: Path
    backend_main: Path
    human_manifest: Path
    human_extracted_root: Path

    @classmethod
    def from_game_dir(cls, game_dir: str | Path) -> RollmanLayout:
        game = Path(game_dir).resolve()
        players = game / "players"
        backend = game / "backend"
        return cls(
            aa_arena_root=game.parents[1],
            backend_source_root=backend,
            backend_main=backend / "main.py",
            human_manifest=players / "manifest.tsv",
            human_extracted_root=players / "pool",
        )

    @classmethod
    def from_root(cls, aa_arena_root: str | Path) -> RollmanLayout:
        return cls.from_game_dir(Path(aa_arena_root) / "games" / "rollman")

    def backend_fingerprint(self) -> str:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        return tree_sha256(self.backend_source_root)

    def validate(self) -> None:
        if not self.backend_main.is_file():
            raise FileNotFoundError(self.backend_main)
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_extracted_root.is_dir():
            raise FileNotFoundError(self.human_extracted_root)


# role 常量（与后端 core.gamedata.Role 对齐）。
ROLE_PACMAN = 0
ROLE_GHOST = 1


@dataclass(frozen=True)
class Opponent:
    """人类池中一个可解析的选手（rank 锚点 + 实现角色）。"""

    opponent_id: str
    rank: int | None
    username: str | None
    entity: str | None
    package_root: Path
    entry_root: Path
    archive_sha256: str
    runnable: bool
    lang: str | None
    role: int | None                     # ROLE_PACMAN / ROLE_GHOST / None(未知)
    exclusion_diagnostic: str | None


_PACMAN_SIGNATURES = (
    re.compile(r"pacman_op\s*\(\s*self"),
    re.compile(r"pacman_to_judger\s*\("),
    re.compile(r'"role"\s*:\s*0'),
)
_GHOST_SIGNATURES = (
    re.compile(r"ghosts_op\s*\(\s*self"),
    re.compile(r"ghost_to_judger\s*\("),
    re.compile(r'"role"\s*:\s*1'),
)


def _find_python_entry(package_root: Path) -> Path | None:
    """定位可运行的 Python 入口目录（含 `main.py`），取深度最浅、字典序最小者。"""

    candidates = sorted(
        package_root.rglob("main.py"),
        key=lambda path: (len(path.relative_to(package_root).parts), path.as_posix()),
    )
    for candidate in candidates:
        if "__pycache__" in candidate.parts:
            continue
        return candidate.parent
    return None


def _entry_call_names(main_py: Path) -> set[str]:
    """从 ``main.py`` 的调用图里取"**从入口可达**的调用名"。

    为什么不能直接 grep 文本：Saiblo 官方模板在 ``main.py`` 里**同时定义**
    ``pacman_op`` 与 ``ghosts_op`` 两个函数，真正的提交只在 ``Controller.run``
    里调用其中一个。直接 grep 会在每个包里同时命中两边（``pacman_op`` 的函数体内
    必然出现 ``pacman_to_judger``），把所有选手都判成"歧义"。
    因此这里遍历 AST，**跳过这两个函数自身的函数体**，只看其余位置的调用。
    """

    if not main_py.is_file():
        return set()
    try:
        tree = ast.parse(main_py.read_text(encoding="utf-8", errors="ignore"))
    except (OSError, SyntaxError):
        return set()

    skip = {"pacman_op", "ghosts_op", "ghost_op"}
    names: set[str] = set()

    class Collector(ast.NodeVisitor):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            if node.name in skip:
                return
            self.generic_visit(node)

        visit_AsyncFunctionDef = visit_FunctionDef  # type: ignore[assignment]

        def visit_Call(self, node: ast.Call) -> None:
            target = node.func
            if isinstance(target, ast.Name):
                names.add(target.id)
            elif isinstance(target, ast.Attribute):
                names.add(target.attr)
            self.generic_visit(node)

    Collector().visit(tree)
    return names


def _detect_role(entry_root: Path) -> int | None:
    """通过扫描入口目录的源码，判断该选手实现的是 pacman 还是 ghost。

    依据官方 SDK 约定：main.py 里调用 ``pacman_op``/``pacman_to_judger`` 或声明
    ``"role": 0`` 即 pacman；``ghosts_op``/``ghost_to_judger`` 或 ``"role": 1`` 即 ghost。

    判定顺序（可靠性递减）：
    1. 入口目录名（``PacmanSDK-python`` / ``GhostsSDK-python`` 等官方 SDK 名）；
    2. ``main.py`` 的**调用图**（见 ``_entry_call_names``）；
    3. ``main.py`` 里的 ``"role": 0|1`` 字面量。

    **不看** ``ai_to_judger.py``：它是官方模板，两个提交函数都在，没有区分度。
    """

    # 1) 目录名强信号。
    name = entry_root.as_posix().lower()
    if "pacman" in name and "ghost" not in name:
        return ROLE_PACMAN
    if "ghost" in name and "pacman" not in name:
        return ROLE_GHOST

    # 2) 调用图信号。
    calls = _entry_call_names(entry_root / "main.py")
    pac_call = bool(calls & {"pacman_op", "pacman_to_judger"})
    gho_call = bool(calls & {"ghosts_op", "ghost_op", "ghost_to_judger"})
    if pac_call != gho_call:
        return ROLE_PACMAN if pac_call else ROLE_GHOST

    # 3) role 字面量信号。
    main_py = entry_root / "main.py"
    blob = main_py.read_text(encoding="utf-8", errors="ignore") if main_py.is_file() else ""
    pac = any(pattern.search(blob) for pattern in _PACMAN_SIGNATURES)
    gho = any(pattern.search(blob) for pattern in _GHOST_SIGNATURES)
    if pac and not gho:
        return ROLE_PACMAN
    if gho and not pac:
        return ROLE_GHOST
    # 二者都出现（双角色 SDK）或都没有：交由调用方进一步判定。
    return None


# ---------------------------------------------------------------------------
# 公开原语：供框架侧（B 仓）复用，避免在框架里重复实现游戏语义
# ---------------------------------------------------------------------------

TRACK_ROLLMAN = "rollman"
TRACK_GHOST = "ghost"


def player_entry_root(package_root: str | Path) -> Path | None:
    """选手包的可运行入口目录（含 ``main.py``），找不到返回 ``None``。

    rollman 的提交**普遍嵌套一层**（如 ``<pkg>/PacmanSDK-python/main.py``）：
    309 个包里 188 个是这种结构，只有 93 个在根目录放 main.py。
    任何"只看包根目录有没有 main.py"的判断都会把三分之二的选手误判为不可运行。
    """

    return _find_python_entry(Path(package_root))


def player_track(package_root: str | Path) -> str | None:
    """选手实现的角色天梯：``"rollman"`` / ``"ghost"``，判不出返回 ``None``。

    rollman 是非对称游戏，每份提交只实现一个角色（pacman 或 ghost）。
    因此：**不能用对称 self-play 审计**（同一份 ghost 提交放两个座位会双方 0 分），
    评分也必须按角色分成两条天梯。
    """

    entry = _find_python_entry(Path(package_root))
    if entry is None:
        return None
    role = _detect_role(entry)
    if role == ROLE_PACMAN:
        return TRACK_ROLLMAN
    if role == ROLE_GHOST:
        return TRACK_GHOST
    return None


def audit_human_pool(layout: RollmanLayout) -> tuple[Opponent, ...]:
    """从 `players/manifest.tsv` 读取选手并解析为可运行对手（含实现角色）。"""

    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rel_dir = (row.get("dir") or "").strip()
            player_id = (row.get("player_id") or "").strip()
            if rel_dir:
                package = (layout.human_manifest.parent / rel_dir).resolve()
            elif player_id:
                package = (layout.human_extracted_root / player_id).resolve()
            else:
                continue
            if not package.is_dir():
                continue
            entry_root = _find_python_entry(package)
            runnable = entry_root is not None
            rank_raw = (row.get("rank") or "").strip()
            pool.append(
                Opponent(
                    opponent_id=player_id or package.name,
                    rank=int(rank_raw) if rank_raw else None,
                    username=(row.get("username") or None),
                    entity=(row.get("entity") or None),
                    package_root=package,
                    entry_root=entry_root if entry_root is not None else package,
                    archive_sha256=tree_sha256(package),
                    runnable=runnable,
                    lang=(row.get("lang") or None),
                    role=_detect_role(entry_root) if runnable else None,
                    exclusion_diagnostic=(
                        None if runnable else "no runnable python main.py entry point"
                    ),
                )
            )
    pool.sort(key=lambda item: ((item.rank if item.rank is not None else 9999),
                                item.opponent_id))
    return tuple(pool)


def resolve_opponent(
    pool: tuple[Opponent, ...],
    player_id: str,
    *,
    required_role: int | None = None,
) -> Opponent | None:
    """把 `rankNN` / 具体 player_id 解析为池中匹配（且角色相符）的可运行选手。"""

    def role_ok(candidate: Opponent) -> bool:
        return required_role is None or candidate.role == required_role

    # 1) 精确 player_id 命中（目录名）。
    for opponent in pool:
        if opponent.opponent_id == player_id and opponent.runnable:
            return opponent
    # 2) rank 别名命中：rankNN 取该 rank 下第一个可运行且角色相符的选手。
    match = re.fullmatch(r"rank0*([0-9]+)", player_id)
    if match:
        wanted_rank = int(match.group(1))
        for opponent in pool:
            if opponent.rank == wanted_rank and opponent.runnable and role_ok(opponent):
                return opponent
        # 放宽：同 rank 下任意可运行选手（角色由 arena 侧再校验）。
        for opponent in pool:
            if opponent.rank == wanted_rank and opponent.runnable:
                return opponent
    return None


def first_runnable_with_role(pool: tuple[Opponent, ...], role: int) -> Opponent | None:
    for opponent in pool:
        if opponent.runnable and opponent.role == role:
            return opponent
    return None

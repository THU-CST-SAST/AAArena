"""Rollman 回放 → 自然语言。

Rollman（第 29 届）是 8 个游戏里唯一的**非对称**对局：一方是吃豆人（每回合交 1 个
方向），另一方操控 3 只幽灵（每回合交 3 个方向）。回放是 **JSONL**，每行一个
``env.render()`` 的状态快照，复用同目录 `replay.py` 的加载器。

非对称对叙述的影响是根本性的：**同一份回放对两个角色的意义完全不同**。
吃豆人要知道"我是在哪一步被围住的"，幽灵要知道"我们的包夹在哪一步漏了"。
所以这里的叙述强依赖 ``context.perspective``，并且两侧的重点段落不一样。

另一个必须讲清的结构：Rollman 有**关卡**（``level``）。关卡切换时后端会重写一行
reset 局面，``round`` 会归位。如果按 ``round`` 单调递增去读，会看到回合数"倒退"，
所以时间轴必须用**全局帧序**，把 level 作为叙述里的分段标记。
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import Document, Event, budget_lines, render_events

from . import replay as replay_decoder

_DIRECTIONS = {0: "不动", 1: "上", 2: "左", 3: "下", 4: "右"}

#: 吃豆人技能状态向量的含义（``pacman_skill_status``）。
_SKILLS = ("双倍得分", "护盾", "冻结幽灵", "加速", "穿墙")


def _role_of(context: NarrationContext) -> str:
    """归一化角色名：配置里可能写 rollman/pacman/ghost。"""

    raw = (context.perspective or "").lower()
    if "ghost" in raw:
        return "ghost"
    if raw:
        return "pacman"
    return "neutral"


def _label(context: NarrationContext, side: str) -> str:
    own = _role_of(context)
    name = "吃豆人" if side == "pacman" else "幽灵方"
    if own == "neutral":
        return name
    return f"你({name})" if own == side else f"对手({name})"


def _coord(value: Any) -> str:
    if isinstance(value, list) and len(value) == 2:
        return f"({value[0]},{value[1]})"
    return str(value)


def _verdict(
    frames: Sequence[Mapping[str, Any]], context: NarrationContext
) -> tuple[list[str], str | None, int]:
    last = frames[-1]
    scores = replay_decoder.final_scores(list(frames))
    rounds = context.official_rounds or replay_decoder.round_count(list(frames))
    reason = replay_decoder.stop_reason(list(frames))

    winner = context.official_winner
    # The evaluator uses "rollman", while this renderer labels that side
    # "pacman". Normalize only for display and perspective comparisons.
    if winner == "rollman":
        winner = "pacman"
    if winner is None and scores is not None:
        if scores[0] > scores[1]:
            winner = "pacman"
        elif scores[1] > scores[0]:
            winner = "ghost"

    lines: list[str] = []
    own = _role_of(context)
    if winner is None:
        lines.append("- 官方裁决：平局或未分出胜负。")
    elif own == "neutral":
        lines.append(f"- 胜者：{'吃豆人' if winner == 'pacman' else '幽灵方'}。")
    elif winner == own:
        lines.append(f"- **你赢了**（{_label(context, own)}）。")
    else:
        lines.append(f"- **你输了**，胜者是 {_label(context, winner)}。")
    if scores is not None:
        lines.append(
            f"- 终局比分：{_label(context, 'pacman')}={scores[0]:g} / "
            f"{_label(context, 'ghost')}={scores[1]:g}。"
        )
    lines.append(
        f"- 打到第 {last.get('level', '?')} 关，共 {rounds} 回合 / {len(frames)} 个状态帧。"
    )
    if reason:
        lines.append(f"- 终止原因：{reason}。")
    if context.diagnostic:
        lines.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")
    return lines, context.official_winner or winner, rounds


def _pressure_timeline(
    frames: Sequence[Mapping[str, Any]], context: NarrationContext
) -> list[str]:
    """包夹与逃脱：吃豆人被抓、关卡推进、技能触发。

    这是双方共同关心的那条主线 —— 吃豆人看"我怎么被抓的"，幽灵看"我们哪次没抓住"。
    """

    lines: list[str] = []
    previous_level = None
    previous_score: tuple[float, float] | None = None
    for index, frame in enumerate(frames):
        level = frame.get("level")
        if previous_level is not None and level != previous_level:
            lines.append(
                f"- 帧 {index}：**进入第 {level} 关**（上一关结束，局面重置、坐标归位）。"
            )
        previous_level = level
        score = frame.get("score")
        if isinstance(score, list) and len(score) == 2:
            try:
                current = (float(score[0]), float(score[1]))
            except (TypeError, ValueError):
                current = None  # type: ignore[assignment]
            if current is not None and previous_score is not None:
                ghost_gain = current[1] - previous_score[1]
                if ghost_gain != 0:
                    lines.append(
                        f"- 帧 {index}（第 {frame.get('round')} 回合）："
                        f"幽灵方比分 {previous_score[1]:g}→{current[1]:g}（{ghost_gain:+g}）。"
                    )
                pacman_gain = current[0] - previous_score[0]
                if pacman_gain != 0:
                    lines.append(
                        f"- 帧 {index}（第 {frame.get('round')} 回合）："
                        f"吃豆人比分 {previous_score[0]:g}→{current[0]:g}（{pacman_gain:+g}）。"
                    )
            if current is not None:
                previous_score = current
        skills = frame.get("pacman_skill_status")
        if isinstance(skills, list):
            active = [
                _SKILLS[position]
                for position, value in enumerate(skills)
                if position < len(_SKILLS) and value
            ]
            if active and index and index % 40 == 0:
                lines.append(f"- 帧 {index}：吃豆人当前生效技能：{'、'.join(active)}。")
    return lines or ["- 相邻状态帧中的比分与关卡编号均未变化。"]


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    frames = replay_decoder.load_replay(replay_path)
    verdict, winner, rounds = _verdict(frames, context)

    events: list[Event] = []
    for index, frame in enumerate(frames):
        round_index = frame.get("round")
        round_index = int(round_index) if isinstance(round_index, (int, float)) else index
        pacman = frame.get("pacman_coord")
        ghosts = frame.get("ghosts_coord")
        pieces: list[str] = []
        if pacman is not None:
            pieces.append(f"吃豆人 @{_coord(pacman)}")
        if isinstance(ghosts, list) and ghosts:
            pieces.append("幽灵 @" + "、".join(_coord(item) for item in ghosts))
        if not pieces:
            continue
        events.append(
            Event(
                round=round_index,
                actor=f"L{frame.get('level', '?')}",
                text="；".join(pieces),
                ref=f"frame{index:05d}",
                # 位置逐帧推进本身是连续的；只有比分/关卡变化才是关键事件。
                fold_key="drift",
                fold_label="双方位置推进（无得分与关卡变化）",
            )
        )

    doc = Document(
        title=(
            f"Rollman 对局叙述：{context.match_id}"
            + (f" vs {context.opponent_id}" if context.opponent_id else "")
        ),
        subtitle=(
            f"非对称对局（吃豆人 1 方向 / 幽灵 3 方向），共 {rounds} 回合 / "
            f"{len(frames)} 个状态帧。由 A 仓 `aa_arena.replay` 从官方回放翻译。"
            "⚠️ 有关卡切换，时间轴按全局帧序，`round` 会在换关时归位。"
        ),
    )
    doc.section("终局事实", verdict)
    state_lines = _pressure_timeline(frames, context)
    if context.detail != "full":
        state_lines = budget_lines(state_lines, 160)
    doc.section("状态变化与数值增量", state_lines)
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=190)
    doc.section("可观测动作", timeline or ["- 回放未记录位置状态。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=190。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="rollman",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights=replay_decoder.summarize(replay_path),
    )

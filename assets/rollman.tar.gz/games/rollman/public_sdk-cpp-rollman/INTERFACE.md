# Rollman pacman C++ strategy interface

This starter compiles the editable strategy in `main.cpp`. The top-level `rollman_bridge.py` process uses the byte-preserved official Python simulator to track level transitions and owns referee framing.

- Build with `make`; the compiled strategy executable is `main`.
- Implement `choose_action(const Observation &observation)`.
- `observation.raw_json` contains the current board/game state, seat, role, latest level initialization, peer notification, and resolved actions.
- The bridge keeps one persistent C++ strategy process for the whole match.
- Standard output framing belongs to the bridge; the C++ strategy uses internal newline-delimited JSON input and one action-string line per decision.

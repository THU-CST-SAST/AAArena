#include <iostream>
#include <string>

namespace {
constexpr const char *kAction = "0";
}

struct Observation {
    std::string raw_json;
};

// AHL C++ strategy callback. The Python bridge owns the official simulator and
// referee framing; this persistent process receives one complete public state
// snapshot per decision and returns only the role action string.
std::string choose_action(const Observation &observation) {
    (void)observation;
    return kAction;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    std::string line;
    while (std::getline(std::cin, line)) {
        std::cout << choose_action(Observation{line}) << '\n' << std::flush;
    }
    return 0;
}

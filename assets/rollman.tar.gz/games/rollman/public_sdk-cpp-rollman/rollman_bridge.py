"""Official Rollman simulator bridge for the persistent compiled C++ strategy."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from core.GymEnvironment import PacmanEnv

ROLE = 0


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "tolist"):
        return _jsonable(value.tolist())
    if hasattr(value, "item"):
        return value.item()
    return value


def _read_line() -> str | None:
    data = sys.stdin.buffer.readline()
    if not data:
        return None
    return data.decode("utf-8", errors="replace").rstrip("\r\n")


def _send_action(action: str) -> None:
    payload = json.dumps(
        {"role": ROLE, "action": action},
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    sys.stdout.buffer.write(len(payload).to_bytes(4, "big"))
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


class Strategy:
    def __init__(self) -> None:
        executable = Path("./main").resolve()
        self.process = subprocess.Popen(
            (str(executable),),
            cwd=executable.parent,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            bufsize=1,
        )

    def decide(self, observation: dict[str, Any]) -> str:
        if self.process.stdin is None or self.process.stdout is None:
            raise RuntimeError("C++ strategy pipes are unavailable")
        self.process.stdin.write(
            json.dumps(_jsonable(observation), ensure_ascii=False, separators=(",", ":"))
            + "\n"
        )
        self.process.stdin.flush()
        action = self.process.stdout.readline()
        if not action:
            raise RuntimeError("C++ strategy exited before returning an action")
        return action.rstrip("\r\n")

    def close(self) -> None:
        if self.process.stdin is not None:
            self.process.stdin.close()
        try:
            self.process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            self.process.wait(timeout=2)


def main() -> int:
    seat_line = _read_line()
    if seat_line is None:
        return 0
    seat = int(seat_line)
    if seat not in (0, 1):
        raise ValueError(f"invalid player seat: {seat}")

    environment = PacmanEnv()
    strategy = Strategy()
    level_change = True
    level_initialization: dict[str, Any] = {}
    peer_notification = ""
    resolved_actions: dict[str, Any] = {}
    try:
        while True:
            if level_change:
                init_line = _read_line()
                if init_line is None:
                    break
                level_initialization = json.loads(init_line)
                environment.ai_reset(level_initialization)
                level_change = False

            def decide() -> str:
                state = environment.game_state().gamestate_to_statedict()
                return strategy.decide(
                    {
                        "seat": seat,
                        "role": ROLE,
                        "level_initialization": level_initialization,
                        "peer_notification": peer_notification,
                        "resolved_actions": resolved_actions,
                        "game_state": state,
                    }
                )

            if seat == 0:
                _send_action(decide())
                notification = _read_line()
                if notification is None:
                    break
                peer_notification = notification
            else:
                notification = _read_line()
                if notification is None:
                    break
                peer_notification = notification
                _send_action(decide())

            resolved_line = _read_line()
            if resolved_line is None:
                break
            resolved_actions = json.loads(resolved_line)
            _info, _pacman_reward, _ghost_reward, level_change, _eat_all = environment.step(
                resolved_actions["pacman_action"],
                resolved_actions["ghosts_action"],
            )
    finally:
        strategy.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

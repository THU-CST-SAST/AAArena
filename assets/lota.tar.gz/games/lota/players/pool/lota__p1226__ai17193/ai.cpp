#include "sdk.h"
#include<ctime>

const Pos EMPTYPOS = Pos(), DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 6, MAXLEVEL = 10, MAXID = 100;

static int fixId[MAXID];
static Pos fixPos[MAXID];
static bool towerDes[2];
typedef vector<const PUnit*> PUnits;
PUnits ours, others, nearBy, nearBy_;
static vector<Pos> blocks;

const PMap* MAP;
const PPlayerInfo* INFO;

vector<int>  id0, id1;
const Pos * tower;
const Pos tower1, tower0; // enemy
const Pos tower1_, tower0_; // self

int attack1, attack0, defend1, defend0;// step1 to attack, step0 to defend
PUnits group1, group0; // group1 to attack, group0 to defend
Pos target0_1, target0_2, target0_3; // target for group0
Pos target1_1, target1_2, target1_3, target1_4, target1_5, target1_6, target1_7, target1_8;
Pos target3_1, target3_2, target3_3; // target for group0 at step0
int minLevel;

const PUnit* belongs(int id, PUnits& units) //�ҳ�unit��ɵ�vector�а���ָ��id��unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

int unitEvaluation(string name) //����һ����λ��ս����
{
    if (name == string("Dog") || name == string("Bow"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //������з���λ��ս
        return 0;
    if (name == string("Wolf") || name == string("StoneMan"))
        return 4;
    if (name == string("Tower") || name == string("Dragon") || name == string("Roshan"))
        return HIGHLEVEL;
    return MAXLEVEL;
}

void getFoes(vector<Pos> &atk_tar, int l, int u) //���ݵȼ�Ѱ�ҵ�ͼ����Ӧ
{
    int t = unitEvaluation("Tower");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            if (!towerDes[i])
            {
                for (int j = 0; j < 5; ++j){
					if (i==0)
						atk_tar.push_back(tower[0]); //�Ӵ���������
					else
						atk_tar.push_back(tower[1]);
				}
            }
    }
    t = unitEvaluation("Dragon");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(Dragon_pos[i]);
        atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEvaluation("Wolf");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 4; ++i)
            atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEvaluation("Dog");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 6; ++i)
            atk_tar.push_back(Dog_pos[i]);
        for (int i = 0; i < 6; ++i)
            if (i % 3) //ȥ�������޷��ƶ������Ұ��
                atk_tar.push_back(Bow_pos[i]);
    }
}

void fighting(const PUnit* a, const PUnit* b, PCommand &cmd) //��λa�Ե�λb�������
{
    Operation op;
    op.id = a->id;

    vector<const PSkill*> useSkill;
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //Ѱ�ҿ��ü���
            if (belongs(b->id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }
    if (useSkill.size()) //���ԣ�����ʹ�ü���
    {
        const PSkill* ptr = useSkill[rand()%useSkill.size()];
        op.type = ptr->name;
        if (ptr->needTarget())
            op.targets.push_back(b->pos);
    } else
        if (dis2(a->pos, b->pos) <= a->range) //�жϵ�λb�Ƿ��ڹ�����Χ��
        {
            op.type = "Attack";
            op.targets.push_back(b->pos);
        } else
        {
            op.type = "Move";
			findShortestPath(*MAP, a->pos, b->pos, blocks, op.targets);
        }
    cmd.cmds.push_back(op);
}

void levelUp(const PUnit* a, PCommand &cmd) //��λa��������
{
    vector<string> level_ups;
    level_ups.push_back("YellowPoint");
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isLU() && a->canUseSkill(ptr->typeId)) //ѡ����������ļ���
            level_ups.push_back(ptr->name);
    }
    Operation op;
    op.id = a->id;
    op.type = level_ups[rand()%level_ups.size()]; //�����������
    cmd.cmds.push_back(op);
}

void findFoes(const PUnit* a, PCommand &cmd, int group) //��λaѰ�Ҷ���
{
    if ((*a)["Exp"]->val[3]) //������������
    {
        levelUp(a, cmd);
    } else
    {
        if (fixPos[a->id] == EMPTYPOS)
        {
            vector<Pos> atk_tar;
            atk_tar.clear();
            if (!towerDes[1]){
				if(group == 0){
					if(attack0 == 1)
						atk_tar.push_back(target0_1);
					else if(attack0 == 2)
						atk_tar.push_back(target0_2);
					else if(attack0 == 3)
						atk_tar.push_back(target0_1);
					else if(attack0 == 4)
						atk_tar.push_back(target0_2);
					else if(attack0 == 5)
						atk_tar.push_back(target0_3);
					else if(attack0 == 6)
						atk_tar.push_back(tower[1]);
				}
				else{
					if(attack1 == 1)
						atk_tar.push_back(target1_4);
					else if(attack1 == 2)
						atk_tar.push_back(target1_3);
					else if(attack1 == 3)
						atk_tar.push_back(target1_2);
					else if(attack1 == 4)
						atk_tar.push_back(target1_5);
					else if(attack1 == 5)
						atk_tar.push_back(target1_6);
					else if(attack1 == 6)
						atk_tar.push_back(target1_7);
					else if(attack1 == 7)
						atk_tar.push_back(target1_4);
					else if(attack1 == 8)
						atk_tar.push_back(target1_3);
					else if(attack1 == 9)
						atk_tar.push_back(target1_2);
					else if(attack1 == 10)
						atk_tar.push_back(target1_5);
					else if(attack1 == 11)
						atk_tar.push_back(target1_6);
					else if(attack1 == 12)
						atk_tar.push_back(target1_7);
					else if(attack1 == 13)
						atk_tar.push_back(target1_1);
					else if(attack1 == 14)
						atk_tar.push_back(tower[1]);
				}
			}
			else{
				if(group == 0){
					if(defend0 == 1)
						atk_tar.push_back(target0_1);
					else if(defend0 == 2)
						atk_tar.push_back(target0_2);
					else if(defend0 == 3)
						atk_tar.push_back(target0_3);
					else if(defend0 == 4)
						atk_tar.push_back(tower[0]);
				}
				else{
					if(defend1 == 1)
						atk_tar.push_back(target0_2);
					else if(defend1 == 2)
						atk_tar.push_back(target0_1);
					else if(defend1 == 3)
						atk_tar.push_back(target0_3);
					else if(defend1 == 4)
						atk_tar.push_back(tower[0]);
				}
			}
			if (atk_tar.size()) //Ѱ�ҹ̶������С����
                fixPos[a->id] = atk_tar[0]; //����Ŀ��
            else
                fixPos[a->id] = DEFAULFPOS;
        }
        
		Operation op;
        op.id = a->id;
        op.type = "Move";
        findShortestPath(*MAP, a->pos, fixPos[a->id], blocks, op.targets); //����С�����ƶ�
        cmd.cmds.push_back(op);
    }
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //��0�غ�ѡ��Ӣ��
{
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
		op.type = "ChooseArcher";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op); //���ѡ��ְҵ
    }
}

void init() //һЩ������ʼ��
{
	blocks.clear();
	minLevel = 0;
	attack0 = attack1 = 1;
	defend0 = defend1 = 0;
	
	tower = INFO->camp ? (Player0_tower_pos) : (Player1_tower_pos);
	//tower1 = INFO->camp ? (Player0_tower_pos[1]+Pos(-3,3)) : (Player1_tower_pos[1]+Pos(3, -3));
	//tower0 = INFO->camp ? (Player0_tower_pos[0]+Pos(-3,-3)) : (Player1_tower_pos[0]+Pos(3,3));
	//tower1_ = INFO->camp ?  Player1_tower_pos[1] : Player0_tower_pos[1];
	//tower0_ = INFO->camp ?  Player1_tower_pos[0] : Player0_tower_pos[0];
	
	target1_1 = INFO->camp ? Pos(145,145): Pos(5,5);
	target1_2 = INFO->camp ? Pos(142,116) : Pos(8, 34);
    target1_3 = INFO->camp ? Pos(116,116) : Pos(34,34);
	target1_4 = INFO->camp ? (Pos(116,96)+Pos(6,0)) : (Pos(34,54)+Pos(-6,0));
	target1_5 = INFO->camp ? (Pos(94, 142)+Pos(6,0)) : (Pos(56, 8)+Pos(-6,0));
	target1_6 = INFO->camp ? (Pos(92, 116)+Pos(6,0)) : (Pos(58, 34)+Pos(-6,0));
	target1_7 = INFO->camp ? Pos(96, 96) : Pos(54, 54);
	target1_8 = INFO->camp ? Pos(96,75) : Pos(54,75);
	
	target0_1 = INFO->camp ? Pos(96, 35) : Pos(54, 115); // target for group0
	target0_2 = INFO->camp ? Pos(58, 34)-Pos(-4,4) : Pos(92, 116)+Pos(-4,4);
	target0_3 = INFO->camp ? Pos(56,8) : Pos(94, 142);
	
	target3_1 = INFO->camp ? Pos(54, 75) : Pos(96, 75);
	target3_2 = INFO->camp ? Pos(34, 54) : Pos(116, 96);
	target3_3 = INFO->camp ? Pos(32, 95) : Pos(118, 55);; // target for group0 at step0
	
	getFoes(blocks, 0, MAXLEVEL);
    for (int i = 0; i < 2; ++i)
        blocks.push_back(tower[i]); //��ͼ�Ϲ̶��㲻�ɾ���
    memset(fixId, EMPTYID, sizeof fixId);
    towerDes[0] = towerDes[1] = false;
    for (int i = 0; i < MAXID; ++i) fixPos[i] = EMPTYPOS;
}

bool timeToShift(const PUnit* ptr, const PPlayerInfo &info, Pos target){
	if(dis2(target, ptr->pos) >= ptr->view - ptr->speed)
		return false;
	info.findUnitInArea(target, 32, nearBy_);
	for (int i = 0; i < nearBy_.size(); ++i){
		if (nearBy_[i]->camp == ptr->camp ||
		  nearBy_[i]->findBuff("Reviving")){
			nearBy_.erase(nearBy_.begin()+i);
			--i;
		}
	}
	if(!nearBy_.size())
		return true;
	else 
		return false;
}

void fightAlone(const PUnit* ptr, const PPlayerInfo &info, PCommand &cmd, int group)
{
    info.findUnitInArea(ptr->pos, ptr->view, nearBy); //Ѱ�Ҹ�������
    fixPos[ptr->id] = EMPTYPOS;
    for (int i = 0; i < nearBy.size(); ++i)
    {
        if (    nearBy[i]->id == 38 || // ignore Roshan
				nearBy[i]->camp == ptr->camp ||
                nearBy[i]->pos == Bow_pos[0] || nearBy[i]->pos == Bow_pos[3] ||
                nearBy[i]->findBuff("Reviving") 
			)
            //ɾ���ȼ����ߵ��ˣ������Ѿ����޳������ߣ�ɾ�����ɵ����Ұ��
        {
            nearBy.erase(nearBy.begin()+i);
            --i;
        }
    }
	
	if(!towerDes[1]){
		if (minLevel > 2){
			attack0 = 6;
			attack1 = 14;
		}
		else if(group == 0){
			if(attack0 == 1 && timeToShift(ptr, info, target0_1))
				attack0 = 2;
			else if(attack0 == 2 && timeToShift(ptr, info, target0_2))
				attack0 = 3;
			if(attack0 == 3 && timeToShift(ptr, info, target0_1))
				attack0 = 4;
			else if(attack0 == 4 && timeToShift(ptr, info, target0_2))
				attack0 = 5;
			else if(attack0 == 5 && timeToShift(ptr, info, target0_3))
				attack0 = 1;
		}
		else{
			if(attack1 == 1 && timeToShift(ptr, info, target1_4))
				attack1 = 2;
			else if(attack1 == 2 && timeToShift(ptr, info, target1_3))
				attack1 = 3;
			else if(attack1 == 3 && timeToShift(ptr, info, target1_2))
				attack1 = 4;
			else if(attack1 == 4 && timeToShift(ptr, info, target1_5))
				attack1 = 5;
			else if(attack1 == 5 && timeToShift(ptr, info, target1_6))
				attack1 = 6;
			else if(attack1 == 6 && timeToShift(ptr, info, target1_7))
				attack1 = 7;
			else if(attack1 == 7 && timeToShift(ptr, info, target1_4))
				attack1 = 8;
			else if(attack1 == 8 && timeToShift(ptr, info, target1_3))
				attack1 = 9;
			else if(attack1 == 9 && timeToShift(ptr, info, target1_2))
				attack1 = 10;
			else if(attack1 == 10 && timeToShift(ptr, info, target1_5))
				attack1 = 11;
			else if(attack1 == 11 && timeToShift(ptr, info, target1_6))
				attack1 = 12;
			else if(attack1 == 12 && timeToShift(ptr, info, target1_7))
				attack1 = 13;
			else if(attack1 == 13 && timeToShift(ptr, info, target1_1))
				attack1 = 1;
		}
		if (nearBy.size()) //���ԣ����ܱ�����С��������й���
		{
			const PUnit* ptr_foe = fixId[ptr->id]!=EMPTYID ?
						belongs(fixId[ptr->id], nearBy) : NULL; //�ж�֮ǰ�Ƿ�������Ŀ��
			if (!ptr_foe)
			{
				ptr_foe = nearBy[rand() % nearBy.size()];
				fixId[ptr->id] = ptr_foe->id;
			}
			fighting(ptr, ptr_foe, cmd); //��Ŀ���
		} else
		{
			findFoes(ptr, cmd, group); //������û�ео����ڵ�ͼ��Ѱ��һ��
		}
	}
	else{
		if (minLevel > 7){
			defend0 = 4;
			defend1 = 4;
		}
		else if(group == 0){
			if(defend0 == 1 && timeToShift(ptr, info, target0_1))
				defend0 = 2;
			else if(defend0 == 2 && timeToShift(ptr, info, target0_2))
				defend0 = 1;
			else if(defend0 == 3 && timeToShift(ptr, info, target0_3))
				defend0 = 1;
		}
		else{
			if(defend1 == 1 && timeToShift(ptr, info, target0_2))
				defend1 = 2;
			else if(defend1 == 2 && timeToShift(ptr, info, target0_1))
				defend1 = 1;
			else if(defend1 == 3 && timeToShift(ptr, info, target0_3))
				defend1 = 1;
		}
		if (nearBy.size()) //���ԣ����ܱ�����С��������й���
		{
			const PUnit* ptr_foe = fixId[ptr->id]!=EMPTYID ?
						belongs(fixId[ptr->id], nearBy) : NULL; //�ж�֮ǰ�Ƿ�������Ŀ��
			if (!ptr_foe)
			{
				ptr_foe = nearBy[rand() % nearBy.size()];
				fixId[ptr->id] = ptr_foe->id; //��֮ǰδ������Ŀ�꣬���ѡ��Ŀ��
			}
			fighting(ptr, ptr_foe, cmd); //��Ŀ���
		} else
		{
			findFoes(ptr, cmd, group); //������û�ео����ڵ�ͼ��Ѱ��һ��
		}
	}
}

int numberBySpring(const PPlayerInfo &info, int group){
	const Pos spring = INFO->camp ? Pos(145, 5):Pos(5, 145);
	int springBy = 0;
	for (int i=0; i<info.units.size(); ++i)
		if (dis2(info.units[i].pos, spring) <= 288 && !info.units[i].findBuff("Reviving")){
			if(group == 1 && 
			  (info.units[i].id == group1[0]->id || 
			  info.units[i].id == group1[1]->id || 
			  info.units[i].id == group1[2]->id))
				springBy++;
			else if (group == 0 &&
			  (info.units[i].id == group0[0]->id ||
			   info.units[i].id == group0[1]->id))
				springBy++;
		}
	return springBy;
}

void freshMinLevel(){
	int min = 9;
	for(int i=0; i<group0.size(); i++)
		if(group0[i]->level < min)
			min = group0[i]->level;
	for(int i=0; i<group1.size(); i++)
		if(group1[i]->level < min)
			min = group1[i]->level;
	minLevel = min;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(0)); //������ش�
    cmd.cmds.clear();
	
    MAP = &map;
    INFO = &info;
    if (info.round == 0)
    {
        chooseHero(info, cmd); //��0�غ�ѡ��Ӣ��
        init(); //һЩ������ʼ��
		
    } else //��ʽ�غ�
    {	
		if(info.round == 1){
			INFO->findUnitByPlayer(INFO->player, ours); //Ѱ�����б�����λ
			id1.clear();
			id0.clear();
			for (int i=0; i<ours.size(); ++i) //���м�����λ
			{
				const PUnit* ptr = ours[i];
				if (ptr->isHero()){
					if(id1.size()<3)
						id1.push_back(ptr->id);
					else
						id0.push_back(ptr->id);
				}
			}
		}
		group1.clear();
		for(int i=0; i<id1.size(); i++)
			group1.push_back(info.findUnitById(id1[i]));
		group0.clear();
		for(int i=0; i<id0.size(); i++)
			group0.push_back(info.findUnitById(id0[i]));
			
		cout<<"----------------"<<endl;
		cout<<"camp: "<<INFO->camp<<endl;
		cout<<"attack0: "<<attack0<<endl;
		cout<<"attack1: "<<attack1<<endl;
		cout<<"defend0: "<<defend0<<endl;
		cout<<"defend1: "<<defend1<<endl;
		cout<<"----------------"<<endl;
		
		freshMinLevel();
		const Pos spring = INFO->camp ? Pos(145, 5):Pos(5, 145);
		for(int i=0; i<group0.size(); i++){
			if(!towerDes[1] && timeToShift(group0[i], info, tower[1])){
				towerDes[1] = true;
				attack1 = attack0 = 0;
				defend0 = defend1 = 1;
			}
			if (dis2(spring, group0[i]->pos) <= 32 && numberBySpring(info, 0)<group0.size() && attack0 == 6);
			else{
				if (dis2(spring, group0[i]->pos) <= 32 && numberBySpring(info, 0) == group0.size() && attack0 != 6)
					attack0 = 1;
				fightAlone(group0[i], info, cmd, 0);
			}
		}
		for(int i=0; i<group1.size(); i++){
			if(!towerDes[1] && timeToShift(group1[i], info, tower[1])){
				towerDes[1] = true;
				attack1 = attack0 = 0;
				defend0 = defend1 = 1;
			}
			if (dis2(spring,group1[i]->pos) <= 32 && numberBySpring(info, 1)<group1.size() && attack1 == 14);
			else{
				if(dis2(spring, group1[i]->pos) <= 32 && numberBySpring(info, 1) == group1.size() && attack1 != 14)
					attack1 = 1;
				fightAlone(group1[i], info, cmd, 1);
			}
		}
    }
}
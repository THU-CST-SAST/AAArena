// ai_v3.cc 三弓手二战士组合，此ai为抱团快速练级推塔流
// 最快记录 203回合，对阵
#include "sdk.h"
#include <queue>
#include <cmath>
using namespace std;

const PMap *MAP;
const PPlayerInfo *INFO;
PCommand *CMD;
static vector<const PUnit*> nearBy;
static vector<Pos> blocks;
static vector<PUnit> myHeros;
static queue<Pos> fight_queue;
static vector<Pos> lastPos;
static queue<Pos> frontTowerPos_enemy;
static bool ruinFirstEnemyTower;
static bool ruinFirstSelfTower;
static bool needGoToSpring;

static int hasSetOperation[] = { 0, 0, 0, 0, 0 };
static Pos south[] = { Pos(-1,-1), Pos(1,-1), Pos(-2,1), Pos(0,2), Pos(2,1) };
static Pos north[] = { Pos(-1,1), Pos(1,1), Pos(-2,-1), Pos(0,-2), Pos(2,-1) };
static Pos west[] = { Pos(-1,1), Pos(-1,-1), Pos(1,2), Pos(2,0), Pos(1,-2) };
static Pos east[] = { Pos(1,1), Pos(1,-1), Pos(-1,2), Pos(-2,0), Pos(-1,-2) };
static Pos* dirctions[] = { east, south, west, north };

static const Pos PUSH_TOWER_POINT_1 = Pos(42,71);
static const Pos PUSH_TOWER_POINT_2 = Pos(75,42);
static const Pos SPRING_POINT = Pos(10,141);

Pos fQueue_normal[] = { Pos(17,61), Pos(25,51), Pos(27,35), Pos(10,10), Pos(44,54),
                        Pos(41,37), Pos(27,37), Pos(4,4), PUSH_TOWER_POINT_1,
                        SPRING_POINT, Pos(69,121),
                        Pos(75,60), Pos(75,55), Pos(75,50), PUSH_TOWER_POINT_2 };
int fq_size_normal = 15;

static const int MAX_UNITS_NUM = 50;
static const int SPIN_MIN_HP = 70;
static const int SPIN_MIN_MP = 75;
static const int PARROW_MIN_HP = 40;
static const int PARROW_MIN_MP = 80;
static const int CHARGE_MIN_HP = 30;
static const double TROOP_SPEED = 4.5;
static const double SLOW_SPEED = 3.5;
static const double PUSH_TOWER_MIN_HP = 0.60;

struct Formation
{
    int curDir;  // 0 -> East; 1 -> South; 2 -> West; 3 -> North
    Pos *dir;
    Formation () : curDir(0), dir(NULL)
    {
    }
    Formation(int direction)
    {
        curDir = direction;
        dir = dirctions[direction];
    }
    void transform(int direction)
    {
        curDir = direction;
        dir = dirctions[direction];
    }
};
static Formation formation;

void posToString(const Pos & pos)
{ cout << "(" << pos.x <<  ", " << pos.y << ") "; }
void printOperation(const Operation & op)
{
    cout << "id = " << op.id << "; type = " << op.type << "; target = ";
    if (op.targets.size()) posToString(op.targets[op.targets.size()-1]);  cout << endl;
}

void chooseHero(const PPlayerInfo & info, PCommand & cmd)  // 2 战士 + 3 弓手
{
    for (int i = 0; i < info.units.size(); i++)
    {
        Operation op;
        if (i == 0 || i == 1)
            op.type = "ChooseFighter";
        else
            op.type = "ChooseArcher";
        op.targets.clear();
        op.id = info.units[i].id;
        cmd.cmds.push_back(op);
    }
}

inline bool isFighter(const PUnit & unit) { return string(unit.name) == string("Fighter"); }
inline bool isArcher(const PUnit & unit) { return string(unit.name) == string("Archer"); }
inline bool isAssassin(const PUnit & unit) { return string(unit.name) == string("Assassin"); }
inline bool isHero(const PUnit & unit)
{
    if (isFighter(unit) || isArcher(unit) || isAssassin(unit))
        return true;
    return false;
}
inline int heroRank(const PUnit & hero)
{
    int i;
    for (i = 0; i < 5; i++) {
        if (myHeros[i].id == hero.id)
            return i;
    }
    return -1;
}
inline void setCommand(const PUnit & hero, PCommand & cmd, const Operation & op)
{
    if (hasSetOperation[heroRank(hero)] == false) {
        cmd.cmds.push_back(op);
        hasSetOperation[heroRank(hero)] = true;
//        printOperation(op);
    }
}

bool isPosVisible(const Pos & tar)
{
    const PPlayerInfo & info = *INFO;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && dis2(tar, unit.pos) <= unit.view / 4) {
            return true;
        }
    }
    return false;
}

bool justLevelUp(const PUnit & hero)
{
    return hero.args[8].val[3];
}

void levelUp(const PUnit & hero)
{
    Operation op;
    op.id = hero.id;
    int fighter_lu_0[] = {2,4,4,2,4,6,2,6,6,19};
    int fighter_lu_1[] = {2,4,4,2,4,6,6,6,2,19};
    int archer__lu1[] = {12,12,12,8,8,8,10,10,10,19};
    int archer__lu2[] = {12,12,12,8,8,10,10,8,10,19};
    int archer__lu3[] = {12,12,12,8,8,8,10,10,10,19};
    int* level[10] { fighter_lu_0, fighter_lu_1, archer__lu1, archer__lu2, archer__lu3 };
    int skillPoints = hero.args[8].val[3];
    for (int i = 0; i < skillPoints; i++) {
        op.typeId = level[heroRank(hero)][hero.level-i];
    }
    PCommand &cmd = *CMD;
    setCommand(hero, cmd, op);
}

void finishLevelUp()
{
    for (int i = 0; i < 5; i++) {
        const PUnit & hero = myHeros[i];
        if (justLevelUp(hero))
            levelUp(hero);
    }
}

void moveTo(const PUnit & hero, const Pos & tarPos, double steps_num = 0) // 可以杜绝野怪卡位
{
    const PMap & map = *MAP; const PPlayerInfo & info = *INFO; PCommand & cmd = *CMD;
    Operation op; op.id = hero.id; op.type = "Move";
    vector<const PUnit*> barriers;
    bool hasBarrierAround = false;
    if (lastPos[hero.id] == hero.pos) {
        info.findUnitInArea(hero.pos, hero.view, nearBy);
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            if (lastPos[unit.id] == unit.pos && unit.id != hero.id) { // 位置没有改变
                hasBarrierAround = true;
                barriers.push_back(&unit);
            }
        }
    }
    if (hasBarrierAround == true) {
        vector<Pos> m_blocks = blocks;
        for (int i = 0; i < barriers.size(); i++)
            m_blocks.push_back(barriers[i]->pos);
        findShortestPath(map, hero.pos, tarPos, m_blocks, op.targets);
    }
    else
        findShortestPath(map, hero.pos, tarPos, blocks, op.targets);
    // 若对步数有特殊要求
    if (steps_num != 0) {
        vector <Pos> m_targets; m_targets.push_back(op.targets[0]);
        double sum = dis(hero.pos, op.targets[0]);
        for (int i = 1; i < op.targets.size(); i++) {
            sum += dis(op.targets[i], op.targets[i-1]);
            if (sum <= steps_num) {
                m_targets.push_back(op.targets[i]);
            }
            else break;
        }
        op.targets = m_targets;
    }
    setCommand(hero, cmd, op);
}

const PUnit* hasTargetsAround()
{
    int minHp = 10000;
    const PUnit *weakest_hero = NULL;
    const PPlayerInfo & info = *INFO;
    for (int k = 0; k < 5; k++) {
        const PUnit & hero = myHeros[k];
        info.findUnitInArea(hero.pos, hero.view, nearBy);
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            if (unit.camp == 1 - hero.camp) {
                if (string(unit.name) == string("Tower")) {
                    Pos towerPos1 = info.camp == 0 ? PUSH_TOWER_POINT_1 : Pos(150,150)-PUSH_TOWER_POINT_1;
                    Pos towerPos2 = info.camp == 0 ? PUSH_TOWER_POINT_2 : Pos(150,150)-PUSH_TOWER_POINT_2;
                    if (fight_queue.front() == towerPos1 ||
                        fight_queue.front() == towerPos2)    // 优先打塔
                        return &unit;
                } else {
                    minHp = unit.hp;
                    weakest_hero = &unit;
                }
            }
        }
    }
    if (weakest_hero) return weakest_hero;
    else if (ruinFirstEnemyTower == false) { // 要推塔就不打怪了
        for (int k = 0; k < 5; k++) {
            const PUnit & hero = myHeros[k];
            info.findUnitInArea(hero.pos, hero.view, nearBy);
            for (int i = 0; i < nearBy.size(); i++) {
                const PUnit & unit = *nearBy[i];
                if (unit.camp == 2 && unit.findBuff("Reviving") == NULL &&
                    unit.hp <= 1000) // 1000 以上的野怪不去打
                    return &unit;
            }
        }
    }
    return NULL;
}

void arrowPos(const PUnit & hero, const Pos *pos, int max_dis)
{
    const PPlayerInfo & info = *INFO;
    vector<Pos> enemy_poses;
    info.findUnitInArea(hero.pos, hero.view, nearBy);
    for (int i = 0; i < nearBy.size(); i++) {
        if (nearBy[i]->camp != hero.camp) {
            enemy_poses.push_back(nearBy[i]->pos);
        }
    }
    for (int i = 0; i < enemy_poses.size(); i++) {
        for (int j = i+1; j < enemy_poses.size(); j++) {
            Pos & a = enemy_poses[i];
            Pos & b = enemy_poses[j];
            if (dis(a,b) <= 4) {
                Pos *m = new Pos(a.x/2 + b.x/2, a.y/2 + b.y/2);
                if (dis2(hero.pos, *m) <= max_dis) {
                    pos = m;
                    return;
                }
            }
        }
    }
    pos = NULL;
}

void beatIt(const PUnit & hero, const PUnit & enemy)
{
    const PPlayerInfo & info = *INFO;
    Operation op;
    op.id = hero.id;
    int nearByEnemyNum = 0;
    info.findUnitInArea(hero.pos, hero.view, nearBy);
    for (int i = 0; i < nearBy.size(); i++) {
        if (nearBy[i]->camp == 1 - hero.camp) {
            nearByEnemyNum++;
        }
    }
    if (string(enemy.name) == string("Dragon") && hero.hp <= Dragon_atk) {
        double moveDis = pow(enemy.range, 0.5) - dis(enemy.pos, hero.pos) + 2;
        moveTo(hero, 3 * hero.pos - 2 * enemy.pos, moveDis);
        return;
    }
    else if (hero.hp <= 5 * (12 - hero.level) &&
             dis2(enemy.pos, hero.pos) <= enemy.range) {
        double moveDis = pow(enemy.range, 0.5) - dis(enemy.pos, hero.pos) + 2;
        moveTo(hero, 3 * hero.pos - 2 * enemy.pos, moveDis);
        return;
    }
    else if (isFighter(hero))
    {
        if (hero.canUseSkill(5) && dis2(enemy.pos, hero.pos) <= Yell_range &&
                 nearByEnemyNum >= 2 && enemy.findBuff("Dizzy") == NULL &&
                 (enemy.camp != 2 || enemy.hp >= 351) && enemy.findBuff("Yelled") == NULL) { // 血量超过351野怪才值得吼
            op.type = "Yell";
        }
        else if (hero.canUseSkill(1) && dis2(enemy.pos, hero.pos) <= Charge_range && enemy.speed > 0
                 && enemy.atk > 35 && string(enemy.name) != string("Roushan") &&
                 enemy.hp >= CHARGE_MIN_HP * ((hero.level-1) / 2 + 1)) {
            op.type = "Charge";
            op.targets.push_back(enemy.pos);
        }
        else if (hero.canUseSkill(3) && dis2(enemy.pos, hero.pos) <= Spin_range && hero.mp >= SPIN_MIN_MP &&
                 (enemy.camp != 2 || enemy.atk >= 40) &&
                 (enemy.camp != 2 || enemy.hp >= SPIN_MIN_HP * ((hero.level-1) / 2 + 1))) { // 小怪慎用
            op.type = "Spin";
        }
        else if (dis2(hero.pos, enemy.pos) <= hero.range && hero.findSkill(0)->cd == 0) {
            op.type = "Attack";
            op.targets.push_back(enemy.pos);
        }
        else {
            moveTo(hero, enemy.pos);
            return;
        }
    }
    else if (isArcher(hero))
    {
        if (hero.canUseSkill(11) && (enemy.atk >= 50 || nearByEnemyNum >= 2)) {
            op.type = "PowerUp";
        }
        else if (hero.canUseSkill(7) && dis2(hero.pos, enemy.pos) <= PiercingArrow_range &&
                 (enemy.camp != 2 || enemy.atk >= 60) &&
                 enemy.hp >= PARROW_MIN_HP * (hero.level / 2 + 1) && hero.mp >= PARROW_MIN_MP ) {  // 慎用
            op.type = "PiercingArrow";
            Pos *p_arrow_pos = NULL;
            arrowPos(hero, p_arrow_pos, PiercingArrow_range);
            if (p_arrow_pos) op.targets.push_back(*p_arrow_pos);
            else op.targets.push_back(enemy.pos);
        }
        else if (hero.canUseSkill(9) && string(enemy.name) != string("Tower") && // 可以用枪林箭雨
                 dis2(hero.pos, enemy.pos) <= SignalArrow_range &&
                 (enemy.camp != 2 || enemy.atk >= 60)) {
            op.type = "ArrowsRain";
            Pos *s_arrow_pos = NULL;
            arrowPos(hero, s_arrow_pos, SignalArrow_range);
            if (s_arrow_pos) op.targets.push_back(*s_arrow_pos);
            else op.targets.push_back(enemy.pos);
        }
        else if (dis2(hero.pos, enemy.pos) <= hero.range && hero.findSkill(0)->cd == 0) {
            op.type = "Attack";
            op.targets.push_back(enemy.pos);
        }
        else if (hero.findSkill(0)->cd > 0) {
            if (enemy.range <= 10 && dis(hero.pos, enemy.pos) <= 6) { // 只对近程单位走位
                moveTo(hero, 3 * hero.pos - 2 * enemy.pos, 2);
                return;
            }
            else if (hero.hp <= 130) {
                moveTo(hero, 3 * hero.pos - 2 * enemy.pos);
                return;
            }
        }
        else {
            double speed = 5.0;
            if (fight_queue.size() <= 3)  // 推塔时速度减缓以保持队形
                speed = pow(11,0.5);
            moveTo(hero, enemy.pos, speed);
            return;
        }
    }
    PCommand & cmd = *CMD;
    setCommand(hero, cmd, op);
}

const PUnit* towerInDanger()
{
    const PPlayerInfo & info = *INFO;
    const PUnit *tower = NULL;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && string(unit.name) == string("Tower")) {
            tower = &unit;
            break;
        }
    }
    info.findUnitInArea(tower->pos, tower->view, nearBy);
    int enemy_num = 0;
    for (int i = 0; i < nearBy.size(); i++) {
        const PUnit & unit = *nearBy[i];
        if (unit.camp == 1 - info.camp && isHero(unit))
            enemy_num++;
    }
    if (enemy_num >= 4) return tower;
    else return NULL;
}

void moveTroopTo(const Pos & tarPos, bool fullSpeed = false)
{
    int preDir = formation.curDir;
    int direction = formation.curDir;
    Pos curPos = myHeros[0].pos - formation.dir[0];
    if (tarPos.y > curPos.y) {
        direction = 3;
    }
    else if (tarPos.y < curPos.y) {
        direction = 1;
    }
    formation.transform(direction);
    if (ruinFirstEnemyTower == false) {
        if (fullSpeed == true) {
            for (int i = 0; i < 5; i++)
                moveTo(myHeros[i], tarPos + formation.dir[i]);
        } else {
            for (int i = 0; i < 5; i++)
                moveTo(myHeros[i], tarPos + formation.dir[i], TROOP_SPEED);
        }
    } else {
        if (preDir == direction) {  // 朝向没变，则直接前进
            for (int i = 0; i < 5; i++)
                moveTo(myHeros[i], tarPos + formation.dir[i], SLOW_SPEED);
        } else {  // 否则变阵为先
            for (int i = 0; i < 5; i++)
                moveTo(myHeros[i], curPos + formation.dir[i]);
        }
    }
}

void troopFight(const PUnit & enemy)
{
    for (int i = 0; i < 5; i++)
        beatIt(myHeros[i], enemy);
}

void init_one()
{
    ruinFirstEnemyTower = false;
    ruinFirstSelfTower = false;
    needGoToSpring = false;
    formation = Formation(1); // face south
    
    const PPlayerInfo & info = *INFO;
    const PMap & map = *MAP;
    
    // fighter_queue
    if (info.camp == 0)
        for (int i = 0; i < fq_size_normal; i++)
            fight_queue.push(fQueue_normal[i]);
    else
        for (int i = 0; i < fq_size_normal; i++)
            fight_queue.push(Pos(150,150) - fQueue_normal[i]);
    
    // init frontTowerPos_enemy
    if (info.camp == 0) {
        frontTowerPos_enemy.push(Player1_tower_pos[1]);
        frontTowerPos_enemy.push(Player1_tower_pos[0]);
    }
    else {
        frontTowerPos_enemy.push(Player0_tower_pos[1]);
        frontTowerPos_enemy.push(Player0_tower_pos[0]);
    }
    // blocks
    for (int i = -2; i <= 2; i++) {
        blocks.push_back(Roshan_pos[0] + Pos(-2,i));
        blocks.push_back(Roshan_pos[0] + Pos(2,i));
    }
    for (int j = -1; j <= 1; j++) {
        blocks.push_back(Roshan_pos[0] + Pos(j,2));
        blocks.push_back(Roshan_pos[0] + Pos(j,-2));
    }
    
    // lastPos
    for  (int i = 0; i < MAX_UNITS_NUM; i++)
        lastPos.push_back(Pos(-1,-1));
}
void update_early()
{
    myHeros.clear();
    const PPlayerInfo & info = *INFO;
    
    for (int i = 0; i < info.units.size(); i++) { // 选出已方英雄
        const PUnit& unit = info.units[i];
        if (unit.camp == info.camp && isHero(unit)) {
            myHeros.push_back(unit);
        }
    }
    
    // hasSetOperation
    memset(hasSetOperation, 0, 5 * sizeof(int));
    
    // update frontTowerPos_enemy
    if (ruinFirstEnemyTower == false && isPosVisible(frontTowerPos_enemy.front()) &&
        info.findUnitByPos(frontTowerPos_enemy.front()) == NULL) {
        frontTowerPos_enemy.pop();
        fight_queue.pop();
        ruinFirstEnemyTower = true;
        needGoToSpring = true;
        double sum_all_hp = 0;
        double sum_cur_hp = 0;
        for (int i = 0; i < 5; i++) {
            sum_all_hp += myHeros[i]["Hp"]->val[1];
            if (myHeros[i].findBuff("Reviving") == NULL)
                sum_cur_hp += myHeros[i].hp;
        }
        if (sum_cur_hp >= sum_all_hp * PUSH_TOWER_MIN_HP) {
            fight_queue.pop();
            fight_queue.pop();
            needGoToSpring = false;
        }
    }
    
    // update ruinFirstSelfTower
    int tower_num = 0;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && string(unit.name) == string("Tower"))
            tower_num++;
    }
    ruinFirstSelfTower = tower_num == 1 ? true : false;
    
    // update fighter_queue
    for (int i = 0; i < 5; i++) {
        const Pos & fight_pos = fight_queue.front() + formation.dir[i];
        if (fight_pos == myHeros[i].pos) {
            Pos towerPos1 = info.camp == 0 ? PUSH_TOWER_POINT_1 : Pos(150,150)-PUSH_TOWER_POINT_1;
            Pos springPos = info.camp == 0 ? SPRING_POINT : Pos(150,150) - SPRING_POINT;
            if (fight_queue.front() == towerPos1 && ruinFirstEnemyTower == false) {}
            else if (fight_queue.front() == springPos) {}
            else if (fight_queue.size() == 1) {}
            else fight_queue.pop();  // 不用循环了
            break;
        }
    }
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == 2 && unit.findBuff("Reviving") && string(unit.name) != string("Dragon") &&
            dis2(unit.pos, fight_queue.front()) <= Archer_range / 2) {
            fight_queue.pop();
            break;
        }
    }
    
    // update needGoToSpring
    if (ruinFirstEnemyTower && needGoToSpring == true) {
        Pos springPos = info.camp == 0 ? SPRING_POINT : Pos(150,150) - SPRING_POINT;
        if (fight_queue.front() == springPos) {
            bool finishGather = true;
            for (int i = 0; i < 5; i++) {
                const PUnit & hero = myHeros[i];
                const Pos & fight_pos = fight_queue.front() + formation.dir[i];
                if (fight_pos != myHeros[i].pos || hero.hp < hero["Hp"]->val[1]) {
                    finishGather = false;
                }
            }
            if (finishGather) {
                needGoToSpring = false;
                fight_queue.pop();
            }
        }
    }
}
void update_late()
{
    const PPlayerInfo & info = *INFO;
    // last pos
    for (int i = 0; i < info.units.size(); i++) {
        int id = info.units[i].id;
        lastPos[id] = info.units[i].pos;
    }
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    CMD = &cmd;
    if (info.round == 0) {
        init_one();
        chooseHero(info, cmd);
    }
    else {
        update_early();
        finishLevelUp();
        const PUnit *enemy = hasTargetsAround();
        const PUnit *dTower = towerInDanger();
        if (needGoToSpring) {
            moveTroopTo(fight_queue.front());
        }
        else if (enemy) {
            troopFight(*enemy);
        }
        else if (ruinFirstSelfTower && dTower) {
            moveTroopTo(dTower->pos + Pos(0, (2*info.camp-1) * 10), true);
        }
        else {
            moveTroopTo(fight_queue.front());
        }
        update_late();
    }
}

















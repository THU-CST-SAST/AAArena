#include "sdk.h"
#include <ctime>
#include <climits>

const int MAXID=200,criticalHp=40,warningHp=90,tuiLimit=7,tuiMax=32;
const int RECHECK_LIMIT=13,STUCK_LIMIT=20;
const int MOVE_RND=10,MOV_DIS=25;
typedef vector<const PUnit *> ulist;

static ulist ours,tower,heros,his;

static Pos neus[MAXID],springPos,hisSpring;
static int neurr[MAXID],nc,nrq[MAXID],notAppro[MAXID];
static string ntt[MAXID];
static const Pos *myTower,*hisTower;
static int towerDes[2];


enum Action{ idle, finding, attack, back, suota ,tui ,defense } nowact;
static int atkId,frmId; Pos fdPos;
static int avail[MAXID];

static Pos lastMPos[MAXID];
static int lastMovRnd[MAXID];
static vector<Pos> lastPath[MAXID];



void initData(const PPlayerInfo &info){
    nowact=idle;memset(lastMovRnd,0x8f,sizeof(lastMovRnd));
    for(int i=0;i<8;++i,++nc) neus[nc]=Dog_pos[i],     neurr[nc]=20,nrq[nc]=0,ntt[nc]="Dog";
    for(int i=0;i<6;++i,++nc) neus[nc]=Bow_pos[i],     neurr[nc]=20,nrq[nc]=0,ntt[nc]="Bow";
    for(int i=0;i<4;++i,++nc) neus[nc]=Wolf_pos[i],    neurr[nc]=25,nrq[nc]=3,ntt[nc]="Wolf";
    for(int i=0;i<2;++i,++nc) neus[nc]=StoneMan_pos[i],neurr[nc]=25,nrq[nc]=3,ntt[nc]="StoneMan";
    for(int i=0;i<2;++i,++nc) neus[nc]=Dragon_pos[i],  neurr[nc]=60,nrq[nc]=5,ntt[nc]="Dragon";
    for(int i=0;i<1;++i,++nc) neus[nc]=Roshan_pos[i],  neurr[nc]=80,nrq[nc]=12,ntt[nc]="Roshan";
    notAppro[8]=notAppro[11]=1;

    myTower=  info.camp ? Player1_tower_pos : Player0_tower_pos;
    hisTower= info.camp ? Player0_tower_pos : Player1_tower_pos;
    springPos=info.camp ? Player1_spring_pos[0] : Player0_spring_pos[0];
    hisSpring=info.camp ? Player0_spring_pos[0] : Player1_spring_pos[0];
    towerDes[0]=towerDes[1]=0;
}
Pos rs(int rad){
    if(!rad)return Pos(0,0);
    return Pos(rand()%(rad*2)-rad,rand()%(rad*2)-rad);
}
int findFarmTarget(int lv,int last){
    for(int t=0,i;t<100;++t){
        i=rand()%nc;
        if(i==last)continue;
        if(lv<nrq[i])continue;
        if(notAppro[i])continue;
        return i;
    } return rand()%(nc-3);
}

int levelLimit(const string &s){
    if(s=="Dog"||s=="Bow")return 0;
    if(s=="Wolf"||s=="StoneMan")return 3;
    if(s=="Dragon")return 5;
    if(s=="Roshan")return 12;
    return 0;
}
int atkRound(const string &s){
    if(s=="Assassin" || s=="Wolf" || s=="Spring" || s=="Tower")return 1;
    return 2;
}
const PUnit *hasId(int id,const ulist &L){
    for(auto it=L.begin();it!=L.end();++it)
        if((*it)->id==id)return *it;
    return NULL;
}
int estimateDamage(const PUnit *u,const PUnit *v){
    if(u->findBuff("Dizzy")||u->findBuff("Reviving"))return 0;
    return (u->atk-v->def)/atkRound(u->name);
}
bool isStructure(string name){return name=="Tower" || name =="Spring";}
bool doMove(const PPlayerInfo &info,const PMap &M,PCommand &cmd,
        Pos end,const PUnit *u,bool duobi=1,int depth=0){
    if(depth>RECHECK_LIMIT)return 0;
    if(end==lastMPos[u->id] && lastMovRnd[u->id]+MOVE_RND>info.round){
        vector<Pos>::iterator it=lastPath[u->id].begin();
        while(it!=lastPath[u->id].end() && *it!=u->pos)++it;
        if(it!=lastPath[u->id].end()){
            Operation op; op.id=u->id; op.targets.clear(); op.type="Move";
            op.targets=vector<Pos>(it,lastPath[u->id].end());
            cmd.cmds.push_back(op);
            return 1;
        }
    }
    if(!avail[u->id])return 1; vector<Pos> L;
    for(auto it=info.units.begin();it!=info.units.end();++it)
        if(it->pos!=end){
            L.push_back(it->pos);
            if(duobi && isStructure(it->name) && it->player!=info.player){
                if(dis2(u->pos,it->pos)>25)
                    for(int i=-5;i<=5;++i)
                        for(int j=-5;j<=5;++j)
                            L.push_back(it->pos+Pos(i,j));
            }
        }
    Operation op; op.id=u->id; op.targets.clear(); op.type="Move";
    findShortestPath(M,u->pos,end,L,op.targets);
    if(op.targets[0].x<0)
        return doMove(info,M,cmd,end+Pos(rand()%15-7,rand()%15-7),u,duobi,depth+1);
    lastMovRnd[u->id]=info.round; lastMPos[u->id]=end; cmd.cmds.push_back(op);
    lastPath[u->id].swap(op.targets);
    return 1;
}

bool canUse(const PUnit *u,const string &skill){
    const PSkill *sk=u->findSkill(skill);
    return sk&&u->canUseSkill(sk->typeId);
}
bool attacking(const PPlayerInfo &info,const PMap &m,PCommand &cmd,
        const PUnit *u,const PUnit *v,string skill){
    ulist t;
    const PSkill *sk=u->findSkill(skill);
    if(!sk||!u->canUseSkill(sk->typeId))return 0;
    infectedBySkill(info,u->id,sk->typeId,t);
    return hasId(v->id,t);
}
bool doAttack(const PPlayerInfo &info,const PMap &m,PCommand &cmd,const PUnit *u,const PUnit *v){
    if(!avail[u->id])return 1;
    Operation op; op.id=u->id; op.targets.clear();
    op.targets.push_back(v->pos);
    int srad=(u->name==string("Archer"))?5:(isStructure(v->name)?2:0);
    if(dis2(u->pos,v->pos)>81)srad=0;
    if(!u->findBuff("Striking") && canUse(u,"PowerUp")){
        op.type="PowerUp";op.targets.clear();
    }else if(attacking(info,m,cmd,u,v,"PiercingArrow")){
        op.type="PiercingArrow";
    }else if(attacking(info,m,cmd,u,v,"Charge")){
        op.type="Charge";
    }else if(attacking(info,m,cmd,u,v,"Attack")){
        op.type="Attack";
    }else return doMove(info,m,cmd,v->pos+rs(srad),u);
    lastMovRnd[u->id]=-1000; cmd.cmds.push_back(op);
    return 1;
}

void heroUpgrade(const PUnit *u,PCommand &cmd){
    Operation op; op.id=u->id; op.targets.clear(); op.type="YellowPoint";
    if(u->name==string("Fighter")){
        if(u->canUseSkill(2) && rand()%3==0)op.type="ChargeLU";
    }
    if(u->name==string("Archer")){
        if(u->canUseSkill(12) && rand()%3==0)op.type="PULU";
        else if(u->canUseSkill(8) && rand()%3==0)op.type="PALU";
    }
    lastMovRnd[u->id]=-1000; cmd.cmds.push_back(op);
}

bool checkArrival(const PUnit *u,Pos p){ return dis2(u->pos,p)<=u->range; }

bool canTui(int hp,int def,int atk){
    return 1000.0/(atk-55.0)*1.5 < hp/(100.0-def);
}

int maxDis2(Pos p,const ulist &L){
    int md=0;
    for(auto it=L.begin();it!=L.end();++it)
        md=max(md,dis2(p,(*it)->pos));
    return md;
}

int affectedByOurTower(int id,const PPlayerInfo &info){
    for(auto it=tower.begin();it!=tower.end();++it){
        ulist L; infectedBySkill(info,(*it)->id,0,L);
        if(hasId(id,L))return (*it)->atk;
    }
    return 0;
}
int affectedByEnemyTower(Pos p){
    for(int i=0;i<2;++i)if(!towerDes[i] && dis2(hisTower[i],p)<100)return 55;
    if(dis2(hisSpring,p)<100)return 100;
    return 0;
}
int perRoundAtk(const PUnit *u,bool dizzy=0){
    if(u->findBuff("Reviving"))return 0;
    if(dizzy && u->findBuff("Dizzy")) return 0;
    return u->atk/atkRound(u->name);
}
double estimateKillRound(double hp,double dps){
    if(dps<=0)return 1.0/0.0;
    return hp/dps;
}

bool canFight(const PPlayerInfo &info,const PUnit *u,int lsum,int asum,int avedef,int hpsum,double factor=1.0){
    if(u->isWild())return lsum>=levelLimit(u->name);
    if(affectedByOurTower(u->id,info))return 1;
    int eatk=u->atk+affectedByEnemyTower(u->pos);
    int edef=u->def,ehp=u->hp;
    ulist L; info.findUnitInArea(u->pos,u->view,L);
    for(auto it=L.begin();it!=L.end();++it)
        if((*it)->camp==u->camp)eatk+=perRoundAtk(*it);
    return estimateKillRound(hpsum,eatk-avedef)*factor > estimateKillRound(ehp,asum-edef);
    //return double(hpsum)/(eatk-avedef) > double(ehp)/(asum-edef);
}

bool dddanger(const PPlayerInfo &info,int lsum,int asum,int avedef,int hpsum,double multi=1.1){
    int eatk=0,edef=0,ehp=0;
    for(auto it=info.units.begin();it!=info.units.end();++it){
        if(it->camp==!info.camp && maxDis2(it->pos,heros)<81){
            if(it->findBuff("Reviving"))continue;
            eatk+=it->atk; edef=max(edef,it->def); ehp+=it->hp;
        }
        if(it->camp==info.camp && isStructure(it->name) && maxDis2(it->pos,heros)<71)
            return 0;
    }
    return multi*estimateKillRound(hpsum,eatk-avedef) < estimateKillRound(ehp,asum-edef);
    //return 1.1*double(hpsum)/(eatk-avedef) < double(ehp)/(asum-edef);
}
void findNewPos(int lv){
    frmId=findFarmTarget(lv,frmId);
    fdPos=neus[frmId];
    //printf("%d\n",frmId);
    nowact=finding;
}
int checkIfTowerUnderAttack(const PPlayerInfo &info){
    for(auto it=tower.begin();it!=tower.end();++it){
        if((**it)["Hp"]->val[0]==(**it)["Hp"]->val[1])continue;
        for(auto ie=info.units.begin();ie!=info.units.end();++ie){
            if(!ie->findBuff("Reviving") &&
                    ie->camp!=info.camp && dis2(ie->pos,(*it)->pos)<81)
                return (*it)->id;
        }
    }
    return -1;
}

bool switchTarget(const PPlayerInfo &info,int levelsum,int atksum,int deff,int hpsum){
    for(auto it=info.units.begin();it!=info.units.end();++it){
        if(it->player!=!info.player)continue;
        if(it->findBuff("Reviving"))continue;
        if(canFight(info,&*it,levelsum,atksum,deff,hpsum)
                && maxDis2(it->pos,heros)<81) {
            atkId=it->id,nowact=attack;
            return 1;
        }
    }
    return 0;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
    srand(time(0));
    cmd.cmds.clear();ours.clear();heros.clear();tower.clear();
    info.findUnitByPlayer(info.player,ours);
    if(info.round==0){
        int id=0;initData(info);
        for(ulist::iterator it=ours.begin();it!=ours.end();++it){
            if((*it)->name==string("Chooser")){
                Operation op; ++id;
                if(id<=2)op.type="ChooseFighter";
                else if(id<=5)op.type="ChooseArcher";
                op.id=(*it)->id;
                op.targets.clear();
                cmd.cmds.push_back(op);
            }
        }
    }else{
        tower.clear();
        int hpsum=0,atksum=0,levelsum=0,deff=0,maxhp=0;
        for(ulist::iterator it=ours.begin();it!=ours.end();++it){
            if((*it)->name==string("Tower")||(*it)->name==string("Spring"))
                tower.push_back(*it);
            if((*it)->isHero()){
                if((*it)->findBuff("Reviving"))continue;
                heros.push_back(*it);
                atksum+=perRoundAtk(*it);
                levelsum+=(*it)->level;
                hpsum+=(*it)->hp;
                maxhp=max(maxhp,(*it)->hp);
                deff=max(deff,(*it)->def);
            }
        }
        int recheckTime=0;
recheck:
        if(++recheckTime<RECHECK_LIMIT){
            if(!heros.empty()){
                for(auto it=heros.begin();it!=heros.end();++it){
                    avail[(*it)->id]=1;
                    if((**it)["Exp"]->val[3])heroUpgrade(*it,cmd),avail[(*it)->id]=0;
                    for(int i=0;i<2;++i)
                        if(dis2((*it)->pos,hisTower[i])<100 && !info.findUnitByPos(hisTower[i]))
                            towerDes[i]=true;
                }
                switch(nowact){
                    case idle:
                        {
                            if(hpsum/heros.size()<warningHp){nowact=back;goto recheck;}
                            if(levelsum>=tuiLimit && canTui(hpsum,deff,atksum))
                                if(rand()%8||levelsum>tuiMax) {
                                    nowact=tui;
                                    if(towerDes[0]) atkId=1;
                                    else if(towerDes[1])atkId=0;
                                    else atkId=rand()%2;
                                    goto recheck;
                                }
                            findNewPos(levelsum);goto recheck;
                        }
                        break;
                    case finding:
                        {
                            //printf("FND\n");
                            const PUnit *prefTarget=nullptr;int lastDis=INT_MAX;
                            for(auto it=info.units.begin();it!=info.units.end();++it){
                                if(it->player==info.player)continue;
                                if(it->findBuff("Reviving"))continue;
                                if(!it->isWild() &&!it->isHero())continue;
                                if(canFight(info,&*it,levelsum,atksum,deff,hpsum)){
                                    int diss=maxDis2(it->pos,heros);
                                    if(diss<lastDis)lastDis=diss,prefTarget=&*it;
                                }
                            }

                            if(prefTarget){
                                nowact=attack; atkId=prefTarget->id;
                                goto recheck;
                            }
                            else{
                                if(maxDis2(fdPos,heros)<81){nowact=idle;goto recheck;}
                                for(auto it=heros.begin();it!=heros.end();++it)
                                    doMove(info,map,cmd,fdPos,*it);
                            }
                        }
                        break;
                    case attack:
                        {
                            //printf("ATK\n");
                            const PUnit *target=info.findUnitById(atkId);
                            if(!target || target->findBuff("Reviving")){
                                nowact=idle;goto recheck;
                            }
                            if(dddanger(info,levelsum,atksum,deff,hpsum)){
                                nowact=suota;
                                if(tower.empty())fdPos=springPos;
                                else fdPos=tower[rand()%tower.size()]->pos;
                                goto recheck;
                            }

                            if(target->isWild()){
                                //switch
                                int tua=checkIfTowerUnderAttack(info);
                                if(~tua){nowact=defense;goto recheck;}
                                if(switchTarget(info,levelsum,atksum,deff,hpsum))goto recheck;
                            }

                            for(auto it=heros.begin();it!=heros.end();++it)
                                doAttack(info,map,cmd,*it,target);
                        }
                        break;
                    case tui:
                        {
                            if(towerDes[atkId]){nowact=idle;goto recheck;}
                            const PUnit *t=info.findUnitByPos(hisTower[atkId]);

                            if(maxDis2(hisTower[atkId],heros)>200){
                                //switch
                                if(maxDis2(hisTower[atkId],heros)>1000){
                                    int tua=checkIfTowerUnderAttack(info);
                                    if(~tua){nowact=defense;goto recheck;}
                                }
                                if(switchTarget(info,levelsum,atksum,deff,hpsum))goto recheck;
                            }
                            if(t&&t->hp>300&&!canFight(info,t,levelsum,atksum,deff,hpsum,1.5)){
                                findNewPos(levelsum);goto recheck;
                            }

                            for(auto it=heros.begin();it!=heros.end();++it){
                                if(!t) doMove(info,map,cmd,hisTower[atkId],*it,0);
                                else doAttack(info,map,cmd,*it,t);
                            }
                        }
                        break;
                    case suota:
                        {
                            //printf("ST %d\n",info.player);
                            bool foundDiJun=0;
                            for(auto it=info.units.begin();it!=info.units.end();++it){
                                if(it->camp!=info.camp && maxDis2(it->pos,heros)<81){
                                    foundDiJun=1;break;
                                }
                            }
                            if(!foundDiJun || maxDis2(fdPos,heros)<71 )
                            {nowact=idle;goto recheck;}
                            for(auto it=heros.begin();it!=heros.end();++it)
                                doMove(info,map,cmd,fdPos,*it,0);
                        }
                        break;
                    case back:
                        {
                            for(auto it=heros.begin();it!=heros.end();++it)
                                doMove(info,map,cmd,springPos,*it);
                            if(maxDis2(springPos,heros)<81){
                                nowact=idle;goto recheck;
                            }
                        }
                    case defense:
                        {
                            //printf("DEF %d\n",info.player);
                            int tua=checkIfTowerUnderAttack(info);
                            const PUnit *t=(~tua)?info.findUnitById(tua):nullptr;
                            if(~tua && t){
                                for(auto it=info.units.begin();it!=info.units.end();++it){
                                    if(it->player!=!info.player)continue;
                                    if(it->findBuff("Reviving"))continue;
                                    if(dis2(t->pos,it->pos)<100)
                                        atkId=it->id,nowact=attack;
                                }
                                if(nowact!=defense)goto recheck;
                            }else{ nowact=idle;goto recheck; }
                        }
                }
            }else nowact=idle;
        }
    }
}

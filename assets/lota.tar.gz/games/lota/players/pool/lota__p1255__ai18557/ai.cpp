//Orz WJMZBMR
//Orz tourist
//Orz kdc
//Orz 7k+

#include "sdk.h"
#include <fstream>

//----------------------������----------------------------
struct _Cout {
    static bool open;
    template <typename T>
    _Cout &operator<<(T X) {
        if (open) cout << X << flush;
        return *this;
    }
};

struct _Log {
    static bool open;
    ofstream fo;
    _Log() {
        if (open) fo.open("LogMsg.txt");
    }
    ~_Log() {
        if (open) fo.close();
    }
    template <typename T>
    _Log &operator<<(T X) {
        if (open) fo << X << flush;
        return *this;
    }
};

namespace yq {
//-----------------------��������-------------------------
struct MyHero;

struct globalStrategy {
    int Sno;
    virtual void work() = 0;
};

struct globalStrategy1: public globalStrategy {
    globalStrategy1() {
        Sno = 1;
    }
    void work() override;
};

struct globalStrategy2: public globalStrategy {
    Pos enemyTower;
    int togetherd;
    bool incontrol[5];
    globalStrategy2() {
        Sno = 2;
        enemyTower = Pos();
        togetherd = 0;
    }
    void refresh(int join, Pos enemyTowerPos = Pos()) {
        if (enemyTowerPos != Pos()) enemyTower = enemyTowerPos;
        for (int i=0; i<5; i++)
            if ((join>>i)&1) incontrol[i] = 1; else incontrol[i] = 0;
    }
    bool calcCanPushTower(int towerHp);
    void work() override;
};

struct strategy {
    string SName;
    MyHero *U;
    strategy(MyHero *p): U(p) {}
    virtual void work() = 0;
};

struct emptyStrategy: public strategy {
    emptyStrategy(MyHero *p): strategy(p) {
        SName = "empty";
    }
    virtual void work() override { };
};

struct exerWildArcherStrategy: public strategy {
    Pos aim, home;
    bool escape = 0, escaping = 0;
    int shotted = 0;
    exerWildArcherStrategy(MyHero *p): strategy(p) {
        SName = "exerWild";
        aim = home = Pos();
    }
    void refresh(Pos x) {
        aim = x;
    }
    virtual void work() override;
private:
    Pos getExerIdeal(Pos, int range, int speed, Pos X, Pos orin, int herange, bool drag);
};

struct fightingArcherStrategy: public strategy {
    Pos aim;
    fightingArcherStrategy(MyHero *p): strategy(p) {
        SName = "fighting";
    }
    void refresh(Pos x) {
        aim = x;
    }
    virtual void work() override;

private:
    //void mainwork();
    double evaluate(Pos, bool);
    void selectMove();
    bool selectAttack();
};

struct pushTowerArcherStrategy: public strategy {
    Pos aim;
    pushTowerArcherStrategy(MyHero *p): strategy(p) {
        SName = "pushTower";
    }
    void refresh(Pos x) {
        aim = x;
    }
    virtual void work() override;
private:
    Pos getPushIdeal(Pos, Pos, int range, int speed);
    bool selectAttack();
};

struct togetherArcherStrategy: public strategy {
    Pos aim;
    togetherArcherStrategy(MyHero *p): strategy(p) {
        SName = "together";
    }
    void refresh(Pos x) {
        aim = x;
    }
    virtual void work() override;
};

struct moveArcherStrategy: public strategy {
    Pos aim;
    moveArcherStrategy(MyHero *p): strategy(p) {
        SName = "move";
    }
    void refresh(Pos x) {
        aim = x;
    }
    virtual void work() override;
};

struct global {
        static void chooseHero();
        static void prepare();
        static void analyse();
        static void calcHeHeroDead();
        static void calcWild();
        static globalStrategy *nowGlobalStrategy;
        static bool assassinfire, aliveassassin;
        static int det[5];
        static int defenceTower;

        static globalStrategy1 S1;
        static globalStrategy2 S2;
};

struct PathMap {
    int step[Map_size][Map_size];
    Pos pre[Map_size][Map_size];
};

struct BoundMap {
    int bound[Map_size][Map_size];
    void setBound(const Pos &, int radius2);
    bool operator[](const Pos &X) {
        return (bound[X.x][X.y] > 0);
    }
};

struct Unit {
    int id, player, hp, mp, atk, def, range, level, maxhp, exp, speed, onlyTarget, refreshRound;
    double hprate;
    Pos pos;
    string name;
    bool buff[8];
    const PUnit *U;
    int bornTime;

    Unit();
    Unit(const PUnit *);
    virtual void refresh(const PUnit *);
};

struct Tower: public Unit {
    static const double SilenceV;
    static const double DangerV;
    int silencetime;
    bool evaluated;

    Tower(const PUnit *U): Unit(U) {
        evaluated = 0;
        silencetime = 0;
    }
    virtual void refresh(const PUnit *U) override {
        Unit::refresh(U);
        evaluated = 0;
    }

    double TowerEvaluate();
};

struct MyHero: public Unit {
    static const int skillKind[5][10];
    int No;
    strategy *nowStrategy;
    int strategySetTime;
    PathMap road, droad;

    MyHero();
    MyHero(const PUnit *);
    virtual ~MyHero() {
        delete nowStrategy;
    }

    virtual void setS(const string, Pos X = Pos()) = 0;
    int getLastHit(const int &id);
    virtual void findRoad();
    virtual void findDRoad();
    virtual bool Move(Pos, int nearforbid = -1);
    bool DMove(Pos, int nearforbid = -1);
    virtual bool avoidDeath(Pos = Pos());
    virtual bool avoidDDeath(Pos = Pos());

    void work();
};

struct Archer: public MyHero {
    int arrowHit, rainHit;

    void setS(const string, Pos X = Pos()) override;
    virtual ~Archer() {}
    Archer(const PUnit *U): MyHero(U),
        _exerWild(this), _fighting(this), _pushTower(this), _together(this), _move(this) {
        arrowHit = 0, rainHit = 0;
    }
    virtual void refresh(const PUnit *U) override {
        Unit::refresh(U);
        arrowHit = PiercingArrow_damage[U->findSkill("PiercingArrow")->level];
        rainHit = Rainy_damage[U->findSkill("ArrowsRain")->level];
    }

    exerWildArcherStrategy _exerWild;
    fightingArcherStrategy _fighting;
    pushTowerArcherStrategy _pushTower;
    togetherArcherStrategy _together;
    moveArcherStrategy _move;
};

struct WildList {
    static const Pos wildpos[6][8];
    static const int wildlevel[6][8];

    static const Pos towerwild[2][2][5];
    static const Pos dragonPos[2];
    static const int revtime[6];
    static int nowwildno;
    static int wildrevtime[6][8];

    static Pos findNo(Pos);
};

//-----------------------��������������-------------------
const int elem_maxsize = 23000;
const int inf = 1000000000;
const int ViewRange = 144;

const Pos WildList::wildpos[6][8] = {{Pos(8, 34), Pos(34, 34), Pos(58, 34), Pos(54, 75), Pos(142, 116), Pos(116, 116), Pos(92, 116), Pos(96, 75)},
    {Pos(8, 102), Pos(54, 54), Pos(54, 115), Pos(142, 48), Pos(96, 96), Pos(96, 35), Pos(), Pos()},
    {Pos(34, 54), Pos(56, 8), Pos(116, 96), Pos(94, 142), Pos(), Pos(), Pos(), Pos()},
    {Pos(32, 95), Pos(118, 55), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()},
    {Pos(5, 5), Pos(145, 145), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()},
    {Pos(75, 75), Pos(), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()}
};
const int WildList::wildlevel[6][8] = {{0, 0, 0, 0, 0, 0, 0, 0},
    {10, 10, 0, 10, 10, 0, 10, 10},
    {0, 0, 0, 0, 10, 10, 10, 10},
    {3, 3, 10, 10, 10, 10, 10, 10},
    {3, 3, 10, 10, 10, 10, 10, 10},
    {6, 10, 10, 10, 10, 10, 10, 10}
};

const Pos WildList::towerwild[2][2][5] = {{{Pos(96, 75), Pos(116, 96), Pos(116, 116), Pos(142, 116), Pos(145, 145)},
    {Pos(92, 116), Pos(54, 115), Pos(94, 142), Pos(), Pos()}},
    {{Pos(54, 75), Pos(34, 54), Pos(34, 34), Pos(8, 34), Pos(5, 5)},
    {Pos(58, 34), Pos(96, 35), Pos(56, 8), Pos(), Pos()}}};

const Pos WildList::dragonPos[2] = {Pos(145, 145), Pos(5, 5)};

const int WildList::revtime[6] = {20, 20, 25, 25, 60, 80};

const double TowerDanger = 1000.0;
const double TowerSilence = 200.0;
const int MyHero::skillKind[5][10] = {{10, 8, 10, 8, 10, 8, 19, 19, 19, 19},
    {8, 10, 8, 10, 8, 10, 19, 19, 19, 19},
    {10, 8, 10, 8, 10, 8, 19, 19, 19, 19},
    {8, 10, 8, 10, 8, 10, 19, 19, 19, 19},
    {10, 8, 10, 8, 10, 8, 19, 19, 19, 19}
};

const double Tower::SilenceV = 200.0;
const double Tower::DangerV = 1000.0;

//-----------------------ȫ�ֱ���������-------------------
const PPlayerInfo *Info;
PCommand *Cmd;
const PMap *Map;
int nowRound;
int nowPlayer;

Archer *myHero[5];
Tower *myTower[2], *heTower[2];
Unit *mySpring, *heHero[5], *heSpring;
int myTowerTot, heTowerTot = 2, heHeroKnown = 0;
int totDangerTime[2], preferTower = -1;
bool heHeroInsight[5];
int heHeroDead[5], totHeHeroDead = 0, totMyHeroDead = 0;
int nowHeHeroHp[5];
bool nowHeRainy[5];

bool myTowerDead[2], heTowerDead[2];
Pos myTowerPos[2], heTowerPos[2]; //�ҵ�����Զ�����ţ��������ӽ���Զ�ţ�����ȪˮΪ�ο��㣩
bool heTowerInsight[2];

Unit *wild[30];
int totWild;

BoundMap Bound;
Pos Queue[elem_maxsize];
int _Dis[Map_size][Map_size];
bool inQueue[Map_size][Map_size];
int occupy[Map_size][Map_size];

int WildList::wildrevtime[6][8];

int towertime = 0;

globalStrategy *global::nowGlobalStrategy = 0;
bool global::assassinfire = 0;
bool global::aliveassassin = 0;
int global::det[5] = {-1, -1, -1, -1, -1};
int global::defenceTower = 0;

globalStrategy1 global::S1;
globalStrategy2 global::S2;

//-----------------------���ߺ���������-------------------
void normalOperationGen(const string &type, const int &id, const Pos _pos = Pos());
bool stringcmp(const char[], const char[]);
bool check(Pos, Pos, Pos);
int getHeight(Pos);
bool checkDeath(Pos);
bool checkDDeath(Pos);
void setOccupy(const Pos &, int);
void moveIdeal(int myrange, Pos mypos, int herange, Pos hepos, MyHero *my);
void leadMyTower(int myrange, Pos mypos, int herange, Pos hepos, MyHero *my, Pos dest);
}

#include <ctime>

using namespace std;

//#define DEBUG

#ifdef DEBUG
bool _Cout::open = 1;
bool _Log::open = 1;
#else
bool _Cout::open = 0;
bool _Log::open = 0;
#endif

_Cout CCout;
_Log LLog;

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
    LLog<<"----------------------\n";
    LLog<<"NowRound:   "<<info.round<<"\n";

    srand(time(0));
    yq::Map = &map, yq::Info = &info, yq::Cmd = &cmd;
    yq::Cmd->cmds.clear();
    if (info.round == 0) {
        yq::global::chooseHero();
        return;
    }
    yq::global::prepare();
    yq::global::analyse();

    LLog<<"globalStrategy No:  "<<((yq::global::nowGlobalStrategy)?2:1)<<"\n";
    CCout<<"globalStrategy No:  "<<((yq::global::nowGlobalStrategy)?2:1)<<"\n";
    for (int i=0; i<5; i++) {
        LLog<<"Hero "<<i<<" strategy:  "<<yq::myHero[i]->nowStrategy->SName<<"\n";
        CCout<<"Hero "<<i<<" strategy:  "<<yq::myHero[i]->nowStrategy->SName<<"\n";
        if (yq::myHero[i]->strategySetTime == yq::nowRound)
            yq::myHero[i]->work();
    }
    for (int i=0; i<cmd.cmds.size(); i++) {
        if (cmd.cmds[i].type=="Move") {
            LLog<<cmd.cmds[i].id<<" "<<cmd.cmds[i].type<<" ";
            for (int j=0; j<cmd.cmds[i].targets.size(); j++)
                LLog<<"("<<cmd.cmds[i].targets[j].x<<","
                    <<cmd.cmds[i].targets[j].y<<") ";
            LLog<<"\n";
        }
    }

    LLog<<"heHero:\n";
    for (int i=0; i<yq::heHeroKnown; i++)
        LLog<<yq::heHeroInsight[i]<<" "<<yq::heHero[i]->pos.x<<" "<<yq::heHero[i]->pos.y<<"\n";

    yq::global::calcHeHeroDead();
}

void yq::global::analyse() {
    //���������������Ӣ��,���N�ҕr�̜ʂ���
    if (totHeHeroDead>=3) towertime = nowRound;

    //���������Ұ��Ŀ��
    for (int i=0; i<5; i++) {
        Pos n = WildList::findNo(myHero[i]->_exerWild.aim);
        if (WildList::wildrevtime[n.x][n.y])
            myHero[i]->_exerWild.aim = Pos();
    }

    //����Ҫ���c���ص���
    if ((myTowerTot == 1) && (myTowerDead[defenceTower]))
        defenceTower ^= 1;
    if ((myTowerTot == 2) &&
        (myTower[defenceTower^1]->TowerEvaluate() - myTower[defenceTower]->TowerEvaluate() > 300.0))
        defenceTower ^= 1;

    //�o䛿�Σ�U�r�g,�K�u������ƫ�۵���
    for (int i=0; i<2; i++)
        if (!myTowerDead[i])
            if (myTower[i]->TowerEvaluate() > Tower::DangerV)
                totDangerTime[i]++;
    if (myTowerTot == 2) {
        if ((totDangerTime[0]>totDangerTime[1]*4) && (totDangerTime[0]>=30))
            preferTower = 0;
        if ((totDangerTime[1]>totDangerTime[0]*4) && (totDangerTime[1]>=30))
            preferTower = 1;
    }
    if (preferTower != defenceTower) preferTower = -1;

    //�ҵ�Ѫ������֮Ӌ��
    double myhpratesum = 0.0;
    for (int i=0; i<5; i++)
        if (!myHero[i]->buff[7])
            myhpratesum += myHero[i]->hprate;

    //�Ƿ���s֮Ӌ��
    bool cooldownd = 1;
    for (int i=0; i<2; i++)
        if ((!myTowerDead[i]) && (myTower[i]->TowerEvaluate() > Tower::SilenceV))
            cooldownd = 0;

    //�o�Ҫ���ȹ��Č�����֮��Ϣ,���ҷ�Ψһ������Ϣ
    int enemyTowerNo = 1, towerhp = 1000, onlyhp = 0;
    if (heTowerPos[0] == S2.enemyTower) enemyTowerNo = 0;
    if (heTowerDead[enemyTowerNo]) enemyTowerNo ^= 1, nowGlobalStrategy = 0;
    //CCout<<"ENEMYTOEWR:   "<<S2.enemyTower.x<<" "<<S2.enemyTower.y<<"\n";
    S2.enemyTower = heTowerPos[enemyTowerNo];
    //CCout<<"ENEMYTOEWR:   "<<S2.enemyTower.x<<" "<<S2.enemyTower.y<<"\n";
    if (heTowerInsight[enemyTowerNo]) towerhp=heTower[enemyTowerNo]->hp;
    if (myTowerTot == 1)
        if (myTowerDead[0]) onlyhp = myTower[1]->hp; else onlyhp = myTower[0]->hp;

    //Ӌ���ҷ��ȼ�֮��
    int levelsum = 0;
    for (int i=0; i<5; i++)
        levelsum+=myHero[i]->level;

    //�Д��Ўׂ�Ӣ���x�Һܽ�
    int heHeroNear = 0;
    for (int i=0; i<heHeroKnown; i++)
        if (heHeroInsight[i]) {
            bool can = 0;
            for (int j=0; j<5; j++)
                if (dis2(heHero[i]->pos, myHero[j]->pos)<=ViewRange)
                    ++heHeroNear;
        }

    bool nearEnemyTower = 0;
    for (int i=0; i<5; i++)
        if ((!myHero[i]->buff[7]) &&
            (dis2(myHero[i]->pos, myTowerPos[defenceTower]) >
             dis2(myHero[i]->pos, S2.enemyTower) * 2))
            nearEnemyTower = 1;

    //Ӌ�㮔ǰ����ʹ�õļ��ܔ�
    int skillcanuse = 0;
    for (int i=0; i<5; i++) {
        if (myHero[i]->U->findSkill("PiercingArrow")->cd <= 3)
            ++skillcanuse;
        if (myHero[i]->U->findSkill("ArrowsRain")->cd <= 3)
            ++skillcanuse;
    }

    calcWild();

    if (nowGlobalStrategy && (nowGlobalStrategy->Sno == 2)) {
        int totalive = 0;
        bool drawback = 0;
        for (int i=0; i<5; i++)
            if (S2.incontrol[i] && !myHero[i]->buff[7])
                ++totalive;
        if ((totalive<=1) && (towerhp>250))
            drawback = 1;
        if (!cooldownd &&
            (((towerhp>onlyhp) && ((S2.togetherd < nowRound-1) || (!nearEnemyTower))) ||
             ((myTowerTot==1) && (heTowerTot == 2) && (towerhp>300) && ((myHero[defenceTower]->hprate<0.4) || !myHero[defenceTower]->buff[7]) )))
        if (drawback) {
            nowGlobalStrategy = 0;
            towertime = nowRound + 50;
            if ((towertime>950) && (nowRound<950)) towertime=950;
            int enemyTowerNo = 0;
            if (S2.enemyTower == heTowerPos[1]) enemyTowerNo = 1;
            if (heTowerTot == 2)
                S2.enemyTower = heTowerPos[enemyTowerNo^1];
        }
    } else {
        if (myTowerTot == 2) {
            if (heTowerTot == 2) {
                int totNearMe = 0, totNearMee[2] = {0, 0};
                for (int i=0; i<heHeroKnown; i++) {
                    if ((heHeroInsight[i] &&
                        ((dis2(heHero[i]->pos, myTowerPos[0])<=400) || (dis2(heHero[i]->pos, myTowerPos[1])<=400)))
                        || heHeroDead[i])
                        ++totNearMe;
                    if ((heHeroInsight[i]) && (dis2(heHero[i]->pos, myTowerPos[0])<=400))
                        ++totNearMee[0];
                    if ((heHeroInsight[i]) && (dis2(heHero[i]->pos, myTowerPos[1])<=400))
                        ++totNearMee[1];
                }
                if (totNearMe>=4) {
                    bool silenceNo=-1;
                    if ((myTower[1-defenceTower]->TowerEvaluate()<=Tower::SilenceV) &&
                        (totNearMee[1-defenceTower] == 0))
                        silenceNo = 1-defenceTower;
                    else
                    if ((myTower[defenceTower]->TowerEvaluate()<=Tower::SilenceV) &&
                        (totNearMee[defenceTower] == 0))
                        silenceNo = defenceTower;
                    if ((silenceNo != -1) && (!aliveassassin)) {
                        int totlevelsum = 0;
                        double tothpratesum = 0;
                        for (int i=0; i<5; i++)
                            if ((det[i]%2==silenceNo) && (!myHero[i]->buff[7]))
                                totlevelsum += myHero[i]->level,
                                tothpratesum += myHero[i]->hprate;
                        if ((totlevelsum>=14) && (tothpratesum>=1.3)) {
                            int sele = 0;
                            for (int i=0; i<5; i++)
                                if (det[i]%2==silenceNo)
                                    sele+=(1<<i);
                            S2.refresh(sele);
                            nowGlobalStrategy=&S2;
                        }
                    }
                }
                int totlevelsum = 0;
                double tothpratesum = 0;
                for (int i=0; i<5; i++)
                    if (!myHero[i]->buff[7])
                        totlevelsum+=myHero[i]->level,
                        tothpratesum+=myHero[i]->hprate;
                if ((totlevelsum>=35) && (tothpratesum>=3.0) && cooldownd) {
                    S2.refresh(31-1-2);
                    nowGlobalStrategy=&S2;
                }
            }
            if (heTowerTot == 1) {
                int totlevelsum = 0;
                double hpratesum = 0;
                for (int i=0; i<5; i++)
                    if ((det[i]!=defenceTower || !aliveassassin) && !myHero[i]->buff[7])
                        totlevelsum += myHero[i]->level,
                        hpratesum += myHero[i]->hprate;
                int sele = 0;
                for (int i=0; i<5; i++)
                    if (det[i]!=defenceTower || !aliveassassin)
                        sele+=(1<<i);
                if (nowGlobalStrategy) {
                    S2.refresh(sele);
                    nowGlobalStrategy=&S2;
                } else
                if ((totlevelsum>=25) && (hpratesum>=3.0) && (cooldownd)) {
                    S2.refresh(sele);
                    nowGlobalStrategy=&S2;
                }
            }
        }
        if (myTowerTot == 1) {
            if (heTowerTot == 2) {
                if (totHeHeroDead>=4) {
                    int totlevelsum = 0;
                    double hpratesum = 0.0;
                    for (int i=0; i<5; i++)
                        if (((i!=defenceTower) || ((!aliveassassin) && (!assassinfire))) && (!myHero[i]->buff[7]))
                            totlevelsum += myHero[i]->level,
                            hpratesum += myHero[i]->hprate;
                    if ((totlevelsum>=15) && (hpratesum >= 2.0) && (cooldownd)) {
                        if ((!aliveassassin) && (!assassinfire)) S2.refresh(31);
                            else S2.refresh(31-1<<defenceTower);
                        nowGlobalStrategy=&S2;
                    }
                }
            }
            if (heTowerTot == 1) {
                int totlevelsum = 0;
                double hpratesum = 0.0;
                for (int i=0; i<5; i++)
                    if (((i!=defenceTower) || ((!aliveassassin) && (!assassinfire))) && (!myHero[i]->buff[7]))
                        totlevelsum += myHero[i]->level,
                        hpratesum += myHero[i]->hprate;
                if ((totHeHeroDead>=4) || ((totlevelsum>=40) && (nowRound>=towertime))) {
                    if ((totlevelsum>=15) && (hpratesum >= 2.0) && (cooldownd)) {
                        if ((!aliveassassin) && (!assassinfire)) S2.refresh(31);
                            else S2.refresh(31-1<<defenceTower);
                        nowGlobalStrategy=&S2;
                    }
                }
            }
        }
    }

    if ((cooldownd) && (nowRound>=960)) {
       if (aliveassassin) S2.refresh(31-1<<defenceTower); else S2.refresh(31);
       nowGlobalStrategy=&S2;
    }

    if (nowGlobalStrategy) nowGlobalStrategy->work();
    S1.work();
}

void yq::global::calcWild() {
    int many[5];
    if (myTowerTot == 2) {
        det[0] = 0, det[1] = 1;
        if (myHero[2]->level+myHero[3]->level+myHero[4]->level<9) {
            det[2] = det[3] = det[4] = 2;
        } else {
            det[2] = det[3] = 2;
            det[4] = 3;
        }
        if (myHero[0]->buff[7])
            det[2] = 0;
        if (myHero[1]->buff[7])
            det[3] = 1;
    } else {
        det[0] = det[1] = defenceTower;
        det[2] = det[3] = det[4] = defenceTower + 2;
    }
    for (int i=0; i<5; i++) {
        if (det[i] == 0) {
            many[i] = 2;
        }
        if (det[i] == 1) {
            bool have3 = 0;
            for (int j=0; j<5; j++)
                if (det[j] == 3) have3 = 1;
            if (have3) many[i] = 2; else many[i] = 1;
        }
        if (det[i] == 2) {
            many[i] = 5;
            /*
            bool alone = 1;
            for (int j=0; j<5; j++)
                if ((i!=j) && (det[j]==2)) alone = 0;
            if ((myHero[0]->level<3) || (alone)) many[i] = 3; else many[i] = 4;
            */
        }
        if (det[i] == 3) {
            many[i] = 3;
        }
    }
    for (int i=0; i<5; i++)
        if (!myHero[i]->buff[7]) {
            //if (det[i]<2) myHero[i]->_exerWild.escape = 1;
            if (dis2(myHero[i]->pos, mySpring->pos)<dis2(myHero[i]->pos, myTowerPos[det[i] % 2]))
                myHero[i]->_exerWild.home = mySpring->pos;
            else
                myHero[i]->_exerWild.home = myTowerPos[det[i] % 2];

            bool legal = 0;
            for (int j=0; j<many[i]; j++)
                if (myHero[i]->_exerWild.aim == WildList::towerwild[nowPlayer][det[i]%2][j])
                    legal = 1;
            if (many[i]==5)
                if (myHero[i]->_exerWild.aim == WildList::towerwild[nowPlayer][det[i]%2][4]) {
                    int sum=0;
                    for (int j=0; j<5; j++)
                        if ((many[j]==5) && (!myHero[j]->buff[7]) &&
                            (dis2(myHero[j]->pos, WildList::towerwild[nowPlayer][0][4])<=2500))
                            sum++;
                    if (sum>=2) legal = 1;
                }

            if (!legal) {
                int mintime = 10000, mindis = 10000, minno = 0;
                int l = (many[i]==5?2:0), r=(many[i]==5?4:many[i]);
                for (int j=l; j<r; j++) {
                    Pos n = WildList::findNo(WildList::towerwild[nowPlayer][det[i]%2][j]);
                    if (n == Pos()) continue;
                    if ((WildList::wildlevel[n.x][n.y]>myHero[i]->level) && (det[i]<2)) continue;
                    if ((WildList::wildrevtime[n.x][n.y] < mintime) ||
                        ((WildList::wildrevtime[n.x][n.y] == mintime) &&
                         (dis2(myHero[i]->pos, WildList::towerwild[nowPlayer][det[i]%2][j])<mindis))) {
                        myHero[i]->_exerWild.aim = WildList::towerwild[nowPlayer][det[i]%2][j];
                        minno = j;
                        mindis=dis2(myHero[i]->pos, WildList::towerwild[nowPlayer][det[i]&2][j]);
                        mintime=WildList::wildrevtime[n.x][n.y];
                    }
                }
            }
        }

    int totHealthyDragon = 0, totHealthy = 0;
    Pos n = WildList::findNo(WildList::towerwild[nowPlayer][0][4]);
    for (int i=0; i<5; i++)
        if ((!myHero[i]->buff[7]) && (myHero[i]->hprate>0.7) &&
            (myHero[i]->level>=2) && (many[i] == 5) &&
            (dis2(myHero[i]->pos, WildList::towerwild[nowPlayer][0][4])<=2500))
            totHealthyDragon+=myHero[i]->level, ++totHealthy;
    if ((((totHealthy>=3) && (totHealthyDragon>=5)) || ((totHealthy>=2) && (totHealthyDragon>=8)))
         && (WildList::wildrevtime[n.x][n.y] == 0))
        for (int i=0; i<5; i++)
            if (!myHero[i]->buff[7] && (myHero[i]->hprate>0.7) &&
                (myHero[i]->level>=2) && (many[i] == 5) &&
                (dis2(myHero[i]->pos, WildList::towerwild[nowPlayer][0][4])<=2500))
                myHero[i]->_exerWild.aim = WildList::towerwild[nowPlayer][0][4];

    for (int i=0; i<5; i++) {
        CCout<<"!!!@@@ "<<det[i]<<" "<<many[i]<<"\n";
        LLog<<"!!!@@@ "<<det[i]<<" "<<many[i]<<"\n";
    }
}

void yq::globalStrategy1::work() {
    //����
    if (myTower[global::defenceTower]->TowerEvaluate()>Tower::SilenceV) {
        int hpmin=10000; Pos enemypos;
        for (int i=0; i<heHeroKnown; i++)
            if (heHeroInsight[i] && (dis2(myTower[global::defenceTower]->pos, heHero[i]->pos)<=ViewRange))
                if (heHero[i]->hp<=hpmin)
                    hpmin = heHero[i]->hp, enemypos = heHero[i]->pos;
        if (hpmin<10000) {
            for (int i=0; i<5; i++)
                if ((global::det[i]!=1-global::defenceTower) || (!global::aliveassassin)) {
                    myHero[i]->setS("fighting", enemypos);
                }
        } else
            for (int i=0; i<5; i++)
                if ((global::det[i]!=1-global::defenceTower) || (!global::aliveassassin)) {
                    myHero[i]->setS("move", enemypos);
                }
        return;
    }

    //���Ț�Ӣ��
    int dissummin=1000000; Pos enemypos;
    for (int i=0; i<heHeroKnown; i++)
        if (heHeroInsight[i]) {
            int nowdissum=0;
            for (int j=0; j<5; j++)
                if (!myHero[j]->buff[7])
                    nowdissum+=dis2(heHero[i]->pos, myHero[j]->pos);
            if (nowdissum<=dissummin)
                dissummin=nowdissum, enemypos=heHero[i]->pos;
        }
    bool nearMyTower = 0;
    if ((dis2(enemypos, myTowerPos[0])<=1600) && !myTowerDead[0]) nearMyTower = 1;
    if ((dis2(enemypos, myTowerPos[1])<=1600) && !myTowerDead[1]) nearMyTower = 1;
    if (dissummin<1000000) {
        for (int i=0; i<5; i++)
            if ((global::det[i]>1) || nearMyTower) {
                //myHero[i]->_fighting.refresh(enemypos);
                myHero[i]->setS("fighting", enemypos);
            }
    }

    //���oѪ,���h�[
    for (int i=0; i<5; i++)
        if ((global::det[i]<2) && (!myTowerDead[global::det[i]]) &&
            ((myTower[global::det[i]]->hprate<0.4) || (global::aliveassassin && (myTower[global::det[i]]->hprate<0.7))))
            myHero[i]->setS("move", myTowerPos[global::det[i]]);

    //��Ұ
    int mylevelsum = 0;
    for (int i=0; i<5; i++)
        mylevelsum += myHero[i]->level;
    CCout<<"preferTower:  "<<preferTower<<"\n";
    LLog<<"preferTower:  "<<preferTower<<"\n";
    for (int i=0; i<5; i++)
        //if (myHero[i]->level>=9) {
        //    myHero[i]->Move(myTower[global::det[i]%2]->pos);
        //    myHero[i]->setS("empty");
        //} else
            myHero[i]->setS("exerWild");

    CCout<<"fi\n";
}

void yq::globalStrategy2::work() {
    int sum = 0, allsum = 0;
    for (int i=0; i<5; i++)
        if (incontrol[i])
            allsum+=myHero[i]->level;
    for (int i=0; i<5; i++)
        if (incontrol[i]) {
            int nowsum = 0;
            for (int j=0; j<5; j++)
                if ((dis2(myHero[i]->pos, myHero[j]->pos)<=81) && (!myHero[j]->buff[7])
                    && incontrol[j])
                    nowsum+=myHero[j]->level;
            if (nowsum>sum) sum=nowsum;
        }
    if (((sum>=allsum*2/3) && (sum>=10)) || (togetherd == nowRound-1)) togetherd = nowRound;

    int enemyHp = 1000;
    for (int i=0; i<2; i++)
        if (heTowerInsight[i] && (enemyTower == heTowerPos[i]))
            enemyHp = heTower[i]->hp;

    int dissummin=1000000; Pos enemypos;
    for (int i=0; i<heHeroKnown; i++) {
        bool can = heHeroInsight[i];
        if (can) {
            bool realcan = 0;
            for (int j=0; j<5; j++)
                if ((dis2(heHero[i]->pos, myHero[j]->pos)<=ViewRange) && (incontrol[j]))
                    realcan = 1;
            if (!realcan) can = 0;
        }
        if (can) {
            int nowdissum=0;
            for (int j=0; j<5; j++)
                if ((!myHero[j]->buff[7]) && (incontrol[j]))
                    nowdissum+=dis2(heHero[i]->pos, myHero[j]->pos);
            if (nowdissum<=dissummin)
                dissummin=nowdissum, enemypos=heHero[i]->pos;
        }
    }

    bool onlyDanger = 0;
    if (myTowerTot == 1) {
        for (int i=0; i<2; i++)
            if ((!myTowerDead[i]) && (myTower[i]->TowerEvaluate()>=Tower::DangerV))
                onlyDanger = 1;
    }

    int arrived = 0, shouldarrive = 0;
    for (int i=0; i<5; i++)
        if (incontrol[i]) {
            if (dis2(myHero[i]->pos, enemyTower)<=myHero[i]->range)
                arrived++;
            if (incontrol[i] && !myHero[i]->buff[7])
                shouldarrive++;
        }

    bool pushing = 0;
    for (int i=0; i<5; i++)
        if (incontrol[i]) {
            if (myHero[i]->nowStrategy->SName == "pushTower")
                pushing = 1;
            else
                pushing = 0;
            break;
        }

    if ((dissummin<1000000) && (enemyHp>250) && (!onlyDanger)
        && ((!pushing) || (arrived < shouldarrive))) {
        for (int i=0; i<5; i++)
            if (incontrol[i]) {
               // myHero[i]->_fighting.refresh(enemypos);
                myHero[i]->setS("fighting", enemypos);
            }
        return;
    }

    if (togetherd!=nowRound) {
        for (int i=0; i<5; i++)
            if (incontrol[i]) {
                //myHero[i]->_together.refresh(enemyTower);
                myHero[i]->setS("together", enemyTower);
            }
    } else {
        for (int i=0; i<5; i++)
            if (incontrol[i]) {
                //myHero[i]->_pushTower.refresh(enemyTower);
                myHero[i]->setS("pushTower", enemyTower);
            }
    }
}

bool yq::globalStrategy2::calcCanPushTower(int towerHp) {
    int sum = 0;
    int X[5], Y[5], Z[5], H[5];
    for (int i=0; i<5; i++)
        if (!myHero[i]->buff[7] && (myHero[i]->hprate>=0.2))
            X[sum]=myHero[i]->atk, Y[sum]=myHero[i]->def,
            Z[sum]=myHero[i]->maxhp, H[sum]=myHero[i]->hp,
            sum++;
    for (int i=0; i<sum; i++)
        for (int j=sum-1; j>=i+1; j--)
            if (H[j]<H[j-1]) {
                int t;
                t=X[j],X[j]=X[j-1],X[j-1]=t;
                t=Y[j],Y[j]=Y[j-1],Y[j-1]=t;
                t=Z[j],Z[j]=Z[j-1],Z[j-1]=t;
                t=H[j],H[j]=H[j-1],H[j-1]=t;
            }
    double T[5], tothurt=0.0;
    for (int i=0; i<sum; i++)
        T[i]=(double)(H[i]-Z[i]/5.0)/(double)(55.0-Y[i]-Z[i]/100.0);
    for (int i=0; i<sum; i++)
        tothurt=(double)(X[i]/2.0/*-17.5/4.0*/)*(3*T[i]);

    CCout<<"*****tothurt:  "<<tothurt<<"  *****\n";
    if (tothurt >= towerHp) return 1; else return 0;
}

void yq::global::prepare() {
    nowRound = Info->round;
    nowPlayer = Info->player;

    //����ѿ�����λ��
    memset(occupy, 0, sizeof(occupy));
    memset(Bound.bound, 0, sizeof(Bound.bound));
    for (int i = 0; i < Info->units.size(); i++)
        Bound.setBound(Info->units[i].pos, 1),
        setOccupy(Info->units[i].pos, 1);

    //��һ�غϳ�ʼ������λ��
    if (nowRound == 1) {
        if (nowPlayer == 0) {
            myTowerPos[0] = Player0_tower_pos[1], myTowerPos[1] = Player0_tower_pos[0];
            heTowerPos[0] = Player1_tower_pos[1], heTowerPos[1] = Player1_tower_pos[0];
        };
        if (nowPlayer == 1) {
            myTowerPos[0] = Player1_tower_pos[1], myTowerPos[1] = Player1_tower_pos[0];
            heTowerPos[0] = Player0_tower_pos[1], heTowerPos[1] = Player0_tower_pos[0];
        }
        S2.enemyTower=heTowerPos[1];
    }

    //��ʼ���Լ���Ӣ��
    int tmp = 0;
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == nowPlayer) && (Info->units[i].isHero())) {
            if (nowRound == 1) {
                ++tmp;
                int Id = tmp - 1;
                if (stringcmp(Info->units[i].name, "Archer"))
                    myHero[Id] = new Archer(&Info->units[i]), myHero[Id]->No = Id;
            }
            else
                for (int j = 0; j < 5; j++)
                    if (myHero[j]->id == Info->units[i].id) {
                        myHero[j]->refresh(&Info->units[i]);
                    }
        }
    totMyHeroDead = 0;
    for (int i=0; i<5; i++)
        if (myHero[i]->buff[7]) ++totMyHeroDead;

    //��ʼ���Լ�������Ȫˮ
    memset(myTowerDead, 1, sizeof(myTowerDead));
    myTowerTot = 0;
    for (int i = 0; i < Info->units.size(); i++) {
        if ((Info->units[i].player == nowPlayer) && (stringcmp(Info->units[i].name, "Tower"))) {
            ++myTowerTot;
            for (int j = 0; j < 2; j++)
                if (Info->units[i].pos == myTowerPos[j]) {
                    if (myTower[j])
                        myTower[j]->refresh(&Info->units[i]);
                    else
                        myTower[j] = new Tower(&Info->units[i]);
                    myTowerDead[j] = 0;
                }
        }
        if ((Info->units[i].player == nowPlayer) && (stringcmp(Info->units[i].name, "Spring")))
            if (mySpring)
                mySpring->refresh(&Info->units[i]);
            else
                mySpring = new Unit(&Info->units[i]);
    }

    //��ʼ������ĵ�λ
    memset(heHeroInsight, 0, sizeof(heHeroInsight));
    memset(heTowerInsight, 0, sizeof(heTowerInsight));
    memset(nowHeHeroHp, 0, sizeof(nowHeHeroHp));
    memset(nowHeRainy, 0, sizeof(nowHeRainy));
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == 1 - nowPlayer) && (Info->units[i].isHero())) {
            int ord = -1;
            for (int j = 0; j < heHeroKnown; j++)
                if (Info->units[i].id == heHero[j]->id) ord = j;
            if (ord == -1) ++heHeroKnown, ord = heHeroKnown - 1;
            heHeroInsight[ord] = 1;
            if (heHero[ord])
                heHero[ord]->refresh(&Info->units[i]);
            else
                heHero[ord] = new Unit(&Info->units[i]);
            nowHeHeroHp[ord] = heHero[ord]->hp;
            nowHeRainy[ord] = heHero[ord]->buff[1];
        }
    for (int i = 0; i < Info->units.size(); i++) {
        if ((Info->units[i].player == 1 - nowPlayer) && (stringcmp(Info->units[i].name, "Tower")))
            for (int j = 0; j < 2; j++)
                if (Info->units[i].pos == heTowerPos[j]) {
                    if (heTower[j])
                        heTower[j]->refresh(&Info->units[i]);
                    else
                        heTower[j] = new Tower(&Info->units[i]);
                    heTowerInsight[j] = 1;
                }
        if ((Info->units[i].player == 1 - nowPlayer) && (stringcmp(Info->units[i].name, "Spring")))
            if (heSpring)
                heSpring->refresh(&Info->units[i]);
            else
                heSpring = new Unit(&Info->units[i]);
    }

    //��ʼ�����������������
    for (int i=0; i<2; i++)
        if (!heTowerDead[i]) {
            bool canObserve=0;
            for (int j=0; j<5; j++)
                if ((dis2(myHero[j]->pos, heTowerPos[i])<=ViewRange) &&
                    (abs(getHeight(myHero[j]->pos)-getHeight(heTowerPos[i]))<2))
                    canObserve=1;
            if ((canObserve)&&(heTower[i]->refreshRound!=nowRound)) {
                heTowerDead[i]=1;
                heTowerTot--;
            }
        }

    //��¼�ɼ�Ұ��
    totWild = 0;
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == 2) && (Info->units[i].isWild()))
            ++totWild, wild[totWild - 1] = new Unit(&Info->units[i]);

    //��¼Ұ�ֵ��������
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 8; j++)
            if (WildList::wildrevtime[i][j])
                WildList::wildrevtime[i][j]--;
    for (int i = 0; i < totWild; i++)
        if (wild[i]->buff[7]) {
            Pos origin;
            int mindis2 = inf;
            for (int j = 0; j < 6; j++)
                for (int k = 0; k < 8; k++)
                    if (dis2(wild[i]->pos, WildList::wildpos[j][k]) < mindis2)
                        mindis2 = dis2(wild[i]->pos, WildList::wildpos[j][k]), origin = Pos(j, k);
            if (WildList::wildrevtime[origin.x][origin.y] == 0)
                WildList::wildrevtime[origin.x][origin.y] = WildList::revtime[origin.x];
        }

    //��ʼ������
    for (int i = 0; i < heHeroKnown; i++)
        if ((heHeroInsight[i]) && (!heHero[i]->buff[4]) && (!heHero[i]->buff[7]))
            Bound.setBound(heHero[i]->pos, 6),
            setOccupy(heHero[i]->pos, 1);
    for (int i = 0; i < 2; i++)
        if (heTowerInsight[i])
            Bound.setBound(heTower[i]->pos, heTower[i]->range);
    for (int i = 0; i < totWild; i++)
        Bound.setBound(wild[i]->pos, 8),
        setOccupy(wild[i]->pos, 1);
    for (int i=0; i<Info->flights.size(); i++) {
        if ((Info->flights[i].camp==1-nowPlayer) && (Info->flights[i].typeId==1))
            Bound.setBound(Info->flights[i].target, 25),
            setOccupy(Info->flights[i].target, 25);
        if ((Info->flights[i].camp==1-nowPlayer) && (Info->flights[i].typeId==0))
            Bound.setBound(Info->flights[i].target, 1),
            setOccupy(Info->flights[i].target, 1);
    }
    for (int i=0; i<Info->areas.size(); i++) {
        if (Info->areas[i].camp==1-nowPlayer)
            Bound.setBound(Info->areas[i].center, 25),
            setOccupy(Info->areas[i].center, 25);
    }

    //Ѱ·����¼
    for (int i = 0; i < 5; i++)
        if (!myHero[i]->buff[7])
            myHero[i]->findRoad();

    //�ж϶����ǲ��Ǹ�̿���
    int totassassin = 0; aliveassassin = 0;
    for (int i=0; i<heHeroKnown; i++) {
        if (heHero[i]->name == "Assassin") ++totassassin;
        if ((heHero[i]->name == "Assassin") && (heHeroDead[i] == 0))
            aliveassassin = 1;
    }
    if (totassassin >= 3) assassinfire = 1;
}

void yq::global::calcHeHeroDead() {
    int hit[5]={0,0,0,0,0};
    for (int i=0; i<Cmd->cmds.size(); i++) {
        int No=0;
        for (int j=0; j<5; j++)
            if (myHero[j]->id==Cmd->cmds[i].id) No=j;
        if (Cmd->cmds[i].type=="Attack") {
            int myatk=(*(myHero[No]->U))["Atk"]->val[1];
            for (int j=0; j<heHeroKnown; j++)
                if ((heHeroInsight[j])&&(heHero[j]->pos==Cmd->cmds[i].targets[0]))
                    hit[j]+=max(myatk-((*(heHero[j]->U))["Def"]->val[1]),5);
        }
        if (Cmd->cmds[i].type=="Charge") {
            for (int j=0; j<heHeroKnown; j++)
                if ((heHeroInsight[j])&&(heHero[j]->pos==Cmd->cmds[i].targets[0]))
                    hit[j]+=(myHero[No]->U->findSkill("Charge")->level*30+30);
        }
        if (Cmd->cmds[i].type=="Spin") {
            for (int j=0; j<heHeroKnown; j++)
                if ((heHeroInsight[j])&&(dis2(heHero[j]->pos,myHero[No]->pos)<=myHero[No]->range))
                    hit[j]+=(myHero[No]->U->findSkill("Spin")->level*45+45);
        }
        if (Cmd->cmds[i].type=="PiercingArrow") {
            for (int j=0; j<heHeroKnown; j++)
                if ((heHeroInsight[j])&&(check(myHero[No]->pos,Cmd->cmds[i].targets[0],heHero[j]->pos)))
                        hit[j]+=5+40*(myHero[No]->U->findSkill("PiercingArrow")->level+1);
        }
        if (Cmd->cmds[i].type=="FlyingBlade") {
            for (int j=0; j<heHeroKnown; j++)
                if ((heHeroInsight[j])&&(heHero[j]->pos==Cmd->cmds[i].targets[0]))
                        hit[j]+=-5+50*(myHero[No]->U->findSkill("FlyingBlade")->level+1);
        }
     }
     for (int i=0; i<Info->areas.size(); i++)
        if (Info->areas[i].camp==nowPlayer) {
            int calcLevel=0, haveAble=0;
            for (int j=0; j<5; j++)
                if (myHero[j]->U->findSkill("ArrowsRain") &&
                    (myHero[j]->U->findSkill("ArrowsRain")->level>=0)) {
                    haveAble++;
                    calcLevel+=myHero[j]->U->findSkill("ArrowsRain")->level;
                }
            calcLevel/=haveAble;
            for (int j=0; j<heHeroKnown; j++)
                if ((nowRound - heHero[j]->refreshRound <=4) && Info->areas[i].containPos(heHero[j]->pos))
                    hit[j]+=45+40*calcLevel;
        }
    for (int i=0; i<heHeroKnown; i++)
        if (heHeroDead[i]) heHeroDead[i]--;
    for (int i=0; i<heHeroKnown; i++)
        if (heHeroInsight[i] && (hit[i]+25>=heHero[i]->hp))
            heHeroDead[i]=5*(heHero[i]->level+1);
    totHeHeroDead=0;
    for (int i=0; i<heHeroKnown; i++)
        if (heHeroDead[i]) ++totHeHeroDead;
    CCout<<totHeHeroDead<<"\n";
    for (int i=0; i<5; i++)
        CCout<<hit[i]<<" ";
    CCout<<"\n";
}

yq::Unit::Unit() {}

yq::Unit::Unit(const PUnit *p): U(p),
    id(p->id), player(p->player), hp(p->hp), mp(p->mp),
    atk(p->atk), def(p->def), range(p->range), level(p->level),
    maxhp((*p)["Hp"]->val[1]), speed(p->speed), exp((*p)["Exp"]->val[0]),
    onlyTarget((*p)["OnlyTarget"]->val[0]),
    refreshRound(nowRound), pos(p->pos), name(p->name) {
    hprate = (double)hp / (double)maxhp;
    memset(buff, 0, sizeof(buff));
    for (int i = 0; i < p->buffs.size(); i++)
        buff[p->buffs[i].typeId] = 1;
    bornTime = 0;
}

yq::MyHero::MyHero() {
    nowStrategy = 0;
    strategySetTime = 0;
}

yq::MyHero::MyHero(const PUnit *p): Unit(p) {
    nowStrategy = 0;
    strategySetTime = 0;
}

void yq::Unit::refresh(const PUnit *p) {
    U = p, id = p->id, player = p->player, hp = p->hp, mp = p->mp,
    atk = p->atk, def = p->def, range = p->range, level = p->level,
    maxhp = (*p)["Hp"]->val[1], speed = p->speed, exp=(*p)["Exp"]->val[0],
    onlyTarget = ((*p)["OnlyTarget"]->val[0]),
    refreshRound = nowRound, pos = p->pos, name = p->name;
    hprate = (double)hp / (double)maxhp;
    memset(buff, 0, sizeof(buff));
    for (int i = 0; i < p->buffs.size(); i++)
        buff[p->buffs[i].typeId] = 1;
    if (buff[7]) bornTime = 0; else bornTime++;
}

int yq::MyHero::getLastHit(const int &id) {
    const PArg &_arg = *(*U)["LastHit"];
    if (id < _arg.val.size()) return _arg.val[id];
    return -1;
}

void yq::MyHero::findRoad() {
    int (*Step)[Map_size] = road.step;
    Pos (*Pre)[Map_size] = road.pre;
    for (int i = 0; i < Map_size; i++)
        for (int j = 0; j < Map_size; j++) {
            _Dis[i][j] = inf;
            Step[i][j] = -1, Pre[i][j] = Pos();
            inQueue[i][j] = 0;
        }
    int l = 1, r = 1, lmo = 1, rmo = 1;
    Queue[1] = pos, _Dis[pos.x][pos.y] = 0, Step[pos.x][pos.y] = 0, Pre[pos.x][pos.y] = pos, inQueue[pos.x][pos.y] = 1;
    int dir_ord[4];
    for (; l <= r; l++, lmo++) {
        if (lmo >= elem_maxsize) lmo -= elem_maxsize;
        Pos now = Queue[lmo];
        for (int i = 0; i < 4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord + 4);
            for (int i = 0; i < 4; i++) {
                Pos nex = Pos(now.x + dir[dir_ord[i]][0], now.y + dir[dir_ord[i]][1]);
                if (!checkPos(nex) || ((occupy[nex.x][nex.y]) && (occupy[now.x][now.y]==0))) continue;
                int delta = (Bound[nex] ? 100 : 1);
                if ((_Dis[now.x][now.y] + delta < _Dis[nex.x][nex.y]) &&
                        (abs(Map->height[now.x][now.y] - Map->height[nex.x][nex.y]) <= 1)) {
                    _Dis[nex.x][nex.y] = _Dis[now.x][now.y] + delta;
                    Step[nex.x][nex.y] = Step[now.x][now.y] + 1;
                    Pre[nex.x][nex.y] = now;
                    if (!inQueue[nex.x][nex.y]) {
                        inQueue[nex.x][nex.y] = 1;
                        ++rmo, ++r;
                        if (rmo >= elem_maxsize) rmo -= elem_maxsize;
                        Queue[rmo] = nex;
                    }
                }
            }
        inQueue[now.x][now.y] = 0;
    }
}

void yq::MyHero::findDRoad() {
    int (*Step)[Map_size] = droad.step;
    Pos (*Pre)[Map_size] = droad.pre;
    for (int i = 0; i < Map_size; i++)
        for (int j = 0; j < Map_size; j++) {
            _Dis[i][j] = inf;
            Step[i][j] = -1, Pre[i][j] = Pos();
            inQueue[i][j] = 0;
        }
    int l = 1, r = 1, lmo = 1, rmo = 1;
    Queue[1] = pos, _Dis[pos.x][pos.y] = 0, Step[pos.x][pos.y] = 0, Pre[pos.x][pos.y] = pos, inQueue[pos.x][pos.y] = 1;
    int dir_ord[4];
    for (; l <= r; l++, lmo++) {
        if (lmo >= elem_maxsize) lmo -= elem_maxsize;
        Pos now = Queue[lmo];
        for (int i = 0; i < 4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord + 4);
            for (int i = 0; i < 4; i++) {
                Pos nex = Pos(now.x + dir[dir_ord[i]][0], now.y + dir[dir_ord[i]][1]);
                if (!checkPos(nex) || ((occupy[nex.x][nex.y]) && (occupy[now.x][now.y]==0))) continue;
                int delta = 1;
                if ((_Dis[now.x][now.y] + delta < _Dis[nex.x][nex.y]) &&
                        (abs(Map->height[now.x][now.y] - Map->height[nex.x][nex.y]) <= 1)) {
                    _Dis[nex.x][nex.y] = _Dis[now.x][now.y] + delta;
                    Step[nex.x][nex.y] = Step[now.x][now.y] + 1;
                    Pre[nex.x][nex.y] = now;
                    if (!inQueue[nex.x][nex.y]) {
                        inQueue[nex.x][nex.y] = 1;
                        ++rmo, ++r;
                        if (rmo >= elem_maxsize) rmo -= elem_maxsize;
                        Queue[rmo] = nex;
                    }
                }
            }
        inQueue[now.x][now.y] = 0;
    }
}

bool yq::MyHero::Move(Pos dest, int nearforbid) {
    if (!(U->canMove())) return 0;

    int mindis = 100000; Pos newdest = Pos();
    for (int i=-10; i<=10; i++)
        for (int j=-10; j<=10; j++)
            if (checkPos(dest+Pos(i,j)) && (road.step[dest.x+i][dest.y+j] != -1)
                && !checkDeath(dest+Pos(i,j)))
                if (i*i+j*j<=mindis)
                    mindis=i*i+j*j, newdest=dest+Pos(i,j);
    dest = newdest;
    if (dest==Pos()) return 0;
    Pos nowp = dest;
    vector<Pos> trace;
    trace.clear();
    bool toonear = 1;
    while (nowp != pos) {
        if (dis2(nowp, dest) > nearforbid) toonear = 0;
        if ((road.step[nowp.x][nowp.y] <= 15) && (!toonear)) trace.push_back(nowp);
        nowp = road.pre[nowp.x][nowp.y];
    }
    trace.push_back(pos);
    Pos tmp;
    for (int i = 0; i < trace.size() / 2; i++)
        tmp = trace[i], trace[i] = trace[trace.size() - i - 1], trace[trace.size() - i - 1] = tmp;
    Operation nowOp;
    nowOp.id = id;
    nowOp.type = "Move";
    nowOp.targets = trace;
    Cmd->cmds.push_back(nowOp);
    return 1;
}

bool yq::MyHero::DMove(Pos dest, int nearforbid) {
    if (!(U->canMove())) return 0;

    int mindis = 100000; Pos newdest=Pos();
    for (int i=-10; i<=10; i++)
        for (int j=-10; j<=10; j++)
            if (checkPos(dest+Pos(i,j)) && (droad.step[dest.x+i][dest.y+j] != -1)
                && !checkDDeath(dest+Pos(i,j)))
                if (i*i+j*j<=mindis)
                    mindis=i*i+j*j, newdest=dest+Pos(i,j);
    dest = newdest;
    if (dest==Pos()) return 0;
    Pos nowp = dest;
    vector<Pos> trace;
    trace.clear();
    bool toonear = 1;
    while (nowp != pos) {
        if (dis2(nowp, dest) > nearforbid) toonear = 0;
        if ((droad.step[nowp.x][nowp.y] <= 15) && (!toonear)) trace.push_back(nowp);
        nowp = droad.pre[nowp.x][nowp.y];
    }
    trace.push_back(pos);
    Pos tmp;
    for (int i = 0; i < trace.size() / 2; i++)
        tmp = trace[i], trace[i] = trace[trace.size() - i - 1], trace[trace.size() - i - 1] = tmp;
    Operation nowOp;
    nowOp.id = id;
    nowOp.type = "Move";
    nowOp.targets = trace;
    Cmd->cmds.push_back(nowOp);
    return 1;
}

void yq::MyHero::work() {
    //CCout<<1;
    if (nowStrategy) {
        //CCout<<nowStrategy->SName;
        nowStrategy->work();
    }
    //CCout<<2<<"\n";
}

void yq::Archer::setS(const string s, Pos X) {
    if (strategySetTime == nowRound) return;
    strategySetTime = nowRound;
    if (s=="exerWild") {
        nowStrategy=&_exerWild;
        if (X!=Pos()) _exerWild.refresh(X);
    }
    if (s=="fighting") {
        nowStrategy=&_fighting;
        if (X!=Pos()) _fighting.refresh(X);
    }
    if (s=="pushTower") {
        nowStrategy=&_pushTower;
        if (X!=Pos()) _pushTower.refresh(X);
    }
    if (s=="together") {
        nowStrategy=&_together;
        if (X!=Pos()) _together.refresh(X);
    }
    if (s=="move") {
        nowStrategy=&_move;
        if (X!=Pos()) _move.refresh(X);
    }
}

void yq::exerWildArcherStrategy::work() {
    CCout<<aim.x<<" "<<aim.y<<"\n";
    LLog<<aim.x<<" "<<aim.y<<"\n";

    if (U->avoidDeath()) return;

    if ((*(U->U))["Exp"]->val[3]) {
        if (U->U->canUseSkill(MyHero::skillKind[U->No][U->level])) {
            normalOperationGen(Skill_name[MyHero::skillKind[U->No][U->level]],U->id);
            return;
        }
    }

    if (aim == Pos()) return;

    U->findRoad();

    int line, column;
    for (int i=0; i<6; i++)
        for (int j=0; j<8; j++)
            if (WildList::wildpos[i][j] == aim)
                line = i, column = j;
    Pos nowaim = Pos();
    Unit *nowwild = 0;
    for (int i=0; i<totWild; i++)
        if ((dis2(wild[i]->pos,U->pos)<=ViewRange) && (dis2(wild[i]->pos, aim)<=324)
            && (dis2(wild[i]->pos, aim)<dis2(nowaim, aim)))
            nowaim=wild[i]->pos, nowwild=wild[i];
    if (nowaim == Pos()) nowaim = aim;

    Pos nearMyTower = Pos();
    for (int i=0; i<2; i++)
        if (myTower[i]->refreshRound==nowRound)
            if ((dis2(myTower[i]->pos,U->pos)<dis2(nearMyTower,U->pos)) || (nearMyTower == Pos()))
                nearMyTower=myTower[i]->pos;

    if (escape) {
       if (U->hprate<=0.3) {
            if (!U->avoidDeath(home))
                U->Move(home);
            escaping = 1;
            return;
       }
       if ((escaping) && (U->hprate<0.8))
            return;
       if ((escaping) && (U->hprate>=0.8))
            escaping = 0;
    }

    if ((nowwild == 0) || (nowwild->buff[7]))
        U->Move(nowaim);
    else {
        int candrug = -1;
        if ((dis2(aim, myTowerPos[0])<=441) && !myTowerDead[0] && (nowwild->range<10))
            candrug = 0;
        if ((dis2(aim, myTowerPos[1])<=441) && !myTowerDead[1] && (nowwild->range<10))
            candrug = 1;

        if ((candrug != -1) && (dis2(nowwild->pos, myTowerPos[candrug])>100)) {
            if (U->U->canUseSkill(0) && (shotted!=nowRound-1)) {
                if (dis2(U->pos, nowwild->pos)>30) {
                    U->Move(nowwild->pos);
                } else {
                    normalOperationGen("Attack",U->id,nowwild->pos);
                    shotted = nowRound;
                }
            } else {
                shotted=nowRound;
                Pos ideal;
                int mindis=10000;
                for (int i=-5; i<=5; i++)
                for (int j=-5; j<=5; j++) {
                    Pos n=U->pos+Pos(i,j);
                    if (checkPos(n) && (occupy[n.x][n.y] == 0) && !checkDeath(n) &&
                        (dis2(nowwild->pos, n)<=ViewRange) && (dis2(aim, n)<=324))
                        if (dis2(n,myTowerPos[candrug])<mindis)
                            mindis=dis2(n,myTowerPos[candrug]), ideal=n;
                }
                U->Move(ideal);
            }
        } else {
        shotted = 0;
        if (U->U->canUseSkill(0)&&((candrug==-1) || (nowwild->hprate<=0.2))) {
            if (dis2(U->pos, nowwild->pos)>U->range)
                U->Move(nowwild->pos);
            else
                normalOperationGen("Attack",U->id,nowwild->pos);
        } else {
            if ((nowwild->hp>=100)&&(nowwild->maxhp>=300)&&(U->mp>=150)/*&&(U->level>=1)*/
                &&((U->level==0) || (U->U->canUseSkill(7) && U->U->canUseSkill(9))
                &&(candrug==-1))) {
                if (U->U->canUseSkill(7)) {
                    if (dis2(U->pos, nowwild->pos)>81)
                        U->Move(nowwild->pos);
                    else
                        normalOperationGen("PiercingArrow",U->id,nowwild->pos);
                    return;
                }
                bool covered = 0;
                for (int i=0; i<Info->areas.size(); i++)
                    if (Info->areas[i].containPos(nowwild->pos)) covered = 1;
                for (int i=0; i<Cmd->cmds.size(); i++)
                    if ((Cmd->cmds[i].type=="ArrowsRain") && (Cmd->cmds[i].targets[0] == nowwild->pos))
                        covered = 1;
                if (U->U->canUseSkill(9) && !covered) {
                    if (dis2(U->pos, nowwild->pos)>100)
                        U->Move(nowwild->pos);
                    else
                        normalOperationGen("ArrowsRain",U->id,nowwild->pos);
                    return;
                }
            }
            LLog<<"MoveIdeal\n";
            Pos tem=getExerIdeal(U->pos, U->range, U->speed, nowwild->pos, aim, nowwild->range, 1);
            U->Move(tem);
            occupy[U->pos.x][U->pos.y]--, occupy[tem.x][tem.y]++;
            Bound.bound[U->pos.x][U->pos.y]--, Bound.bound[tem.x][tem.y]++;
            U->pos = tem;
        }
        }
    }
}

Pos yq::exerWildArcherStrategy::getExerIdeal(Pos nowp, int range, int speed, Pos X, Pos orin, int herange, bool drag) {
    Pos ans = Pos(); int maxv=-10000, mindis=10000;
    for (int i=-5; i<=5; i++)
        for (int j=-5; j<=5; j++)
            if (checkPos(nowp+Pos(i,j)) &&
                !checkDeath(nowp+Pos(i,j)) &&
                !occupy[nowp.x+i][nowp.y+j] &&
                (i*i+j*j<=speed) &&
                (dis2(nowp, X)<=range) &&
                (abs(Map->height[nowp.x+i][nowp.y+j]-Map->height[X.x][X.y])<2) &&
                (dis2(nowp+Pos(i,j),orin)<=324)) {
                Pos newp = nowp + Pos(i,j);
                int nowv=0;
                for (int k=0; k<totWild; k++)
                    if ((dis2(newp, wild[k]->pos)<=range) && (dis2(newp, wild[k]->pos)>wild[k]->range))
                        nowv+=dis2(newp, wild[k]->pos)-wild[k]->range+10;

                if (drag) {
                    if ((dis2(orin, myTowerPos[0])<=441) && !myTowerDead[0] && (herange<10))
                        nowv+=450-max(dis2(newp, myTowerPos[0]),81);
                    if ((dis2(orin, myTowerPos[1])<=441) && !myTowerDead[1] && (herange<10))
                        nowv+=450-max(dis2(newp, myTowerPos[1]),81);
                }
                //if ((dis2(X, myTowerPos[0])<=81) && (!myTowerDead[0])) nowv=0;
                //if ((dis2(X, myTowerPos[1])<=81) && (!myTowerDead[1])) nowv=0;
                if ((nowv>maxv) || ((nowv==maxv) && (i*i+j*j<mindis)))
                    maxv=nowv, mindis=i*i+j*j, ans=newp;
            }
    return ans;
}

void yq::fightingArcherStrategy::work() {
    if ((*(U->U))["Exp"]->val[3]) {
        if (U->U->canUseSkill(MyHero::skillKind[U->No][U->level])) {
            normalOperationGen(Skill_name[MyHero::skillKind[U->No][U->level]],U->id);
            return;
        }
    }

    U->findRoad();

    bool inrangeEnemy = 0;
    if (U->U->canUseSkill(9)) {
        for (int i=0; i<heHeroKnown; i++)
            if ((heHeroInsight[i]) && (dis2(heHero[i]->pos, U->pos) <= 225)
                && (nowHeHeroHp[i]>0) && (!nowHeRainy[i]))
                inrangeEnemy = 1;
    } else {
        for (int i=0; i<heHeroKnown; i++)
            if ((heHeroInsight[i]) && (dis2(heHero[i]->pos, U->pos) <= U->range)
                && (nowHeHeroHp[i]>0))
                inrangeEnemy = 1;
    }

    if ((dis2(U->pos, aim)>=288) || !inrangeEnemy) {
        if (checkDeath(U->pos)) U->avoidDeath(aim); else
        U->Move(aim);
    } else {
        //mainwork();

        if (((U->U->canUseSkill(0) || U->U->canUseSkill(7) || U->U->canUseSkill(9))) && (!checkDeath(U->pos))) {
            selectAttack();
        } else {
            selectMove();
        }

    }
}
/*
void yq::fightingArcherStrategy::mainwork() {
}
*/
double yq::fightingArcherStrategy::evaluate(Pos X, bool work = 0) {
    double maxV=0.0;
    int KK = -1; Pos idealp = Pos();
    int Yelled = -1;
    if (U->onlyTarget != -1) {
        Yelled = -2;
        for (int k=0; k<heHeroKnown; k++)
            if (heHero[k]->id == U->onlyTarget)
                Yelled = k;
    }
    CCout<<"Only Target:       "<<U->onlyTarget<<"\n";
    CCout<<"Yelled:            "<<Yelled<<"\n";
    for (int i=0; i<heHeroKnown; i++)
        CCout<<"heHeroNo:"<<i<<"  HP:"<<nowHeHeroHp[i]<<"\n";
    for (int i=-10; i<=10; i++)
        for (int j=-10; j<=10; j++) {
            Pos aim = X+Pos(i,j);
            double nowV;

            if ((i*i+j*j<=U->range) && checkPos(aim)) {
                if (U->U->canUseSkill(0)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (heHero[k]->pos == aim)) {
                            nowV=min(nowHeHeroHp[k], U->atk-heHero[k]->def);
                            nowV=nowV*(1.0+(double)(nowV)/(double)(nowHeHeroHp[k]));
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 0, idealp = aim;
                }

                if (U->U->canUseSkill(7)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (check(X, aim, heHero[k]->pos))) {
                            double tt=min(nowHeHeroHp[k], ((Archer*)U)->arrowHit);
                            tt=tt*(1.0+(double)(tt)/(double)(nowHeHeroHp[k]));
                            nowV=nowV+tt;
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 1, idealp = aim;
                }
            }
            if ((i*i+j*j<=100) && checkPos(aim)) {
                if (U->U->canUseSkill(9)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (dis2(heHero[k]->pos, aim)<=25)
                            && !nowHeRainy[k]) {
                            double myoriginHit = ((Archer*)U)->rainHit;
                            if (heHero[k]->name == "Archer")
                                myoriginHit*=(2.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            if (heHero[k]->name == "Assassin") {
                                if (heHero[k]->U->canUseSkill(17))
                                    myoriginHit*=(2.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                                else
                                    myoriginHit*=(3.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            }
                            if (heHero[k]->name == "Fighter")
                                myoriginHit*=(3.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            double tt=min((double)nowHeHeroHp[k], myoriginHit);
                            tt=tt*(1.0+(double)(tt)/(double)(nowHeHeroHp[k]));
                            nowV=nowV+tt;
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 2, idealp = aim;
                }
            }
        }
    for (int i=0; i<U->No-1; i++)
        if (dis2(myHero[i]->pos, U->pos)<26) maxV+=dis2(myHero[i]->pos, U->pos)*2; else maxV+=56.0;
    for (int i=U->No-1; i<5; i++)
        maxV+=56.0;

    if (work) {
        if (KK == 0) {
            for (int k=0; k<heHeroKnown; k++)
                if ((Yelled == k) || (Yelled == -1))
                if (heHeroInsight[k] && (heHero[k]->pos == aim)) {
                    nowHeHeroHp[k]-=(U->atk-heHero[k]->def);
                }
            normalOperationGen("Attack", U->id, idealp);
        }
        if (KK == 1) {
            for (int k=0; k<heHeroKnown; k++)
                if ((Yelled == k) || (Yelled == -1))
                if (heHeroInsight[k] && (check(U->pos, aim, heHero[k]->pos))) {
                    nowHeHeroHp[k]-=(((Archer*)U)->arrowHit);
                }
            normalOperationGen("PiercingArrow", U->id, idealp);
        }
        if (KK == 2) {
            for (int k=0; k<heHeroKnown; k++)
                if ((Yelled == k) || (Yelled == -1))
                if (heHeroInsight[k] && (dis2(heHero[k]->pos, aim)<=25)
                    && !nowHeRainy[k]) {
                    nowHeRainy[k] = 1;
                    double myoriginHit = ((Archer*)U)->rainHit;
                    if (heHero[k]->name == "Archer")
                        myoriginHit*=(2.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                    if (heHero[k]->name == "Assassin") {
                        if (heHero[k]->U->canUseSkill(17))
                            myoriginHit*=(2.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                        else
                            myoriginHit*=(3.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                    }
                    if (heHero[k]->name == "Fighter")
                        myoriginHit*=(3.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                    nowHeHeroHp[k]-=myoriginHit;
                }
            normalOperationGen("ArrowsRain", U->id, idealp);
        }
    }
    return maxV;
}

bool yq::fightingArcherStrategy::selectAttack() {
    double VV[11][11];
    for (int i=-5; i<=5; i++)
    for (int j=-5; j<=5; j++) {
        double N=0.0;
        Pos XX=U->pos+Pos(i,j);
        if ((!checkPos(XX)) || checkDeath(XX) || (i*i+j*j>U->speed) || (occupy[XX.x][XX.y] && (XX!=U->pos))) {
            N=-10000.0;
            /*if (XX==U->pos) {
                CCout<<"SBSBSBSBSBSBSB\n";
                CCout<<checkPos(XX)<<"\n";
                CCout<<checkDeath(XX)<<"\n";
                CCout<<occupy[XX.x][XX.y]<<"\n";
                while (1) {}
            }*/
        } else
            N=evaluate(XX);
        VV[i+5][j+5]=N;
    }
    double nowVV=VV[5][5], orinVV=VV[5][5];
    Pos sele = U->pos;
    for (int i=-5; i<=5; i++)
        for (int j=-5; j<=5; j++)
            if ((VV[i+5][j+5]>=orinVV*2.0) && (VV[i+5][j+5]>nowVV))
                sele=U->pos+Pos(i,j), nowVV=VV[i+5][j+5];

    if (sele == U->pos)
        evaluate(sele, 1);
    else
        U->setS("move", sele);
    CCout<<"orinVV: "<<orinVV<<"\n";
    CCout<<"nowVV: "<<nowVV<<"\n";
    LLog<<"orinVV: "<<orinVV<<"\n";
    LLog<<"nowVV: "<<nowVV<<"\n";
}

void yq::fightingArcherStrategy::selectMove() {
    double maxV=-100000.0; int dis=100000;
    double VMap[20][20];
    Pos idealp = Pos();
    for (int i=-9; i<=9; i++)
        for (int j=-9; j<=9; j++) {
            double nowV=0.0;
            if (checkDDeath(U->pos+Pos(i,j))) nowV-=10000.0;
            if (checkPos(U->pos+Pos(i,j)) && (occupy[U->pos.x+i][U->pos.y+j] == 0)) {
                Pos Dest = U->pos+Pos(i,j);
                for (int k=0; k<totWild; k++)
                    if (dis2(Dest, wild[k]->pos)<=wild[k]->range)
                        nowV-=10000.0;
                for (int k=0; k<2; k++)
                    if ((dis2(Dest, heTowerPos[k])<=100) && (!heTowerDead[k]))
                        nowV-=10000.0;
                for (int k=0; k<heHeroKnown; k++)
                    if (heHeroInsight[k] && (dis2(Dest, heHero[k]->pos)<=81)) {
                        if (heHero[k]->name == "Archer")
                            nowV+=(2.0-heHero[k]->hprate)*(double)(81+dis2(Dest, heHero[k]->pos));
                        if (heHero[k]->name == "Fighter") {
                            if (dis2(Dest, heHero[k]->pos)<=13)
                                nowV+=(2.0-heHero[k]->hprate)*40.0;
                            else
                                nowV+=(2.0-heHero[k]->hprate)*(double)(81+dis2(Dest, heHero[k]->pos));
                        }
                        if (heHero[k]->name == "Assassin") {
                            if (dis2(Dest, heHero[k]->pos)<=8)
                                nowV+=(2.0-heHero[k]->hprate)*40.0;
                            else
                                nowV+=(2.0-heHero[k]->hprate)*(double)(81+dis2(Dest, heHero[k]->pos));
                        }
                    }
            }
            VMap[i+9][j+9] = nowV;
        }
    for (int i=-9; i<=9; i++)
        for (int j=-9; j<=9; j++)
            if (i*i+j*j<=U->speed)
                if (checkPos(U->pos+Pos(i,j)))
                if (VMap[i+9][j+9]>maxV)
                    maxV=VMap[i+9][j+9], idealp=U->pos+Pos(i,j);
    if (maxV<-10.0)
        for (int i=-9; i<=9; i++)
            for (int j=-9; j<=9; j++)
                if (checkPos(U->pos+Pos(i,j)))
                if ((VMap[i+9][j+9]>maxV) && (VMap[i+9][j+9]>0.0) && (i*i+j*j<=U->speed*2))
                    maxV=VMap[i+9][j+9], idealp=U->pos+Pos(i,j);
    if (idealp != Pos()) {
        U->Move(idealp);
        occupy[U->pos.x][U->pos.y]--, occupy[idealp.x][idealp.y]++;
        Bound.bound[U->pos.x][U->pos.y]--, Bound.bound[idealp.x][idealp.y]++;
        U->pos = idealp;
    }
}

void yq::pushTowerArcherStrategy::work() {
    if (U->avoidDDeath(aim)) return;

    if ((*(U->U))["Exp"]->val[3]) {
        if (U->U->canUseSkill(MyHero::skillKind[U->No][U->level])) {
            normalOperationGen(Skill_name[MyHero::skillKind[U->No][U->level]],U->id);
            return;
        }
    }

    U->findDRoad();

    if (dis2(U->pos, aim)>ViewRange)
        U->Move(aim);
    else {
        if (dis2(U->pos, aim)>U->range)
            U->DMove(aim);
        else if (!U->U->canUseSkill(0)) {
            bool attacked = selectAttack();
            if (attacked) return;
            Pos tem=getPushIdeal(U->pos, aim, U->range, U->speed);
            U->DMove(tem);
            occupy[U->pos.x][U->pos.y]--, occupy[tem.x][tem.y]++;
            Bound.bound[U->pos.x][U->pos.y]--, Bound.bound[tem.x][tem.y]++;
            U->pos = tem;
        } else
            normalOperationGen("Attack", U->id, aim);
    }
}

Pos yq::pushTowerArcherStrategy::getPushIdeal(Pos nowp, Pos aim, int range, int speed) {
    Pos ans = Pos(); int minv=100000, mindis=0;
    for (int i=-5; i<=5; i++)
        for (int j=-5; j<=5; j++)
            if (checkPos(nowp+Pos(i,j)) &&
                !checkDDeath(nowp+Pos(i,j)) &&
                !occupy[nowp.x+i][nowp.y+j] &&
                (i*i+j*j<=speed) &&
                (dis2(nowp+Pos(i,j), aim)<=range) &&
                (abs(Map->height[nowp.x+i][nowp.y+j]-Map->height[nowp.x][nowp.y])<2)) {
                Pos newp = nowp + Pos(i,j);
                int nowv=0;
                for (int k=0; k<totWild; k++)
                    if (dis2(newp, wild[k]->pos)<=wild[k]->range)
                        nowv+=(wild[k]->range-dis2(newp, wild[k]->pos))*10;
                for (int k=0; k<heHeroKnown; k++)
                    if (heHeroInsight[k] && (dis2(heHero[k]->pos, newp)<=heHero[k]->range))
                        nowv+=(heHero[k]->range-dis2(newp, heHero[k]->pos))*10;
                for (int k=0; k<5; k++)
                    if (myHero[k]->pos != nowp)
                        nowv-=dis2(newp, myHero[k]->pos);
                nowv+=range-dis2(newp, aim);
                if ((nowv<minv) || ((nowv==minv) && (i*i+j*j<mindis)))
                    minv=nowv, mindis=i*i+j*j, ans=newp;
            }
    LLog<<"tem: ("<<ans.x<<","<<ans.y<<")\n";
    LLog<<"minv: "<<minv<<"   "<<"mindis: "<<mindis<<"\n";
    return ans;
}

bool yq::pushTowerArcherStrategy::selectAttack() {
    double maxV=0.0;
    int KK = -1; Pos idealp = Pos();
    int Yelled = -1;
    if (U->onlyTarget != -1) {
        Yelled = -2;
        for (int k=0; k<heHeroKnown; k++)
            if (heHero[k]->id == U->onlyTarget)
                Yelled = k;
    }
    for (int i=-10; i<=10; i++)
        for (int j=-10; j<=10; j++) {
            Pos aim = U->pos+Pos(i,j);
            double nowV;

            if ((i*i+j*j<=U->range) && checkPos(U->pos+Pos(i,j))) {
                if (U->U->canUseSkill(0)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (heHero[k]->pos == aim)) {
                            nowV=min(nowHeHeroHp[k], U->atk-heHero[k]->def);
                            nowV=nowV*(1.0+(double)(nowV)/(double)(nowHeHeroHp[k]));
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 0, idealp = aim;
                }

                if (U->U->canUseSkill(7)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (check(U->pos, aim, heHero[k]->pos))) {
                            double tt=min(nowHeHeroHp[k], ((Archer*)U)->arrowHit);
                            tt=tt*(1.0+(double)(tt)/(double)(nowHeHeroHp[k]));
                            nowV=nowV+tt;
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 1, idealp = aim;
                }
            }
            if ((i*i+j*j<=100) && checkPos(U->pos+Pos(i,j))) {
                if (U->U->canUseSkill(9)) {
                    nowV=0.0;
                    for (int k=0; k<heHeroKnown; k++)
                        if ((Yelled == k) || (Yelled == -1))
                        if (heHeroInsight[k] && (dis2(heHero[k]->pos, aim)<=25)
                            && !nowHeRainy[k]) {
                            double myoriginHit = ((Archer*)U)->rainHit;
                            if (heHero[k]->name == "Archer")
                                myoriginHit*=(2.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            if (heHero[k]->name == "Assassin") {
                                if (heHero[k]->U->canUseSkill(17))
                                    myoriginHit*=(2.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                                else
                                    myoriginHit*=(3.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            }
                            if (heHero[k]->name == "Fighter")
                                myoriginHit*=(3.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                            double tt=min((double)nowHeHeroHp[k], myoriginHit);
                            tt=tt*(1.0+(double)(tt)/(double)(nowHeHeroHp[k]));
                            nowV=nowV+tt;
                        }
                    if (nowV>maxV+1e-6)
                        maxV = nowV, KK = 2, idealp = aim;
                }
            }
        }
    CCout<<"\n maxV:"<<maxV<<"\n";
    if (KK == 0) {
        for (int k=0; k<heHeroKnown; k++)
            if ((Yelled == k) || (Yelled == -1))
            if (heHeroInsight[k] && (heHero[k]->pos == aim)) {
                nowHeHeroHp[k]-=(U->atk-heHero[k]->def);
            }
        normalOperationGen("Attack", U->id, idealp);
    }
    if (KK == 1) {
        for (int k=0; k<heHeroKnown; k++)
            if ((Yelled == k) || (Yelled == -1))
            if (heHeroInsight[k] && (check(U->pos, aim, heHero[k]->pos))) {
                nowHeHeroHp[k]-=(((Archer*)U)->arrowHit);
            }
        normalOperationGen("PiercingArrow", U->id, idealp);
    }
    if (KK == 2) {
        for (int k=0; k<heHeroKnown; k++)
            if ((Yelled == k) || (Yelled == -1))
            if (heHeroInsight[k] && (dis2(heHero[k]->pos, aim)<=25)
                && !nowHeRainy[k]) {
                nowHeRainy[k] = 1;
                double myoriginHit = ((Archer*)U)->rainHit;
                if (heHero[k]->name == "Archer")
                    myoriginHit*=(2.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                if (heHero[k]->name == "Assassin") {
                    if (heHero[k]->U->canUseSkill(17))
                        myoriginHit*=(2.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                    else
                        myoriginHit*=(3.0-((double)(dis2(heHero[k]->pos, aim))/25.0));
                }
                if (heHero[k]->name == "Fighter")
                    myoriginHit*=(3.5-((double)(dis2(heHero[k]->pos, aim))/25.0));
                nowHeHeroHp[k]-=myoriginHit;
            }
        normalOperationGen("ArrowsRain", U->id, idealp);
    }
    if (KK == -1) return 0; else return 1;
}

void yq::togetherArcherStrategy::work() {
    if (U->avoidDeath()) return;

    if ((*(U->U))["Exp"]->val[3]) {
        if (U->U->canUseSkill(MyHero::skillKind[U->No][U->level])) {
            normalOperationGen(Skill_name[MyHero::skillKind[U->No][U->level]],U->id);
            return;
        }
    }

    U->findRoad();

    int mindis=100000; Pos ideal = Pos();

    for (int i=0; i<Map_size; i++)
    for (int j=0; j<Map_size; j++) {
        bool able = 1;
        for (int k=0; k<5; k++)
            if (global::S2.incontrol[k] &&(myHero[k]->road.step[i][j] == -1))
                able = 0;
        if (Bound.bound[i][j]) able = 0;
        if (dis2(Pos(i, j), aim)<500) able = 0;
        bool NearMyT = 0;
        for (int k=0; k<2; k++)
            if (!myTowerDead[k] && (dis2(Pos(i,j), myTower[k]->pos)<=1000))
                NearMyT = 1;
        if (!NearMyT) able = 0;
        //�ܽ^Ұ��
        for (int ii=0; ii<6; ii++)
            for (int jj=0; jj<8; jj++)
                if (dis2(Pos(i,j), WildList::wildpos[ii][jj])<=10)
                    able = 0;
        if (able) {
            int nowmax = 0;
            for (int k=0; k<5; k++)
                if (global::S2.incontrol[k] && (myHero[k]->road.step[i][j]>nowmax))
                    nowmax=myHero[k]->road.step[i][j];
            nowmax+=dis(Pos(i, j), aim);
            if (nowmax<mindis)
                mindis = nowmax, ideal = Pos(i, j);
        }
    }

    U->Move(ideal);
}

void yq::moveArcherStrategy::work() {
    U->Move(aim);
}

bool yq::MyHero::avoidDeath(Pos checkaim) {
    if (!checkDeath(pos)) return 0;
    if (checkDeath(checkaim)) checkaim = Pos();
    if (checkaim == Pos()) checkaim = pos;
    Pos nearSafe; int nearDis=1000000, aimdis=1000000;
    for (int i=-12; i<=12; i++)
        for (int j=-12; j<=12; j++)
            if (checkPos(pos+Pos(i,j)) && !checkDeath(pos+Pos(i,j)))
                if (((i*i+j*j)/speed<nearDis) ||
                    (((i*i+j*j)/speed==nearDis) && (dis2(pos+Pos(i,j), checkaim)<aimdis)))
                    nearSafe=pos+Pos(i,j), nearDis=(i*i+j*j)/speed,
                    aimdis=dis2(pos+Pos(i,j), checkaim);
    LLog<<id<<" Nearsafe:  "<<nearSafe.x<<" "<<nearSafe.y<<"\n";
    if ((!U->canMove()) || (nearDis==1000000))
        return 0;
    else {
        occupy[pos.x][pos.y]--, occupy[nearSafe.x][nearSafe.y]++;
        Bound.bound[pos.x][pos.y]--, Bound.bound[nearSafe.x][nearSafe.y]++;
        Move(nearSafe);
        pos = nearSafe;
        return 1;
    }
}

bool yq::MyHero::avoidDDeath(Pos checkaim) {
    if (!checkDDeath(pos)) return 0;
    if (checkDDeath(checkaim)) checkaim = Pos();
    if (checkaim == Pos()) checkaim = pos;
    Pos nearSafe; int nearDis=1000000, aimdis=1000000;
    for (int i=-12; i<=12; i++)
        for (int j=-12; j<=12; j++)
            if (checkPos(pos+Pos(i,j)) && !checkDDeath(pos+Pos(i,j)))
                 if (((i*i+j*j)/speed<nearDis) ||
                    (((i*i+j*j)/speed==nearDis) && (dis2(pos+Pos(i,j), checkaim)<aimdis)))
                    nearSafe=pos+Pos(i,j), nearDis=(i*i+j*j)/speed,
                    aimdis=dis2(pos+Pos(i,j), checkaim);
    LLog<<id<<" Nearsafe:  "<<nearSafe.x<<" "<<nearSafe.y<<"\n";
    if ((!U->canMove()) || (nearDis==1000000))
        return 0;
    else {
        occupy[pos.x][pos.y]--, occupy[nearSafe.x][nearSafe.y]++;
        Bound.bound[pos.x][pos.y]--, Bound.bound[nearSafe.x][nearSafe.y]++;
        Move(nearSafe);
        pos = nearSafe;
        return 1;
    }
}

void yq::global::chooseHero() {
    vector<const PUnit *> Myunitset;
    Info->findUnitByPlayer(Info->player, Myunitset);
    int tot_selected = 0;
    for (int i = 0; i < Myunitset.size(); i++) {
        if (stringcmp(Myunitset[i]->name, "Chooser")) {
            ++tot_selected;
            switch (tot_selected) {
                case 1:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 2:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 3:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 4:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 5:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
            }
        }
    }
    memset(myHero, 0, sizeof(myHero));
    memset(myTower, 0, sizeof(myTower));
    memset(heHero, 0, sizeof(heHero));
    memset(heTower, 0, sizeof(heTower));
    mySpring = heSpring = 0;
    memset(wild, 0, sizeof(wild));
}

void yq::BoundMap::setBound(const Pos &center, int radius2) {
    for (int i = center.x - sqrt(radius2); i <= center.x + sqrt(radius2); i++) {
        if ((i < 0) || (i >= Map_size)) continue;
        for (int j = center.y - sqrt(radius2 - (center.x - i) * (center.x - i)); j <= center.y + sqrt(radius2 - (center.x - i) * (center.x - i)); j++) {
            if ((j < 0) || (j >= Map_size)) continue;
            bound[i][j] += 1;
        }
    }
}

Pos yq::WildList::findNo(Pos nowp) {
    Pos No = Pos();
    for (int i=0; i<6; i++)
        for (int j=0; j<8; j++)
            if (wildpos[i][j] == nowp)
                No = Pos(i, j);
    return No;
}

double yq::Tower::TowerEvaluate() {
    double X = 0.0;
    bool existEnemy = 0;
    for (int i = 0; i < heHeroKnown; i++)
        if ((heHeroInsight[i]) && (dis2(pos, heHero[i]->pos) <= ViewRange)) {
            existEnemy = 1;
            Unit *Now = heHero[i];
            if (dis2(pos, Now->pos) <= range)
                X = X + (double)((Now->level + 1) * (Now->hp));
            else
                X = X + (double)((Now->level + 1) * (Now->hp)) / 2;
        }
    X = X + (1.0 - hprate) * 3000.0;
    if (existEnemy) silencetime = 0;
    else
        if (!evaluated) silencetime++;
    if (silencetime >= 5) X = min(X, 150.0);
    evaluated = 1;
    return X;
}

//------------------------���ߺ���ʵ����------------------
void yq::normalOperationGen(const string &type, const int &id, const Pos _pos) {
    Operation nowop;
    nowop.type = type;
    nowop.id = id;
    LLog<<nowop.type<<" "<<nowop.id;
    if ((type == "Attack") || (type == "Charge") || (type == "PiercingArrow") ||
            (type == "ArrowsRain") || (type == "FlyingBlade") || (type == "Blink"))
        nowop.targets.push_back(_pos), LLog<<" "<<_pos.x<<" "<<_pos.y;
    LLog<<"\n";
    Cmd->cmds.push_back(nowop);
}

bool yq::stringcmp(const char _a[], const char _b[]) {
    return (strcmp(_a, _b) == 0);
}

bool yq::check(Pos a, Pos b, Pos c) {
//a�Ǽ������λ�ã�b�Ǽ������λ�ã��ж�λ��c�Ƿ���ܲ���int
    double S = abs(crossProduct(c, a, b));
    int lab = dis2(a, b);
    int lac = dis2(a, c);
    int lbc = dis2(b, c);
    if (sqrt(lab) * 1.5f <= double(S))
        return false;
    if ((lac > lab + lbc) || (lbc > lab + lac))
        return false;
    return true;
}

int yq::getHeight(Pos a) {
    return Map->height[a.x][a.y];
}

bool yq::checkDeath(Pos Now) {
    for (int i=0; i<2; i++)
        if (!heTowerDead[i] && (dis2(Now, heTowerPos[i])<=100))
            return 1;
    for (int i=0; i<Info->areas.size(); i++)
        if ((Info->areas[i].camp==1-nowPlayer)&&
            (dis2(Now,Info->areas[i].center)<=25))
            return 1;
    for (int i=0; i<Info->flights.size(); i++)
        if (Info->flights[i].camp==1-nowPlayer) {
            if (Info->flights[i].typeId==0)
                if (check(Info->flights[i].pos, Info->flights[i].target, Now))
                    return 1;
            if (Info->flights[i].typeId==1)
                if (dis2(Now,Info->flights[i].target)<=25)
                    return 1;
        }
    return 0;
}

bool yq::checkDDeath(Pos Now) {
    for (int i=0; i<Info->areas.size(); i++)
        if ((Info->areas[i].camp==1-nowPlayer)&&
            (dis2(Now,Info->areas[i].center)<=25))
            return 1;
    for (int i=0; i<Info->flights.size(); i++)
        if (Info->flights[i].camp==1-nowPlayer) {
            if (Info->flights[i].typeId==0)
                if (check(Info->flights[i].pos, Info->flights[i].target, Now))
                    return 1;
            if (Info->flights[i].typeId==1)
                if (dis2(Now,Info->flights[i].target)<=25)
                    return 1;
        }
    return 0;
}

void yq::setOccupy(const Pos &center, int radius2) {
    for (int i = center.x - sqrt(radius2); i <= center.x + sqrt(radius2); i++) {
        if ((i < 0) || (i >= Map_size)) continue;
        for (int j = center.y - sqrt(radius2 - (center.x - i) * (center.x - i)); j <= center.y + sqrt(radius2 - (center.x - i) * (center.x - i)); j++) {
            if ((j < 0) || (j >= Map_size)) continue;
            occupy[i][j] += 1;
        }
    }
}

void yq::moveIdeal(int myrange, Pos mypos, int herange, Pos hepos, MyHero *my) {
    if ((herange>10) || (myrange<=10)) {
        my->Move(hepos);
        return;
    }
    int mindis=1000000;
    Pos ideal;
    for (int i=-5; i<=5; i++)
        for (int j=-5; j<=5; j++)
            if (checkPos(mypos+Pos(i,j)) && (i*i+j*j<=myrange) && !checkDeath(mypos+Pos(i,j)))
                if ((dis2(mypos+Pos(i,j),hepos)>herange) &&
                    (i*i+j*j<mindis))
                    mindis=i*i+j*j, ideal=mypos+Pos(i,j);
    if (mindis!=1000000) my->Move(ideal); else my->Move(hepos);
}

void yq::leadMyTower(int myrange, Pos mypos, int herange, Pos hepos, MyHero *my, Pos dest) {
    int mindis=1000000;
    Pos ideal;
    for (int i=-5; i<=5; i++)
        for (int j=-5; j<=5; j++)
            if (checkPos(mypos+Pos(i,j)) && (i*i+j*j<=myrange))
                if ((dis2(mypos+Pos(i,j),hepos)<=myrange) &&
                    (dis2(mypos+Pos(i,j),dest)<mindis))
                    mindis=dis2(mypos+Pos(i,j),dest), ideal=mypos+Pos(i,j);
    if (mindis!=1000000) my->Move(ideal);
}

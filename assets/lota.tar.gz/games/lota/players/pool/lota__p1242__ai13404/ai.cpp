#include "sdk.h"
#include<ctime>

typedef vector<const PUnit*> PUnits;
PUnits nitre_ours;

const PMap* nitre_MAP;
const PPlayerInfo* nitre_INFO;

void nitre_chooseHero(const PPlayerInfo &info, PCommand &cmd) //��0�غ�ѡ��Ӣ��
{
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
        int r=rand()%3;
        if(r==0)
            op.type="ChooseAssassin";
        else if(r==1)
            op.type="ChooseFighter";
        else if(r==2)
            op.type="ChooseArcher";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op); //���ѡ��ְҵ
    }
}


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(0)); //������ش�
    cmd.cmds.clear();
    nitre_MAP = &map;
    if (info.round == 0)
    {
        nitre_chooseHero(info, cmd); //��0�غ�ѡ��Ӣ��
    } else //��ʽ�غ�
    {
        info.findUnitByPlayer(info.player, nitre_ours); //Ѱ�����б�����λ
        const PUnit* ptr = nitre_ours[3];
		Operation op;
		op.id = ptr->id;
		op.type = "Move";
		findShortestPath(*nitre_MAP, ptr->pos, Player1_spring_pos[0], op.targets);
		cmd.cmds.push_back(op);	
    }
}

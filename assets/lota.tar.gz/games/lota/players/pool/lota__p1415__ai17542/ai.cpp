#include "sdk.h"
#include<ctime>

const Pos EMPTYPOS = Pos(), DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 6, MAXLEVEL = 10, MAXID = 100;
int flag = 0;

static int fixId[MAXID];
static Pos fixPos[MAXID];
static bool towerDes[2];
typedef vector<const PUnit*> PUnits;
PUnits ours, others, nearBy, AddBlocks;
static vector<Pos> blocks, blocks2;

const PMap* MAP;
const PPlayerInfo* INFO;
const Pos* Atktower;
const Pos* tower;

/* =====================================  整合类:MonsterInfo(最新版) ===========================================*/

/*
功能：
将我方英雄分为两波，分别针对两个怪物的坐标列表进行循环攻击
player0:         39<=id<=41 刷离家近的塔1，    42<=id<=43	刷离家近的塔2
player1:         44<=id<=46 刷离家近的塔1，    47<=id<=48	刷离家近的塔2
其中：怪物名称列表(供参考)
const string Player0monsterList1[] = {"Bow", "Dog", "Wolf"};					//玩家0的野怪列表1（塔1附近）
const string Player1monsterList1[] = {"Bow", "Dog", "Wolf"};					//玩家1的野怪列表（塔1附近）
const string Player0monsterList2[] = {"Wolf", "Dog", "Dog"};					//玩家0的野怪列表（塔2附近)
const string Player1monsterList2[] = {"Wolf"," Dog", "Dog"};					//玩家1的野怪列表(塔2附近）
*/
/*建议：定义一个全局MonsterInfo 对象(MonsterInfo monsterInfo).
改变之前的InitPos为：
monsterInfo.initPos();
monsterInfo.initFlag();（参数自行查看MonsterInfo类）
将LoopFight,isToTransform分别用类函数覆盖
PS1:CounterAttack_LoopFight函数同时进行覆盖
PS2:LoopFight改名为LoopMove(更合适一点)
*/

std::vector<const PUnit*> EnemyUnit, Units;		//时刻准备获取了敌人列表
std::vector<const PUnit*> CheckLevels, Check, TogetherTeam, HideAssassin;
std::vector<const PUnit*> CheckEnemy, Enemy;	//寻找塔0下敌人坐标（可复用）
std::vector<Pos> MonsterPos;				//初始怪物位置
std::vector<Pos> Symbols;					//带定位的寻路
#define MAXDISTANCE 9999
//LOGIC为逻辑攻击指标，依据以下宏定义说明
int Logic = 2;
#define		 FightDragon		0
#define		 AttackTower		1
#define		 LoopMonster		2
#define		 AtkToWinner		3
#define		 Artificial			4
bool isTowerDes = false;
//EndDefine
bool LocateFlag[2][3];						//定位英雄下一个移动方位
void InitPos(const PPlayerInfo &info, std::vector<Pos> &_monsterPos);					//返回循环怪物坐标列表的引用以及初始化英雄移动指针(放在round == 0处）
void CounterAttack_LoopDenfence(const PPlayerInfo &info, Operation &op, const PUnit &t);		////联合守塔&&循环打怪（主函数）
const string Player0monsterList1[] = {"Bow", "Dog", "Wolf"};					//玩家0的野怪列表1（塔1附近）
const string Player1monsterList1[] = {"Bow", "Dog", "Wolf"};					//玩家1的野怪列表（塔1附近）
const string Player0monsterList2[] = {"Wolf", "Dog", "Dog"};					//玩家0的野怪列表（塔2附近)
const string Player1monsterList2[] = {"Wolf"," Dog", "Dog"};					//玩家1的野怪列表(塔2附近）

void fighting(const PUnit* a, const PUnit* b, PCommand &cmd);

bool in_attack_range(const PUnit &t, const Pos& tar)
{
    return dis2(t.pos, tar) <= t.range;
}

void levelUp(const PUnit* a, PCommand &cmd) //单位a升级操作
{
		 vector<string> level_ups;
		if(a->name == string("Assassin"))
		{
			if(a->level == 0 || a->level == 1 || a->level == 2 )
			{				
					const PSkill* ptr= a->findSkill("HideLU");
					level_ups.push_back(ptr->name);				
			}			
			else if(a->level == 3 || a->level == 4)
			{
					const PSkill* ptr= a->findSkill("FBLU");
					level_ups.push_back(ptr->name);				
			}
			else
			{				
				level_ups.push_back("YellowPoint");
				for (int i = 0; i < a->skills.size(); ++i)
				{
					const PSkill* ptr = &a->skills[i];
					if (ptr->isLU() && a->canUseSkill(ptr->typeId)) //选择可以升级的技能
						level_ups.push_back(ptr->name);
				}
			}
		}
    Operation op;
    op.id = a->id;
    op.type = level_ups[rand() % level_ups.size()]; //随机升级技能
    cmd.cmds.push_back(op);
}

void addBlocks(const PPlayerInfo &info, const PUnit *ptr, std::vector<Pos> &blocks)
{
	//增加BLOCKS,且随时更新
	info.findUnitInArea(ptr->pos, ptr->view, AddBlocks);
	blocks2.clear();
	for(int i = 0; i < AddBlocks.size(); i++)
	{
		blocks2.push_back(AddBlocks[i]->pos);
	}

	for ( int i = 0; i < blocks.size(); i++)
	{
		blocks2.push_back(blocks[i]);
	}
}

class MonsterInfo
{
public:	
	bool LocateFlag[2][3];				//循环定位数组【二维二分刷怪】
	Pos MonsterList[2][3];			//怪物坐标列表[二分列表]

	//返回_monsterPos的怪物列表
	void initPos(const PPlayerInfo &info, std::vector<Pos> &_monsterPos)
	{
		//第一组
		_monsterPos.push_back(info.player ? Bow_pos[5] : Bow_pos[2]);		
		_monsterPos.push_back(info.player ? Dog_pos[2] : Dog_pos[6]);
		_monsterPos.push_back(info.player ? Wolf_pos[1]: Wolf_pos[3]);
		//第二组
		_monsterPos.push_back(info.player ? Wolf_pos[0]: Wolf_pos[2]);		
		_monsterPos.push_back(info.player ? Dog_pos[3] : Dog_pos[7]);
		_monsterPos.push_back(info.player ? Dog_pos[1] : Dog_pos[5]);

		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				this->MonsterList[i][j] = _monsterPos[3*i+j];
			}
		}
	}

	//初始化定位
	void initFlag(bool LocateFlag[2][3])
	{
		//第一组野怪
		LocateFlag[0][0] = true;
		LocateFlag[0][1] = LocateFlag[0][2] = false;

		//第二组野怪
		LocateFlag[1][0] = true;
		LocateFlag[1][1] = LocateFlag[1][2] = false;

		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				this->LocateFlag[i][j] = LocateFlag[i][j];
			}
		}
	}

	//更变怪物定位
	void isToTransform(const PPlayerInfo &info, const PUnit &t)
	{
		int record[2];
		bool tempRec;
		for (int i = 0; i < 3; i++)
		{
			////可以自行修改英雄分拨分配,通过名字或者id分拨 （必须是分成两波)
			if ( (t.id >= 39 && t.id <= 41) || (t.id >= 44 && t.id <= 46) )
			{
				if (LocateFlag[0][i])
				{
					record[0] = i;
				}
			}
			////可以自行修改英雄分拨分配,通过名字或者id分拨 （必须是分成两波)
			if ( ( t.id >= 42 && t.id <= 43) || (t.id >= 47 && t.id <= 48))
			{
				if (LocateFlag[1][i])
				{
					record[1] = i;			//获取怪物指针
				}
			}
		}

		if (info.player)
		{
			for ( int i = 0; i < info.units.size(); i++)
			{
				const PUnit *ptr = &info.units[i];
				if ( (t.id >= 42 && t.id <= 43) || (t.id >= 47 && t.id <= 48))
				{
					if ( ptr->name == Player1monsterList2[record[1]] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[3+record[1]]))
					{
						tempRec = LocateFlag[1][2];
						LocateFlag[1][2] = LocateFlag[1][1];
						LocateFlag[1][1] = LocateFlag[1][0];
						LocateFlag[1][0] = tempRec;
					}
				}

				else
				{
					if ( ptr->name == Player1monsterList1[record[0]] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[record[0]]))
					{
						tempRec = LocateFlag[0][2];
						LocateFlag[0][2] = LocateFlag[0][1];
						LocateFlag[0][1] = LocateFlag[0][0];
						LocateFlag[0][0] = tempRec;
					}
				}
			}
		}
		else
		{
			for ( int i = 0; i < info.units.size(); i++)
			{
				const PUnit *ptr = &info.units[i];
				if ( (t.id >= 42 && t.id <= 43) || (t.id >= 47 && t.id <= 48))
				{
					if ( ptr->name == Player0monsterList2[record[1]] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[3+record[1]]))
					{
						tempRec = LocateFlag[1][2];
						LocateFlag[1][2] = LocateFlag[1][1];
						LocateFlag[1][1] = LocateFlag[1][0];
						LocateFlag[1][0] = tempRec;
					}
				}
				else
				{
					if ( ptr->name == Player0monsterList1[record[0]] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[record[0]]))
					{
						tempRec = LocateFlag[0][2];
						LocateFlag[0][2] = LocateFlag[0][1];
						LocateFlag[0][1] = LocateFlag[0][0];
						LocateFlag[0][0] = tempRec;
					}
				}
			}
		}
	}

	void LoopMove(Operation &op, const PUnit &t, PCommand &cmd)
	{
		addBlocks(*INFO, &t, blocks);				//防止卡位
		if (t["Exp"]->val[3]) //优先升级技能
		{
			levelUp(&t, cmd);
		} 
		else
		{
			for (int i = 0; i < 3; i++)
			{
				if (t.id >= 39 && t.id <= 40 || (t.id >= 45 && t.id <= 46))
				{
					if (LocateFlag[0][i])
					{
						findShortestPath(*MAP, t.pos, MonsterPos[i], blocks2, op.targets);
						op.type = "Move";
						op.id = t.id;
						cmd.cmds.push_back(op);
					}
				}
				else
				{
					if (LocateFlag[1][i])
					{
						findShortestPath(*MAP, t.pos, MonsterPos[3+i], blocks2, op.targets);
						op.type = "Move";
						op.id = t.id;
						cmd.cmds.push_back(op);
					}
				}
			}
		}
	}

	//五个英雄全部集中在塔1上的循环刷怪(建议后期使用)
	void DefenseAroundTower(const PPlayerInfo &info, const PUnit &t)
	{
		int record;
		bool tempRec;
		for (int i = 0; i < 3; i++)
		{
			if (LocateFlag[0][i])
			{
				record = i;			
			}
		}

		if (info.player)
		{
			for ( int i = 0; i < info.units.size(); i++)
			{
				const PUnit *ptr = &info.units[i];							
				if ( ptr->name == Player1monsterList1[record] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[record]))
				{
					tempRec = LocateFlag[0][2];
					LocateFlag[0][2] = LocateFlag[0][1];
					LocateFlag[0][1] = LocateFlag[0][0];
					LocateFlag[0][0] = tempRec;
				}
				
			}
		}
		else
		{
			for ( int i = 0; i < info.units.size(); i++)
			{
				const PUnit *ptr = &info.units[i];		
				if ( ptr->name == Player0monsterList1[record] && ptr->findBuff("Reviving") && in_attack_range(t, MonsterPos[record]))
				{
					tempRec = LocateFlag[0][2];
					LocateFlag[0][2] = LocateFlag[0][1];
					LocateFlag[0][1] = LocateFlag[0][0];
					LocateFlag[0][0] = tempRec;
				}			
			}
		}
	}

	//针对DefenseAroundTower的移动方式（跟随DenfenseAroundTower共同使用)
	void DefenseMove(Operation &op, const PUnit &t, PCommand &cmd)
	{
		addBlocks(*INFO, &t, blocks);				//防止卡位
		if (t["Exp"]->val[3]) //优先升级技能
		{
			levelUp(&t, cmd);
		} 
		else
		{
			for (int i = 0; i < 3; i++)
			{			
				if (LocateFlag[0][i])
				{
					findShortestPath(*MAP, t.pos, MonsterPos[i], blocks2, op.targets);
					op.type = "Move";
					op.id = t.id;
					cmd.cmds.push_back(op);
				}		
			}
		}
	}

	//寻龙路线（第二次优化版）
	/*
		更新内容：
		当且仅当人数大于5人时进行攻击
	*/
	void AtkDragon(const PPlayerInfo &info, const PUnit &t, PCommand &cmd)
	{
		if (t["Exp"]->val[3]) //优先升级技能
		{
			levelUp(&t, cmd);
		} 
		else
		{
			Pos dragon = info.player ? Dragon_pos[1] : Dragon_pos[0];
			if ( !in_attack_range(t, dragon) )
			{
				Operation op;
				findShortestPath(*MAP, t.pos, dragon, blocks2, op.targets);
				op.type = "Move";
				op.id  = t.id;
				cmd.cmds.push_back(op);
			}
			else
			{
				const PUnit *monster;
				//找到龙的单位
				for ( int i = 0; i < info.units.size(); i++)
				{
					if ( info.units[i].name == string("Dragon") )
					{
						monster = &info.units[i];
						break;
					}
				}

				if (monster->findBuff("Reviving"))
				{
					Logic = AttackTower;
				}
				else
				{
					fighting(&t, monster, cmd);
				}
			}
		}
	}

	//推塔路线(更新内容:当且仅当人数大于5人时进行攻击)
	void AtkOneTower(const PPlayerInfo &info, const PUnit &t, PCommand &cmd)
	{
		//隐身路线参数
		static const char *skill = NULL;
		static bool setPlace = false;
		Pos Hiding(16,75);

		if (t["Exp"]->val[3]) //优先升级技能
		{
			levelUp(&t, cmd);
		} 
		else
		{
			Operation op;
			//如果塔1未被推掉
			if ( towerDes[1] == false )
			{
				//修改思路，先确定一个地点，在此地点选择隐身，然后再findShortestPath去打塔，避免被对方破除隐身！！
				//清除数组信息
				TogetherTeam.clear();
				Check.clear();
				//重新获得塔0处的相关信息参数,收集塔0附近的单位列表
				INFO->findUnitInArea(tower[0], 100, Check);
				for ( int i = 0 ; i < Check.size(); i++)
				{
					if ( Check[i]->camp == INFO->camp && 
							(Check[i]->name == string("Archer") || 
							 Check[i]->name == string("Fighter") ||
							 Check[i]->name == string("Assassin")))
						{
							//收集我方英雄单位
							TogetherTeam.push_back(Check[i]);
						}
				}
				//如果英雄人数未凑齐
				if (TogetherTeam.size() != 5 && !setPlace)
				{
					op.type = "Move";
					op.id  = t.id;
					findShortestPath(*MAP, t.pos, tower[0], blocks2, op.targets);
					cmd.cmds.push_back(op);
				}
				else
				{
					setPlace = true;
					//转移地点使用技能
					if (in_attack_range(t, Hiding))
					{
						HideAssassin.clear();
						INFO->findUnitInArea(t.pos, t.view, HideAssassin);
						for ( int i = 0; i < HideAssassin.size(); i++)
						{
							//获取我方列表
							if (HideAssassin[i]->player != info.player || HideAssassin[i]->findBuff("Reviving") ||
								HideAssassin[i]->name != string("Fighter") || HideAssassin[i]->name != string("Archer") ||
								HideAssassin[i]->name != string("Assassin") )
							{
								 HideAssassin.erase(HideAssassin.begin()+i);
								 --i;
							}
						}
						if(HideAssassin.size() == 5)
						{
							if (skill == NULL)
							{
								skill = "Hide";		//标记skill指针
								op.type = "Hide";
							}
							else
							{
								op.type = "Move";
								findShortestPath(*MAP, t.pos, Atktower[1], blocks2, op.targets);
							}
							op.id  = t.id;
							cmd.cmds.push_back(op);
						}
						else
						{
							//暂时看看效果,不然可以增进其他代码
							op.type = "Move";
							findShortestPath(*MAP, t.pos, Atktower[1], blocks2, op.targets);
							op.id  = t.id;
							cmd.cmds.push_back(op);
						}
					}
					else
					{
						op.type = "Move";
						op.id  = t.id;
						findShortestPath(*MAP, t.pos, Hiding, blocks2, op.targets);
						cmd.cmds.push_back(op);
					}
				}			
			}
			//退完塔继续循环刷怪
			else
			{
				Logic = LoopMonster;
			}
		}
	}

	//第二推塔路线（未更新)
	void AtkOneTower(const PPlayerInfo &info, const PUnit &t, PCommand &cmd, int another)
	{
		if (t["Exp"]->val[3]) //优先升级技能
		{
			levelUp(&t, cmd);
		} 
		else
		{
			if (!in_attack_range(t, Atktower[1]))
			{
				if ( towerDes[0] == false )
				{
					Operation op;
					op.type = "Move";
					op.id  = t.id;
					findShortestPath(*MAP, t.pos, Atktower[0], blocks2, op.targets);
					cmd.cmds.push_back(op);
				}
				else
				{
					Logic =  AttackTower;
				}
			}
		}
	}

	//守塔路线(改进is_Teamwork存在的BUG问题)
	void ProtectTower(const	PPlayerInfo &info, const PUnit &t, bool &is_TeamAttack, PCommand &cmd)
	{
		int hp = 9999;
		int recordUnit = 0;
		const PUnit*ptr = NULL;
		Operation op;
		canTransTeamAttack(info, t, is_TeamAttack);				//准备更改坐标路线（is_TeamAttack的引用）
		if (is_TeamAttack)
		{
			//清除坐标信息
			Units.clear();
			EnemyUnit.clear();
			info.findUnitInArea(t.pos, t.view, Units);
			if (Units.size())
			{
				for (int i = 0; i < Units.size(); i++)
				{
					if ( info.player != Units[i]->player && info.camp != Units[i]->camp && !Units[i]->findBuff("Reviving") &&
						(Units[i]->name == string("Fighter") || Units[i]->name == string("Archer") || Units[i]->name == string("Assassin")))
					{
						EnemyUnit.push_back(Units[i]);
					}
				}
				//如果列表内没有敌人,则继续寻路
				if (!EnemyUnit.size())
				{
					//如果没有英雄，则继续寻路
					op.type = "Move";
					op.id = t.id;
					findShortestPath(*MAP, t.pos, tower[0], blocks2, op.targets);
					cmd.cmds.push_back(op);
					return;
				}
			}

			for (int i = 0; i < EnemyUnit.size(); i++)
			{
				ptr = EnemyUnit[i];		//记录敌方英雄的指针
				if ( EnemyUnit[i]->hp < hp && !EnemyUnit[i]->findBuff("Reviving"))
				{
					//获取最小血量的敌方英雄坐标
					hp = EnemyUnit[i]->hp;
					recordUnit = i;
					ptr = EnemyUnit[i];		//记录敌方英雄的指针
				}
			}
			if (!in_attack_range(t, ptr->pos))
			{
				findShortestPath(*MAP, t.pos, ptr->pos, blocks2, op.targets);
				op.type = "Move";
				op.id = t.id;
				cmd.cmds.push_back(op);
			}
			else
			{
				fighting(&t, ptr, cmd);
			}
		}
	}

	//辅助函数,用于protectTower
	//主要用来修复is_TeamWork的判定问题
	void canTransTeamAttack(const PPlayerInfo &info, const PUnit &t, bool &is_TeamAttack )
	{
		CheckEnemy.clear();
		Enemy.clear();
		INFO->findUnitInArea(tower[0], 100, CheckEnemy);
		for ( int i = 0 ; i < CheckEnemy.size(); i++)
		{
			//获取敌人单位列表
			if ( CheckEnemy[i]->camp != INFO->camp && 
				CheckEnemy[i]->player != INFO->player &&
				(CheckEnemy[i]->name == string("Archer") || 
				CheckEnemy[i]->name == string("Fighter") ||
				CheckEnemy[i]->name == string("Assassin")))
				{
					Enemy.push_back(CheckEnemy[i]);
				}
		}
		//如果英雄人数未凑齐
		if (!Enemy.size())
		{
			is_TeamAttack = false;
		}
	}
};

MonsterInfo monsterInfo;			//全局对象monsterInfo

//联合守塔&&循环打怪（主函数）
//入口参数：info， op， 英雄的PUnit引用（可以改成英雄指针）
void CounterAttack_LoopDenfence(const PPlayerInfo &info, Operation &op, const PUnit &t, PCommand &cmd)
{
	bool is_TeamAttack = false;							//团战标志
	
	Pos defaultPos = info.player ?  Player1_tower_pos[0] : Player0_tower_pos[0];	//我方塔位置
	Pos nowPos = defaultPos;				//现在的位置
	int defaultDistance = MAXDISTANCE;

	//时刻获取塔视野范围内的敌人列表
	info.findUnitInArea(defaultPos, info.findUnitByPos(defaultPos)->view, Units);
	if (Units.size())
	{
		for (int i = 0; i < Units.size(); i++)
		{
			if ( info.player != Units[i]->player && info.camp != Units[i]->camp && !Units[i]->findBuff("Reviving") &&
				(Units[i]->name == string("Fighter") || Units[i]->name == string("Archer") || Units[i]->name == string("Assassin")))
			{
				EnemyUnit.push_back(Units[i]);
			}
		}
		//获取塔内敌人列表
		if (EnemyUnit.size())
		{
			is_TeamAttack = true;
			monsterInfo.canTransTeamAttack(info, t, is_TeamAttack);
		}
	}
	//如果塔附近没有敌人 
	if ( !is_TeamAttack )
	{
		//专门针对辣鱼块的打法
		if (t.level >= 6)
		{
			Logic = AttackTower;
		}

		if (t.level >= 8 && !towerDes[0])
		{
			Logic = AtkToWinner;
		}

		if (Logic == FightDragon)
		{
			monsterInfo.AtkDragon(*INFO, t, cmd);		
		}
		if (Logic == AttackTower)
		{
			monsterInfo.AtkOneTower(*INFO, t, cmd);	
		}
		if (Logic == LoopMonster)
		{
			if ( !isTowerDes )
			{			
				monsterInfo.LoopMove(op, t, cmd);	
			}
			else
			{
				monsterInfo.DefenseMove(op, t, cmd);
			}
		}
		if (Logic == AtkToWinner)
		{
			monsterInfo.AtkOneTower(*INFO, t, cmd, 0);
		}
	}
	//如果有人，那么团战
	else
	{
		bool dead = false;
		if (t.findBuff("Reviving"))
			dead = true;
		//如果英雄没死
		if (!dead)
		{
			monsterInfo.ProtectTower(*INFO, t, is_TeamAttack, cmd);
		}
		else
		{
			Operation op;
			op.type = "Stop";
			op.id  = t.id;
			cmd.cmds.push_back(op);
		}
	}
}

const PUnit* belongs(int id, PUnits& units) //找出unit组成的vector中包含指定id的unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

int unitEvaluation(string name) //评估一个单位的战斗力
{
    if (name == string("Dog") || name == string("Bow") || name == string("Wolf") || name == string("Tower") || name == string("Dragon"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //鼓励与敌方单位交战
        return 0;
    if ( name == string("StoneMan"))
        return 4;
    if ( name == string("Roshan"))
        return HIGHLEVEL;
    return MAXLEVEL;
}

void getFoes(vector<Pos> &atk_tar, int l, int u) //根据等级寻找地图中相应
{
    int t = unitEvaluation("Tower");
    if (l <= t && t <= u)
    {
        const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
        for (int i = 0; i < 2; ++i)
            if (!towerDes[i])
            {
                for (int j = 0; j < 5; ++j)
                    atk_tar.push_back(tower[i]); //加大推塔概率
            }
    }
    t = unitEvaluation("Dragon");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(Dragon_pos[i]);
        atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEvaluation("Wolf");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 4; ++i)
            atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEvaluation("Dog");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 6; ++i)
            atk_tar.push_back(Dog_pos[i]);
        for (int i = 0; i < 6; ++i)
            if (i % 3) //去除两个无法移动到达的野怪
                atk_tar.push_back(Bow_pos[i]);
    }
}

void findFoes(const PUnit* a, PCommand &cmd) //单位a寻找对手
{
    if ((*a)["Exp"]->val[3]) //优先升级技能
    {
        levelUp(a, cmd);
    } else
    {
        if (fixPos[a->id] == EMPTYPOS)
        {
            vector<Pos> atk_tar;
            atk_tar.clear();
            getFoes(atk_tar, a->level > HIGHLEVEL ? HIGHLEVEL : 0, a->level); //策略：达到一定强度开始攻击防御塔
            if (atk_tar.size()) //寻找固定点的弱小对手
            {
                fixPos[a->id] = atk_tar[rand()%atk_tar.size()]; //锁定目标
            } else
            {
                fixPos[a->id] = DEFAULFPOS;
            }
        }
        Operation op;
        op.id = a->id;
        op.type = "Move";
        findShortestPath(*MAP, a->pos, fixPos[a->id], blocks, op.targets); //向弱小对手移动
        cmd.cmds.push_back(op);
    }
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //第0回合选择英雄
{
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
        op.type="ChooseAssassin";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op); //随机选择职业
    }
}

void init() //一些参数初始化
{
    blocks.clear();
    getFoes(blocks, 0, MAXLEVEL);
    tower = INFO->camp ? Player1_tower_pos : Player0_tower_pos;
	Atktower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
    for (int i = 0; i < 2; ++i)
        blocks.push_back(tower[i]); //地图上固定点不可经过
	for (int i = 0; i < 8; i++)
		blocks.push_back(Dog_pos[i]);
	for (int i = 0; i < 6; i++)
		blocks.push_back(Bow_pos[i]);
	for (int i = 0; i < 4; i++)
		blocks.push_back(Wolf_pos[i]);

    memset(fixId, EMPTYID, sizeof fixId);
    towerDes[0] = towerDes[1] = false;
    for (int i = 0; i < MAXID; ++i) fixPos[i] = EMPTYPOS;
	monsterInfo.initPos(*INFO, MonsterPos);
	monsterInfo.initFlag(LocateFlag);

	Symbols.push_back(INFO->player ? Bow_pos[5]  : Bow_pos[2]);
	Symbols.push_back(INFO->player ? Dog_pos[7]  : Dog_pos[3]);
	Symbols.push_back(INFO->player ? Wolf_pos[2] : Wolf_pos[0]);
	Symbols.push_back(INFO->player ? Dog_pos[5]  : Dog_pos[1]);
}

void fighting(const PUnit* a, const PUnit* b, PCommand &cmd) //单位a对单位b发起进攻
{
    Operation op;
    op.id = a->id;
    vector<const PSkill*> useSkill;
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //寻找可用技能
            if (belongs(b->id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }
    if (useSkill.size()) //策略：优先使用技能
    {
		//打狗不需要技能39,40 45 46
		if (((!strcmp(b->name,"Tower") || !strcmp(b->name,"Dragon") || !strcmp(b->name,"Fighter") || 
			!strcmp(b->name,"Archer") || !strcmp(b->name,"Assassin")	||
			!strcmp(b->name, "Wolf") || !strcmp(b->name, "Roshan") || !strcmp(b->name, "Bow")) && a->level <= 4)  || 
			((!strcmp(b->name,"Tower") || !strcmp(b->name,"Dragon") || !strcmp(b->name,"Fighter") || 
			!strcmp(b->name,"Archer") || !strcmp(b->name,"Assassin") ||
		    !strcmp(b->name, "Roshan")) && a->level > 4 ))  
		{
			const PSkill* ptr = useSkill[rand()%useSkill.size()];
			op.type = ptr->name;
			if (ptr->needTarget())
				op.targets.push_back(b->pos);
		}
		else
		{
			if (dis2(a->pos, b->pos) <= a->range) //判断单位b是否在攻击范围内
			{
				op.type = "Attack";
				op.targets.push_back(b->pos);
			} 
			else
			{
				op.type = "Move";
				findShortestPath(*MAP, a->pos, b->pos, blocks2, op.targets);
			}
		}
    } 
	else
	{
        if (dis2(a->pos, b->pos) <= a->range) //判断单位b是否在攻击范围内
        {
            op.type = "Attack";
            op.targets.push_back(b->pos);
        } 
		else
        {
            op.type = "Move";
            findShortestPath(*MAP, a->pos, b->pos, blocks2, op.targets);
        }
	}
    cmd.cmds.push_back(op);
}

void fightAlone(const PUnit* ptr, const PPlayerInfo &info, PCommand &cmd)
{
	//判断循环打怪方式
	if ( !isTowerDes)
	{
		monsterInfo.isToTransform(*INFO, *ptr);
	}
	else
	{
		monsterInfo.DefenseAroundTower(*INFO, *ptr);
	}
    info.findUnitInArea(ptr->pos, ptr->view, nearBy); //寻找附近的人
    fixPos[ptr->id] = EMPTYPOS;
    for (int i = 0; i < nearBy.size(); ++i)
    {
        if (unitEvaluation(nearBy[i]->name) > ptr->level ||
                nearBy[i]->camp == ptr->camp ||
                nearBy[i]->pos == Bow_pos[0] || nearBy[i]->pos == Bow_pos[3] ||
                nearBy[i]->findBuff("Reviving"))
            //删除等级过高的人，忽略友军，剔除复活者，删除不可到达的野怪
        {
            nearBy.erase(nearBy.begin()+i);
            --i;
        }
    }
    if (nearBy.size()) //策略：若周边有弱小对手则进行攻击
    {
        const PUnit* ptr_foe = fixId[ptr->id]!=EMPTYID ?
                    belongs(fixId[ptr->id], nearBy) : NULL; //判断之前是否锁定过目标
        if (!ptr_foe)
        {
            ptr_foe = nearBy[rand()%nearBy.size()];
            fixId[ptr->id] = ptr_foe->id; //若之前未锁定过目标，随机选定目标
        }
        fighting(ptr, ptr_foe, cmd); //与目标打斗
    } 
	else
    {
		Operation op;
        //monsterInfo.DefenseMove(op, *ptr, cmd);
		CounterAttack_LoopDenfence(*INFO, op, *ptr, cmd);
    }
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(0)); //随机开关打开
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    if (info.round == 0)
    {
        chooseHero(info, cmd); //第0回合选择英雄
        init(); //一些参数初始化
    } 
	else //正式回合
    {
		//如果外塔被摧毁，则改变循环怪物打法）
		if ( !info.findUnitByPos(tower[1]) )
		{
			isTowerDes = true;
		}
        info.findUnitByPlayer(info.player, ours); //寻找所有本方单位
        for (int i=0; i<ours.size(); ++i) //所有己方单位
        {
            const PUnit* ptr = ours[i];
			addBlocks(*INFO, ptr, blocks);				//防止卡位
            if (ptr->isHero()) //ptr是一个英雄，不和队友配合，单独作战
            {
                //const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
                for (int i = 0; i < 2; ++i)
                    if (dis2(ptr->pos, Atktower[i]) < 100 && !info.findUnitByPos(Atktower[i]))
                        towerDes[i] = true; //去除已摧毁防御塔
                fightAlone(ptr, info, cmd);
            }
        }
    }
}

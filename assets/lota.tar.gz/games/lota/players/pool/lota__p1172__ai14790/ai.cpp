#include "sdk.h"
#include<ctime>
#include<bits/stdc++.h>
#include<cassert>
int player;
PMap Map;
PPlayerInfo Info;
Pos Rpos;
int lost0;
int retreat[23333];
vector<Pos>Blocks;
typedef vector<const PUnit*> PUnits;
int Px[6]={5,54,96,145,92,58};
int Py[6]={5,75,75,145,116,34};
double per=0.5;	
double drand(){
	return rand()/double(RAND_MAX);
}
bool rand01(double p){
	return drand()<p;
}
pair<int,int> RandPs(double p=0.5){
	if(p<0.1&&rand01(0.5)){
		if(!player)return make_pair(Px[4],Py[4]);
		return make_pair(Px[5],Py[5]);
	}
	if(rand01(p)){
		if(player)return make_pair(Px[0],Py[0]);
		return make_pair(Px[3],Py[3]);
	}else{
		if(player)return make_pair(Px[1],Py[1]);
		return make_pair(Px[2],Py[2]);		
	}
}
void init(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
	pair<int,int> pp=RandPs(0.00);
	Rpos.x=pp.first;
	Rpos.y=pp.second;
	int cur=0;
	for(int i=0;i<info.units.size();i++)if(info.units[i].player==player){
		Operation op;
		op.id=info.units[i].id;
		op.type=cur++<2?"ChooseFighter":"ChooseArcher";
		op.targets.clear();
		cmd.cmds.push_back(op);
	}
}
bool in_attack_range(const PUnit &t, const Pos& tar){return dis2(t.pos, tar) <= t.range;}
vector<PUnit> ours,enemy,other,notme;
void findUnitByPlayer(const PPlayerInfo &info,int player,vector<PUnit>&vec){
	vec.clear();
	for(int i=0;i<info.units.size();i++)if(info.units[i].player==player)
		vec.push_back(info.units[i]);
}
int danger(string name){
    if (name == string("Tower") || name == string("Dog") || name == string("Bow"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //������з���λ��ս
        return -30-(name == string("Archer")?20:0);
    if (name == string("Wolf") || name == string("StoneMan"))
        return 40;
    if ( name == string("Dragon") || name == string("Roshan"))
        return 60;
    return 80;
}
void levelup(PUnit a,const PPlayerInfo info,PCommand &cmd) //��λa��������
{
    vector<string> level_ups; 
    if(rand01(0.5))
	    for (int i = (int)a.skills.size()-1; i >=0; i--)
	    {
	        const PSkill* ptr = &a.skills[i];
	        if (ptr->isLU() && a.canUseSkill(ptr->typeId)) //ѡ����������ļ���
	            level_ups.push_back(ptr->name);
	    }
    else level_ups.push_back("YellowPoint");
    Operation op;
    op.id = a.id;
    op.type = level_ups.front(); //�����������
    cmd.cmds.push_back(op);
}
int Push=0,unite=1;
int Dis[23333];
bool cmp(PUnit a,PUnit b){
	return Dis[a.id]<Dis[b.id];
}
Pos findEnemy(PUnit a,const PPlayerInfo &info){
	if(0){
//		cerr<<"ok in findEnemy"<<endl;
		if(player==0){
			if(lost0)
				return Player1_tower_pos[0];
			else return Player1_tower_pos[1];
		}else{
			if(lost0)
				return Player0_tower_pos[0];
			else return Player0_tower_pos[1];
		}
	}else{
		for(int i=0;i<notme.size();i++){
			PUnit b=notme[i];
			Dis[b.id]=danger(b.name)+(int)dis(a.pos,b.pos)+100*(b["Hp"]->val[0]/double(b["Hp"]->val[1]));
		}
		sort(notme.begin(),notme.end(),cmp);
		return notme[0].pos;
	}
}
const PUnit* belongs(int id, PUnits& units) //�ҳ�unit��ɵ�vector�а���ָ��id��unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}
void fighting(const PUnit* a, const PUnit* b, PCommand &cmd) //��λa�Ե�λb�������
{
    Operation op;
    op.id = a->id;

    vector<const PSkill*> useSkill;
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(Info, a->id, ptr->typeId, ptr_foe); //Ѱ�ҿ��ü���
            if (belongs(b->id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }
    if (useSkill.size()) //���ԣ�����ʹ�ü���
    {
        const PSkill* ptr = useSkill[rand()%useSkill.size()];
        if(rand01(0.2)){
	        op.type = ptr->name;
	        if (ptr->needTarget())
	            op.targets.push_back(b->pos);
	    }else{
	        if (dis2(a->pos, b->pos) <= a->range) //�жϵ�λb�Ƿ��ڹ�����Χ��
	        {
	            op.type = "Attack";
	            op.targets.push_back(b->pos);
	        } else
	        {
	            op.type = "Move";
	            findShortestPath(Map, a->pos, b->pos, Blocks, op.targets);
	        }			
		}
        
    } else
        if (dis2(a->pos, b->pos) <= a->range) //�жϵ�λb�Ƿ��ڹ�����Χ��
        {
            op.type = "Attack";
            op.targets.push_back(b->pos);
        } else
        {
            op.type = "Move";
            findShortestPath(Map, a->pos, b->pos, Blocks, op.targets);
        }
    cmd.cmds.push_back(op);
}
void Moving(PUnit a,Pos b,const PMap &map,const PPlayerInfo &info,PCommand &cmd){
	Operation op;
    op.id = a.id;
    op.type = "Move";
    findShortestPath(map, a.pos, b, Blocks,op.targets);
    cmd.cmds.push_back(op);
}

bool Group(){
	int d=0;
	for(int i=0;i<ours.size();i++)
	for(int j=i+j;j<ours.size();j++){
		PUnit a=ours[i],b=ours[j];
		if(a.name==string("Tower")||a.name==string("Spring"))continue;
		if(b.name==string("Tower")||b.name==string("Spring"))continue;
		if(retreat[a.id]||retreat[b.id])continue;
		d=max(d,dis2(a.pos,b.pos));
	}return d<=64;
}

bool oneNear(Pos ps){
	for(int i=0;i<ours.size();i++){
		Pos p=ours[i].pos;
		if(dis2(ps,p)<81)return 1;
	}return 0;
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
//	freopen("test.deb","w",stderr);
	pair<int,int> pp=RandPs();
	srand(time(0)^(long long)(new int));
	Map=map;Info=info;
    player = info.player;
    cmd.cmds.clear();
    Pos Home=(!player)?Pos(5,145):Pos(145,5);
    unite|=Group();
    if(info.round%20==0)unite=Group();
	if(info.round==0)
    	init(map,info,cmd);
    else{
    	if(player==1){
			if(info.findUnitByPos(Player0_tower_pos[1])
				&&strcmp(info.findUnitByPos(Player0_tower_pos[1])->name,"Tower"))
				lost0=1;
		}else{
			if(info.findUnitByPos(Player1_tower_pos[1])
				&&strcmp(info.findUnitByPos(Player1_tower_pos[1])->name,"Tower"))
				lost0=1;			
		}
        findUnitByPlayer(info,info.player,ours);
        findUnitByPlayer(info,info.player^1,enemy);
        findUnitByPlayer(info,2,other);
    	if(info.round%8==0){
			if(oneNear(Rpos)){
	    		pair<int,int> pp=RandPs(per);
	    		while(pp.first==Rpos.x)pp=RandPs(per);
	    		Rpos.x=pp.first;
	    		Rpos.y=pp.second;
	    	}
    		/*vector<Pos>tmpath;
			Rpos.x=Rpos.y=(rand01(0.33)?!player:player)?(6*(rand()%10)+1):(6*(rand()%10)+90);
			findShortestPath(map,Pos(1,1),Rpos,tmpath);
			while(tmpath.front().x<0){
				Rpos.x=Rpos.y=(rand01(0.33)?!player:player)?(6*(rand()%10)+1):(6*(rand()%10)+90);
				tmpath.clear();findShortestPath(map,Pos(1,1),Rpos,tmpath);
			}*/
		} 
        notme.clear();
		Push=0;
		int tmp=0;
		for(int i=0;i<ours.size();i++)
			if(ours[i].isHero())tmp+=ours[i].level;
		//Push+=tmp&&tmp%9==0;	
		Push=info.round%400>max(270-tmp*8,32);
		if(Push)per=max(0.5-(double)info.round/600.0,0.0);
        Blocks.clear();
        if(!Push)
        for(int i=0;i<=150;i++)for(int j=0;j<=150;j++){
			if(!player){
				if(dis2(Pos(i,j),Player1_tower_pos[1])<=100)
					Blocks.push_back(Pos(i,j));
				if(dis2(Pos(i,j),Player1_tower_pos[0])<=100)
					Blocks.push_back(Pos(i,j));					
			}else{
				if(dis2(Pos(i,j),Player0_tower_pos[1])<=100)
					Blocks.push_back(Pos(i,j));
				if(dis2(Pos(i,j),Player0_tower_pos[0])<=100)
					Blocks.push_back(Pos(i,j));
			}
		}
        for(int i=0;i<info.units.size();i++){
			PUnit b=info.units[i];
			Blocks.push_back(b.pos);
			if(b.name==string("Roshan")){
				for(int k=0;k<4;k++)
					Blocks.push_back(Pos(b.pos.x+dir[k][0],b.pos.y+dir[k][1]));		
			}
			if(b.player==2&&Push)continue;
			if(b.name==string("Roshan")&&info.round<400)continue;
			if(b.name==string("Tower")&&!Push)continue;
			if(b.player!=player&&!b.findBuff("Reviving"))
			notme.push_back(info.units[i]);
		}
		if(Push){
			if(player==0){
				if(lost0)
					Rpos=Player1_tower_pos[0];
				else Rpos=Player1_tower_pos[1];
			}else{
				if(lost0)
					Rpos=Player0_tower_pos[0];
				else Rpos=Player0_tower_pos[1];
			}
		}
        for(int i=0;i<ours.size();i++){
			PUnit a=ours[i];
			if(a.name==string("Tower")||a.name==string("Spring"))continue;
			if(a["Hp"]->val[0]+10>=a["Hp"]->val[1])retreat[a.id]=0;
			if(a["Exp"]->val[3]){
				levelup(a,info,cmd);
			}else{
				if(dis2(a.pos,Home)<16&&a["Hp"]->val[0]<a["Hp"]->val[1])continue;
				if(a.name==string("Archer")
					&&(retreat[a.id]||a["Hp"]->val[0]<70+a["Hp"]->val[1]/20)){ 
					Moving(a,Home,map,info,cmd);
					retreat[a.id]=1;
					continue;
				}
				if(!notme.size()){
					Moving(a,Rpos,map,info,cmd);
					continue;
				}
				Pos b=findEnemy(a,info);
				if(info.findUnitByPos(b))
					fighting(&a,info.findUnitByPos(b),cmd);
				else Moving(a,b,map,info,cmd);
			}
		}
    }
}//main(){}

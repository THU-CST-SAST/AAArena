#include "sdk.h"
#include<ctime>

const Pos EMPTYPOS = Pos(), DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 7, MAXLEVEL = 10, MAXID = 100;

static int fixId[MAXID];
static Pos fixPos[MAXID];
static bool towerDes[2];
typedef vector<const PUnit*> PUnits;
PUnits ours, others, nearBy;
static vector<Pos> blocks;

const PMap* MAP;
const PPlayerInfo* INFO;

int levelSum = 0, RoshanDie = -60;
const PUnit* belongs(int id, PUnits& units) //�ҳ�unit��ɵ�vector�а���ָ��id��unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

int unitEvaluation(string name) //����һ����λ��ս����
{	
    if (name == string("Dog") || name == string("Bow"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //������з���λ��ս
        return 0;
    if (name == string("Wolf") || name == string("StoneMan"))
        return 4;
    if (name == string("Dragon") || name == string("Roshan"))
        return 6;
	if (name == string("Tower"))
		return 7;
    return MAXLEVEL;
}

void fighting(const PUnit* a, const PUnit* b, PCommand &cmd) //��λa�Ե�λb�������
{
    Operation op;
    op.id = a->id;

    vector<const PSkill*> useSkill;
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //Ѱ�ҿ��ü���
			if (strcmp(ptr->name, "Charge") == 0 && strcmp(b->name, "Tower") == 0)
				continue;
            if (belongs(b->id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }
    if (useSkill.size()) //���ԣ�����ʹ�ü���
    {
        const PSkill* ptr = useSkill[rand()%useSkill.size()];
        op.type = ptr->name;
        if (ptr->needTarget())
            op.targets.push_back(b->pos);
    } else
        if (dis2(a->pos, b->pos) <= a->range) //�жϵ�λb�Ƿ��ڹ�����Χ��
        {
            op.type = "Attack";
            op.targets.push_back(b->pos);
        } else
        {
            op.type = "Move";
            findShortestPath(*MAP, a->pos, b->pos, blocks, op.targets);
        }
    cmd.cmds.push_back(op);
}

void levelUp(const PUnit* a, PCommand &cmd) //��λa��������
{
    vector<string> level_ups;
    level_ups.push_back("YellowPoint");
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isLU() && a->canUseSkill(ptr->typeId)) {//ѡ����������ļ���
			if (strcmp(a->skills[i].name, "YellLU") != 0 && strcmp(a->skills[i].name, "BlinkLU") != 0 && strcmp(a->skills[i].name, "PALU") != 0) {
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
			}
			if (strcmp(a->skills[i].name, "HideLU") == 0) {
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
			}
			if (strcmp(a->skills[i].name, "SpinLU") == 0) {
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
			}
			if (strcmp(a->skills[i].name, "ARLU") == 0) {
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
				level_ups.push_back(a->skills[i].name);
			}
		}
    }
    Operation op;
    op.id = a->id;
    op.type = level_ups[rand()%level_ups.size()]; //�����������
    cmd.cmds.push_back(op);
}

void getFoes(vector<Pos> &atk_tar, int l, int u) //���ݵȼ�Ѱ�ҵ�ͼ����Ӧ
{
    int t = unitEvaluation("Tower");
    if (l <= t && t <= u || levelSum >= 35)
    {
        const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
        for (int i = 1; i >= 0; i--)
            if (!towerDes[i])
            {
                for (int j = 0; j < 5; ++j)
                    atk_tar.push_back(tower[i]); //�Ӵ���������
				break;
            }
    }
	if (levelSum >= 35) return;
    t = unitEvaluation("Dragon");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(Dragon_pos[i]);
		if (INFO->round > RoshanDie+ 60)
			atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEvaluation("Wolf");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 4; ++i)
            atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEvaluation("Dog");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 6; ++i)
            atk_tar.push_back(Dog_pos[i]);
        for (int i = 0; i < 6; ++i)
            if (i % 3) //ȥ�������޷��ƶ������Ұ��
                atk_tar.push_back(Bow_pos[i]);
    }
}

void findFoes(const PUnit* a, PCommand &cmd) //��λaѰ�Ҷ���
{
    if ((*a)["Exp"]->val[3]) //������������
    {
        levelUp(a, cmd);
    } else
    {
        if (fixPos[a->id] == EMPTYPOS || levelSum >= 35)
        {
            vector<Pos> atk_tar;
            atk_tar.clear();
            getFoes(atk_tar, a->level > HIGHLEVEL ? HIGHLEVEL : 0, a->level); //���ԣ��ﵽһ��ǿ�ȿ�ʼ����������
            if (atk_tar.size()) //Ѱ�ҹ̶������С����
            {
                fixPos[a->id] = atk_tar[rand()%atk_tar.size()]; //����Ŀ��
            } else
            {
                fixPos[a->id] = DEFAULFPOS;
            }
        }
        Operation op;
        op.id = a->id;
        op.type = "Move";
        findShortestPath(*MAP, a->pos, fixPos[a->id], blocks, op.targets); //����С�����ƶ�
        cmd.cmds.push_back(op);
    }
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //��0�غ�ѡ��Ӣ��
{
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
        int r=rand()%3;
        if(r==0)
            op.type="ChooseAssassin";
        else if(r==1)
            op.type="ChooseFighter";
        else if(r==2)
            op.type="ChooseArcher";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op); //���ѡ��ְҵ
    }
}

void init() //һЩ������ʼ��
{
    blocks.clear();
    getFoes(blocks, 0, MAXLEVEL);
    const Pos* tower = INFO->camp ? Player1_tower_pos : Player0_tower_pos;
    for (int i = 0; i < 2; ++i)
        blocks.push_back(tower[i]); //��ͼ�Ϲ̶��㲻�ɾ���
    memset(fixId, EMPTYID, sizeof fixId);
    towerDes[0] = towerDes[1] = false;
    for (int i = 0; i < MAXID; ++i) fixPos[i] = EMPTYPOS;
}


void fightAlone(const PUnit* ptr, const PPlayerInfo &info, PCommand &cmd)
{
    info.findUnitInArea(ptr->pos, ptr->view, nearBy); //Ѱ�Ҹ�������
    fixPos[ptr->id] = EMPTYPOS;
    for (int i = nearBy.size() - 1; i >= 0; i--)
    {
		if (nearBy[i]->findBuff("Reviving") && strcmp(nearBy[i]->name, "Roshan") == 0)
			RoshanDie = INFO->round;
        if ((unitEvaluation(nearBy[i]->name) > ptr->level && levelSum < 35)||
                nearBy[i]->camp == ptr->camp ||
                nearBy[i]->pos == Bow_pos[0] || nearBy[i]->pos == Bow_pos[3] ||
                nearBy[i]->findBuff("Reviving"))
            //ɾ���ȼ����ߵ��ˣ������Ѿ����޳������ߣ�ɾ�����ɵ����Ұ��
        {
            nearBy.erase(nearBy.begin()+i);
        }
    }
    if (nearBy.size()) //���ԣ����ܱ�����С��������й���
    {
        const PUnit* ptr_foe = fixId[ptr->id]!=EMPTYID ?
                    belongs(fixId[ptr->id], nearBy) : NULL; //�ж�֮ǰ�Ƿ�������Ŀ��
        if (!ptr_foe)
        {
            ptr_foe = nearBy[rand()%nearBy.size()];
            fixId[ptr->id] = ptr_foe->id; //��֮ǰδ������Ŀ�꣬���ѡ��Ŀ��
        }
        fighting(ptr, ptr_foe, cmd); //��Ŀ���
    } else
    {
		findFoes(ptr, cmd); //������û�ео����ڵ�ͼ��Ѱ��һ��
    }
}

bool iAmBack[1000];
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(0)); //������ش�
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    if (info.round == 0)
    {
        chooseHero(info, cmd); //��0�غ�ѡ��Ӣ��
        init(); //һЩ������ʼ��
    } else //��ʽ�غ�
    {
        info.findUnitByPlayer(info.player, ours); //Ѱ�����б�����λ
		levelSum = 0;
		for (int i=0; i<ours.size(); ++i) //���м�����λ
        {
            const PUnit* ptr = ours[i];
			if (strcmp(ptr->name, "Fighter") == 0) 
				levelSum += ptr->level;
			if (strcmp(ptr->name, "Archer") == 0)
				levelSum += ptr->level;
			if (strcmp(ptr->name, "Assassin") == 0)
				levelSum += ptr->level;
		}

        for (int i=0; i<ours.size(); ++i) //���м�����λ
        {
            const PUnit* ptr = ours[i];
            if (ptr->isHero()) //ptr��һ��Ӣ�ۣ����Ͷ�����ϣ�������ս
            {
                const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
                for (int i = 0; i < 2; ++i)
                    if (dis2(ptr->pos, tower[i]) < 100 && info.findUnitByPos(tower[i]) == NULL && map.height[ptr->pos.x][ptr->pos.y] >= map.height[tower[i].x][tower[i].y] - 1)
                        towerDes[i] = true; //ȥ���Ѵݻٷ�����
				
				//ADD................................
				int max_hp = 0;
				if (strcmp(ptr->name, "Fighter") == 0)
					max_hp = Fighter_base_hp + ptr->level * Fighter_hp_delta;
				if (strcmp(ptr->name, "Archer") == 0)
					max_hp = Archer_base_hp + ptr->level * Archer_hp_delta;
				if (strcmp(ptr->name, "Assassin") == 0)
					max_hp = Assassin_base_hp + ptr->level * Assassin_hp_delta;

				if ((strcmp(ptr->name, "Fighter") == 0) && ptr->hp >= max_hp - 50)
					iAmBack[ptr->id] = false;
				if ((strcmp(ptr->name, "Archer") == 0) && ptr->hp >= max_hp - 50)
					iAmBack[ptr->id] = false;
				if ((strcmp(ptr->name, "Assassin") == 0) && ptr->hp >= max_hp - 50)
					iAmBack[ptr->id] = false;
				
				if ((strcmp(ptr->name, "Spring") != 0) && (strcmp(ptr->name, "Tower") != 0) && ptr->hp < max_hp * 0.3 && ptr->level > 1)
					iAmBack[ptr->id] = true;

				if (iAmBack[ptr->id]) {
					Operation op;
					op.id = ptr->id;
					op.type = "Move";
					if (info.player == 0)
						findShortestPath(*MAP, ptr->pos, Pos(6, 144), blocks, op.targets); //��Ȫˮ
					else
						findShortestPath(*MAP, ptr->pos, Pos(144, 6), blocks, op.targets);
					cmd.cmds.push_back(op);
				} else
					fightAlone(ptr, info, cmd);
            }
        }
    }
}

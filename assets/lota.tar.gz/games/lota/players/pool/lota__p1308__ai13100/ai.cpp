#include "sdk.h"
#include <vector>
#include <algorithm>
#include <cstdio>
using namespace std;
const PMap *Map;  const PPlayerInfo *Info;
typedef vector<const PUnit*> Units;
Units ours,enemy,wild;  
vector<Pos>Blocks; Pos Home;
int towerDes[5];
//评估一个单位的战斗力
int unitEvaluation(string name){
    if (name == string("Dog") || name == string("Bow"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //鼓励与敌方单位交战
        return 0;
    if (name == string("Wolf") || name == string("StoneMan"))
        return 4;
    if (name == string("Tower") || name == string("Dragon") || name == string("Roshan"))
        return 10;
    return 100;
}

//找出unit组成的vector中包含指定id的unit
inline const PUnit* belongs(int id, Units& units){
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

//游戏开始阶段选择英雄
inline void ChooseHero(const PPlayerInfo &info,PCommand &cmd){
	int cur=0;
	for (int i=0;i<info.units.size();i++){
		const PUnit *now=&info.units[i];
		if (strcmp(now->name,"Chooser")) continue;
		Operation op;
		op.id=now->id;
		if (cur==0 || cur==1){
			op.type="ChooseFighter";
		}else if (cur==2 || cur==3){
			op.type="ChooseArcher";
		}else{
			op.type="ChooseAssassin";
		}
		op.targets.clear();
		cmd.cmds.push_back(op);
		cur++;
	}
}

//显示视野信息
inline void show(const PPlayerInfo &info){
	for (int i=0;i<info.units.size();i++){
		const PUnit *A=&info.units[i];
		printf("name:%s  id:%d  typeId:%d\n",A->name,A->id,A->typeId);
	}
}

//对一名英雄寻路
inline void getRoad(const PUnit *A,Pos Target,PCommand &cmd){
	Operation op;
	findShortestPath(*Map,A->pos,Target,Blocks,op.targets);
	op.id=A->id; op.type="Move";
	cmd.cmds.push_back(op);
}

//英雄A的升级
inline void LevelUp(const PUnit *A,PCommand &cmd){
	Operation op;
	op.id=A->id;
	op.targets.clear();
	if ((*A)["Exp"]->val[3]){
		//战士
		if (strcmp(A->name,"Fighter")){
			if (A->canUseSkill(2)){
				op.type="ChargeLU";
			}else if (A->canUseSkill(6)){
				op.type="YellLU";
			}else if (A->canUseSkill(4)){
				op.type="SpinLU";
			}else{
				op.type="YellowPoint";
			}
		}else if (strcmp(A->name,"Archer")){
			if (A->canUseSkill(12)){
				op.type="PULU";
			}else if (A->canUseSkill(10)){
				op.type="ARLU";
			}else if (A->canUseSkill(8)){
				op.type="PALU";
			}else{
				op.type="YellowPoint";
			}
		}else if (strcmp(A->name,"Assassin")){
			if (A->canUseSkill(16)){
				op.type="FBLU";
			}else if (A->canUseSkill(19)){
				op.type="YellowPoint";
			}else if (A->canUseSkill(18)){
				op.type="BlinkLU";
			}else{
				op.type="HideLU";
			}
		}
	}
	cmd.cmds.push_back(op);
}

//A对B进行攻击
inline void Fight(const PUnit *A,const PUnit *B,PCommand &cmd){
	if (B==NULL) return;
	Operation op;
	op.id=A->id;
	vector<const PSkill *>Useful;
	for (int i=0;i<A->skills.size();i++){
		const PSkill* now= &A->skills[i];
		Units List;
		infectedBySkill(*Info,A->id,now->typeId,List);
		if (belongs(B->id,List) || !strcmp("Hide",now->name)){
			Useful.push_back(now);
		}
	}
	if (Useful.size()){
        const PSkill* ptr = Useful[rand()%Useful.size()];
        op.type = ptr->name;
        if (ptr->needTarget()) op.targets.push_back(B->pos);
    }else if (dis2(A->pos, B->pos) <= A->range) //判断单位b是否在攻击范围内
    {
        op.type = "Attack";
        op.targets.push_back(B->pos);
    } else
    {
        op.type = "Move";
        findShortestPath(*Map, A->pos, B->pos, Blocks, op.targets);
    }
    cmd.cmds.push_back(op);
}

//是否可以对战
inline int canFight(const PUnit *A,const PUnit *B){
	if (A->camp^B->camp==1){
		if (A->level>7) return 1;
		if (A->level<B->level || !strcmp("Tower",B->name)) return 0;
		return 1;
	}
	else{
		return A->level>=unitEvaluation(B->name);
	}
}

//根据等级寻找地图中相应敌人
void getFoes(vector<Pos> &atk_tar, int l, int u){
    int t = unitEvaluation("Tower");
    if (l <= t && t <= u)
    {
        const Pos* tower = Info->camp ? Player0_tower_pos: Player1_tower_pos;
        for (int i = 0; i < 2; ++i) atk_tar.push_back(tower[i]); //加大推塔概率
    }
    t = unitEvaluation("Dragon");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(Dragon_pos[i]);
        atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEvaluation("Wolf");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 4; ++i)
            atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEvaluation("Dog");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 6; ++i)
            atk_tar.push_back(Dog_pos[i]);
        for (int i = 0; i < 6; ++i)
            if (i % 3) //去除两个无法移动到达的野怪
                atk_tar.push_back(Bow_pos[i]);
    }
}

//为这个英雄寻找一个对手
inline const PUnit* FindTarget(const PPlayerInfo &info,const PUnit *A,PCommand &cmd){
	Units List;
	//寻找视野中的敌人
	info.findUnitInArea(A->pos,A->view,List);
	for (int i=0;i<List.size();i++){
		if (List[i]->camp==A->camp || !canFight(A,List[i]) || List[i]->findBuff("Reviving")
		|| ((List[i]->pos==Bow_pos[0] || List[i]->pos==Bow_pos[3]) && strcmp(A->name,"Archer"))){
			List.erase(List.begin()+i);
			i--;
		}
	}
	if (List.size()){
		return List[rand()%List.size()];
	}
	//寻找其他敌人
	vector<Pos>B;
	getFoes(B,A->level-5,A->level+1);
	getRoad(A,B[rand()%B.size()],cmd);
	return NULL;
}

inline void work(const PPlayerInfo &info,const PUnit *A,PCommand &cmd){
	//升级
	LevelUp(A,cmd);
	//回家
	if (A->hp*20 < (*A)["Hp"]->val[1]){
		getRoad(A,Home,cmd);
		return;
	}
	Fight(A,FindTarget(info,A,cmd),cmd);
}

void player_ai(const PMap &map,const PPlayerInfo &info,PCommand &cmd){
	cmd.cmds.clear();
	if (info.round==0){
		Map=&map; Info=&info;
		ChooseHero(info,cmd);
		Home=info.player?Player1_spring_pos[0]:Player0_spring_pos[0];
		return;
	}
	info.findUnitByPlayer(info.player,ours);
	for (int i=0;i<ours.size();i++){
		work(info,ours[i],cmd);
	}
}
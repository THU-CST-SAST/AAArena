#include "sdk.h"
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <functional>
#include <algorithm>
#include <iostream>
#include <fstream>

static bool aggressive = false;

static int vst[Map_size][Map_size];
static Pos Q[Map_size * Map_size + 1], Q_prior[Map_size][Map_size];
static int countF = 0;

void assassinFindShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回一个负数坐标
{
	int _sz = blocks.size();
	
	++countF;
	_path.clear();
	for (int i=0; i<_sz; ++i)
	{
		if (checkPos(blocks[i]))
			vst[blocks[i].x][blocks[i].y] = countF;
	}
	if (!checkPos(start) || !checkPos(dest))
	{
		_path.push_back(Pos());
		return;
	}
	vst[start.x][start.y] = vst[dest.x][dest.y] = countF - 1;
	
	Pos _0, _1;
	
	int dir_ord[4];
	Q[0] = start;
	vst[start.x][start.y] = countF;
	for (int front=0, rear=0; front<=rear; ++front) {
		_0 = Q[front];
		for (int i=0; i<4; ++i) dir_ord[i] = i;
		random_shuffle(dir_ord, dir_ord+4);
		
		for (int i=0; i<4; ++i) {
			_1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
			if (checkPos(_1) && (abs(map.height[_0.x][_0.y] - map.height[_1.x][_1.y]) <= 1 || max(map.height[_0.x][_0.y], map.height[_1.x][_1.y]) >= 4) && vst[_1.x][_1.y] != countF) {
				vst[_1.x][_1.y] = countF;
				Q[++rear] = _1;
				Q_prior[_1.x][_1.y] = _0;
			}
		}
	}
	
	if (vst[dest.x][dest.y] == countF) {
		for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y])
			_path.push_back(_0);
		_path.push_back(_0);
		reverse(_path.begin(), _path.end());
	} else _path.push_back(Pos());
}

const Pos EMPTYPOS = Pos(), DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 6, MAXLEVEL = 10, MAXID = 100;


const PMap* MAP;
const PPlayerInfo* INFO;

class Enemy;
class MyHero;
class Game;
class Monster;

const int monster2Tower[4][26] = {
	83, 83, 182, 150, 124, 100, 63, 138, 112, 18, 63, -1, 160, 23, -1, 148, 103, 104, 128, 92, 46, 91, 109, 182, 170, 42,
	83, 83, 116, 150, 124, 100, 63, 68, 42, 76, 21, -1, 160, 103, -1, 98, 61, 104, 128, 22, 104, 109, 43, 182, 100, 42,
	83, 83, 182, 138, 112, 18, 63, 150, 124, 100, 63, -1, 148, 103, -1, 160, 23, 92, 46, 104, 128, 109, 91, 170, 182, 42,
	83, 83, 116, 68, 42, 76, 21, 150, 124, 100, 63, -1, 98, 61, -1, 160, 103, 22, 104, 104, 128, 43, 109, 100, 182, 42
};

const int monster2Spring[2][26] = {
	182, 116, 281, 145, 143, 175, 120, 237, 211, 117, 162, -1, 199, 80, -1, 247, 202, 123, 203, 191, 105, 96, 208, 177, 269, 141,
	182, 116, 281, 237, 211, 117, 162, 145, 143, 175, 120, -1, 247, 202, -1, 199, 80, 191, 105, 123, 203, 208, 96, 269, 177, 141,
};

static int monsterIndex[23];

int abs(int x) {return x < 0 ? -x : x;}

class Game
{
public:
	int enemyLiving;
	int myLiving;
	int myTower;
	int myTowerId[2];
	Pos myTowerPos[2];
	Pos safetyPos[2];
	int enemyTower;
	Pos myHome;
	Pos enemyHome;
	int myHeroStrength[5];
	int index[100];
	int stage;
	vector<int> targets[2];
	int target[2];
	vector<int> myTowerAround[2];
	vector<int> myTowerHero[2];
	queue<int> myTowerSafeQ[2];
	int myTowerSafe[2];
	vector<int> enemyTeam;
	vector<int> myTeam;
	int step;
	int allBigNine;
	bool tower1Fail;
	bool tower2Fail;
	int asTower0Fail;
	int asTower1Fail;
	bool myTowerExist[2];
	int myTowerHp[2];
	bool enemyAggressive;
	int myTowerDanger[2];
	
public:
	Game()
	{
		enemyLiving = 5;
		myLiving = 5;
		myTower = 2;
		enemyTower = 2;
		step = -1;
		stage = 0;
		allBigNine = 0;
		tower1Fail = false;
		tower2Fail = false;
		asTower0Fail = 1;
		asTower1Fail = 0;
		enemyAggressive = false;
		myTowerDanger[0] = myTowerDanger[1] = 0;
	}
	bool isMonster(int id);
	bool isEnemy(int id);
	void initial(PCommand &cmd);
	void clearInfo();
	void getInfo();
	void higherOrder();
	void getTarget();
	void setState();
	void playAlone(PCommand &cmd);
	void debug();
};

bool Game::isMonster(int id)
{
	if (id <= 38)
		return true;
	else
		return false;
}

bool Game::isEnemy(int id)
{
	if (INFO->camp)
		return id >= 39 && id <= 43;
	else
		return id >= 44 && id <= 48;
}

static Game GAME;

struct Power
{
	int damage;
	int Mp;
	int range;
	int target;
	string name;
	bool operator > (const Power &a) const;
	bool operator < (const Power &a) const;
};

bool Power::operator > (const Power &a) const
{
	return Mp > a.Mp;
}

bool Power::operator < (const Power &a) const
{
	return Mp < a.Mp;
}

class MyHero
{
public:
	int id;			// hero's id;
	int index;		// hero's id from 0;
	PUnit self = PUnit(1,1,1,1,1,1);		// point to hero itself;
	Pos safePoint;		// hero's moving to position;
	int state;		// hero state:
	// 0: all right;
	// 1: coming to help!;
	// 2: change target;
	// 3: almost die;
	int ATKInterval;
	vector<Pos> blocks;
	vector<Power> power;
	string mission;
	bool dead;
	bool inTeam;
	bool justBeaten;
	bool upWind;
	bool downWind;
	bool canFight;
	int defenceTower;
	int justAttacked;
	vector<int> aroundHero;
	vector<int> aroundEnemy;
	vector<int> targets;
	int target;
	int distance2[26];
	int w[4][4];
	int iWillTake;
	int formationId;
	Pos teamCenter;
	Operation higherOrder;
	Pos prepareTower[2];
public:
	MyHero()
	{
		state = 0;
		targets.clear();
		target = 0;
		blocks.clear();
		power.clear();
		aroundHero.clear();
		aroundEnemy.clear();
		dead = false;
		justAttacked = false;
		justBeaten = false;
		canFight = true;
		defenceTower = 0;
		formationId = 0;
		mission = "";
	};
	void findMyself();
	void findBlocks();
	//	int defeat(Enemy unit);		// whether my hero can defeat unit, if can: return HP left, else: return 0;
	int doEvaluate(int timeCost, int expGain, int winGain, int continueMonster, int distanceToOpposite, double winPercent);
	int doEvaluate(Enemy unit, int count);
	void defeatEvaluate(Monster unit);	// return .weight of fighting with [unit];
	// in which, .weight == (can_defeat{0|1} && can_reach{0|1}) -> {
	// w10 * time_need{w11 * time_goto + w12 * time_fight_against} +
	// w20 * reward_gain{w21 * exp_gain + w22 * continue_monster} +
	// w30 * safety_point{w31 * Hp_left + w32 * distance_to_opposite}
	// }
	// the larger weight is, the better;
	Operation attackAt(Pos position);
	Operation assassinMoveTo(Pos position);
	Operation moveTo(Pos position);
	Operation moveTo(Pos position, int _range);
	Operation keepDistanceTo(Pos position, int _range);
	Pos oppositeTo(Pos position, int _range);
	Pos oppositeTo(Pos position);
	Pos oppositeTo(Pos position1, Pos position2);
	Pos avoid(Pos enemyPos, Pos position);
	Pos clockWise(Pos position, bool clock);
	void archerPlayAlone(PCommand &cmd);
	void assassinPlayBack(PCommand &cmd);
	void assassinPlayAlone(PCommand &cmd);
	int timeGoingTo(int id);
	void findTarget();
	void levelUp(PCommand &cmd);
};

static MyHero myHero[5];
// 0: Fi;
// 1: As;
// 2: Ar;
// 3: Ar;
// 4: Ar;

class Enemy					// enemy heros;
{
public:
	int id;
	string type;
	bool known;
	PUnit self = PUnit(1,1,1,1,1,1);
	Pos position;
	Pos direction;			// position this turn - position last turn;
	int Hp;
	int Mp;
	int shown;
	int notLive;
	int ATKInterval;
	vector<int> inRange;	// enemy is in <v>'s range;
public:
	Enemy()
	{
		known = false;
		notLive = 0;
	}
	void findItself();
	bool facingTo(Pos position);
};

static Enemy enemy[5];

class Monster				// monster units;
{
public:
	int id;
	vector<int> hero;
	Pos position;
	Pos initPos;
	Pos direction;
	int Hp;
	int HpMax;
	int ATK;
	int DEF;
	int speed;
	int range;
	int exp;
	int deltaHp;
	int notLive;
	int revive;				// how many turn to revive;
	bool consider;			// whether should be attacked;
	int ATKInterval;
public:
	Monster()
	{
		hero.clear();
		notLive = 0;
		consider = true;
	};
	void findItself();
	bool facingTo(Pos position);
};

static Monster monster[26];

void Game::initial(PCommand &cmd)
{
	for(int i = 0; i < INFO->units.size(); ++i)	// choose hero
	{
		Operation op;
		if (aggressive)
		{
			op.type = "ChooseAssassin";
		}
		else
		{
			if(i==0)
				op.type="ChooseArcher";
			else if(i==1 || i==2 || i == 3)
				op.type="ChooseArcher";
			else if(i==4)
				op.type="ChooseAssassin";
		}
		op.targets.clear();
		op.id=INFO->units[i].id;
		cmd.cmds.push_back(op);
	}
	for (int i = 0; i < 5; i++)
	{
		myHeroStrength[i] = i;
		myHero[i].index = i;
		if (!INFO->player)					// if camp == 0
		{
			myHero[i].id = 39 + i;
			enemy[i].id = 44 + i;
		}
		else								// if camp == 1
		{
			myHero[i].id = 44 + i;
			enemy[i].id = 39 + i;
		}
	}
	if (aggressive)
	{
		for (int i = 0; i < 5; i++)
		{
			myHero[i].canFight = false;
		}
	}
	myTowerHero[0].push_back(0);
	myTowerHero[0].push_back(2);
	myTowerHero[1].push_back(1);
	myTowerHero[1].push_back(3);
	myHero[0].ATKInterval = 2;
	myHero[1].ATKInterval = 2;
	myHero[2].ATKInterval = 2;
	myHero[3].ATKInterval = 2;
	myHero[4].ATKInterval = 1;
	monster[0].ATKInterval = 1;
	monster[1].ATKInterval = 1;
	monster[2].ATKInterval = 1;
	myTowerExist[0] = true;
	myTowerExist[1] = true;
	if (!INFO->player)						// if camp == 0;
	{
		safetyPos[0].x = 76;
		safetyPos[0].y = 117;
		safetyPos[1].x = 117;
		safetyPos[1].y = 76;
		monster[0].id = 12;
		monster[1].id = 13;
		monster[2].id = 15;
		index[12] = 0;
		index[13] = 1;
		index[15] = 2;
		index[44] = 0;
		index[45] = 1;
		index[46] = 2;
		index[47] = 3;
		index[48] = 4;
		monster[0].position = monster[0].initPos = Player1_tower_pos[0];
		monster[1].position = monster[1].initPos = Player1_tower_pos[1];
		monster[2].position = monster[2].initPos = Player1_spring_pos[0];
		monster[0].Hp = monster[0].HpMax = 1000;
		monster[1].Hp = monster[1].HpMax = 1000;
		monster[2].Hp = monster[2].HpMax = 2000;
		monster[0].ATK = monster[1].ATK = 55;
		monster[2].ATK = 100;
		monster[0].DEF = monster[1].DEF = 15;
		monster[2].DEF = 0;
		monster[0].speed = monster[1].speed = monster[2].speed = -1;		// no speed;
		monster[0].range = monster[1].range = 100;
		monster[2].range = 50;
		monster[0].exp = monster[1].exp = monster[2].exp = 0;
		myTowerId[0] = 10;
		myTowerId[1] = 11;
		myHome = Player0_spring_pos[0];
		enemyHome = Player1_tower_pos[0];
		myTowerPos[0] = Player0_tower_pos[0];
		myTowerPos[1] = Player0_tower_pos[1];
		monsterIndex[1] = 26;
		monsterIndex[2] = 22;
		monsterIndex[3] = 33;
		monsterIndex[4] = 21;
		monsterIndex[5] = 20;
		monsterIndex[6] = 37;
		monsterIndex[7] = 23;
		monsterIndex[8] = 19;
		monsterIndex[10] = 30;
		monsterIndex[11] = 17;
		monsterIndex[12] = 29;
		monsterIndex[13] = 31;
		monsterIndex[14] = 18;
		monsterIndex[15] = 12;
		monsterIndex[16] = 13;
		monsterIndex[17] = 36;
		monsterIndex[18] = 16;
		monsterIndex[19] = 32;
		monsterIndex[20] = 24;
		monsterIndex[21] = 25;
		monsterIndex[22] = 34;
		myHero[0].safePoint = Pos(75, 117);
		myHero[1].safePoint = Pos(75, 115);
		myHero[2].safePoint = Pos(116, 74);
		myHero[3].safePoint = Pos(116, 76);
		myHero[0].prepareTower[0] = Pos(64, 37);
		myHero[1].prepareTower[0] = Pos(76, 44);
		myHero[2].prepareTower[0] = Pos(86, 32);
		myHero[3].prepareTower[0] = Pos(82, 25);
		myHero[0].prepareTower[1] = Pos(33, 82);
		myHero[1].prepareTower[1] = Pos(25, 69);
		myHero[2].prepareTower[1] = Pos(31, 65);
		myHero[3].prepareTower[1] = Pos(44, 71);
	}
	else									// if camp == 1;
	{
		safetyPos[0].x = 74;
		safetyPos[0].y = 33;
		safetyPos[1].x = 33;
		safetyPos[1].y = 74;
		monster[0].id = 10;
		monster[1].id = 11;
		monster[2].id = 14;
		index[10] = 0;
		index[11] = 1;
		index[14] = 2;
		index[39] = 0;
		index[40] = 1;
		index[41] = 2;
		index[42] = 3;
		index[43] = 4;
		monster[0].position = monster[0].initPos = Player0_tower_pos[0];
		monster[1].position = monster[1].initPos = Player0_tower_pos[1];
		monster[2].position = monster[2].initPos = Player0_spring_pos[0];
		monster[0].Hp = monster[0].HpMax = 1000;
		monster[1].Hp = monster[1].HpMax = 1000;
		monster[2].Hp = monster[2].HpMax = 2000;
		monster[0].ATK = monster[1].ATK = 55;
		monster[2].ATK = 100;
		monster[0].DEF = monster[1].DEF = 15;
		monster[2].DEF = 0;
		monster[0].speed = monster[1].speed = monster[2].speed = -1;		// no speed;
		monster[0].range = monster[1].range = 100;
		monster[2].range = 50;
		monster[0].exp = monster[1].exp = monster[2].exp = 0;
		myTowerId[0] = 12;
		myTowerId[1] = 13;
		myHome = Player1_spring_pos[0];
		enemyHome = Player0_tower_pos[0];
		myTowerPos[0] = Player1_tower_pos[0];
		myTowerPos[1] = Player1_tower_pos[1];
		monsterIndex[1] = 29;
		monsterIndex[2] = 18;
		monsterIndex[3] = 31;
		monsterIndex[4] = 17;
		monsterIndex[5] = 16;
		monsterIndex[6] = 36;
		monsterIndex[7] = 19;
		monsterIndex[8] = 23;
		monsterIndex[10] = 32;
		monsterIndex[11] = 21;
		monsterIndex[12] = 26;
		monsterIndex[13] = 33;
		monsterIndex[14] = 22;
		monsterIndex[15] = 10;
		monsterIndex[16] = 11;
		monsterIndex[17] = 37;
		monsterIndex[18] = 20;
		monsterIndex[19] = 30;
		monsterIndex[20] = 27;
		monsterIndex[21] = 28;
		monsterIndex[22] = 35;
		myHero[0].safePoint = Pos(75, 33);
		myHero[1].safePoint = Pos(75, 35);
		myHero[2].safePoint = Pos(34, 74);
		myHero[3].safePoint = Pos(34, 76);
		myHero[0].prepareTower[0] = Pos(150 - 64, 150 - 37);
		myHero[1].prepareTower[0] = Pos(150 - 76, 150 - 44);
		myHero[2].prepareTower[0] = Pos(150 - 86, 150 - 32);
		myHero[3].prepareTower[0] = Pos(150 - 82, 150 - 25);
		myHero[0].prepareTower[1] = Pos(150 - 33, 150 - 82);
		myHero[1].prepareTower[1] = Pos(150 - 25, 150 - 69);
		myHero[2].prepareTower[1] = Pos(150 - 31, 150 - 65);
		myHero[3].prepareTower[1] = Pos(150 - 44, 150 - 71);
	}
	for (int i = 3; i < 26; i++)
	{
		monster[i].id = 16 + (i - 3);
		index[monster[i].id] = i;
		if (monster[i].id >= 30 && monster[i].id <= 33)
			monster[i].ATKInterval = 1;
		else
			monster[i].ATKInterval = 2;
		if (monster[i].id >= 16 && monster[i].id <= 23)						// locate position
		{
			monster[i].Hp = monster[i].HpMax = 250;
			monster[i].ATK = 25;
			monster[i].DEF = 10;
			monster[i].speed = 16;
			monster[i].range = 9;
			monster[i].exp = 70;
			monster[i].revive = 20;
			monster[i].position = monster[i].initPos = Dog_pos[monster[i].id - 16];
		}
		else
		if (monster[i].id >= 24 && monster[i].id <= 29)
		{
			monster[i].Hp = monster[i].HpMax = 280;
			monster[i].ATK = 35;
			monster[i].DEF = 0;
			monster[i].speed = 16;
			monster[i].range = 81;
			monster[i].exp = 90;
			monster[i].revive = 20;
			monster[i].position = monster[i].initPos = Bow_pos[monster[i].id - 24];
		}
		else
		if (monster[i].id >= 30 && monster[i].id <= 33)
		{
			monster[i].Hp = monster[i].HpMax = 350;
			monster[i].ATK = 42;
			monster[i].DEF = 12;
			monster[i].speed = 16;
			monster[i].range = 9;
			monster[i].exp = 150;
			monster[i].revive = 25;
			monster[i].position = monster[i].initPos = Wolf_pos[monster[i].id - 30];
		}
		else
		if (monster[i].id >= 34 && monster[i].id <= 35)
		{
			monster[i].Hp = monster[i].HpMax = 550;
			monster[i].ATK = 35;
			monster[i].DEF = 25;
			monster[i].speed = 12;
			monster[i].range = 9;
			monster[i].exp = 150;
			monster[i].revive = 25;
			monster[i].position = monster[i].initPos = StoneMan_pos[monster[i].id - 34];
		}
		else
		if (monster[i].id >= 36 && monster[i].id <= 37)
		{
			monster[i].Hp = monster[i].HpMax = 600;
			monster[i].ATK = 80;
			monster[i].DEF = 10;
			monster[i].speed = 12;
			monster[i].range = 81;
			monster[i].exp = 500;
			monster[i].revive = 60;
			monster[i].position = monster[i].initPos = Dragon_pos[monster[i].id - 36];
		}
		else
		if (monster[i].id == 38)
		{
			monster[i].Hp = monster[i].HpMax = 1200;
			monster[i].ATK = 65;
			monster[i].DEF = 25;
			monster[i].speed = 12;
			monster[i].range = 9;
			monster[i].exp = 500;
			monster[i].revive = 80;
			monster[i].position = monster[i].initPos = Roshan_pos[monster[i].id - 38];
		}
	}
	for (int i = 0; i < 26; i++)
		monster[i].deltaHp = monster[i].HpMax * 0.01;
	// time_need{w10 * time_cost / exp_gain} +
	// reward_gain{w21 * win_gain{0|1|2} + w22 * continue_monster{0|1} +
	// safety_point{w30 * distance_to_opposite * w31 * win_percent}
	int w[5][4][4] = {								// initialize w[i][j]
		40, 1, 1, 1,
		100, 1, 1, 1,
		1, 1, 30, 1,
		1, 10, 2, 1,
		
		40, 1, 1, 1,
		100, 1, 1, 1,
		1, 1, 30, 1,
		1, 10, 2, 1,
		
		40, 1, 1, 1,
		100, 1, 1, 1,
		1, 1, 30, 1,
		2, 10, 2, 1,
		
		40, 1, 1, 1,
		100, 1, 1, 1,
		1, 1, 30, 1,
		1, 10, 2, 1,
		
		40, 1, 1, 1,
		100, 1, 1, 1,
		1, 1, 30, 1,
		1, 10, 2, 1,
	};
	for (int k = 0; k < 5; k++)
		for (int i = 0; i < 4; i++)
			for (int j = 0; j < 4; j++)
				myHero[k].w[i][j] = w[k][i][j];
}

void Game::clearInfo()
{
	
}

void Game::getInfo()
{
	if (aggressive)
	{
		for (int i = 0; i < 5; i++)						// deal with enemy hero information
		{
			enemy[i].findItself();
		}
		
		int nine = 0;
		for (int i = 0; i < 5; i++)						// deal with myHero information
		{
			myHero[i].findMyself();
			if (myHero[i].self.level >= 1)
			{
				nine++;
			}
		}
		if (nine == 5)
		{
			allBigNine = INFO->round;
		}
		if (enemyTower == 1)
		{
			allBigNine = 0;
		}
		
		for (int i = 0; i < 5; i++)
		{
			if (enemy[i].shown)
			{
				for (int j = 0; j < 5; j++)
				{
					if (dis2(enemy[i].position, myHero[j].self.pos) <= 144)
					{
						for (int k = 0; k < 5; k++)
						{
							myHero[k].aroundEnemy.push_back(i);
						}
						break;
					}
				}
			}
		}
		
		for (int i = 0; i < 26; i++)					// find monsters and spring or tower
		{
			monster[i].findItself();
		}
		
		for (int i = 0; i < 2; i++)
		{
			myTowerAround[i].clear();
			for (int j = 0; j < 5; j++)
			{
				if (enemy[j].shown && dis2(enemy[j].position, myTowerPos[i]) <= 144)
				{
					myTowerAround[i].push_back(j);
				}
			}
		}
		
		if (myTowerAround[0].size() || myTowerAround[1].size())
		{
			stage = 15;
		}
		else
		if (stage)
		{
			stage--;
		}
	}
	else
	{
		for (int i = 0; i < 5; i++)						// deal with enemy hero information
		{
			enemy[i].findItself();
		}
		bool allNine = true;
		for (int i = 0; i < 5; i++)						// deal with myHero information
		{
			myHero[i].findMyself();
			myHero[i].higherOrder.type = "";
			if (myHero[i].self.level < 8 && i != 4)
			{
				allNine = false;
			}
		}
		if (allNine && allBigNine == 0)
		{
			allBigNine = INFO->round;
		}
		if (enemyTower < 2)
		{
			allBigNine = 0;
		}
		
		for (int i = 0; i < 4; i++)
		{
			myHero[i].aroundEnemy.clear();
		}
		
		for (int i = 0; i < 26; i++)					// find monsters and spring or tower
		{
			monster[i].findItself();
		}
		
		if (INFO->findUnitById(myTowerId[0]) != NULL)
		{
			myTowerHp[0] = INFO->findUnitById(myTowerId[0])->hp;
		}
		else
		{
			myTowerHp[0] = 0;
			myTowerExist[0] = false;
		}
		
		if (INFO->findUnitById(myTowerId[1]) != NULL)
		{
			myTowerHp[1] = INFO->findUnitById(myTowerId[1])->hp;
		}
		else
		{
			myTowerHp[1] = 0;
			myTowerExist[1] = false;
		}
		for (int i = 0; i < 2; i++)
		{
			myTowerAround[i].clear();
			if (myTowerExist[i])
			{
				for (int j = 0; j < 5; j++)
				{
					if (enemy[j].shown && dis2(enemy[j].position, myTowerPos[i]) <= 196)
					{
						myTowerAround[i].push_back(j);
					}
				}
				// to sleepychord
				/*
				myTowerSafeQ[i].push(myTowerAround[i].size());
				myTowerSafe[i] += myTowerAround[i].size();
				if (myTowerSafeQ[i].size() > 200)
				{
					myTowerSafe[i] -= myTowerSafeQ[i].front();
					myTowerSafeQ[i].pop();
				}
				if (myTowerAround[i].size())
				{
					myTowerDanger[i] = 30;
				}
				else
				if (myTowerDanger[i])
				{
					myTowerDanger[i]--;
				}
				*/
			}
		}
		if ((myTowerHp[1] <= 500 && myTowerExist[1]) || !myTowerExist[0])
		{
			myTowerHero[0].clear();
			myTowerHero[1].clear();
			myTowerHero[1].push_back(0);
			myTowerHero[1].push_back(1);
			myTowerHero[1].push_back(2);
			myTowerHero[1].push_back(3);
		}
		else
		if ((myTowerHp[0] <= 500 && myTowerExist[0]) || !myTowerExist[1])
		{
			myTowerHero[0].clear();
			myTowerHero[1].clear();
			myTowerHero[0].push_back(0);
			myTowerHero[0].push_back(1);
			myTowerHero[0].push_back(2);
			myTowerHero[0].push_back(3);
		}
		else
		if (myTowerSafe[1] < myTowerSafe[0])
		{
			myTowerHero[0].clear();
			myTowerHero[1].clear();
			myTowerHero[0].push_back(!myHero[0].dead && myHero[0].self.level >= myHero[1].self.level ? 0: 1);
			myTowerHero[0].push_back(!myHero[2].dead && myHero[2].self.level >= myHero[3].self.level ? 2: 3);
			myTowerHero[1].push_back(myHero[0].dead || myHero[0].self.level < myHero[1].self.level ? 0: 1);
			myTowerHero[1].push_back(myHero[0].dead || myHero[2].self.level < myHero[3].self.level ? 2: 3);
		}
		else
		if (myTowerSafe[1] > myTowerSafe[0])
		{
			myTowerHero[0].clear();
			myTowerHero[1].clear();
			myTowerHero[1].push_back(!myHero[0].dead && myHero[0].self.level >= myHero[1].self.level ? 0: 1);
			myTowerHero[1].push_back(!myHero[2].dead && myHero[2].self.level >= myHero[3].self.level ? 2: 3);
			myTowerHero[0].push_back(myHero[0].dead || myHero[0].self.level < myHero[1].self.level ? 0: 1);
			myTowerHero[0].push_back(myHero[2].dead || myHero[2].self.level < myHero[3].self.level ? 2: 3);
		}
		if (GAME.allBigNine == 0)
		{
			for (int i = 0; i < 5; i++)
			{
				if (enemy[i].shown)
				{
					for (int j = 0; j < 5; j++)
					{
						if (dis2(myHero[j].self.pos, enemy[i].position) <= 144)
						{
							myHero[j].aroundEnemy.push_back(i);
						}
					}
				}
			}
			
			for (int i = 0; i < 4; i++)
			{
				myHero[i].aroundEnemy.clear();
			}
			
			for (int i = 0; i < 2; i++)
			{
				for (int j = 0; j < 5; j++)
				{
					if (enemy[j].shown)
					{
						bool flag = false;
						for (int k = 0; k < myTowerHero[i].size(); k++)
						{
							if (dis2(myHero[myTowerHero[i][k]].self.pos, enemy[j].position) <= 144)
							{
								flag = true;
							}
						}
						if (flag)
						{
							for (int k = 0; k < myTowerHero[i].size(); k++)
							{
								myHero[myTowerHero[i][k]].aroundEnemy.push_back(j);
							}
						}
					}
				}
			}
		}
		else
		{
			for (int i = 0; i < 5; i++)
			{
				if (enemy[i].shown)
				{
					bool flag = false;
					for (int j = 0; j < 4; j++)
					{
						if (dis2(myHero[j].self.pos, enemy[i].position) <= 144)
						{
							flag = true;
						}
					}
					if (flag)
					{
						for (int j = 0; j < 4; j++)
						{
							myHero[j].aroundEnemy.push_back(i);
						}
					}
				}
			}
		}
		if (myTowerAround[0].size() >= 1)
		{
			for (int i = 0; i < myTowerHero[1].size(); i++)
			{
				myHero[myTowerHero[1][i]].aroundEnemy = myTowerAround[0];
			}
		}
		if (myTowerAround[1].size() >= 1)
		{
			for (int i = 0; i < myTowerHero[0].size(); i++)
			{
				myHero[myTowerHero[0][i]].aroundEnemy = myTowerAround[1];
			}
		}
		if (myTowerAround[0].size())
		{
			for (int i = 0; i < myTowerHero[0].size(); i++)
			{
				myHero[myTowerHero[0][i]].aroundEnemy = myTowerAround[0];
			}
		}
		if (myTowerAround[1].size())
		{
			for (int i = 0; i < myTowerHero[1].size(); i++)
			{
				myHero[myTowerHero[1][i]].aroundEnemy = myTowerAround[1];
			}
		}
		
		if (GAME.allBigNine != 0)
		{
			Pos center = Pos(0, 0);
			int size = 0;
			for (int i = 0; i < 4; i++)
			{
				if (!myHero[i].dead)
				{
					center = center + myHero[i].self.pos;
					size++;
				}
			}
			if (size)
			{
				center.x /= size;
				center.y /= size;
				if ((INFO->camp == 0 && center.y < 84) || (INFO->camp == 1 && center.y > 66))
				{
					for (int i = 0; i < 4; i++)
					{
						//myHero[i].aroundEnemy.clear();
					}
				}
			}
		}
		
		getTarget();
	}
}

void Game::getTarget()
{
	targets[0].clear();
	int level = 0;
	for (int i = 0; i < myTowerHero[0].size(); i++)
	{
		level += myHero[myTowerHero[0][i]].self.level;
		myHero[myTowerHero[0][i]].safePoint = myTowerPos[0];
	}
	level /= myTowerHero[0].size();
	if (GAME.allBigNine != 0)
	{
		if (monster[0].consider)
		{
			targets[0].push_back(monsterIndex[15]);
		}
		else
		{
			targets[0].push_back(monsterIndex[16]);
		}
	}
	else
	if (level <= 2)
	{
		targets[0].push_back(monsterIndex[2]);
		targets[0].push_back(monsterIndex[3]);
	}
	else
	if (level <= 4)
	{
		targets[0].push_back(monsterIndex[2]);
		targets[0].push_back(monsterIndex[3]);
		targets[0].push_back(monsterIndex[1]);
	}
	else
	{
		targets[0].push_back(monsterIndex[3]);
		targets[0].push_back(monsterIndex[2]);
		targets[0].push_back(monsterIndex[1]);
	}
	for (int i = 0; i < myTowerHero[0].size(); i++)
	{
		myHero[myTowerHero[0][i]].targets = targets[0];
	}
	
	targets[1].clear();
	level = 0;
	for (int i = 0; i < myTowerHero[1].size(); i++)
	{
		level += myHero[myTowerHero[1][i]].self.level;
		myHero[myTowerHero[1][i]].safePoint = myTowerPos[1];
	}
	level /= myTowerHero[1].size();
	if (GAME.allBigNine != 0)
	{
		if (monster[0].consider)
		{
			targets[1].push_back(monsterIndex[15]);
		}
		else
		{
			targets[1].push_back(monsterIndex[16]);
		}
	}
	else
	if (level <= 6)
	{
		targets[1].push_back(monsterIndex[7]);
		targets[1].push_back(monsterIndex[19]);
	}
	else
	{
		bool allas = true;
		for (int i = 0; i < 5; i++)
		{
			if (enemy[i].known && enemy[i].ATKInterval != 1)
			{
				allas = false;
			}
		}
		if (allas)
		{
			targets[1].push_back(monsterIndex[7]);
			targets[1].push_back(monsterIndex[19]);
		}
		else
		{
			targets[1].push_back(monsterIndex[7]);
			targets[1].push_back(monsterIndex[19]);
			targets[1].push_back(monsterIndex[4]);
			targets[1].push_back(monsterIndex[19]);
		}
	}
	for (int i = 0; i < myTowerHero[1].size(); i++)
	{
		myHero[myTowerHero[1][i]].targets = targets[1];
	}
}

void Game::higherOrder()
{
	for (int i = 0; i < 4; i++)
	{
		myHero[i].findTarget();
	}
	
	for (int j = 0; j < 4; j++)
	{
		if (!myHero[j].canFight)
		{
			int totalSize1 = 0, totalSize2 = 0;
			int targetIndex = index[myHero[j].targets[myHero[j].target]];
			for (int i = 0; i < 4; i++)
			{
				if (dis2(myHero[i].self.pos, monster[targetIndex].position) <= 100)
				{
					totalSize1++;
				}
				if (myHero[i].self.pos == myHero[i].prepareTower[targetIndex])
				{
					totalSize2++;
				}
			}
			if (totalSize1 >= 2 || totalSize2 >= 3 || monster[targetIndex].Hp <= 200)
			{
				myHero[j].canFight = true;
			}
		}
	}
	
	for (int i = 0; i < 4; i++)
	{
		myHero[i].findBlocks();
	}
	
	int maxKilling = 0;
	int maxTotalDamage = 0;
	int attackingNumber = 0;
	int damagePoint[100];
	for (int i = 0; i < 4; i++)
	{
		myHero[i].higherOrder.type = "";
	}
	for (int a = 0; a < myHero[0].power.size(); a++)
	{
		for (int b = 0; b < myHero[1].power.size(); b++)
		{
			for (int c = 0; c < myHero[2].power.size(); c++)
			{
				for (int d = 0; d < myHero[3].power.size(); d++)
				{
					int killing = 0;
					int totalDamage = 0;
					for (int i = 0; i < 100; i++)
					{
						damagePoint[i] = 0;
					}
					if (myHero[0].power[a].name != "")
					{
						damagePoint[myHero[0].power[a].target] += myHero[0].power[a].damage;
					}
					if (myHero[1].power[b].name != "")
					{
						damagePoint[myHero[1].power[b].target] += myHero[1].power[b].damage;
					}
					if (myHero[2].power[c].name != "")
					{
						damagePoint[myHero[2].power[c].target] += myHero[2].power[c].damage;
					}
					if (myHero[3].power[d].name != "")
					{
						damagePoint[myHero[3].power[d].target] += myHero[3].power[d].damage;
					}
					for (int i = 0; i < INFO->units.size(); i++)
					{
						if (INFO->units[i].hp < damagePoint[INFO->units[i].id])
						{
							killing++;
						}
						if (damagePoint[INFO->units[i].id])
						{
							totalDamage += min(damagePoint[INFO->units[i].id], INFO->units[i].hp);
						}
					}
					if (killing > maxKilling && totalDamage > maxTotalDamage)
					{
						maxKilling = killing;
						maxTotalDamage = totalDamage;
						myHero[0].higherOrder.type = myHero[0].power[a].name;
						myHero[0].higherOrder.id = myHero[0].self.id;
						if (myHero[0].power[a].name != "" && myHero[0].power[a].target != myHero[0].targets[myHero[0].target] && INFO->findUnitById(myHero[0].power[a].target)->hp >= damagePoint[myHero[0].power[a].target])
						{
							myHero[0].higherOrder.type = "";
						}
						if (myHero[0].higherOrder.type != "")
						{
							myHero[0].higherOrder.targets.clear();
							myHero[0].higherOrder.targets.push_back(INFO->findUnitById(myHero[0].power[a].target)->pos);
						}
						myHero[1].higherOrder.type = myHero[1].power[b].name;
						myHero[1].higherOrder.id = myHero[1].self.id;
						if (myHero[1].power[b].name != "" && myHero[1].power[b].target != myHero[1].targets[myHero[1].target] && INFO->findUnitById(myHero[1].power[b].target)->hp >= damagePoint[myHero[1].power[b].target])
						{
							myHero[1].higherOrder.type = "";
						}
						if (myHero[1].higherOrder.type != "")
						{
							myHero[1].higherOrder.targets.clear();
							myHero[1].higherOrder.targets.push_back(INFO->findUnitById(myHero[1].power[b].target)->pos);
						}
						myHero[2].higherOrder.type = myHero[2].power[c].name;
						myHero[2].higherOrder.id = myHero[2].self.id;
						if (myHero[2].power[c].name != "" && myHero[2].power[c].target != myHero[2].targets[myHero[2].target] && INFO->findUnitById(myHero[2].power[c].target)->hp >= damagePoint[myHero[2].power[c].target])
						{
							myHero[2].higherOrder.type = "";
						}
						if (myHero[2].higherOrder.type != "")
						{
							myHero[2].higherOrder.targets.clear();
							myHero[2].higherOrder.targets.push_back(INFO->findUnitById(myHero[2].power[c].target)->pos);
						}
						myHero[3].higherOrder.type = myHero[3].power[d].name;
						myHero[3].higherOrder.id = myHero[3].self.id;
						if (myHero[3].power[d].name != "" && myHero[3].power[d].target != myHero[3].targets[myHero[3].target] && INFO->findUnitById(myHero[3].power[d].target)->hp >= damagePoint[myHero[3].power[d].target])
						{
							myHero[3].higherOrder.type = "";
						}
						if (myHero[3].higherOrder.type != "")
						{
							myHero[3].higherOrder.targets.clear();
							myHero[3].higherOrder.targets.push_back(INFO->findUnitById(myHero[3].power[d].target)->pos);
						}
					}
				}
			}
		}
	}
}

void Game::playAlone(PCommand &cmd)
{
	if (aggressive)
	{
		for (int i = 0; i < 5; i++)
		{
			myHero[i].assassinPlayBack(cmd);
		}
	}
	else
	{
		for (int i = 0; i < 4; i++)
		{
			myHero[i].archerPlayAlone(cmd);
		}
		myHero[4].assassinPlayAlone(cmd);
	}
}

void Game::debug()
{
	fstream fout;
	if (INFO->round == 0)
	{
		fout.open("debug.txt", ios::trunc | ios::out);
		fout.close();
	}
	else
	{
		fout.open("debug.txt", ios::app);
		fout << "round " << INFO->round << ", player " << INFO->player << endl << endl;
		if (INFO->round)
			for (int i = 0; i < 5; i++)
			{
				fout << "    " << "myHero " << i << ": " << "Pos(" << myHero[i].self.pos.x << ", " << myHero[i].self.pos.y << "), " << "Hp: " << myHero[i].self["Hp"]->val[0] << ", " << "Mp: " <<  myHero[i].self["Mp"]->val[0] << ", " << "target: " << myHero[i].targets[myHero[i].target] << ", Point: " << myHero[i].self["Exp"]->val[3] << endl;
			}
		fout.close();
	}
}

void MyHero::findMyself()
{
	self = *(INFO->findUnitById(id));
	if (!dead && self.findBuff("Reviving") != NULL)
	{
		GAME.myLiving--;
		dead = true;
	}
	if (dead && self.findBuff("Reviving") == NULL)
	{
		GAME.myLiving++;
		dead = false;
	}
	
	aroundEnemy.clear();			// find enemy around;
	for (int i = 0; i < 5; i++)
	{
		if (enemy[i].shown && dis2(enemy[i].position, self.pos) <= 144)
		{
			aroundEnemy.push_back(i);
		}
	}
	
	justBeaten = false;
	for (int i = 0; i < self["LastHit"]->val.size(); i++)
	{
		if (INFO->round - self["LastHit"]->val[i] <= 2)
		{
			justBeaten = true;
		}
	}
	
	power.clear();				// attack;
	for (int i = 0; i < INFO->units.size(); i++)
	{
		if (INFO->units[i].camp != INFO->camp && INFO->units[i].hp > 0 && !(INFO->units[i].id >= 10 && INFO->units[i].id <= 13) && INFO->units[i].findBuff("Reviving") == NULL)
		{
			Power p;
			p.name = "";
			power.push_back(p);
			if (!justAttacked && dis2(INFO->units[i].pos, self.pos) <= 81)
			{
				p.damage = self["Atk"]->val[0] - INFO->units[i].def;
				p.Mp = 0;
				p.range = self["Range"]->val[0];
				p.name = "Attack";
				p.target = INFO->units[i].id;
				power.push_back(p);
			}
			if (self.canUseSkill(7) && dis2(INFO->units[i].pos, self.pos) <= 81 && (aroundEnemy.size() || (self.mp >= 140 && rand() % 100 > 70 || self.hp <= 100)))
			{
				switch(self.findSkill(7)->level)
				{
					case 0:
						p.damage = 45;
						break;
					case 1:
						p.damage = 80;
						break;
					case 2:
						p.damage = 125;
						break;
				}
				p.Mp = 100;
				p.name = "PiercingArrow";
				p.range = 81;
				p.target = INFO->units[i].id;
				power.push_back(p);
			}
		}
	}
}

void MyHero::findTarget()
{
	if (target > targets.size() - 1)
	{
		target = 0;
	}
	if (monster[GAME.index[targets[target]]].notLive > sqrt(dis2(self.pos, monster[GAME.index[targets[target]]].position)) / sqrt(self.speed))
	{
		target++;
		target %= targets.size();
	}
	if (GAME.allBigNine != 0)
	{
		canFight = false;
	}
	else
	{
		canFight = true;
	}
}

void MyHero::levelUp(PCommand &cmd)
{
	if (aggressive)
	{
		Operation op;
		op.id = id;
		string level[5][10] = {
			"HideLU", "HideLU", "BlinkLU", "HideLU", "FlyingBlade", "FlyingBlade", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"HideLU", "HideLU", "BlinkLU", "HideLU", "FlyingBlade", "FlyingBlade", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"HideLU", "HideLU", "BlinkLU", "HideLU", "FlyingBlade", "FlyingBlade", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"HideLU", "HideLU", "BlinkLU", "HideLU", "FlyingBlade", "FlyingBlade", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"HideLU", "HideLU", "BlinkLU", "HideLU", "FlyingBlade", "FlyingBlade", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
		};
		op.type = level[index][self.level];
		cmd.cmds.push_back(op);
	}
	else
	{
		Operation op;
		op.id = id;
		string level[5][10] = {
			"PALU", "PALU", "PALU", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"PALU", "PALU", "PALU", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"ARLU", "ARLU", "ARLU", "PALU", "PALU", "PALU", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"ARLU", "ARLU", "ARLU", "PALU", "PALU", "PALU", "YellowPoint", "YellowPoint", "YellowPoint", "YellowPoint",
			"BlinkLU", "YellowPoint", "YellowPoint", "YellowPoint", "HideLU", "BlinkLU", "BlinkLU", "YellowPoint", "YellowPoint", "YellowPoint"
		};
		op.type = level[index][self.level];
		cmd.cmds.push_back(op);
	}
}

void MyHero::findBlocks()
{
	blocks.clear();
	blocks.push_back(GAME.myTowerPos[0]);
	blocks.push_back(GAME.myTowerPos[1]);
	for (int i = 0; i < 5; i++)
	{
		if (myHero[i].id != id)
		{
			blocks.push_back(myHero[i].self.pos);
		}
	}
	for (int i = 0; i < 5; i++)
	{
		if (enemy[i].shown)
		{
			blocks.push_back(enemy[i].self.pos);
		}
	}
	for (int i = 3; i < 26; i++)
	{
		if (targets.size() == 0 || targets[target] != monster[i].id)
		{
			blocks.push_back(monster[i].position);
			Pos around = Pos();
			if (dis2(self.pos, monster[i].position) > 8 && monster[i].notLive <= 2)
			{
				for (int j = -3; j <= 3; j++)
				{
					for (int k = -3; k <= 3; k++)
					{
						around.x = monster[i].position.x + j;
						around.y = monster[i].position.y + k;
						if(dis2(around, monster[i].position) <= 8)
						{
							blocks.push_back(around);
						}
					}
				}
			}
		}
	}
	
	if (aggressive)
	{
		if (!canFight)
		{
			for (int i = 0; i < 2; i++)
			{
				if (monster[i].consider && targets[target] != monster[i].id)
				{
					blocks.push_back(monster[i].position);
					Pos around = Pos();
					for (int j = -12; j <= 12; j++)
					{
						for (int k = -12; k <= 12; k++)
						{
							around.x = monster[i].position.x + j;
							around.y = monster[i].position.y + k;
							if(dis2(around, monster[i].position) <= 144)
							{
								blocks.push_back(around);
							}
						}
					}
				}
			}
		}
	}
	else
	{
		if (targets.size() == 0 || targets[target] > 13 || targets[target] < 10)
		{
			for (int i = 0; i < 2; i++)
			{
				if (monster[i].consider && dis2(self.pos, monster[i].position) > 144)
				{
					if ((i == 0 && !canFight) || i == 1)
					{
						blocks.push_back(monster[i].position);
						Pos around = Pos();
						for (int j = -10; j <= 10; j++)
						{
							for (int k = -10; k <= 10; k++)
							{
								around.x = monster[i].position.x + j;
								around.y = monster[i].position.y + k;
								if(dis2(around, monster[i].position) <= 100)
								{
									blocks.push_back(around);
								}
							}
						}
					}
				}
			}
		}
	}
	vector<const PArea*> rains;
	INFO->findAreaByName("RainyPlace", rains);
	for (int i = 0; i < rains.size(); i++)
	{
		if (rains[i]->camp != INFO->camp && !rains[i]->containPos(self.pos) && rains[i]->timeLeft > 1)
		{
			Pos thisPos;
			for (int j = -5; j <= 5; j++)
			{
				for (int k = -5; k <= 5; k++)
				{
					thisPos.x = rains[i]->center.x + j;
					thisPos.y = rains[i]->center.y + k;
					if(dis2(thisPos, rains[i]->center) <= 25)
					{
						blocks.push_back(thisPos);
					}
				}
			}
		}
	}
}

Operation MyHero::attackAt(Pos position)
{
	Operation op;
	op.id = id;
	op.type = "Attack";
	op.targets.push_back(position);
	return op;
}

Operation MyHero::moveTo(Pos position)
{
	Operation op;
	op.id = id;
	op.type = "Move";
	findShortestPath(*MAP, self.pos, position, blocks, op.targets);
	if (op.targets[0].x == -1)
	{
		findShortestPath(*MAP, self.pos, Pos(70, 70), blocks, op.targets);
	}
	return op;
}

Operation MyHero::moveTo(Pos position, int _range)
{
	Operation op;
	op.id = id;
	op.type = "Move";
	op.targets.clear();
	vector<Pos> path;
	findShortestPath(*MAP, self.pos, position, blocks, path);
	for (int i = 0; i < path.size(); i++)
	{
		op.targets.push_back(path[i]);
		if (dis2(path[i], position) <= _range)
			break;
	}
	return op;
}

int scalarProduct(Pos a, Pos b)
{
	return a.x * b.x + a.y * b.y;
}

int vectorProduct(Pos a, Pos b)
{
	return a.x * b.y - a.y * b.x;
}

Pos MyHero::oppositeTo(Pos position)
{
	bool visited[19][19];
	int min = 0x7fffffff;
	Pos dest;
	Pos delta = position - self.pos;
	for (int i = 0; i < 19; i++)
		for (int j = 0; j < 19; j++)
			visited[i][j] = false;
	queue<Pos> q;
	q.push(Pos(0, 0));
	visited[10][10] = true;
	while (!q.empty())
	{
		Pos now = q.front();
		q.pop();
		if (scalarProduct(delta, now) < min)
		{
			min = scalarProduct(delta, now);
			dest = self.pos + now;
		}
		Pos dir[4] = {Pos(1, 0), Pos(0, 1), Pos(-1, 0), Pos(0, -1)};
		for (int i = 0; i < 4; i++)
		{
			Pos next = now + dir[i];
			if (!visited[next.x + 10][next.y + 10] && dis2(next, Pos(0, 0)) <= self.speed
				&& abs(MAP->height[self.pos.x + next.x][self.pos.y + next.y] - MAP->height[self.pos.x][self.pos.y]) <= 1)
			{
				bool flag = true;
				for (int j = 0; j < blocks.size(); j++)
				{
					if (next + self.pos == blocks[j])
					{
						flag = false;
					}
				}
				if (flag)
				{
					visited[next.x + 10][next.y + 10] = true;
					q.push(next);
				}
			}
		}
	}
	return dest;
}

Pos MyHero::oppositeTo(Pos position, int _range)
{
	bool visited[19][19];
	int min = 0x7fffffff;
	Pos dest;
	Pos delta = position - self.pos;
	for (int i = 0; i < 19; i++)
		for (int j = 0; j < 19; j++)
			visited[i][j] = false;
	queue<Pos> q;
	q.push(Pos(0, 0));
	visited[10][10] = true;
	while (!q.empty())
	{
		Pos now = q.front();
		q.pop();
		if (scalarProduct(delta, now) < min && dis2(now + self.pos, position) <= _range)
		{
			min = scalarProduct(delta, now);
			dest = self.pos + now;
		}
		Pos dir[4] = {Pos(1, 0), Pos(0, 1), Pos(-1, 0), Pos(0, -1)};
		for (int i = 0; i < 4; i++)
		{
			Pos next = now + dir[i];
			if (!visited[next.x + 10][next.y + 10] && dis2(next, Pos(0, 0)) <= self.speed
				&& abs(MAP->height[self.pos.x + next.x][self.pos.y + next.y] - MAP->height[self.pos.x][self.pos.y]) <= 1)
			{
				bool flag = true;
				for (int j = 0; j < blocks.size(); j++)
				{
					if (next + self.pos == blocks[j])
					{
						flag = false;
					}
				}
				if (flag)
				{
					visited[next.x + 10][next.y + 10] = true;
					q.push(next);
				}
			}
		}
	}
	return dest;
}

Pos MyHero::oppositeTo(Pos position1, Pos position2)
{
	bool visited[19][19];
	int min = 0x7fffffff;
	Pos dest;
	Pos delta = position1 - position2;
	delta = vectorProduct(position1 - position2, self.pos - position2) >= 0 ? Pos(-delta.y, delta.x) : Pos(delta.y, -delta.x);
	for (int i = 0; i < 19; i++)
		for (int j = 0; j < 19; j++)
			visited[i][j] = false;
	queue<Pos> q;
	q.push(Pos(0, 0));
	visited[10][10] = true;
	while (!q.empty())
	{
		Pos now = q.front();
		q.pop();
		if (scalarProduct(delta, now) < min)
		{
			min = scalarProduct(delta, now);
			dest = self.pos + now;
		}
		Pos dir[4] = {Pos(1, 0), Pos(0, 1), Pos(-1, 0), Pos(0, -1)};
		for (int i = 0; i < 4; i++)
		{
			Pos next = now + dir[i];
			if (!visited[next.x + 10][next.y + 10] && dis2(next, Pos(0, 0)) <= self.speed
				&& abs(MAP->height[self.pos.x + next.x][self.pos.y + next.y] - MAP->height[self.pos.x][self.pos.y]) <= 1)
			{
				visited[next.x + 10][next.y + 10] = true;
				q.push(next);
			}
		}
	}
	return dest;
}

Pos MyHero::avoid(Pos enemyPos, Pos position)
{
	bool visited[19][19];
	double cosTheta[19][19];
	Pos delta = self.pos - position;
	for (int i = 0; i < 19; i++)
		for (int j = 0; j < 19; j++)
			visited[i][j] = false;
	queue<Pos> q;
	q.push(Pos(0, 0));
	visited[10][10] = true;
	Pos dir[4] = {Pos(1, 0), Pos(0, 1), Pos(-1, 0), Pos(0, -1)};
	while (!q.empty())
	{
		Pos now = q.front();
		q.pop();
		cosTheta[now.x + 10][now.y + 10] = (double)scalarProduct(delta, delta + now) / sqrt(scalarProduct(delta + now, delta + now) * scalarProduct(delta, delta));
		for (int i = 0; i < 4; i++)
		{
			Pos next = now + dir[i];
			if (!visited[next.x + 10][next.y + 10] && (self.pos.x + next.x != position.x && self.pos.y + next.y != position.y) && dis2(next, Pos(0, 0)) <= self.speed && vectorProduct(enemyPos - position, delta) * vectorProduct(delta, delta + next) >= 0
				&& abs(MAP->height[self.pos.x + next.x][self.pos.y + next.y] - MAP->height[self.pos.x][self.pos.y]) <= 1)
			{
				bool flag = true;
				for (int j = 0; j < blocks.size(); j++)
				{
					if (next + self.pos == blocks[j])
					{
//						flag = false;
					}
				}
				if (flag)
				{
					visited[next.x + 10][next.y + 10] = true;
					q.push(next);
				}
			}
		}
	}
	Pos dest;
	int minCos = 0x7fffffff;
	for (int i = 0; i < 19; i++)
	{
		for (int j = 0; j < 19; j++)
		{
			if (visited[i][j] && dis2(Pos(i - 10, j - 10), Pos(0, 0)) <= dis2(self.pos, position))
			{
				if (minCos > cosTheta[i - 10][j - 10])
				{
					minCos = cosTheta[i - 10][j - 10];
					dest = Pos(i, j) + self.pos;
				}
			}
		}
	}
	if (minCos != 0x7fffffff)
	{
		return dest;
	}
	else
	{
		for (int i = 0; i < 19; i++)
		{
			for (int j = 0; j < 19; j++)
			{
				if (visited[i][j])
				{
					if (minCos > cosTheta[i - 10][j - 10])
					{
						minCos = cosTheta[i - 10][j - 10];
						dest = Pos(i, j) + self.pos;
					}
				}
			}
		}
	}
	if (minCos != 0x7fffffff)
	{
		return dest;
	}
	else
	{
		return self.pos;
	}
}

Pos MyHero::clockWise(Pos position, bool clock)
{
	double r = 9.0;
	double theta = sqrt((double)self.speed) / r;
	Pos now = self.pos - position;
	Pos next;
	double nowX = now.x * r / sqrt((double)dis2(Pos(0, 0), now));
	double nowY = now.y * r / sqrt((double)dis2(Pos(0, 0), now));
	double deltaX = nowX * cos(clock ? theta : -theta) + nowY * sin(clock ? theta : -theta);
	double deltaY = nowY * cos(clock ? theta : -theta) - nowX * sin(clock ? theta : -theta);
	next.x = deltaX > 0 ? (int)deltaX : (int)deltaX + 1;
	next.y = deltaY > 0 ? (int)deltaY : (int)deltaY + 1;
	return position + next;
}

Operation MyHero::keepDistanceTo(Pos enemyPos, int _range)
{
	if (dis2(self.pos, enemyPos) <= _range)
	{
		vector<Pos> path;
		Operation op;
		op.id = id;
		op.type = "Move";
		op.targets.clear();
		vector<Pos> blocksWithTarget = blocks;
		blocksWithTarget.push_back(enemyPos);
		if (aroundEnemy.size() <= 2)
		{
			findShortestPath(*MAP, self.pos, safePoint, blocksWithTarget, path);
		}
		else
		{
			findShortestPath(*MAP, self.pos, oppositeTo(enemyPos), blocksWithTarget, path);
		}
		for (int i = 0; i < path.size(); i++)
		{
			if (dis2(path[i], enemyPos) > _range)
			{
				break;
			}
			op.targets.push_back(path[i]);
		}
		return op;
	}
	else
  	{
		return moveTo(enemyPos, _range);
	}
}

void MyHero::archerPlayAlone(PCommand &cmd)
{
	int targetId, targetIndex;
	if (!targets.empty())
	{
		targetId = targets[target];
		targetIndex = GAME.index[targets[target]];
	}
	
	if (higherOrder.type != "")
	{
		cmd.cmds.push_back(higherOrder);
		if (higherOrder.type == "Attack")
		{
			justAttacked = 1;
		}
		else
		{
			justAttacked = 0;
		}
		return;
	}
	
	if (aroundEnemy.size())					// teamFight;
	{
		/*
		 if use skill: use;
		 if aeo: avoid;
		 if roshan or tower: avoid;
		 if fight: fight;
		 else: move;
		*/
		
		// require format;
		
		if (self.canUseSkill(9))
		{
			Pos enemyCenter = Pos(0, 0);
			int max = 0;														// max enemy number
			int maxQueue = 0;
			for (int k = 1; k < (1 << aroundEnemy.size()); k++)					// see if enemy is gathering
			{
				bool flag = true;
				int number = 0;
				for (int i = 0; i < aroundEnemy.size(); i++)
					if ((k >> i) & 1 == 1)
						number++;
				for (int i = 0; i < aroundEnemy.size(); i++)
					for (int j = i + 1; j < aroundEnemy.size(); j++)
						if (i != j && ((k >> i) & 1 == 1) && ((k >> j) & 1 == 1) && dis2(enemy[aroundEnemy[i]].position, enemy[aroundEnemy[j]].position) > 100)
							flag = false;
				if (flag && number > max)
				{
					maxQueue = k;
					max = number;
				}
			}
			bool allAr = true;
			if (max >= 1)
			{
				for (int i = 0; i < aroundEnemy.size(); i++)
				{
					if ((maxQueue >> i) & 1 == 1)
					{
						enemyCenter = enemyCenter + enemy[aroundEnemy[i]].position;
						if (enemy[aroundEnemy[i]].self.name != "Archer")
						{
							allAr = false;
						}
					}
				}
				enemyCenter.x /= max;
				enemyCenter.y /= max;
			}
			else
			{
				enemyCenter = Pos(-1, -1);
			}
			
			if (allAr)
			{
				enemyCenter = 1 * self.pos + 9 * enemyCenter;
				enemyCenter.x /= 10;
				enemyCenter.y /= 10;
			}
			else
			{
				enemyCenter = 3 * self.pos + 7 * enemyCenter;
				enemyCenter.x /= 10;
				enemyCenter.y /= 10;
			}
			
			bool alreadyRain = false;
			vector<const PArea*> rains;
			INFO->findAreaByName("RainyPlace", rains);
			for (int i = 0; i < rains.size(); i++)
			{
				if (rains[i]->camp == INFO->camp && rains[i]->containPos(enemyCenter))
				{
					alreadyRain = true;
				}
			}
			if ((!GAME.enemyAggressive && (max >= 2 || rand() % 100 > 50)) ||
				(GAME.enemyAggressive && (max >= 3 || rand() % 100 > 70)) ||
				self.hp < 80)
			{
				if (!alreadyRain && dis2(self.pos, enemyCenter) <= 100)
				{
					Operation op;
					op.id = self.id;
					op.targets.push_back(enemyCenter);
					op.type = "ArrowsRain";
					cmd.cmds.push_back(op);
					justAttacked = 0;
					return;
				}
				else
				{
					cmd.cmds.push_back(moveTo(enemyCenter, 100));
					justAttacked = 0;
					return;
				}
			}
		}
		
		if (self.canUseSkill(7))
		{
			int maxEffect = 0;
			Pos maxPos;
			for (int i = -9; i <= 9; i++)
			{
				for (int j = -9; j <= 9; j++)
				{
					if (dis2(Pos(0, 0), Pos(i, j)) <= 81 && !(i == 0 && j == 0))
					{
						int effect = 0;
						for (int k = 0; k < 5; k++)
						{
							if (enemy[k].shown && PiercingArrow_inRange(Pos(0, 0), Pos(i, j), enemy[k].position - self.pos))
							{
								effect++;
							}
						}
						if (effect > maxEffect)
						{
							maxEffect = effect;
							maxPos = Pos(i, j) + self.pos;
						}
					}
				}
			}
			if (maxEffect >= 1 && (maxEffect >= 2 || rand() % 100 > 60))
			{
				Operation op;
				op.id = id;
				op.targets.push_back(maxPos);
				op.type = "PiercingArrow";
				cmd.cmds.push_back(op);
				justAttacked = 0;
				return;
			}
		}
		
		bool around = false;
		int weakest = -1;
		int weakestNum = 0x7fffffff;
		for (int i = 0; i < aroundEnemy.size(); i++)
		{
			if (enemy[aroundEnemy[i]].shown && enemy[aroundEnemy[i]].self.hp * dis2(enemy[aroundEnemy[i]].position, self.pos) < weakestNum)
			{
				weakest = i;
				weakestNum = enemy[aroundEnemy[i]].self.hp * dis2(enemy[aroundEnemy[i]].position, self.pos);
			}
			if (enemy[aroundEnemy[i]].shown && dis2(enemy[aroundEnemy[i]].position, self.pos) <= 144)
			{
				around = true;
			}
		}
		
		if (!justAttacked && dis2(enemy[aroundEnemy[weakest]].position, self.pos) <= 81)
		{
			cmd.cmds.push_back(attackAt(enemy[aroundEnemy[weakest]].position));
			justAttacked = 1;
		}
		else
		{
			bool affected = false;
			Pos affectSource;
			for (int i = 0; i < 26; i++)
			{
				if (monster[i].consider && !monster[i].notLive && dis2(monster[i].position, self.pos) <= monster[i].range)
				{
					affected = true;
					affectSource = monster[i].position;
				}
			}
			for (int i = 0; i < 5; i++)
			{
				if (index < myHero[i].index && dis2(myHero[i].self.pos, self.pos) <= 9)
				{
					affected = true;
					affectSource = myHero[i].self.pos;
					break;
				}
			}
			vector<const PFlight*> arrows;
			INFO->findFlightByName("SignalArrow", arrows);
			for (int i = 0; i < arrows.size(); i++)
			{
				if (arrows[i]->camp != INFO->camp && dis2(arrows[i]->target, self.pos) <= 25)
				{
					affected = true;
					affectSource = arrows[i]->target;
				}
			}
			vector<const PArea*> rains;
			INFO->findAreaByName("RainyPlace", rains);
			for (int i = 0; i < rains.size(); i++)
			{
				if (rains[i]->camp != INFO->camp && rains[i]->containPos(self.pos))
				{
					affected = true;
					affectSource = rains[i]->center;
				}
			}
			for (int i = 0; i < 5; i++)
			{
				if (enemy[i].shown)
				{
					if (enemy[i].self.canUseSkill(3) && dis2(enemy[i].position, self.pos) <= 25)
					{
						affected = true;
						affectSource = enemy[i].position;
					}
				}
			}
			if (affected && around)
			{
				cmd.cmds.push_back(moveTo(oppositeTo(affectSource)));
			}
			else
			{
				cmd.cmds.push_back(keepDistanceTo(enemy[aroundEnemy[weakest]].position, 81));
			}
			justAttacked = 0;
		}
	}
	else
	if (canFight)
	{
		if (self["Exp"]->val[3])
		{
			levelUp(cmd);
			return;
		}
		if (self.canUseSkill(9) && dis2(self.pos, monster[targetIndex].position) <= 100 && monster[targetIndex].ATK >= 80)
		{
			Operation op;
			op.id = self.id;
			op.type = "ArrowsRain";
			Pos mid = 7 * monster[targetIndex].position + 3 * self.pos;
			mid.x /= 10;
			mid.y /= 10;
			op.targets.push_back(mid);
			cmd.cmds.push_back(op);
			return;
		}
		if (dis2(self.pos, monster[targetIndex].position) <= self.range && INFO->findUnitById(targets[target]) != NULL)
		{
			if (monster[targetIndex].range < self.range)
			{
				if (!justAttacked)					// time to fight;
				{
					if (justBeaten && self.hp <= 155)
					{
						cmd.cmds.push_back(moveTo(oppositeTo(monster[targetIndex].position)));
						justAttacked = 0;
					}
					else
					{
						cmd.cmds.push_back(attackAt(monster[targetIndex].position));
						justAttacked = 1;
					}
				}
				else
				{
					bool affected = false;
					Pos affectSource;
					vector<const PArea*> rains;
					INFO->findAreaByName("RainyPlace", rains);
					for (int i = 0; i < rains.size(); i++)
					{
						if (rains[i]->camp != INFO->camp && rains[i]->containPos(self.pos))
						{
							affected = true;
							affectSource = rains[i]->center;
						}
					}
					if (affected)
					{
						cmd.cmds.push_back(moveTo(oppositeTo(affectSource)));
					}
					else
					{
						if (self.hp > 155)
						{
							if (monster[GAME.index[targets[target]]].direction != monster[GAME.index[targets[target]]].position)
							{
								cmd.cmds.push_back(keepDistanceTo(monster[GAME.index[targets[target]]].direction, 81));
							}
							else
							{
								cmd.cmds.push_back(keepDistanceTo(monster[GAME.index[targets[target]]].position, (9 + sqrt(monster[GAME.index[targets[target]]].speed)) * (9 + sqrt(monster[GAME.index[targets[target]]].speed))));
							}
						}
						else
						{
							cmd.cmds.push_back(moveTo(oppositeTo(monster[GAME.index[targets[target]]].position)));
						}
					}
					justAttacked = 0;
				}
			}
			else
			{
				if (!justAttacked)
				{
					cmd.cmds.push_back(attackAt(monster[targetIndex].position));
					justAttacked = 1;
				}
				else
				{
					if (self.canUseSkill(11))
					{
						Operation op;
						op.id = self.id;
						op.type = "PowerUp";
						cmd.cmds.push_back(op);
						return;
					}
					cmd.cmds.push_back(moveTo(clockWise(monster[targetIndex].position, rand() % 100 > 50)));
					justAttacked = 0;
				}
			}
		}
		else
		{
			if (INFO->findUnitById(targets[target]) != NULL)
			{
				cmd.cmds.push_back(moveTo(monster[targetIndex].position, 81));
			}
			else
			{
				cmd.cmds.push_back(moveTo(monster[targetIndex].position));
			}
			justAttacked = 0;
		}
	}
	else
	{
		if (self["Exp"]->val[3])
		{
			levelUp(cmd);
			return;
		}
		Pos center = Pos(0, 0);
		for (int i = 0; i < 4; i++)
		{
			center = center + myHero[i].self.pos;
		}
		center.x /= 4;
		center.y /= 4;
		if (dis2(self.pos, center) > 81 && dis2(self.pos, center) <= 324)
		{
			cmd.cmds.push_back(moveTo(center));
		}
		else
		{
			cmd.cmds.push_back(moveTo(prepareTower[targetIndex]));
		}
		justAttacked = 0;
	}
}

void MyHero::assassinPlayBack(PCommand &cmd)
{
	if (self["Exp"]->val[3])
	{
		levelUp(cmd);
		return;
	}
	
	targets.clear();
	
	bool allFive = true;
	for (int i = 0; i < 5; i++)
	{
		if (myHero[i].self.level <= 4)
		{
			allFive = false;
		}
	}
	
	if (GAME.allBigNine)
	{
		canFight = false;
		if (monster[1].consider)
		{
			targets.push_back(monsterIndex[16]);
		}
		else
		{
			targets.push_back(monsterIndex[15]);
		}
	}
	else
	{
		canFight = false;
		targets.push_back(monsterIndex[17]);
	}
	
	if (!canFight)
	{
		int total = 0;
		for (int i = 0; i < 5; i++)
		{
			if (dis2(myHero[i].self.pos, monster[GAME.index[targets[target]]].position) <= self.range)
			{
				total++;
			}
		}
		if (total == 5)
		{
			canFight = true;
		}
	}
	
	findBlocks();
	
	if (aroundEnemy.size() && self.canUseSkill(13))
	{
		Operation op;
		op.id = id;
		op.type = "Hide";
		cmd.cmds.push_back(op);
		return;
	}
	
	if (targets[target] == monsterIndex[16] || targets[target] == monsterIndex[15])
	{
		if (dis2(self.pos, monster[GAME.index[targets[target]]].position) <= self.range)
		{
			cmd.cmds.push_back(attackAt(monster[GAME.index[targets[target]]].position));
		}
		else
		{
			bool flag = true;
			for (int i = 0; i < 5; i++)
			{
				if (dis2(myHero[i].self.pos, monster[GAME.index[targets[target]]].position) > 324)
				{
					flag = false;
				}
			}
			if (flag)
			{
				bool use = true;
				for (int i = 0; i < 5; i++)
				{
					if (!myHero[i].self.canUseSkill(13))
					{
						use = false;
					}
				}
				if (use)
				{
					Operation op;
					op.id = id;
					op.type = "Hide";
					cmd.cmds.push_back(op);
					return;
				}
				if (self.findBuff("Hided") != NULL)
				{
					Pos delta[5] = {Pos(0, 1), Pos(1, 0), Pos(0, -1), Pos(-1, 0), Pos(1, 1)};
					cmd.cmds.push_back(moveTo(monster[GAME.index[targets[target]]].position + delta[index]));
					return;
				}
			}
			else
			{
				if (dis2(self.pos, monster[GAME.index[targets[target]]].position) > 324)
				{
					cmd.cmds.push_back(moveTo(monster[GAME.index[targets[target]]].position));
				}
				else
				{
					// stop;
				}
				return;
			}
		}
	}
	else
	{
		if (dis2(self.pos, monster[GAME.index[targets[target]]].position) <= 324 && self.canUseSkill(13) && (targets[target] == monsterIndex[17] || targets[target] == monsterIndex[16] || targets[target] == monsterIndex[15]))
		{
			Operation op;
			op.id = id;
			op.type = "Hide";
			cmd.cmds.push_back(op);
			return;
		}
		
		Pos center = Pos(0, 0);
		for (int i = 0; i < 5; i++)
		{
			center = center + myHero[i].self.pos;
		}
		center.x /= 5;
		center.y /= 5;
		
		if (dis2(self.pos, monster[GAME.index[targets[target]]].position) <= self.range && canFight)
		{
			cmd.cmds.push_back(attackAt(monster[GAME.index[targets[target]]].position));
		}
		else
		{
			if (dis2(self.pos, center) > 144)
			{
				cmd.cmds.push_back(moveTo(center));
			}
			else
			{
				Pos delta[5] = {Pos(0, 1), Pos(1, 0), Pos(0, -1), Pos(-1, 0), Pos(1, 1)};
				cmd.cmds.push_back(assassinMoveTo(monster[GAME.index[targets[target]]].position + delta[index]));
				return;
			}
		}
	}
}

Operation MyHero::assassinMoveTo(Pos position)
{
	Operation op;
	op.id = self.id;
	op.type = "Move";
	if (aggressive)
	{
		findShortestPath(*MAP, self.pos, position, blocks, op.targets);
		if (op.targets[0].x == -1)
		{
			if (dis2(position, monster[GAME.index[monsterIndex[21]]].position) <= self.range)
			{
				if (INFO->camp == 0)
				{
					assassinFindShortestPath(*MAP, self.pos, Pos(18, 5), blocks, op.targets);
				}
				else
				{
					assassinFindShortestPath(*MAP, self.pos, Pos(150 - 18, 150 - 5), blocks, op.targets);
				}
			}
			else
			if (dis2(position, monster[GAME.index[monsterIndex[17]]].position) <= self.range && (self.pos != Pos(18, 5) || self.pos != Pos(150 - 18, 150 - 5)))
			{
				if (INFO->camp == 0)
				{
					findShortestPath(*MAP, self.pos, Pos(18, 5), blocks, op.targets);
				}
				else
				{
					findShortestPath(*MAP, self.pos, Pos(150 - 18, 150 - 5), blocks, op.targets);
				}
			}
			else
			{
				assassinFindShortestPath(*MAP, self.pos, position, blocks, op.targets);
			}
		}
		Pos next;
		bool cant = false;
		for (int i = 0; i < op.targets.size(); i++)
		{
			if (dis2(op.targets[i], self.pos) > 81)
			{
				break;
			}
			next = op.targets[i];
			if ((i >= 1 && abs(MAP->height[op.targets[i].x][op.targets[i].y] - MAP->height[op.targets[i - 1].x][op.targets[i - 1].y]) > 1) || (i == 0 && abs(MAP->height[op.targets[i].x][op.targets[i].y] - MAP->height[self.pos.x][self.pos.y]) > 1))
			{
				cant = true;
			}
		}
		
		if (cant && self.canUseSkill(17))
		{
			op.type = "Blink";
			op.targets.clear();
			op.targets.push_back(next);
		}
	}
	else
	{
		if (self.canUseSkill(13) && !self.canUseSkill(17) && self.mp >= 80 && (dis2(self.pos, monster[GAME.index[targets[target]]].position) >= 324 && abs(MAP->height[monster[GAME.index[targets[target]]].position.x][monster[GAME.index[targets[target]]].position.y] - MAP->height[self.pos.x][self.pos.y]) <= 1))
		{
			op.type = "Hide";
			return op;
		}
		findShortestPath(*MAP, self.pos, position, blocks, op.targets);
		if (op.targets[0].x == -1)
		{
			assassinFindShortestPath(*MAP, self.pos, position, blocks, op.targets);
		}
		
		Pos next;
		bool cant = false;
		for (int i = 0; i < op.targets.size(); i++)
		{
			if (dis2(op.targets[i], self.pos) > 81)
			{
				break;
			}
			next = op.targets[i];
			if (i == op.targets.size() - 1)
			{
				cant = true;
			}
			if ((i >= 1 && abs(MAP->height[op.targets[i].x][op.targets[i].y] - MAP->height[op.targets[i - 1].x][op.targets[i - 1].y]) > 1) || (i == 0 && abs(MAP->height[op.targets[i].x][op.targets[i].y] - MAP->height[self.pos.x][self.pos.y]) > 1))
			{
				cant = true;
			}
		}
		
		if ((cant && self.canUseSkill(17)) || (aroundEnemy.size() && self.canUseSkill(17)))
		{
			op.type = "Blink";
			op.targets.clear();
			op.targets.push_back(next);
		}
	}
	return op;
}


static int assassinFinalAttack = 0;
void MyHero::assassinPlayAlone(PCommand &cmd)
{
	if (self["Exp"]->val[3])
	{
		levelUp(cmd);
		return;
	}
	Pos back;
	
	// assassin find targets;
	if (assassinFinalAttack)
	{
		assassinFinalAttack--;
	}
	long long checkPoint = 0;
	for (int i = 0; i < targets.size(); i++)
	{
		checkPoint *= 30;
		checkPoint += targets[i];
	}
	targets.clear();
	if (self.level <= 3)
	{
		targets.push_back(monsterIndex[20]);
		if (INFO->camp == 0)
		{
			back = Pos(4, 139);
		}
		else
		{
			back = Pos(146, 11);
		}
	}
	else
	if (self.level <= 4)
	{
		targets.push_back(monsterIndex[22]);
		targets.push_back(monsterIndex[22]);
		targets.push_back(monsterIndex[18]);
		targets.push_back(monsterIndex[11]);
		targets.push_back(monsterIndex[18]);
		targets.push_back(monsterIndex[11]);
		targets.push_back(monsterIndex[18]);
		targets.push_back(monsterIndex[11]);
		if (INFO->camp == 0)
		{
			back = Pos(16, 100);
		}
		else
		{
			back = Pos(134, 50);
		}
	}
	else
	if (self.level <= 8)
	{
		targets.push_back(monsterIndex[8]);
		targets.push_back(monsterIndex[21]);
		targets.push_back(monsterIndex[11]);
		targets.push_back(monsterIndex[21]);
		targets.push_back(monsterIndex[14]);
		targets.push_back(monsterIndex[21]);
		if (monster[1].consider && monster[0].consider)
		{
			if (INFO->camp == 0)
			{
				back = Pos(51, 47);
			}
			else
			{
				back = Pos(99, 103);
			}
		}
		else
		if (monster[1].consider)
		{
			if (INFO->camp == 0)
			{
				back = Pos(4, 139);
			}
			else
			{
				back = Pos(146, 11);
			}
		}
		else
		{
			if (INFO->camp == 0)
			{
				back = Pos(51, 47);
			}
			else
			{
				back = Pos(99, 103);
			}
		}
	}
	else
	{
		if (monster[1].consider && monster[0].consider)
		{
			targets.push_back(monsterIndex[11]);
			targets.push_back(monsterIndex[21]);
			targets.push_back(monsterIndex[14]);
			targets.push_back(monsterIndex[15]);
			targets.push_back(monsterIndex[14]);
			targets.push_back(monsterIndex[21]);
			if (INFO->camp == 0)
			{
				back = Pos(10, 61);
			}
			else
			{
				back = Pos(140, 89);
			}
		}
		else
		if (monster[1].consider)
		{
			targets.push_back(monsterIndex[21]);
			if (INFO->camp == 0)
			{
				back = Pos(4, 139);
			}
			else
			{
				back = Pos(146, 11);
			}
		}
		else
		{
			targets.push_back(monsterIndex[21]);
			if (INFO->camp == 0)
			{
				back = Pos(51, 47);
			}
			else
			{
				back = Pos(99, 103);
			}
		}
	}
	
	long long now = 0;
	for (int i = 0; i < targets.size(); i++)
	{
		now *= 30;
		now += targets[i];
	}
	
	if (now != checkPoint)
	{
		target = 0;
	}
	
	if (self.level >= 8)
	{
		int total = 0;
		Pos center = Pos(0, 0);
		int size = 0;
		for (int i = 0; i < 4; i++)
		{
			if (!myHero[i].dead)
			{
				size++;
				center = center + myHero[i].self.pos;
			}
		}
		if (size)
		{
			center.x /= size;
			center.y /= size;
		}
		if (monster[1].consider && self.hp * (self.atk - 15) > monster[1].Hp * (55 - self.def))
		{
			if (GAME.myTower == 2 && GAME.enemyTower < 2)
			{
				int enemyNum = 0;
				bool ok = true;
				for (int i = 0; i < 5; i++)
				{
					if (enemy[i].shown && dis2(self.pos, enemy[i].position) > 144)
					{
						enemyNum++;
					}
					if (dis2(self.pos, enemy[i].position) <= 144)
					{
						ok = false;
					}
				}
				if (enemyNum >= 2 && ok)
				{
					assassinFinalAttack = 20;
				}
				if (assassinFinalAttack)
				{
					targets[target] = monsterIndex[16];
				}
			}
			else
			if (GAME.asTower0Fail)
			{
				targets[target] = monsterIndex[16];
			}
		}
		else
		if (monster[0].consider && self.hp * (self.atk - 15) > monster[0].Hp * (55 - self.def))
		{
			if (GAME.myTower == 2 && GAME.enemyTower < 2)
			{
				int enemyNum = 0;
				bool ok = true;
				for (int i = 0; i < 5; i++)
				{
					if (enemy[i].shown && dis2(self.pos, enemy[i].position) > 144)
					{
						enemyNum++;
					}
					if (dis2(self.pos, enemy[i].position) <= 144)
					{
						ok = false;
					}
				}
				if (enemyNum >= 2 && ok)
				{
					assassinFinalAttack = 20;
				}
				if (assassinFinalAttack)
				{
					targets[target] = monsterIndex[15];
				}
			}
			else
			if (GAME.asTower1Fail)
			{
				targets[target] = monsterIndex[15];
			}
		}
		else
		if (GAME.enemyTower == 2 && size)
		{
			if (monster[1].consider && self.hp * (self.atk - 15) > monster[1].Hp * (55 - self.def) && ((INFO->camp == 0 && center.y < 60) || (INFO->camp == 1 && center.y > 90)))
			{
				GAME.asTower0Fail = 0;
				GAME.asTower1Fail = 1;
				targets[target] = monsterIndex[16];
			}
		}
	}
	
	Pos home;
	if (INFO->camp == 0)
	{
		home = Pos(6, 139);
	}
	else
	{
		home = Pos(144, 11);
	}

	// assassin find targets;
	
	// assassin find blocks;
	findBlocks();
	
	bool danger = false;
	int around = 0;
	for (int i = 0; i < aroundEnemy.size(); i++)
	{
		if (abs(MAP->height[enemy[aroundEnemy[i]].position.x][enemy[aroundEnemy[i]].position.y] - MAP->height[self.pos.x][self.pos.y]) <= 1)
		{
			around++;
		}
	}
	if (around >= 1)
	{
		danger = true;
	}
	
	
	if (!danger)
	{
		if (monster[GAME.index[targets[target]]].notLive - sqrt(dis2(self.pos, monster[GAME.index[targets[target]]].position)) / sqrt(self.speed) > 0)
		{
			cmd.cmds.push_back(assassinMoveTo(back));
			return;
		}
		bool flag = false;
		if (self["LastHit"]->val.size() > targets[target] && self["LastHit"]->val[targets[target]] == INFO->round - 1)
		{
			flag = true;
		}
		if (!flag && monster[GAME.index[targets[target]]].Hp * (monster[GAME.index[targets[target]]].ATK - self.def) / monster[GAME.index[targets[target]]].ATKInterval > self.hp * (self["Atk"]->val[1] - monster[GAME.index[targets[target]]].DEF))
		{
			cmd.cmds.push_back(assassinMoveTo(home));
			return;
		}
		if (flag && monster[GAME.index[targets[target]]].Hp * (monster[GAME.index[targets[target]]].ATK - self.def) / monster[GAME.index[targets[target]]].ATKInterval > self.hp * (self["Atk"]->val[1] - monster[GAME.index[targets[target]]].DEF) + (monster[GAME.index[targets[target]]].ATK - self.def) / monster[GAME.index[targets[target]]].ATKInterval * (self["Atk"]->val[1] - monster[GAME.index[targets[target]]].DEF))
		{
			cmd.cmds.push_back(assassinMoveTo(home));
			return;
		}
		
		if (dis2(monster[GAME.index[targets[target]]].position, self.pos) <= self.range)
		{
			cmd.cmds.push_back(attackAt(monster[GAME.index[targets[target]]].position));
			if (monster[GAME.index[targets[target]]].Hp + monster[GAME.index[targets[target]]].deltaHp <= self.atk - monster[GAME.index[targets[target]]].DEF)
			{
				target++;
				target %= targets.size();
			}
		}
		else
		if (aroundEnemy.size())
		{
			target++;
			target %= targets.size();
		}
		else
		{
			cmd.cmds.push_back(assassinMoveTo(monster[GAME.index[targets[target]]].position));
		}
	}
	else
	{
		if (aroundEnemy.size() || monster[GAME.index[targets[target]]].notLive)
		{
			if (targets[target] == monsterIndex[15])
			{
				bool guard = false;
				for (int i = 0; i < 5; i++)
				{
					if (enemy[i].shown && dis2(enemy[i].position, monster[GAME.index[targets[target]]].position) <= 324)
					{
						guard = true;
					}
				}
				if (guard && monster[1].consider)
				{
					GAME.asTower0Fail = 0;
					GAME.asTower1Fail = 1;
				}
			}
			else
			if (targets[target] == monsterIndex[16])
			{
				bool guard = false;
				for (int i = 0; i < 5; i++)
				{
					if (enemy[i].shown && dis2(enemy[i].position, monster[GAME.index[targets[target]]].position) <= 324)
					{
						guard = true;
					}
				}
				if (guard && monster[0].consider)
				{
					GAME.asTower0Fail = 1;
					GAME.asTower1Fail = 0;
				}
			}
			target++;
			target %= targets.size();
		}
		if (self.canUseSkill(17))
		{
			cmd.cmds.push_back(assassinMoveTo(back));
			return;
		}
		if (self.canUseSkill(13))
		{
			Operation op;
			op.id = self.id;
			op.type = "Hide";
			cmd.cmds.push_back(op);
			return;
		}
		cmd.cmds.push_back(assassinMoveTo(back));
	}
}

void Enemy::findItself()
{
	for (int i = 0; i < INFO->units.size(); i++)
	{
		if (INFO->units[i].id == id)				// online update information;
		{
			self = INFO->units[i];
			if (!known)								// record information;
			{
				switch (self.typeId)				// record attack interval;
				{
					case 0:
						ATKInterval = 2;
						break;
					case 1:
						ATKInterval = 2;
						break;
					case 2:
						ATKInterval = 1;
						break;
				}
				known = true;
			}
			if (shown)								// if shown last turn;
			{
				direction = self.pos - position;
			}
			position = self.pos;
			Hp = self["Hp"]->val[0];
			Mp = self["Mp"]->val[0];
			shown++;
			if (notLive)							// information of enemy living;
			{
				notLive = 0;
				GAME.enemyLiving++;
			}
			if (self.findBuff("Reviving") != NULL && !notLive)
			{
				notLive = self.findBuff("Reviving")->timeLeft;
				GAME.enemyLiving--;
			}
			return;
		}
	}
	shown = 0;										// offline update information;
	// require a position guess method;
	if (known)
	{
		Hp = (Hp >= self["Hp"]->val[1]) ? self["Hp"]->val[1] : (Hp + self["Hp"]->val[2]);
		Mp = (Mp >= self["Mp"]->val[1]) ? self["Mp"]->val[1] : (Mp + self["Mp"]->val[2]);
	}
	if (notLive)			// if enemy not alive;
	{
		notLive--;
		if (notLive == 0)	// enemy reviving;
		{
			GAME.enemyLiving++;
			// require a position guess method;
		}
	}
	return;
}

bool Enemy::facingTo(Pos position)
{
	Pos delta = position - self.pos;
	return delta.x * direction.x + delta.y * direction.y > 0;
}

void Monster::findItself()
{
	if (id >= 16)
	{
		for (int i = 0; i < INFO->units.size(); i++)
		{
			if (INFO->units[i].id == id)				// online update information;
			{
				PUnit self = INFO->units[i];
				position = self.pos;
				direction = position;
				
				bool goBack = true;
				for (int j = 0; j < 5; j++)
				{
					if (dis2(INFO->findUnitById(myHero[j].id)->pos, initPos) <= 324)
					{
						goBack = false;
					}
				}
				
				if (goBack)
				{
					vector<Pos> path;
					findShortestPath(*MAP, self.pos, initPos, path);
					for (int i = 0; i < path.size(); i++)
					{
						if (dis2(path[i], self.pos) > speed)
						{
							break;
						}
						direction = path[i];
					}
				}
				Hp = self["Hp"]->val[0];
				if (self.findBuff("Reviving") != NULL)	// monster living data;
				{
					notLive = self.findBuff("Reviving")->timeLeft;
					Hp = self["Hp"]->val[1];
				}
				else
				{
					notLive = 0;
				}
				return;
			}
		}
		// offline update information;
		position = initPos;
		direction = position;
		Hp = (Hp + deltaHp >= HpMax) ? HpMax : (Hp + deltaHp);
		if (notLive)
		{
			notLive--;
		}
		return;
	}
	else
	if (id <= 13)
	{
		if (!consider)								// already no such tower;
			return;
		// online update information;
		for (int i = 0; i < 5; i++)					// see if my hero around tower but it has been taken down;
		{
			if (consider && dis2(myHero[i].self.pos, position) < myHero[i].self.view && INFO->findUnitById(id) == NULL && abs(MAP->height[position.x][position.y] - MAP->height[myHero[i].self.pos.x][myHero[i].self.pos.y]) <= 1)	// taken down last turn;
			{
				GAME.enemyTower--;
				consider = false;
				return;
			}
			else
			if (consider && dis2(myHero[i].self.pos, position) < 144 && abs(MAP->height[position.x][position.y] - MAP->height[myHero[i].self.pos.x][myHero[i].self.pos.y]) <= 1)
			{
				Hp = (*INFO->findUnitById(id))["Hp"]->val[0];
				return;
			}
		}
		if (consider)								// offline update information;
		{
			Hp = (Hp + deltaHp >= HpMax) ? HpMax : (Hp + deltaHp);
			return;
		}
	}
}

bool Monster::facingTo(Pos _position)
{
	Pos delta = _position - position;
	if (delta.x * direction.x >= 0 && delta.y * direction.y >= 0)
		return true;
	else
		return false;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	//操作包括:使用技能(类型编号与技能的类型编号相同)、移动 (Move,类型编号23)、停止(Stop,类型编号24)。对于任意一个操作,你需要给出它的实施者编号、操作类型(类型编号或名称)以及目标位置列表(对于需要给出目标位置的操作,必须给出正确的目标位置,其中除了移动外的操作的目标位置列表中只能包含一个元素;不需给出目标位置 的操作,目标位置列表应当为空)。注意,操作实施者编号必须为己方单位的id,每个己方单位每回合需要且仅需要给出一个操作,且该操作的类型 必须为其实施者可以实施的。对于目标位置列表,逻辑将只保留有效部分(后面多余的部分将被舍弃)。若某个己方单位没有给出操作或给出的操作 不合法,将被置为Stop(停止)。 如果你的AI出现编译错误、 运行时崩溃、 超时(每回合时限0.1s)或进行了任何系统调用,则会被直接判负。
	cmd.cmds.clear();
	MAP = &map;
	INFO = &info;
	srand((unsigned int)time(NULL));
	if (info.round == 0)
	{
		for (int i = 0; i < MAP->playerIds.size(); i++)
		{
			if (MAP->playerIds[i] != -1 && MAP->playerIds[i] != 1260)
			{
				if ((MAP->playerIds[i] == 1179 || // 7
					 MAP->playerIds[i] == 1212 || // yellowmeng
					MAP->playerIds[i] == 1229 || // nbajiaoshi
					MAP->playerIds[i] == 1180 || // cenyk
					MAP->playerIds[i] == 1329 || // interesting
					MAP->playerIds[i] == 1214) && INFO->camp == 0) // sleepychord
				{
					aggressive = false;
				}
			}
		}
		GAME.initial(cmd);
	}
	else //正式回合
	{
		if (aggressive)
		{
			GAME.clearInfo();
			GAME.getInfo();
			GAME.playAlone(cmd);
		}
		else
		{
			GAME.clearInfo();
			GAME.getInfo();
			GAME.higherOrder();
			GAME.playAlone(cmd);
		}
	}
//	GAME.debug();
}

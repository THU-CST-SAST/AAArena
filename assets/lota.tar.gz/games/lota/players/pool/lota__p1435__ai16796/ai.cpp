#include "sdk.h"

bool in_attack_range(const PUnit &t, const Pos& tar)
{
    return dis2(t.pos, tar) <= t.range;
}

int cal_distance(const PUnit a, const PUnit b){
	Pos p1 = a.pos;
	Pos p2 = b.pos;
	return (p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y);
}

int player;

vector <PUnit> monster;
vector <PUnit> my_archer;
vector <PUnit> my_assassin;
vector <PUnit> my_fighter;

vector <PUnit> en_archer;
vector <PUnit> en_assassin;
vector <PUnit> en_fighter;

PUnit my_spring(0,0,0,0,0,0);
vector <PUnit> my_tower;
PUnit en_spring(0,0,0,0,0,0);
vector <PUnit> en_tower;

typedef vector<const PUnit*> PUnits;

void init_Round(const PMap &map, const PPlayerInfo &info, PCommand &cmd){

        for (int i = 0; i < info.units.size(); i ++)
        {
            if (info.units[i].player == player)
            {
                Operation op;
                op.id = info.units[i].id;
                //if (op.id % 3 == 0)
                    op.type = "ChooseArcher";
                //if (op.id % 3 == 1)
                  //  op.type = "ChooseFighter";
                //if (op.id % 3 == 2)
                  //  op.type = "ChooseAssassin";
                op.targets.clear();
                cmd.cmds.push_back(op);
            }
        }	
}

void go_to_spring(const PMap &map, PUnit unit, PCommand &cmd){
	 Operation op;
     op.id = unit.id;
     op.type = "Move";
     findShortestPath(map, unit.pos, en_spring.pos, op.targets);
    // op.targets.push_back(en_spring.pos);
     cmd.cmds.push_back(op);
}

/*void go_to_tower(PUnit unit, PCommand &cmd){
	 Operation op;
     op.id = unit.id;
     op.type = "Move";
     op.targets.push_back(en_tower.pos);
}*/

void split_info(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
	monster.clear();
	my_archer.clear();
	my_assassin.clear();
	my_fighter.clear();
	my_tower.clear();

	en_archer.clear();
	en_assassin.clear();
	en_fighter.clear();
	en_tower.clear();

	player = info.player;

	for(int i = 0; i < info.units.size(); i ++){
		if(info.units[i].player == -1)
			monster.push_back(info.units[i]);
		if(info.units[i].player == player){
			if(info.units[i].typeId == 0)
				my_fighter.push_back(info.units[i]);
			if(info.units[i].typeId == 1)
				my_archer.push_back(info.units[i]);
			if(info.units[i].typeId == 2)
				my_assassin.push_back(info.units[i]);
			if(info.units[i].typeId == 3)
				my_tower.push_back(info.units[i]);
			if(info.units[i].typeId == 4)
				my_spring = info.units[i];
		}
		if(info.units[i].player != player){
			if(info.units[i].typeId == 0)
				en_fighter.push_back(info.units[i]);
			if(info.units[i].typeId == 1)
				en_archer.push_back(info.units[i]);
			if(info.units[i
				].typeId == 2)
				en_assassin.push_back(info.units[i]);
			if(info.units[i].typeId == 3)
				en_tower.push_back(info.units[i]);
			if(info.units[i].typeId == 4)
				en_spring = info.units[i];
		}
	}
}

/*void archer_attack_monster(PUnit archer, PUnit monster){
	int safedistance = 0;
	if(PUnit.typeId == 6 || PUnit.typeId == 8 || PUnit.typeId == 9 || PUnit.typeId == 11 ) //dog, wolf, stoneman, roshan
		safedistance = 16;
	else //bow, dragon
		safedistance = 48;

	int dis = cal_distance(archer, monster);

	if(dis > safedistance){
		Operation op;
		op.id = archer.id;
		op.type = "Attack";
		op.typeId = 0;
		op.targets.push_back(monster.pos);
	}

	if()

}*/

void archer_upgrade_skill(PUnit archer, PCommand &cmd){
	Operation op;
	op.id = archer.id;
	if(archer.level <= 2)
		op.type = "PALU";
	if(archer.level >= 3 && archer.level <= 5)
		op.type = "ARLU";
	if(archer.level >= 6 && archer.level <= 8)
		op.type = "PULU";
	if(archer.level == 9)
		op.type = "YellowPoint";
	cmd.cmds.push_back(op);

}

bool in_attack_range(PUnit a, PUnit target){
	if(cal_distance(a,target) <= a.range)
		return true;
	return false;
}

const PUnit* belongs(int id, PUnits& units) //找出unit组成的vector中包含指定id的unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

void archer_attack(const PMap &map, const PPlayerInfo &info, PCommand &cmd, PUnit archer, PUnit target){
	Operation op;
	vector<const PSkill*> useSkill;
    for (int i = 0; i < archer.skills.size(); i ++){
        const PSkill* ptr = &(archer.skills[i]);
        if (ptr->isHeroSkill() && archer.canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(info, archer.id, ptr->typeId, ptr_foe); //寻找可用技能
            if (belongs(target.id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }

	if(in_attack_range(archer,target)){	
    	if (useSkill.size()){ //策略：优先使用技能
       		const PSkill* ptr = useSkill[rand()%useSkill.size()];
       		op.type = ptr->name;
        	if (ptr->needTarget())
            	op.targets.push_back(target.pos);
   		}
    	else{
			op.type = "Attack";
        	op.targets.push_back(target.pos);
		}
	}
	else{
		op.type = "Move";
        findShortestPath(map, archer.pos, target.pos, op.targets);
	}
	cmd.cmds.push_back(op);
}

void mission_allot(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
	for(int i = 0; i < my_archer.size(); i ++)
		if (my_archer[i]["Exp"]->val[3]) //优先升级技能
    {
        archer_upgrade_skill(my_archer[i], cmd);
    } 

    int total_level = 0;
    for(int i = 0; i < my_archer.size(); i ++)
    	total_level += my_archer[i].level;

    PUnit target(0,0,0,0,0,0);

    bool find_target = false;

    if(total_level >= 40)
    	 for(int i = 0; i < en_tower.size(); i ++)
    		if(!en_tower[i].findBuff("Reviving")){
    			target = en_tower[i];
    			break;
    		}
    else {
    	for(int i = 0; i < en_fighter.size(); i ++)
    			if(!en_fighter[i].findBuff("Reviving")){
    				target = en_fighter[i];
    				find_target = true;
    				break;
    		}
    	if( ! find_target){
    		for(int i = 0; i < en_assassin.size(); i ++)
    			if(!en_assassin[i].findBuff("Reviving")){
    				target = en_assassin[i];
    				find_target = true;
    				break;
    		}
    	}
    	if( ! find_target){
    		for(int i = 0; i < en_archer.size(); i ++)
    			if(!en_archer[i].findBuff("Reviving")){
    				target = en_archer[i];
    				find_target = true;
    				break;
    		}
    	}
    	if(!find_target){
    			target = en_spring;
    			find_target = true;
    	}
    }
    for(int i = 0; i < my_archer.size(); i ++)
   		archer_attack(map,info,cmd,my_archer[i],target);

}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    int player = info.player;
    cmd.cmds.clear();
    if (info.round == 0){
    	init_Round(map,info,cmd);
    }
    else
    {
    	split_info(map,info,cmd);
        
        mission_allot(map,info,cmd);

          /*  if (info.units[i].player == player)
            {
                const PUnit &t = info.units[i];
                bool fighting = false;
                Operation op;
                op.id = t.id;

                if (t.skills[0].cd == 0)//attack
                {
                    for (int j = 0; j < info.units.size(); j ++)
                        if (info.units[j].player != player && !info.units[j].findSkill("Reviving")
                                && info.units[j].hp > 0)//enemy
                        {
                            if (in_attack_range(t, info.units[j].pos))
                            {
                                op.type = "Attack";
                                op.targets.push_back(info.units[j].pos);
                                fighting = true;
                                break;
                            }
                        }
                }
                
                if (!fighting)
                {
                    Pos tower = info.player ? Player0_tower_pos[1] : Player1_tower_pos[1];
                    if (!in_attack_range(t, tower))
                    {
                        op.type = "Move";
                        findShortestPath(map, t.pos, tower, op.targets);
                    }
                }
                cmd.cmds.push_back(op);
            }*/
    }
}

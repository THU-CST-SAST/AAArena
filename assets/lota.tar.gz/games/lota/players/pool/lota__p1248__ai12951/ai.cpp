#include "sdk.h"
#include<ctime>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<fstream>
#include<iomanip>

//ofstream fout("debug.log");

//��Ϣ
PMap MAP;
PPlayerInfo INFO;
PCommand CMD;

//����Ӣ����Ϣ
struct heroINFO{
	int id;
	int v; //��Ұ�еĵ�λ���
	Pos validPos[130]; //����λ��
	int prevID[130],dir[130],nVP;
}HERO[5];
int numHERO;

int blocked[160][160]; //��ͼ��λ
double spfaResult[160][160]; //spfa���

void chooseHero() //��0�غ�ѡ��Ӣ��
{
    int heroType[5]={1,1,1,1,1}; //��սʿ 
    for(int i=0;i<INFO.units.size();++i) {
		if (INFO.units[i].name[0]!='C')
			continue;
        Operation op;
        if(heroType[i]==0)
            op.type="ChooseAssassin";
        else if(heroType[i]==1)
            op.type="ChooseFighter";
        else if(heroType[i]==2)
            op.type="ChooseArcher";
        op.targets.clear();
        op.id=INFO.units[i].id;
        CMD.cmds.push_back(op); 
    }
}

void initHero() //��1�غϳ�ʼ��Ӣ��
{
	int id;
	numHERO=0;
    for(int i=0;i<INFO.units.size();++i) {
		if (INFO.units[i].name[0]=='T' || INFO.units[i].name[0]=='S')
			continue;
		id=INFO.units[i].id;
		HERO[numHERO++].id=id;
    }
}


void actionZero() //��0�غ���Ϊ
{
	srand(unsigned(time(0)));
	chooseHero();
}

void actionOne() //��1�غ���Ϊ
{
	initHero();
}

bool operator< (Pos a, Pos b) {
	if (a.x>b.x) return 0;
	if (a.y>b.y) return 0;
	if (a.x==b.x && a.y==b.y) return 0;
	return 1;
}

bool operator> (Pos a, Pos b) {
	if (b<a) return 1;
	return 0;
}

void swap(Pos &a, Pos &b) {
	Pos c;
	c=a;
	a=b;
	b=c;
}

void calBlock() //���㿨λ��
{
	memset(blocked,0,sizeof(blocked));
	for (int i=0; i<INFO.units.size(); i++) 
		blocked[INFO.units[i].pos.x][INFO.units[i].pos.y]=1;
}

void calHero() //ÿ�غϳ�ʼ��Ӣ��
{
	for(int i=0;i<INFO.units.size();++i) {
		for (int j=0;j<=4;j++)
			if (HERO[j].id==INFO.units[i].id)
				HERO[j].v=i;
	}
}

int legalSquare(Pos a, Pos b) //���α߽��Ƿ�ȫ���Ϸ������ҳ��Ϸ�����
{
	int connect;
	int rx,ry;
	if (a.x<=b.x)
		rx=1;
    else 
		rx=-1;
    if (a.y<=b.y)
		ry=1;
	else  
		ry=-1;
	connect=1;
	for (int i=a.x+rx; rx*i<=rx*b.x; i+=rx) {
		if (blocked[i][a.y])
			{ connect=0; break; }
		if (abs(MAP.height[i][a.y] - MAP.height[i-rx][a.y])>=2) 
			{ connect=0; break; }
	}
	if (connect)
	for (int i=a.y+ry; ry*i<=ry*b.y; i+=ry) {
		if (blocked[b.x][i])
			{ connect=0; break; }
		if (abs(MAP.height[b.x][i] - MAP.height[b.x][i-ry])>=2) 
			{ connect=0; break; }
	}
	if (connect) return 1;
	connect=1;
	for (int i=a.y+ry; ry*i<=ry*b.y; i+=ry) {
		if (blocked[a.x][i])
			{ connect=0; break; }
		if (abs(MAP.height[a.x][i] - MAP.height[a.x][i-ry])>=2) 
			{ connect=0; break; }
	}
	if (connect)
	for (int i=a.x+rx; rx*i<=rx*b.x; i+=rx) {
		if (blocked[i][b.y])
			{ connect=0; break; }
		if (abs(MAP.height[i][b.y] - MAP.height[i-rx][b.y])>=2) 
		    { connect=0; break; }
	}
  	if (connect) return 2;
	return 0;
}

void findValidPos() //Ѱ�ҿ���λ��
{
	Pos q[130],nowp;
	double dis[130];
	int prev[130],dir[130],s,t,d;
	int pass[20][20];
	for (int I=0;I<=4;I++) {
		memset(pass,0,sizeof(pass));
	    q[0]=INFO.units[HERO[I].v].pos;
		dis[0]=0;
		prev[0]=-1;
		pass[10][10]=1;
		t=s=0;
		do {
		    for (int i=-5; i<=5; i++) {
			    for (int j=-5; j<=5; j++) {
					nowp=q[t]+Pos(i,j);
				    if (!checkPos(nowp))
						continue;
				    if (blocked[nowp.x][nowp.y])
						continue;
					if (pass[nowp.x-q[0].x+10][nowp.y-q[0].y+10])
						continue;
				    if (dis[t]+sqrt(i*i+j*j) > sqrt(INFO.units[HERO[I].v].speed))
						continue;
					d=legalSquare(q[t],nowp);
					if (!d)
						continue;
				    s++;
					q[s]=nowp;
					dis[s]=dis[t]+sqrt(i*i+j*j);
					prev[s]=t;
					dir[s]=d;
					pass[nowp.x-q[0].x+10][nowp.y-q[0].y+10]=1;
			    }
		    }
		t++;
		} while (t<=s);
		HERO[I].nVP=s;
		for (int i=0;i<=s;i++) {
			HERO[I].validPos[i]=q[i];
			HERO[I].prevID[i]=prev[i];
			HERO[I].dir[i]=dir[i];
		}
	}
}

void spfa(Pos b) //spfa��Ŀ������̾���
{
	int dx[8]={-1,-1,0,1,1,1,0,-1}; 
	int dy[8]={0,1,1,1,0,-1,-1,-1};
	Pos q[90000],nowp;
	double dis;
	int pass[151][151],s,t,d;
	memset(pass,0,sizeof(pass));
	for (int i=0;i<=150;i++)
		for (int j=0;j<=150;j++)
			spfaResult[i][j]=-1;
	s=t=0;
	pass[b.x][b.y]=1;
	spfaResult[b.x][b.y]=0;
	q[0]=b;
	do {
		for (int i=0; i<=7; i++) {
			nowp=q[t]+Pos(dx[i],dy[i]);
			if (!checkPos(nowp))
				continue;
			if (blocked[nowp.x][nowp.y])
				continue;
			if (pass[nowp.x][nowp.y])
				continue;
			d=legalSquare(q[t],nowp);
			if (!d)
				continue;
			dis= sqrt(dx[i]*dx[i]+dy[i]*dy[i]);
			if (pass[nowp.x][nowp.y] && spfaResult[q[t].x][q[t].y]+dis >= spfaResult[nowp.x][nowp.y])
                continue;
            s++;
			q[s]=nowp;
            spfaResult[nowp.x][nowp.y] = spfaResult[q[t].x][q[t].y]+dis;
			pass[nowp.x][nowp.y]=1;
		}
		t++;
	} while (t<=s);
}

void actionStop(int heroID) //����ֹͣ����
{
	Operation op;
	op.type="Stop";
	op.targets.clear();
	op.id=heroID;
	CMD.cmds.push_back(op); 
}

void actionMove(Pos target, int targetID, int heroID) //�����ƶ�����
{
	Pos q[20],prevPos,nowPos;
	int l,nowID,prevID,rx,ry;
	if (target == INFO.units[HERO[heroID].v].pos) {
		actionStop(heroID);
		return;
	}
	Operation op;
	op.type="Move";
	op.targets.clear();
	op.id=HERO[heroID].id;
	q[0]=target;
	l=0;
	nowID=targetID;
	nowPos=HERO[heroID].validPos[targetID];
	for (prevID=nowID,nowID=HERO[heroID].prevID[nowID]; nowID!=-1 ; prevID=nowID,nowID=HERO[heroID].prevID[nowID]) {
		prevPos=HERO[heroID].validPos[prevID];
		nowPos=HERO[heroID].validPos[nowID];
		if (prevPos.x<=nowPos.x) rx=1;
		else rx=-1;
		if (prevPos.y<=nowPos.y) ry=1;
		else ry=-1;
		if (HERO[heroID].dir[prevID]==2) {
			for (int i=prevPos.x+rx; rx*i<=rx*nowPos.x; i+=rx) 
				q[++l]=Pos(i,prevPos.y);
			for (int i=prevPos.y+ry; ry*i<=ry*nowPos.y; i+=ry)
				q[++l]=Pos(nowPos.x,i);
		}
		if (HERO[heroID].dir[prevID]==1) {
			for (int i=prevPos.y+ry; ry*i<=ry*nowPos.y; i+=ry)
				q[++l]=Pos(prevPos.x,i);
			for (int i=prevPos.x+rx; rx*i<=rx*nowPos.x; i+=rx) 
				q[++l]=Pos(i,nowPos.y);
		}
	}
	for (int i=l; i>=0; i--)  {
		op.targets.push_back(q[i]);
	}
	for (int i=0;i<op.targets.size();i++)
	CMD.cmds.push_back(op); 
}

void pointMove(Pos target, int heroID) //�����������ƶ�
{
	double minDis;
	Pos minPos;
	int minId;
	spfa(target);
	minDis=99999;
	for (int i=0; i<=HERO[heroID].nVP; i++) {
		if (spfaResult[HERO[heroID].validPos[i].x][HERO[heroID].validPos[i].y] > -0.5 && spfaResult[HERO[heroID].validPos[i].x][HERO[heroID].validPos[i].y] < minDis) {
			minDis=spfaResult[HERO[heroID].validPos[i].x][HERO[heroID].validPos[i].y];
			minPos=HERO[heroID].validPos[i];
			minId=i;
		}
	}
	if (minDis>10000)
		actionStop(heroID);
    else
		actionMove(minPos,minId,heroID);
}

void init(const PMap &map, const PPlayerInfo &info) //��ʼ��
{
    MAP=map;
    INFO=info;
	CMD.cmds.clear();
	if (INFO.round == 0)
        actionZero();
    if (INFO.round == 1)
		actionOne();
	calBlock();
	calHero();
	findValidPos();
}

void action(PCommand &cmd) {
    cmd=CMD;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    init(map, info); //��ʼ�� 
    if (info.round > 0)
        pointMove(Pos(145,5),0);
    action(cmd); //���ض��� 
}

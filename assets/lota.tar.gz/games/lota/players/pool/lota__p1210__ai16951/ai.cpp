  
#include "sdk.h"
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <algorithm>
#include <stdlib.h> 
using namespace std;

class GameData
{
public:

	GameData(const PMap* _map = NULL, const PPlayerInfo* _info = NULL):
		map(_map), info(_info), myHeros(), myTowers(),enemysInit(), 
		enemys(), revivingTime(), enemysRating(),towerLeft_Enemy(2),
		target(), block(), gameState(-1), block_InitAccount(0), 
		level_average(0),beatBack(false)
		{
			for(int i = 0;i < 5;i++)
			{
				already[i] = false;
				level_EnemyHero[i] = 0;
			}
		}
public:
	void SetMapAndInfo(const PMap* _map, const PPlayerInfo* _info)
	{
		map = _map;
		info = _info;
	}
public:
	static int Range2OfAUnit[12];//储存某一单位的射程的平方，下标为unit的typeid
	const PMap* map;			//储存游戏地图
	const PPlayerInfo* info;	//储存游戏局面信息
	vector<PUnit> myHeros;		//储存我方英雄信息
	double level_average;		//我方英雄的平均等级
	vector<int> exp_sum;		//我方英雄每回合的经验总值
	vector<PUnit> myTowers;		//储存我方防御塔信息
	bool already[5];			//我方英雄是否已行动
	vector<PUnit> enemysInit;	//储存初始化时敌方英雄，野怪，敌方塔的信息
	vector<PUnit> enemys;		//储存当前敌方英雄，野怪，敌方塔的信息
	vector<int> revivingTime;	//敌方复活时间
	vector<int> enemysRating;	//0代表优先攻击，1代表正常，1000代表不攻击
	int towerLeft_Enemy;		//敌方塔的存活数量
	vector<PUnit> target[5];	//储存我方英雄的目标
	vector<Pos> block[5];		//储存障碍点
	int gameState;				//储存游戏状态
	bool beatBack;				//储存当前是否属于反击状态
	int block_InitAccount;		//障碍点初始化数量
	int level_EnemyHero[5];		//敌方英雄的等级单独保存，根据id的顺序排序
	int HerosNearAUnit(PUnit& unit);//统计某一单位附近的我方英雄数量

};
int GameData::Range2OfAUnit[12]= {64, 81, 25, 100, 50, 0, 81, 81, 81, 81, 81, 81};

//声明函数指针类型
typedef bool (*Update)(vector<PUnit>&);
typedef bool (*rule)(vector<PUnit>&);
typedef void (*action)(vector<PUnit>&, PCommand*);

//常量宏定义
#define UpdateState_number	6
#define State_number		6
#define rule_number			2
#define startGame			0
#define skillLUP			1	
#define fight				2
#define attackTower			3
#define targetDied			4
#define defendTower			5
#define LEVEL_TOGETHER		0
#define LEVEL_2OR3			0
#define LEVEL_ALONE			5
#define LEVEL_ATTACTTOWER	5
#define LEVEL_DEFENDTOWER	0
//有关UpdateState的声明
bool UpdateState_gameStart(vector<PUnit>& heros);
bool UpdateState_skillLU(vector<PUnit>& heros);
bool UpdateState_attackMonster(vector<PUnit>& heros);
bool UpdateState_attackTower(vector<PUnit>& heros);
bool UpdateState_targetDied(vector<PUnit>& heros);
bool UpdateState_defendTower(vector<PUnit>& heros);
//有关rule的声明
bool rule_gameStart(vector<PUnit>& heros);
bool rule_skillLU(vector<PUnit>& heros);
bool rule_attackMonster(vector<PUnit>& heros);
bool rule_attackTower_0(vector<PUnit>& heros);
bool rule_attackTower_1(vector<PUnit>& heros);
bool rule_targetDied(vector<PUnit>& heros);
bool rule_defendTower_0(vector<PUnit>& heros);
bool rule_defendTower_1(vector<PUnit>& heros);
//有关Act的声明
void Act_gameStart(vector<PUnit>& heros, PCommand* cmd);
void Act_skillLU(vector<PUnit>& heros, PCommand* cmd);
void Act_attackMonster(vector<PUnit>& heros, PCommand* cmd);
void Act_attackTower_0(vector<PUnit>& heros, PCommand* cmd);
void Act_attackTower_1(vector<PUnit>& heros, PCommand* cmd);
void Act_targetDied(vector<PUnit>& heros, PCommand* cmd);
void Act_defendTower_0(vector<PUnit>& heros, PCommand* cmd);
void Act_defendTower_1(vector<PUnit>& heros, PCommand* cmd);

//其他函数
///////////////////////////////.........主体函数..........//////////////////
void	Init();												//第0回合初始化一系列数据
void	Cmd_Input(PCommand* cmd);							//第一回合后决定怎么行动
///////////////////////////////.....UpdateData相关函数.......//////////////
void	UpdateData(vector<PUnit>& heros);					//同步数据
void	UpdateData_heros();									//英雄数据更新
void	UpdateData_enemys();								//敌方数据更新
void	UpdateData_target();								//目标更新
void	UpdateData_revivingTime();							//复活时间更新
void    UpdateData_blocks();								//障碍点数据更新
void	UpdateData_already();								//已行动数据更新
void	UpdateData_state(vector<PUnit>& heros);				//更新游戏状态
void	UpdateUnit(PUnit& unit);							//更新某一单位的数据
void    UpdateData_myTower();								//我方防御塔数据更新
////////////////////////////.....相关辅助函数....../////////////////////////
int		rankOfHero(PUnit& hero);							//返回英雄的下标
int		rankOfEnemy(PUnit& enemy);							//返回敌方单位在vector中的下标
void	 rule_action(vector<PUnit>& heros, PCommand* cmd);	//规则—行动一一对应
int		Eva(vector<PUnit>& heros, PUnit& enemy);		//评估函数
int		Eva(PUnit& hero, Pos& pos);					//评估箭雨释放点的位置的函数
void	ChooseHero(PCommand* cmd);							//选择五弓手
PUnit	ChooseEnemy(vector<PUnit>& heros);					//选择攻击哪个敌人
PUnit	ChooseNearbyEnemy(vector<PUnit>& heros, PUnit &unit);//选择在某一单位附近的敌人
Pos 	ChooseArrowsRainPoint(PUnit& hero);					//选择箭雨释放的位置
void	Find_Enermy(vector<PUnit>& heros, PCommand *cmd);	//给每个英雄选择攻击哪个敌人
void	Find_NearbyEnermy(vector<PUnit>& heros, PCommand *cmd, PUnit &unit);	//在某一个单位附近给每个英雄选择攻击哪个敌人
//bool    ShouldUseArrowsRain(PUnit& hero, PUnit& enemy);		//判断是否应该使用箭雨技能。
PSkill	ChooseSkill(PUnit& hero, PUnit& enemy);				//选择使用哪个技能
void	Move(PUnit& hero, PUnit& enemy, PCommand* cmd);		//风筝走位
void    Wait(PUnit& hero, PUnit& unit, PCommand *cmd);		//在某一单位附近等待我方英雄
void	addBlocksNearAUnit(PUnit& unit, vector<Pos>& blocks);				//在某一单位的攻击范围内添加障碍点 
void	AttackMonsterAlone(PUnit& hero, PUnit& enemy, PCommand* cmd);		//英雄单独攻击指定敌人
void	AttackMonsterAlone_1(PUnit& hero, PUnit& enemy, PCommand* cmd);	//单独刷怪_顺便刷视野中的其它怪
void	AttackMonsterAlone_2(PUnit& hero, PUnit& enemy, PCommand* cmd);	//单独刷怪_顺便刷视野中的其它英雄
bool	AisInRangeOfB(PUnit& A, PUnit& B);									//判断A是否在B的攻击范围内。
bool	AisInViewOfB(PUnit& A, PUnit& B);									//判断A是否在B的视野范围内。
//定义near(适合位置）为：(A能两回合内走到B攻击范围内。)
bool	AisNearB(PUnit& A, PUnit& B);										//判断A是否在适合位置
bool	AInPosIsNearB(PUnit& A, Pos pos, PUnit& B);							//判断A在pos点时是否处于适合位置
void	MoveOutOfView(PUnit &hero, PUnit& unit, PCommand* cmd);				//逃出该单位的攻击范围。
void	MoveAroundAUnit(PUnit &hero, PUnit& unit, PCommand* cmd);			//围着某一单位转圈
void	Move_special(PUnit &hero, PUnit& unit, PCommand* cmd);				//朝目标移动但是不进入其视野范围内。
double	Length(vector<Pos> &_path);											//计算某一路径的实际移动长度
int		dotProduct(Pos A,Pos B);											//计算点积
Pos		FindPointNearUnit_random(PUnit& hero, PUnit& unit);					//在A附近随机寻找一个相对B合适的点
Update updates[UpdateState_number] = {UpdateState_gameStart, 
										UpdateState_skillLU,
										UpdateState_attackMonster, 
										UpdateState_attackTower, 
										UpdateState_targetDied, 
										UpdateState_defendTower
									};
int updates_State[UpdateState_number] = {0, 1, 2, 3, 4, 5};
int updateRank[UpdateState_number] = {0,1,4,3,5,2};

rule rules[State_number][rule_number] = {
	{rule_gameStart},
	{rule_skillLU},
	{rule_attackMonster},
	{rule_attackTower_0, rule_attackTower_1},
	{rule_targetDied},
	{rule_defendTower_0, rule_defendTower_1}
};

action actions[State_number][rule_number] = {
	{Act_gameStart},
	{Act_skillLU},
	{Act_attackMonster},
	{Act_attackTower_0, Act_attackTower_1},
	{Act_targetDied},
	{Act_defendTower_0, Act_defendTower_1}
};

int ruleCount[State_number] = {1, 1, 1, 2, 1, 2};
//给不同规则下优先级
int ruleRank[State_number][rule_number] ={
	{0},
	{0},
	{0},
	{0,1},
	{0},
	{0,1}
};

GameData* data = new GameData();

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{

	data->SetMapAndInfo(&map, &info);
	Cmd_Input(&cmd);
}

void Cmd_Input(PCommand* cmd){

	cmd->cmds.clear();
	UpdateData(data->myHeros);
	rule_action(data->myHeros, cmd);

	//删除后期增加的障碍点
	for(int j = 0; j < 5; j ++)
	{
		while(data->block[j].size() > data->block_InitAccount)
		{
			data->block[j].pop_back();
		}
	}
}
//更新data
void UpdateData(vector<PUnit>& heros){

	UpdateData_heros();
	UpdateData_already();
	if(data->info->round > 0){
		UpdateData_enemys();
		UpdateData_target();
		UpdateData_blocks();
	}
	UpdateData_revivingTime();	
	UpdateData_state(data->myHeros);
}
//更新gameState
void UpdateData_state(vector<PUnit>& heros){
	if((heros.size() == 0) && (data->info->round > 0)){
		data->gameState = -1;
		return;
	}
	for(int i = 0;i < UpdateState_number;i++)
	{
		if(updates[updateRank[i]](heros))
		{
			data->gameState = updateRank[i];

			break;
		}
	}
}
//根据实现预定好的优先级判定当前符合哪种行动，并做出决策。
void rule_action(vector<PUnit>& heros, PCommand* cmd)
{

	int state = data->gameState;
	if(state == -1) return;
	for(int i = 0;i < ruleCount[state];i++)
		if(rules[state][ruleRank[state][i]](heros))
		{
			actions[state][ruleRank[state][i]](heros, cmd);

			break;
		}
}
   
//开局状态
bool UpdateState_gameStart(vector<PUnit>& heros)
{

	if(data->info->round == 0)
		return true;
	return false;
}
//技能升级状态
bool UpdateState_skillLU(vector<PUnit>& heros)
{

	if(! heros.size()) return false;
	for(int i = 0;i < heros.size();i++)
	{
		//攻击范围内内有敌人，则不升级
		for(int j = 0; j < data->enemys.size(); j ++)
			if(AisInRangeOfB(data->enemys[j], heros[i]))
				break;
		//否则若可以升级则升级
		if(heros[i]["Exp"]->val[3] > 0)
			return true;
	}
	return false;
}
//刷野状态
bool UpdateState_attackMonster(vector<PUnit>& heros)
{

	if(! heros.size()) return false;
	return true;
}
//平均超过LEVEL_ATTACKTOWER级则进入推塔状态
bool UpdateState_attackTower(vector<PUnit>& heros)
{

	if(! heros.size()) return false;
	int round = data->info->round;
	if((round > 400) || data->beatBack) return true;
	//判断是否该反击攻塔
	int level_enemy = 0;
	for(int i = 0; i < 5; i ++)
	{
		level_enemy += data->level_EnemyHero[i];
	}
	if(data->exp_sum.size() >= 10 && (level_enemy > 25 || round >= 500))
	{
		//计算击杀敌方经验
		int exp_enemy = 0, exp_max = 0;
		for(int i = 0; i < 5; i ++)
		{
			int exp_tmp = 50 * (1 + data->level_EnemyHero[i]); 
			exp_enemy += exp_tmp;
			if(exp_tmp > exp_max)
			{
				exp_max = exp_tmp;
			}
		}
		exp_enemy = (exp_enemy - exp_max) * 9 / 10;
	
		if(((data->exp_sum[round] - data->exp_sum[round-10]) > exp_enemy) && rule_defendTower_0(heros))
		{
			data->beatBack = true;
			return true;
		}
	}
	int hp_average = 0, mp_sum = 0;
	for(int i = 0;i < heros.size();i++)
	{
		hp_average += heros[i]["Hp"]->val[0];
		mp_sum += heros[i]["Mp"]->val[0];
	}
	hp_average /= heros.size();
	if((data->level_average >= LEVEL_ATTACTTOWER) && (hp_average >= 110) && mp_sum >= 500)
	{
		return true;
	}
	return false;
}
//状态转变：目标死亡状态
bool UpdateState_targetDied(vector<PUnit>& heros)
{

	if(heros.size() == 0) return false;
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		if(! data->target[index].size())  continue;
		PUnit enemy = data->target[index][0];
		if(! AisInViewOfB(enemy, heros[index])) continue;
		if(enemy.findBuff("Reviving") != 0)
		{
			return true;
		}
		for(int i = 0;i < heros.size();i++)
		{

			if(!data->info->findUnitById(enemy.id) && dis2(enemy.pos, heros[i].pos) <= heros[i].view)
			{
				return true;
			}
			if(enemy.isHero() && !data->info->findUnitById(enemy.id))
			{
				return true;
			}
		}
	}
	return false;
}
//状态转变：防守我方防御塔
bool UpdateState_defendTower(vector<PUnit>& heros)
{

	if(heros.size() == 0) return false;
	if(rule_defendTower_0(heros)) return true;
	else if(data->level_average >= LEVEL_DEFENDTOWER)
	{
		return true;
	}
	return false;
}
//开局状态：round==0
bool rule_gameStart(vector<PUnit>& heros)
{
	return true;
}
//action:初始化一些数据；选取英雄
void Act_gameStart(vector<PUnit>& heros, PCommand* cmd)
{
	Init();
	ChooseHero(cmd);
}
//技能升级状态：
bool rule_skillLU(vector<PUnit>& heros)
{
	return true;
}
//action:技能升级，其他英雄继续
void Act_skillLU(vector<PUnit>& heros, PCommand* cmd)
{

	static int skill_0[] = {10,10,10,8,8,8,19,19,19,19};
	static int skill_1[] = {8,8,8,10,10,10,19,19,19,19};
	static int skill_2[] = {19,19,19,19,19,19,19,12,12,12};
	int* skill[] = {skill_0, skill_1, skill_0, skill_1, skill_2};
	vector<PUnit> herosLeft;
	for(int i = 0;i < heros.size();i++)
		if(heros[i]["Exp"]->val[3] > 0)
		{
			Operation op;
			op.id = heros[i].id;
			int index = rankOfHero(heros[i]);
			op.typeId = skill[index][heros[i].level];
			cmd->cmds.push_back(op);
			data->already[index] = true;
		}
		else
			herosLeft.push_back(heros[i]);
	data->gameState = -1;
	UpdateData_state(herosLeft);
	rule_action(herosLeft, cmd);
}

//rule_刷野（包括敌方英雄）
bool rule_attackMonster(vector<PUnit>& heros)
{
	return true;
}
//action
void Act_attackMonster(vector<PUnit>& heros, PCommand* cmd)
{

	Find_Enermy(heros, cmd);
	for(int j = 0;j < heros.size();j++)
	{
		int index = rankOfHero(heros[j]);
		if(!data->already[index])
		{
			AttackMonsterAlone_1(heros[j], data->target[index][0], cmd);
		}
	}
}
//推塔状态：
bool rule_attackTower_0(vector<PUnit>& heros)
{
	return true;
}
//action
void Act_attackTower_0(vector<PUnit>& heros, PCommand* cmd)
{

	int rankOfTower = 0;
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		data->enemysRating[index] = 1;
		data->target[index].clear();
		if(data->towerLeft_Enemy == 2)
		{
			data->target[index].push_back((data->enemys[0]));
			rankOfTower = 0;
		}
		else
		{
			data->target[index].push_back((data->enemys[1]));
			rankOfTower = 1;
		}
		UpdateUnit(data->target[index][0]);
	}
	//当前可攻塔人数大于等于2则开始攻塔
	if(data->HerosNearAUnit(data->target[0][0]) > 3)
	{
		data->enemysRating[rankOfTower] = 0;
		for(int j = 0;j < heros.size();j++)
		{
			int index = rankOfHero(heros[j]);
			if(!data->already[index])
			{
				AttackMonsterAlone_2(heros[j], data->target[index][0], cmd);
			}
		}
	}
	else
	{
		data->enemysRating[rankOfTower] = 1000;
		for(int j = 0;j < heros.size(); j++)
		{
			int index = rankOfHero(heros[j]);
			if(data->already[index] == 0)
			{
				if(AisInRangeOfB(heros[j], data->target[0][0]))
				{
					AttackMonsterAlone_2(heros[j], data->target[0][0], cmd);
				}
				else if(AisNearB(heros[j], data->target[0][0]))
				{
					Wait(heros[j], data->target[0][0], cmd);
				}
				else
				{
					Move_special(heros[j], data->target[0][0], cmd);
				}
			}
		}
	}
}
//推塔时刷野等待
bool rule_attackTower_1(vector<PUnit>& heros)
{
	return true;
}
//action
void Act_attackTower_1(vector<PUnit>& heros, PCommand* cmd)
{
	int rankOfTower = 0;
	for(int j = 0; j < heros.size(); j ++)
	{
		if(data->towerLeft_Enemy == 2)
		{
			rankOfTower = 1;
		}
		else
		{
			rankOfTower = 0;
		}
	}
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		data->enemysRating[index] = 1;
		data->target[index].clear();
	}
	Find_NearbyEnermy(heros, cmd, data->enemys[rankOfTower]);
	for(int j = 0;j < heros.size();j++)
	{
		int index = rankOfHero(heros[j]);
		if(!data->already[index])
		{
			AttackMonsterAlone_1(heros[j], data->target[index][0], cmd);
		}
	}
}
//目标死亡状态：
bool rule_targetDied(vector<PUnit>& heros)
{
	return true;
}
//action
void Act_targetDied(vector<PUnit>& heros, PCommand* cmd)
{

	for(int j = 0; j < heros.size(); j ++)
	{
		int index_hero = rankOfHero(heros[j]);
		if(! data->target[index_hero].size())  continue;
		int index_enemy = rankOfEnemy(data->target[index_hero][0]);
		int typeId = data->target[index_hero][0].typeId;
		//计算第i个英雄的目标是否死亡
		bool flag = false;
		if(data->enemys[index_enemy].findBuff("Reviving") != 0)
		{
			flag = true;
		}
		else 
		{
			for(int i = 0;i < heros.size();i++)
			{
				PUnit unit = data->target[index_hero][0];
				if(!data->info->findUnitById(unit.id) 
					&& ((dis2(unit.pos, heros[i].pos) <= heros[i].view) || unit.isHero()))
				{
					flag = true;
					break;
				}
			}
		}

		if(! flag) continue;
		//若目标死亡
		switch(typeId)
		{
		case 0: case 1: case 2:
			data->revivingTime[index_enemy] = 5*(data->target[index_hero][0].level+1);
			break;
		case 3:
			data->revivingTime[index_enemy] = 2000;
			data->enemysRating[index_enemy] = 1000;
			data->towerLeft_Enemy -= 1;
			data->beatBack = false;
			//为防止意外，推掉一个塔时将另一个塔“复活”
			if(data->towerLeft_Enemy == 0)
			{
				data->towerLeft_Enemy = 1;
				data->enemys[! index_enemy] = data->enemysInit[! index_enemy];
				data->enemysRating[! index_enemy] = 1;
			}
			break;
		case 4: case 5:
			data->revivingTime[index_enemy] = 2000;
			break;
		case 6: case 7:
			data->revivingTime[index_enemy] = 20;
			break;
		case 8: case 9:
			data->revivingTime[index_enemy] = 25;
			break;
		case 10:
			data->revivingTime[index_enemy] = 60;
			break;
		default:
			data->revivingTime[index_enemy] = 80;
			break;
		}
		if(typeId != 3) data->enemysRating[index_enemy] = 1;
		data->target[index_hero].clear();
	}
	for(int i = 3;i < UpdateState_number;i++)
	{
		if(updates[updateRank[i]](heros))
		{
			data->gameState = updateRank[i];
			break;
		}
	}
	rule_action(heros, cmd);
}
//防御塔状态
bool rule_defendTower_0(vector<PUnit>& heros)
{
	if(data->enemys.size() == 0 || data->myHeros.size() == 0)
		return false;
	bool flag = false;
	for(int i = 0; i < data->enemys.size(); i ++)
	{
		if(data->enemys[i].isHero())
		{
			for(int j = 0; j < data->myTowers.size(); j ++)
			{
				if(AisInViewOfB(data->enemys[i], data->myTowers[j]))
				{
					return true;
				}
			}
		}
	}
	return false;
}
//action_防御塔
void Act_defendTower_0(vector<PUnit>& heros, PCommand* cmd)
{

	vector<PUnit> enemys_nearMyTower;
	for(int i = 0; i < data->enemys.size(); i ++)
	{
		PUnit enemy = data->enemys[i];
		if(enemy.isHero())
		{
			for(int k = 0; k < data->myTowers.size(); k ++)
			{
				if(AisInViewOfB(enemy, data->myTowers[k]))
				{
					enemys_nearMyTower.push_back(enemy);
				}
			}
		}
	}
	if(enemys_nearMyTower.size() == 0)
	{
		Act_defendTower_1(heros, cmd);
		return;
	}
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		data->enemysRating[index] = 1;
		data->target[index].clear();
		data->target[index].push_back(enemys_nearMyTower[0]);
		if(! data->already[index])
		{
			AttackMonsterAlone_2(heros[j], enemys_nearMyTower[0], cmd);
		}
	}
}
//防御塔时刷野状态
bool rule_defendTower_1(vector<PUnit>& heros)
{
	return true;
}
//action_防御塔时刷野（两个塔时2,3分防，否则只全防一个）
void Act_defendTower_1(vector<PUnit>& heros, PCommand* cmd)
{

	for(int j = 0; j < heros.size(); j ++)
	{
		data->enemysRating[rankOfHero(heros[j])] = 1;
		data->target[rankOfHero(heros[j])].clear();
	}
	//平均7级则不刷怪，朝塔走去
	if(data->level_average == 7)
	{
		if(data->myTowers.size() == 1)
		{
			PUnit tower = data->myTowers[0];
			for(int j = 0;j < heros.size(); j++)
			{
				int index = rankOfHero(heros[j]);
				if(data->already[index] == 0)
				{
					Operation op;
					op.id = heros[j].id;
					op.type = "Move";
					findShortestPath(*data->map, heros[j].pos, tower.pos, data->block[index], op.targets);
					cmd->cmds.push_back(op);
					data->already[index] = true;
				}
			}
		}
		else
		{
			vector<PUnit> heros_tmp;
			for(int i = 0; i < heros.size()/2; i ++)
			{
				heros_tmp.push_back(heros[i]);
			}
			PUnit tower = data->myTowers[0];
			for(int j = 0;j < heros_tmp.size(); j++)
			{
				int index = rankOfHero(heros_tmp[j]);
				if(data->already[index] == 0)
				{
					Operation op;
					op.id = heros_tmp[j].id;
					op.type = "Move";
					findShortestPath(*data->map, heros_tmp[j].pos, tower.pos, data->block[index], op.targets);
					cmd->cmds.push_back(op);
					data->already[index] = true;
				}
			}
			heros_tmp.clear();
			for(int i = heros.size()/2; i < heros.size(); i ++)
			{
				heros_tmp.push_back(heros[i]);
			}
			tower = data->myTowers[1];
			for(int j = 0;j < heros_tmp.size(); j++)
			{
				int index = rankOfHero(heros_tmp[j]);
				if(data->already[index] == 0)
				{
					Operation op;
					op.id = heros_tmp[j].id;
					op.type = "Move";
					findShortestPath(*data->map, heros_tmp[j].pos, tower.pos, data->block[index], op.targets);
					cmd->cmds.push_back(op);
					data->already[index] = true;
				}
			}
		}
	}
	else if(data->myTowers.size() == 1)
	{
		PUnit tower = data->myTowers[0];
		Find_NearbyEnermy(heros, cmd, tower);
		Act_attackMonster(heros, cmd);
	}
	else
	{
		vector<PUnit> heros_tmp;
		for(int i = 0; i < heros.size()/2; i ++)
		{
			heros_tmp.push_back(heros[i]);
		}
		Find_NearbyEnermy(heros_tmp, cmd, data->myTowers[0]);
		heros_tmp.clear();
		for(int i = heros.size()/2; i < heros.size(); i ++)
		{
			heros_tmp.push_back(heros[i]);
		}
		Find_NearbyEnermy(heros_tmp, cmd, data->myTowers[1]);
		Act_attackMonster(heros, cmd);
	}
}
int forbidden[] = {24,34,25,27,35,28};
//初始化
void Init()
{
	for(int j = 0;  j < 5; j ++)
	{
		data->block[j].push_back(Player0_spring_pos[0]);
		data->block[j].push_back(Player1_spring_pos[0]);
		for(int i = 0;i < 2;i++)
		{
			data->block[j].push_back(Player0_tower_pos[i]);
			data->block[j].push_back(Player1_tower_pos[i]);
		}
		if(data->info->camp)
		{
			int x = 22;
			for(int y = 72; y <= 89; y ++)
			{
				data->block[j].push_back(Pos(x, y));
			}
		}
		else
		{
			int x = 128;
			for(int y = 61; y <= 78; y++)
			{
				data->block[j].push_back(Pos(x, y));
			}
		}
	}
	data->block_InitAccount  = data->block->size();
	if(data->info->camp)
	{
		for(int i = 0;i < 2;i++)
		{
			data->enemysInit.push_back(PUnit(3, 10+i, 0, 0, Player0_tower_pos[i].x, Player0_tower_pos[i].y));
			data->myTowers.push_back(PUnit(3, 12+i, 1, 1, Player1_tower_pos[i].x, Player1_tower_pos[i].y));
		}
		data->enemysInit.push_back(PUnit(4, 14, 0, 0, Player0_spring_pos[0].x, Player0_spring_pos[0].y));
		for(int i = 0;i < 5;i++)
		{
			data->enemysInit.push_back(PUnit(1, 39+i, 0, 0, Player0_hero_initial_pos[i].x, Player0_hero_initial_pos[i].y));
		}
	}
	else{
		for(int i = 0;i < 2;i++)
		{
			data->enemysInit.push_back(PUnit(3, 12+i, 1, 1, Player1_tower_pos[i].x, Player1_tower_pos[i].y));
			data->myTowers.push_back(PUnit(3, 10+i, 0, 0, Player0_tower_pos[i].x, Player0_tower_pos[i].y));
		}
		data->enemysInit.push_back(PUnit(4, 15, 1, 1, Player1_spring_pos[0].x, Player1_spring_pos[0].y));
		for(int i = 0;i < 5;i++)
		{
			data->enemysInit.push_back(PUnit(1, 44+i, 1, 1, Player1_hero_initial_pos[i].x, Player1_hero_initial_pos[i].y));
		}
	}
	for(int i = 0;i < 23;i++)
	{
		if(i < 8)
		{
			data->enemysInit.push_back(PUnit(6, 16+i, 2, 2, Dog_pos[i].x, Dog_pos[i].y));
		}
		else if(i < 14)
		{
			data->enemysInit.push_back(PUnit(7, 16+i, 2, 2, Bow_pos[i-8].x, Bow_pos[i-8].y));
		}
		else if(i < 18)
		{
			data->enemysInit.push_back(PUnit(8, 16+i, 2, 2, Wolf_pos[i-14].x, Wolf_pos[i-14].y));
		}
		else if(i < 20)
		{
			data->enemysInit.push_back(PUnit(9, 16+i, 2, 2, StoneMan_pos[i-18].x, StoneMan_pos[i-18].y));
		}
		else if(i < 22)
		{
			data->enemysInit.push_back(PUnit(10, 16+i, 2, 2, Dragon_pos[i-20].x, Dragon_pos[i-20].y));
		}
		else
		{
			data->enemysInit.push_back(PUnit(11, 16+i, 2, 2, Roshan_pos[0].x, Roshan_pos[0].y));
		}
	}
	for(int i = 0;i < data->enemysInit.size();i++)
	{
		data->enemysRating.push_back(1);
		data->revivingTime.push_back(0);
		data->enemysInit[i].hp = 0;
		data->enemysInit[i].max_hp = 0;
	}
	data->enemysInit[0].hp = 1000;
	data->enemysInit[1].hp = 1000;
	data->enemysInit[2].hp = 2000;
	data->enemysRating[0] = 1000;
	data->enemysRating[1] = 1000;
	data->enemysRating[2] = 1000;
	data->enemysInit[30].hp = 1200;
	for(int i = 0;i < 6;i++)
	{
		UpdateData_enemys();
		PUnit enemy(0,forbidden[i],0,0,0,0);
		data->enemysRating[rankOfEnemy(enemy)] = 1000;
	}
}
//五弓手
void ChooseHero(PCommand* cmd)
{
	for(int i = 0;i < data->info->units.size();i++)
	{
		const PUnit& unit = data->info->units[i];
		if(unit.camp == data->info->camp && unit.typeId == 5)
		{
			Operation op;
			op.id = unit.id;
			op.type = "ChooseArcher";
			cmd->cmds.push_back(op);
		}
	}
}
//英雄下标
int rankOfHero(PUnit& hero)
{
	for(int i = 0;i < 5;i++)
		if(data->myHeros[i].id == hero.id)
			return i;
}
//敌人下标
int rankOfEnemy(PUnit& enemy)
{
	for(int i = 0;i < data->enemys.size();i++)
		if(data->enemys[i].id == enemy.id)
		{
			return i;
		}
}
//更新Enemys
void UpdateData_enemys()
{

	data->enemys.clear();
	for(int i = 0;i < data->enemysInit.size();i++)
	{
		const PUnit* unit = data->info->findUnitById(data->enemysInit[i].id);
		if(unit != NULL)
		{
			data->enemys.push_back(*unit);
		}
		else
		{
			data->enemys.push_back(data->enemysInit[i]);
		}
	}
	//更新敌方英雄等级
	for(int i = 0; i < 5; i ++)
	{
		for(int j = 0; j < data->enemys.size(); j ++)
		{
			PUnit enemy = data->enemys[j];
			if(data->info->findUnitById(enemy.id) 
				&& enemy.id == 44 - 5 * data->info->camp + i 
				&& data->level_EnemyHero[i] < enemy.level)
			{
				data->level_EnemyHero[i] = enemy.level;
				break;
			}
		}
	}

}
//更新我方英雄信息
void UpdateData_heros()
{
	data->myHeros.clear();
	for(int i = 0;i < data->info->units.size();i++)
	{
		const PUnit& unit = data->info->units[i];
		if(unit.camp == data->info->camp && unit.isHero())
			data->myHeros.push_back(unit);
	}
	double level = 0;
	int exp_sum = 0;

	for(int i = 0; i < data->myHeros.size(); i ++)
	{
		level += data->myHeros[i].level;
		exp_sum += data->myHeros[i].exp;
	}
	if(data->myHeros.size() == 0)
	{
		data->level_average = 0;
	}
	else
	{
		data->level_average = level / data->myHeros.size();
	}
	data->exp_sum.push_back(exp_sum);

}	
//我方防御塔数据更新
void UpdateData_myTower()
{
	data->myTowers.clear();
	for(int i = 0;i < data->info->units.size();i++)
	{
		const PUnit& unit = data->info->units[i];
		if((unit.camp == data->info->camp) && (unit.typeId == 3) && (unit.hp > 0) && (unit.max_hp > 0)
			&& (data->info->findUnitById(unit.id) != 0))
		{
			data->myTowers.push_back(unit);
		}
	}
}
//目标更新
void UpdateData_target()
{

	for(int j = 0; j < 5; j ++)
	{
		for(int i = 0; i < data->target[j].size(); i ++)
		{
			int index_enemy = rankOfEnemy(data->target[j][i]);
			data->target[j][i] = data->enemys[index_enemy];
		}
	}
}
//复活时间更新
void UpdateData_revivingTime()
{

	//changed
	for(int i = 0;i < data->enemys.size();i++)
	{
		if(data->info->findUnitById(data->enemys[i].id))
		{
			if(data->enemys[i].findBuff("Reviving"))
				data->revivingTime[i] = data->enemys[i].findBuff("Reviving")->timeLeft;
			else
				data->revivingTime[i] = 0;
		}
		else if(data->revivingTime[i] > 0)
		{
			data->revivingTime[i]--;
		}
	}

}
//更新障碍点信息（将非目标敌人与我方英雄设为障碍）
void UpdateData_blocks()
{

	for(int j = 0; j < 5; j ++)
	{
		for(int i = 0;i < data->enemys.size();i++)
		{
			if(data->enemys[i].max_hp > 0)
			{
				data->block[j].push_back(data->enemys[i].pos);
			}
		}
		for(int i = 0;i < data->myHeros.size(); i++)
		{
			if(i != j)
				data->block[j].push_back(data->myHeros[i].pos);
		}
	}

}
//已行动数据更新
void UpdateData_already()
{
	for(int i = 0;i < 5;i++)
	{
		data->already[i] = false;
	}
}
//评估函数
int Eva(vector<PUnit>& heros, PUnit& enemy)
{
	int result = 1000;
	int size = heros.size();
	if(size == 0)
		return result;
	Pos pos(0,0);
	for(int i = 0;i < heros.size();i++)
	{
		int flag = 0;
		pos = heros[i].pos;
		for(int j = 0;j < heros.size();j++)
		{
			if(dis(pos, heros[j].pos) > 10)
				flag++;
		}
		if(flag < heros.size()/2)
			break;
	}
	int speed = 0, hp = 0;
	for(int i = 0;i < size;i++)
	{
		speed += heros[i].speed;
		hp += heros[i]["Hp"]->val[0];
	}
	speed /= size;
	hp /= size;
	int arrive = dis(pos, enemy.pos) / sqrt(speed);
	if(data->revivingTime[rankOfEnemy(enemy)] > arrive)
		return result;
	if(enemy.isHero())
	{
		if(enemy.level > data->level_average + 3)
			return result;
		if(enemy.typeId == 0)
			result = 50;
		else if(enemy.typeId == 1)
			result = 100;
		else if(enemy.typeId == 2)
			result = 50;
	}
	else
	{
		if(enemy.typeId < 8)
			result = 150;
		else if(enemy.typeId == 8)
			result = 140;
		else if(enemy.typeId == 10)
			result = 120;
	}
	if(enemy.max_hp >= 1000)
		result = 1000;
	result += arrive * 10;
	result *= data->enemysRating[rankOfEnemy(enemy)];
	return result;
}
//评估箭雨释放点的评估函数
int Eva(PUnit& hero, Pos& pos)
{
	//undo
	int result = 0;
	if(dis2(hero.pos, pos) > 100) return result;
	for(int i = 0; i  < data->enemys.size(); i ++)
	{
		if((dis2(data->enemys[i].pos, pos) <= 25) && (data->enemys[i].hp > 0))
		{
			if(data->enemys[i].isHero())
				result += 100;
			else
				result += 20;
		}
	}
	if(dis2(hero.pos, pos) <= 81)
		result *= 10;
	return result;
}
//选取敌人
void Find_Enermy(vector<PUnit>& heros, PCommand* cmd)
{

	if(heros.size() == 0) 
		return;
	vector<PUnit> heros_left;
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		if(data->target[index].size() > 0)
		{
			PUnit enemy = data->target[index][0];
			if(data->level_average > LEVEL_ALONE)
			{
				data->enemysRating[rankOfEnemy(enemy)] = 1000;
			}
		}
		else 
		{
			heros_left.push_back(heros[j]);
		}
	}
	if(heros_left.size() == 0) return;
	//单独寻怪
	if(data->level_average >= LEVEL_ALONE)
	{
		
		data->enemysRating[28+data->info->camp] = 1000;
		for(int j = 0; j < heros_left.size(); j ++)
		{
			int index = rankOfHero(heros_left[j]);
			vector<PUnit> heros_tmp;
			heros_tmp.push_back(heros_left[j]);
			PUnit enemy = ChooseEnemy(heros_tmp);
			data->target[index].push_back(enemy);
			data->enemysRating[rankOfEnemy(enemy)] = 1000;
			
		}
	}
	//2,3寻怪
	
	//集体寻怪
	else
	{
	
		data->enemysRating[28+data->info->camp] = 0;
		PUnit enemy = ChooseEnemy(data->myHeros);
		for(int j = 0; j < heros_left.size(); j ++)
		{
			int index = rankOfHero(heros_left[j]);
			data->target[index].push_back(enemy);
		}

	}
}
//在某一单位附近寻找敌人
void Find_NearbyEnermy(vector<PUnit>& heros, PCommand *cmd, PUnit &unit)
{

	vector<PUnit> heros_left;
	for(int j = 0; j < heros.size(); j ++)
	{
		int index = rankOfHero(heros[j]);
		if(data->target[index].size() == 0)
		{
			heros_left.push_back(heros[j]);
		}
	}

	for(int j = 0; j < heros_left.size(); j ++)
	{

		int index = rankOfHero(heros_left[j]);
		vector<PUnit> heros_tmp;
		heros_tmp.push_back(heros_left[j]);
		PUnit enemy = ChooseNearbyEnemy(heros_tmp, unit);
		data->target[index].push_back(enemy);
	}
}
PUnit ChooseEnemy(vector<PUnit>& heros)
{
	int min = 1000;
	int tmp = 0;
	PUnit result = data->enemys[0];
	for(int i = 0;i < data->enemys.size();i++)
	{
		tmp = Eva(heros, data->enemys[i]);
		if(tmp < min)
		{
			min = tmp;
			result = data->enemys[i];
		}
	}
	return result;
}
PUnit ChooseNearbyEnemy(vector<PUnit>& heros, PUnit& unit)
{

	int min = 1000;
	int tmp = 0;
	PUnit result = data->enemys.back();
	if(unit.pos == Player0_tower_pos[0])
	{
		for(int j = 0; j < data->enemys.size(); j++)
		{
			if(data->enemys[j].id == 26)
			{
				result = data->enemys[j];
				break;
			}
		}
	}
	else if(unit.pos == Player0_tower_pos[1])
	{
		for(int j = 0; j < data->enemys.size(); j++)
		{
			if(data->enemys[j].id == 32)
			{
				result = data->enemys[j];
				break;
			}
		}
	}
	else if(unit.pos == Player1_tower_pos[0])
	{
		for(int j = 0; j < data->enemys.size(); j++)
		{
			if(data->enemys[j].id == 31)
			{
				result = data->enemys[j];
				break;
			}
		}
	}
	else if(unit.pos == Player1_tower_pos[1])
	{
		for(int j = 0; j < data->enemys.size(); j++)
		{
			if(data->enemys[j].id == 30)
			{
				result = data->enemys[j];
				break;
			}
		}
	}
	for(int i = 0;i < data->enemys.size();i++)
	{
		PUnit enemy = data->enemys[i];
		if(dis2(enemy.pos, unit.pos) <= 450 && (enemy.findBuff("Reviving") == 0))
		{
			tmp = Eva(heros, enemy);

			if(tmp < min)
			{
				min = tmp;
				result = data->enemys[i];
			}
		}
	}

	return result;
}
//选择箭雨释放的位置
Pos ChooseArrowsRainPoint(PUnit& hero)
{
	int max = 0;
	Pos result = hero.pos;
	for(int x = -10; x <= 10; x ++)
	{
		for(int y = -10; y <= 10; y ++)
		{
			Pos pos(hero.pos.x-x, hero.pos.y-y);
			int tmp = Eva(hero, pos);
			if(tmp > max)
			{
				result = pos;
				max = tmp;
			}
			else if(tmp == max)
			{
				srand((unsigned)time(NULL));
				int flag = rand()%2;
				if(flag == 0) result = pos;
			}
		}
	}
}					
//风筝走位
void Move(PUnit& hero, PUnit& enemy, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	Operation op;
	op.id = hero.id;
	op.type = "Move";
	Pos result = hero.pos;
	for(int i = -5;i < 5;i++)
		for(int j = -5;j < 5;j++)
		{
			Pos pos(hero.pos.x+i,hero.pos.y+j);
			if((dis2(pos, hero.pos) < hero.speed)&&(dis2(pos, enemy.pos) < hero.range))
			{
				if((dis2(pos, enemy.pos) > enemy.range) && (dis2(pos, enemy.pos) > dis2(result, enemy.pos)))
				{
					result = pos;
				}
				if((result == hero.pos) && (dis2(pos, enemy.pos) > dis2(result, enemy.pos)))
				{
					result == pos;
				}
			}
		}
		findShortestPath(*data->map, hero.pos, result, data->block[rankOfHero(hero)], op.targets);
		cmd->cmds.push_back(op);
		data->already[rankOfHero(hero)] = true;
}

//在某一单位视野之外盘旋以等待我方英雄,同时对来敌人进行攻击。
void Wait(PUnit& hero, PUnit& unit, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	if(AisInViewOfB(hero, unit))
	{
		MoveOutOfView(hero, unit, cmd);
		return;
	}
	for(int i = 0; i < data->enemys.size(); i ++)
	{
		if(data->enemys[i].isHero() && AisInRangeOfB(data->enemys[i], hero))
		{
			addBlocksNearAUnit(unit, data->block[rankOfHero(hero)]);
			AttackMonsterAlone_1(hero, data->enemys[i], cmd);
			return;
		}
	}
	MoveAroundAUnit(hero, unit, cmd);
}
//在某一单位视野范围内添加障碍点
void addBlocksNearAUnit(PUnit& unit, vector<Pos>& blocks)
{
	Pos _beg((int)(unit.pos.x - 12), (int)(unit.pos.y - 12));
	Pos _end((int)(unit.pos.x + 12), (int)(unit.pos.y + 12));
	_beg.x = max(_beg.x, 0);
	_beg.y = max(_beg.y, 0);
	_end.x = min(_end.x, 150);
	_end.y = min(_end.y, 150);
	for(int x=_beg.x; x <=_end.x; x ++)
	for(int y=_beg.y; y <=_end.y; y ++)
	{
		Pos pos(x, y);
		if(dis2(pos, unit.pos) <= 144 && dis2(pos, unit.pos) >= 81 )
		{
			blocks.push_back(pos);
		}
	}
}
PSkill ChooseSkill(PUnit& hero, PUnit& enemy)
{
	//打塔和打龙过程
	if((enemy.typeId == 10) || (enemy.typeId == 3))
	{
		//判定攻击范围内是否有敌方英雄，若有，使用箭雨
		for(int i = 0; i < data->enemys.size(); i ++)
		{
			if(data->enemys[i].isHero() && AisInRangeOfB(data->enemys[i], hero))
			{
				if(hero.canUseSkill(9))
				{
					for(int i = 0;i < hero.skills.size();i++)
					{
						if(hero.skills[i].typeId == 9)
						{
							return hero.skills[i];
						}
					}
				}
			}
		}
		bool flag = false;
		//判定是否处于全力重击状态
		for(int i = 0;i < hero.buffs.size();i++)
		{
			if(hero.buffs[i].typeId == 5)
			{
				flag = true;
				break;
			}
		}
		//优先使用全力重击
		if(!flag && hero.canUseSkill(11))
		{
			for(int i = 0;i < hero.skills.size();i++)
			{
				if(hero.skills[i].typeId == 11)
				{
					return hero.skills[i];
				}
			}
		}
		//若当前已有全力重击，则使用普通攻击
		if(flag)
		{
			for(int i = 0;i < hero.skills.size();i++)
			{
				if(hero.skills[i].typeId == 0)
				{
					return hero.skills[i];
				}
			}
		}
	}
	//若对手是敌方英雄
	if(enemy.typeId < 3)
	{
		//优先选择箭雨
		if(hero.canUseSkill(9))
		{
			for(int i = 0;i < hero.skills.size();i++)
			{
				if(hero.skills[i].typeId == 9)
				{
					return hero.skills[i];
				}
			}
		}
		//选择穿透火箭
		if(hero.canUseSkill(7))
		{
			for(int i = 0;i < hero.skills.size();i++)
			{
				if(hero.skills[i].typeId == 7)
				{
					return hero.skills[i];
				}
			}
		}
		//若不能选择上述两技能，则选择其他技能
		for(int i = 0;i < hero.skills.size();i++)
		{
			if(hero.skills[i].typeId != 0)
			{
				if(hero.canUseSkill(hero.skills[i].typeId))
				{
					return hero.skills[i];
				}
			}
		}
		//最后选择普通攻击
		for(int i = 0;i < hero.skills.size();i++)
		{
			if(hero.skills[i].typeId == 0)
			{
				return hero.skills[i];
			}
		}
	}
	//刷其它野怪是不选择使用技能
	for(int i = 0;i < hero.skills.size();i++)
	{
		if(hero.skills[i].typeId == 0)
		{
			return hero.skills[i];
		}
	}
}

void UpdateUnit(PUnit& unit)
{
	const PUnit* tmp = data->info->findUnitById(unit.id);
	if(tmp != NULL)
	{
		
		unit = *tmp;
	}
	
}
int GameData::HerosNearAUnit(PUnit& unit)
{

	int account = 0;
	for(int i = 0; i < myHeros.size(); i ++)
	{
		vector<Pos> _path;
		if(AisNearB(myHeros[i], unit) || AisInViewOfB(myHeros[i], unit))
		{
			account ++;
		}
	}

	return account;
}
//单独刷怪_直奔敌人。
void AttackMonsterAlone(PUnit& hero, PUnit& enemy, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	if(dis2(enemy.pos, hero.pos) <= hero.range)
	{
		bool flag = false;
		for(int i = 0; i < hero.skills.size(); i ++)
		{
			PSkill skill = hero.skills[i];
			if(skill.typeId == 0 && skill.cd == 0 && enemy.hp > 0)
			{

				Operation op;
				op.id = hero.id;
				op.typeId = skill.typeId;
				op.targets.push_back(enemy.pos);
				cmd->cmds.push_back(op);
				data->already[rankOfHero(hero)] = true;
				flag = true;
				break;
			}
		}
		if(! flag)
		{
			PSkill skill = ChooseSkill(hero, enemy);
			if(skill.cd == 0 && enemy.hp > 0)
			{
				Operation op;
				op.id = hero.id;
				op.typeId = skill.typeId;
				if(skill.needTarget())
				{
					if(skill.typeId == 9 && enemy.hp > 0)
					{
						Pos pos = ChooseArrowsRainPoint(hero);
						op.targets.push_back(pos);
					}
					else 
					{
						op.targets.push_back(enemy.pos);
					}
				}
				cmd->cmds.push_back(op);
				data->already[rankOfHero(hero)] = true;
			}
			else
			{
				Move(hero, data->target[rankOfHero(hero)][0],cmd);
			}
		}
	}
	else
	{
		Operation op;
		op.id = hero.id;
		op.type = "Move";
		findShortestPath(*data->map, hero.pos, enemy.pos, data->block[rankOfHero(hero)], op.targets);
		cmd->cmds.push_back(op);
		data->already[rankOfHero(hero)] = true;
	}
}
//单独刷怪_顺便刷视野中的其它怪
void AttackMonsterAlone_1(PUnit& hero, PUnit& enemy, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	bool flag = false;
	//目标不在视野内则顺便攻击视野内的目标
	if(! AisInViewOfB(enemy, hero))
	{
		vector<const PUnit*> nearBy;
		data->info->findUnitInArea(hero.pos, hero.view, nearBy); //寻找附近的人
		for (int i = 0; i < nearBy.size(); ++i)
		{
			if (nearBy[i]->level > hero.level + 3 ||
				nearBy[i]->camp == data->info->camp ||
				nearBy[i]->typeId == 3 ||
				nearBy[i]->typeId == 4 ||
				nearBy[i]->typeId == 9 ||
				nearBy[i]->typeId == 11 ||
				
				nearBy[i]->pos == Bow_pos[0] || nearBy[i]->pos == Bow_pos[3] ||
				nearBy[i]->findBuff("Reviving"))
				//删除等级过高的人，忽略友军，剔除敌方塔、复活者，删除不可到达的野怪
			{
				nearBy.erase(nearBy.begin()+i);
				--i;

			}
		}
		PUnit enemy_nearBy = *nearBy[0];
		if(nearBy.size())
		{
			AttackMonsterAlone(hero, enemy_nearBy, cmd);
			flag = true;

		}
	}
	if(! flag) 
		AttackMonsterAlone(hero, enemy, cmd);
}
//单独刷怪_首先刷视野中的其它英雄
void AttackMonsterAlone_2(PUnit& hero, PUnit& enemy, PCommand* cmd)
{

	//changed
	if(data->already[rankOfHero(hero)]) return;
	if(AisInViewOfB(enemy, hero) && (enemy.hp < (enemy.max_hp / 10)))
	{
		AttackMonsterAlone(hero, enemy, cmd);
		return;
	}
	bool flag = false;
	vector<const PUnit*> nearBy;
	data->info->findUnitInArea(hero.pos, hero.view, nearBy); //寻找附近的人
	for (int i = 0; i < nearBy.size(); ++i)
	{
		if (! nearBy[i]->isHero() || nearBy[i]->camp != (1-data->info->camp))
			//删除除敌方英雄外的单位
		{
			nearBy.erase(nearBy.begin()+i);
			--i;
		}
	}

	PUnit enemy_nearBy = *nearBy[0];
	if(nearBy.size())
	{
		AttackMonsterAlone(hero, enemy_nearBy, cmd);
		return;
	}
	AttackMonsterAlone(hero, enemy, cmd);
}
//判断A是否在B的攻击范围内。
bool AisInRangeOfB(PUnit& A, PUnit& B)
{
	bool ok = (dis2(A.pos, B.pos) <= data->Range2OfAUnit[B.typeId]);

	return ok;
}
//判断A是否在B的视野范围内。
bool AisInViewOfB(PUnit& A, PUnit& B)
{
	bool ok = (dis2(A.pos, B.pos) <= 144);
	return ok;
}
//判断A是否在B的视野范围外，但能两回合内走到A攻击范围内。
bool AisNearB(PUnit& A, PUnit& B)
{
	bool ok = AInPosIsNearB(A, A.pos, B);

	return ok;
}
//判断A在pos点时是否处于适合位置
bool AInPosIsNearB(PUnit& A, Pos pos, PUnit& B)
{

	int range = (sqrt((int)A.speed)*2 + sqrt((int)data->Range2OfAUnit[B.typeId]));
	if(dis(A.pos, B.pos) > range)
		return false;
	else
	{
		vector<Pos> _path;
		findShortestPath(*data->map, pos, B.pos, _path);
		if(Length(_path) <= range)
		{
			return true;
		}
		else 
			return false;
	}
}
//使英雄逃出unit的逃出视野范围
void MoveOutOfView(PUnit &hero, PUnit& unit, PCommand *cmd)
{
	if(data->already[rankOfHero(hero)]) return;
	if(! AisInViewOfB(hero, unit)) return;
	//思路，求出unit视野范围外的所有能一回合走到的点并随机选取其中一个点作为目标
	Operation op;
	op.id = hero.id;
	op.type = "Move";
	Pos result = FindPointNearUnit_random(hero, unit);
	findShortestPath(*data->map, hero.pos, result, data->block[rankOfHero(hero)], op.targets);
	cmd->cmds.push_back(op);
	data->already[rankOfHero(hero)] = true;

}
//围着某一单位转圈
void MoveAroundAUnit(PUnit &hero, PUnit& unit, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	addBlocksNearAUnit(unit, data->block[rankOfHero(hero)]);
	Pos result(2*unit.pos.x-hero.pos.x, 2*unit.pos.y-hero.pos.y);
	Operation op;
	op.id = hero.id;
	op.type = "Move";
	findShortestPath(*data->map, hero.pos, result, data->block[rankOfHero(hero)], op.targets);
	cmd->cmds.push_back(op);
	data->already[rankOfHero(hero)] = true;
}
//朝目标移动但是不进入其视野范围内。
void Move_special(PUnit &hero, PUnit& unit, PCommand* cmd)
{

	if(data->already[rankOfHero(hero)]) return;
	Operation op;
	op.id = hero.id;
	op.type = "Move";
	//将敌人视野范围内的行动点截掉
	findShortestPath(*data->map, hero.pos, unit.pos, data->block[rankOfHero(hero)], op.targets);
	double range = (12 + sqrt((double)hero.speed));
	double l = dis(hero.pos, unit.pos);
	if(l < range)
	{
		l = Length(op.targets);
	}
	if(l < range)
	{
		Pos pos = op.targets.back();
		while(op.targets.size() > 1 && dis2(pos, unit.pos) <= 144)
		{

			op.targets.pop_back();
			pos = op.targets.back();
		}
	}
	cmd->cmds.push_back(op);
	data->already[rankOfHero(hero)] = true;
}
//计算某一路径的实际移动长度_有一定误差
double Length(vector<Pos> &_path)
{

	if( _path.size() <= 1 || _path[0] == Pos(-1, -1)) return 0;
	int l = dis(_path[0], _path.back());
	if(l <= 17)
	{
		l = 0;
		int _beg = 0;
		int _end = 1;
		while(_end < _path.size()-1)
		{
			Pos v0(_path[_end].x-_path[_end-1].x, _path[_end].y-_path[_end-1].y); 
			Pos v1(_path[_end+1].x-_path[_end].x, _path[_end+1].y-_path[_end].y); 
			if(  (v0.x*v1.x + v0.y*v1.y) == 0)
			{
				_end ++;
			}
			else
			{
				l += dis(_path[_beg], _path[_end]);
				_beg = _end;
				_end ++;
			}
			
		}
		l += dis(_path[_beg], _path[_end]);
	}

	return l;
}


//在A附近随机寻找一个相对unit合适但不在unit视野范围内的点
Pos FindPointNearUnit_random(PUnit& hero, PUnit& unit)
{

	int tmp = 4;
	Pos _beg(hero.pos.x - tmp, hero.pos.y - tmp);
	Pos _end(hero.pos.x + tmp, hero.pos.y + tmp);
	_beg.x = max(_beg.x, 0);
	_beg.y = max(_beg.y, 0);
	_end.x = min(_end.x, 150);
	_end.y = min(_end.y, 150);
	vector<Pos> result;
	for(int x=_beg.x; x <=_end.x; x ++)
	{
		for(int y=_beg.y; y <=_end.y; y ++)
		{
			Pos pos(x, y);
			
			if(dis(pos, unit.pos) <= 17 && (dis2(pos, unit.pos) > 144))
			{
				result.push_back(pos);
			}
		}
	}
	srand((unsigned)time(NULL));
	int rank_random = rand() % result.size();

	if(result.size())
		return result[rank_random];
	else
		return Pos(hero.pos.x, hero.pos.y);
}


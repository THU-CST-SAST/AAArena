#include <math.h>
#include <ctime>
#include "sdk.h"

#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)

Pos towerPos;
Pos dPos[4] = {Pos(0,1), Pos(1,0), Pos(0,-1), Pos(-1,0)};
Pos arroundTower[13] = {
  Pos(0,12), Pos(1,11), Pos(2,11), Pos(3,11), Pos(4,11),
  Pos(5,10), Pos(6,10), Pos(7,9), Pos(8,8),
  Pos(0,11), Pos(4,10), Pos(6,9), Pos(7,8)
};

vector<int> attackId, moveId;

inline int dot(const Pos& a, const Pos& b) {
  return a.x * b.x + a.y * b.y;
}

Pos aimPos;
Pos singleAimPos[5];
bool TowerExist[4]; // ours(nearer, further), others(..,..)

enum AimType {
  Ground = 0,
  OursTower,
  Wilds,
  OthersTower
};
AimType aimType;

vector<const PUnit*> ours, others, wilds;

vector<Pos> blocks;

Operation lastRound[5];
const PUnit* oursHero[5];
Pos posCenter, enemyCenter;
int oursId[5];

Pos rainPos;
Pos rainDelta[] = {
  Pos(0,0), Pos(1,0), Pos(2,0), Pos(1,1), Pos(2,1)
};

// new
//bool wildsAlert;
vector<const PUnit*> oursTower;
bool firstTowerExist;

/* *** from file init.cpp *** */
void chooseHero(const PPlayerInfo &info, PCommand &cmd);
void init(const PPlayerInfo &info);
/* ************************** */

/* *** from file fight.cpp *** */
void singleDes(const PMap &map, const PPlayerInfo &info, PCommand &cmd);
  // attack with others
  void findAttackableRoles(const PUnit* ptr, vector<const PUnit*>& target, const vector<const PUnit*>& rolesRange);
  const PUnit* findRoleMostWeak(const PUnit* ptr, const vector<const PUnit*>& target, const vector<int>& attackId, string& magic);
  Pos findDodgePos(const PPlayerInfo &info, int index, const vector<int>& attackId);
    const PUnit* findAccessibleRoles(int index);
  // attack with wilds
  const PUnit* findRoleMostWeak(const PUnit* ptr, const vector<const PUnit*>& target, string& magic);
  void fight(const PMap&, const PPlayerInfo&, PCommand&, const PUnit*, int);
  // both
  void addOtherWildsInBlocks(int wildId, const PArg *arg, int range = 8);
  int findRoleFrom(int id, const vector<const PUnit*>& target); // 瀵绘壘瀹瑰櫒涓璉D鐩稿悓鐨勫厓绱?
  void addInBlocks(const vector<Pos>& path, const Pos& pos, int speed);

void fightTower(const PUnit* aimPtr, const PMap &map, const PPlayerInfo &info, PCommand &cmd, int index);

void arroundTowerPushInBlock(Pos pos);

/* *************************** */

/* *** from file ai.cpp *** */
void findRoles(const PPlayerInfo &info);
bool aimPosArrived(const PPlayerInfo &info);
bool availableForFirstTower();
void desAimPos(const PPlayerInfo &info);
void levelUp(int index, PCommand &cmd);
bool startFight;
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd);

Pos findEndPos(vector<Pos>& targets, int index);
void posDetect(int index, vector<Pos>& targets, const PMap &map, const PPlayerInfo &info, PCommand &cmd);
Pos skillAvailable(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd);
Pos findArrowsRainCenter(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd);
Pos findPiercingArrowCenter(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd);

double cross(Pos a, Pos b);
/* ************************ */

/* ------ in file init.cpp ------ */
void chooseHero(const PPlayerInfo &info, PCommand &cmd) {
  int i;
  for(i = 0; i < info.units.size(); i++) {
    Operation op;
    op.type = "ChooseArcher";
    op.targets.clear();
    op.id = info.units[i].id;
    cmd.cmds.push_back(op);
  }
}

void init(const PPlayerInfo &info) {
  int i;
  aimPos = Pos(-1,-1); aimType = Ground;
  towerPos = !info.player ? Pos(75,34) : Pos(75,116);
  for (i = 0; i < 5; i++) {
    lastRound[i].type = "Stop";
  }
  for (i = 0; i < 4; i++) {
    TowerExist[i] = true;
  }
  startFight = false;
  firstTowerExist = true;
}
/* ------------------------------ */

/* ------ in file fight.cpp ------ */
void singleDes(const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  int i, sum;
  Pos nextPos, center;
  const PUnit *pOurs, *pOthers, *pWilds;
  vector<const PUnit*> target;
  vector<int> attackId, moveId;
  string magic;
  
  target.clear(); attackId.clear(); moveId.clear(); 
  
  if (!others.empty()) {
    addOtherWildsInBlocks(-1, NULL);
    for (i = 0; i < 5; i++) {
      pOurs = oursHero[i];
      if (pOurs == NULL) { lastRound[i].type = "Stop"; continue; }
      
      if ( (i == 4 && pOurs->canUseSkill(9)) 
        || (i != 4 && pOurs->canUseSkill(7)) ) {
        center = skillAvailable(i, map, info, cmd);
        if (center == Pos(-2,-2)) {
          Operation op;
          op.id = oursId[i];
          op.type = "PowerUp";
          op.targets.clear();
          //op.targets.push_back(pOurs->pos);
          cmd.cmds.push_back(op);
          lastRound[i] = op;
          continue;
        }
        else if (center != Pos(-1,-1)) {
          Operation op;
          op.id = oursId[i];
          op.type = i == 4 ? "ArrowsRain" : "PiercingArrow";
          op.targets.push_back(center);
          cmd.cmds.push_back(op);
          lastRound[i] = op;
          continue;
        }    
      }
      if ( strcmp(lastRound[i].type.c_str(), "Attack") == 0 ) {
        moveId.push_back(i); continue;
      }
      else {
        findAttackableRoles(pOurs, target, others);
        if (target.empty()) { moveId.push_back(i); continue; }

        pOthers = findRoleMostWeak(pOurs, target, attackId, magic); // 鑰冭檻鍒板叾浠栦汉鐨勬敾鍑荤洰鏍?
        if (pOthers == NULL) { moveId.push_back(i); continue; }
        attackId.push_back(i);
        
        Operation op;
        op.id = oursId[i];
        op.type = "Attack";
        op.targets.clear();
        op.targets.push_back(pOthers->pos);
        cmd.cmds.push_back(op);
        lastRound[i] = op;
      }
    }
    for (i = 0; i < moveId.size(); i++) {
      pOurs = oursHero[ moveId[i] ];
      nextPos = findDodgePos(info, moveId[i], attackId); // 鑰冭檻鍒版墍鏈塧ttack鍜屽皬浜巌鐨勬墍鏈塵ove
      Operation op;
      op.id = oursId[ moveId[i] ];
      op.type = "Move";
      op.targets.clear();
      findShortestPath(map, pOurs->pos, nextPos, blocks, op.targets);
      cmd.cmds.push_back(op);
      lastRound[ moveId[i] ] = op;
    }
  }
  else if (!wilds.empty() 
   && !(wilds.size() == 1 && wilds[0]->id == 38) ) {
   //&& !(wilds.size() == 1 && wilds[0]->id == !info.player ? 26 : 29) ) {
    for (i = 0; i < 5; i++) {
      pOurs = oursHero[i];
      if (pOurs == NULL) continue;
      pWilds = findRoleMostWeak(pOurs, wilds, magic);
     
      if (dis2(pOurs->pos, pWilds->pos) < pOurs->range
       && strcmp(lastRound[i].type.c_str(), "Attack") != 0)
        attackId.push_back(i);
      else moveId.push_back(i);  
    }
    for (i = 0; i < moveId.size(); i++)
      fight(map, info, cmd, pWilds, moveId[i]);
    for (i = 0; i < attackId.size(); i++)
      fight(map, info, cmd, pWilds, attackId[i]);
  }
  else {
    if (!wilds.empty()) addOtherWildsInBlocks(-1, NULL);
    for (i = 0; i < 5; i++) {
      Operation op;
      pOurs = oursHero[i];
      if (pOurs == NULL) continue;
      op.id = oursId[i];
      op.type = "Move";
      op.targets.clear();
      findShortestPath(map, pOurs->pos, aimPos, blocks, op.targets);
      cmd.cmds.push_back(op);
      lastRound[i] = op;
    }
  }
}

// attack with others
void findAttackableRoles(const PUnit* ptr, vector<const PUnit*>& target, const vector<const PUnit*>& rolesRange) {
  int i;
  const PUnit *pOthers;
  target.clear();
  for (i = 0; i < rolesRange.size(); i++) {
    pOthers = rolesRange[i];
    if (ptr->id == 38) { addOtherWildsInBlocks(38, NULL); continue; }
    if ( dis2(ptr->pos, pOthers->pos) < ptr->range )
      target.push_back(pOthers);
  }
}

const PUnit* findRoleMostWeak(const PUnit* ptr, const vector<const PUnit*>& target, const vector<int>& attackId, string& magic) {
  int i, j, other_pos, minGrade = 0xfffff, minId = -1;
  int grade[ target.size() ];
  const PUnit* pOthers;
  memset(grade, 0, sizeof(int) * target.size());
  
  for (i = 0; i < target.size(); i++) {
    pOthers = target[i];
    grade[i] = pOthers->hp - (ptr->atk - pOthers->def); // 鍚庢湡鑰冭檻閫熷害銆佹妧鑳?
  }
  for (i = 0; i < attackId.size(); i++) {
    other_pos = findRoleFrom(attackId[i], target);
    if (other_pos != -1)
      grade[other_pos] -= oursHero[i]->atk - pOthers->def;
  }
  
  // return min
  for (i = 0; i < target.size(); i++) {
    if (grade[i] < minGrade) { minGrade = grade[i]; minId = i; }
  }
  
  magic = "Attack";
  
  if (minId != -1) {
    return target[minId];
  }
  return NULL;
}

Pos findDodgePos(const PPlayerInfo &info, int index, const vector<int>& attackId) {
  int i;
  const PUnit *ptr = oursHero[index], *pOthers;
  Pos nextPos;
  
  if ( strcmp(lastRound[index].type.c_str(), "Attack") == 0 ) {
    nextPos = ptr->pos + 5 * (ptr->pos - lastRound[index].targets[0]); 
                 //      + 3 * (posCenter - ptr->pos);
  }
  else if (attackId.empty()) {
    pOthers = findAccessibleRoles(index);
    if (pOthers == NULL) nextPos = aimPos;
    nextPos = pOthers->pos;
  }
  else {
    nextPos = Pos(0,0);
    for (i = 0; i < attackId.size(); i++) {
      nextPos = nextPos + lastRound[ attackId[i] ].targets[0];
    }
    nextPos.x /= attackId.size(); nextPos.y /= attackId.size();
  }
  return nextPos;
}

const PUnit* findAccessibleRoles(int index) {
  int i, minId, minGrade = 0xfffff, dist;
  const PUnit *ptr = oursHero[index];
  
  //return min
  for (i = 0; i < others.size(); i++) {
    dist = dis2(ptr->pos, others[i]->pos);
    if (dist < minGrade) { minGrade = dist; minId = i; }
  }
  
  if (minId != -1) {
    return others[minId];
  }
  
  return NULL;
}

// attack with wilds
const PUnit* findRoleMostWeak(const PUnit* ptr, const vector<const PUnit*>& target, string& magic) {
  int i, j, other_pos, minGrade = 0xfffff, minId = -1;
  int grade[ target.size() ];
  const PUnit* pOthers;
  memset(grade, 0, sizeof(int) * target.size());
  
  for (i = 0; i < target.size(); i++) {
    pOthers = target[i];
    grade[i] = pOthers->hp - (ptr->atk - pOthers->def); // 鍚庢湡鑰冭檻閫熷害銆佹妧鑳?
  }
  
  // return min
  for (i = 0; i < target.size(); i++) {
    if (target[i]->id == 38) continue;
    if (grade[i] < minGrade) { minGrade = grade[i]; minId = i; }
  }
  
  magic = "Attack";
  
  if (minId != -1) {
    return target[minId];
  }
  return NULL;
}

void fight(const PMap& map, const PPlayerInfo& info, PCommand& cmd, const PUnit* pWilds, int index) {
  int i, j;
  const PUnit *ptr;
  Pos avoidPos;
  Operation op;
  
  int dist, dist2, leastDis, bestId = -1;
  const PArg* arg;
  
  ptr = oursHero[index];
  leastDis = dis2(ptr->pos, pWilds->pos);
 
  arg = (*ptr)["LastHit"];
  addOtherWildsInBlocks(pWilds->id, arg);
  if (leastDis <= ptr->range) {
    op.id = oursId[index];
    
    if ( strcmp(lastRound[index].type.c_str(), "Attack") != 0 ) {
      op.type = "Attack";
      op.targets.push_back(pWilds->pos);
      cmd.cmds.push_back(op);
    }
    else { // 绉诲姩鏃朵笉搴旂Щ鍔ㄥ埌澶繙, 涓斾笉搴旇鍒板叾浠栨晫浜虹殑鍖哄煙鍐?
      op.type = "Move";
      avoidPos = ptr->pos + 3 * (ptr->pos - pWilds->pos);
      avoidPos.x = max(0, min(avoidPos.x, 149) );
      avoidPos.y = max(0, min(avoidPos.y, 149) );
      findShortestPath(map, ptr->pos, avoidPos, blocks, op.targets);
      if (ptr->typeId == 1)
      while (op.targets.size() > 1) {
        dist  = dis2(pWilds->pos, op.targets[ op.targets.size() - 2 ]);
        if (dist >= (ptr->range + 1.1 * pWilds->speed) || dis2(ptr->pos, op.targets[ op.targets.size() - 2 ]) > ptr->speed)
          op.targets.pop_back();
        else break;
      }
      blocks.push_back(op.targets.back());
      cmd.cmds.push_back(op);
      
    }
    lastRound[index] = op;
  }
  else { // 绉诲姩鏃朵笉搴旂Щ鍔ㄥ埌澶繎
    op.id = oursId[index];
    op.type = "Move";
    findShortestPath(map, ptr->pos, pWilds->pos, blocks, op.targets);
    
    posDetect(index, op.targets, map, info, cmd);
    
    if (ptr->typeId == 1) {
      if (arg->val.size() > pWilds->id && info.round - arg->val[pWilds->id] <= 2 
       && ptr->hp <=  2 * (pWilds->atk - ptr->def) ) {
        while (op.targets.size() > 1) {
          dist  = dis2(pWilds->pos, op.targets[ op.targets.size() - 2 ]);
          if (dist <= (pWilds->range + pWilds->speed) )
            op.targets.pop_back();
          else break;
        }
      }
      else {
        while (op.targets.size() > 2) {
          dist  = dis2(pWilds->pos, op.targets[ op.targets.size() - 2 ]);
          dist2 = dis2(pWilds->pos, op.targets[ op.targets.size() - 3 ]);
          if (dist <= (pWilds->range +  pWilds->speed) && dist2 <= ptr->range)
            op.targets.pop_back();
          else break;
        }
      }
    }
    cmd.cmds.push_back(op);
    lastRound[index] = op;
  }
}

// both used
void addOtherWildsInBlocks(int wildId, const PArg *arg, int range /* = 8 */) {
  int i, j, t;
  Pos pos;
  const PUnit *ptr;
  bool wildsAlert;
  for (i = 0; i < wilds.size(); i++) {
    if (wilds[i]->id == wildId) continue;
    //if (arg->val.size() > pWilds->id && info.round - arg->val[pWilds->id] <= 2)
    //鏆傛椂涓嶈€冭檻鍏跺叾鏀诲嚮鑼冨洿锛?涔熻寮€8鐨勬牸瀛?
    pos = wilds[i]->pos;
    
    wildsAlert = false;
    for (j = 0; j < 5; j++) {
      ptr = oursHero[i];
      if (ptr == NULL) continue;
      if ( dis2(ptr->pos, pos) <= 8 ) {
        wildsAlert = true; break;
      }
    }
    
    if (!wildsAlert) {
      for (j = -2; j <= 2; j++) {
        for (t = -2; t <= 2; t++) {
          blocks.push_back(pos + Pos(j,t));
        }
      }
    }
    else blocks.push_back(pos);
  }
}

int findRoleFrom(int id, const vector<const PUnit*>& target) {
  int i;
  const PUnit *ptr, *pOthers;
  Pos other_pos;
  
  ptr = oursHero[id];
  if (ptr == NULL) return -1;
  other_pos = lastRound[id].targets[ lastRound[id].targets.size() - 1 ];
  
  for (i = 0; i < target.size(); i++) {
    if (target[i]->pos == other_pos)
      return i;
  }
  
  return -1;
}

void addInBlocks(const vector<Pos>& path, const Pos& pos, int speed) {
  Pos nextPos;
  int i = 0;
  
  if (path.empty()) return;
  do {
    nextPos = path[i++];
  } while ( i < path.size() && dis2(pos, nextPos) <= speed );
  
  blocks.push_back(nextPos + Pos(-1,0));
  blocks.push_back(nextPos + Pos(1,0) );
  blocks.push_back(nextPos + Pos(0,1) );
  blocks.push_back(nextPos + Pos(0,-1));
}


void fightTower(const PUnit* aimPtr, const PMap &map, const PPlayerInfo &info, PCommand &cmd, int index) {
  int i, j, dist, dist2;
  const PUnit *ptr;
  const PSkill* psk;
  const PArg *arg;
  Pos avoidPos;
  Operation op;
  
  ptr = oursHero[index];
  op.id = oursId[index];
  
  if (ptr->typeId == 1) {
    psk = ptr->findSkill("PowerUp");
    if (psk->isHeroSkill() && ptr->canUseSkill(psk->typeId)) {
      op.type = psk->name;
      op.targets.push_back(ptr->pos);
      cmd.cmds.push_back(op);
      lastRound[index] = op;
      return;
    }
  }
  
  arg = (*ptr)["LastHit"];
  
  if (arg->val.size() > aimPtr->id && info.round - arg->val[aimPtr->id] <= 1
   && ptr->hp <= 2 * (aimPtr->atk - ptr->def) ) {
    op.type = "Move";
    avoidPos = ptr->pos + 3 * (ptr->pos - aimPtr->pos);
    avoidPos.x = max(0, min(avoidPos.x, 149) );
    avoidPos.y = max(0, min(avoidPos.y, 149) );
    
    findShortestPath(map, ptr->pos, avoidPos, blocks, op.targets);
    
    if (ptr->typeId == 1) {
      while (op.targets.size() > 2) {
        dist  = dis2(aimPtr->pos, op.targets[ op.targets.size() - 2 ]);
        dist2 = dis2(aimPtr->pos, op.targets[ op.targets.size() - 3 ]);
        if (dist <= aimPtr->range && dist2 <= aimPtr->range)
          op.targets.pop_back();
        else break;
      }
    }
    cmd.cmds.push_back(op);
    lastRound[index] = op;
    
    return;
  }
  
  if (dis2(ptr->pos, aimPos) <= ptr->range) {
    op.type = "Attack";
    op.targets.push_back(aimPos);
    blocks.push_back(ptr->pos);
    cmd.cmds.push_back(op);
  }
  else {
    op.id = oursId[index];
    op.type = "Move";
    findShortestPath(map, ptr->pos, aimPtr->pos, blocks, op.targets);
    if (ptr->typeId == 1) {
      while (op.targets.size() > 2) {
        dist  = dis2(aimPtr->pos, op.targets[ op.targets.size() - 2 ]);
        dist2 = dis2(aimPtr->pos, op.targets[ op.targets.size() - 3 ]);
        if (dist <= ptr->range && dist2 <= ptr->range)
          op.targets.pop_back();
        else break;
      }
    }
    cmd.cmds.push_back(op);
  }
  lastRound[index] = op;
}

Pos findEndPos(vector<Pos>& targets, int index) {
  vector<Pos>::iterator iter;
  Pos origin, last;
  const PUnit *ptr = oursHero[index];
  if (ptr == NULL) exit(-1);
  last = origin = targets[0];
  for (iter = targets.begin(); iter != targets.end(); iter++) {
    if (dis2(origin, *iter) > ptr->speed) break;
    last = *iter;
  }
  return last;
}

void posDetect(int index, vector<Pos>& targets, const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  int i, j, times = 0;
  const PUnit* ptr;
  vector<Pos> block, old;
  Pos origin, aim, final_pos;
  
  block = blocks;
  old = targets;
  while (times < 3) {
    times ++;
    origin = targets.front(); aim = targets.back();
    final_pos = findEndPos(targets, index);
  
    for (i = 0; i < index; i++) {
      ptr = oursHero[i];
      if (ptr == NULL) continue;
    
      if (dis2(ptr->pos, final_pos) <= 2) {
        for (j = 0; j < 4; j++) {
          block.push_back(ptr->pos + dPos[j]);
        }
      }
    }
    if (block.size() > blocks.size()) {
      targets.clear();
      findShortestPath(map, origin, aim, block, targets);
    }
    else break;
  }
  
  final_pos = findEndPos(targets, index);
  if (dis2(final_pos, targets[0]) <= 4)
    targets = old;
}

Pos skillAvailable(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  int i, j, affectableRoles, count;
  vector<const PSkill*> useSkill;
  const PSkill *psk;
  const PUnit *ptr = oursHero[index];
  if (ptr == NULL) return Pos(-1,-1);
  
  Pos center;
  //vector<const PUnit*> infects;
  
  if (index == 4) {
    psk = ptr->findSkill("ArrowsRain");
    if (!ptr->canUseSkill(9)) return Pos(-1,-1);
    
    if (others.size() > 2 
     || ( others.size() == 2 && (others[0]->isHero() && others[1]->isHero())
      && !( others[0]->typeId == 0 && others[1]->typeId == 0
       && others[0]->canUseSkill(1) && others[1]->canUseSkill(1) ) ) ) {
      return findArrowsRainCenter(index, map, info, cmd);
    }
    //return Pos(-1,-1);
  }
  else {
    psk = ptr->findSkill("PiercingArrow");
    if (!ptr->canUseSkill(7)) return Pos(-1,-1);
    
    if (others.size() > 2 
     || ( others.size() == 2 && (others[0]->isHero() && others[1]->isHero())
      && !( others[0]->typeId == 0 && others[1]->typeId == 0
       && others[0]->canUseSkill(1) && others[1]->canUseSkill(1) ) ) ) {
      return findPiercingArrowCenter(index, map, info, cmd);
    }
    //return Pos(-1,-1);
  }
  psk = ptr->findSkill("PowerUp");
  if (ptr->canUseSkill(11) && ptr->hp >= ptr->max_hp * 2 / 3) return Pos(-2,-2);
  return Pos(-1,-1);
}

double cross(Pos a, Pos b) {
  return a.x * b.y - b.x * a.y;
}

Pos findArrowsRainCenter(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  Pos center = Pos(0,0);
  int i, j, t, count = 0;
  const PUnit *ptr = oursHero[index];
  bool affectWilds, affectFriends;
  if (ptr == NULL) return Pos(-1,-1);
  for (i = 0; i < others.size(); i++) {
    if (!others[i]->isHero()) continue;
    if ( dis2(ptr->pos, others[i]->pos) > ptr->view * 2 ) continue;
    center = center + others[i]->pos;
    count++;
  }
  if (count == 0) return Pos(-1,-1);
  center = Pos(center.x / count, center.y / count);
  
  Pos bestPos, tmp; int maxTargets = 0;
  for (i = -4; i <= 4; i++) {
    for (j = -4; j <=4; j++) {
      tmp = center + Pos(i,j); count = 0;
      if ( dis2(tmp, ptr->pos) > SignalArrow_range ) continue;
      
      affectWilds = false;
      for (t = 0; t < wilds.size(); t++) {
        if ( dis2(tmp, wilds[t]->pos) <= RainyPlace_range ) {
          affectWilds = true; break;
        }
      }
      if (affectWilds) continue;
      /*affectFriends = true;
      for (t = 0; t < ours.size(); t++) {
        if ( dis2(tmp, ours[t]->pos) < RainyPlace_range ) {
          affectFriends = true; break;
        }
      }
      if (affectFriends) continue;*/
      
      for (t = 0; t < others.size(); t++) {
        if (!others[t]->isHero()) continue;
        if ( dis2(tmp, others[t]->pos) > RainyPlace_range ) continue;
        count++;
      }
      
      if (count > maxTargets) {
        bestPos = tmp; maxTargets = count;
      }
    }
  }
  
  if (maxTargets >= 2 || (maxTargets == 1 && ptr->hp <= ptr->max_hp / 3) ) return bestPos;
  else return (-1,-1);
}

Pos findPiercingArrowCenter(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  Pos center = Pos(0,0);
  int i, j, t, count = 0;
  const PUnit *ptr = oursHero[index];
  bool affectWilds;
  
  int lastLeastHp = 0xfffff, leastHp = 0xfffff, onlyId = -1;
  
  if (ptr == NULL) return Pos(-1,-1);
  
  for (i = 0; i < others.size(); i++) {
    if (!others[i]->isHero()) continue;
    if ( dis2(ptr->pos, others[i]->pos) > ptr->view * 2 ) continue;
    center = center + others[i]->pos;
    count++;
  }
  if (count == 0) return Pos(-1,-1);
  center = Pos(center.x / count, center.y / count);
  
  Pos bestPos, tmp, dir, targetDir; int maxTargets = 0;
  lastLeastHp = 0xfffff; // 上一地点影响到的最小的生命值
  for (i = -6; i <= 6; i++) {
    for (j = -6; j <= 6; j++) {
      tmp = center + Pos(i,j); count = 0;
      if ( dis2(tmp, ptr->pos) > PiercingArrow_range ) continue;
      
      affectWilds = false;
      for (t = 0; t < wilds.size(); t++) {
        dir = tmp - ptr->pos;
        targetDir = wilds[t]->pos - ptr->pos;
        if (1.5 > cross(dir, targetDir) / dis(dir, Pos(0,0)) ) {
          affectWilds = true; break;
        }
      }
      if (affectWilds) continue;
      
      leastHp = 0xfffff; onlyId = -1; // 影响到的角色的最小生命值及对应id
      for (t = 0; t < others.size(); t++) {
        if (!others[t]->isHero()) continue;
        if ( dis2(ptr->pos, tmp) < dis2(ptr->pos, others[t]->pos) ) continue;
        dir = tmp - ptr->pos;
        targetDir = others[t]->pos - ptr->pos;
        if (1.5 > cross(dir, targetDir) / dis(dir, Pos(0,0)) ) {
          count++;
          if (others[t]->hp < leastHp) {
            leastHp = others[t]->hp;
            onlyId = others[t]->id;
          }
        }
      }
      
      if (count > maxTargets || (count == maxTargets && leastHp < lastLeastHp) ) {
        bestPos = tmp; maxTargets = count;
        lastLeastHp = leastHp;
      }
    }
  }
  
  if (maxTargets >= 2 || (maxTargets == 1 && ptr->hp <= 2 * ptr->max_hp / 3) ) return bestPos;
  else return (-1,-1);
}

void move(int index, const PMap &map, const PPlayerInfo &info, PCommand &cmd, Pos aim) {
  int j;
  Operation op;
  const PUnit* ptr;
  
  ptr = oursHero[index];
  if (ptr == NULL) return;
  op.id = oursId[index];
  op.type = "Move";
  op.targets.clear();
  findShortestPath(map, ptr->pos, aim, blocks, op.targets);
  cmd.cmds.push_back(op);
  lastRound[index] = op;
}

void arroundTowerPushInBlock(Pos pos) {
  int i, j;
  for (i = 0; i < 13; i++) {
    blocks.push_back(pos + arroundTower[i]);
    blocks.push_back(pos - arroundTower[i]);
    blocks.push_back(pos + Pos(arroundTower[i].y, arroundTower[i].x) );
    blocks.push_back(pos - Pos(arroundTower[i].y, arroundTower[i].x) );
  }
}
/* ------------------------------- */

/* ------ in file ai.cpp ------ */
bool find(const PUnit* ptr, const vector<const PUnit*>& ptrs) {
  int i;
  for (i = 0; i < ptrs.size(); i++) {
    if (ptr->pos.x == ptrs[i]->pos.x && ptr->pos.y == ptrs[i]->pos.y)
      return true;
  }
  return false;

}

// 姣忓洖鍚堟洿鏂拌鑹蹭俊鎭?
void findRoles(const PPlayerInfo &info) {
  int i, j, t, index, count;
  const PUnit* ptr;
  Pos newCenter;
  bool all_dead = true;
  
  ours.clear();
  info.findUnitByPlayer(info.player, ours);

  if (info.round == 1) {
    index = 0;
    for (i = 0; i < ours.size(); i++) {
      ptr = ours[i];
      if ( ptr->isHero() ) {
        oursId[index] = ptr->id;
        oursHero[index] = ptr;
        index++;
      }
    }
  }
  else {
    for (j = 0; j < 5; j++) {
      oursHero[j] = NULL;
      for (i = 0; i < ours.size(); i++) {
        if (ours[i]->id == oursId[j]) {
          oursHero[j] = ours[i];
          //addInBlocks(oursHero[j]->pos, 0, i);
          break;
        }
      }
      if (oursHero[j] != NULL) all_dead = false;
    }
  }
  if (all_dead) startFight = false;
  
  // 璁＄畻閲嶅績
  newCenter = Pos(0,0);
  count = 0;
  for (i = 0; i < 5; i++) {
    ptr = oursHero[i];
    if (ptr == NULL) continue;
    if ( dis2(posCenter, ptr->pos) > ptr->view ) continue;
    newCenter = newCenter + ptr->pos;
  }
  if (newCenter != Pos(0,0) && count > 0) { // all dead
    posCenter = Pos(newCenter.x / count, newCenter.y / count);
  }
  else posCenter = !info.player ? Pos(5,145) : Pos(145,5);

  others.clear();
  newCenter = Pos(0,0);
  count = 0;
  //info.findUnitByPlayer(1 - info.player, others);
  for (i = 0; i < info.units.size(); i++) {
    ptr = &info.units[i];
    if (ptr->player != info.player && ptr->isHero()) {
      if (ptr->findBuff("Reviving")) {
        blocks.push_back(ptr->pos); 
        continue;
      }
      others.push_back(ptr);
      newCenter = newCenter + ptr->pos; count++;
    }
  }
  if (count == 0) enemyCenter = info.player ? Pos(5,145) : Pos(145,5);
  else enemyCenter = Pos(newCenter.x / count, newCenter.y / count);
  
  wilds.clear();
  for (i = 0; i < info.units.size(); i++) {
    ptr = &info.units[i];
    if (ptr->isWild()) {
      if (ptr->findBuff("Reviving")) {
        blocks.push_back(ptr->pos); 
        continue;
      }
      if (ptr->id == 24 || ptr->id == 27) continue;
      if ( firstTowerExist && (ptr->id == 26 || ptr->id == 29) ) {
        for (j = -2; j <= 2; j++) {
          for (t = -2; t <= 2; t++) {
            blocks.push_back(ptr->pos + Pos(j,t));
          }
        }
        continue;
      }
      wilds.push_back(ptr);
    }
  }
  
  oursTower.clear();
  for (i = 0; i < info.units.size(); i++) {
    ptr = &info.units[i];
    if (ptr->player == info.player && ptr->typeId == 3) {
      oursTower.push_back(ptr);
      blocks.push_back(ptr->pos);
      blocks.push_back(ptr->pos);
    }
  }
  
  // 绠洦鑼冨洿
  if (rainPos != Pos(-1,-1)) {
    for (i = 0; i < 9; i++) {
      blocks.push_back(rainPos + rainDelta[i]);
      blocks.push_back(rainPos - rainDelta[i]);
      blocks.push_back(rainPos + Pos(rainDelta[i].y, rainDelta[i].x) );
      blocks.push_back(rainPos - Pos(rainDelta[i].y, rainDelta[i].x) );
    }
  }
}

bool aimPosArrived(const PPlayerInfo &info) {
  int i;
  for (i = 0; i < 5; i++) {
    if (oursHero[i] == NULL) continue;
    if ( dis2(oursHero[i]->pos, aimPos) <= oursHero[i]->range / 2 ) {
      return true;
    }
  }
  
  return false;
}

bool availableForFirstTower() {
  int i, levelSum = 0;
  
  //if (!TowerExist[2]) return false;
  if (!firstTowerExist) return false;
  
  for (i = 0; i < 5; i++) {
    if (oursHero[i] == NULL) continue;
    levelSum += oursHero[i]->level;
  }
  if (levelSum >= 10) return true;
  
  return false;
}

bool availableForSecondTower() {
  int i, levelSum = 0;
  
  for (i = 0; i < 5; i++) {
    if (oursHero[i] == NULL) continue;
    levelSum += oursHero[i]->level;
  }
  
  if (oursTower.size() == 1) {
    if (levelSum >= 13) return true;
  }
  else if (levelSum >= 16) return true; 
  
  return false;
}

void desAimPos(const PPlayerInfo &info) {
  if (aimPos == Pos(-1,-1) || aimPosArrived(info)) {
    if (aimPos == Pos(-1,-1)) {
      aimPos = !info.player ? Pos(116,96) : Pos(34,54);
      aimType = Wilds;
    }
    else if (availableForFirstTower()) {
      aimPos = towerPos = !info.player ? Pos(34,75) : Pos(116,75);
    }
    else if (availableForSecondTower()) {
      aimPos = towerPos = !info.player ? Pos(75,34) : Pos(75,116);
    }
    else if (aimPos == Pos(116,96) || aimPos == Pos(34,54)
          || aimPos == towerPos ) {
      aimPos = !info.player ? Pos(96,75) : Pos(54,75);
    }
    else if (aimPos == Pos(96,75) || aimPos == Pos(54,75)) {
      aimPos = !info.player ? Pos(116,116) : Pos(34,34);
    }
    else if (aimPos == Pos(116,116) || aimPos == Pos(34,34)) {
      aimPos = !info.player ? Pos(116,96) : Pos(34,54);
    }
    else if (aimPos == Pos(92,116) || aimPos == Pos(58,34)
          || aimPos == towerPos ) {
      aimPos = !info.player ? Pos(54,115) : Pos(96,35);
    }
    else if (aimPos == Pos(54,115) || aimPos == Pos(96,35)) {
      aimPos = !info.player ? Pos(94,142) : Pos(56,8);
    }
    else if (aimPos == Pos(94,142) || aimPos == Pos(56,8)) {
      aimPos = !info.player ? Pos(92,116) : Pos(58,34);
    }
  }
}

void levelUp(int index, PCommand &cmd) {
  Operation op;
  const PUnit *ptr;
  const PSkill *psk;
  
  ptr = oursHero[index];
  op.id = oursId[index];
  
  if (ptr->typeId == 1) {
    if (index == 4) psk = ptr->findSkill("ArrowsRain");
    else psk = ptr->findSkill("PiercingArrow");
    if (psk->level == 2) {
      if (rand() % 2 > 1) op.type = "PULU";
      else op.type = "YellowPoint";
    }
    else {
      if (index == 4) op.type = "ARLU";
      else op.type = "PALU"; //闅忔満鍗囩骇鎶€鑳?
    }
  }
  
  cmd.cmds.push_back(op);
}
// 鑰冭檻寮€涓€涓猇ector锛岄噷闈㈣鐨勬槸涓嶉渶瑕佸嵆鏃惰鍔紝鍙互璺熺潃澶ч儴闃熻蛋鐨勪汉
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
  int i, j, count;
  const PUnit *ptow, *ptr, *pOurs, *pOthers;
  vector<const PUnit*> inSight, target;
  vector<int> escapeId, attackId, moveId;
  Pos nextPos, dir, ddir, center; vector<Pos> tmp;
  DPos dpPos;
  bool readyFightTower;
  string magic;
  int sumOfLevel, sumOfHp, sumOfMaxHp, value, enemy_value;
  
  cmd.cmds.clear(); blocks.clear();
  if (info.round == 0) { chooseHero(info, cmd); return; }
  if (info.round == 1) { init(info); }
  
  findRoles(info);

  // 若敌塔据己方只有3倍视野以内距离，且敌人距离过远，others.clear()
  /*bool ignore = true;
  for (i = 0; i < others.size(); i++) {
    if ( dis2() )
  }*/
  // 评价敌我双方战力 // 考虑逃回塔
  /*if (!others.empty())
  value = enemy_value = 0
  for (i = 0; i < 5; i++) {
    ptr = oursHero[i];
    if (ptr)
  }*/
  
  if (!others.empty() && !firstTowerExist && aimPos == towerPos
   && dis2(posCenter, towerPos) < 3 * Tower_view ) {
    bool continue_attack = true;
    for (i = 0; i < 5; i++) {
      ptr = oursHero[i];
      if (ptr == NULL) continue;
      for (j = 0; j < others.size(); j++) {
        if ( dis2(ptr->pos, others[j]->pos) < 2 * ptr->view ) {
          continue_attack = false; break;
        }
      }
      if (continue_attack == false) break;
    }
    if (continue_attack) others.empty();
  }
  
  // 若某一塔生命值过低，保护之
  if (others.empty())
  for (i = 0; i < oursTower.size(); i++) {
    ptr = oursTower[i];
    if (ptr->hp < ptr->max_hp * 2 / 3) {
      for (j = 0; j < 5; j++) {
        pOurs = oursHero[j];
        if (pOurs == NULL) continue;
        blocks.push_back(pOurs->pos);
      }
      for (j = 0; j < 5; j++) {
        pOurs = oursHero[j];
        if (pOurs == NULL) continue;
        Operation op;
        op.id = oursId[j];
        op.targets.clear();
        if ( dis2(ptr->pos, pOurs->pos) <= Tower_range ) {
          op.type = "Stop";
        }
        else {
          op.type = "Move";
          findShortestPath(map, pOurs->pos, ptr->pos, blocks, op.targets);
        }
        cmd.cmds.push_back(op);
      }
      return;
    }
  }
  
  readyFightTower = true;
  if (aimPos == towerPos) {
    ptow = info.findUnitByPos(aimPos);
    if (aimPosArrived(info) && (ptow == NULL || ptow->isHero() || ptow->isWild()) ) {
      firstTowerExist = false; towerPos = Pos(-1,-1);
      if (oursTower.size() == 2) aimPos = !info.player ? Pos(116,96) : Pos(34,54);
      else {
        if (oursTower[0]->pos == (!info.player ? Pos(116,75) : Pos(34,75) ) ) {
          aimPos = !info.player ? Pos(96,75) : Pos(54,75);
        }
        else aimPos = !info.player ? Pos(92,116) : Pos(58,34);
      }
      //towerPos = aimPos = !info.player ? Pos(75,34) : Pos(75,116); startFight = false;
    }
    
    if (ptow == NULL && others.empty() && !wilds.empty()
     && !(wilds.size() == 1 && wilds[0]->id == 38) ) {
      arroundTowerPushInBlock(towerPos);
      return singleDes(map, info, cmd);
    }
    addOtherWildsInBlocks(-1, NULL);
    
    if (ptow == NULL) startFight = false;
    if (!startFight) {// 鑻ヤ竴寮€濮嬫垬鏂楋紝濮嬬粓涓簍rue
      sumOfLevel = sumOfHp = sumOfMaxHp = 0;
      for (i = 0; i < 5; i++) {
        ptr = oursHero[i];
        if (ptr == NULL) continue;
        if ( dis2(ptr->pos, towerPos) <= Tower_view * 1.5 ) {
          sumOfLevel += ptr->level;
          sumOfHp += ptr->hp;
          sumOfMaxHp += ptr->max_hp;
        }
      }
      if (sumOfMaxHp != 0
       && (double)sumOfLevel * sumOfHp / sumOfMaxHp > 9)
        readyFightTower = startFight = true;
      else readyFightTower = startFight = false;
    }
    
    if (ptow == NULL && !readyFightTower && others.empty()) {
      //if (ptow != NULL)
      for (i = 0; i < 5; i++) {
        ptr = oursHero[i];
        if (ptr == NULL) continue;
        Operation op;
        op.id = oursId[i];
        op.type = "Move";
        op.targets.clear(); tmp.clear();
        if ( dis2(ptr->pos, towerPos) <= Tower_view ) {
          ddir = ptr->pos + (ptr->pos - towerPos);
          
          findShortestPath(map, ptr->pos, ddir, blocks, op.targets);
          cmd.cmds.push_back(op);
          lastRound[i] = op;
        }
        else {
          findShortestPath(map, ptr->pos, aimPos, blocks, tmp);
          op.targets.push_back(tmp[0]);
          for (j = 1; j < tmp.size(); j++) {
            if (dis2(ptr->pos, tmp[j]) > ptr->speed) break;
            if (dis2(tmp[j], towerPos) > Tower_view) {
              op.targets.push_back(tmp[j]);
            }
          }
          blocks.push_back(op.targets.back());
          cmd.cmds.push_back(op);
          lastRound[i] = op;
        }
      }
      
      return;
    }
    else if (others.empty()) {
      if (ptow == NULL) {
        for (i = 0; i < 5; i++) {
          ptr = oursHero[i];
          if (ptr == NULL) continue;
          Operation op;
          op.id = oursId[i];
          op.type = "Move";
          op.targets.clear(); tmp.clear();
          findShortestPath(map, ptr->pos, aimPos, blocks, tmp);
          for (j = 0; j < tmp.size(); j++) {
            op.targets.push_back(tmp[j]);
            if (dis2(tmp[j], towerPos) <= ptr->range) break;
          }
          cmd.cmds.push_back(op);
          lastRound[i] = op;
        }
      }
      else {
        attackId.clear(); moveId.clear();
        for (i = 0; i < 5; i++) {
          ptr = oursHero[i];
          if (ptr == NULL) continue;
          if ( dis2(ptr->pos, towerPos) <= ptow->range ) attackId.push_back(i);
          else moveId.push_back(i);
          // just for a try
          //blocks.push_back(ptr->pos);          
        }
        for (i = 0; i < attackId.size(); i++) 
          fightTower(ptow, map, info, cmd, attackId[i]);
        for (i = 0; i < moveId.size(); i++) 
          fightTower(ptow, map, info, cmd, moveId[i]);
      }
      return;
    }
    else { // !others.empty()
      if (ptow != NULL && startFight) {
        count = 0;
        for (i = 0; i < 5; i++) {
          ptr = oursHero[i];
          if (ptr != NULL)
            count += ptr->atk - ptow->def;
        }
        if (count * 2 >= ptow->hp || dis2(enemyCenter, towerPos) > 3 * Tower_range) {
          for (i = 0; i < 5; i++) {
            if (oursHero[i] != NULL)
              fightTower(ptow, map, info, cmd, i);
          }
          return;
        }
      } // �����¼����ж��Ƿ��������
      
      if (ptow != NULL) { // �������Ĺ�����Χ
        escapeId.clear(); attackId.clear(); moveId.clear();
        for (i = 0; i < 5; i++) {
          ptr = oursHero[i];
          if (ptr == NULL) continue;
          if ( dis2(ptr->pos, towerPos) <= ptow->range ) escapeId.push_back(i);
          else attackId.push_back(i);
        }
        
        for (i = 0; i < escapeId.size(); i++) {
          ptr = oursHero[ escapeId[i] ];
          dir = -1 * ( ptow->pos +  enemyCenter - ptr->pos - posCenter);
          dpPos = DPos((double)dir.x / 100, (double)dir.y / 100);
          
          j = 0;
          while (true) { 
            j++;
            ddir = ptr->pos; ddir.x += j * dpPos.x; ddir.y += j * dpPos.y;
            ddir.x = max(0, min(ddir.x, 149));
            ddir.y = max(0, min(ddir.y, 149));
            if ( dis2(ddir, ptow->pos) > ptow->range ) break;
            if (j >= 21) break;
          }
          if (j >= 21) ddir = ptr->pos + 3 * (ptr->pos - towerPos);
            
          Operation op;
          op.id = oursId[ escapeId[i] ];
          op.type = "Move";
          op.targets.clear(); tmp.clear();
          findShortestPath(map, ptr->pos, ddir, blocks, tmp);
          
          op.targets = tmp;
          cmd.cmds.push_back(op);
          lastRound[ escapeId[i] ] = op;
        }
          
        arroundTowerPushInBlock(towerPos);
        
        for (i = 0; i < attackId.size(); i++) {
          pOurs = oursHero[ attackId[i] ];
          if (pOurs == NULL) { lastRound[ attackId[i] ].type = "Stop"; continue; }
          
          if ( (attackId[i] == 4 && pOurs->canUseSkill(9)) 
           || (attackId[i] != 4 && pOurs->canUseSkill(7)) ) {
            center = skillAvailable(attackId[i], map, info, cmd);
            if (center == Pos(-2,-2)) {
              Operation op;
              op.id = oursId[i];
              op.type = "PowerUp";
              op.targets.clear();
              //op.targets.push_back(pOurs->pos);
              cmd.cmds.push_back(op);
              lastRound[i] = op;
              continue;
            }
            else if (center != Pos(-1,-1)) {
              Operation op;
              op.id = oursId[ attackId[i] ];
              op.type = attackId[i] == 4 ? "ArrowsRain" : "PiercingArrow";
              op.targets.push_back(center);
              cmd.cmds.push_back(op);
              lastRound[i] = op;
              continue;
            }     
          }
          if ( strcmp(lastRound[ attackId[i] ].type.c_str(), "Attack") == 0 ) {
            moveId.push_back(attackId[i]); continue;
          }
          else {
            target.clear();
            findAttackableRoles(pOurs, target, others);
            if (target.empty()) { moveId.push_back(attackId[i]); continue; }

            pOthers = findRoleMostWeak(pOurs, target, attackId, magic); // 鑰冭檻鍒板叾浠栦汉鐨勬敾鍑荤洰鏍?
            if (pOthers == NULL) { moveId.push_back(attackId[i]); continue; }
            
            Operation op;
            op.id = oursId[ attackId[i] ];
            op.type = "Attack";
            op.targets.clear();
            op.targets.push_back(pOthers->pos);
            cmd.cmds.push_back(op);
            lastRound[ attackId[i] ] = op;
          }
        }
        
        for (i = 0; i < moveId.size(); i++) {
          pOurs = oursHero[ moveId[i] ];
          if (pOurs == NULL) continue;
          nextPos = findDodgePos(info, moveId[i], attackId); // 鑰冭檻鍒版墍鏈塧ttack鍜屽皬浜巌鐨勬墍鏈塵ove
          Operation op;
          op.id = oursId[ moveId[i] ];
          op.type = "Move";
          op.targets.clear();
          findShortestPath(map, pOurs->pos, nextPos, blocks, op.targets);
          cmd.cmds.push_back(op);
          lastRound[ moveId[i] ] = op;
        }
        return;
      }
      else {
        singleDes(map, info, cmd);
        return;
      }
    }
  }
  
  if (!others.empty() || !wilds.empty()) {
    singleDes(map, info, cmd);
  }
  else {
    desAimPos(info);
    for (i = 0; i < 5; i++) {
      ptr = oursHero[i];
      if (ptr == NULL) continue;
      
      if ((*ptr)["Exp"]->val[3]) {
        levelUp(i, cmd); continue;
      }
      
      Operation op;
      op.id = oursId[i];
      op.type = "Move";
      op.targets.clear();
      findShortestPath(map, ptr->pos, aimPos, blocks, op.targets);
      cmd.cmds.push_back(op);
      lastRound[i] = op;
    }
  }
}
/* ------------------------------ */
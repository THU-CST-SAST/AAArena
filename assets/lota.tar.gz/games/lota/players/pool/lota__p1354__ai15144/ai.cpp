#include "sdk.h"
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

//#define PDEBUG

#ifndef null
#define null                     (void *)0
#endif
#ifndef NULL
#define NULL                     (void *)0
#endif

//��Ϸ����
#define MAP_SIZE                 151
#define MAX_ROUND                1000

#define DOG_NUM                  (sizeof(Dog_pos)/sizeof(Pos))
#define BOW_NUM                  (sizeof(Bow_pos)/sizeof(Pos))
#define WOLF_NUM                 (sizeof(Wolf_pos)/sizeof(Pos))
#define STONE_MAN_NUM            (sizeof(StoneMan_pos)/sizeof(Pos))
#define DRAGON_NUM               (sizeof(Dragon_pos)/sizeof(Pos))
#define ROSHAN_NUM               (sizeof(Roshan_pos)/sizeof(Pos))
#define PLAYER_TOWER_NUM         (sizeof(Player0_tower_pos)/sizeof(Pos))
#define PLAYER_SPRING_NUM        (sizeof(Player0_spring_pos)/sizeof(Pos))
#define PLAYER_HERO_NUM          (sizeof(Player0_hero_initial_pos)/sizeof(Pos))

#define MONSTER_DOG              0
#define MONSTER_BOW              1
#define MONSTER_WOLF             2
#define MONSTER_STONE_MAN        3
#define MONSTER_DRAGON           4
#define MONSTER_ROSHAN           5
#define MONSTER_TYPE_NUM         6

#define MAX_TYPE_MONSTER_NUM     DOG_NUM

#define DOG_REVIVE               20
#define BOW_REVIVE               20
#define WOLF_REVIVE              25
#define STONE_MAN_REVIVE         25
#define DRAGON_REVIVE            60
#define ROSHAN_REVIVE            80

#define DOG_EXP                  70
#define BOW_EXP                  90
#define WOLF_EXP                 150
#define STONE_MAN_EXP            150
#define DRAGON_EXP               500
#define ROSHAN_EXP               500
 
//��Ϸ�趨
#define ROSHAN_MIN_LEVEL         15
#define DRAGON_MIN_LEVEL         10
#define STONE_MAN_MIN_LEVEL      5
#define TOWER_MIN_LEVEL          10

//������
#define DANGER_SAFE				 0
#define DANGER_ATTACK			 1 
#define DANGER_ENEMY_TOWER		 2
#define DANGER_OCCUPIED			 3 


//�������TypeID
namespace TypeSpace
{
	enum UnitType
	{
		Fighter=0, 
		Archer, 
		Assassin, 
		Tower, 
		Spring, 
		Chooser, 
		Dog, 
		Bow, 
		Wolf, 
		StoneMan, 
		Dragon, 
		Roshan
	};

	enum OperationType
	{
		Attack=0,
		Charge, 
		ChargeLU,
		Spin, 
		SpinLU,
		Yell,
		YellLU, 
		PiercingArrow, 
		PALU, 
		ArrowsRain, 
		ARLU, 
		PowerUp, 
		PULU,
		Hide, 
		HideLU,
		FlyingBlade,
		FBLU, 
		Blink, 
		BlinkLU, 
		YellowPoint, 
		ChooseFighter, 
		ChooseArcher, 
		ChooseAssassin,
		Move,
		Stop
	};

	enum BuffType
	{
		Hided=0, 
		Rainy, 
		Yelled, 
		Yelling, 
		Dizzy, 
		Striking, 
		Slow, 
		Reviving
	};

	enum AreaType
	{
		RainyPlace=0
	};

	enum ArgType
	{
		Hp=0,
		Mp,
		Atk,
		Def,
		Speed,
		Range,
		Exp,
		View,
		LastHit,
		OnlyTraget
	};

	enum FlightType
	{
		FlightBlade=0,
		SignalArrow
	};
}

//��¼Ӣ����Ϣ
struct HeroInfo
{
	int ID;
	int Type;
	int LastDetected;
	int Level;
	int HP;
	int MP;
};

//�洢ÿ�غ���������Ϣ
struct DynamicInfo
{
	int Round;

	std::vector<PUnit> MyHero;
	std::vector<PUnit> MyFighter;
	std::vector<PUnit> MyArcher;
	std::vector<PUnit> MyAssassin;

	std::vector<PUnit> MyHeroAlive;
	std::vector<PUnit> MyFighterAlive;
	std::vector<PUnit> MyArcherAlive;
	std::vector<PUnit> MyAssassinAlive;

	std::vector<PUnit> MyCampHero;
	std::vector<PUnit> MyCampFighter;
	std::vector<PUnit> MyCampArcher;
	std::vector<PUnit> MyCampAssassin;

	std::vector<PUnit> MyCampHeroAlive;
	std::vector<PUnit> MyCampFighterAlive;
	std::vector<PUnit> MyCampArcherAlive;
	std::vector<PUnit> MyCampAssassinAlive;

	std::vector<PUnit> EnemyHero;
	std::vector<PUnit> EnemyFighter;
	std::vector<PUnit> EnemyArcher;
	std::vector<PUnit> EnemyAssassin;

	std::vector<PUnit> EnemyHeroAlive;
	std::vector<PUnit> EnemyFighterAlive;
	std::vector<PUnit> EnemyArcherAlive;
	std::vector<PUnit> EnemyAssassinAlive;

	std::vector<PUnit> MyChooser;

	std::vector<PUnit> Monster;
	std::vector<PUnit> Dog;
	std::vector<PUnit> Bow;
	std::vector<PUnit> Wolf;
	std::vector<PUnit> StoneMan;
	std::vector<PUnit> Dragon;
	std::vector<PUnit> Roshan;

	std::vector<PUnit> MonsterAlive;
	std::vector<PUnit> DogAlive;
	std::vector<PUnit> BowAlive;
	std::vector<PUnit> WolfAlive;
	std::vector<PUnit> StoneManAlive;
	std::vector<PUnit> DragonAlive;
	std::vector<PUnit> RoshanAlive;
	
	std::vector<PUnit> MyTower;
	std::vector<PUnit> MySpring;
	std::vector<PUnit> MyCampTower;
	std::vector<PUnit> MyCampSpring;
	std::vector<PUnit> EnemyTower;
	std::vector<PUnit> EnemySpring;

	std::vector<PFlight> MyCampSignalArrow;
	std::vector<PFlight> MyCampFlyingBlade;
	std::vector<PArea> MyCampRainyPlace;

	std::vector<PFlight> EnemySignalArrow;
	std::vector<PFlight> EnemyFlyingBlade;
	std::vector<PArea> EnemyRainyPlace;

	std::vector<Pos> Block;

	bool EnemyTowerAlive[PLAYER_TOWER_NUM];
	bool MyTowerAlive[PLAYER_TOWER_NUM];
	int MonsterReviveTime[MONSTER_TYPE_NUM][MAX_TYPE_MONSTER_NUM];

	int MyTotalLevel;
	int EnemyTotalLevel;

	Pos MonsterPos[MONSTER_TYPE_NUM][MAX_TYPE_MONSTER_NUM];
	std::vector<Pos> PathToMonster[PLAYER_HERO_NUM][MONSTER_TYPE_NUM][MAX_TYPE_MONSTER_NUM];

	bool DangerousPoint[MAP_SIZE][MAP_SIZE];
};

//�洢ÿ���������һ�ε���Ϣ
struct StaticInfo
{
	int MyCamp;
	int MyPlayer;
	int MyPlayerThisGame;

	Pos MyTowerPos[PLAYER_TOWER_NUM];
	Pos MySpringPos[PLAYER_SPRING_NUM];
	Pos MyChooserPos[PLAYER_HERO_NUM];
	Pos MyHeroInitialPos[PLAYER_HERO_NUM];

	Pos EnemyTowerPos[PLAYER_TOWER_NUM];
	Pos EnemySpringPos[PLAYER_SPRING_NUM];
	Pos EnemyChooserPos[PLAYER_HERO_NUM];
	Pos EnemyHeroInitialPos[PLAYER_HERO_NUM];

	int TypeMonsterNum[MONSTER_TYPE_NUM];
	int MonsterRevive[MONSTER_TYPE_NUM];
	int MonsterReachable[MONSTER_TYPE_NUM][MAX_TYPE_MONSTER_NUM];
	int MonsterExp[MONSTER_TYPE_NUM];
	Pos MonsterRevivePos[MONSTER_TYPE_NUM][MAX_TYPE_MONSTER_NUM];

	std::vector<Pos> EmptyBlock;

	std::vector<std::vector<Pos> > NearPointIndex;
};

//������Ϣ
#ifdef PDEBUG
FILE *Debug=fopen("Debug.txt", "w");
#endif

//����Ұ��λ�ü��������������-----------------------
void GetMonsterTypeIndex(const StaticInfo &SInfo, const PUnit &Monster, int &Type, int &Index);

//����·��ʵ�ʳ���ƽ��
double GetPathLength2(const std::vector<Pos> &Path);

//��Ϣ��Դ���㹤��-----------------------------------
void GetDynamicInfo(const PMap &Map, const PPlayerInfo &Info, DynamicInfo &DInfo, const StaticInfo &SInfo);
void GetStaticInfoFirst(const PMap &Map, const PPlayerInfo &Info, const DynamicInfo &DInfo, StaticInfo &SInfo);
void GetStaticInfoSecond(const PMap &Map, const PPlayerInfo &Info, const DynamicInfo &DInfo, StaticInfo &SInfo);
int GetEnemyHeroLog(const DynamicInfo &DInfo, std::vector<HeroInfo> &EnemyHeroLog);

//���ߺ�������---------------------------------------
Operation GetArcherCommand(const PMap &Map, DynamicInfo &DInfo, const StaticInfo &SInfo, const PUnit &Archer, const Pos &Target, bool UseAttackSkill);

//·����ع���---------------------------------------
void FindPath(const PMap &Map, const Pos &Start, const std::vector<Pos> &Dest, const std::vector<Pos> &Block, std::vector<std::vector<Pos> > &Path);
void FindPath(const PMap &Map, const Pos &Start, const Pos &Dest, const std::vector<Pos> &Block, std::vector<Pos> &Path);

//ͨ�ü��㹤��---------------------------------------
inline bool CheckPos(const Pos &A);
int VectorMax(const std::vector<int> &Data);
inline int Dis2(const Pos &A, const Pos &B);

//-------------------------------------------------------------------------------------------------------------------------------------
//���뿪ʼ-----------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------

//AI����---------------------------------------------
void player_ai(const PMap &Map, const PPlayerInfo &Info, PCommand &Cmd)
{
#ifdef PDEBUG
	fprintf(Debug, "\n\nRound %d\n", Info.round);
	fprintf(Debug, "player_ai Called\n");
	fflush(Debug);
#endif
	
	static StaticInfo SInfo;
	DynamicInfo DInfo;
	static std::vector<std::vector<PUnit> > MyHeroGroup;
	static std::vector<HeroInfo> EnemyHeroLog;

	int i, j, k;

	//��Ϣ��ȡ------------------------------------------------
	if(Info.round==0)
	{
		GetStaticInfoFirst(Map, Info, DInfo, SInfo);
	}
	GetDynamicInfo(Map, Info, DInfo, SInfo);
	if(Info.round==0)
	{
		GetStaticInfoSecond(Map, Info, DInfo, SInfo);
	}
	DInfo.EnemyTotalLevel=GetEnemyHeroLog(DInfo, EnemyHeroLog);

	//���������
	srand(DInfo.Round);

	//׼����������-------------------------------------------
	std::vector<Operation> &CmdQueue=Cmd.cmds;
	CmdQueue.clear();

	//��һ�غ�------------------------------------------------
	if(DInfo.Round==0)
	{
		//ѡ��Ӣ��-------------------------------------------
		for(i=0;i<DInfo.MyChooser.size();i++)
		{
			Operation Command;

			Command.id=DInfo.MyChooser[i].id;
			Command.typeId=TypeSpace::ChooseArcher;

			CmdQueue.push_back(Command);
		}
	}
	//�����غ�------------------------------------------------
	else 
	{
		//��������
		if(DInfo.EnemyHeroAlive.size()>0)
		{
#ifdef PDEBUG
			fprintf(Debug, "�������� %d %d\n", DInfo.EnemyHero[0].pos.x, DInfo.EnemyHero[0].pos.y);
			fflush(Debug);
#endif

			for(i=0;i<DInfo.MyArcher.size();i++)
			{
				CmdQueue.push_back(GetArcherCommand(Map, DInfo, SInfo, DInfo.MyArcher[i], DInfo.EnemyHeroAlive[0].pos, true));
			}
		}

		//�����㹻ʱ����--------------------------
		else if(DInfo.MyTotalLevel>TOWER_MIN_LEVEL)
		{
#ifdef PDEBUG
			fprintf(Debug, "����");
			fflush(Debug);
#endif

			//ȡ������Σ���趨
			for(i=0;i<PLAYER_TOWER_NUM;i++)
			{
				if(DInfo.EnemyTowerAlive[i])
				{
					for(j=0;j<sqrt(Tower_range);j++)
					{
						for(k=0;k<SInfo.NearPointIndex[j].size();k++)
						{
							Pos DangerousPoint_t=SInfo.EnemyTowerPos[i]+SInfo.NearPointIndex[j][k];
							if(CheckPos(DangerousPoint_t))
							{
								DInfo.DangerousPoint[DangerousPoint_t.x][DangerousPoint_t.y]=DANGER_SAFE;
							}
						}
					}
				}
			}

			Pos Dest;
			bool DestGot=false;

			for(i=0;i<PLAYER_TOWER_NUM;i++)
			{
				if(DInfo.EnemyTowerAlive[i])
				{
					Dest=SInfo.EnemyTowerPos[i];
					DestGot=true;
					break;
				}
			}

			//��������----------------------
			if(DestGot)
			{
#ifdef PDEBUG
				fprintf(Debug, "����Ŀ�� %d %d\n", Dest.x, Dest.y);
				fflush(Debug);
#endif
				for(i=0;i<DInfo.MyArcher.size();i++)
				{
					CmdQueue.push_back(GetArcherCommand(Map, DInfo, SInfo, DInfo.MyArcher[i], Dest, true));
				}
			}
			//��������----------------------
			else
			{
#ifdef PDEBUG
				fprintf(Debug, "�������\n");
				fflush(Debug);
#endif
			}
		}

		//��Ұ
		else
		{
			//�����ҰĿ��
			Pos Dest;

			int MostHighLevelMonster;

			if(DInfo.MyTotalLevel>ROSHAN_MIN_LEVEL)
			{
				MostHighLevelMonster=MONSTER_ROSHAN;
			}
			else if(DInfo.MyTotalLevel>DRAGON_MIN_LEVEL)
			{
				MostHighLevelMonster=MONSTER_DRAGON;
			}
			else if(DInfo.MyTotalLevel>STONE_MAN_MIN_LEVEL)
			{
				MostHighLevelMonster=MONSTER_STONE_MAN;
			}
			else
			{
				MostHighLevelMonster=MONSTER_WOLF;
			}

			int TotalDis;
			double SearchEffect;
			double MaxSearchEffect=0;
			int HitMonsterType;
			int HitMonsterIndex;
			static double LastMaxSearchEffect=0;
			static int LastHitMonsterType=0;
			static int LastHitMonsterIndex=0;

			for(i=0;i<=MostHighLevelMonster;i++)
			{
				for(j=0;j<SInfo.TypeMonsterNum[i];j++)
				{
					if(SInfo.MonsterReachable[i][j] && DInfo.MonsterReviveTime[i][j]==0)
					{
						TotalDis=0;
						for(k=0;k<PLAYER_HERO_NUM;k++)
						{
							TotalDis+=DInfo.PathToMonster[k][i][j].size();
						}
						SearchEffect=SInfo.MonsterExp[i]/(double)TotalDis;
						if(Dis2(DInfo.MonsterPos[i][j], SInfo.MyTowerPos[0])+Dis2(DInfo.MonsterPos[i][j], SInfo.MyTowerPos[1])>14000)
						{
							SearchEffect=0;
						}
						if(SearchEffect>MaxSearchEffect)
						{
							MaxSearchEffect=SearchEffect;
							HitMonsterType=i;
							HitMonsterIndex=j;
						}
					}
					else
					{
						if(i==LastHitMonsterType && j==LastHitMonsterIndex)
						{
							LastMaxSearchEffect=0;
						}
					}
				}
			}

#ifdef PDEBUG
			fprintf(Debug, "����Ч�� %.4lf, �ϴ�Ч�� %.4lf, �ϴ�Ŀ�� %d %d\n", MaxSearchEffect, LastMaxSearchEffect, LastHitMonsterType, LastHitMonsterIndex);
			fflush(Debug);
#endif

			if(LastMaxSearchEffect==0 || MaxSearchEffect/LastMaxSearchEffect>1.1)
			{
				Dest=DInfo.MonsterPos[HitMonsterType][HitMonsterIndex];
				LastMaxSearchEffect=MaxSearchEffect;
				LastHitMonsterType=HitMonsterType;
				LastHitMonsterIndex=HitMonsterIndex;
			}
			else
			{
				Dest=DInfo.MonsterPos[LastHitMonsterType][LastHitMonsterIndex];
			}

#ifdef PDEBUG
			fprintf(Debug, "��ҰĿ�� %d %d\n", Dest.x, Dest.y);
			fflush(Debug);
#endif

			for(i=0;i<DInfo.MyArcher.size();i++)
			{
				CmdQueue.push_back(GetArcherCommand(Map, DInfo, SInfo, DInfo.MyArcher[i], Dest, DInfo.MyTotalLevel<10));
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "player_ai Finished\n");
	fflush(Debug);
#endif
}

//��Ϣ��Դ���㹤��-----------------------------------
void GetDynamicInfo(const PMap &Map, const PPlayerInfo &Info, DynamicInfo &DInfo, const StaticInfo &SInfo)
{
#ifdef PDEBUG
	fprintf(Debug, "GetDynamicInfo Called\n");
	fflush(Debug);
#endif
	int i, j, k;

	memcpy(DInfo.MonsterPos[MONSTER_DOG], Dog_pos, sizeof(Dog_pos));
	memcpy(DInfo.MonsterPos[MONSTER_BOW], Bow_pos, sizeof(Bow_pos));
	memcpy(DInfo.MonsterPos[MONSTER_WOLF], Wolf_pos, sizeof(Wolf_pos));
	memcpy(DInfo.MonsterPos[MONSTER_STONE_MAN], StoneMan_pos, sizeof(StoneMan_pos));
	memcpy(DInfo.MonsterPos[MONSTER_DRAGON], Dragon_pos, sizeof(Dragon_pos));
	memcpy(DInfo.MonsterPos[MONSTER_ROSHAN], Roshan_pos, sizeof(Roshan_pos));

	DInfo.Round=Info.round;

	//����
	for(i=0;i<Info.units.size();i++)
	{
		const PUnit &ThisUnit=Info.units[i];

		DInfo.Block.push_back(ThisUnit.pos);

		if(ThisUnit.camp==Info.camp)
		{
			if(ThisUnit.player==Info.player)
			{
				if(ThisUnit.typeId==TypeSpace::Fighter)
				{
					DInfo.MyFighter.push_back(ThisUnit);
					DInfo.MyCampFighter.push_back(ThisUnit);
					DInfo.MyHero.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyFighterAlive.push_back(ThisUnit);
						DInfo.MyCampFighterAlive.push_back(ThisUnit);
						DInfo.MyHeroAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Archer)
				{
					DInfo.MyArcher.push_back(ThisUnit);
					DInfo.MyCampArcher.push_back(ThisUnit);
					DInfo.MyHero.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyArcherAlive.push_back(ThisUnit);
						DInfo.MyCampArcherAlive.push_back(ThisUnit);
						DInfo.MyHeroAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Assassin)
				{
					DInfo.MyAssassin.push_back(ThisUnit);
					DInfo.MyCampAssassin.push_back(ThisUnit);
					DInfo.MyHero.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyAssassinAlive.push_back(ThisUnit);
						DInfo.MyCampAssassinAlive.push_back(ThisUnit);
						DInfo.MyHeroAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Tower)
				{
					DInfo.MyTower.push_back(ThisUnit);
					DInfo.MyCampTower.push_back(ThisUnit);
					DInfo.Block.push_back(ThisUnit.pos);
				}
				else if(ThisUnit.typeId==TypeSpace::Spring)
				{
					DInfo.MySpring.push_back(ThisUnit);
					DInfo.MyCampSpring.push_back(ThisUnit);
				}
				else if(ThisUnit.typeId==TypeSpace::Chooser)
				{
					DInfo.MyChooser.push_back(ThisUnit);
				}
			}
			else
			{
				if(ThisUnit.typeId==TypeSpace::Fighter)
				{
					DInfo.MyCampFighter.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyCampFighterAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Archer)
				{
					DInfo.MyCampArcher.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyCampArcherAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Assassin)
				{
					DInfo.MyCampAssassin.push_back(ThisUnit);
					DInfo.MyCampHero.push_back(ThisUnit);
					if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
					{
						DInfo.MyCampAssassinAlive.push_back(ThisUnit);
						DInfo.MyCampHeroAlive.push_back(ThisUnit);
					}
					else
					{
						DInfo.Block.push_back(ThisUnit.pos);
					}
				}
				else if(ThisUnit.typeId==TypeSpace::Tower)
				{
					DInfo.MyCampTower.push_back(ThisUnit);
					DInfo.Block.push_back(ThisUnit.pos);
				}
				else if(ThisUnit.typeId==TypeSpace::Spring)
				{
					DInfo.MyCampSpring.push_back(ThisUnit);
				}
			}
		}
		else if(ThisUnit.camp==2)
		{
			if(ThisUnit.typeId==TypeSpace::Dog)
			{
				DInfo.Dog.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.DogAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Bow)
			{
				DInfo.Bow.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.BowAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Wolf)
			{
				DInfo.Wolf.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.WolfAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::StoneMan)
			{
				DInfo.StoneMan.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.StoneManAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Dragon)
			{
				DInfo.Dragon.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.DragonAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Roshan)
			{
				DInfo.Roshan.push_back(ThisUnit);
				DInfo.Monster.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.RoshanAlive.push_back(ThisUnit);
					DInfo.MonsterAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
		}
		else
		{
			if(ThisUnit.typeId==TypeSpace::Fighter)
			{
				DInfo.EnemyFighter.push_back(ThisUnit);
				DInfo.EnemyHero.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.EnemyFighterAlive.push_back(ThisUnit);
					DInfo.EnemyHeroAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Archer)
			{
				DInfo.EnemyArcher.push_back(ThisUnit);
				DInfo.EnemyHero.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.EnemyArcherAlive.push_back(ThisUnit);
					DInfo.EnemyHeroAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Assassin)
			{
				DInfo.EnemyAssassin.push_back(ThisUnit);
				DInfo.EnemyHero.push_back(ThisUnit);
				if(ThisUnit.findBuff(TypeSpace::Reviving)==null)
				{
					DInfo.EnemyAssassinAlive.push_back(ThisUnit);
					DInfo.EnemyHeroAlive.push_back(ThisUnit);
				}
				else
				{
					DInfo.Block.push_back(ThisUnit.pos);
				}
			}
			else if(ThisUnit.typeId==TypeSpace::Tower)
			{
				DInfo.EnemyTower.push_back(ThisUnit);
				DInfo.Block.push_back(ThisUnit.pos);
			}
			else if(ThisUnit.typeId==TypeSpace::Spring)
			{
				DInfo.EnemySpring.push_back(ThisUnit);
			}
		}
	}

	for(i=0;i<Info.flights.size();i++)
	{
		const PFlight &ThisFlight=Info.flights[i];

		if(ThisFlight.camp==Info.camp)
		{
			if(ThisFlight.typeId==TypeSpace::SignalArrow)
			{
				DInfo.MyCampSignalArrow.push_back(ThisFlight);
			}
			else if(ThisFlight.typeId==TypeSpace::FlyingBlade)
			{
				DInfo.MyCampFlyingBlade.push_back(ThisFlight);
			}
		}
		else if(ThisFlight.camp!=2)
		{
			if(ThisFlight.typeId==TypeSpace::SignalArrow)
			{
				DInfo.EnemySignalArrow.push_back(ThisFlight);
			}
			else if(ThisFlight.typeId==TypeSpace::FlyingBlade)
			{
				DInfo.EnemyFlyingBlade.push_back(ThisFlight);
			}
		}
	}

	for(i=0;i<Info.areas.size();i++)
	{
		const PArea &ThisArea=Info.areas[i];

		if(ThisArea.camp==Info.camp)
		{
			if(ThisArea.typeId==TypeSpace::RainyPlace)
			{
				DInfo.MyCampRainyPlace.push_back(ThisArea);
			}
		}
		else if(ThisArea.camp!=2)
		{
			if(ThisArea.typeId==TypeSpace::RainyPlace)
			{
				DInfo.EnemyRainyPlace.push_back(ThisArea);
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "����Ӣ�� %d Ұ�� %d ������ %d �з�Ӣ�� %d �������� %d\n", DInfo.MyHero.size(), DInfo.Monster.size(), DInfo.MyTower.size(), DInfo.EnemyHero.size(), DInfo.MyCampRainyPlace.size());
	fflush(Debug);
#endif

	//ͳ�Ƽ�����ǰ�ܵȼ�
	DInfo.MyTotalLevel=0;
	for(i=0;i<DInfo.MyHero.size();i++)
	{
		DInfo.MyTotalLevel+=DInfo.MyHero[i].level;
	}
	
#ifdef PDEBUG
	fprintf(Debug, "�����ܵȼ� %d\n", DInfo.MyTotalLevel);
	fflush(Debug);
#endif

	//���¼����з����Ĵ��״̬
	if(DInfo.Round==0)
	{
		for(i=0;i<PLAYER_TOWER_NUM;i++)
		{
			DInfo.EnemyTowerAlive[i]=true;
		}
		for(i=0;i<PLAYER_TOWER_NUM;i++)
		{
			DInfo.MyTowerAlive[i]=true;
		}
	}
	else
	{
		bool MustExist;
		bool Exist;
		for(i=0;i<PLAYER_TOWER_NUM;i++)
		{
			MustExist=false;
			for(j=0;j<DInfo.MyHero.size();j++)
			{
				if(Dis2(DInfo.MyHero[j].pos, SInfo.EnemyTowerPos[i])<121)
				{
					MustExist=true;
					break;
				}
			}

			if(MustExist)
			{
				Exist=false;
				for(j=0;j<DInfo.EnemyTower.size();k++)
				{
					if(Dis2(DInfo.EnemyTower[j].pos, SInfo.EnemyTowerPos[i])<16)
					{
						Exist=true;
						break;
					}
				}

				if(Exist)
				{
					DInfo.EnemyTowerAlive[i]=true;
				}
				else
				{
					DInfo.EnemyTowerAlive[i]=false;
				}
			}

			Exist=false;
			for(j=0;j<DInfo.MyTower.size();j++)
			{
				if(Dis2(DInfo.MyTower[j].pos, SInfo.MyTowerPos[i])<16)
				{
					Exist=true;
					break;
				}
			}

			if(Exist)
			{
				DInfo.MyTowerAlive[i]=true;
			}
			else
			{
				DInfo.MyTowerAlive[i]=false;
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "�з��������� %d %d\n", DInfo.EnemyTowerAlive[0]?1:0, DInfo.EnemyTowerAlive[1]?1:0);
	fprintf(Debug, "�ҷ��������� %d %d\n", DInfo.MyTowerAlive[0]?1:0, DInfo.MyTowerAlive[1]?1:0);
	fflush(Debug);
#endif

	//����Ұ��λ�úʹ��״̬
	if(DInfo.Round==0)
	{
		for(i=0;i<MONSTER_TYPE_NUM;i++)
		{
			for(j=0;j<SInfo.TypeMonsterNum[i];j++)
			{
				DInfo.MonsterReviveTime[i][j]=0;
			}
		}
	}
	else
	{
		for(i=0;i<MONSTER_TYPE_NUM;i++)
		{
			for(j=0;j<SInfo.TypeMonsterNum[i];j++)
			{
				DInfo.MonsterReviveTime[i][j]--;
				if(DInfo.MonsterReviveTime[i][j]<0)
				{
					DInfo.MonsterReviveTime[i][j]=0;
				}
			}
		}

		int MonsterType;
		int MonsterIndex;
		for(i=0;i<DInfo.Monster.size();i++)
		{
			GetMonsterTypeIndex(SInfo, DInfo.Monster[i], MonsterType, MonsterIndex);
			DInfo.MonsterPos[MonsterType][MonsterIndex]=DInfo.Monster[i].pos;
			if(DInfo.Monster[i].findBuff(TypeSpace::Reviving)!=null)
			{
				DInfo.MonsterReviveTime[MonsterType][MonsterIndex]=SInfo.MonsterRevive[MonsterType]+VectorMax(DInfo.Monster[i][TypeSpace::LastHit]->val)-DInfo.Round;
			}
			else
			{
				DInfo.MonsterReviveTime[MonsterType][MonsterIndex]=0;
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "Ұ�ָ������\n");
	for(i=0;i<MONSTER_TYPE_NUM;i++)
	{
		for(j=0;j<SInfo.TypeMonsterNum[i];j++)
		{
			fprintf(Debug, "%d ", DInfo.MonsterReviveTime[i][j]);
		}
		fprintf(Debug, "\n");
	}
	fflush(Debug);
#endif

#ifdef PDEBUG
	fprintf(Debug, "Ұ��λ�����\n");
	for(i=0;i<MONSTER_TYPE_NUM;i++)
	{
		for(j=0;j<SInfo.TypeMonsterNum[i];j++)
		{
			fprintf(Debug, "(%d,%d) ", DInfo.MonsterPos[i][j].x, DInfo.MonsterPos[i][j].y);
		}
		fprintf(Debug, "\n");
	}
	fflush(Debug);
#endif

	//�������м���Ӣ�۵�����Ұ��·��
	if(DInfo.Round==0)
	{

	}
	else
	{
		std::vector<Pos> TargetList;
		for(i=0;i<MONSTER_TYPE_NUM;i++)
		{
			for(j=0;j<SInfo.TypeMonsterNum[i];j++)
			{
				TargetList.push_back(DInfo.MonsterPos[i][j]);
			}
		}

		std::vector<std::vector<Pos> > Path;
		for(i=0;i<DInfo.MyHero.size();i++)
		{
			FindPath(Map, DInfo.MyHero[i].pos, TargetList, SInfo.EmptyBlock, Path);

			int StartIndex=0;
			for(j=0;j<MONSTER_TYPE_NUM;j++)
			{
				for(k=0;k<SInfo.TypeMonsterNum[j];k++)
				{
					DInfo.PathToMonster[i][j][k]=Path[StartIndex+k];
				}
				StartIndex+=SInfo.TypeMonsterNum[j];
			}
		}

#ifdef PDEBUG
		fprintf(Debug, "Ұ��·�����\n");
		for(i=0;i<MONSTER_TYPE_NUM;i++)
		{
			for(j=0;j<SInfo.TypeMonsterNum[i];j++)
			{
				fprintf(Debug, "%d ", DInfo.PathToMonster[0][i][j].size());
			}
			fprintf(Debug, "\n");
		}
		fflush(Debug);
#endif
	}

	//Σ�������趨
	if(DInfo.Round>0)
	{
		memset(DInfo.DangerousPoint, DANGER_SAFE, sizeof(bool)*MAP_SIZE*MAP_SIZE);
		for(i=0;i<DInfo.Block.size();i++)
		{
			DInfo.DangerousPoint[DInfo.Block[i].x][DInfo.Block[i].y]=DANGER_OCCUPIED;
		}
		for(i=0;i<PLAYER_TOWER_NUM;i++)
		{
			if(DInfo.EnemyTowerAlive[i])
			{
				for(j=0;j<sqrt(Tower_range);j++)
				{
					for(k=0;k<SInfo.NearPointIndex[j].size();k++)
					{
						Pos DangerousPoint_t=SInfo.EnemyTowerPos[i]+SInfo.NearPointIndex[j][k];
						if(CheckPos(DangerousPoint_t))
						{
							DInfo.DangerousPoint[DangerousPoint_t.x][DangerousPoint_t.y]=DANGER_ENEMY_TOWER;
						}
					}
				}
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "GetDynamicInfo Finished\n");
	fflush(Debug);
#endif
}

void GetStaticInfoFirst(const PMap &Map, const PPlayerInfo &Info, const DynamicInfo &DInfo, StaticInfo &SInfo)
{
#ifdef PDEBUG
	fprintf(Debug, "GetStaticInfoFirst Called\n");
	fflush(Debug);
#endif

	int i, j;

	SInfo.MyCamp=Info.camp;
	SInfo.MyPlayer=Info.player;

	SInfo.TypeMonsterNum[MONSTER_DOG]=DOG_NUM;
	SInfo.TypeMonsterNum[MONSTER_BOW]=BOW_NUM;
	SInfo.TypeMonsterNum[MONSTER_WOLF]=WOLF_NUM;
	SInfo.TypeMonsterNum[MONSTER_STONE_MAN]=STONE_MAN_NUM;
	SInfo.TypeMonsterNum[MONSTER_DRAGON]=DRAGON_NUM;
	SInfo.TypeMonsterNum[MONSTER_ROSHAN]=ROSHAN_NUM;

	SInfo.MonsterRevive[MONSTER_DOG]=DOG_REVIVE;
	SInfo.MonsterRevive[MONSTER_BOW]=BOW_REVIVE;
	SInfo.MonsterRevive[MONSTER_WOLF]=WOLF_REVIVE;
	SInfo.MonsterRevive[MONSTER_STONE_MAN]=STONE_MAN_REVIVE;
	SInfo.MonsterRevive[MONSTER_DRAGON]=DRAGON_REVIVE;
	SInfo.MonsterRevive[MONSTER_ROSHAN]=ROSHAN_REVIVE;

	SInfo.MonsterExp[MONSTER_DOG]=DOG_EXP;
	SInfo.MonsterExp[MONSTER_BOW]=BOW_EXP;
	SInfo.MonsterExp[MONSTER_WOLF]=WOLF_EXP;
	SInfo.MonsterExp[MONSTER_STONE_MAN]=STONE_MAN_EXP;
	SInfo.MonsterExp[MONSTER_DRAGON]=DRAGON_EXP;
	SInfo.MonsterExp[MONSTER_ROSHAN]=ROSHAN_EXP;

	memcpy(SInfo.MonsterRevivePos[MONSTER_DOG], Dog_pos, sizeof(Dog_pos));
	memcpy(SInfo.MonsterRevivePos[MONSTER_BOW], Bow_pos, sizeof(Bow_pos));
	memcpy(SInfo.MonsterRevivePos[MONSTER_WOLF], Wolf_pos, sizeof(Wolf_pos));
	memcpy(SInfo.MonsterRevivePos[MONSTER_STONE_MAN], StoneMan_pos, sizeof(StoneMan_pos));
	memcpy(SInfo.MonsterRevivePos[MONSTER_DRAGON], Dragon_pos, sizeof(Dragon_pos));
	memcpy(SInfo.MonsterRevivePos[MONSTER_ROSHAN], Roshan_pos, sizeof(Roshan_pos));

	std::vector<Pos> PointIndex;
	for(i=1;i<20;i++)
	{
		SInfo.NearPointIndex.push_back(PointIndex);
		for(j=-1*i+1;j<i;j++)
		{
			SInfo.NearPointIndex[i-1].push_back(Pos(i, j));
			SInfo.NearPointIndex[i-1].push_back(Pos(-1*i, j));
			SInfo.NearPointIndex[i-1].push_back(Pos(j, i));
			SInfo.NearPointIndex[i-1].push_back(Pos(j, -1*i));
		}
		SInfo.NearPointIndex[i-1].push_back(Pos(i, -1*i));
		SInfo.NearPointIndex[i-1].push_back(Pos(i, i));
		SInfo.NearPointIndex[i-1].push_back(Pos(-1*i, i));
		SInfo.NearPointIndex[i-1].push_back(Pos(-1*i, i));
	}

#ifdef PDEBUG
	fprintf(Debug, "GetStaticInfoFirst Finished\n");
	fflush(Debug);
#endif
}

void GetStaticInfoSecond(const PMap &Map, const PPlayerInfo &Info, const DynamicInfo &DInfo, StaticInfo &SInfo)
{
#ifdef PDEBUG
	fprintf(Debug, "GetStaticInfoSecond Called\n");
	fflush(Debug);
#endif

	int i, j;

	if(DInfo.MySpring[0].pos.x<DInfo.MySpring[0].pos.y)
	{
		SInfo.MyPlayerThisGame=0;
		memcpy(SInfo.MyTowerPos, Player0_tower_pos, sizeof(Player0_tower_pos));
		memcpy(SInfo.MySpringPos, Player0_spring_pos, sizeof(Player0_spring_pos));
		memcpy(SInfo.MyChooserPos, Player0_chooser_pos, sizeof(Player0_chooser_pos));
		memcpy(SInfo.MyHeroInitialPos, Player0_hero_initial_pos, sizeof(Player0_hero_initial_pos));
		memcpy(SInfo.EnemyTowerPos, Player1_tower_pos, sizeof(Player1_tower_pos));
		memcpy(SInfo.EnemySpringPos, Player1_spring_pos, sizeof(Player1_spring_pos));
		memcpy(SInfo.EnemyChooserPos, Player1_chooser_pos, sizeof(Player1_chooser_pos));
		memcpy(SInfo.EnemyHeroInitialPos, Player1_hero_initial_pos, sizeof(Player1_hero_initial_pos));
	}
	else
	{
		SInfo.MyPlayerThisGame=1;
		memcpy(SInfo.MyTowerPos, Player1_tower_pos, sizeof(Player1_tower_pos));
		memcpy(SInfo.MySpringPos, Player1_spring_pos, sizeof(Player1_spring_pos));
		memcpy(SInfo.MyChooserPos, Player1_chooser_pos, sizeof(Player1_chooser_pos));
		memcpy(SInfo.MyHeroInitialPos, Player1_hero_initial_pos, sizeof(Player1_hero_initial_pos));
		memcpy(SInfo.EnemyTowerPos, Player0_tower_pos, sizeof(Player0_tower_pos));
		memcpy(SInfo.EnemySpringPos, Player0_spring_pos, sizeof(Player0_spring_pos));
		memcpy(SInfo.EnemyChooserPos, Player0_chooser_pos, sizeof(Player0_chooser_pos));
		memcpy(SInfo.EnemyHeroInitialPos, Player0_hero_initial_pos, sizeof(Player0_hero_initial_pos));
	}
	//�����͵з������뼺��Ȫˮ�������򣨽�~Զ��
	Pos Temp;
	for(i=0;i<PLAYER_TOWER_NUM-1;i++)
	{
		for(j=i+1;j<PLAYER_TOWER_NUM;j++)
		{
			if(Dis2(SInfo.MySpringPos[0], SInfo.MyTowerPos[i])>Dis2(SInfo.MySpringPos[0], SInfo.MyTowerPos[j]))
			{
				Temp=SInfo.MyTowerPos[j];
				SInfo.MyTowerPos[j]=SInfo.MyTowerPos[i];
				SInfo.MyTowerPos[i]=Temp;
			}
			if(Dis2(SInfo.MySpringPos[0], SInfo.EnemyTowerPos[i])>Dis2(SInfo.MySpringPos[0], SInfo.EnemyTowerPos[j]))
			{
				Temp=SInfo.EnemyTowerPos[j];
				SInfo.EnemyTowerPos[j]=SInfo.EnemyTowerPos[i];
				SInfo.EnemyTowerPos[i]=Temp;
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "�з�����");
	for(i=0;i<PLAYER_TOWER_NUM;i++)
	{
		fprintf(Debug, "(%d,%d) ", SInfo.EnemyTowerPos[i].x, SInfo.EnemyTowerPos[i].y);
	}
	fprintf(Debug, "\n��������");
	for(i=0;i<PLAYER_TOWER_NUM;i++)
	{
		fprintf(Debug, "(%d,%d) ", SInfo.MyTowerPos[i].x, SInfo.MyTowerPos[i].y);
	}
	fprintf(Debug, "\n");
	fflush(Debug);
#endif

	//����Ұ����ͨ���
	std::vector<Pos> TargetList;
	for(i=0;i<MONSTER_TYPE_NUM;i++)
	{
		for(j=0;j<SInfo.TypeMonsterNum[i];j++)
		{
			TargetList.push_back(DInfo.MonsterPos[i][j]);
		}
	}

	std::vector<std::vector<Pos> > Path;
	FindPath(Map, SInfo.MySpringPos[0], TargetList, SInfo.EmptyBlock, Path);

	int StartIndex=0;
	for(i=0;i<MONSTER_TYPE_NUM;i++)
	{
		for(j=0;j<SInfo.TypeMonsterNum[i];j++)
		{
			if(Path[StartIndex+j].size()>0)
			{
				SInfo.MonsterReachable[i][j]=true;
			}
			else
			{
				SInfo.MonsterReachable[i][j]=false;
			}
		}
		StartIndex+=SInfo.TypeMonsterNum[i];
	}
	SInfo.MonsterReachable[MONSTER_STONE_MAN][0]=false;
	SInfo.MonsterReachable[MONSTER_STONE_MAN][1]=false;

#ifdef PDEBUG
	fprintf(Debug, "��Ӫ %d, ��� %d, �ֱ� %d\n", SInfo.MyCamp, SInfo.MyPlayer, SInfo.MyPlayerThisGame);
	fprintf(Debug, "Ұ����ͨ���\n");
	for(i=0;i<MONSTER_TYPE_NUM;i++)
	{
		for(j=0;j<SInfo.TypeMonsterNum[i];j++)
		{
			fprintf(Debug, "%d ", SInfo.MonsterReachable[i][j]?1:0);
		}
		fprintf(Debug, "\n");
	}
	fflush(Debug);
#endif

#ifdef PDEBUG
	fprintf(Debug, "GetStaticInfoSecond Finished\n");
	fflush(Debug);
#endif
}

int GetEnemyHeroLog(const DynamicInfo &DInfo, std::vector<HeroInfo> &EnemyHeroLog)
{
#ifdef PDEBUG
	fprintf(Debug, "GetEnemyHeroLog Called\n");
	fflush(Debug);
#endif

#ifdef PDEBUG
	fprintf(Debug, "Enemy Hero Num %d\n", DInfo.EnemyHero.size());
	fflush(Debug);
#endif

#ifdef PDEBUG
	fprintf(Debug, "Enemy Hero Log Num %d\n", EnemyHeroLog.size());
	fflush(Debug);
#endif

	int i, j;

	bool InLog;
	for(i=0;i<DInfo.EnemyHero.size();i++)
	{
		InLog=false;
		for(j=0;j<EnemyHeroLog.size();j++)
		{
			if(EnemyHeroLog[j].ID==DInfo.EnemyHero[i].id)
			{
				EnemyHeroLog[j].LastDetected=DInfo.Round;
				EnemyHeroLog[j].Level=DInfo.EnemyHero[i].level;
				EnemyHeroLog[j].HP=DInfo.EnemyHero[i].hp;
				EnemyHeroLog[j].MP=DInfo.EnemyHero[i].mp;
				InLog=true;
				break;
			}
		}
		if(!InLog)
		{
			HeroInfo TempHero;

			TempHero.ID=DInfo.EnemyHero[i].id;
			TempHero.Type=DInfo.EnemyHero[i].typeId;
			TempHero.LastDetected=DInfo.Round;
			TempHero.Level=DInfo.EnemyHero[i].level;
			TempHero.HP=DInfo.EnemyHero[i].hp;
			TempHero.MP=DInfo.EnemyHero[i].mp;

			EnemyHeroLog.push_back(TempHero);
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "Enemy Hero Log Num %d\n", EnemyHeroLog.size());
	fflush(Debug);
#endif

	int EnemyTotalLevel=0;
	for(i=0;i<EnemyHeroLog.size();i++)
	{
		EnemyTotalLevel+=EnemyHeroLog[i].Level;
	}
	if(EnemyHeroLog.size()>0)
	{
		EnemyTotalLevel=EnemyTotalLevel*(double)PLAYER_HERO_NUM/EnemyHeroLog.size();
	}
	else
	{
		EnemyTotalLevel=-1;
	}

#ifdef PDEBUG
	fprintf(Debug, "�з��ܵȼ� %d\n", EnemyTotalLevel);
	fflush(Debug);
#endif

#ifdef PDEBUG
	fprintf(Debug, "GetEnemyHeroLog Finished\n");
	fflush(Debug);
#endif

	return EnemyTotalLevel;
}

Operation GetArcherCommand(const PMap &Map, DynamicInfo &DInfo, const StaticInfo &SInfo, const PUnit &Archer, const Pos &Target,  bool UseAttackSkill)
{
	int i, j;
	Operation Command;

	Command.id=Archer.id;
	Command.targets.clear();
	if(Archer.canUseSkill(TypeSpace::ARLU))
	{
#ifdef PDEBUG
		fprintf(Debug, "������ARLU\n");
#endif

		Command.typeId=TypeSpace::ARLU;
	}
	else if(Archer.canUseSkill(TypeSpace::PALU))
	{
#ifdef PDEBUG
		fprintf(Debug, "������PALU\n");
#endif

		Command.typeId=TypeSpace::PALU;
	}
	else if(Archer.canUseSkill(TypeSpace::PULU))
	{
#ifdef PDEBUG
		fprintf(Debug, "������PULU\n");
#endif

		Command.typeId=TypeSpace::PULU;
	}
	else if(Archer.canUseSkill(TypeSpace::YellowPoint))
	{
#ifdef PDEBUG
		fprintf(Debug, "������YP\n");
#endif

		Command.typeId=TypeSpace::YellowPoint;
	}
	else
	{
		bool CanUseArrowsRain=true;

		if(!Archer.canUseSkill(TypeSpace::ArrowsRain) || Dis2(Archer.pos, Target)>SignalArrow_range)
		{
			CanUseArrowsRain=false;
		}
		for(i=0;i<DInfo.MyCampRainyPlace.size();i++)
		{
			if(Dis2(DInfo.MyCampRainyPlace[i].center, Target)<DInfo.MyCampRainyPlace[i].radius*DInfo.MyCampRainyPlace[i].radius)
			{
				CanUseArrowsRain=false;
			}
		}
		for(i=0;i<DInfo.MyCampSignalArrow.size();i++)
		{
			if(Dis2(DInfo.MyCampSignalArrow[i].target, Target)<RainyPlace_range*RainyPlace_range)
			{
				CanUseArrowsRain=false;
			}
		}

		if(CanUseArrowsRain && UseAttackSkill)
		{
#ifdef PDEBUG
			fprintf(Debug, "������AR %d %d\n", Target.x, Target.y);
#endif

			Command.typeId=TypeSpace::ArrowsRain;
			Command.targets.push_back(Target);

			PFlight NewFlight(TypeSpace::SignalArrow, 0, Archer.id, SInfo.MyCamp, SignalArrow_speed, Archer.pos.x, Archer.pos.y, Target.x, Target.y);
			DInfo.MyCampSignalArrow.push_back(NewFlight);
		}

		else if(Archer.canUseSkill(TypeSpace::PiercingArrow) && Dis2(Archer.pos, Target)<PiercingArrow_range && UseAttackSkill)
		{
	#ifdef PDEBUG
			fprintf(Debug, "������PA %d %d\n", Target.x, Target.y);
	#endif

			Command.typeId=TypeSpace::PiercingArrow;
			Command.targets.push_back(Target);
		}
		else
		{
			if(Dis2(Archer.pos, Target)<Archer_range)
			{
				if(Archer.canUseSkill(TypeSpace::PowerUp) && UseAttackSkill)
				{
#ifdef PDEBUG
					fprintf(Debug, "������PU\n");
#endif
					Command.typeId=TypeSpace::PowerUp;
				}
				else if(Archer.canUseSkill(TypeSpace::Attack))
				{
#ifdef PDEBUG
					fprintf(Debug, "�����ֹ��� ��ǰ %d %d Ŀ�� %d %d\n", Archer.pos.x, Archer.pos.y, Target.x, Target.y);
#endif
					Command.typeId=TypeSpace::Attack;
					Command.targets.push_back(Target);
				}
				else
				{
					Command.typeId=TypeSpace::Move;

					Pos Dest;
					std::vector<Pos> Path;
					int MaxNearPoint=sqrt(Archer_speed);
					bool SafePointFind=false;
					for(i=0;i<MaxNearPoint;i++)
					{
						for(j=0;j<SInfo.NearPointIndex[i].size();j++)
						{
							Dest=Archer.pos+SInfo.NearPointIndex[i][j];
							if(CheckPos(Dest))
							{
								if(DInfo.DangerousPoint[Dest.x][Dest.y]==DANGER_SAFE)
								{
									FindPath(Map, Archer.pos, Dest, DInfo.Block, Command.targets);
									if(GetPathLength2(Command.targets)<Archer_speed)
									{
										SafePointFind=true;
										break;
									}
								}
							}
						}
						if(SafePointFind)
						{
							break;
						}
					}
					if(SafePointFind)
					{
						DInfo.DangerousPoint[Dest.x][Dest.y]=DANGER_OCCUPIED;
#ifdef PDEBUG
						fprintf(Debug, "�����־ͽ���� ��ʼ%d %d Ŀ��%d %d ·���� %d\n", Archer.pos.x, Archer.pos.y, Dest.x, Dest.y, Command.targets.size());
#endif
					}
					else
					{
						Command.targets.clear();
#ifdef PDEBUG
						fprintf(Debug, "�������޷����\n", Archer.pos.x, Archer.pos.y, Dest.x, Dest.y, Command.targets.size());
#endif
					}
				}
			}
			else
			{
				Command.typeId=TypeSpace::Move;
				vector<Pos> BlockAndDanger=DInfo.Block;
				for(i=0;i<Map_size;i++)
				{
					for(j=0;j<Map_size;j++)
					{
						if(DInfo.DangerousPoint[i][j]!=DANGER_SAFE)
						{
							BlockAndDanger.push_back(Pos(i, j));
						}
					}
				}
				FindPath(Map, Archer.pos, Target, BlockAndDanger, Command.targets);
#ifdef PDEBUG
				fprintf(Debug, "�������ƶ� ��ʼ%d %d Ŀ��%d %d ·���� %d\n", Archer.pos.x, Archer.pos.y, Target.x, Target.y, Command.targets.size());
#endif
			}
		}
	}

	return Command;
}

void GetMonsterTypeIndex(const StaticInfo &SInfo, const PUnit &Monster, int &Type, int &Index)
{
	switch(Monster.typeId)
	{
	case TypeSpace::Dog:
		Type=MONSTER_DOG;
		break;
	case TypeSpace::Bow:
		Type=MONSTER_BOW;
		break;
	case TypeSpace::Wolf:
		Type=MONSTER_WOLF;
		break;
	case TypeSpace::StoneMan:
		Type=MONSTER_STONE_MAN;
		break;
	case TypeSpace::Dragon:
		Type=MONSTER_DRAGON;
		break;
	case TypeSpace::Roshan:
		Type=MONSTER_ROSHAN;
		break;
	default:
		Type=0;
		break;
	}

	int MinDis=INT_MAX;
	int Dis;
	int i;

	for(i=0;i<SInfo.TypeMonsterNum[Type];i++)
	{
		Dis=Dis2(SInfo.MonsterRevivePos[Type][i], Monster.pos);
		if(Dis<MinDis)
		{
			MinDis=Dis;
			Index=i;
		}
	}
}

double GetPathLength2(const std::vector<Pos> &Path)
{
	int i;

	double Length=0;
	if(Path.size()<2)
	{
		return 0;
	}
	else
	{
		return (Path.size()-1)*(Path.size()-1);
	}
}

//���·�����Һ���
//����Start:��ʼ����
//����Dest:��ֹ���꼯
//����Map:��ͼ
//����Block:��ֹ������
//����Path:·����
//���ش�λ��Start��Dest�����·����
void FindPath(const PMap &Map, const Pos &Start, const std::vector<Pos> &Dest, const std::vector<Pos> &Block, std::vector<std::vector<Pos> > &Path)
{
#ifdef PDEBUG
	fprintf(Debug, "FindPath Called\n");
	fflush(Debug);
#endif

	static int PosVisited[MAP_SIZE][MAP_SIZE]={0};
	static Pos PosQueue[MAP_SIZE*MAP_SIZE+1], PosPrior[MAP_SIZE][MAP_SIZE];
	static int Visited=0;
	static Pos Dir[4]={Pos(0, 1), Pos(0, -1), Pos(1, 0), Pos(-1, 0)};
	static int DirOrder[4]={0, 1, 2, 3};
	int i, j;

	Visited+=2;

	PosVisited[Start.x][Start.y]=Visited;
	PosQueue[0]=Start;

	for(i=0;i<Block.size();i++)
	{
		PosVisited[Block[i].x][Block[i].y]=Visited+1;
	}

	for(i=0;i<Dest.size();i++)
	{
		PosVisited[Dest[i].x][Dest[i].y]=Visited-1;
	}

	int Front;
	int Rear;
	Pos ThisPoint, NextPoint;
    for(Front=0, Rear=1; Front<Rear; Front++)
	{
        random_shuffle(DirOrder, DirOrder+4);

        for(i=0;i<4;i++)
		{
			NextPoint=PosQueue[Front]+Dir[DirOrder[i]];
			if(!CheckPos(NextPoint))
			{
				continue;
			}

            if(abs(Map.height[PosQueue[Front].x][PosQueue[Front].y]-Map.height[NextPoint.x][NextPoint.y])<=1 && PosVisited[NextPoint.x][NextPoint.y]!=Visited && PosVisited[NextPoint.x][NextPoint.y]!=Visited+1)
			{
				PosQueue[Rear]=NextPoint;
				Rear++;
				PosPrior[NextPoint.x][NextPoint.y]=PosQueue[Front];
				PosVisited[NextPoint.x][NextPoint.y]=Visited;
            }
        }
    }

	Path.clear();
	std::vector<Pos> EmptyPath;
	for(i=0;i<Dest.size();i++)
	{
		Path.push_back(EmptyPath);
		if(CheckPos(Dest[i]))
		{
			if(PosVisited[Dest[i].x][Dest[i].y]==Visited)
			{
				for(ThisPoint=Dest[i];ThisPoint!=Start;ThisPoint=PosPrior[ThisPoint.x][ThisPoint.y])
				{
					Path[i].push_back(ThisPoint);
				}
				Path[i].push_back(ThisPoint);
				reverse(Path[i].begin(), Path[i].end());	
			}
		}
	}

#ifdef PDEBUG
	fprintf(Debug, "FindPath Finished\n");
	fflush(Debug);
#endif
}

//���·�����Һ���
//����Start:��ʼ����
//����Dest:��ֹ����
//����Map:��ͼ
//����Block:��ֹ������
//����Path:·��
//���ش�λ��Start��Dest�����·��
void FindPath(const PMap &Map, const Pos &Start, const Pos &Dest, const std::vector<Pos> &Block, std::vector<Pos> &Path)
{
#ifdef PDEBUG
	fprintf(Debug, "FindPath Called\n");
	fflush(Debug);
#endif

	static int PosVisited[MAP_SIZE][MAP_SIZE]={0};
	static Pos PosQueue[MAP_SIZE*MAP_SIZE+1], PosPrior[MAP_SIZE][MAP_SIZE];
	static int Visited=0;
	static Pos Dir[4]={Pos(0, 1), Pos(0, -1), Pos(1, 0), Pos(-1, 0)};
	static int DirOrder[4]={0, 1, 2, 3};
	int i, j;

	if(!CheckPos(Dest))
	{
		return;
	}

	Visited+=2;

	PosVisited[Start.x][Start.y]=Visited;
	PosQueue[0]=Start;

	for(i=0;i<Block.size();i++)
	{
		PosVisited[Block[i].x][Block[i].y]=Visited+1;
	}

	PosVisited[Dest.x][Dest.y]=Visited-1;

	int Front;
	int Rear;
	Pos ThisPoint, NextPoint;
    for(Front=0, Rear=1; Front<Rear; Front++)
	{
		random_shuffle(DirOrder, DirOrder+4);

        for(i=0;i<4;i++)
		{
			NextPoint=PosQueue[Front]+Dir[DirOrder[i]];
			if(!CheckPos(NextPoint))
			{
				continue;
			}

            if(abs(Map.height[PosQueue[Front].x][PosQueue[Front].y]-Map.height[NextPoint.x][NextPoint.y])<=1 && PosVisited[NextPoint.x][NextPoint.y]!=Visited && PosVisited[NextPoint.x][NextPoint.y]!=Visited+1)
			{
				PosQueue[Rear]=NextPoint;
				Rear++;
				PosPrior[NextPoint.x][NextPoint.y]=PosQueue[Front];
				PosVisited[NextPoint.x][NextPoint.y]=Visited;
            }
        }

		if(PosVisited[Dest.x][Dest.y]==Visited)
		{
			break;
		}
    }

	Path.clear();
	if(PosVisited[Dest.x][Dest.y]==Visited)
	{
		for(ThisPoint=Dest;ThisPoint!=Start;ThisPoint=PosPrior[ThisPoint.x][ThisPoint.y])
		{
			Path.push_back(ThisPoint);
		}
		Path.push_back(ThisPoint);
		reverse(Path.begin(), Path.end());	
	}


#ifdef PDEBUG
	fprintf(Debug, "FindPath Finished, ·����%d\n", Path.size());
	fflush(Debug);
#endif
}

//ͨ�ü��㺯��
inline bool CheckPos(const Pos &A)
{
    return 0<=A.x && A.x<MAP_SIZE && 0<=A.y && A.y<MAP_SIZE;
}

int VectorMax(const std::vector<int> &Data)
{
	int Max=INT_MIN;
	int i;

	for(i=0;i<Data.size();i++)
	{
		if(Data[i]>Max)
		{
			Max=Data[i];
		}
	}

	return Max;
}

inline int Dis2(const Pos &A, const Pos &B)
{
	return (A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y);
}

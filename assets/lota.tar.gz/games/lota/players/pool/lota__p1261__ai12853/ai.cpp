#include "sdk.h"

bool in_attack_range(const PUnit &t, const Pos& tar)
{
    return dis2(t.pos, tar) <= t.range;
}

#define __interupt do{ \
    asm ("int $0x03"); \
}while(0)

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
   __interupt;
}

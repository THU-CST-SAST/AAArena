#include "sdk.h"

const int Dog_Num = 8;
const int Bow_Num = 6;
const int Wolf_Num = 4;
const int StoneMan_Num = 2;
const int Dragon_Num = 2;

const int wildThreshold = 30;
const int targetInnerCircle = 350;
const int levelThreshold = 15;

enum STATE{SELECT = 0, FIND, GO_ATTACK, CRUSH} state = SELECT;
vector<Pos> blocks, wilds;

Pos targetPos(70, 70);
int targetWild;
bool targetFound = false;

int level_sum;
int towerNum = 2;
Pos towerTarget;

vector<const PUnit*> ours;

void chooseHero(const PPlayerInfo &info, PCommand &cmd){
    for(int i = 0; i < info.units.size(); i++){
        Operation op;
        op.id = info.units[i].id;
        op.type = "ChooseArcher";
        op.targets.clear();
        cmd.cmds.push_back(op);
    }
}

void blocksInit(){
    blocks.clear();
    wilds.clear();
    for(int i = 0; i < Dog_Num; i++){
        blocks.push_back(Dog_pos[i]);
        wilds.push_back(Dog_pos[i]);
    }
    for(int i = 0; i < Bow_Num; i++){
        blocks.push_back(Bow_pos[i]);
        Pos deadend1(54, 54), deadend2(96, 96);
        if(Bow_pos[i] != deadend1 && Bow_pos[i] != deadend2)
            wilds.push_back(Bow_pos[i]);
    }
    for(int i = 0; i < Wolf_Num; i++){
        blocks.push_back(Wolf_pos[i]);
        wilds.push_back(Wolf_pos[i]);
    }
    for(int i = 0; i < StoneMan_Num; i++){
        blocks.push_back(StoneMan_pos[i]);
    }
    for(int i = 0; i < Dragon_Num; i++){
        blocks.push_back(Dragon_pos[i]);
        wilds.push_back(Dragon_pos[i]);
    }
    blocks.push_back(Roshan_pos[0]);
    for(int i = 0; i < 2; i++){
        blocks.push_back(Player0_tower_pos[i]);
        blocks.push_back(Player1_tower_pos[i]);
    }
}

Pos findTarget(){
    Pos average(0, 0);
    for(int i = 0; i < ours.size(); i++){
        average = average + ours[i]->pos;
        if(i == ours.size() - 1){
            average.x /= ours.size();
            average.y /= ours.size();
        }
    }
    Pos near, near2;
    int nearDis = 30000;
    for(int i = 0; i < wilds.size(); i++){
        int dist = dis2(average, wilds[i]);
        if(dist > targetInnerCircle && dist < nearDis){
            near2 = near;
            near = wilds[i];
            nearDis = dist;
        }
    }
    if(dis2(near2, average) < 3 * dis2(near, average)){
        if(rand() % 3)
            return near;
        else
            return near2;
    }
    else
        return near;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
    ours.clear();
    cmd.cmds.clear();
    info.findUnitByPlayer(info.player, ours);

SWITCH:
    switch(state){
    case SELECT:
        chooseHero(info, cmd);
        blocksInit();
        state = FIND;
        return;
        break;
    case FIND:FIND:
        targetPos = findTarget();
        state = GO_ATTACK;
        level_sum = 0;
        for(int i = 0; i < ours.size(); i++)
            level_sum += ours[i]->level;
        if(level_sum > levelThreshold){
            state = CRUSH;
        }
        break;
    case GO_ATTACK:GO_ATTACK:
        if(!targetFound){
            for(int i = 0; i < info.units.size(); i++){
                const PUnit* ptr = &info.units[i];
                if(ptr->name != string("Roshan") &&
                   ptr->name != string("StoneMan") &&
                   dis2(targetPos, ptr->pos) < wildThreshold){
                    if(ptr->isWild()){
                        targetFound = true;
                        targetWild = ptr->id;
                        break;
                    }
                }
            }
        }
        else{
            const PUnit* target = info.findUnitById(targetWild);
            if(target->hp <= 0){
                targetFound = false;
                state = FIND;
                break;
            }
        }

        for(int i = 0; i < ours.size(); i++) if(ours[i]->isHero()){
            const PUnit* unit = ours[i];
            const PUnit* target = info.findUnitById(targetWild);
            Operation op;
            op.id = unit->id;
            if(targetFound && dis2(unit->pos, target->pos) < unit->range){
                op.type = "Attack";
                op.targets.push_back(target->pos);
            }
            else{
                op.type = "Move";
                Pos randoms(2 - rand() % 4, 2 - rand() % 4);
                findShortestPath(map, unit->pos, targetPos + randoms, blocks, op.targets);
            }
            cmd.cmds.push_back(op);
        }
        break;
    case CRUSH:CRUSH:
        if(info.camp == 0){
            if(towerNum == 2)
                towerTarget = Player1_tower_pos[0];
            else
                towerTarget = Player1_tower_pos[1];
        }
        else{
            if(towerNum == 2)
                towerTarget = Player0_tower_pos[0];
            else
                towerTarget = Player0_tower_pos[1];
        }

        for(int i = 0; i < ours.size(); i++){
            const PUnit* unit = ours[i];
            Operation op;
            op.id = unit->id;
            if(dis2(unit->pos, towerTarget) < unit->range){
                if(info.findUnitByPos(towerTarget) != 0){
                    if(unit->canUseSkill(11)){
                        op.typeId = 11;
                    }
                    else{
                        op.type = "Attack";
                        op.targets.push_back(towerTarget);
                    }
                }
                else{
                    towerNum = 1;
                    break;
                }
            }
            else{
                op.type = "Move";
                Pos randoms(2 - rand() % 4, 2 - rand() % 4);
                findShortestPath(map, unit->pos, towerTarget + randoms, blocks, op.targets);
            }

            cmd.cmds.push_back(op);
        }
        break;

    }

    /*bool foundEnemy = false;
    int enemyNum = 0;
    const PUnit* enemy;
    for(int i = 0; i < info.units.size(); i++){
        const PUnit* ptr = &info.units[i];
        if(ptr->camp == 1 - info.camp){
            foundEnemy = true;
            enemyNum++;
            enemy = ptr;
        }
    }
    if(foundEnemy){
        for(int i = 0; i < ours.size(); i++){
            const PUnit* unit = ours[i];
            Operation op;
            op.id = unit->id;
            if(dis2(unit->pos, enemy->pos) < unit->range){
                if(unit->mp > 170){
                    if(enemyNum >= 3 && unit->canUseSkill(9)){
                        op.typeId = 9;
                        op.targets.push_back(enemy->pos);
                    }
                    else if(unit->canUseSkill(7)){
                        op.typeId = 7;
                        op.targets.push_back(enemy->pos);
                    }
                }
                else{
                    op.type = "Attack";
                    op.targets.push_back(enemy->pos);
                }
            }
            else{
                op.type = "Move";
                Pos randoms(2 - rand() % 4, 2 - rand() % 4);
                findShortestPath(map, unit->pos, enemy->pos + randoms, blocks, op.targets);
            }
            cmd.cmds.push_back(op);
        }
    }*/

    if(cmd.cmds.empty())
        goto SWITCH;
    for(int i = 0; i < ours.size(); i++){
        if(ours[i]->level >= 2 && ours[i]->canUseSkill(12)){
            Operation op;
            op.id = ours[i]->id;
            op.type = "PULU";
            op.targets.clear();
            cmd.cmds.push_back(op);
        }
        else if(ours[i]->canUseSkill(19)){
            Operation op;
            op.id = ours[i]->id;
            op.type = "YellowPoint";
            op.targets.clear();
            cmd.cmds.push_back(op);
        }
    }


}

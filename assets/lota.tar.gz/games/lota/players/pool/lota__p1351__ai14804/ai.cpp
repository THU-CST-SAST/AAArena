#include "sdk.h"
#include<ctime>
#include<iostream>
using namespace std;
 //��������ѡһ��                 //�ӳ�ƫ����                                                     116 96 first duandian                                                10 60 8
Pos mode,lastcap,lastene,tt,spr,des[100],rt[100]={Pos(54,115),Pos(94,142),Pos(92,116),Pos(88,74),Pos(116,96),Pos(96,75),Pos(54,75),Pos(34,54)};     //����ʮ��

const int LENS=8,rollbg = 4;                      //stage12 131 27
int toflag,huntstage,ygt=0,captain,stage,flag = 0,tp,loop=0,lprd=0,numbermet = 0,desize;   //�ӳ�id   /   �׶�    �� ���з��š����ͱ��
int tmphuntstage,tmpdesize,numt = 2;
bool tat = false;

vector<Pos> circ[15];
const double cd = sqrt(1.5);
bool occu[200],actioned[100],met[100]={false},enecheck[100],mtflag,dflag=false;   //�ж��ж�
static bool towerDes[2];
typedef vector<const PUnit*> PUnits;
PUnits ours, others, nearBy,hero,tnearBy;
vector<int> revive;
static vector<Pos> allblocks,fixblocks,unitblocks,pblocks;
int syms[20][5];
const PMap* MAP;
const PPlayerInfo* INFO;
Pos tower[2];
int corid[100]={0};   //��idӳ��Ϊ���ͱ��

void chooseHero(const PPlayerInfo &info, PCommand &cmd){ //��0�غ�ѡ��Ӣ�� done
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
        op.type="ChooseArcher";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op);
    }
}
void lprd1dest();
void init(int camp){ //һЩ������ʼ��
    if(camp == 0){
      tower[0] = Player1_tower_pos[0];
      tower[1] = Player1_tower_pos[1];
      spr = Player0_spring_pos[0];
    }
    else{
      tower[0] = Player0_tower_pos[0];
      tower[1] = Player0_tower_pos[1];
      spr = Player1_spring_pos[0];
      for(int i=0;i<LENS;i++){
        rt[i] = Pos(150,150)-rt[i];
      }
    }
    fixblocks.clear();

    for (int i = 0; i < 2; ++i){
      fixblocks.push_back(tower[i]); //��ͼ�Ϲ̶��㲻�ɾ���
      for(int j=-11;j<=11;j++){
        for(int k =-11;k<=11;k++){
          if(k*k+j*j < 110 && k*k +j*j >100)
            fixblocks.push_back(tower[i]+Pos(j,k));
        }
      }
    }
    for (int i = 0;i<8;i++){
      fixblocks.push_back(Dog_pos[i]);
      pblocks.push_back(Dog_pos[i]);
    }
    for (int i = 0;i<6;i++){
      fixblocks.push_back(Bow_pos[i]);
      pblocks.push_back(Bow_pos[i]);
    }
    for (int i = 0;i<4;i++){
      fixblocks.push_back(Wolf_pos[i]);
      pblocks.push_back(Wolf_pos[i]);
    }
    for (int i = 0;i<2;i++)
      fixblocks.push_back(Dragon_pos[i]);

    fixblocks.push_back(Roshan_pos[0]);
    for(int j=-4;j<=4;j++){
        fixblocks.push_back(Roshan_pos[0]+Pos(j,-3));
        fixblocks.push_back(Roshan_pos[0]+Pos(j,3));
        fixblocks.push_back(Roshan_pos[0]+Pos(-3,j));
        fixblocks.push_back(Roshan_pos[0]+Pos(3,j));
        pblocks.push_back(Roshan_pos[0]+Pos(j,-3));
        pblocks.push_back(Roshan_pos[0]+Pos(j,3));
        pblocks.push_back(Roshan_pos[0]+Pos(-3,j));
        pblocks.push_back(Roshan_pos[0]+Pos(3,j));
    }

    towerDes[0] = towerDes[1] = false;
    int j;
    for(int rad = 1;rad < 15; rad ++){
      circ[rad].push_back(Pos(rad,0));
      j = 0;  //former one
      for(float theta = 0.05 ;theta < 6.28 ; theta += 0.1){
        Pos p = Pos(rad * cos(theta),rad * sin(theta));
        if(p != circ[rad][j]){
          circ[rad].push_back(p);
          j++;
        }
      }
      //cout<<circ[rad].size()<<" ";
    }
   // for(int i=0;i<circ[9].size();i++)
   //   cout<<circ[9][i].x<<" "<<circ[9][i].y<<"|";
}

void Move_Together(Pos tar, PCommand &cmd){// cout<<"move"<<tar.x<<" "<<tar.y<<" ";
    Operation tmp1;
    for(int i=0;i<hero.size();i++){
      if(actioned[hero[i]->id])continue;
      tmp1.id = hero[i]->id;
      tmp1.type = "Move";
      findShortestPath(*MAP,hero[i]->pos,tar,allblocks,tmp1.targets);
      cmd.cmds.push_back(tmp1);actioned[hero[i]->id] = true;
    }
}

bool Together_check(const PPlayerInfo &info){
    int idtmp,num=0;
    const PUnit *cap = info.findUnitById(captain);
    for(int i=0;i<hero.size();i++)
      num += (dis2(hero[i]->pos,cap->pos)<=50);
    return num>4;
}

bool Enemy_Check(const PPlayerInfo &info){
  for(int i=0;i<hero.size();i++){
    info.findUnitInArea(hero[i]->pos, hero[i]->view, nearBy); //Ѱ�Ҹ�������

    for (int j = 0; j < nearBy.size(); ++j)
    {
        if (!(  nearBy[j]->camp == hero[i]->camp ||
                nearBy[j]->pos == Bow_pos[0] || nearBy[j]->pos == Bow_pos[3] ||
                nearBy[j]->findBuff("Reviving") || enecheck[nearBy[j]->id]))  //ɾ���ȼ����ߵ��ˣ������Ѿ����޳������ߣ�ɾ�����ɵ����Ұ��
        {
            enecheck[nearBy[j]->id] = true;
            others.push_back(nearBy[j]);
        }
    }
  }

  for(int i=0;i<others.size();i++)
    if(others[i]->isHero() && !met[others[i]->id]){
      met[others[i]->id] = true;
      numbermet++;
      //cout<<others[i]->name<<" ";
    }
  //cout<<"ECDone-"<<others.size()<<" | ";
  return others.size();
}

void LVUP(const PPlayerInfo &info,PCommand &cmd){   //test done
  Operation op;
  for(int i=0;i<hero.size();i++){
    if(actioned[hero[i]->id])continue;
    if(!hero[i]->canUseSkill(19))continue;
    op.id = hero[i]->id;
    if(hero[i]->level <=1 ||hero[i]->level == 4)op.type = "PALU";
    else if(hero[i]->level <=4) op.type = "PULU";
    else op.type = "YellowPoint";
    cmd.cmds.push_back(op);actioned[hero[i]->id] = true;
  }
}

int Unit_Evaluation(const PUnit *ptr){  //��С��ʾ���ȹ���
  if(ptr->hp < 4*(INFO->findUnitById(captain))->atk) return -1;
  if(ptr->name == string("Tower") || ptr->name == string("Roshan")) return 5;
  if(ptr->name == string("Archer")) return 0;
  if(ptr->name == string("Assasin")) return 1;
  if(ptr->name == string("Fighter")) return 2;
  if(ptr->name == string("Dog") || ptr->name == string("Bow"))return 3;
  if(ptr->name == string("Wolf") || ptr->name == string("StoneMan"))return 4;
}

int Evaluation(){
  for(int i=0;i<nearBy.size();i++)
    if(Unit_Evaluation(nearBy[i])==5 && dis2(nearBy[i]->pos , hero[0]->pos)<25) return 5;
  if(nearBy.size()>1)return 3;
  return Unit_Evaluation(nearBy[0]);
}

Pos Target_Choose(const PPlayerInfo &info){
  int th=0,tmp,ma=Unit_Evaluation(others[0]);
  Pos p = others[0]->pos;
  for(int i=1;i<others.size();i++){
    tmp = Unit_Evaluation(others[i]);
    if(ma>tmp || (ma == tmp && others[i]->hp < others[th]->hp)){
      ma = tmp;
      p = others[i]->pos;
      th = i;
    }
  }
  //cout<<"ChooseTarget"<<others[th]->name<<" ";
  return p;
}

void Loop_Change(PCommand &cmd){
  loop ++;
  vector<Operation> op;
  for(int i=0;i<cmd.cmds.size();i++){
    op.push_back(cmd.cmds[(i+loop)%hero.size()]);
  }
  cmd.cmds = op;
}

void Cap_Change(const PPlayerInfo &info){
  const PUnit *cap = info.findUnitById(captain);
  bool capdead = false;
  for(int i=0;i<hero.size();i++){
    if(hero[i]->findBuff("Reviving")){
      if(hero[i] -> id  == captain) capdead = true;
      revive.push_back(hero[i]->id);
      hero.erase(hero.begin()+i);
    }
  }

  if(!capdead){
    for(int i=0;i<hero.size();i++){
      if(dis2(hero[i]->pos,cap->pos)>81){
        revive.push_back(hero[i]->id);
        hero.erase(hero.begin()+i);
      }
    }
  }

  if(hero.size()>0 && capdead){
    captain = hero[0]->id;
    for(int i=1;i<hero.size();i++)
      corid[hero[i]->id] = i-1;
  }
  else if(hero.size()>0 && !capdead){
    for(int i=1;i<hero.size();i++)
      corid[hero[i]->id] = i-1;
  }
  else captain = revive[0];

  if(lprd != 8 && hero.size()<2){
    lprd = 8;
    mode = Pos(14,17);
    int j=0;
    for(int i=mode.x;i<=mode.y;i++)
      des[j++] = rt[i];
    for(int i=mode.y-1;i>mode.x;i--)
      des[j++] = rt[i];
    desize = j;
  }
}

void Recover(const PPlayerInfo &info,PCommand &cmd){
  if(revive.size()==0)return;

  Operation tmp1;
  const PUnit *cap = info.findUnitById(captain);
  PUnit* t;
  for(int i=0;i<revive.size();i++){
    if(actioned[revive[i]])continue;
    t = (PUnit*)info.findUnitById(revive[i]);
    tmp1.id = revive[i];
    tmp1.type = "Move";
    findShortestPath(*MAP,t->pos,cap->pos,allblocks,tmp1.targets);
    cmd.cmds.push_back(tmp1);actioned[revive[i]] = true;
  }
}

inline double cp(Pos from,Pos to1,Pos to2){
  return (to1-from).x * (to2 - from).x + (to1-from).y * (to2 - from).y;
}

bool Pinrange(Pos from,Pos to,Pos tar){
  double pro = cp(from,to,tar),AB = dis(from,to),AC = dis(from,tar) , BC = dis(tar,to);
  double cost = pro/(AB*AC),sint = sqrt(1-cost*cost);
  if(AC<= cd|| BC <=cd) return true;
  if(cost < 0)return false;
  double dist = AC*sint;
  if( dist <= cd && AC*cost <= (AB+cd))return true;
  return false;
}

Pos affectMost(Pos from){
  int maxx = -1;Pos tmp;
  for(int i = 0;i<circ[9].size();i++){
    int num = 0;

    for(int j = 0;j<others.size();j++)
      if(Pinrange(from,from+circ[9][i],others[j]->pos)) num++;

    if(num>maxx){
      maxx = num;
      tmp  = from +circ[9][i];
    }
  }

  if(maxx > 2){
    //cout<<"piercingto"<<tmp.x<<" "<<tmp.y<<" | ";
    return tmp;
  }
  else{
    //cout<<"nopiercing ";
    return Pos(-1,-1);
  }
}

void standtoPos(const PPlayerInfo &info, PCommand &cmd,Pos tar,const PUnit *ptr,int rad = 9){
  int minn = 999999999,num;
  vector<Pos> tmpr;
  Operation op;

  for(int i=0;i<circ[rad].size();i++){
    if(occu[i])continue;
    Pos tmp = tar + circ[rad][i];
    if(tmp.x <2 ||tmp.y <2 ||tmp.x >149 ||tmp.y>149)continue;
    if(minn > dis2(tmp,ptr->pos) &&
       ( (dis2(tmp,tower[0])>100 && dis2(tmp,tower[1])>100 && dis2(tmp,Roshan_pos[0])>8) || lprd == 2 || lprd == 3 )){
      minn = dis2(tmp,ptr->pos);
      num = i;
    }
  }

  //cout<<"standto"<<num<<" ";
  findShortestPath(*MAP,ptr->pos,tar + circ[rad][num],allblocks,tmpr);
  op.id = ptr->id;
  op.type = "Move";
  op.targets = tmpr;
  occu[num] = true;
  cmd.cmds.push_back(op);actioned[ptr->id] = true;
}

void Attack(const PPlayerInfo &info, PCommand &cmd,const PUnit *ptr,Pos tar,int mode){  //0 ֻ���չ���1 ����ʹ�ô�͸��
  if(actioned[ptr->id])return;
  vector <const PUnit*> sgnear;
  Operation op;int rad = 9;
  Pos todo;

  if(lprd == 2 || lprd == 3)rad = 8;

  if(dis2(ptr->pos,tar)<=81 && ptr->canUseSkill(0)){
    cout<<"Use0 ";
    op.targets.push_back(tar);
    op.id = ptr->id;
    op.typeId = 0;
    cmd.cmds.push_back(op);
    actioned[ptr->id] = true;
  }
  else if (dis2(ptr->pos,tar)<=81 && (mode == 2 || (mode == 3 &&others.size() >= 3 )) && ptr->canUseSkill(7) && (todo  = affectMost(ptr->pos)).x>0){
    cout<<"Use7 "<<todo.x<<" "<<todo.y<<" ";
    op.targets.push_back(todo);
    op.id = ptr->id;
    op.typeId = 7;
    cmd.cmds.push_back(op);
  }
  else if (mode == 3 && ptr->canUseSkill(11)){
    cout<<"Use11 ";
    op.id = ptr->id;
    op.typeId = 11;
    cmd.cmds.push_back(op);
  }
  else{
    standtoPos(info,cmd,tar,ptr,rad);
  }
}

void Search_Hunt(const PPlayerInfo &info, PCommand &cmd,Pos dest[]){cout<<"Search_Hunt"<<stage<<" ";
  int mode;
  const PUnit *cap = info.findUnitById(captain);

  if(others.size()){
    Pos tar = Target_Choose(info);

    if(info.findUnitByPos(tar)->name == string("Tower") || info.findUnitByPos(tar)->name == string("Roshan"))goto next;

    if(others.size()>2) mode = 2;
    if(flag == 0){
      flag = 1;
      mode = 1;
    }

    if(flag == 1 || flag == 2){
      flag = 2;
      for(int i =0;i<hero.size();i++){
        Attack(info,cmd,hero[i],tar,mode);
      }
    }
  }
  else{
      next:
    if(dis2(cap->pos,dest[stage])<20)
      stage = (stage+1)%desize;
    flag = 0;
    Move_Together(dest[stage],cmd);
  }
}

void Tower_Des(const PPlayerInfo &info, PCommand &cmd,Pos dest[],int mod = 3){
  int mode;
  const PUnit *cap = info.findUnitById(captain), *t = info.findUnitByPos(dest[0]);
  Operation op;
  vector<const PUnit*> tmp;

  info.findUnitByName("Tower",tmp);
  for(int i =0;i<tmp.size();i++){
    if(tmp[i]->camp == info.camp)
      tmp.erase(tmp.begin()+i--);
  }

  cout<<"TowerNum "<<tmp.size()<<" ";

  if(!tmp.size()){
    Search_Hunt(info,cmd,dest);
    return;
  }

  if(mod == 1) ygt++;

  if(others.size()<=3){
    for(int i =0;i<hero.size();i++)
      Attack(info,cmd,hero[i],tower[toflag],mod);
    return;
  }
  else{
    if(!towerDes[1-toflag] && t->hp > 10*hero[0]->atk && !tat){
      tat = true;
      toflag = 1-toflag;
      des[0] = tower[toflag];
      Move_Together(tower[toflag],cmd);
    }
    else if(tat){
      lprd = 1;
      lprd1dest();
    }
  }
}

void Tower_Check(const PPlayerInfo &info){
  vector<const PUnit*> towersight;
  const PUnit *cap = info.findUnitById(captain);
  info.findUnitByName("Tower",towersight);

  for(int i=0;i<towersight.size();i++)
    if(towersight[i]->camp != info.camp)
      towersight.erase(towersight.begin()+i--);


  for(int i=0;i<towersight.size();i++){
    info.findUnitInArea(towersight[i]->pos, towersight[i]->view, tnearBy);
    for (int i = 0; i < tnearBy.size(); ++i)
    {
        if (    tnearBy[i]->camp == info.camp ||
                tnearBy[i]->isWild() ||
                tnearBy[i]->findBuff("Reviving"))  //ɾ���ȼ����ߵ��ˣ������Ѿ����޳������ߣ�ɾ�����ɵ����Ұ��
        {
            tnearBy.erase(tnearBy.begin()+i);
            --i;
        }
    }
    if(tnearBy.size()>2 || dis2(cap->pos,towersight[i]->pos) < 3700){
        if(towersight.size() > numt){
          lprd = 2;
          if(towerDes[0]) toflag = 1;
          else toflag = 0;
          des[0] = tower[toflag];desize = 1;
          return;
        }

        int summ = 0;
        for(int i=0;i<tnearBy.size();i++)
          summ += tnearBy[i]->level;

        if(summ < 5)
          break;

        if(lprd == 2 && dis2(cap->pos,towersight[i]->pos) > 3700)
          break;

        lprd = 6+i;
        cout<<"TowerC:"<<tnearBy[0]->pos.x<<" "<<tnearBy[0]->pos.y<<" ";
        return;
      }
  }

  if((lprd==6||lprd ==7) && hero.size() >=4){
    lprd = 2;
    if(!towerDes[0] && !towerDes[1] )
      toflag = dis2(cap->pos,tower[0]) < dis2(cap->pos,tower[1]) ? 0:1;
    else if(!towerDes[0]) toflag = 0;
    else toflag = 1;
    des[0] = tower[toflag];desize = 1;
  }
}

void lprd1dest(){
  lprd=1;stage = 0;
  int j=0;
  for(int i=rollbg;i<LENS;i++)
    des[j++] = rt[i];
  for(int i=LENS-1;i>rollbg;i--)
    des[j++] = rt[i];
  desize = j;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){  //player0{
    //double ts = clock();
    srand(time(0)); //������ش�
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    int summ;
    mtflag = false;

    if (info.round == 0)
    {
        chooseHero(info, cmd); //��0�غ�ѡ��Ӣ��
        init(info.camp); //һЩ������ʼ��
        lprd = 0;desize = 2*LENS;
        memset(met,0,sizeof(met));
        return;
    }

    info.findUnitByPlayer(info.player, ours); //Ѱ�����б�����λ
    hero.clear();revive.clear();others.clear();
    unitblocks.clear();
    for(int i=0;i<info.units.size();i++)  unitblocks.push_back(info.units[i].pos);
    memset(actioned,0, sizeof(actioned));
    memset(enecheck,0, sizeof(enecheck));
    memset(occu,0,sizeof(occu));
    for(int i=0;i<ours.size();i++){
      if(ours[i]->isHero()){
        hero.push_back(ours[i]);
      }
    }
    if(info.round == 1){
      captain = hero[0]->id;
      for(int i=1;i<hero.size();i++)
        corid[hero[i]->id] = i-1;
      Move_Together(rt[0],cmd);
      stage = 0;
      return;
    }

    const PUnit *cap = info.findUnitById(captain);
    int capp;

    allblocks.clear();
    allblocks = fixblocks;
    for(int i=0;i<info.units.size();i++)
      allblocks.push_back(info.units[i].pos);


    Cap_Change(info);   cout<<"lprd:"<<lprd<<" ";
    LVUP(info,cmd);
    Recover(info,cmd);
    Enemy_Check(info);
    Tower_Check(info);

    //this
    switch(lprd){
    case 0: //��ʼ�׶�
      Search_Hunt(info,cmd,rt);

      if(stage == rollbg + 1)
        lprd1dest();

      break;
    case 1: //Ѳ���׶�
        case1:
        Search_Hunt(info,cmd,des);

        if(stage == 4 && !ygt){
          tt = des[0];lprd = 3;ygt = 0;toflag = 0;
          des[0] = tower[0];
          tmphuntstage = stage;
          tmpdesize = desize;
          stage = 0;desize = 1;
          break;
        }

        if(stage == 0) ygt = 0;

        summ = 0;
        for(int i=0;i<hero.size();i++){
          summ += hero[i]->level;
        }
        if(summ >=10){
          lprd =2;
          if(stage >= 2 && stage <=4) toflag = 0;
          else toflag = 1;
          des[0] = tower[toflag] + Pos();desize = 1;
        }

        break;
    case 2: //tower destroying
        towerpushing:
        if(dis2(cap->pos,tower[toflag])<144 && !info.findUnitByPos(tower[toflag])){
          towerDes[toflag] = true;
          lprd1dest();
          lprd = 4;numt--;
        }
        Tower_Des(info,cmd,des);
        break;
    case 3: //pretend to tower destroying
        if(others.size()>2 || hero.size()<2 || ygt > 5){
          lprd = 1;
          ygt = 1;
          des[0] = tt;
          stage = tmphuntstage;
          desize = tmpdesize;
          Move_Together(rt[stage+1],cmd);toflag = -1;
          break;
        }
        Tower_Des(info,cmd,des,1);
        break;
    case 4: //һ�������Ƶ����Ѳ��
        Search_Hunt(info,cmd,des);

        summ = 0;
        for(int i=0;i<hero.size();i++){
          summ += hero[i]->level;
        }
        if(summ >=20){
          lprd =2;
          if(towerDes[0]) toflag = 1;
          else toflag = 0;
          des[0] = tower[toflag];desize = 1;
        }
      break;
    case 6:case 7:  //�ط�
          for(int i=0;i<hero.size();i++){
            if(dis2(hero[i]->pos,Pos(149,149) - tower[lprd-6])<40){
              Pos tar = Target_Choose(info);
              Attack(info,cmd,hero[i],tar,2);
            }
            else{
              Operation op;vector<Pos> tmpr;
              findShortestPath(*MAP,hero[i]->pos,Pos(149,149) - tower[lprd-6],allblocks,tmpr);
              op.id = hero[i]->id;
              op.type = "Move";
              op.targets = tmpr;
              cmd.cmds.push_back(op);
            }
          }
        break;
    }
    lastcap = (info.findUnitById(captain))->pos;
    lastene = nearBy[0]->pos;
    //cout<<"Time:"<<clock()-ts<<" ";
}

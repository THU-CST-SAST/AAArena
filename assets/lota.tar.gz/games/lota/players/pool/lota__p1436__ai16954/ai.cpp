#include "sdk.h"
#include<ctime>

//F2 Assasin,一个字就是莽。

const Pos DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 20, MAXLEVEL = 10, MAXID = 100;
const double EPS = 1E-8;
const int INF = 1 << 30;

const Pos monsterPos[] = {Pos(8, 34), Pos(34, 34), Pos(58, 34), Pos(54, 75), Pos(142, 116), Pos(116, 116), Pos(92, 116),
                          Pos(96, 75),
                          Pos(8, 102), Pos(54, 54), Pos(54, 115), Pos(142, 48), Pos(96, 96), Pos(96, 35),
                          Pos(34, 54), Pos(56, 8), Pos(116, 96), Pos(94, 142),
                          Pos(32, 95), Pos(118, 55),
                          Pos(5, 5), Pos(145, 145),
                          Pos(75, 75)};


typedef vector<const PUnit *> PUnits;
PUnits nearBy;
static vector<Pos> blocks, towerBlocks;

const PMap *MAP;
const PPlayerInfo *INFO;
const Pos *tower, *spring, *mytower;

class TypeGen {
public:
    int revivingTime[MAXID];
    bool towerDes[2];
    int lastHit[MAXID];
    int towerAttacked[2];
    double enemysEval;
    double oursEval;
    double foesEval;
    double oursHeroEval;
    double enemysHeroEval;
    PUnits ours, enemys, foes;
    vector<Pos> blocks, towerBlocks;
};

class TypeFen {
public:
    double othersEval;
    double enemysEval;
    double oursEval;
    double foesEval;
    double oursHeroEval;
    double enemysHeroEval;
    Pos battleGround;
    PUnits ours, enemys, foes;

    bool hurt;
    const char *orderType;
    Pos aimPos;

    Pos target[MAXID];
};

static TypeGen Gen;
static TypeFen Fen[5];

int position(int id) {
    return (id - 39) % 5;
}

const PUnit *belongs(int id, PUnits &units) //找出unit组成的vector中包含指定id的unit
{
    for (int i = 0; i < units.size(); ++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

const Pos *belongs(Pos pos, vector<Pos> &units) //找出Pos组成的vector中包含指定pos的Pos
{
    for (int i = 0; i < units.size(); ++i)
        if (units[i] == pos)
            return &units[i];
    return NULL;
}

double unitEval(const PUnit *ptr) //评估一个单位的战斗力
{
    int res = 0;
    if (ptr->name == string("Dog") || ptr->name == string("Bow"))
        res = 2;
    if (ptr->name == string("Fighter") || ptr->name == string("Assassin") || ptr->name == string("Archer")) //鼓励与敌方单位交战
        res = ptr->level + 3;
    if (ptr->name == string("Wolf"))
        res = 6;
    if (ptr->name == string("StoneMan"))
        res = 8;
    if (ptr->name == string("Dragon"))
        res = 10;
    if (ptr->name == string("Tower") || ptr->name == string("Roshan"))
        res = HIGHLEVEL;
    return res * (0.5 + 1. * ptr->hp / (ptr->hp + ptr->max_hp));
}

double unitEval(string name) //评估一个单位的战斗力
{
    int res = 0;
    if (name == string("Dog") || name == string("Bow"))
        res = 2;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //鼓励与敌方单位交战
        res = 3;
    if (name == string("Wolf"))
        res = 6;
    if (name == string("StoneMan"))
        res = 8;
    if (name == string("Dragon"))
        res = 10;
    if (name == string("Tower") || name == string("Roshan"))
        res = HIGHLEVEL;
    return res;
}

double unitEvalHero(string name, int hp, int max_hp, int level) {
    int res;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer"))
        res = level + 3;
    else
        res = int(unitEval(name));
    return res * (0.5 + 1. * hp / (hp + max_hp));
}

int cost[151][151];
Pos Q[100000];
int visit[151][151];
int D[151][151];
Pos Q_prior[151][151];

int findShortestPath(const PMap &map, Pos start, Pos dest, const std::vector<Pos> &blocks,
                     const std::vector<Pos> avoid, std::vector<Pos> &_path)
//带卡位的寻路，返回从位置start到dest的一条最短路径，blocks中的位置不可经过，考虑悬崖，若路径不存在返回一个负数坐标
{
    memset(cost, 0, sizeof cost);
    for (int i = 0; i < 151; ++i)
        for (int j = 0; j < 151; ++j)
            cost[i][j] = 1;
    _path.clear();
    for (int i = 0; i < blocks.size(); ++i) {
        if (checkPos(blocks[i]))
            cost[blocks[i].x][blocks[i].y] = 10000;
    }

    for (int i = 0; i < avoid.size(); ++i) {
        if (checkPos(avoid[i]))
            cost[avoid[i].x][avoid[i].y] += 5;
    }

    if (!checkPos(start) || !checkPos(dest)) {
        _path.push_back(Pos(start.x, start.y));
        return INF;
    }
    Pos _0, _1;

    int dir_ord[4];
    Q[0] = dest;
    memset(visit, 0, sizeof(visit));
    memset(D, 10, sizeof(D));
    visit[dest.x][dest.y] = true;
    D[dest.x][dest.y] = cost[dest.x][dest.y];
    int front = 0, rear = 0;
    for (front = 0, rear = 0; front <= rear; ++front) {
        _0 = Q[front];

        for (int i = 0; i < 4; ++i) {
            _1 = _0 + Pos(dir[i][0], dir[i][1]);

            if (checkPos(_1) && D[_1.x][_1.y] > D[_0.x][_0.y] + cost[_1.x][_1.y] +
                                                ((abs(map.height[_0.x][_0.y] - map.height[_1.x][_1.y]) <= 1) ? 0
                                                                                                             : 1000000)) {
                D[_1.x][_1.y] =
                        D[_0.x][_0.y] + (cost[_1.x][_1.y] + ((abs(map.height[_0.x][_0.y] - map.height[_1.x][_1.y]) <= 1)
                                                             ? 0 : 1000000));
                Q_prior[_1.x][_1.y] = _0;
                if (!visit[_1.x][_1.y]) {
                    visit[_1.x][_1.y] = true;
                    Q[++rear] = _1;
                }
            }
        }
        visit[_0.x][_0.y] = false;
    }
    for (_0 = start; _0 != dest; _0 = Q_prior[_0.x][_0.y]) {
        _path.push_back(_0);
    }
    _path.push_back(_0);
    return D[start.x][start.y];
}

void avoidAttacked(std::vector<Pos> &_path) {
    while (_path.size() > 1) {
        if (belongs(_path[_path.size() - 1], Gen.towerBlocks))
            _path.pop_back();
        else
            break;
    }
}

int monsterId(Pos pos) {
    for (int i = 0; i < 23; ++i)
        if (pos == monsterPos[i]) return i + 16;
    return -1;
}

int damage(const PUnit *a, const PUnit *b) {
    int res = 0;
    vector<const PSkill *> useSkill;
    for (int i = 0; i < a->skills.size(); ++i) {
        const PSkill *ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId)) {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //寻找可用技能
            if (belongs(b->id, ptr_foe) || strstr(ptr->name, "Hide") || strstr(ptr->name, "PowerUp"))
                useSkill.push_back(ptr);
        }
    }

    bool decide = false;
    if (!decide) if (a->operator[]("OnlyTarget")->val[0] == -1)
        for (int i = 0; i < useSkill.size(); ++i) {
            const PSkill *ptr = useSkill[i];
            if (strstr(ptr->name, "Hide"))
                decide = true, res = Hided_atk_delta[ptr->level];
        }
    if (b->typeId < 3) if (a->operator[]("OnlyTarget")->val[0] == -1) if (!decide)
        for (int i = 0; i < useSkill.size(); ++i) {
            const PSkill *ptr = useSkill[i];
            if (strstr(ptr->name, "FlyingBlade"))
                decide = true, res = FlightBlade_damage[ptr->level];
        }
    if (a->operator[]("OnlyTarget")->val[0] == -1 ||
        (a->operator[]("OnlyTarget")->val[0] == b->id)) if (!decide) if (a->canUseSkill(0)) if (
            dis2(a->pos, b->pos) <= a->range) //判断单位b是否在攻击范围内
    {
        res = a->atk + (a->findBuff("Hided") ? Hided_atk_delta[a->findSkill("Hide")->level] : 0) - b->def;
    } else {
        res = (a->atk + (a->findBuff("Hided") ? Hided_atk_delta[a->findSkill("Hide")->level] : 0) - b->def) /
              int(ceil(dis(a->pos, b->pos) / sqrt(a->speed)));
    }
    return res;
}

void fighting(const PUnit *a, const PUnit *b, PCommand &cmd) //单位a对单位b发起进攻
{
    Operation op;
    op.id = a->id;

    vector<const PSkill *> useSkill;
    for (int i = 0; i < a->skills.size(); ++i) {
        const PSkill *ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId)) {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //寻找可用技能
            if (belongs(b->id, ptr_foe) || strstr(ptr->name, "Hide") || strstr(ptr->name, "PowerUp"))
                useSkill.push_back(ptr);
        }
    }

    bool decide = false;

    if (b->typeId < 3) if (!decide) if (a->operator[]("OnlyTarget")->val[0] == -1)
        for (int i = 0; i < useSkill.size(); ++i) {
            const PSkill *ptr = useSkill[i];
            if (strstr(ptr->name, "Hide")) {
                op.type = ptr->name;
                if (ptr->needTarget())
                    op.targets.push_back(b->pos);
                decide = true;
            }
        }

    if (b->typeId < 3) if (!decide) if (a->operator[]("OnlyTarget")->val[0] == -1)
        for (int i = 0; i < useSkill.size(); ++i) {
            const PSkill *ptr = useSkill[i];
            if (strstr(ptr->name, "FlyingBlade")) {
                op.type = ptr->name;
                if (ptr->needTarget())
                    op.targets.push_back(b->pos);
                decide = true;
            }
        }

    if (!decide) if (dis2(a->pos, b->pos) <= a->range) //判断单位b是否在攻击范围内
    {
        if (a->operator[]("OnlyTarget")->val[0] == -1 ||
            a->operator[]("OnlyTarget")->val[0] == b->id) if (a->canUseSkill(0)) {
            op.type = "Attack";
            op.targets.push_back(b->pos);
            decide = true;
        }
    }

    if (!decide) if (dis2(a->pos, b->pos) <= a->speed) {
        op.type = "Move";
        findShortestPath(*MAP, a->pos, b->pos, Gen.blocks, Gen.towerBlocks, op.targets);
        decide = true;
    } else {
        if (a->operator[]("OnlyTarget")->val[0] == -1)
            for (int i = 0; i < useSkill.size(); ++i) {
                const PSkill *ptr = useSkill[i];
                if (strstr(ptr->name, "Blink")) {
                    op.type = ptr->name;
                    if (ptr->needTarget())
                        op.targets.push_back(b->pos);
                    decide = true;
                }
            }
    }

    if (!decide) {
        op.type = "Move";
        findShortestPath(*MAP, a->pos, b->pos, Gen.blocks, Gen.towerBlocks, op.targets);
        decide = true;
    }
    cmd.cmds.push_back(op);
}

void escape(const PUnit *a, const Pos b, PCommand &cmd) {
    Operation op;
    op.id = a->id;

    bool decide = false;
    for (int i = 0; i < a->skills.size(); ++i) {
        const PSkill *ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId)) {
            if (a->operator[]("OnlyTarget")->val[0] == -1) if (strstr(ptr->name, "Hide")) {
                if (!decide)
                    op.type = ptr->name;
                if (ptr->needTarget())
                    op.targets.push_back(b);
                decide = true;
            }
            if (a->operator[]("OnlyTarget")->val[0] == -1) if (strstr(ptr->name, "Blink")) {
                if (!decide) if (dis2(a->pos, b) <= a->speed) {
                    op.type = "Move";
                    findShortestPath(*MAP, a->pos, b, Gen.blocks, Gen.towerBlocks, op.targets);
                    decide = true;
                } else {
                    op.type = ptr->name;
                    if (ptr->needTarget()) {
                        int minDis = INF;
                        Pos target = DEFAULFPOS;
                        vector<Pos> targets;
                        findShortestPath(*MAP, a->pos, b, Gen.blocks, Gen.towerBlocks, targets);
                        for (int x = a->pos.x - int(sqrt(Blink_range)); x <= a->pos.x + int(sqrt(Blink_range)); ++x)
                            for (int y = a->pos.y - int(sqrt(Blink_range)); y <= a->pos.y + int(sqrt(Blink_range)); ++y)
                                if (checkPos(Pos(x, y)) && dis2(Pos(x, y), a->pos) <= Blink_range && D[x][y] <= minDis)
                                    minDis = D[x][y], target = Pos(x, y);
                        op.targets.push_back(target);
                    }
                    decide = true;
                }
            }
        }
    }

    if (!decide) {
        op.type = "Move";
        findShortestPath(*MAP, a->pos, b, Gen.blocks, Gen.towerBlocks, op.targets);
        decide = true;
    }
    cmd.cmds.push_back(op);
}


const char *Assasin_Skill_LU[5][10] = {
        {"BlinkLU", "YellowPoint", "YellowPoint", "BlinkLU", "BlinkLU", "HideLU",  "FBLU",    "FBLU",   "FBLU",   "HideLU"},
        {"BlinkLU", "YellowPoint", "YellowPoint", "BlinkLU", "BlinkLU", "HideLU",  "FBLU",    "FBLU",   "FBLU",   "HideLU"},
        {"HideLU",  "FBLU",        "FBLU",        "FBLU",    "BlinkLU", "BlinkLU", "BlinkLU", "HideLU", "HideLU", "YellowPoint"},
        {"HideLU",  "FBLU",        "FBLU",        "FBLU",    "BlinkLU", "BlinkLU", "BlinkLU", "HideLU", "HideLU", "YellowPoint"},
        {"HideLU",  "FBLU",        "FBLU",        "FBLU",    "BlinkLU", "BlinkLU", "BlinkLU", "HideLU", "HideLU", "YellowPoint"}
};

/*
{"HideLU",  "FBLU",    "FBLU", "FBLU", "BlinkLU", "BlinkLU",
"BlinkLU",  "HideLU", "HideLU", "YellowPoint"},
*/

void levelUp(const PUnit *a, PCommand &cmd) //单位a升级操作
{
    Operation op;
    op.id = a->id;
    op.type = Assasin_Skill_LU[position(a->id)][a->level]; //升级技能
    cmd.cmds.push_back(op);
}

void getFoes(vector<Pos> &atk_tar, int l, int u) //根据等级寻找地图中相应
{
    double t = unitEval("Tower");
    if (l <= t && t <= u) {
        const Pos *tower = INFO->player ? Player0_tower_pos : Player1_tower_pos;
        for (int i = 0; i < 2; ++i)
            if (!Gen.towerDes[i])
                atk_tar.push_back(tower[i]);
    }
    t = unitEval("Dragon");
    if (l <= t && t <= u) {
        for (int i = 0; i < 2; ++i)
            if (INFO->round >= Gen.revivingTime[monsterId(Dragon_pos[i])])
                atk_tar.push_back(Dragon_pos[i]);
        if (INFO->round >= Gen.revivingTime[monsterId(Roshan_pos[0])])
            atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEval("Wolf");
    if (l <= t && t <= u) {
        for (int i = 0; i < 4; ++i)
            if (INFO->round >= Gen.revivingTime[monsterId(Wolf_pos[i])])
                atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            if (INFO->round >= Gen.revivingTime[monsterId(StoneMan_pos[i])])
                atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEval("Dog");
    if (l <= t && t <= u) {
        for (int i = 0; i < 8; ++i)
            if (INFO->round >= Gen.revivingTime[monsterId(Dog_pos[i])])
                atk_tar.push_back(Dog_pos[i]);
        for (int i = 0; i < 6; ++i)
            if (INFO->round >= Gen.revivingTime[monsterId(Bow_pos[i])])
                atk_tar.push_back(Bow_pos[i]);
    }
}

void attack(const PUnit *a, Pos b, PCommand &cmd) //单位a寻找对手
{
    Operation op;
    op.id = a->id;
    op.type = "Move";
    int length = findShortestPath(*MAP, a->pos, b, Gen.blocks, Gen.towerBlocks, op.targets); //向弱小对手移动
    avoidAttacked(op.targets);
    if (a->canUseSkill(17)) {
        int minDis = INF;
        Pos target;
        for (int x = a->pos.x - int(sqrt(Blink_range)); x <= a->pos.x + int(sqrt(Blink_range)); ++x)
            for (int y = a->pos.y - int(sqrt(Blink_range)); y <= a->pos.y + int(sqrt(Blink_range)); ++y)
                if (checkPos(Pos(x, y)) && dis2(Pos(x, y), a->pos) <= Blink_range && D[x][y] <= minDis)
                    minDis = D[x][y], target = Pos(x, y);
        if (minDis <= length - 1000000) {
            op.type = "Blink";
            op.targets.clear();
            op.targets.push_back(target);
        }
    }
    cmd.cmds.push_back(op);
}


int nearTower(const PUnit *ptr) {
    double minDis = INF;
    int res = -1;
    for (int i = 0; i < 2; ++i)
        if (!Gen.towerDes[i]) {
            double totalDis = 0;
            vector<Pos> targets;
            totalDis += findShortestPath(*MAP, ptr->pos, tower[i], Gen.blocks, Gen.towerBlocks,
                                         targets);
            if (totalDis < minDis)
                minDis = totalDis, res = i;
        }
    return res;
}

int nearTower() {
    double minDis = INF;
    int res = -1;
    for (int i = 0; i < 2; ++i)
        if (!Gen.towerDes[i]) {
            double totalDis = 0;
            for (int j = 0; j < Gen.ours.size(); ++j)
                if (Gen.ours[j]->isHero()) {
                    vector<Pos> targets;
                    totalDis += findShortestPath(*MAP, Gen.ours[j]->pos, tower[i], Gen.blocks, Gen.towerBlocks,
                                                 targets);
                }
            if (totalDis < minDis)
                minDis = totalDis, res = i;
        }
    return res;
}

int nearMonster(const PUnit *ptr) {

    vector<Pos> targets;
    findShortestPath(*MAP, DEFAULFPOS, ptr->pos, Gen.blocks, Gen.towerBlocks, targets);
    int res = -1;
    int minDis = INF;
    for (int i = 0; i < 23; ++i) {
        string name = "";
        if (i < 8) name = "Dog";
        else if (i < 14) name = "Bow";
        else if (i < 18) name = "Wolf";
        else if (i < 20) name = "StoneMan";
        else if (i < 22) name = "Dragon";
        else name = "Roshan";
        if (position(ptr->id) > 1) if (((monsterPos[i].x + monsterPos[i].y > 150) == INFO->player) &&
                                       (i != 11 && i != 8))
            continue;
        if (position(ptr->id) > 3) if (i == 2 || i == 6 || i == 10 || i == 13) continue;

        if (unitEval(ptr) >= unitEval(name)) {
            int totalDis = D[monsterPos[i].x][monsterPos[i].y];
            if (ptr->findSkill("Blink")->level >= 0)
                totalDis %= 1000000;
            if (totalDis > 10000)
                totalDis = totalDis / 1000000 * 1000000 + totalDis % 10000;

            totalDis = max(totalDis, int((Gen.revivingTime[16 + i] - INFO->round) * sqrt(Assassin_speed)));

            if (i >= 8 && i < 14) {
                //printf("BOW %d %d\n", i, totalDis);
            }
            if (totalDis < minDis)
                minDis = totalDis, res = i;
        }
    }
    return res;
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //第0回合选择英雄
{
    for (int i = 0; i < info.units.size(); ++i) {
        Operation op;
        op.type = "ChooseAssassin";
        op.targets.clear();
        op.id = info.units[i].id;
        cmd.cmds.push_back(op); //随机选择职业
    }
}

void init() //一些参数初始化
{
    memset(Gen.revivingTime, 0, sizeof(Gen.revivingTime));
    memset(Gen.towerDes, 0, sizeof(Gen.towerDes));
    Gen.towerDes[0] = Gen.towerDes[1] = false;
    blocks.clear();
    getFoes(blocks, 0, MAXLEVEL);

    for (int i = 0; i < 2; ++i) {
        blocks.push_back(Player0_tower_pos[i]); //地图上固定点不可经过
        blocks.push_back(Player1_tower_pos[i]); //地图上固定点不可经过
    }
    blocks.push_back(Player0_spring_pos[0]);
    blocks.push_back(Player1_spring_pos[0]);
    for (int i = 0; i < 5; ++i)
        Fen[i].orderType = "nothing",
                Fen[i].aimPos = DEFAULFPOS;

}

void fightAlone(TypeFen &Fen, const PUnit *ptr, const PPlayerInfo &info, PCommand &cmd) {
    //printf("fightAlone(%d %d %d %s)\n", ptr->id, Fen.target[ptr->id].x, Fen.target[ptr->id].y, Fen.orderType);
    if ((*ptr)["Exp"]->val[3]) //优先升级技能
        levelUp(ptr, cmd);
    else if (strstr(Fen.orderType, "attacking")) {
        if (ptr->hp <= ptr->max_hp / 4 && strstr(Fen.orderType, "Foes") &&
            Gen.lastHit[ptr->id] >= INFO->round - 1 && Fen.ours.size() > 1)
            escape(ptr, spring[0], cmd);
        else fighting(ptr, INFO->findUnitByPos(Fen.target[ptr->id]), cmd); //与目标打斗
    }
    else if (strstr(Fen.orderType, "attack"))
        attack(ptr, Fen.target[ptr->id], cmd); //若附近没有敌军，在地图中寻找一个
    else if (strstr(Fen.orderType, "escape"))
        escape(ptr, Fen.target[ptr->id], cmd);
}

double allReach(TypeFen &Fen, Pos pos) { //到达某个位置附近
    double total = 0;
    for (int i = 0; i < Fen.ours.size(); ++i) //所有己方单位
    {
        const PUnit *ptr = Fen.ours[i];
        if (ptr->isHero()) if (dis2(pos, ptr->pos) <= ptr->view)
            total += unitEval(ptr);
    }
    return total;
}

int reach(const PUnit *ptr, Pos pos) { //到达某个位置附近
    return dis2(pos, ptr->pos) <= ptr->view;
}

int reach(TypeFen &Fen, Pos pos) { //到达某个位置附近
    for (int i = 0; i < Fen.ours.size(); ++i) //所有己方单位
    {
        const PUnit *ptr = Fen.ours[i];
        if (ptr->isHero()) if (dis2(pos, ptr->pos) <= ptr->view)
            return true;
    }
    return false;
}

void updateGen() {

    Gen.enemysEval = Gen.oursEval = Gen.foesEval = Gen.enemysHeroEval = Gen.oursHeroEval = 0;
    Gen.towerAttacked[0] = Gen.towerAttacked[1] = 0;

    mytower = INFO->player ? Player1_tower_pos : Player0_tower_pos;
    tower = INFO->player ? Player0_tower_pos : Player1_tower_pos;
    spring = INFO->player ? Player1_spring_pos : Player0_spring_pos;
    //printf("Tower : %d %d", Gen.towerDes[0], Gen.towerDes[1]);
    towerBlocks = blocks;
    for (int i = 0; i < 2; ++i)
        if (!Gen.towerDes[i])
            for (int x = tower[i].x - int(sqrt(Tower_range)); x <= tower[i].x + int(sqrt(Tower_range)); ++x)
                for (int y = tower[i].y - int(sqrt(Tower_range)); y <= tower[i].y + int(sqrt(Tower_range)); ++y)
                    if (checkPos(Pos(x, y)) && dis2(Pos(x, y), tower[i]) <= Tower_range)
                        towerBlocks.push_back(Pos(x, y));

    int _sz = (int) INFO->units.size();

    Gen.ours.clear(), Gen.enemys.clear(), Gen.foes.clear();
    for (int i = 0; i < _sz; ++i) {
        if (!INFO->units[i].findBuff("Reviving")) if (INFO->units[i].player == INFO->player) {
            Gen.ours.push_back(&INFO->units[i]);
            Gen.oursEval += unitEval(&INFO->units[i]);
            if (INFO->units[i].isHero())
                Gen.oursHeroEval += unitEval(&INFO->units[i]);
        }
        else if (INFO->units[i].player < 2) {
            Gen.enemys.push_back(&INFO->units[i]),
                    Gen.enemysEval += unitEval(&INFO->units[i]);
            if (INFO->units[i].isHero()) {
                Gen.enemysHeroEval += unitEval(&INFO->units[i]);
                if (dis2(INFO->units[i].pos, mytower[0]) <= Tower_view) ++Gen.towerAttacked[0];
                if (dis2(INFO->units[i].pos, mytower[1]) <= Tower_view) ++Gen.towerAttacked[1];
            }
        }
        else {
            Gen.foes.push_back(&INFO->units[i]), Gen.foesEval += unitEval(&INFO->units[i]);
        }
    }

    Gen.blocks = blocks, Gen.towerBlocks = towerBlocks;
    for (int i = 0; i < _sz; ++i) {
        Gen.blocks.push_back(INFO->units[i].pos);
        Gen.towerBlocks.push_back(INFO->units[i].pos);
    }

    for (int x = 0; x < 151; ++x)
        for (int y = 0; y < 151; ++y)
            for (int i = 0; i < _sz; ++i)
                if (!INFO->units[i].findBuff("Reviving") && INFO->units[i].player != INFO->player) if (
                        dis2(Pos(x, y), INFO->units[i].pos) <= INFO->units[i].range)
                    Gen.towerBlocks.push_back(Pos(x, y));

    //对于事业内的单位分类
    for (int i = 0; i < Gen.ours.size(); ++i) //所有己方单位
    {
        const PUnit *ptr = Gen.ours[i];
        for (int j = 0; j < 2; ++j)
            if (dis2(ptr->pos, tower[j]) <= ptr->view && !INFO->findUnitByPos(tower[j]) &&
                MAP->height[ptr->pos.x][ptr->pos.y] > j)
                Gen.towerDes[j] = true; //去除已摧毁防御塔
    }

    for (int i = 0; i < Gen.ours.size(); ++i) //所有己方单位
    {
        const PArg *pgr = Gen.ours[i]->operator[]("LastHit");
        for (int j = 0; j < pgr->val.size(); ++j)
            Gen.lastHit[Gen.ours[i]->id] = max(pgr->val[j], Gen.lastHit[Gen.ours[i]->id]);
    }
    for (int i = 0; i < Gen.ours.size(); ++i) //所有己方单位
    {
        const PUnit *ptr = Gen.ours[i];
        INFO->findUnitInArea(ptr->pos, ptr->view, nearBy);
        for (int j = 0; j < nearBy.size(); ++j)
            if (dis2(ptr->pos, nearBy[j]->pos) <= ptr->view && nearBy[j]->findBuff("Reviving"))
                Gen.revivingTime[nearBy[j]->id] = INFO->round + nearBy[j]->findBuff("Reviving")->timeLeft;
    }
}


void updateFen(TypeFen &Fen, const PUnit *ptr) {

    Fen.othersEval = Fen.enemysEval = Fen.oursEval = Fen.foesEval = Fen.enemysHeroEval = Fen.oursHeroEval = Fen.hurt = 0;
    Fen.battleGround = DEFAULFPOS;
    Fen.ours.clear(), Fen.enemys.clear(), Fen.foes.clear();
    memset(Fen.target, 0, sizeof Fen.target);

    if (ptr->operator[]("Hp")->val[0] <= ptr->operator[]("Hp")->val[1] / 3)
        Fen.hurt = true;

    Fen.battleGround = ptr->pos;

    INFO->findUnitInArea(ptr->pos, 4 * ptr->view, nearBy);
    for (int j = 0; j < nearBy.size(); ++j)
        if (!nearBy[j]->findBuff("Reviving")) {
            if (nearBy[j]->player != INFO->player) if (nearBy[j]->player < 2)
                Fen.enemysEval += unitEval(nearBy[j]), Fen.enemysHeroEval += (nearBy[j]->isHero()) ? unitEval(nearBy[j])
                                                                                                   : 0;
            else Fen.foesEval += unitEval(nearBy[j]);
            else
                Fen.oursEval += unitEval(nearBy[j]), Fen.oursHeroEval += (nearBy[j]->isHero()) ? unitEval(nearBy[j])
                                                                                               : 0;

            if (nearBy[j]->player == INFO->player)
                Fen.ours.push_back(nearBy[j]);
            else if (nearBy[j]->player < 2)
                Fen.enemys.push_back(nearBy[j]);
            else
                Fen.foes.push_back(nearBy[j]);
        }
}

void getCenterOrder(TypeFen &Fen, const PUnit *ptr) {

    if (strstr(Fen.orderType, "Enemys"))
        Fen.othersEval = Fen.enemysEval;
    else if (strstr(Fen.orderType, "Foes"))
        Fen.othersEval = Fen.foesEval;
    else
        Fen.othersEval = Fen.enemysEval;

    //printf("getCenterOrder(%d %d %s)\n", Fen.aimPos.x, Fen.aimPos.y, Fen.orderType);

    //printf("%lf %lf %lf\n", Fen.oursHeroEval, Fen.enemysHeroEval, Fen.foesEval);

    if (strstr(Fen.orderType, "attacking")) {
        //正在交战中
        if (Fen.enemysHeroEval > EPS && strstr(Fen.orderType, "Foes")) {
            Fen.orderType = "attackingEnemys",
                    Fen.aimPos = Fen.battleGround;
            getCenterOrder(Fen, ptr);
        } else if (Fen.othersEval > Fen.oursHeroEval && (Gen.towerAttacked[0] + Gen.towerAttacked[1] < 2))
            Fen.aimPos = spring[0],
                    Fen.orderType = "escape";
        else if (Fen.othersEval < EPS) {
            Fen.orderType = "nothing",
                    Fen.aimPos = DEFAULFPOS,
                    getCenterOrder(Fen, ptr);
        }
            /*else if ((dis2(mytower[0], ptr->pos) <= 500 || dis2(mytower[1], ptr->pos) <= 500) &&
                     Gen.lastHit[ptr->id] >= INFO->round - 3 &&
                     strstr(Fen.orderType, "Foes")) {
                Fen.orderType = "escape", Fen.aimPos = (dis2(mytower[0], ptr->pos) <= 500 ? mytower[0] : mytower[1]);
            } */
        else {
            Fen.aimPos = Fen.battleGround,
                    Fen.orderType = (strstr(Fen.orderType, "Enemys")) ? "attackingEnemys"
                                                                      : "attackingFoes";
        }
    } else if (strstr(Fen.orderType, "attack")) {
        //前往下一次攻击
        if (Fen.enemysHeroEval > EPS) {
            Fen.orderType = "attackingEnemys",
                    Fen.aimPos = Fen.battleGround;
            getCenterOrder(Fen, ptr);
        } else if (Gen.towerAttacked[0] + Gen.towerAttacked[1] >= 2) {
            Fen.orderType = "attackEnemys",
                    Fen.aimPos = Gen.towerAttacked[0] > Gen.towerAttacked[1] ? mytower[0] : mytower[1];
        } else if (reach(Fen, Fen.aimPos) && allReach(Fen, Fen.aimPos) >= Fen.othersEval) {
            Fen.orderType = (strstr(Fen.orderType, "Enemys")) ? "attackingEnemys" : "attackingFoes",
                    Fen.aimPos = Fen.battleGround;
            getCenterOrder(Fen, ptr);
        } else if (Fen.oursEval < Fen.enemysEval && (Fen.aimPos == tower[0] || Fen.aimPos == tower[1]) &&
                   reach(Fen, Fen.aimPos)) {
            Fen.orderType = "escape",
                    Fen.aimPos = spring[0];
        } else if (strstr(Fen.orderType, "Enemys") && reach(Fen, Fen.aimPos) && Fen.enemysEval < EPS) {
            Fen.orderType = "nothing",
                    Fen.aimPos = DEFAULFPOS;
            getCenterOrder(Fen, ptr);
        } else if (Gen.lastHit[ptr->id] == INFO->round - 1) {
            Fen.orderType = "attackingFoes",
                    Fen.aimPos = Fen.battleGround;
            getCenterOrder(Fen, ptr);
        } else
            Fen.orderType = (strstr(Fen.orderType, "Enemys")) ? "attackEnemys" : "attackFoes",
                    Fen.aimPos = Fen.aimPos;
    } else if (strstr(Fen.orderType, "escape")) {
        //逃命中

        //printf("ESCAP %d %d %lf\n", Fen.hurt, ptr->id, Fen.othersEval);
        if (Fen.hurt) {
            Fen.aimPos = spring[0],
                    Fen.orderType = "escape";
        } else if (Fen.othersEval > EPS)
            Fen.aimPos = spring[0],
                    Fen.orderType = "escape";
        else if (reach(ptr, Fen.aimPos)) {
            Fen.aimPos = DEFAULFPOS,
                    Fen.orderType = "nothing";
            getCenterOrder(Fen, ptr);
        } else {
            Fen.aimPos = Fen.battleGround,
                    Fen.orderType = "attackingEnemys",
                    getCenterOrder(Fen, ptr);
        }

    } else if (strstr(Fen.orderType, "nothing")) {
        //当前无事可做，寻找下一个指令
        //printf("HURT %d %d\n", Fen.hurt, ptr->id);
        if (Fen.hurt) {
            Fen.aimPos = spring[0],
                    Fen.orderType = "escape";
        } else if (Fen.oursHeroEval > unitEval("Tower")) {
            Fen.aimPos = tower[nearTower()],
                    Fen.orderType = "attackEnemys";
        } else if (Gen.towerAttacked[0] + Gen.towerAttacked[1] >= 2) {
            Fen.orderType = "attackEnemys",
                    Fen.aimPos = Gen.towerAttacked[0] > Gen.towerAttacked[1] ? mytower[0] : mytower[1];
        } else if (Fen.oursHeroEval > unitEval("Dragon") &&
                   INFO->round <= 10) {
            Fen.aimPos = Dragon_pos[INFO->player],
                    Fen.orderType = "attackFoes";
        } else {
            //去自己野区打野
            int aim = nearMonster(ptr);
            if (aim == -1)
                Fen.aimPos = spring[0],
                        Fen.orderType = "escape";
            else
                Fen.orderType = "attackFoes",
                        Fen.aimPos = monsterPos[aim];
            //getCenterOrder(Fen, ptr);
        }
    }

}

double miniEval;
int totalDamage[MAXID];
Pos tmpTarget[MAXID];

void figureTotalDamage(TypeFen &Fen, PUnits ours, PUnits others) {
    double restEval = 0;
    for (int i = 0; i < others.size(); ++i) {
        if (totalDamage[i] > others[i]->hp);
        else
            restEval += unitEvalHero(others[i]->name, others[i]->hp - totalDamage[i],
                                     others[i]->max_hp, others[i]->level);
    }
    //printf("Total : %lf\n", restEval);
    if (restEval < miniEval) {
        for (int i = 0; i < ours.size(); ++i)
            if (ours[i]->isHero()) {
                Fen.target[ours[i]->id] = tmpTarget[ours[i]->id];
                //printf("%d %d %d\n", ours[i]->id, tmpTarget[ours[i]->id].x, tmpTarget[ours[i]->id].y);
            }
        miniEval = restEval;
    }
}

void DFS(TypeFen &Fen, int deep, PUnits ours, PUnits others) {
    if (deep >= ours.size()) {
        figureTotalDamage(Fen, ours, others);
        return;
    }
    if (deep == 0) {
        miniEval = INF;
        memset(totalDamage, 0, sizeof totalDamage);
        memset(tmpTarget, 0, sizeof tmpTarget);
    }
    if (ours[deep]->isHero())
        for (int i = 0; i < others.size(); ++i) {
            tmpTarget[ours[deep]->id] = others[i]->pos;
            int tmp = damage(ours[deep], others[i]);
            totalDamage[i] += tmp;
            //printf("DFS(%d %d %d)\n", ours[deep]->id, others[i]->id, tmp);
            DFS(Fen, deep + 1, ours, others);
            totalDamage[i] -= tmp;
        }
    else DFS(Fen, deep + 1, ours, others);
}

void getCenterTarget(TypeFen &Fen) {

    if (strstr(Fen.orderType, "attacking")) {
        if (strstr(Fen.orderType, "Enemys")) DFS(Fen, 0, Fen.ours, Fen.enemys);
        else if (strstr(Fen.orderType, "Foes")) DFS(Fen, 0, Fen.ours, Fen.foes);
    } else if (strstr(Fen.orderType, "attack")) {
        for (int i = 0; i < Fen.ours.size(); ++i)
            if (Fen.ours[i]->isHero()) Fen.target[Fen.ours[i]->id] = Fen.aimPos;
    } else if (strstr(Fen.orderType, "escape")) {
        for (int i = 0; i < Fen.ours.size(); ++i)
            if (Fen.ours[i]->isHero()) Fen.target[Fen.ours[i]->id] = Fen.aimPos;
    }

    //for (int i = 0; i < Fen.ours.size(); ++i)
        //printf("%d TO %d %d\n", Fen.ours[i]->id, Fen.target[Fen.ours[i]->id].x, Fen.target[Fen.ours[i]->id].y);

}


void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    if (info.round == 0) {
        //freopen("log.txt", "w", stdout);
        chooseHero(info, cmd); //第0回合选择英雄
        init(); //一些参数初始化
    } else if (info.round == 1) {
        updateGen();
        for (int i = 0; i < Gen.ours.size(); ++i)
            if (Gen.ours[i]->isHero()) if (Gen.ours[i]->operator[]("Exp")->val[3]) //优先升级技能
                levelUp(Gen.ours[i], cmd);
    } else //正式回合
    {
        updateGen();
        //printf("updateGen()\n");
        for (int i = 0; i < Gen.ours.size(); ++i)
            if (Gen.ours[i]->isHero()) updateFen(Fen[position(Gen.ours[i]->id)], Gen.ours[i]);
        //printf("getCenterOrder()\n");
        for (int i = 0; i < Gen.ours.size(); ++i) {
            if (Gen.ours[i]->isHero())
                getCenterOrder(Fen[position(Gen.ours[i]->id)], Gen.ours[i]);
        }
        //printf("getCenterTarget()\n");
        for (int i = 0; i < Gen.ours.size(); ++i)
            if (Gen.ours[i]->isHero()) getCenterTarget(Fen[position(Gen.ours[i]->id)]);

        for (int i = 0; i < Gen.ours.size(); ++i) //所有己方单位
            if (Gen.ours[i]->isHero()) //ptr是一个英雄，不和队友配合，单独作战
            if (!Gen.ours[i]->findBuff("Reviving"))
                fightAlone(Fen[position(Gen.ours[i]->id)], Gen.ours[i], info, cmd);
    }
}

// ai_v10.cc 1战3弓1刺 加强团战，增加寻路函数
#include "sdk.h"
#include <queue>
#include <cmath>
using namespace std;

const PMap *MAP;
const PPlayerInfo *INFO;
PCommand *CMD;
static vector<const PUnit*> nearBy;
static vector<Pos> blocks;
static vector<PUnit> myHeros;
static vector<PUnit> enemyGroups;
static queue<Pos> jungle_queue_assassin;
static queue<Pos> jungle_queue_near_tower;
static queue<Pos> jungle_queue_start_low;
static queue<Pos> jungle_queue_start_high;
static queue<Pos> jungle_queue_ready_defend;
static queue<Pos> jungle_queue_self_dragon;
static queue<Pos> jungle_queue_enemy_dragon;
static queue<Pos> jungle_queue_enemy_dragon_loop;
static queue<Pos> defend_queue_high;
static queue<Pos> defend_queue_low;
static queue<Pos> defend_queue_both;
static queue<Pos> tank_queue_high;
static queue<Pos> tank_queue_low;
static vector<PUnit> myHerosRecord;
static vector<PUnit> unitsRecord;
static vector<int> enemyRevivedRound;
static PUnit DPUnit(0,0,0,0,0,0);
static bool ruinFirstEnemyTower;
static bool lostFirstSelfTower;
static bool isGoingToRush;
static bool isTowerInDanger;
static int reviving_enemy_num;
static int dangerTowerCount;
static int pushFailTimes;

static int vst[Map_size][Map_size];
static Pos Q[Map_size * Map_size + 1], Q_prior[Map_size][Map_size];
static int countF = 0;

static int hasSetOperation[] = { 0, 0, 0, 0, 0 };
static int needGoToSpring[] = { 0, 0, 0, 0, 0 };
static int deadTimes[] = { 0, 0, 0, 0, 0 };
static Pos fiveTeam[] = { Pos(-3,-1), Pos(3,-1), Pos(0,0), Pos(-2,1), Pos(2,1) };
static Pos fourTeam[] = { Pos(-2,2), Pos(2,-2), Pos(-2,-2), Pos(2,2) };
static Pos threeTeam[] = { Pos(0,-1), Pos(-2,1), Pos(2,1) };
static Pos twoTeam[] = { Pos(-2,0), Pos(2,0) };
static Pos oneTeam[] = { Pos(0,0) };

static const Pos SPRING_POINT = Pos(10,140);
static const Pos GATHER_POINT1 = Pos(70,118);
static const Pos GATHER_POINT2 = Pos(112,80);
static const Pos RUSH_POINT1 = Pos(63,45);
static const Pos RUSH_POINT2 = Pos(50,80);
static const Pos DEFEND_POINT1 = Pos(75,123);
static const Pos DEFEND_POINT2 = Pos(115,72);
static const Pos DP = Pos(-1,-1);  // Default pos
static const Pos ZP = Pos(0,0);  // Zero pos
static Pos selfTowerPos_hi, selfTowerPos_lo;
static Pos enemyTowerPos_hi, enemyTowerPos_lo;
static Pos springPos, gatherPos1, gatherPos2;
static Pos rushPos1, rushPos2, defendPos1, defendPos2;

static Pos jQueue_assassin1[] = { Pos(8,103), Pos(8,103), Pos(8,103), Pos(8,103),
                                  Pos(8,103), Pos(8,103), Pos(8,103), Pos(8,103), DP }; // once
static Pos jQueue_assassin2[] = { Pos(31,94), Pos(9,102), DP }; // loop
static Pos jQueue_near_tower1[] = { Pos(50,116), Pos(78,116), Pos(83,116), Pos(60,117), Pos(78,116), Pos(83,116), DP };  // once
static Pos jQueue_near_tower2[] = { Pos(116,82), Pos(116,87), Pos(110,75), Pos(105,75), DP };  // loop
static Pos jQueue_start_lo[] = { Pos(50,116), Pos(88,137), Pos(57,118), Pos(54,81), Pos(58,112), Pos(90,137), DP };  // once
static Pos jQueue_start_hi[] = { Pos(50,116), Pos(87,116), Pos(58,116), Pos(87,116), Pos(91,137), DP };  // once
static Pos jQueue_ready_defend1[] = { DP }; // once
static Pos jQueue_ready_defend2[] = { Pos(54,82), Pos(54,110), Pos(80,116), Pos(87,117), Pos(90,138), Pos(88,119), Pos(58,119), DP }; // loop
static Pos jQueue_self_dragon1[] = { Pos(50,117), Pos(52,78), Pos(46,58), Pos(38,56), Pos(27,56), Pos(26,36), Pos(9,38), DP }; // once
static Pos jQueue_self_dragon2[] = { Pos(31,50), Pos(29,37), Pos(7,7), Pos(30,31), Pos(31,50), Pos(11,36), Pos(31,36), DP };  // loop
static Pos jQueue_enemy_dragon1[] = { Pos(50,117), Pos(92,76), Pos(116,82), Pos(116,87), Pos(117,113), Pos(140,138), Pos(121, 118), DP };  // once
static Pos jQueue_enemy_dragon2[] = { Pos(120,97), Pos(121,119), Pos(140,138), Pos(120,115),
                                      Pos(120,98), Pos(140,113), Pos(120,113), DP };  // loop

static Pos dQueue_high[] = { Pos(78,116), Pos(83,116), Pos(60,117), DP };
static Pos dQueue_low[] = { Pos(116,82), Pos(116,87), Pos(110,75), Pos(105,75), DP };
static Pos dQueue_both[] = { Pos(89,111), Pos(91,78), DP };

static Pos tQueue_high1[] = { GATHER_POINT1, GATHER_POINT1, Pos(65,71), Pos(62,46), RUSH_POINT1, DP };
static Pos tQueue_low1[] = { GATHER_POINT1, GATHER_POINT1, Pos(51,102), Pos(51,81), RUSH_POINT2, DP };
static Pos tQueue_high2[] = { GATHER_POINT2, GATHER_POINT2, Pos(65,71), Pos(62,46), RUSH_POINT1, DP };
static Pos tQueue_low2[] = { GATHER_POINT2, GATHER_POINT2, Pos(51,102), Pos(51,81), RUSH_POINT2, DP };

static const int MAX_UNITS_NUM = 50;
static const int FINAL_RUSH_ROUND = 960;
static const int FAR_FROM_SPRING_DIS = 20;
static const int TOO_FAR_TO_ATTACK_DIS = 40;
static const int NEAR_TOWER_DIS = 20;
static const int FIRE_DIS = 5;
static const int HIDE_DIS_FROM_SPRING = 50;
static const int MAX_DIS_FROM_WILD_BORN_POS = 15;
static const int TOO_FAR_TO_DEFEND_TOWER_DIS = 40;
static const double RUSH_WIDER_RATE = 3.0;
static const double BEST_MATCHED_DAMAGE = 1.5;
static const double TOWER_SAFE_HP_RATE = 0.80;
static const double HELP_DEFEND_MIN_HP_RATE = 0.4;
static const double PUSH_MIN_LEVEL = 3.0;
static const int RUSH_REVIVING_REMAIN_ROUND = 14;
static const int RUSH_WITH_LEAST_ENEMY_NUM = 3;
static const int LOOP_TIMES = 30;
static const int CALC_PATH_DIFF = 2;
static const int WEAK_HP = 30;

enum TroopType { Jungle, Defend, Push, Tank, Nil };

struct Formation
{
    int dir;  // 0 -> South; 1 -> East; 2 -> North; 3 -> West
    int scale;
    Pos* _formation;
    Formation () : dir(0), scale(0), _formation(NULL)
    {
    }
    Formation(int s, int d)
    {
        scale = s;
        dir = 0;  // 先默认为0
        switch (scale) {
            case 1:  _formation = oneTeam;   break;
            case 2:  _formation = twoTeam;   break;
            case 3:  _formation = threeTeam; break;
            case 4:  _formation = fourTeam;  break;
            case 5:  _formation = fiveTeam;  break;
            default: _formation = oneTeam;   break;
        }
        dir = d;
    }
};

struct PTroop
{
    TroopType type;
    vector<PUnit> troop;
    Formation formation;
    queue<Pos> route;
    int useRainyRound;
    PTroop(TroopType ty) : type(ty)
    {
        useRainyRound = 0;
    }
    PTroop(TroopType ty, const vector<PUnit> & tr) : type(ty), troop(tr)
    {
        formation = Formation(troop.size(), 0);
        useRainyRound = 0;
        updateRoute();
    }
    PTroop(TroopType ty, const vector<PUnit> & tr, queue<Pos> & rt) : type(ty), troop(tr), route(rt)
    {
        formation = Formation(troop.size(), 0);
        useRainyRound = 0;
    }
    const Pos getPos(int rank) const  {
        return formation._formation[rank];
    }
    const Pos getTroopCenter() const // 以人多的为中心
    {
        Pos getMaxPos(const vector<PUnit> &);
        Pos getMinPos(const vector<PUnit> &);
        Pos maxPos = getMaxPos(troop);
        Pos minPos = getMinPos(troop);
        int max_hero_num_nearby = 0;
        int max_dis_from_spring = 0;
        Pos fakeCenterPos;
        for (int x = minPos.x; x <= maxPos.x; x++) {
            for (int y = minPos.y; y <= maxPos.y; y++) {
                int sum = 0;
                for (int i = 0; i < troop.size(); i++)
                    if (dis2(troop[i].pos, Pos(x,y)) <= troop[i].view)
                        sum++;
                if (sum > max_hero_num_nearby || (sum == max_hero_num_nearby && dis(springPos, Pos(x,y)) > max_dis_from_spring)) {
                    max_hero_num_nearby = sum;
                    max_dis_from_spring = dis(springPos, Pos(x,y));
                    fakeCenterPos = Pos(x,y);
                }
            }
        }
        Pos sum_pos = ZP;
        int sum_num = 0;
        for (int i = 0; i < troop.size(); i++) {
            if (dis2(troop[i].pos, fakeCenterPos) <= troop[i].view) {
                sum_pos = sum_pos + troop[i].pos;
                sum_num++;
            }
        }
        if (sum_num == 0) cout << "ERROR HERE!!!!!!!!!!!!!!!" << endl;
        return Pos(sum_pos.x / sum_num, sum_pos.y / sum_num);
    }
    const bool isApart() const
    {
        Pos troopCenter = getTroopCenter();
        int sum_num = 0;
        for (int i = 0; i < troop.size(); i++)
            if (dis2(troop[i].pos, troopCenter) <= troop[i].view)
                sum_num++;
        if (troop.size() >= 2 && sum_num == 1) {  // 说明散掉了
            return true;
        }
        if (sum_num >= 2 && dis(troopCenter, springPos) <= 10) {
            return true;
        }
        return false;
    }
    double getAverageHp() const
    {
        double hp_sum = 0;
        double maxhp_sum = 0;
        for (int i = 0; i < troop.size(); i++) {
            const PUnit & hero = troop[i];
            maxhp_sum += hero["Hp"]->val[1];
            if (hero.findBuff("Reviving") == NULL && dis(hero.pos, springPos) >= FAR_FROM_SPRING_DIS)  // 离泉水有一定距离才计入hp
                hp_sum += hero.hp;
        }
        return hp_sum / maxhp_sum;
    }
    double getAverageLevel() const
    {
        double level_sum = 0;
        for (int i = 0; i < troop.size(); i++)
            level_sum += troop[i].level;
        return level_sum / troop.size();
    }
    void setType(TroopType newType)
    {
        type = newType;
    }
    bool hasRoute() const
    {
        return (type == Jungle || type == Defend || type == Tank);
    }
    void updateRoute();
    bool isEnoughToPush();
    bool hasLeastTogether(int num);
    bool isTogether();
};
static PTroop myHeroTroop(Nil, myHeros);  // 暂时只有rush的时候用得到
static vector<PTroop> myTroops;

void posToString(const Pos & pos)
{ cout << "(" << pos.x <<  ", " << pos.y << ") "; }
void printOperation(const Operation & op)
{
    cout << "id = " << op.id << "; type = " << op.type << "; typeId = " << op.typeId << "; target = ";
    if (op.targets.size()) posToString(op.targets[op.targets.size()-1]);  cout << endl;
}
inline bool isFighter(const PUnit & unit) { return string(unit.name) == string("Fighter"); }
inline bool isArcher(const PUnit & unit) { return string(unit.name) == string("Archer"); }
inline bool isAssassin(const PUnit & unit) { return string(unit.name) == string("Assassin"); }
inline bool isTower(const PUnit & unit) { return string(unit.name) == string("Tower"); }
inline bool isHero(const PUnit & unit)
{
    if (isFighter(unit) || isArcher(unit) || isAssassin(unit))
        return true;
    return false;
}
inline int rankInTroop(int heroId, const vector<PUnit> & troop)
{
    int i;
    for (i = 0; i < troop.size(); i++) {
        if (troop[i].id == heroId)
            return i;
    }
    return -1;
}
inline void setCommand(const Operation & op)
{
    PCommand & cmd = *CMD;
    int heroRank = rankInTroop(op.id, myHeros);
    if (hasSetOperation[heroRank] == false) {
        printOperation(op);
        cmd.cmds.push_back(op);
        hasSetOperation[heroRank] = true;
    }
}

bool isInBlocks(const Pos & tarPos)
{
    if (blocks.size() == 0) return false;
    Pos diff = tarPos - Pos(75,75);
    if (abs(diff.x) <= 2 && abs(diff.y) <= 2)
        return true;
    return false;
}

bool isFlat(const Pos & a, const Pos & b)
{
    if (b.x < 0|| b.x >= Map_size || b.y < 0 || b.y >= Map_size) return false;
    if (isInBlocks(b)) return false;
    const PMap & map = *MAP;
    int height_a = map.height[a.x][a.y];
    int height_b = map.height[b.x][b.y];
    int height_dis = abs(height_a - height_b);
    if (height_dis <= 1) return true;
    else {
        for (int x = min(a.x, b.x); x <= max(a.x, b.x); x++) {
            for (int y = min(a.y, b.y); y <= max(a.y, b.y); y++) {
                int height_c = map.height[x][y];
                if (height_c == (height_a + height_b) / 2)
                    return true;
            }
        }
        return false;
    }
}

int disToSegment(const Pos & p, const Pos & start, const Pos & end)
{
    if (start == end) return false;
    double a = dis(p, start), b = dis(p, end), c = dis(start, end);
    if (a * a > b * b + c * c || b * b > a * a + c * c)  // 太远的点不要
        return false;
    double l = (a + b + c)/2;     //周长的一半
    double s = sqrt(l * (l-a) * (l-b) * (l-c));  //海伦公式求面积
    double dis = 2 * s / c;
    return dis;
}

bool hasMission(const PUnit & hero)
{
    return hasSetOperation[rankInTroop(hero.id, myHeros)];
}

void chooseHero(const PPlayerInfo & info, PCommand & cmd)  // 2 战士 + 3 弓手
{
    for (int i = 0; i < info.units.size(); i++)
    {
        Operation op;
        if (i == 0)
            op.type = "ChooseAssassin";
        if (i == 1)
            op.type = "ChooseFighter";
        if (i == 2 || i == 3 || i == 4)
            op.type = "ChooseArcher";
        op.targets.clear();
        op.id = info.units[i].id;
        cmd.cmds.push_back(op);
    }
}

bool isPosVisible(const Pos & tar)
{
    const PPlayerInfo & info = *INFO;
    const PMap & map = *MAP;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && dis(tar, unit.pos) <= 9) {
            if (map.height[tar.x][tar.y] >= map.height[unit.pos.x][unit.pos.y] + 2) {} // 有高度差则也视为看不到
            else
                return true;
        }
    }
    return false;
}

Pos getMaxPos(const vector<PUnit> & troop)
{
    int max_x = 0, max_y = 0;
    for (int i = 0; i < troop.size(); i++) {
        const PUnit & hero = troop[i];
        if (hero.pos.x > max_x) max_x = hero.pos.x;
        if (hero.pos.y > max_y) max_y = hero.pos.y;
    }
    return Pos(max_x, max_y);
}
Pos getMinPos(const vector<PUnit> & troop)
{
    int min_x = 150, min_y = 150;
    for (int i = 0; i < troop.size(); i++) {
        const PUnit & hero = troop[i];
        if (hero.pos.x < min_x) min_x = hero.pos.x;
        if (hero.pos.y < min_y) min_y = hero.pos.y;
    }
    return Pos(min_x, min_y);
}

double lenOfPos(const Pos & pos)
{
    return sqrt(pos.x * pos.x + pos.y * pos.y);
}

int dotProduct(const Pos & a, const Pos & b, const Pos & c)  // 向量ab,ac的点积
{
    return (b.x - a.x) * (c.x - a.x) + (b.y - a.y) * (c.y - a.y);
}

double vectorAngleCos(const Pos & a, const Pos & b, const Pos & c) // 向量ab,ac的夹角
{
//    posToString(b-a); posToString(c-a); cout << "FUCK!   ";
    double product = dotProduct(a, b, c);
    double len_sum = lenOfPos(b-a) * lenOfPos(c-a);
//    cout << "product = " << product << ", lensum = " << len_sum << endl;
    if (len_sum > 0) return product / len_sum;
    else return 0;
}

void levelUp(const PUnit & hero)
{
    Operation op;
    op.id = hero.id;
    int fighter_lu[] = {2,6,2,2,6,6,19,19,19,19};
    int assassin_lu[] = {18,16,16,16,14,19,19,19,19,19};
    int archer_lu1[] = {10,8,10,10,8,8,19,19,19,19};
    int archer_lu2[] = {8,10,10,8,8,10,19,19,19,19};
    int archer_lu3[] = {8,10,8,10,8,10,19,19,19,19};
    int *archer_lu[] = { archer_lu1, archer_lu2, archer_lu3 };
    
    int skillPoints = hero["Exp"]->val[3];
    if (isFighter(hero)) op.typeId = fighter_lu[hero.level - (skillPoints-1)];
    if (isArcher(hero)) op.typeId = archer_lu[hero.id % 3][hero.level - (skillPoints-1)];
    if (isAssassin(hero)) op.typeId = assassin_lu[hero.level - (skillPoints-1)];
    PCommand &cmd = *CMD;
    setCommand(op);
}

void finishLevelUp()
{
    const PPlayerInfo & info = *INFO;
    for (int i = 0; i < myTroops.size(); i++) {
        const vector<PUnit> & troop = myTroops[i].troop;
        bool hasEnemyNearby = false;
        for (int j = 0; j < troop.size(); j++) {
            const PUnit & hero = myHeros[j];
            info.findUnitInArea(hero.pos, hero.view, nearBy);
            for (int k = 0; k < nearBy.size(); k++)
                if (nearBy[k]->camp == 1 - info.camp)
                    hasEnemyNearby = true;
        }
        if (!hasEnemyNearby) {
            for (int j = 0; j < troop.size(); j++)
                if (troop[j].args[8].val[3] > 0)
                    levelUp(troop[j]);
        }
        
    }
}

// override sdk
bool canUseSkill(const PUnit & hero, int typeId)
{
    if (typeId != 0 && hero.findBuff("Yelled")) return false;  // 补充嘲讽情况
    if (typeId == 0 && hero.findSkill(0)->cd == 0) return true;
    const PSkill *skill = hero.findSkill(typeId);
    if (skill) {
        if (skill->level >= 0 && hero.mp >= skill->mp && skill->cd == 0) return true;
    }
    return false;
}
void infectedBySkill(const PUnit & hero, int skillId, vector<PUnit> & unitList)
{
    const PPlayerInfo & info = *INFO;
    unitList.clear();
    int range = 0;
    switch (skillId) {
        case 0: range = hero.range; break;
        case 1: range = Charge_range; break;
        case 3: range = Spin_range; break;
        case 5: range = Yell_range; break;
        case 7: range = PiercingArrow_range; break;
        case 9: range = SignalArrow_range; break;
        case 15: range = FlyingBlade_range; break;
        default: range = hero.view; break;  // 默认范围视野
    }
    for (int i = 0; i < info.units.size(); i++) {
        if (dis2(info.units[i].pos, hero.pos) <= range && info.units[i].camp != info.camp) { // 剔除己方英雄
            bool canChargeIt(const PUnit&, const PUnit&);
            if (skillId == 1 && !canChargeIt(hero, info.units[i])) continue;
            unitList.push_back(info.units[i]);
        }
    }
}
void infectedBySkill(int heroId, int skillId, vector<PUnit> & unitList)
{
    const PPlayerInfo & info = *INFO;
    const PUnit & hero = *info.findUnitById(heroId);
    infectedBySkill(hero, skillId, unitList);
}
void findShortestPath(Pos start, Pos dest, const std::vector<Pos> &blocks, std::vector<Pos> &_path)
{
    const PMap & map = *MAP; const PPlayerInfo & info = *INFO;
    ++countF;
    _path.clear();
    int _sz = blocks.size();
    for (int i=0; i<_sz; ++i)
    {
        if (checkPos(blocks[i]))
            vst[blocks[i].x][blocks[i].y] = countF;
    }
    if (!checkPos(start) || !checkPos(dest))
    {
        _path.push_back(Pos());
        return;
    }
    for (int i=0; i<info.units.size(); ++i)
    {
        if (info.units[i].pos != dest)
            vst[info.units[i].pos.x][info.units[i].pos.y] = countF;
    }
    Pos _0, _1;
    
    int dir_ord[4] = { 0, 1, 2, 3 };
    Q[0] = start;
    vst[start.x][start.y] = countF;
    vst[dest.x][dest.y] = countF - 1;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) {
            for (int j=0; j<3; ++j) {
                Pos cur = _0 + Pos(dir[dir_ord[j]][0], dir[dir_ord[j]][1]);
                Pos next = _0 + Pos(dir[dir_ord[j+1]][0], dir[dir_ord[j+1]][1]);
                if (dis2(cur, start) + dis2(cur, dest) > dis2(next, start) + dis2(next, dest)) {
                    int temp = dir_ord[j];
                    dir_ord[j] = dir_ord[j+1];
                    dir_ord[j+1] = temp;
                }
            }
        }
        bool arrive_dest = false;
        for (int i=0; i<4; ++i) {
            _1 = _0 + Pos(dir[dir_ord[i]][0], dir[dir_ord[i]][1]);
            if (checkPos(_1) && abs(map.height[_0.x][_0.y] - map.height[_1.x][_1.y]) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
                if (_1 == dest) {
                    arrive_dest = true;
                }
            }
        }
        if (arrive_dest) break;
    }
    
    if (vst[dest.x][dest.y] == countF) {
        int max_dis = 0;
        Pos farestPos;
        for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y]) {
            int m_dis = disToSegment(_0, start, dest);
            if (m_dis > max_dis) {
                max_dis = m_dis;
                farestPos = _0;
            }
        }
        if (max_dis >= CALC_PATH_DIFF) {
            findShortestPath(start, farestPos, blocks, _path);
            vector<Pos> path_;
            findShortestPath(farestPos, dest, blocks, path_);
            for (int i = 1; i < path_.size(); i++)
                _path.push_back(path_[i]);
            return;
        }
        else {
            for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y])
                _path.push_back(_0);
            _path.push_back(_0);
            reverse(_path.begin(), _path.end());
        }
    } else _path.push_back(Pos());
}

bool isSameRoute(const queue<Pos> & route1, const queue<Pos> & route2)
{
    cout << "isSameRoute between ";
    if (route1.size() && route2.size()) {
        posToString(route1.front()); cout << "and "; posToString(route2.front()); cout << endl;
    }
    cout << " ?";
    if (route1.size() != route2.size()) { cout << "false" << endl; return false;}
    int count = 0;
    queue<Pos> r1 = route1;
    while (r1.size()) {
        queue<Pos> r2 = route2;
        while (r2.size()) {
            if (r2.front() == r1.front()) {
                count++;
                break;
            }
            r2.pop();
        }
        r1.pop();
    }
    cout << (count >= route1.size()) << endl;
    return count >= route1.size();
}

bool hasAliveWildNearBy(const PTroop & pTroop)
{
    const vector<PUnit> & troop = pTroop.troop;
    const PPlayerInfo & info = *INFO;
    for (int i = 0; i < troop.size(); i++) {
        info.findUnitInArea(troop[i].pos, troop[i].view, nearBy);
        for (int j = 0; j < nearBy.size(); j++) {
            const PUnit & unit = *nearBy[j];
            if (unit.camp == 2 && unit.findBuff("Reviving") == NULL) {
                if (unit.hp >= 600 && (pTroop.getAverageLevel() + 2) * pTroop.troop.size() < 8) continue;  // 英雄等级太低则无视
//                if (pTroop.type == Tank && (unit.atk < Roshan_atk || pTroop.getAverageLevel() >= 8 || pTroop.getAverageLevel() <= 3)) continue;  // Tank只打肉山，但也有等级限制
                if (pTroop.type == Tank) continue;
                if (pTroop.type != Tank && string(unit.name) == string("Roshan")) continue;
                if (pTroop.hasRoute() && dis(unit.pos, pTroop.route.front()) <= 15)
                    return true;
            }
        }
    }
    return false;
}

void PTroop::updateRoute()
{
    const PPlayerInfo & info = *INFO;
    if (hasRoute() && route.size()) {
        const PPlayerInfo & info = *INFO;
        for (int i = 0; i < troop.size(); i++) {
            if (route.size() == 0) break;  // 循环过程中可能使其为空
            const PUnit & hero = troop[i];
            const Pos & tarPos = route.front() + getPos(i);
            if (tarPos == hero.pos && !hasAliveWildNearBy(*this)) {
                queue<Pos> tempQueue = route; tempQueue.pop();
                if (troop.size() == 1 && tempQueue.front() == route.front()) {} // 如果要重复刷野，则用野怪复活来激发pop
                else if (type == Tank && (route.front() == gatherPos1 || route.front() == gatherPos2) && !isEnoughToPush()) {}  // 先在gatherPos聚集，否则不要贸然进攻
                else {
                    Pos front = route.front();
                    if (type != Jungle) route.push(front);
                    route.pop();  // 要重复循环
                    if (type == Jungle && route.size() == 0) {
                        type = Defend; break;
                    }
                }
            }
            // 周边有野怪死了就立即去下一个点
            info.findUnitInArea(hero.pos, hero.view, nearBy);
            bool wildIsDead = false;
            for (int j = 0; j < nearBy.size(); j++) {
                const PUnit & unit = *nearBy[j];
                if (unit.camp == 2 && dis2(unit.pos, hero.pos) <= Archer_range &&
                    unit.findBuff("Reviving") && unitsRecord[unit.id].findBuff("Reviving") == NULL) {  // 野怪才刚刚死亡
                    Pos front = route.front();
                    if (type != Jungle) route.push(front);
                    route.pop();  // 要重复循环
                    if (type == Jungle && route.size() == 0) type = Defend;
                    wildIsDead = true;
                    break;
                }
            }
            if (wildIsDead) break;
        }
    }
    if (type == Defend) {
        queue<Pos> right_queue;
        bool hasTowerInDanger = false;
        Pos defendPos = DP;
        for (int i = 0; i < info.units.size(); i++) {
            if (isTower(info.units[i]) && info.units[i].camp == info.camp) {
                const PUnit & tower = info.units[i];
                if (info.units[i].hp < info.units[i].max_hp || dis(getTroopCenter(), tower.pos) <= NEAR_TOWER_DIS) {
                    if (tower.pos == selfTowerPos_hi) {
                        right_queue = defend_queue_high;
                        defendPos = defendPos1;
                    }
                    if (tower.pos == selfTowerPos_lo) {
                        right_queue = defend_queue_low;
                        defendPos = defendPos2;
                    }
                    break;
                }
            }
        }
        if (defendPos == DP) {
            if (info.findUnitByPos(selfTowerPos_hi)) {
                right_queue = defend_queue_high;
                defendPos = defendPos1;
            }
            if (info.findUnitByPos(selfTowerPos_lo)) {
                right_queue = defend_queue_low;
                defendPos = defendPos2;
            }
        }
        if (getAverageLevel() >= 9) {
            while (right_queue.size()) right_queue.pop(); // 清空
            right_queue.push(defendPos);
        }
        if (!isSameRoute(route, right_queue)) route = right_queue;
    }
}

bool PTroop::hasLeastTogether(int num)
{
    if (isTogether()) return true;
    if (num == 1) return true;
    if (num == 2) {
        if (troop.size() <= 1) return false;
        for (int i = 0; i < troop.size(); i++) {
            for (int j = 0; j < troop.size(); j++) {
                if (j != i) {
                    vector<PUnit> m_troop;
                    m_troop.push_back(troop[i]);
                    m_troop.push_back(troop[j]);
                    PTroop m_pTroop(Nil, m_troop);
                    if (m_pTroop.isTogether()) return true;
                }
            }
        }
    }
    if (num == 3) {
        if (troop.size() <= 2) return false;
        for (int i = 0; i < troop.size(); i++) {
            for (int j = 0; j < troop.size(); j++) {
                if (j == i) continue;
                for (int k = 0; k < troop.size(); k++) {
                    if (k != i && k != j) {
                        vector<PUnit> m_troop;
                        m_troop.push_back(troop[i]);
                        m_troop.push_back(troop[j]);
                        m_troop.push_back(troop[k]);
                        PTroop m_pTroop(Nil, m_troop);
                        if (m_pTroop.isTogether()) return true;
                    }
                }
            }
        }
    }
    return false;
}

bool PTroop::isTogether()
{
    Pos centerPos = getTroopCenter();
    for (int i = 0; i < troop.size(); i++) {
        Pos goodPos = centerPos + getPos(i);
        Pos diff = troop[i].pos - goodPos;
        if (abs(diff.x) > 4 || abs(diff.y) > 4)
            return false;
    }
    return true;
}

bool PTroop::isEnoughToPush()
{
    bool hp_flag = false;
    // 0级 -> 0.8, 1级 -> 0.6, 2级 ->0.4, 3级 ->0.35
    if (getAverageLevel() <= 2)
        hp_flag = getAverageHp() >= 0.8 - getAverageLevel() * 0.2;
    else
        hp_flag = getAverageHp() >= 0.5 - getAverageLevel() * 0.05;
    if (!hp_flag) return false;
    else {
        if (!ruinFirstEnemyTower && lostFirstSelfTower) return hasLeastTogether(3);
        if (!ruinFirstEnemyTower && !lostFirstSelfTower) return hasLeastTogether(3);
        if (ruinFirstEnemyTower && !lostFirstSelfTower) return hasLeastTogether(3);
        if (ruinFirstEnemyTower && lostFirstSelfTower) return hasLeastTogether(2);
        return false;
    }
}

double fightPower(const vector<PUnit> & troop)
{
    cout << "CALC FIGHT POWER : ";
    double fight_power = 0.0;
    for (int i = 0; i < troop.size(); i++) {
        const PUnit & hero = troop[i];
        cout << hero.id << " ";
        if (isTower(hero)) {
            fight_power += 40 * ((double)hero.hp / hero.max_hp + 1.0) / 2;
        }
        else if (isHero(hero)) {
            fight_power += double(hero.hp) / hero.max_hp * 10; // 血量加权  // 30 ,20
            fight_power += hero.level * 3;  // 等级加权  // 81, 33
            fight_power += double(hero.mp) / Fighter_mp * 4;  // 魔法加权 // 10, 8
            fight_power += sqrt(hero.range) * 2;  // 种类加权 //
        }
    }
    cout << "fight power = " << fight_power << endl;
    return fight_power;
}


double speed_when_hided(const PUnit & hero) // 开过根号的
{
    if (!canUseSkill(hero, 13)) return sqrt(hero.speed);
    else {
        double newSpeed = hero.speed * Hided_speed_delta_rate[hero.findSkill(13)->level];
        return pow(newSpeed, 0.5);
    }
}

void findEnemyGroups(const PTroop & pTroop, vector<PUnit> & enemyGroups)
{
    const PPlayerInfo & info = *INFO;
    const vector<PUnit> & troop = pTroop.troop;  // 在团队中心的才计入队伍
    enemyGroups.clear(); // 及时清空
    // 塔永远放在第一个
    for (int k = 0; k < troop.size(); k++) {
        const PUnit & hero = troop[k];
        info.findUnitInArea(hero.pos, hero.view, nearBy);
        bool hasTowerNearby = false;
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            if (unit.camp == 1 - hero.camp && isTower(unit) && pTroop.type == Push) { // 距离控制
                if (isSameRoute(pTroop.route, tank_queue_high) && unit.pos == enemyTowerPos_lo) continue;
                enemyGroups.push_back(unit);
                hasTowerNearby = true;
                break;
            }
        }
        if (hasTowerNearby) break;
    }
    // 其次是所有敌方英雄
    for (int k = 0; k < troop.size(); k++) {
        const PUnit & hero = troop[k];
        if (isAssassin(hero)) continue;  // 刺客不主动去打敌人，只和己方英雄配合
        info.findUnitInArea(hero.pos, hero.view, nearBy);
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            // 检查重复
            bool isRepeat = false;
            for (int j = 0; j < enemyGroups.size(); j++)
                if (enemyGroups[j].id == unit.id)
                    isRepeat = true;
            if (isRepeat) continue;
            if (unit.camp == 1 - hero.camp && isHero(unit)) {
                if (pTroop.hasRoute() && (dis2(unit.pos, enemyTowerPos_hi) <= Tower_range || dis2(unit.pos, enemyTowerPos_lo) <= Tower_range)) continue;  // 对方躲进塔射程之内则无视
                if (dis(unit.pos, Pos(150,150)-springPos) <= TOO_FAR_TO_ATTACK_DIS) continue; // 离对方泉水太近就无视
                if (pTroop.type == Push && info.round >= FINAL_RUSH_ROUND) continue;
                else
                    enemyGroups.push_back(unit);
            }
        }
    }
    if (isTowerInDanger && pTroop.type == Defend) {
        for (int k = 0; k < info.units.size(); k++) {
            const PUnit & tower = info.units[k];
            if (isTower(tower) && tower.camp == info.camp) {
                info.findUnitInArea(tower.pos, tower.view, nearBy);
                for (int i = 0; i < nearBy.size(); i++) {
                    const PUnit & unit = *nearBy[i];
                    // 检查重复
                    bool isRepeat = false;
                    for (int j = 0; j < enemyGroups.size(); j++)
                        if (enemyGroups[j].id == unit.id)
                            isRepeat = true;
                    if (isRepeat) continue;
                    if (unit.camp == 1 - tower.camp && isHero(unit))
                        enemyGroups.push_back(unit);
                }
            }
        }
    }
    // 最后是野怪
    if (pTroop.type != Push) {
        // 要推塔就不打怪了
        for (int k = 0; k < troop.size(); k++) {
            const PUnit & hero = troop[k];
            info.findUnitInArea(hero.pos, hero.view, nearBy);
            for (int i = 0; i < nearBy.size(); i++) {
                const PUnit & unit = *nearBy[i];
                // 检查重复
                bool isRepeat = false;
                for (int j = 0; j < enemyGroups.size(); j++)
                    if (enemyGroups[j].id == unit.id)
                        isRepeat = true;
                if (isRepeat) continue;
                if (unit.camp == 2 && unit.findBuff("Reviving") == NULL && isFlat(hero.pos, unit.pos)) {
                    cout << "FIND UNIT, pos = "; posToString(unit.pos); cout << endl;
                    if (pTroop.hasRoute() && dis(unit.pos, pTroop.route.front()) > 15) continue;
//                    if (pTroop.type == Tank && (unit.atk < Roshan_atk || pTroop.getAverageLevel() >= 8 || pTroop.getAverageLevel() <= 3)) continue;  // Tank只打肉山，但也有等级限制
                    if (pTroop.type == Tank) continue;
                    if (pTroop.type != Tank && string(unit.name) == string("Roshan")) continue;
                    if (unit.hp >= 600 && (pTroop.getAverageLevel() + 2) * pTroop.troop.size() < 8) continue;
                    enemyGroups.push_back(unit);
                }
            }
        }
    }
    // test
    cout << "FIND ENEMY GROUP: ";
    for (int i = 0; i < enemyGroups.size(); i++)
        cout << enemyGroups[i].id << " ";
    cout << endl;
}

void moveTo(const PUnit & hero, const Pos & tarPos, double steps_num = 0) // 可以杜绝野怪卡位
{
    cout << "move from "; posToString(hero.pos); cout << "to "; posToString(tarPos); cout << endl;
    const PMap & map = *MAP; const PPlayerInfo & info = *INFO; PCommand & cmd = *CMD;
    Operation op; op.id = hero.id; op.type = "Move";
    vector<const PUnit*> barriers;
    bool hasBarrierAround = false;
    if (unitsRecord[hero.id].pos == hero.pos) {
        info.findUnitInArea(hero.pos, hero.view, nearBy);
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            if (unitsRecord[unit.id].pos == unit.pos && unit.id != hero.id && dis2(hero.pos, unit.pos) <= 2) { // 卡路者位置没有改变
                hasBarrierAround = true;
                barriers.push_back(&unit);
            }
        }
    }
    if (hasBarrierAround == true) {
        vector<Pos> m_blocks = blocks;
        for (int i = 0; i < barriers.size(); i++)
            m_blocks.push_back(barriers[i]->pos);
        findShortestPath(hero.pos, tarPos, m_blocks, op.targets);
    }
    else
        findShortestPath(hero.pos, tarPos, blocks, op.targets);
    // 对刺客进行特殊操作
    if (isAssassin(hero)) {
        cout << "assassin move" << endl;
        // 计算总路程
        int steps_sum = dis(hero.pos, op.targets[0]);
        for (int i = 0; i < op.targets.size() - 1; i++)
            steps_sum += dis(op.targets[i], op.targets[i+1]);
        if (op.targets[0] == DP && canUseSkill(hero,17)) { // 前面有悬崖
            if (dis2(hero.pos, tarPos) <= Blink_range) { // 如果能直接飞到，就飞
                Operation op; op.id = hero.id; op.type = "Blink";
                op.targets.clear(); op.targets.push_back(tarPos);
                setCommand(op); return;
            }
            else {  // 没法飞就先走到边缘
                moveTo(hero, Pos((hero.pos.x + tarPos.x)/2, (hero.pos.y + tarPos.y)/2));
                return;
            }
        }
        if (op.targets[0] != DP && canUseSkill(hero,17) && hero.findSkill(17)->level >= 2) {
            cout << "USE BLINK!" << endl;
            Pos blink_pos = DP;
            if (dis2(hero.pos, tarPos) <= Blink_range) {
                if (info.findUnitByPos(tarPos) && dis2(tarPos + Pos(0,1), hero.pos) <= Blink_range)
                    blink_pos = tarPos + Pos(0,1);
                else
                    blink_pos = tarPos;
            }
            else {
                int i;
                for (i = 0; i < op.targets.size(); i++) {
                    if (dis2(hero.pos, op.targets[i]) > Blink_range)
                        break;
                    if (steps_num != 0 && dis(hero.pos, op.targets[i]) > steps_num)
                        break;
                }
                blink_pos = op.targets[i-1];
            }
            Operation op; op.id = hero.id; op.type = "Blink";
            op.targets.clear(); op.targets.push_back(blink_pos);
            setCommand(op); return;
        }
    }
//    if (op.targets[0] == DP) {
//        double s = sqrt(hero.speed);
//        int max_dis = 0;
//        Pos bestPos;
//        for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {
//            for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
//                if (abs(dis(Pos(x,y), hero.pos) + dis(Pos(x,y), tarPos) - dis(hero.pos, tarPos)) < 2 && isFlat(hero.pos, Pos(x,y))) {
//                    if (dis(Pos(x,y), hero.pos) > max_dis) {
//                        max_dis = dis(Pos(x,y), hero.pos);
//                        bestPos = Pos(x,y);
//                    }
//                }
//            }
//        }
//        if (max_dis > 0) findShortestPath(hero.pos, bestPos, blocks, op.targets);
//    }
    // 若对步数有特殊要求
    if (steps_num != 0) {
        vector <Pos> m_targets; m_targets.push_back(op.targets[0]);
        double sum = dis(hero.pos, op.targets[0]);
        for (int i = 1; i < op.targets.size(); i++) {
            sum += dis(op.targets[i], op.targets[i-1]);
            if (sum <= steps_num) {
                m_targets.push_back(op.targets[i]);
            }
            else break;
        }
        op.targets = m_targets;
    }
    setCommand(op);
}

void moveTroopTo(PTroop & pTroop, const Pos & tarPos)
{
    cout << "moveTroopTo"; posToString(tarPos); cout << endl;
    int min_speed = 100;
    for (int i = 0; i < pTroop.troop.size(); i++)
        if (!isAssassin(pTroop.troop[i]) && pTroop.troop[i].speed < min_speed)  // 刺客速度不计入，因为有blink
            min_speed = pTroop.troop[i].speed;
    if (min_speed == 100) min_speed = pTroop.troop[0].speed;
    for (int i = 0; i < pTroop.troop.size(); i++) {
        const PUnit & hero = pTroop.troop[i];
        if (hero.canUseSkill(13) && pTroop.type == Tank) {  // 能隐身就隐身
            Operation op; op.id = hero.id; op.typeId = 13; setCommand(op);
        }
        else if (isTowerInDanger && pTroop.type == Defend)
            moveTo(pTroop.troop[i], tarPos + pTroop.getPos(i));  // 防御要全速
        else
            moveTo(pTroop.troop[i], tarPos + pTroop.getPos(i), sqrt(min_speed));
    }
}

bool isPosInPiercingArrowRange(const Pos & p, const Pos & start, const Pos & end)
{
    if (start == end) return false;
    double a = dis(p, start), b = dis(p, end), c = dis(start, end);
    if (a * a > b * b + c * c || b * b > a * a + c * c)  // 太远的点不要
        return false;
    double l = (a + b + c)/2;     //周长的一半
    double s = sqrt(l * (l-a) * (l-b) * (l-c));  //海伦公式求面积
    double dis = 2 * s / c;
    return dis <= PiercingArrow_dis;
}

bool canChargeIt(const PUnit & hero, const PUnit & enemy)
{
    const PMap & map = *MAP;
    // 检查我方单位四周
    Pos list1[] = { Pos(hero.pos.x+1,hero.pos.y),Pos(hero.pos.x-1,hero.pos.y),
        Pos(hero.pos.x,hero.pos.y+1),Pos(hero.pos.x,hero.pos.y-1)};
    int h1 = map.height[hero.pos.x][hero.pos.y];
    for (int i = 0; i < 4; i++) {
        const Pos & pos = list1[i];
        if (map.height[pos.x][pos.y] >= 4 && map.height[pos.x][pos.y] >= h1 + 2)
            return false;
    }
    // 检查敌方单位四周
    Pos list2[] = { Pos(enemy.pos.x+1,enemy.pos.y),Pos(enemy.pos.x-1,enemy.pos.y),
        Pos(enemy.pos.x,enemy.pos.y+1),Pos(enemy.pos.x,enemy.pos.y-1)};
    int h2 = map.height[enemy.pos.x][enemy.pos.y];
    for (int i = 0; i < 4; i++) {
        const Pos & pos = list2[i];
        if (map.height[pos.x][pos.y] >= 4 && map.height[pos.x][pos.y] >= h2 + 2)
            return false;
    }
    // 检查是否在blocks里
    if (isInBlocks(enemy.pos)) return false;
    //检查中心连线
    if (map.height[(hero.pos.x + enemy.pos.x) / 2][(hero.pos.y + enemy.pos.y) / 2] >= 4 &&
        map.height[(hero.pos.x + enemy.pos.x) / 2][(hero.pos.y + enemy.pos.y) / 2] >= map.height[hero.pos.x][hero.pos.y] + 2)
        return false;
    else
        return true;
}


void troopFight(PTroop & pTroop, const vector<PUnit> & enemyGroups)
{
    cout << "########## TROOP FIGHT!!! " << endl;
    if (enemyGroups.size() == 0) return;
    const vector<PUnit> & troop = pTroop.troop; // 在团队中心的才计入队伍
    Pos troopCenter = pTroop.getTroopCenter();
    
    const PCommand & cmd = *CMD; const PPlayerInfo & info = *INFO;
    vector<PArea> areaList;
    vector<PFlight> flightList;
    for (int i = 0; i < info.areas.size(); i++)
        if (info.areas[i].camp != info.camp)
            areaList.push_back(info.areas[i]);
    for (int i = 0; i < info.flights.size(); i++)
        if (info.flights[i].camp != info.camp && info.flights[i].typeId == 1)
            flightList.push_back(info.flights[i]);
    auto updateEnemyHeros = [&](vector<PUnit> & enemyHeros) -> vector<PUnit> & {
        for(vector<PUnit>::iterator it = enemyHeros.begin(); it != enemyHeros.end();)
        {
            if((*it).hp <= 0)
                it = enemyHeros.erase(it);    //删除元素，返回值指向已删除元素的下一个位置
            else
                ++it;    //指向下一个位置
        }
        return enemyHeros;
    };
    // 删除塔和野怪部分
    vector<PUnit> enemyHeros;
    for (int i = 0; i < enemyGroups.size(); i++) {
        PUnit enemy = enemyGroups[i];
        bool isInSight = false;
        for (int j = 0; j < troop.size(); j++)
            if (dis2(enemyGroups[i].pos, troop[j].pos) <= troop[j].view)
                isInSight = true;
        for (int j = 0; j < info.units.size(); j++)
            if (pTroop.type == Defend && isTower(info.units[i]) && info.units[i].camp == info.camp &&
                dis2(enemyGroups[i].pos, info.units[i].pos) <= Tower_view)
                isInSight = true;
        if (isInSight && isHero(enemy)) {
            enemy.hp += enemy["Hp"]->val[2];
            if (enemy.findBuff("Rainy") && !enemy.findBuff("Dizzy"))
                enemy.hp -= Rainy_damage[enemy.findBuff("Rainy")->level];
            if (enemy.findBuff("Rainy") && enemy.findBuff("Dizzy"))
                enemy.hp -= Rainy_damage[enemy.findBuff("Rainy")->level] * (enemy.findBuff("Dizzy")->timeLeft + 1);  // timeLeft最低为0
            if (enemy.hp > 0)
                enemyHeros.push_back(enemyGroups[i]);  // 添加至可更改单位中
        }
    }
    bool isStrongerThanEnemy = fightPower(troop) >= fightPower(enemyHeros) / 2;  // 只要有敌方一半强，就拼了
    // 计算仇恨值,用exp表示 ##
    for (int i = 0; i < enemyHeros.size(); i++) {
        PUnit & enemy = enemyHeros[i];
        enemy.exp = 1000; // 初始化为1000
        // 生命值加权
        enemy.exp -= enemy.hp;  // 血越少，仇恨值越高
        // 等级加权
        enemy.exp += enemy.level * 10;
        // 技能加权
        if (enemy.canUseSkill(9))  enemy.exp += 9 * (enemy.findSkill(9)->level + 1);  // 可以放箭雨
        if (enemy.canUseSkill(7))  enemy.exp += 7 * (enemy.findSkill(7)->level + 1);  // 可以放火箭
        if (enemy.canUseSkill(15)) enemy.exp += 5 * (enemy.findSkill(15)->level + 1); // 可以放飞刀
        if (enemy.canUseSkill(3))  enemy.exp += 5 * (enemy.findSkill(3)->level + 1);  // 可以放刀刃
        if (enemy.canUseSkill(1))  enemy.exp += 2 * (enemy.findSkill(1)->level + 1);  // 可以放冲锋
        // 状态加权
        if (enemy.findBuff("Striking")) enemy.exp += 4 * (enemy.findBuff("Striking")->level + 1);  // 正处于全力重击状态
        if (enemy.findBuff("Dizzy")) enemy.exp += 4;  // 正处于眩晕状态
        // 距离加权
        bool canSeeIt = false;
        double sum_dis = 0;
        for (int j = 0; j < troop.size(); j++) {
            sum_dis += dis(troop[j].pos, enemy.pos);
            if (dis2(troop[j].pos, enemy.pos) <= troop[j].range) {
                enemy.exp += 20;
            }
            if (dis2(troop[j].pos, enemy.pos) <= troop[j].view)
                canSeeIt = true;
        }
        if (!canSeeIt) enemy.exp -= 10;  // 看不到的就降低权重
        enemy.exp -= sum_dis;  // 越近越好
        // 英雄加权
        if (isArcher(enemy)) enemy.exp += (pTroop.type == Defend && isTowerInDanger) ? 100 : 80;
        if (isAssassin(enemy)) enemy.exp += (pTroop.type == Defend && isTowerInDanger) ? 50 : 30;;
        if (isFighter(enemy)) enemy.exp += (pTroop.type == Defend && isTowerInDanger) ? 0 : 5;
    }
    // 通过仇恨值从大到小进行排序
    for (int i = 0; i < enemyHeros.size(); i++) {
        for (int j = 0; j < enemyHeros.size() - 1; j++) {
            PUnit *cur = &enemyHeros[j];
            PUnit *next = &enemyHeros[j+1];
            if (cur->exp < next->exp) {
                PUnit temp = *cur;
                *cur = *next;
                *next = temp;
            }
        }
    }
    // test
    cout << "CURRENT ENEMYHEROS ORDER: ";
    for (int i = 0; i < enemyHeros.size(); i++)
        cout << "id = " << enemyHeros[i].id << ", weight = " << enemyHeros[i].exp << "; ";
    cout << endl;
    
    if (isTower(enemyGroups[0])) { // 针对推塔战场
        cout << "### TEST POINT 0-0 PUSH TOWER! ### " << endl;
        const PUnit & tower = enemyGroups[0];
        if (enemyHeros.size()) { // 如果塔边有敌军防守
            vector<PUnit> fighterTroop;
            for (int i = 0; i < troop.size(); i++) {
                const PUnit & hero = troop[i];
                if (isFighter(hero) || isArcher(hero)) {  // 战士弓手专门击杀防御者
                    fighterTroop.push_back(hero);
                }
                if (isAssassin(hero)) {
                    if (canUseSkill(hero,15) && !hasMission(hero)) {  // 可以使用飞刀
                        for (int j = 0; j < enemyHeros.size(); j++) {
                            const PUnit & enemy = enemyHeros[i];
                            if (enemy.hp >= FlightBlade_damage[hero.findSkill(15)->level] / 2 &&
                                dis2(enemy.pos, hero.pos) <= FlyingBlade_range) {
                                Operation op; op.id = hero.id; op.typeId = 15;
                                op.targets.push_back(enemy.pos); setCommand(op); break;
                            }
                        }
                    }
                }
            }
            if (fighterTroop.size()) {
                PTroop fighterPTroop = PTroop(Tank, fighterTroop);
                troopFight(fighterPTroop, enemyHeros); // 战士团战，type为Tank
            }
        }
        // 专心攻塔
        for (int i = 0; i < troop.size(); i++) {
            const PUnit & hero = troop[i];
            if (!hasMission(hero)) {
                int skill_list[] = { 0, 11, 13 };
                for (int si = 2; si >= 0; si--) {  // 先从技能开始
                    int skillId = skill_list[si];
                    if (canUseSkill(hero,skillId)) {
                        Operation op; op.id = hero.id; op.typeId = skillId;
                        vector<PUnit> unitList;
                        infectedBySkill(hero, skillId, unitList);
                        bool hasTarget = false;
                        for (int k = 0; k < unitList.size(); k++) {
                            if (unitList[k].pos == tower.pos) {
                                cout << "PUSH TOWER! USE SKILL " << skillId << endl;
                                if (hero.findSkill(skillId)->needTarget()) op.targets.push_back(tower.pos);
                                setCommand(op); hasTarget = true; break;
                            }
                        }
                        if (hasTarget) break;
                    }
                }
                if (!canUseSkill(hero,0)) { // 处于普攻冷却，则走位
                    // 暴力搜索最优攻击点位
                    double s = int(sqrt(hero.speed));  // 单位移速
                    int max_dis = -100;
                    Pos bestPos;
                    for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {  // 在矩形范围内循环求点
                        for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
                            if (dis2(Pos(x,y), tower.pos) <= hero.range) { // 要能打到塔
                                int sum_dis = 0;
                                // 计算出离所有英雄、箭雨中心、塔最远的点位
                                for (int j = 0; j < areaList.size(); j++)
                                    if (dis2(areaList[j].center, Pos(x,y)) <= RainyPlace_range)  // 有可能受到箭雨伤害的
                                        sum_dis += dis(areaList[j].center, Pos(x,y)) * 9;
                                for (int j = 0; j < enemyHeros.size(); j++)
                                    sum_dis += dis(enemyHeros[j].pos, Pos(x,y)) * 5;
                                for (int j = 0; j < troop.size(); j++)
                                    if (troop[j].id != hero.id && dis2(troop[j].pos, hero.pos) <= hero.view)
                                        sum_dis += dis(troop[j].pos, Pos(x,y)) * 1;
                                if (sum_dis > max_dis && isFlat(hero.pos, Pos(x,y))) {
                                    max_dis = sum_dis;
                                    bestPos = Pos(x,y);
                                }
                            }
                        }
                    }
                    cout << "MOVE4 BEST POS = "; posToString(bestPos); cout << endl;
                    if (max_dis > -100) {
                        moveTo(hero, bestPos);  // 移到最安全的点
                    }
                }
                if (dis2(hero.pos, tower.pos) > hero.view || isAssassin(hero)) {
                    moveTo(hero, tower.pos);
                }
                else if (dis2(hero.pos, tower.pos) > hero.range) {
                    // 暴力搜索最优攻击点位
                    double s = int(sqrt(hero.speed));  // 单位移速
                    int max_dis = -1000;
                    Pos bestPos = DP;
                    for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {  // 在矩形范围内循环求点
                        for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
                            if (isFlat(hero.pos, Pos(x,y))) {
                                int sum_dis = 0;
                                // 计算出离所有英雄、箭雨中心最远的点位
                                for (int j = 0; j < areaList.size(); j++)
                                    if (dis2(areaList[j].center, Pos(x,y)) <= RainyPlace_range)  // 有可能受到箭雨伤害的
                                        sum_dis += dis(areaList[j].center, Pos(x,y)) * 9;
                                for (int j = 0; j < enemyHeros.size(); j++)
                                    sum_dis += dis(enemyHeros[j].pos, Pos(x,y)) * 3;
                                for (int j = 0; j < troop.size(); j++)
                                    if (troop[j].id != hero.id && dis2(troop[j].pos, hero.pos) <= hero.view)
                                        sum_dis += dis(troop[j].pos, Pos(x,y)) * 2;
                                sum_dis -= dis(tower.pos, Pos(x,y)) * 9;   // 离塔越近越好
                                if (sum_dis > max_dis) {
                                    max_dis = sum_dis;
                                    bestPos = Pos(x,y);
                                }
                            }
                        }
                    }
                    cout << "MOVE5 BEST POS = "; posToString(bestPos); cout << endl;
                    if (bestPos != DP) {
                        moveTo(hero, bestPos);  // 移到最安全的点
                    }
                }
            }
        }
    }
    else if (isHero(enemyGroups[0])) { // 正常团战
        cout << "### TEST POINT 0-0 ### " << endl;
        if (!enemyHeros.size()) return;
        bool shouldRun = !isStrongerThanEnemy;
        if (pTroop.type == Tank) shouldRun = false;
        if (pTroop.type == Defend && isTowerInDanger) shouldRun = false;
        if (pTroop.troop.size() >= 2 && pTroop.isTogether()) shouldRun = false;
        cout << "### TEST POINT 0-1 ### " << endl;
        // 确认我方英雄组合
        vector<PUnit> ADC, TANK, ASS;
        for (int i = 0; i < troop.size(); i++) {
            if (isArcher(troop[i])) ADC.push_back(troop[i]);
            if (isFighter(troop[i])) TANK.push_back(troop[i]);
            if (isAssassin(troop[i])) ASS.push_back(troop[i]);
        }
        
        bool findEnemyLastRound = false;
        for (int i = 0; i < enemyHeros.size(); i++)
            if (unitsRecord[enemyHeros[i].id].id != DPUnit.id)
                findEnemyLastRound = true;
        
        cout << "### TEST POINT 1 ### " << endl;
        // 首先摆好阵型，确定队列中心点和朝向
        Pos centerPos = DP;
        auto findBestMovePos = [&](const PUnit & hero, const Pos & _center, const vector<PUnit> & enemyHeros) -> Pos {
            cout << "id = " << hero.id << " ";
            cout << "centerPos = "; posToString(_center); cout << endl;
            Pos dir = Pos(enemyHeros[0].pos.x - _center.x, enemyHeros[0].pos.y - _center.y);
            double s = sqrt(hero.speed);  // 单位移速
            if (dis2(hero.pos, enemyHeros[0].pos) > hero.view) return enemyHeros[0].pos;
            Pos bestPos = DP;
            int max_good_reason_num = -10000;
            for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {
                for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
                    Pos diff = _center - Pos(x,y);
                    if (dis2(hero.pos, Pos(x,y)) <= hero.speed && isFlat(hero.pos, Pos(x,y))) {
                        int good_reason = 0;
                        // 最好能打到敌人
                        if (findEnemyLastRound && dis2(Pos(x,y), enemyHeros[0].pos) <= hero.range)  // 首次见到敌人就不强求能打到他
                            good_reason += 25;
                        // 尽量别在雨中（最重要的因素）
                        vector<Pos> path;
                        findShortestPath(hero.pos, Pos(x,y), blocks, path);
                        int rainy_place_dis = 0;
                        bool isInRainyPlace = Pos(x,y) == hero.pos ? true : false;
                        for (int k = 0; k < areaList.size(); k++)  {
                            for (int t = 1; t < path.size(); t++)
                                if (dis(areaList[k].center, path[t]) <= RainyPlace_range)
                                    isInRainyPlace = true;
                            if (dis(areaList[k].center, Pos(x,y)) <= RainyPlace_range)
                                rainy_place_dis += dis(areaList[k].center, Pos(x,y));
                        }
                        for (int k = 0; k < flightList.size(); k++) {
                            for (int t = 1; t < path.size(); t++)
                                if (dis(flightList[k].target, path[t]) <= RainyPlace_range)
                                    isInRainyPlace = true;
                            if (dis(flightList[k].target, Pos(x,y)) <= RainyPlace_range)
                                rainy_place_dis += dis(flightList[k].target, Pos(x,y));
                        }
                        if (!hero.canUseSkill(7)) {   // 如果是要用火箭的，则鼓励往前（直接无视箭雨）
                            if (!isInRainyPlace) {
                                good_reason += 100;
                            }
                            else
                                good_reason += 10 * rainy_place_dis - 50;
                        }
                        // 尽量在120度弧度内
                        if (vectorAngleCos(ZP, diff, dir) >= 0.5)
                            good_reason += 5;
                        else if (vectorAngleCos(ZP, diff, dir) >= 0.5)
                            good_reason += 3;
                        // 尽量在FIREDIS之间
                        if (fabs(dis(_center, Pos(x,y)) - FIRE_DIS) <= 1)
                            good_reason += 5;
                        else if (fabs(dis(_center, Pos(x,y)) - FIRE_DIS) <= 2)
                            good_reason += 3;
                        // 被攻击到的数目越少越好
                        for (int j = 1; j < enemyHeros.size(); j++)
                            if (dis2(Pos(x,y), enemyHeros[j].pos) > enemyHeros[j].range)
                                good_reason++;
                        // 尽可能多看到敌人
                        for (int j = 0; j < enemyHeros.size(); j++)
                            if (dis2(Pos(x,y), enemyHeros[j].pos) <= hero.view)
                                good_reason++;
                        for (int j = 0; j < info.units.size(); j++) {
                            // 尽量别招惹野怪
                            if (info.units[j].camp == 2 && dis2(info.units[j].pos, Pos(x,y)) <= 9)
                                good_reason -= 2;
                            // 尽量远离敌方的塔
                            if (info.units[j].camp != info.camp && isTower(info.units[j])) 
                                if (dis2(info.units[j].pos, Pos(x,y)) <= info.units[j].range)
                                    good_reason -= 15;
                        }
                        
                        // 选择最优点
                        if (good_reason > max_good_reason_num) {
                            max_good_reason_num = good_reason;
                            bestPos = Pos(x,y);
                            cout << "   bestPos = "; posToString(bestPos);
                            cout << "good_reason = " << good_reason << endl;
                        }
                    }
                }
            }
            return bestPos;
        };
        if (!findEnemyLastRound) {  // 如果是首次碰到敌人，则先摆好阵型
            cout << "### TEST POINT 2-0 ### " << endl;
            for (int i = 0; i < info.units.size(); i++) {
                // 如果边上有塔，则躲到塔下
                if (isTower(info.units[i]) && info.units[i].camp == info.camp) {
                    const PUnit & tower = info.units[i];
                    if (dis(troopCenter, tower.pos) <= NEAR_TOWER_DIS) {
                        centerPos = tower.pos;
                    }
                }
            }
            if (centerPos == DP) {
                bool isEnemyNearby = false;
                for (int i = 0; i < troop.size(); i++) {
                    if (dis2(troop[i].pos, enemyHeros[0].pos) <= troop[i].view) {
                        centerPos = Pos((enemyHeros[0].pos.x + troopCenter.x) / 2, (enemyHeros[0].pos.y + troopCenter.y) / 2);
                        isEnemyNearby = true; break;
                    }
                }
                if (!isEnemyNearby)
                    centerPos = enemyHeros[0].pos;
            }
            
        }
        else {  // 在战斗中调整中心
            int max_good_pos_num = -1;
            double closest_dis = 1000;
            for (int _x = enemyHeros[0].pos.x - 2; _x <= enemyHeros[0].pos.x + 2; _x++) {
                for (int _y = enemyHeros[0].pos.y - 2; _y <= enemyHeros[0].pos.y + 2; _y++) {
                    Pos _center = Pos(_x, _y);
                    cout << "## now _center is: "; posToString(_center); cout << endl;
                    if (_center == enemyHeros[0].pos) continue;
                    int good_pos_sum = 0;
                    for (int i = 0; i < ADC.size(); i++) {
                        const PUnit & hero = ADC[i];
                        Pos bestPos = findBestMovePos(hero, _center, enemyHeros);
                        if (bestPos != DP) {
                            good_pos_sum++;
                        }
                    }
                    double sum_dis = 0;
                    // 如果实力足够，则接近敌方，如果实力不够，则远离敌方
                    if (shouldRun)
                        sum_dis -= 2 * dis(enemyHeros[0].pos, _center);
                    else
                        sum_dis += 2 * dis(enemyHeros[0].pos, _center);
                    for (int j = 1; j < enemyHeros.size(); j++) {
                        sum_dis -= dis(enemyHeros[j].pos, _center);
                    }
                    for (int j = 0; j < troop.size(); j++) {
                        sum_dis += dis(troop[j].pos, _center);
                    }
                    for (int j = 0; j < info.units.size(); j++) {
                        if (info.units[j].camp == info.camp && isTower(info.units[j])) {
                            const PUnit & tower = info.units[j];
                            if (dis(tower.pos, _center) <= NEAR_TOWER_DIS)
                                sum_dis += 3 * dis(tower.pos, _center);
                        }
                        if (info.units[j].camp != info.camp && isTower(info.units[j])) {
                            const PUnit & tower = info.units[j];
                            if (dis2(tower.pos, _center) <= tower.range)
                                sum_dis -= 3 * dis(tower.pos, _center);
                        }
                    }
                    if ((good_pos_sum > max_good_pos_num) || (good_pos_sum == max_good_pos_num && sum_dis < closest_dis)) {
                        max_good_pos_num = good_pos_sum;
                        closest_dis = sum_dis;
                        centerPos = _center;
                        cout << "_center pos = "; posToString(centerPos);
                        cout << ", good_pos_sum = " << good_pos_sum << ", sum_dis = " << sum_dis << endl;
                    }
                }
            }
        }
        cout << "center pos = "; posToString(centerPos);
        cout << "troop center = "; posToString(troopCenter); cout << endl;
        
        // 战士使用冲锋
        for (int i = 0; i < TANK.size(); i++) {
            const PUnit & hero = TANK[i];
            if (!hasMission(hero) && hero.canUseSkill(1) && dis2(hero.pos, enemyHeros[0].pos) <= Charge_range) {
                cout << "### TEST POINT 3-0 ### " << endl;
                Operation op; op.id = hero.id; op.typeId = 1; op.targets.push_back(enemyHeros[0].pos); setCommand(op);
                enemyHeros[0].hp -= Charge_damage[hero.findSkill(1)->level];
                if (!updateEnemyHeros(enemyHeros).size()) return;
            }
        }
        
        // 战士使用嘲讽
        for (int i = 0; i < TANK.size(); i++) {
            const PUnit & hero = TANK[i];
            if (!hasMission(hero) && hero.canUseSkill(5) && dis2(hero.pos, enemyHeros[0].pos) <= Yell_range) {
                vector<PUnit> unitList;
                infectedBySkill(hero, 5, unitList);
                if (isArcher(enemyHeros[0]) || unitList.size() >= 2) {  // 如果吼到ADC或者超过两人，都值得吼
                    cout << "### TEST POINT 3-1 ### " << endl;
                    Operation op; op.id = hero.id; op.typeId = 5; setCommand(op);
                }
            }
        }
        
        // 战士使用普通攻击
        for (int i = 0; i < TANK.size(); i++) {
            const PUnit & hero = TANK[i];
            if (!hasMission(hero) && hero.canUseSkill(0) && dis2(hero.pos, enemyHeros[0].pos) <= hero.range) {
                cout << "### TEST POINT 3-2 ### " << endl;
                Operation op; op.id = hero.id; op.typeId = 0; op.targets.push_back(enemyHeros[0].pos); setCommand(op);
                enemyHeros[0].hp -= hero.atk - enemyHeros[0].def;
                if (!updateEnemyHeros(enemyHeros).size()) return;
            }
        }
        
        // 战士移动到前方干扰敌人
        for (int i = 0; i < TANK.size(); i++) {
            const PUnit & hero = TANK[i];
            if (!hasMission(hero)) {
                if (dis2(enemyHeros[0].pos, hero.pos) > hero.range)  // 若打不到则直接走过去
                    moveTo(hero, enemyHeros[0].pos);
                else if (!findEnemyLastRound) {  // 如果是首次看到敌人，先不要冲太猛
                    moveTo(hero, troopCenter);
                }
                else {
                    double s = sqrt(hero.speed);  // 单位移速
                    int max_num = -100;
                    Pos bestPos = hero.pos;
                    bool canLeaveOutRainyPlace = false;
                    for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {
                        for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
                            if (dis2(hero.pos, Pos(x,y)) <= hero.speed && isFlat(hero.pos, Pos(x,y)) && dis2(enemyHeros[0].pos, Pos(x,y)) <= hero.range) {  // 保持能攻击到敌人
                                vector<Pos> path;
                                findShortestPath(hero.pos, Pos(x,y), blocks, path);
                                int sum = 0;
                                for (int j = 0; j < enemyHeros.size(); j++)
                                    if (dis2(enemyHeros[j].pos, hero.pos) <= enemyHeros[j].range)
                                        sum++;
                                bool isInRainyPlace = Pos(x,y) == hero.pos ? true : false;  // 最好一直动着
                                for (int k = 0; k < areaList.size(); k++)
                                    for (int t = 1; t < path.size(); t++)
                                        if (dis(areaList[k].center, path[t]) <= RainyPlace_range)
                                            isInRainyPlace = true;
                                if (canLeaveOutRainyPlace == !isInRainyPlace) {  // 保持在箭雨范围的状态不变，则选取最吸引火力的点
                                    if (sum > max_num) {
                                        max_num = sum;
                                        bestPos = Pos(x,y);
                                    }
                                }
                                else if (canLeaveOutRainyPlace == false && isInRainyPlace == false) {  // 尽量选取不在箭雨范围之内的点
                                    max_num = sum;
                                    bestPos = Pos(x,y);
                                    canLeaveOutRainyPlace = true;
                                }
                            }
                        }
                    }
                    cout << "### TEST POINT 3-3 ### " << endl;
                    moveTo(hero, bestPos);
                }
            }
        }
        
        // 刺客使用隐身
        for (int i = 0; i < ASS.size(); i++) {
            const PUnit & hero = ASS[i];
            if (!hasMission(hero) && hero.canUseSkill(13)) {
                cout << "### TEST POINT 4-0 ### " << endl;
                Operation op; op.id = hero.id; op.typeId = 13; setCommand(op);
            }
        }
        
        // 刺客使用飞刀
        for (int i = 0; i < ASS.size(); i++) {
            const PUnit & hero = ASS[i];
            if (!hasMission(hero) && hero.canUseSkill(15)) {
                for (int j = 0; j < enemyHeros.size(); j++) {
                    if (dis2(enemyHeros[j].pos, hero.pos) <= FlyingBlade_range && enemyHeros[j].hp >= FlightBlade_damage[hero.findSkill(15)->level] / 2) {
                        cout << "### TEST POINT 4-1 ### " << endl;
                        Operation op; op.id = hero.id; op.typeId = 15; op.targets.push_back(enemyHeros[j].pos); setCommand(op);
                        enemyHeros[0].hp -= FlightBlade_damage[hero.findSkill(15)->level];
                        if (!updateEnemyHeros(enemyHeros).size()) return;
                        break;
                    }
                }
            }
        }
        
        // 刺客使用普通攻击
        for (int i = 0; i < ASS.size(); i++) {
            const PUnit & hero = ASS[i];
            if (!hasMission(hero) && hero.canUseSkill(0) && dis2(hero.pos, enemyHeros[0].pos) <= hero.range) {
                cout << "### TEST POINT 4-2 ### " << endl;
                if (fightPower(troop) > fightPower(enemyHeros)) {  // 当有足够实力杀了敌方时才下手
                    Operation op; op.id = hero.id; op.typeId = 0; op.targets.push_back(enemyHeros[0].pos); setCommand(op);
                    enemyHeros[0].hp -= hero.atk - enemyHeros[0].def;
                    if (!updateEnemyHeros(enemyHeros).size()) return;
                }
            }
        }
        
        // 刺客移动到敌人后背
        for (int i = 0; i < ASS.size(); i++) {
            const PUnit & hero = ASS[i];
            if (!hasMission(hero)) {
                for (int j = 0; j < 4; j++) {
                    Pos tarPos = enemyHeros[0].pos + Pos(dir[j][0], dir[j][1]);
                    Pos direction = Pos(tarPos.x - centerPos.x, tarPos.y - centerPos.y);
                    if (dotProduct(0, direction, Pos(dir[j][0], dir[j][1])) >= 0) {
                        cout << "### TEST POINT 4-3 ### " << endl;
                        moveTo(hero, tarPos);
                        break;
                    }
                }
            }
        }
        
        
        // 弓手使用箭雨
        for (int i = 0; i < ADC.size(); i++) {
            const PUnit & hero = ADC[i];
            if (!hasMission(hero) && hero.canUseSkill(9) && info.round >= pTroop.useRainyRound + 2) {
                bool isInRainyPlace = false;
                for (int k = 0; k < areaList.size(); k++)
                    if (dis(areaList[k].center, hero.pos) <= RainyPlace_range)
                        isInRainyPlace = true;
                if (!isInRainyPlace) {
                    int r = sqrt(SignalArrow_range);  // 单位范围
                    int max_attack_other_num = -1;
                    int min_dis = 1000;
                    Pos bestPos;
                    for (int x = hero.pos.x - r; x <= hero.pos.x + r; x++) {
                        for (int y = hero.pos.y - r; y <= hero.pos.y + r; y++) {
                            if (dis2(hero.pos, Pos(x,y)) <= SignalArrow_range && dis(enemyHeros[0].pos, Pos(x,y)) <= RainyPlace_range) {  // 要能击中首要敌人
                                int sum = 0;
                                for (int j = 0; j < enemyHeros.size(); j++)
                                    if (j != 0 && dis(enemyHeros[j].pos, Pos(x,y)) <= RainyPlace_range && !enemyHeros[j].findBuff("Rainy"))
                                        sum++;
                                if (sum > max_attack_other_num ||
                                    (sum == max_attack_other_num && 5 * dis(enemyHeros[0].pos, Pos(x,y)) + dis(troopCenter, Pos(x,y)) <= min_dis)) {
                                    max_attack_other_num = sum;
                                    bestPos = Pos(x,y);
                                    min_dis = 5 * dis(enemyHeros[0].pos, Pos(x,y)) + dis(troopCenter, Pos(x,y));
                                }
                            }
                        }
                    }
                    if (max_attack_other_num >= 0) {  // 至少能打中敌方一个
                        if (max_attack_other_num >= 1 ||
                            (!enemyHeros[0].findBuff("Rainy") && enemyHeros[0].hp >= Rainy_damage[hero.findSkill(9)->level] * 2)) {
                            cout << "### TEST POINT 5-0 ### " << endl;
                            Operation op; op.id = hero.id; op.typeId = 9; op.targets.push_back(bestPos);
                            setCommand(op);  pTroop.useRainyRound = info.round;
                        }
                    }
                }
            }
        }
        
        // 找最合适的火箭，敌方ADC全吃伤害或者击中至少两人
        for (int i = 0; i < ADC.size(); i++) {
            const PUnit & hero = ADC[i];
            if (!hasMission(hero) && hero.canUseSkill(7) && dis2(hero.pos, enemyHeros[0].pos) <= PiercingArrow_range) {
                int max_attack_other_num = 0;
                Pos bestPos = enemyHeros[0].pos;
                for (int x = hero.pos.x - 12; x <= hero.pos.x + 12; x++) {
                    for (int y = hero.pos.y - 12; y <= hero.pos.y + 12; y++) {
                        if (dis2(hero.pos, Pos(x,y)) <= PiercingArrow_range &&
                            isPosInPiercingArrowRange(enemyHeros[0].pos, hero.pos, Pos(x,y))) {  // 务必要能打到关键英雄
                            int sum = 0;
                            for (int j = 0; j < enemyHeros.size(); j++)
                                if (j != 0 && isPosInPiercingArrowRange(enemyHeros[j].pos, hero.pos, Pos(x,y)))
                                    sum++;
                            if (sum > max_attack_other_num) {
                                max_attack_other_num = sum;
                                bestPos = Pos(x,y);
                            }
                        }
                    }
                }
                if (max_attack_other_num > 0 || enemyHeros[0].hp >= PiercingArrow_damage[hero.findSkill(7)->level]) {  // 如果可以击中两个人或者一人伤害全吃
                    cout << "### TEST POINT 5-2 max_attack_other_num = " << max_attack_other_num << " ### " << endl;
                    Operation op; op.id = hero.id; op.typeId = 7;
                    op.targets.push_back(bestPos); setCommand(op);
                    for (int j = 0; j < enemyHeros.size(); j++)
                        if (PiercingArrow_inRange(hero.pos, bestPos, DPos(enemyHeros[j].pos)))
                            enemyHeros[j].hp -= PiercingArrow_damage[hero.findSkill(7)->level];
                    if (!updateEnemyHeros(enemyHeros).size()) return;
                }
            }
        }
        
        // 弓手使用普通攻击
        for (int i = 0; i < ADC.size(); i++) {
            const PUnit & hero = ADC[i];
            if (!hasMission(hero) && hero.canUseSkill(0) && dis2(hero.pos, enemyHeros[0].pos) <= hero.range) {
                bool isInRainyPlace = false;
                for (int k = 0; k < areaList.size(); k++)
                    if (dis(areaList[k].center, hero.pos) <= RainyPlace_range)
                        isInRainyPlace = true;
                if (!isInRainyPlace) {
                    cout << "### TEST POINT 5-3 ### " << endl;
                    Operation op; op.id = hero.id; op.typeId = 0; op.targets.push_back(enemyHeros[0].pos); setCommand(op);
                    enemyHeros[0].hp -= hero.atk - enemyHeros[0].def;
                    if (!updateEnemyHeros(enemyHeros).size()) return;
                }
            }
        }
        
        // 弓手圆环式移动
        for (int i = 0; i < ADC.size(); i++) {
            const PUnit & hero = ADC[i];
            if (!hasMission(hero)) {
                Pos bestPos = findBestMovePos(hero, centerPos, enemyHeros);
                if (bestPos != DP) {
                    moveTo(hero, bestPos);
                }
            }
        }
        
        // 弓手移动至我军中心
        for (int i = 0; i < ADC.size(); i++) {
            const PUnit & hero = ADC[i];
            if (!hasMission(hero)) {
                if (dis2(enemyHeros[0].pos, hero.pos) > hero.range)
                    moveTo(hero, enemyHeros[0].pos);
                else
                    moveTo(hero, troopCenter);
            }
        }
    }
    else { // 打野
        const PUnit & wild = enemyGroups[0];
        for (int i = 0; i < troop.size(); i++) {
            const PUnit & hero = troop[i];
            if (isArcher(hero) && wild.range < Bow_range &&
                dis(hero.pos, wild.pos) <= sqrt(wild.range) + sqrt(wild.speed) + 1 && hero.findSkill(0)->cd > 0) {  // 弓手对近程野怪走位
                Pos bestPos = wild.pos;
                int min_dis = 1000;
                // 暴力搜索
                double s = int(sqrt(hero.speed));  // 单位移速
                for (int x = hero.pos.x - s; x <= hero.pos.x + s; x++) {  // 在矩形范围内循环求点
                    for (int y = hero.pos.y - s; y <= hero.pos.y + s; y++) {
                        if (isFlat(hero.pos, Pos(x,y))) {
                            vector<Pos> path;
                            findShortestPath(hero.pos, Pos(x,y), blocks, path);
                            bool isInRainyPlace = Pos(x,y) == hero.pos ? true : false;
                            for (int k = 0; k < areaList.size(); k++)
                                for (int t = 1; t < path.size(); t++)
                                    if (dis(areaList[k].center, path[t]) <= RainyPlace_range)
                                        isInRainyPlace = true;
                            if (!isInRainyPlace) {
                                int sum_dis = -dis(Pos(x,y), wild.pos);  // 离敌人越远越好
                                for (int j = 0; j < info.units.size(); j++) {
                                    if (info.units[j].camp == info.camp && isTower(info.units[j])) {
                                        const PUnit & tower = info.units[j];
                                        if (dis(tower.pos, Pos(x,y)) <= NEAR_TOWER_DIS)
                                            sum_dis += 5 * dis(tower.pos, Pos(x,y));
                                    }
                                }
                                if (sum_dis < min_dis) {
                                    min_dis = sum_dis;
                                    bestPos = Pos(x,y);
                                }
                            }
                        }
                    }
                }
                moveTo(hero, bestPos);
            }
            else {
                int skill_list[] = { 0, 1, 3, 5, 7, 9, 13, 15 };
                for (int si = 7; si >= 0; si--) {  // 先从技能开始
                    int skillId = skill_list[si];
                    if (wild.atk < Dragon_atk && si > 0) continue; // 只对大龙使用技能
//                    if (pTroop.type == Defend && si > 0) continue; // 防守的时候不用技能
//                    if (pTroop.getAverageLevel() >= 3 && wild.atk < Roshan_atk && si > 0) continue;
                    if (canUseSkill(hero,skillId)) {
                        if (skillId == 9 && info.round < pTroop.useRainyRound + 5) continue; // 避免重复
                        if (skillId == 9 && wild.hp < Rainy_damage[hero.findSkill(9)->level] * 2) continue; // 避免重复
                        if (skillId == 5 && wild.findBuff("Dizzy")) continue;
                        Operation op; op.id = hero.id; op.typeId = skillId;
                        vector<PUnit> unitList;
                        infectedBySkill(hero, skillId, unitList);
                        bool hasTarget = false;
                        for (int k = 0; k < unitList.size(); k++) {
                            if (unitList[k].pos == wild.pos) {
                                if (skillId != 3 && skillId != 5 && skillId != 13) op.targets.push_back(wild.pos);
                                if (skillId == 9) pTroop.useRainyRound = info.round;
                                setCommand(op); hasTarget = true; break;
                            }
                        }
                        if (hasTarget) break;
                    }
                }
                if (!hasMission(hero) && dis2(hero.pos, wild.pos) > hero.range) {
                    moveTo(hero, wild.pos);
                }
            }
        }
    }
}

const PUnit* towerInDanger()
{
    const PPlayerInfo & info = *INFO;
    vector<const PUnit*> towers;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && string(unit.name) == string("Tower")) {
            towers.push_back(&unit);
        }
    }
    for (int j = 0; j < towers.size(); j++) {
        const PUnit *tower = towers[j];
        info.findUnitInArea(tower->pos, tower->view, nearBy);
        int enemy_num = 0;
        for (int i = 0; i < nearBy.size(); i++) {
            const PUnit & unit = *nearBy[i];
            if (unit.camp == 1 - info.camp && isHero(unit) &&
                dis2(unit.pos, tower->pos) <= unit.view) // 还要在攻击距离之内的
                enemy_num++;
        }
        if (info.round < 70) {  // 70回合内有人经过都不算，要进攻才算
            if (enemy_num >= 1 && unitsRecord[tower->id].hp > tower->hp)
                return tower;
        }
        else {
            if (enemy_num >= 1 && unitsRecord[tower->id].hp > tower->hp) return tower;
            if (enemy_num >= 2) return tower; // 有两人接近就算有威胁
        }
    }
    return NULL;
}

void init_one()
{
    ruinFirstEnemyTower = false;
    lostFirstSelfTower = false;
    isTowerInDanger = false;
    isGoingToRush = false;
    reviving_enemy_num = 0;
    dangerTowerCount = 0;
    pushFailTimes = 0;
    
    const PPlayerInfo & info = *INFO;
    const PMap & map = *MAP;
    
    DPUnit = info.units[0];
    
    // tower pos
    selfTowerPos_lo = info.camp == 0 ? Player0_tower_pos[1] : Player1_tower_pos[1];
    selfTowerPos_hi = info.camp == 0 ? Player0_tower_pos[0] : Player1_tower_pos[0];
    enemyTowerPos_lo = info.camp == 0 ? Player1_tower_pos[1] : Player0_tower_pos[1];
    enemyTowerPos_hi = info.camp == 0 ? Player1_tower_pos[0] : Player0_tower_pos[0];
    springPos = info.camp == 0 ? SPRING_POINT : Pos(150,150) - SPRING_POINT;
    gatherPos1 = info.camp == 0 ? GATHER_POINT1 : Pos(150,150) - GATHER_POINT1;
    gatherPos2 = info.camp == 0 ? GATHER_POINT2 : Pos(150,150) - GATHER_POINT2;
    rushPos1 = info.camp == 0 ? RUSH_POINT1 : Pos(150,150) - RUSH_POINT1;
    rushPos2 = info.camp == 0 ? RUSH_POINT2 : Pos(150,150) - RUSH_POINT2;
    defendPos1 = info.camp == 0 ? DEFEND_POINT1 : Pos(150,150) - DEFEND_POINT1;
    defendPos2 = info.camp == 0 ? DEFEND_POINT2 : Pos(150,150) - DEFEND_POINT2;
    
    int camp_factor = info.camp == 0 ? 1 : -1;
    Pos camp_factor_pos = info.camp == 0 ? Pos(0,0) : Pos(150,150);
    // fighter_queue
    // once
    for (int i = 0; jQueue_assassin1[i] != DP; i++)
        jungle_queue_assassin.push(jQueue_assassin1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_near_tower1[i] != DP; i++)
        jungle_queue_near_tower.push(jQueue_near_tower1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_ready_defend1[i] != DP; i++)
        jungle_queue_ready_defend.push(jQueue_ready_defend1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_self_dragon1[i] != DP; i++)
        jungle_queue_self_dragon.push(jQueue_self_dragon1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_enemy_dragon1[i] != DP; i++)
        jungle_queue_enemy_dragon.push(jQueue_enemy_dragon1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_start_lo[i] != DP; i++)
        jungle_queue_start_low.push(jQueue_start_lo[i] * camp_factor + camp_factor_pos);
    for (int i = 0; jQueue_start_hi[i] != DP; i++)
        jungle_queue_start_high.push(jQueue_start_hi[i] * camp_factor + camp_factor_pos);
    
    // loop
    for (int k = 0; k < LOOP_TIMES; k++) {
        for (int i = 0; jQueue_assassin2[i] != DP; i++)
            jungle_queue_assassin.push(jQueue_assassin2[i] * camp_factor + camp_factor_pos);
        for (int i = 0; jQueue_near_tower2[i] != DP; i++)
            jungle_queue_near_tower.push(jQueue_near_tower2[i] * camp_factor + camp_factor_pos);
        for (int i = 0; jQueue_ready_defend2[i] != DP; i++)
            jungle_queue_ready_defend.push(jQueue_ready_defend2[i] * camp_factor + camp_factor_pos);
        for (int i = 0; jQueue_self_dragon2[i] != DP; i++)
            jungle_queue_self_dragon.push(jQueue_self_dragon2[i] * camp_factor + camp_factor_pos);
        for (int i = 0; jQueue_enemy_dragon2[i] != DP; i++)
            jungle_queue_enemy_dragon.push(jQueue_enemy_dragon2[i] * camp_factor + camp_factor_pos);
        for (int i = 0; jQueue_enemy_dragon2[i] != DP; i++)
            jungle_queue_enemy_dragon_loop.push(jQueue_enemy_dragon2[i] * camp_factor + camp_factor_pos);
    }
    
    // defend_queue
    for (int i = 0; dQueue_high[i] != DP; i++)
        defend_queue_high.push(dQueue_high[i] * camp_factor + camp_factor_pos);
    for (int i = 0; dQueue_low[i] != DP; i++)
        defend_queue_low.push(dQueue_low[i] * camp_factor + camp_factor_pos);
    for (int i = 0; dQueue_both[i] != DP; i++)
        defend_queue_both.push(dQueue_both[i] * camp_factor + camp_factor_pos);
    
    // tank_queue
    for (int i = 0; tQueue_high1[i] != DP; i++)
        tank_queue_high.push(tQueue_high1[i] * camp_factor + camp_factor_pos);
    for (int i = 0; tQueue_low1[i] != DP; i++)
        tank_queue_low.push(tQueue_low1[i] * camp_factor + camp_factor_pos);
    
    // blocks
    for (int i = -2; i <= 2; i++) {
        blocks.push_back(Roshan_pos[0] + Pos(-2,i));
        blocks.push_back(Roshan_pos[0] + Pos(2,i));
    }
    for (int j = -1; j <= 1; j++) {
        blocks.push_back(Roshan_pos[0] + Pos(j,2));
        blocks.push_back(Roshan_pos[0] + Pos(j,-2));
    }
    
    // unitsRecord
    for  (int i = 0; i < MAX_UNITS_NUM; i++)
        unitsRecord.push_back(DPUnit);
    
    // enemyRevivedRound
    for (int i = 0; i < 5; i++)
        enemyRevivedRound.push_back(0);
}
void update()
{
    const PPlayerInfo & info = *INFO;
    
    // init for each round
    memset(hasSetOperation, 0, 5 * sizeof(int));
    
    // update myHeros
    myHeros.clear();
    for (int i = 0; i < info.units.size(); i++) { // 选出已方英雄
        const PUnit& unit = info.units[i];
        if (unit.camp == info.camp && isHero(unit)) {
            myHeros.push_back(unit);
        }
    }
    if (myHerosRecord.size() == 0) {
        for (int i = 0; i < 5; i++)
            myHerosRecord.push_back(myHeros[i]);
    }
    
    // init troops
    if (myTroops.size() == 0) {  // 若尚未分配队伍
        vector<PUnit> troop1, troop2, troop3;
        troop1.push_back(myHeros[0]);  // Jungle 1
        troop2.push_back(myHeros[1]); troop2.push_back(myHeros[2]);  // Jungle 2
        troop2.push_back(myHeros[3]); troop2.push_back(myHeros[4]);  // Jungle 2
//        troop3.push_back(myHeros[3]); troop3.push_back(myHeros[4]);  // Jungle 3
        PTroop pTroop1 = PTroop(Jungle, troop1);
        PTroop pTroop2 = PTroop(Jungle, troop2);
//        PTroop pTroop3 = PTroop(Jungle, troop3);
        pTroop1.route = jungle_queue_assassin;
        pTroop2.route = jungle_queue_enemy_dragon;
//        pTroop2.route = jungle_queue_start_high;
//        pTroop3.route = jungle_queue_start_low;
        myTroops.push_back(pTroop1);
        myTroops.push_back(pTroop2);
//        myTroops.push_back(pTroop3);
    }
    // update troops members
    for (int i = 0; i < myTroops.size(); i++) {
        for (int j = 0; j < myTroops[i].troop.size(); j++) {
            PUnit & hero = myTroops[i].troop[j];
            hero = myHeros[rankInTroop(hero.id, myHeros)]; // 更新hero
        }
    }
    // update myHerosTroop
    myHeroTroop.troop = myHeros;
    
    // update isTowerInDanger
    const PUnit *dTower = towerInDanger();
    if (!isTowerInDanger && dTower) {
        isTowerInDanger = true;
        if (lostFirstSelfTower)
            dangerTowerCount++;
    }
    if (isTowerInDanger && dTower == NULL)
        isTowerInDanger = false;
    
    // update lostFirstSelfTower
    bool preFlag_lostFirstSelfTower = lostFirstSelfTower;
    int tower_num = 0;
    const PUnit *leftTower = NULL;
    for (int i = 0; i < info.units.size(); i++) {
        const PUnit & unit = info.units[i];
        if (unit.camp == info.camp && string(unit.name) == string("Tower")) {
            tower_num++;
            leftTower = &unit;
        }
    }
    lostFirstSelfTower = tower_num == 1 ? true : false;
    if (!preFlag_lostFirstSelfTower && lostFirstSelfTower) {
        if (myHeroTroop.getAverageLevel() < PUSH_MIN_LEVEL) {
            for (int i = 0; i < myTroops.size(); i++)
                if (myTroops[i].type == Jungle && myTroops[i].troop.size() >= 2)
                    myTroops[i].setType(Defend);
        }
        if (leftTower->pos == selfTowerPos_lo) {  // 不在高位塔聚集了
            cout << "CHANGE TANK_ROUTE " << endl;
            int camp_factor = info.camp == 0 ? 1 : -1;
            Pos camp_factor_pos = info.camp == 0 ? Pos(0,0) : Pos(150,150);
            while(tank_queue_high.size()) tank_queue_high.pop();
            while(tank_queue_low.size()) tank_queue_low.pop();
            for (int i = 0; tQueue_high2[i] != DP; i++)
                tank_queue_high.push(tQueue_high2[i] * camp_factor + camp_factor_pos);
            for (int i = 0; tQueue_low2[i] != DP; i++)
                tank_queue_low.push(tQueue_low2[i] * camp_factor + camp_factor_pos);
            for (int i = 0; i < myTroops.size(); i++) {
                if (myTroops[i].type == Tank || myTroops[i].type == Push) {
                    myTroops[i].route = tank_queue_low;  // 统一先推低位塔
                    cout << "myTroops[i].route.front() = "; posToString(myTroops[i].route.front());
                    break;
                }
            }
        }
    }

    // update ruinFirstEnemyTower
    if (ruinFirstEnemyTower == false && isPosVisible(enemyTowerPos_lo) &&
        info.findUnitByPos(enemyTowerPos_lo) == NULL) {
        ruinFirstEnemyTower = true;
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Push) {
                myTroops[i].setType(Tank);
                myTroops[i].route = tank_queue_high;
            }
        }
    }
    if (ruinFirstEnemyTower == false && isPosVisible(enemyTowerPos_hi) &&
        info.findUnitByPos(enemyTowerPos_hi) == NULL) {
        ruinFirstEnemyTower = true;
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Push) {
                myTroops[i].setType(Tank);
                myTroops[i].route = tank_queue_low;
            }
        }
    }
    
    // enemyRevivedRound
    int exp_sum_pre = 0;
    int exp_sum_now = 0;
    for (int i = 0; i < 5; i++) {
        exp_sum_pre += myHerosRecord[i]["Exp"]->val[0];
        exp_sum_now += myHeros[i]["Exp"]->val[0];
    }
    if (exp_sum_now > exp_sum_pre) {  // 如果有经验增长
        int newExp = exp_sum_now - exp_sum_pre;
        cout << "new Exp with wild = " << newExp << endl;
        // 首先扣除在视野内被击杀的野怪的经验
        for (int i = 0; i < info.units.size(); i++) {
            const PUnit & wild = info.units[i];
            if (wild.camp == 2 && wild.findBuff("Reviving") && unitsRecord[wild.id].camp == 2 &&
                unitsRecord[wild.id].findBuff("Reviving") == NULL)
                newExp -= wild["Exp"]->val[4];
        }
        // 再针对上回合出现这回合被杀死消失并消失在视野里的野怪
        for (int i = 0; i < unitsRecord.size(); i++) {
            if (unitsRecord[i].camp == 2 && info.findUnitById(i) == NULL &&
                unitsRecord[i].findBuff("Reviving") == NULL && unitsRecord[i].hp < unitsRecord[i]["Hp"]->val[1])
                newExp -= unitsRecord[i]["Exp"]->val[4];
        }
        vector<int> deadHerosId;
        cout << "new Exp without wild = " << newExp << endl;
        int count = 0;
        while (newExp > 0) { // 说明有敌方英雄死亡
            cout << "new Exp = " << newExp << endl;
            for (int i = 0; i < unitsRecord.size(); i++) {
                const PUnit & unit = unitsRecord[i];
                if (isHero(unit) && unit.camp == 1 - info.camp) { // 敌方英雄上回合还在
                    // 如果已经扣除过，则继续
                    bool hasBeenCounted = false;
                    for (int k = 0; k < deadHerosId.size(); k++)
                        if (deadHerosId[k] == unit.id)
                            hasBeenCounted = true;
                    if (hasBeenCounted) continue;
                    
                    // 下面判断并结算
                    bool isDead = true;
                    for (int j = 0; j < info.units.size(); j++) {
                        if (info.units[j].id == unit.id)
                            isDead = false;
                    }
                    if (isDead) { // 如果这回合视野内没有他了，则视为死亡
                        deadHerosId.push_back(unit.id);
                        newExp -= unit["Exp"]->val[4];
                        int rank = info.camp == 0 ? unit.id - 44 : unit.id - 39;
                        enemyRevivedRound[rank] = info.round + 5 * (unit.level + 1);
                        break;
                    }
                }
            }
            count++;
            if (count >= 5) break;  // 保护措施以免无限循环
        }
    }
    reviving_enemy_num = 0;
    for (int i = 0; i < 5; i++) {
        cout << "rank " << i << " will be revived at round " << enemyRevivedRound[i] << endl;
        if (enemyRevivedRound[i] >= info.round + RUSH_REVIVING_REMAIN_ROUND)
            reviving_enemy_num++;
    }
    cout << "reviving_enemy_num = " << reviving_enemy_num << endl;
    
    // deal with push lose situation
    for (int i = 0; i < myTroops.size(); i++) {
        if (myTroops[i].type == Push) {
            bool hero_near_tower_cur = false;
            bool hero_near_tower_pre = false;
            Pos towerPos = isSameRoute(myTroops[i].route, tank_queue_low) ? enemyTowerPos_lo : enemyTowerPos_hi;
            for (int i = 0; i < myHeros.size(); i++) {
                int m_dis = 15;
                if (dis(unitsRecord[myHeros[i].id].pos, towerPos) <= m_dis) {
                    hero_near_tower_pre = true;
                }
                if (dis(myHeros[i].pos, towerPos) <= m_dis) {
                    hero_near_tower_cur = true;
                }
            }
            if (hero_near_tower_pre && !hero_near_tower_cur) {
                pushFailTimes++;
                myTroops[i].setType(Tank);  // 切换回Tank状态
                if (!ruinFirstEnemyTower && towerPos == enemyTowerPos_hi)
                    myTroops[i].route = tank_queue_low;
                if (!ruinFirstEnemyTower && towerPos == enemyTowerPos_lo)
                    myTroops[i].route = tank_queue_high;
            }
        }
    }
    
    // check troop type transform ###
    bool needHelpDefend = false;
    bool hasDefendTroop = false;
    Pos dangerTowerPos = DP;
    for (int i = 0; i < myTroops.size(); i++) {
        if (myTroops[i].type == Defend) {
            hasDefendTroop = true;
            for (int j = 0; j < info.units.size(); j++) {
                if (isTower(info.units[j]) && info.units[j].camp == info.camp) {
                    dangerTowerPos = info.units[j].pos;
                }
            }
            if (!lostFirstSelfTower) dangerTowerPos = selfTowerPos_lo;
            if (myTroops[i].getAverageHp() < HELP_DEFEND_MIN_HP_RATE ||
                dis(myTroops[i].getTroopCenter(), dangerTowerPos) >= TOO_FAR_TO_DEFEND_TOWER_DIS)
                needHelpDefend = true;
        }
    }
    if ((dTower && !hasDefendTroop) || (hasDefendTroop && needHelpDefend)) { // 如果塔受到威胁且无防守 || 如果有防守且需要支援
        cout << "### CHECK POINT 1 ###" << endl;
        // 找到最近的打野团队
        int min_dis = 500;
        PTroop *jungleTroop = NULL;
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Jungle && myTroops[i].troop.size() >= 2) { // 寻找两人以上的打野小队
                cout << "@@@ ptroop.route.front() = "; posToString(myTroops[i].route.front()); cout << endl;
                if (dis(myTroops[i].getTroopCenter(), dangerTowerPos) < min_dis) {
                    min_dis = dis(myTroops[i].getTroopCenter(), dangerTowerPos);
                    jungleTroop = &myTroops[i];
                }
            }
        }
        if (!isGoingToRush) {
            vector<PUnit> defendHeros;  // 记录防守的英雄
            for (int i = 0; i < myTroops.size(); i++)
                if (myTroops[i].type == Defend)
                    for (int j = 0; j < myTroops[i].troop.size(); j++)
                        defendHeros.push_back(myTroops[i].troop[j]);
            if (jungleTroop) {  // 把打野的变成防守
                for (int i = 0; i < jungleTroop->troop.size(); i++)
                    defendHeros.push_back(jungleTroop->troop[i]);
                jungleTroop->setType(Defend);
            }
            // 将两者合成一个整体
            for(vector<PTroop>::iterator it = myTroops.begin(); it != myTroops.end();)
            {
                if((*it).type == Defend)
                    it = myTroops.erase(it);    //删除元素，返回值指向已删除元素的下一个位置
                else
                    ++it;    //指向下一个位置
            }
            myTroops.push_back(PTroop(Defend, defendHeros));
        }
        else {  // 选取血最多的非刺客英雄去防守
            cout << "NO JUNGLE TROOP!" << endl;
            PTroop *defendTroop = NULL;
            for (int i = 0; i < myTroops.size(); i++)
                if (myTroops[i].type == Defend)
                    defendTroop = &myTroops[i];
            if (defendTroop) {
                PUnit & weakHero = defendTroop->troop[0];  // 这个weak有可能是距离太远导致的
                int archer_max_hp = weakHero.hp;
                const PUnit *archer = NULL;
                for (int i = 0; i < myHeros.size(); i++) {
                    if (!isAssassin(myHeros[i]) && myHeros[i].id != weakHero.id && myHeros[i].hp > archer_max_hp) {
                        archer_max_hp = myHeros[i].hp;
                        archer = &myHeros[i];
                    }
                }
                if (archer) {
                    // 交换血少的英雄和血多的英雄
                    for (int i = 0; i < myTroops.size(); i++) {
                        bool findMatchHero = false;
                        for (int j = 0; j < myTroops[i].troop.size(); j++) {
                            if (myTroops[i].troop[j].id == archer->id) {
                                PUnit temp = myTroops[i].troop[j];
                                myTroops[i].troop[j] = weakHero;
                                weakHero = temp;
                                findMatchHero = true;
                                break;
                            }
                        }
                        if (findMatchHero) break;
                    }
                }
            }
        }
    }
    else {
        cout << "### CHECK POINT 2 ###" << endl;
        int defender_num = 0;
        for (int i = 0; i < myTroops.size(); i++)
            if (myTroops[i].type == Defend)
                defender_num += myTroops[i].troop.size();
        bool isTowerSafe = true;
        for (int i = 0; i < info.units.size(); i++)
            if (isTower(info.units[i]) && info.units[i].camp == info.camp && info.units[i].hp < info.units[i].max_hp)
                isTowerSafe = false;
        cout << "defender_Num = " << defender_num << " , isTowerSafe" << isTowerSafe << endl;
        if (defender_num > 2 && isTowerSafe) {  // 如果防御的队伍太多了，则派一队回去刷野
            // 再派血少的一队去刷野
            vector<PUnit> defendHeros;  // 记录防守的英雄
            for (int i = 0; i < myTroops.size(); i++)
                if (myTroops[i].type == Defend)
                    for (int j = 0; j < myTroops[i].troop.size(); j++)
                        defendHeros.push_back(myTroops[i].troop[j]);
            // 将防守人员以血量比例从小到大排列
            for (int i = 0; i < defendHeros.size(); i++) {
                for (int j = 0; j < defendHeros.size() - 1; j++) {
                    double pre_hero_hp = (double)defendHeros[j].hp / defendHeros[j].max_hp;
                    double cur_hero_hp = (double)defendHeros[j+1].hp / defendHeros[j+1].max_hp;
                    if (pre_hero_hp > cur_hero_hp) {
                        PUnit temp = defendHeros[j];
                        defendHeros[j] = defendHeros[j+1];
                        defendHeros[j+1] = temp;
                    }
                }
            }
            cout << "defenHero.size() = " << defendHeros.size() << endl;
            vector<PUnit> jungleHeros;  // 准备去打野的英雄
            vector<PUnit> stillDefendHeros;
            for (int i = 0; i < defendHeros.size(); i++) {
                if (i <= 1)
                    jungleHeros.push_back(defendHeros[i]);
                else
                    stillDefendHeros.push_back(defendHeros[i]);
            }
            PTroop jungleTroop(Jungle, jungleHeros);
            jungleTroop.route = info.findUnitByPos(selfTowerPos_lo) ? jungle_queue_enemy_dragon_loop : jungle_queue_ready_defend;
            // 开始分拆
            for(vector<PTroop>::iterator it = myTroops.begin(); it != myTroops.end();)
            {
                if((*it).type == Defend)
                    it = myTroops.erase(it);    //删除元素，返回值指向已删除元素的下一个位置
                else
                    ++it;    //指向下一个位置
            }
            myTroops.push_back(jungleTroop);
            myTroops.push_back(PTroop(Defend, stillDefendHeros));
        }
    }
    
    bool preFlag_isGoingToRush = isGoingToRush;
    double min_level = 0;
    if (dangerTowerCount >= 1) min_level = 5;  // 如果敌人持续进攻，则应保持推塔状态
    if (dangerTowerCount == 0 && !ruinFirstEnemyTower) min_level = 6; // 推第一座塔要快
    if (myHeroTroop.getAverageLevel() >= min_level) isGoingToRush = true;
    if (!preFlag_lostFirstSelfTower && lostFirstSelfTower && myHeroTroop.getAverageLevel() >= PUSH_MIN_LEVEL) isGoingToRush = true;   // 第一座塔被推掉，则进入Tank模式
    if (preFlag_isGoingToRush == false && isGoingToRush == true) {
        cout << "### CHECK POINT 3 ###" << endl;
        myTroops.clear();
//        blocks.clear();  // 清空对肉山的阻碍
        // defender
        vector<PUnit> defendTroop;
        int archer_max_hp = -1;
        const PUnit *archer = NULL;
        for (int i = 0; i < myHeros.size(); i++) {
            if (isArcher(myHeros[i]) && myHeros[i].hp > archer_max_hp) {
                archer_max_hp = myHeros[i].hp;
                archer = &myHeros[i];
            }
        }
        defendTroop.push_back(*archer);
        PTroop defender(Defend, defendTroop);
        cout << "defender: " << defender.troop.size() << ", " << defender.route.size() << endl;
        myTroops.push_back(defender);
        // tanker
        vector<PUnit> tankTroop;
        for (int i = 0; i < myHeros.size(); i++)
            if (myHeros[i].id != archer->id)
                tankTroop.push_back(myHeros[i]);
        PTroop tanker(Tank, tankTroop);
        tanker.route = lostFirstSelfTower ? tank_queue_low : tank_queue_high;
        myTroops.push_back(tanker);
    }
    
    // Jungle -> Defend
    for (int i = 0; i < myTroops.size(); i++) {
        if (myTroops[i].type == Jungle && myTroops[i].troop.size() >= 2) {
            cout << "### CHECK POINT 4 ###" << endl;
            if (myTroops[i].getAverageLevel() >= 3 && info.round < 300) {
                bool hasDefendTroop = false;
                for (int j = 0; j < myTroops.size(); j++)
                    if (myTroops[j].type == Defend)
                        hasDefendTroop = true;
                if (!hasDefendTroop) {
                    myTroops[i].setType(Defend);
                    break;
                }
            }
        }
    }
    
    // Tank -> Push
    for (int i = 0; i < myTroops.size(); i++) {
        if (myTroops[i].type == Tank) {
            cout << "### CHECK POINT 5 ###" << endl;
            PTroop & tanker = myTroops[i];
            Pos rushPos = isSameRoute(myTroops[i].route, tank_queue_low) ? rushPos2 : rushPos1;
            if (tanker.isEnoughToPush() && (tanker.route.front() == rushPos || reviving_enemy_num >= 2)) {
                tanker.type = Push;
                if (tanker.route.front() == rushPos) {
                    tanker.route.pop();
                    tanker.route.push(rushPos);
                }
            }
        }
    }
    // Push -> Tank
    for (int i = 0; i < myTroops.size(); i++) {
        if (myTroops[i].type == Push) {
            cout << "### CHECK POINT 6 ###" << endl;
            PTroop & pusher = myTroops[i];
            findEnemyGroups(pusher, enemyGroups);
            bool needChangeToTank = false;
            if (enemyGroups.size() == 0 || !isTower(enemyGroups[0])) {  // 如果不在塔周围
                if (!pusher.isEnoughToPush() && reviving_enemy_num < 2) {
                    needChangeToTank = true;
                }
            }
            if (enemyGroups.size() && isTower(enemyGroups[0]) && enemyGroups[0].hp >= enemyGroups[0].max_hp * 0.75) {  // 如果在塔周围，且塔血量充足
                if (fightPower(enemyGroups) / 2 > fightPower(myTroops[i].troop)) {  // 打不过敌人
                    needChangeToTank = true;
                }
            }
            if (needChangeToTank) {
                pusher.type = Tank;
                Pos towerPos = isSameRoute(myTroops[i].route, tank_queue_low) ? enemyTowerPos_lo : enemyTowerPos_hi;
                myTroops[i].setType(Tank);  // 切换回Tank状态
                if (!ruinFirstEnemyTower && towerPos == enemyTowerPos_hi)
                    myTroops[i].route = tank_queue_low;
                if (!ruinFirstEnemyTower && towerPos == enemyTowerPos_lo)
                    myTroops[i].route = tank_queue_high;
            }
        }
    }
    if (info.round >= FINAL_RUSH_ROUND - 20 && info.round < FINAL_RUSH_ROUND) {
        cout << "### CHECK POINT 7 ###" << endl;
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Tank || Push) {
                myTroops[i].setType(Tank);
                if (isSameRoute(myTroops[i].route, tank_queue_high))
                    myTroops[i].route = tank_queue_high;
                if (isSameRoute(myTroops[i].route, tank_queue_low))
                    myTroops[i].route = tank_queue_low;
            }
        }
    }
    if (info.round >= FINAL_RUSH_ROUND) {
        cout << "### CHECK POINT 8 ###" << endl;
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Tank) {
                myTroops[i].setType(Push);
            }
        }
    }
    
    // update needGoToSpring
    for (int i = 0; i < myTroops.size(); i++) {
        cout << "### CHECK POINT 10 ###" << endl;
        const PTroop & pTroop = myTroops[i];
        for (int j = 0; j < pTroop.troop.size(); j++) {
            const PUnit & hero = pTroop.troop[j];
            int rank = rankInTroop(hero.id, myHeros);
            int weakHp = WEAK_HP;
            if (isAssassin(hero) && pTroop.type == Jungle) weakHp = 150;
            if (hero.hp <= weakHp && !hasAliveWildNearBy(pTroop))
                needGoToSpring[rank] = true;
            if (needGoToSpring[rank] && hero.hp == hero.max_hp)
                needGoToSpring[rank] = false;
        }
    }
    cout << "needGoToSpring[0] = " << needGoToSpring[0] << endl;
    
    // update route
    for (int i = 0; i < myTroops.size(); i++)
        myTroops[i].updateRoute();
    cout << "route finish update" << endl;
    
    // update deadTimes
    for (int i = 0; i < myHeros.size(); i++) {
        if (myHerosRecord[i].findBuff("Reviving") == NULL && myHeros[i].findBuff("Reviving")) {
            deadTimes[i]++;
        }
    }
    cout << "FINISH UPDATE " << endl;
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
    CMD = &cmd;
    if (info.round == 0) {
        init_one();
        chooseHero(info, cmd);
    }
    else {
        if (info.camp == 1) {
            INFO = NULL;
            int round = INFO->round;  // XD~
        }
        update();
        cout << "### ALL ###" << endl;
        // 先对全体操作
        finishLevelUp();
        for (int i = 0; i < myHeros.size(); i++) {  // 回家补血
            if (needGoToSpring[i])
                moveTo(myHeros[i], springPos);
        }
        cout << "### DEFENDER ###" << endl;
        // 对防守者进行操作
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Defend) {
                PTroop & defender = myTroops[i];
                const PUnit *dTower = towerInDanger();
                findEnemyGroups(defender, enemyGroups);
                if (dTower) {
                    cout << "### DEFENDER 0-0 ###" << endl;
                    if (enemyGroups.size() && isHero(enemyGroups[0])) {
                        troopFight(defender, enemyGroups); cout << "### DEFENDER 0-1 ###" << endl; }
                    else {
                        Pos diff = dTower->pos == selfTowerPos_hi ? Pos(0,-4) : Pos(0,4);
                        moveTroopTo(defender, dTower->pos + diff);
                    }
                    cout << "### DEFENDER 0-2 ###" << endl;
                }
                else {
                    cout << "### DEFENDER 1-0 ###";
                    cout << defender.troop.size() << defender.route.size() << endl;
                    if (enemyGroups.size()) { cout << "### DEFENDER 1-1 ###" << endl;
                        troopFight(defender, enemyGroups);}
                    else
                        moveTroopTo(defender, defender.route.front());
                    cout << "### DEFENDER 1-2 ###" << endl;
                }
            }
        }
        
        cout << "### TANKER ###" << endl;
        // 对团战者进行操作
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Tank) {
                PTroop & tanker = myTroops[i];
                findEnemyGroups(tanker, enemyGroups);
                if (enemyGroups.size()) {
                    troopFight(tanker, enemyGroups); cout << "### TANKER 0-1 ###" << endl; }
                else
                    moveTroopTo(tanker, tanker.route.front());
                cout << "### TANKER 0-2 ###" << endl;
            }
        }
        
        cout << "### PUSHER ###" << endl;
        // 对推塔者进行操作
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Push) {
                PTroop & pusher = myTroops[i];
                Pos towerPos = isSameRoute(myTroops[i].route, tank_queue_low) ? enemyTowerPos_lo : enemyTowerPos_hi;
                findEnemyGroups(pusher, enemyGroups);
                cout << "### PUSHER 0-0 ###" << endl;
                if (enemyGroups.size()) {
                    troopFight(pusher, enemyGroups); cout << "### PUSHER 0-1 ###" << endl;}
                else {
                    moveTroopTo(pusher, towerPos); cout << "### PUSHER 0-2 ###" << endl;}
            }
        }
        
        cout << "### JUNGLE ###" << endl;
        // 对打野者操作
        for (int i = 0; i < myTroops.size(); i++) {
            if (myTroops[i].type == Jungle) {
                PTroop & jungler = myTroops[i];
                findEnemyGroups(jungler, enemyGroups);
                if (enemyGroups.size())
                    troopFight(jungler, enemyGroups);
                else
                    moveTroopTo(jungler, jungler.route.front());
            }
        }
        
        // test
        for (int i = 0; i < myTroops.size(); i++) {
            cout << "pTroop.type = " << myTroops[i].type << ", pTroop.troop.size() = ";
            cout << myTroops[i].troop.size() << ", pTroop.route.front() = "; posToString(myTroops[i].route.front()); cout << endl;
        }
    }
    cout << "********************************** round = " << info.round << endl;
    // update later
    // myHerosRecord
    for (int i = 0; i < myHeros.size(); i++) {
        myHerosRecord[i] = myHeros[i];
    }
    
    // unitsRecord
    for (int i = 0; i < MAX_UNITS_NUM; i++) {
        unitsRecord[i] = DPUnit;
    }
    for (int i = 0; i < info.units.size(); i++) {
        int id = info.units[i].id;
        unitsRecord[id] = info.units[i];
    }
}











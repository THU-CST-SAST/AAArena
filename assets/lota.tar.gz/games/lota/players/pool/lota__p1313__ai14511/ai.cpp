#include "sdk.h"
#include <fstream>

using namespace std;

namespace yq {
//-----------------------�����-------------------------
struct global {
    static void chooseHero();
    static void prepare();
    static void analyse();
};

struct BoundMap {
    bool bound[Map_size][Map_size];
    void setBound(const Pos &, int radius2);
    bool operator[](const Pos &X) {
        return bound[X.x][X.y];
    }
};

struct Unit {
    int id, player, hp, mp, atk, def, range, level, maxhp, onlyTarget, refreshRound;
    double hprate;
    Pos pos;
    string name;
    bool buff[8];
    const PUnit *U;
    int silencetime;
    bool evaluated;
    Unit();
    Unit(const PUnit *);
    double TowerEvaluate();
};

struct PathMap {
    int step[Map_size][Map_size];
    Pos pre[Map_size][Map_size];
};

struct MyHero: Unit {
    static const int skillKind[10];
    int status, localstatus;
    Pos aim;
    static int defenceTower;
    PathMap direct, avoid;
    int drawtime;

    MyHero();
    MyHero(const PUnit *);
    int getLastHit(const int &id);
    void BFSdirect();
    void SPFAavoid();
    void archerWork();
    bool fastDisplace(Pos, int nearforbid=-1);
    bool hinderDisplace(Pos ,int nearforbid=-1);
};

struct WildList {
    static const Pos wildpos[6][8];
    static const int wildlevel[6][8];
    //�ڴ�����֮Pos����֮ǰ��Ұ�־�̖
    static const Pos towerwild[2][2][3];
    static const Pos wildroute[2][6];
    static const int totwildroute;
    static const int revtime[6];
    static int nowwildno;
    static int wildrevtime[6][8];
};

//-----------------------������������^-------------------
const int elem_maxsize = 23000;
const int inf = 1000000000;
const int ViewRange = 100;

const Pos WildList::wildpos[6][8] = {{Pos(8, 34), Pos(34, 34), Pos(58, 34), Pos(54, 75), Pos(142, 116), Pos(116, 116), Pos(92, 116), Pos(96, 75)},
    {Pos(8, 102), Pos(54, 54), Pos(54, 115), Pos(142, 48), Pos(96, 96), Pos(96, 35), Pos(), Pos()},
    {Pos(34, 54), Pos(56, 8), Pos(116, 96), Pos(94, 142), Pos(), Pos(), Pos(), Pos()},
    {Pos(32, 95), Pos(118, 55), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()},
    {Pos(5, 5), Pos(145, 145), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()},
    {Pos(75, 75), Pos(), Pos(), Pos(), Pos(), Pos(), Pos(), Pos()}
};
const int WildList::wildlevel[6][8] = {{0, 0, 0, 0, 0, 0, 0, 0},
    {10, 10, 0, 10, 10, 0, 10, 10},
    {0, 0, 0, 0, 10, 10, 10, 10},
    {3, 3, 10, 10, 10, 10, 10, 10},
    {1, 1, 10, 10, 10, 10, 10, 10},
    {6, 10, 10, 10, 10, 10, 10, 10}
};
const Pos WildList::towerwild[2][2][3] = {{{Pos(2, 2), Pos(0, 5), Pos(0, 7)}, {Pos(0, 6), Pos(1, 2), Pos(2, 3)}},
    {{Pos(2, 0), Pos(0, 1), Pos(0, 3)}, {Pos(0, 2), Pos(1, 5), Pos(2, 1)}}
};
//const Pos WildList::wildroute[2][9] = {{Pos(1, 2), Pos(2, 3), Pos(0, 6), Pos(0, 7), Pos(2, 2), Pos(3, 1), Pos(0, 3), Pos(0, 1), Pos(5, 0)},
//    {Pos(1, 5), Pos(2, 1), Pos(0, 2), Pos(0, 3), Pos(2, 0), Pos(3, 0), Pos(0, 7), Pos(0, 5), Pos(5, 1)}
//};
const Pos WildList::wildroute[2][6] = {{Pos(1, 2), Pos(0, 3), Pos(2, 0), Pos(0, 1), Pos(0, 0), Pos(4, 0)},
    {Pos(1, 5), Pos(0, 7), Pos(2, 2), Pos(0, 5), Pos(0, 4), Pos(4, 1)}
};
const int WildList::totwildroute = 6;
const int WildList::revtime[6] = {20, 20, 25, 25, 60, 80};

const double TowerDanger = 1000.0;
const double TowerSilence = 200.0;
const int MyHero::skillKind[10] = {12, 10, 12, 10, 12, 10, 19, 19, 19, 19};

//-----------------------ȫ��׃������^-------------------
const PPlayerInfo *Info;
PCommand *Cmd;
const PMap *Map;
int nowRound;
int player;

MyHero myHero[5];
Unit myTower[2], mySpring, heTower[2], heHero[5], heSpring;
int myTowerTot, heTowerTot = 2, heHeroKnown = 0;
bool heHeroInsight[5];

bool heTowerDead[2];
Pos myTowerPos[2], heTowerPos[2];
bool heTowerInsight[5];

Unit wild[30];
int totWild;

BoundMap Bound;
Pos Queue[elem_maxsize];
int _Dis[Map_size][Map_size];
bool inQueue[Map_size][Map_size];
bool occupy[Map_size][Map_size];

int WildList::wildrevtime[6][8];
int WildList::nowwildno = 0;

int MyHero::defenceTower = 0;

int arrowRainUsed=0;
int towertime=0;
//-----------------------���߳�ʽ����^-------------------
void normalOperationGen(const string &type, const int &id, const Pos &_pos = Pos());
bool stringcmp(const char[], const char[]);
}

//-----------------------����ʽ---------------------------
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd) {
    yq::Map = &map, yq::Info = &info, yq::Cmd = &cmd;
    yq::Cmd->cmds.clear();
    if (info.round == 0) {
        yq::global::chooseHero();
        return;
    }
    yq::global::prepare();
    yq::global::analyse();
    for (int i = 0; i < 5; i++)
        yq::myHero[i].archerWork();
}
//------------------------���F�^--------------------------
void yq::global::chooseHero() {
    vector<const PUnit *> Myunitset;
    Info->findUnitByPlayer(Info->player, Myunitset);
    int tot_selected = 0;
    for (int i = 0; i < Myunitset.size(); i++) {
        if (stringcmp(Myunitset[i]->name, "Chooser")) {
            ++tot_selected;
            switch (tot_selected) {
                case 1:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 2:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 3:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 4:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
                case 5:
                    normalOperationGen("ChooseArcher", Myunitset[i]->id);
                    break;
            }
        }
    }
}

void yq::global::prepare() {
    nowRound = Info->round;
    player = Info->player;
    if (arrowRainUsed) arrowRainUsed--;

    memset(occupy, 0, sizeof(occupy));
    for (int i = 0; i < Info->units.size(); i++)
        occupy[Info->units[i].pos.x][Info->units[i].pos.y] = 1;

    //��һ�غϳ�ʼ������λ��
    if (nowRound == 1) {
        if (player == 0) {
            myTowerPos[0] = Player0_tower_pos[1], myTowerPos[1] = Player0_tower_pos[0];
            heTowerPos[0] = Player1_tower_pos[1], heTowerPos[1] = Player1_tower_pos[0];
        };
        if (player == 1) {
            myTowerPos[0] = Player1_tower_pos[1], myTowerPos[1] = Player1_tower_pos[0];
            heTowerPos[0] = Player0_tower_pos[1], heTowerPos[1] = Player0_tower_pos[0];
        }
        MyHero::defenceTower = 0;
    }

    //��ʼ���Լ���Ӣ��
    int tmp = 0;
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == player) && (Info->units[i].isHero())) {
            if (nowRound == 1) {
                ++tmp, myHero[tmp - 1] = MyHero(&Info->units[i]), myHero[tmp - 1].localstatus = 1;
                myHero[tmp - 1].status = 1;
                myHero[tmp - 1].drawtime = 0;
            }
            else
                for (int j = 0; j < 5; j++)
                    if (myHero[j].id == Info->units[i].id) {
                        int prelocalstatus = myHero[j].localstatus, prestatus = myHero[j].status, predrawtime = myHero[j].drawtime;
                        Pos preaim = myHero[j].aim;
                        myHero[j] = MyHero(&Info->units[i]);
                        myHero[j].localstatus = prelocalstatus;
                        myHero[j].status = prestatus;
                        myHero[j].aim = preaim;
                        myHero[j].drawtime = predrawtime;
                        if (myHero[j].drawtime)
                            myHero[j].drawtime--;
                    }
        }

    //��ʼ���Լ�������Ȫˮ
    myTowerTot = 0;
    for (int i = 0; i < Info->units.size(); i++) {
        if ((Info->units[i].player == player) && (stringcmp(Info->units[i].name, "Tower"))) {
            ++myTowerTot;
            for (int j = 0; j < 2; j++)
                if (Info->units[i].pos == myTowerPos[j]) {
                    int presilence = myTower[j].silencetime;
                    myTower[j] = Unit(&Info->units[i]);
                    myTower[j].silencetime = presilence;
                }
        }
        if ((Info->units[i].player == player) && (stringcmp(Info->units[i].name, "Spring")))
            mySpring = Unit(&Info->units[i]);
    }

    //��ʼ������Ć�λ
    memset(heHeroInsight, 0, sizeof(heHeroInsight));
    memset(heTowerInsight, 0, sizeof(heTowerInsight));
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == 1 - player) && (Info->units[i].isHero())) {
            int ord = -1;
            for (int j = 0; j < heHeroKnown; j++)
                if (Info->units[i].id == heHero[j].id) ord = j;
            if (ord == -1) ++heHeroKnown, ord = heHeroKnown - 1;
            heHeroInsight[ord] = 1;
            heHero[ord] = Unit(&Info->units[i]);
        }
    for (int i = 0; i < Info->units.size(); i++) {
        if ((Info->units[i].player == 1 - player) && (stringcmp(Info->units[i].name, "Tower")))
            for (int j = 0; j < 2; j++)
                if (Info->units[i].pos == heTowerPos[j])
                    heTower[j] = Unit(&Info->units[i]), heTowerInsight[j] = 1;
        if ((Info->units[i].player == 1 - player) && (stringcmp(Info->units[i].name, "Spring")))
            heSpring = Unit(&Info->units[i]);
    }

    //ӛ䛿�ҊҰ��
    totWild = 0;
    for (int i = 0; i < Info->units.size(); i++)
        if ((Info->units[i].player == 2) && (Info->units[i].isWild()))
            ++totWild, wild[totWild - 1] = Unit(&Info->units[i]);

    //ӛ�Ұ�ֵ�������r
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 8; j++)
            if (WildList::wildrevtime[i][j])
                WildList::wildrevtime[i][j]--;
    for (int i = 0; i < totWild; i++)
        if (wild[i].buff[7]) {
            Pos origin;
            int mindis2 = inf;
            for (int j = 0; j < 6; j++)
                for (int k = 0; k < 8; k++)
                    if (dis2(wild[i].pos, WildList::wildpos[j][k]) < mindis2)
                        mindis2 = dis2(wild[i].pos, WildList::wildpos[j][k]), origin = Pos(j, k);
            if (WildList::wildrevtime[origin.x][origin.y] == 0)
                WildList::wildrevtime[origin.x][origin.y] = WildList::revtime[origin.x];
        }


    //��ʼ�����^
    memset(Bound.bound, 0, sizeof(Bound.bound));
    for (int i = 0; i < heHeroKnown; i++)
        if ((heHeroInsight[i]) && (!heHero[i].buff[4]) && (!heHero[i].buff[7]))
            Bound.setBound(heHero[i].pos, min(heHero[i].range, 64));
    for (int i = 0; i < 2; i++)
        if (heTowerInsight[i])
            Bound.setBound(heTower[i].pos, heTower[i].range);
    for (int i = 0; i < totWild; i++)
        Bound.setBound(wild[i].pos, 9);

    //��·�Kӛ�
    for (int i = 0; i < 5; i++)
        if (!myHero[i].buff[7]) {
            myHero[i].BFSdirect();
            myHero[i].SPFAavoid();
        }
}

void yq::global::analyse() {
    double dangerV[2];
    if (myTowerTot == 1) {
        for (int i=0; i<2; i++)
            if (myTower[i].refreshRound==nowRound) MyHero::defenceTower=i;
        dangerV[MyHero::defenceTower]=myTower[MyHero::defenceTower].TowerEvaluate();
    }
    if (myTowerTot == 2) {
        for (int i=0; i<2; i++)
            dangerV[i]=myTower[i].TowerEvaluate();
        if (dangerV[0]-dangerV[1]>=300.0) MyHero::defenceTower=0;
        if (dangerV[1]-dangerV[0]>=300.0) MyHero::defenceTower=1;
    }

    if (WildList::nowwildno<6) {
        Pos nowwild=WildList::wildroute[player][WildList::nowwildno];
        if (WildList::wildrevtime[nowwild.x][nowwild.y]) ++WildList::nowwildno;
    }

    if (heTowerTot == 2) {
        if (WildList::nowwildno < 6) {
            for (int i=0; i<5; i++)
                myHero[i].status=myHero[i].localstatus=1,
                myHero[i].aim=WildList::wildpos[WildList::wildroute[player][WildList::nowwildno].x][WildList::wildroute[player][WildList::nowwildno].y];
        } else {
            for (int i=0; i<5; i++)
                myHero[i].status=3,
                myHero[i].aim=heTowerPos[0];
            bool notdraw=1;
            for (int i=0; i<5; i++)
                if ((myHero[i].localstatus==3)&&((myHero[i].drawtime)||(myHero[i].hprate<=0.7))) notdraw=0;
            if (notdraw) {
                myHero[0].localstatus=1;
                myHero[1].localstatus=1;
                myHero[2].localstatus=1;
                myHero[3].localstatus=2;
                myHero[4].localstatus=2;
            }
            double towerhp=0.0;
            if (heTowerInsight[0]) towerhp=heTower[0].hprate;
            int heHerolevelsum=0,myHerolevelsum=0,mydeadsum=0;
            for (int i=0; i<heHeroKnown; i++)
                if (heHeroInsight[i]) {
                    bool able=0;
                    for (int j=0; j<5; j++)
                        if ((dis2(myHero[j].aim,myHero[j].pos)<=myHero[j].range)&&(dis2(heHero[i].pos,myHero[j].pos)<=heHero[i].range))
                            able=1;
                    if (able) heHerolevelsum+=heHero[i].level;
                }
            for (int i=0; i<5; i++) {
                if (myHero[i].buff[7]) ++mydeadsum;
                myHerolevelsum+=myHero[i].level;
            }
            if (((heHerolevelsum>myHerolevelsum)&&(towerhp>0.5))||(mydeadsum>=3))
                for (int i=0; i<5; i++)
                    myHero[i].localstatus=3;
        }
    }

    if (heTowerTot == 1) {
        int prestatus=myHero[0].status;
        for (int i=0; i<5; i++)
            myHero[i].status=2,myHero[i].localstatus=1,myHero[i].aim=myTower[MyHero::defenceTower].pos;

        int totdead=0, levelsum=0, healthy=0, together=1, heHerolevelsum=0;
        for (int i=0; i<5; i++) {
            if (myHero[i].buff[7]) ++totdead;
            levelsum+=myHero[i].level;
        }
        for (int i=0; i<5; i++)
            if ((myHero[i].hprate>0.3)&&(!myHero[i].buff[7])) ++healthy;
        for (int i=1; i<5; i++)
            if (dis2(myHero[i].pos,myHero[0].pos)<=144)
                ++together;
        for (int i=0; i<heHeroKnown; i++)
                if (heHeroInsight[i]) {
                    bool able=0;
                    for (int j=0; j<5; j++)
                        if ((dis2(myHero[j].aim,myHero[j].pos)<=myHero[j].range)&&(dis2(heHero[i].pos,myHero[j].pos)<=heHero[i].range))
                            able=1;
                    if (able) heHerolevelsum+=heHero[i].level;
                }
        double towerhp=1.0;
        if (heTowerInsight[1]) towerhp=heTower[1].hprate;

        if (prestatus==3) {
            if ((totdead>=3)&&(towerhp>=0.2)) towertime=nowRound+70;
            if ((0.5*levelsum<heHerolevelsum)&&(towerhp>=0.5)) towertime=nowRound+70;
            if (totdead>=4) towertime=nowRound+70;
            if ((nowRound>towertime)&&(levelsum>=18)) {
                myHero[0].status=3,myHero[0].localstatus=1,myHero[0].aim=heTowerPos[1];
                myHero[1].status=3,myHero[1].localstatus=1,myHero[1].aim=heTowerPos[1];
                myHero[2].status=3,myHero[2].localstatus=1,myHero[2].aim=heTowerPos[1];
                myHero[3].status=3,myHero[3].localstatus=2,myHero[3].aim=heTowerPos[1];
            }
        } else {
            if ((levelsum>=24)&&(dangerV[MyHero::defenceTower]<=TowerSilence)&&(nowRound>=towertime)&&(together>=4)&&(healthy>=4)
                &&(!myHero[4].buff[7])) {
                myHero[0].status=3,myHero[0].localstatus=1,myHero[0].aim=heTowerPos[1];
                myHero[1].status=3,myHero[1].localstatus=1,myHero[1].aim=heTowerPos[1];
                myHero[2].status=3,myHero[2].localstatus=1,myHero[2].aim=heTowerPos[1];
                myHero[3].status=3,myHero[3].localstatus=2,myHero[3].aim=heTowerPos[1];
            }
        }
    }
}

void yq::BoundMap::setBound(const Pos &center, int radius2) {
    for (int i = center.x - sqrt(radius2); i <= center.x + sqrt(radius2); i++) {
        if ((i < 0) || (i >= Map_size)) continue;
        for (int j = center.y - sqrt(radius2 - (center.x - i) * (center.x - i)); j <= center.y + sqrt(radius2 - (center.x - i) * (center.x - i)); j++) {
            if ((j < 0) || (j >= Map_size)) continue;
            bound[i][j] = 1;
        }
    }
}

yq::Unit::Unit(): id(-1), U(NULL) {
    memset(buff, 0, sizeof(buff));
    silencetime = 0, evaluated = 0;
}

yq::Unit::Unit(const PUnit *Yu): atk(Yu->atk), def(Yu->def), hp(Yu->hp), id(Yu->id), level(Yu->level),
    maxhp((*Yu)["Hp"]->val[1]), mp(Yu->mp), name(string(Yu->name)), onlyTarget((*Yu)["OnlyTarget"]->val[0]), player(Yu->player),
    pos(Yu->pos), range(Yu->range), U(Yu), refreshRound(nowRound) {
    hprate = double(hp) / double(maxhp);
    memset(buff, 0, sizeof(buff));
    for (int i = 0; i < Yu->buffs.size(); i++)
        buff[Yu->buffs[i].typeId] = 1;
    silencetime = 0, evaluated = 0;
}

double yq::Unit::TowerEvaluate() {
    if (name != "Tower") return 0.0;
    double X = 0.0;
    bool existEnemy = 0;
    for (int i = 0; i < heHeroKnown; i++)
        if ((heHeroInsight[i]) && (dis2(pos, heHero[i].pos) <= ViewRange)) {
            existEnemy = 1;
            Unit &Now = heHero[i];
            if (dis2(pos, Now.pos) <= 81)
                X = X + (double)((Now.level + 1) * (Now.hp));
            else
                X = X + (double)((Now.level + 1) * (Now.hp)) / 2;
        }
    X = X + (1.0 - hprate) * 3000.0;
    if (existEnemy) silencetime = 0;
    else
        if (!evaluated) silencetime++;
    if (silencetime >= 5) X = min(X, 150.0);
    evaluated = 1;
    return X;
}

yq::MyHero::MyHero(): Unit() {
    memset(buff, 0, sizeof(buff));
    silencetime = 0, evaluated = 0;
}

yq::MyHero::MyHero(const PUnit *Yu): Unit(Yu) {
    memset(buff, 0, sizeof(buff));
    for (int i = 0; i < Yu->buffs.size(); i++)
        buff[Yu->buffs[i].typeId] = 1;
    silencetime = 0, evaluated = 0;
}

int yq::MyHero::getLastHit(const int &id) {
    const PArg &_arg = *(*U)["LastHit"];
    if (id < _arg.val.size()) return _arg.val[id];
    return -1;
}

void yq::MyHero::BFSdirect() {
    int (*Step)[Map_size] = direct.step;
    Pos (*Pre)[Map_size] = direct.pre;
    memset(_Dis, 0, sizeof(_Dis));
    for (int i = 0; i < Map_size; i++)
        for (int j = 0; j < Map_size; j++)
            Step[i][j] = -1, Pre[i][j] = Pos();
    int l = 1, r = 1;
    Queue[1] = pos, _Dis[pos.x][pos.y] = 1, Step[pos.x][pos.y] = 0, Pre[pos.x][pos.y] = pos;
    int dir_ord[4];
    for (; l <= r; l++) {
        Pos now = Queue[l];
        for (int i = 0; i < 4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord + 4);
        if ((!occupy[now.x][now.y]) || (now == pos))
            for (int i = 0; i < 4; i++) {
                Pos nex = Pos(now.x + dir[dir_ord[i]][0], now.y + dir[dir_ord[i]][1]);
                if ((checkPos(nex)) && (_Dis[nex.x][nex.y] == 0) &&
                        (abs(Map->height[nex.x][nex.y] - Map->height[now.x][now.y]) <= 1)) {
                    ++r;
                    Queue[r] = nex;
                    _Dis[nex.x][nex.y] = 1;
                    Step[nex.x][nex.y] = Step[now.x][now.y] + 1;
                    Pre[nex.x][nex.y] = now;
                }
            }
    }
}

void yq::MyHero::SPFAavoid() {
    int (*Step)[Map_size] = avoid.step;
    Pos (*Pre)[Map_size] = avoid.pre;
    for (int i = 0; i < Map_size; i++)
        for (int j = 0; j < Map_size; j++) {
            _Dis[i][j] = inf;
            Step[i][j] = -1, Pre[i][j] = Pos();
            inQueue[i][j] = 0;
        }
    int l = 1, r = 1, lmo = 1, rmo = 1;
    Queue[1] = pos, _Dis[pos.x][pos.y] = 0, Step[pos.x][pos.y] = 0, Pre[pos.x][pos.y] = pos, inQueue[pos.x][pos.y] = 1;
    int dir_ord[4];
    for (; l <= r; l++, lmo++) {
        if (lmo >= elem_maxsize) lmo -= elem_maxsize;
        Pos now = Queue[lmo];
        for (int i = 0; i < 4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord + 4);
        if ((!occupy[now.x][now.y]) || (now == pos))
            for (int i = 0; i < 4; i++) {
                Pos nex = Pos(now.x + dir[dir_ord[i]][0], now.y + dir[dir_ord[i]][1]);
                if (!checkPos(nex)) continue;
                int delta = (Bound[nex] ? 100 : 1);
                if ((_Dis[now.x][now.y] + delta < _Dis[nex.x][nex.y]) &&
                        (abs(Map->height[now.x][now.y] - Map->height[nex.x][nex.y]) <= 1)) {
                    _Dis[nex.x][nex.y] = _Dis[now.x][now.y] + delta;
                    Step[nex.x][nex.y] = Step[now.x][now.y] + 1;
                    Pre[nex.x][nex.y] = now;
                    if (!inQueue[nex.x][nex.y]) {
                        inQueue[nex.x][nex.y] = 1;
                        ++rmo, ++r;
                        if (rmo >= elem_maxsize) rmo -= elem_maxsize;
                        Queue[rmo] = nex;
                    }
                }
            }
        inQueue[now.x][now.y] = 0;
    }
}

void yq::MyHero::archerWork() {
    if ((*U)["Exp"]->val[3]) {
        if (U->canUseSkill(MyHero::skillKind[level])) {
            normalOperationGen(Skill_name[MyHero::skillKind[level]], id);
            return;
        }
    }
    //����������
    if (localstatus == 3) {
        if (dis2(pos,mySpring.pos)>81) hinderDisplace(mySpring.pos);
        return;
    }
    if ((status == 1) && (localstatus == 1)) {
        int inRainEnemy=0;
        for (int i=0; i<=heHeroKnown; i++)
            if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=144))
                ++inRainEnemy;
        if ((inRainEnemy>=2)&&(U->canUseSkill(9))&&(arrowRainUsed == 0)) {
            Pos ideal; int maxcanattack=-1;
            for (int x=pos.x-12; x<=pos.x+12; x++)
                for (int y=pos.y-12; y<=pos.y+12; y++)
                    if (checkPos(Pos(x,y))&&(dis2(Pos(x,y),pos)<=100)) {
                        int nowcanattack=0;
                        for (int j=0; j<heHeroKnown; j++)
                            if ((heHeroInsight[j])&&(dis2(Pos(x,y),heHero[j].pos)<=36))
                                ++nowcanattack;
                        if (nowcanattack>maxcanattack)
                            maxcanattack=nowcanattack,
                            ideal=Pos(x,y);
                    }
            if (maxcanattack>=2) {
                if (dis2(ideal,pos)>100) fastDisplace(ideal); else {
                    normalOperationGen("ArrowsRain",id,ideal);
                    arrowRainUsed=5;
                    return;
                }
            }
        }
        Pos enemyPos(Pos(10000,10000)); int enemyrange;
        for (int i=0; i<=heHeroKnown; i++)
            if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=dis2(pos,enemyPos))&&(dis2(pos,heHero[i].pos)<=ViewRange))
                enemyPos=heHero[i].pos,enemyrange=heHero[i].range;
        if (enemyPos!=Pos(10000,10000)) {
            if (U->canUseSkill(11))
                normalOperationGen("PowerUp",id);
            else if (dis2(pos,enemyPos)>range)
                (enemyrange<=10)?fastDisplace(enemyPos,enemyrange):fastDisplace(enemyPos);
            else
                normalOperationGen("Attack",id,enemyPos);
            return;
        }
        Pos wildPos(Pos(10000,10000)); Unit *wildp;
        for (int i=0; i<totWild; i++)
            if ((dis2(wild[i].pos,pos)<=dis2(wildPos,pos))&&(dis2(wild[i].pos,pos)<=ViewRange)&&(!wild[i].buff[7])&&(!(wild[i].name=="Roshan")))
                wildPos=wild[i].pos,wildp=&wild[i];
        if ((wildPos!=Pos(10000,10000))&&(dis2(pos,wildPos)<=range)) {
            if (wildp->maxhp>500)
                if (U->canUseSkill(11)) {
                    normalOperationGen("PowerUp",id);
                    return;
                }
            normalOperationGen("Attack",id,wildPos);
            return;
        } else
        if ((wildPos!=Pos(10000,10000))&&(dis2(pos,wildPos)>range))
            (wildp->range<=10)?fastDisplace(wildPos,wildp->range):fastDisplace(wildPos);
        else
            hinderDisplace(aim);
    }

    if ((status == 2) && (localstatus == 1))
        if (dis2(pos,aim)>=1600) hinderDisplace(aim);
        else if ((myTower[MyHero::defenceTower].TowerEvaluate()>=TowerDanger)&&(dis2(pos,aim)>=200)) fastDisplace(aim);
        else {
        bool alone=1;
        for (int i=0; i<5; i++)
            if ((myHero[i].pos!=pos)&&(myHero[i].status==2)) alone=0;

        bool attacked=0;
        for (int i=0; i<heHeroKnown; i++)
            if ((heHeroInsight[i])&&(getLastHit(heHero[i].id)>=nowRound-3)) attacked=1;
        if ((dis2(pos,aim)>ViewRange)&&(attacked)) {
            fastDisplace(aim); return;
        }
        int inRainEnemy=0;
        for (int i=0; i<=heHeroKnown; i++)
            if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=144))
                ++inRainEnemy;
        if ((inRainEnemy>=2)&&(U->canUseSkill(9))&&(arrowRainUsed == 0)) {
            Pos ideal; int maxcanattack=-1;
            for (int x=pos.x-12; x<=pos.x+12; x++)
                for (int y=pos.y-12; y<=pos.y+12; y++)
                    if (checkPos(Pos(x,y))&&(dis2(Pos(x,y),pos)<=100)) {
                        int nowcanattack=0;
                        for (int j=0; j<heHeroKnown; j++)
                            if ((heHeroInsight[j])&&(dis2(Pos(x,y),heHero[j].pos)<=36))
                                ++nowcanattack;
                        if (nowcanattack>maxcanattack)
                            maxcanattack=nowcanattack,
                            ideal=Pos(x,y);
                    }
            if (maxcanattack>=2) {
                if (dis2(ideal,pos)>100) fastDisplace(ideal); else {
                    normalOperationGen("ArrowsRain",id,ideal);
                    arrowRainUsed=5;
                    return;
                }
            }
        }
        Pos enemyPos(Pos(10000,10000)); int enemyrange;
        for (int i=0; i<=heHeroKnown; i++)
            if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=dis2(pos,enemyPos))&&(dis2(pos,heHero[i].pos)<=ViewRange))
                enemyPos=heHero[i].pos, enemyrange=heHero[i].range;
        if (enemyPos!=Pos(10000,10000)) {
            if (U->canUseSkill(11))
                normalOperationGen("PowerUp",id);
            else if (dis2(pos,enemyPos)>range)
                (enemyrange<=10)?fastDisplace(enemyPos,enemyrange):fastDisplace(enemyPos);
            else
                normalOperationGen("Attack",id,enemyPos);
            return;
        }
        if ((myTower[MyHero::defenceTower].TowerEvaluate()<TowerDanger)&&(!alone)) {
            Pos wildPos(Pos(10000,10000)); int wildrange;
            for (int i=0; i<totWild; i++)
                if ((dis2(wild[i].pos,pos)<dis2(wildPos,pos))&&(dis2(wild[i].pos,pos)<=ViewRange)&&(!wild[i].buff[7])&&(!(wild[i].name=="Roshan")))
                    wildPos=wild[i].pos, wildrange=wild[i].range;
            if (wildPos!=Pos(10000,10000)) {
                if (dis2(pos,wildPos)>range) (wildrange<=10)?fastDisplace(wildPos,wildrange):fastDisplace(wildPos); else
                    normalOperationGen("Attack",id,wildPos);
                return;
            }
            Pos t(Pos(10000,10000));
            for (int i=0; i<3; i++)
                if (WildList::wildrevtime[WildList::towerwild[player][defenceTower][i].x][WildList::towerwild[player][defenceTower][i].y]==0) {
                    t=WildList::towerwild[player][defenceTower][i];
                    break;
                }
            if (t!=Pos(10000,10000)) {
                Pos newaim=WildList::wildpos[t.x][t.y];
                fastDisplace(newaim);
            }
        } else fastDisplace(aim);
    }

    if (status == 3) {
        if (dis2(pos,aim)>300) hinderDisplace(aim); else
        if (dis2(pos,aim)>ViewRange) fastDisplace(aim); else {
            if (localstatus == 2) {
                int inRainEnemy=0;
                for (int i=0; i<=heHeroKnown; i++)
                    if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=144))
                        ++inRainEnemy;
                if ((inRainEnemy>=2)&&(U->canUseSkill(9))&&(arrowRainUsed == 0)) {
                    Pos ideal; int maxcanattack=-1;
                    for (int x=pos.x-12; x<=pos.x+12; x++)
                        for (int y=pos.y-12; y<=pos.y+12; y++)
                            if (checkPos(Pos(x,y))&&(dis2(Pos(x,y),pos)<=100)) {
                                int nowcanattack=0;
                                for (int j=0; j<heHeroKnown; j++)
                                    if ((heHeroInsight[j])&&(dis2(Pos(x,y),heHero[j].pos)<=36))
                                        ++nowcanattack;
                                if (nowcanattack>maxcanattack)
                                    maxcanattack=nowcanattack,
                                    ideal=Pos(x,y);
                            }
                    if (maxcanattack>=2) {
                        if (dis2(ideal,pos)>100) fastDisplace(ideal); else {
                            normalOperationGen("ArrowsRain",id,ideal);
                            arrowRainUsed=5;
                            return;
                        }
                    }
                }
                Pos enemyPos(Pos(10000,10000)); int enemyrange;
                for (int i=0; i<=heHeroKnown; i++)
                    if ((heHeroInsight[i])&&(dis2(pos,heHero[i].pos)<=dis2(pos,enemyPos))&&(dis2(pos,heHero[i].pos)<=ViewRange))
                        enemyPos=heHero[i].pos, enemyrange=heHero[i].range;
                if (enemyPos!=Pos(10000,10000)) {
                    if (U->canUseSkill(11))
                        normalOperationGen("PowerUp",id);
                    else if (dis2(pos,enemyPos)>range)
                        (enemyrange<=10)?fastDisplace(enemyPos,enemyrange):fastDisplace(enemyPos);
                    else
                        normalOperationGen("Attack",id,enemyPos);
                    return;
                }
            }
            if ((dis2(pos,aim)>range)||(abs(Map->height[pos.x][pos.y]-Map->height[aim.x][aim.y])>=2)) fastDisplace(aim); else {
                if (Info->findUnitByPos(aim)==0) {
                    for (int i=0; i<2; i++)
                        if ((aim==heTowerPos[i])&&(!heTowerDead[i]))
                            heTowerDead[i]=1,heTowerTot--;
                    return;
                }
                if (U->canUseSkill(11))
                    normalOperationGen("PowerUp",id);
                else
                    normalOperationGen("Attack",id,aim);
            }
        }
    }
}

bool yq::MyHero::fastDisplace(Pos dest, int nearforbid) {
    if (!(U->canMove())) return 0;
    while ((direct.step[dest.x][dest.y] == -1) && (dest.y < Map_size - 1)) dest.y++;
    if (direct.step[dest.x][dest.y] == -1) return 0;
    Pos nowp = dest;
    vector<Pos> trace;
    trace.clear();
    bool toonear=1;
    while (nowp != pos) {
        if (dis2(nowp,dest)>nearforbid) toonear=0;
        if ((direct.step[nowp.x][nowp.y] <= 15)&&(!toonear)) trace.push_back(nowp);
        nowp = direct.pre[nowp.x][nowp.y];
    }
    trace.push_back(pos);
    Pos tmp;
    for (int i = 0; i < trace.size() / 2; i++)
        tmp = trace[i], trace[i] = trace[trace.size() - i - 1], trace[trace.size() - i - 1] = tmp;
    Operation nowOp;
    nowOp.id = id;
    nowOp.type = "Move";
    nowOp.targets = trace;
    Cmd->cmds.push_back(nowOp);
    return 1;
}

bool yq::MyHero::hinderDisplace(Pos dest, int nearforbid) {
    if (!(U->canMove())) return 0;
    while ((direct.step[dest.x][dest.y] == -1) && (dest.y < Map_size - 1)) dest.y++;
    if (direct.step[dest.x][dest.y] == -1) return 0;
    Pos nowp = dest;
    vector<Pos> trace;
    trace.clear();
    bool toonear=1;
    while (nowp != pos) {
        if (dis2(nowp,dest)>nearforbid) toonear=0;
        if ((avoid.step[nowp.x][nowp.y] <= 15)&&(!toonear)) trace.push_back(nowp);
        nowp = avoid.pre[nowp.x][nowp.y];
    }
    trace.push_back(pos);
    Pos tmp;
    for (int i = 0; i < trace.size() / 2; i++)
        tmp = trace[i], trace[i] = trace[trace.size() - i - 1], trace[trace.size() - i - 1] = tmp;
    Operation nowOp;
    nowOp.id = id;
    nowOp.type = "Move";
    nowOp.targets = trace;
    Cmd->cmds.push_back(nowOp);
    return 1;
}

//------------------------���߳�ʽ���F�^------------------
void yq::normalOperationGen(const string &type, const int &id, const Pos &_pos) {
    Operation nowop;
    nowop.type = type;
    nowop.id = id;
    if ((type == "Attack") || (type == "Charge") || (type == "PiercingArrow") ||
            (type == "ArrowsRain") || (type == "FlyingBlade") || (type == "Blink"))
        nowop.targets.push_back(_pos);
    Cmd->cmds.push_back(nowop);
}

bool yq::stringcmp(const char _a[], const char _b[]) {
    return (strcmp(_a, _b) == 0);
}

//Copyright

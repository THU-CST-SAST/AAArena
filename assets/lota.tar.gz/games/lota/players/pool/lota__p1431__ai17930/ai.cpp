#include "sdk.h"
#include "const.h"
#include <cmath>
#include <ctime>

//五刺客偷塔
//2015-5-16

#define PI 3.1416
const PMap* MAP;
const PPlayerInfo* INFO;

typedef vector<const PUnit*> PUnits;

PUnits oursTrj, enemyTrj, team0Trj, team1Trj, wildTrj, nearByTrj, towerTrj, enemyHeroTrj, towerLeft; //几个单位容器

static vector<Pos> blocksTrj, friendTowerPosTrj, enemyTowerPosTrj; //几个需要绕开的位置
vector<Pos> targetTrj;

bool isReturnToSpringTrj[100]; //单位是否正在返回水泉(若是则不执行其他任务)
bool isReadyToMfDragonTrj = false; //单位是否准备攻击大龙
bool isReadyToDestroyTowerTrj = false;
bool isAssassinUpTrj[100]; //刺客是否正在高台上
bool isFinalTrj = false; //判断是否进行决战
bool isAttackingTowerTrj = false; //判断是否正在推塔
bool isTimerStartTrj = false;

Pos ourSpringPosTrj; //我方水泉地点
Pos monsterPosTrj[2]; //打野地点
Pos destroyTowerReadyPosTrj[2]; //团体推塔等待地点
Pos spyReadyPosTrj, spyUpPosTrj; //刺客上台地点
Pos spyReadyPosTrj2, spyDownPosTrj; //刺客下台地点

int mfDragonLevelTrj = 0; //大于等于4个英雄到达此等级时开始攻击大龙
int destroyTowerLevelTrj = 1; //大于等于4个英雄到达此等级时开始攻击塔
int towerTodestroyTrj = 0; //准备推的塔
int dragonTimerTrj = 0; //mf大龙复活计时器
int wolfTimerTrj = 0; //mf狼复活计时器
int flyingBladeUsedTrj = 0; //使用飞刀的次数
int waitForReviveTrj = 0; //若怪物仍在复活中则等待5回合

void init(const PPlayerInfo &info); //第0回合初始化
void refresh(const PPlayerInfo &info); //每回合刷新数据
void chooseHero(const PPlayerInfo &info, PCommand &cmd); //第0回合选择英雄
void levelUp(const PUnit* a, PCommand &cmd); //单位a升级操作
bool escape(const PUnit* a, const PPlayerInfo &info, PCommand &cmd); //逃跑
void escapeWhenWeak(const PUnit* a, const PPlayerInfo &info, PCommand &cmd, int arg); //在虚弱时逃跑
void escapeInDirection(const PUnit* a, PCommand &cmd, double angle); //按照特定方向逃跑
void move(const PUnit* a, const Pos pos, PCommand &cmd); //英雄移动
void attack(const PUnit* a, const PUnit* b, PCommand &cmd); //对一单位发起进攻(允许使用技能)
void attack(const PUnit* a, Pos b, const PPlayerInfo &info, PCommand &cmd); //对某一地点的单位发起进攻(一般为防御塔)
bool useSkill(const PUnit* a, const PUnit* b, string skillName, PCommand &cmd); //使用指向性技能
bool useSkill(const PUnit* a, Pos b, string skillName, PCommand &cmd); //使用地点指向性技能
bool useSkill(const PUnit* a, string skillName, PCommand &cmd); //使用非指向性技能
const PUnit* belongs(int id, PUnits& units); //找出unit组成的vector中包含指定id的unit
void addEnemyInSight(const PUnit* a); //将看到的敌方英雄加入容器中
void OperateMf(const PUnit* a, const PPlayerInfo &info, PCommand &cmd); //第一阶段刺客打野直到有四个英雄达到2级
void OperateRush(const PUnit* a, const PPlayerInfo &info, PCommand &cmd); //第二阶段刺客推掉对方二塔
void OperateSpy(const PUnit* a, const PPlayerInfo &info, PCommand &cmd); //第三阶段刺客进行侦查
void OperateFinal(const PUnit* a, const PPlayerInfo &info, PCommand &cmd); //第四阶段刺客推掉对方一塔

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd) //ai整体操作
{
	cmd.cmds.clear();
	MAP = &map;
	INFO = &info;
	if (info.round == 0) //第0回合
	{
		init(info); //初始化
		chooseHero(info, cmd); //选择英雄
	} else if(!isReadyToDestroyTowerTrj) //正式回合
	{
		int highLevelHeroNum = 0;
		int mfDragonHeroNum = 0;
		refresh(info); //每回合刷新
		info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
		for(int i = 0; i < oursTrj.size(); ++i) //所有己方单位
		{
			const PUnit* ptr = oursTrj[i];
			if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
			{
				//已筛选出所有己方英雄
				if(ptr->level >= destroyTowerLevelTrj)
					highLevelHeroNum++;
				if(ptr->level >= mfDragonLevelTrj)
					mfDragonHeroNum++;
				if(dis2(ptr->pos, ourSpringPosTrj) <= 16)
					isAssassinUpTrj[ptr->id] = false;
				if(destroyTowerLevelTrj == 1)
					OperateMf(ptr, info, cmd);
				else
					OperateSpy(ptr, info, cmd);
			}
		}
		if(highLevelHeroNum >= 4) //当有大于等于4个英雄等级达到预置等级时可以开始推塔
			isReadyToDestroyTowerTrj = true;
		if(mfDragonHeroNum >= 4 && (isTimerStartTrj == false || dragonTimerTrj >= Dragon_reviving_time))
			isReadyToMfDragonTrj = true;
	} else {
		//开始推塔
		refresh(info); //每回合刷新
		info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
		for(int i = 0; i < oursTrj.size(); ++i)
		{
			const PUnit* ptr = oursTrj[i];
			if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
			{
				if(!isFinalTrj)
					OperateRush(ptr, info, cmd);
				else
					OperateFinal(ptr, info, cmd);
			}
		}
	}
}

void init(const PPlayerInfo &info) //第0回合初始化
{
	//获得敌我防御塔位置信息
	if(info.camp == 0)
	{
		friendTowerPosTrj.push_back(Player0_tower_pos[1]);
		friendTowerPosTrj.push_back(Player0_tower_pos[0]);
		enemyTowerPosTrj.push_back(Player1_tower_pos[1]);
		enemyTowerPosTrj.push_back(Player1_tower_pos[0]);
		ourSpringPosTrj = Player0_spring_pos[0];
		monsterPosTrj[0] = Dragon_pos[0];
		monsterPosTrj[1] = Dog_pos[1];
		spyReadyPosTrj = Pos(49, 57);
		spyUpPosTrj = Bow_pos[1];
		spyReadyPosTrj2 = Pos(57, 45);
		spyDownPosTrj = Pos(60, 43);
	} else {
		friendTowerPosTrj.push_back(Player1_tower_pos[1]);
		friendTowerPosTrj.push_back(Player1_tower_pos[0]);
		enemyTowerPosTrj.push_back(Player0_tower_pos[1]);
		enemyTowerPosTrj.push_back(Player0_tower_pos[0]);
		ourSpringPosTrj = Player1_spring_pos[0];
		monsterPosTrj[0] = Dragon_pos[1];
		monsterPosTrj[1] = Dog_pos[5];
		spyReadyPosTrj = Pos(101, 93);
		spyUpPosTrj = Bow_pos[4];
		spyReadyPosTrj2 = Pos(93, 105);
		spyDownPosTrj = Pos(90, 107);
	}
	//变量初始化
	for(int i = 0; i < 100; ++i)
	{
		isReturnToSpringTrj[i] = false;
		isAssassinUpTrj[i] = false;
	}
}

void refresh(const PPlayerInfo &info) //每回合刷新数据
{
	//回满血的继续作战
	double hpRate = 0;
	info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
	for(int i = 0; i < oursTrj.size(); ++i)
	{
		const PUnit* ptr = oursTrj[i];
		if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
		{
			hpRate = (double)((*ptr)["Hp"]->val[0]) / (double)((*ptr)["Hp"]->val[1]);
			if(hpRate >= 0.9)
				isReturnToSpringTrj[ptr->id] = false;
		}
	}
	//刷新障碍信息
	blocksTrj.clear();
	//设置所有可见单位所在位置不可经过
	info.findUnitByPlayer(0, team0Trj);
	info.findUnitByPlayer(1, team1Trj);
	info.findUnitByPlayer(2, wildTrj);
	for(int i = 0; i < team0Trj.size(); ++i)
		blocksTrj.push_back(team0Trj[i]->pos);
	for(int i = 0; i < team1Trj.size(); ++i)
		blocksTrj.push_back(team1Trj[i]->pos);
	for(int i = 0; i < wildTrj.size(); ++i)
		blocksTrj.push_back(wildTrj[i]->pos);
	//设置野怪复活点不可经过
	for(int i = 0; i < 8; ++i)
		blocksTrj.push_back(Dog_pos[i]);
	for(int i = 0; i < 6; ++i)
		blocksTrj.push_back(Bow_pos[i]);
	for(int i = 0; i < 4; ++i)
		blocksTrj.push_back(Wolf_pos[i]);
	for(int i = 0; i < 2; ++i)
		blocksTrj.push_back(StoneMan_pos[i]);
	for(int i = 0; i < 2; ++i)
		blocksTrj.push_back(Dragon_pos[i]);
	//设置敌方水泉附近不可经过
	if(info.camp == 0)
	{
		for(int i = Player1_spring_pos[0].x - 8; i < Player1_spring_pos[0].x + 8; ++i)
			for(int j = Player1_spring_pos[0].y - 8; j < Player1_spring_pos[0].y + 8; ++j)
				if(dis2(Pos(i, j), Player1_spring_pos[0]) <= Spring_range)
					blocksTrj.push_back(Pos(i, j));
	} else {
		for(int i = Player0_spring_pos[0].x - 8; i < Player0_spring_pos[0].x + 8; ++i)
			for(int j = Player0_spring_pos[0].y - 8; j < Player0_spring_pos[0].y + 8; ++j)
				if(dis2(Pos(i, j), Player0_spring_pos[0]) <= Spring_range)
					blocksTrj.push_back(Pos(i, j));
	}
	//前期敌方防御塔附近不可经过
	if(!isReadyToDestroyTowerTrj && destroyTowerLevelTrj == 1)
		for(int i = 0; i < enemyTowerPosTrj.size(); ++i)
			for(int j = enemyTowerPosTrj[i].x - 10; j < enemyTowerPosTrj[i].x + 10; ++j)
				for(int k = enemyTowerPosTrj[i].y - 10; k < enemyTowerPosTrj[i].y + 10; ++k)
					if(dis2(Pos(j, k), enemyTowerPosTrj[i]) <= Tower_range)
						blocksTrj.push_back(Pos(j, k));
	//wolf附近不可经过
	for(int i = 0; i < 4; ++i)
		for(int j = Wolf_pos[i].x - 5; j < Wolf_pos[i].x + 5; ++j)
			for(int k = Wolf_pos[i].y - 5; k < Wolf_pos[i].y + 5; ++k)
				if(dis2(Pos(j, k), Wolf_pos[i]) <= Wolf_range)
					blocksTrj.push_back(Pos(j, k));
	//roshan附近不可经过
	for(int i = Roshan_pos[0].x - 3; i < Roshan_pos[0].x + 3; ++i)
		for(int j = Roshan_pos[0].y - 3; j < Roshan_pos[0].y + 3; ++j)
			if(dis2(Pos(i, j), Roshan_pos[0]) <= 9)
				blocksTrj.push_back(Pos(i, j));
	//设置可以攻击大龙
	if(isReadyToMfDragonTrj)
	{
		if(info.camp == 0)
			monsterPosTrj[0] = Dragon_pos[0];
		else
			monsterPosTrj[0] = Dragon_pos[1];
	} else {
		if(info.camp == 0)
			monsterPosTrj[0] = Dog_pos[0];
		else
			monsterPosTrj[0] = Dog_pos[4];
	}
	if(isTimerStartTrj)
		dragonTimerTrj++;
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //第0回合选择英雄
{
	for(int i = 0; i < info.units.size(); ++i)
	{
		Operation op;
		op.type = "ChooseAssassin";
		op.targets.clear();
		op.id=info.units[i].id;
		cmd.cmds.push_back(op);
	}
}

void levelUp(const PUnit* a, PCommand &cmd) //单位a升级操作
{
	vector<string> level_ups;
	string skillUp;
	for (int i = 0; i < a->skills.size(); ++i)
	{
		const PSkill* ptr = &a->skills[i];
		if (ptr->isLU() && a->canUseSkill(ptr->typeId)) //选择可以升级的技能
			level_ups.push_back(ptr->name);
	}
	Operation op;
	op.id = a->id;
	skillUp = "YellowPoint";
	if(a->level == 0 || a->level == 2 || a->level == 3)
	{
		for(int j = 0; j < level_ups.size(); ++j)
			if(level_ups[j] == "HideLU")
				skillUp = "HideLU";
	}else if(a->level == 1)
	{
		for(int j = 0; j < level_ups.size(); ++j)
			if(level_ups[j] == "BlinkLU")
				skillUp = "BlinkLU";
	}else if(a->level >= 4)
	{
		for(int j = 0; j < level_ups.size(); ++j)
			if(level_ups[j] == "FBLU")
				skillUp = "FBLU";
	}
	op.type = skillUp; //升级技能
	cmd.cmds.push_back(op);
}

bool escape(const PUnit* a, const PPlayerInfo &info, PCommand &cmd) //逃跑
{
	//判断是否正在逃向水泉的路上
	if(isReturnToSpringTrj[a->id])
	{
		escapeWhenWeak(a, info, cmd, 0);
		return true;
	}
	double hpRate = (double)((*a)["Hp"]->val[0]) / (double)((*a)["Hp"]->val[1]);
	if(hpRate <= 0.2) //血量不足五分之一时进行判定
	{
		//判断视野是否有敌人
		bool isSafe = true;
		info.findUnitInArea(a->pos, a->view, nearByTrj); //寻找附近的人
		for(int i = 0; i < nearByTrj.size(); ++i)
		{
			const PUnit *unitInSight = nearByTrj[i];
			if(unitInSight->camp == 1 - info.camp) //判断是否为敌人
			{
				isSafe = false;
			}
		}
		if(!isSafe)
		{
			//刺客优先使用隐形
			bool isHide = false;
			if(useSkill(a, string("Hide"), cmd))
				isHide = true;
			if(!isHide)
				escapeWhenWeak(a, info, cmd, 1); //根据敌人方向逃跑
		} else {
			//安全但血量过低时回水泉
			isReturnToSpringTrj[a->id] = true;
			escapeWhenWeak(a, info, cmd, 0);
		}
		return true;
	}
	return false;
}

void escapeWhenWeak(const PUnit* a, const PPlayerInfo &info, PCommand &cmd, int arg) //在虚弱时逃跑
{
	//arg:0 无脑返回水泉   arg:1 根据敌人方向逃跑
	if(arg == 0)
	{
		if(info.camp == 0)
			move(a, Player0_spring_pos[0], cmd);
		else
			move(a, Player1_spring_pos[0], cmd);
	}
	if(arg == 1)
	{
		int xEscape = 0, yEscape = 0;
		double escapeAngle = 0;
		for(int i = 0; i < nearByTrj.size(); ++i)
		{
			const PUnit *unitInSight = nearByTrj[i];
			if(unitInSight->camp != info.camp) //判断是否为敌人
			{
				if(a->pos.x != unitInSight->pos.x)
					xEscape += a->pos.x - unitInSight->pos.x;
				if(a->pos.y != unitInSight->pos.y)
					yEscape += a->pos.y - unitInSight->pos.y;
			}
		}
		if(xEscape != 0 && yEscape != 0)
		{
			escapeAngle = atan(yEscape / xEscape);
			if(xEscape > 0)
			{
				if(escapeAngle < 0)
					escapeAngle += 2 * PI;
			} else {
				escapeAngle += PI;
			}
			escapeInDirection(a, cmd, escapeAngle);
		} else {
			if(xEscape == 0)
			{
				if(yEscape > 0)
					escapeInDirection(a, cmd, PI / 2);
				else if(yEscape < 0)
					escapeInDirection(a, cmd, PI * 3 / 2);
			}
			else if(xEscape > 0)
			{
				escapeInDirection(a, cmd, 0);
			} else {
				escapeInDirection(a, cmd, PI);
			}
		}
	}
}

void escapeInDirection(const PUnit* a, PCommand &cmd, double angle) //按照特定方向逃跑
{
	Pos escapePos;
	if(angle <= PI / 8 || angle > PI * 15 / 8)
	{
		escapePos.x = 149;
		escapePos.y = 75;
	}
	if(angle > PI / 8 && angle <= PI * 3 / 8)
	{
		escapePos.x = 149;
		escapePos.y = 149;
	}
	if(angle > PI * 3 / 8 && angle <= PI * 5 / 8)
	{
		escapePos.x = 75;
		escapePos.y = 149;
	}
	if(angle > PI * 5 / 8 && angle <= PI * 7 / 8)
	{
		escapePos.x = 1;
		escapePos.y = 149;
	}
	if(angle > PI * 7 / 8 && angle <= PI * 9 / 8)
	{
		escapePos.x = 1;
		escapePos.y = 75;
	}
	if(angle > PI * 9 / 8 && angle <= PI * 11 / 8)
	{
		escapePos.x = 1;
		escapePos.y = 1;
	}
	if(angle > PI * 11 / 8 && angle <= PI * 13 / 8)
	{
		escapePos.x = 75;
		escapePos.y = 1;
	}
	if(angle > PI * 13 / 8 && angle <= PI * 15 / 8)
	{
		escapePos.x = 149;
		escapePos.y = 1;
	}
	move(a, escapePos, cmd);
}

void move(const PUnit* a, const Pos pos, PCommand &cmd) //英雄移动
{
	Operation op;
	op.id = a->id;
	op.type = "Move";
	findShortestPath(*MAP, a->pos, pos, blocksTrj, op.targets); //向目标地点移动
	cmd.cmds.push_back(op);
}

void attack(const PUnit* a, const PUnit* b, PCommand &cmd) //对一单位发起进攻(允许使用技能)
{
	//优先使用技能
	bool isUseSkill = false;
	if(string(a->name) == string("Assassin"))
	{
		if((b->name == string("Dragon") && !b->findBuff("Reviving")) || b->camp == 1 - a->camp
			|| (a->mp >= 160 && b->hp >= 150 && flyingBladeUsedTrj <= 3) || b->name == string("Wolf"))
		{
			if(useSkill(a, b, string("FlyingBlade"), cmd))
			{
				isUseSkill = true;
				if(b->name == string("Dog") || b->name == string("Bow"))
					flyingBladeUsedTrj++;
			}
		}
	}
	if(!isUseSkill)
	{
		Operation op;
		op.id = a->id;
		if (dis2(a->pos, b->pos) <= a->range) //判断单位b是否在攻击范围内
		{
			op.type = "Attack";
			op.targets.push_back(b->pos);
			cmd.cmds.push_back(op);
		} else {
			op.type = "Move";
			findShortestPath(*MAP, a->pos, b->pos, blocksTrj, op.targets); //向目标地点移动
			cmd.cmds.push_back(op);
		}
	}
}

void attack(const PUnit* a, Pos b, const PPlayerInfo &info, PCommand &cmd) //对某一地点的单位发起进攻(一般为防御塔)
{
	Operation op;
	op.id = a->id;
	if (dis2(a->pos, b) <= a->range) //判断位置b是否在攻击范围内
	{
		op.type = "Attack";
		op.targets.push_back(b);
		cmd.cmds.push_back(op);
		//一座塔被摧毁时转换目标
		bool isTowerExist = false;
		info.findUnitInArea(a->pos, a->range, towerTrj);
		for(int i = 0; i < towerTrj.size(); ++i)
		{
			if(string(towerTrj[i]->name) == "Tower")
				isTowerExist = true;
		}
		if(!isTowerExist)
		{
			isReadyToDestroyTowerTrj = false;
			destroyTowerLevelTrj = 9;
			towerTodestroyTrj = 1;
		}
	} else {
		op.type = "Move";
		findShortestPath(*MAP, a->pos, b, blocksTrj, op.targets); //向目标地点移动
		cmd.cmds.push_back(op);
	}
}

bool useSkill(const PUnit* a, const PUnit* b, string skillName, PCommand &cmd) //使用指向性技能
{
	for (int i = 0; i < a->skills.size(); ++i)
	{
		const PSkill* ptr = &a->skills[i];
		if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
		{
			if(ptr->needTarget() && string(ptr->name) == skillName)
			{
				PUnits ptr_foe;
				infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe);
				if (belongs(b->id, ptr_foe))
				{
					Operation op;
					op.id = a->id;
					op.type = ptr->name;
					op.targets.push_back(b->pos);
					cmd.cmds.push_back(op);
					return true;
				}
			}
		}
	}
	return false;
}

bool useSkill(const PUnit* a, Pos b, string skillName, PCommand &cmd) //使用地点指向性技能
{
	if(skillName == string("FlyingBlade") && dis2(a->pos, b) > FlyingBlade_range)
		return false;
	if(skillName == string("Blink") && dis2(a->pos, b) > Blink_range)
		return false;
	for (int i = 0; i < a->skills.size(); ++i)
	{
		const PSkill* ptr = &a->skills[i];
		if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId) && string(ptr->name) == skillName)
		{
			Operation op;
			op.id = a->id;
			op.type = ptr->name;
			op.targets.push_back(b);
			cmd.cmds.push_back(op);
			return true;
		}
	}
	return false;
}

bool useSkill(const PUnit* a, string skillName, PCommand &cmd) //使用非指向性技能
{
	for (int i = 0; i < a->skills.size(); ++i)
	{
		const PSkill* ptr = &a->skills[i];
		if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
		{
			if(!ptr->needTarget() && string(ptr->name) == skillName)
			{
				Operation op;
				op.id = a->id;
				op.type = ptr->name;
				cmd.cmds.push_back(op);
				return true;
			}
		}
	}
	return false;
}

const PUnit* belongs(int id, PUnits& units) //找出unit组成的vector中包含指定id的unit
{
	for (int i = 0; i < units.size(); ++i)
		if (units[i]->id == id)
			return units[i];
	return NULL;
}

void addEnemyInSight(const PUnit* a) //将看到的敌方英雄加入容器中
{
	bool isExist = false;
	for(int i = 0; i < enemyHeroTrj.size(); ++i)
	{
		if(enemyHeroTrj[i]->id == a->id)
			isExist = true;
	}
	if(!isExist)
	{
		enemyHeroTrj.push_back(a);
	}
}

void OperateMf(const PUnit* a, const PPlayerInfo &info, PCommand &cmd) //第一阶段刺客打野直到有四个英雄达到2级
{
	if(!escape(a, info, cmd))
	{
		if((*a)["Exp"]->val[3]) //升级技能
		{
			levelUp(a, cmd);
		} else {
			//获得视野内的敌人
			info.findUnitInArea(a->pos, a->view, enemyTrj);
			for(int i = 0; i < enemyTrj.size(); ++i)
			{
				if(enemyTrj[i]->camp != 1 - info.camp || enemyTrj[i]->name == string("Tower"))
				{
					enemyTrj.erase(enemyTrj.begin() + i);
					--i;
				}
			}
			if(enemyTrj.size())
			{
				if(!useSkill(a, enemyTrj[0], string("FlyingBlade"), cmd) && !useSkill(a, string("Hide"), cmd))
					attack(a, enemyTrj[0], cmd);
			} else {
				//统计准备好的刺客数量
				int preparedNum = 0;
				info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
				for(int i = 0; i < oursTrj.size(); ++i) //所有己方单位
				{
					const PUnit* ptr = oursTrj[i];
					if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
					{
						if(dis2(ptr->pos, monsterPosTrj[0]) <= 125)
							preparedNum++;
					}
				}
				if(preparedNum >= 4)
				{
					info.findUnitInArea(a->pos, a->view, nearByTrj);
					for(int i = 0; i < nearByTrj.size(); ++i)
					{
						if(nearByTrj[i]->name != string("Dragon"))
						{
							nearByTrj.erase(nearByTrj.begin() + i);
							--i;
						}
					}
					if(nearByTrj.size())
					{
						if(nearByTrj.size() == 1 && nearByTrj[0]->findBuff("Reviving"))
						{
							if(waitForReviveTrj >= 10 || nearByTrj[0]->name == string("Dragon"))
							{
								waitForReviveTrj = 0;
								flyingBladeUsedTrj = 0;
								if(nearByTrj[0]->name == string("Dragon"))
								{
									isReadyToMfDragonTrj = false;
									isTimerStartTrj = true;
								}
							} else {
								waitForReviveTrj++;
							}
						}
						bool isFlyingBlade = false;
						if(nearByTrj[0]->name == string("Dragon"))
						{
							if(useSkill(a,  string("Hide"), cmd))
								isFlyingBlade = true;
						}
						if(!isFlyingBlade)
							attack(a, nearByTrj[0], cmd);
					} else {
						move(a, nearByTrj[0]->pos, cmd);
					}
				} else {
					if(dis2(a->pos, monsterPosTrj[0]) > 81)
						move(a, monsterPosTrj[0], cmd);
				}
			}
		}
	}
}

void OperateRush(const PUnit* a, const PPlayerInfo &info, PCommand &cmd) //第二阶段刺客推掉对方二塔
{
	if((*a)["Exp"]->val[3]) //升级技能
	{
		levelUp(a, cmd);
	} else {
		//统计准备好的刺客数量
		int preparedNum = 0;
		info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
		for(int i = 0; i < oursTrj.size(); ++i) //所有己方单位
		{
			const PUnit* ptr = oursTrj[i];
			if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
			{
				if(dis2(ptr->pos, enemyTowerPosTrj[towerTodestroyTrj]) <= 225)
					preparedNum++;
			}
		}
		if(preparedNum < 4)
		{
			//未到达准备地点则进行移动
			if(dis2(a->pos, enemyTowerPosTrj[towerTodestroyTrj]) > 200)
			{
				if(!useSkill(a, string("Hide"), cmd))
					move(a, enemyTowerPosTrj[towerTodestroyTrj], cmd);
			}
		} else {
			attack(a, enemyTowerPosTrj[towerTodestroyTrj], info, cmd);
		}
	}
}

void OperateSpy(const PUnit* a, const PPlayerInfo &info, PCommand &cmd) //第三阶段刺客依次进行侦查
{
	if((*a)["Exp"]->val[3]) //升级技能
	{
		levelUp(a, cmd);
	} else {
		if(!isAssassinUpTrj[a->id])
		{
			//刺客不在台上
			if(dis2(a->pos, spyReadyPosTrj) > 1)
			{
				move(a, spyReadyPosTrj, cmd);
			} else {
				if(useSkill(a, spyUpPosTrj, string("Blink"), cmd))
						isAssassinUpTrj[a->id] = true;
			}
		} else {
			//刺客在台上
			bool isAttackHero = false;
			info.findUnitByPlayer(1 - info.camp, enemyHeroTrj);
			if(enemyHeroTrj.size())
			{
				findShortestPath(*MAP, a->pos, enemyHeroTrj[0]->pos, targetTrj);
				if(targetTrj[0].x > 0 && targetTrj[0].y > 0)
				{
					attack(a, enemyHeroTrj[0], cmd);
					isAttackHero = true;
				}
			}
			if(!isAttackHero)
			{
				info.findUnitInArea(a->pos, a->view, enemyTrj);
				for(int i = 0; i < enemyTrj.size(); ++i)
				{
					if(enemyTrj[i]->name != string("Bow") && enemyTrj[i]->name != string("Assassin"))
					{
						enemyTrj.erase(enemyTrj.begin() + i);
						--i;
					}
				}
				if(enemyTrj.size())
				{
					attack(a, enemyTrj[0], cmd);
				}
				enemyHeroTrj.clear();
				info.findUnitInArea(friendTowerPosTrj[0], Tower_view, enemyTrj);
				for(int i = 0; i < enemyTrj.size(); ++i)
					if(enemyTrj[i]->camp == 1 - info.camp)
						addEnemyInSight(enemyTrj[i]);
				info.findUnitInArea(friendTowerPosTrj[1], Tower_view, enemyTrj);
				for(int i = 0; i < enemyTrj.size(); ++i)
					if(enemyTrj[i]->camp == 1 - info.camp)
						addEnemyInSight(enemyTrj[i]);
				int towerleft = 0;
				info.findUnitByPlayer(info.camp, towerLeft);
				for(int i = 0; i < towerLeft.size(); ++i)
					if(towerLeft[i]->name == string("Tower"))
						towerleft++;
				if(enemyHeroTrj.size() >= 3 || towerleft != 2)
				{
					isFinalTrj = true;
					isReadyToDestroyTowerTrj = true;
				}
			}
			
		}
	}
}

void OperateFinal(const PUnit* a, const PPlayerInfo &info, PCommand &cmd) //第四阶段刺客推掉对方一塔
{
	if((*a)["Exp"]->val[3]) //升级技能
	{
		levelUp(a, cmd);
	} else {
		//统计准备好的刺客数量
		int preparedNum = 0;
		info.findUnitByPlayer(info.player, oursTrj); //寻找所有本方单位
		for(int i = 0; i < oursTrj.size(); ++i) //所有己方单位
		{
			const PUnit* ptr = oursTrj[i];
			if(ptr->isHero() && string(ptr->name) != string("Tower") && string(ptr->name) != string("Spring"))
			{
				if(dis2(ptr->pos, enemyTowerPosTrj[towerTodestroyTrj]) <= 225)
					preparedNum++;
			}
		}
		if(preparedNum < 4 && !isAttackingTowerTrj)
		{
			//未到达准备地点则进行移动
			if(dis2(a->pos, enemyTowerPosTrj[towerTodestroyTrj]) > 200)
			{
				if(isAssassinUpTrj[a->id])
				{
					//台上刺客先下台
					if(dis2(a->pos, spyReadyPosTrj2) > 1)
					{
						move(a, spyReadyPosTrj2, cmd);
					} else {
						if(!a->findBuff("Hided") && a->canUseSkill(13))
						{
							useSkill(a, string("Hide"), cmd);
						} else {
							if(useSkill(a, spyDownPosTrj, string("Blink"), cmd))
							{
								isAssassinUpTrj[a->id] = false;
							}
						}
					}
				} else {
					move(a, enemyTowerPosTrj[towerTodestroyTrj], cmd);
				}
			}
		} else {
			isAttackingTowerTrj = true;
			if(preparedNum == 0)
				isAttackingTowerTrj = false;
			attack(a, enemyTowerPosTrj[towerTodestroyTrj], info, cmd);
		}
	}
}

//end

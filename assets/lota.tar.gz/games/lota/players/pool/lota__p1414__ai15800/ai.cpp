#include "sdk.h"
//global variable
#define MAXID  100
std::vector<const PUnit*> ours,nearBy;
int fixedId[MAXID];
static bool towerDes[2];
const Pos *AtkTower, *DefenseTow;
const PMap *pMap;
const PCommand *Cmd;
const PPlayerInfo *Info;
static vector<Pos> blocks;
Pos monster[3];
Pos *ptr;

#define MAXDISTANCE	 9999
std::vector<const PUnit*> MonsterUnit;		//Ӧ���Ѿ���ȡ�˹�������
std::vector<const PUnit*> EnemyUnit;		//ʱ��׼����ȡ�˵����б�
std::vector<Pos> MonsterPos;				//��ʼ����λ��

void InitLoop(const PPlayerInfo &info, std::vector<Pos> &_monsterPos , std::vector<const PUnit*> &_monsterList);//����ѭ����ֵĹ���λ�ú͹��ﵥԪ
void CounterAttack_LoopDenfence(const PPlayerInfo &info, Operation &op, const PUnit &t);

bool in_attack_range(const PUnit &, const Pos&);

void initMyHero(Operation &, const PPlayerInfo &, PCommand &); 

void HeroNormalFight(Operation &, const PPlayerInfo &, const PUnit &, bool &);

void LowLevelFight(Operation &, const PUnit &, Pos* );

void HighLevelFight(Operation &, const PUnit &);

const PUnit* belongs(int , vector<const PUnit*>&);

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	//������ұ��id
    int player = info.player;
	AtkTower = player ?  Player0_tower_pos : Player1_tower_pos;
	DefenseTow = player ?  Player1_tower_pos : Player0_tower_pos;
	for (int i = 0; i < 8; i++)
		blocks.push_back( Dog_pos[i]);
	for ( int i = 0; i < 4; i++)
		blocks.push_back( Wolf_pos[i]);
	for (int i = 0; i < 2; i++)
		blocks.push_back(Dragon_pos[i]);
	pMap = &map;
	Info = &info;
	Cmd = &cmd;
    cmd.cmds.clear();
	//��ʼ��Ӣ��
    if (info.round == 0)
    {
        Operation op;
		for (int i = 0; i < MAXID; i++)
			fixedId[i] = 0;
		ptr = monster;
		monster[0] = info.player ? Wolf_pos[2] : Wolf_pos[0];
		monster[1] = info.player ? Dragon_pos[1] : Dragon_pos[0];
		monster[2] = info.player ? Dog_pos[1] : Dog_pos[5];

		towerDes[0] = towerDes[1] = false;
		initMyHero(op, info, cmd);
    }
	//��ʽս��
    else
    {
		bool fighting;		
        for (int i = 0; i < info.units.size(); i ++)
        {
            if (info.units[i].player == player)
            {
                const PUnit &t = info.units[i];	//Ӣ�۵�λ
                fighting = false;
                Operation op;
                op.id = t.id;
				//�ж��Ƿ�����
				for (int i = 0; i < 2; i++)
				{
					if ( dis2(t.pos, AtkTower[1-i]) < 100 && !info.findUnitByPos(AtkTower[1-i]))
						towerDes[i] = true;
				}
                if (t.skills[0].cd == 0)//attack
                {
					HeroNormalFight(op, info, t, fighting);
                }
				if (!fighting)
			   {				
					if ( t.level < 3 )
						LowLevelFight(op, t, ptr);
					else
						HighLevelFight(op,t);
				
				}
				cmd.cmds.push_back(op);
            }
        }
    }
}

bool in_attack_range(const PUnit &t, const Pos& tar)
{
    return dis2(t.pos, tar) <= t.range;
}

void initMyHero(Operation &op, const PPlayerInfo &info, PCommand &cmd)
{
	info.findUnitByPlayer(info.player, ours);
	for (int i = 0; i < ours.size(); i++)
	{
		op.id = ours[i]->id;
		op.type = "ChooseArcher";
		op.targets.clear();
		cmd.cmds.push_back(op);
	}
}

void HeroNormalFight(Operation &op, const PPlayerInfo &info, const PUnit &t, bool &fighting)
{
	for (int j = 0; j < info.units.size(); j++)
	{
           if (info.units[j].player != info.player && !info.units[j].findBuff("Reviving")
                     && info.units[j].hp > 0)//enemy
		   {			

				if (in_attack_range(t, info.units[j].pos))  
				{
					op.type = "Attack";
					op.targets.push_back(info.units[j].pos);
					fighting = true;
					/*if ( fixedId[t.id] != 0)
					{
							if (in_attack_range(t, Info->findUnitById(fixedId[t.id])->pos))  
							{
								if (Info->findUnitById(fixedId[t.id])->hp > 0)
								{
									op.type = "Attack";
									op.targets.push_back(Info->findUnitById(fixedId[t.id])->pos);
									fighting = true;
								}
								else
								{
									fixedId[t.id] = 0;
								}
							}
					}*/
				}
			}
	}
}

void LowLevelFight(Operation &op, const PUnit &t, Pos *ptr)
{
	////ѭ����֣����˴��ˣ�û�˴��
	//static int i = 0;
	//int hp = 1000, record;
	//if ( !in_attack_range(t, ptr[i]) )
	//{
	//	findshortestpath(*pmap, t.pos, ptr[i], blocks, op.targets);
	//	op.type = "move";
	//}
	//else
	//{
	//	if ( in_attack_range(t, ptr[i]) )
	//	{
	//		nearby.clear();
	//		info->findunitinarea(t.pos, t.view, nearby);
	//		for (int i = 0; i < nearby.size(); i++)
	//		{
	//			if (nearby[i]->findbuff("reviving"))
	//			{
	//				nearby.erase(nearby.begin()+i);
	//				--i;
	//			}
	//		}
	//		if ( nearby.size() == 0)
	//		{
	//			findshortestpath(*pmap, t.pos, ptr[(++i)%3], blocks, op.targets);
	//			op.type = "move";
	//		}
	//		else if (nearby.size() == 1)
	//		{
	//			op.type = "stop";
	//		}

	//		else
	//		{
	//			//ɾ������
	//			info->findunitinarea(t.pos, t.view, nearby);
	//			for (int i = 0; i < nearby.size(); i++)
	//			{
	//				if ( !info->player != nearby[i]->player || nearby[i]->findbuff("reviving"))
	//				{
	//					nearby.erase(nearby.begin()+i);
	//					--i;
	//				}
	//			}
	//			//����
	//			for (int i = 0; i < nearby.size(); i++)
	//			{
	//				if (in_attack_range(t, nearby[i]->pos) )
	//				{
	//					if ( nearby[i]->hp < hp)
	//					{
	//						hp = nearby[i]->hp;
	//						record = i;
	//					}
	//				}
	//			}
	//			fixedid[t.id] = nearby[record]->id;
	//			findshortestpath(*pmap, t.pos, info->findunitbyid(nearby[record]->id)->pos, blocks, op.targets);
	//			op.type = "move";
	//		}
	//	}
	//}
	CounterAttack_LoopDenfence(*Info, op, t);
}

void HighLevelFight(Operation &op, const PUnit &t)
{
	//if ( !towerDes[0] )
	//{
	//	if ( in_attack_range(t, AtkTower[1]))
	//	{
	//		op.type = "Stop";
	//	}
	//	findShortestPath(*pMap, t.pos, AtkTower[1], blocks, op.targets);
	//	op.type = "Move";
	//}
	//else
	//{
	//	findShortestPath(*pMap, t.pos, DefenseTow[0], blocks, op.targets);
	//	for ( int i = 0; i < Info->units.size(); i++)
	//	{
	//		if ( Info->units[i].player != Info->player && !Info->units[i].findBuff("Reviving") &&
	//			Info->units[i].hp > 0 )
	//		{
	//			
	//		}
	//	}
	//}
}

//
//#define MAXDISTANCE	 9999
//std::vector<const PUnit*> MonsterUnit;		//Ӧ���Ѿ���ȡ�˹�������
//std::vector<const PUnit*> EnemyUnit;		//ʱ��׼����ȡ�˵����б�
//std::vector<Pos> MonsterPos;				//��ʼ����λ��
//
//void InitLoop(const PPlayerInfo &info, Pos defaultPos, std::vector<Pos> &_monsterPos , std::vector<const PUnit*> &_monsterList);//����ѭ����ֵĹ���λ�ú͹��ﵥԪ
//void CounterAttack_LoopDenfence(const PPlayer &info, Operation &op, const PUnit &t);


void CounterAttack_LoopDenfence(const PPlayerInfo &info, Operation &op, const PUnit &t)
{
	int is_TeamAttack = false;							//��ս��־
	static int record = 0;								//ѭ������
	Pos defaultPos = info.player ?  Player1_tower_pos[0] : Player0_tower_pos[0];	//�ҷ���λ��
	Pos nowPos = defaultPos;				//���ڵ�λ��
	int defaultDistance = MAXDISTANCE;

	InitLoop(info, MonsterPos, MonsterUnit);			//�������Round == 0λ��
	findShortestPath(*pMap, t.pos, MonsterPos[2], blocks, op.targets);
	////ʱ�̻�ȡ����Ұ��Χ�ڵĵ����б�
	//info.findUnitInArea(defaultPos, info.findUnitByPos(defaultPos)->view, EnemyUnit);
	//if (EnemyUnit.size())
	//{
	//	is_TeamAttack = true;
	//}
	////���������û�е��� 
	//if ( !is_TeamAttack )
	//{
	//	//��ʼѰ·
	//	findShortestPath(*pMap, t.pos, MonsterPos[record], blocks, op.targets);
	//	if (in_attack_range(t, MonsterPos[record]))
	//	{
	//		if (MonsterUnit[record]->hp <=0 && MonsterUnit[record]->findBuff("Reviving"))
	//		{
	//		    MonsterPos[(++record)%3];
	//			MonsterUnit[(++record)%3];
	//			op.type = "Stop";
	//		}
	//		else
	//			op.type = "Attack";	//TIP1:�Ժ������ｫ��ͨ�����ĳɡ����ꡱ,����Ҫ�����ж�һ����ɱ�жϺ���
	//	}
	//	else
	//	{
	//		op.type = "Move";
	//	}
	//}
	////������ˣ���ô��ս
	//else
}


void InitLoop(const PPlayerInfo &info, std::vector<Pos> &_monsterPos , std::vector<const PUnit*> &_monsterList)
{
	vector <const PUnit*> temp;
	int record = 0;
	_monsterPos.push_back(info.player ?  Bow_pos[5] : Wolf_pos[2]);
	_monsterPos.push_back(info.player ? Dog_pos[2] : Dog_pos[7]);
	_monsterPos.push_back(info.player ? Wolf_pos[1]: Dog_pos[5]);
	////������1�Ĳ���
	//if (info.player)
	//{
	//	//��ȡDog����
	//	info.findUnitByName("Dog", temp);
	//	long distance = dis(_monsterPos[1], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[1], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[1], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();

	//	//��ȡWolf����
	//	info.findUnitByName("Wolf", temp);
	//	distance = dis(_monsterPos[2], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[2], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[2], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();

	//	//��ȡBow����
	//	info.findUnitByName("Bow", temp);
	//	distance = dis(_monsterPos[0], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[0], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[0], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();
	//}
	//
	////������0�Ĳ���
	//else
	//{
	//	//��ȡDog1����
	//	info.findUnitByName("Dog", temp);
	//	int distance = dis(_monsterPos[1], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[1], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[1], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();

	//	//��ȡDog2����
	//	info.findUnitByName("Dog", temp);
	//	distance = dis(_monsterPos[2], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[2], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[2], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();

	//	//��ȡWolf����
	//	info.findUnitByName("Wolf", temp);
	//	distance = dis(_monsterPos[0], temp[0]->pos);
	//	for (int i = 1; i < temp.size(); ++i)
	//	{
	//		if ( dis(_monsterPos[0], temp[i]->pos) < distance)
	//		{
	//			record = i;
	//			distance = dis(_monsterPos[0], temp[i]->pos);
	//		}
	//	}
	//	_monsterList.push_back(temp[record]);
	//	temp.clear();
	//}
}
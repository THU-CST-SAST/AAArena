#include "sdk.h"
#include "const.h"

const PMap *map;
const PPlayerInfo *info;
PCommand *cmd;

#include <queue>
#include <deque>
#include <list>
#include <vector>
using std::queue;
using std::deque;
using std::list;
using std::vector;

#include <cmath>
#include <cstdlib>
#include <climits>
#include <ctime>
#include <cstring>

const double INF = 1e9;
const double PI = acos((double)-1.0);

const int Tower_Cnt = 2, Dog_Cnt = 8, Bow_Cnt = 6, Wolf_Cnt = 4, StoneMan_Cnt = 2, Dragon_Cnt = 2, Roshan_Cnt = 1;
const int Max_Unit_Cnt = 50;
const int Foe_Id_St = 16;
const int Tower_Id_St = 10;
const int Player0_Tower_Id_St = 10, Player1_Tower_Id_St = 12;
const int Player0_Hero_Id_St = 39, Player1_Hero_Id_St = 44;

static int Own_Tower_Id_St, Enemy_Tower_Id_St;
static int Own_Hero_Id_St, Enemy_Hero_Id_St;

static Pos Spring_pos;

int abs(int x) { return x < 0 ? -x : x; }

int randInt(int high) { return rand() % high; }

double sqr(double x) { return x * x; }

int sqr(int x) { return x * x; }

int getHeight(Pos pos)
{
	return map->height[pos.x][pos.y];
}

Pos getTowerPosById(int id)
{
	id -= 10;
	if (id < 0) return Pos(-1, -1);
	if (id < 2) return Player0_tower_pos[id]; else id -= 2;
	if (id < 2) return Player1_tower_pos[id]; else id -= 2;
	return Pos(-1, -1);
}

int getFoeCntById(int id)
{
	id -= 16;
	if (id < 0) return -1;
	if (id < Dog_Cnt) return Dog_Cnt; else id -= Dog_Cnt;
	if (id < Bow_Cnt) return Bow_Cnt; else id -= Bow_Cnt;
	if (id < Wolf_Cnt) return Wolf_Cnt; else id -= Wolf_Cnt;
	if (id < StoneMan_Cnt) return StoneMan_Cnt; else id -= StoneMan_Cnt;
	if (id < Dragon_Cnt) return Dragon_Cnt; else id -= Dragon_Cnt;
	if (id < Roshan_Cnt) return Roshan_Cnt; else id -= Roshan_Cnt;
	return -1;
}

int getFoeIdStartById(int id)
{
	id -= 16;
	int ret = Foe_Id_St;
	if (id < 0) return -1;
	if (id < Dog_Cnt) return ret; else id -= Dog_Cnt, ret += Dog_Cnt;
	if (id < Bow_Cnt) return ret; else id -= Bow_Cnt, ret += Bow_Cnt;
	if (id < Wolf_Cnt) return ret; else id -= Wolf_Cnt, ret += Wolf_Cnt;
	if (id < StoneMan_Cnt) return ret; else id -= StoneMan_Cnt, ret += StoneMan_Cnt;
	if (id < Dragon_Cnt) return ret; else id -= Dragon_Cnt, ret += Dragon_Cnt;
	if (id < Roshan_Cnt) return ret; else id -= Roshan_Cnt, ret += Roshan_Cnt;
	return -1;
}

int convertFoeIdByPlayer(int id)
{
	if (info->player == 0) return id;
	int cnt = getFoeCntById(id);
	int st = getFoeIdStartById(id);
	id -= cnt/2;
	return id < st ? id + cnt : id;
}

void getAllDistFromPos(const Pos st, const vector<Pos>& blocks, double dist[Map_size][Map_size])
{
	static bool isblock[Map_size][Map_size];
	static bool vis[Map_size][Map_size];
	for (int i = 0; i < Map_size; ++i)
		for (int j = 0; j < Map_size; ++j)
		{
			isblock[i][j] = false;
			dist[i][j] = INF;
			vis[i][j] = false;
		}
	for (vector<Pos>::const_iterator it = blocks.begin(); it != blocks.end(); ++it)
		if (checkPos(*it)) isblock[it->x][it->y] = true;

	static queue<Pos> Q;
	while (!Q.empty()) Q.pop();
	Q.push(st);
	dist[st.x][st.y] = 0;
	vis[st.x][st.y] = true;
	while (!Q.empty())
	{
		Pos pos = Q.front();
		int h = getHeight(pos);
		Q.pop();
		for (int i = 0; i < 4; ++i)
		{
			Pos newpos(pos.x + dir[i][0], pos.y + dir[i][1]);
			if (checkPos(newpos) && !vis[newpos.x][newpos.y] && abs(h - getHeight(newpos)) <= 1)
			{
				dist[newpos.x][newpos.y] = dist[pos.x][pos.y] + PI/4;
				if (!isblock[newpos.x][newpos.y])
				{
					Q.push(newpos);
					vis[newpos.x][newpos.y] = true;
				}
			}
		}
	}
}

Pos findFoePosById(int id)
{
	id -= 16;
	if (id < 0) return Pos(-1, -1);
	if (id < Dog_Cnt) return Dog_pos[id]; else id -= Dog_Cnt;
	if (id < Bow_Cnt) return Bow_pos[id]; else id -= Bow_Cnt;
	if (id < Wolf_Cnt) return Wolf_pos[id]; else id -= Wolf_Cnt;
	if (id < StoneMan_Cnt) return StoneMan_pos[id]; else id -= StoneMan_Cnt;
	if (id < Dragon_Cnt) return Dragon_pos[id]; else id -= Dragon_Cnt;
	if (id < Roshan_Cnt) return Roshan_pos[id]; else id -= Roshan_Cnt;
	return Pos(-1, -1);
}


struct Action
{
	enum {
		Goto,
		Formation, 
		Gather, 
		Retreat, 
		AttackTower, 
		FightFoe, 
		FightEnemy,
		Patrol,
		Recover
	} type;
	vector<int> operatorIDs;
	vector<int> targetIDs;
	vector<Pos> targetPos;
	int threshold;
	int id;
	int changedcnt;
	int startround;

	static int m_cnt;
	Action() { id = ++m_cnt; changedcnt = 0; startround = -1; }

	bool checkCompleted();
	void perform();
};
int Action::m_cnt = 0;

struct ActionSeries
{
	 deque<Action> actions;
	 ActionSeries() {}
};

static list<ActionSeries> series;

typedef list<ActionSeries>::iterator SeriesIt;

struct UnitAttr
{
	UnitAttr(): exist(false) {}
	bool exist;
	int unitID;
	Action *assignedAction;
	int estimatedReviveRound;
	int estimatedActionRound;
	Operation *assignedop;
	bool destroyed;
	int atkAttempts;
	int curPatrolPoint;
	int lastActionId;
	int lastDieRound;
	Pos pos;
	int maxhp;
	int hp;
	int def;
	int atk;
	int atkcd;
};

static vector<UnitAttr> unitattrs;

static vector<Pos> blocks;

static int inatkarea[Map_size][Map_size];

static vector<Pos> atkareablocks;

static vector<vector<int> > foeregions;

static const int Foe_Region_Ids_0[] = {24, 34};
static const int Foe_Region_Ids_1[] = {22, 26, 33};
static const int Foe_Region_Ids_2[] = {23, 28, 32};
static const int Foe_Region_Ids_3[] = {20, 21, 37};
static const int Foe_Region_Ids_4[] = {27, 35};
static const int Foe_Region_Ids_5[] = {25};

static const int Foe_Region_Ids_Size_0 = 2;
static const int Foe_Region_Ids_Size_1 = 3;
static const int Foe_Region_Ids_Size_2 = 3;
static const int Foe_Region_Ids_Size_3 = 3;
static const int Foe_Region_Ids_Size_4 = 2;
static const int Foe_Region_Ids_Size_5 = 1;

const int Foe_Region_Cnt = 6;

const int Foe_Region_Ids_Size(int x)
{
	switch (x) 
	{
	case 0:
		return Foe_Region_Ids_Size_0;
	case 1:
		return Foe_Region_Ids_Size_1;
	case 2:
		return Foe_Region_Ids_Size_2;
	case 3:
		return Foe_Region_Ids_Size_3;
	case 4:
		return Foe_Region_Ids_Size_4;
	case 5:
		return Foe_Region_Ids_Size_5;
	default:
		return 0;
	}
}

const int* Foe_Region_Ids(int x)
{
	switch (x) 
	{
	case 0:
		return Foe_Region_Ids_0;
	case 1:
		return Foe_Region_Ids_1;
	case 2:
		return Foe_Region_Ids_2;
	case 3:
		return Foe_Region_Ids_3;
	case 4:
		return Foe_Region_Ids_4;
	case 5:
		return Foe_Region_Ids_5;
	default:
		return NULL;
	}
}

double getPathLength(vector<Pos>& path)
{
	if (path[0].x < 0) return INF;
/*	vector<double> d;
	d.clear();
	d.reserve(path.size());
	d.push_back(0);
	for (int i = 1; i < path.size(); ++i)
	{
		double dcur = INT_MAX;
		for (int j = 0; j < i; ++j)
		{
			bool found = false;
			for (int k = j + 1; k < i; k++)
				if (!checkOnLine(path[i], path[j], path[k])) { found = true; break; }
			if (!found && dcur > d[j] + dis(path[i], path[j]))
				dcur = d[j] + dis(path[i], path[j]);
		}
		d.push_back(dcur);
	}
	return d[path.size() - 1];*/
	return path.size() * PI / 4;
}

int getFoeExpById(int id)
{
	id -= 16;
	if (id < 0) return -1;
	if (id < Dog_Cnt) return Dog_exp; else id -= Dog_Cnt;
	if (id < Bow_Cnt) return Bow_exp; else id -= Bow_Cnt;
	if (id < Wolf_Cnt) return Wolf_exp; else id -= Wolf_Cnt;
	if (id < StoneMan_Cnt) return StoneMan_exp; else id -= StoneMan_Cnt;
	if (id < Dragon_Cnt) return Dragon_exp; else id -= Dragon_Cnt;
	if (id < Roshan_Cnt) return Roshan_exp; else id -= Roshan_Cnt;
	return -1;
}

double getMapDist(Pos S, Pos T)
{
	vector<Pos> path;
	findShortestPath(*map, S, T, blocks, path);
	return getPathLength(path);
}

void chooseHero()
{
	for (int i = 0; i < info->units.size(); ++i)
	{
		Operation op;
		op.type = "ChooseAssassin";
		op.id = info->units[i].id;
		op.targets.clear();
		cmd->cmds.push_back(op);
	}
}

void levelUpSkill(const PUnit* unit)
{
	Operation op;
	if (unit->findSkill("Blink")->level < 0) op.type = "BlinkLU";
	else if (unit->findSkill("Hide")->level < 0) op.type = "HideLU";
	else if (unit->findSkill("Blink")->level < 2) op.type = "BlinkLU";
	else if (unit->findSkill("FlyingBlade")->level < 2) op.type = "FBLU";
	else if (unit->findSkill("Hide")->level < 2) op.type = "HideLU";
	else op.type = "YellowPoint";
	op.id = unit->id;
	op.targets.clear();
	cmd->cmds.push_back(op);
	unitattrs[unit->id].assignedop = &(cmd->cmds[cmd->cmds.size()-1]);
}

bool Action::checkCompleted()
{
	if (startround == -1) startround = info->round;

	switch (type) {
		case Goto: {
			if (!checkPos(targetPos[0])) return true;
			int arrivedcnt = 0, diedcnt = 0;
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (unitattrs[*it].lastDieRound > startround) diedcnt++;
				if (unit->findBuff("Reviving")) continue;
				Pos a = unit->pos, b = targetPos[0];
				if (dis2(a, b) <= 16 &&
					abs(map->height[a.x][a.y] - map->height[b.x][b.y]) <= 1)
					arrivedcnt++;
			}
			if (arrivedcnt >= threshold) return true;
			else if (diedcnt > operatorIDs.size() - threshold) return true;
			else return false;
			break;
		}
		case Formation:
			break;
		case Gather:
			break;
		case Retreat:
			break;
		case AttackTower: {
			if (operatorIDs.empty())
			{
				++unitattrs[targetIDs[0]].atkAttempts;
				return true;
			}
			Pos pos = getTowerPosById(targetIDs[0]);
			int h = getHeight(pos);
			for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
				if (it->player == info->player && 
					dis2(it->pos, pos) < 144 && h - getHeight(it->pos) < 2 &&
					!info->findUnitById(targetIDs[0]))
				{
					for (int i = 10; i < 14; ++i)
						unitattrs[i].atkAttempts = 0;
					return true;
				}
			vector<int> enemyids;
			for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
			{
				if (it->player == 1 - info->player &&
					it->isHero() && dis2(it->pos, pos) < 400)
				{
					enemyids.push_back(it->id);
				}
			}
			if (enemyids.size() >= 3 && info->round < 950)
			{
				++unitattrs[targetIDs[0]].atkAttempts;
				return true;
			}
			return false;
			break;
		}
		case FightFoe:
			if (info->findUnitById(targetIDs[0]) && info->findUnitById(targetIDs[0])->findBuff("Reviving")) return true;
			//else if (info->findUnitById(targetIDs[0]) == NULL) return true;
			else return false;
			break;
		case FightEnemy: {
			const PUnit *enemy = info->findUnitById(targetIDs[0]);
			if (!enemy || enemy->findBuff("Reviving")) return true;
			bool found = false;
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (!unit || unit->findBuff("Reviving")) continue;
				if (dis2(unit->pos, enemy->pos) <= 100) { found = true; break; }
			}
			if (!found) return true;
			else return false;
			break;
		}
		case Patrol: {
			return false;
			break;
		}
		case Recover: {
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (unit->hp < unit->max_hp) return false;
			}
			return true;
		}
		default:
			break;
	}
	return true;
}

void Action::perform()
{
	if (startround == -1) startround = info->round;

	switch (type) {
		case Goto:
		{
			if (!checkPos(targetPos[0])) break;
			vector<Pos> newblocks = blocks;
			static bool occupied[Map_size][Map_size];
			for (int i = 0; i < Map_size; i++)
				for (int j = 0; j < Map_size; j++)
					occupied[i][j] = false;
			for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
			{
				bool foundID = false;
				for (int i = 0; i < operatorIDs.size(); ++i)
					if (it->id == operatorIDs[i])
					{
						foundID = true;
						break;
					}
				if (!foundID) newblocks.push_back(it->pos);
				else if (unitattrs[it->id].assignedop)
					newblocks.push_back(it->pos);
				//else newblocks.push_back(it->pos);
			}
			for (vector<Pos>::iterator it = newblocks.begin(); it != newblocks.end(); ++it)
				occupied[it->x][it->y] = true;

			int h = map->height[targetPos[0].x][targetPos[0].y];
			int pertrange = ceil(sqrt(4));
			int numcap = 5;
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (unit->findBuff("Reviving") || unitattrs[unit->id].assignedop) continue;
				int dx = randInt(pertrange*2+1)-pertrange, dy = randInt(pertrange*2+1)-pertrange;
				int numleft = numcap;
				while (numleft-- && (
					   !checkPos(Pos(targetPos[0].x + dx, targetPos[0].y + dy)) ||
					   occupied[targetPos[0].x + dx][targetPos[0].y + dy] ||
					   inatkarea[targetPos[0].x + dx][targetPos[0].y + dy] ||
					   abs(map->height[targetPos[0].x + dx][targetPos[0].y + dy] - h) > 0))
				{
					dx = randInt(pertrange*2+1)-pertrange; dy = randInt(pertrange*2+1)-pertrange;
				}
				Operation op;
				op.id = *it;
				if (numleft >= 0)
				{
					vector<Pos> tempblocks = newblocks;
					/*for (vector<int>::iterator ip = operatorIDs.begin(); ip != operatorIDs.end(); ++ip)
						if (*ip != *it) tempblocks.push_back(info->findUnitById(*ip)->pos);*/
					int atkx = inatkarea[unit->pos.x][unit->pos.y];
					for (int i = 0; i < Map_size; ++i)
						for (int j = 0; j < Map_size; ++j)
							if (inatkarea[i][j] && inatkarea[i][j] != atkx)
								tempblocks.push_back(Pos(i, j));
					Pos dest(targetPos[0].x + dx, targetPos[0].y + dy);
					bool enemyfound = false;
					for (vector<PUnit>::const_iterator ip = info->units.begin(); ip != info->units.end(); ++ip)
					{
						if (ip->isHero() && ip->player == 1-info->player && dis2(unit->pos, ip->pos) < 144)
						{
							enemyfound = true;
							break;
						}
					}
					bool useblink = false;
					if(enemyfound && unit->canUseSkill(13))
					{
						op.type = "Hide";
						useblink = true;
					}
					else if (unit->canUseSkill(17))
					{
						vector<Pos> oldpath, newpath;
						findShortestPath(*map, unit->pos, dest, tempblocks, oldpath);
						double r = min(sqrt(81.0 / dis2(unit->pos, dest)), 1.0);
						DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
						Pos pos;
						pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
						pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
						findShortestPath(*map, pos, dest, tempblocks, newpath);
						if (oldpath[0].x < 0 || newpath[0].x >= 0 && newpath.size() + 3 < oldpath.size())
						{
							op.type = "Blink";
							op.targets.clear();
							op.targets.push_back(pos);
							useblink = true;
						}
					}
					if (!useblink && unit->findSkill("Hide") && unit->canUseSkill(13) && 
					   (dis2(unit->pos, dest) > 4850 || enemyfound || info->round > 80 && info->round < 300))
						op.type = "Hide";
					else if (!useblink)
					{
						op.type = "Move";
						findShortestPath(*map, unit->pos, dest, tempblocks, op.targets);
						if (op.targets[0].x < 0)
						{
							double r = min(sqrt((double)unit->speed / dis2(unit->pos, dest)), 1.0);
							DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
							Pos pos;
							pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
							pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
							findShortestPath(*map, unit->pos, pos, tempblocks, op.targets);
							if (op.targets[0].x < 0)
								op.type = "Stop";
							else
								op.type = "Move";
						}
						/*else
						{
							int upper = ceil(sqrt(unit->speed * 2)) + 1;
							upper = min(upper, (int)op.targets.size());
							for (int i = 0; i < upper; ++i)
								newblocks.push_back(op.targets[i]);
						}*/
					}
				}
				else op.type = "Stop";
				cmd->cmds.push_back(op);
				//newblocks.push_back(dest);
				//occupied[dest.x][dest.y] = true;
			}

			break;
		}
		case Formation:
			break;
		case Gather:
			break;
		case Retreat:
			break;
		case AttackTower:
		{
			if (operatorIDs.empty()) break;
			Pos towerpos = getTowerPosById(targetIDs[0]);
			vector<Pos> tempblocks = blocks;

			bool enemyfound = false;
			vector<int> enemyids;
			for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
			{
				if (it->findBuff("Reviving")) continue;
				if (it->player == 1 - info->player &&
					it->isHero() && dis2(it->pos, towerpos) < 350)
				{
					enemyfound = true;
					enemyids.push_back(it->id);
				}
			}
			if (info->round >= 900) enemyfound = false;

			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (unit->findBuff("Reviving") || unitattrs[unit->id].assignedop) continue;
				Operation op;
				op.id = *it;
				op.targets.clear();
				Pos targetpos = enemyfound ? info->findUnitById(enemyids[0])->pos : towerpos;
				if (unit->canUseSkill(13))
				{
					op.type = "Hide";
				}
				else if (enemyfound && unit->canUseSkill(15) && dis2(targetpos, unit->pos) <= 81)
				{
					op.type = "FlyingBlade";
					op.targets.push_back(targetpos);
				}
				else if (unit->findSkill("Attack")->cd ||
					dis2(unit->pos, targetpos) > unit->range)
				{
					op.type = "Move";
					vector<Pos> newblocks = tempblocks;
					for (vector<PUnit>::const_iterator ip = info->units.begin(); ip != info->units.end(); ++ip)
						if (ip->id != *it)
							newblocks.push_back(ip->pos);
					findShortestPath(*map, unit->pos, targetpos - Pos(randInt(2), randInt(2)), newblocks, op.targets);
					if (op.targets[0].x < 0) op.type = "Stop";
					/*else
					{
						for (vector<Pos>::iterator ip = op.targets.begin(); ip != op.targets.end(); ++ip)
							tempblocks.push_back(*ip);
					}*/		
				}
				else
				{
					op.type = "Attack";
					op.targets.push_back(targetpos);
				}
				cmd->cmds.push_back(op);
			}
			break;
		}
		case FightFoe:
		{
			vector<Pos> tempblocks = blocks;
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				const PUnit *foe = info->findUnitById(targetIDs[0]);
				Pos foepos;
				if (!foe) foepos = findFoePosById(targetIDs[0]);
				else foepos = foe->pos;
				Operation op;
				op.id = *it;
				op.targets.clear();
				if (unit->findBuff("Reviving") || unitattrs[unit->id].assignedop) continue;
				if (unit->findSkill("FlyingBlade")->level >= 0 &&
					unit->findSkill("FlyingBlade")->cd == 0 &&
					unit->findSkill("FlyingBlade")->mp < unit->mp &&
					dis2(unit->pos, foepos) < 81)
				{
					op.type = "FlyingBlade";
					op.targets.push_back(foepos);
				}
				else if (unit->canUseSkill(13) && 
						(targetIDs[0] == 36 || targetIDs[0] == 37 || info->round < 200))
				{
					op.type = "Hide";
				}
				else if (unit->findSkill("Attack")->cd ||
						 dis2(unit->pos, foepos) > unit->range)
				{
					op.type = "Move";
					vector<Pos> newblocks = tempblocks;
					for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
						newblocks.push_back(it->pos);
					findShortestPath(*map, unit->pos, foepos - Pos(randInt(2), randInt(2)), newblocks, op.targets);
					if (op.targets[0].x < 0) op.type = "Stop";
					/*else
					{
						for (vector<Pos>::iterator it = op.targets.begin(); it != op.targets.end(); ++it)
							tempblocks.push_back(*it);
					}*/
				}
				else
				{
					op.type = "Attack";
					op.targets.push_back(foepos);
				}
				cmd->cmds.push_back(op);
			}
			break;
		}
		case FightEnemy: {
			const PUnit *enemy = info->findUnitById(targetIDs[0]);
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (!enemy)
				{
					Operation op;
					op.id = *it;
					op.type = "Stop";
					cmd->cmds.push_back(op);
					continue;
				}
				if (unit->findBuff("Reviving") || unitattrs[unit->id].assignedop) continue;
				if (unit->findSkill("Attack")->cd ||
					dis2(unit->pos, enemy->pos) > unit->range)
				{
					Operation op;
					op.id = *it;
					op.type = "Move";
					vector<Pos> newblocks = blocks;
					for (vector<PUnit>::const_iterator ip = info->units.begin(); ip != info->units.end(); ++ip)
						newblocks.push_back(ip->pos);
					findShortestPath(*map, unit->pos, enemy->pos - Pos(randInt(2), randInt(2)), newblocks, op.targets);
					if (op.targets[0].x < 0) op.type = "Stop";
					cmd->cmds.push_back(op);
				}
				else
				{
					Operation op;
					op.id = *it;
					op.type = "Attack";
					op.targets.clear();
					op.targets.push_back(enemy->pos);
					cmd->cmds.push_back(op);
				}
			}
			break;
		}
		case Patrol: {
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				if (unit->findBuff("Reviving"))
				{
					unitattrs[*it].curPatrolPoint = -1;
					continue;
				}
				if (unitattrs[*it].curPatrolPoint == -1 || unitattrs[*it].lastActionId != id)
				{
					unitattrs[*it].curPatrolPoint = randInt(targetPos.size());
					unitattrs[*it].lastActionId = id;
				}
				int k = unitattrs[*it].curPatrolPoint;
				if (dis2(unit->pos, targetPos[k]) < 16) k = (k + 1) % targetPos.size();
				unitattrs[*it].curPatrolPoint = k;
				int areaid = inatkarea[unit->pos.x][unit->pos.y];
				vector<Pos> newblocks = blocks;
				for (int i = 0; i < Map_size; ++i)
					for (int j = 0; j < Map_size; ++j)
						if (inatkarea[i][j] && inatkarea[i][j] != areaid)
							newblocks.push_back(Pos(i, j));
				Operation op;
				op.id = *it;
				op.type = "Move";
				findShortestPath(*map, unit->pos, targetPos[k], newblocks, op.targets);
				if (op.targets[0].x < 0)
				{
					Pos dest = targetPos[k];
					if (unit->canUseSkill(17))
					{
						op.type = "Blink";
						op.targets.clear();
						double r = min(sqrt(81.0 / dis2(unit->pos, dest)), 1.0);
						DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
						Pos pos;
						pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
						pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
						op.targets.push_back(pos);
					}
					else
					{
						double r = min(sqrt((double)unit->speed / dis2(unit->pos, dest)), 1.0);
						DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
						Pos pos;
						pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
						pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
						findShortestPath(*map, unit->pos, pos, newblocks, op.targets);
						if (op.targets[0].x < 0)
							op.type = "Stop";
						else
							op.type = "Move";
					}
				}
				cmd->cmds.push_back(op);
			}
			break;
		}
		case Recover: {
			for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
			{
				const PUnit *unit = info->findUnitById(*it);
				Operation op;
				op.id = *it;
				if (dis2(unit->pos, Spring_pos) < 81)
					op.type = "Stop";
				else if (unit->canUseSkill(17))
				{
					Pos dest = Spring_pos - Pos(1, 1);
					op.type = "Blink";
					op.targets.clear();
					double r = min(sqrt(81.0 / dis2(unit->pos, dest)), 1.0);
					DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
					Pos pos;
					pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
					pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
					op.targets.push_back(pos);
				}
				else
				{
					op.type = "Move";
					findShortestPath(*map, unit->pos, Spring_pos + Pos(randInt(3), randInt(3)), blocks, op.targets);
					if (op.targets[0].x < 0)
					{
						Pos dest = Spring_pos - Pos(1, 1);
						op.targets.clear();
						double r = min(sqrt(81.0 / dis2(unit->speed, dest)), 1.0);
						DPos dpos = (1-r)*DPos(unit->pos) + r*DPos(dest);
						Pos pos;
						pos.x = dest.x > unit->pos.x ? floor(dpos.x) : ceil(dpos.x);
						pos.y = dest.y > unit->pos.y ? floor(dpos.y) : ceil(dpos.y);
						findShortestPath(*map, unit->pos, pos, blocks, op.targets);
						if (op.targets[0].x < 0)
							op.type = "Stop";
						else op.type = "Move";
					}
				}
				cmd->cmds.push_back(op);
			}
		}
		default:
			break;
	}
}

int findNearestFoe(Pos pos, Pos excludepos = Pos(-1, -1), vector<int> *excludeids = NULL, int opcnt = 2)
{
	vector<Pos> foepos;
	foepos.reserve(50);
	foepos.clear();
	for (int i = 0; i < Dog_Cnt; ++i) foepos.push_back(Dog_pos[i]);
	for (int i = 0; i < Bow_Cnt; ++i) foepos.push_back(Bow_pos[i]);
	for (int i = 0; i < Wolf_Cnt; ++i) foepos.push_back(Wolf_pos[i]);
	for (int i = 0; i < StoneMan_Cnt; ++i) foepos.push_back(StoneMan_pos[i]);
	for (int i = 0; i < Dragon_Cnt; ++i) foepos.push_back(Dragon_pos[i]);
	//for (int i = 0; i < Roshan_Cnt; ++i) foepos.push_back(Roshan_pos[i]);

	int dragonexid = info->player ? 37 : 36;

	const Pos *tower_pos = info->player ? Player0_tower_pos : Player1_tower_pos;

	int ret = -1;
	double mindis = INF;
	int curid = 16;
	static double dists[Map_size][Map_size];
	static bool excluded[50];
	for (int i = 0; i < 50; ++i) excluded[i] = false;
	if (excludeids)
	{
		for (vector<int>::iterator it = excludeids->begin(); it != excludeids->end(); ++it)
			excluded[*it] = true;
	}

	getAllDistFromPos(pos, blocks, dists);
	for (vector<Pos>::iterator it = foepos.begin(); it != foepos.end(); ++it, ++curid)
	{
		if (excludepos.x >= 0 && dis2(excludepos, *it) <= 20) continue;
		//if (curid == 25 || curid == 28 || curid == dragonexid || curid == 34 || curid == 35) continue;
		if (excluded[curid]) continue;
		//if (opcnt >= 2 && curid < 24) continue;
		if (opcnt <= 2 && curid >= 30) break;
		if (opcnt <= 5 && curid >= 36) break;
		//vector<Pos> path;
		//findShortestPath(*map, pos, (*it) - Pos(1, 0), blocks, path);
		//double dist = getPathLength(path);
		if (dis2(tower_pos[0], *it) < 1100) continue;
		if (dis2(tower_pos[1], *it) < 1100) continue;
		double dist = dists[it->x][it->y];
		if (unitattrs[curid].exist && unitattrs[curid].estimatedReviveRound >= info->round + (dist/(sqrt(20*1.5)))) continue;
		//if (dist > 10000) continue;
		/*double score;
		if (dist > 4) score = getFoeExpById(curid) / dist;
		else score = 500;*/
		if (mindis > dist)
		{
			mindis = dist;
			ret = curid;
		}
	}
	return ret;
}

int findNearestFoeByRegion(const vector<int> &operatorIDs, int regionid)
{
	int mindis = INT_MAX;
	int ret = -1;
	int minrevdis = INT_MAX, revid = -1;
	const Pos pos = info->findUnitById(operatorIDs[0])->pos;
	vector<const PUnit*> units;
	for (vector<int>::const_iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
	{
		const PUnit *unit = info->findUnitById(*it);
		if (unit->findBuff("Reviving")) continue;
		units.push_back(unit);
	}

	for (vector<int>::iterator it = foeregions[regionid].begin(); it != foeregions[regionid].end(); ++it)
	{
		int dist = dis2(unitattrs[*it].pos, pos);

		int mint = INT_MAX;
		int unitperatk = 0;
		for (int i = 0; i < units.size(); ++i)
		{
			int peratk = max(unitattrs[*it].atk - units[i]->def, 5);
			int t = ceil((double)units[i]->hp / peratk);
			t = (t - 1) * unitattrs[*it].atkcd + 1;
			mint = min(mint, t);

			unitperatk += max(units[i]->atk - unitattrs[*it].def, 5);
		}
		int ut = ceil((double)unitattrs[*it].hp / unitperatk);

		if (ut >= mint) continue;

		if (unitattrs[*it].exist && unitattrs[*it].estimatedReviveRound >= info->round + (sqrt(dist)/(sqrt(20*1.5))))
		{
			if (minrevdis > dist)
			{
				minrevdis = dist;
				revid = *it;
			}
		}
		else if (mindis > dist)
		{
			mindis = dist;
			ret = *it;
		}
	}
	if (ret == -1) ret = revid;
	return ret;
}

Pos findGatherPoint(vector<int> operatorIDs, Pos pos, int lowerdist = 200, int upperdist = 280)
{
	int range = floor(sqrt((double)upperdist));
	Pos res(-1, -1);
	double mindist = INF;
	const PUnit *testunit = info->findUnitById(operatorIDs[0]);
	static double dists[Map_size][Map_size];
	static double tgdists[Map_size][Map_size];

	//getAllDistFromPos(testunit->pos, blocks, dists);
	getAllDistFromPos(pos, blocks, tgdists);
	for (int dx = -range; dx <= range; dx += 2)
	{
		int low = floor(sqrt(280.0 - sqr(dx)));
		int hi = sqr(dx) < lowerdist ? ceil(sqrt((double)lowerdist - sqr(dx))) : 0;
		for (int dy = -low; dy <= -hi; dy += 2)
		{
			if (dx == 0 && dy == 0) continue;
			//if (sqr(dx) + sqr(dy) > 120 || sqr(dx) + sqr(dy) < 81) continue;
			Pos newpos(pos.x + dx, pos.y + dy);
			if (!checkPos(newpos)) continue;
			if (inatkarea[newpos.x][newpos.y]) continue;
			if (tgdists[newpos.x][newpos.y] > upperdist) continue;
			//if (abs(getHeight(newpos) - getHeight(pos)) > 1) continue;
			//if (sqr(getMapDist(pos, newpos)) > 135) continue;
			double dist = 0;
			//dist = max(dist, dists[newpos.x][newpos.y]);
			dist = dis2(testunit->pos, newpos);
			if (mindist > dist)
			{
				mindist = dist;
				res = newpos;
			}
		}
		for (int dy = hi; dy <= low; dy += 2)
		{
			if (dx == 0 && dy == 0) continue;
			//if (sqr(dx) + sqr(dy) > 135 || sqr(dx) + sqr(dy) < 81) continue;
			Pos newpos(pos.x + dx, pos.y + dy);
			if (!checkPos(newpos)) continue;
			if (inatkarea[newpos.x][newpos.y]) continue;
			if (tgdists[newpos.x][newpos.y] > upperdist) continue;
			//if (abs(getHeight(newpos) - getHeight(pos)) > 1) continue;
			//if (sqr(getMapDist(pos, newpos)) > 135) continue;
			double dist = 0;
			//dist = max(dist, dists[newpos.x][newpos.y]);
			dist = dis2(testunit->pos, newpos);
			if (mindist > dist)
			{
				mindist = dist;
				res = newpos;
			}
		}
	}
	return res;
}

void getActions()
{
	vector<const PUnit*> ownunits;
	info->findUnitByPlayer(info->player, ownunits);
	bool attackingfoe = false;
	Pos attackingpos;

	if (!series.empty() && !series.front().actions.empty() &&
		series.front().actions.front().type == Action::AttackTower)
	{
		Action *action = &series.front().actions.front();
		vector<int> &operatorIDs = action->operatorIDs;
		vector<int> newoperaterIDs;
		newoperaterIDs.clear();
		for (vector<int>::iterator it = operatorIDs.begin(); it != operatorIDs.end(); ++it)
		{
			const PUnit *unit = info->findUnitById(*it);
			if (!unit) continue;
			if (!unit->findBuff("Reviving")) newoperaterIDs.push_back(*it);
		}
		action->operatorIDs = newoperaterIDs;
	}

	if (!series.empty() && !series.front().actions.empty() && series.front().actions.front().type == Action::FightFoe)
	{
		attackingfoe = true;
		attackingpos = findFoePosById(series.front().actions.front().targetIDs[0]);
	}

	if (series.empty() && info->round <= 2)
	{
		ActionSeries newseries;
		Action action;
		action.type = Action::Goto;
		action.threshold = 5;
		action.operatorIDs.clear();
		for (int i = 0; i < ownunits.size(); ++i)
			if (ownunits[i]->isHero()) action.operatorIDs.push_back(ownunits[i]->id);
		//int id = info->player ? 37 : 36;
		int id = info->player ? 37 : 36;
		Pos pos = findFoePosById(id);
		action.targetPos.clear();
		action.targetPos.push_back(findGatherPoint(action.operatorIDs, pos, 11, 20));
		newseries.actions.push_back(action);

		action.type = Action::FightFoe;
		action.targetIDs.clear();
		action.targetIDs.push_back(id);
		newseries.actions.push_back(action);

		for (int i = 1; i >= 0; --i)
		{
			action.type = Action::Goto;
			action.targetPos.clear();
			action.targetPos.push_back(findGatherPoint(action.operatorIDs, unitattrs[Enemy_Tower_Id_St + i].pos));
			newseries.actions.push_back(action);

			action.type = Action::AttackTower;
			action.targetIDs.clear();
			action.targetIDs.push_back(Enemy_Tower_Id_St + i);
			newseries.actions.push_back(action);
		}

		series.push_back(newseries);
	}
	else
	{
		vector<int> excludedfoe;
		excludedfoe.clear();
		int heroidst = 39 + info->player * 5;
		static bool assigned[50];
		for (int i = 0; i < 5; ++i) assigned[heroidst + i] = false;
		vector<int> nonassignedIDs;
		for (SeriesIt it = series.begin(); it != series.end(); ++it)
		{
			if (it->actions.empty()) continue;
			Action &action = it->actions.front();
			for (vector<int>::iterator ip = action.operatorIDs.begin(); ip != action.operatorIDs.end(); ++ip)
				assigned[*ip] = true;
			for (deque<Action>::iterator ip = it->actions.begin(); ip != it->actions.end(); ++ip)
				if (ip->type == Action::FightFoe)
					excludedfoe.push_back(ip->targetIDs[0]);
		}
		nonassignedIDs.clear();
		for (int i = 0; i < 5; i++)
			if (!assigned[heroidst + i])
				nonassignedIDs.push_back(heroidst + i);
		for (int i = 0; i < 4; ++i)
		{
			if (assigned[heroidst + i]) continue;
			if (i + 1 == 4 && assigned[heroidst + i + 1]) continue;
			ActionSeries newseries;
			Action action;
			action.type = Action::Goto;
			action.operatorIDs.clear();
			action.operatorIDs.push_back(heroidst + i);
			if (i + 1 == 4) action.operatorIDs.push_back(heroidst + i + 1);
			action.threshold = action.operatorIDs.size();

			const PUnit *unit = info->findUnitById(action.operatorIDs[0]);

			/*if (nonassignedIDs.size() > 4 && i + 1 == 4)
				action.operatorIDs.push_back(nonassignedIDs[i + 1]);*/
			//if (i + 2 < 5) action.operatorIDs.push_back(heroidst + i + 2);
			int id = findNearestFoeByRegion(action.operatorIDs, i);
			if (id != -1)
			{
				Pos pos = findFoePosById(id);
				excludedfoe.push_back(id);
				action.targetPos.clear();
				action.targetPos.push_back(findGatherPoint(action.operatorIDs, pos, 11, 16));
				newseries.actions.push_back(action);

				action.type = Action::FightFoe;
				action.targetIDs.clear();
				action.targetIDs.push_back(id);
				newseries.actions.push_back(action);
			}
			else
			{
				action.type = Action::Recover;
				newseries.actions.push_back(action);
			}
 
			series.push_back(newseries);
		}
	}

	if (!series.empty() && !series.front().actions.empty() && series.front().actions.front().type == Action::Goto)
	{
		bool foeattack = false;
		for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
		{
			if (!it->isWild()) continue;
			if (it->findBuff("Reviving")) continue;
			bool found = false;
			for (int i = 0; i < ownunits.size(); ++i)
			{
				const PUnit *unit = ownunits[i];
				if (!unit->isHero()) continue;
				if (unit->findBuff("Reviving")) continue;
				const PArg *arg = (*unit)["LastHit"];
				if (arg && arg->val.size() > it->id && arg->val[it->id] > info->round - 3) { found = true; break; }
			}
			if (found) { foeattack = true; break; }
		}
		//if (foeattack) series.front().actions.pop_front();
	}

	vector<const PUnit*> enemys;
	info->findUnitByPlayer(1 - info->player, enemys);
	bool enemyfound = false;
	bool enemyfoundneartower = false;
	int enemyid;
	for (int i = 0; i < enemys.size(); ++i)
	{
		const PUnit *enemy = enemys[i];
		if (!enemy->isHero()) continue;
		if (enemy->findBuff("Reviving")) continue;
		if (enemy->typeId == 2) continue;
/*		bool found = false, foundalive = false;
		for (int j = 0; j < ownunits.size(); ++j)
		{
			const PUnit *unit = ownunits[j];
			if (!unit->isHero()) continue;
			if (unit->findBuff("Reviving")) continue;
			foundalive = true;
			if (dis2(unit->pos, enemy->pos) > 185) { found = true; break; }
		}
		if (foundalive && !found) { enemyid = enemy->id; enemyfound = true; break; }*/
		enemyfound = true;
		for (int j = 0; j < 2; ++j)
			if (dis2(enemy->pos, unitattrs[Own_Tower_Id_St + j].pos) <= 400) enemyfoundneartower = true;
	}

	bool canatktower = false;
	if (enemyfound && !series.empty() && !series.front().actions.empty() && series.front().actions.front().type == Action::Patrol)
		canatktower = true;
	if (enemyfoundneartower && info->round >= 200) canatktower = true;
	if (info->round >= 950) canatktower = true;

	if (enemyfound && !series.empty() && !series.front().actions.empty() &&
		series.front().actions.front().type == Action::Goto &&
		series.front().actions.back().type == Action::AttackTower)
	{
		Pos towerpos = getTowerPosById(series.front().actions.back().targetIDs[0]);
		Pos pos = series.front().actions.front().targetPos[0];
		pos.x = 2*towerpos.x - pos.x;
		if (series.front().actions.front().changedcnt < 0)
		{
			series.front().actions.front().targetPos[0] = pos;
			series.front().actions.front().changedcnt++;
		}
	}
	/*if (enemyfound &&
		(series.empty() || series.front().actions.empty() || 
		 series.front().actions.front().type != Action::FightEnemy))
	{
		const PUnit *testunit = info->findUnitById(enemyid);
		int enemycnt = 0;
		for (int i = 0; i < enemys.size(); ++i)
		{
			const PUnit *unit = enemys[i];
			if (!unit->isHero()) continue;
			if (unit->findBuff("Reviving")) continue;
			if (dis2(unit->pos, testunit->pos) <= 144) enemycnt++;
		}
		if (enemycnt <= 2)
		{
			ActionSeries newseries;
			Action action;
			action.type = Action::FightEnemy;
			action.operatorIDs.clear();
			for (int i = 0; i < ownunits.size(); ++i)
				if (ownunits[i]->isHero()) action.operatorIDs.push_back(ownunits[i]->id);
			action.targetIDs.clear();
			action.targetIDs.push_back(enemyid);
			newseries.actions.push_back(action);
			series.clear();
			series.push_back(newseries);
		}
	}*/


	int lvlsum = 0;
	for (int i = 0; i < ownunits.size(); ++i)
	{
		const PUnit *unit = ownunits[i];
		if (!unit->isHero()) continue;
		if (unit->findBuff("Reviving")) { lvlsum = -1; break; }
		const PArg *arg = (*unit)["Exp"];
		if (arg && arg->val[0]) lvlsum += arg->val[0];
	}
	if ((canatktower || info->round > 400 && lvlsum >= 500) && series.front().actions.back().type != Action::AttackTower)
	{
		Action action;
		action.type = Action::Goto;
		action.threshold = 5;
		vector<int> heroids;
		heroids.clear();
		action.operatorIDs.clear();
		for (int i = 0; i < ownunits.size(); ++i)
			if (ownunits[i]->isHero()) heroids.push_back(ownunits[i]->id);
		for (int i = 0; i < 5; ++i) action.operatorIDs.push_back(heroids[i]);
		const Pos *towers = info->camp ? Player0_tower_pos : Player1_tower_pos;
		Pos ownpos = info->findUnitById(action.operatorIDs[0])->pos;
		int toweridst = info->camp ? 10 : 12;
		double mindist = INF;
		int minid = -1;
		for (int i = 0; i < 2; i++)
		{
			if (unitattrs[toweridst+i].destroyed) continue;
			if (!canatktower && unitattrs[toweridst+i].atkAttempts >= 1) continue;
			double dist = getMapDist(towers[i], ownpos);
			if (dist < mindist)
			{
				mindist = dist;
				minid = toweridst + i;
			}
		}

		if (minid != -1)
		{
			series.clear();
			ActionSeries newseries;

			if (info->round <= 330 && !canatktower)
			{
				action.targetPos.clear();
				action.targetPos.push_back(Pos(9, 141));
				if (info->player == 1) action.targetPos[0] = Pos(Map_size-1, Map_size-1) - action.targetPos[0];
				newseries.actions.push_back(action);
			}

			action.targetPos.clear();
			action.targetPos.push_back(findGatherPoint(action.operatorIDs, towers[minid - toweridst]));
			newseries.actions.push_back(action);

			action.type = Action::AttackTower;
			action.targetIDs.clear();
			action.targetIDs.push_back(minid);

			newseries.actions.push_back(action);

			series.push_back(newseries);
		}
		else if (series.front().actions.front().type != Action::Patrol)
		{
			series.clear();
			ActionSeries newseries;

			action.type = Action::Patrol;
			action.targetPos.clear();
			action.targetPos.push_back(Pos(52, 82));
			action.targetPos.push_back(Pos(84, 86));
			if (info->player == 0)
			{
				action.targetPos[0] = Pos(Map_size-1, Map_size-1) - action.targetPos[0];
				action.targetPos[1] = Pos(Map_size-1, Map_size-1) - action.targetPos[1];
			}
			newseries.actions.push_back(action);

			series.push_back(newseries);
		}

		/*if (series.back().actions.front().type != Action::Patrol)
		{
			action.type = Action::Patrol;
			const Pos *own_tower_pos = info->player ? Player1_tower_pos : Player0_tower_pos;
			for (int i = 0; i < 2; ++i)
			{
				ActionSeries newseries;
				action.operatorIDs.clear();
				action.operatorIDs.push_back(heroids[i]);
				action.targetPos.clear();
				action.targetPos.push_back(own_tower_pos[i] - Pos(1, 1));
				newseries.actions.push_back(action);
				series.push_back(newseries);
			}
		}*/		
	}
}

void updateUnitAttrs()
{
	for (vector<PUnit>::const_iterator it = info->units.begin(); it != info->units.end(); ++it)
	{
		if (it->id >= unitattrs.size())
			unitattrs.resize(it->id + 2);
		UnitAttr &attr = unitattrs[it->id];
		if (!attr.exist)
		{
			attr.exist = true;
			attr.unitID = it->id;
			attr.assignedAction = NULL;
			attr.assignedop = NULL;
			attr.estimatedReviveRound = -1;
			attr.lastActionId = -1;
			attr.lastDieRound = -1;
		}
		if (it->findBuff("Reviving") && info->round > attr.estimatedReviveRound)
		{
			attr.estimatedReviveRound = info->round + it->findBuff("Reviving")->timeLeft;
			attr.lastDieRound = info->round;
		}
	}

	const Pos *enemytowers = info->camp ? Player0_tower_pos : Player1_tower_pos;
	const Pos *owntowers = info->camp ? Player1_tower_pos : Player0_tower_pos;
	int enemytoweridst = info->camp ? 10 : 12;
	int owntoweridst = info->camp ? 12 : 10;
	for (int i = 0; i < 2; i++)
		if (!info->findUnitById(owntoweridst + i)) unitattrs[owntoweridst + i].destroyed = true;
	vector<const PUnit*> ownunits;
	info->findUnitByPlayer(info->player, ownunits);
	for (int i = 0; i < 2; i++)
	{
		bool found = false;
		for (int j = 0; j < ownunits.size(); j++)
		{
			if (dis2(ownunits[j]->pos, enemytowers[i]) <= ownunits[j]->view &&
				getHeight(ownunits[j]->pos) > getHeight(enemytowers[i]) - 2)
			{
				found = true; break;
			}
		}
		if (found && !info->findUnitById(enemytoweridst + i))
			unitattrs[enemytoweridst + i].destroyed = true;
	}
}

void initAll()
{
	srand(time(NULL));

	Own_Tower_Id_St = info->player ? Player1_Tower_Id_St : Player0_Tower_Id_St;
	Enemy_Tower_Id_St = info->player ? Player0_Tower_Id_St : Player1_Tower_Id_St;
	Own_Hero_Id_St = info->player ? Player1_Hero_Id_St : Player0_Hero_Id_St;
	Enemy_Hero_Id_St = info->player ? Player0_Hero_Id_St : Player1_Hero_Id_St;

	Spring_pos = info->player ? Player1_spring_pos[0] : Player0_spring_pos[0];

	series.clear();
	unitattrs.clear();
	for (int i = 0; i < Max_Unit_Cnt; ++i) unitattrs.push_back(UnitAttr());
	for (int i = 10; i < 14; i++)
	{
		unitattrs[i].destroyed = false;
		unitattrs[i].atkAttempts = 0;
		unitattrs[i].lastDieRound = -1;
	}

	blocks.clear();
	for (int i = 0; i < 8; i++) blocks.push_back(Dog_pos[i]);
	for (int i = 0; i < 6; i++) blocks.push_back(Bow_pos[i]);
	for (int i = 0; i < 4; i++) blocks.push_back(Wolf_pos[i]);
	for (int i = 0; i < 2; i++) blocks.push_back(StoneMan_pos[i]);
	for (int i = 0; i < 2; i++) blocks.push_back(Dragon_pos[i]);
	for (int i = 0; i < 1; i++) blocks.push_back(Roshan_pos[i]);

	const Pos *tower_pos = info->player ? Player0_tower_pos : Player1_tower_pos;

	atkareablocks.clear();
	for (int i = 0; i < Map_size; ++i)
		for (int j = 0; j < Map_size; ++j)
		{
			inatkarea[i][j] = 0;
			int k = 0;
			for (vector<Pos>::iterator it = blocks.begin(); it != blocks.end(); ++it, ++k)
				if (dis2(*it, Pos(i, j)) <= 10) inatkarea[i][j] = k + 1;
			for (k = 0; k < 2; ++k)
				if (dis2(tower_pos[k], Pos(i, j)) <= 144) inatkarea[i][j] = k + 50;
			if (inatkarea[i][j]) atkareablocks.push_back(Pos(i, j));
		}

	for (int i = 0; i < 2; i++) blocks.push_back(Player1_tower_pos[i]);
	for (int i = 0; i < 2; i++) blocks.push_back(Player0_tower_pos[i]);

	foeregions.reserve(Foe_Region_Cnt);
	for (int i = 0; i < Foe_Region_Cnt; ++i)
	{
		vector<int> ids;
		int n = Foe_Region_Ids_Size(i);
		for (int j = 0; j < n; ++j) ids.push_back(convertFoeIdByPlayer(Foe_Region_Ids(i)[j]));
		foeregions.push_back(ids);
	}

	int idst = Foe_Id_St;
	for (int i = 0; i < Dog_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Dog_pos[i];
		attr.hp = Dog_hp;
		attr.atk = Dog_atk;
		attr.def = Dog_def;
	}

	idst += Dog_Cnt;
	for (int i = 0; i < Bow_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Bow_pos[i];
		attr.hp = Bow_hp;
		attr.atk = Bow_atk;
		attr.def = Bow_def;
	}

	idst += Bow_Cnt;
	for (int i = 0; i < Wolf_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Wolf_pos[i];
		attr.hp = Wolf_hp;
		attr.atk = Wolf_atk;
		attr.def = Wolf_def;
	}

	idst += Wolf_Cnt;
	for (int i = 0; i < StoneMan_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = StoneMan_pos[i];
		attr.hp = StoneMan_hp;
		attr.atk = StoneMan_atk;
		attr.def = StoneMan_def;
	}

	idst += StoneMan_Cnt;
	for (int i = 0; i < Dragon_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Dragon_pos[i];
		attr.hp = Dragon_hp;
		attr.atk = Dragon_atk;
		attr.def = Dragon_def;
	}

	idst += Dragon_Cnt;
	for (int i = 0; i < Roshan_Cnt; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Roshan_pos[i];
		attr.hp = Roshan_hp;
		attr.atk = Roshan_atk;
		attr.def = Roshan_def;
	}

	idst = Tower_Id_St;
	for (int i = 0; i < 2; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Player0_tower_pos[i];
		attr.hp = Tower_hp;
		attr.atk = Tower_atk;
		attr.def = Tower_def;
	}

	idst += 2;
	for (int i = 0; i < 2; ++i)
	{
		UnitAttr &attr = unitattrs[idst + i];
		attr.exist = true;
		attr.unitID = idst + i;
		attr.estimatedReviveRound = -1;
		attr.lastDieRound = -1;
		attr.pos = Player1_tower_pos[i];
		attr.hp = Tower_hp;
		attr.atk = Tower_atk;
		attr.def = Tower_def;
	}

	for (int i = Foe_Id_St; i < Player0_Hero_Id_St; ++i)
	{
		unitattrs[i].maxhp = unitattrs[i].hp;
		unitattrs[i].atkcd = 2;
	}

	for (int i = 30; i < 34; ++i)
		unitattrs[i].atkcd = 1;
}

void player_ai(const PMap &_map, const PPlayerInfo &_info, PCommand &_cmd)
{
	#ifdef __PROFILING__
		clock_t clk = clock();
	#endif
	info = &_info; map = &_map; cmd = &_cmd;
	if (info->round == 0)
	{
		chooseHero();
		initAll();
	}
	else
	{
		updateUnitAttrs();
		vector<const PUnit*> unitList;
		info->findUnitByPlayer(info->player, unitList);
		for (int i = 0; i < unitList.size(); ++i)
		{
			const PUnit *unit = unitList[i];
			unitattrs[unit->id].assignedop = NULL;
			if (unit->findBuff("Reviving")) continue;
			if ((*unit)["Exp"]->val[3])
				levelUpSkill(unit);
		}
		for (SeriesIt it = series.begin(); it != series.end(); ++it)
		{
			if (it->actions.empty()) continue;
			Action *action = &(it->actions.front());
			while (!it->actions.empty() && action->checkCompleted())
			{
				it->actions.pop_front();
				if (it->actions.empty()) break;
				action = &(it->actions.front());
			}
		}
		SeriesIt ip = series.begin();
		while (ip != series.end())
		{
			SeriesIt it = ip++;
			if (it->actions.empty()) series.erase(it);
		}
		getActions();
		for (SeriesIt it = series.begin(); it != series.end(); ++it)
		{
			if (it->actions.empty()) continue;
			Action *action = &(it->actions.front());
			while (!it->actions.empty() && action->checkCompleted())
			{
				it->actions.pop_front();
				if (it->actions.empty()) break;
				action = &(it->actions.front());
			}
			if (!it->actions.empty())
				action->perform();
		}
		ip = series.begin();
		while (ip != series.end())
		{
			SeriesIt it = ip++;
			if (it->actions.empty()) series.erase(it);
		}
	}
	#ifdef __PROFILING__
		clk = clock() - clk;
		printf("%u\n", clk);
	#endif
}

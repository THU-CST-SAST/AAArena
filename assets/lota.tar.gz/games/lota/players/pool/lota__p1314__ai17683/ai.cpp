#include <cstdio>
#include <vector>
#include <cmath>
#include <iostream>
#include <fstream>
#include "sdk.h"
//#define debug
using namespace std;
const int LevelUp_value=50;
const int skills[2][5][10]={{{1,1,1,4,4,4,4,4,4,4},{2,2,2,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4}},
							{{1,1,1,4,4,4,4,4,4,4},{2,2,2,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4},{1,1,1,4,4,4,4,4,4,4}}};
int Skills[5][10];
int choose[51],choose_final[51],choose_last[51],dir_ord[4];
int player,camp,Round,Round_last,attack_last[16],i,l,g[51],min_length[2][151][151][51];
double Max,move_value[51][51];
int hatred[51][51],gg[100000],groups[51],groups_last[51],needdefense,Divide;
bool PPP,maydie[51];
Operation option[51],option_final[51],option2[51][101];
double Maxx,record[32][51],record2[51][2][3];
PMap Map;
vector<PArea> area;
const Pos delta[4]={Pos(0,1),Pos(1,0),Pos(0,-1),Pos(-1,0)};
bool vst[151][151];
Pos Q[100000],Q_prior[151][151],path_next[151][151][51];
const int nearBy=8;
const int maxDis0=324;
const int maxDis1=144;
#ifdef debug
ofstream out("log.txt");
#endif
////////////////////////////////////////////////////
struct PUnit2:public PUnit
{
	Pos pos_origin;
	bool visible;
	int hp_bound,mp_bound,atk_base,def_base,speed_base,time,reviving_time,priority,canchoose,lastvisit;
	PUnit2():PUnit(0,-1,-1,-1,-1000,-1000),pos_origin(-1000,-1000)
	{
		hp_bound=mp_bound=atk_base=def_base=speed_base=time=reviving_time=-1;
		visible=false;
	}
	bool CanUseSkill(int _typeId) const
	{
		const PSkill* _ = findSkill(_typeId);
		if (!_)
			return 0;
			int mp, skill_point;
			const PArg* _arg = (*this)[1]; 
			if (_arg) 
			mp = _arg->val[0]; 
			else 
			mp = 0;
		_arg = (*this)[6]; 
		if (_arg)
			skill_point = _arg->val[3];
		else
			skill_point = 0;
		bool with_dizzy = findBuff(4), with_reviving = findBuff(7);
		if (with_reviving)
			return 0;
		if (!_typeId)
			return !with_dizzy && _->cd==0;
		else if (_typeId >= 20)
			return 1;
		else if (_->maxCd)
			return !with_dizzy && _->level >= 0 && mp >= _->mp && _->cd==0;
		else if (_typeId == 19)
			return skill_point;
			else {
				_ = findSkill(_typeId - 1);
				return skill_point && _->level < _->maxLevel;
			}
		return 0;
	}
	~PUnit2()
	{
	}
};
PUnit2 unit[51];
void FindShortestPath(const PMap &map, Pos start, Pos dest, std::vector<Pos> &_path)
{
    if (!checkPos(start))
    {
        _path.push_back(Pos());
        return;
    }
    Pos _0, _1;
    Q[0] = start;
    vst[start.x][start.y] = true;
	for (int i=0; i<4; ++i) dir_ord[i] = i;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];random_shuffle(dir_ord, dir_ord+4);
        for (int i=0; i<4; ++i) {
            _1 = _0 + delta[dir_ord[i]];
            if (checkPos(_1) && abs(map.height[_0.x][_0.y] - map.height[_1.x][_1.y]) <= 1 && !vst[_1.x][_1.y]) {
                vst[_1.x][_1.y] = true;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
            }
        }
		if (vst[dest.x][dest.y]) break;
    }
    if (vst[dest.x][dest.y]) {
        for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    } else _path.push_back(Pos());
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void push(PUnit2 &a,const UnitArgs &b,int x,int y,int priority,const char name[100],int o)
{
	strcpy(a.name,name);
	a.canchoose=o;
	a.priority=priority;
	a.player=a.camp=-1;
    a.pos_origin.x=a.pos.x=x;
	a.pos_origin.y=a.pos.y=y;
	a.hp_bound=a.hp=b.hp;
	a.atk_base=a.atk=b.atk;
	a.def_base=a.def=b.def;
	a.speed_base=a.speed=b.speed;
	a.range=b.range;
	a.exp=b.exp;
	a.view=b.view;
	a.reviving_time=b.reviving_time;
	a.time=0;
	a.args.clear();
	a.buffs.clear();
	a.skills.clear();
	for (int i=0;i<10;++i)
	{
		a.args.push_back(i);
		for (int j=0;j<=4;++j) a.args[i].val.push_back(j);
	}
	a.args[0].val[0]=a.hp;
	a.args[0].val[1]=a.hp_bound;
	a.args[0].val[2]=a.hp_bound/100;
	a.args[1].val[0]=0;
	a.args[1].val[1]=0;
	a.args[1].val[2]=0;
	a.args[2].val[0]=a.atk;
	a.args[2].val[1]=a.atk_base;
	a.args[3].val[0]=a.def;
	a.args[3].val[1]=a.def_base;
	a.args[4].val[0]=a.speed;
	a.args[4].val[1]=a.speed_base;
	a.args[5].val[0]=a.range;
	a.args[5].val[1]=a.range;
	a.args[5].val[2]=1;
	a.args[6].val[0]=0;
	a.args[6].val[1]=1000;
	a.args[6].val[2]=0;
	a.args[6].val[3]=0;
	a.args[6].val[4]=a.exp;
	a.args[7].val[0]=a.view;
	a.args[7].val[1]=a.view;
	a.args[7].val[2]=0;
	a.args[9].val[0]=-1;
}
void push(PUnit2 &a,const SpecialUnitArgs &b,int x,int y,bool p,int priority,const char name[100])
{
	if (p) a.player=player,a.camp=camp;
	else a.player=a.camp=1-player;
	strcpy(a.name,name);
	a.priority=priority;
	a.pos_origin.x=a.pos.x=x;
	a.pos_origin.y=a.pos.y=y;
	a.hp_bound=a.hp=b.hp;
	a.atk_base=a.atk=b.atk;
	a.def_base=a.def=b.def;
	a.speed=a.speed_base=0;
	a.range=b.range;
	a.exp=b.exp;
	a.view=b.view;
	a.reviving_time=100000;
	a.time=0;
	a.args.clear();
	a.buffs.clear();
	a.skills.clear();
	for (int i=0;i<10;++i)
	{
		a.args.push_back(i);
		for (int j=0;j<=4;++j) a.args[i].val.push_back(j);
	}
	a.args[0].val[0]=a.hp;
	a.args[0].val[1]=a.hp_bound;
	a.args[0].val[2]=a.hp_bound/100;
	a.args[1].val[0]=0;
	a.args[1].val[1]=0;
	a.args[1].val[2]=0;
	a.args[2].val[0]=a.atk;
	a.args[2].val[1]=a.atk_base;
	a.args[3].val[0]=a.def;
	a.args[3].val[1]=a.def_base;
	a.args[4].val[0]=0;
	a.args[4].val[1]=0;
	a.args[5].val[0]=a.range;
	a.args[5].val[1]=a.range;
	a.args[5].val[2]=1;
	a.args[6].val[0]=0;
	a.args[6].val[1]=1000;
	a.args[6].val[2]=0;
	a.args[6].val[3]=0;
	a.args[6].val[4]=0; //死亡分配的exp
	a.args[7].val[0]=a.view;
	a.args[7].val[1]=a.view;
	a.args[7].val[2]=1;
	a.args[9].val[0]=-1;
}
void push (PUnit2 &a,int x,int y)
{
	a.pos_origin.x=x;
	a.pos_origin.y=y;
}
void init(const PPlayerInfo &info)
{
	player=info.player;camp=info.camp;
	int i,o;
	for (i=0;i<49;++i) unit[i].id=i,unit[i].lastvisit=0;
	for (i=39;i<49;++i) unit[i].priority=-1;
	//Hero
	push(unit[39],6,144);
	push(unit[40],4,144);
	push(unit[41],6,146);
	push(unit[42],6,142);
	push(unit[43],8,144);
	push(unit[44],144,6);
	push(unit[45],146,6);
	push(unit[46],144,4);
	push(unit[47],144,8);
	push(unit[48],142,6);
	//Dog
	push(unit[22],monsters[0],92,116,1,"Dog",0);
	push(unit[21],monsters[0],116,116,1,"Dog",0);
	push(unit[20],monsters[0],142,116,1,"Dog",0);
	push(unit[19],monsters[0],54,75,1,"Dog",1);
	push(unit[23],monsters[0],96,75,1,"Dog",0);
	push(unit[16],monsters[0],8,34,1,"Dog",1);
	push(unit[17],monsters[0],34,34,1,"Dog",1);
	push(unit[18],monsters[0],58,34,1,"Dog",1);
	//Bow
	push(unit[26],monsters[1],54,115,1,"Bow",0);
	push(unit[24],monsters[1],8,102,1,"Bow",1);
	push(unit[28],monsters[1],96,96,1,"Bow",0);
	push(unit[25],monsters[1],54,54,1,"Bow",1);
	push(unit[27],monsters[1],142,48,1,"Bow",0);
	push(unit[29],monsters[1],96,35,1,"Bow",1);
	//Wolf
	push(unit[33],monsters[2],94,142,2,"Wolf",0);
	push(unit[32],monsters[2],116,96,2,"Wolf",0);
	push(unit[30],monsters[2],34,54,2,"Wolf",1);
	push(unit[31],monsters[2],56,8,2,"Wolf",1);
	//StoneMan
	push(unit[34],monsters[3],32,95,4,"StoneMan",1);
	push(unit[35],monsters[3],118,55,4,"StoneMan",0);
	//Dragon
	push(unit[36],monsters[4],5,5,3,"Dragon",1);
	push(unit[37],monsters[4],145,145,3,"Dragon",0);
	//Roshan
	push(unit[38],monsters[5],75,75,5,"Roshan",-1);
	//Tower+Spring
	for (i=0;i<info.units.size();++i) if (info.units[i].id>9&&info.units[i].id<14) o=info.units[i].id;
	if (o<12)
	{
		push(unit[10],specialUnits[0],75,116,true,-1,"Tower");
		push(unit[11],specialUnits[0],116,75,true,-1,"Tower");
		push(unit[14],specialUnits[2],5,145,true,-2,"Spring");
		push(unit[13],specialUnits[1],34,75,false,-1,"Tower");
		push(unit[12],specialUnits[1],75,34,false,-1,"Tower");
		push(unit[15],specialUnits[3],145,5,false,6,"Spring");
	}else
	{
		push(unit[10],specialUnits[0],75,116,false,-1,"Tower");
		push(unit[11],specialUnits[0],116,75,false,-1,"Tower");
		push(unit[14],specialUnits[2],5,145,false,6,"Spring");
		push(unit[13],specialUnits[1],34,75,true,-1,"Tower");
		push(unit[12],specialUnits[1],75,34,true,-1,"Tower");
		push(unit[15],specialUnits[3],145,5,true,-2,"Spring");
	}
}
void push_blocks(PUnit2 &a)
{
	int range=0,o;Pos p;
	if (a.id>9&&a.id<14&&a.camp!=camp) range=Tower_range;
	if (a.id>13&&a.id<16&&a.camp!=camp) range=Spring_range;
	if (a.id==38) range=8;
//	if (a.id>15&&a.id<39) range=8;
//	if (a.hp<0||a.findBuff("Reviving")||a.camp==camp) range=0;
//	range=0;
	o=int(sqrt(range));
	for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,a.pos)<=range)
	vst[p.x][p.y]=true;
}
void getmin_length(int k)
{
	int i,j,t1,t2,o,range;Pos x,p;
	memset(vst,0,sizeof(vst));
	for (i=10;i<39;++i) if (i!=k) push_blocks(unit[i]);
	for (o=0;o<=1;++o) for (i=0;i<151;++i) for (j=0;j<151;++j) min_length[o][i][j][k]=100000000;
	if (k>13&&k<16) range=LifeSpring_range;else range=0;
	o=int(sqrt(range));t1=t2=0;
	for (p.x=unit[k].pos.x-o;p.x<=unit[k].pos.x+o;++p.x) for (p.y=unit[k].pos.y-o;p.y<=unit[k].pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,unit[k].pos)<=range)
	{
		++t2;Q[t2]=p;gg[t2]=0;min_length[0][p.x][p.y][k]=0;
	}
	while (t1<t2)
	{
		++t1;j=min_length[gg[t1]][Q[t1].x][Q[t1].y][k]+1;
		for (i=0;i<4;++i)
		{
			x=Q[t1]+delta[i];
			o=abs(Map.height[Q[t1].x][Q[t1].y]-Map.height[x.x][x.y])<=1;
			if (checkPos(x)&&(vst[x.x][x.y]||!vst[Q[t1].x][Q[t1].y]))
			{
				if (j<min_length[gg[t1]][x.x][x.y][k]&&o)
				{
					min_length[gg[t1]][x.x][x.y][k]=j;
					++t2;Q[t2]=x;gg[t2]=gg[t1];
				}
	/*			if (gg[t1]==0&&j+5<min_length[1][x.x][x.y][k])
				{
					min_length[1][x.x][x.y][k]=j+5;
					++t2;Q[t2]=x;gg[t2]=1;
				}*/
			}
		}
	}
}
void init_length()
{
	int k;
	for (k=10;k<39;++k)	getmin_length(k);
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void inc(int &x,int y)
{
	x+=x/100;if (x>y) x=y;
}
void set(Operation &op,int i)
{
	op.id=i;op.type="Stop";
	op.targets.clear();
}
void change(PUnit2 &a,const PUnit &b)
{
	a.visible=true;
	strcpy(a.name,b.name);
	a.lastvisit=Round;
	a.id=b.id;
	a.player=b.player;
	a.camp=b.camp;
	a.pos=b.pos;
	a.args=b.args;
	a.buffs=b.buffs;
	a.skills=b.skills;
	if (a.id>9&&a.id<14&&a.camp==camp&&a.hp<b.hp) attack_last[a.id]=Round-1;
	a.hp=b.hp;
	a.mp=b.mp;
	a.atk=b.atk;
	a.def=b.def;
	a.speed=b.speed;
	a.exp=b.exp;
	a.range=b.range;
	a.view=b.view;
	a.level=b.level;
	if (b.id>38)
	{
		a.reviving_time=5*(b.level+1);
		const PSkill* c=b.findSkill("YellowPoint");int p=0;
		if (c!=0) p=c->level;
		if (strcmp(b.name,"Fighter")==0)
		{
			a.mp_bound=Fighter_mp;
			a.hp_bound=Fighter_base_hp+Fighter_hp_delta*a.level;
			a.atk_base=Fighter_base_atk+Fighter_atk_delta*a.level;
			a.def_base=Fighter_base_def+Fighter_def_delta*a.level;
			a.speed_base=Fighter_speed;
		}
		if (strcmp(b.name,"Archer")==0)
		{
			a.mp_bound=Archer_mp;
			a.hp_bound=Archer_base_hp+Archer_hp_delta*a.level;
			a.atk_base=Archer_base_atk+Archer_atk_delta*a.level;
			a.def_base=Archer_base_def+Archer_def_delta*a.level;
			a.speed_base=Archer_speed;
		}
		if (strcmp(b.name,"Assassin")==0)
		{
			a.mp_bound=Assassin_mp;
			a.hp_bound=Assassin_base_hp+Assassin_hp_delta*a.level;
			a.atk_base=Assassin_base_atk+Assassin_atk_delta*a.level;
			a.def_base=Assassin_base_def+Assassin_def_delta*a.level;
			a.speed_base=Assassin_speed;
		}
		a.hp_bound+=p*YellowPoint_hp_delta;
		a.atk_base+=p*YellowPoint_atk_delta;
		a.def_base+=p*YellowPoint_def_delta;
		const PBuff* d=b.findBuff("Reviving");
		if (d!=0) a.time=d->timeLeft;else a.time=0;
	}
}
void change(PUnit2 &a)
{
	a.visible=false;a.pos=a.pos_origin;
	if (a.id>38&&maydie[a.id]&&!a.findBuff("Reviving"))
	a.buffs.push_back(PBuff(7,0,5*(a.level+1)));
	if (a.id>9&&a.id<16&&(a.hp<0||a.findBuff("Reviving"))) return;
	if (a.findBuff("Reviving"))
	{
		for (i=0;i<a.buffs.size();++i)
		if (strcmp(a.buffs[i].name,"Reviving")==0)
		{
			--a.buffs[i].timeLeft;
			if (a.buffs[i].timeLeft<=0)
				a.buffs.erase(a.buffs.begin()+i);
			break;
		}
		if (a.findBuff("Reviving"))
		{
			a.hp=a.hp_bound;
			if (a.id>38) a.mp=a.mp_bound;
		}
	}else
	{
		if (a.hp<a.hp_bound) inc(a.hp,a.hp_bound);
		if (a.id>38&&a.mp<a.mp_bound) inc(a.mp,a.mp_bound);
	}
}
void change(const PPlayerInfo &info)
{
	int i,j;
	for (i=10;i<49;++i) change(unit[i]);
	for (i=0;i<info.units.size();++i)
	{
		change(unit[info.units[i].id],info.units[i]);
		if (info.units[i].id>38) 
		getmin_length(info.units[i].id);
	}
	for (i=39;i<49;++i) if (unit[i].visible&&unit[i].camp!=camp&&strcmp(unit[i].name,"Assassin")!=0)
	if (camp==0&&unit[i].pos.x+unit[i].pos.y>=170||camp==1&&unit[i].pos.x+unit[i].pos.y<=130)
	Round_last=Round;
	for (i=39;i<49;++i) set(option_final[i],i);
	area=info.areas;
	for (i=0;i<info.flights.size();++i)
	{
		PFlight a=info.flights[i];
		if (a.typeId==1)
		area.push_back(PArea(0,a.id,a.camp,Rainy_time,a.target.x,a.target.y,RainyPlace_range));
	}
#ifdef debug
	out<<"Area:"<<endl;
	for (i=0;i<area.size();++i) out<<area[i].camp<<' '<<area[i].center.x<<' '<<area[i].center.y<<' '<<area[i].timeLeft<<endl;
#endif
	for (i=10;i<14;++i)
	if (unit[i].camp==camp)
	{
		if (i==10||i==12)
		const_cast<PArg*>(unit[i]["Exp"])->val[4]=100000;
		else
		const_cast<PArg*>(unit[i]["Exp"])->val[4]=10000;
	}
	else
	if (i==10||i==12)
		const_cast<PArg*>(unit[i]["Exp"])->val[4]=100000;
	else
		const_cast<PArg*>(unit[i]["Exp"])->val[4]=10000;
	if (Round<300)
	{
		const_cast<PArg*>(unit[38]["Exp"])->val[4]=200;
		const_cast<PArg*>(unit[36]["Exp"])->val[4]=1000;
		const_cast<PArg*>(unit[37]["Exp"])->val[4]=1000;
	}else
	{
		const_cast<PArg*>(unit[36]["Exp"])->val[4]=200;
		const_cast<PArg*>(unit[37]["Exp"])->val[4]=200;
	}
	for (i=16;i<39;++i) if (!unit[i].visible) 
	{
		memset(hatred[i],0,sizeof(hatred[i]));
	}else
	{
		for (j=39;j<49;++j)
		{
			if (unit[i]["LastHit"]->val[j]>=Round-1&&unit[i]["LastHit"]->val[j]<=Round)
			hatred[i][j]+=5;
			if (unit[j].visible&&dis2(unit[i].pos,unit[j].pos)<=nearBy)
            hatred[i][j]+=1;
			if (!unit[j].visible||dis2(unit[i].pos,unit[j].pos)>maxDis0)
            hatred[i][j]=0;
			if (unit[j].findBuff("Hided"))
			hatred[i][j]=0;
		}
		if (unit[i]["OnlyTarget"]->val[0]>-1)
		hatred[i][unit[i]["OnlyTarget"]->val[0]]+=1;
		hatred[i][0]=0;
		for (j=39;j<49;++j) if (hatred[i][j]>hatred[i][0])
			hatred[i][0]=hatred[i][j];
    }
	memset(record2,0,sizeof(record2));
	int oo;
	for (i=10;i<16;++i) if (!unit[i].visible)
	{
		if (unit[i].camp==camp) unit[i].hp=-1;else
		for (j=39;j<49;++j)
		if (unit[j].camp==camp&&unit[j].hp>0&&dis2(unit[j].pos,unit[i].pos)<=144) unit[i].hp=-1;
	}
	for (i=10;i<49;++i) if (unit[i].visible) for (j=10;j<49;++j)
	if (unit[j].visible&&(j<16||j>38)&&dis2(unit[i].pos,unit[j].pos)<=maxDis1)
	{
		if (unit[i].camp==unit[j].camp) oo=0;else oo=1;
		record2[i][oo][0]+=unit[j].level;
		record2[i][oo][1]+=unit[j].hp;
		if (strcmp(unit[i].name,"Assassin")==0)
			record2[i][oo][2]+=unit[j].atk*2;
		else
			record2[i][oo][2]+=unit[j].atk;
	}
	for (i=10;i<39;++i) choose[i]=-1;
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void inc(PUnit2 &a)
{
	a.hp+=a.hp_bound/100;
	if (a.hp>a.hp_bound) a.hp=a.hp_bound;
}
void find(const PPlayerInfo &info)
{
	l=0;
	int i;
	for (i=10;i<14;++i) if (unit[i].hp>0&&!unit[i].findBuff("Reviving")) g[++l]=i;
	for (i=16;i<38;++i)
	{
		if (camp==0&&(i==16||i==17||i==36||i==31||i==30)) continue;
		if (camp==1&&(i==33||i==20||i==21||i==37||i==32)) continue;
		g[++l]=i;
	}
	for (i=39;i<49;++i) if (unit[i].visible&&unit[i].camp!=camp)
		g[++l]=i;
	needdefense=-1;
	for (i=10;i<16;++i) if (unit[i].camp==camp&&unit[i].hp>0&&!unit[i].findBuff("Reviving")&&Round>50&&attack_last[i]>=Round-50&&(needdefense==-1||attack_last[i]>=attack_last[needdefense])) needdefense=i;
	if (Round>=450&&needdefense==-1)
	{
		if (camp==0) if (unit[10].hp>0&&!unit[10].findBuff("Reviving"))
		if (attack_last[10]>=attack_last[11]||unit[11].hp<=0||unit[11].findBuff("Reviving")) needdefense=10;else needdefense=11;
		else needdefense=11;
		if (camp==1) if (unit[12].hp>0&&!unit[12].findBuff("Reviving"))
		if (attack_last[12]>=attack_last[13]||unit[13].hp<=0||unit[13].findBuff("Reviving")) needdefense=12;else needdefense=13;
		else needdefense=13;
	}
}
int path_cal(PUnit2 &a,PUnit2 &b)
{
	int o1=int(min_length[0][a.pos.x][a.pos.y][b.id]/1.2/sqrt(a.speed_base));
//	int o2=int(min_length[a.findSkill("Blink")!=0][a.pos.x][a.pos.y][b.id]/1.2/sqrt(a.speed_base));
//	if (o1<o2)
	return o1;
//	else return o2;
}
bool cmp(const Pos &x,const Pos &y)
{
	return x.x<y.x;
}
const int canchoose[6][9]={{0,0,0,0,0,0,0,0,0},{2,2,3,1,1,1,1,1,2},{6,0,0,0,0,0,0,0,0},{2,0,2,1,2,0,0,0,0},{4,0,0,0,0,0,0,0,0},{2,2,3,1,1,1,1,1,2}};
int gettype(int x,int p)
{
	if (p==0) return 0;
	if (p==1||p==5)
	{
		if (x<16) if (unit[x].camp==camp) return 0;else return 1;
		if (x>15&&x<24) return 2;
		if (x>23&&x<30) return 3;
		if (x>29&&x<34) return 4;
		if (x==34||x==35) return 5;
		if (x==36||x==37) return 6;
		if (x==38) return 7;
		if (x>38) return 8;
	}
	if (p==2)
	{
		if (x>15&&x<38) return 0;
		return 1;
	}
	if (p==3)
	{
		if (x<16) if (unit[x].camp==camp) return 0;else return 1;
		if (x>15&&x<24) return 2;
		if (x>23&&x<30) return 3;
		if (x>29&&x<39) return 4;
		if (x>38) return 5;
	}
	if (p==4)
	{
		if (x>9&&x<14) return 0;
		return 1;
	}
}
void gc(int t,int divide)
{
	int i,j,k,ss,w;double tot=0;int p[51];
	if (t>48)
	{
		int l1,l2,g1[51],g2[51],h1[51],h2[51],ti,ti2,ti3,k,o,ww[51];
		PUnit2 unit2[51];memset(p,0,sizeof(p));
		for (i=10;i<49;++i) unit2[i]=unit[i];
		ww[39]=1;ww[40]=2;ww[41]=4;ww[42]=8;ww[43]=16;
		ww[44]=1;ww[45]=2;ww[46]=4;ww[47]=8;ww[48]=16;
		for (i=10;i<49;++i) if (unit2[i].player==player&&!p[i])
		{
#ifdef debug
			out<<"------------------------------------"<<endl;
#endif
			l1=0;l2=0;ti=ss=100000;w=0;bool P=false;int SSS=0,SSSS=0,SSS3=0,target=-1,MIN=100000;
			bool canattacktower=false;
			for (j=10;j<49;++j) if (unit2[j].player==player&&!p[j]&&(choose[j]>-1&&choose[i]==choose[j]||choose[i]==j||i==choose[j]||i==j))
			{
				if (unit2[j].hp<=0||unit[j].findBuff("Reviving")) continue;
				++l1;g1[l1]=j;p[j]=1;
				if (choose[j]>-1)
				h1[l1]=path_cal(unit2[j],unit2[choose[j]]);
				else h1[l1]=0;
				if (h1[l1]<ti) ti=h1[l1];
				if (i>38) w+=ww[j];
				if (j>38||unit2[j].level<9) P=true;
				if (h1[l1]==0&&unit2[j].visible) h1[l1]=-unit2[j].findSkill(0)->cd;
				SSS+=unit2[j].hp;
				SSS3+=unit2[j].level;
				if (h1[l1]<MIN) MIN=h1[l1];
				if (j>38) target=choose[i];
#ifdef debug
				out<<"1:"<<h1[l1]<<' '<<unit2[j].hp<<' '<<unit2[j].atk_base<<' '<<unit2[j].def_base<<endl;
#endif
			}
			for (j=1;j<=l1;++j) if (h1[j]-MIN<=3&&unit2[g1[j]].hp>200) ++SSSS;
			if (SSS>=1000&&SSSS>=4&&SSS3>=36||divide==5&&SSS3>15) canattacktower=true;
			bool PPPP=(divide==5);
			for (j=1;j<=l1;++j) if (groups[j]==0) PPPP=false;
			if (needdefense!=-1&&target>15&&!PPPP)
			if (min_length[0][unit[needdefense].pos.x][unit[needdefense].pos.y][target]>50) {tot-=100000;continue;}
			for (j=10;j<49;++j) if (unit2[j].camp!=camp&&(unit[j].visible||j<39&&i>38&&j==choose[i])&&(i>38&&dis2(unit2[choose[i]].pos,unit2[j].pos)<=maxDis1||i<39&&dis2(unit2[i].pos,unit2[j].pos)<=maxDis1))
			{
				if (j>38&&(!unit[j].visible||unit[j].hp<=0||unit[j].findBuff("Reviving"))) continue;
				if (j<16&&(unit[j].hp<=0||unit[j].findBuff("Reviving"))) continue;
				++l2;g2[l2]=j;h2[l2]=0;
				const PBuff *d=unit2[j].findBuff("Reviving");
				if (d!=0) h2[l2]=d->timeLeft,unit2[j].hp=unit2[j].hp_bound;
				if (h2[l2]<ss) ss=h2[l2];
				if (h2[l2]==0&&unit2[j].visible) h2[l2]=-unit2[j].findSkill(0)->cd;
#ifdef debug
				out<<"2:"<<unit2[j].hp<<' '<<unit2[j].atk_base<<' '<<unit2[j].def_base<<endl;
#endif
			}
			if (ss==100000) ss=0;
			if (ss>ti)
			{
				if (ss>ti+2)
				{
					tot-=100000;continue;
				}
				ti=ss;
			}
			ss=0;
			for (j=1;j<=l1;++j) if (h1[j]>=ti) h1[j]-=ti;else if (ti>0) h1[j]=0;
			for (j=1;j<=l2;++j) if (h2[j]>=ti) h2[j]-=ti;else if (ti>0) h2[j]=0;
			if ((choose[i]>13&&choose[i]<16||i>13&&i<16)&&unit[choose[i]].camp==camp)
			{
				for (j=1;j<=l1;++j) if (g1[j]>38)
				{
					o=ti+h1[j];
					o+=(unit2[g1[j]].hp_bound-unit2[g1[j]].hp-o*2-1)/LifeSpring_hp_recover_delta+1;if (o==0) o=1;
					ss+=5.0*(unit2[g1[j]].hp_bound-unit2[g1[j]].hp-1)/o;
				}
				record[w][choose[i]]=ss;
				tot+=ss;
				continue;
			}
			ti2=0;ti3=0;int SS=0;
			while (l1>0&&l2>0)
			{
				++ti2;
				for (j=1;j<=l1;++j)
				{
					if (h1[j]==0)
					{
						k=-1;
						for (o=1;o<=l2;++o) if (h2[o]<=0&&unit2[g1[j]].hp>unit2[g2[o]].atk-unit2[g1[j]].def&&(k==-1||unit2[g2[o]].def<unit2[g2[k]].def)) k=o;
						if (k==-1) continue;
						o=unit2[g2[k]].hp;
						unit2[g2[k]].hp-=unit2[g1[j]].atk-unit2[g2[k]].def;
						if (unit2[g2[k]].hp<0) unit2[g2[k]].hp=0;
						if (strcmp(unit2[g1[j]].name,"Assassin")!=0&&strcmp(unit2[g1[j]].name,"Wolf")!=0) --h1[j];
					}else
					{
						if (h1[j]>0)
						{
							--h1[j];
							if (h1[j]==0&&strcmp(unit2[g1[j]].name,"Fighter")==0)
							{
								if (unit2[g1[j]].level<3) ti3+=(unit2[g1[j]].level+1)*2,ss+=(unit2[g1[j]].level+1)*40;
								else ti3+=6,ss+=120;
							}
						}
						if (h1[j]<0) ++h1[j];
					}
				}
				for (j=1;j<=l2;++j)
				{
					if (h2[j]==0&&(ti3==0||g2[j]<16||g2[j]>38))
					{
						k=-1;
						for (o=1;o<=l1;++o) if (h1[o]<=0&&unit2[g1[o]].hp>0&&(k==-1||g2[j]>15&&g2[j]<39&&(unit2[g1[o]].def>unit2[g1[k]].def&&unit2[g1[o]].hp>unit2[g2[j]].atk-unit2[g1[o]].def)||((g2[j]<16||g2[j]>38)&&unit2[g1[o]].def<unit2[g1[k]].def)||strcmp(unit2[g1[o]].name,"Tower")==0)) k=o;
						if (k==-1) continue;
						o=unit2[g1[k]].hp;
						unit2[g1[k]].hp-=unit2[g2[j]].atk-unit2[g1[k]].def;
						if (unit2[g1[k]].hp<0) unit2[g1[k]].hp=0;
						if (strcmp(unit2[g2[j]].name,"Assassin")!=0&&strcmp(unit2[g2[j]].name,"Wolf")!=0) --h2[j];
					}else
					{
						if (ti3>0) --ti3;
						if (ss>0) unit2[g2[j]].hp-=ss;
						if (h2[j]>0) --h2[j];
						if (h2[j]<0) ++h2[j];
					}
				}
				int PP=0,S=0;bool die=false;
				for (j=1;j<=l1;++j) if (unit2[g1[j]].hp<=0)
				{
#ifdef debug
					out<<"1:"<<g1[j]<<' '<<unit2[g1[j]]["Exp"]->val[4]<<endl;
#endif
					ss=ti+(ti2-1)/2+1;
					if (g1[j]>38) ++S;
					if (g1[j]<16) ss/=10;
					if (ss==0) ss=1;
					if (target>9&&target<14) ss*=1.5;
					tot-=100.0*unit2[g1[j]]["Exp"]->val[4]*15/ss;
					if (g1[j]>38) die=true;
					for (k=j;k<l1;++k) g1[k]=g1[k+1];--l1;
				}else
				{
					if (g1[j]>38&&h1[j]<=0)
					{
						if (PP==0) PP=1;
						if (unit2[g1[j]].level<9) PP=2;
					}
					inc(unit2[g1[j]]);
				}
				for (j=1;j<=l2;++j) if (unit2[g2[j]].hp<=0)
				{
#ifdef debug
					out<<"2:"<<g2[j]<<' '<<unit2[g2[j]]["Exp"]->val[4]<<endl;
#endif
					ss=ti+(ti2-1)/2+1;
					if (g2[j]>9&&g2[j]<16)
					{
						int k,sss=SSSS;
						for (k=39;k<49;++k) if (unit2[k].camp!=camp&&strcmp(unit2[k].name,"Assassin")!=0&&(!unit2[k].findBuff("Reviving")||unit2[k].findBuff("Reviving")->timeLeft<=ss))
						if (Round-unit2[k].lastvisit>50||unit2[k].level>=SSS3/5-2) --sss;
#ifdef debug
						out<<sss<<endl;
#endif
						if (sss>=3||divide==5&&SSS3>=15) canattacktower=true;
						if (!canattacktower||die)
						{
							tot-=100000;
							for (k=j;k<l2;++k) g2[k]=g2[k+1];--l2;
							continue;
						}
					}
					if (PP==0||S&&i>38&&choose[i]<16) tot+=0;else
					if (PP==1&&i>38&&choose[i]>15&&choose[i]<39) tot+=unit2[g2[j]]["Exp"]->val[4]/ss;
					else if (g2[j]>38) tot+=100.0*unit2[g2[j]]["Exp"]->val[4]*15/ss;else
					tot+=100.0*unit2[g2[j]]["Exp"]->val[4]*10/ss;
					for (k=j;k<l2;++k) g2[k]=g2[k+1];--l2;
				}else
					inc(unit2[g2[j]]);
				if (ti2>30) break;
			}
		}
#ifdef debug
		out<<tot<<endl;
#endif
		if (tot>Maxx)
		{
			Maxx=tot;memcpy(choose_final,choose,sizeof(choose));
		}
		return;
	}
	if (unit[t].camp!=camp||unit[t].findBuff("Reviving"))
	{
		choose[t]=-1;gc(t+1,divide);return;
	}
	for (i=39;i<t;++i)
	{
		if (unit[i].camp==camp&&groups[i]==groups[t]&&choose[i]!=-1)
		{
			choose[t]=choose[i];gc(t+1,divide);return;
		}
	}
	int ll=0;Pos a[51];memset(p,0,sizeof(p));
	for (i=1;i<=l;++i)
	{
		if (divide==2)
		{
			if (groups[t]==1&&g[i]!=26&&g[i]!=33&&g[i]!=22&&g[i]!=18&&g[i]!=29&&g[i]!=31) continue;
			if (groups[t]!=1&&(g[i]==26||g[i]==33||g[i]==22||g[i]==18||g[i]==29||g[i]==31)) continue;
		}
		if (Round<150&&(g[i]==34||g[i]==35)) continue;
		if (g[i]>15&&g[i]<39&&unit[g[i]].canchoose!=camp&&unit[g[i]].canchoose!=-1) continue;
		if (divide==1&&Round<72&&g[i]!=36&&g[i]!=37) continue;
		if (groups[t]==0)
		{
			bool PPPP=false;
			for (k=10;k<14;++k) if (unit[k].hp>0&&!unit[k].findBuff("Reviving")&&unit[k].camp==camp&&(needdefense==-1||needdefense==k))
			if (min_length[0][unit[k].pos.x][unit[k].pos.y][g[i]]<=41)
			{
				PPPP=true;break;
			}
			if (!PPPP) continue;
		}
		++ll;a[ll].x=path_cal(unit[t],unit[g[i]]),a[ll].y=g[i];
		if (unit[g[i]].findBuff("Reviving")&&unit[g[i]].findBuff("Reviving")->timeLeft>a[ll].x)
		a[ll].x=unit[g[i]].findBuff("Reviving")->timeLeft;
	}
	sort(a+1,a+ll+1,cmp);j=0;
	for (i=1;i<=ll;++i)
	{
		if (a[i].y>15&&a[i].y<39&&a[i].x+unit[a[i].y].hp/(unit[t].atk-unit[a[i].y].def)/4>400) continue;
		k=gettype(a[i].y,divide);
		if (p[k]<canchoose[divide][k]) ++p[k];
		else continue;
		choose[t]=a[i].y;gc(t+1,divide);
	}
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
int innerproduct(Pos x,Pos y,Pos z)
{
	return (y.x-x.x)*(z.x-x.x)+(y.y-x.y)*(z.y-x.y);
}
void decide(PCommand &cmd)
{
	int i;
	for (i=39;i<49;++i) if (option_final[i].type!="Stop")
		cmd.cmds.push_back(option_final[i]);
}
bool PiercingArrow_inrange(Pos a,Pos b,Pos c)
{
	int s1,s2;double s=3;
	s1=innerproduct(a,b,c);
	s2=innerproduct(b,a,c);
	if (s1>=0&&s2>=0) s=abs(crossProduct(a,b,c))/dis(a,b);
//	else if (s1>=0) s=dis(b,c);
//	else s=dis(a,c);
	return s<0.75;
}
void check(double value)
{
	int i;
	if (value>Max)
	{
		Max=value;for (i=39;i<49;++i) option_final[i]=option[i];
	}
	for (i=39;i<49;++i) if (unit[i].hp<=0) maydie[i]=true;else maydie[i]=false;
}
void Choose(const PPlayerInfo &info, PCommand &cmd)
{
	int select=1,s=0,i;
	if (select==0)
	{
		for (int i = 0; i < info.units.size(); i ++)
		{
			if (info.units[i].player == info.player)
			{
				Operation op;++s;
				op.id = info.units[i].id;
				if (s==1)
				op.type = "ChooseFighter";
				if (s==2||s==3||s==4||s==5)
				op.type = "ChooseArcher";
				op.targets.clear();
				cmd.cmds.push_back(op);
			}
		}
		memcpy(Skills,skills[0],sizeof(skills[0]));
	}
	if (select==1)
	{
		for (int i = 0; i < info.units.size(); i ++)
		{
			if (info.units[i].player == info.player)
			{
				Operation op;++s;
				op.id = info.units[i].id;
				op.type = "ChooseArcher";
				op.targets.clear();
				cmd.cmds.push_back(op);
			}
		}
		memcpy(Skills,skills[1],sizeof(skills[1]));
	}
}
bool cmp2(const int &x,const int &y)
{
	if (unit[x].hp<=50&&unit[y].hp>50) return true;
	if (unit[x].hp>50&&unit[y].hp<=50) return false;
	return unit[x].def<unit[x].def;
}
void InfectedBySkill(PUnit2 &a,int typeId,vector<int> &list)
{
    list.clear();
    int range = 0;
    switch (typeId) {
        case 0: {
            range=a["Range"]->val[0];
            break;
        }
        case 1: {
            range = Charge_range;
            break;
        }
        case 3: {
            range = Spin_range;
            break;
        }
        case 5: {
            range = Yell_range;
            break;
        }
        case 7: {
            range = PiercingArrow_range;
            break;
        }
        case 9: {
            range = RainyPlace_range;
            break;
        }
        case 15: {
            range = FlyingBlade_range;
            break;
        }
        case 17: {
            range = Blink_range;
            break;
        }
    }
    if (!range) return;
    for (int i=10; i<49; ++i)
	{
		if (unit[i].visible&&dis2(a.pos, unit[i].pos) <= range && unit[i].camp != a.camp&&unit[i].hp>0&&!unit[i].findBuff("Reviving")&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{
			if (typeId>0&&i>9&&i<16) continue;
			if (typeId==1&&unit[i].findBuff("Dizzy")&&unit[i].findBuff("Dizzy")->timeLeft>1) continue;
			if (typeId==3&&i>15&&i<39&&unit[i].priority<3) continue;
			if (typeId!=1||min_length[0][a.pos.x][a.pos.y][i]<=10000)
			list.push_back(i);
		}
	}
}
double path_length(vector<Pos> &path)
{
	int i,j,k;double s,f[1001];bool p;
	for (i=0;i<path.size();++i) f[i]=1000;f[0]=0;
	for (i=1;i<path.size();++i) for (j=0;j<i;++j)
	{
		p=true;
		for (k=j+1;k<i;++k)
		if (!checkOnLine(path[i],path[j],path[k]))
		{
			p=false;break;
		}
		if (p)
		{
			s=f[j]+dis(path[j],path[i]);
			if (s<f[i]) f[i]=s;
		}
	}
	return f[path.size()-1]*f[path.size()-1];
}
void path_truncation(vector<Pos> &path,int len)
{
	int i,j,k;double f[1001],s;bool p;
	for (i=0;i<path.size();++i) f[i]=1000;f[0]=0;
	for (i=1;i<path.size();++i)
	{
		for (j=0;j<i;++j)
		{
			p=true;
			for (k=j+1;k<i;++k)
			if (!checkOnLine(path[i],path[j],path[k]))
			{
				p=false;break;
			}
			if (p)
			{
				s=f[j]+dis(path[j],path[i]);
				if (s<f[i]) f[i]=s;
			}
		}
		if (f[i]*f[i]>len)
		{
			while (path.size()>i) path.erase(path.end());
			return;
		}
	}
}
bool Cmp(const int &x,const int &y)
{
	return x>y;
}
double getprobability(PUnit2 &a,int typeId,int id,Pos p)
{
	int range=0;
	if (a.id==38) return 10;
	if (a.id>15&&a.id<39) return 1.1;
//	out<<typeId<<endl;
	switch (typeId) {
        case 0: {
            range=a["Range"]->val[0];
            break;
        }
        case 1: {
            range = Charge_range;
            break;
        }
        case 3: {
            range = Spin_range;
            break;
        }
        case 5: {
            range = Yell_range;
            break;
        }
        case 7: {
            range = PiercingArrow_range;
            break;
        }
        case 9: {
            range = RainyPlace_range;
            break;
        }
        case 15: {
            range = FlyingBlade_range;
            break;
        }
        case 17: {
            range = Blink_range;
            break;
        }
    }
	if (range==0) return 0;
	int o=100000,s1=0,s2=0,i,len;
	bool p1=false,p2=false;
	double s=0;
	for (i=39;i<49;++i) if (unit[i].camp==camp)
	{
		len=dis2(unit[i].pos,a.pos);
		if (i==id) len=dis2(p,a.pos);
		if (unit[i].hp>0&&!unit[i].findBuff("Reviving")&&unit[i].hp<o&&len<=range) o=unit[i].hp;
	}
	for (i=39;i<49;++i) if (unit[i].camp==camp)
	{
		len=dis2(unit[i].pos,a.pos);
		if (i==id) len=dis2(p,a.pos);
		if (unit[i].hp>0&&!unit[i].findBuff("Reviving")&&len<=range)
		{
			if (unit[i].hp<=o+20)
			{
				++s1;
				if (i==id) p1=true;
			}
			++s2;
			if (i==id) p2=true;
		}
	}
	if (p1) s+=0.9*p1/s1;
	if (p2) s+=0.1*p2/s2;
//	out<<range<<' '<<a.id<<' '<<id<<' '<<s1<<' '<<s2<<' '<<p1<<' '<<p2<<' '<<s<<endl;
	if (a.id<16) s*=1.1;
	return s;
}
double getdamage(Pos p,PUnit2 &a)
{
#ifdef debug
	out<<a.id<<"begin"<<endl;
#endif
	int i,Max,j,o,l,ti=0;double factor,s,len,o1,o2,o3,tot1=0,tot2=0,tot3=0,tot4=0,w[6];
	const PSkill *c;bool P;memset(w,0,sizeof(w));
	const PBuff *d;Max=0;
	for (j=0;j<area.size();++j) if (area[j].camp!=a.camp&&area[j].containPos(p))
	{
		i=2+int(RainyPlace_range-dis(a.pos,p));
		if (i>ti) ti=i;
		if (RainyPlace_range-dis(a.pos,p)>Max) Max=RainyPlace_range-dis(a.pos,p);
	}
	if (Round<=60) o=0;
	if (Round<=120) o=1;
	if (Round>120) o=2;
	tot4+=ti*(Rainy_damage[o]+30)+Max;
	tot3+=ti*Rainy_damage[o];
	o1=1.5;
	for (i=10;i<49;++i) if ((i<16||i>38)&&unit[i].camp!=camp&&unit[i].hp>0&&dis2(unit[i].pos,p)<=maxDis1)
	o1=3.5;
	for (i=39;i<49;++i) if (unit[i].camp==camp&&i!=a.id)
	{
		if (dis(p,unit[i].pos)<o1) tot4+=(o1-dis(p,unit[i].pos))*2;
		if (i<a.id&&option2[i][0].targets.size()>0)
		{
			s=dis(p,option2[i][0].targets[option2[i][0].targets.size()-1]);
			if (s<o1) tot4+=(o1-s)*2;
		}
	}
	for (i=10;i<49;++i) if (unit[i].camp!=a.camp)
	{
		if (unit[i].findBuff("Reviving")||unit[i].hp<=0) continue;
		if (unit[i].findBuff("Dizzy")) continue;
		if (dis2(unit[i].pos,p)>maxDis1) continue;
		if (unit[i].hp<=a.atk-unit[i].def) continue;
		l=0;factor=0.1;
		Max=0;j=unit[i]["OnlyTarget"]->val[0];
		len=dis(p,unit[i].pos);
		o1=sqrt(unit[i]["Range"]->val[0]);
		o2=o3=sqrt(unit[i].speed);
		o2+=o1;o3+=o2;
		if (i>15&&i<39&&(dis2(p,unit[i].pos_origin)>maxDis0||dis2(p,unit[i].pos)>maxDis1)) o1=o2=o3=-1;
		if (j==-1||j==a.id)
		{
			P=(hatred[i][0]==hatred[i][a.id]&&hatred[i][0]>0||hatred[i][0]<=hatred[i][a.id]+1&&dis2(p,unit[i].pos)<=nearBy);
			if (len<=o3&&(i>38||i<16||P))
			{
				s=unit[i].atk-a.def;
				if (s<5) s=5;
				if (Map.height[unit[i].pos.x][unit[i].pos.y]+2<=Map.height[p.x][p.y]&&Map.height[p.x][p.y]!=1000) s/=2;
				s*=getprobability(unit[i],0,a.id,p);
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
				o=a["Range"]->val[0];
				if (o>len*len) tot2+=(sqrt(o)-len)*0.01;
			}
		}
		if (i>38)
		{
		if (unit[i].CanUseSkill(1))
		{
			c=unit[i].findSkill("Charge");
			o1=sqrt(Charge_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=Charge_damage[c->level]+Charge_dizzy_time[c->level]*record2[a.id][1][2]*0.5;
				s*=getprobability(unit[i],1,a.id,p);
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}
	/*	if (unit[i].CanUseSkill(3))
		{
			c=unit[i].findSkill("Spin");
			o1=sqrt(Spin_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=Spin_damage[c->level];
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}*/
	/*	if (unit[i].CanUseSkill(5))
		{
			c=unit[i].findSkill("Yell");
			o1=sqrt(Yell_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=10;
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}*/
		if (unit[i].CanUseSkill(7))
		{
			c=unit[i].findSkill("PiercingArrow");
			o1=sqrt(PiercingArrow_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=PiercingArrow_damage[c->level];
				s*=getprobability(unit[i],7,a.id,p);
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}
	/*	if (unit[i].CanUseSkill(9))
		{
			c=unit[i].findSkill("ArrowsRain");
			o1=sqrt(SignalArrow_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=(Rainy_damage[c->level]+record2[a.id][1][2])*2;
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}*/
		if (unit[i].CanUseSkill(15))
		{
			c=unit[i].findSkill("FlyingBlade");
			o1=sqrt(PiercingArrow_range);
			o2=o3=sqrt(unit[i].speed);
			o2+=o1;o3+=o2;
			if (len<=o3)
			{
				s=FlightBlade_damage[c->level];
				s*=getprobability(unit[i],15,a.id,p);
				if (len>o1) s*=0.9;
				if (len>o2) s*=0.1;
				w[++l]=s;
			}
		}
		}
		if (l>0)
		sort(w+1,w+l+1,Cmp);
		if (i<39) tot4+=(w[1]+w[2]*0.9+w[3]*0.2)*factor;
		else tot2+=(w[1]+w[2]*0.9+w[3]*0.2)*factor;
		if (i>38) factor=0.8;else if (i<16) factor=1.2;else factor=1.1;
		tot3+=(w[1]+w[2]*0.9+w[3]*0.2)*factor;
	}
	l=0;
	if (a.CanUseSkill(0))
	{
		Max=0;j=a["OnlyTarget"]->val[0];
		o1=sqrt(a["Range"]->val[0]);
		o2=o3=sqrt(a.speed);
		if (strcmp(a.name,"Fighter")==0) o2=o3=0;
		o2+=o1;o3+=o2;
		for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{
			if (i<16&&choose_final[a.id]!=i) continue;
			len=dis(p,unit[i].pos);
			if ((j==-1||j==i)&&len<=o1)
			{
				s=a.atk-unit[i].def;
				if (s<5) s=5;
				if (Map.height[unit[i].pos.x][unit[i].pos.y]>=Map.height[p.x][p.y]+2&&Map.height[unit[i].pos.x][unit[i].pos.y]!=1000) s/=2;
			//	if (len>o1) s*=0.6;
			//	if (len>o2) s*=0.3;
				if (s>Max) Max=s;
			}
		}
	}
	w[++l]=Max;Max=0;
	if (a.CanUseSkill(1))
	{
		c=a.findSkill("Charge");
		for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{		
			if (dis2(p,unit[i].pos)<=Charge_range)
			{
				s=Charge_damage[c->level]+Charge_dizzy_time[c->level]*record2[i][1][2]*0.5;
				if (s>Max) Max=s;
			}
		}
	}
	w[++l]=Max;Max=0;
	if (a.CanUseSkill(7))
	{
		c=a.findSkill("PiercingArrow");
		for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{
			if (dis2(p,unit[i].pos)<=PiercingArrow_range)
			{
				s=PiercingArrow_damage[c->level];
				if (s>Max) Max=s;
			}
		}
	}
	w[++l]=Max;Max=0;
	if (a.CanUseSkill(9))
	{
		c=a.findSkill("ArrowsRain");
		for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{
			if (dis2(p,unit[i].pos)<=SignalArrow_range)
			{
				s=(Rainy_damage[c->level]+record2[i][1][2])*2;
				if (s>Max) Max=s;
			}
		}
	}
	w[++l]=Max;Max=0;
	if (a.CanUseSkill(15))
	{
		c=a.findSkill("FlyingBlade");
		for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
		{
			if (dis2(p,unit[i].pos)<=FlyingBlade_range)
			{
				s=FlightBlade_damage[c->level]+record2[i][1][2];
				if (s>Max) Max=s;
			}
		}
	}
	w[++l]=Max;
	s=0;
	if (a.CanUseSkill(3))
	for (i=10;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[i].findBuff("Reviving")==0&&unit[i].hp>0&&unit[choose_final[a.id]].priority>=unit[i].priority)
	{
		c=a.findSkill("Spin");
		if (dis2(p,unit[i].pos)<=Spin_range)
		{
			s+=Spin_damage[c->level];
		}
	}
	w[++l]=s;
	if (l>0)
	sort(w+1,w+l+1,Cmp);
	tot1=w[1]+w[2]*0.9+w[3]*0.2;
#ifdef debug
	out<<a.id<<' '<<p.x<<' '<<p.y<<' '<<tot1<<' '<<tot2<<' '<<tot3<<endl;
#endif
	if (a.hp>tot3*2) return tot1-tot4;
	if (a.hp<=tot3) return -tot2-tot4-10000;
	else return tot1-tot2-tot4;
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void Stop(PUnit2 &a,Operation &op)
{
	op.id=a.id;
	op.type="Stop";
	op.targets.clear();
}
double LevelUp(PUnit2 &a, Operation &op)
{
	op.id=a.id;const PSkill* d;
	int i=0,o=a.id;
	if (a.id<44) o-=39;else o-=44;
	if (strcmp(a.name,"Fighter")==0)
	{
		d=a.findSkill("Charge");
		if (d) i+=d->level+1;
		d=a.findSkill("Spin");
		if (d) i+=d->level+1;
		d=a.findSkill("Yell");
		if (d) i+=d->level+1;
		d=a.findSkill("YellowPoint");
		if (d) i+=d->level+1;
		i=Skills[o][i];
		if (i==1)
		{
//			const_cast<PSkill*>(a.findSkill("Charge"))->level++;
			op.type="ChargeLU";
		}
		if (i==2)
		{
//			const_cast<PSkill*>(a.findSkill("Spin"))->level++;
			op.type="SpinLU";
		}
		if (i==3)
		{
//			const_cast<PSkill*>(a.findSkill("Yell"))->level++;
			op.type="YellLU";
		}
		if (i==4)
		{
//			const_cast<PSkill*>(a.findSkill("YellowPoint"))->level++;
			op.type="YellowPoint";
		}
	}
	if (strcmp(a.name,"Archer")==0)
	{
		d=a.findSkill("PiercingArrow");
		if (d) i+=d->level+1;
		 d=a.findSkill("ArrowsRain");
		if (d) i+=d->level+1;
		d=a.findSkill("PowerUp");
		if (d) i+=d->level+1;
		d=a.findSkill("YellowPoint");
		if (d) i+=d->level+1;
		i=Skills[o][i];
		if (i==1)
		{
//			const_cast<PSkill*>(a.findSkill("PiercingArrow"))->level++;
			op.type="PALU";
		}
		if (i==2)
		{
//			const_cast<PSkill*>(a.findSkill("ArrowsRain"))->level++;
			op.type="ARLU";
		}
		if (i==3)
		{
//			const_cast<PSkill*>(a.findSkill("PowerUp"))->level++;
			op.type="PULU";
		}
		if (i==4)
		{
//			const_cast<PSkill*>(a.findSkill("YellowPoint"))->level++;
			op.type="YellowPoint";
		}
	}
	if (strcmp(a.name,"Assassin")==0)
	{
		d=a.findSkill("Hide");
		if (d) i+=d->level+1;
		d=a.findSkill("FlyingBlade");
		if (d) i+=d->level+1;
		d=a.findSkill("Blink");
		if (d) i+=d->level+1;
		d=a.findSkill("YellowPoint");
		if (d) i+=d->level+1;
		i=Skills[o][i];
		if (i==1)
		{
//			const_cast<PSkill*>(a.findSkill("Hide"))->level++;
			op.type="HideLU";
		}
		if (i==2)
		{
//			const_cast<PSkill*>(a.findSkill("FlyingBlade"))->level++;
			op.type="FBLU";
		}
		if (i==3)
		{
//			const_cast<PSkill*>(a.findSkill("Blink"))->level++;
			op.type="BlinkLU";
		}
		if (i==4)
		{
//			const_cast<PSkill*>(a.findSkill("YellowPoint"))->level++;
			op.type="YellowPoint";
		}
	}
	op.targets.clear();
	return LevelUp_value;
}
void FindShortestPath(PUnit2 &a)
{
	int i,j,t1,t2;Pos x;
	t1=0;t2=1;Q[1]=a.pos;
	while (t1<t2)
	{
		++t1;
		for (i=0;i<4;++i)
		{
			if (camp==0) x=Q[t1]+delta[i];
			else x=Q[t1]+delta[3-i];
			if (checkPos(x)&&abs(Map.height[Q[t1].x][Q[t1].y]-Map.height[x.x][x.y])<=1&&!vst[x.x][x.y]&&dis2(a.pos,x)<=a.speed)
			{
				vst[x.x][x.y]=true;
				path_next[x.x][x.y][a.id]=Q[t1];
				++t2;Q[t2]=x;
			}
		}
	}
}
void Move_Blink(PUnit2 &a,Operation &op1,Operation &op2)
{
	op1.id=a.id;op1.type="Stop";
	op1.targets.clear();
	op2.id=a.id;op2.type="Stop";
	op2.targets.clear();
	const PBuff* d=a.findBuff("Dizzy");
	if (d!=0) return;
	vector<Pos> path,path_final;
	int i,o=int(sqrt(a.speed)),oo=a.findSkill("Blink")!=0;
	Pos p,pp,x;double Max=-100000000;
	memset(vst,0,sizeof(vst));
	for (i=10;i<49;++i) if (dis2(a.pos,unit[i].pos)<=81) vst[unit[i].pos.x][unit[i].pos.y]=true;
	for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,a.pos)<=a.speed)
	path_next[p.x][p.y][a.id]=Pos(-1,-1);
	FindShortestPath(a);
	if (strcmp(a.name,"Fighter")==0)
	{
		for (i=16;i<49;++i) if (unit[i].visible&&dis2(a.pos,unit[i].pos)<=Charge_range&&unit[i].camp!=camp)
		move_value[a.id][i]=getdamage(unit[i].pos,a)-min_length[0][unit[i].pos.x][unit[i].pos.y][choose_final[a.id]]*0.0001;
	}
	for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,a.pos)<=a.speed)
	{
//		double ss=min_length[oo][p.x][p.y][choose_final[a.id]];
//		if (min_length[0][p.x][p.y][choose_final[a.id]]<ss)
		double ss=min_length[0][p.x][p.y][choose_final[a.id]];
		if (ss<20&&unit[choose_final[a.id]].visible) ss=dis(p,unit[choose_final[a.id]].pos);
		double s=getdamage(p,a)-ss*0.0001;
//		out<<p.x<<' '<<p.y<<' '<<s*100<<endl;
		if (p.x==a.pos.x&&p.y==a.pos.y) move_value[a.id][0]=s;
		if (s>Max||s==Max&&dis2(p,a.pos)<dis2(pp,a.pos))
		{
			path.clear();x=p;path.push_back(x);
			while (x.x>=0)
			{
				x=path_next[x.x][x.y][a.id];
				if (x.x>=0)
				path.push_back(x);
			}
			reverse(path.begin(),path.end());
			if (path.size()<1||path[0].x!=a.pos.x||path[0].y!=a.pos.y) continue;
			if (path_length(path)>a.speed) continue;
			Max=s,pp=p,path_final=path;
		}
	}
	move_value[a.id][1]=Max;
#ifdef debug
	out<<a.id<<' '<<move_value[a.id][1]<<' '<<pp.x<<' '<<pp.y<<endl;
#endif
	if (Max>-99999999.99999)
	{
		op1.id=a.id;
		op1.type="Move";
		op1.targets=path_final;
	}
/*	if (strcmp(a.name,"Assassin")==0)
	{
		Max=-100000000;
		o=int(sqrt(Blink_range));
		for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
		if (checkPos(p)&&dis2(p,a.pos)<=Blink_range)
		{
			double ss=min_length[oo][p.x][p.y][choose_final[a.id]];
			if (min_length[0][p.x][p.y][choose_final[a.id]]<ss)
			ss=min_length[0][p.x][p.y][choose_final[a.id]];
			if (ss<20&&unit[choose_final[a.id]].visible) ss=dis(p,unit[choose_final[a.id]].pos);
			double s=getdamage(p,a)-ss*0.0001;
			if (s>Max||s==Max&&dis2(p,a.pos)<dis2(pp,a.pos))
			Max=s,pp=p;
		}
		const PSkill* d=a.findSkill("Blink");
		if (d)
		Max-=(Blink_mp[d->level]+1)*0.00001;
		else Max=-100000000;
		move_value[a.id][2]=Max;
		if (Max>-99999999.99999)
		{
			op2.id=a.id;
			op2.type="Blink";
			op2.targets.push_back(pp);
		}
	}*/
}
double Attack(PUnit2 &a,int id,Operation &op)
{
	PUnit2 &b=unit[id];
	if (b.hp<0||b.findBuff("Reviving")) return -1000000;
	int o=a.atk-b.def;double ss=0;
	if (o<5) o=5;
	if (Map.height[b.pos.x][b.pos.y]>=Map.height[a.pos.x][a.pos.y]+2&&Map.height[b.pos.x][b.pos.y]!=1000) o/=2;
	if (o>b.hp) o=b.hp;
	b.hp-=o;
	op.id=a.id;
	op.type="Attack";
	op.targets.clear();
	op.targets.push_back(b.pos);
	ss=o;
	if (b.hp<=0) ss+=b["Exp"]->val[4];
	ss*=3;
	return ss;
}
double Charge(PUnit2 &a,int id,Operation &op)
{
	PUnit2 &b=unit[id];
	const PSkill* c=a.findSkill(1);
	const PBuff* d=b.findBuff("Dizzy");
	int oo=c->level,o=Charge_damage[oo];double ss=0;
	if (o>b.hp) o=b.hp;
	b.hp-=o;
	op.id=a.id;
	op.type="Charge";
	op.targets.clear();
	op.targets.push_back(b.pos);
	ss=o;
	if (d)
	{
		ss+=(Charge_dizzy_time[oo]-d->timeLeft)*record2[id][1][2];
		const_cast<PBuff*>(d)->timeLeft=Charge_dizzy_time[oo];
	}else
	{
		ss+=record2[id][1][2]*Charge_dizzy_time[oo];
		b.buffs.push_back(PBuff(4,0,Charge_dizzy_time[oo]));
	}
	if (b.hp<=0) ss+=b["Exp"]->val[4];
	if (a.mp>=Charge_mp*2)
	ss-=Charge_mp*0.1;
	else ss-=Charge_mp;
	ss*=3;
	return ss;
}
double Spin(PUnit2 &a,Operation &op,vector<int> &target)
{
	int oo=a.findSkill("Spin")->level,o;double ss=0;
	for (int i=0;i<target.size();++i) if (unit[target[i]].hp>0&&!unit[target[i]].findBuff("Reviving"))
	{
		if (i>9&&i<16) o=Spin_damage[oo]/3;
		else o=Spin_damage[oo];
		if (o>unit[target[i]].hp) o=unit[target[i]].hp;
		ss+=o;
		if (unit[target[i]].hp<=0) ss+=unit[target[i]]["Exp"]->val[4];
	}
	op.id=a.id;
	op.type="Spin";
	op.targets.clear();
	if (a.mp>=Spin_mp*2)
	ss-=Spin_mp*0.1;
	else ss-=Spin_mp;
	ss*=3;
	return ss;
}
/*double Yell(PUnit2 &a,Operation &op,vector<int> &target)
{
	const PSkill* c=a.findSkill(5);
	int oo=c->level;double ss=0;
	for (int i=0;i<target.size();++i)
	{
		const PBuff* d=unit[target[i]].findBuff("Yelled");
		if (d!=0) const_cast<PBuff*>(d)->timeLeft=Yelled_time[o];
		else
		{
			unit[target[i]].buffs.push_back(PBuff(3,o,Yelled_time[o]));
		}
		const_cast<PArg*>(unit[target[i]]["OnlyTarget"])->val[0]=a.id;
		if (i>15&&i<39) ++hatred[i][a.id];
	}
	op.id=a.id;
	op.type="Yell";
	op.targets.clear();
}*/
double PiercingArrow(PUnit2 &a,Operation &op,const PPlayerInfo &info)
{
	const PSkill* c=a.findSkill(7);
	Pos p,pp;pp.x=-1000;pp.y=-1000;double ss=0,tot,Max=0;
	int o=int(sqrt(PiercingArrow_range)),i;
	for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,a.pos)<=PiercingArrow_range&&dis2(p,a.pos)>PiercingArrow_range-15)
	{
		tot=0;
		for (i=16;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[choose_final[a.id]].priority>=unit[i].priority)
		if (unit[i].hp>0&&!unit[i].findBuff("Reviving")&&PiercingArrow_inrange(a.pos,p,unit[i].pos))
		{
			if (i<39&&(Divide!=2||unit[i].hp<190)&&(unit[i].priority<3||a.mp<120)) continue;
			if (unit[i].hp<=500) ss=1.3-unit[i].hp*0.3/500;
			if (unit[i].hp<=PiercingArrow_damage[c->level])
			tot+=(unit[i]["Exp"]->val[4]+unit[i].hp)*1.3;
			else tot+=PiercingArrow_damage[c->level]*ss;
		}
		if (tot>Max)
		{
			Max=tot;pp=p;
		}
	}
	if (pp.x!=-1000&&pp.y!=-1000)
	{
		for (i=16;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp)
		if (unit[i].hp>0&&!unit[i].findBuff("Reviving")&&PiercingArrow_inrange(a.pos,pp,unit[i].pos))
		{
			o=PiercingArrow_damage[c->level];
			if (o>unit[i].hp) o=unit[i].hp;
			unit[i].hp-=o;
			ss+=o;
			if (unit[i].hp<=0) ss+=unit[i]["Exp"]->val[4];
		}
		op.id=a.id;
		op.type="PiercingArrow";
		op.targets.clear();
		op.targets.push_back(pp);
		if (a.mp>=PiercingArrow_mp*2)
		ss-=PiercingArrow_mp*0.1;
		else ss-=PiercingArrow_mp;
		ss*=3;
		return ss;
	} else return -1000000;
}
double ArrowsRain(PUnit2 &a,Operation &op)
{
	const PSkill* c=a.findSkill(9);
	Pos p,pp;pp.x=-1000;pp.y=-1000;
	int o=int(sqrt(SignalArrow_range)),i,j;double ss,tot,Max=0,ti;
	for (p.x=a.pos.x-o;p.x<=a.pos.x+o;++p.x) for (p.y=a.pos.y-o;p.y<=a.pos.y+o;++p.y)
	if (checkPos(p)&&dis2(p,a.pos)<=SignalArrow_range)
	{
		tot=-dis(a.pos,p)/9;
		for (i=16;i<49;++i) if (unit[i].visible&&unit[i].camp!=a.camp&&unit[choose_final[a.id]].priority>=unit[i].priority)
		if (dis(unit[i].pos,p)<=RainyPlace_range&&unit[i].hp>0&&!unit[i].findBuff("Reviving"))
		{
			if (i<39&&(Divide!=2||unit[i].hp<190)&&(unit[i].priority<3||a.mp<120)) continue;
			bool P=true;
			for (j=0;j<area.size();++j) if (area[j].camp!=unit[i].camp&&area[j].containPos(unit[i].pos))
			{
				P=false;break;
			}
			if (!P) continue;
			ss=Rainy_damage[c->level]+record2[i][1][2];
			ti=int(unit[i].hp/ss)+1;
			if (Rainy_time-1<ti) ti=Rainy_time-1;
			if (ti<2) ss*=0.1;
			ss*=ti;
			ss*=0.5+(1-dis(unit[i].pos,p)/RainyPlace_range)/2;
			tot+=ss;
		}
		if (tot>Max) Max=tot,pp=p;
	}
	if (pp.x!=-1000&&pp.y!=-1000)
	{
		area.push_back(PArea(0,1000,camp,Rainy_time,pp.x,pp.y,RainyPlace_range));
		op.id=a.id;
		op.type="ArrowsRain";
		op.targets.clear();
		op.targets.push_back(pp);
		ss=Max;
		if (a.mp>=ArrowsRain_mp*2)
		ss-=ArrowsRain_mp*0.1;
		else ss-=ArrowsRain_mp;
		ss*=3;
		return ss;
	}else return -1000000;
}
/*void PowerUp(PUnit2 &a,Operation &op)
{
	const PSkill* c=a.findSkill(11);
	const PBuff* d=a.findBuff("Striking");
	int o=c->level;
	a.mp-=PowerUp_mp;
	const_cast<PSkill*>(c)->cd=c->maxCd;
	if (d!=0) const_cast<PBuff*>(d)->timeLeft=Striking_time;
	else
	{
		a.buffs.push_back(PBuff(5,o,Striking_time));
		a.atk+=PowerUp_atk_delta[o];
	}
	op.id=a.id;
	op.type="PowerUp";
	op.targets.clear();
}*/
/*void Hide(PUnit2 &a,Operation &op)
{
	const PSkill* c=a.findSkill(13);
	const PBuff* d=a.findBuff("Hided");
	int o=c->level;
	a.mp-=Hided_mp;
	const_cast<PSkill*>(c)->cd=c->maxCd;
	if (d!=0) const_cast<PBuff*>(d)->timeLeft=Hided_time;
	else
	{
		a.buffs.push_back(PBuff(0,o,Hided_time));
		a.atk+=Hided_atk_delta[o];
		a.speed+=Hided_speed_delta_rate[o];
	}
	op.id=a.id;
	op.type="Hide";
	op.targets.clear();
}
void FlyingBlade(PUnit2 &a,int id,Operation &op)
{
	PUnit2 &b=unit[id];
	const PSkill* c=a.findSkill(15);
	const PBuff* d=b.findBuff("Slow");
	int o=c->level;
	a.mp-=FlyingBlade_mp;
	const_cast<PSkill*>(c)->cd=c->maxCd;
	if (id>9&&id<16)
	b.hp-=FlightBlade_damage[o]/3;
	else
	b.hp-=FlightBlade_damage[o];
	if (d!=0)
	const_cast<PBuff*>(d)->timeLeft=Slow_time;
	else
	{
		b.buffs.push_back(PBuff(6,o,Slow_time));
	}
	op.id=a.id;
	op.type="FlyingBlade";
	op.targets.clear();
	op.targets.push_back(b.pos);
	if (id>15&&id<39) hatred[id][a.id]+=5;
}*/
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void doit(const PPlayerInfo &info,int t,double value)
{
	int i;
	if (t>48)
	{
		check(value);return;
	}
	if (unit[t].player!=player||unit[t].findBuff("Reviving"))
	{
		Stop(unit[t],option[t]);doit(info,t+1,value);return;
	}
	int hp[51];
	for (i=10;i<49;++i) hp[i]=unit[i].hp;
	if (unit[t]["Exp"]->val[3])
	{
		doit(info,t+1,value+LevelUp(unit[t],option[t])+move_value[t][0]);
	}
	if (option2[t][0].id!=-1)
	{
		option[t]=option2[t][0];
		doit(info,t+1,value+move_value[t][1]);
	}
	vector<int> target;
	if (unit[t].canUseSkill(0))
	{
		InfectedBySkill(unit[t],0,target);
		int o=unit[t]["OnlyTarget"]->val[0];int p=-1,pp;
		for (i=0;i<target.size();++i) if (o==-1||o==target[i])
		{
			if (target[i]>15&&target[i]<39) pp=0;
			if (target[i]>9&&target[i]<16) pp=0;
			if (target[i]>38) pp=1;
			if (unit[target[i]].hp<=5||unit[t].atk-unit[target[i]].def>=unit[target[i]].hp) pp=1;
			if (pp>p) p=pp;
		}
		if (p!=-1)
		{
			for (i=0;i<target.size();++i) if (o==-1||o==target[i])
			{
				if (p==0)
				if (target[i]>15&&target[i]<39||target[i]>9&&target[i]<16)
				doit(info,t+1,value+Attack(unit[t],target[i],option[t])+move_value[t][0]);
				if (p==1)
				if (target[i]>38||unit[target[i]].hp<=5||unit[t].atk-unit[target[i]].def>=unit[target[i]].hp)
				doit(info,t+1,value+Attack(unit[t],target[i],option[t])+move_value[t][0]);
				unit[target[i]].hp=hp[target[i]];
			}
		}
	}
	if (strcmp(unit[t].name,"Fighter")==0)
	{
		if (unit[t].canUseSkill(1))
		{
			InfectedBySkill(unit[t],1,target);
			int oo=-1,s=0;int p=0,pp;
			for (i=0;i<target.size();++i)
			{
				if (target[i]>9&&target[i]<16) pp=0;
				if (target[i]>15&&target[i]<39) pp=1;
				if (target[i]>38)
				{
					if (strcmp(unit[target[i]].name,"Figher")==0) pp=2;
					if (strcmp(unit[target[i]].name,"Archer")==0) pp=3;
					if (strcmp(unit[target[i]].name,"Assassin")==0) pp=4;
				}
				if (target[i]==24||target[i]==25||target[i]==27||target[i]==28) pp=-1;
				if (oo==-1||pp>p||pp==p&&(pp<=2&&unit[target[i]].atk>unit[oo].atk||pp>2&&unit[target[i]].hp>unit[oo].hp)) oo=target[i];
			}
			if (oo!=-1&&(oo>38||oo<39&&(unit[t].mp>120&&unit[oo].priority>2||Divide==2&&unit[t].hp>=190)))
			{
				int time=0;
				const PBuff* d=unit[oo].findBuff("Charge");
				if (d) time=d->timeLeft;
				doit(info,t+1,value+Charge(unit[t],oo,option[t])+move_value[t][oo]);
				if (time>0)
				const_cast<PBuff*>(unit[oo].findBuff("Charge"))->timeLeft=time;
				else unit[oo].buffs.erase(unit[oo].buffs.end());
				unit[oo].hp=hp[oo];
			}
		}
/*		if (unit[t].canUseSkill(3))
		{
			InfectedBySkill(unit[t],3,target);bool p=false;
			for (i=0;i<target.size();++i) if (target[i]>38) p=true;
			if (target.size()>0&&(p||unit[t].mp>120))
			{
				doit(info,t+1,value+Spin(unit[t],option[t],target)+move_value[t][0]);
				for (i=0;i<target.size();++i)
				unit[target[i]].hp=hp[target[i]];
			}
		}
		if (unit[t].canUseSkill(5))
		{
			InfectedBySkill(unit[t],5,target);
			if (target.size()>0)
			{
				doit(info,t+1,value+Yell(unit[t],option[t],target)+move[t][0]);
				for (i=0;i<target.size();++i)
				unit[target[i]].hp=hp[target[i]];
			}
		}*/
	}
	if (strcmp(unit[t].name,"Archer")==0)
	{
		if (unit[t].canUseSkill(7))
		{
			double s=PiercingArrow(unit[t],option[t],info);
			if (s>-10000)
			{
				doit(info,t+1,value+s+move_value[t][0]);
				for (i=10;i<49;++i) unit[i].hp=hp[i];
			}
		}
		if (unit[t].canUseSkill(9))
		{
			double s=ArrowsRain(unit[t],option[t]);
			if (s>-10000)
			{
				doit(info,t+1,value+s+move_value[t][0]);
				area.erase(area.end());
			}
		}
/*		if (unit[t].canUseSkill(11))
		{
			doit(info,t+1,value+PowerUp(unit[t],option[t]));
			unit[t]=unit_copy[t];
		}*/
	}
	if (strcmp(unit[t].name,"Assassin")==0)
	{
/*		if (unit[t].canUseSkill(13))
		{
			doit(info,t+1,value+Hide(unit[t],option[t])+move[t][0]);
		}
		if (unit[t].canUseSkill(15))
		{
			InfectedBySkill(unit[t],15,target);
			int oo=-1;
			for (i=0;i<target.size();++i)
			{
				if (oo==-1||unit[target[i]].hp<unit[oo].hp) oo=target[i];
			}
			if (oo!=-1)
			{
				doit(info,t+1,value+FlyingBlade(unit[t],oo,option[t])+move[t][0]);
				unit[oo].hp=hp[oo];
			}
		}*/
		if (unit[t].canUseSkill(17))
		{
			if (option2[t][1].id!=-1)
			{
				option[t]=option2[t][1];
				doit(info,t+1,value+move_value[t][2]);
			}
		}
	}
}
void fight(const PPlayerInfo &info)
{
	PUnit2 unit_copy[51];
	int i,j;
	for (i=10;i<49;++i) unit_copy[i]=unit[i];
	for (i=39;i<49;++i) if (unit[i].hp>0&&unit[i].camp==camp&&!unit[i].findBuff("Reviving"))
	Move_Blink(unit[i],option2[i][0],option2[i][1]);
#ifdef debug
	out<<"Move() done"<<endl;
#endif
	doit(info,39,0);
}
////////////////////////////////////////////////////

////////////////////////////////////////////////////
void changeMap()
{
	int i,j,t1,t2,o;Pos x,p;
	memset(vst,0,sizeof(vst));
	if (camp==0) Q[1].x=35,Q[1].y=85;else Q[1].x=116,Q[1].y=66;
	t1=0;t2=1;vst[Q[1].x][Q[1].y]=true;
	while (t1<t2)
	{
		++t1;x=Q[t1];
		for (i=0;i<4;++i)
		{
			p=x+delta[i];
			if (checkPos(p)&&!vst[p.x][p.y]&&Map.height[p.x][p.y]==0)
			{
				++t2;Q[t2]=p;vst[p.x][p.y]=true;
			}
		}
	}
	for (i=1;i<=t2;++i) Map.height[Q[i].x][Q[i].y]=1000;
}
int divide()
{
	int i,j,tot=0,s=0,S=0,p,o1,o2,MIN;bool P=false;
	for (i=10;i<14;++i) if (unit[i].camp==camp&&unit[i].hp>0)
	{
		++s;
		for (j=39;j<49;++j) if (unit[j].visible&&unit[j].camp==1-camp&&dis2(unit[i].pos,unit[j].pos)<=maxDis1)
		P=true;
	}
	for (i=39;i<49;++i) if (unit[i].camp!=camp&&strcmp(unit[i].name,"Assassin")==0)
	++S;
	for (i=39;i<49;++i) if (unit[i].camp==camp)
	tot+=unit[i].level,groups[i]=0;
	if (P) p=4;else if (S==5) p=5;else
	if (tot<11||Round<=150) p=1;
	else if (tot<42&&needdefense==-1&&Round-Round_last>50)
	if (s==2&&Round<=400) p=2;else p=1;
	else p=1;
	if (p==1||p==4)
	for (i=39;i<49;++i) if (unit[i].camp==camp)
		groups[i]=1;
	if (p==2)
	{
		o1=o2=-1;MIN=1000000;
		if (camp==0) o1=10;else o1=12;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&groups[i]==0)
		if (min_length[0][unit[i].pos.x][unit[i].pos.y][o1]<MIN)
		{
			MIN=min_length[0][unit[i].pos.x][unit[i].pos.y][o1];
			o2=i;
		}
		groups[o2]=1;
		o1=o2=-1;MIN=1000000;
		if (camp==0) o1=10;else o1=12;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&groups[i]==0)
		if (min_length[0][unit[i].pos.x][unit[i].pos.y][o1]<MIN)
		{
			MIN=min_length[0][unit[i].pos.x][unit[i].pos.y][o1];
			o2=i;
		}
		groups[o2]=1;
		o1=-1;MIN=0;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&groups[i]==0)
		if (unit[i].level>MIN||unit[i].level==MIN&&groups_last[i]==3)
		{
			o1=i;MIN=unit[i].level;
		}
		groups[o1]=3;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&groups[i]==0) groups[i]=2;
	}
	if (p==3)
	{
		o1=-1;MIN=100;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&(unit[i].level<MIN||unit[i].level==MIN&&groups_last[i]==2))
		{
			MIN=unit[i].level;o1=i;
		}
		groups[o1]=2;
		for (i=39;i<49;++i) if (unit[i].camp==camp&&i!=o1) groups[i]=1;
	}
	if (p==5)
	{
		S=(S+1)/2;
		for (i=39;i<49;++i) if (unit[i].camp==camp)
		if (S>0) groups[i]=0,--S;else groups[i]=1;
	}
	memcpy(groups_last,groups,sizeof(groups));
#ifdef debug
	out<<needdefense<<' '<<p<<endl;
#endif
	Divide=p;
	return p;
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
	Map=map;player=info.player;camp=info.camp;Round=info.round;
	changeMap();
	if (info.round==0)
	{
		init(info);init_length();Choose(info,cmd);return;
	}
#ifdef debug
	out<<"Round="<<Round<<endl;
#endif
	change(info);
	find(info);
	Maxx=-1000000;
	memset(record,0,sizeof(record));
	gc(39,divide());
#ifdef debug
	int i,j;
	for (i=39;i<49;++i) out<<choose_final[i]<<' ';out<<endl;
	out<<Maxx<<endl;
#endif
	memcpy(choose_last,choose_final,sizeof(choose_final));
	Max=-1e16;fight(info);
#ifdef debug
	for (i=39;i<49;++i)
	{
		out<<option_final[i].id<<' '<<option_final[i].type<<' ';
		for (j=0;j<option_final[i].targets.size();++j)
		{
			out<<'('<<option_final[i].targets[j].x<<','<<option_final[i].targets[j].y<<") ";
		}
		out<<endl;
	}
#endif
	decide(cmd);
#ifdef debug
	out<<"done"<<endl;
#endif
}
////////////////////////////////////////////////////

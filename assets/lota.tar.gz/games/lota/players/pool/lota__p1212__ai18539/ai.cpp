#include "sdk.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <ctime>
using namespace std;
//const int order[10] = {12,12,8,8,12,8,19,19,19,19};
const int order[3][10] = {{8,8,8,10,10,19,19,19,19,19},
                          {8,8,8,19,19,19,19,19,19,19},
                          {10,8,10,10,8,8,19,19,19,19}};
bool change1 = false, change2 = false;
bool collapse = false;
bool try1 = false;
int tp[50];
//const int order[10] = {19,19,19,19,19,19,19,19,19,19};
const Pos zz(0,0);
int myplayer, myround, basicBlockSize;
int def[50];
int myflag[50];
int mydef[50];
int mtotal = 0;
int roshantime = 0;
int mjx = 0;
bool tag1, tag2;
bool team[50];
bool know[50];
Pos mydes[50];
Pos mylast[50];
vector<PUnit> myHero, enemyHero, monster, myBuilding, enemyBuilding;
vector<Pos> blockPos;
vector<Pos> recommend;
vector<int> recint;
int start[50];
int steps = 0;
int tmp = 0;
vector<int> eid;
int eLevel[50];
int lastEnemy = 0;
int avic = 0;
int lastHp = 1000;
const int len = 150;
const int inf = 100000;
//int dist[len][len];
bool ban[len][len];
bool vis[len][len];
int lastdir[len][len];
vector<Pos> bfs_seq;
vector<int> trace;
int mydir[4][2] = {{0,1},{1,0},{0,-1},{-1,0}};
int rainint;
bool dan = false;
int group = 0;
int cike = 0;
//ofstream fout("out.txt");
/*
flag: 1 ���� 2 ���� 3 ���� 4 ���� 5 �ƶ� 6 ��cd 7 ��Ŀ�� 8 �������� 9 �����ж�
*/
void bfs(const vector<PArea>& areas, const PMap &map, const Pos& sta, const Pos& des, const vector<Pos> &block, vector<Pos> &path)
{
    //cout << block.size() << endl;
    if (sta == des)
        return;
    for(int i = 0; i < len; i++)
        for(int j = 0; j < len; j++)
        {
            //dist[i][j] = inf;
            ban[i][j] = false;
            vis[i][j] = false;
        }
    for(int i = 0; i < block.size(); i++)
    {
        Pos p = block[i];
        if (dis2(p,recommend[steps])>8 || dis2(p,recommend[steps])==0)
            ban[p.x][p.y] = true;
    }
    for(int i = 0; i < areas.size(); i++)
    {
        if (areas[i].camp == myplayer)
            continue;
        if (dis2(areas[i].center,sta)>25)
            for(int j = -5; j <= 5; j++)
                for(int k = -5; k <= 5; k++)
                    if (j*j+k*k<=25)
                    {
                        int nx, ny;
                        nx = areas[i].center.x + j;
                        ny = areas[i].center.y + k;
                        ban[nx][ny] = true;
                    }
    }
    if (ban[sta.x][sta.y])
    {
        for(int i = -1; i <= 1; i++)
            for(int j = -1; j <= 1; j++)
            {
                ban[sta.x+i][sta.y+j] = false;
            }
    }
    if (ban[des.x][des.y])
    {
        for(int i = -1; i <= 1; i++)
            for(int j = -1; j <= 1; j++)
            {
                ban[des.x+i][des.y+j] = false;
            }
    }
    for(int i = 0; i < recommend.size(); i++)
        ban[recommend[i].x][recommend[i].y] = true;
    bfs_seq.clear();
    trace.clear();
    bfs_seq.push_back(sta);
    trace.push_back(-1);
    int head = 0, tail = 0;
    bool myfind = false;
    vis[sta.x][sta.y] = true;
    lastdir[sta.x][sta.y] = 3;
    while (head <= tail)
    {
        Pos p = bfs_seq[head];
        int mjx, ojj;
        mjx = lastdir[p.x][p.y];
        for(int i = 0; i < 4; i++)
        if (i != mjx)
        {
            Pos np;
            np.x = p.x + mydir[i][0];
            np.y = p.y + mydir[i][1];
            if (np.x < 0 || np.y < 0 || np.x >= len || np.y >= len)
                continue;
            if (ban[np.x][np.y])
                continue;
            if (abs(map.height[p.x][p.y]-map.height[np.x][np.y])>1)
                continue;
            if (vis[np.x][np.y])
                continue;
            tail++;
            vis[np.x][np.y] = true;
            lastdir[np.x][np.y] = i;
            bfs_seq.push_back(np);
            trace.push_back(head);
            if (np == des)
            {
                myfind = true;
                break;
            }
        }
        for(int i = 0; i < 4; i++)
        if (i == mjx)
        {
            Pos np;
            np.x = p.x + mydir[i][0];
            np.y = p.y + mydir[i][1];
            if (np.x < 0 || np.y < 0 || np.x >= len || np.y >= len)
                continue;
            if (ban[np.x][np.y])
                continue;
            if (abs(map.height[p.x][p.y]-map.height[np.x][np.y])>1)
                continue;
            if (vis[np.x][np.y])
                continue;
            tail++;
            vis[np.x][np.y] = true;
            lastdir[np.x][np.y] = i;
            bfs_seq.push_back(np);
            trace.push_back(head);
            if (np == des)
            {
                myfind = true;
                break;
            }
        }
        if (myfind)
            break;
        head++;
    }
    int now = tail;
    do
    {
        path.push_back(bfs_seq[now]);
        now = trace[now];
    }
    while (now >= 0);
    reverse(path.begin(),path.end());
}
void createHero(const PPlayerInfo &info, PCommand &cmd)
{
    for(int i = 0; i < 5; i++)
    {
        Operation op;
        op.id = info.units[i].id;
        op.type = "ChooseArcher";
        op.targets.clear();
        cmd.cmds.push_back(op);
    }
    for(int i = 0; i < 50; i++)
    {
        myflag[i] = 0;
        mydes[i].x = 0;
        mydes[i].y = 0;
        mylast[i].x = 0;
        mylast[i].y = 0;
    }
}
void getBlockList(const PPlayerInfo &info)
{
    blockPos.clear();
    Pos tmp;
    for(int i = 0; i < 2; i++)
    {
        tmp = Player0_tower_pos[i];
        blockPos.push_back(tmp);
/*        if (myplayer == 1)
            blockPos.push_back(tmp);
        else
        {
            for(int j = -10; j <= 10; j++)
                for(int k = -10; k <= 10; k++)
                {
                    if (j*j+k*k<=100)
                    {
                        Pos pp = tmp;
                        tmp.x += j;
                        tmp.y += k'
                        blockPos.push_back(pp);
                    }
                }
        }*/
    }//0,1
    for(int i = 0; i < 1; i++)
    {
        tmp = Player0_spring_pos[i];
        blockPos.push_back(tmp);
    }//2
    for(int i = 0; i < 2; i++)
    {
        tmp = Player1_tower_pos[i];
        blockPos.push_back(tmp);
/*        if (myplayer == 0)
            blockPos.push_back(tmp);
        else
        {
            for(int j = -10; j <= 10; j++)
                for(int k = -10; k <= 10; k++)
                {
                    if (j*j+k*k<=100)
                    {
                        Pos pp = tmp;
                        tmp.x += j;
                        tmp.y += k'
                        blockPos.push_back(pp);
                    }
                }
        }*/
    }//3,4
    for(int i = 0; i < 1; i++)
    {
        tmp = Player1_spring_pos[i];
        blockPos.push_back(tmp);
    }//5
    for(int i = 0; i < 8; i++)
    {
        tmp = Dog_pos[i];
        for(int j = -1; j <= 1; j++)
            for(int k = -1; k <= 1; k++)
            if(j*j+k*k<=9)
            {
                Pos pp = tmp;
                pp.x += j;
                pp.y += k;
                blockPos.push_back(pp);
            }
    }//6,7,8,9,10,11,12,13
    for(int i = 0; i < 6; i++)
    {
        tmp = Bow_pos[i];
        for(int j = -1; j <= 1; j++)
            for(int k = -1; k <= 1; k++)
            if(j*j+k*k<=9)
            {
                Pos pp = tmp;
                pp.x += j;
                pp.y += k;
                blockPos.push_back(pp);
            }
    }//14,15,16,17,18,19
    for(int i = 0; i < 4; i++)
    {
        tmp = Wolf_pos[i];
        for(int j = -2; j <= 2; j++)
            for(int k = -2; k <= 2; k++)
            if(j*j+k*k<=9)
            {
                Pos pp = tmp;
                pp.x += j;
                pp.y += k;
                blockPos.push_back(pp);
            }
    }//20,21,22,23
    for(int i = 0; i < 2; i++)
    {
        tmp = StoneMan_pos[i];
        for(int j = -1; j <= 1; j++)
            for(int k = -1; k <= 1; k++)
            {
                Pos pp = tmp;
                pp.x += j;
                pp.y += k;
                blockPos.push_back(pp);
            }
    }//24,25
    for(int i = 0; i < 2; i++)
    {
        tmp = Dragon_pos[i];
        for(int j = -1; j <= 1; j++)
            for(int k = -1; k <= 1; k++)
            {
                Pos pp = tmp;
                pp.x += j;
                pp.y += k;
                blockPos.push_back(pp);
            }
    }//26,27
    for(int i = 0; i < 1; i++)
    {
        tmp = Roshan_pos[i];
        for(int j = -2; j <= 2; j++)
            for(int k = -2; k <= 2; k++)
            {
                if (j*j+k*k<=9)
                {
                    Pos pp = tmp;
                    pp.x += j;
                    pp.y += k;
                    blockPos.push_back(pp);
                }
            }
    }//28
    basicBlockSize = blockPos.size();
    //cout << "basic = " << basicBlockSize << endl;
}
void getLists(const PPlayerInfo &info)
{
    myHero.clear();
    enemyHero.clear();
    monster.clear();
    myBuilding.clear();
    enemyBuilding.clear();
    for(int i = 0; i < info.units.size(); i++)
    {
        //cout << "fine" << endl;
        const PBuff* now = info.units[i].findBuff("Reviving");
        //cout << "fine" << endl;
        if (now != NULL)
        {
            if (info.units[i].player == myplayer)
            {
                myflag[info.units[i].id] = 0;
                mydes[info.units[i].id] = zz;
            }
            else if (info.units[i].player == 1 - myplayer)
            {
                if (!eLevel[info.units[i].id])
                {
                    eLevel[info.units[i].id] = info.units[i].level + 1;
                    eid.push_back(info.units[i].id);
                }
                else
                    eLevel[info.units[i].id] = info.units[i].level + 1;
                def[info.units[i].id] = 0;
            }
            else
            {
                if (info.units[i].id == recint[steps])
                {
                    steps++;
                    if (info.units[i].name == "Roshan")
                        roshantime = 75;
                }
            }
            continue;
        }
        if (info.units[i].isWild())
        {
            monster.push_back(info.units[i]);
        }
        else if (info.units[i].player == myplayer)
        {
            if (info.units[i].isHero())
            {
                myHero.push_back(info.units[i]);
            }
            else
            {
                myBuilding.push_back(info.units[i]);
            }
        }
        else
        {
            if (info.units[i].isHero())
            {
                enemyHero.push_back(info.units[i]);
                if (!eLevel[info.units[i].id])
                {
                    eLevel[info.units[i].id] = info.units[i].level + 1;
                    eid.push_back(info.units[i].id);
                    if (strcmp(info.units[i].name,"Assassin")==0)
                        cike++;
                }
                else
                    eLevel[info.units[i].id] = info.units[i].level + 1;
            }
            else
            {
                enemyBuilding.push_back(info.units[i]);
            }
        }
    }
    if (myBuilding.size() == 2)
        mjx++;
}
void addBlocks(bool more)
{
    //int cnt = 0;
    while (blockPos.size() > basicBlockSize)
    {
        //cnt++;
        //cout << "cnt = " << cnt << endl;
        blockPos.pop_back();
    }
    for(int i = 0; i < monster.size(); i++)
    {
        Pos p = monster[i].pos;
        blockPos.push_back(p);
    }
    /*for(int i = 0; i < enemyHero.size(); i++)
    {
        Pos p = enemyHero[i].pos;
        blockPos.push_back(p);
    }*/
    if (more)
    {
        if (myplayer == 0)
        {
            Pos tmp;
            if (!collapse)
            {
                tmp.x = 34;
                tmp.y = 75;
                for(int i = -10; i <= 10; i++)
                    for(int j = -10; j <= 10; j++)
                        if (i*i+j*j<=100)
                        {
                            Pos pp;
                            pp.x = tmp.x + i;
                            pp.y = tmp.y + j;
                            blockPos.push_back(pp);
                        }
            }
            tmp.x = 75;
            tmp.y = 34;
            for(int i = -10; i <= 10; i++)
                for(int j = -10; j <= 10; j++)
                    if (i*i+j*j<=100)
                    {
                        Pos pp;
                        pp.x = tmp.x + i;
                        pp.y = tmp.y + j;
                        blockPos.push_back(pp);
                    }
        }
        else
        {
            Pos tmp;
            tmp.x = 75;
            tmp.y = 116;
            for(int i = -10; i <= 10; i++)
                for(int j = -10; j <= 10; j++)
                    if (i*i+j*j<=100)
                    {
                        Pos pp;
                        pp.x = tmp.x + i;
                        pp.y = tmp.y + j;
                        blockPos.push_back(pp);
                    }
            if (!collapse)
            {
                tmp.x = 116;
                tmp.y = 75;
                for(int i = -10; i <= 10; i++)
                    for(int j = -10; j <= 10; j++)
                        if (i*i+j*j<=100)
                        {
                            Pos pp;
                            pp.x = tmp.x + i;
                            pp.y = tmp.y + j;
                            blockPos.push_back(pp);
                        }
            }
        }
    }
}
void runaway(const vector<PArea>& areas, const PMap &map, const PUnit &u, PCommand &cmd)
{
    bool boo = false;
    bool at1 = false, at2 = false;;
    int sum = 0;
    for(int i = 0; i < enemyHero.size(); i++)
    {
        Pos p1 = u.pos;
        Pos p2 = enemyHero[i].pos;
        if (dis2(p1,p2) <= enemyHero[i].range)
        {
            //sum += enemyHero[i].atk;
            at1 = true;
        }
    }
    if (enemyHero.size() > 0)
        sum /= enemyHero.size();
    int mm = 0;
    for(int i = 0; i < myHero.size(); i++)
        if (dis2(u.pos, myHero[i].pos) <= 81)
            mm++;
    int me = 0;
    for(int i = 0; i < enemyHero.size(); i++)
        if (dis2(u.pos, enemyHero[i].pos) <= 210)
            me++;
    for(int i = 0; i < myBuilding.size(); i++)
        if (dis2(u.pos, myBuilding[i].pos) <= 49)
            mm+=5;
    for(int i = 0; i < enemyBuilding.size(); i++)
    {
        if (enemyBuilding[i].name == "Spring") continue;
        Pos p1 = u.pos;
        Pos p2 = enemyBuilding[i].pos;
        if (dis2(p1,p2) <= enemyBuilding[i].range && enemyBuilding[i].hp >= 900)
        {
            //sum += enemyBuilding[i].atk;
            at2 = true;
        }
    }
    for(int i = 0; i < monster.size(); i++)
    {
        if (monster[i].name == "Spring") continue;
        Pos p1 = u.pos;
        Pos p2 = monster[i].pos;
        if (dis2(p1,p2) <= monster[i].range)
        {
            //sum += monster[i].atk;
        }
    }
    if (myflag[u.id] == 1 && !at2 && (u.hp > u.max_hp * 0.35) || dis2(u.pos, mydes[u.id]) <= 16)
    {
        myflag[u.id] = 0;
        mydes[u.id] = zz;
        return;
    }
    if (myflag[u.id] == 1 || sum >= u.hp + u.def /*|| mm + 1 < me*/)
        boo = true;
    if (steps == 7 && dis2(u.pos, recommend[7]) <= 81 || steps == 14 && dis2(u.pos, recommend[14]) <= 81 ||
        steps == 25 && dis2(u.pos, recommend[25]) <= 81)
        boo = false;
    //if (at1 && at2 && me > 1 && )
      //  boo = true;
    if (at1 && steps == 12)
    {
        boo = true;
        steps++;
    }
    if (boo)
    {
        Operation op;
        op.id = u.id;
        op.type = "Move";
        Pos pp;
        if (myplayer == 0)
        {
            if (u.hp > 0.30 * u.max_hp)
            {
                Pos p1(75,116), p2(116,75);
                if (dis2(u.pos, p1) < dis2(u.pos, p2))
                    pp = p1;
                else
                    pp = p2;
            }
            else
            {
                pp.x = 5;
                pp.y = 145;
            }
            pp.x += (rand()%5) - 2;
            pp.y += (rand()%5) - 2;
            if (pp.x == 5 && pp.y == 145)
                pp.x++;
        }
        else
        {
            if (u.hp > 0.30 * u.max_hp)
            {
                Pos p1(75,34), p2(34,75);
                if (dis2(u.pos, p1) < dis2(u.pos, p2))
                    pp = p1;
                else
                    pp = p2;
            }
            else
            {
                pp.x = 145;
                pp.y = 5;
            }
            pp.x += (rand()%5) - 2;
            pp.y += (rand()%5) - 2;
            if (pp.x == 145 && pp.y == 5)
                pp.y++;
        }
        addBlocks(!at2);
        bfs(areas, map, u.pos, pp, blockPos, op.targets);
        cmd.cmds.push_back(op);
        myflag[u.id] = 1;
        mydes[u.id] = pp;
    }
}
void upLevel(const PUnit &u, PCommand &cmd)
{
    const PArg* now = u["Exp"];
    if (now->val[3] > 0)
    {
        //cout << now->val[2] << endl;
        Operation op;
        op.id = u.id;
        //int rr = rand()%3;
        if (cike >= 3 && u.level == 1)
            op.typeId = 12;
        else if (myflag[u.id] == 2)
            op.typeId = 19;
        else
            op.typeId = order[tp[u.id]][now->val[2]];
        op.targets.clear();
        cmd.cmds.push_back(op);
        myflag[u.id] = 2;
    }
}
Pos cal_attack(const PUnit& u)
{
    Pos pp(0,0);
    int hpmin = 1000;
    for(int i = 0; i < enemyHero.size(); i++)
        if (enemyHero[i].hp < hpmin && dis2(u.pos,enemyHero[i].pos) <= 81)
        {
            pp = enemyHero[i].pos;
            hpmin = enemyHero[i].hp;
        }
    return pp;
}
Pos cal_rain(const PUnit& u)
{
    int num_max = 0;
    Pos pp(0,0);
    for(int i = -10; i <= 10; i++)
        for(int j = -10; j <= 10; j++)
            if (i*i+j*j<=100)
            {
                int cnt = 0;
                Pos ptmp = u.pos;
                ptmp.x += i;
                ptmp.y += j;
                if (ptmp.x < 0 || ptmp.x >= 150 || ptmp.y < 0 || ptmp.y >= 150)
                    continue;
                for(int k = 0; k < enemyHero.size(); k++)
                    if (dis2(ptmp,enemyHero[k].pos) <= 25)
                        cnt++;
                if (cnt > num_max)
                {
                    num_max = cnt;
                    pp = ptmp;
                }
            }
    return pp;
}
Pos cal_arrow(const PUnit& u)
{
    int num_max = 0;
    Pos pp(0,0);
    for(int i = -9; i <= 9; i++)
        for(int j = -9; j <= 9; j++)
            if (i*i+j*j<=81 && i*i+j*j>0)
            {
                int cnt = 0;
                Pos pt1 = u.pos;
                pt1.x += i;
                pt1.y += j;
                for(int k = 0; k < enemyHero.size(); k++)
                {
                    Pos pt2 = enemyHero[k].pos - u.pos;
                    int v1 = dis2(pt1,u.pos);
                    int v2 = i*pt2.x+j*pt2.y;
                    if (v2 > v1 || v2 < 0)
                        continue;
                    int v3 = dis2(enemyHero[k].pos,u.pos);
                    if (v3-(v2*v2-0.01)/(v1-0.01) <= 2.25)
                        cnt++;
                }
                if (cnt > num_max)
                {
                    num_max = cnt;
                    pp = pt1;
                }
            }
    return pp;
}
void attackUnit(const PUnit &u, PCommand &cmd)
{
    if (myflag[u.id] == 1 || myflag[u.id] == 2) return;
    const PSkill* sk = u.findSkill("Attack");
    if (sk->cd > 0)
    {
        myflag[u.id] = 6;
        return;
    }
    Operation op;
    op.id = u.id;
    op.type = "Attack";
    if (myround >= 970 || mtotal >= 35)
    {
    for(int i = 0; i < enemyBuilding.size(); i++)
    {
        Pos p1 = u.pos, p2 = enemyBuilding[i].pos;
        if (dis2(p1, p2) <= u.range && (steps == 7 || steps == 17))
        {
            if (u.canUseSkill(11) && u.level <= 3)
                op.type = "PowerUp";
            else if (u.canUseSkill(7))
                op.type = "PiercingArrow";
            if (strcmp(op.type.c_str(),"PowerUp") != 0)
                op.targets.push_back(p2);
            cmd.cmds.push_back(op);
            myflag[u.id] = 3;
            mydes[u.id] = zz;
            return;
        }
    }
    }
    for(int i = 0; i < enemyHero.size(); i++)
    {
        Pos p1 = u.pos, p2 = enemyHero[i].pos;
        if (dis2(p1, p2) <= u.range)
        {
            if (u.canUseSkill(9) && rainint == 0)
            {
                op.type = "ArrowsRain";
                rainint = 5;
            }
            else if (u.canUseSkill(7))
                op.type = "PiercingArrow";
            else if (u.canUseSkill(11))
                op.type = "PowerUp";
            if (strcmp(op.type.c_str(),"Attack") == 0)
            {
                Pos p3 = cal_attack(u);
                op.targets.push_back(p3);
            }
            if (strcmp(op.type.c_str(),"ArrowsRain") == 0)
            {
                Pos p3 = cal_rain(u);
                op.targets.push_back(p3);
            }
            if (strcmp(op.type.c_str(),"PiercingArrow") == 0)
            {
                Pos p3 = cal_arrow(u);
                op.targets.push_back(p3);
            }
            cmd.cmds.push_back(op);
            myflag[u.id] = 3;
            mydes[u.id] = zz;
            if (enemyHero.size() >= 4)
            {
                group = myround;
            }
            //if (strcmp(op.type.c_str(),"PiercingArrow")==0)
              //fout << myround << endl;
            return;
        }
        else if (dis2(p1,p2) <= 144)
        {
            if (myround <= 100)
            {
                try1 = false;
            }
            if (dis2(p1,p2) <= 144 && u.canUseSkill(9) && rainint == 0)
            {
                op.type = "ArrowsRain";
                rainint = 5;
                Pos p3 = cal_rain(u);
                op.targets.push_back(p3);
                cmd.cmds.push_back(op);
                myflag[u.id] = 3;
                mydes[u.id] = zz;
                if (enemyHero.size() >= 4)
                {
                    group = myround;
                }
                return;
            }
        }
    }
    for(int i = 0; i < enemyBuilding.size(); i++)
    {
        Pos p1 = u.pos, p2 = enemyBuilding[i].pos;
        if (dis2(p1, p2) <= u.range && (steps == 7 || steps == 17 || steps == 25))
        {
            if (u.canUseSkill(11) && u.level <= 3)
                op.type = "PowerUp";
            else if (u.canUseSkill(7))
                op.type = "PiercingArrow";
            if (strcmp(op.type.c_str(),"PowerUp") != 0)
                op.targets.push_back(p2);
            cmd.cmds.push_back(op);
            myflag[u.id] = 3;
            mydes[u.id] = zz;
            return;
        }
    }
    if (myflag[u.id] == 4) return;
    if (mydes[u.id] != zz && dis2(u.pos, mydes[u.id]) > u.range) return;
    for(int i = 0; i < monster.size(); i++)
    {
        Pos p1 = u.pos, p2 = monster[i].pos;
        if (dis2(p1, p2) <= u.range && monster[i].id == recint[steps])
        {
            if (strcmp(monster[i].name,"Dragon")==0)
            {
                if (u.canUseSkill(9) && rainint == 0)
                {
                    rainint = 5;
                    op.type = "ArrowsRain";
                }
                else if (u.canUseSkill(7))
                    op.type = "PiercingArrow";
                else if (u.canUseSkill(11))
                    op.type = "PowerUp";
            }
            if (strcmp(monster[i].name,"Wolf")==0 && u.level <= 3)
            {
                if (u.canUseSkill(7))
                    op.type = "PiercingArrow";
                else if (u.canUseSkill(9) && rainint == 0)
                {
                    rainint = 5;
                    op.type = "ArrowsRain";
                }
            }
            if (strcmp(monster[i].name,"StoneMan")==0 && u.level <= 3)
            {
                if (u.canUseSkill(7))
                    op.type = "PiercingArrow";
                else if (u.canUseSkill(9) && rainint == 0)
                {
                    rainint = 5;
                    op.type = "ArrowsRain";
                }
            }
            if (strcmp(monster[i].name,"Roshan")==0)
            {
                if (u.canUseSkill(9) && rainint == 0)
                {
                    rainint = 5;
                    op.type = "ArrowsRain";
                }
                else if (u.canUseSkill(7))
                    op.type = "PiercingArrow";
                else if (u.canUseSkill(11))
                    op.type = "PowerUp";
            }
            if (strcmp(op.type.c_str(),"PowerUp") != 0)
                op.targets.push_back(p2);
            cmd.cmds.push_back(op);
            myflag[u.id] = 3;
            mydes[u.id] = zz;
            return;
        }
        else if (dis2(p1, p2) < u.range && monster[i].id != recint[steps])
            myflag[u.id] = 8;
    }
    if (myflag[u.id] == 3)
    {
        if (steps != 7 && steps != 17 && steps != 25 && dis2(recommend[steps],u.pos) < 36)
            steps++;
        myflag[u.id] = 8;
    }
}
void defence(const vector<PArea>& areas, const PMap &map, const PUnit &u, PCommand &cmd)
{
    if (myflag[u.id] == 1 || myflag[u.id] == 2) return;
    for(int i = 0; i < myBuilding.size(); i++)
    {
        for(int j = 0; j < enemyHero.size(); j++)
        {
            Pos p1 = myBuilding[i].pos;
            Pos p2 = enemyHero[j].pos;
            if (dis2(p1,p2) <= 81 && (myBuilding[i].hp < 1000 || enemyHero[j].level >= 3))
            {
                if (steps != 4 && steps <= 7)
                {
                    steps = 7;
                    dan = true;
                    myflag[u.id] = 0;
                    return;
                }
                if (myBuilding.size() == 3 && steps > 7 && mtotal >= 15 && steps <= 17)
                {
                    steps = 17;
                    myflag[u.id] = 0;
                    return;
                }
                if (myBuilding.size() == 3 && steps >= 18 && dis(u.pos,p1) >= 1200)
                {
                    steps = 25;
                    return;
                }
                if (steps == 25 || steps == 17)
                {
                    return;
                }
                if (steps >= 14 && steps <= 17 && dis2(u.pos,p1) >= 3000)
                {
                    steps = 17;
                    myflag[u.id] = 0;
                    return;
                }
                if (steps >= 22 && steps <= 25 && dis2(u.pos,p1) >= 3000)
                {
                    steps = 25;
                    myflag[u.id] = 0;
                    return;
                }
                if (dis2(p2, u.pos) <= 81)
                {
                    myflag[u.id] = 0;
                    return;
                }
                if(dis2(u.pos, p1) <= 8000)
                {
                    Operation op;
                    op.id = u.id;
                    op.type = "Move";
                    addBlocks(true);
                    Pos p = p2;
                    p.x++;
                    if (p == p1) p.y++;
                    bfs(areas, map ,u.pos, p, blockPos, op.targets);
                    cmd.cmds.push_back(op);
                    myflag[u.id] = 4;
                    mydes[u.id] = p;
                    def[enemyHero[j].id] = u.id;
                    mydef[u.id] = enemyHero[j].id;
                    return;
                }
            }
        }
    }
    if (myflag[u.id] == 4)
    {
        myflag[u.id] = 0;
        def[mydef[u.id]] = 0;
        mydef[u.id] = 0;
        mydes[u.id] = zz;
    }
}
bool cmp(Pos p1, Pos p2)
{
    Pos pp;
    pp.x = 0; pp.y = 0;
    return dis2(p1,pp) < dis2(p2,pp);
}
bool inrain(const vector<PArea>&areas, const Pos p)
{
    for(int i = 0; i < areas.size(); i++)
    {
        if (areas[i].camp == myplayer)
            continue;
        if (dis2(areas[i].center,p)<=25)
        {
            return true;
        }
    }
    return false;
}
void randommoving(const vector<PArea>& areas, const PMap& map, const PUnit &u, PCommand &cmd)
{
    if (myflag[u.id] != 6) return;
    Pos p = u.pos;
    bool wwj = false;
    for(int i = 0; i < enemyHero.size(); i++)
        if (dis2(u.pos,enemyHero[i].pos) <= 81)
            wwj = true;
    bool ojj = inrain(areas,u.pos);
    if (!ojj)
    {
        if (steps == 7 || steps == 17 || steps == 25)
        {
            if (recommend[steps].x > u.pos.x)
                p.x += rand()&4-1;
            else
                p.x -= rand()%4-1;
            if (recommend[steps].y > u.pos.y)
                p.y += rand()&4-1;
            else
                p.y -= rand()%4-1;
        }
        else
        {
            p.x += rand()%5 - 2;
            p.y += rand()%5 - 2;
        }
        if (p == u.pos)
            p.x++;
        if (dis2(p,recommend[steps]) > 81 && !wwj)
            p = u.pos;
    }
    else
    {
        int mindis = 10000;
        for(int i = -6; i <= 6; i++)
            for(int j = -6; j <= 6; j++)
            {
                Pos np;
                np.x = u.pos.x + i;
                np.y = u.pos.y + j;
                bool ydm = inrain(areas, np);
                if (!ydm)
                {
                    if (i*i+j*j < mindis)
                    {
                        mindis = i*i+j*j;
                        p = np;
                    }
                }
            }
    }
    Operation op;
    op.id = u.id;
    op.type = "Move";
    addBlocks(false);
    bfs(areas, map, u.pos, p, blockPos, op.targets);
    cmd.cmds.push_back(op);
    myflag[u.id] = 3;
    mydes[u.id] = zz;
}
void findTarget(const vector<PArea>& areas, const PMap &map, const PUnit &u, PCommand &cmd)
{
    if (myflag[u.id] == 1 || myflag[u.id] == 2 || myflag[u.id] == 3 ||
        myflag[u.id] == 4 || myflag[u.id] == 5 || myflag[u.id] == 6) return;
    if (enemyBuilding.size() == 0 && dis2(recommend[7],u.pos) <= u.range)
        collapse = true;
    if (steps == 7 && collapse)
            steps++;
    if (steps != 7 && steps != 17 && steps != 25)
    {
        bool next = true;
        for(int i = 0; i < monster.size(); i++)
            if (monster[i].id == recint[steps])
                next = false;
        if (next && dis2(u.pos,recommend[steps]) < 36)
            steps++;
    }
    Pos p = recommend[steps];
    for(int i = 0; i < enemyHero.size(); i++)
        if (dis2(u.pos, enemyHero[i].pos) <= 1200)
        {
            bool chase = false;
            for(int j = 0; j < myHero.size(); j++)
                if (dis2(myHero[j].pos, enemyHero[i].pos) <= 81)
                    chase = true;
            if (chase)
                p = enemyHero[i].pos;
        }
    if (cike >= 3 && myround >= 100)
    {
        int now = myround / 100;
        if (tp[u.id] == now % 2)
        {
            if (myplayer == 0)
            {
                p.x = 75;
                p.y = 117;
            }
            else
            {
                p.x = 75;
                p.y = 33;
            }
        }
    }
    Pos po = p;
    p.x += rand()%5 - 2;
    p.y += rand()%5 - 2;
    if (po == p)
        p.x++;
    Operation op;
    op.id = u.id;
    op.type = "Move";
    if (dis2(recommend[7],u.pos)<=100 || dis2(recommend[17],u.pos)<=100 || steps == 7 || steps == 17 || steps == 25)
        addBlocks(false);
    else
        addBlocks(true);
    bfs(areas, map, u.pos, p, blockPos, op.targets);
    cmd.cmds.push_back(op);
    myflag[u.id] = 7;
    mydes[u.id] = p;
    //cout << blockPos.size() << "   ";
    //cout << u.pos.x << " " << u.pos.y << "->";
    //cout << p.x << " " << p.y << "   ";
    //cout << "(" << op.targets[0].x << "," << op.targets[0].y << ") ";
    //cout << endl;
}
void rushTower(const PMap &map, PCommand &cmd)
{

}
void teamwork(const PMap &map, PCommand &cmd)
{
    int total = 0;
    mtotal = 0;
    int avi = 0;
    int mhp = 0;
    for(int i = 0; i < myHero.size(); i++)
    {
        mtotal += myHero[i]["Exp"]->val[2];
        if (myflag[myHero[i].id] != 1 && !team[myHero[i].id] &&
           ((dis2(myHero[i].pos, Pos(5,145)) > 4000 && myplayer == 0) ||
            (dis2(myHero[i].pos, Pos(145,5)) > 4000 && myplayer == 1)))
            avi++;
        else continue;
        total += myHero[i]["Exp"]->val[2];
        mhp += myHero[i].hp;
    }
    avic = avi;
    int etotal = 0;
    for(int i = 0; i < eid.size(); i++)
    {
        etotal += eLevel[eid[i]] - 1;
    }
    if (steps == 4 && avi < 3 && myround > 30)
        steps = 1;
    //cout << steps << endl;
    for(int i = 0; i < myHero.size(); i++)
    {
        if (steps == 7 && enemyBuilding.size() == 0 && dis2(recommend[7],myHero[i].pos) <= 81)
        {
            steps++;
            collapse = true;
        }
        if ((steps == 17 || steps == 25) && enemyBuilding.size() == 0 && dis2(recommend[17],myHero[i].pos) <= 81)
        {
            steps = 7;
            collapse = false;
        }
    }
    if (steps == 7 && total < 20 && !dan && (myround >= 150 || !try1))
    {
        steps = 1;
    }
    if (steps == 7 && (avi <= 3 || total < 5) && enemyBuilding.size() == 0)
    {
        steps = 1;
    }
    if (steps == 9 && (cike >= 3 || myBuilding[0].hp <= 600 || myBuilding[1].hp <= 600))
        steps++;
    if (steps == 9 && mtotal >= 40)
        steps++;
    if (steps == 11 && roshantime > 0)
        steps = 8;
    if (steps >= 11 && steps <= 13)
        steps = 8;
    if (steps == 12 && total < 12)
        steps++;
    if (steps == 10 && (total >= etotal+5 && total >= 20 || total >= 25) && avi == 5 && enemyHero.size() == 0)
        steps = 17;
    if (steps >= 14 && steps < 17 && (avi < 3 || total < 25))
        steps = 8;
    if (steps == 17 && avi < 3 && enemyHero.size() == 0)
    {
        steps = 8;
    }
    if (myround >= 970 && enemyHero.size() == 0)
        steps = 17;
    if (collapse && myBuilding.size() == 3 && steps <= 8)
        steps = 18;
    if (steps == 21 && (roshantime > 0 || total < 60))
        steps = 18;
    if (steps >= 22 && steps < 25 && (total < 25 || avi < 5))
        steps = 18;
    if (steps == 20 && avi == 5 && total >= 25 && enemyHero.size() == 0)
        steps = 25;
    if (steps == 25 && avi < 3 && enemyHero.size() == 0)
    {
        steps = 18;
    }
    if (steps >= 18 && mjx >= 1 && mjx <= 2 && total >= 18)
        steps = 17;
    if (myBuilding.size() < 3 && steps != 25 && steps >= 18)
    {
        Pos p1(75,116),p2(75,34);
        if (myBuilding[0].pos == p1 || myBuilding[1].pos == p1 || myBuilding[0].pos == p2 || myBuilding[1].pos == p2)
            steps = 8;
    }
    if (myBuilding.size() < 3 && steps < 17 && steps >= 8)
    {
        Pos p1(116,75),p2(34,75);
        if (myBuilding[0].pos == p1 || myBuilding[1].pos == p1 || myBuilding[0].pos == p2 || myBuilding[1].pos == p2)
            steps = 18;
    }
    if (myround - group <= 10 && avi >= 3 && enemyHero.size() == 0 && total >= 20)
    {
        if (steps >= 8 && steps <= 17)
            steps = 17;
        if (steps >= 18 && steps <= 25)
            steps = 25;
    }
    if (steps >= 14 && steps <= 17 && !collapse)
        steps = 7;
    if (steps >= 22 && !collapse)
        steps = 7;
    ///if (myBuilding.size() == 2 && steps != 4 && cike >= 3 && steps <= 7 && myround <= 120 && enemyBuilding.size() == 0)
      ///  steps = 8;
}
void mytargets()
{
    if (myplayer == 0)
    {
        recommend.push_back(Pos(54,115));///0
        recommend.push_back(Pos(54,75));///1
        recommend.push_back(Pos(34,54));///2
        recommend.push_back(Pos(34,34));///3
        recommend.push_back(Pos(5,5));///4
        recommend.push_back(Pos(34,34));///5
        recommend.push_back(Pos(34,54));///6
        recommend.push_back(Pos(75,34));///17 tower2

        recommend.push_back(Pos(54,115));///8
        recommend.push_back(Pos(94,142));///9
        recommend.push_back(Pos(92,116));///10
        recommend.push_back(Pos(96,75));///11
        recommend.push_back(Pos(75,75));///12 roshan
        recommend.push_back(Pos(54,75));///13
        recommend.push_back(Pos(96,35));///14
        recommend.push_back(Pos(56,8));///15
        recommend.push_back(Pos(58,34));///16
        recommend.push_back(Pos(34,75));///7 tower1

        recommend.push_back(Pos(96,75));///18
        recommend.push_back(Pos(116,96));///19
        recommend.push_back(Pos(118,55));///20
        recommend.push_back(Pos(75,75));///21 roshan
        recommend.push_back(Pos(96,35));///22
        recommend.push_back(Pos(56,8));///23
        recommend.push_back(Pos(58,34));///24
        recommend.push_back(Pos(34,75));///7 tower1

        //-------------------------------------
        recint.push_back(26);///0
        recint.push_back(19);///1
        recint.push_back(30);///2
        recint.push_back(17);///3
        recint.push_back(36);///4
        recint.push_back(17);///5
        recint.push_back(30);///6
        recint.push_back(12);///17 tower2

        recint.push_back(26);///8
        recint.push_back(33);///9
        recint.push_back(22);///10
        recint.push_back(23);///11
        recint.push_back(38);///12 roshan
        recint.push_back(19);///13
        recint.push_back(29);///14
        recint.push_back(31);///15
        recint.push_back(18);///16
        recint.push_back(13);///7 tower1

        recint.push_back(23);///18
        recint.push_back(32);///19
        recint.push_back(35);///20
        recint.push_back(38);///21 roshan
        recint.push_back(29);///22
        recint.push_back(31);///23
        recint.push_back(18);///24
        recint.push_back(13);///7 tower1
    }
    else
    {
        recommend.push_back(Pos(96,35));
        recommend.push_back(Pos(96,75));
        recommend.push_back(Pos(116,96));
        recommend.push_back(Pos(116,116));
        recommend.push_back(Pos(145,145));
        recommend.push_back(Pos(116,116));
        recommend.push_back(Pos(116,96));
        recommend.push_back(Pos(75,116));///tower2
        recommend.push_back(Pos(96,35));
        recommend.push_back(Pos(56,8));
        recommend.push_back(Pos(58,34));
        recommend.push_back(Pos(54,75));
        recommend.push_back(Pos(75,75));
        recommend.push_back(Pos(96,75));
        recommend.push_back(Pos(54,115));
        recommend.push_back(Pos(94,142));
        recommend.push_back(Pos(92,116));
        recommend.push_back(Pos(116,75));///tower1

        recommend.push_back(Pos(54,75));///
        recommend.push_back(Pos(34,54));///
        recommend.push_back(Pos(32,95));///
        recommend.push_back(Pos(75,75));///
        recommend.push_back(Pos(54,115));
        recommend.push_back(Pos(94,142));
        recommend.push_back(Pos(92,116));
        recommend.push_back(Pos(116,75));///tower1

        recint.push_back(29);
        recint.push_back(23);
        recint.push_back(32);
        recint.push_back(21);
        recint.push_back(37);
        recint.push_back(21);
        recint.push_back(32);
        recint.push_back(10);

        recint.push_back(29);
        recint.push_back(31);
        recint.push_back(18);
        recint.push_back(19);
        recint.push_back(38);
        recint.push_back(23);
        recint.push_back(26);
        recint.push_back(33);
        recint.push_back(22);
        recint.push_back(11);

        recint.push_back(19);
        recint.push_back(30);
        recint.push_back(34);
        recint.push_back(38);
        recint.push_back(26);
        recint.push_back(33);
        recint.push_back(22);
        recint.push_back(11);
    }
}
void haha()
{
    tp[myHero[0].id] = 0;
    tp[myHero[1].id] = 0;
    tp[myHero[2].id] = 1;
    tp[myHero[3].id] = 1;
    tp[myHero[4].id] = 2;
}
void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    myplayer = info.player;
    myround = info.round;
    cmd.cmds.clear();
    if (myround == 0)
    {
        createHero(info, cmd);
        getBlockList(info);
        for(int i = 0; i < 50; i++)
        {
            def[i] = 0;
            team[i] = false;
        }
        srand((unsigned)time(NULL));
        tag1 = false;
        tag2 = false;
        try1 = true;
        mytargets();
        return;
    }
    //cout << "begin" << endl;
    getLists(info);
    if (myround == 1)
    {
        haha();
        steps = 4;
        //if (myplayer == 1)
          //  steps = 18;
    }
    //cout << "getLists" << endl;
    teamwork(map, cmd);
    if (rainint > 0)
        rainint--;
    if (roshantime > 0)
        roshantime--;
    for(int i = 0; i < myHero.size(); i++)
    {
        runaway(info.areas, map, myHero[i], cmd);
        upLevel(myHero[i], cmd);
        defence(info.areas, map, myHero[i], cmd);
        attackUnit(myHero[i], cmd);
        randommoving(info.areas, map, myHero[i], cmd);
        findTarget(info.areas, map, myHero[i], cmd);
        int tmp = myHero[i].id;
        if (cmd.cmds.size() < i + 1)
        {
            myflag[myHero[i].id] = 8;
            findTarget(info.areas, map, myHero[i], cmd);
        }
        //cout << myflag[myHero[i].id] << endl;
    }
    //cout << "steps = " << steps << endl;
    for(int i = 0; i < myHero.size(); i++)
    {
        mylast[i] = myHero[i].pos;
    }
    lastEnemy = enemyHero.size();
    if (enemyBuilding.size() > 0)
        lastHp = enemyBuilding[0].hp;
}

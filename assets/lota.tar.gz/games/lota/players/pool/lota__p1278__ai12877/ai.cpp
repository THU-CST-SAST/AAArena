#include "sdk.h"

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd){
    int player = info.player;
    cmd.cmds.clear();
    if (!info.round){
        Operation op[5];
        for (int i = 0;i < 5;i++) op[i].id = i;
        op[0].type = "chooseArcher";
        op[1].type = "chooseFighter";
        op[2].type = "chooseFighter";
        op[3].type = "chooseAssassin";
        op[4].type = "chooseAssassin";
        for (int i = 0;i < 5;i++){
            op[i].targets.clear();
            cmd.cmds.push_back(op[i]);
        }
    }
    else{
        
    }
}
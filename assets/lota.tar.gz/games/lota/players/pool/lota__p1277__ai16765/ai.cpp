#include "sdk.h"
#include<ctime>

const Pos EMPTYPOS = Pos(), DEFAULFPOS = Pos(75, 75);
const int EMPTYID = 0, HIGHLEVEL = 4, MAXLEVEL = 10, MAXID = 100;

static int fixId[MAXID], cnt;
static Pos fixPos[MAXID];
static Pos tarPos;
static Pos p1[3], p2[2], p3[2];
static bool towerDes[2];
typedef vector<const PUnit*> PUnits;
PUnits ours, others, nearBy;
static vector<Pos> blocks;
static double argLv;

const PMap* MAP;
const PPlayerInfo* INFO;

const PUnit* belongs(int id, PUnits& units) //�ҳ�unit��ɵ�vector�а���ָ��id��unit
{
    for (int i=0;i<units.size();++i)
        if (units[i]->id == id)
            return units[i];
    return NULL;
}

int unitEvaluation(string name) //����һ����λ��ս����
{
    if (name == string("Dog") || name == string("Bow"))
        return 0;
    if (name == string("Fighter") || name == string("Assassin") || name == string("Archer")) //������з���λ��ս
        return 0;
    if (name == string("Wolf") || name == string("StoneMan"))
        return 2;
    if (name == string("Tower") || name == string("Dragon") || name == string("Roshan"))
        return HIGHLEVEL;
    return MAXLEVEL;
}

void fighting(const PUnit* a, const PUnit* b, PCommand &cmd) //��λa�Ե�λb�������
{
    Operation op;
    op.id = a->id;

    vector<const PSkill*> useSkill;
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isHeroSkill() && a->canUseSkill(ptr->typeId))
        {
            PUnits ptr_foe;
            infectedBySkill(*INFO, a->id, ptr->typeId, ptr_foe); //Ѱ�ҿ��ü���
            if (belongs(b->id, ptr_foe) || !strcmp(ptr->name,"Hide") || !strcmp(ptr->name,"PowerUp"))
                useSkill.push_back(ptr);
        }
    }
    if (useSkill.size()) //���ԣ�����ʹ�ü���
    {
        const PSkill* ptr = useSkill[rand()%useSkill.size()];
        op.type = ptr->name;
        if (ptr->needTarget())
            op.targets.push_back(b->pos);
    } else
        if (dis2(a->pos, b->pos) <= a->range) //�жϵ�λb�Ƿ��ڹ�����Χ��
        {
            op.type = "Attack";
            op.targets.push_back(b->pos);
        } else
        {
            op.type = "Move";
            findShortestPath(*MAP, a->pos, b->pos, blocks, op.targets);
        }
    cmd.cmds.push_back(op);
}

void levelUp(const PUnit* a, PCommand &cmd) //��λa��������
{
    vector<string> level_ups;
	string ss[4] = {"PALU", "PULU", "ARLU", "YellowPoint"};
	for (int k = 0; k < 4; ++k)
	{
		const PSkill* ptr = &a->skills[0];
		for (int i = 0; i < a->skills.size(); ++i)
		{
			const PSkill* ptrr = &a->skills[i];
			if (ptrr->name == ss[k])
			{
				ptr = &a->skills[i];
				break;
			}
		}
		
        if (ptr->isLU() && a->canUseSkill(ptr->typeId)) //ѡ����������ļ���
		{
            level_ups.push_back(ptr->name);
			break;
		}
	}
	/*
    level_ups.push_back("YellowPoint");
    for (int i = 0; i < a->skills.size(); ++i)
    {
        const PSkill* ptr = &a->skills[i];
        if (ptr->isLU() && a->canUseSkill(ptr->typeId)) //ѡ����������ļ���
            level_ups.push_back(ptr->name);
    }*/
    Operation op;
    op.id = a->id;
    op.type = level_ups[0]; //�����������
    cmd.cmds.push_back(op);
}

Pos getNT(double lv)
{
	bool near = false;
	bool noEm = true;
	int camp = 0;
	
	for (int i=0; i<ours.size(); ++i) //���м�����λ
	{
		const PUnit* ptr = ours[i];
		if (ptr->isHero()) //ptr��һ��Ӣ�ۣ����Ͷ�����ϣ�������ս
		{
			camp = ptr->camp;
			if (abs(ptr->pos.x - tarPos.x) <= 5 && abs(ptr->pos.y - tarPos.y) <= 5)
			{
				near = true;
				break;
			}
		}
	}
	for (int j = 0; j < INFO->units.size(); ++j)
		if (abs(tarPos.x - INFO->units[j].pos.x) <= 10 && abs(tarPos.y - INFO->units[j].pos.y) <= 10 && INFO->units[j].hp > 0 && INFO->units[j].camp != camp && !(INFO->units[j].findBuff("Reviving")))
		{
			noEm = false;
			break;
		}
	
	if (near && noEm)
	{
		if (lv < 0.9)
		{
			Pos temp = p1[cnt];
			cnt = (cnt + 1) % 3;
			return temp;
		}
		else
		if (lv < 2.4)
		{
			cnt = (cnt + 1) % 2;
			return p2[cnt];
		}
		else
		{
			const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
			for (int i = 1; i >= 0; --i)
				if (!towerDes[i])
					return tower[i];
		}
	}
	else return tarPos;
}

void getFoes(vector<Pos> &atk_tar, int l, int u) //���ݵȼ�Ѱ�ҵ�ͼ����Ӧ
{
    int t = unitEvaluation("Tower");
    if (l <= t && t <= u)
    {
        const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
        for (int i = 0; i < 2; ++i)
            if (!towerDes[i])
            {
                for (int j = 0; j < 5; ++j)
                    atk_tar.push_back(tower[i]); //�Ӵ���������
            }
    }
    t = unitEvaluation("Dragon");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(Dragon_pos[i]);
        atk_tar.push_back(Roshan_pos[0]);
    }
    t = unitEvaluation("Wolf");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 4; ++i)
            atk_tar.push_back(Wolf_pos[i]);
        for (int i = 0; i < 2; ++i)
            atk_tar.push_back(StoneMan_pos[i]);
    }
    t = unitEvaluation("Dog");
    if (l <= t && t <= u)
    {
        for (int i = 0; i < 6; ++i)
            atk_tar.push_back(Dog_pos[i]);/*
        for (int i = 0; i < 6; ++i)
            if (i % 3) //ȥ�������޷��ƶ������Ұ��
                atk_tar.push_back(Bow_pos[i]);*/
    }
}

void findFoes(const PUnit* a, PCommand &cmd) //��λaѰ�Ҷ���
{
    if ((*a)["Exp"]->val[3]) //������������
    {
        levelUp(a, cmd);
    } else
    {
		fixPos[a->id] = tarPos;
		/*
		if (abs(tarPos[a->id].x - a->pos.x) <= 5 && abs(tarPos[a->id].y - a->pos.y) <= 5)
			tarPos[a->id] = EMPTYPOS;
		fixPos[a->id] = tarPos[a->id];
        if (fixPos[a->id] == EMPTYPOS)
        {
            vector<Pos> atk_tar;
            atk_tar.clear();
            getFoes(atk_tar, a->level >= HIGHLEVEL ? HIGHLEVEL : 0, a->level); //���ԣ��ﵽһ��ǿ�ȿ�ʼ����������
            if (atk_tar.size()) //Ѱ�ҹ̶������С����
            {
                fixPos[a->id] = DEFAULFPOS;
				for (int i = 0; i < atk_tar.size(); ++i)
				{
					bool br = true;
					if (abs(atk_tar[i].x - a->pos.x) <= 10 && abs(atk_tar[i].y - a->pos.y) <= 10)
					{
						br = false;
						
						for (int j = 0; j < INFO->units.size(); ++j)
							if (abs(a->pos.x - INFO->units[j].pos.x) <= 10 && abs(a->pos.y - INFO->units[j].pos.y) <= 10 && INFO->units[j].hp > 0 && INFO->units[j].camp != a->camp)
							{
								br = true;
								break;
							}
					}
					if (br)
					{
						fixPos[a->id] = atk_tar[i]; //����Ŀ��
						break;
					}
				}
            } else
            {
                fixPos[a->id] = DEFAULFPOS;
            }
			if (fixPos[a->id].x != DEFAULFPOS.x && fixPos[a->id].y != DEFAULFPOS.y)
				tarPos[a->id] = fixPos[a->id];
        }*/
        Operation op;
        op.id = a->id;
        op.type = "Move";
        findShortestPath(*MAP, a->pos, tarPos, blocks, op.targets); //����С�����ƶ�
        cmd.cmds.push_back(op);
    }
}

void chooseHero(const PPlayerInfo &info, PCommand &cmd) //��0�غ�ѡ��Ӣ��
{
    for(int i=0;i<info.units.size();++i)
    {
        Operation op;
        int r=2;
        if(r==0)
            op.type="ChooseAssassin";
        else if(r==1)
            op.type="ChooseFighter";
        else if(r==2)
            op.type="ChooseArcher";
        op.targets.clear();
        op.id=info.units[i].id;
        cmd.cmds.push_back(op); //���ѡ��ְҵ
    }
}

void init() //һЩ������ʼ��
{
    memset(fixId, EMPTYID, sizeof fixId);
    towerDes[0] = towerDes[1] = false;
    for (int i = 0; i < MAXID; ++i) fixPos[i] = EMPTYPOS;
	if (INFO->camp == 0)
	{
		p1[0] = Pos(54, 115);
		p1[1] = Pos(92, 116);
		p1[2] = Pos(96, 75);
		
		p2[0] = Pos(116, 96);
		p2[1] = Pos(94, 142);	
	}
	else
	{
		p1[0] = Pos(96, 35);
		p1[1] = Pos(58, 34);
		p1[2] = Pos(54, 75);
		
		p2[0] = Pos(34, 54);
		p2[1] = Pos(56, 8);	
	}/*
	if (INFO->camp == 0)
	{
		p1[0] = Pos(96, 75);
		p1[1] = Pos(116, 116);
		p1[2] = Pos(142, 116);
		
		p2[0] = Pos(116, 96);
		p2[1] = Pos(94, 142);	
	}
	else
	{
		p1[0] = Pos(54, 75);
		p1[1] = Pos(34, 34);
		p1[2] = Pos(8, 34);
		
		p2[0] = Pos(34, 54);
		p2[1] = Pos(56, 8);	
	}*/
	tarPos = p1[0];
}

void fightAlone(const PUnit* ptr, const PPlayerInfo &info, PCommand &cmd)
{
    info.findUnitInArea(ptr->pos, ptr->view, nearBy); //Ѱ�Ҹ�������
    fixPos[ptr->id] = EMPTYPOS;
    for (int i = 0; i < nearBy.size(); ++i)
    {
        if (	nearBy[i]->level >= 13 ||
                nearBy[i]->camp == ptr->camp ||
                nearBy[i]->pos == Bow_pos[0] || nearBy[i]->pos == Bow_pos[3] ||
                nearBy[i]->findBuff("Reviving"))
            //ɾ���ȼ����ߵ��ˣ������Ѿ����޳������ߣ�ɾ�����ɵ����Ұ��
        {
            nearBy.erase(nearBy.begin()+i);
            --i;
        }
    }
    if (nearBy.size()) //���ԣ����ܱ�����С��������й���
    {
        const PUnit* ptr_foe = NULL; //�ж�֮ǰ�Ƿ�������Ŀ��
        if (!ptr_foe)
        {
            ptr_foe = nearBy[rand()%nearBy.size()];
            fixId[ptr->id] = ptr_foe->id; //��֮ǰδ������Ŀ�꣬���ѡ��Ŀ��
        }
		
		int minHp = 10000000;
		for (int i = 0; i < nearBy.size(); ++i)
			if (nearBy[i]->hp < minHp)
			{
				minHp = nearBy[i]->hp;
				ptr_foe = nearBy[i];
			}
        fighting(ptr, ptr_foe, cmd); //��Ŀ���
    } else
    {
        findFoes(ptr, cmd); //������û�ео����ڵ�ͼ��Ѱ��һ��
    }
}

void player_ai(const PMap &map, const PPlayerInfo &info, PCommand &cmd)
{
    srand(time(0)); //������ش�
    cmd.cmds.clear();
    MAP = &map;
    INFO = &info;
	
    blocks.clear();
    getFoes(blocks, 0, MAXLEVEL);
    const Pos* tower = INFO->camp ? Player1_tower_pos : Player0_tower_pos;
    for (int i = 0; i < 2; ++i)
        blocks.push_back(tower[i]); //��ͼ�Ϲ̶��㲻�ɾ���
	for (int i = 0; i < info.units.size(); ++i)
		blocks.push_back(info.units[i].pos);
	
    if (info.round == 0)
    {
        chooseHero(info, cmd); //��0�غ�ѡ��Ӣ��
        init(); //һЩ������ʼ��
    } else //��ʽ�غ�
    {
        info.findUnitByPlayer(info.player, ours); //Ѱ�����б�����λ
		argLv = 0;
        for (int i=0; i<ours.size(); ++i) //���м�����λ
        {
            const PUnit* ptr = ours[i];
            if (ptr->isHero()) //ptr��һ��Ӣ�ۣ����Ͷ�����ϣ�������ս
				argLv += ptr->level;
				
			const Pos* tower = INFO->camp ? Player0_tower_pos : Player1_tower_pos;
			for (int j = 0; j < 2; ++j)
				if (dis2(ptr->pos, tower[j]) < 100 && !info.findUnitByPos(tower[j]))
					towerDes[j] = true; //ȥ���Ѵݻٷ�����
        }
		argLv /= 5.0;
		tarPos = getNT(argLv);
        for (int i=0; i<ours.size(); ++i) //���м�����λ
        {
            const PUnit* ptr = ours[i];
            if (ptr->isHero()) //ptr��һ��Ӣ�ۣ����Ͷ�����ϣ�������ս
            {
				if (ptr->hp == 0 || ptr->findBuff("Reviving")) continue;
                fightAlone(ptr, info, cmd);
            }
        }
    }
}

"""LOTA legacy AI9 evaluator."""

from __future__ import annotations

from pathlib import Path

from aa_arena.core.contract import EvaluateResult, EvaluationStatus
from aa_arena.legacy.ai9 import Ai9Error, Ai9GameConfig, build_backend, build_player, run_ai9_match


class LotaEvaluator:
    def __init__(self, game_dir: Path, *, build_root: Path | None = None,
                 artifact_root: Path | None = None, timeout_s: float = 1800.0,
                 max_rounds: int = 1000):
        self._game_dir = Path(game_dir).resolve()
        root = self._game_dir.parents[1]
        self._build_root = Path(build_root).resolve() if build_root else root / "data" / "lota-build"
        self._artifact_root = Path(artifact_root).resolve() if artifact_root else root / "data" / "lota-matches"
        self._timeout = float(timeout_s)
        self._max_rounds = int(max_rounds)
        backend = self._game_dir / "backend"
        self._config = Ai9GameConfig(
            name="lota",
            backend_source_root=backend,
            player_sdk_includes=(backend / "logic" / "src" / "include",
                                 backend / "logic" / "src" / "include" / "sdk"),
            player_sdk_sources=tuple(backend / "logic" / "src" / n for n in
                ("sdk.cpp", "Pos.cpp", "const.cpp", "trans.cpp", "Operation.cpp")),
            resources_content="map.txt 0\n0 1\n",
            map_source=backend / "map.txt",
            match_files=(backend / "logic" / "analyse",
                         backend / "logic" / "replayV.txt",
                         backend / "logic" / "trans.rb"),
            npc_library_name="ai.so",
            roles=("P0", "P1"),
            player_count=3,
        )

    def preflight_candidate(self, package_root):
        try:
            build_player(self._config, 'candidate', Path(package_root), self._build_root)
        except (Ai9Error, OSError) as exc:
            raise ValueError(f'AI9 candidate preflight failed: {exc}') from exc

    def evaluate(self, players, roles, seed):
        if len(players) != 2 or set(roles) != {"P0", "P1"}:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR,
                                  diagnostic=f"lota requires 2 players [P0,P1], got {len(players)}/{roles}")
        try:
            self._config.backend_source_root  # validate existence
            for p in self._config.player_sdk_sources:
                if not p.is_file():
                    raise FileNotFoundError(p)
            if not self._config.map_source.is_file():
                raise FileNotFoundError(self._config.map_source)
            backend = build_backend(self._config, self._build_root)
            self._game_dir / "players" / "pool"
            prepared = [build_player(self._config, p.player_id, Path(p.code_path), self._build_root) for p in players]
            prepared.append(build_player(self._config, 'neutral-npc',
                self._config.backend_source_root / 'npc', self._build_root))
        except (Ai9Error, OSError) as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))
        try:
            return run_ai9_match(self._config, backend, prepared, build_root=self._build_root,
                                 artifact_root=self._artifact_root, seed=seed,
                                 timeout_s=self._timeout, max_rounds=self._max_rounds)
        except (Ai9Error, OSError) as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))


def make_evaluator(game_dir: Path, **kwargs) -> LotaEvaluator:
    return LotaEvaluator(game_dir, **kwargs)

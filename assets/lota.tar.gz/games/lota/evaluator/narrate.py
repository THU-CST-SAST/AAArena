from __future__ import annotations

from pathlib import Path

from aa_arena.legacy.replay import narrate_ai9
from aa_arena.replay.narration import Narration, NarrationContext


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    return narrate_ai9("lota", Path(replay_path), context)

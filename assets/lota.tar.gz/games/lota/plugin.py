"""LOTA legacy AI9 GamePack plugin."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

from aa_arena.core import Evaluator, GamePlugin


def _load():
    d = Path(__file__).resolve().parent / "evaluator"
    n = "aa_arena_games_lota_evaluator"
    spec = importlib.util.spec_from_file_location(n, d / "__init__.py", submodule_search_locations=[str(d)])
    m = importlib.util.module_from_spec(spec)
    sys.modules[n] = m
    spec.loader.exec_module(m)
    return m


def _factory(game_dir: Path, **kwargs):
    return _load().make_evaluator(game_dir, **kwargs)


PLUGIN = GamePlugin(
    name="lota",
    evaluator_factory=_factory,
    display_name="LOTA / 战棋传说",
    roles=("P0", "P1"),
    roles_symmetric=True,
)

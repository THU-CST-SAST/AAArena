#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Flight/Flights.h"
#include "include/Area/Areas.h"
#include "include/Game/Game.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
void FlightBlade::roundStart()
{
    if(game->findUnitById(targetId)!=NULL)
        target=game->findUnitById(targetId)->getPos();
    Flight::roundStart();
}
void FlightBlade::oneRoundPass()
{
    if(game->findUnitById(targetId)==NULL) return;
    target=game->findUnitById(targetId)->getPos();
    if(dis2(pos,target)<=speed)
        pos=target;
    else{
        double d=dis(pos,target);
        pos.x=pos.x+(target.x-pos.x)*sqrt(speed)/d;
        pos.y=pos.y+(target.y-pos.y)*sqrt(speed)/d;
    }
}
void FlightBlade::terminate()
{
    if(game->findUnitById(targetId)==NULL)
    {
        hit=true;
        return;
    }
    Unit* ptr=game->findUnitById(targetId);
    if (ptr->getPos() == pos)
    {
        int dmg=FlightBlade_damage[level];
        ptr->findArg("Hp")->add(0, -dmg/skillReduce(ptr->getName()));
        ptr->findArg("LastHit")->change(unitId,game->getRound());
        ptr->addBuff(new Slow(ptr,level));
        hit=true;
    }
}
bool FlightBlade::remove()
{
    return hit;
}

int FlightBlade::getHit()
{
    return hit;
}
FlightBlade::FlightBlade(Game* Gm,int UnitID,int Id,int Camp,Pos Start,int TargetId,int Level):
    Flight(Gm,"FlightBlade",UnitID,Id,Camp,1<<10,FlightBlade_speed,Start),
    level(Level),targetId(TargetId),hit(false)
{
    target=game->findUnitById(targetId)->getPos();
}
//===========

void SignalArrow::oneRoundPass()
{
    if(dis2(pos,target)<=speed)
        pos=target;
    else{
        double d=dis(pos,target);
        pos.x=pos.x+(target.x-pos.x)*sqrt(speed)/d;
        pos.y=pos.y+(target.y-pos.y)*sqrt(speed)/d;
    }
}
void SignalArrow::terminate()
{
    if(pos==target)
        game->addArea(
                    new RainyPlace(game,camp,unitId,-1,
                                   target,level)
                    );
}
bool SignalArrow::remove()
{
    return pos==target;
}

int SignalArrow::getHit()
{
    return pos==target;
}
SignalArrow::SignalArrow(Game* Gm,int UnitID,int Id,int Camp,Pos Start,Pos TargetPos,int Level):
    Flight(Gm,"SignalArrow",UnitID,Id,Camp,1<<10,SignalArrow_speed,Start), level(Level)
{
    target=TargetPos;
}


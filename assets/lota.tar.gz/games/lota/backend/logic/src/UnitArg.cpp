//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
UnitArg::UnitArg(const char* myName, Unit* myUnit):
    name(myName),unit(myUnit)
{
    val.clear();
}
void UnitArg::add(int no,int deltaValue)
{
 //   val[no]+=deltaValue;
    change(no,val[no]+deltaValue);
}
int UnitArg::getVal(int no)//获取数值
{
	if(val.size()<=no)
	{
		int k=val.size();
		val.resize(no+1);
		for(int i=k;i<val.size();++i)
			val[i]=-1;
	}
    return val[no];
}
void UnitArg::oneRoundPass()//参数生效，如生命值回复速率，法力回复速率等
{
}
void UnitArg::roundStart()//回合初始，无视所有buff
{
}
void UnitArg::change(int no,int newValue)//数值变化,可能引起事件，如升级等
{
	if(val.size()<=no)
	{
		int k=val.size();
		val.resize(no+1);
		for(int i=k;i<val.size();++i)
			val[i]=-1;
	}
    val[no]=newValue;
}
string UnitArg::toString()
{
    string tmp = name;
    int _size = val.size();
    for (int i=0; i<_size; ++i)
    {
        tmp = tmp + "&" + ToString(val[i]);
    }
    return tmp;
}
//===========================
Hp::Hp(int Origin, Unit* myUnit) :
    UnitArg("Hp", myUnit)//hp/当前hp上限/hp回复速率/正常hp上限
{
    val.resize(4);
    val[0]=val[1]=val[3]=Origin;
    val[2]=val[0]/100;
    if(val[2]<1)
        val[2]=1;
}
void Hp::roundStart()
{
    val[2]=val[1]/100;
    if(val[2]<1)
        val[2]=1;
}
void Hp::oneRoundPass()
{
    val[0]+=val[2];
//    if(val[0]>val[1])
//        val[0]=val[1];
}
void Hp::output(ostream &os)
{
    os<<"hp:"<<val[0]<<";";
    os<<"maxHp:"<<val[1]<<";";
    os<<"hpRate:"<<val[2];
}
void Hp::check()
{
    if (val[0]>val[1])
        val[0]=val[1];
}
//===================
Mp::Mp(int Origin, Unit* myUnit) :
    UnitArg("Mp", myUnit)//Mp/当前Mp上限/Mp回复速率/正常Mp上限
{
    val.resize(4);
    val[0]=val[1]=val[3]=Origin;
    val[2]=val[0]/100;
    if(val[2]<1)
        val[2]=1;
}
void Mp::roundStart()
{
    val[2]=val[1]/100;
    if(val[2]<1)
        val[2]=1;
}
void Mp::oneRoundPass()
{
    val[0]+=val[2];
//    if(val[0]>val[1])
//        val[0]=val[1];
}
void Mp::output(ostream &os)
{
    os<<"mp:"<<val[0]<<";";
    os<<"maxMp:"<<val[1]<<";";
    os<<"mpRate:"<<val[2];
}

void Mp::check()
{
    if (val[0]>val[1])
        val[0]=val[1];
}
//===================
Exp::Exp(int nextLevel,int level,int skillPoint,int DeadExp, Unit* myUnit) :
    UnitArg("Exp", myUnit)//当前经验值，升一级要达到的经验，当前等级，当前剩余技能点
{
    val.push_back(0);
    val.push_back(nextLevel);
    val.push_back(level);
    val.push_back(skillPoint);
    val.push_back(DeadExp);
}
void Exp::output(ostream &os)
{
    os<<"exp:"<<val[0]<<";";
    os<<"nextLevel:"<<val[1]<<";";
    os<<"level:"<<val[2]<<";";
    os<<"skillPoints:"<<val[3];
}
//===============
Speed::Speed(int Origin,Unit* myUnit):
	UnitArg("Speed",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Speed::output(ostream &os)
{
    os<<"speed:"<<val[0];
}
//============
View::View(int Origin,Unit* myUnit,int Detector):
	UnitArg("View",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
    val.push_back(Detector);
}
void View::output(ostream &os)
{
    os<<"view:"<<val[0]<<";";
    os<<"detector:"<<val[2];
}
//===========
Atk::Atk(int Origin,Unit* myUnit):
	UnitArg("Atk",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Atk::output(ostream &os)
{
    os<<"atk:"<<val[0];
}

void Atk::add(int no, int deltaValue)
{
    UnitArg::add(no,deltaValue);
    if(no==1)
        UnitArg::add(0,deltaValue);
}
//==========
Def::Def(int Origin,Unit* myUnit):
	UnitArg("Def",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
}
void Def::output(ostream &os)
{
    os<<"def:"<<val[0];
}

void Def::add(int no, int deltaValue)
{
    UnitArg::add(no,deltaValue);
    if(no==1)
        UnitArg::add(0,deltaValue);
}
//=================
Range::Range(int Origin,int Fly,Unit* myUnit):
	UnitArg("Range",myUnit)
{
	val.push_back(Origin);
	val.push_back(Origin);
	val.push_back(Fly);
}
void Range::output(ostream &os)
{
    os<<"range:"<<val[0];
}
//===================
LastHit::LastHit(Unit *myUnit):
    UnitArg("LastHit",myUnit)
{
}

void LastHit::output(ostream &os)
{
    os<<"lastHit:{";
    int k=0;
    for(int i=0;i<val.size();++i)
        if(val[i]==unit->getGame()->getRound())
        {
            if(k>0)
                os<<";";
            ++k;
            os<<i;
        }
    os<<"}";
}
//==================
OnlyTarget::OnlyTarget(Unit *myUnit):
    UnitArg("OnlyTarget",myUnit)
{
    val.push_back(-1);
}
void OnlyTarget::output(ostream &os)
{
    os<<"onlyTarget:"<<val[0];
}

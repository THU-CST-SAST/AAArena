#include "include/Area/Areas.h"
#include "include/Buff/Buffs.h"
#include "include/Unit/Unit.h"
#include "include/sdk/const.h"
RainyPlace::RainyPlace(Game* Gm,int Camp,int UnitId,int ID,Pos Center,int Level):
    Area("RainyPlace",Gm,Camp,5,ID,Center,RainyPlace_range),level(Level),unitId(UnitId)
{
}
void RainyPlace::work(Unit *unit)
{
    if(!inArea(unit->getPos()))
        return;
    if (unit->getCamp() != Area::camp)
    {
        unit->addBuff(new Rainy(unit,level,unitId));
    }
}
//========================
LifeSpring::LifeSpring(Game *Gm, int Camp, int ID, Pos Center):
    Area("CurePlace",Gm,Camp,500,ID,Center,30)
{
}
void LifeSpring::work(Unit *unit)
{
    if(!inArea(unit->getPos()))
        return;
    unit->addBuff(new Cure(unit));
}

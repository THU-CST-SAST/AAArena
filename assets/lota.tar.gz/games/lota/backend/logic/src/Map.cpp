//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"

Map::Map(int M,int N,const char* filename):
    m(M),n(N)
{
    char ch[m+10];
    ifstream fin(filename);
    for(int i=0;i<n;++i)
    {
        fin>>ch;
        for(int j=0;j<m;++j)
            height[i][j]=ch[j]-'0';
    }
    fin.close();
}
void Map::roundInit()
{
    memset(view,0,sizeof view);
    memset(detector,0,sizeof detector);
}
bool Map::tryPosition(Pos pos,int volume)
{
    int v=volume;
    for(int i=pos.x-v+1;i<pos.x+v;++i)
        for(int j=pos.y-v+1;j<pos.y+v;++j)
            if( dis2(pos,Pos(i,j))<=(v-1)*(v-1) )
            {
                if(j<0 || j>=m || i<0 || i>=n)
                    return false;
                else if(dis2(pos,Pos(i-1,j))<=(v-1)*(v-1)&&abs(height[i-1][j]-height[i][j])>1)
                    return false;
                else if(dis2(pos,Pos(i,j-1))<=(v-1)*(v-1)&&abs(height[i][j-1]-height[i][j])>1)
                    return false;
            }
    return true;
}
void Map::calcView(Unit* unit)
{
    Pos pos=unit->getPos();
    UnitArg *ptr=unit->findArg("View");
    int unitView=1;
    if(ptr!=NULL)
        unitView=ptr->getVal();
    int vvv=sqrt(unitView);
    for(int i=pos.x-vvv;i<=pos.x+vvv;++i)
        if (0<=i && i<n )
            for(int j=pos.y-vvv;j<=pos.y+vvv;++j)
                if(0<=j && j<m)
                    if( dis2(pos,Pos(i,j))<=unitView )
                        if(height[pos.x][pos.y]+2>height[i][j])
                        {
                            view[i][j]=(view[i][j]|(1<<(unit->getCamp())));
                            if( unit->findArg("View")->getVal(2)>0 )
                                detector[i][j]=(detector[i][j]|(1<<(unit->getCamp())));
                        }
}
Map::~Map()
{
}

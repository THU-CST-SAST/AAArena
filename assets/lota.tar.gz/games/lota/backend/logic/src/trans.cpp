#ifndef _AI__
#include "include/trans.h"
#else
#include "trans.h"
#endif//_AI__
#include <cstdio>
#include <cstring>
#include <sstream>
#include <iostream>
using namespace std;
stringstream transer;
string tmpstr;
int String2Int(string str)
{
    int tmp;
    transer.clear();
    transer << str;
    transer >> tmp;
    transer.clear();
    return tmp;
}

double String2Double(string str)
{
    double tmp;
    transer.clear();
    transer << str;
    transer >> tmp;
    transer.clear();
    return tmp;
}

DPos String2DPos(string str)
{
    int tmp = str.find('_');
    return DPos( String2Double( str.substr(0, tmp) ), String2Double( str.substr(tmp+1, str.length() - tmp - 1) ) );
}

Pos String2Pos(string str)
{
    int tmp = str.find('_');
    return Pos( String2Int( str.substr(0, tmp) ), String2Int( str.substr(tmp+1, str.length() - tmp - 1) ) );
}
char ch[20];
string ToString(int a)
{
    //string tmp;
    /*transer.clear();
    transer << a;
    tmpstr="";
    transer >> tmpstr;
    transer.clear();
*/
    sprintf(ch,"%d",a);
    tmpstr=ch;
    return tmpstr;
}

string ToString(double a)
{
    //string tmp;
    transer.clear();
    transer << a;
    transer >> tmpstr;
    transer.clear();
    return tmpstr;
}

string ToString(DPos pos)
{
    return ToString(pos.x) + "_" + ToString(pos.y);
}

string ToString(Pos pos)
{
    return ToString(pos.x) + "_" + ToString(pos.y);
}

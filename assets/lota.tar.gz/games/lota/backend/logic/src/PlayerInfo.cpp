//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"

void PlayerInfo::roundInit(int Round)
{
    round=Round;
    units.clear();
    flights.clear();
    areas.clear();
}
PlayerInfo::PlayerInfo(Game* Gm,int Camp):
    game(Gm),camp(Camp)
{
    units.clear();
    flights.clear();
    areas.clear();
}
void PlayerInfo::addUnit(Unit* unit)
{
    units.push_back(unit);
}
void PlayerInfo::addFlight(Flight* flight)
{
    flights.push_back(flight);
}
void PlayerInfo::addArea(Area* area)
{
    areas.push_back(area);
}
string PlayerInfo::toString()const
{
    string tmp = ToString(camp) + "#" + ToString(player) + '#' + ToString(round) + '#';
    int _size = units.size();
    for (int i=0; i<_size; ++i)
    {
        tmp += units[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
    _size = flights.size();
    tmp += '#';
    for (int i=0; i<_size; ++i)
    {
        tmp += flights[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
    tmp += '#';
    _size = areas.size();
    for (int i=0; i<_size; ++i)
    {
        tmp += areas[i]->toString();
        if (i != _size-1)
            tmp += '@';
    }
    tmp += '@';
   // //cout<<"\n\n"<<tmp<<'\n';
    return tmp;
}

#include "include/Game/Game.h"
#include "include/frame.h"
#include "include/ActMaker/ActMakerLocal.h"
#ifdef _SERVER_
#include "include/ActMaker/ActMakerWeb.h"
#include "include/socket_trans.h"
#endif//_SERVER_
using namespace std;
PMap *pmap;
#define DEFAULT_MAX_ROUND 1000
#ifndef _SERVER_
void Loader_local::load(int argc,char *argv[])
{
    if(argc>=2)
        if (argv[argc-2][0] == '-' && argv[argc-2][1] == 'm' && argv[argc-2][2] == 'd' )
        {
            lgc->setMode(atoi(argv[argc-1]));
        }

    int playerNum = lgc->getPlayerNum();
    int campNum = lgc->getCampNum();
    cout << "playerNum:" << playerNum << " campNum:" << campNum << endl;
    if(argc < playerNum+1)
    {
        cerr << "Too Few Arguments!\n";
        throw -1;
    }

    if ((argc - playerNum - 1) & 1)
    {
        cerr << "Illegal Arguments!\n";
        throw -1;
    }
    int rd = DEFAULT_MAX_ROUND;
    string mapFile = "map.txt";

    for (int i = playerNum+1; i < argc; i += 2)
    {
        if (argv[i][0] == '-' && argv[i][1] == 'r' && argv[i][2] == 'd' )
            rd = atoi(argv[i+1]);
        else if (argv[i][0] == '-' && argv[i][1] == 'm' && argv[i][2] == 'p' )
            mapFile = argv[i+1];
    }
    lgc->getMapAndPlayer(rd, mapFile.c_str());
    pmap=new PMap(mapFile.c_str());
    //模式应该由开发者来决定（主要是玩家数和阵营数 默认均为3）
    for (int i = 0; i<playerNum; ++i)
    {
        ActMakerLocal *tmp;
        tmp = new ActMakerLocal();
        lgc->addActMaker(tmp);
        cout<<i<<' '<<argv[i+1]<<'\n';
        cout<<"status of ai" << i << "(0:failed 1:succeed):"<<(tmp->load(argv[i+1]))<<endl;
        tmp->setMap(pmap);
    }
    return;
}
#else
void Loader_web::load(int argc, char *argv[])
{
    //此处应有ai数量，模式等信息
    string mapFile;
    int mode;
    GameInfoMeta ginfometa;
    ginfometa.rlim_mem = 1 << 30;
    ifstream fin("resources.res");
    fin >> mapFile;
    if (mapFile[0] != '\"')
    {
        if (fin >> mode)
            lgc->setMode(mode);
        pmap=new PMap(mapFile.c_str());
        if(mode==0)
        {
            int pid;
            fin>>pid;pmap->playerIds[0]=pid;
            fin>>pid;pmap->playerIds[1]=pid;
        }
    } else
    {
        mapFile.erase(mapFile.begin());
        if (fin >> mode)
            lgc->setMode(mode);
        pmap=new PMap(mapFile.c_str());
        char a = 0;
        do{
            fin >> a;
        } while (a != 'n');
        if(mode==0)
        {
            int pid;
            fin>>pid;pmap->playerIds[0]=pid;
            fin>>pid;pmap->playerIds[1]=pid;
        }
    }
    logic::init(argc,argv,ginfometa,[=,pmap](int ai_num,SocketBase& c){
        c<<(*pmap);
    });
    int playerNum=lgc->getPlayerNum();
    if(mode==4)
        playerNum=2;
    int rd =DEFAULT_MAX_ROUND;
    fin.close();

    lgc->getMapAndPlayer(rd, mapFile.c_str());

    if ( logic::get_nr_ai()!=playerNum )
        throw AI9Error("THE NUMBER of AIs is wrong!");
    for(int i=0;i<playerNum;++i)
    {
        int conn_id=i;
        ActMakerWeb *tmp = new ActMakerWeb(conn_id);
        // glogic.addAI(actPlayer);
        lgc->addActMaker(tmp);
        if(mode==4 && i==0)
        {
            ActMakerLocal *tmpForSampleAi;
            tmpForSampleAi = new ActMakerLocal();
            lgc->addActMaker(tmpForSampleAi);
            cout<<"status of ai" << 1 << "(0:failed 1:succeed):"<<(tmpForSampleAi->load("./sampleAi/ai.so"))<<endl;
            tmpForSampleAi->setMap(pmap);
        }
    }
    return;
}
#endif//_SERVER_
/*void Judgement::judge(Game* lgc)
{
    int winner = -1;

    int playerNum = lgc->getPlayerNum();

    // if ( lgc->get_config_number_before_fight() != 0 )
    // {
    // 	for (int i=0; i<playerNum; ++i)
    // 	{
    // 		lgc->act_players()[i]->start_game(lgc->get_config_option_before_fight(), lgc->get_config_number_before_fight());
    // 	}
    // }

    lgc->init();
    do
    {
        lgc->roundStart();
        lgc->getPlayerInfo();
        lgc->getPlayerCmd();
        lgc->clean();
        lgc->outputReplayInfo();
    }
    while (lgc->winnerJudge() != NEXT);
}*/


// void Judgement_web::round_judge(PrototypeInfo* info, PrototypeCmd* cmd)
// {
// 	int winner = -1;

// }

// void Judgement_local::round_judge(PrototypeInfo* info, PrototypeCmd* cmd)
// {
// 	player_ai(info, cmd);
// 	return true;
// }

// bool ActPlayer_web::start_game(int *config_option, int config_number)
// {
// 	//
// }



Executor::Executor(int Argc, char *Argv[], Game* lgc): argc(Argc), argv(Argv), lgc(lgc)
{
#ifdef _SERVER_
    ld = new Loader_web(lgc);
    //jgm = new Judgement_web(lgc);
#else
    ld = new Loader_local(lgc);
    //jgm = new Judgement_local(lgc);
#endif
}

Executor::~Executor()
{
}

void Executor::load()
{
    ld->load(argc, argv);
}

void Executor::judge()
{
    int round=0;
    int winner;
    lgc->init();
    do
    {
        cout<<"Round:"<<(round++)<<"\n";
        lgc->oneRoundRun();
    }
    while ((winner=lgc->winnerJudge()) == NEXT_TURN);
    cout<<"winner:"<<winner<<"\n";
    delete ld;
    delete lgc;
#ifdef _SERVER_
    try
    {
        logic::kill(0);
        logic::kill(1);
        logic::kill(2);
    }
    catch(...)
    {
    }
    try{
        logic::end([](int,SocketBase&){});
    }
    catch(...){}
#endif//_SERVER_
    delete pmap;
}

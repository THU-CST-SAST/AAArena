#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Game/Game.h"
#include "include/Unit/Heroes.h"
#include "include/Skill/Skills.h"
#include "include/PCommand//Operation.h"
#include "include/Buff/Buffs.h"
#include "include/sdk/const.h"
#include <vector>
using namespace std;
const int rangeD = 144;

Hero::Hero(Game* Gm,const char* Name,int Camp,int Player,int ID,int Volume,Pos Ps):
    Unit(Gm,Name,Camp,Player,ID,Volume,Ps),beforeDead(-1,-1)
{
    addArg(new LastHit(this));
    addArg(new OnlyTarget(this));
}
void Hero::addBuff(Buff* newBuff)
{
    if(findBuff("Reviving")==NULL)
    {
        int a = ++buffRound[newBuff->getName()];
        if (rand()%a == 0)
            Unit::addBuff(newBuff);
        else delete newBuff;
    }
    else delete newBuff;
}
bool Hero::remove(){return false;}
bool Hero::useSkill()
{
    if(findBuff("Reviving")!=NULL)
        return false;
    if(findBuff("Dizzy")!=NULL && getGame()->getRoundProcess()==1)
        return false;
    if(findBuff("Yelled")!=NULL && getGame()->getRoundProcess()==1)
    {
        Pos foePos = getGame()->findUnitById(findArg("OnlyTarget")->getVal())->getLastPos();
        if( cmd->type=="Attack"
                && cmd->targets.size()==1
                && foePos==cmd->targets[0])
            return Unit::useSkill();
        return false;
    }
    return Unit::useSkill();
}
int Hero::getStatus()
{
    Buff *ptr=findBuff("Reviving");
    if(ptr!=NULL)
        return ptr->getTimeLeft()>0;
    return 0;
}
void Hero::changePos(Pos newPos)
{
    if(findBuff("Reviving")!=NULL)
    {
        beforeDead=pos;
    }
    pos=newPos;
}
void Hero::output(ostream &os)
{
    bool flag=(beforeDead!=Pos(-1,-1));
    if( flag)
    {
        Pos tmp=pos;
        pos=beforeDead;
        beforeDead=tmp;
    }
    Unit::output(os);
    if(flag)
    {
        Pos tmp=pos;
        pos=beforeDead;
        beforeDead=tmp;
    }
}
void Hero::roundStart()
{
    beforeDead=Pos(-1,-1);
    if(findBuff("Reviving"))
    {
        for(vector<Buff*>::iterator i=buffs.begin();i!=buffs.end();)
            if((*i)->getName()!="Reviving")
                buffs.erase(i);
            else ++i;
    }
    buffRound.clear();
    Unit::roundStart();
}

void Hero::makeOneStep()
{
    if(findBuff("Reviving")||findBuff("Dizzy"))
        return;
    Unit::makeOneStep();
}

void Hero::clean()
{
    if(findBuff("Reviving"))
        for(vector<Buff*>::iterator i=buffs.begin();i!=buffs.end();)
            if((*i)->getName()!="Reviving")
            {
                delete (*i);
                buffs.erase(i);
            }
            else ++i;
    Unit::clean();
}
//==========
Fighter::Fighter(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Fighter",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Charge(this));
//    addSkill(new Spin(this));
//    addSkill(new Yell(this));
//    addSkill(new YellowPoint(this));
//    addSkill(new ChargeLU(this));
//    addSkill(new SpinLU(this));
//    addSkill(new YellLU(this));
//    addSkill(new LevelUp(this,35,4,3));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(350,this));
//    addArg(new Mp(200,this));
//    addArg(new Atk(30,this));
//    addArg(new Def(10,this));
//    addArg(new Speed(12,this));
//    addArg(new Range(8,0,this));
//    addArg(new Exp(100,0,1,100,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Fighter_attack_maxcd));
    addSkill(new Charge(this));
    addSkill(new Spin(this));
    addSkill(new Yell(this));
    addSkill(new YellowPoint(this));
    addSkill(new ChargeLU(this));
    addSkill(new SpinLU(this));
    addSkill(new YellLU(this));
    addSkill(new LevelUp(this,Fighter_hp_delta,Fighter_atk_delta,Fighter_def_delta));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Fighter_base_hp,this));
    addArg(new Mp(Fighter_mp,this));
    addArg(new Atk(Fighter_base_atk,this));
    addArg(new Def(Fighter_base_def,this));
    addArg(new Speed(Fighter_speed,this));
    addArg(new Range(Fighter_range,0,this));
    addArg(new Exp(HeroArgs::expForLevelUp(0),0,1,HeroArgs::currentLevel_exp(0),this));
    addArg(new View(Fighter_view,this));
}
//============
Archer::Archer(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Archer",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new PiercingArrow(this));
//    addSkill(new ArrowsRain(this));
//    addSkill(new PowerUp(this));
//    addSkill(new YellowPoint(this));
//    addSkill(new PALU(this));
//    addSkill(new ARLU(this));
//    addSkill(new PULU(this));
//    addSkill(new LevelUp(this,25,5,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(250,this));
//    addArg(new Mp(200,this));
//    addArg(new Atk(32,this));
//    addArg(new Def(5,this));
//    addArg(new Speed(25,this));
//    addArg(new Range(81,1,this));
//    addArg(new Exp(100,0,1,100,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Archer_attack_maxcd));
    addSkill(new PiercingArrow(this));
    addSkill(new ArrowsRain(this));
    addSkill(new PowerUp(this));
    addSkill(new YellowPoint(this));
    addSkill(new PALU(this));
    addSkill(new ARLU(this));
    addSkill(new PULU(this));
    addSkill(new LevelUp(this,Archer_hp_delta,Archer_atk_delta,Archer_def_delta));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Archer_base_hp,this));
    addArg(new Mp(Archer_mp,this));
    addArg(new Atk(Archer_base_atk,this));
    addArg(new Def(Archer_base_def,this));
    addArg(new Speed(Archer_speed,this));
    addArg(new Range(Archer_range,1,this));
    addArg(new Exp(HeroArgs::expForLevelUp(0),0,1,HeroArgs::currentLevel_exp(0),this));
    addArg(new View(Archer_view,this));
}
//==============
Assassin::Assassin(Game* Gm,int Camp,int Player,int ID,Pos Ps):
    Hero(Gm,"Assassin",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,1));
//    addSkill(new Hide(this));
//    addSkill(new FlyingBlade(this));
//    addSkill(new Blink(this));
//    addSkill(new YellowPoint(this));
//    addSkill(new HideLU(this));
//    addSkill(new FBLU(this));
//    addSkill(new BlinkLU(this));
//    addSkill(new LevelUp(this,20,6,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(200,this));
//    addArg(new Mp(200,this));
//    addArg(new Atk(29,this));
//    addArg(new Def(3,this));
//    addArg(new Speed(20,this));
//    addArg(new Range(5,0,this));
//    addArg(new Exp(100,0,1,100,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Assassin_attack_maxcd));
    addSkill(new Hide(this));
    addSkill(new FlyingBlade(this));
    addSkill(new Blink(this));
    addSkill(new YellowPoint(this));
    addSkill(new HideLU(this));
    addSkill(new FBLU(this));
    addSkill(new BlinkLU(this));
    addSkill(new LevelUp(this,Assassin_hp_delta,Assassin_atk_delta,Assassin_def_delta));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Assassin_base_hp,this));
    addArg(new Mp(Assassin_mp,this));
    addArg(new Atk(Assassin_base_atk,this));
    addArg(new Def(Assassin_base_def,this));
    addArg(new Speed(Assassin_speed,this));//20!=9
    addArg(new Range(Assassin_range,0,this));
    addArg(new Exp(HeroArgs::expForLevelUp(0),0,1,HeroArgs::currentLevel_exp(0),this));
    addArg(new View(Assassin_view,this));
}
//===============
Tower::Tower(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Tower",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,Tower_attack_maxcd));
    addArg(new Hp(Tower_hp,this));
    addArg(new Atk(Tower_atk,this));
    addArg(new Def(Tower_def,this));
    addArg(new Speed(0,this));
    addArg(new Range(Tower_range,1,this));
    addArg(new Exp(100,0,0,0,this));
    addArg(new View(Tower_view,this,1));
}

void Tower::roundStart()
{
    if(cmd!=NULL)
    {
        delete cmd;
        cmd=NULL;
    }

    cmd = new Operation();
    int range = findArg("Range")->getVal();

    vector<int> foe;
    foe.clear();
    for (int i = 0; i < game->getUnits().size(); ++i)
    {
        Unit* ptr = game->getUnits()[i];
        if (ptr->getCamp() != camp && dis2(ptr->getLastPos(), pos) <= range)
        {
            foe.push_back(i);
        }
    }
    if (foe.size())
	{
		Pos ps = game->getUnits()[foe[rand()%foe.size()]]->getPos();
		cmd->targets.push_back(ps);
		cmd->type = "Attack";
	}
}

void Tower::addBuff(Buff *newBuff)
{
    delete newBuff;
}
bool Tower::remove()
{
    return getStatus();
}
int Tower::getStatus()
{
    return findArg("Hp")->getVal()<=0;
}

Spring::Spring(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Spring",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,1));
//    addSkill(new Recovery(this));
//    addArg(new Hp(2000,this));
//    addArg(new Atk(100,this));
//    addArg(new Def(0,this));
//    addArg(new Speed(0,this));
//    addArg(new Range(rangeD,1,this));
//    addArg(new Exp(100,0,0,0,this));
//    addArg(new View(rangeD,this,1));
    addSkill(new Attack(this,Spring_attack_maxcd));
    addSkill(new Recovery(this));
    addArg(new Hp(Spring_hp,this));
    addArg(new Atk(Spring_atk,this));
    addArg(new Def(Spring_def,this));
    addArg(new Speed(0,this));
    addArg(new Range(Spring_range,1,this));//rangeD!=Spring_range
    addArg(new Exp(100,0,0,0,this));
    addArg(new View(rangeD,this,1));

}

void Spring::roundStart()
{
    if(cmd!=NULL)
    {
        delete cmd;
        cmd=NULL;
    }

    cmd = new Operation();
    int range = findArg("Range")->getVal();

    vector<int> foe;
    foe.clear();
    for (int i = 0; i < game->getUnits().size(); ++i)
    {
        Unit* ptr = game->getUnits()[i];
        if (ptr->getCamp() != camp && dis2(ptr->getLastPos(), pos) <= range)
        {
            foe.push_back(i);
        }
    }
    if (foe.size())
    {
        Pos ps = game->getUnits()[foe[rand()%foe.size()]]->getPos();
        cmd->targets.push_back(ps);
        cmd->type = "Attack";
    }
}

void Spring::addBuff(Buff *newBuff)
{
    delete newBuff;
}
bool Spring::remove()
{
    return getStatus();
}
int Spring::getStatus()
{
    return findArg("Hp")->getVal()<=0;
}

//================
Dog::Dog(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Dog",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(250,this));
//    addArg(new Atk(25,this));
//    addArg(new Def(10,this));
//    addArg(new Speed(16,this));
//    addArg(new Range(9,0,this));
//    addArg(new Exp(100,3,0,70,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Dog_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Dog_hp,this));
    addArg(new Atk(Dog_atk,this));
    addArg(new Def(Dog_def,this));
    addArg(new Speed(Dog_speed,this));
    addArg(new Range(Dog_range,0,this));
    addArg(new Exp(100,Dog_reviving_time/5-1,0,Dog_exp,this));
    addArg(new View(rangeD,this));
}
/*
Ant::Ant(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Ant",Camp,Player,ID,1,Ps)
{
    addSkill(new Attack(this,1));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(200,this));
    addArg(new Atk(30,this));
    addArg(new Def(6,this));
    addArg(new Speed(20,this));
    addArg(new Range(9,0,this));
    addArg(new Exp(100,3,0,75,this));
    addArg(new View(rangeD,this));
}*/
Bow::Bow(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Bow",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(280,this));
//    addArg(new Atk(35,this));
//    addArg(new Def(0,this));
//    addArg(new Speed(16,this));
//    addArg(new Range(81,1,this));
//    addArg(new Exp(100,3,0,90,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Bow_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Bow_hp,this));
    addArg(new Atk(Bow_atk,this));
    addArg(new Def(Bow_def,this));
    addArg(new Speed(Bow_speed,this));
    addArg(new Range(Bow_range,1,this));
    addArg(new Exp(100,Bow_reviving_time/5-1,0,Bow_exp,this));
    addArg(new View(rangeD,this));
}
Wolf::Wolf(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Wolf",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,1));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(350,this));
//    addArg(new Atk(42,this));
//    addArg(new Def(12,this));
//    addArg(new Speed(16,this));
//    addArg(new Range(9,0,this));
//    addArg(new Exp(100,4,0,150,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Wolf_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Wolf_hp,this));
    addArg(new Atk(Wolf_atk,this));
    addArg(new Def(Wolf_def,this));
    addArg(new Speed(Wolf_speed,this));
    addArg(new Range(Wolf_range,0,this));
    addArg(new Exp(100,Wolf_reviving_time/5-1,0,Wolf_exp,this));
    addArg(new View(rangeD,this));
}
StoneMan::StoneMan(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"StoneMan",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(550,this));
//    addArg(new Atk(35,this));
//    addArg(new Def(25,this));
//    addArg(new Speed(12,this));
//    addArg(new Range(9,0,this));
//    addArg(new Exp(100,4,0,150,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,StoneMan_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(StoneMan_hp,this));
    addArg(new Atk(StoneMan_atk,this));
    addArg(new Def(StoneMan_def,this));
    addArg(new Speed(StoneMan_speed,this));
    addArg(new Range(StoneMan_range,0,this));
    addArg(new Exp(100,StoneMan_reviving_time/5-1,0,StoneMan_exp,this));
    addArg(new View(rangeD,this));
}
Dragon::Dragon(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Dragon",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(600,this));
//    addArg(new Atk(80,this));
//    addArg(new Def(10,this));
//    addArg(new Speed(12,this));
//    addArg(new Range(81,1,this));
//    addArg(new Exp(100,11,0,500,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Dragon_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Dragon_hp,this));
    addArg(new Atk(Dragon_atk,this));
    addArg(new Def(Dragon_def,this));
    addArg(new Speed(Dragon_speed,this));
    addArg(new Range(Dragon_range,1,this));
    addArg(new Exp(100,Dragon_reviving_time/5-1,0,Dragon_exp,this));
    addArg(new View(rangeD,this));
}
Roshan::Roshan(Game *Gm, int Camp, int Player, int ID, Pos Ps):
    Hero(Gm,"Roshan",Camp,Player,ID,1,Ps)
{
//    addSkill(new Attack(this,2));
//    addSkill(new Dead(this,Ps));
//    addArg(new Hp(1200,this));
//    addArg(new Atk(65,this));
//    addArg(new Def(25,this));
//    addArg(new Speed(12,this));
//    addArg(new Range(9,0,this));
//    addArg(new Exp(100,15,0,500,this));
//    addArg(new View(rangeD,this));
    addSkill(new Attack(this,Roshan_attack_maxcd));
    addSkill(new Dead(this,Ps));
    addArg(new Hp(Roshan_hp,this));
    addArg(new Atk(Roshan_atk,this));
    addArg(new Def(Roshan_def,this));
    addArg(new Speed(Roshan_speed,this));
    addArg(new Range(Roshan_range,0,this));
    addArg(new Exp(100,Roshan_reviving_time/5-1,0,Roshan_exp,this));
    addArg(new View(rangeD,this));
}
//==================
Chooser::Chooser(Game *Gm, int Camp, int Player, int ID, Pos Ps, Pos HeroPos):
    Unit(Gm,"Chooser",Camp,Player,ID,1,Ps)
{
    addArg(new View(5,this));
    addSkill(new ChooseFighter(this,HeroPos));
    addSkill(new ChooseArcher(this,HeroPos));
    addSkill(new ChooseAssassin(this,HeroPos));
}

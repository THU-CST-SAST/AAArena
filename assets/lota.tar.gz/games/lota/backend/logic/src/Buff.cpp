//#include "include/Base.h"
#include "include/ActMaker/ActMaker.h"
#include "include/Area/Area.h"
#include "include/Buff/Buff.h"
#include "include/PCommand/PCommand.h"
#include "include/Flight/Flight.h"
#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/PCommand/Operation.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/Skill/Skill.h"
#include "include/Unit/Unit.h"
#include "include/UnitArg/UnitArg.h"
Buff::Buff(const char *Name, Unit *myUnit, int TimeLeft, int Level, const char *Des):
    unit(myUnit),name(Name),des(Des),timeLeft(TimeLeft),level(Level)
{
}
void Buff::oneRoundPass()
{
    --timeLeft;
}
void Buff::roundStart()
{
}
void Buff::terminate()//buff终止特效
{
    if(timeLeft>0)
        return;
}
void Buff::work(){}//非累计型buff生效
void Buff::overlap(Buff *buff)
{
    *this = *buff;
    delete buff;
}
bool Buff::remove()
{
    return timeLeft==0;
}
void Buff::output(ostream &os)
{
    os<<"{";
    {
        os<<"name:"<<name<<";";
        os<<"description:"<<des<<";";
        os<<"time:"<<timeLeft;
    }
    os<<"}";
}
string Buff::toString()
{
    return name + "&" + ToString(level) + "&" + ToString(timeLeft);
}

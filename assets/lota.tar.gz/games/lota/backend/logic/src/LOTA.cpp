#include "include/Game/LOTA.h"
#include "include/Map/Map.h"
#include "include/Unit/Heroes.h"
#include "include/PlayerInfo/PlayerInfo.h"
#include "include/PCommand/PCommand.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Pos.h"
#include "include/sdk/sdk.h"
#define sqr(x) ((x)*(x))
#include "include/sdk/const.h"

void findPVCpath(Map *map, Pos start, Pos dest, std::vector<Pos> &_path)
{
    static int vst[Map_size][Map_size];
    static Pos Q[Map_size * Map_size + 1], Q_prior[Map_size][Map_size];
    static int countF = 0;
    _path.clear();
    Pos _0, _1;

    int dir_ord[4];
    Q[0] = start;
    ++countF;
    vst[start.x][start.y] = countF;
    for (int front=0, rear=0; front<=rear; ++front) {
        _0 = Q[front];
        for (int i=0; i<4; ++i) dir_ord[i] = i;
        random_shuffle(dir_ord, dir_ord+4);

        for (int i=0; i<4; ++i) {
            _1.x = _0.x + dir[dir_ord[i]][0];
            _1.y = _0.y + dir[dir_ord[i]][1];
            if (checkPos(_1) && abs(map->getHeight(_0)- map->getHeight(_1)) <= 1 && vst[_1.x][_1.y] != countF) {
                vst[_1.x][_1.y] = countF;
                Q[++rear] = _1;
                Q_prior[_1.x][_1.y] = _0;
            }
        }
    }

    if (vst[dest.x][dest.y] == countF) {
        for (_0 = dest; _0 != start; _0 = Q_prior[_0.x][_0.y])
            _path.push_back(_0);
        _path.push_back(_0);
        reverse(_path.begin(), _path.end());
    } else _path.push_back(Pos());
}
void LOTA::setPVCcmd(const Operation &op)
{
//    static Pos b[30000];
//    static int pre[30000];
//    static bool used[160][160];
//    static Pos d[4]={Pos(0,1),Pos(0,-1),Pos(-1,0),Pos(1,0)};
    Unit *unit=findUnitById(op.id);
    if(unit!=NULL)
    {

        cout<<op.type<<'\n';
        if(op.type=="Move")
        {
            if(op.targets.size()==0 || !map->tryPosition(op.targets[0],1))
                return;
            Operation a(op);
            findPVCpath(map,unit->getPos(),op.targets[0],a.targets);
            unit->setCmd(a);
            /*
            int h=0,t=0;
            b[h]=op.targets[0];
            pre[0]=-1;
            memset(used,0,sizeof(used));
            for(;h<=t;++h)
            {
                for(int j=0;j<4;++j)
                {
                    Pos tmp=b[h]+d[j];
                    if(map->tryPosition(tmp,1)&&!used[tmp.x][tmp.y])
                        if(abs(map->getHeight(tmp)-map->getHeight(b[h]))<2)
                        {
                            b[++t]=tmp;
                            used[tmp.x][tmp.y]=true;
                            pre[t]=h;
                            if(b[t]==unit->getPos())
                            {
                                Operation a(op);
                                a.targets.clear();
                                for(int k=t;k>-1;k=pre[k])
                                    a.targets.push_back(b[k]);
                                unit->setCmd(a);
                                break;
                            }
                        }
                }
                if(b[t]==unit->getPos())
                    break;
            }*/
        }
        else
            unit->setCmd(op);
    }
}
LOTA::LOTA():
    Game()
{
    playerNum=3;
    campNum=3;
}

void LOTA::getMapAndPlayer(int MaxRound,const char* FileName)
{
    map=new Map(151,151,FileName);
    maxRound=MaxRound;
    playerCamp.resize(3);
    playerCamp[0]=0;
    playerCamp[1]=1;
    playerCamp[2]=2;
    addCmd(new PCommand());
    addCmd(new PCommand());
    addCmd(new PCommand());
    addInfo(new PlayerInfo(this,0));
    addInfo(new PlayerInfo(this,1));
    addInfo(new PlayerInfo(this,2));
}

void LOTA::init()
{
    if(mode==0 || mode==4)
    {
        if (mode==0)
        {
            addUnit(new Chooser(this,0,0,0,Pos(0,0),Player0_hero_initial_pos[0]));
            addUnit(new Chooser(this,0,0,1,Pos(2,0),Player0_hero_initial_pos[1]));
        }
        else
        {
            addId(0, "Chooser");
            addId(1, "Chooser");
        }
        addUnit(new Chooser(this,0,0,2,Pos(4,0),Player0_hero_initial_pos[2]));
        addUnit(new Chooser(this,0,0,3,Pos(6,0),Player0_hero_initial_pos[3]));
        addUnit(new Chooser(this,0,0,4,Pos(8,0),Player0_hero_initial_pos[4]));

        addUnit(new Chooser(this,1,1,5,Pos(0,100),Player1_hero_initial_pos[0]));
        addUnit(new Chooser(this,1,1,6,Pos(2,100),Player1_hero_initial_pos[1]));
        addUnit(new Chooser(this,1,1,7,Pos(4,100),Player1_hero_initial_pos[2]));
        addUnit(new Chooser(this,1,1,8,Pos(6,100),Player1_hero_initial_pos[3]));
        addUnit(new Chooser(this,1,1,9,Pos(8,100),Player1_hero_initial_pos[4]));

        addUnit(new Tower(this,0,0,10,Player0_tower_pos[0]));
        addUnit(new Tower(this,0,0,11,Player0_tower_pos[1]));

        addUnit(new Tower(this,1,1,12,Player1_tower_pos[0]));
        addUnit(new Tower(this,1,1,13,Player1_tower_pos[1]));

        addUnit(new Spring(this,0,0,14,Player0_spring_pos[0]));
        addUnit(new Spring(this,1,1,15,Player1_spring_pos[0]));

        int monsterId=0;//Dog
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new Dog(this,2,2,-1,monsters[monsterId].poslist[i]));
        monsterId=1;//Bow
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new Bow(this,2,2,-1,monsters[monsterId].poslist[i]));
        monsterId=2;//Wolf
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new Wolf(this,2,2,-1,monsters[monsterId].poslist[i]));
        monsterId=3;//StoneMan
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new StoneMan(this,2,2,-1,monsters[monsterId].poslist[i]));
        monsterId=4;//Dragon
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new Dragon(this,2,2,-1,monsters[monsterId].poslist[i]));
        monsterId=5;//Roshan
        for(int i=0;i<monsters[monsterId].poslist.size();++i)
            addUnit(new Roshan(this,2,2,-1,monsters[monsterId].poslist[i]));
/*
        addUnit(new Tower(this,0,0,10,Pos(75,116)));
        addUnit(new Tower(this,0,0,11,Pos(116,75)));

        addUnit(new Tower(this,1,1,12,Pos(75,34)));
        addUnit(new Tower(this,1,1,13,Pos(34,75)));

        addUnit(new Spring(this,0,0,14,Pos(5,145)));
        addUnit(new Spring(this,1,1,15,Pos(145,5)));

        addUnit(new Dragon(this,2,2,-1,Pos(5,5))); // big
        addUnit(new Dog(this,2,2,-1,Pos(8,34))); // small
        addUnit(new StoneMan(this,2,2,-1,Pos(32,95))); // mid
        addUnit(new Bow(this,2,2,-1,Pos(8,102))); // small
        addUnit(new Dog(this,2,2,-1,Pos(34,34))); // small
        addUnit(new Wolf(this,2,2,-1,Pos(34,54))); // mid
        addUnit(new Dog(this,2,2,-1,Pos(54,8))); // mid
        addUnit(new Wolf(this,2,2,-1,Pos(56,34))); // mid
        addUnit(new Bow(this,2,2,-1,Pos(54,54))); // small
        addUnit(new Dog(this,2,2,-1,Pos(54,75))); // small
        addUnit(new Bow(this,2,2,-1,Pos(54,115))); // small

        addUnit(new Roshan(this,2,2,-1,Pos(75,75))); // roshan

        addUnit(new Dragon(this,2,2,-1,Pos(145,145))); // big
        addUnit(new Dog(this,2,2,-1,Pos(142,116))); // small
        addUnit(new StoneMan(this,2,2,-1,Pos(118,55))); // mid
        addUnit(new Bow(this,2,2,-1,Pos(142,58))); // small
        addUnit(new Dog(this,2,2,-1,Pos(116,116))); // small
        addUnit(new Wolf(this,2,2,-1,Pos(116,96))); // mid
        addUnit(new Dog(this,2,2,-1,Pos(96,142))); // mid
        addUnit(new Wolf(this,2,2,-1,Pos(94,116))); // mid
        addUnit(new Bow(this,2,2,-1,Pos(96,96))); // small
        addUnit(new Dog(this,2,2,-1,Pos(96,75))); // small
        addUnit(new Bow(this,2,2,-1,Pos(96,35))); // small*/
    }
    else if( mode==1 || mode==2)
    {
        addUnit(new Chooser(this,0,0,0,Pos(0,0),Pos(6,144)));
        addUnit(new Dog(this,1,1,2,Pos(5,5)));
    }
    else if(mode==3)
    {
        addUnit(new Chooser(this,0,0,0,Pos(0,0),Pos(6,144)));
        addUnit(new Chooser(this,0,0,1,Pos(2,0),Pos(4,144)));
        addUnit(new Chooser(this,0,0,2,Pos(4,0),Pos(6,146)));
        addUnit(new Chooser(this,0,0,3,Pos(6,0),Pos(6,142)));
        addUnit(new Chooser(this,0,0,4,Pos(8,0),Pos(8,144)));
        addUnit(new Dog(this,1,1,5,Pos(75,75)));
    }
}

int LOTA::winnerJudge()
{
    if(winner!=-1)return winner;
    if(mode ==0 || mode==4)
    {
        bool pd0=false, pd1=false;
        for (int i = 0; i < units.size(); ++i)
        {
            if (units[i]->getId()== 10 || units[i]->getId() == 11)
                pd0=true;
            if (units[i]->getId() == 12 || units[i]->getId() == 13)
                pd1=true;
        }
        if (!pd0 && !pd1)
            winner=-2;
        else if (!pd0)
            winner=1;
        else if (!pd1)
            winner=0;
        else if(round>=maxRound && winner==-1)
        {
            int x0=0,x1=0,hp0=0,hp1=0,exp0=0,exp1=0;
            for (int i = 0; i < units.size(); ++i)
            {
                if (units[i]->getId()== 10 || units[i]->getId() == 11)
                    ++x0,hp0+=units[i]->findArg("Hp")->getVal();
                else if (units[i]->getId() == 12 || units[i]->getId() == 13)
                    ++x1,hp1+=units[i]->findArg("Hp")->getVal();
                else if (units[i]->getCamp()==0)
                    exp0+=units[i]->findArg("Exp")->getVal();
                else if (units[i]->getCamp()==1)
                    exp1+=units[i]->findArg("Exp")->getVal();
            }
            if(x0!=x1)
                winner=(x0>x1?0:1);
            else if(hp0!=hp1)
                winner=(hp0>hp1?0:1);
            else if(exp0!=exp1)
                winner=(exp0>exp1?0:1);
            else winner=-2;
        }
#ifndef _PVC_
        if(winner!=-1)
            fout<<"winner:"<<winner<<'\n';
#endif//_PVC_
    }
    else if( mode==1)
    {
        if( findUnitById(1)!=NULL)
            winner=0;
        else if(round==3)
            winner=1;
        if(winner!=-1)
            fout<<"winner:"<<winner<<'\n';
    }
    else if (mode==2)
    {
        if(findUnitById(1)==NULL || round==100)
            winner=1;
        else
        {
            Unit* ptr=findUnitById(1);
            if(dis2(ptr->getPos(),Pos(144,6))<100)
                winner=0;
        }
        if(winner!=-1)
            fout<<"winner:"<<winner<<'\n';
    }
    else if(mode==3)
    {
        if(findUnitById(5)->findBuff("Reviving")!=NULL)
            winner=0;
        else if(round==100)
            winner=1;
        if(winner!=-1)
            fout<<"winner:"<<winner<<'\n';
    }
    return winner;
}

void LOTA::setMode(int Mode)
{
    mode=Mode;
    playerCamp.clear();
    if(mode==0 || mode==4)
    {
        playerNum=campNum=3;
        playerCamp.push_back(0);
        playerCamp.push_back(1);
        playerCamp.push_back(2);
    }
    else if(mode==1 || mode==2 || mode==3)
    {
        playerNum=campNum=2;
        playerCamp.push_back(0);
        playerCamp.push_back(1);
    }
}

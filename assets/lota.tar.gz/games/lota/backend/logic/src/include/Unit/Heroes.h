#ifndef AI9_2015_Heroes_H
#define AI9_2015_Heroes_H

#include "Unit.h"
#include "../Buff/Buff.h"
#include "../Pos.h"
#include "../Game/Game.h"
class Hero:public Unit
{
public:
    Hero(Game* Gm,const char* Name,int Camp,int Player,int ID,int Volume,Pos Ps);
    virtual void addBuff(Buff* newBuff);
    virtual bool remove();
    virtual bool useSkill();
    virtual int getStatus();
    virtual void changePos(Pos newPos);
    virtual void output(ostream &os);
    virtual void roundStart();
    virtual void makeOneStep();
    virtual void clean();
protected:
    Pos beforeDead;
    std::map<std::string,int> buffRound;
};
class Fighter:public Hero
{
public:
    Fighter(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Archer:public Hero
{
public:
    Archer(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Assassin:public Hero
{
public:
    Assassin(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
//============
class Tower:public Hero
{
public:
    Tower(Game* Gm,int Camp,int Player,int ID,Pos Ps);
    virtual void roundStart();
    virtual void setCmd(const Operation& Cmd){}
    virtual void addBuff(Buff* newBuff);
    virtual bool remove();
    virtual int getStatus();
};
class Spring:public Hero
{
public:
    Spring(Game* Gm,int Camp,int Player,int ID,Pos Ps);
    virtual void roundStart();
    virtual void setCmd(const Operation& Cmd){}
    virtual void addBuff(Buff* newBuff);
    virtual bool remove();
    virtual int getStatus();
};
//============
class Dog:public Hero
{
public:
    Dog(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Ant:public Hero
{
public:
    Ant(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Bow:public Hero
{
public:
    Bow(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Wolf:public Hero
{
public:
    Wolf(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class StoneMan:public Hero
{
public:
    StoneMan(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Dragon:public Hero
{
public:
    Dragon(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
class Roshan:public Hero
{
public:
    Roshan(Game* Gm,int Camp,int Player,int ID,Pos Ps);
};
//===========
class Chooser:public Unit
{
public:
    Chooser(Game* Gm,int Camp,int Player,int ID,Pos Ps,Pos HeroPos);
    virtual bool remove(){return true;}
    virtual bool findCollision(){return false;}
    virtual int getStatus(){return 0;}
};
#endif//AI9_2015_Heroes_H

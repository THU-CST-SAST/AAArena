#ifndef AI9_2015_FLIGHTS_H
#define AI9_2015_FLIGHTS_H

#include "Flight.h"
#include "../Pos.h"
class Game;
class FlightBlade : public Flight
{
public:
    virtual void roundStart();
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    FlightBlade(Game* Gm,int UnitID,int Id,int Camp,Pos Start,int TargetId,int Level);
    virtual ~FlightBlade(){}
protected:
    int level;
    int targetId;
    bool hit;//命中与否
};

class SignalArrow : public Flight
{
public:
    virtual void oneRoundPass();
    virtual void terminate();
    virtual bool remove();
    virtual int getHit();
    SignalArrow(Game* Gm,int UnitID,int Id,int Camp,Pos Start,Pos TargetPos,int Level);
    virtual ~SignalArrow(){}
protected:
    int level;
};

#endif//AI9_2015_FLIGHTS_H

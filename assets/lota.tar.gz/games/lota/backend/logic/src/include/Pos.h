#ifndef POS_H
#define POS_H
struct Pos
{
	int x,y;
	Pos(int X=-1,int Y=-1):
		x(X),y(Y)
	{
	}
		
};
struct DPos
{
	double x,y;
	DPos(double X=-1,double Y=-1):
		x(X),y(Y)
	{
	}
    DPos(const Pos &pos):
		x(pos.x),y(pos.y)
	{
	}
};
int crossProduct(Pos A,Pos B,Pos C);//向量AB叉乘AC
bool cross(Pos A,Pos B,Pos C,Pos D);//判断线段AB与CD是否有公共点
bool checkOnLine(Pos A,Pos B,Pos C);//判断AB连线是否与C（方格）有交点
int dis2(Pos A,Pos B);//欧氏距离平方
double dis(Pos A,Pos B);//欧几里得距离
bool operator==(Pos A,Pos B);
bool operator!=(Pos A,Pos B);
Pos operator+(Pos A,Pos B);
Pos operator-(Pos A,Pos B);
Pos operator*(Pos A,int _);
Pos operator*(int _,Pos A);
//以下面对DPos定义的函数其功能与面对Pos的相应函数相同
double crossProduct(DPos A,DPos B,DPos C);
bool cross(DPos A,DPos B,DPos C,DPos D);
bool checkOnLine(DPos A,DPos B,DPos C);
double dis2(DPos A,DPos B);
double dis(DPos A,DPos B);
bool operator==(DPos A,DPos B);
bool operator!=(DPos A,DPos B);
DPos operator+(DPos A,DPos B);
DPos operator-(DPos A,DPos B);
DPos operator*(DPos A,double _);
DPos operator*(double _,DPos A);
#endif//Pos_H

#ifndef TRANS_H
#define TRANS_H
#ifndef _AI__
#include "Pos.h"
#else
#include "sdk.h"
#endif//_AI__
#include <string>
int String2Int(std::string);
double String2Double(std::string);
DPos String2DPos(std::string);
Pos String2Pos(std::string);
std::string ToString(int);
std::string ToString(double);
std::string ToString(DPos);
std::string ToString(Pos);

#endif//TRANS_H

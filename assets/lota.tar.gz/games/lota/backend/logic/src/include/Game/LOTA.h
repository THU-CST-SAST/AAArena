#ifndef AI9_2015_LOTA_H
#define AI9_2015_LOTA_H

#include "Game.h"

class LOTA : public Game
{
public:
    LOTA();
    virtual void getMapAndPlayer(int MaxRound,const char* FileName);
    virtual void init();
    virtual int winnerJudge();
    virtual void setMode(int Mode);
    virtual ~LOTA(){}
    void setPVCcmd(const Operation &op);
};

#endif//AI9_2015_LOTA_H

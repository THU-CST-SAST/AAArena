#ifndef AI9_2015_Skills_H
#define AI9_2015_Skills_H

#include "Skill.h"
#include "../Unit/Unit.h"

class Attack:public Skill
{
public:
    Attack(Unit* myUnit,int MaxCd);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~Attack(){}
};
class YellowPoint:public Skill
{
public:
    YellowPoint(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual ~YellowPoint(){}
protected:
    int ahp;
    int aatk;
    int adef;
};
class Recovery:public Skill
{
public:
    Recovery(Unit* myUnit);
	virtual bool canBeUse();
	virtual bool trigger();
    virtual ~Recovery(){}
protected:
	int ahp;
	int amp;
	int range;
};
class Hide : public Skill
{
public:
    Hide(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~Hide(){}
protected:
	int mp;
};
class HideLU:public Skill
{
public:
    HideLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~HideLU(){}
};
class FlyingBlade : public Skill
{
public:
    FlyingBlade(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual bool levelUp();
    virtual string toString();
    virtual ~FlyingBlade(){}
protected:
    int mp;
    int range;
};
class FBLU:public Skill
{
public:
    FBLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~FBLU(){}
};
class Blink : public Skill
{
public:
    Blink(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Blink(){}
protected:
    int mp;
    int range;
};
class BlinkLU:public Skill
{
public:
    BlinkLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~BlinkLU(){}
};
class PiercingArrow : public Skill
{
public:
    PiercingArrow(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~PiercingArrow(){}
protected:
    bool check(Pos a, Pos b, Pos c);
    int mp;
    int range;
    int dmg;
    double wid;
};
class PALU:public Skill
{
public:
    PALU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~PALU(){}
};
class ArrowsRain : public Skill
{
public:
    ArrowsRain(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~ArrowsRain(){}
protected:
    int mp;
    int range;
};
class ARLU:public Skill
{
public:
    ARLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~ARLU(){}
};
class PowerUp : public Skill
{
public:
    PowerUp(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~PowerUp(){}
protected:
	int mp;
};
class PULU:public Skill
{
public:
    PULU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~PULU(){}
};
class Charge:public Skill
{
public:
    Charge(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Charge(){}
protected:
    int mp;
    int range;
    int dmg;
};
class ChargeLU:public Skill
{
public:
    ChargeLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~ChargeLU(){}
};
class Spin : public Skill
{
public:
    Spin(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Spin(){}
protected:
    int mp;
    int range;
    int dmg;
};
class SpinLU:public Skill
{
public:
    SpinLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~SpinLU(){}
};
class Yell : public Skill
{
public:
    Yell(Unit* myUnit);
    virtual bool levelUp();
    virtual bool canBeUse();
    virtual bool trigger();
    virtual string toString();
    virtual ~Yell(){}
protected:
    int mp;
    int range;
};
class YellLU:public Skill
{
public:
    YellLU(Unit* myUnit);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~YellLU(){}
};
class LevelUp:public Skill
{
public:
    LevelUp(Unit* myUnit,int Hp,int Atk,int Def);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~LevelUp(){}
protected:
    int ahp;
    int aatk;
    int adef;
};
class Dead:public Skill
{
public:
    Dead(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual void output(ostream &os,int x){}
    virtual ~Dead(){}
protected:
    Pos pos;
    int range;
    bool check(Pos tmp);
    void shareExp();
};
//=================
class ChooseFighter:public Skill
{
public:
    ChooseFighter(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseFighter(){}
protected:
    Pos pos;
};

class ChooseArcher:public Skill
{
public:
    ChooseArcher(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseArcher(){}
protected:
    Pos pos;
};

class ChooseAssassin:public Skill
{
public:
    ChooseAssassin(Unit* myUnit,Pos Ps);
    virtual bool canBeUse();
    virtual bool trigger();
    virtual ~ChooseAssassin(){}
protected:
    Pos pos;
};
#endif//AI9_2015_Skills_H

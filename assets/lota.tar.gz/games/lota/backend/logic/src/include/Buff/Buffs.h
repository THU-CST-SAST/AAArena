#ifndef AI9_2015_BUFFS_H
#define AI9_2015_BUFFS_H

#include "Buff.h"
class Hided:public Buff
{
public:
    virtual bool remove();
    virtual void work();
    virtual void terminate();
    Hided(Unit *myUnit,int Level);
    virtual ~Hided(){}
protected:
    int delta;
    bool end;
};

class Rainy:public Buff
{
public:
    virtual void work();
    virtual void oneRoundPass();
    virtual void terminate();
    Rainy(Unit *myUnit,int Level,int UnitId);
    virtual void overlap(Buff *buff);
    virtual ~Rainy(){}
protected:
    int spd;
    int delta;
    int shooterId;
};
class Yelled:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Yelled(Unit *myUnit,int Level,int ID);
    virtual void overlap(Buff *buff);
    virtual ~Yelled(){}
protected:
    int targetId;
};

class Yelling:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Yelling(Unit *myUnit,int Level);
    virtual ~Yelling(){}
};

class Dizzy:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Dizzy(Unit *myUnit,int Level);
    virtual ~Dizzy(){}
};

class Striking:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Striking(Unit *myUnit,int Level);
    virtual ~Striking(){}
};

class Reviving:public Buff
{
public:
    virtual void work();
    virtual void terminate();
    Reviving(Unit *myUnit,int TimeLeft);
    virtual ~Reviving(){}
};

class Slow:public Buff//速度减少当前速度的25%，buff消除后将这部分速度加回
{
public:
    virtual void work();
    virtual void terminate();
    Slow(Unit *myUnit,int Level);
    virtual void overlap(Buff *buff);
    virtual ~Slow(){}
protected:
    int delta;
};
class Cure:public Buff
{
public:
    virtual void oneRoundPass();
    Cure(Unit *myUnit);
    virtual ~Cure(){}
};

int skillReduce(std::string name);

#endif//AI9_2015_BUFFS_H

#ifndef PLAYERINFO_H
#define PLAYERINFO_H
#include "../Base.h"
class ActMaker;
class Area;
class Buff;
struct PCommand;
class Flight;
class Game;
struct Operation;
class Skill;
class Unit;
class UnitArg;
class Map;
class PlayerInfo
{
	public:
        void roundInit(int Round);
        PlayerInfo(Game* Gm,int Camp);
        virtual void addUnit(Unit* unit);
        virtual void addFlight(Flight* flight);
        virtual void addArea(Area* area);
        virtual string toString()const;
        virtual ~PlayerInfo(){}
    public:
        void setPlayer(int Player){player=Player;}
	protected:
		Game* game;
		int round;	
        int camp;
        int player;
		vector<Unit*> units;
		vector<Flight*> flights;
        vector<Area*> areas;
};
#endif//PLAYERINFO_H

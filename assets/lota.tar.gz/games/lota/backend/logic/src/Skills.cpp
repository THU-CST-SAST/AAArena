#include "include/Game/Game.h"
#include "include/Map/Map.h"
#include "include/Skill/Skill.h"
#include "include/Skill/Skills.h"
#include "include/Flight/Flights.h"
#include "include/Unit/Unit.h"
#include "include/Unit/Heroes.h"
#include "include/UnitArg/UnitArg.h"
#include "include/Buff/Buffs.h"
#include "include/PCommand/Operation.h"
#include "include/sdk/const.h"
#define sqr(x) ((x)*(x))
#define STRUCT_ID 15
const int MAX_DES = 200;

const char* genDes(const char* s, int t)
{
    static char des[MAX_DES];
    sprintf(des, s, t);
    return des;
}
const char* genDes(const char* s, int t, int u)
{
    static char des[MAX_DES];
    sprintf(des, s, t, u);
    return des;
}
const char* genDes(const char* s, int t, int u, int v)
{
    static char des[MAX_DES];
    sprintf(des, s, t, u, v);
    return des;
}

Attack::Attack(Unit* myUnit,int MaxCd):
    Skill("Attack",genDes("target ready, Range=%d", Fighter_range),
          myUnit,0,0,MaxCd,1)
{
}
bool Attack::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(unit->getCmd()->targets[0] == unit->getPos())
        return false;
    int range=unit->findArg("Range")->getVal();
    if(unit->getGame()->getRoundProcess()==1)
        return cd==0&&dis2(unit->getCmd()->targets[0],unit->getLastPos())<=range;
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool Attack::trigger()
{
#define injury (max(dmg-def,5))
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            int dmg=unit->findArg("Atk")->getVal();
            int h0=unit->getGame()->getMap()->getHeight(unit->getPos());
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];

                if(ptr->getPos()==unit->getCmd()->targets[0])
                {
                    double percent=1.0;
                    if(h0+1<ptr->getGame()->getMap()->getHeight(unit->getPos())
                            && unit->findArg("Range")->getVal(2)==1)
                        percent=0.5;
                    int def=ptr->findArg("Def")->getVal();
                    ptr->findArg("Hp")->add(0,-percent*injury);
                    ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                }
            }
        }
        return true;
    }
    return false;
}
//==============
YellowPoint::YellowPoint(Unit* myUnit):
    Skill("YellowPoint","1 skill point for 10 maxHp, 2 atk, 2 def",myUnit,0,0,0),
    ahp(YellowPoint_hp_delta),aatk(YellowPoint_atk_delta),adef(YellowPoint_def_delta)
{
}
bool YellowPoint::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool YellowPoint::trigger()
{
    if (canBeUse())
    {
        unit->findArg("Exp")->add(3,-1);
        unit->findArg("Hp")->add(1,ahp);
        unit->findArg("Atk")->add(1,aatk);
        unit->findArg("Def")->add(1,adef);
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
bool YellowPoint::levelUp()
{
    return false;
}
//===============
Recovery::Recovery(Unit* myUnit):
    Skill("Recovery",genDes("be healed near the spring, Range=%d",LifeSpring_range),myUnit,1,1,1000),
    ahp(LifeSpring_hp_recover_delta), amp(LifeSpring_mp_recover_delta), range(LifeSpring_range)
{
}
bool Recovery::canBeUse()
{
    //if (name!=unit->getCmd()->type)
        //return false;//视作被动技能
    return unit->getGame()->getRoundProcess()==1;
}
bool Recovery::trigger()
{
    if (canBeUse())
    {
        for(int i=0;i<unit->getGame()->getUnits().size();++i)
        {
            Unit* ptr=unit->getGame()->getUnits()[i];
            if(dis2(ptr->getLastPos(),unit->getLastPos())<=range
                    && ptr->getCamp()==unit->getCamp() && ptr->getId() != unit->getId())
            {//cout<<ptr->getName()<<'\n';
                UnitArg* arg=ptr->findArg("Hp");
                //cout<<"lallalala\n";//cout<<ptr->getName()<<'\n';
                if(arg==NULL)
                    continue;
                //int delta = min(ahp,arg->getVal(1)-arg->getVal(0));//不必判断上限，Hp::add的重载已判断上限
                arg->add(0, ahp);
                //cout<<ptr->getName()<<'\n';
                arg=ptr->findArg("Mp");
                if(arg==NULL)
                    continue;
                //cout<<ptr->getName()<<'\n';
                //delta = min(amp,arg->getVal(1)-arg->getVal(0));//不必判断上限，Mp::add的重载已判断上限
                arg->add(0, amp);
            }
        }
        return true;
    }
    return false;
}
//===============
Hide::Hide(Unit* myUnit):
    Skill("Hide",genDes("higher speed, higher atk, no one can see you, MP=%d",Hided_mp),myUnit,-1,2,Hided_maxcd),
    mp(Hided_mp)
{
}
bool Hide::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==1
            &&unit->findArg("Mp")->getVal()>=mp&&cd==0;
}
bool Hide::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Mp")->add(0,-mp);
        cd=maxCd;
        unit->addBuff(new Hided(unit,level));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
bool Hide::levelUp()
{
    if (level<maxLevel)
    {
        level++;
        return true;
    }
    return false;
}

string Hide::toString()
{
     return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
HideLU::HideLU(Unit* myUnit):
    Skill("HideLU","No description",myUnit,0,0,0)
{
}
bool HideLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool HideLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("Hide")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//===================
FlyingBlade::FlyingBlade(Unit* myUnit):
    Skill("FlyingBlade",genDes("you cannot escape, Range=%d, MP=%d",FlyingBlade_range,FlyingBlade_mp),
          myUnit,-1,2,FlyingBlade_maxcd,1),
    mp(FlyingBlade_mp),range(FlyingBlade_range)
{
}
bool FlyingBlade::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(dis2(unit->getLastPos(),unit->getCmd()->targets[0])>range)
        return false;
    if( unit->getGame()->getRoundProcess()==1)
    {
        if(unit->findArg("Mp")->getVal()>=mp&&cd==0)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(ptr->getLastPos()==unit->getCmd()->targets[0]
                        &&unit->getCamp()!=ptr->getCamp())
                    return true;
            }
        }
        return false;
    }
    else if(unit->getGame()->getRoundProcess()==2)
        return lastUse==unit->getGame()->getRound();
    return false;
}
bool FlyingBlade::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(ptr->getLastPos()==unit->getCmd()->targets[0]
                        &&unit->getCamp()!=ptr->getCamp())
                {
                    unit->getGame()->addFlight(
                                new FlightBlade(unit->getGame(),unit->getId(),
                                                -1,unit->getCamp(),
                                                unit->getPos(),ptr->getId(),level)
                                );
                    break;
                }
            }
        }
        return true;
    }
    return false;
}
bool FlyingBlade::levelUp()
{
    if (level<maxLevel)
    {
        level++;
        return true;
    }
    return false;
}

string FlyingBlade::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
FBLU::FBLU(Unit* myUnit):
    Skill("FBLU","No description",myUnit,0,0,0)
{
}
bool FBLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool FBLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("FlyingBlade")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//=================
Blink::Blink(Unit* myUnit):
    Skill("Blink",genDes("twinkle, twinkle, Range=%d, MP=%d", Blink_range, Blink_mp[0]),
          myUnit,-1,2,Blink_maxcd[0],1),
    mp(Blink_mp[0]),range(Blink_range)
{
}
bool Blink::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        mp=Blink_mp[level];
        maxCd=Blink_maxcd[level];
        cd=0;
        des=string(genDes("twinkle, twinkle, Range=%d, MP=%d", range, mp));
        return true;
    }
    return false;
}
bool Blink::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    return unit->getGame()->getRoundProcess()==1
            &&unit->findArg("Mp")->getVal()>=mp&&cd==0
            &&dis2(unit->getCmd()->targets[0],unit->getLastPos())<=range;
}
bool Blink::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Mp")->add(0,-mp);
        cd=maxCd;
        unit->changePos(unit->getCmd()->targets[0]);
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}

string Blink::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
BlinkLU::BlinkLU(Unit* myUnit):
    Skill("BlinkLU","No description",myUnit,0,0,0)
{
}
bool BlinkLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool BlinkLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("Blink")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//======================
PiercingArrow::PiercingArrow(Unit* myUnit):
    Skill("PiercingArrow",genDes("let it fly, Range=%d, MP=%d",PiercingArrow_range, PiercingArrow_mp),
          myUnit,-1,2,PiercingArrow_maxcd,1),
    mp(PiercingArrow_mp),range(PiercingArrow_range),dmg(0),wid(PiercingArrow_dis)
{
}
bool PiercingArrow::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=PiercingArrow_damage[level];
        return true;
    }
    return false;
}
bool PiercingArrow::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
        return unit->findArg("Mp")->getVal()>=mp&&cd==0
                &&dis2(unit->getCmd()->targets[0],unit->getLastPos())<=range;
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool PiercingArrow::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(check(unit->getPos(),unit->getCmd()->targets[0],ptr->getPos()))
                    if(ptr->getCamp()!=unit->getCamp())
                    {
                        ptr->findArg("Hp")->add(0,-dmg/skillReduce(ptr->getName()));
                        ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                    }
            }
        }
        return true;
    }
    return false;
}

string PiercingArrow::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
bool PiercingArrow::check(Pos a, Pos b, Pos c)
{
    int S = abs(crossProduct(c, a, b));
    int lab = dis2(a,b);
    int lac = dis2(a,c);
    int lbc = dis2(b,c);
    if (sqrt(lab) * wid <= double(S)) return false;
    if (lac > lab+lbc || lbc > lab+lac) return false;
    return true;
}

PALU::PALU(Unit* myUnit):
    Skill("PALU","No description",myUnit,0,0,0)
{
}
bool PALU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool PALU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("PiercingArrow")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//=====================
ArrowsRain::ArrowsRain(Unit* myUnit):
    Skill("ArrowsRain",genDes("cry in the rain, Range=%d, MP=%d", ArrowsRain_range, ArrowsRain_mp),
          myUnit,-1,2,ArrowsRain_maxcd,1),
    mp(ArrowsRain_mp),range(ArrowsRain_range)
{
}
bool ArrowsRain::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        return true;
    }
    return false;
}
bool ArrowsRain::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
        return unit->findArg("Mp")->getVal()>=mp&&cd==0
                &&dis2(unit->getCmd()->targets[0],unit->getLastPos())<=range;
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool ArrowsRain::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
            unit->getGame()->addFlight(
                        new SignalArrow(unit->getGame(),unit->getId(),
                                        -1,unit->getCamp(),
                                        unit->getPos(),unit->getCmd()->targets[0],level)
                    );
        return true;
    }
    return false;
}

string ArrowsRain::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
ARLU::ARLU(Unit* myUnit):
    Skill("ARLU","No description",myUnit,0,0,0)
{
}
bool ARLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool ARLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("ArrowsRain")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//==================
PowerUp::PowerUp(Unit* myUnit):
    Skill("PowerUp",genDes("infuse with power, MP=%d", PowerUp_mp),myUnit,-1,2,PowerUp_maxcd),
    mp(PowerUp_mp)
{
}
bool PowerUp::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        return true;
    }
    return false;
}
bool PowerUp::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()>0)
        return false;
    return unit->getGame()->getRoundProcess()==1
            &&unit->findArg("Mp")->getVal()>=mp&&cd==0;
}
bool PowerUp::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Mp")->add(0,-mp);
        cd=maxCd;
        unit->addBuff(new Striking(unit,level));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}

string PowerUp::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
PULU::PULU(Unit* myUnit):
    Skill("PULU","No description",myUnit,0,0,0)
{
}
bool PULU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool PULU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("PowerUp")->levelUp())
            unit->findArg("Exp")->add(3,-1);
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
//=======================
Charge::Charge(Unit* myUnit):
    Skill("Charge",genDes("for glory, Range=%d, MP=%d", Charge_range, Charge_mp),
          myUnit,-1,2,Charge_maxcd,1),
    mp(Charge_mp),range(Charge_range),dmg(0)
{
}
bool Charge::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=Charge_damage[level];
        return true;
    }
    return false;
}
bool Charge::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=1)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
    {
        Pos tar = unit->getCmd()->targets[0];
        if (!unit->findArg("Mp")->getVal()>=mp||cd||dis2(tar,unit->getLastPos())>range)
            return false;
		for(int i=0;i<unit->getGame()->getUnits().size();++i)
		{
			Unit* ptr=unit->getGame()->getUnits()[i];
			if(ptr->getLastPos()==unit->getCmd()->targets[0]
				&&unit->getCamp()!=ptr->getCamp()&&ptr->getId()>STRUCT_ID)
					return true;
		}
		return false;
        //Unit* ptr=unit->getGame()->findUnitByPos(tar);
        //return ptr && ptr->getCamp()!=unit->getCamp() && ptr->getId()>STRUCT_ID;
    }
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool Charge::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->changePos(unit->getCmd()->targets[0]);
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(ptr->getPos()==unit->getPos()
                        &&ptr->getCamp()!=unit->getCamp())
                {
                    ptr->addBuff(new Dizzy(unit,level));
                    ptr->findArg("Hp")->add(0,-dmg);
                    ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                }
            }
        }
        return true;
    }
    return false;
}

string Charge::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
ChargeLU::ChargeLU(Unit* myUnit):
    Skill("ChargeLU","No description",myUnit,0,0,0)
{
}
bool ChargeLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool ChargeLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("Charge")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//==========================
Spin::Spin(Unit* myUnit):
    Skill("Spin",genDes("slashing, Range=%d, MP=%d", Spin_range, Spin_mp),
          myUnit,-1,2,Spin_maxcd),
    mp(Spin_mp),range(Spin_range),dmg(0)
{
}
bool Spin::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        dmg=Spin_damage[level];
        return true;
    }
    return false;
}
bool Spin::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
        return unit->findArg("Mp")->getVal()>=mp&&cd==0;
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool Spin::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(dis2(ptr->getPos(),unit->getPos())<=range
                        &&ptr->getCamp()!=unit->getCamp())
                {
                    ptr->findArg("Hp")->add(0,-dmg/skillReduce(ptr->getName()));
                    ptr->findArg("LastHit")->change(unit->getId(),unit->getGame()->getRound());
                }
            }
        }
        return true;
    }
    return false;
}

string Spin::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
SpinLU::SpinLU(Unit* myUnit):
    Skill("SpinLU","No description",myUnit,0,0,0)
{
}
bool SpinLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool SpinLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("Spin")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//========================
Yell::Yell(Unit* myUnit):
    Skill("Yell",genDes("can you kill me, Range=%d, MP=%d", Yell_range, Yell_mp),
          myUnit,-1,2,Yell_maxcd),
    mp(Yell_mp),range(Yell_range)
{
}
bool Yell::levelUp()
{
    if(level<maxLevel)
    {
        ++level;
        return true;
    }
    return false;
}
bool Yell::canBeUse()
{
    if(level<0) return false;
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    if(unit->getGame()->getRoundProcess()==1)
        return unit->findArg("Mp")->getVal()>=mp&&cd==0;
    return unit->getGame()->getRoundProcess()==2
            &&lastUse==unit->getGame()->getRound();
}
bool Yell::trigger()
{
    if(canBeUse())
    {
        if(unit->getGame()->getRoundProcess()==1)
        {
            lastUse=unit->getGame()->getRound();
            unit->addBuff(new Yelling(unit,level));
            unit->findArg("Mp")->add(0,-mp);
            cd=maxCd;
        }
        else if(unit->getGame()->getRoundProcess()==2)
        {
            for(int i=0;i<unit->getGame()->getUnits().size();++i)
            {
                Unit* ptr=unit->getGame()->getUnits()[i];
                if(dis2(ptr->getPos(),unit->getPos())<=range
                        &&ptr->getCamp()!=unit->getCamp())
                    ptr->addBuff(new Yelled(ptr,level,unit->getId()));
            }
        }
        return true;
    }
    return false;
}

string Yell::toString()
{
    return name +ToString(mp)+ "&" + ToString(level) + "&" + ToString(maxLevel) + "&" + ToString(cd) + "&" + ToString(maxCd);
}
YellLU::YellLU(Unit* myUnit):
    Skill("YellLU","No description",myUnit,0,0,0)
{
}
bool YellLU::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    return unit->getGame()->getRoundProcess()==0
            && unit->findArg("Exp")->getVal(3)>0;
}
bool YellLU::trigger()
{
    if(canBeUse())
    {
        if(unit->findSkill("Yell")->levelUp())
        {
            unit->findArg("Exp")->add(3,-1);
            lastUse=unit->getGame()->getRound();
        }
        return true;
    }
    return false;
}
//==============
LevelUp::LevelUp(Unit* myUnit,int Hp,int Atk,int Def):
    Skill("LevelUp","No description",myUnit,0,0,0),
    ahp(Hp),aatk(Atk),adef(Def)
{
}
bool LevelUp::canBeUse()
{
    return unit->getGame()->getRoundProcess()==3
            && unit->findArg("Exp")->getVal(0) >= unit->findArg("Exp")->getVal(1)
            && unit->findArg("Exp")->getVal(2) <= 8;
}
bool LevelUp::trigger()
{
    if(canBeUse())
    {
        unit->findArg("Exp")->add(2,1);
        int lvl=unit->findArg("Exp")->getVal(2);
        unit->findArg("Exp")->add(3,1);
        unit->findArg("Exp")->add(1,HeroArgs::expForLevelUp(lvl));
        unit->findArg("Exp")->change(4,HeroArgs::currentLevel_exp(lvl));
        unit->findArg("Hp")->add(1,ahp);
        unit->findArg("Atk")->add(1,aatk);
        unit->findArg("Def")->add(1,adef);
        return true;
    }
    return false;
}
//============
Dead::Dead(Unit* myUnit,Pos Ps):
    Skill("Dead","No description",myUnit,0,0,0),
    pos(Ps),range(Exp_share_range)
{
}
bool Dead::canBeUse()
{
    return unit->getGame()->getRoundProcess()==3
            && unit->findArg("Hp")->getVal(0)<=0
            && unit->findBuff("Reviving")==NULL;
}
bool Dead::trigger()
{
    if(canBeUse())
    {
        shareExp();
        unit->addBuff(new Reviving(unit,(unit->findArg("Exp")->getVal(2)+1)*5));
        for(int d=0;true;++d)
        {
            Pos tmp(pos.x+d,pos.y);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x-d,pos.y);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x,pos.y+d);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
            tmp=Pos(pos.x,pos.y-d);
            if(check(tmp))
            {
                unit->changePos(tmp);
                break;
            }
        }
        //unit->changePos(pos);
        return true;
    }
    return false;
}
bool Dead::check(Pos tmp)
{
    if(!unit->getGame()->getMap()->tryPosition(tmp,unit->getVolume()))
        return false;
    for(int i=0;i<unit->getGame()->getUnits().size();++i)
    {
        Unit* ptr=unit->getGame()->getUnits()[i];
        if(ptr->getId()==unit->getId())
            continue;
        if(dis2(ptr->getPos(),tmp)<sqr(ptr->getVolume()+unit->getVolume()-1))
            return false;
    }
    return true;
}
void Dead::shareExp()
{
#define killercheck (ptr->getCamp()!=camp \
                && ptr->getCamp()<2 \
                && unit->findArg("LastHit")->getVal(ptr->getId())==round \
                && ptr->getId()>STRUCT_ID)
#define nearbycheck ((dis2(ptr->getLastPos(),unit->getLastPos()))<=range&& \
                ptr->getCamp()!=unit->getCamp() && ptr->getCamp()!=2 && ptr->getId()>STRUCT_ID)

    int delta = unit->findArg("Exp")->getVal(4);
    int camp  = unit->getCamp();
    Game *game= unit->getGame();
    int round = unit->getGame()->getRound();
    int cnt=0;
    for(int i=0;i<game->getUnits().size();++i)
    {
        Unit* ptr=game->getUnits()[i];
        if(killercheck)
            ++cnt;
    }
    if(cnt>0)
        for(int i=0;i<game->getUnits().size();++i)
        {
            Unit* ptr=game->getUnits()[i];
            if(killercheck)
                ptr->findArg("Exp")->add(0,delta/2/cnt);
        }
    cnt=0;
    for(int i=0;i<unit->getGame()->getUnits().size();++i)
    {
        Unit* ptr=unit->getGame()->getUnits()[i];
        if(nearbycheck)
            cnt++;
    }
    if(cnt>0)
        for(int i=0;i<unit->getGame()->getUnits().size();++i)
        {
            Unit* ptr=unit->getGame()->getUnits()[i];
            if(nearbycheck)
                ptr->findArg("Exp")->add(0,delta/2/cnt);
        }
}
//===========
ChooseFighter::ChooseFighter(Unit* myUnit,Pos Ps):
    Skill("ChooseFighter","No description",myUnit,0,0,0),pos(Ps)
{
}

bool ChooseFighter::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseFighter::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Fighter(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
//=========================
ChooseArcher::ChooseArcher(Unit *myUnit, Pos Ps):
    Skill("ChooseArcher","No description",myUnit,0,0,0),pos(Ps)
{
}
bool ChooseArcher::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseArcher::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Archer(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}
//===========================
ChooseAssassin::ChooseAssassin(Unit *myUnit, Pos Ps):
    Skill("ChooseAssassin","No description",myUnit,0,0,0),pos(Ps)
{
}
bool ChooseAssassin::canBeUse()
{
    if(name!=unit->getCmd()->type)
        return false;
    if(unit->getCmd()->targets.size()!=0)
        return false;
    return unit->getGame()->getRoundProcess()==0;
}
bool ChooseAssassin::trigger()
{
    if(canBeUse())
    {
        unit->getGame()->addUnit(new Assassin(unit->getGame(),unit->getCamp(),unit->getPlayer(),-1,pos));
        lastUse=unit->getGame()->getRound();
        return true;
    }
    return false;
}

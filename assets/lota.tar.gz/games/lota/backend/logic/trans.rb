require "json"
require "base64"
f=File.open('replay.zip','rb')
replay=f.read()
f.close()
f=File.open('replayV.txt','rb')
analyse=f.read()
f.close()
f=File.open('result.txt','w')

f.write(JSON.dump ({'winner'=>ARGV[0].to_i,'replay'=>Base64.encode64(replay),'analyse'=>Base64.encode64(analyse)}))
f.close()


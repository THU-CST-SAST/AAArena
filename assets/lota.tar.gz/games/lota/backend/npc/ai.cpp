#include "sdk.h"
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <queue>
using namespace std;
#define FOE (otherUnit->id > 15 && otherUnit->camp < 2)
typedef const PMap CM;
typedef const PPlayerInfo CP;
typedef const PUnit CU;
typedef const PArg CA;
const int ma = 100;
const int nearBy=8;
const int maxDis0=324;
const int maxDis1=144;

// define and typedef

CP* info;
CM* map;
PCommand* cmd;

static Pos poso[ma];
static int ang[ma][ma];
Pos pos[ma];
bool seen[ma];
int c[ma], d[ma];
int rd;
int *angP;
vector<Pos> nu;

void forOurs(void func(CU *ourUnit));
void forOthers(void func(CU *otherUnit));
void forAll(void func(CU *ourUnit, CU *otherUnit));
int signal(int x,int y);
bool comp(int a,int b);

// extern funcs and vars

void player_ai(const PMap &map_, const PPlayerInfo &info_, PCommand &cmd_)
{
    info = &info_;
    map = &map_;
    cmd = &cmd_;
    cmd->cmds.clear();
    nu.clear();
    if (info->round == 0)
    {
        forOurs([](CU* ourUnit){
            poso[ourUnit->id] = ourUnit->pos;
            pos[ourUnit->id] = ourUnit->pos;
        });
        forOthers([](CU* otherUnit){
            for (int i = 0; i < ma; ++i)
            {
                ang[otherUnit->id][i] = 0;
            }
        });
    } else
    {
        memset(seen, false, sizeof seen);
        forOurs([](CU* ourUnit){
            pos[ourUnit->id] = ourUnit->pos;
        });
        forOthers([](CU* otherUnit){
           seen[otherUnit->id] = true;
        });
        forAll([](CU* ourUnit, CU* otherUnit)
        {
            if (dis2(otherUnit->pos,ourUnit->pos) <= nearBy)
                ang[ourUnit->id][otherUnit->id] += 1;
            if (dis2(otherUnit->pos,ourUnit->pos) > maxDis0)
                ang[ourUnit->id][otherUnit->id] = 0;
        });

        forOurs([](CU* ourUnit){
            for(int i=0;i<ourUnit->args.size();++i)
            {
                CA* arg = (*ourUnit)["LastHit"];
                if (arg)
                {
                    for(int j=0; j<ma && j<arg->val.size(); ++j)
                        if (arg->val[j] >= info->round-1)
                            ang[ourUnit->id][j] += 5;
                }
            }
            for (int i = 0; i < ma; ++i)
            {
                if (!seen[i])
                    ang[ourUnit->id][i] = 0;
            }
        });
    }

    forOurs([](CU* ourUnit){
        int id = ourUnit->id;
        bool flag = true, atk = true;
        angP = ang[id];

        CA* arg = (*ourUnit)["OnlyTarget"];
        if (arg)
        {
            int id2 = arg->val[0];
            angP[id] += 1;
            if (id2 != -1)
            {
                CU* otherUnit = info->findUnitById(id2);
                if (otherUnit)
                {
                    Pos ps = otherUnit->pos;
                    if (dis2(ps,pos[id])<=ourUnit->range)
                    {
                        Operation op;
                        op.id = id;
                        angP[id] += 1;
                        op.targets.push_back(ps);
                        cmd->cmds.push_back(op);
                        return;
                    }
                }
                atk = false;
            }
        }

        for (int i = 0; i < ma; ++i)
        {
            c[i] = d[i] = i;
        }
        random_shuffle(d,d+ma);
        sort(c,c+ma,comp);
        for (int i = 0; i < ma; ++i)
        {
            if (angP[c[i]] == 0 || !flag) break;
            CU* otherUnit = info->findUnitById(c[i]);
            if (otherUnit == NULL) continue;
            if (FOE)
            {
                Pos ps = otherUnit->pos;
                if (dis2(ps,pos[id])<=maxDis1 && dis2(ps,poso[id])<=maxDis0)
                {
                    if (dis2(ps,pos[id])<=ourUnit->range && atk)
                    {
                        Operation op;
                        op.id = id;
                        angP[id] += 1;
                        op.type = "Attack";
                        op.targets.push_back(ps);
                        cmd->cmds.push_back(op);
                        flag = false;
                    } else
                    {
                        Operation op;
                        op.id = id;
                        op.type = "Move";
                        findShortestPath(*map, pos[id], ps, nu, op.targets);
                        cmd->cmds.push_back(op);
                        flag = false;
                    }
                }
            }
        }

        if (flag && pos[id] != poso[id])
        {
            Operation op;
            op.id = id;
            op.type = "Move";
            findShortestPath(*map, pos[id], poso[id], nu, op.targets);
            cmd->cmds.push_back(op);
        }
    });
}

int signal(int x,int y)
{
    return x<y?-1:x==y?0:1;
}

bool comp(int a,int b)
{
    return angP[a]>angP[b] || angP[a]==angP[b] && d[a]<d[b];
}

void forOurs(void func(CU *ourUnit))
{
    for (int i=0; i<info->units.size(); ++i)
    {
        CU* ourUnit= &info->units[i];
        if (ourUnit->player == info->player)
        {
            func(ourUnit);
        }
    }
}

void forOthers(void func(CU *otherUnit))
{
    for (int i=0; i<info->units.size(); ++i)
    {
        CU* otherUnit= &info->units[i];
        if (FOE)
        {
            func(otherUnit);
        }
    }
}

void forAll(void func(CU *ourUnit, CU *otherUnit))
{
    for (int i = 0; i < info->units.size(); ++i)
    {
        CU* ourUnit= &info->units[i];
        if (ourUnit->player == info->player)
        {
            for (int j = 0; j < info->units.size(); ++j)
            {
                CU* otherUnit = &info->units[j];
                if (FOE)
                {
                    func(ourUnit, otherUnit);
                }
            }
        }
    }
}


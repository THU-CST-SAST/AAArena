# Neutral camp controller

Recovered from the archived AI9 LOTA source:

`/root/data/sources/recovery-tank/rug/rugraid/srv/ai9-platform/Platform/gameLibrary/games/lota/sampleAi/ai_camp2_ver_l00.cpp`

This is the fixed third participant for neutral monsters in competitive mode 0,
not a competing pool submission. The evaluator builds it and connects it after
the two competing players. Runtime use is entirely within this repository.

Compatibility edits: use `sdk.h` from the compiler include path; replace the
old `PUnit::findArg(name)` calls with this SDK's `PUnit::operator[](name)`.
No competing player sources are modified.

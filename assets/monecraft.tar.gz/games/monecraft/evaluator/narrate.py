"""Translate MoneCraft state records without inventing action fields."""
from pathlib import Path
from aa_arena.replay import Narration, NarrationContext
from aa_arena.replay.public_json import load_ai9_document
from aa_arena.legacy.replay import _selected_rounds, narrate_ai9

SECTIONS = (
    ('ginfo', '资源', (('id','玩家'), ('golds','金币'), ('mine-num','矿数'))),
    ('players', '玩家状态', (('id','玩家'), ('x','x'), ('y','y'), ('blink-cd','闪现冷却'))),
    ('mines', '矿点状态', (('id','矿点'), ('owner','归属'), ('point','point'), ('ptc-round','ptc-round'))),
    ('OB', '观察者状态', (('id','观察者'), ('owner','归属'), ('x','x'), ('y','y'), ('last-time','last-time'))),
)

def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    document = load_ai9_document(Path(replay_path))
    if document.get('format') != 'ai9-monecraft-rounds':
        return narrate_ai9('monecraft', Path(replay_path), context)
    rounds = document.get('rounds', [])
    winner = context.official_winner
    raw = document.get('winner')
    if winner is None and type(raw) is int and 0 <= raw < len(context.role_names()):
        winner = context.role_names()[raw]
    selected = _selected_rounds(rounds)
    lines = [f'# MoneCraft replay：{context.match_id}', '',
             f'- 官方裁决：{winner + " 获胜" if winner is not None else "平局或未记录胜者"}。',
             f'- 你的座位：{context.perspective or "中立视角"}。',
             f'- 回合记录：{len(rounds)}；展示首、中、末 {len(selected)} 条记录。',
             '- 以下为记录中的状态快照；位置和冷却不是提交的动作指令。']
    if context.diagnostic:
        lines.append(f'- 诊断：{context.diagnostic}')
    for frame in selected:
        lines += ['', f'## Round {frame.get("round", "未记录")}']
        state = frame.get('state_changes')
        if not isinstance(state, dict):
            lines.append('- 状态字段缺失。')
            continue
        for key, title, fields in SECTIONS:
            rows = state.get(key)
            if not isinstance(rows, list):
                lines.append(f'- {title}：未记录。')
                continue
            lines.append(f'- {title}：{len(rows)} 条记录。')
            for row in rows[:24]:
                if not isinstance(row, dict):
                    lines.append('  - 无法解读的记录。')
                    continue
                values = [f'{label}={row[field]}' for field,label in fields if field in row and row[field] is not None]
                lines.append('  - ' + ('；'.join(values) if values else '相关字段未记录。'))
            if len(rows) > 24:
                lines.append(f'  - 省略 {len(rows)-24} 条；请查阅 JSON。')
    lines += ['', '## 迭代提示', '',
              '- 先比较关键回合的位置、资源与冷却；不要只看终局。',
              '- 把改动变成与对手 ID、seed、回放 ID 无关的一般规则，再用小对局验证。']
    return Narration(game='monecraft', match_id=context.match_id,
                     text='\n'.join(lines)+'\n', winner=winner,
                     rounds=context.official_rounds if context.official_rounds is not None else len(rounds),
                     highlights={'format':document.get('format'),'round_count':len(rounds),
                                 'rendered_rounds':len(selected)})

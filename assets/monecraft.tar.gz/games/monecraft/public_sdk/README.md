# MoneCraft public AI9 SDK

占领矿点、累积金币，可用瞬移、护盾与地雷改变博弈。

## Files

- `ai.cpp`: editable starter policy.
- `sdk-src/`: public game SDK headers and implementation.
- `include/`: platform headers needed by the public sample.
- `Makefile`: local compile check that produces `player.so`.

Only `ai.cpp` is submitted as strategy; the evaluator rebuilds it against the
complete private game SDK.

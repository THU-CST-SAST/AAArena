#include "sdk.h"
#include <ctime>
#include <iostream>
#include <cmath>
#include <cstring>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fox(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};
const int inf=10000;
Player my_player,op_player;
double wmp,mm,mt,remt,real,haha,mdef,hab;
int n,m,myid,blink_cd,now,wh,bcd,wwh,whe,cnt,oppo,def,la1=-1,la2=-1;
int ditu[31][31];
struct POINT{	int x,y,start,mine_id;}point[1000];
struct LINE{int op,next,type,ori;}q[10000];
struct NN{int point,line,mine;}num;

int cost[1000][50],mcost[1000],gcost[31][31];
int used[10],loc[10];
struct QUEU{int x,y;}queu[10000];
int arrive[1000];
struct PRE{int n,cd,type;}pre[1000][50];
struct QUE{int n,blink;}que[500000];


void inse(int a,int b,int z){  //�ӱ� z��ʾ����
	q[++num.line].op=b;
	q[num.line].ori=a;
	q[num.line].next=point[a].start;
	q[num.line].type=z;
	point[a].start=num.line;

	q[++num.line].op=a;
	q[num.line].ori=b;
	q[num.line].next=point[b].start;
	if (z!=5 && z!=0)
        q[num.line].type=(z % 2==0)?(6-z):(4-z);
    else
        q[num.line].type=z;
	point[b].start=num.line;
}
void build_line(int a,int b){
    if (a==b) inse(a,b,0);
    else
	 if ((abs(point[a].x-point[b].x) + abs(point[a].y-point[b].y))==1) {
     	if (point[b].y==point[a].y+1)
      		inse(a,b,1);
  		if (point[b].y==point[a].y-1)
      		inse(a,b,3);
  		if (point[b].x==point[a].x+1)
      		inse(a,b,4);
  		if (point[b].x==point[a].x-1)
      		inse(a,b,2);
     }else
        if (abs(point[a].x-point[b].x)<=2 && abs(point[a].y-point[b].y)<=2){
            inse(a,b,5);
        }
}

void update(){ //Ϊ�µ�ӱ�
    build_line(num.point,num.point);
	fo(i,1,num.point-1){
    	build_line(i,num.point);
     }
}

void check_map(Map& map){//���µ�ͼ
    fo(i,0,n) fo(j,0,m){
	    if (ditu[i][j]==0){  //0Ϊ���ɼ� -1Ϊǽ  ����Ϊ���
			if (map.grids[ i ][ j ].terrain == MapGrid::BLOCK) {
                    ditu[i][j]=-1;
                    ditu[n-i][m-j]=-1;
			}
			if (map.grids[ i ][ j ].terrain == MapGrid::FLAT) {
       			ditu[i][j]=++num.point;
       			point[num.point].x=i;
       			point[num.point].y=j;
       			point[num.point].mine_id=-1;
       			update();
       			if (map.grids[ i ][ j ].mine_id!=-1){
              		point[num.point].mine_id=map.grids[ i ][ j ].mine_id;
                }
                if (ditu[n-i][m-j]==0){
                    ditu[n-i][m-j]=++num.point;
                    point[num.point].x=n-i;
                    point[num.point].y=m-j;
                    point[num.point].mine_id=-1;
                    update();
                    if (map.grids[ n-i ][ m-j ].mine_id!=-1){
                        point[num.point].mine_id=map.grids[ n-i ][ m-j ].mine_id;
                    }
                }

       		}
		}
 	}
}

void mak_arrive(int n){
    int st=1,en=1,y;
	que[st].n=n;
	fo(i,0,num.point)
        arrive[i]=0;
	arrive[n]=1;
	do{
	    n=que[st].n;
	    for (int k=point[n].start;k;k=q[k].next){
	        y=q[k].op;
  			if (!arrive[y]){
                arrive[y]=1;
         		que[++en].n=y;
          	}
    	}
    	st++;
     }while (st<=en);
}

void bfs(int n,int cd){  //bfsѰ·
	int st=1,en=1,cos=0,bl,y;
	que[st].n=n;que[st].blink=cd;
	fo(i,0,num.point) fo(j,0,30)
        cost[i][j]=cost[i][j]=inf,pre[i][j].n=pre[i][j].type=pre[i][j].cd=0;
	cost[n][cd]=0;
	do{
	    n=que[st].n;
	    cos=cost[n][que[st].blink]+1;
	    bl=max(que[st].blink-1,0);
	    for (int k=point[n].start;k;k=q[k].next){
	        y=q[k].op;
  			if (q[k].type!=5){
                if (cos>=cost[y][bl]) continue;
         		cost[y][bl]=cos;
         		pre[y][bl].n=n;                      //���ĸ�״̬ת�ƹ���
         		pre[y][bl].type=q[k].type;
         		pre[y][bl].cd=que[st].blink;
         		que[++en].n=y;
         		que[en].blink=bl;
          	}
  			else {
                if (cos>=cost[y][blink_cd]) continue;
 		 		if (que[st].blink!=0) continue;
 		 		cost[y][blink_cd]=cos;
 		 		pre[y][blink_cd].n=n;
 		 		pre[y][blink_cd].type=q[k].type;
 		 		pre[y][blink_cd].cd=0;
         		que[++en].n=y;
         		que[en].blink=blink_cd;
			}
    	}
    	st++;
     }while (st<=en);
     mcost[0]=inf;
     fo(i,1,num.point) {
         mcost[i]=inf;
         fo(j,0,30)
            if (cost[i][j]<mcost[i])
                mcost[i]=cost[i][j];
     }
    //  cout<<"bfs done"<<endl;
}

void init(Map& map, GameInfo& ginfo, RoundInfo& rinfo){
    n=MAP_WIDTH-1;
    m=MAP_HEIGHT-1;
    num.mine=rinfo.mines.size()-1;
    oppo=0;
    static Position last(-1,-1);


    for (int i = 0; i < rinfo.players.size(); ++i){
        if (rinfo.players[i].owner == rinfo.player_id){
            my_player = rinfo.players[i];
        }
        if (rinfo.players[i].owner != rinfo.player_id){
            op_player = rinfo.players[i];
            oppo=1;
        }
    }
    myid=rinfo.player_id;
    if (myid==0) myid=-1;
    blink_cd=5+3*ginfo.mine_num[rinfo.player_id];
      //�ҵ�λ�õı��
    check_map(map);
    now=ditu[my_player.pos.x][my_player.pos.y];       //�Ե�ͼ�пɼ�����б�źͽ�ͼ
    mak_arrive(now);


    //memset(cost,0,sizeof(cost));
    //memset(mcost,0,sizeof(mcost));
    //memset(gcost,0,sizeof(gcost));
    //memset(inn,0,sizeof(inn));
    memset(queu,0,sizeof(queu));
    //memset(arrive,0,sizeof(arrive));
    memset(pre,0,sizeof(pre));
    memset(que,0,sizeof(que));
}

void check_bestmine( RoundInfo& rinfo){
    mm=inf-1;
    wh=0;
    bcd=0;
    fo(i,0,num.mine){
        if (ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]==now){
            if (rinfo.mines[i].own_point*myid>=4) continue;
        }else
            if (rinfo.mines[i].owner==rinfo.player_id) continue;
        if (oppo && (op_player.pos.x==point[i].x)
            && (op_player.pos.y==point[i].y) && (rinfo.mines[point[i].mine_id].owner==1-rinfo.player_id)) continue;
        if (rinfo.mines[i].protect_round>mcost[ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]]+3) continue;
        fo(j,0,30){
            int nimei=ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y];
            int coo=cost[nimei][j];
            if (rinfo.mines[i].owner==1-rinfo.player_id) coo=coo*0.78;
            if ((coo<mm)||(coo==mm && j<bcd)){
                mm=cost[nimei][j],
                wh=nimei,bcd=j;
            }
        }
    }
}
int goo(int xx,int yy, RoundInfo& rinfo){ //����̽·�㵽���Ĳ���
    fo(i,0,30) fo(j,0,30){
        gcost[i][j]=inf;
    }

    int st=1,en=1;
    gcost[xx][yy]=0;
    queu[1].x=xx;
    queu[1].y=yy;
    haha=0;
    real=inf;
    cnt=0;
    int x,y;
    do{
        fo(i,0,num.mine){
            if (ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]==now){
                if (rinfo.mines[i].own_point*myid>=4) continue;
            }else
                if (rinfo.mines[i].owner==rinfo.player_id) continue;
            if (rinfo.mines[i].pos.x==queu[st].x && rinfo.mines[i].pos.y==queu[st].y){
                if (rinfo.mines[i].protect_round>gcost[queu[st].x][queu[st].y]+5) continue;
                double coo=gcost[queu[st].x][queu[st].y];
                if (rinfo.mines[i].owner==1-rinfo.player_id) coo=coo*0.9;
                if (coo<real) real=coo;
                if (coo<15) {
                        cnt++;
                        haha+=coo;
                }
            }
        }
        fo(j,0,3){
            x=queu[st].x+dx[j];
            y=queu[st].y+dy[j];
            if (x<0 || y<0 || x>n || y>m) continue;
            if ((ditu[x][y]>=0)&& gcost[x][y]>gcost[queu[st].x][queu[st].y]+1) {
                gcost[x][y]=gcost[queu[st].x][queu[st].y]+1;
                en++;
                queu[en].x=x;
                queu[en].y=y;
            }
        }
        st++;
    }while (st<=en);
    return real;
}
void check_bestunseen( RoundInfo& rinfo){
    mt=inf;
    wwh=0;
    wmp=inf;
    hab=inf;
    int tanx=-1,tany=-1;
    fo(i,0,n) fo(j,0,m){
        if (ditu[i][j]!=0) continue;
        int x,y,op=0;
        fo(k,0,3){
            x=i+dx[k];
            y=j+dy[k];
            if (x<0 || y<0 || x>n || y>m) continue;
            if (ditu[x][y]>0 && arrive[ditu[x][y]]) {
                    op=1;
                    if (mcost[ditu[x][y]]<wmp) wmp=mcost[ditu[x][y]];
            }
        }
        if (!op) continue;
        wmp=wmp+goo(i,j,rinfo);
        //cout<<wmp<<' ';
        if (wmp<mt || ((cnt>1) && (haha<hab)) ){
            mt=wmp,tanx=i,tany=j,hab=haha;
        }
    }
    wwh=0;
    fo(i,1,num.point){
        if (!arrive[i]) continue;
        if (point[i].x!=tanx && point[i].y!=tany) continue;
        int noo=0;

        if (point[i].x==tanx){
            fo(j,point[i].y+1,tany-1){
                if (ditu[tanx][j]<=0) {
                    noo=1;break;
                }
            }
            fo(j,tany+1,point[i].y-1){
                if (ditu[tanx][j]<=0) {
                    noo=1;break;
                }
            }
        }
        if (point[i].y==tany){
            fo(j,point[i].x+1,tanx-1){
                if (ditu[j][tany]<=0) {
                    noo=1;break;
                }
            }
            fo(j,tanx+1,point[i].x-1){
                if (ditu[j][tany]<=0) {
                    noo=1;break;
                }
            }
        }
        if (noo) continue;
        if (mcost[i]<mcost[wwh]) wwh=i;
    }
}
void let_go(int whe,int bcd,Action& act){
    if (whe==now || whe==0){
        act.move = (Action::Move)(0);
    }else{

        int move=0,la;
        do{
            la=whe;
            move=pre[whe][bcd].type;
            int tb=bcd;
            bcd=pre[whe][bcd].cd;
            whe=pre[whe][tb].n;
        }while (whe!=now);

        if (move==5){
            act.move = (Action::Move)(5);
            act.blink_pos.x=point[la].x;
            act.blink_pos.y=point[la].y;
        }
        else
            act.move = (Action::Move)(move);
    }
}
/*
void don(int x){
    if (x==cnt+1){
        int tmp=0;
        fo(i,cnt,1){
            tmp+=()
        }
        return;
    }
    fo(i,1,cnt){
        if (!used[i]){
            used[i]=1;
            loc[x]=ned[i];
            don(x+1);
            used[i]=0;
        }
    }
}
void check(){
    cnt=0;
    fo(i,0,num.mine){
        if (ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]==now){
            if (rinfo.mines[i].own_point*myid>=4) continue;
        }else
            if (rinfo.mines[i].owner==rinfo.player_id) continue;
        if (rinfo.mines[i].protect_round>mcost[i]+3) continue;
        ned[++cnt]=i;
    }
    mm=inf;
    don(1);
}
*/
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
    act.buy_protect=0;
    init(map,ginfo,rinfo);
    bfs(now,my_player.blink_cd);
    check_bestmine(rinfo);
    check_bestunseen(rinfo);
    if (point[now].mine_id!=-1){
        if (now!=la2){
            if (now==la1) act.buy_protect=1;
            la1=la2;
            la2=now;
        }
        if (oppo && (abs(my_player.pos.x-op_player.pos.x)+abs(my_player.pos.y-op_player.pos.y))<15){act.buy_protect=1;}
        if (rinfo.mines[point[now].mine_id].own_point*myid>=4)
            if (abs(point[now].x-15)+abs(point[now].y-15)<=10) act.buy_protect=1;
        if (oppo && my_player.pos==op_player.pos && rinfo.mines[point[now].mine_id].owner!=1-rinfo.player_id)
                {act.move = (Action::Move)(0);return;}
    }
    whe=wh;
    if ((!wh || mt*2<mm ||mt<7)&& !(now==wh) && !(mt>mm-5)){
        whe=wwh;
        bcd=0;
        //cout<<arrive[15]<<endl;
        fo(j,0,30) {if (cost[whe][j]<cost[whe][bcd]) bcd=j;}
        //cout<<endl;
        //cout<<"bcd:"<<bcd<<endl;
    }
    cnt=0;
    mdef=inf;
    def=-1;
    fo(i,0,num.mine){
        if (ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]==now){
            if (rinfo.mines[i].own_point*myid>=4) continue;
        }
        if (rinfo.mines[i].owner==rinfo.player_id) {
                if (rinfo.mines[i].protect_round==0){
                    if (mcost[ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]]<mdef){
                        mdef=mcost[ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]];
                        def=i;
                    }
                }
                continue;
        }
        if (rinfo.mines[i].protect_round>mcost[ditu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]]) continue;
        cnt++;
    }
    if (cnt==0 && def!=-1){
        whe=ditu[rinfo.mines[def].pos.x][rinfo.mines[def].pos.y];
        bcd=0;
        fo(j,0,30) {if (cost[whe][j]<cost[whe][bcd]) bcd=j;}
        let_go(whe,bcd,act);
        return;
    }
    let_go(whe,bcd,act);
    act.setOB=0;
  //  act.buy_protect=0;
}


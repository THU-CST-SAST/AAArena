#include "sdk.h"
#include <ctime>
#include <fstream>
using namespace std;
int lu[31][31],o[1000][3],first,last,pat[31][31],road[31][31];
//Position pmine;
//int ro=0;
//Position la;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
  for(int i=0;i<31;i++)
     for(int j=0;j<31;j++)
         {
           lu[i][j]=0;
           road[i][j]=-1;
         }
  for(int i=0;i<1000;i++)
     for(int j=0;j<=2;j++)
        o[i][j]=0;
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  first=0;
  last=1;
  o[0][0]=my_player.pos.x;
  o[0][1]=my_player.pos.y;
  pat[my_player.pos.x][my_player.pos.y]=1;
  road[my_player.pos.x][my_player.pos.y]=1; 
  int next = -1;
  int nSize = rinfo.mines.size();
  for(int i=0;i<nSize;i++)
     {
          lu[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y]=rinfo.mines[i].owner;
     }
  int ID=map.grids[my_player.pos.x][my_player.pos.y].mine_id;
  /*if(map.grids[ my_player.pos.x ][ my_player.pos.y ].mine_id!=-1 )  
     for(int i=0;i<nSize;i++)
       if(rinfo.mines[i].id==ID && rinfo.mines[i].owner!=rinfo.player_id)
          next=-2;*/
  if(lu[my_player.pos.x][my_player.pos.y]==-1) next=-2;
  for(int i=0;i<4;i++)
  {
          int nx,ny;
          nx=my_player.pos.x+dx[i];
          ny=my_player.pos.y+dy[i];
          if(map.grids[ nx ][ ny ].terrain == MapGrid::FLAT || pat[nx][ny]==1 )
          {
                        pat[nx][ny]=1;
                        o[last][0]=nx;
                        o[last][1]=ny;
                        o[last][2]=i;
                        road[nx][ny]=1;
                        last++;
          }
  }
  first++;
  if(next=-1)
  {
             while(lu[o[first][0]][o[first][1]]!=-1 && first<last)
             {
                  for(int i=0;i<4;i++)
                     {
                          int nx,ny;
                          nx=o[first][0]+dx[i];
                          ny=o[first][1]+dy[i];
                          if(nx>=0 && nx<=30 && ny>=0 && ny<=30)  
                            if((map.grids[ nx ][ ny ].terrain == MapGrid::FLAT || pat[nx][ny]==1 || map.grids[ nx ][ ny ].terrain == MapGrid::UNSEEN) && road[nx][ny]!=1)
                            {
                                    pat[nx][ny]=1;
                                    o[last][0]=nx;
                                    o[last][1]=ny;
                                    o[last][2]=o[first][2];
                                    road[nx][ny]=1;
                                    last++;    
                            }
                     }
                     first++; 
             }
             if(first<last) next=o[first][2];
  }
  /*int mx=my_player.pos.x,my=my_player.pos.y;
  if(next==-1)
  {
              pmine.x=1000;
              pmine.y=1000;
              for(int i=0;i<31;i++)
                 for(int j=0;j<=31;j++)
                     if(lu[i][j]==-1)
                       if((i-mx)*(i-mx)+(j-my)*(j-my)<(pmine.x-mx)*(pmine.x-mx)+(pmine.y-my)*(pmine.y-my))
                          {
                               pmine.x=i;
                               pmine.y=j;
                          }
              for(int i=0;i<4;i++)
                 {
                      int nx,ny;
                      nx=mx+dx[i];
                      ny=my+dy[i];
                      if(map.grids[ nx ][ ny ].terrain == MapGrid::FLAT || pat[nx][ny]==1)
                      if((nx-pmine.x)*(nx-pmine.x)+(ny-pmine.y)*(ny-pmine.y)<(pmine.x-mx)*(pmine.x-mx)+(pmine.y-my)*(pmine.y-my))
                         {
                           next=i;
                           break;
                         }
                 }
  }
  Position next_pos;
  if(next==-1)
  for (int i = 0; i < 4; ++i)
  {
    next_pos.x = my_player.pos.x + dx[i];
	next_pos.y = my_player.pos.y + dy[i];
	if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == la))
	{
      next = i;
	  break;
	}
  }*/
  if(next==-2) act.move=Action::Stop;
  else act.move=(Action::Move)(next+1);
  //la=my_player.pos;
}


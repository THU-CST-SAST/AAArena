#include "sdk.h"
#include <ctime>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
    act.move = (Action::Up);
}


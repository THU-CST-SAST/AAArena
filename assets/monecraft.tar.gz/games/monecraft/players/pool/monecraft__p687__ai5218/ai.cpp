#include "sdk.h"
#include <ctime>
#include <fstream>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
static FILE *fptr = fopen("debug.log", "w");

fprintf(fptr, "ROUND %d\n%d\n", rinfo.round, act.move);

fprintf(fptr, "BLINK: %d %d\n", act.blink_pos.x, act.blink_pos.y);
  //ofstream fout("debug.txt");
  //fout << "test!" << endl;
  //cout << "test  ~!" << endl;
  //cout << "test mark!" << endl;
  static Position last(-1,-1);
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  //cout << "test mark 1!" << endl;
  Position next_pos;
  int next = -1;
  for(int i=0;i<rinfo.mines.size();i++)
  {
      if(rinfo.mines[i].pos==my_player.pos)
      {
          if(rinfo.mines[i].owner !=my_player.owner)
          {
              act.move=Action::Stop;
              return;
          }else break;
      }
  }            
  for (int i = 0; i < 4; ++i)
  {
    next_pos.x = my_player.pos.x + dx[i];
	next_pos.y = my_player.pos.y + dy[i];
	if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
	{
      next = i;
	  break;
	}
  }
  if (next >= 0)
  {
    //cout << dx[next] << ' ' << dy[next] << endl;
    act.move = (Action::Move)(next+1);
  }
  else
    act.move = (Action::Move)(time(0) % 5);
  last = my_player.pos;
  //cout << "test end!" << endl;
}


#include "sdk.h"
#include <ctime>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
  static Position last(-1,-1);
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  Position next_pos;
  int next = -1;
  for (int i = 0; i < 4; ++i)
  {
        next_pos.x = my_player.pos.x + dx[i];
	next_pos.y = my_player.pos.y + dy[i];
	if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
	{
          next = i;
	  break;
	}
   if (map.grids[ next_pos.x ][ next_pos.y ].mine_id!=-1) {next=-1;break;} 
      

  }
 if (next!=-1) 
  {if (next >= 0)
  {
    //cout << dx[next] << ' ' << dy[next] << endl;
    act.move = (Action::Move)(next+1);
  }
  else
    act.move = (Action::Move)(time(0) % 5);
  last = my_player.pos;

}
}


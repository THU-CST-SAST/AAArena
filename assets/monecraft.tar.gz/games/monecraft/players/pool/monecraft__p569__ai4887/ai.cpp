#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<queue>
#include"sdk.h"

using namespace std;

const int Inf = 1000000000;
const int dx[5] = { 0 , 0 , -1 , 0 , 1 };
const int dy[5] = { 0 , 1 , 0 , -1 , 0 };
	
bool vis[MAP_WIDTH][MAP_HEIGHT];
queue< pair< Position , int > > Q;

bool legal( Position &A ) {
	return 0 <= A.x && A.x < MAP_WIDTH && 0 <= A.y && A.y < MAP_HEIGHT;
}

int search( Map &map , Position &S , Position &T ) {
	while ( !Q.empty() ) Q.pop();
	memset( vis , false , sizeof( vis ) );
	Q.push( make_pair( S , 0 ) );
	
	while ( !Q.empty() ) {
		Position now = Q.front().first;
		int step = Q.front().second;
		Q.pop();
		
		if ( now == T ) return step;
		vis[now.x][now.y] = true;
		
		for ( int d = 1 ; d <= 4 ; d++ ) {
			Position next( now.x + dx[d] , now.y + dy[d] );
			if ( legal( next ) && map.grids[next.x][next.y].terrain == MapGrid::FLAT && !vis[next.x][next.y] )
				Q.push( make_pair( next , step + 1 ) );
		}
	}
	
	return -1;
}

void player_ai( Map &map , GameInfo &ginfo , RoundInfo &rinfo , Action &act ) {
	Player my_player;
	for ( int i = 0 ; i < ( int ) rinfo.players.size() ; i++ )
		if ( rinfo.players[i].owner == rinfo.player_id ) {
			my_player = rinfo.players[i];
			break;
		}
	
	int mind_id = -1 , dis = Inf;
	for ( int i = 0 ; i < ( int ) rinfo.mines.size() ; i++ ) {
		if ( rinfo.mines[i].owner == rinfo.player_id ) continue;
		int cnt = search( map , my_player.pos , rinfo.mines[i].pos );
		if ( cnt < dis ) {
			dis = cnt;
			mind_id = i;
		}
	}
	
	if ( dis == 0 ) {
		act.move = ( Action::Move ) ( 0 );
		return;
	}
	for ( int d = 1 ; d <= 4 ; d++ ) {
		Position next( my_player.pos.x + dx[d] , my_player.pos.y + dy[d] );
		if ( legal( next ) && map.grids[next.x][next.y].terrain == MapGrid::FLAT && search( map , next , rinfo.mines[mind_id].pos ) == dis - 1 ) {
			act.move = ( Action::Move ) ( d );
			return;
		}
	}
}

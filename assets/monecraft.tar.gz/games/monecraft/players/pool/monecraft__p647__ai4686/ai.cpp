#include "sdk.h"
#include <ctime>
#include <cmath>
#include <iostream>
using namespace std;
int square[32][32]={0};
int stepuse[32][32]={0};
int stepnum=0;
const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};
Position dpath(-1,-1);
//�����ݹ� 
void makepath(Position k, Position m, Map& map) 
{
	square[k.x][k.y]=1;
	if(k == m){}//�߽����� 
	else
	for(int i = 0; i <4; i++)//������ѭ���ˣ��� 
	{
		dpath.x = k.x + dx[i];
		dpath.y = k.y + dy[i];
		if (square[dpath.x][dpath.y] == 1)continue; 
		if (map.grids[ dpath.x ][ dpath.y ].terrain == MapGrid::FLAT )
		{
			makepath(dpath,m,map);
		}
	}	
}
int step(Position k, Position m, Map& map, int i)
{
	stepuse[k.x][k.y]=i+1;
	if (k == m)return 1;
	for(int i = 0; i <4; i++)
	{
		dpath.x = k.x + dx[i];
		dpath.y = k.y + dy[i];
		if (stepuse[dpath.x][dpath.y] == i+1)continue; 
		if (map.grids[ dpath.x ][ dpath.y ].terrain == MapGrid::FLAT )
		{
			return step(dpath,m,map,i)+1;
		}
	}
	return 1;	
}
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	act.setOB=0;
	act.buy_protect=0;
	//static Position last(-1,-1);
  	
  	Player my_player;Player enemy_player;
  	//��ɫ����ȷ�� 
  	for (int i = 0; i < rinfo.players.size(); ++i)
  	{
		if (rinfo.players[i].owner == rinfo.player_id)
		{
	  		my_player = rinfo.players[i];
		}
		else enemy_player = rinfo.players[i];
  	}
	//����������ʼ����δ�裬����flag == 1��
	int minlength = 2000;
	
	if (ginfo.mine_num[ rinfo.player_id ] == rinfo.mines.size())//��rinfo.player_id��
	{
		act.move = (Action::Move)(0);
	} 
	//��δ�� 
	static int  bestid = -1, easyid = -1, flag = 0;
	int id = map.grids[ my_player.pos.x ][ my_player.pos.y ].mine_id;
	if ( id != -1 && rinfo.mines[id].owner != rinfo.player_id)
	{
		act.move = (Action::Move)(0);flag = 0;
	}
	else{
		int length,mineid,lengthx,lengthy;
		if(flag == 0)
		{
			int a,b=100;
			for (int i = 0; i < rinfo.mines.size(); ++i)
			{
				if ( (rinfo.mines[i].owner == rinfo.player_id) && 
				   ( abs(rinfo.mines[i].own_point) == 5) )
				continue;//�Ȱ�����򵥷��� 			
				makepath (rinfo.mines[i].pos, my_player.pos, map);
				a = step (rinfo.mines[i].pos, my_player.pos, map,i);
				if (a<b)
				{
					b=a;easyid = i;
				}
				stepnum = 0;flag = 1;
			}
		}
		for (int i = 0; i < rinfo.mines.size(); ++i)
		{
			//�ڸ÷����У�����ֻ������ֱ����˸�� ���� 
			mineid = rinfo.mines[i].id;
			lengthx = my_player.pos.x - rinfo.mines[i].pos.x;
			lengthy = my_player.pos.y - rinfo.mines[i].pos.y;
			length  = lengthx*lengthx + lengthy*lengthy;
			if(length < minlength)
			{
				minlength = length;
				bestid = mineid;
			} 
		}
	//�����������ƶ����ʼ 
  	//Position next_pos;ʡ��ȥ 
  	int next = -1;
  	if ( sqrt (minlength) < 2.9 && my_player.blink_cd == 0 ) //�˴��д� 
  	{
  		act.blink_pos.x = rinfo.mines[bestid].pos.x;
  		act.blink_pos.y = rinfo.mines[bestid].pos.y;
  		//last = rinfo.mines[bestid].pos;flag=0;
  		act.move = (Action::Move)(5);
  	}
  	if (next == -1)
  	{
		for(int i = 0; i <4; i++)//һ��Ҫע�⣬�����ǵ��Ĺ�ʱ�������֮������ж�����·����ʱ�Ͳ���ÿ�غ�ѡ·�ˣ�Ҫ��ǰ�滮�� 
		{
			dpath.x = my_player.pos.x + dx[i];
			dpath.y = my_player.pos.y + dy[i];
			if (stepuse[ dpath.x ][ dpath.y ] == (i+1) )
			{
				act.move = (Action::Move)(i+1);
				break;
			}
		}	
  	}
  }
}
  	//����Ұ���ɼ�ʱ������������� 
  	/*else
	{
		int k1, k2, k3, k4;
		for (int i = 0; i < 4; ++i)
  		{
    		next_pos.x = my_player.pos.x + dx[i];
			next_pos.y = my_player.pos.y + dy[i];
			if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
			{
      			k1 = rinfo.mines[bestid].pos.x - next_pos.x;
      			k2 = rinfo.mines[bestid].pos.y - next_pos.y;
      			k3 = rinfo.mines[bestid].pos.x - my_player.pos.x;
				k4 = rinfo.mines[bestid].pos.y - my_player.pos.y;
				if ( ( k1*k1 <= k3*k3 ) && ( k2*k2 <= k4*k4 ) )
				{
					next=i;flag=0;
	  				break;
	  			}
			}
  		}
  		if (next == -1 && flag == 0 )
  		for (int i = 0; i < 4; ++i)
  		{
    		next_pos.x = my_player.pos.x + dx[i];
			next_pos.y = my_player.pos.y + dy[i];
			if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
			{
      			k1 = rinfo.mines[bestid].pos.x - next_pos.x;
      			k2 = rinfo.mines[bestid].pos.y - next_pos.y;
      			k3 = rinfo.mines[bestid].pos.x - my_player.pos.x;
				k4 = rinfo.mines[bestid].pos.y - my_player.pos.y;
				if ( ( k1*k1 <= k3*k3 ) || ( k2*k2 <= k4*k4 ) )
				{
					next=i;flag++;
	  				break;
	  			}
			}
  		}
  		if (next == -1)
  		{
			if ( my_player.blink_cd == 0 )//���費�����.png����� 
			{
				int lengthx, lengthy, length = minlength, lengthnew;
				for(int i = -2; i <= 2; i++)
				{
					for(int j = -2; j<= 2; j++)
					{
						if ( i != 2 && i != -2 && j != 2 && j != -2 )
						continue;
						next_pos.x = my_player.pos.x + j;
						next_pos.y = my_player.pos.y + i;
						if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
						{
      						lengthx = rinfo.mines[bestid].pos.x - next_pos.x ;
      						lengthy = rinfo.mines[bestid].pos.y - next_pos.y ;
      						lengthnew = lengthx*lengthx + lengthy*lengthy;
							if ( lengthnew <length )
							{
								next=4;
								length = lengthnew;
								act.blink_pos.x = next_pos.x;
								act.blink_pos.y = next_pos.y;
	  						}
						}
					}
				} 
			}
			//else 
		} 
    	//cout << my_player.pos.x << ' ' << my_player.pos.y << endl;//��bat����� 
    	act.move = (Action::Move)(next+1);
  		last = my_player.pos;
  	}}
}*/
//�ɵ�ȡ������
/*map.grids[][].pos.x
	map.grids[][].pos.y
map.grids[][].terrain// == MapGrid::FLAT//==0???������
map.grids[][].mine_id
map.grids[][].players//������
ginfo.rounds
ginfo.mine_num[ rinfo.player_id ];         //˫��ռ����Ŀ
	ginfo.mine_num[ rinfo.enemy_id ]; 
ginfo.golds[ rinfo.player_id ]; 
	ginfo.golds[ rinfo.enemy_id ];
rinfo.round
rinfo.player_id
rinfo.observers
	rinfo.observers.id
	rinfo.observers.pos
	rinfo.observers.last_time
	rinfo.observers.owner
rinfo.players
	rinfo.players.pos
	rinfo.players.owner//�� rinfo.player_id��ȣ�
	rinfo.players.blink_cd 	
rinfo.mines
	rinfo.mines.id
	rinfo.mines.pos
	rinfo.mines.owner
	rinfo.mines.owner_point
	rinfo.mines.protect_round
	rinfo.mines.gain_rate=10
act.move
act.blink_pos
rinfo.setOB=0
rinfo.buy_protect=0*/

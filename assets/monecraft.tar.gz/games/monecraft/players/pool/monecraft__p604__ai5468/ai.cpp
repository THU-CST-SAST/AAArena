#include "sdk.h"
#include <ctime>
#include <map>
using namespace std;

bool operator<(Position a, Position b)
{
	if (a.x != b.x)
		return a.x < b.x;
	return a.y < b.y;
}

namespace mission_solve
{
	Map a;
	Position player;
	const Position d[4] = {Position(0, 1), Position(-1, 0), Position(0, -1), Position(1, 0)};

	void get_target(Position tar, Action &act)
	{
		map<Position, int> s;
		//cout << tar.x << " " << tar.y << endl;
		s.clear();
		Position queue[1000];
		int h = 0, t = 1;
		queue[0] = player;
		s[player] = -1;
		while (h < t)
		{
			Position cur = queue[h++];
			for (int i = 0; i < 4; ++i)
			{
				Position tmp = Position(cur.x + d[i].x, cur.y + d[i].y);
				if (tmp.x < 0 || tmp.x > 30 || tmp.y < 0 || tmp.y > 30)
					continue;
				if (a.grids[tmp.x][tmp.y].terrain == MapGrid::FLAT && s.find(tmp) == s.end())
				{
					queue[t++] = tmp;
					if (h == 1)
						s[tmp] = i;
					else
						s[tmp] = s[cur];
				}
			}
		}
		act.move = (Action::Move)(s[tar] + 1);
	}

};

void player_ai(Map& map0, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	//cout << "start" << endl;
	for (int i = 0; i < rinfo.players.size(); ++i)
		if (rinfo.players[i].owner == rinfo.player_id)
			mission_solve::player = rinfo.players[i].pos;
	mission_solve::a = map0;
	Position pos(-1, -1);
	for (int i = 0; i < rinfo.mines.size(); ++i)
		if (rinfo.mines[i].owner == -1)
		{
			pos = rinfo.mines[i].pos;
			break;
		}
	if (pos.x == -1)
		act.move = Action::Stop;
	else
		mission_solve::get_target(pos, act);
}
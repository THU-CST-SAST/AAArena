#include "sdk.h"
#include <ctime>
#include <algorithm>
#include <queue>
#include <cmath>
#include <iostream>
#include <cstdio>
//oparound notgiveup
using namespace std;

const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};
const int bx[] = {0,-1,-2,-2,-2,-2,-2,-1,0,1,2,2,2,2,2,1,1,-1,-1,1};
const int by[] = {2,2,2,1,0,-1,-2,-2,-2,-2,-2,-1,0,1,2,2,1,1,-1,-1};
Map map;
GameInfo ginfo;
RoundInfo rinfo;
Action act;
MapGrid mapinfo[31][31];
Player me, op;
int mymine, opmine, mygold, opgold;
Mine mineinfo[6];
int dis[31][31][24];
int h[31][31][24];
int dis_op[31][31][24];
int from[31][31][24][3];
int ntry[31][31];
int lastblink, lastblinkx, lastblinky;
int lastprotect;
static int et = -1;
static int tracing = 0;
int race = 1;

struct Point
{
	Position pos;
	int blink_cd;
};
queue<Point> q;

void update_mapinfo()
{
	for (int i = 0; i < 31; i++)
		for (int j = 0; j < 31; j++)
			if (map.grids[i][j].terrain != MapGrid::UNSEEN)
			{
				mapinfo[i][j].terrain = map.grids[i][j].terrain;
				mapinfo[i][j].mine_id = map.grids[i][j].mine_id;
			}
}

void symmetrization()
{
	for (int i = 0; i < 31 ; i++)
		for (int j = 0; j < 31; j++)
		{
			if (mapinfo[30 - i][30 - j].terrain == MapGrid::UNSEEN)
				mapinfo[30 - i][30 - j].terrain = mapinfo[i][j].terrain;
			if (ntry[30 - i][30 - j] == 0)
				ntry[30 - i][30 - j] = ntry[i][j];
		}
}

bool legal(int xx, int yy)
{
	return (xx < 31 && xx >= 0 &&
			yy < 31 && yy >= 0 &&
			mapinfo[xx][yy].terrain != MapGrid::BLOCK);
}

void spfa()
{
	while (!q.empty())
		q.pop();
	for (int i = 0; i < 31; i++)
		for (int j = 0; j < 31; j++)
		{
			for (int k = 0; k < 24; k++)
			{
				h[i][j][k] = 0;
				dis[i][j][k] = -1;
				from[i][j][k][0] = from[i][j][k][1] = -1;
			}
		}
	dis[me.pos.x][me.pos.y][me.blink_cd] = 0;
	from[me.pos.x][me.pos.y][me.blink_cd][0] = me.pos.x;
	from[me.pos.x][me.pos.y][me.blink_cd][1] = me.pos.y;
	from[me.pos.x][me.pos.y][me.blink_cd][2] = me.blink_cd;
	
	Point now, next;
	
	now.pos = me.pos;
	now.blink_cd = me.blink_cd;
	q.push(now);

	while (!q.empty())
	{
		now = q.front();
		q.pop();
		h[now.pos.x][now.pos.y][now.blink_cd] = 0;
		if (now.blink_cd == 0)
		{
			next.blink_cd = 5 + 3 * mymine;
			for (int j = 0; j < 20; j++)
			{
				next.pos.x = now.pos.x + bx[j];
				next.pos.y = now.pos.y + by[j];
				if (legal(next.pos.x, next.pos.y))
				{
					if (mapinfo[next.pos.x][next.pos.y].terrain == MapGrid::UNSEEN)
						continue;
					if (dis[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis[next.pos.x][next.pos.y][next.blink_cd] > dis[now.pos.x][now.pos.y][now.blink_cd] + 1)
					{
						dis[next.pos.x][next.pos.y][next.blink_cd] = dis[now.pos.x][now.pos.y][now.blink_cd] + 1;
						from[next.pos.x][next.pos.y][next.blink_cd][0] = now.pos.x;
						from[next.pos.x][next.pos.y][next.blink_cd][1] = now.pos.y;
						from[next.pos.x][next.pos.y][next.blink_cd][2] = now.blink_cd;
						if (!h[next.pos.x][next.pos.y][next.blink_cd] && mapinfo[next.pos.x][next.pos.y].terrain != MapGrid::UNSEEN)
							q.push(next);
						h[next.pos.x][next.pos.y][next.blink_cd] = 1;
					}
				}
			}
		}
		for (int i = 0; i < 4; i++)
		{
			next.blink_cd = now.blink_cd>0?(now.blink_cd-1):0;
			next.pos.x = now.pos.x + dx[i];
			next.pos.y = now.pos.y + dy[i];
			if (legal(next.pos.x, next.pos.y) && (dis[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis[next.pos.x][next.pos.y][next.blink_cd] > dis[now.pos.x][now.pos.y][now.blink_cd] + 1))
			{
				dis[next.pos.x][next.pos.y][next.blink_cd] = dis[now.pos.x][now.pos.y][now.blink_cd] + 1;
				from[next.pos.x][next.pos.y][next.blink_cd][0] = now.pos.x;
				from[next.pos.x][next.pos.y][next.blink_cd][1] = now.pos.y;
				from[next.pos.x][next.pos.y][next.blink_cd][2] = now.blink_cd;
				if (!h[next.pos.x][next.pos.y][next.blink_cd] && mapinfo[next.pos.x][next.pos.y].terrain != MapGrid::UNSEEN)
					q.push(next);
				h[next.pos.x][next.pos.y][next.blink_cd] = 1;
			}
		}
		next.blink_cd = now.blink_cd>0?(now.blink_cd-1):0;
		next.pos.x = now.pos.x;
		next.pos.y = now.pos.y;
		if (dis[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis[next.pos.x][next.pos.y][next.blink_cd] > dis[now.pos.x][now.pos.y][now.blink_cd] + 1)
		{
			dis[next.pos.x][next.pos.y][next.blink_cd] = dis[now.pos.x][now.pos.y][now.blink_cd] + 1;
			from[next.pos.x][next.pos.y][next.blink_cd][0] = now.pos.x;
			from[next.pos.x][next.pos.y][next.blink_cd][1] = now.pos.y;
			from[next.pos.x][next.pos.y][next.blink_cd][2] = now.blink_cd;
			if (!h[next.pos.x][next.pos.y][next.blink_cd])
				q.push(next);
			h[next.pos.x][next.pos.y][next.blink_cd] = 1;
		}
	}
}

void spfa_op()
{
	while (!q.empty())
		q.pop();
	for (int i = 0; i < 31; i++)
		for (int j = 0; j < 31; j++)
		{
			for (int k = 0; k < 24; k++)
			{
				h[i][j][k] = 0;
				dis_op[i][j][k] = -1;
			}
		}
	dis_op[op.pos.x][op.pos.y][op.blink_cd] = 0;
	
	Point now, next;
	
	now.pos = op.pos;
	now.blink_cd = op.blink_cd;
	q.push(now);

	while (!q.empty())
	{
		now = q.front();
		q.pop();
		h[now.pos.x][now.pos.y][now.blink_cd] = 0;
		if (now.blink_cd == 0)
		{
			next.blink_cd = 5 + 3 * mymine;
			for (int j = 0; j < 20; j++)
			{
				next.pos.x = now.pos.x + bx[j];
				next.pos.y = now.pos.y + by[j];
				if (legal(next.pos.x, next.pos.y))
				{
					if (mapinfo[next.pos.x][next.pos.y].terrain == MapGrid::UNSEEN)
						continue;
					if (dis_op[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis_op[next.pos.x][next.pos.y][next.blink_cd] > dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1)
					{
						dis_op[next.pos.x][next.pos.y][next.blink_cd] = dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1;
						if (!h[next.pos.x][next.pos.y][next.blink_cd] && mapinfo[next.pos.x][next.pos.y].terrain != MapGrid::UNSEEN)
							q.push(next);
						h[next.pos.x][next.pos.y][next.blink_cd] = 1;
					}
				}
			}
		}
		for (int i = 0; i < 4; i++)
		{
			next.blink_cd = now.blink_cd>0?(now.blink_cd-1):0;
			next.pos.x = now.pos.x + dx[i];
			next.pos.y = now.pos.y + dy[i];
			if (legal(next.pos.x, next.pos.y) && (dis_op[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis_op[next.pos.x][next.pos.y][next.blink_cd] > dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1))
			{
				dis_op[next.pos.x][next.pos.y][next.blink_cd] = dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1;
				if (!h[next.pos.x][next.pos.y][next.blink_cd] && mapinfo[next.pos.x][next.pos.y].terrain != MapGrid::UNSEEN)
					q.push(next);
				h[next.pos.x][next.pos.y][next.blink_cd] = 1;
			}
		}
		next.blink_cd = now.blink_cd>0?(now.blink_cd-1):0;
		next.pos.x = now.pos.x;
		next.pos.y = now.pos.y;
		if (dis_op[next.pos.x][next.pos.y][next.blink_cd] == -1 || dis_op[next.pos.x][next.pos.y][next.blink_cd] > dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1)
		{
			dis_op[next.pos.x][next.pos.y][next.blink_cd] = dis_op[now.pos.x][now.pos.y][now.blink_cd] + 1;
			if (!h[next.pos.x][next.pos.y][next.blink_cd])
				q.push(next);
			h[next.pos.x][next.pos.y][next.blink_cd] = 1;
		}
	}
}

double line_dis(Position xx, Position yy)
{
	return sqrt((xx.x - yy.x) * (xx.x - yy.x) + (xx.y - yy.y) * (xx.y - yy.y));
}

int man_dis(Position xx, Position yy)
{
	return abs(xx.x - yy.x) + abs(xx.y - yy.y);
}

bool cango(int x, int y)
{
	if (!legal(x, y))
		return false;
	if (mapinfo[x][y].terrain != MapGrid::UNSEEN)
		return false;
	Position t(x, y);
	if (me.pos == t)
		return false;
	int ret = 0;
	for (int i = 0; i < 24; i++)
		if (dis[x][y][i] != -1)
			ret = 1;
	return ret;
}

bool cannotreach(int tar)
{
	int ret = 1;
	for (int i = 0; i < 24; i++)
		if (dis[mineinfo[tar].pos.x][mineinfo[tar].pos.y][i] != -1)
			ret = 0;
	return ret;
}

int mindis(Position t)
{
	int ret = 10000;
	for (int i = 0; i < 24; i++)
		if (dis[t.x][t.y][i] != -1 && dis[t.x][t.y][i] < ret)
			ret = dis[t.x][t.y][i];
	return ret;
}

bool minecmp(Mine xx, Mine yy)
{
	//return line_dis(xx.pos, me.pos) < line_dis(yy.pos, me.pos);
	return man_dis(xx.pos, me.pos) < man_dis(yy.pos, me.pos);
	/*
	int dxx = man_dis(xx.pos, me.pos) * 3 / 2;
	int dyy = man_dis(xx.pos, me.pos) * 3 / 2;
	if (mindis(xx.pos) < 1000)
		dxx = mindis(xx.pos);
	if (mindis(yy.pos) < 1000)
		dyy = mindis(yy.pos);
	return dxx < dyy;
	*/
}

bool cantry(int x, int y)
{
	if (!(legal(x, y) && mapinfo[x][y].terrain == MapGrid::UNSEEN && !ntry[x][y]))
		return false;
	int ml = 31, mr = -1;
	for (int i = 0; i < 6; i++)
		if (!cannotreach(i))
		{
			if (mineinfo[i].pos.x < ml)
				ml = mineinfo[i].pos.x;
			if (mineinfo[i].pos.x > mr)
				mr = mineinfo[i].pos.x;
		}
	if (x >= mr || x <= ml)
		return true;
	return false;
}

int tryblink(int tar)
{
	int delx = mineinfo[tar].pos.x - me.pos.x;
	int dely = mineinfo[tar].pos.y - me.pos.y;
	if (abs(delx) <= 1)
		return 0;
	int bb = 0;
	if (delx < 0)
	{
		if (dely > 0)
			bb = 1;
		else if (dely < 0)
			bb = 5;
	}
	else if (delx > 0)
	{
		if (dely < 0)
			bb = 9;
		else if (dely > 0)
			bb = 13;
	}
	if (bb > 0)
	{
		int tb[3] = {1, 0, 2};
		for (int i = 0; i < 3; i++)
			if (cantry(me.pos.x + bx[tb[i] + bb], me.pos.y + by[tb[i] + bb]))
			{
				act.blink_pos.x = me.pos.x + bx[tb[i] + bb];
				act.blink_pos.y = me.pos.y + by[tb[i] + bb];
				lastblink = 1;
				lastblinkx = act.blink_pos.x;
				lastblinky = act.blink_pos.y;
				return 5;
			}
	}
	return 0;
}

void update_ntry()
{
	for (int i = lastblinkx - 2; i <= lastblinkx + 2; i++)
		for (int j = lastblinky - 2; j <= lastblinky + 2; j++)
			if (legal(i, j))
				ntry[i][j] = 1;
}

bool at_nearest_my_mine(int tar)
{
	int nd = 10000;
	for (int i = 0; i < 6; i++)
		if (i != tar)
		{
			if (man_dis(mineinfo[tar].pos, mineinfo[i].pos) < nd)
				nd = man_dis(mineinfo[tar].pos, mineinfo[i].pos);
		}
	if (man_dis(me.pos, mineinfo[tar].pos) <= nd)
		return 1;
	return 0;
}

bool needprotect()
{
	Position nearest_op_mine(-1, -1);
	for (int i = 0; i < 6; i++)
		if (mineinfo[i].owner == 1 - me.owner)
		{
			nearest_op_mine = mineinfo[i].pos;
			break;
		}
	if (nearest_op_mine.x == -1)
	{
		nearest_op_mine.x = 30 - me.pos.x;
		nearest_op_mine.y = 30 - me.pos.y;
	}
	int nm = 0;
	for (int i = 0; i < 6; i++)
		if (man_dis(mineinfo[i].pos, me.pos) <= 10)
			nm++;
	if (nm > 1 && (mindis(nearest_op_mine) <= 80 || (mindis(nearest_op_mine) >=100 && man_dis(me.pos, nearest_op_mine) <= 30)))
		return 1;
	
	Position cp(15, 15);
	for (int i = 0; i < 6; i++)
	{
		if (abs(mineinfo[i].pos.x - 15) <= 10)
			return 1;
		if (line_dis(mineinfo[i].pos, cp) <= 15)
			return 1;
	}

	if (op.pos.x < 0)
		return false;
	if (man_dis(op.pos, me.pos) <= 4)
		return true;
	int warning = 0;
	for (int i = 0; i < 6; i++)
		if (mineinfo[i].owner != op.owner && 
			man_dis(op.pos, mineinfo[i].pos) <= 6 &&
			at_nearest_my_mine(i))
		{
			warning = 1;
			break;
		}
	if (warning)
		return 1;
	
	
	
	return 0;
}

bool guarded(int tar)
{
	if (mineinfo[tar].owner != op.owner)
		return false;
	if (op.pos.x < 0)
		return false;
	if (man_dis(op.pos, mineinfo[tar].pos) <= 2)
	{
		if (me.pos == mineinfo[tar].pos && mineinfo[tar].own_point <= man_dis(op.pos, mineinfo[tar].pos))
			return false;
		return true;
	}
	return false;
}

bool opcap(int tar)
{
	if (op.pos.x < 0)
		return false;
	if (man_dis(op.pos, mineinfo[tar].pos) <= 2)
	{
		if (me.pos == mineinfo[tar].pos && mineinfo[tar].own_point <= man_dis(op.pos, mineinfo[tar].pos))
			return false;
		return true;
	}
	return false;
}

bool capture()
{
	int id = mapinfo[me.pos.x][me.pos.y].mine_id;
	if (id == -1)
		return false;
	int i;
	for (i = 0; i < 6; i++)
		if (mineinfo[i].id == id)
			break;
	if (mineinfo[i].owner == me.owner && (mymine > opmine || (mymine == opmine && mygold >= opgold)) && me.pos == op.pos)
		return true;
	
	int tar = 0;
	for (tar = 0; tar < 6; tar++)
	{
		if (!(mineinfo[tar].pos == me.pos) && mineinfo[tar].owner != me.owner && mineinfo[tar].protect_round <= man_dis(mineinfo[tar].pos, me.pos) && !guarded(tar))
			break;
	}
	if (lastprotect)
		return true;
	if (mineinfo[i].owner == me.owner || (mineinfo[i].protect_round && tar < 6))
		return false;
	if (mineinfo[i].owner == 1 - me.owner)
	{
		if (guarded(i))
			return false;
		return true;
	}
	if (abs(mineinfo[i].own_point) < 4)
		return true;
	if (abs(mineinfo[i].own_point) == 4 && me.pos == op.pos)
		return true;
	return false;
}

bool no_deadlock()
{
	if (me.pos == op.pos)
		return false;
	return true;
}

bool no_shield()
{
	if (rinfo.mines[mapinfo[me.pos.x][me.pos.y].mine_id].protect_round)
		return false;
	return true;
}

void set_center(Position &center, Position &t)
{
	center.x = 0;
	center.y = 0;
	int s = 0;
	for (int i = 0; i < 6; i++)
		if (mineinfo[i].owner != me.owner && (int)(line_dis(t, mineinfo[i].pos)) <= 8)
		{
			s++;
			center.x += mineinfo[i].pos.x;
			center.y += mineinfo[i].pos.y;
		}
	center.x /= s;
	center.y /= s;
}

int mindis_op(Position t)
{
	int ret = 10000;
	for (int i = 0; i < 24; i++)
		if (dis_op[t.x][t.y][i] != -1 && dis_op[t.x][t.y][i] < ret)
			ret = dis_op[t.x][t.y][i];
	return ret;
}

int get_op_target()
{
	int ret = -1;
	int md = 10000;
	spfa_op();
	for (int i = 0; i < 6; i++)
	{
		if (mineinfo[i].owner == me.owner)
			if (mindis_op(mineinfo[i].pos) < md)
			{
				md = mindis_op(mineinfo[i].pos);
				ret = i;
			}
	}
	return ret;
}

int areamines(int tar)
{
	int ret = 0;
	for (int i = 0; i < 6; i++)
		if (line_dis(mineinfo[i].pos, mineinfo[tar].pos) < 4)
			ret++;
	return ret;
}

int decide_action()
{
	spfa();
	sort(mineinfo, mineinfo + 6, minecmp);
	
	int ob = 0;
	for (int i = 0; i < rinfo.observers.size(); i++)
		if (rinfo.observers[i].owner == me.owner)
			ob++;
	if (ob == 0)
	{
		for (int i = 0; i < 6; i++)
			if (abs(mineinfo[i].pos.x - me.pos.x) <= 1 &&
				abs(mineinfo[i].pos.y - me.pos.y) <= 1)
			{
				ob = 1;
				break;
			}
		if (!ob)
			act.setOB = true;
	}
	
	if (lastblink)
	{
		if (me.blink_cd == 0)
		{
			mapinfo[lastblinkx][lastblinky].terrain = MapGrid::BLOCK;
			update_ntry();
			symmetrization();
		}
		lastblink = 0;
	}
	
	if (!race)
	{
		if (et > -1 && me.pos == mineinfo[et].pos && !mineinfo[et].protect_round)
			act.buy_protect = 1;
		if (mapinfo[me.pos.x][me.pos.y].mine_id != -1 && needprotect() && no_shield())
			act.buy_protect = 1;
	}
	
	if (capture())
		return 0;
	
	int tar = 0, tar2 = 6, tar3;;
	Position target(-1, -1), tmp, center;
	
	for (tar = 0; tar < 6; tar++)
	{
		{
			if (!(mineinfo[tar].pos == me.pos) && (mineinfo[tar].owner != me.owner || mineinfo[tar].pos == op.pos) && mineinfo[tar].protect_round <= man_dis(mineinfo[tar].pos, me.pos) && !guarded(tar))
				break;
		}
	}
	
	if (tar == 6)
	{
		for (tar = 0; tar < 6; tar++)
		{
			{
				if (!(mineinfo[tar].pos == me.pos) && (mineinfo[tar].owner == me.owner) && mineinfo[tar].protect_round <= man_dis(mineinfo[tar].pos, me.pos))
					break;
			}
		}
	}
	
	if (tar == 6)
	{
		for (tar = 0; tar < 6; tar++)
		{
			{
				if (!(mineinfo[tar].pos == me.pos) && (mineinfo[tar].owner != me.owner || mineinfo[tar].pos == op.pos) && !guarded(tar))
					break;
			}
		}
	}
	
	for (tar2 = tar + 1; tar2 < 6; tar2++)
	{
		{
			if (!(mineinfo[tar2].pos == me.pos) && (mineinfo[tar2].owner != me.owner || mineinfo[tar2].pos == op.pos) && mineinfo[tar2].protect_round <= man_dis(mineinfo[tar2].pos, me.pos) && !guarded(tar2))
				break;
		}
	}
	
	if (tar2 > 5)
	{
		for (tar2 = tar + 1; tar2 < 6; tar2++)
		{
			{
				if (!(mineinfo[tar2].pos == me.pos) && (mineinfo[tar2].owner != me.owner || mineinfo[tar2].pos == op.pos) && !guarded(tar2))
					break;
			}
		}
	}
	
	for (tar3 = 0; tar3 < 6; tar3++)
		if (!(mineinfo[tar3].pos == me.pos) && (mineinfo[tar3].owner == me.owner) && !opcap(tar3) && !mineinfo[tar3].protect_round)
			break;
	
	if (tar == 6)
		tar = rand() % 6;
/*
	if (me.blink_cd == 0 && cannotreach(tar))
	{
		int bins = tryblink(tar);
		if (bins == 5)
			return bins;
	}
*/	
	//set_center(center, mineinfo[tar].pos);
	
	Position cp(15, 15);
	if (tar2 < 6)
	{
		if (areamines(tar2) > areamines(tar) && abs(man_dis(me.pos, mineinfo[tar].pos) - man_dis(me.pos, mineinfo[tar2].pos)) <= 7)
			tar = tar2;
		/*
		else if	(mineinfo[tar].owner != 1 - me.owner)
		{
			if (man_dis(me.pos, mineinfo[tar2].pos) +
				man_dis(mineinfo[tar].pos, mineinfo[tar2].pos) +
				man_dis(mineinfo[tar].pos, cp) <=
				man_dis(me.pos, mineinfo[tar].pos) +
				man_dis(mineinfo[tar].pos, mineinfo[tar2].pos) +
				man_dis(mineinfo[tar2].pos, cp) &&
				abs(man_dis(me.pos, mineinfo[tar].pos) - man_dis(me.pos, mineinfo[tar2].pos)) <= 5)
				tar = tar2;
		}*/
	}

	if (tar3 < 6 && mineinfo[tar].owner == 1 - me.owner)
	{
		if (mindis(mineinfo[tar3].pos) <= mindis(mineinfo[tar].pos) + 5)
			tar = tar3;
	}
	
	center = mineinfo[tar].pos;
	
	double mdis = 100000, tdis;
	for (int i = 0; i < 31; i++)
		for (int j = 0; j < 31; j++)
		{
			tmp.x = i;
			tmp.y = j;
			if (cango(i, j))
			{
				if ((tmp.x - me.pos.x) * (mineinfo[tar].pos.x - me.pos.x) >= 0)
				{
					tdis = man_dis(center, tmp) + mindis(tmp);
					if (mdis > tdis)
					{
						mdis = tdis;
						target = tmp;
					}
				}
			}
		}
	
	if (target.x == -1)
	{
		mdis = 100000;
		for (int i = 0; i < 31; i++)
			for (int j = 0; j < 31; j++)
			{
				tmp.x = i;
				tmp.y = j;
				if (cango(i, j))
				{
					tdis = man_dis(mineinfo[tar].pos, tmp) + mindis(tmp);
					if (mdis > tdis)
					{
						mdis = tdis;
						target = tmp;
					}
				}
			}
	}
	
	if (mindis(mineinfo[tar].pos) < 1000)
		target = mineinfo[tar].pos;
	
	if (et > -1)
	{
		if (mineinfo[et].owner == 1 - me.owner)
			et = -1;
		else if (mineinfo[et].protect_round)
			et = -1;
	}
	if (op.pos.x != -1)
		et = get_op_target();
	if (et > -1)
	{
		if (mindis(mineinfo[et].pos) + 5 <= mindis_op(mineinfo[et].pos) && !mineinfo[et].protect_round && man_dis(me.pos, op.pos) <= 10)
			if (man_dis(me.pos, mineinfo[et].pos) <= man_dis(me.pos, target) + 5)
				target = mineinfo[et].pos;
	}
	/*
	if ((mymine > opmine || (mymine == opmine && mygold > opgold)))
	{
		if (op.pos.x > -1)
		{
			if (me.pos == op.pos)
			{
				tracing = 1;
				return 0;
			}
			else if (man_dis(me.pos, op.pos) == 1)
			{
				target = op.pos;
				tracing = 1;
			}
		}
		else if (tracing)
		{
			if (et > -1)
				target = mineinfo[et].pos;
			else
				tracing = 0;
		}
	}
	else
		tracing = 0;
	*/
	Point t;
	int mincd = 10000, mindis = 10000;
	for (int i = 0; i < 24; i++)
		if (dis[target.x][target.y][i] != -1)
		{
			if (dis[target.x][target.y][i] < mindis)
			{
				mincd = i;
				mindis = dis[target.x][target.y][i];
			}
		}
	t.pos = target;
	t.blink_cd = mincd;
	
	int tx, ty, tcd;
	while (from[t.pos.x][t.pos.y][t.blink_cd][0] != me.pos.x ||
			from[t.pos.x][t.pos.y][t.blink_cd][1] != me.pos.y)
	{
		tx = from[t.pos.x][t.pos.y][t.blink_cd][0];
		ty = from[t.pos.x][t.pos.y][t.blink_cd][1];
		tcd = from[t.pos.x][t.pos.y][t.blink_cd][2];
		t.pos.x = tx;
		t.pos.y = ty;
		t.blink_cd = tcd;
	}
	
	tx = t.pos.x - me.pos.x;
	ty = t.pos.y - me.pos.y;
	int ins;
	for (ins = 0; ins < 4; ins++)
	{
		if (tx == dx[ins] && ty == dy[ins])
			break;
	}
	if (ins < 4)
	{
		return ins + 1;
	}
	else
	{
		act.blink_pos = t.pos;
		lastblink = 1;
		lastblinkx = t.pos.x;
		lastblinky = t.pos.y;
		
		return 5;
	}
	
}

void player_ai(Map& pmap, GameInfo& pginfo, RoundInfo& prinfo, Action& pact)
{
	map = pmap, ginfo = pginfo, rinfo = prinfo, act = pact;
	if (rinfo.round == 0)
	{
		for (int i = 0; i < 31; i++)
			for (int j = 0; j < 31; j++)
			{
				mapinfo[i][j].terrain = map.grids[i][j].terrain;
				mapinfo[i][j].mine_id = map.grids[i][j].mine_id;
				mapinfo[i][j].pos = map.grids[i][j].pos;
			}
	}
	act.setOB = 0;
	act.buy_protect = 0;
	op.pos.x = -1;
	for (int i = 0; i < rinfo.players.size(); ++i)
	{
		if (rinfo.players[i].owner == rinfo.player_id)
			me = rinfo.players[i];
		else
			op = rinfo.players[i];
	}
	update_mapinfo();
	symmetrization();
	
	mymine = opmine = 0;
	for (int i = 0; i < rinfo.mines.size(); i++)
	{
		mineinfo[i].id = rinfo.mines[i].id;
		mineinfo[i].pos = rinfo.mines[i].pos;
		mineinfo[i].owner = rinfo.mines[i].owner;
		mineinfo[i].own_point = rinfo.mines[i].own_point;
		mineinfo[i].protect_round = rinfo.mines[i].protect_round;
		mineinfo[i].gain_rate = rinfo.mines[i].gain_rate;
		if (mineinfo[i].owner == me.owner)
			mymine++;
		if (mineinfo[i].owner == 1 - me.owner)
			opmine++;
	}
	mygold = ginfo.golds[rinfo.player_id];
	opgold = ginfo.golds[1 - rinfo.player_id];
	
	int leftmines = 0;
	for (int i = 0; i < 6; i++)
		if (mineinfo[i].pos.x < 8)
			leftmines++;
	if (leftmines > 2)
		race = 1;
	else
		race = 0;
	
	act.move = (Action::Move)(decide_action());
	pact = act;
}

#include "sdk.h"
#include <ctime>
#include <fstream>
using namespace std;

const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};

int d[31][31];
int from[31][31][2];

void dfs(int x, int y, Map& map)
{
	for (int i = 0; i < 4; i++)
	{
		if (((x + dx[i]) <= 30) && ((y + dy[i]) <= 30) && ((x + dx[i]) >= 0) && ((y + dy[i]) >= 0))
		{
			if (map.grids[x + dx[i]][y + dy[i]].terrain == 0)
			{
				if ((d[x + dx[i]][y + dy[i]] == -1) || ((d[x][y] + 1) < d[x + dx[i]][y + dy[i]]))
				{
					d[x + dx[i]][y + dy[i]] = d[x][y] + 1;
					from[x + dx[i]][y + dy[i]][0] = x;
					from[x + dx[i]][y + dy[i]][1] = y;
					dfs((x + dx[i]), (y + dy[i]), map);
				}
			}
		}
	}
}

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
  static Position last(-1,-1);

  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  if (((map.grids[my_player.pos.x][my_player.pos.y].mine_id) != (-1)) && (rinfo.mines[map.grids[my_player.pos.x][my_player.pos.y].mine_id].owner != my_player.owner))
  {
  	act.move = (Action::Move)(0);
  	return;
  }
  for (int i = 0; i < 31; i++)
  	for (int j = 0; j < 31; j++)
  		d[i][j] = -1;
  d[my_player.pos.x][my_player.pos.y] = 0;
  dfs(my_player.pos.x, my_player.pos.y, map);
  int mindis = 10000, tar;
  for (int i = 0; i < rinfo.mines.size(); i++)
  {
  	if (rinfo.mines[i].owner != my_player.owner && d[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y] < mindis)
  	{
  		mindis = d[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y];
  		tar = i;
  	}
  }
  int tx = rinfo.mines[tar].pos.x, ty = rinfo.mines[tar].pos.y;
	while ((from[tx][ty][0] != my_player.pos.x) || (from[tx][ty][1] != my_player.pos.y))
	{
		int t = from[tx][ty][1];
		tx = from[tx][ty][0];
		ty = t;
	}
  for (int i = 0; i < 4; i++)
  {
	if (((tx - my_player.pos.x) == dx[i]) && ((ty - my_player.pos.y) == dy[i]))
		act.move = (Action::Move)(i + 1);
}  
}



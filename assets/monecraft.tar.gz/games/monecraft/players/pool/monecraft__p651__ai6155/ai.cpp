#include "sdk.h"
#include <ctime>
#include <cstring>
using namespace std;
struct mytype
{
	int last;
	int next;
	Position pos_my;
	int direct;
	//int visit;
}act_move[1000];
int judge[100][100];

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{	
	
	const int dx[] = {0,-1,0,1};
	const int dy[] = {1,0,-1,0};
	Player my_player;
	for (int i = 0; i < rinfo.players.size(); ++i)
	{
		if (rinfo.players[i].owner == rinfo.player_id)
		{
	  		my_player = rinfo.players[i];
	  		break;
		}
	}
	
	for (int i=0 ; i<rinfo.mines.size() ; ++i)
	{
		if (my_player.pos == rinfo.mines[i].pos)
		{
			if (rinfo.mines[i].owner != my_player.owner)
			{
				act.move = (Action::Stop);
				return;
			}
		}
	}
	
	/*if(map.grids[my_player.pos.x][my_player.pos.y].mine_id!=-1){
		act.move=Action::Stop;
		return;
	}*/
	
	static int head=0;
	static int tail=0;
	
	if( tail == head )
	{
		memset ( judge , 0 ,sizeof(judge) );
		tail=0;
		head=0;
		act_move[0].last = -1;
		act_move[0].pos_my.x = my_player.pos.x;
		act_move[0].pos_my.y = my_player.pos.y;
	
		judge[my_player.pos.x][my_player.pos.y] = 1;
		
		int flag = 0;
		int m=0;
		while ( (flag==0) && (m<10000) )
		{
			for (int k=0 ; k<4 ; ++k)
			{
				int x1 = act_move[m].pos_my.x + dx[k];
				int y1 = act_move[m].pos_my.y + dy[k];
				if ( map.grids[x1][y1].terrain == MapGrid::FLAT && x1>=0 && x1< MAP_WIDTH && y1>=0 && y1 < MAP_HEIGHT )
				{
					if (judge[x1][y1]!=1)
					{
						tail++;
						act_move[tail].pos_my.x = x1;
						act_move[tail].pos_my.y = y1;
						act_move[tail].direct = k;
						act_move[tail].last = m;
						judge[x1][y1] = 1;
						for (int i=0 ; i<rinfo.mines.size() ; ++i)
						{
							if (act_move[tail].pos_my == rinfo.mines[i].pos 
								&& rinfo.mines[i].owner != my_player.owner )
								{
									flag=1;
									break;
								}
						}
					}
				}
				if (flag==1)
				{
					break;
				}
			}
			m++;
		}
		int sq=tail;
		while (act_move[sq].last != -1)
		{
			act_move[ act_move[sq].last ].next = sq;
			sq = act_move[sq].last;
		}
	}
	head = act_move[head].next;
	act.move = (Action::Move)(act_move[head].direct+1);
	
}



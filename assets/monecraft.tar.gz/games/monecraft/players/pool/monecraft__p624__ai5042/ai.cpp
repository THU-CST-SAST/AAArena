#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <fstream>

#include <cstdio>
#include <cstring>

#include "sdk.h"

#ifdef DEBUG
FILE *ptr = fopen("debug.log", "w");
#endif

const int SIZE = MAP_WIDTH * MAP_HEIGHT;
const int dx[] = {0, -1, 0, 1, 0};
const int dy[] = {1, 0, -1, 0, 0};
const int MAX_CD = 1 + BLINK_CD_INIT + BLINK_RATE * 3;
int pre = 7, COUNT;

enum __Terrain {
	_UNKNOWN = 0, 
	_FLAT, 
	_BLOCK, 
	_UNSEEN, 
	_MINE
} terr[MAP_WIDTH][MAP_HEIGHT];

inline bool valid(int kx, int ky) {
	if (kx < 0 || kx >= MAP_WIDTH || ky < 0 || ky >= MAP_HEIGHT || terr[kx][ky] == _BLOCK) return false;
	return true;
}

inline int get_sssp_no(int no, int x, int y) {
	return no * 5 * 5 + (x + 2) * 5 + y + 2;
}

bool operator < (Position a, Position b) {
	return a.x < b.x && a.y < b.y;
}

struct Data {
	Action _act;
	RoundInfo _rinfo;
	GameInfo _ginfo;
	Map _map;

	int __dist[5 * 5 * 2][MAX_CD][MAP_WIDTH][MAP_HEIGHT];
	int dist[5 * 5 * 2][MAP_WIDTH][MAP_HEIGHT];

	Player me, enemy;

	int get_dist(int x, int y) {
		if (terr[x][y] == _FLAT || terr[x][y] == _MINE) return 1;
		if (terr[x][y] == _BLOCK) return SIZE * 2;
		return 3;
	}

	std::pair<Position, int> Q[SIZE];
	bool inq[MAX_CD][MAP_WIDTH][MAP_HEIGHT];

	void sssp(Position sp, int d[MAX_CD][MAP_WIDTH][MAP_HEIGHT], int cd) {
		memset(inq, false, sizeof(inq));
		int st = 0, en = 0, size = 1;
		Q[0] = std::make_pair(sp, cd); d[cd][sp.x][sp.y] = 0; inq[cd][sp.x][sp.y] = true;

		while (size > 0) {
			sp = Q[st].first; cd = Q[st++].second; size--;
			inq[cd][sp.x][sp.y] = false;
			if (st >= SIZE) st = 0;

			for (int i = 0; i < 5; i++) {
				int kx = sp.x + dx[i], ky = sp.y + dy[i], kcd = std::max(0, cd - 1);
				if ( ! valid(kx, ky) ) continue;

				if (d[kcd][kx][ky] > d[cd][sp.x][sp.y] + get_dist(kx, ky)) {
					d[kcd][kx][ky] = d[cd][sp.x][sp.y] + get_dist(kx, ky);
					if (!inq[kcd][kx][ky]) {
						en++; size++;
						if (en >= SIZE) en = 0;
						Q[en] = std::make_pair(Position(kx, ky), kcd);
						inq[kcd][kx][ky] = true;
					}
				}
			}

			if (cd == 0 && (T(sp.x, sp.y) == _FLAT || T(sp.x, sp.y) == _MINE)) {
				cd = BLINK_CD_INIT + _ginfo.mine_num[me.owner] * BLINK_RATE;
				for (int kx = sp.x - 2; kx <= sp.x + 2; kx++)
					for (int ky = sp.y - 2; ky <= sp.y + 2; ky++) {
						if (!valid(kx, ky) || T(kx, ky) == _UNKNOWN) continue;
						if (T(kx, ky) != _FLAT && T(kx, ky) != _MINE) continue;
						if (d[cd][kx][ky] > d[0][sp.x][sp.y] + 1) {
							d[cd][kx][ky] = d[0][sp.x][sp.y] + 1;
							if (!inq[cd][kx][ky]) {
								en++; size++;
								if (en >= SIZE) en = 0;
								Q[en] = std::make_pair(Position(kx, ky), cd);
								inq[cd][kx][ky] = true;
							}
						}
					}
			}
		}
	}

	void set(Map &map, GameInfo &ginfo, RoundInfo &rinfo, Action &act) {
		memset(dist, 60, sizeof(dist));
		memset(__dist, 60, sizeof(__dist));
		_act = act;
		_rinfo = rinfo;
		_ginfo = ginfo;
		_map = map;

		COUNT = rinfo.mines.size();
		enemy.owner = -1;

		for (int i = 0; i < MAP_WIDTH; i++)
			for (int j = 0; j < MAP_HEIGHT; j++) {
				if (map.grids[i][j].terrain == MapGrid::FLAT) terr[i][j] = terr[MAP_WIDTH - i - 1][MAP_HEIGHT - j - 1] = _FLAT;
				if (map.grids[i][j].terrain == MapGrid::BLOCK) terr[i][j] = terr[MAP_WIDTH - i - 1][MAP_HEIGHT - j - 1] = _BLOCK;

				if (map.grids[i][j].players.size() != 0) {
					for (int k = 0; k < map.grids[i][j].players.size(); k++) {
						if (map.grids[i][j].players[k] == rinfo.player_id) {
							for (int l = 0; l < rinfo.players.size(); l++)
								if (rinfo.players[l].owner == map.grids[i][j].players[k])
									me = rinfo.players[l];
						} else {
							for (int l = 0; l < rinfo.players.size(); l++)
								if (rinfo.players[l].owner == map.grids[i][j].players[k])
									enemy = rinfo.players[l];
							enemy.pos = Position(i, j);
							enemy.owner = me.owner ^ 1;
						}
					}
				}
			}

		for (int i = me.pos.x - 2; i <= me.pos.x + 2; i++)
			for (int j = me.pos.y - 2; j <= me.pos.y + 2; j++) {
				if (!valid(i, j)) continue;
				int no = get_sssp_no(0, i - me.pos.x, j - me.pos.y);
				if (abs(i - me.pos.x) + abs(j - me.pos.y) > 1) {
					if (me.blink_cd == 0)
						sssp(Position(i, j), __dist[no], BLINK_CD_INIT + _ginfo.mine_num[me.owner] * BLINK_RATE);
				} else
					sssp(Position(i, j), __dist[no], me.blink_cd);

				for (int x = 0; x < MAP_WIDTH; x++)
					for (int y = 0; y < MAP_HEIGHT; y++)
						for (int cd = 0; cd < MAX_CD; cd++)
							dist[no][x][y] = std::min(dist[no][x][y], __dist[no][cd][x][y]);

#ifdef DIST
				fprintf(ptr, "	DISTANCE of no %d at %d %d\n", no, i, j);
				for (int y = 0; y < MAP_HEIGHT; y++) fprintf(ptr, "[%2d]", y);
				fprintf(ptr, "\n");
				for (int x = 0; x < MAP_WIDTH; x++) {
					fprintf(ptr, "[%2d] ", x);
					for (int y = 0; y < MAP_HEIGHT; y++) {
						if (dist[no][x][y] > 1e6) fprintf(ptr, "%3d ", -1);
						else fprintf(ptr, "%3d ", dist[no][x][y]);
					}
					fprintf(ptr, "\n");
				}
#endif
			}


		if (enemy.owner != -1) {
			for (int i = enemy.pos.x - 2; i <= enemy.pos.x + 2; i++)
				for (int j = enemy.pos.y - 2; j <= enemy.pos.y + 2; j++) {
					int no = get_sssp_no(1, i - enemy.pos.x, j - enemy.pos.y);
					sssp(Position(i, j), __dist[no], std::min(MAX_CD, enemy.blink_cd + 1));

					for (int x = 0; x < MAP_WIDTH; x++)
						for (int y = 0; y < MAP_HEIGHT; y++)
							for (int cd = 0; cd < MAX_CD; cd++)
								dist[no][x][y] = std::min(dist[no][x][y], __dist[no][cd][x][y]);
				}
		}

		for (int i = 0; i < rinfo.mines.size(); i++)
			terr[rinfo.mines[i].pos.x][rinfo.mines[i].pos.y] = _MINE;

		_act.setOB = false;
		_act.buy_protect = false;
		_act.move = Action::Stop;
	}

	void move(Action::Move _move) {
		_act.move = _move;
		pre = _move - 1;
	}

	void protect() {
		_act.buy_protect = true;
	}

	Position get_pos(int id) {
		if (id == 0) return me.pos;
		else return enemy.pos;
	}

	Position get_mine_pos(int id) {
		return _rinfo.mines[id].pos;
	}

	__Terrain T(int x, int y) {
		return terr[x][y];
	}

	__Terrain T(Position pos) {
		return terr[pos.x][pos.y];
	}

	int get_owner(Position pos) {
		return _rinfo.mines[_map.grids[pos.x][pos.y].mine_id].owner;
	}

	int get_owner(int id) {
		return _rinfo.mines[id].owner;
	}

	int get_own_point(int id) {
		return _rinfo.mines[id].own_point;
	}

	int get_owner(int x, int y) {
		return _rinfo.mines[_map.grids[x][y].mine_id].owner;
	}

	int get_own_point(int x, int y) {
		return _rinfo.mines[_map.grids[x][y].mine_id].own_point;
	}

	int get_own_point(Position pos) {
		return _rinfo.mines[_map.grids[pos.x][pos.y].mine_id].own_point;
	}

	bool can_blink() {
		return me.blink_cd == 0;
	}

	bool enemy_appeared() {
		return enemy.owner != -1;
	}

	int enemy_dist(int x, int y) {
		return dist[get_sssp_no(1, 0, 0)][x][y];
	}

	int enemy_dist(Position pos) {
		return enemy_dist(pos.x, pos.y);
	}

	int me_dist(int x, int y, int no = -1) {
		if (no < 0) no = get_sssp_no(0, 0, 0);
		return dist[no][x][y];
	}

	int me_dist(Position pos, int no = -1) {
		return me_dist(pos.x, pos.y, no);
	}

	int get_player_id() {
		return _rinfo.player_id;
	}

	void blink(Position pos) {
		_act.move = Action::Blink;
		_act.blink_pos = pos;
		pre = 7;
	}

	void blink(int x, int y) {
		blink(Position(x, y));
	}

	int get_protect_round(int id) {
		return _rinfo.mines[id].protect_round;
	}

	int get_protect_round(int x, int y) {
		return _rinfo.mines[_map.grids[x][y].mine_id].protect_round;
	}

	int get_protect_round(Position pos) {
		return get_protect_round(pos.x, pos.y);
	}

	int expect() {
		int diff = _ginfo.golds[me.owner] - _ginfo.golds[me.owner ^ 1];
		diff += (_ginfo.mine_num[me.owner] - _ginfo.mine_num[me.owner ^ 1])
			* (GAME_ROUND - 1 - _rinfo.round) * GAIN_RATE;
		return diff;
	}

	bool is_mine(int x, int y) {
		return _map.grids[x][y].mine_id != -1;
	}

	bool is_mine(Position pos) {
		return is_mine(pos.x, pos.y);
	}
};

Data data;

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act) {
	data.set(map, ginfo, rinfo, act);
	Position mPos = data.get_pos(0);

#ifdef DEBUG
	fprintf(ptr, "ROUND %d with expect %d at %d %d\n", rinfo.round, data.expect(), mPos.x, mPos.y);
#endif
	
	//BEGIN
	//just follow enemy
	if (data.expect() > 0 && data.enemy_appeared() && data.enemy_dist(mPos) < 0) {
#ifdef DEBUG
		fprintf(ptr, "	follow!\n");
#endif
		for (int i = 0; i < 4; i++) {
			int kx = mPos.x + dx[i], ky = mPos.y + dy[i];
			if ( ! valid(kx, ky)) continue;
			if (data.enemy_dist(mPos) > data.enemy_dist(kx, ky)) {
				data.move((Action::Move)(i + 1));
				break;
			}
		}

		if (data.can_blink()) {
			int dec = 0;
			for (int x = mPos.x - 2; x <= mPos.x + 2; x++)
				for (int y = mPos.y - 2; y <= mPos.y + 2; y++) {
					if ( ! valid(x, y) || data.T(x, y) == _UNKNOWN ) continue;
					int tmp = data.enemy_dist(mPos) - data.enemy_dist(x, y) - 2;
					if (tmp > dec) {
						dec = tmp;
						data.blink(x, y);
					}
				}
		}
	} else {
		if (data.is_mine(mPos) && data.get_owner(mPos) != data.get_player_id() && data.get_protect_round(mPos) == 0) {
			data.move((Action::Move)0);
		} else {
			//SET PROTECT
			if (data.is_mine(mPos) && data.enemy_appeared() && data.enemy_dist(mPos) < 5) data.protect();

			//SET TARGET MINE
			int dist[MAX_MINE_NUM], MIN_DIST = 1e9, target;
			memset(dist, 60, sizeof(dist));
			for (int i = 0; i < COUNT; i++) {
				if (data.get_protect_round(i) > data.me_dist(data.get_mine_pos(i))) continue;
				if (data.get_owner(i) == data.get_player_id()) continue;
				dist[i] = data.me_dist(data.get_mine_pos(i));
#ifdef DEBUG
			fprintf(ptr, "	estimate %d at %d %d with dist %d\n", i, data.get_mine_pos(i).x, data.get_mine_pos(i).y, dist[i]);
#endif
				if (dist[i] < MIN_DIST) target = i, MIN_DIST = dist[i];
			}
#ifdef DEBUG
			fprintf(ptr, "	target %d at %d %d\n", target, data.get_mine_pos(target).x, data.get_mine_pos(target).y);
#endif

			//SET MOVEMENT
			MIN_DIST = 1e9;
			for (int i = 0; i < 5; i++) {
				if ( !valid(mPos.x + dx[i], mPos.y + dy[i])) continue;
				int no = get_sssp_no(0, dx[i], dy[i]);
#ifdef DEBUG
				fprintf(ptr, "	move candidate: %d %d dist %d\n", mPos.x + dx[i], mPos.y + dy[i], data.me_dist(data.get_mine_pos(target), no));
#endif
				if (data.me_dist(data.get_mine_pos(target), no) < MIN_DIST) {
					MIN_DIST = data.me_dist(data.get_mine_pos(target), no);
					if (i < 4) data.move((Action::Move)(i + 1));
					else data.move(Action::Stop);
				}
			}

			if (data.can_blink()) {
				for (int x = mPos.x - 2; x <= mPos.x + 2; x++)
					for (int y = mPos.y - 2; y <= mPos.y + 2; y++) {
						if ( ! valid(x, y) || data.T(x, y) == _UNKNOWN ) continue;
						int no = get_sssp_no(0, x - mPos.x, y - mPos.y);
#ifdef DEBUG
						fprintf(ptr, "	blink candidate: %d %d dist %d\n", x, y, data.me_dist(data.get_mine_pos(target), no));
#endif
						int tmp = data.me_dist(data.get_mine_pos(target), no);
						if (tmp < MIN_DIST) {
							MIN_DIST = tmp;
							data.blink(x, y);
						}
					}
			}
		}
	}

	//END
	act = data._act;
#ifdef DEBUG
	fprintf(ptr, "MOVE: %d\nBLINK: %d %d\n\n", act.move, act.blink_pos.x, act.blink_pos.y);
#endif
}


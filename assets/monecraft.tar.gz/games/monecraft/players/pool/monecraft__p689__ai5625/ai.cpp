#include "sdk.h"
#include <cstdio>

using namespace std;

const int dx[] = {0, -1, 0, 1};
const int dy[] = {1, 0, -1, 0};
extern const int MAP_WIDTH;
extern const int MAP_HEIGHT;

//#define DEGUG

#ifdef DEGUG
static FILE *fp = fopen("test.log", "w");
void debug(Map & map, Player & my_player, Action & act, RoundInfo & rinfo, GameInfo & ginfo) {
    fprintf(fp, "round %d # Action %d\n", rinfo.round, act.move);
    int x = my_player.pos.x + dx[act.move - 1];
    int y = my_player.pos.y + dy[act.move - 1];
    fprintf(fp, "terrain is %s\n", map.grids[x][y].terrain == MapGrid::FLAT ? "FLAT" : "BLOCK");
    fprintf(fp, "Golds %d\n", ginfo.golds[rinfo.player_id]);
}
#endif

int unseen_grid = MAP_HEIGHT * MAP_WIDTH;
int direction = 0;

int abs(int x) {
    return x >= 0 ? x : -x;
}

int m_distance(Position A, Position B) {
	return abs(A.x - B.x) + abs(A.y - B.y);
}

bool in_range(int x, int y) {
    return x >= 0 && y >= 0 && x < MAP_WIDTH && y < MAP_HEIGHT;
}

void import_map_info(Player & my_player, Map & map, Map & mapinfo) {
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            if (map.grids[i][j].terrain != MapGrid::UNSEEN
                && mapinfo.grids[i][j].terrain == MapGrid::UNSEEN) {
                mapinfo.grids[i][j].terrain = map.grids[i][j].terrain;
                unseen_grid--;
            }
}

Mine search_mine(Player & my_player, RoundInfo & rinfo) {
	Mine s_mine;
    int mindis = 0x7FFFFFFF;

    for (int i = 0; i < rinfo.mines.size(); ++i)
    	if (my_player.owner != rinfo.mines[i].owner)
    		if (m_distance(my_player.pos, rinfo.mines[i].pos) < mindis) {
    			mindis = m_distance(my_player.pos, rinfo.mines[i].pos);
    			s_mine = rinfo.mines[i];
    		}

    return s_mine;
}

bool move_blink_towards_lmine(Map & map, Player & my_player, Mine & lmine, Action & act) {
    Position s_pos;
    int mindis = 0x7FFFFFFF;
    
    for (int dx = -2;  dx <= 2; ++dx)
        for (int dy = -2; dy <= 2; ++dy) {
            Position t_pos(my_player.pos.x + dx, my_player.pos.y + dy);
            if (in_range(t_pos.x, t_pos.y) 
                && map.grids[t_pos.x][t_pos.y].terrain == MapGrid::FLAT
                && m_distance(t_pos, my_player.pos) < mindis) {
                mindis = m_distance(t_pos, my_player.pos);
                s_pos = t_pos;
            }
        }
    
    if (mindis != 0x7FFFFFFF && mindis > 1) {
        act.move = Action::Blink;
        act.blink_pos = s_pos;
        return true;
    } else 
        return false;
}

void march_or_turn_right(Map & mapinfo, Player & my_player, Action & act, RoundInfo rinfo) {

    for (int i = 3; i < 7; ++i) {
        int x = my_player.pos.x + dx[(i + direction) % 4];
        int y = my_player.pos.y + dy[(i + direction) % 4];
        if (in_range(x, y) && mapinfo.grids[x][y].terrain == MapGrid::FLAT) {
            act.move = Action::Move ((i + direction) % 4 + 1);
            direction = (i + direction) % 4;
            return;
        }
    }
}

void player_ai(Map & map, GameInfo & ginfo, RoundInfo & rinfo, Action &act) {
	static Map mapinfo = map;
	Player my_player;

	for (int i = 0; i < rinfo.players.size(); ++i) 
		if (rinfo.players[i].owner == rinfo.player_id)
            my_player = rinfo.players[i];

    import_map_info(my_player, map, mapinfo);

    int lm_id = map.grids[my_player.pos.x][my_player.pos.y].mine_id;

    if (lm_id != -1) {
        Mine lmine;
    	for (int i = 0; i < rinfo.mines.size(); ++i)
    		if (rinfo.mines[i].id == lm_id)
    			lmine = rinfo.mines[i];
    	if (lmine.owner != rinfo.player_id) {
    		act.move = Action::Stop;
            return;
        }
    }

    march_or_turn_right(mapinfo, my_player, act, rinfo);
    act.setOB = false;
    act.buy_protect = false;

#ifdef DEGUG
    debug(map, my_player, act, rinfo, ginfo);
#endif

    return ;
}
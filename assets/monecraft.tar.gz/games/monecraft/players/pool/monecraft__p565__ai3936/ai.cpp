#include <iostream>
#include <cstdio>
#include <cstring>
#include "sdk.h"
using namespace std;

namespace sample
{
	const int maxn = 31;
	int cnt[maxn][maxn];
	bool mine[maxn][maxn];
	Map map;
	GameInfo gameinfo;
	RoundInfo roundinfo;
	Player player;
	int status;														//0 for stop; 1 for search; 2 for backtrack
	int t, dire[maxn * maxn], num[maxn * maxn];
	int dx[5] = {0, 0, -1, 0, 1};
	int dy[5] = {0, 1, 0, -1, 0};
	int chg[5] = {0, 3, 4, 1, 2};
	
	void update()
	{
		if (roundinfo.round == 0)									//initialize
		{
			memset(cnt, 0, sizeof(cnt));
			memset(mine, 0, sizeof(mine));
			for (int i = 0; i < roundinfo.mines.size(); ++i)
			{
				Position pos = roundinfo.mines[i].pos;
				mine[pos.x][pos.y] = 1;
			}
			status = 1;
			t = 1;
		}
		for (int i = 0; i < maxn; ++i)								//update data
			for (int j = 0; j < maxn; ++j)
				if (map.grids[i][j].terrain == MapGrid::BLOCK)
					cnt[i][j] = 1;
		for (int i = 0; i < roundinfo.players.size(); ++i)
			if (roundinfo.players[i].owner == roundinfo.player_id)
			{
				//cout << roundinfo.players[i].owner << endl;
				player = roundinfo.players[i];
				//cout << roundinfo.players[i].pos.y << endl;
			}
		//cout << "good" << endl;
	}

	int cal(int x, int y)
	{
		int ans = 0;
		for (int i = 1; i <= 4; ++i)
			if (x + dx[i] >= 0 && x + dx[i] < maxn && y + dy[i] >= 0 && y + dy[i] < maxn)
			if (cnt[x + dx[i]][y + dy[i]] == 0)
				++ans;
		return ans;
	}

	void decide(Action &action)
	{
		int x = player.pos.x, y = player.pos.y;
		num[t] = cal(x, y);
		//cout << "x = " << x << "y = " << player.pos.y << endl;
		++cnt[x][y];												//counts when step into (x, y)
		if (mine[x][y])												//if on a mine, stop
		{
			status = 0;
			action.move = Action::Stop;
			//cout << "stop" << endl;
			return;
		}
		if (status == 2 || num[t] == 0)								//backtrack when found no path
		{
			action.move = (Action::Move)(chg[dire[t]]);
			action.setOB = false;
			action.buy_protect = false;
			--t;
			//cout << dire[t] << endl;
			return;
		}
		status = 1;
		int dir = 0;
		for (int i = 1; i <= 4; ++i)								//move to the grid with no visit
			if (x + dx[i] >= 0 && x + dx[i] < maxn && y + dy[i] >= 0 && y + dy[i] < maxn)
			if (cnt[x + dx[i]][y + dy[i]] == 0)
				dir = i;
		//cout << "dir = " << dir << endl;
		action.move = (Action::Move)(dir);
		action.setOB = false;
		action.buy_protect = false;
		dire[++t] = dir;
	}
}

void player_ai(Map &map, GameInfo &gameinfo, RoundInfo &roundinfo, Action &action)
{
	sample::map = map;												//data initialization
	sample::gameinfo = gameinfo;
	sample::roundinfo = roundinfo;
	sample::update();
	sample::decide(action);
}

#include "sdk.h"
#include <ctime>
#include <iostream>
#include <cmath>
#include<queue>
using namespace std;

struct Star_map
{
Position pos,f_pos;
int n,f_i;
};


int easy_dist(Position a,Position b)//��ģʽ�жϾ���
{
return abs(a.x-b.x)+abs(a.y-b.y);

}

int can_blink(Position p,Player my_player)//p�Ƿ�������ֵ�
{
if(sqrt((p.x-my_player.pos.x)*(p.x-my_player.pos.x)+(p.y-my_player.pos.y)*(p.y-my_player.pos.y))<2.9)
return 1;
else 
return 0;
}


int is_not_my_mine(Position p,RoundInfo rinfo,Player my_player)//�ж����ڵ�p�ǲ���һ�����ҷ���
{
	int t_ok=0;
	

	if(p.x>=0&&p.x<=30&&p.y>=0&&p.y<=30)
	for(int i=0;i<rinfo.mines.size();i++)
	{
	if(p.x==rinfo.mines[i].pos.x&&p.y==rinfo.mines[i].pos.y&&(rinfo.mines[i].owner!=my_player.owner||(rinfo.mines[i].owner==my_player.owner&&abs(rinfo.mines[i].own_point)<4.5)))
		{t_ok=1;
		break;}
	}
	if(t_ok==1)
	return 1;
	else
	return 0;
}

int id_near_nmmine(RoundInfo rinfo,Player my_player)//��ģʽ�������ķ��ҷ���
{
	int min_dist=999,my_i=-1;
	for(int i=0;i<rinfo.mines.size();i++)
	{
		if(easy_dist(rinfo.mines[i].pos,my_player.pos)<min_dist&&rinfo.mines[i].owner!=my_player.owner)
			my_i=i;
	}
return my_i;
}


void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	static Position last(-1,-1);
  static Map my_map;
  int is_star[MAP_WIDTH][MAP_HEIGHT];
  static int num_reach[MAP_WIDTH][MAP_HEIGHT];
  static bool map_saw[MAP_WIDTH][MAP_HEIGHT]={0};
     if(ginfo.rounds==0)//��һ�غϳ�ʼ��һ��~
	 {
		/*for(int i=0;i<MAP_WIDTH;++i)
			for(int j=0;j<MAP_HEIGHT;++j)//ˢ��ͼ
			{
			map_saw[i][j]=0;
			num_reach[i][j]=0;
			my_map.grids[i][j].terrain=MapGrid::UNSEEN;
			my_map.grids[i][j].pos=Position(i,j);
			
			}*/
			my_map=map;
	 }
	 

	for(int i=0;i<MAP_WIDTH;i++)
		for(int j=0;j<MAP_HEIGHT;j++)//�Լ��ֶ�����û����Ұ�ĵ�ͼ
			{
			is_star[i][j]=0;
			if(map_saw[i][j]==0&&map.grids[i][j].terrain != MapGrid::UNSEEN)
				{
				map_saw[i][j]=1;
				map_saw[MAP_WIDTH-i-1][MAP_HEIGHT-j-1]=1;
				my_map.grids[i][j]=map.grids[i][j];
				my_map.grids[MAP_WIDTH-i][MAP_HEIGHT-j]=map.grids[i][j];//��Ϊ��ͼ�����ĶԳƵ�ô��
				}		
				
			//	cout<<i<<' '<<j<<' '<<my_map.grids[i][j].terrain<<endl;
			}
 
 /*for(int i=0;i<MAP_WIDTH;i++)
		{for(int j=0;j<MAP_HEIGHT;j++)//�Լ��ֶ�����û����Ұ�ĵ�ͼ
			{
				cout<<my_map.grids[i][j].terrain;
			}
			cout<<endl;
 
 }*/
 

  
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  
  num_reach[my_player.pos.x][my_player.pos.y]++;
  Position next_pos;
  int next = -1,mp[4]={999,999,999,999},mp_min=800,way2mine=999;
  
  int star_ok=0;//�ж��Ƿ����A*Ѱ·
  
  //����ΪA*�㷨��
  queue<Star_map> q;
  Star_map star_map[MAP_WIDTH][MAP_HEIGHT],now_star,back_star,block_go;
  
  star_map[my_player.pos.x][my_player.pos.y].pos=my_player.pos;//��ʼ
  star_map[my_player.pos.x][my_player.pos.y].f_pos=Position(-100,-100);
  star_map[my_player.pos.x][my_player.pos.y].n=0;
  
  q.push(star_map[my_player.pos.x][my_player.pos.y]);
  is_star[my_player.pos.x][my_player.pos.y]++;
  
  int uc_mine_dist=999;//���ڼ���������Ŀ�ľ���
  
  
  while(!q.empty())
  {
	
	  now_star=q.front();
	 // cout<<now_star.pos.x<<' '<<now_star.pos.y<<endl;
	 q.pop();
	  if(is_not_my_mine(now_star.pos,rinfo,my_player)!=0)//�ҵ����ˣ��˳�
		{star_ok=1;break;}
	 
	  for (int i = 0; i < 4; ++i)
	  {
		next_pos.x = now_star.pos.x + dx[i];
		next_pos.y = now_star.pos.y + dy[i];
		//cout<<my_map.grids[ next_pos.x ][ next_pos.y ].terrain<<endl;
		if(next_pos.x>=0&&next_pos.x<=30&&next_pos.y>=0&&next_pos.y<=30)
		if (my_map.grids[ next_pos.x ][ next_pos.y ].terrain == 0&&is_star[next_pos.x][next_pos.y]==0)//���棿������bug
		{
		  is_star[next_pos.x][next_pos.y]++;
		  star_map[next_pos.x][next_pos.y].pos=next_pos; 
		  star_map[next_pos.x][next_pos.y].f_pos=now_star.pos;
		  star_map[next_pos.x][next_pos.y].n=now_star.n+1;
		  star_map[next_pos.x][next_pos.y].f_i=i;
		  q.push(star_map[next_pos.x][next_pos.y]);
		}
		
		if (my_map.grids[ next_pos.x ][ next_pos.y ].terrain == 2&&is_star[next_pos.x][next_pos.y]==0&&easy_dist(next_pos,rinfo.mines[id_near_nmmine(rinfo,my_player)].pos)<uc_mine_dist)//���Һڿ�
		{
		   uc_mine_dist=easy_dist(next_pos,rinfo.mines[id_near_nmmine(rinfo,my_player)].pos);
		  is_star[next_pos.x][next_pos.y]++;
		  block_go.pos=next_pos; 
		  block_go.f_pos=now_star.pos;
		  block_go.n=now_star.n+1;
		  block_go.f_i=i;
		}
	  }
  }
  //cout<<star_ok<<endl;
  if(star_ok==1)
  {
  back_star=now_star;
	  while(!(back_star.n<=1||(can_blink(back_star.pos,my_player)==1)&&my_player.blink_cd<=0))
	  {
	  back_star=star_map[back_star.f_pos.x][back_star.f_pos.y];
	  }
	 if(back_star.n==1)
		act.move=(Action::Move)(back_star.f_i+1);
	else
		{act.blink_pos=back_star.pos;act.move=(Action::Move)(5);}
	}
	
	
	//cout<<my_player.blink_cd<<endl;
	
	//�¼���һ������ڿ�����㷨��
	if(star_ok==0)
	{
	 back_star=block_go;
	  while(!(back_star.n<=1||(can_blink(back_star.pos,my_player)==1)&&my_player.blink_cd<=0))
	  {
	  back_star=star_map[back_star.f_pos.x][back_star.f_pos.y];
	  }
	 if(back_star.n==1)
		act.move=(Action::Move)(back_star.f_i+1);
	else
		{act.blink_pos=back_star.pos;act.move=(Action::Move)(5);}
	}
	
	
	
	
	
	
/*
  if(star_ok==0)//����Ӧ����û��A*�㷨��ʱ��ʹ�õİ�
  {
		next = -1;
	  for (int i = 0; i < 4; ++i)//�ҳ�����mpֵ
	  {
		next_pos.x = my_player.pos.x + dx[i];
		next_pos.y = my_player.pos.y + dy[i];
		
		if(next_pos.x>=0&&next_pos.x<=30&&next_pos.y>=0&&next_pos.y<=30)
		if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT)
		{
		  mp[i]=num_reach[next_pos.x][next_pos.y]; 
		  if(next_pos == last)
		  mp[i]=mp[i]+10;
		}
		
		if(next_pos.x>=0&&next_pos.x<=30&&next_pos.y>=0&&next_pos.y<=30)
		if(mp[i]<mp_min||(mp[i]==mp_min&&easy_dist(next_pos,rinfo.mines[id_near_nmmine(rinfo,my_player)].pos)<way2mine))
		{
			mp_min=mp[i];
			next=i;
			way2mine=easy_dist(next_pos,rinfo.mines[id_near_nmmine(rinfo,my_player)].pos);
		}
	  }
	  //cout<<next<<endl;
	  if (next >= 0)
	  {
		act.move = (Action::Move)(next+1);
	  }
	  else
		act.move = (Action::Move)0;		
  }//isok=0���������
  */
  
  
   act.setOB=0;//��ʱ���Ź۲��߰�
	act.buy_protect=0;//Ҳ��ʱ���ŷ����ְ�~
	/*
   for(int i=0;i<rinfo.mines.size();i++)//�п��ռ
	  {
		if(rinfo.mines[i].pos.x==my_player.pos.x&&rinfo.mines[i].pos.y==my_player.pos.y&&rinfo.mines[i].owner!=my_player.owner)
		
			act.move=(Action::Move)0;
			
	  }
	  */

	  for (int i = 0; i < 4; ++i)//��Χ4���п�
	{
		next_pos.x = my_player.pos.x + dx[i];
		next_pos.y = my_player.pos.y + dy[i];
		if(is_not_my_mine(next_pos,rinfo,my_player)!=0)
		{
			act.move=(Action::Move)(i+1);
			break;
		}
	}
	
	
	const int ddx[] = {2,2,2,2,2,-2,-2,-2,-2,-2,1,1,1,1,-1,-1,-1,-1,0,0};
	const int ddy[] = {-2,-1,0,1,2,-2,-1,0,1,2,2,1,-1,-2,2,1,-1,-2,2,-2};
	for (int i = 0; i < 20; ++i)//�ҳ�����mpֵ
	{
		next_pos.x = my_player.pos.x + dx[i];
		next_pos.y = my_player.pos.y + dy[i];
		if(is_not_my_mine(next_pos,rinfo,my_player)!=0&&my_player.blink_cd==0)
		{
			{act.blink_pos=next_pos;act.move=(Action::Move)(5);}
			break;
		}
	}
	
	  
	  
	  
	  if(is_not_my_mine(my_player.pos,rinfo,my_player)!=0)//�п� ռ��
		{act.move=(Action::Move)0;}
	  
		
		
		
		
		
		
	  last = my_player.pos;
  

  
  
  
  //cout<<act.move<<endl;
  //cout << "test end!" << endl;
}


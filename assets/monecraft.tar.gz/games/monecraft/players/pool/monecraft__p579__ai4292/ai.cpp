#include "sdk.h"
#include <cstring>
#include <cmath>
#include <algorithm>

using std::max;
using std::min;

typedef Position (*PosFunc)(const Position&);


struct MinDist {
    const static int MAX_DIST = 1000;
    int round;
    int f[MAP_WIDTH][MAP_HEIGHT];
    MinDist() {
        round = -1;
        clear();
    }
    void clear() {
        memset(f, 0xFF, sizeof f);
    }
};

struct Worth {
    const static int MAX_VALUE = 1000;
    Position pos;
    double value;
    int dist;
    Worth() : value(0), dist(0) {
    }
    Worth(const Position& pos, double value, int dist) : pos(pos), value(value), dist(dist) {
    }
    
    bool better(const Worth& w) {
        if (pos.x < 0) return false;
        if (w.pos.x < 0 ) return true;
        if (dist == MinDist::MAX_DIST) return false;
        if (w.dist == MinDist::MAX_DIST) return true;
        return value > w.value || (value == w.value && dist < w.dist);
    }
};

struct MyGrid {
    enum Terrain {
        FLAT = 0,
        BLOCK,
        UNSEEN,
        UNPROBE
    } terrain;
    int mine_id;
    
    MyGrid() {
        mine_id = -1;
        terrain = UNPROBE;
    }
};

struct MyMap {
    MyGrid grids[MAP_WIDTH][MAP_HEIGHT];
    MyGrid& operator[] (const Position& pos) {
        return grids[pos.x][pos.y];
    }
};

struct MineRecorder {
    const static int DEFAULT_CD = 30;
    int cd;
    int count, id;
    int player;
    
    MineRecorder() : cd(DEFAULT_CD), count(0) {
        player = -1;
        id = -1;
    }
    
    MineRecorder(int id) : cd(DEFAULT_CD), count(0), id(id) {
        player = -1;
    }
    
    void update(const RoundInfo& rinfo) {
        if (rinfo.mines[id].owner != player) {
            if (cd) {
                ++count;
            } else {
                count = 1;
            }
            player = rinfo.mines[id].owner;
            cd = DEFAULT_CD;
        } else {
            if (cd) cd --;
        }
    }
    
    bool useProtection() {
        return count > 6;
    }
};

Position up(const Position& p) {
    return Position(p.x, p.y - 1);
}

Position down(const Position& p) {
    return Position(p.x, p.y + 1);
}

Position left(const Position& p) {
    return Position(p.x - 1, p.y);
}

Position right(const Position& p) {
    return Position(p.x + 1, p.y);
}

PosFunc posFunc[4] = {up, down, left, right};

int manhattanDist(const Position& u, const Position& v) {
    return std::abs(u.x - v.x) + std::abs(u.y - v.y);
}

double euclideanDist(const Position& u, const Position& v) {
    return sqrt((u.x - v.x) * (u.x - v.x) + (u.y - v.y) * (u.y - v.y));
}

bool valid(const Position& pos) {
    return pos.x >= 0 && pos.x < MAP_WIDTH && pos.y >= 0 && pos.y < MAP_HEIGHT;
}

Player getPlayer(const RoundInfo& rinfo) {
    for (unsigned i = 0; i < rinfo.players.size(); ++i)
        if (rinfo.players[i].owner == rinfo.player_id) return rinfo.players[i];
    printf("Error, get Player %d\n", __LINE__);
    return Player();
}

double getValue(const MyMap& map, const Position& pos, const RoundInfo& rinfo) {
    if (map.grids[pos.x][pos.y].terrain != MyGrid::FLAT) return 0;
    if (map.grids[pos.x][pos.y].mine_id != -1) {
        if (rinfo.mines[map.grids[pos.x][pos.y].mine_id].owner == rinfo.player_id)
            return 0;
        if (rinfo.mines[map.grids[pos.x][pos.y].mine_id].protect_round < 5) {
            if (rinfo.mines[map.grids[pos.x][pos.y].mine_id].owner != -1)
                return Worth::MAX_VALUE;
            Player my = getPlayer(rinfo);
            if (pos.x == my.pos.x && pos.y == my.pos.y)
                return 3 * Worth::MAX_VALUE;
            return Worth::MAX_VALUE;
        }
    }
    
    double value = 0, sum = 0;
    for (int i = 0; i < 4; ++i) {
        Position p = posFunc[i](pos);
        if (valid(p) && map.grids[p.x][p.y].terrain == MyGrid::UNPROBE)
            value += 1;
    }
    //value = sqrt(value);
    if (value) value = 1;
    
    
    for (unsigned i = 0; i < rinfo.mines.size(); ++i)
        if ( rinfo.mines[i].owner != rinfo.player_id ) {
            double t = euclideanDist(pos , rinfo.mines[i].pos);
            sum += 10 / pow(t, 2);
        }
    
    return value * sum;
}

void getMinDist(const MyMap& map, MinDist& mdist, const Position& source) {
    static Position queue[MAP_WIDTH * MAP_HEIGHT];
    mdist.clear();
    int head = 0, tail = 0;
    mdist.f[source.x][source.y] = 0;
    queue[head] = source;
    while (head <= tail) {
        Position u = queue[head ++];
        for (int i = 0; i < 4; ++i) {
            Position v = posFunc[i](u);
            if (!valid(v) || map.grids[v.x][v.y].terrain != MyGrid::FLAT) continue;
            
            if (mdist.f[v.x][v.y] == -1) {
                mdist.f[v.x][v.y] = mdist.f[u.x][u.y] + 1;
                queue[++ tail] = v;
            }
        }
    }
}

int getDist(const MyMap& map, const Position& pos, const Position& myPos, const RoundInfo& rinfo) {
    static MinDist mdist;
    
    if (mdist.round < rinfo.round) {
        mdist.round = rinfo.round;
        getMinDist(map, mdist, myPos);
    }
    
    if (mdist.f[pos.x][pos.y] >= 0) return mdist.f[pos.x][pos.y];
    if (map.grids[pos.x][pos.y].terrain != MyGrid::FLAT) return MinDist::MAX_DIST;
    
    int value = MinDist::MAX_DIST;
//    for (int i = 0; i < MAP_WIDTH; ++i)
//        for (int j = 0; j < MAP_HEIGHT; ++j)
//            if (mdist.f[i][j] >= 0)
//                value = min(value, mdist.f[i][j] + manhattanDist(pos, Position(i, j)));
    return value;
}

Worth findTarget(const MyMap& map, const Position& myPos, const RoundInfo& rinfo) {
    Worth target;
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            if (map.grids[i][j].terrain == MyGrid::FLAT) {
                Position pos(i, j);
                double value = getValue(map, pos, rinfo);
                int dist = getDist(map, pos, myPos, rinfo);
                Worth u(pos, value, dist);
                if (u.better(target)) target = u;
                
                //printf("//// %d %d , v = %d , d = %d\n", pos.x, pos.y, value, dist);
            }
    //printf("//// %d %d , v = %d , d = %d\n", target.pos.x, target.pos.y, target.value, target.dist);
    return target;
}

Action calcAction(const Position& myPos, const Position target) {
    
    //printf("calcAction : %d %d, %d %d, %d\n", myPos.x, myPos.y, target.x, target.y, manhattanDist(myPos, target));

    Action ret;
    ret.setOB = ret.buy_protect = false;
    ret.move = Action::Stop;
    if (!valid(target) || manhattanDist(myPos, target) == 0) return ret;
    if (manhattanDist(myPos, target) > 1) {
        ret.move = Action::Blink;
        ret.blink_pos = target;
        return ret;
    }
    
    if (myPos.x > target.x) ret.move = Action::Left;
    else if (myPos.x < target.x) ret.move = Action::Right;
    else if (myPos.y > target.y) ret.move = Action::Down;
    else ret.move = Action::Up;
    
    return ret;
}

Action getNext(const MyMap& map, const Position& myPos, const Position& target, const RoundInfo& rinfo, const GameInfo& ginfo) {
    static MinDist mdist;
    static MineRecorder mrecord[MAX_MINE_NUM];
    if (mrecord[0].id == -1) {
        //init
        for (unsigned i = 0; i < rinfo.mines.size(); ++i)
            mrecord[i].id = i;
    }
    for (unsigned i = 0; i < rinfo.mines.size(); ++i)
        mrecord[i].update(rinfo);
    
    getMinDist(map, mdist, target);
    Player player = getPlayer(rinfo);
    double dist = player.blink_cd == 0 ? BLINK_LIMIT : 1.1;
    
    Position ret;
    int value = -1;
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            if (mdist.f[i][j] >= 0 && euclideanDist(myPos, Position(i, j)) <= dist) {
                if (value == -1 || value > mdist.f[i][j]) {
                    value = mdist.f[i][j];
                    ret = Position(i, j);
                }
            }
    if (value == -1) {
        printf("ERROR\n");
        exit(0);
    }
    Action act = calcAction(myPos, ret);
    
    if (map.grids[myPos.x][myPos.y].mine_id != -1) {
        int id = map.grids[myPos.x][myPos.y].mine_id;
        if (mrecord[id].useProtection() &&
            rinfo.players.size() == 2 &&
            ginfo.golds[rinfo.player_id] - 500 >= ginfo.golds[1 - rinfo.player_id])
            act.buy_protect = true;
    }
    
    return act;
}

void updateMap(MyMap& myMap, const Map& map) {
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            //if (myMap.grids[i][j].terrain == MyGrid::UNPROBE) {
            {
                switch (map.grids[i][j].terrain) {
                    case MapGrid::UNSEEN:
                        break;
                    case MapGrid::FLAT:
                        myMap.grids[i][j].terrain = MyGrid::FLAT;
                        myMap.grids[i][j].mine_id = map.grids[i][j].mine_id;
                        break;
                    case MapGrid::BLOCK:
                        myMap.grids[i][j].terrain = MyGrid::BLOCK;
                        break;
                }
                
                switch (map.grids[MAP_WIDTH - 1 - i][MAP_HEIGHT - 1 - j].terrain) {
                    case MapGrid::UNSEEN:
                        break;
                    case MapGrid::FLAT:
                        myMap.grids[i][j].terrain = MyGrid::FLAT;
                        //myMap.grids[i][j].mine_id = map.grids[MAP_WIDTH - 1 - i][MAP_HEIGHT - 1 - j].mine_id;
                        break;
                    case MapGrid::BLOCK:
                        myMap.grids[i][j].terrain = MyGrid::BLOCK;
                        break;
                }
            }
}

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act) {
    
    static MyMap myMap;
    static bool hasTarget = false;
//    static Position target;
    static Worth target;
    
    updateMap(myMap, map);
    
    Position myPos = getPlayer(rinfo).pos;
    if (hasTarget && manhattanDist(myPos, target.pos) == 0) {
        hasTarget = false;
    } else {
        Worth tmp = findTarget(myMap, myPos, rinfo);
        if (tmp.better(target)) target = tmp;
    }
    if (!hasTarget) {
        hasTarget = true;
        target = findTarget(myMap, myPos, rinfo);
    }
    
    //printf("%d %d, %d %d\n", myPos.x, myPos.y, target.x, target.y);
    /*for (int i = 0; i < MAP_WIDTH; ++i, puts(""))
        for (int j = 0; j < MAP_HEIGHT; ++j) {
            switch (myMap.grids[i][j].terrain) {
                case MyGrid::FLAT:
                    if (myMap.grids[i][j].mine_id != -1) putchar('x');
                    else putchar(' ');
                    break;
                case MyGrid::BLOCK:
                    putchar('#');
                    break;
                default:
                    putchar('?');
                    break;
            }
        }*/
    
    act = getNext(myMap, myPos, target.pos, rinfo, ginfo);
}

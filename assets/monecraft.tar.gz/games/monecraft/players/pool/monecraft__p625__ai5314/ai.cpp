#include "sdk.h"
#include <cstdio>
#include <iostream>
#include <fstream>
using namespace std;
static int reach[31][31];
static int length[31][31];
static int stay[200][3];
static int flag = 0;
static Position point(0,0);
const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};
void Make_Map(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act, int x, int y) //�������·
{
  int left = 0;
  int right = 0;
  int x1, y1;
  stay[0][1] = x;
  stay[0][2] = y;
  while (right >= 0)
  {
    x1 = stay[0][1];
    y1 = stay[0][2];
    for (int j = 0; j < 4; j++)
      {
        if (x1 + dx[j] < 31 && x1 + dx[j] >= 0 && y1 + dy[j] < 31 && y1 + dy[j] >= 0)
        if ( length[x1][y1] + 1 < length[ x1 + dx[j] ][ y1 + dy[j] ]  && reach[ x1 + dx[j] ][ y1 + dy[j] ] != 1)
        {
          length[ x1 + dx[j] ][ y1 + dy[j] ] = length[x1][y1] + 1;
          right++;
          stay[right][1] = x1 + dx[j];
          stay[right][2] = y1 + dy[j];
        }
      }
    left++;
    for (int i = 0; i <= right - left; i++)
    {
      stay[i][1] = stay[i + left][1];
      stay[i][2] = stay[i + left][2];
    }
    right = right - left;
    left = 0;
  }
  return;
}

int judge(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act, int x, int y) //�������·�������
{
  for (int i = 0; i < 200; i++)
    for (int j = 0; j < 3; j++)
    stay[i][j] = 0;
  Make_Map(map, ginfo, rinfo, act, point.x, point.y);
  if (x == point.x && y == point.y ) return -1;
  for (int j = 0; j < 4; j++)
    if (x + dx[j] < 31 && x + dx[j] >= 0 && y + dy[j] < 31 && y + dy[j] >= 0)
      if (length[ x + dx[j] ][ y + dy[j] ] == length[x][y] - 1) return j;
  return -1;
}

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
  Player my_player;  
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  flag++;
  int toward;
  if (flag == 1)
  {
    for (int i = 0; i < 31; i++)
      for (int j = 0; j < 31; j++)
        reach[i][j] = 0;
  }
  for (int i = 0; i < 31; i++)
    for (int j = 0; j < 31; j++)
    {
      length[i][j] = 1000;
      if (map.grids[i][j].terrain == 1)
        reach[i][j] = 1;
      if (map.grids[i][j].mine_id != -1)
      {
        point.x = i;
        point.y = j;
      } 
    }
  length[ point.x ][ point.y ] = 0;  //���·Դ��Ϊ�Ǹ����
  toward = judge(map, ginfo, rinfo, act, my_player.pos.x, my_player.pos.y);
  act.move = (Action::Move)(toward + 1);
  return;
}

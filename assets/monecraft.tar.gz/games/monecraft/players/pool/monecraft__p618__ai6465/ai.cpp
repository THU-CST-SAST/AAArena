#include "sdk.h"
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cstdio>
#include <fstream>
using namespace std;

extern int GetDis(Position ,Position );

int gl,dis[35][35],gpre[35][35],MaxRound=10,nowRound,Blink_Cd=20;
bool _in[35][35];
Position gg[100011];
bool Is_Blink=false;
Position Blinkp;

struct Mymap
{
	int dat[35][35];
	Mymap()
	{
		memset(dat,-1,sizeof(dat));
	}
	void update(int _x,int _y,int _z)
	{
		dat[_x][_y]=_z;
	}
}bmap;
struct MineNode
{
	int no,dis,level;
};
struct Mymine
{
	int len;
	MineNode dat[100],tmp;
	public:
	void Init(RoundInfo& rinfo)
	{
		len=rinfo.mines.size();
		for (int i=0;i<len;++i)
			dat[i].no=i,dat[i].level=0;
	}
	void Update(Player& me,RoundInfo& rinfo)
	{
		Position tmp;
		for (int i=0;i<len;++i)
		{
			int u=dat[i].no;
			tmp=rinfo.mines[u].pos;
			dat[i].dis=dis[tmp.x][tmp.y];
			if (dat[i].dis < rinfo.mines[u].protect_round)
				dat[i].dis=rinfo.mines[u].protect_round;

			if (rinfo.mines[u].owner == me.owner)
				dat[i].level=1;
			else
			{
				if (rinfo.mines[u].owner != -1)
					dat[i].dis+=5;	
				dat[i].level=0;
			}
			if (dat[i].dis < 0) dat[i].level=2;
		}
	}
	void Sort()
	{
		int i,j,k;
		for (i=0;i<len;++i)
		{
			k=i;
			for (j=i+1;j<len;++j)
				if (MyPd(j,k)) k=j;
			if (k!=i)
				tmp=dat[i],dat[i]=dat[k],dat[k]=tmp;
		}
	}
	private:
	bool MyPd(int u,int v)
	{
		return (dat[u].level < dat[v].level || (dat[u].level == dat[v].level && dat[u].dis < dat[v].dis));
	}
}bmine;

int GetDis(Position st,Position dt)
{
	int dx=dt.x-st.x,dy=dt.y-st.y;
	if (dx < 0) dx=-dx;
	if (dy < 0) dy=-dy;
	return (dx+dy);
}

bool Pd(int x,int y,int z)
{
	if (x < 0 || x > 30) return false;
	if (y < 0 || y > 30) return false;
	return (bmap.dat[x][y] != 1 && (dis[x][y] < 0 || dis[x][y] > z));
}

void Push(int x,int y,int z,int p)
{
	if (_in[x][y] == 0)
	{
		gg[++gl]=Position(x,y);
		_in[x][y]=true;
	}
//printf("%d %d : %d %d\n",p,_in[x][y],dis[x][y],z);
	dis[x][y]=z;
	gpre[x][y]=p;
}

void Bfs(Position st)
{	
	memset(dis,-1,sizeof(dis));
	memset(_in,0,sizeof(_in));
	memset(gpre,0,sizeof(gpre));
	dis[st.x][st.y]=0;
	gg[gl=1]=st;
	_in[st.x][st.y]=true;

	Position now;
	for (int i=1;i<=gl;++i)
	{
		now=gg[i];
		if (Pd(now.x-1,now.y,dis[now.x][now.y]+1))
			Push(now.x-1,now.y,dis[now.x][now.y]+1,i);
		if (Pd(now.x+1,now.y,dis[now.x][now.y]+1))
			Push(now.x+1,now.y,dis[now.x][now.y]+1,i);
		if (Pd(now.x,now.y-1,dis[now.x][now.y]+1))
			Push(now.x,now.y-1,dis[now.x][now.y]+1,i);
		if (Pd(now.x,now.y+1,dis[now.x][now.y]+1))
			Push(now.x,now.y+1,dis[now.x][now.y]+1,i);
		for (int j=-2;j<=2;++j)
			for (int k=-2;k<=2;++k)
				if (Pd(now.x+j,now.y+k,dis[now.x][now.y]+Blink_Cd))
					Push(now.x+j,now.y+k,dis[now.x][now.y]+Blink_Cd,i);
		_in[now.x][now.y]=false;
	}
}

// one mine last 50 rounds at most
void UpdateMine(Player& me,RoundInfo& rinfo)
{
	Bfs(me.pos);
	if (rinfo.round == 0)
	{
		bmine.Init(rinfo);
		bmine.Update(me,rinfo);
		bmine.Sort();
		nowRound=0;
	}
	++nowRound;
	if (rinfo.mines[bmine.dat[0].no].owner == me.owner)
	{
		bmine.Update(me,rinfo);
		bmine.Sort();
		nowRound=0;
	}
	if (nowRound > MaxRound)
	{
		bmine.Update(me,rinfo);
		bmine.Sort();
		nowRound=0;
	}
}

Position Calc(Player& me,Mine& u)
{
	Position dt=u.pos;
	if (me.pos == dt && me.owner != u.owner)
		return me.pos;
	
	Bfs(dt);
	Position next,tmp;	
	int minc=10000;
	
	if (me.blink_cd == 0)
	{
		for (int i=-2;i<=2;++i)
			for (int j=-2;j<=2;++j)
			{
				tmp=Position(me.pos.x+i,me.pos.y+j);
				if (tmp.x < 0 || tmp.x > 30) continue;
				if (tmp.y < 0 || tmp.y > 30) continue;
				if (dis[tmp.x][tmp.y] < 0) continue;
				if (dis[tmp.x][tmp.y] < minc)
				{
					minc=dis[tmp.x][tmp.y];
					next=tmp;
				}
			}
	}
	else
	{
    	const int dx[] = {0,-1,0,1};
	    const int dy[] = {1,0,-1,0};
		for (int i=0;i<4;++i)
		{
			tmp=Position(me.pos.x+dx[i],me.pos.y+dy[i]);
			if (tmp.x < 0 || tmp.x > 30) continue;
			if (tmp.y < 0 || tmp.y > 30) continue;
			if (dis[tmp.x][tmp.y] < 0) continue;
			if (dis[tmp.x][tmp.y] < minc)
			{
				minc=dis[tmp.x][tmp.y];
				next=tmp;
			}
		}
	}
/*
printf("%d %d ; %d %d\n",me.pos.x,me.pos.y,next.x,next.y);
*/
	return next;
}

void MyMove(Player& ii,Position dt,Action& act)
{
	Position me=ii.pos;
	extern Mymap bmap;
	if (me == dt) act.move=(Action::Move)(0);
	if (me.x - dt.x == 1 && me.y == dt.y) act.move=(Action::Move)(2); else 
   	if (dt.x - me.x == 1 && me.y == dt.y) act.move=(Action::Move)(4); else
	if (me.y - dt.y == 1 && me.x == dt.x) act.move=(Action::Move)(3); else
	if (dt.y - me.y == 1 && me.x == dt.x) act.move=(Action::Move)(1); else
	{
		act.move=(Action::Move)(5);
		act.blink_pos=Position(dt.x,dt.y);
	}
}

void MyPP(Position& u)
{
	printf("%d %d\n",u.x,u.y);
}

void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
    const int dx[] = {0,-1,0,1};
    const int dy[] = {1,0,-1,0};
    Player my_player;
    for (int i = 0; i < rinfo.players.size(); ++i)
    {
    	if (rinfo.players[i].owner == rinfo.player_id)
    	{
	        my_player = rinfo.players[i];
	        break;
	    }
    }
    // update map
    for (int i=0;i<=30;++i)
	    for (int j=0;j<=30;++j)
		    if (map.grids[i][j].terrain	== 0)
				bmap.update(i,j,0);
  		    else
		    if (map.grids[i][j].terrain == 1)
			    bmap.update(i,j,1);
	if (Is_Blink)
	{
		if (!(my_player.pos == Blinkp))
			bmap.dat[Blinkp.x][Blinkp.y]=1;
	}

	act.setOB=0;
act.buy_protect=0;
	UpdateMine(my_player,rinfo);
	MyMove(my_player,Calc(my_player,rinfo.mines[bmine.dat[0].no]),act);
	if (act.move == 5) Is_Blink=true,Blinkp=act.blink_pos;
/*
MyPP(my_player.pos);
MyPP(rinfo.mines[bmine.dat[0].no].pos);
printf("%d\n",act.move);
MyPP(act.blink_pos);
for (int i=0;i<bmine.len;++i)
	printf("%d ",bmine.dat[i].no);
puts("");
for (int i=0;i<bmine.len;++i)
	printf("%d ",bmine.dat[i].dis);
puts("");
for (int i=0;i<bmine.len;++i)
	printf("%d ",bmine.dat[i].level);
puts("");
*/

}

#include "sdk.h"
#include <cstring>

using namespace std;

const int dx[] = {0, -1, 0, 1};
const int dy[] = {1, 0, -1, 0};
const int MAX_CD = 5 + 6 * 3 + 1;
const int W = 1;

Map minfo;
int my_mine_num;
int my_ob_num;
int my_own_point;
int mine_num;

Player my_player, en_player;
int en_pos_range;
RoundInfo my_round;

bool en_in_view;
int cd_lim;
int round_id;
int mine_mark[MAX_MINE_NUM];
int mine_cold[MAX_MINE_NUM];

int evaluation[MAX_MINE_NUM][MAP_WIDTH][MAP_HEIGHT];
Position spfa[MAP_WIDTH *MAP_HEIGHT * 100];
bool in_spfa[MAP_WIDTH][MAP_HEIGHT];

struct Tnode
{
    int x, y, c, dis, lx, ly, lc;
    Tnode () {}
    Tnode (int cx, int cy, int cc, int cd) :
        x(cx), y(cy), c(cc), dis(cd), lx(0), ly(0), lc(0) {}
} node[MAP_WIDTH][MAP_HEIGHT][MAX_CD], * queue[MAP_WIDTH *MAP_HEIGHT *MAX_CD];

class Statistics
{
private:
    int last_mine_owner[MAX_MINE_NUM];
    int mine_occupied_times[MAX_MINE_NUM];
    int grid_stay_times[MAP_WIDTH][MAP_HEIGHT];
    bool in_centre[MAP_WIDTH][MAP_HEIGHT];
    enum limit { OBlimit = 2 };
public:

    Statistics()
    {
        for (int i = 0; i < MAX_MINE_NUM; ++i)
            last_mine_owner[i] = -1;
        memset(in_centre, 0, sizeof in_centre);
        for (int i = 10; i <= 20; ++i)
            for (int j = 10; j <= 20; ++j)
                in_centre[i][j] = true;
    }

    void gather_statistics()
    {
        for (int i = 0; i < mine_num; ++i)
            mine_occupied_times[i] += my_round.mines[i].owner == en_player.owner &&
                                      last_mine_owner[i] != en_player.owner;
        if (en_in_view)
            ++grid_stay_times[en_player.pos.x][en_player.pos.y];

        for (int i = 0; i < mine_num; ++i)
            last_mine_owner[i] = my_round.mines[i].owner;
    }

    bool set_protect(Mine &lmine);
    bool set_observe();

} STA;

inline int abs(int x)
{
    return x >= 0 ? x : -x;
}

inline int m_distance(Position A, Position B)
{
    return abs(A.x - B.x) + abs(A.y - B.y);
}

inline bool in_range(int x, int y)
{
    return x >= 0 && y >= 0 && x < MAP_WIDTH && y < MAP_HEIGHT;
}

inline bool is_FLAT(int x, int y)
{
    return minfo.grids[x][y].terrain == MapGrid::FLAT;
}

inline bool is_BLOCK(int x, int y)
{
    return minfo.grids[x][y].terrain == MapGrid::BLOCK;
}

inline bool is_unseen(int x, int y)
{
    return minfo.grids[x][y].terrain == MapGrid::UNSEEN;
}

inline bool en_in(Position pos)
{
    return en_in_view && en_player.pos == pos;
}

bool is_border(int x, int y)
{
    for (int i = 0; i < 4; ++i)
        if (in_range(x + dx[i], y + dy[i]) && is_unseen(x + dx[i], y + dy[i]))
            return true;
    return false;
}

bool is_mine(int x, int y, int u) // u = 0 for a mine not belonging to me
{
    for (int i = 0; i < mine_num; ++i)
        if (my_round.mines[i].pos == Position(x, y) 
            && (u || !(mine_mark[i] || mine_cold[i])))
            return true;
    return false;
}

int f_distance(int x, int y, int dis)
{
    int minf = 0x7FFFFFFF;
    for (int i = 0; i < mine_num; ++i)
        if (!(mine_mark[i] || mine_cold[i]))
        {
            int tmp = evaluation[i][x][y] + dis;
            if (my_round.mines[i].protect_round > tmp)
                tmp = my_round.mines[i].protect_round;
            minf = min(minf, tmp);
        }
    return minf;
}

bool Statistics::set_protect(Mine &lmine)
{
    int cnt = 0;
    for (int i = 0; i < mine_num; ++i)
        if (mine_occupied_times[i] > mine_occupied_times[lmine.id])
            ++cnt;
    return cnt <= 1;
}

bool Statistics::set_observe()
{
    int x = my_player.pos.x, y = my_player.pos.y, cnt = 0;
    if (my_ob_num == OBlimit || !grid_stay_times[x][y] || !in_centre[x][y])
        return false;

    for (int i = 0; i < 4; ++i)
    {
        x = my_player.pos.x, y = my_player.pos.y;
        while (in_range(x, y) && is_FLAT(x, y))
        {
            x += dx[i], y += dy[i], ++cnt;    
            for (int j = 0; j < my_round.observers.size(); ++j)
                if (my_round.observers[j].pos == Position(x, y))
                    return false;       
        }
    }

    return cnt > 10;
}

void player_init(RoundInfo &rinfo)
{
    en_in_view   = false;
    cd_lim   = BLINK_CD_INIT + BLINK_RATE * my_mine_num;
    my_round = rinfo;
    round_id = rinfo.round;

    for (int i = 0; i < rinfo.players.size(); ++i)
        if (rinfo.players[i].owner == rinfo.player_id)
            my_player = rinfo.players[i];
        else
            en_player = rinfo.players[i], en_in_view = true;

    en_pos_range = en_in_view ? 0 : en_pos_range + 1;

    my_ob_num = 0;
    for (int i = 0; i < my_round.observers.size(); ++i)
        my_ob_num += my_round.observers[i].owner == my_player.owner;
}

void import_map_info(Map &map)
{
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            if (map.grids[i][j].terrain != MapGrid::UNSEEN
                    && minfo.grids[i][j].terrain == MapGrid::UNSEEN)
                minfo.grids[i][j].terrain = map.grids[i][j].terrain;
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            if (minfo.grids[i][j].terrain != MapGrid::UNSEEN)
                minfo.grids[MAP_WIDTH - i - 1][MAP_HEIGHT - j - 1].terrain = minfo.grids[i][j].terrain;
}


void update_mine_info(RoundInfo &rinfo)
{
    mine_num = rinfo.mines.size();
    my_mine_num = 0;

    memset(mine_mark, 0, sizeof mine_mark);
    for (int i = 0; i < rinfo.mines.size(); ++i)
        if (rinfo.mines[i].owner == my_player.owner)
            ++my_mine_num, mine_mark[i] = true;

    for (int i = 0; i < mine_num; ++i)
        mine_cold[i] -= mine_cold[i] ? 1 : 0;
}

int mindis_of_another_mine(int k)
{
    int res = 0x7FFFFFFF;

    for (int i = 0; i < mine_num; ++i)
        for (int c = 0; c <= max(my_player.blink_cd, cd_lim); ++c)
            if (i != k && !mine_mark[i] && !mine_cold[i])
            {
                Position pos = my_round.mines[i].pos;
                res = min(res, node[pos.x][pos.y][c].dis);
            }
    return min(res, 30);
}

bool is_mine_stop(Action &act)
{
    int lm_id = minfo.grids[my_player.pos.x][my_player.pos.y].mine_id;

    if (lm_id != -1)
    {
        Mine lmine;
        for (int i = 0; i < mine_num; ++i)
            if (my_round.mines[i].id == lm_id)
                lmine = my_round.mines[i];
        if (!my_own_point)
            my_own_point = 5 * lmine.own_point;

        if (lmine.protect_round)
            return false;

        if (lmine.owner == en_player.owner && my_player.pos == en_player.pos)
            {
                mine_cold[lmine.id] = mindis_of_another_mine(lmine.id);
                return false;
            }

        if (abs(my_own_point - lmine.own_point) > 1)
            return act.move = Action::Stop, true;

         if (abs(my_own_point - lmine.own_point) == 1 && en_in(lmine.pos))
        {
            act.move = Action::Stop;
            act.buy_protect = true;
            return true;
        }
        if (abs(my_own_point - lmine.own_point) <= 1)
        {
            mine_mark[lmine.id] = 1;
            int mindis = m_distance(en_player.pos, my_player.pos) - en_pos_range;
            if (mindis < 15 || (mindis < 30 && STA.set_protect(lmine)))
                act.buy_protect = true;
        }
    }

    return false;
}

void queue_push_back(Tnode &new_node, Tnode *p, int &tail)
{
    queue[++tail] = & new_node;
    new_node.dis  = p->dis + 1;
    new_node.lx   = p->x;
    new_node.ly   = p->y;
    new_node.lc   = p->c;
}

void BFS()
{
    int head = 0, tail = 0, x = my_player.pos.x, y = my_player.pos.y, c;
    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            for (int k = 0; k <= max(cd_lim, my_player.blink_cd); ++k)
                node[i][j][k] = Tnode(i, j, k, 0x7FFFFFFF);
    node[x][y][my_player.blink_cd].dis = 0;
    queue[0] = &node[x][y][my_player.blink_cd];

    for (; head <= tail; ++head)
    {
        Tnode *p = queue[head];
        c = p->c ? p->c - 1 : 0;

        if (node[p->x][p->y][c].dis == 0x7FFFFFFF)
            queue_push_back(node[p->x][p->y][c], p, tail);
        for (int i = 0; i < 4; ++i)
        {
            x = p->x + dx[i];
            y = p->y + dy[i];
            if (in_range(x, y) && is_FLAT(x, y) && node[x][y][c].dis == 0x7FFFFFFF)
                queue_push_back(node[x][y][c], p, tail);
        }

        if (!p->c)
        {
            for (int i = -2; i <= 2; ++i)
                for (int j = -2; j <= 2; ++ j)
                {
                    x = p->x + i, y = p->y + j, c = cd_lim;
                    if (in_range(x, y) && is_FLAT(x, y) && node[x][y][c].dis == 0x7FFFFFFF)
                        queue_push_back(node[x][y][c], p, tail);
                }
        }
    }
}

void calc_evaluation(RoundInfo &rinfo)
{
    memset(evaluation, 1, sizeof evaluation);
    for (int k = 0; k < rinfo.mines.size(); ++k)
    {
        int head = 0, tail = 0;
        evaluation[k][rinfo.mines[k].pos.x][rinfo.mines[k].pos.y] = 0;
        spfa[0] = rinfo.mines[k].pos;

        for ( ; head <= tail; ++head)
        {
            MapGrid::Terrain trn = minfo.grids[spfa[head].x][spfa[head].y].terrain;
            for (int i = 0; i < 4; ++i)
            {
                int x = spfa[head].x + dx[i], y = spfa[head].y + dy[i];
                if (in_range(x, y))
                {
                    int d = evaluation[k][spfa[head].x][spfa[head].y];
                    switch (minfo.grids[x][y].terrain)
                    {
                    case MapGrid::FLAT:   d += 1; break;
                    case MapGrid::UNSEEN: d += 2; break;
                    case MapGrid::BLOCK:  d += (int) trn ? 30 : 3;
                    }

                    if (evaluation[k][x][y] > d)
                    {
                        evaluation[k][x][y] = d;
                        if (!in_spfa[x][y])
                        {
                            spfa[++tail] = Position(x, y);
                            in_spfa[x][y] = true;
                        }
                    }
                }
            }
            in_spfa[spfa[head].x][spfa[head].y] = false;
        }
    }
}

void decision(Action &act, int x, int y, int c)
{
    for ( ; node[x][y][c].dis > 1; )
    {
        Tnode tmp = node[x][y][c];
        x = tmp.lx, y = tmp.ly, c = tmp.lc;
    }
    if (c == cd_lim && !my_player.blink_cd)
    {
        act.move = Action::Blink;
        act.blink_pos = Position(x, y);
    }
    else
        for (int i = 0; i < 4; ++i)
            if (x == my_player.pos.x + dx[i] && y == my_player.pos.y + dy[i])
            {
                act.move = Action::Move(i + 1);
                return;
            }
}

bool defence(Action &act, int nowf)
{
    if (!en_in_view)
        return false;
    for (int i = 0; i < my_round.mines.size(); ++i)
        if (mine_mark[i] && m_distance(en_player.pos, my_round.mines[i].pos) <= 1)
        {
            Position mp = my_round.mines[i].pos;
            int res = 0x7FFFFFFF, lc;
            for (int c = 0; c <= max(cd_lim, my_player.blink_cd); ++c)
                if (res > node[mp.x][mp.y][c].dis)
                {
                    res = node[mp.x][mp.y][c].dis;
                    lc = c;
                }
            if (my_round.mines[i].protect_round >= 10)
                return false;
            if (res < 5 + m_distance(en_player.pos, my_round.mines[i].pos) && res < nowf + 5)
            {
                decision(act, mp.x, mp.y, lc);
                return true;
            }
        }
    return false;
}

void search_opt_grid(Action &act, GameInfo &ginfo)
{
    int minf = 0x7FFFFFFF, lx = -1, ly = -1, lc;

    for (int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            for (int k = 0; k <= max(cd_lim, my_player.blink_cd); ++k)
                if (node[i][j][k].dis < 0x7FFFFFFF && (is_border(i, j) || is_mine(i, j, 0)))
                {
                    int nowf = f_distance(i, j, node[i][j][k].dis);
                    if (nowf < minf || (nowf == minf && k < lc))
                        minf = nowf, lx = i, ly = j, lc = k;
                }

    if (defence(act, minf))
        return;

    if (STA.set_observe() && ginfo.golds[my_player.owner] > ginfo.golds[en_player.owner])
        act.setOB = true;
    if (lx >= 0)
        decision(act, lx, ly, lc);
    else
    {
        int i = en_player.pos.x, j = en_player.pos.y;
        for (int k = 0; k <= max(cd_lim, my_player.blink_cd); ++k)
            if (node[i][j][k].dis < 0x7FFFFFFF)
            {
                int nowf = f_distance(i, j, node[i][j][k].dis);
                if (nowf < minf || (nowf == minf && k < lc))
                    minf = nowf, lx = i, ly = j, lc = k;
            }
        decision(act, lx, ly, lc);
    }
}

bool follow(GameInfo &ginfo, Action &act)
{
    if (!en_in_view)
        return false;
    if (m_distance(my_player.pos, en_player.pos) > 3)
        return false;

    int mcnt = ginfo.mine_num[my_player.owner];
    int ecnt = ginfo.mine_num[en_player.owner];
    if (mcnt < 3)
        return false;
    if (mcnt > ecnt || (mcnt == ecnt && ginfo.golds[my_player.owner] - ginfo.golds[en_player.owner] > 0))
    {
        int tmp = 0x7FFFFFFF, lc;
        if (my_player.pos == en_player.pos)
            return act.move = Action::Stop, true;
        for (int i = 0; i < 4; ++i)
            if (Position(my_player.pos.x + dx[i], my_player.pos.y + dy[i]) == en_player.pos)
            {
                act.move = Action::Move(i + 1);
                return true;
            }
        if (my_player.blink_cd == 0)
            for (int i = -2; i <= 2; ++i)
                for (int j = -2; j <= 2; ++j)
                    if (Position(my_player.pos.x + i, my_player.pos.y + j) == en_player.pos)
                    {
                        act.move = Action::Blink;
                        act.blink_pos = en_player.pos;
                        return true;
                    }
    }
    return false;
}

void player_ai(Map &map, GameInfo &ginfo, RoundInfo &rinfo, Action &act)
{
    static int first_into = 1;
    if (first_into)
    {
        first_into = 0;
        minfo = map;
    }

    player_init(rinfo);
    import_map_info(map);
    update_mine_info(rinfo);
    STA.gather_statistics();

    if (is_mine_stop(act))
        return;

    BFS();

    calc_evaluation(rinfo);

    if (follow(ginfo, act))
        return;

    search_opt_grid(act, ginfo);
}
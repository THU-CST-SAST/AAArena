#include "sdk.h"
#include "stdlib.h"
#include <ctime>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	static Position last(-1,-1);
	static int mine_index = -1;
	const int dx[] = {0,-1,0,1};
	const int dy[] = {1,0,-1,0};
	Player my_player;
	for (int i = 0; i < rinfo.players.size(); ++i)
	{
		if (rinfo.players[i].owner == rinfo.player_id)
		{
			my_player = rinfo.players[i];
			break;
		}
	}
	for (int i = 0; i < rinfo.mines.size(); i++)
	{
		if (rinfo.mines[i].pos == my_player.pos)
		{
			if (rinfo.mines[i].owner != my_player.owner)
			{
				act.move = Action::Stop;
				return;
			} else break;
		}
	}
	Position next_pos;
	if(mine_index != -1 && rinfo.mines[mine_index].owner != my_player.owner)
	{
		if (my_player.blink_cd==0 &&
			 (abs(my_player.pos.x - rinfo.mines[mine_index].pos.x) < 3 && abs(my_player.pos.y - rinfo.mines[mine_index].pos.y) < 3))
		{
			act.move = (Action::Move)5;
			next_pos = rinfo.mines[mine_index].pos;
			act.blink_pos = next_pos;
			last = my_player.pos;
			return;
		}
		else
		{
			// move
			if(my_player.pos.x < rinfo.mines[mine_index].pos.x)
			{
				next_pos.x = my_player.pos.x + 1;
				next_pos.y = my_player.pos.y;
				if (map.grids[next_pos.x][next_pos.y].terrain == MapGrid::FLAT)
				{
					act.move = (Action::Move)(4);
					last = my_player.pos;
					return;
				}
				
			}
			if(my_player.pos.x > rinfo.mines[mine_index].pos.x)
			{
				next_pos.x = my_player.pos.x - 1;
				next_pos.y = my_player.pos.y;
				if (map.grids[next_pos.x][next_pos.y].terrain == MapGrid::FLAT)
				{
					act.move = (Action::Move)(2);
					last = my_player.pos;
					return;
				}
			}
			if(my_player.pos.y < rinfo.mines[mine_index].pos.y)
			{
				next_pos.x = my_player.pos.x;
				next_pos.y = my_player.pos.y + 1;
				if (map.grids[next_pos.x][next_pos.y].terrain == MapGrid::FLAT)
				{
					act.move = (Action::Move)(1);
					last = my_player.pos;
					return;
				}
			}
			if(my_player.pos.y < rinfo.mines[mine_index].pos.y)
			{
				next_pos.x = my_player.pos.x;
				next_pos.y = my_player.pos.y - 1;
				if (map.grids[next_pos.x][next_pos.y].terrain == MapGrid::FLAT)
				{
					act.move = (Action::Move)(3);
					last = my_player.pos;
					return;
				}
			}
		}
	}
	else
	{
		int mini_distance = 0;
		for (int i = 0; i < rinfo.mines.size(); i++)
		{
			if (rinfo.mines[i].owner == my_player.owner) continue;
			int distance = abs(my_player.pos.x - rinfo.mines[i].pos.x) + abs(my_player.pos.y - rinfo.mines[i].pos.y);
			if (mini_distance <= distance) continue;
			mini_distance = distance;
			mine_index = i;
		}
		// move
	}
	return;
//	int next = -1;
//	for (int i = 0; i < 4; ++i)
//	{
//		next_pos.x = my_player.pos.x + dx[i];
//		next_pos.y = my_player.pos.y + dy[i];
//		if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
//		{
//			next = i;
//			break;
//		}
//	}
//	if (next >= 0)
//	{
//		//cout << dx[next] << ' ' << dy[next] << endl;
//		act.move = (Action::Move)(next+1);
//	}
//	else
//		act.move = (Action::Move)(time(0) % 5);
//	last = my_player.pos;
}


#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include"sdk.h"

using namespace std;

//==================================================Constant==================================================//

const int Inf = 100000000;
const int dx[5] = { 0 , 0 , -1 , 0 , 1 };
const int dy[5] = { 0 , 1 , 0 , -1 , 0 };
const int MAX_MINES = 6 , MAX_CD = 30;
const int SEARCH_STEPS = 300 , SEARCH_STATES = 2000 , SEARCH_MAX_COST = 10;
const int CRITICAL_ROUND = 80 , CRITICAL_DIFF = 10;
const int MINE_TIME = 5 , ANTI_PRO_TIME = 5 , PRO_MIN_TIME = 15;
const int ITERATE_DEEP = 3;
const int PRO_REINFORCE = 8;
const int MINE_COME_HOME = 15;
const int FOLLOW_STEP = 3 , FOLLOW_SPAN = 10 , FOLLOW_STD = 7;
const int DISTURB_MAX_WASTE = 8;
const int ANTI_FOLLOW_DIST = 8 , ANTI_FOLLOW_OPTION = 20;
const int NEAR_ENOUGH = 6;

//==================================================Type Definition==================================================//

struct Assess {
	int step , cd;
	bool operator < ( Assess &B ) { return step < B.step || ( step == B.step && cd < B.cd ); }
	bool operator > ( Assess &B ) { return step > B.step || ( step == B.step && cd > B.cd ); }
	bool operator == ( Assess &B ) { return step == B.step && cd == B.cd; }
	Assess() {}
	Assess( int input_step , int input_cd ) : step( input_step ) , cd( input_cd ) {}
};

struct State {
	int id;
	Position pos;
	Assess ass;
	Action act;
	bool operator < ( State &B ) { return ass < B.ass; }
	bool operator > ( State &B ) { return ass > B.ass; }
	bool operator == ( State &B ) { return ass == B.ass; }
	State() {}
	State( Position input_pos , Assess input_ass , Action input_act ) : pos( input_pos ) , ass( input_ass ) , act( input_act ) {}
};

struct Queue {
	int tot;
	State sta[SEARCH_STATES];
};

struct Extend_map {
	int known , sur_N;
	Position sur[MAP_WIDTH * MAP_HEIGHT];
	int cost[MAP_WIDTH][MAP_HEIGHT];
	int cont[MAP_WIDTH][MAP_HEIGHT];
};

struct Extend_player {
	int mines , OBs , M_cd;
	int avail[MAX_MINES];
	int G_n; State G[MAX_MINES];
	int I_n; State I[MAX_MINES];
};

struct History {
	Position mys_track , opp_track;
	bool followed;
};

//==================================================Variable==================================================//

Map map , cur_map;
GameInfo ginfo;
RoundInfo rinfo;
Player mys , opp;
Extend_map E_map;
Extend_player E_mys , E_opp;
int Observed = -1;
Position Anti_follow_aim( -1 , -1 );
bool Rushed , Followed , In_mine;
History history[GAME_ROUND];
Queue Q[SEARCH_STEPS];
int F[MAX_CD][MAP_WIDTH][MAP_HEIGHT];

//==================================================Fundamental Fuction==================================================//

int Sur_money() {
	return ginfo.golds[rinfo.player_id] - ginfo.golds[rinfo.player_id ^ 1];
}

int Sur_mines() {
	return ginfo.mine_num[rinfo.player_id] - ginfo.mine_num[rinfo.player_id ^ 1];
}

bool Super() {
	if ( Sur_mines() != 0 ) return Sur_mines() > 0;
	return Sur_money() > 0;
}

bool Inside( Position P ) {
	return 0 <= P.x && P.x < MAP_WIDTH && 0 <= P.y && P.y < MAP_HEIGHT;
}

bool Legal( Position P ) {
	return Inside( P ) && map.grids[P.x][P.y].terrain != MapGrid::BLOCK;
}

bool Strict_legal( Position P ) {
	return Inside( P ) && map.grids[P.x][P.y].terrain == MapGrid::FLAT;
}

Action Load_act( int d , Position P ) {
	Action ret;
	ret.move = ( Action::Move ) ( d );
	ret.blink_pos = P;
	return ret;
}

Action Load_act( int d ) {
	Action ret;
	ret.move = ( Action::Move ) ( d );
	return ret;
}

int Mine_owner( int id ) {
	Mine &this_mine = rinfo.mines[id];
	if ( this_mine.owner == -1 ) {
		if ( abs( this_mine.own_point ) == 4 ) {
			if ( mys.pos == this_mine.pos && !( opp.pos == this_mine.pos ) ) return 1;
			if ( opp.pos == this_mine.pos && !( mys.pos == this_mine.pos ) ) return 0;
		}
		return -1;
	}
	if ( this_mine.owner == rinfo.player_id ) return 1;
	return 0;
}

int Occupy_time( int id ) {
	if ( Mine_owner( id ) == -1 ) return MINE_TIME - abs( rinfo.mines[id].own_point );
	return MINE_TIME + abs( rinfo.mines[id].own_point );
}

int Manha_dist( Position A , Position B ) {
	return abs( A.x - B.x ) + abs( A.y - B.y );
}

int Minxy_dist( Position A , Position B ) {
	return min( abs( A.x - B.x ) , abs( A.y - B.y ) );
}

//==================================================Preparation==================================================//

void Extend_map() {
	if ( rinfo.round == 0 ) map = cur_map;
	
	for ( int i = 0 ; i < MAP_WIDTH ; i++ )
		for ( int j = 0 ; j < MAP_HEIGHT ; j++ )
			if ( cur_map.grids[i][j].terrain != MapGrid::UNSEEN )
				map.grids[MAP_WIDTH - 1 - i][MAP_HEIGHT - 1 - j].terrain = map.grids[i][j].terrain = cur_map.grids[i][j].terrain;
	
	E_map.known = 0;	
	for ( int i = 0 ; i < MAP_WIDTH ; i++ )
		for ( int j = 0 ; j < MAP_HEIGHT ; j++ )
			if ( map.grids[i][j].terrain != MapGrid::UNSEEN ) E_map.known++;
}

void Assess_map_cost() {
	for ( int i = 0 ; i < MAP_WIDTH ; i++ )
		for ( int j = 0 ; j < MAP_HEIGHT ; j++ ) {
			if ( map.grids[i][j].terrain == MapGrid::BLOCK ) E_map.cost[i][j] = Inf;
			if ( map.grids[i][j].terrain == MapGrid::FLAT ) E_map.cost[i][j] = 1;
			if ( map.grids[i][j].terrain == MapGrid::UNSEEN ) {
				int df_centre = min( abs( i - MAP_WIDTH / 2 ) , abs( j - MAP_HEIGHT ) );
				int df_mines = Inf;
				for ( int k = 0 ; k < MAX_MINES ; k++ )
					df_mines = min( df_mines , min( abs( i - rinfo.mines[k].pos.x ) , abs( j - rinfo.mines[k].pos.y ) ) );
				
				if ( df_centre <= 10 || df_mines <= 4 ) E_map.cost[i][j] = 2; else E_map.cost[i][j] = 3;
				if ( rinfo.round >= CRITICAL_ROUND ) E_map.cost[i][j]--;
			}
		}
}

void Assess_map_cont() {
	E_map.sur_N = 0;
	
	for ( int i = 0 ; i < MAP_WIDTH ; i++ )
		for ( int j = 0 ; j < MAP_HEIGHT ; j++ )
			if ( map.grids[i][j].terrain == MapGrid::FLAT && Manha_dist( mys.pos , Position( i , j ) ) >= ANTI_FOLLOW_DIST ) {
				int df_mys = Inf , df_opp = Inf;
				for ( int k = 0 ; k < MAX_MINES ; k++ ) {
					int dist = Manha_dist( Position( i , j ) , rinfo.mines[k].pos );
					if ( Mine_owner( k ) == 1 ) df_mys = min( df_mys , dist );
					if ( Mine_owner( k ) == 0 ) df_opp = min( df_opp , dist );
				}
				E_map.cont[i][j] = df_mys - df_opp;
				E_map.sur[E_map.sur_N++] = Position( i , j ); 
			}
}

void Observe_opp() {
	opp.blink_cd = 0;
	
	if ( rinfo.round == 0 ) {
		Observed = rinfo.round;
		opp.pos = Position( MAP_WIDTH - 1 - mys.pos.x , MAP_HEIGHT - 1 - mys.pos.y );
	}
	
	for ( int i = 0 ; i < MAP_WIDTH ; i++ )
		for ( int j = 0 ; j < MAP_HEIGHT ; j++ )
			for ( int k = 0 ; k < ( int ) cur_map.grids[i][j].players.size() ; k++ )
				if ( cur_map.grids[i][j].players[k] != rinfo.player_id ) {
					Observed = rinfo.round;
					opp.pos = Position( i , j );
				}
	
	history[rinfo.round].mys_track = mys.pos;
	history[rinfo.round].opp_track = Position( -1 , -1 );
	if ( Observed == rinfo.round ) {
		history[rinfo.round].opp_track = opp.pos;
		
		for ( int i = max( 0 , rinfo.round - FOLLOW_STEP ) ; i < rinfo.round ; i++ )
			if ( opp.pos == history[i].mys_track && !( In_mine && opp.pos == mys.pos ) ) {
				history[rinfo.round].followed = true;
				break;
			}
	}
	
	Followed = false;
	if ( rinfo.round - FOLLOW_SPAN + 1 >= 0 ) {
		int cnt = 0;
		for ( int i = rinfo.round - FOLLOW_SPAN + 1 ; i <= rinfo.round ; i++ )
			if ( history[i].followed ) cnt++;
		if ( cnt >= FOLLOW_STD ) Followed = true;
	}
}

void Caln_mines() {
	E_mys.mines = E_opp.mines = 0;
	In_mine = false;
	
	for ( int i = 0 ; i < MAX_MINES ; i++ ) {
		if ( mys.pos == rinfo.mines[i].pos ) In_mine = true;
		if ( Mine_owner( i ) == 1 ) {
			E_mys.mines++;
			if ( rinfo.mines[i].protect_round > 0 ) E_opp.avail[i] = max( E_opp.avail[i] , rinfo.round + rinfo.mines[i].protect_round - 1 );
		}
		if ( Mine_owner( i ) == 0 ) {
			E_opp.mines++;
			if ( rinfo.mines[i].protect_round > 0 ) E_mys.avail[i] = max( E_mys.avail[i] , rinfo.round + rinfo.mines[i].protect_round - 1 );
			if ( Observed == rinfo.round && opp.pos == rinfo.mines[i].pos && !Super() ) E_mys.avail[i] = max( E_mys.avail[i] , rinfo.round + ANTI_PRO_TIME );
		}
	}
	
	E_mys.M_cd = 5 + 3 * E_mys.mines;
	E_opp.M_cd = 5 + 3 * E_opp.mines;
}

void Caln_OBs() {
	E_mys.OBs = 0;
	for ( int i = 0 ; i < ( int ) rinfo.observers.size() ; i++ )
		if ( rinfo.observers[i].owner == rinfo.player_id ) E_mys.OBs++;
}

void Preparation() {
	for ( int i = 0 ; i < ( int ) rinfo.players.size() ; i++ )
		if ( rinfo.players[i].owner == rinfo.player_id ) mys = rinfo.players[i];
	
	Caln_mines();
	Caln_OBs();
	Observe_opp();
	
	Extend_map();
	Assess_map_cost();
	Assess_map_cont();
}

//==================================================Breadth First Search==================================================//

void Insert( State now ) {
	int &tmp = F[now.ass.cd][now.pos.x][now.pos.y];
	int st = now.ass.step;
	if ( tmp == -1 || now.ass.step < tmp ) {
		tmp = st;
		Q[st].sta[Q[st].tot++] = now;
	}
}

State Search( Position S , Position T , int S_cd , int M_cd ) {
	memset( F , -1 , sizeof( F ) );
	
	Insert( State( S , Assess( 0 , S_cd ) , Load_act( 0 ) ) );
	
	State opt( T , Assess( Inf , 0 ) , Load_act( 0 ) );
	
	for ( int st = 0 ; st <= opt.ass.step ; st++ ) {
		if ( st + SEARCH_MAX_COST == SEARCH_STEPS ) break;
		
		for ( int k = 0 ; k < Q[st].tot ; k++ ) {
			State now = Q[st].sta[k];
			if ( now.ass.step > F[now.ass.cd][now.pos.x][now.pos.y] ) continue;
				
			if ( now.pos == T && now.ass < opt.ass ) opt = now;
			if ( now.ass.step == opt.ass.step ) continue;
			
			int cost = E_map.cost[now.pos.x][now.pos.y];
			
			for ( int d = 0 ; d <= 4 ; d++ ) {
				Position next_pos( now.pos.x + dx[d] , now.pos.y + dy[d] );
				Action next_act = ( st == 0 ) ? ( Load_act( d ) ) : ( now.act );
				if ( Legal( next_pos ) ) Insert( State( next_pos  , Assess( now.ass.step + cost , max( 0 , now.ass.cd - 1 ) ) , next_act ) );
			}
			
			if ( now.ass.cd == 0 ) {
				for ( int i = -2 ; i <= 2 ; i++ )
					for ( int j = -2 ; j <= 2 ; j++ ) {
						if ( abs( i ) + abs( j ) <= 1 ) continue;
						Position next_pos( now.pos.x + i , now.pos.y + j );
						Action next_act = ( st == 0 ) ? ( Load_act( 5 , next_pos ) ) : ( now.act );
						if ( Strict_legal( next_pos ) ) Insert( State( next_pos , Assess( now.ass.step + cost , M_cd ) , next_act ) );
					}
			}
		}
	}
	
	for ( int st = 0 ; st <= opt.ass.step + SEARCH_MAX_COST && st < SEARCH_STEPS ; st++ )
		Q[st].tot = 0;
	
	return opt;
}

//==================================================Preliminary Analysis==================================================//

bool State_cmp( State A , State B ) { return A.ass < B.ass; }

void Greedy_analyse( Player player , Extend_player &E_player , int player_id ) {
	E_player.G_n = 0;
	
	for ( int i = 0 ; i < MAX_MINES ; i++ )
		if ( Mine_owner( i ) != player_id ) {
			State now = Search( player.pos , rinfo.mines[i].pos , player.blink_cd , E_player.M_cd );
			now.id = i;
			
			if ( player_id == 1 && now.ass.step < E_player.avail[i] - rinfo.round ) continue;
			if ( player_id == 0 ) now.ass.step = max( now.ass.step , E_player.avail[i] - Observed );
			
			E_player.G[E_player.G_n++] = now;
		}
	sort( E_player.G , E_player.G + E_player.G_n , State_cmp );
}

void Iterate_analyse( Player player , Extend_player &E_player , int player_id ) {
	int N = E_player.I_n = min( E_player.G_n , ITERATE_DEEP );
	if ( N == 0 ) return;
	
	State rec[MAX_MINES];
	E_player.I[N - 1].ass = Assess( Inf , Inf );
	
	int per[3] = { 0 , 1 , 2 };
	do {
		rec[0] = E_player.G[per[0]];
		
		for ( int i = 1 ; i < N ; i++ ) {
			int id = E_player.G[per[i]].id;
			
			rec[i] = Search( rec[i - 1].pos , rinfo.mines[id].pos , max( 0 , rec[i - 1].ass.cd - Occupy_time( rec[i - 1].id ) ) , E_player.M_cd );
			rec[i].id = id;
			rec[i].ass.step += rec[i - 1].ass.step + Occupy_time( rec[i - 1].id );
			
			if ( player_id == 0 ) rec[i].ass.step = max( rec[i].ass.step , E_player.avail[id] - Observed );
		}
		
		if ( ( rec[N - 1] < E_player.I[N - 1] ) || ( rec[N - 1] == E_player.I[N - 1] && rec[0] < E_player.I[0] ) )
			for ( int i = 0 ; i < N ; i++ ) E_player.I[i] = rec[i];
		
		if ( player_id == 0 ) break;
	} while ( next_permutation( per , per + N ) );
}

void Pre_analyse() {
	if ( Observed == rinfo.round ) {
		Greedy_analyse( opp , E_opp , 0 );
		Iterate_analyse( opp , E_opp , 0 );
	}
	
	Greedy_analyse( mys , E_mys , 1 );
	
	if ( rinfo.round - Observed < MINE_TIME ) {
		while ( E_mys.G_n != 0 ) {
			int id = E_mys.G[0].id;
			State now = Search( opp.pos , rinfo.mines[id].pos , E_opp.M_cd , E_opp.M_cd );
			
			if ( Mine_owner( id ) == 0 && now.ass.step < min( NEAR_ENOUGH , E_mys.G[0].ass.step + abs( rinfo.mines[id].own_point ) ) ) {
				E_mys.avail[id] = max( E_mys.avail[id] , rinfo.round + E_mys.G[0].ass.step + 1 );
				Greedy_analyse( mys , E_mys , 1 );
			} else
				break;
		}
	}
	
	Iterate_analyse( mys , E_mys , 1 );
}

//==================================================Buy Something==================================================//

bool SetOB() {
	return ( E_mys.OBs == 0 );
}

bool Buy_protect() {
	if ( ginfo.golds[rinfo.player_id] < MINE_PROTEC_RATE * ginfo.mine_num[rinfo.player_id] ) return false;
	if ( rinfo.round + E_mys.mines * MINE_COME_HOME >= GAME_ROUND ) return false;
	
	int id = -1;
	for ( int i = 0 ; i < MAX_MINES ; i++ )
		if ( Mine_owner( i ) == 1 && mys.pos == rinfo.mines[i].pos ) {
			id = i;
			break;
		}
	if ( id == -1 ) return false;
	
	if ( rinfo.mines[id].protect_round > PRO_REINFORCE ) return false;
	
	for ( int i = 0 ; i < E_opp.I_n ; i++ )
		if ( E_opp.I[i].id == id ) {
			if ( ( rinfo.round + MINE_PROTEC_ROUND ) - ( Observed + E_opp.I[i].ass.step ) < PRO_MIN_TIME ) return false;
			return true;
		}
	
	return false;
}

//==================================================Mys Strategy==================================================//

bool To_Be_A_Follower( Action &act ) {
	if ( E_mys.G_n == 0 ) {
		Position aim = opp.pos;
		if ( E_opp.G_n != 0 ) aim = E_opp.G[0].pos;
		
		act = Search( mys.pos , aim , mys.blink_cd , E_mys.M_cd ).act;
		return true;
	}
	
	if ( E_mys.G_n != 0 && E_mys.G[0].ass.step == 0 ) return false;
	
	if ( Sur_mines() >= 1 && ( rinfo.round - Observed ) + Manha_dist( mys.pos , opp.pos ) <= MINE_TIME ) {
		if ( E_mys.G_n != 0 && E_opp.G_n != 0 && E_opp.G[0].ass.step - E_mys.G[0].ass.step >= CRITICAL_DIFF ) return false;
		
		if ( Observed == rinfo.round ) {
			State now = Search( mys.pos , opp.pos , max( MINE_TIME , mys.blink_cd ) , E_mys.M_cd );
			if ( mys.blink_cd == 0 && now.ass.step > FOLLOW_STEP )
				now = Search( mys.pos , opp.pos , 0 , E_mys.M_cd );
			
			act = now.act;
			return true;
		} else {
			Position aim = opp.pos;
			Position dir( 0 , 0 );
			for ( int i = Observed ; i >= 0 && i > Observed - FOLLOW_SPAN ; i-- ) {
				if ( history[i].opp_track == Position( -1 , -1 ) ) continue;
				dir.x += opp.pos.x - history[i].opp_track.x;
				dir.y += opp.pos.y - history[i].opp_track.y;
			}
			
			double max_dot = -1e9;
			for ( int i = -2 ; i <= 2 ; i++ )
				for ( int j = -2 ; j <= 2 ; j++ ) {
					if ( abs( i ) + abs( j ) <= 1 ) continue;
					
					Position pos( opp.pos.x + i , opp.pos.y + j );
					if ( !Strict_legal( pos ) ) continue;
					if ( cur_map.grids[pos.x][pos.y].terrain != MapGrid::UNSEEN ) continue;
						
					double dot = ( double ) ( i * dir.x + j * dir.y ) / sqrt( ( double ) i * i + j * j );
					if ( dot > max_dot ) {
						max_dot = dot;
						aim = pos;
					}
				}
			
			State now = Search( mys.pos , aim , mys.blink_cd , E_mys.M_cd );
			if ( now.act.move == 0 && mys.blink_cd >= FOLLOW_STEP ) return false;
			
			act = now.act;
			return true;
		}
	}
		
	return false;
}

bool Disturb_Your_Target( Action &act ) {
	if ( E_opp.G_n == 0 ) return false;
	
	int id = E_opp.G[0].id;
	if ( Mine_owner( id ) != 1 ) return false;
	
	State now = Search( mys.pos , rinfo.mines[id].pos , mys.blink_cd , E_mys.M_cd );
	if ( rinfo.round + now.ass.step + E_mys.mines * MINE_COME_HOME >= GAME_ROUND ) return false;
	if ( now.ass.step == 0 ) return false;
	if ( rinfo.mines[id].protect_round - now.ass.step > PRO_REINFORCE ) return false;
	if ( E_opp.G[0].ass.step + abs( rinfo.mines[id].own_point ) < now.ass.step ) return false;
	
	if ( E_mys.G_n != 0 ) {
		int waste = Inf;
		for ( int i = 0 ; i < E_mys.G_n ; i++ ) {
			State next = Search( rinfo.mines[id].pos , E_mys.G[i].pos , now.ass.cd , E_mys.M_cd );
			waste = min( waste , ( now.ass.step + next.ass.step ) - E_mys.G[0].ass.step );
		}
		
		if ( E_opp.G_n >= 2 ) {
			int AC_waste = DISTURB_MAX_WASTE;
			if ( Sur_mines() >= 0 && E_opp.G[1].ass.step - E_opp.G[0].ass.step >= CRITICAL_DIFF ) AC_waste *= 2;
			if ( waste > AC_waste ) return false;
		} else
			if ( E_mys.mines <= 1 ) return false;
		
		State next = Search( rinfo.mines[E_mys.G[0].id].pos , rinfo.mines[id].pos , E_mys.G[0].ass.cd , E_mys.M_cd );
		if ( E_mys.G[0].ass.step + Occupy_time( E_mys.G[0].id ) + next.ass.step < E_opp.G[0].ass.step + abs( rinfo.mines[id].own_point ) ) return false;
	}
	
	act = now.act;
	return true;
}

bool Sur_cmp( Position A , Position B ) { return E_map.cont[A.x][A.y] > E_map.cont[B.x][B.y]; }

bool Deal_With_Follower( Action &act ) {
	Position &aim = Anti_follow_aim;
	
	if ( !Followed || Super() ) { aim = Position( -1 , -1 ); return false; }
	if ( mys.pos == aim ) aim = Position( -1 , -1 );
	
	if ( aim == Position( -1 , -1 ) ) {		
		if ( E_map.sur_N == 0 ) return false;
		sort( E_map.sur , E_map.sur + E_map.sur_N , Sur_cmp );
		
		int M = 0;
		while ( M + 1 < E_map.sur_N && E_map.cont[E_map.sur[M + 1].x][E_map.sur[M + 1].y] * 3 / 2 >= E_map.cont[E_map.sur[0].x][E_map.sur[0].y] ) M++;
		M = max( M , ANTI_FOLLOW_OPTION );
		aim = E_map.sur[rand() % M];
	}
	
	act = Load_act( 0 );
	if ( mys.blink_cd == 0 && ( rand() & 1 ) ) {
		Position dir( 0 , 0 );
		for ( int i = rinfo.round ; i >= 0 && i > rinfo.round - FOLLOW_SPAN ; i-- ) {
			dir.x += mys.pos.x - history[i].mys_track.x;
			dir.y += mys.pos.y - history[i].mys_track.y;
		}
			
		double min_dot = 1e9;
		for ( int i = -2 ; i <= 2 ; i++ )
			for ( int j = -2 ; j <= 2 ; j++ ) {
				if ( abs( i ) + abs( j ) <= 1 ) continue;
				
				Position pos( mys.pos.x + i , mys.pos.y + j );
				if ( !Strict_legal( pos ) ) continue;
				if ( cur_map.grids[pos.x][pos.y].terrain != MapGrid::UNSEEN ) continue;
					
				double dot = ( double ) ( i * dir.x + j * dir.y ) / sqrt( ( double ) i * i + j * j );
				if ( dot < min_dot ) {
					min_dot = dot;
					act = Load_act( 5 , pos );
				}
			}
		
		if ( E_map.sur_N != 0 ) {
			sort( E_map.sur , E_map.sur + E_map.sur_N , Sur_cmp );
			
			int M = 0;
			while ( M + 1 < E_map.sur_N && E_map.cont[E_map.sur[M + 1].x][E_map.sur[M + 1].y] * 3 / 2 >= E_map.cont[E_map.sur[0].x][E_map.sur[0].y] ) M++;
			
			min_dot = 1e9;
			for ( int k = 0 ; k < M ; k++ ) {
				int i = E_map.sur[k].x - mys.pos.x , j = E_map.sur[k].y - mys.pos.y;
				
				double dot = ( double ) ( i * dir.x + j * dir.y ) / sqrt( ( double ) i * i + j * j );
				if ( dot < min_dot ) {
					min_dot = dot;
					aim = E_map.sur[k];
				}
			}
		}
	}
	
	if ( act.move == 0 ) act = Search( mys.pos , aim , mys.blink_cd , E_mys.M_cd ).act;
	return true;
}

void Mys_action( Action &act ) {
	if ( To_Be_A_Follower( act ) ) return;
	if ( Disturb_Your_Target( act ) ) return;
	if ( Deal_With_Follower( act ) ) return;
	
	if ( rinfo.round >= CRITICAL_ROUND && GAME_ROUND - rinfo.round >= CRITICAL_ROUND && E_mys.I_n == E_mys.G_n && E_mys.G[0].ass.step != 0 ) act = E_mys.I[0].act;
		else act = E_mys.G[0].act;
}

//==================================================Evalution==================================================//

double start_time , end_time , max_time = 0;

void Evalute() {
	end_time = clock();
	max_time = max( max_time , ( end_time - start_time ) / CLOCKS_PER_SEC );
	
	if ( rinfo.round == 999 ) {
		freopen( "evalute.txt" , "w" , stdout );
		printf( "Hello! It's AI4.\n" );
		printf( "[Maximum Time] %.3lf\n" , max_time );
		printf( "[Mys] %d : %d\n" , ginfo.mine_num[rinfo.player_id] , ginfo.golds[rinfo.player_id] );
		printf( "[opp] %d : %d\n" , ginfo.mine_num[rinfo.player_id ^ 1] , ginfo.golds[rinfo.player_id ^ 1] );
	}
}

//==================================================Main Process==================================================//

void player_ai( Map &input_map , GameInfo &input_ginfo , RoundInfo &input_rinfo , Action &act ) {
	srand( 1995 - 05 - 12 );
	start_time = clock();
	
	ginfo = input_ginfo;
	rinfo = input_rinfo;
	cur_map = input_map;
	
	Preparation();
	Pre_analyse();
	
	Mys_action( act );
	act.setOB = SetOB();
	act.buy_protect = Buy_protect();
	
	//Evalute();
}

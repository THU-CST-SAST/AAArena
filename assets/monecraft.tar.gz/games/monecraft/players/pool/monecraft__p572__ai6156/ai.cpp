#include "sdk.h"
#include <ctime>
#include<cstring>
using namespace std;

int number=0; //number --> num of the move2[]
int move2[1000];

struct qtype
{
	Position pos;
	int last_move;
	Position last;
}queue[100000];
//*********************************
void BFS(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	const int dx[] = {0,-1,0,1};
	const int dy[] = {1,0,-1,0};
	Player my_player;
	for (int i = 0; i < rinfo.players.size(); ++i)
	{
		if (rinfo.players[i].owner == rinfo.player_id)
		{
			my_player = rinfo.players[i];
			break;
		}
	}
	int head=1;
	int tail=1;
	queue[head].pos=my_player.pos;
	
	int Judge[50][50];memset(Judge,0,sizeof(Judge));
//****************************************************************************************************
		for (int i=0;i<rinfo.mines.size();i++)
		{
			if (rinfo.mines[i].pos==queue[tail].pos)
			{
				act.move=Action::Stop;
				return ;
			}
		}
	
	while(head<=tail)
	{
			for (int k=0;k<4;k++)
			{
				Position next_pos;
				next_pos.x = queue[head].pos.x + dx[k];
				next_pos.y = queue[head].pos.y + dy[k];
				 
				if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT  &&next_pos.x<=MAP_WIDTH-1 && next_pos.y<=MAP_WIDTH-1)
				{
					if (Judge[next_pos.x][next_pos.y]==0)
					{
						tail++;	
						queue[tail].last=queue[head].pos;
						queue[tail].pos=next_pos;
						queue[tail].last_move=k;	
						Judge[next_pos.x][next_pos.y]=1;
						
//**************************************************************************************************************
						for (int i=0;i<rinfo.mines.size();i++)
						{
							if (rinfo.mines[i].pos==queue[tail].pos&&rinfo.mines[i].owner!=my_player.owner)
							{
								int end=tail;
								do
								{
									for (int mm=end-1;mm>0;mm--)
									{
										if (queue[mm].pos==queue[end].last)
										{
											move2[number]=queue[end].last_move;number++;
											end=mm;
											break;
										}
									}
								}
								while (end>1);
								return;
							}
						}
//**************************************************************************************************************
					}//judge is available
				}//if
			}//for 
			head++;
	}//while
}

//****************************************************************************************************************
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	if (number==0)
	{
		BFS(map,ginfo,rinfo,act);
	}
	
	int a=move2[number-1];
	act.move=(Action::Move)(a+1);
	number--;
}

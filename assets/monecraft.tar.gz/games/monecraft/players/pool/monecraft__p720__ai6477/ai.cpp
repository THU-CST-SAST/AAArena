/*
 * main.cpp
 *
 *  Created on: 2013年12月11日
 *      Author: roosephu
 */

#include "sdk.h"
#include <iostream>
#include <cassert>
#include <queue>
#include <algorithm>
using namespace std;

#define foreach(it, vec) for (__typeof__(vec.begin()) it = vec.begin(); it != vec.end(); ++it)

#define CERR 0 && cerr
const int inf = 0x3f3f3f3f;

static Map M;
static bool vis[MAP_HEIGHT][MAP_WIDTH];
MapGrid::Terrain rec[MAP_HEIGHT][MAP_WIDTH];
const int dx[4] = { 0, -1, 0, 1 };
const int dy[4] = { 1, 0, -1, 0 };
int dist[MAP_HEIGHT][MAP_WIDTH];
bool initialized = false;

bool valid(int a, int b) {
	return 0 <= a && a < MAP_HEIGHT && 0 <= b && b < MAP_WIDTH;
}

void BFS(Position x) {
	fill(dist[0], dist[MAP_HEIGHT], inf);
	dist[x.x][x.y] = 0;
	queue<Position> Q;
	Q.push(x);
	for (; !Q.empty(); Q.pop()) {
		Position x = Q.front();
		for (int i = 0; i < 4; ++i) {
			int nx = x.x + dx[i], ny = x.y + dy[i];
			if (valid(nx, ny) && rec[nx][ny] == MapGrid::FLAT
					&& dist[nx][ny] == inf) {
				dist[nx][ny] = dist[x.x][x.y] + 1;
				Q.push(Position(nx, ny));
			}
		}
	}
}

void init() {
	if (initialized)
		return;
	initialized = true;
	for (int i = 0; i < MAP_WIDTH; ++i) {
		for (int j = 0; j < MAP_HEIGHT; ++j) {
			rec[i][j] = MapGrid::UNSEEN;
		}
	}
}

void show_map(Position me) {
	for (int i = 0; i < MAP_HEIGHT; ++i) {
		for (int j = 0; j < MAP_WIDTH; ++j) {
			MapGrid::Terrain &t = rec[i][j];
			char c = ".#?"[t];
			if (i == me.x && j == me.y) {
				c = 'x';
			}
			CERR << c;
			if (t != MapGrid::UNSEEN) {
				rec[i][j] = t;
			}
		}
		CERR << endl;
	}
}

void update_rec_map() {
	for (int i = 0; i < MAP_HEIGHT; ++i) {
		for (int j = 0; j < MAP_WIDTH; ++j) {
			if (rec[i][j] == MapGrid::UNSEEN) {
				rec[i][j] = M.grids[i][j].terrain;
				if (M.grids[i][j].terrain != MapGrid::UNSEEN) {
					CERR << "update terrain " << i << " " << j << endl;
				}
			}
		}
	}
}

Position extend_map(Position pos) {
	CERR << "decision: extend" << endl;
	for (int d = 0; d < 4; ++d) {
		int nx = pos.x + dx[d], ny = pos.y + dy[d];
		if (!valid(nx, ny)) continue;
		if (rec[nx][ny] == MapGrid::UNSEEN) {
			CERR << " > find a nearby unseen..." << endl;
			return Position(nx, ny);
		}
	}

	int md = inf;
	Position closest;
	for (int i = 0; i < MAP_HEIGHT; ++i) {
		for (int j = 0; j < MAP_WIDTH; ++j) {
			if (dist[i][j] == inf) continue;
			for (int d = 0; d < 4; ++d) {
				int nx = i + dx[d], ny = j + dy[d];
				if (!valid(nx, ny)) continue;
				if (dist[nx][ny] == inf && dist[i][j] < md && rec[nx][ny] != MapGrid::BLOCK) {
					md = dist[i][j];
					closest = Position(i, j);
					CERR << " > evidence: " << nx << " " << ny << endl;
				}
			}
		}
	}


	if (md == inf) {
		for (int i = 0; i < MAP_HEIGHT; ++i) {
			for (int j = 0; j < MAP_WIDTH; ++j) {
				if (dist[i][j] < md) {
					closest = Position(i, j);
				}
			}
		}
	}
	CERR << " > so go to " << closest.x << " " << closest.y << endl;
	return closest;
}

void show_dist() {
	for (int i = 0; i < MAP_HEIGHT; ++i) {
		for (int j = 0; j < MAP_WIDTH; ++j) {
			if (dist[i][j] == inf)
				CERR << "X" << " ";
			else
				CERR << dist[i][j] << " ";
		}
		CERR << "\n";
	}
}

int manhattan(Position a, Position b) {
	return abs(a.x - b.x) + abs(a.y + b.y);
}

void player_ai(Map &_M, GameInfo &G, RoundInfo &rnd, Action &act) {
	// if (G.rounds == 500) assert(0);
	init();
	M = _M;
	update_rec_map();
	/// assert(0);
	CERR << "----------------------------------" << endl;
	CERR << "run: " << rnd.players.size() << " " << rnd.player_id << endl;

	int me_id = -1;
	// assert(rnd.players.size() == 2);
	foreach(it, rnd.players) {
		CERR << it->owner << " " << it->pos.x << " " << it->pos.y << endl;
		if (it->owner == rnd.player_id) {
			me_id = it - rnd.players.begin();
		}
	}
	assert(me_id != -1);
	Player &me = rnd.players[me_id];
	vis[me.pos.x][me.pos.y] = true;
	CERR << "my pos: " << me.pos.x << " " << me.pos.y << endl;
	show_map(me.pos);

	BFS(me.pos);
//	show_dist();

	act.move = Action::Stop;

	int closest = -1, md = inf;
	foreach(it, rnd.mines) {
		if (it->owner != rnd.player_id || abs(it->own_point) != 5) {
			CERR << "mines: " << " " << it->owner << " " << it->pos.x << " " << it->pos.y << " " << it->own_point << endl;
			int x = it->pos.x, y = it->pos.y;
			if (dist[x][y] < md) {
				md = dist[x][y];
				closest = it - rnd.mines.begin();
			}
//			BFS(it->pos);			break;
		}
	}

	Position dst;
//	CERR << "now dist: " << dist[me.pos.x][me.pos.y] << endl;
	if (closest != -1) {
		CERR << "decision: goto mines " << closest << " " << "dist " << md << " " << rnd.mines[closest].pos.x << " " << rnd.mines[closest].pos.y << endl;
		dst = rnd.mines[closest].pos;
	} else {
		dst = extend_map(me.pos);
	}

	foreach(it, rnd.players) {
		if (it->owner != rnd.player_id) {
			foreach(mine, rnd.mines) {
				if (manhattan(mine->pos, me.pos) <= 5 && manhattan(mine->pos, it->pos) <= 5) {
					if (mine->pos == me.pos) {
						act.buy_protect = true;
					} else {
						dst = mine->pos;
					}
				}
			}
		}
	}


	BFS(dst);
	int wt = dist[me.pos.x][me.pos.y];
	for (int i = 0; i < 4; ++i) {
		int nx = me.pos.x + dx[i], ny = me.pos.y + dy[i];
		if (valid(nx, ny) && dist[nx][ny] < wt) {
			act.move = (Action::Move) (i + 1);
			wt = dist[nx][ny];
		}
	}
	if (me.blink_cd == 0) { // use blink
		for (int i = -2; i <= 2; ++i) {
			for (int j = -2; j <= 2; ++j) {
				int nx = me.pos.x + i, ny = me.pos.y + j;
				if (valid(nx, ny) && dist[nx][ny] < wt) {
					wt = dist[nx][ny];
					cerr << "blink!" << endl;
					act.move = Action::Blink;
					act.blink_pos = Position(nx, ny);
					cerr << "blink dist: " << nx << " " << ny << endl;
				}
			}
		}
	}

	act.setOB = false;
}


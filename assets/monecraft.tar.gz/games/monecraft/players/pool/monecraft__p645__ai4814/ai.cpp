#include "sdk.h"
#include <ctime>
#include<cmath>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
    act.setOB=0;
    act.buy_protect=0;

	

  static int direction=-1;
  static Position last(-1,-1);
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }

   MapGrid minegrid=map.grids[my_player.pos.x][my_player.pos.y];
	 if((minegrid.mine_id!=-1)&&(abs(rinfo.mines[minegrid.mine_id].own_point)!=5))
     {
     	act.move = Action::Stop;
     	last = my_player.pos;
		 return;
     }

     
     
  Position next_pos;
  int next = -1;
  int cross = 0 ;
  for (int i = 0; i < 4; ++i)
  {
    next_pos.x = my_player.pos.x + dx[i];
	next_pos.y = my_player.pos.y + dy[i];
	if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
	{
      cross++;
	}
  }
  if(cross<=1)
  {
   	for (int i = 0; i < 4; ++i)
	{
    next_pos.x = my_player.pos.x + dx[i];
	next_pos.y = my_player.pos.y + dy[i];
	if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
	{
      next = i;
	  break;
	}
    }
  if (next >= 0)
  {
    //cout << dx[next] << ' ' << dy[next] << endl;
    act.move = (Action::Move)(next+1);
  }
  else
    act.move = (Action::Move)(time(0) % 5);
    
	
	last = my_player.pos;
    direction = next;
  }
  
  
  if(cross>=2)
  {
  	
  	int right=-1;
  	if(direction==0)
  	{
  		right = 3;
  	}
  	else
  	{
  		right = abs(direction + 3 - 4);
  	}
  	
	 if(map.grids[my_player.pos.x + dx[right]][ my_player.pos.y + dy[right]].terrain == MapGrid::FLAT )
	 {
	 	act.move = (Action::Move)(right + 1);
	 	last = my_player.pos;
	 	direction = right;
	 	return;	
	 }
	 else
	 {
	 	 	for (int i = 0; i < 4; ++i)
		{
    		next_pos.x = my_player.pos.x + dx[i];
			next_pos.y = my_player.pos.y + dy[i];
			if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
			{
      		 	next = i;
	  			break;
			}
  		}
  			if (next >= 0)
  			{
   					 //cout << dx[next] << ' ' << dy[next] << endl;
    					act.move = (Action::Move)(next+1);
 			 }
  			else
    				act.move = (Action::Move)(time(0) % 5);
  					last = my_player.pos;
  					direction = next;
	 }
	 
	 
	 
  }
  
  
}


#include "sdk.h"
#include <ctime>
#include <fstream>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
     act.move = Action :: Up;
}


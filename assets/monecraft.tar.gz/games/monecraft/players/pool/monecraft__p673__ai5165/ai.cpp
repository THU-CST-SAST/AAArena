#include "sdk.h"
#include <ctime>
#include <fstream>
#include <cstring>
#include <iostream>
using namespace std;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
    int k=-1;
    act.setOB = false;
    act.buy_protect = false;
    int beforek[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  static Position last(-1,-1);
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  //cout << "test mark 1!" << endl;
  Position next_pos;
  int next = -1;

  if (last.x!=-1)
  {
      if (my_player.pos.x-last.x==0&&my_player.pos.y-last.y==1)
      	k=0;
      if (my_player.pos.x-last.x==-1&&my_player.pos.y-last.y==0)
      	k=1;
      if (my_player.pos.x-last.x==0&&my_player.pos.y-last.y==-1)
      	k=2;
      if (my_player.pos.x-last.x==1&&my_player.pos.y-last.y==0)
      	k=3;
  }
  if (k==-1)
  {
  	for (int i = 0; i < 4; ++i)
  	{
    	next_pos.x = my_player.pos.x + dx[i];
		next_pos.y = my_player.pos.y + dy[i];
		if (next_pos.x>31||next_pos.x<0||next_pos.y>31||next_pos.y<0) continue;
		if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT && !(next_pos == last))
		{
     	 next = i;
	  	break;
		}
  	}
  }
  else
  {
         for(int i = 0; i < 4; i++)
  			{
    			next_pos.x = my_player.pos.x + dx[beforek[k+3+i]];
				next_pos.y = my_player.pos.y + dy[beforek[k+3+i]];
				if (next_pos.x>31||next_pos.x<0||next_pos.y>31||next_pos.y<0) continue;
				if (map.grids[ next_pos.x ][ next_pos.y ].terrain == MapGrid::FLAT)
        		{
                 	 next = (k+3+i)%4;
            	  	break;
        		}
      		}
  }
  if (map.grids[my_player.pos.x][my_player.pos.y].mine_id != -1)
  {
      	int temmine = map.grids[my_player.pos.x][my_player.pos.y].mine_id;

      	    if(rinfo.mines[temmine].owner != my_player.owner)
  			act.move = (Action::Move)(0);
  			else
  			{
  			     if (next >= 0)
              	{
                //cout << dx[next] << ' ' << dy[next] << endl;
                	act.move = (Action::Move)(next+1);
              	}
              	else
                	act.move = (Action::Move)(time(0) % 5);
  			}    

	}
  else
  {
      if (next >= 0)
  	{
    //cout << dx[next] << ' ' << dy[next] << endl;
    	act.move = (Action::Move)(next+1);
  	}
  	else
    	act.move = (Action::Move)(time(0) % 5);
  }
  cout<<act.move<<endl;
  last = my_player.pos;
  //cout << "test end!" << endl;
}


#include "sdk.h"
#include<cstring>
using namespace std;
int mymap[40][40];
int b[20000][5];
int d[300];
void did(Map& map,Position my)
{
int a[40][40],c[40][40];
int i,j,k,l,o,x,y;
const int dx[] = {0,-1,0,1};
const int dy[] = {1,0,-1,0};
memset(a,127,sizeof(a));
memset(b,0,sizeof(b));
memset(c,0,sizeof(c));
memset(mymap,0,sizeof(mymap));
k=1;l=1;
b[1][0]=my.x;b[1][1]=my.y;b[1][2]=0;b[1][3]=0;
a[my.x][my.y]=0;c[my.x][my.y]=1;
o=0;
while(k<=l)
{
for(i=0;i<4;i++)
{
x=b[k][0]+dx[i]; y=b[k][1]+dy[i];
if(x>=0&&x<=30&&y>=0&&y<=30&&map.grids[x][y].terrain==MapGrid::FLAT && a[x][y]>b[k][3]+1){
a[x][y]=b[k][3]+1;
if(c[x][y]==0)
{
l++;
c[x][y]=1;
b[l][0]=x;b[l][1]=y;
b[l][2]=k;b[l][3]=b[k][3]+1;b[l][4]=i+1;
}
if(map.grids[x][y].mine_id>=0 && d[map.grids[x][y].mine_id]==0)
{
d[map.grids[x][y].mine_id]=1;
o=1;
break;
}
}
}
if(o==1) break;
c[b[k][0]][b[k][1]]=0;
k++;
}
for(i=l;b[i][2];i=b[i][2])
{
j=b[i][2];
mymap[b[j][0]][b[j][1]]=b[i][4];
}
return;
}
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
static int flag=0;
static int cs=0;
Player my_player;
for (int i = 0; i < rinfo.players.size(); ++i)
{
if (rinfo.players[i].owner == rinfo.player_id)
{
 my_player = rinfo.players[i];
 break;
}
}
if(map.grids[my_player.pos.x][my_player.pos.y].mine_id>=0)
{
if(cs<5) cs++;
else flag=0;
}
if(flag==0){ cs=-1;flag=1; did(map,my_player.pos);}
act.move=(Action::Move)(mymap[my_player.pos.x][my_player.pos.y]);
}

#include "sdk.h"
#include <ctime>
#include <iostream>
#include <stack>
#include <cstring>
#include <vector>

using namespace std;

#define MAXN 10000000

struct queueMember{
    Position pos;
    int from;
    Action::Move method;
};

class Map_:public Map{
public:
    MapGrid &operator[](const Position &);
    MapGrid &operator[](const queueMember &);
};

MapGrid &Map_::operator[](const Position &p){
    return this->grids[p.x][p.y];
}
MapGrid &Map_::operator[](const queueMember &p){
    return (*this)[p.pos];
}


void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
#if 0
    static queueMember queue[MAXN];
    static stack<Action::Move> history;
    static int rec[ MAP_WIDTH ][ MAP_HEIGHT ];
    static int rec2[ MAP_WIDTH ][ MAP_HEIGHT ];
    static int first=1;
    
    const int dx[] = {0,-1,0,1};
    const int dy[] = {1,0,-1,0};
    static int debug=0;
    
    int top=0,tail=0;
    Player my_player;
    Map_ *t=(Map_ *)&map;
    Map_ map_=*t;
    for (int i = 0; i < rinfo.players.size(); ++i)
    {
        if (rinfo.players[i].owner == rinfo.player_id)
        {
            my_player = rinfo.players[i];
            break;
        }
    }
    /*for (int i=0; i<31; i++) {
        for (int j=0; j<31; j++) {
            cout<<map.grids[i][j].terrain;
        }
        cout<<endl;
    }*/
    if (first) {
        for (int k=0; k<6; k++) {
            history.push((Action::Move)0);
        }
        top=tail=0;
        memset(rec, 0, sizeof(rec));
        queue[tail++]=(queueMember){my_player.pos,-1,(Action::Move)0};
        rec[my_player.pos.x][my_player.pos.y]=1;
        while (tail>top) {
            int now=top++;
            if(map_[queue[now]].mine_id!=-1&&!rec2[queue[now].pos.x][queue[now].pos.y]){
                int cur=now;
                while (queue[cur].from!=-1) {
                    history.push(queue[cur].method);
                    cur=queue[cur].from;
                }
                rec2[queue[now].pos.x][queue[now].pos.y]=1;
                //history.pop();
                break;
            }
            for (int i=0; i<4; i++) {
                queueMember newMember={{queue[now].pos.x+dx[i],queue[now].pos.y+dy[i]},now,(Action::Move)(i+1)};
                if (
                    (newMember.pos.x<MAP_WIDTH)&&(newMember.pos.x>=0)&&
                    (newMember.pos.y<MAP_HEIGHT)&&(newMember.pos.y>=0)&&
                    (!rec[newMember.pos.x][newMember.pos.y])&&
                    (map_[newMember].terrain!=MapGrid::BLOCK)
                    ) {
                    queue[tail++]=newMember;
                    rec[newMember.pos.x][newMember.pos.y]=1;
                }
            }
        }
        first=0;
    }
    /*for (int i=0; i<tail; i++) {
        cout<<queue[i].pos.x<<' '<<queue[i].pos.x<<';';
    }*/
    if(!history.empty()) {
        act.move=history.top();
        act.setOB=0;
        act.buy_protect=0;
        //cout<<(debug++)<<':'<<act.move<<endl;
        history.pop();
    }else{
        first=1;
    }
    //act.move=Action::Stop;
#endif
    
#if 0
    const int dx[] = {0,-1,0,1};
    const int dy[] = {1,0,-1,0};
    //                上左下右
    Map_ *t=(Map_ *)&map;
    Map_ map_=*t;
    static int first=1;
    static Position lastPos;
    Player my_player,enemy;
    int i;
    
    for (i = 0; i < rinfo.players.size(); ++i)
    {
        if (rinfo.players[i].owner == rinfo.player_id)
        {
            my_player = rinfo.players[i];
            break;
        }
    }
    
    cout<<rinfo.players.size()<<endl;
    
    enemy=rinfo.players[1-i];
    //exit(0);
    
    if (first) {
        scanf("%*s");
        lastPos=Position(MAP_WIDTH-1-my_player.pos.x,MAP_HEIGHT-1-my_player.pos.y);
        first=0;
    }
    
    //cout<<"nowpos:("<<enemy.pos.x<<","<<enemy.pos.y<<")\n";
    
    Position dPos=Position(enemy.pos.x-lastPos.x,enemy.pos.y-lastPos.y);
    
    act=*(new Action);
    
    if (dPos.x*dPos.x+dPos.y*dPos.y==1) {
        if (dPos.x==1) {
            act.move=Action::Left;
        }else if (dPos.x==-1){
            act.move=Action::Right;
        }else if (dPos.y==1){
            act.move=Action::Down;
        }else if (dPos.y==-1){
            act.move=Action::Up;
        }
    }else if (dPos.x*dPos.x+dPos.y*dPos.y==0){
        act.move=Action::Stop;
    }else{
        act.move=Action::Blink;
        act.blink_pos=Position(MAP_WIDTH-1-enemy.pos.x,MAP_HEIGHT-1-enemy.pos.y);
    }
    lastPos=enemy.pos;
#endif
    throw -1;
}


#include "sdk.h"
#include <ctime>
using namespace std;
int how = 2,num = 0;
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
  static Position last(-1,-1);
  const int dx[] = {0,-1,0,1};
  const int dy[] = {1,0,-1,0};
  Player my_player;
  for (int i = 0; i < rinfo.players.size(); ++i)
  {
	if (rinfo.players[i].owner == rinfo.player_id)
	{
	  my_player = rinfo.players[i];
	  break;
	}
  }
  Position next_pos;
  
  
  next_pos.x = my_player.pos.x + dx[how];
  next_pos.y = my_player.pos.y + dy[how];
  if (map.grids[ next_pos.x ][ next_pos.y ].terrain != MapGrid::FLAT && num < 28)
	{	
		if(how != 3)	
		{
			how += 1;
			num ++;
		}
		else	
		{
			how = 0;
			num ++;
		}
	}
    act.move = (Action::Move)(how+1);
}


#include "sdk.h"
#include <cstdio>
#include <cmath>
using namespace std;
bool reach[MAP_WIDTH][MAP_HEIGHT] = {0};
bool hdis[MAP_WIDTH][MAP_HEIGHT] = {0};
int my_map[MAP_WIDTH][MAP_HEIGHT] = {0};
const int dx[] = {0,-1,0,1,1,1,-1,-1,2,2,2,2,2,1,1,0,0,-1,-1,-2,-2,-2,-2,-2};
const int dy[] = {1,0,-1,0,1,-1,-1,1,-2,-1,0,1,2,-2,2,-2,2,-2,2,-2,-1,0,1,2};
bool valid(int x, int y)
{
	return ((x>=0)&&(x<MAP_WIDTH)&&(y>=0)&&(y<MAP_HEIGHT));
}
void reach_out(int x, int y)
{
	int k;
	Position next_pos;
	bool f = true;
	for (k=0;k<4;k++)
	{
		next_pos.x = x + dx[k];
		next_pos.y = y + dy[k];
		if (valid(next_pos.x,next_pos.y))
		{
			if ((my_map[next_pos.x][next_pos.y]>0)&&(!reach[next_pos.x][next_pos.y]))
			{
				reach[next_pos.x][next_pos.y] = true;
				reach_out(next_pos.x,next_pos.y);
//				fprintf(out,"reach %d %d\n",next_pos.x,next_pos.y);
			}
			if (!my_map[next_pos.x][next_pos.y]) f = false;
		}
	}
	hdis[x][y] = f;
}
void player_ai(Map& map, GameInfo& ginfo, RoundInfo& rinfo, Action& act)
{
	int i, j, k, l, cnt, mini, mind;
	int mined[30];
	bool to_mine[30];
	int minedist[MAP_WIDTH][MAP_HEIGHT];
	int dmine[MAP_WIDTH][MAP_HEIGHT][30];
	int dist[MAP_WIDTH][MAP_HEIGHT];
	Position target[30];
	bool flag, f;
	bool ndis[MAP_WIDTH][MAP_HEIGHT] = {0};
	Player my_player;
  	Position next_pos;
	Mine cur_mine;
//  FILE *out=fopen("debug.txt","a");
	for (int i = 0; i < rinfo.players.size(); ++i)
	{
		if (rinfo.players[i].owner == rinfo.player_id)
		{
			my_player = rinfo.players[i];
//			fprintf(out,"my place %d %d\n",my_player.pos.x,my_player.pos.y);
			reach[my_player.pos.x][my_player.pos.y] = true;
			break;
		}
  	}
  	//update my_map
  	act.setOB = false;
 	for (i=0;i<MAP_WIDTH;i++)
  		for (j=0;j<MAP_HEIGHT;j++)
  			if ((map.grids[i][j].terrain!=MapGrid::UNSEEN)&&(!my_map[i][j]))
  			{
  				switch (map.grids[i][j].terrain)
  				{
  					case MapGrid::FLAT : 
					  my_map[i][j] = 1;
					  my_map[MAP_WIDTH-1-i][MAP_HEIGHT-1-j] = 1;
					  break;
  					case MapGrid::BLOCK : 
					  my_map[i][j] = -1;
					  my_map[MAP_WIDTH-1-i][MAP_HEIGHT-1-j] = -1;
					  break;
  				}
  				if (map.grids[i][j].mine_id>-1)
				{
					my_map[i][j] = 2;
					my_map[MAP_WIDTH-1-i][MAP_HEIGHT-1-j] = 2;
				}
  			}
	//reach
	for (i=0;i<MAP_WIDTH;i++)
		for (j=0;j<MAP_HEIGHT;j++)
			if ((my_map[i][j]>0)&&(!hdis[i][j])&&(reach[i][j])) reach_out(i,j);
	//check notDiscovered
	for (i=0;i<MAP_WIDTH;i++)
  		for (j=0;j<MAP_HEIGHT;j++)
  			if ((reach[i][j])&&(my_map[i][j]==1))
  			{
  				k = 0;
  				while (k<4)
				{
					next_pos.x = i + dx[k];
					next_pos.y = j + dy[k];
					if (valid(next_pos.x,next_pos.y)&&(!my_map[next_pos.x][next_pos.y]))
					{
						ndis[i][j] = true;
					}
					k++;
				}
  			}
	//own mine
	for (i=0;i<rinfo.mines.size();i++)
	{
		to_mine[i] = false;
		cur_mine = rinfo.mines[i];
		if (((!my_player.owner)&&(cur_mine.own_point!=-5))||((my_player.owner)&&(cur_mine.own_point!=5))) to_mine[i] = true;
		if (cur_mine.protect_round) to_mine[i] = false;
	}
  	if (map.grids[my_player.pos.x][my_player.pos.y].mine_id >-1)
	{
		cur_mine = rinfo.mines[map.grids[my_player.pos.x][my_player.pos.y].mine_id];
		flag = true;
		if ((rinfo.players[0].pos.x!=rinfo.players[1].pos.x)||(rinfo.players[0].pos.y!=rinfo.players[1].pos.y))
			if (((!my_player.owner)&&(cur_mine.own_point==-4))||((my_player.owner)&&(cur_mine.own_point==4))) flag = false;
		if ((flag)&&(!cur_mine.protect_round)&&(cur_mine.owner!=my_player.owner))
		{
  			act.move = (Action::Move)(0);
//			fclose(out);
			return;
  		}
  		if (!flag)
  		{
  			to_mine[cur_mine.id] = false;
  		}
	}
  	//calculate eculid distance
	for (i=0;i<MAP_WIDTH;i++)
		for (j=0;j<MAP_HEIGHT;j++)
			for (k=0;k<rinfo.mines.size();k++)
				if (to_mine[k])
				{
					cur_mine = rinfo.mines[k];
					dmine[i][j][k] = abs(i-cur_mine.pos.x) + abs(j-cur_mine.pos.y);
				}
	for (k=0;k<rinfo.mines.size();k++)
		if (to_mine[k])
		{
			cur_mine = rinfo.mines[k];
//			fprintf(out,"mine %d %d\n",cur_mine.pos.x,cur_mine.pos.y);
			target[k] = cur_mine.pos;
			if (!reach[cur_mine.pos.x][cur_mine.pos.y])
			{
//				if (my_map[cur_mine.pos.x][cur_mine.pos.y]) fprintf(out,"Can't reach mine %d\n",k);
				mind = 5000;
				for (i=0;i<MAP_WIDTH;i++)
					for (j=0;j<MAP_HEIGHT;j++)
						if ((reach[i][j])&&(ndis[i][j]))
						{
							if (dmine[i][j][k]<mind)
							{
								mind = dmine[i][j][k];
								target[k].x = i;
								target[k].y = j;
							}
						}
			}
		}	
	//calculate distance
	for (i=0;i<MAP_WIDTH;i++)
		for (j=0;j<MAP_HEIGHT;j++) dist[i][j] = 5000;
	dist[my_player.pos.x][my_player.pos.y] = 0;
	flag = true;
	cnt = 0;
	while (flag)
 	{
 		flag = false;
 		for (i=0;i<MAP_WIDTH;i++)
 			for (j=0;j<MAP_HEIGHT;j++)
 				if (dist[i][j]==cnt)
 				{
 					for (l=0;l<4;l++)
 					{
 						next_pos.x = i + dx[l];
						next_pos.y = j + dy[l];
						if (valid(next_pos.x,next_pos.y)&&(my_map[next_pos.x][next_pos.y]>0)&&(dist[next_pos.x][next_pos.y]>cnt+1))
						{
							dist[next_pos.x][next_pos.y] = cnt + 1;
							flag = true;
						}
 					}
				}
 		cnt++;
 	}
	//update mined
 	mind = 5000;
 	f = false;
 	for (k=0;k<rinfo.mines.size();k++)
 		if (to_mine[k])
 		{
 			cur_mine = rinfo.mines[k];
 			mined[k] = dmine[target[k].x][target[k].y][k] + dist[target[k].x][target[k].y];
 			if (mined[k]<mind)
 			{
 				mind = mined[k];
 				mini = k;
 				f = true;
 			}
// 			fprintf(out,"%d %d\n",k,mined[target[k].x][target[k].y][k]);
 		}
 	if (f)
 	{
 		for (i=0;i<MAP_WIDTH;i++)
 			for (j=0;j<MAP_HEIGHT;j++) minedist[i][j] = 5000;
 		minedist[target[mini].x][target[mini].y] = 0;
 		flag = true;
		cnt = 0;
 		while (flag)
 		{
 			flag = false;	
 			for (i=0;i<MAP_WIDTH;i++)
 				for (j=0;j<MAP_HEIGHT;j++)
 					if (minedist[i][j]==cnt)
 					{
 						for (l=0;l<4;l++)
 						{
 							next_pos.x = i + dx[l];
							next_pos.y = j + dy[l];
							if (valid(next_pos.x,next_pos.y)&&(my_map[next_pos.x][next_pos.y]>0)&&(minedist[next_pos.x][next_pos.y]>cnt+1))
							{
								minedist[next_pos.x][next_pos.y] = cnt + 1;
								flag = true;
							}
 						}
						
					}
 			cnt++;
 		}
 	}
//	if (!flag) fprintf(out,"NO TARGET!!!\n");
	if (f)
	{
		mind = 3000;
		if (my_player.blink_cd)
		{
			for (l=0;l<4;l++)
 			{
 				next_pos.x = my_player.pos.x + dx[l];
				next_pos.y = my_player.pos.y + dy[l];
				if (valid(next_pos.x,next_pos.y)&&(my_map[next_pos.x][next_pos.y]>0)&&(minedist[next_pos.x][next_pos.y]<mind))
				{
					mind = minedist[next_pos.x][next_pos.y];
					mini = l;
				}
 			}
 			act.move = (Action::Move)(mini+1);
// 			fclose(out);
 			return;
		}
		for (l=0;l<24;l++)
 		{
 			next_pos.x = my_player.pos.x + dx[l];
			next_pos.y = my_player.pos.y + dy[l];
			if (valid(next_pos.x,next_pos.y)&&(my_map[next_pos.x][next_pos.y]>0)&&(minedist[next_pos.x][next_pos.y]<mind))
			{
				mind = minedist[next_pos.x][next_pos.y];
				mini = l;
			}
 		}
 		if (mini<4) act.move = (Action::Move)(mini+1);
 		else
 		{ 				
		 	act.blink_pos.x = my_player.pos.x + dx[mini];
			act.blink_pos.y = my_player.pos.y + dy[mini];
 			act.move = (Action::Move)(5);
 		}
// 		fclose(out);
 		return;
	}
	act.move = (Action::Move)(0);
//	fclose(out);
	return;
}


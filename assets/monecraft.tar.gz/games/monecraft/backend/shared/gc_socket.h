#ifndef GC_SOCKET_H_LIHAODA___
#define GC_SOCKET_H_LIHAODA___
#include "sdk.h"
#include "socket.hh"


#define IMPL_BY_SENDABLE(type) \
SocketBase& operator << (SocketBase &s, const type &val);\
SocketBase& operator >> (SocketBase &s, type &val);


IMPL_BY_SENDABLE(Position);
IMPL_BY_SENDABLE(GameInfo);
IMPL_BY_SENDABLE(Action);
IMPL_BY_SENDABLE(Observer);
IMPL_BY_SENDABLE(Mine);
IMPL_BY_SENDABLE(Player);
IMPL_BY_SENDABLE(View);
IMPL_BY_SENDABLE(MapGrid::Terrain);
#undef IMPL_BY_SENDABLE

SocketBase& operator << (SocketBase &s, const MapGrid::Terrain &val);
SocketBase& operator >> (SocketBase &s, MapGrid::Terrain &val);
SocketBase& operator << (SocketBase &s, const MapGrid &val);
SocketBase& operator >> (SocketBase &s, MapGrid &val);
SocketBase& operator << (SocketBase &s, const Map &val);
SocketBase& operator >> (SocketBase &s, Map &val);
SocketBase& operator << (SocketBase &s, const RoundInfo &val);
SocketBase& operator >> (SocketBase &s, RoundInfo &val);
SocketBase& XSend(SocketBase &s, const Map &val, const View &v);
SocketBase& XRecv(SocketBase &s, Map &val);

#endif //GC_SOCKET_H_LIHAODA___

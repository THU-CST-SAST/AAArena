#include "gc_socket.h"

#define IMPL_BY_SENDABLE(type) \
SocketBase& operator << (SocketBase &s, const type &val)  { \
    return s << sendable(val); \
} \
SocketBase& operator >> (SocketBase &s, type &val)  { \
    return s >> recvable(val); \
}

IMPL_BY_SENDABLE(GameInfo);
IMPL_BY_SENDABLE(Action);
IMPL_BY_SENDABLE(Position);
IMPL_BY_SENDABLE(Observer);
IMPL_BY_SENDABLE(Mine);
IMPL_BY_SENDABLE(Player);
IMPL_BY_SENDABLE(View);
IMPL_BY_SENDABLE(MapGrid::Terrain);
#undef IMPL_BY_SENDABLE


SocketBase& operator << (SocketBase &s, const MapGrid &val)
{
  return s << val.pos << val.terrain << val.mine_id << val.players;
}
SocketBase& operator >> (SocketBase &s, MapGrid &val)
{
  return s >> val.pos >> val.terrain >> val.mine_id >> val.players;
}
SocketBase& operator << (SocketBase &s, const Map &val)
{
  for (int i = 0; i < MAP_WIDTH; ++i)
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
      s << val.grids[i][j].pos << val.grids[i][j].terrain << val.grids[i][j].mine_id;
    }
  return s;
}
SocketBase& operator >> (SocketBase &s, Map &val)
{
  for (int i = 0; i < MAP_WIDTH; ++i)
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
      s >> val.grids[i][j].pos >> val.grids[i][j].terrain >> val.grids[i][j].mine_id;
    }
  return s;
}
SocketBase& operator << (SocketBase &s, const RoundInfo &val)
{
  return s << val.round << val.player_id
	   << val.observers << val.players
	   << val.mines;
}
SocketBase& operator >> (SocketBase &s, RoundInfo &val)
{
  return s >> val.round >> val.player_id
	   >> val.observers >> val.players
	   >> val.mines;
}


SocketBase& XSend(SocketBase &s, const Map &val, const View &v)
{
  int flag = 1;
  for (int i = 0; i < MAP_WIDTH; ++i)
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
	if (v.get(i,j))
	{
		s << flag;
      		s << i << j;
		s << val.grids[i][j];
	}
    }
  flag = 0;
  s << flag;
  return s;
}
SocketBase& XRecv(SocketBase &s, Map &val)
{
  for (int i = 0; i < MAP_WIDTH; ++i)
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
	val.grids[i][j].terrain = MapGrid::UNSEEN;
      	val.grids[i][j].mine_id = -1;
	val.grids[i][j].players.clear();
    }
  int flag = 0;
  int i,j;
  s >> flag;
  while (flag)
  {
    s >> i >> j;
    s >> val.grids[i][j];
    s >> flag;
  }
  return s;
}

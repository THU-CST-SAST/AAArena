/*
 * $File: lib.cc
 * $Date: Sun Mar 24 15:05:10 2013 +0800
 * $Author: jiakai <jia.kai66@gmail.com>
 */

#include "include_private/lib.hh"
#include "ai9.hh"

#include <map>
#include <set>
#include <string>

#include <cstdlib>
#include <cstdio>

#include <errno.h>
#include <time.h>
#include <linux/limits.h>
#include <sys/mman.h>
#include <sys/user.h>
#include <sys/ptrace.h>
#include <sys/syscall.h>

static const std::map<int, int>
SYSCALL_LIMIT = {
	{__NR_mprotect, -1},
	{__NR_mmap, -1},
#ifdef __NR_mmap2
	{__NR_mmap2, -1},
#endif
	{__NR_munmap, -1},
	// user function can do no harm, even if unmapped m_subproc_shared

	{__NR_times, -1},
	{__NR_brk, -1},
	{__NR_futex, -1},
	{__NR_exit_group, -1},
	{__NR_getcwd, -1},
	{__NR_time, -1}
};

static const std::set<int> SYSCALL_ALLOWED_FOPT = {
	// allowed syscall for file operations on stdin/out/err
	__NR_read, __NR_write, __NR_fstat, __NR_ioctl, __NR_close,
#ifdef __NR_fstat64
	__NR_fstat64,
#endif
};

static std::set<std::string> open_allowed_path;
static std::set<std::string> stat_allowed_path = {"/etc/localtime"};
static std::set<int> fopt_allowed_fd = {
	fileno(stdin), fileno(stdout), fileno(stderr)
};
static std::map<int, int> syscall_remain;

static void get_ptrace_str(pid_t pid, size_t addr, char *buf, size_t len);

double get_cputime()
{
	struct timespec time;
	clock_gettime(CLOCK_THREAD_CPUTIME_ID, &time);
	return time.tv_sec + 1e-9 * time.tv_nsec;
}

double get_realtime()
{
	struct timespec time;
	clock_gettime(CLOCK_MONOTONIC, &time);
	return time.tv_sec + 1e-9 * time.tv_nsec;
}

void* get_shared_mem(size_t len)
{
	if (!len)
		return nullptr;
	void* ret = mmap(NULL, len, PROT_READ | PROT_WRITE,
			MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	if (ret == MAP_FAILED)
		throw AI9Error("failed to map memory: %m");
	return ret;
}

void unget_shared_mem(void *addr, size_t len)
{
	if (len)
		munmap(addr, len);
}

int check_syscall(pid_t pid)
{
	static bool on_return = true;
	// since ptrace would be triggered both on entering and exiting from the
	// syscall, on_return is whether this call is exiting or entering

	on_return ^= 1;
	int scno;
	int64_t arg0, retval;
	struct user_regs_struct regs;
	ptrace(PTRACE_GETREGS, pid, nullptr, &regs);
#ifdef __x86_64__
	scno = regs.orig_rax;
	arg0 = regs.rdi;
	retval = regs.rax;
#else
	scno = regs.orig_eax;
	arg0 = regs.ebx;
	retval = regs.eax;
#endif

	static bool log_syscall = getenv("AI9_AILOADER_LOGSYSCALL") != nullptr;

	char syscall_arg_fpath[PATH_MAX];
	// the file path argument of syscall (if operates on file)

#ifndef __NR_stat64
#define __NR_stat64	__NR_stat
#endif

	if (scno == __NR_open || scno == __NR_stat || scno == __NR_stat64)
		get_ptrace_str(pid, arg0, syscall_arg_fpath, PATH_MAX);

	if (log_syscall)
	{
		printf("syscall: %d (arg0=%lld)\n", scno, (long long)arg0);
		if (scno == __NR_open || scno == __NR_stat)
		{
			const char *name;
			if (scno == __NR_open)
				name = "open";
			else if (scno == __NR_stat || scno == __NR_stat64)
				name = "stat";
			else name = "WTF?!";

			printf("  [%s]arg0=%s ret=%d\n", name,
					syscall_arg_fpath, (int)retval);
		}
		return 0;
	}

	if (scno == __NR_open || scno == __NR_openat)
	{
		if (open_allowed_path.find(syscall_arg_fpath) ==
				open_allowed_path.end())
			return scno;
		if (on_return)
			fopt_allowed_fd.insert(retval);
		return 0;
	}

	if (scno == __NR_stat || scno == __NR_stat64) {
		if (stat_allowed_path.find(syscall_arg_fpath) ==
				stat_allowed_path.end())
			return scno;
		return 0;
	}

	if (SYSCALL_ALLOWED_FOPT.find(scno) != SYSCALL_ALLOWED_FOPT.end())
	{
		if (fopt_allowed_fd.find(arg0) == fopt_allowed_fd.end())
			return scno;
		return 0;
	}

	auto p = syscall_remain.find(scno);
	if (p == syscall_remain.end() || !p->second)
		return scno;
	p->second --;
	return 0;
}

void *get_instruction_addr(pid_t pid)
{
	struct user_regs_struct regs;
	ptrace(PTRACE_GETREGS, pid, nullptr, &regs);
#ifdef __x86_64__
	return (void*)regs.rip;
#else
	return (void*)regs.eip;
#endif
}

void ptrace_goto(pid_t pid, void *addr)
{
	struct user_regs_struct regs;
	ptrace(PTRACE_GETREGS, pid, nullptr, &regs);
#ifdef __x86_64__
	regs.rip = (size_t)addr;
#else
	regs.eip = (size_t)addr;
#endif
	ptrace(PTRACE_SETREGS, pid, nullptr, &regs);
}

void init_syscall_check()
{
	syscall_remain = SYSCALL_LIMIT;
	for (auto &i: syscall_remain)
		i.second *= 2;
}

void get_ptrace_str(pid_t pid, size_t addr, char *buf, size_t len)
{
	errno = 0;
	typedef long word;
	for (size_t pos = 0; ; )
	{
		*(word*)(buf + pos) = ptrace(PTRACE_PEEKDATA, pid, addr, nullptr);
		if (errno)
			throw AI9Error("failed to peek data: %m");
		for (size_t i = 0; i < sizeof(word); i ++)
		{
			if (!buf[pos ++])
				return;
			if (pos == len)
			{
				buf[pos - 1] = 0;
				return;
			}
		}
		addr += sizeof(word);
	}
}

void add_allowed_open_path(const char *path)
{
	open_allowed_path.insert(path);
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


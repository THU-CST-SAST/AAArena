//
// 2013智能体系列赛 逻辑内核
// 作者 李浩达 lihaoda9@163.com
// 2013-07-18
//


#include "logic.hh"
#include "ai9.hh"
#include "gc_socket.h"

#include "json/json.h"

#include "sdk.h"
#include <algorithm>
#include <string.h>
#include <string>
#include "output.h"
#include "gc_logic.h"
#include "MapGenX.h"
#include "MapGenX.2.h"
#include "MapGenX.4.h"
#include "MapGenX.5.h"
#include "achieve.h"
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <functional>
//初始化游戏信息
using namespace std;


const char map_file[] = "map.txt";
const char out_file[] = "result.txt";
int winner = -1;
int ob_id = 0;
int PLAYER_NUM         = 2;
int MINE_NUM           = 6;
enum {fight=0,contest=1} game_mode;
Map game_map;
Mine game_mines[MAX_MINE_NUM];
Player game_players[MAX_PLAYER_NUM];
int ob_num[MAX_PLAYER_NUM];
GameInfo game_info;
View view[MAX_PLAYER_NUM];
vector<Observer> observers;
AchieveSys achievesys;
bool err_flag = false;
std::string err_message;
ofstream game_fout;
MapGenBase* map_gen = NULL;


#define DBG(x) ;

int normal_game(int,char**);
int contest_game(int,char**,std::string,int);
int main(int argc, char** argv)
{
  try{
	std::ifstream fin("resources.res");
	if(!fin)
		cout << "resources file open failed!" << endl;
	std::string res;
	char ch;
	while (fin >> ch) res.push_back(ch);
	fin.close();
	Json::Value root;
	Json::Reader reader;
	if (!reader.parse(res , root))
	{
		// EXCEPTION
		return -1;
	}
	std::string str_mode = root["mode"].asString();
	int contest_rd = CONTEST_ROUND;
	int mode = -1;
	if (str_mode == "fight")
	{
		mode = 0;
		game_mode = fight;
		map_gen = new MapGenX(map_file);
	}
	else
	{
		game_mode = contest;
		if (str_mode == "contest_level_1") mode = 1;
		else if (str_mode == "contest_level_2")
		{
			mode = 2;
			map_gen = new MapGenX2((str_mode+".txt").c_str());
		}
		if (str_mode == "contest_level_3") mode = 3;
		if (str_mode == "contest_level_4")
		{
			mode = 4;
			map_gen = new MapGenX4((str_mode+".txt").c_str());
		}
		if (str_mode == "contest_level_5")
		{
			mode = 5;
			map_gen = new MapGenX5((str_mode+".txt").c_str());
			contest_rd = 55;
		}
	}
	if(!mode)
	  return normal_game(argc,argv);
	else
	  return contest_game(argc,argv,str_mode+".txt",contest_rd);
  }
  catch (std::exception &e)
  {
    fprintf(stderr, "%s: caught exception: %s\n", argv[0], e.what());
    return -1;
  }
}
int contest_game(int argc,char** argv,std::string filename, int max_rd)
{
  PLAYER_NUM = 1;
  game_info_init();
  if(!map_load(filename.c_str(),0))
    throw AI9Error("map load failed!");
  if(!start_info_load())
  {
    DBG(start info load failed);
    throw AI9Error("start info load failed!");
  }
  GameInfoMeta ginfometa;
  ginfometa.rlim_mem = 1 << 30;
  logic::init(argc,argv,ginfometa,[&game_map](int,SocketBase& c)
	{
		c << game_map;
	});
  //cout << "debug mark 2!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  if (logic::get_nr_ai() != 1)
    throw AI9Error("1 AI are required!");
  
  if(!init_output())
  {
    DBG(init output failed);
    throw AI9Error("init output failed!");
  }
  int rounds = -1;
    for(int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            view[0](i,j) = 1;
  bool pass_flag = 0;
  while((++rounds) < max_rd)
  {
    cout << "context rounds: " << rounds << endl;
    DBG(new round ----------------);
    //calc_view();
    DBG(mark1);
    Action act;
    //cout << "load" << endl;
    //cout << "mark 1 ~~~~~~~~~~~~~~~~~\n";
    if(!round_load( NULL, 0, act))
    {
      err_flag = 1;
      err_message = "ai 0 failed!" ;
      throw AI9Error("ai 0 failed in round load!");
    };
    //cout << "mark 2 ~~~~~~~~~~~~~~~~~\n";
    DBG(mark2);
    //cout << "exec" << endl;
    mine_change();
    move_player(game_players[0],act);
    observerchange();
    game_info_execute();
    //cout << "mark 3 ~~~~~~~~~~~~~~~~~\n";
    DBG(mark3);
    //cout << "out" << endl;
    round_output();                       //输出回合信息
    pass_flag = 1;
    for (int i = 0; i < MINE_NUM; ++i)
      {
	if (game_mines[i].owner == -1)
	{
	  pass_flag = 0;
	  break;
	}
      }
    if(pass_flag)
      break;
    DBG(mark4);
    if(game_info.rounds != max_rd)
      game_fout << ',';
  }
  game_fout << "]," << endl;
  if(pass_flag)
    game_fout << "\"result\": {"
       << "\"pass\":" << "\"true\""<< "}}";
  else
    game_fout << "\"result\": {"
       << "\"pass\":" << "\"false\""<< "}}";
  return 0;
}
int normal_game(int argc, char** argv)
{
 // cout << "start !!!!!!!!!!!!!!!!!!!!!!!!!\n";
  if (!game_init(argc,argv))
    throw AI9Error("game init failed!");
  if (!game_round())
    throw AI9Error("game round failed!");
  if (!game_result())
    throw AI9Error("game end failed!");
  return 0;
}
bool game_info_init()
{
  memset((void*)(&game_info), 0, sizeof(game_info));
  observers.clear();
  return true;
}

#define DBG(x) ;
#define DBGI(x) ;
#define DBGX(x) ;

int legal_map()
{
  for (int i = 0; i < 31; ++i)
    for (int j = 0; j < 31; ++j)
    {
      if(game_map.grids[i][j].terrain != game_map.grids[30-i][30-j].terrain)
      {
        return 0;
      }
    }
  std::cout << "in legal_map ... " << std::endl;
  Position que[1000];
  que[0] = game_players[0].pos;
  bool flg[31][31] = {0};
  flg[que[0].x][que[0].y] = 1;
  int ddx[] = {0,1,0,-1};
  int ddy[] = {1,0,-1,0};
  int i = 0;
  int j = 1;
  int m_count = 0;
  while(i<j)
  {
    if(game_map.grids[que[i].x][que[i].y].mine_id != -1)
        m_count++;
    for (int k = 0; k < 4; ++k)
    {
      Position tmp(que[i].x+ddx[k],que[i].y+ddy[k]);
      if (tmp.x >= 0 && tmp.x <31 && tmp.y >= 0 && tmp.y <31 && game_map.grids[tmp.x][tmp.y].terrain == MapGrid::FLAT && !flg[tmp.x][tmp.y])
      {
        que[j++] = tmp;
        flg[tmp.x][tmp.y] = 1;
      }
    }
    ++i;
  }
  
  std::cout << "end legal_map ... " << std::endl;
  return m_count;
}
bool map_load(const char* map_file_name,int set_num)
{
  MINE_NUM = 0;
  while(MINE_NUM != 6)
  {
  if(map_gen)
  {
    map_gen->gen();
    map_gen->print();
  }
  ifstream fin(map_file_name);
  if(!fin)
  {
    cout << "map file: " << map_file_name << " open failed!" << endl;
    return false;
  }
  char temp;
  int mine_id = 0;
  DBG(st map ld...);
  for (int i = 0; i < MAP_WIDTH; ++i)
  {
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
      DBGX(cout << i << ',' << j << ": ");
      if (!(fin >> temp))
        return false;
      game_map.grids[i][j].pos = Position(i,j);
      DBGI(temp);
      switch (temp)
      {
        case '.':
          game_map.grids[i][j].terrain = MapGrid::FLAT;
          game_map.grids[i][j].mine_id = -1;
          break;
        case '#':
          game_map.grids[i][j].terrain = MapGrid::BLOCK;
          game_map.grids[i][j].mine_id = -1;
          break;
        case '$':
          game_map.grids[i][j].terrain = MapGrid::FLAT;
          game_map.grids[i][j].mine_id = mine_id;
          game_mines[mine_id].pos = Position(i,j);
          mine_id++;
          break;
        case '1':
          game_map.grids[i][j].terrain = MapGrid::FLAT;
          game_map.grids[i][j].mine_id = -1;
          game_players[0].pos = Position(i,j);
          break;
        case '2':
          game_map.grids[i][j].terrain = MapGrid::FLAT;
          game_map.grids[i][j].mine_id = -1;
          game_players[1].pos = Position(i,j);
          break;
        default:
          return false;
      }
    }
  }
  fin.close();
  MINE_NUM = mine_id;
  if(set_num && legal_map() != set_num)
  {
     MINE_NUM = 0;
  }
  }
  game_map.grids[game_players[0].pos.x][game_players[0].pos.y].players.push_back(0);
  game_map.grids[game_players[1].pos.x][game_players[1].pos.y].players.push_back(1);
  delete map_gen;
  DBG(at mp load end);
  return true;
}

#undef DBG
#undef DBGI
#undef DBGX

#define DBG(x)
#define DBGI(x)
#define DBGX(x)


bool start_info_load()
{
  for (int i = 0; i < MINE_NUM; ++i)
  {
    game_mines[i].id = i;
  }
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    game_players[i].owner = i;
  }
  return true;
}


bool game_init(int argc, char** argv)
{
  DBG(init...);
  game_info_init();
  if(!map_load(map_file,6))
  {
    DBG(map load failed);
    return false;
  }
  DBG(map loaded);
  if(!start_info_load())
  {
    DBG(start info load failed);
    return false;
  }
  DBG(star info loaded);

  GameInfoMeta ginfometa;//@@@@@
  ginfometa.rlim_mem = 1 << 30;//@@@@@
  
  //cout << "debug mark 1!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  logic::init(argc,argv,ginfometa,[&game_map](int,SocketBase& c)//@@@@@
	{
		c << game_map;
	});
  //cout << "debug mark 2!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
  if (logic::get_nr_ai() != 2)//@@@@@
    throw AI9Error("2 AIs are required!");

  if(!init_output())
  {
    DBG(init output failed);
    return false;
  }//输出初始信息,未完成
  DBG(finish init.);
  return true;
}


bool get_gold()
{
  for (int i = 0; i < MINE_NUM; ++i)
  {
    if (game_mines[i].owner != -1)
    {
      game_info.golds[ game_mines[i].owner ] += game_mines[i].gain_rate;
    }
  }
  return true;
}

inline void change_mine_point(Mine& mine, int i)
{
  switch (i)
  {
    case 0:
      --mine.own_point;
      break;
    case 1:
      ++mine.own_point;
      break;
    default:
      break;
  }
}

bool mine_change()
{
  for (int i = 0; i < MINE_NUM; ++i)
  {
    Mine& mine = game_mines[i];
    Position& pos = mine.pos;
    std::vector<int>& players = game_map.grids[pos.x][pos.y].players;
    if (players.size() > 0)
    {
        if (players.size() == 1)
        {
            if (game_players[ players[0] ].owner == mine.owner)
            {
                if (mine.owner)
                    mine.own_point = 5;
                else
                    mine.own_point = -5;
            }
            else if(mine.protect_round == 0)
            {
                change_mine_point(mine, game_players[ players[0] ].owner);
            }
        }
        else if (players.size() == 2)
        {
            if (mine.owner != -1)
            {
                if (mine.owner)
                    mine.own_point = 5;
                else
                    mine.own_point = -5;
            }
            else
                change_mine_point(mine, rand()%2);
        }
    }
  }
  for (int i = 0; i < MINE_NUM; ++i)
  {
    Mine& mine = game_mines[i];
    switch (mine.own_point)
    {
      case 0:
        mine.owner = -1;
        break;
      case 5:
        mine.owner = game_players[1].owner;
        break;
      case -5:
        mine.owner = game_players[0].owner;
        break;
      default:
        break;
    }
    if (mine.protect_round > 0)
      mine.protect_round--;
  }
  return true;
}

inline int get_blink_cd(Player& player)
{
  return BLINK_CD_INIT + game_info.mine_num[ player.owner ] * BLINK_RATE;
}

bool set_ob(Player& player, Position p)
{
  Observer ob;
  ob.id = ob_id;
  ob.pos = p;
  ob.owner = player.owner;
  ob.last_time = OBSERVER_ROUND;
  observers.push_back(ob);
  ob_id++;
  return true;
}


bool move_player(Player& player, Action& act)
{
  Position now_p = player.pos;
  Position new_p = now_p;
  switch (act.move)
  {
    case Action::Up:
      new_p.y++;
      break;
    case Action::Left:
      new_p.x--;
      break;
    case Action::Down:
      new_p.y--;
      break;
    case Action::Right:
      new_p.x++;
      break;
    case Action::Blink:
      new_p = act.blink_pos;
      break;
    default:
      break;
  }
  if (legal_pos(new_p) && get_terrain(game_map,new_p) == MapGrid::FLAT)
  {
    double length_limit = 1;
    if (act.move == Action::Blink)
      length_limit = BLINK_LIMIT;
    if (in_range(now_p, new_p, (double)length_limit) && (act.move != Action::Blink || player.blink_cd == 0))
    {
      MapGrid& tmp_grid1 = game_map.grids[now_p.x][now_p.y];
      MapGrid& tmp_grid2 = game_map.grids[new_p.x][new_p.y];
      for (vector<int>::iterator it = tmp_grid1.players.begin(); it != tmp_grid1.players.end();)
      {
        if (*it == player.owner)
        {
          tmp_grid1.players.erase(it);
          break;
        }
        else
        {
          ++it;
        }
      }
      tmp_grid2.players.push_back(player.owner);
      player.pos = new_p;
      if (act.move == Action::Blink)
        player.blink_cd = get_blink_cd(player) + 1;
    }
  }
  if (act.setOB && game_info.golds[player.owner] >= OBSERVER_RATE*ob_num[player.owner])
  {
    game_info.golds[player.owner] -= OBSERVER_RATE*ob_num[player.owner];
    set_ob(player, now_p);
  }
  int m_id = game_map.grids[now_p.x][now_p.y].mine_id;
  if (m_id != -1  &&
      game_mines[m_id].owner == player.owner)
  {
    if (act.buy_protect && game_info.golds[player.owner] >= MINE_PROTEC_RATE*game_info.mine_num[player.owner])
    {
      game_info.golds[player.owner] -= MINE_PROTEC_RATE*game_info.mine_num[player.owner];
      game_mines[m_id].protect_round = MINE_PROTEC_ROUND;
    }
  }
  if (player.blink_cd > 0)
    player.blink_cd--;
  return true;
}

bool observerchange()
{
  for (vector<Observer>::iterator it = observers.begin(); it != observers.end();)
  {
    it->last_time--;
    if (it->last_time < 0 || it->pos == game_players[ !(it->owner) ].pos)
    {
      it = observers.erase(it);
    }
    else
    {
      it++;
    }
  }
  return true;
}

bool move_players(Action& act_p1, Action& act_p2)
{
  move_player(game_players[0], act_p1);
  move_player(game_players[1], act_p2);
  return true;
}

bool calc_mine_num()
{
  int sum[MAX_PLAYER_NUM] = {0};
  for (int i = 0; i < MINE_NUM; ++i)
    if (game_mines[i].owner != -1)
      sum[ game_mines[i].owner ]++;
  for (int i = 0; i < PLAYER_NUM; ++i)
    game_info.mine_num[i] = sum[i];
  return true;
}
bool calc_ob_num()
{
  for (int i = 0; i < PLAYER_NUM; ++i)
    ob_num[i] = 0;
  for (int i = 0; i < observers.size();++i)
    ob_num[observers[i].owner]++;
  return true;
}
bool game_info_execute()
{
  get_gold();
  calc_mine_num();
  game_info.rounds++;
  return true;
}

bool round_execute(Action& act_p1, Action& act_p2)
{
  mine_change();
  calc_mine_num();
  calc_ob_num();
  move_players(act_p1, act_p2);
  observerchange();
  game_info_execute();
  return true;
}


bool round_load(std::function<void(Map&, GameInfo&, RoundInfo&, Action&)> player_func, int owner, Action& act)
{
  //cout << "build info" << endl;
  GameInfo gm_info = game_info;
  /*Map new_map = game_map;

  int mine_count = 0;
  for (int i = 0; i < MAP_WIDTH; ++i)
      for (int j = 0 ; j < MAP_HEIGHT; ++j)
      {
          if(!view[owner](i,j))
          {
              new_map.grids[i][j].terrain = MapGrid::UNSEEN;
          }
      }
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    DBGX(cout << game_players[i].pos.x << ',' << game_players[i].pos.y << endl);
    new_map.grids[ game_players[i].pos.x ][ game_players[i].pos.y ].players.clear();
  }

  DBG(mark1-1);

  DBG(mark1-2);*/
  //cout << "mark1" << endl;
  RoundInfo rd_info;
  rd_info.round = gm_info.rounds;
  rd_info.player_id = owner;
  for (int i = 0; i < observers.size(); ++i)
  {
    if ( view[owner](observers[i].pos) )
    {
      rd_info.observers.push_back( observers[i] );
    }
  }
  DBG(mark1-3);
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    if ( view[owner](game_players[i].pos) )
    {
      rd_info.players.push_back(game_players[i]);
     // new_map.grids[ game_players[i].pos.x ][ game_players[i].pos.y ].players.push_back(i);
    }
  }
  DBG(mark1-4);
  for (int i = 0; i < MINE_NUM; ++i)
  {
    rd_info.mines.push_back(game_mines[i]);  //矿点恒可见
   // new_map.grids[ game_mines[i].pos.x ][ game_mines[i].pos.y ].mine_id = i;
  }

  DBG(mark1-5);

  RoundInfoMeta rinfometa;//@@@@@
  rinfometa.rlim_cpu = 1;//@@@@@
  auto &conn = logic::get_conn(owner);//@@@@@
  logic::start_round(conn, rinfometa);//@@@@@


  //cout << "mark2" << endl;
  XSend(conn,game_map, view[owner]);//@@@@@
  conn << game_info;//@@@@@
  conn << rd_info;//@@@@@
  //cout << "mark3" << endl;
  RoundResultMeta rst;//@@@@@
  //cout << "wait" << endl;
  logic::wait(conn, rst);//@@@@@
  //cout << "mark4" << endl;
  //cout << "result" << endl;
  typedef RoundResultMeta::Status STATU;//@@@@@

  if (rst.status == STATU::NORMAL)//@@@@@
  {
    conn >> act;
    //cout << (int)act.move << endl;
  }
  else//@@@@@
  {
    err_message = RoundResultMeta::status2str(rst.status);
    fprintf(stderr, "AI %d exited with status %d(%s), "
	    "status_data=%d, err_msg=%s\n",
	    owner, int(rst.status),
	    err_message.c_str(),
	    rst.status_data, rst.err_msg);
    cout << "AI " << owner << " died\n";
    return false;
  }
  //cout << "end" << endl;
  return true;
}

bool make9view(Position pos, View& view, bool value)
{
  const int dx[] = {0,-1,1};
  const int dy[] = {0,-1,1};
  for (int i = 0; i < 3; ++i)
  {
    for (int j = 0; j < 3; ++j)
    {
      Position tmp = pos + Position(dx[i],dy[j]);
      if (legal_pos(tmp))
      {
        view(tmp) = value;
      }
    }
  }
  return true;
}


bool make_line_view(Position pos, View& view, bool value)
{
  const int dx[] = {0,0,1,-1};
  const int dy[] = {1,-1,0,0};
  for (int i = 0; i < 4; ++i)
  {
    Position tmp = pos;
    Position dP(dx[i],dy[i]);
    do
    {
      // DBGX(cout << pos.x << ',' << pos.y << endl);
      make9view(tmp, view, 1);
      tmp = tmp + dP;
    }while( legal_pos(tmp) && get_terrain(game_map, tmp) == MapGrid::FLAT);
  }
  return true;
}

bool calc_view(View& view, int owner)
{
    for(int i = 0; i < MAP_WIDTH; ++i)
        for (int j = 0; j < MAP_HEIGHT; ++j)
            view(i,j) = 0;
  for (int i = 0; i < MINE_NUM; ++i)
  {
    make9view(game_mines[i].pos, view, 1);
  }
  DBG(calc view : step1 finish);
  make_line_view(game_players[owner].pos, view, 1);
  DBG(st step2);
  for (int i = 0; i < observers.size(); ++i)
  {
    if (observers[i].owner == owner)
    {
      make_line_view(observers[i].pos, view, 1);
    }
  }
  return true;
}


bool calc_view()
{
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    calc_view(view[i],i);
  }
  return true;
}


//回合循环及操作
bool game_round()
{
  int rounds = -1;
  achievesys.at_game_start();
  //ofstream debug("debug.txt");
  while((++rounds) < GAME_ROUND)
  {
    cout << "rounds: " << rounds << endl;
    DBG(new round ----------------);
    DBGI(rounds);
    calc_view();
    DBG(mark1);
    Action act[2];
    //cout << "load" << endl;
    //cout << "mark 1 ~~~~~~~~~~~~~~~~~\n";
    if(!round_load( NULL, 0, act[0]))
    {
      winner = 1;
      err_flag = 1;
      err_message = "ai 0 failed!" ;
      return true;
    };
    if(!round_load( NULL, 1, act[1]))
    {
      err_flag = 1;
      winner = 0;
      err_message = "ai 1 failed!" ;
      return true;
    };    //载入回合信息并调用选手AI
    //cout << "mark 2 ~~~~~~~~~~~~~~~~~\n";
    DBG(mark2);
    //cout << "exec" << endl;
    round_execute(act[0], act[1]);        //处理回合信息及变化
    /*debug << "rounds: " << rounds << " "
		<< (int)act[0].move << " "
		<< (int)act[1].move << endl;*/
    //cout << "mark 3 ~~~~~~~~~~~~~~~~~\n";
    DBG(mark3);
    //cout << "out" << endl;
    if (rounds != 0)
    	game_fout << ',';
    round_output();                       //输出回合信息
    DBG(mark4);
    achievesys.at_round_end();
  }
  return true;
}


int get_winner()
{
  if(err_flag)
    return winner;
  int golds0 = game_info.golds[0];
  int golds1 = game_info.golds[1];
  if (golds0 == golds1)
    if (game_info.mine_num[1] == game_info.mine_num[0])
      return -1;
    else
      return game_info.mine_num[1] > game_info.mine_num[0];
  else
    return golds1 > golds0;
}

bool game_result()
{
  achievesys.at_game_end();
  winner = get_winner();
  result_output();
  return true;
}


bool init_output()
{
  game_fout.open(out_file);
  game_fout << "{ ";
  game_fout << "\"map\":" << game_map << ','<< endl;
  game_fout << "\"init-players\":[";
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    game_fout << game_players[i];
    if (i < PLAYER_NUM-1)
      game_fout << ',';
  }
  game_fout << "], ";
  game_fout << "\"init-mines\":[";
  for (int i = 0; i < MINE_NUM; ++i)
  {
    game_fout << "{ \"id\":" << game_mines[i].id <<','
	      << "\"x\":" << game_mines[i].pos.x << ','
	      << "\"y\":" << game_mines[i].pos.y << ','
	      << "\"owner\":" << game_mines[i].owner << ','
	      << "\"point\":" << game_mines[i].own_point << ','
	      <<"\"ptc-round\":" << game_mines[i].protect_round << ','
	      <<"\"gain-rate\":" << game_mines[i].gain_rate << "}";
    if (i < MINE_NUM-1)
      game_fout << ',';
  }
  game_fout << "], \"rounds-info\":[";
  return true;
}


void round_output()
{
  ostream& ss = game_fout;
  ss << "{";
  ss << "\"rounds\":" << game_info.rounds-1<<','<<endl;
  ss << "\"ginfo\":" << game_info << ',' << endl;
  ss << "\"players\":[";
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    ss << game_players[i] << endl;
    if (i < PLAYER_NUM -1)
      ss << ',';
  }
  ss << "],\"mines\":[";
  for (int i = 0; i < MINE_NUM; ++i)
  {
    ss << game_mines[i] << endl;
    if (i < MINE_NUM-1)
      ss << ',';
  }
  ss << "],\"OB\":[";
  for (int i = 0; i < observers.size(); ++i)
  {
    ss << observers[i] << endl;
    if (i < observers.size()-1)
      ss << ',';
  }
  ss << "]}";
  //round_out = ss.str();
}



void result_output()
{
  
  ostream& ss = game_fout;
  
  ss << "]," << endl;
  if(!err_flag)
  {
  ss << "\"result\": {"
	    << "\"type\":" << "\"normal\","
	      << "\"winner\":" << winner << "}, \"achieves\":[";
  for(int i = 0;i < PLAYER_NUM; ++i)
  {
    ss << "{\"id\":\"" << i << "\",\"achieve\":[";
    ACHIEVE ach = achievesys.get_achieve(i);
    for(int j = 0; j < ach.size(); ++j)
    {
      ss << "{\"name\":\"" << ach[j].first << "\","
           <<"\"value\":\""<< ach[j].second << "\"}";
      if (j != ach.size()-1)
        ss << ',';
    }
    ss << "]}";
    if (i != PLAYER_NUM-1)
      ss << ',';
  }
  ss<<"]}";
  }
  else
  {
    ss << "\"result\": {"
	    << "\"type\":" << "\"error\","
	      << "\"winner\":" << winner << "}}";
  }
}

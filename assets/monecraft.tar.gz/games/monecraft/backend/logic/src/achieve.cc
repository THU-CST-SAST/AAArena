#include "achieve.h"
#include <sstream>
#include <iostream>
using namespace std;
template<class T> void AchieveSys::add_to_achieves(int id,std::string name,T item)
{
	if(id < 0 || id >= MAX_PLAYER_NUM)
		return;
	ostringstream o;
	o << item;
	achieves[id].push_back(pair<string,string>(name,o.str()));
}

void AchieveSys::at_game_start()
{
}


void AchieveSys::at_round_end()
{
}


void AchieveSys::at_game_end()
{
	add_to_achieves(0,string("test"),1);
}

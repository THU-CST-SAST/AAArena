#include "sdk.h"
Position operator+(const Position& p1, const Position& p2)
{
  return Position(p1.x + p2.x, p1.y + p2.y);
}

Position operator-(const Position& p1, const Position& p2)
{
  return Position(p1.x - p2.x, p1.y - p2.y);
}
bool in_range(const Position& p1, const Position& p2, double length)
{
  double ddx = p1.x - p2.x, ddy = p1.y - p2.y;
  return ddx*ddx + ddy*ddy < length * length + EPS;
}
bool legal_pos(const Position p)
{
  return p.x >= 0 && p.x < MAP_WIDTH && p.y >= 0 && p.y < MAP_HEIGHT;
}

MapGrid::Terrain get_terrain(const Map& m, int x, int y)
{
  return m.grids[x][y].terrain;
}
MapGrid::Terrain get_terrain(const Map& m, Position pos)
{
  return get_terrain(m,pos.x,pos.y);
}

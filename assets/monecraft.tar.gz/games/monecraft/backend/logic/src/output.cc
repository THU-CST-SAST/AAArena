#include "sdk.h"
#include <fstream>


#define DEBUG___LHD_FLAG__
#ifdef DEBUG___LHD_FLAG__
#define DBG(x) x
#include <iostream>
#else
#define DBG(x)
#endif //DEBUG___LHD_FLAG__

using namespace std;
ostream& operator<<(ostream& ot, const GameInfo& g)
{
  ot << '[';
  for (int i = 0; i < PLAYER_NUM; ++i)
  {
    ot << "{\"id\":" << i << ',';
    ot << "\"mine-num\":" << g.mine_num[i] << ','
       << "\"golds\":" << g.golds[i] << '}';
    if (i < PLAYER_NUM -1)
      ot << ',';
  }
  ot << ']';
  return ot;
}
ostream& operator<<(ostream& ot, const Mine& m)
{
  ot << "{";
  ot << "\"id\":" << m.id << ','
     << "\"owner\":" << m.owner << ','
     << "\"point\":" << m.own_point << ','
     << "\"ptc-round\":" << m.protect_round << "}" << endl;
  return ot;
}
ostream& operator<<(ostream& ot, const Player& p)
{
  ot << "{";
  ot << "\"id\":" << p.owner << ','
     << "\"x\":" << p.pos.x << ','
     << "\"y\":" << p.pos.y << ','
     << "\"blink-cd\":" << p.blink_cd << "}"<<endl;
  return ot;
}
ostream& operator<<(ostream& ot, const Observer& ob)
{
  ot << "{";
  ot << "\"id\":" << ob.id << ','
     << "\"owner\":" << ob.owner << ','
     << "\"x\":" << ob.pos.x << ','
     << "\"y\":" << ob.pos.y << ','
     << "\"last-time\":" << ob.last_time << "}" << endl;
  return ot;
}
ostream& operator<<(ostream& ot, const Map& m)
{
  ot << '{';
  ot << "\"width\":" << MAP_WIDTH << ','
     << "\"height\":" << MAP_HEIGHT << ','
     << "\"terrain\":\"";
  for (int i = 0; i < MAP_WIDTH; ++i)
  {
    for (int j = 0; j < MAP_HEIGHT; ++j)
    {
      // DBG(cout << i << ',' << j << endl);
      if (m.grids[i][j].terrain == MapGrid::FLAT)
        ot << '.';
      else if (m.grids[i][j].terrain == MapGrid::BLOCK)
        ot << '#';
      else
        ot << '?';
    }
  }
  ot << "\"}";
  return ot;
}

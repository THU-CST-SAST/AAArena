#ifndef MapGenBase_H
#define MapGenBase_H

#include <fstream>
extern const int size;
extern const char BLOCKES;
extern const char PLAIN;
extern const char PLAYER_1;
extern const char PLAYER_2;
extern const char GOLD_MINE;
class MapGenBase
{
  protected:
	const char* file;
	char a[50][50];
	bool aa_arena_seeded_ = false;
  public:
	MapGenBase(const char* f = "map.txt");
	virtual ~MapGenBase() = default;
	virtual void gen() = 0;
	virtual void print();
};


#endif //MapGenBase_H

#ifndef MapGenX2_H
#define MapGenX2_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include "MapGenBase.h"


class MapGenX2: public MapGenBase
{
	const int GoldNum;
	const int COMPLEXITY;
	public:
		MapGenX2(const char* f = "map.txt");
		void gen();
};

#endif //MapGenX_H

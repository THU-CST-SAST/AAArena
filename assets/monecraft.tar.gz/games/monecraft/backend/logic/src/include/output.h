#ifndef OUTPUT_H_LIHAODA__
#define OUTPUT_H_LIHAODA__


#include "sdk.h"
#include <fstream>

std::ostream& operator<<(std::ostream& ot, const GameInfo& g);
std::ostream& operator<<(std::ostream& ot, const Mine& m);
std::ostream& operator<<(std::ostream& ot, const Player& p);
std::ostream& operator<<(std::ostream& ot, const Observer& ob);
std::ostream& operator<<(std::ostream& ot, const Map& m);
void outround(std::ostream& o, RoundInfo& rdinfo);
#endif //OUTPUT_H_LIHAODA__

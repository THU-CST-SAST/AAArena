#ifndef MapGenX4_H
#define MapGenX4_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include "MapGenBase.h"
using namespace std;

class MapGenX4 :public MapGenBase
{
	struct Point{
		int x, y;
		Point(){}
		Point(int _x, int _y)
			:x(_x), y(_y){}
		Point operator+(const Point& a)const{
			return Point(x + a.x, y + a.y);
		}
	};
	static const int GoldNum;
	static const Point dir[4];
	MapGenX4::Point seeds[50 * 50];
	int seedsSize;

	bool inMap(const Point& pos);
	bool isLeaf(const Point& pos);
	bool canMoveTo(const Point& pos);
	bool canPut(const Point& pos);
	public:
		MapGenX4(const char* f = "map.txt");
		void gen();
};

#endif //MapGenX4_H

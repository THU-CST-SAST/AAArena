#ifndef MapGenX_H
#define MapGenX_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include "MapGenBase.h"



class MapGenX:public MapGenBase
{
	int tot;
	int f[1200];
	const int GoldNum;
	const int COMPLEXITY;
	bool check_gen(int);
	bool square(int, int);
	void spec_gen(int);
	bool blocked_off();
	int gf(int);
	public:
		MapGenX(const char* ff = "map.txt");
		void gen();
};

#endif //MapGenX_H


#ifndef AI_GAME_CORE_H_2013_LIHAODA__
#define AI_GAME_CORE_H_2013_LIHAODA__

#include <vector>
#include <fstream>
const int MAP_WIDTH          = 31;      //地图宽
const int MAP_HEIGHT         = 31;      //地图高
const int MAX_PLAYER_NUM     = 2;	//玩家数上限
extern int PLAYER_NUM;
const int BLINK_CD_INIT      = 5;       //闪烁初始CD
const int MINE_PROTEC_RATE   = 100;      //购买塔防所需金子，待定
const int MINE_PROTEC_ROUND  = 80;      //塔防时间，待定
const int OBSERVER_RATE      = 10;      //购买侦察者所需金子，待定
const int OBSERVER_ROUND     = 50;      //观察者持续回合，待定
const int GAME_ROUND         = 1000;      //总回合数
const int CONTEST_ROUND      = 500;
const int MAX_MINE_NUM       = 20;
extern int MINE_NUM;
const int GAIN_RATE          = 10;      // 每回合矿点提供的金子数，暂定为10个
const int BLINK_RATE         = 3;      //每拥有一个矿点的闪烁CD增量
const double BLINK_LIMIT     = 2.9;      //blink距离限制
const double EPS = 1e-6;

struct Player;
struct Mine;

struct Position
{
  int x, y;
  bool operator==(const Position& p) const
  {
    return x == p.x && y == p.y;
  }
  Position& operator=(const Position& p)
  {
    x = p.x;
    y = p.y;
    return *this;
  }
 Position ():x(-100),y(-100){}
 Position(int i, int j):x(i),y(j){}
};


Position operator+(const Position& p1, const Position& p2);

Position operator-(const Position& p1, const Position& p2);
bool in_range(const Position& p1, const Position& p2, double length);
bool legal_pos(const Position p);


struct MapGrid
{
  Position pos;
  enum Terrain                      //地形信息
  {
    FLAT = 0,                       //平地
    BLOCK,                          //障碍
    UNSEEN                          //不在视野内
  } terrain;
  int mine_id;                      //在该格点上的金矿编号，没有或不可见则为-1
  std::vector<int> players;     //站在该格点上的玩家编号，没有则为空
 MapGrid():pos(-1,-1),mine_id(-1)
  {
    players.clear();
  }
};


struct Observer
{
  int id;        //编号
  Position pos;  //位置
  int last_time; //剩余持续时间
  int owner;     //拥有者
 Observer():
  owner(-1),
  pos(0,0),
  last_time(OBSERVER_ROUND)
  {}
};


struct Map
{
  MapGrid grids[ MAP_WIDTH ][ MAP_HEIGHT ];
};


MapGrid::Terrain get_terrain(const Map& m, int x, int y);
MapGrid::Terrain get_terrain(const Map& m, Position pos);
struct Mine
{
  int id;
  Position pos;
  int owner;                      //默认为-1
  int own_point;                  //初始为0，达到+5 或 -5 时所有权变更，再次变为 0 时所有权将变为中立
  int protect_round;              //若大于0，则一定回合内own_point不会改变
  int gain_rate;                  //每回合给予拥有者的金子数目
 Mine():
  id(-1),
  owner(-1),
  own_point(0),
  protect_round(0),
  gain_rate(GAIN_RATE){}
};


struct Player
{
  Position pos;
  int owner;         //所属玩家
  int blink_cd;      //闪烁cd
  Player()
  {
    owner = -1;
    blink_cd = 0;
  }
};


struct View
{
  bool value[MAP_WIDTH][MAP_HEIGHT];
  void clear()
  {
    int sum = MAP_WIDTH*MAP_HEIGHT;
    for (int i = 0; i < sum; ++i)
      ((bool*)value)[i] = false;
  }
  View()
  {
    clear();
  }
  bool get(int i,int j) const
  {
	return value[i][j];
  }
  bool& operator()(int i, int j)
  {
    return value[i][j];
  }
  bool& operator()(Position p)
  {
    return value[p.x][p.y];
  }
};


struct RoundInfo
{
  int round;
  int player_id;
  std::vector<Observer>  observers;
  std::vector<Player>    players;
  std::vector<Mine>      mines;
};


struct Action //动作信息
{
  enum Move{
  Stop = 0,
  Up,
  Left,
  Down,
  Right,
  Blink
  } move;
  Position blink_pos;         //仅当 move == Blink 时使用
  bool setOB;                 //放置Observer
  bool buy_protect;           //够买金矿保护
};


struct GameInfo
{
  int rounds;
  int mine_num[ MAX_PLAYER_NUM ];         //双方占矿数目
  int golds[ MAX_PLAYER_NUM ];            //双方金子数目
};
extern "C" void player_ai(Map&, GameInfo&, RoundInfo&, Action&);
#endif //AI_GAME_CORE_H_2013_LIHAODA__

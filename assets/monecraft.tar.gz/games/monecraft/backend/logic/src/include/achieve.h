#ifndef AI9_MONECRAFT_LOGIC_ACHIEVE_H__
#define AI9_MONECRAFT_LOGIC_ACHIEVE_H__
#include <string>
#include <utility>
#include <vector>
#include "sdk.h"


extern Map game_map;
extern Mine game_mines[MAX_MINE_NUM];
extern Player game_players[MAX_PLAYER_NUM];
extern GameInfo game_info;
extern View view[MAX_PLAYER_NUM];
extern std::vector<Observer> observers;

typedef std::vector<std::pair<std::string,std::string>> ACHIEVE;
class AchieveSys
{
	ACHIEVE achieves[MAX_PLAYER_NUM];
	template<class T> void add_to_achieves(int id, std::string,T);




public:	
	AchieveSys(){}
	~AchieveSys(){}
	ACHIEVE get_achieve(int id)
	{
		if(id < 0 || id >= MAX_PLAYER_NUM)
			return ACHIEVE();
		return achieves[id];
	}
	void at_game_start();
	void at_round_end();
	void at_game_end();
};
#endif //AI9_MONECRAFT_LOGIC_ACHIEVE_H__

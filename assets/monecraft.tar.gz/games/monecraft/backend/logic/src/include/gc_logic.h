#ifndef LOGIC_H_LIHAODA__
#define LOGIC_H_LIHAODA__



bool game_init(int argc, char** argv);
  bool game_info_init();
  bool map_load(const char* map_file_name,int set_num);
  bool start_info_load();
  bool init_output();

bool game_round();
  bool calc_view();
bool round_load(std::function<void(Map&, GameInfo&, RoundInfo&, Action&)> player_func, int owner, Action& act);
  bool round_execute(Action& act_p1, Action& act_p2);
    bool mine_change();
    bool move_players(Action& act_p1, Action& act_p2);
    bool observerchange();
    bool game_info_execute();
    void round_output();
bool move_player(Player& player, Action& act);
bool game_result();
  void result_output();

#endif //LOGIC_H_LIHAODA__


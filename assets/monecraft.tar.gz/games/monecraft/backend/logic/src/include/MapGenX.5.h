#ifndef MapGenX5_H
#define MapGenX5_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include "MapGenBase.h"
using namespace std;

class MapGenX5: public MapGenBase
{
	struct Point{
		int x, y;
		Point(){}
		Point(int _x, int _y)
			:x(_x), y(_y){}
		Point operator+(const Point& a)const{
			return Point(x + a.x, y + a.y);
		}
	};

	static const Point dir[4];
	static const int STEP;
	
	MapGenX5::Point seeds[50 * 50];
	int seedsSize;
	int dist[50][50];

	bool inMap(const Point& pos);
	bool isLeaf(const Point& pos);
	bool canMoveTo(const Point& pos);
	bool canPut(const Point& pos);
	public:
		MapGenX5(const char* f = "map.txt");
		void gen();
};

#endif //MapGenX5_H

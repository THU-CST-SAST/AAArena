#include "MapGenBase.h"


const int size = 31;
const char BLOCKES = '#';
const char PLAIN = '.';
const char PLAYER_1 = '1';
const char PLAYER_2 = '2';
const char GOLD_MINE = '$';
MapGenBase::MapGenBase(const char* f):file(f){}
void MapGenBase::print()
{
	std::ofstream fout(file);
	for (int i = 0; i < size; ++i)
	{
		for (int j = 0; j < size; ++j)
			fout << a[i][j];
		fout << std::endl;
	}
	fout.close();
}

#include <cstdlib>
#include "MapGenX.5.h"
#define random(l, r) (rand() % ((r) - (l) + 1) + (l))

const int MapGenX5::STEP = 50;
MapGenX5::MapGenX5(const char* f):MapGenBase(f){}
const MapGenX5::Point MapGenX5::dir[4] = {
	Point(0, 1), Point(1, 0), Point(0, -1), Point(-1, 0)};

bool MapGenX5::canMoveTo(const Point& pos){
	return inMap(pos) && a[pos.x][pos.y] != BLOCKES;
}

bool MapGenX5::inMap(const Point& pos){
	return !(pos.x < 0 || pos.y < 0 || pos.x >= size || pos.y >= size);
}

bool MapGenX5::isLeaf(const Point& pos){
	if(!inMap(pos))
		return false;
	int cnt = 0;
	for(int i = 0; i < 4; i++)
		cnt += canMoveTo(pos + dir[i]);
	return cnt == 1;
}

bool MapGenX5::canPut(const Point& pos){
	return isLeaf(pos) && a[pos.x][pos.y] == BLOCKES;
}

void MapGenX5::gen()
{
	//cout << "generating..." << endl;
	const char* aa_arena_seed = std::getenv("AA_ARENA_GAME_SEED");
	// Rejected maps must advance the same random stream instead of repeating forever.
	if (aa_arena_seed) {
		if (!aa_arena_seeded_) {
			std::srand(static_cast<unsigned int>(std::strtoul(aa_arena_seed, nullptr, 10)));
			aa_arena_seeded_ = true;
		}
	} else {
		std::srand(static_cast<unsigned int>(time(NULL)));
	}
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			a[i][j] = BLOCKES;
	seedsSize = 1;
	seeds[0] = Point(0, 0);
	a[seeds[0].x][seeds[0].y] = PLAYER_1;
	while(seedsSize){
		int num = random(0, seedsSize - 1);
		Point &cur = seeds[num];
		int pque = 0, que[4];
		for(int i = 0; i < 4; i++)
			if(canPut(cur + dir[i]))
				que[pque++] = i;
		if(!pque){
			seeds[num] = seeds[--seedsSize];
			continue;
		}
		Point next = cur + dir[que[random(0, pque - 1)]];
		seeds[seedsSize++] = next;
		a[next.x][next.y] = PLAIN;
	}
	for(int i = 0; i < size * 2; i++)
		a[random(0, size - 1)][random(0, size - 1)] = PLAIN;
	const int inf = 0x01010101;
	for(int i = 0; i < size; i++)
		for(int j = 0; j < size; j++)
			dist[i][j] = inf;
	seeds[0] = Point(0, 0);
	dist[0][0] = 0;
	seedsSize = 1;
	for(int i = 0; i < seedsSize; i++){
		Point& cur = seeds[i];
		if(dist[cur.x][cur.y] == STEP){
			int ans = random(i, seedsSize - 1);
			/*for(int i = 0; i < size; i++){
				for(int j = 0; j < size; j++)
					printf("%3d ", (dist[i][j] & 0x1FF));
				printf("\n");
			}*/
			a[seeds[ans].x][seeds[ans].y] = GOLD_MINE;
			break;
		}
		for(int j = 0; j < 4; j++){
			Point next = cur + dir[j];
			if(canMoveTo(next) && dist[next.x][next.y] == inf){
				seeds[seedsSize++] = next;
				dist[next.x][next.y] = dist[cur.x][cur.y] + 1;
			}
		}
	}
}

/*int main(){
	MapGenX5 gen("test.map");
	gen.gen();
	gen.print();
	
	return 0;
}*/


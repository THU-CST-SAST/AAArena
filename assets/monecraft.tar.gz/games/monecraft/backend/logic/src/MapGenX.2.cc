#include <cstdlib>
#include "MapGenX.2.h"
#define random(l, r) (rand() % ((r) - (l) + 1) + (l))



MapGenX2::MapGenX2(const char* f):MapGenBase(f),GoldNum(6),COMPLEXITY(4)	
{
}

static int max(int a, int b)
{
	return a < b ? b : a;
}

void MapGenX2::gen()
{
	//cout << "generating..." << endl;
	const char* aa_arena_seed = std::getenv("AA_ARENA_GAME_SEED");
	// Rejected maps must advance the same random stream instead of repeating forever.
	if (aa_arena_seed) {
		if (!aa_arena_seeded_) {
			std::srand(static_cast<unsigned int>(std::strtoul(aa_arena_seed, nullptr, 10)));
			aa_arena_seeded_ = true;
		}
	} else {
		std::srand(static_cast<unsigned int>(time(NULL)));
	}
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			a[i][j] = BLOCKES;
	if(size <= 5){
		a[1][1] = PLAYER_1;
		a[1][2] = GOLD_MINE;
		return;
	}
	int centerX = random(2, size - 3);
	int centerY = random(2, size - 3);
	int sourceX = random(0, centerX - 1);
	int badX = random(centerX + 1, size - 1);
	int targetY;
	do targetY = random(0, size - 1);
	while(targetY == centerY);
	for(int i = sourceX; i < badX; i++)
		a[i][centerY] = PLAIN;
	for(int i = centerY; i <= targetY; i++)
		a[centerX][i] = PLAIN;
	for(int i = targetY; i <= centerY; i++)
		a[centerX][i] = PLAIN;
	a[sourceX][centerY] = PLAYER_1;
	a[centerX][targetY] = GOLD_MINE;
}


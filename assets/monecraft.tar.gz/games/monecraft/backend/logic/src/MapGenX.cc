#include <cstdlib>
#include "MapGenX.h"
#define random(l, r) (rand() % ((r) - (l) + 1) + (l))


int MapGenX::gf(int x)
{
	return f[x] == x ? x : (f[x] = gf(f[x]));
}

MapGenX::MapGenX(const char* f):MapGenBase(f),tot(0),GoldNum(6),COMPLEXITY(4){}

bool MapGenX::blocked_off()
{
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			f[i * size + j] = i * size + j;
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
		{
			int k = i * size + j;
			if (i && a[i - 1][j] != BLOCKES && a[i][j] != BLOCKES)
				f[gf(k)] = gf(k - size);
			if (j && a[i][j - 1] != BLOCKES && a[i][j] != BLOCKES)
				f[gf(k)] = gf(k - 1);
		}
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			if (a[i][j] == PLAYER_1)
				if (gf(i * size + j) == gf((size - 1 - i) * size + size - 1 - j))
					return false;
				else
					return true;
	return true;
}

int max(int a, int b)
{
	return a < b ? b : a;
}

bool MapGenX::square(int i, int j)
{
	if (i == 0 || j == 0)
		return false;
	if (a[i - 1][j - 1] == BLOCKES)
		return false;
	if (a[i - 1][j] == BLOCKES)
		return false;
	return true;
}

void MapGenX::spec_gen(int n)
{
	int last = -1;
	tot = 0;
	while (1)
	{
		int i, j;
		for (i = last + 1; i < size - 1; ++i)
			if (a[n - 1][i] != BLOCKES && a[n - 1][i + 1] == BLOCKES)
				break;
		if (last == -1 && a[n - 1][0] == BLOCKES && n == size / 2 - 1)
			i = 0;
		if (i >= size - 1)
			break;
		for (j = i + 1; j < size; ++j)
			if (a[n - 1][j - 1] == BLOCKES && a[n - 1][j] != BLOCKES)
				break;
		if (j == size)
			--j;
		++tot;
		for (int k = i; k <= j; ++k)
			a[n][k] = '0' + tot;
		last = j + 1;
	}
}

bool MapGenX::check_gen(int n)
{
	//cout << "generating " << n << "th row..." << endl;
	if (n && random(1, 3) == 1 && tot != 1)
	{
		spec_gen(n);
		return true;
	}
	for (int i = 0; i < size; ++i)
		a[n][i] = BLOCKES;
	int k = random(1, COMPLEXITY);
	tot = 0;
	int len = size / k - 1;
	int f[50], g[50], b[50];
	for (int i = 0; i < size; ++i)
		f[i] = i, g[i] = -i, b[i] = 0;
	int last = -1;
	//cout << k << endl;
	for (int i = 1; i <= k; ++i)
	{
		int start = random(last + 1, max(last + 1, size - 1 - 5 * (k - i + 1)));
		int end = start + random(1, len) - 1;
		if (end > size - 1)
			end = size - 1;
		for (int j = end; j > start; --j)
			if (square(n, j))
				end = j - 1;
		for (int j = start; j <= end; ++j)
			a[n][j] = i + '0';
		//cout << start << " " << end << endl;
		last = end + 1;
	}
	//cout << "square done..." << endl;
	tot = k;
	if (!n)
		return true;
	for (int i = 0; i < size; ++i)
		if (a[n][i] != BLOCKES)
			if (a[n - 1][i] != BLOCKES)
			{
				if (g[a[n][i] - '0'] < 0)
					g[a[n][i] - '0'] = f[a[n - 1][i] - '0'];
				else
					f[a[n - 1][i] - '0'] = g[a[n][i] - '0'];
				b[a[n - 1][i] - '0'] = 1;
			}
	for (int i = 0; i < size; ++i)
		if (a[n - 1][i] != BLOCKES && !b[a[n - 1][i] - '0'])
			return false;
	tot = 0, last = 0;
	for (int i = 0; i < size; ++i)
		if (a[n][i] != BLOCKES)
		{
			if (g[a[n][i] - '0'] != last)
			{
				last = g[a[n][i] - '0'];
				++tot;
			}
			a[n][i] = tot + '0';
		}
	return true;
}

void MapGenX::gen()
{
	//cout << "generating..." << endl;
	const char* aa_arena_seed = std::getenv("AA_ARENA_GAME_SEED");
	// Rejected maps must advance the same random stream instead of repeating forever.
	if (aa_arena_seed) {
		if (!aa_arena_seeded_) {
			std::srand(static_cast<unsigned int>(std::strtoul(aa_arena_seed, nullptr, 10)));
			aa_arena_seeded_ = true;
		}
	} else {
		std::srand(static_cast<unsigned int>(time(NULL)));
	}
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			a[i][j] = BLOCKES;
	int half = size / 2;
	for (int i = 0; i < half - 1; ++i)
		while (!check_gen(i))
			;
	//cout << "half done..." << endl;
	spec_gen(half - 1);
	int b[50];
	memset(b, 0, sizeof(b));
	if (true)
		for (int i = 0; half - i >= 0; ++i)
			if (a[half - 1][half - i] != BLOCKES || a[half - 1][half + i] != BLOCKES)
			{
				for (int j = 0; j <= i; ++j)
				{
					a[half][half + j] = a[half][half - j] = PLAIN;
					b[half + j] = b[half - j] = 1;
				}
				break;
			}
	for (int i = 0; i < size / 2; ++i)
		if (!b[i] && !b[size - i - 1] && !b[i + 1])
		{
			if (a[half - 1][i] != BLOCKES && a[half - 1][size - 1 - i] != BLOCKES)
				if (i == 0 || b[i - 1] == 0)
				{
					b[i] = b[size - 1 - i] = 1;
					a[half][i] = a[half][size - 1 - i] = PLAIN;
				}
		}
	for (int i = 0; i < half + 1; ++i)
		for (int j = 0; j < size; ++j)
		{
			if (a[i][j] != BLOCKES)
				a[i][j] = PLAIN;
			if (i <= half - 1)
				a[size - 1 - i][size - 1 - j] = a[i][j];
		}
	for (int i = 0; i < GoldNum / 2; ++i)
	{
		int x, y;
		do
		{
			x = random(0, size - 1);
			y = random(0, size - 1);
		} while (a[x][y] != PLAIN && (x != size - 1 - x || y != size - 1 - y));
		a[x][y] = a[size - 1 - x][size - 1 - y] = GOLD_MINE;
	}
	int x, y;
	do
	{
		x = random(0, size - 1);
		y = random(0, size - 1);
	} while (a[x][y] != PLAIN);
	a[x][y] = PLAYER_1;
	a[size - 1 - x][size - 1 - y] = PLAYER_2;
	if (blocked_off())
		gen();
}


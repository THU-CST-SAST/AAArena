#include <cstdlib>
#include "MapGenX.4.h"
#define random(l, r) (rand() % ((r) - (l) + 1) + (l))

const int MapGenX4::GoldNum = 20;
MapGenX4::MapGenX4(const char* f):MapGenBase(f){}

const MapGenX4::Point MapGenX4::dir[4] = {
	Point(0, 1), Point(1, 0), Point(0, -1), Point(-1, 0)};

bool MapGenX4::canMoveTo(const Point& pos){
	return inMap(pos) && a[pos.x][pos.y] != BLOCKES;
}

bool MapGenX4::inMap(const Point& pos){
	return !(pos.x < 0 || pos.y < 0 || pos.x >= size || pos.y >= size);
}

bool MapGenX4::isLeaf(const Point& pos){
	if(!inMap(pos))
		return false;
	int cnt = 0;
	for(int i = 0; i < 4; i++)
		cnt += canMoveTo(pos + dir[i]);
	return cnt == 1;
}

bool MapGenX4::canPut(const Point& pos){
	return isLeaf(pos) && a[pos.x][pos.y] == BLOCKES;
}

void MapGenX4::gen()
{
	//cout << "generating..." << endl;
	const char* aa_arena_seed = std::getenv("AA_ARENA_GAME_SEED");
	// Rejected maps must advance the same random stream instead of repeating forever.
	if (aa_arena_seed) {
		if (!aa_arena_seeded_) {
			std::srand(static_cast<unsigned int>(std::strtoul(aa_arena_seed, nullptr, 10)));
			aa_arena_seeded_ = true;
		}
	} else {
		std::srand(static_cast<unsigned int>(time(NULL)));
	}
	for (int i = 0; i < size; ++i)
		for (int j = 0; j < size; ++j)
			a[i][j] = BLOCKES;
	seedsSize = 1;
	seeds[0] = Point(random(0, size - 1), random(0, size - 1));
	a[seeds[0].x][seeds[0].y] = PLAYER_1;
	int mineCnt = GoldNum;
	while(seedsSize){
		int num = random(0, seedsSize - 1);
		Point &cur = seeds[num];
		int pque = 0, que[4];
		for(int i = 0; i < 4; i++)
			if(canPut(cur + dir[i]))
				que[pque++] = i;
		if(!pque){
			if(mineCnt && isLeaf(cur) && a[cur.x][cur.y] == PLAIN && random(0, 3) == 0){
				a[cur.x][cur.y] = GOLD_MINE;
				mineCnt--;
			}
			seeds[num] = seeds[--seedsSize];
			continue;
		}
		Point next = cur + dir[que[random(0, pque - 1)]];
		seeds[seedsSize++] = next;
		a[next.x][next.y] = PLAIN;
	}
}


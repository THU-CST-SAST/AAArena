#include "sdk.h"
#include "ailoader.hh"
#include "GC_controller.h"
#include "gc_socket.h"

#include <string>
#include <cstdlib>
#include <dlfcn.h>

using namespace std;



int main(int argc, char **argv)
{
	if (argc != 2 && argc != 3)
	{
		fprintf(stderr, "usage: %s <AI .so file> [<port numnber>]\n", argv[0]);
		return 1;
	}
	try
	{
		GC_Controller ctl(argv[1]);
		uint16_t port = 0;
		if (argc == 3)
		{
			int x;
			if (sscanf(argv[2], "%d", &x) != 1 || x < 0 || x > 0xFFFF)
				throw AI9Error("invalid port number: %s", argv[2]);
			port = x;
		}
		AILoader::add_allowed_open_path(argv[1]);
		AILoader::mainloop(port, ctl);
	} catch (std::exception &e)
	{
		fprintf(stderr, "AI loader: caught exception: %s\n", e.what());
		return -1;
	}
}

// vim: syntax=cpp11.doxygen foldmethod=marker foldmarker=f{{{,f}}}


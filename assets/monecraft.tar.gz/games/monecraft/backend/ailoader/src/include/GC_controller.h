#include "gc_socket.h"

#include "ailoader.hh"
#include "sdk.h"

//#include "debug.h"
#include <unistd.h>
#include <ctime>
#include <string>
#include <cstdlib>
#include <dlfcn.h>
#include <fstream>
#include <iostream>
#define AI_FUNC player_ai
#define AI_FUNC_STR "player_ai"


class GC_Controller: public GameControllerBase
{
  Map map;
  GameInfo game_info;
  RoundInfo rd_info;
  Action action;
 // int t;
  //std::ofstream debug;
  typedef decltype(AI_FUNC) *ai_func;
  ai_func m_ai;

  std::string ai_path;
  ai_func get_ai()
  {
    //std::cout << "mark 1" << std::endl;
    if (m_ai)
      return m_ai;
    printf("before loading .so\n");
    void *hdl = dlopen(ai_path.c_str(), RTLD_NOW);
    printf("loading .so done\n");
    if (!hdl)
      throw AI9Error("failed to load AI: %s", dlerror());
    m_ai = reinterpret_cast<ai_func>(dlsym(hdl, AI_FUNC_STR));
    printf("dlsym done\n");
    if (!m_ai)
      throw AI9Error("failed to lookup AI func: %s", dlerror());
    return m_ai;
  }
 public:
 GC_Controller(const char *path):ai_path(path),m_ai(0)//debug("/home/dream/ai9/Platform/gameLibrary/games/GoldCraft/debug2.txt")
{}
  virtual void on_game_init()
  {
    srand(getpid());
    *m_conn >> map;
    get_ai();
    /*std::string df = "debug";
    df = df + (char)(rand()%('z'-'a') + 'a') + ".txt";
    debug.open(df.c_str());*/
  }
  virtual void on_round_start()
  {
   // debug << "on start "<< std::time(0) - t<< std::endl;
  //  t = std::time(0);
    XRecv(*m_conn, map);
    *m_conn >> game_info;
    *m_conn >> rd_info;
    //std::cout << "test" << std::endl;
   // debug << "on start end: "<< std::time(0) - t << std::endl;
    /*   std::ofstream debug("/home/dream/ai9/Platform/gameLibrary/games/GoldCraft/rdinfo.txt");
    debug << map << std::endl;
    debug << game_info << std::endl;
    outround(debug, rd_info);
    debug.close();*/
  }

  virtual void do_round()
  {
    //int t = std::time(0);
    //debug << "on do" << std::endl;
    action.move = Action::Stop;
    action.buy_protect = false;
    action.setOB = false;
    get_ai()(map, game_info, rd_info, action);
    //debug << "on do end"<< std::time(0) - t << std::endl;
  }
  virtual void on_round_end()
  {
    /*debug << "---- round " << game_info.rounds << " ----" << std::endl;
    for (int i = 0; i < rd_info.mines.size(); ++i)
{
	debug << "mine " << rd_info.mines[i].id << " (" << rd_info.mines[i].pos.x << "," << rd_info.mines[i].pos.y << ")" << std::endl;
}
    action.move = Action::Move(0);
    for (int i = 0; i < 31; ++i)
    {
        for (int j = 0; j < 31; ++j)
        {
	    if(map.grids[i][j].players.size() > 0)
		debug << '!';
	    else if(map.grids[i][j].mine_id >= 0)
		debug << '$';
            else if(map.grids[i][j].terrain == MapGrid::UNSEEN)
		debug << '?';
	    else if (map.grids[i][j].terrain == MapGrid::FLAT)
		debug << ' ';
	    else if (map.grids[i][j].terrain == MapGrid::BLOCK)
		debug << '#';
	    else
		debug << 'W';
        }
		debug << std::endl;
    }*/
    *m_conn << action;
    //debug << std::endl;
  }
  virtual void on_game_end()
  {
  }

  virtual std::string get_log_msg()
    {
      return std::string();
    }
};

# AntWar (27th) Evaluator

AntWar 对战器（游戏资产，属仓库 A）。满足 `docs/evaluator-contract.md` 的
`Evaluator` 协议：`evaluate(players, roles, seed) -> EvaluateResult`。

## 模块

- `runtime.py`：编译本 GamePack `backend/` 中的官方 C++ 后端与 C++ 选手
  （`players/pool/*`）。
  只复用 `aa_arena.core.cpp_build` 的游戏无关 C++ 构建/哈希原语，不读取其他游戏目录；
  编译策略为「优先选手 Makefile → 失败回退（解析 g++ 命令 + 兼容垫片，多标准版本
  尝试） → 再失败诚实抛错」，并按内容哈希缓存产物。
- `arena.py`：用 4 字节大端长度前缀 + 4 字节 object_id 的 stdio 协议驱动后端与两名
  选手完成一局。处理 AntWar 特有流程：init 信息推送、每回合 OJ 文本状态推送、
  选手操作以 `object=1-p` 互相转发、config 帧忽略、listen 回复回传；固定随机种子
  （`FIXED_SEED`）保证可复现；终局以 `{"state":-1}` 标志，从 `end_info` 判胜。
- `replay.py`：把回放 JSON 解码为角色感知的胜负、回合数与种子（供 B/C 复用）。
- `__init__.py`：`AntWarEvaluator` 装配上述模块，返回契约 `EvaluateResult`；
  严格三态：编译/后端故障=`infra_error`，选手编译失败/超时/非法/崩溃=`game_error`，
  正常终局=`complete`。

## 协议要点（与 antwar2/aquawar 的关系）

AntWar（27 届）是 antwar2（30 届）的前身，帧协议同属 Saiblo C++。差异：选手协议为
**OJ 文本**（非 JSON）——init 发 `"{id} {seed}\n"`，每回合发多行文本状态，选手回复
OJ 文本操作（带 4 字节长度前缀）。后端每回合把选手操作直接转发给对手（object∈{0,1}
帧），arena 忠实搬运字节即可。

## 三态归因

- `infra_error`：后端编译失败、人类池审计失败、选手包无法解析、传输层自身异常。
- `game_error`：某选手无法编译、超时、崩溃或非法（判对手胜）。
- `complete`：产出有效终局，填 `winner`/`scores`/`rounds`/`replay_path`。

## 产物

构建缓存与对局产物落在仓库根的 `data/antwar-build/`、`data/antwar-matches/`
（gitignore）。

"""AntWar (27th) 对战器 —— 满足 `aa_arena.core.Evaluator` 协议的可运行实现。

AntWar 的游戏语义（编译 C++ 后端与 C++ 选手、跑一局塔防对抗、解码回放、裁决胜负）
是仓库 A 的资产。本包对外暴露 `AntWarEvaluator`，其
`evaluate(players, roles, seed) -> EvaluateResult` 遵循 `docs/evaluator-contract.md`：

- 从已提交的后端源码树编译官方 C++ 后端（可复现于全新 checkout）；
- 编译两名 C++ 选手（AntWar 选手各自带 Makefile；编译失败即诚实标记）；
- 用 4 字节长度前缀 + object_id 的 stdio 协议驱动后端与两名选手完成一局，其中包含
  init 信息推送、每回合 OJ 文本状态推送、选手操作互相转发、选手回复回传；
- 固定随机种子保证可复现；从终局 `end_info` 判胜；
- 严格区分三态：编译/后端进程故障 = `infra_error`；选手超时/非法/崩溃 =
  `game_error`；正常终局 = `complete`。

B (HL) / C (RL) 通过 A 的统一入口 `evaluate("antwar", ...)` 复用本实现。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.contract import EvaluateResult, EvaluationStatus, PlayerRef
from aa_arena.core.player_environment import PlayerEnvironmentError, player_command
from aa_arena.core.player_entry import find_python_entry
from aa_arena.sandbox import SandboxInfrastructureError

from .arena import (
    AntWarArena,
    AntWarMatchError,
    MatchCase,
    MatchResult,
    ProcessSpec,
    run_native_match,
)
from .replay import ReplayReport, decode_replay
from .runtime import (
    AntWarLayout,
    AntWarRuntimeError,
    FrozenBackend,
    Opponent,
    audit_human_pool,
    build_backend,
    build_player,
    has_cpp_build,
    sha256_file,
    tree_sha256,
)

__all__ = [
    "AntWarArena",
    "AntWarEvaluator",
    "AntWarLayout",
    "AntWarMatchError",
    "AntWarRuntimeError",
    "FrozenBackend",
    "MatchCase",
    "MatchResult",
    "Opponent",
    "ProcessSpec",
    "ReplayReport",
    "audit_human_pool",
    "build_backend",
    "build_player",
    "decode_replay",
    "make_evaluator",
    "run_native_match",
    "sha256_file",
    "tree_sha256",
]


def _resolve_player_package(player: PlayerRef, *, pool: tuple[Opponent, ...]) -> Path:
    if player.code_path is not None:
        root = Path(player.code_path).resolve()
        if not root.is_dir():
            raise AntWarMatchError(f"player code path is not a directory: {root}")
        return root
    for opponent in pool:
        if opponent.opponent_id == player.player_id and opponent.runnable:
            return opponent.package_root
    raise AntWarMatchError(
        f"cannot resolve runnable player {player.player_id!r} in the frozen human pool"
    )


def _player_process_spec(
    package_root: Path, build_root: Path, *, public_sdk_root: Path
) -> ProcessSpec:
    """按提交类型决定怎么起这个选手进程。

    27 届 AntWar 的统一选手池里既有 **C++ 提交**（带 Makefile/源码，需要编译），
    也有 **Python 提交**（``main.py``，Saiblo 侧直接 ``python main.py`` 运行，
    走同一套 stdio 协议）。此前这里无条件走 C++ 编译，于是所有 Python 提交都被
    判成"编译失败"（很多包里只有一个 Sphinx 文档 Makefile，报 sphinx-build 缺失）。
    """

    if has_cpp_build(package_root):
        exe = build_player(package_root, build_root)
        return ProcessSpec((str(exe),), exe.parent)
    entry_root = find_python_entry(package_root)
    if entry_root is not None:
        pythonpath = str(public_sdk_root)
        return ProcessSpec(
            player_command(), entry_root, env={"PYTHONPATH": pythonpath}
        )
    raise AntWarRuntimeError(
        f"player package has neither a C++ build nor main.py: {package_root}"
    )


@dataclass(frozen=True)
class _ReplayFacts:
    """一次加载就把评测需要的所有回放事实取齐。

    为什么合成一个：这三样（回合数、终局血量、判定链分量）都来自同一份 JSON，
    而 antwar 的回放是 1~2 MB。分成三个函数会把同一个文件解析三遍，
    在 8 路并行 × 每轮 8 局下是白烧的 CPU。
    """

    #: 真实**游戏回合数** = 回放帧数（每帧一回合）。官方上限 512。
    rounds: int
    #: 终局大本营血量（官方第一判据）。
    base_hp: dict[str, float]
    #: 官方判定链第 2 级：击败对方蚂蚁数。
    ants_killed: dict[str, int]
    #: 官方判定链第 3 级：使用超级武器次数（少者胜）。
    weapons_used: dict[str, int]


def _other_role(role: str) -> str:
    return "P1" if role == "P0" else "P0"


def _replay_facts(replay_path: Path | str | None) -> _ReplayFacts | None:
    """从回放里取齐官方判定所需的事实；取不到就返回 None（绝不编造）。

    权威依据（saiblo game id=22 官方文档「8. 胜负判定」，与 antwar2/id=48 逐字相同）::

        - 大本营剩余血量多者，胜。如果剩余血量相同：
        - 击败对方蚂蚁数多者，胜。如果击败蚂蚁数相同：
        - 使用超级武器少者，胜。如果使用超级武器次数相同：
        - AI用时少者，胜。如果用时相同：
        - 先手胜。

    **回合数**：用**帧数**，不用后端的 ``state`` 计数器。
    后端每回合给每个玩家各发一次 listen/act，所以 ``state`` 走的是"玩家半回合"：
    实测 ``state_max = 2 × 帧数 + 1``（893=2×446+1、1025=2×512+1、565=2×282+1）。
    官方回合上限是 512，而我们一直往下游报 1025 —— 差 2 倍的量纲错误会让
    "第几回合发生了什么"的所有分析与官方语义对不上，也让 agent 读到的回合号是错的。
    回放帧数与官方 512 上限严丝合缝，是唯一可信的回合数来源。

    **分数**：只放第一判据（基地血量），也正是官方 ``end_info`` 里给的
    ``HP0 HP1``（文档：「接下来两个整数 HP0 HP1，分别代表先后手玩家的剩余基地血量」）。
    开局各 50，每有一只敌蚁走进基地 −1，任一方 ≤0 立即结束。
    只回报胜负位的代价是实测过的：antwar 连打 32 局 ``score_margin`` 全是 −1.0、
    ``win_rate`` 恒 0，而 agent 自己从回放里读出了进展（两次打开对手基地、把血量压到 48）。
    框架看不见的进展等于没有进展——课程无法推进、Elo 只会单调下降。

    第 4 级（AI 用时）与第 5 级（先手）不在回放里，故**不计算**：
    缺就是缺，填 0 会把"判不出来"伪装成"打平"。
    """

    if replay_path is None:
        return None
    path = Path(replay_path)
    if not path.is_file():
        return None
    try:
        frames = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(frames, list) or not frames:
        return None
    final = frames[-1]
    if not isinstance(final, dict):
        return None
    terminal = final.get("round_state")
    if not isinstance(terminal, dict):
        return None
    camps = terminal.get("camps")
    if not isinstance(camps, list) or len(camps) != 2:
        return None
    try:
        base_hp = {"P0": float(camps[0]), "P1": float(camps[1])}
    except (TypeError, ValueError):
        return None

    ants_lost = {0: 0, 1: 0}
    weapons_used = {0: 0, 1: 0}
    counted: set[tuple[int, int]] = set()
    for record in frames:
        if not isinstance(record, dict):
            continue
        for player in (0, 1):
            operations = record.get(f"op{player}")
            if not isinstance(operations, list):
                continue
            for operation in operations:
                if isinstance(operation, dict) and operation.get("type") in (21, 22, 23, 24):
                    weapons_used[player] += 1
        state = record.get("round_state")
        if not isinstance(state, dict):
            continue
        ants = state.get("ants")
        if not isinstance(ants, list):
            continue
        for ant in ants:
            if not isinstance(ant, dict):
                continue
            owner, ant_id, status = ant.get("player"), ant.get("id"), ant.get("status")
            if not isinstance(owner, int) or not isinstance(ant_id, int):
                continue
            # status==2 是 Fail（被击杀）。蚂蚁跨帧重复出现，按 (player, id) 去重。
            if status != 2 or (owner, ant_id) in counted:
                continue
            counted.add((owner, ant_id))
            ants_lost[owner] += 1
    return _ReplayFacts(
        rounds=len(frames),
        base_hp=base_hp,
        # 「击败对方蚂蚁数」= 对手损失的蚂蚁数。
        ants_killed={"P0": ants_lost[1], "P1": ants_lost[0]},
        weapons_used={"P0": weapons_used[0], "P1": weapons_used[1]},
    )


class AntWarEvaluator:
    """AntWar 的对战器：给定两名选手、角色与种子，跑一局并返回契约结果。

    `game_dir` 指向 `games/antwar/`，据此定位 A 仓库根与产物构建目录。AntWar 后端
    支持随机种子；本对战器以固定种子运行以保证可复现，`seed` 参数用于产物分目录。
    """

    def __init__(
        self,
        game_dir: Path,
        *,
        build_root: Path | None = None,
        artifact_root: Path | None = None,
        timeout_s: float = 1800.0,
    ) -> None:
        self.game_dir = Path(game_dir).resolve()
        self.aa_arena_root = self.game_dir.parents[1]
        self._build_root = (
            Path(build_root).resolve()
            if build_root is not None
            else self.aa_arena_root / "data" / "antwar-build"
        )
        self._artifact_root = (
            Path(artifact_root).resolve()
            if artifact_root is not None
            else self.aa_arena_root / "data" / "antwar-matches"
        )
        self.timeout_s = float(timeout_s)

    def evaluate(self, players: list[PlayerRef], roles: list[str], seed: int) -> EvaluateResult:
        if len(players) != 2 or len(roles) != 2:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"antwar requires exactly 2 players/roles, got {len(players)}/{len(roles)}",
            )
        if set(roles) != {"P0", "P1"}:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"antwar roles must be a permutation of [P0, P1], got {roles}",
            )

        layout = AntWarLayout.from_game_dir(self.game_dir, self._build_root)
        try:
            layout.validate()
            backend = build_backend(layout)
            pool = audit_human_pool(layout)
        except (AntWarRuntimeError, FileNotFoundError, OSError) as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"backend/pool preparation failed: {exc}",
            )

        try:
            candidate_pkg = _resolve_player_package(players[0], pool=pool)
            opponent_pkg = _resolve_player_package(players[1], pool=pool)
        except AntWarMatchError as exc:
            return EvaluateResult(status=EvaluationStatus.INFRA_ERROR, diagnostic=str(exc))

        candidate_role = roles[0]
        try:
            candidate_spec = _player_process_spec(
                candidate_pkg, self._build_root, public_sdk_root=self.game_dir / "public_sdk"
            )
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )
        except AntWarRuntimeError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=_other_role(candidate_role),
                diagnostic=f"candidate build failed: {exc}",
            )
        try:
            opponent_spec = _player_process_spec(
                opponent_pkg, self._build_root, public_sdk_root=self.game_dir / "public_sdk"
            )
        except PlayerEnvironmentError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"shared player environment failed: {exc}",
            )
        except AntWarRuntimeError as exc:
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                winner=candidate_role,
                diagnostic=f"opponent build failed: {exc}",
            )

        arena = AntWarArena(
            game=ProcessSpec((str(backend.executable),), backend.executable.parent),
            candidate=candidate_spec,
            opponent=opponent_spec,
            artifact_root=self._artifact_root,
            timeout_s=self.timeout_s,
        )
        case = MatchCase(players[0].player_id, players[1].player_id, candidate_role, seed)
        try:
            result = arena.run_case(case)
        except SandboxInfrastructureError as exc:
            return EvaluateResult(
                status=EvaluationStatus.INFRA_ERROR,
                diagnostic=f"player sandbox infrastructure failed: {exc}",
            )

        if result.status != "complete":
            return EvaluateResult(
                status=EvaluationStatus.GAME_ERROR,
                diagnostic=result.error,
                replay_path=(str(result.replay_path) if result.replay_path else None),
            )

        return self._to_evaluate_result(result, candidate_role)

    def _to_evaluate_result(self, result: MatchResult, candidate_role: str) -> EvaluateResult:
        winner_player = result.payload.get("winner_player")
        if winner_player == 0:
            winner: str | None = "P0"
        elif winner_player == 1:
            winner = "P1"
        else:
            winner = None
        facts = _replay_facts(result.replay_path)
        if facts is None:
            # 回放缺失/损坏：只能退回胜负位，且回合数只有后端的半回合计数可用。
            # 这是**降级路径**——score_margin 会退化成 ±1，下游看不到"差多少"。
            if winner == "P0":
                scores = {"P0": 1.0, "P1": 0.0}
            elif winner == "P1":
                scores = {"P0": 0.0, "P1": 1.0}
            else:
                scores = {"P0": 0.5, "P1": 0.5}
            return EvaluateResult(
                status=EvaluationStatus.COMPLETE,
                winner=winner,
                scores=scores,
                rounds=result.rounds,
                replay_path=str(result.replay_path) if result.replay_path else None,
                payload={"official_criterion": "degraded_win_loss_only", "rounds_unit": "backend_half_round"},
            )
        return EvaluateResult(
            status=EvaluationStatus.COMPLETE,
            winner=winner,
            # 官方第一判据。第 2、3 级放 payload——scores 混入其它量纲就等于
            # 我们自己发明了一个加权和，margin 将不再可解释。
            scores=facts.base_hp,
            rounds=facts.rounds,
            replay_path=str(result.replay_path) if result.replay_path else None,
            payload={
                "official_criterion": "base_hp_then_tiebreakers",
                "ants_killed": facts.ants_killed,
                "weapons_used": facts.weapons_used,
                "criterion_chain": [
                    "base_hp(desc)",
                    "ants_killed(desc)",
                    "weapons_used(asc)",
                    "ai_time(asc, 回放不含)",
                    "first_player(回放不含)",
                ],
                "rounds_unit": "game_round",
                "backend_half_rounds": result.rounds,
            },
        )


def make_evaluator(game_dir: Path) -> AntWarEvaluator:
    """插件工厂：供 `games/antwar/plugin.py` 装配对战器。"""

    return AntWarEvaluator(game_dir)

"""AntWar 回放 → 自然语言。

AntWar（第 27 届）与 AntWar2（第 30 届）的回放**外壳同形**（JSON 数组、每元素一回合、
``round_state`` + ``op0``/``op1``），但游戏本体不同：AntWar 的核心机制是**信息素**
（``round_state.pheromone``，2×19×19 矩阵）驱动蚂蚁寻路，而 AntWar2 没有这一层。

所以叙述的重点也不同：这里必须把「你往哪儿铺信息素、蚂蚁因此走了哪条路、塔打到了
没有」串起来讲。只讲塔和金币的话，读者根本看不出这一局的胜负是怎么来的。
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path

from aa_arena.replay.narration import Narration, NarrationContext
from aa_arena.replay.prose import (
    budget_lines,
    Document,
    Event,
    describe_pair,
    render_events,
)

_ROLES = ("P0", "P1")

#: 操作码 → 人话。与 `decision_space.yaml` 的 `operation_types` 一一对应。
_ACTIONS: dict[int, str] = {
    11: "建基础塔",
    12: "升级塔",
    13: "降级/拆塔",
    21: "放闪电风暴",
    22: "放 EMP 干扰",
    23: "放力场护盾",
    24: "紧急疏散",
    31: "升级出兵速度",
    32: "升级新生蚂蚁等级",
}

#: 蚂蚁终局状态（`round_state.ants[].status`）。
_ANT_STATUS = {0: "存活", 1: "抵达对方基地", 2: "被击杀", 3: "老死", 4: "被冻结"}

#: `round_state.message` 里的终止原因（官方回放指南：「结束信息，表示玩家结束时状态」）。
#: 这是**判断这一局到底算不算战术失败**的唯一依据：IA/TLE/RE 属于程序故障，
#: 与策略强度无关，混在一起看会让人以为"策略不行"，实际是"金币没算准就提交了动作"。
_END_REASON = {
    "OK": "正常结束",
    "IA": "**非法操作**（Illegal Action，动作被后端拒绝并直接判负）",
    "TLE": "**超时**（Time Limit Exceeded）",
    "RE": "**运行时错误**（Runtime Error）",
    "MLE": "**内存超限**（Memory Limit Exceeded）",
    "OLE": "**输出超限**（Output Limit Exceeded）",
    "CE": "**编译错误**（Compile Error）",
}


def _load(path: Path) -> Sequence[Mapping[str, object]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(document, list) or not document:
        raise ValueError("antwar 回放应当是非空 JSON 数组（每元素一回合）")
    return document


def _pair(state: Mapping[str, object], key: str, default: float = 0.0) -> tuple[float, float]:
    raw = state.get(key)
    if isinstance(raw, list) and len(raw) == 2:
        try:
            return float(raw[0]), float(raw[1])
        except (TypeError, ValueError):
            return default, default
    return default, default


def _describe_operation(operation: Mapping[str, object]) -> str:
    code = operation.get("type")
    name = _ACTIONS.get(int(code), f"未识别操作 {code}") if isinstance(code, int) else "非法操作"
    position = operation.get("pos")
    if isinstance(position, Mapping) and position.get("x", -1) != -1:
        name += f" @({position.get('x')},{position.get('y')})"
    tower_id = operation.get("id")
    if isinstance(tower_id, int) and tower_id >= 0:
        name += f"（塔 id={tower_id}）"
    args = operation.get("args")
    if isinstance(args, int) and args >= 0:
        name += f"（参数={args}）"
    return name


def _pheromone_footprint(state: Mapping[str, object]) -> tuple[int, int] | None:
    """信息素矩阵的"活跃格数"——铺得越广，蚂蚁的可选路径越多。

    只报一个标量：19×19 的矩阵逐格念出来毫无可读性，而"铺了多少格"恰好是策略层面
    真正在调的量（集中一条路 vs 铺散）。
    """

    raw = state.get("pheromone")
    if not isinstance(raw, list) or len(raw) != 2:
        return None
    counts: list[int] = []
    for layer in raw:
        if not isinstance(layer, list):
            return None
        total = 0
        for row in layer:
            if isinstance(row, list):
                total += sum(1 for cell in row if isinstance(cell, (int, float)) and cell)
            elif isinstance(row, (int, float)) and row:
                total += 1
        counts.append(total)
    return counts[0], counts[1]


def _end_reasons(state: Mapping[str, object], context: NarrationContext) -> list[str]:
    """终止原因。**必须放在判决最前面**。

    历史教训：这一段原先完全没写。有一局候选在第 199 回合因金币 98<100 提交
    紧急疏散被判 IA，末帧 `message` 明写 `["IA","OK"]`，而叙述里只说"你输了" ——
    读的人会把它当成战术失败去调策略，而真正要修的是"提交前没做金币安全边际"。
    程序故障与战术失败必须一眼分得开。
    """

    raw = state.get("message")
    # ⚠️ `message` 在回放里是**JSON 字符串**（实测 `'["IA", "OK"]'`），不是列表。
    # 按列表去读会静默地什么都取不到——正是这个类型假设让 IA 警告整段消失，
    # 而 IA 恰恰是那一局最该被读到的事实。所以两种形态都接。
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError:
            return []
    if not isinstance(raw, list) or len(raw) != 2:
        return []
    lines: list[str] = []
    for player, code in enumerate(raw):
        if not isinstance(code, str):
            continue
        text = _END_REASON.get(code.upper(), f"未识别状态 {code}")
        if code.upper() == "OK":
            continue
        lines.append(f"- ⚠️ {context.label(f'P{player}')} 的结束状态是 {text}。")
    return lines


def _verdict(
    frames: Sequence[Mapping[str, object]], context: NarrationContext
) -> tuple[list[str], str | None, int]:
    final = frames[-1]
    state = final.get("round_state")
    state = state if isinstance(state, Mapping) else {}
    raw_winner = state.get("winner")
    winner = f"P{raw_winner}" if raw_winner in {0, 1} else None
    winner = context.official_winner or winner
    # 回合数**一律用帧数**（每帧一回合，官方上限 512）。
    # 不采用外部传入的 official_rounds：对战器曾把后端的"玩家半回合"计数
    # （= 2×帧数+1）传进来，导致同一份叙述标题写 199 回合、判决写 398 回合，自相矛盾。
    rounds = len(frames)
    labels = [context.label(role) for role in _ROLES]
    lines: list[str] = []
    if winner is None:
        lines.append("- 官方裁决：平局或未分出胜负。")
    elif context.perspective is None:
        lines.append(f"- 官方裁决胜者：{winner}。")
    elif winner == context.perspective:
        lines.append(f"- **你赢了**（{context.label(winner)}）。")
    else:
        lines.append(f"- **你输了**，胜者是 {context.label(winner)}。")
    lines.extend(_end_reasons(state, context))
    if context.official_rounds is not None and context.official_rounds != rounds:
        lines.append(
            f"- 全局共 {rounds} 回合（官方上限 512；对战器另报 "
            f"{context.official_rounds}，那是后端的玩家半回合计数，非游戏回合）。"
        )
    else:
        lines.append(f"- 全局共 {rounds} 回合（官方上限 512）。")
    lines.append("- 终局 " + describe_pair("基地血量", [int(v) for v in _pair(state, "camps", 50)], labels) + "。")
    lines.append("- 终局 " + describe_pair("金币", [int(v) for v in _pair(state, "coins")], labels) + "。")
    lines.append(
        "- 终局 "
        + describe_pair("出兵速度等级", [int(v) for v in _pair(state, "speedLv")], labels)
        + "；"
        + describe_pair("蚂蚁等级", [int(v) for v in _pair(state, "anthpLv")], labels)
        + "。"
    )
    footprint = _pheromone_footprint(state)
    if footprint is not None:
        lines.append(
            "- 终局 "
            + describe_pair("信息素活跃格数", list(footprint), labels)
            + "。"
        )
    if context.diagnostic:
        lines.append(f"- ⚠️ 对战器诊断（你自己的程序故障）：{context.diagnostic}。")
    return lines, winner, rounds


def _ant_outcomes(frames: Sequence[Mapping[str, object]], context: NarrationContext) -> list[str]:
    """蚂蚁的结局 —— 按**官方判定链的措辞**陈述，而不是按数据的存放方式。

    ⚠️ 这里踩过一个真实的坑，代价是 agent 写进经验文档的结论直接反了。
    原先的措辞是「你(P0) 的蚂蚁结局：被击杀 38 只」——数据上没错（你**损失**了 38 只），
    但读起来极易被理解成「你**击杀了** 38 只」。实测 agent 就是这么读的：真实值是
    它击杀 45、损失 38，它却在经验里写下「我方 killed 38，对手 killed 45」，完全反了。
    它甚至自己标注了「按归属核对」的疑问 —— 说明归属是框架该讲清的，不该让它猜。

    所以现在改成主动语态 + 直接对齐官方判定第 2 级（「击败对方蚂蚁数多者胜」）：
    「你击杀对手蚂蚁 N 只」与「你损失 M 只」分成两句，主语明确，不可能读反。
    """

    # (player, id) 去重：蚂蚁跨帧重复出现，只记它第一次进入终局态。
    tally: dict[int, dict[int, int]] = {0: {}, 1: {}}
    seen: set[tuple[int, int]] = set()
    for record in frames:
        state = record.get("round_state")
        if not isinstance(state, Mapping):
            continue
        ants = state.get("ants")
        if not isinstance(ants, list):
            continue
        for ant in ants:
            if not isinstance(ant, Mapping):
                continue
            player = ant.get("player")
            ant_id = ant.get("id")
            status = ant.get("status")
            if not isinstance(player, int) or not isinstance(ant_id, int):
                continue
            if not isinstance(status, int) or status == 0:
                continue
            if (player, ant_id) in seen:
                continue
            seen.add((player, ant_id))
            bucket = tally[player]
            bucket[status] = bucket.get(status, 0) + 1

    lines: list[str] = []
    for role in _ROLES:
        index = 1 if role.endswith("1") else 0
        rival = 1 - index
        mine, theirs = tally[index], tally[rival]
        # 官方第 2 级判据：我击杀的敌蚁数 = 对手损失的蚂蚁数（status==2）。
        killed = theirs.get(2, 0)
        lost = mine.get(2, 0)
        arrived = mine.get(1, 0)
        conceded = theirs.get(1, 0)
        label = context.label(role)
        lines.append(
            f"- {label} **击杀对手蚂蚁 {killed} 只**（官方判定第 2 级：击败对方蚂蚁数多者胜）；"
            f"自己损失 {lost} 只。"
        )
        lines.append(
            f"- {label} **有 {arrived} 只蚂蚁攻入对方基地**（每只令对方基地 −1 HP）；"
            f"被对方攻入 {conceded} 次。"
        )
        others = "、".join(
            f"{_ANT_STATUS.get(status, f'状态{status}')} {count} 只"
            for status, count in sorted(mine.items())
            if status not in (1, 2)
        )
        if others:
            lines.append(f"- {label} 其余蚂蚁结局：{others}。")
    if not lines:
        lines.append("- 回放里没有记录到任何蚂蚁的终局状态（可能对局极短）。")
    return lines


def _state_deltas(
    frames: Sequence[Mapping[str, object]], context: NarrationContext
) -> list[str]:
    lines: list[str] = []
    fields = (("camps", "基地血量"), ("coins", "金币"), ("speedLv", "出兵速度等级"), ("anthpLv", "蚂蚁等级"))
    for index, (before_record, after_record) in enumerate(zip(frames, frames[1:], strict=False), start=1):
        before = before_record.get("round_state")
        after = after_record.get("round_state")
        if not isinstance(before, Mapping) or not isinstance(after, Mapping):
            continue
        round_index = after.get("round") if isinstance(after.get("round"), int) else index
        for key, label in fields:
            old_pair = _pair(before, key)
            new_pair = _pair(after, key)
            for player, (old, new) in enumerate(zip(old_pair, new_pair, strict=True)):
                if old != new:
                    lines.append(
                        f"- 第 {round_index} 回合：{context.label(f'P{player}')} {label} "
                        f"{old:g}→{new:g}（{new - old:+g}）。"
                    )
    return lines or ["- 相邻状态帧中的基地血量、金币和等级数值均未变化。"]


def narrate(replay_path: Path, context: NarrationContext) -> Narration:
    frames = _load(replay_path)
    verdict, winner, rounds = _verdict(frames, context)

    events: list[Event] = []
    for index, record in enumerate(frames):
        state = record.get("round_state")
        round_index = index
        if isinstance(state, Mapping) and isinstance(state.get("round"), int):
            round_index = int(state["round"])
        for player in (0, 1):
            actor = context.label(f"P{player}")
            operations = record.get(f"op{player}")
            if not isinstance(operations, list) or not operations:
                events.append(
                    Event(
                        round=round_index,
                        actor=actor,
                        text="未提交操作",
                        ref=f"r{round_index:04d}:p{player}",
                        fold_key="idle",
                        fold_label="未提交操作",
                    )
                )
                continue
            for operation in operations:
                if not isinstance(operation, Mapping):
                    continue
                events.append(
                    Event(
                        round=round_index,
                        actor=actor,
                        text=_describe_operation(operation),
                        ref=f"r{round_index:04d}:p{player}",
                    )
                )

    rival = " vs " + context.opponent_id if context.opponent_id else ""
    doc = Document(
        title=f"AntWar 对局叙述：{context.match_id}{rival}",
        subtitle=(
            f"共 {len(frames)} 回合 / {len(events)} 条操作记录。"
            "由 A 仓 `aa_arena.replay` 从官方回放翻译，断言均可回溯到具体回合。"
        ),
    )
    doc.section("终局事实", verdict + _ant_outcomes(frames, context))
    state_lines = _state_deltas(frames, context)
    if context.detail != "full":
        state_lines = budget_lines(state_lines, 160)
    doc.section("状态变化与数值增量", state_lines)
    if context.detail == "full":
        timeline = render_events(events, fold=False)
    else:
        timeline = render_events(events, max_lines=240)
    doc.section("可观测动作", timeline or ["- 回放未记录动作。"])
    metadata = (
        f"- detail=full；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=false；line_limit=unbounded。"
        if context.detail == "full"
        else f"- detail=digest；source_events={len(events)}；rendered_lines={len(timeline)}；folding_enabled=true；line_limit=240。"
    )
    doc.section(
        "截断元数据",
        [metadata],
    )
    return Narration(
        game="antwar",
        match_id=context.match_id,
        text=doc.render(),
        rounds=rounds,
        winner=winner,
        highlights={"operations": len(events), "frames": len(frames)},
    )

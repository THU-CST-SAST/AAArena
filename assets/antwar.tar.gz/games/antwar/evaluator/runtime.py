"""Frozen AntWar (27th) resources, builds, and human-pool audit.

AntWar（第 27 届）的对战器内核（游戏资产），属仓库 A。负责：
- 从后端**源码目录**编译官方 C++ 后端（可复现于全新 checkout）；
- 编译人类天梯选手（AntWar 选手为 C++，各自带 Makefile，需逐个编译）；
- 审计冻结的人类天梯选手池（players/manifest.tsv 中带 rank 的选手）。

协议与 aquawar/antwar2 同属 Saiblo C++（4 字节大端长度前缀 + 4 字节 object_id 的
stdio 帧）。AntWar（27 届）是 antwar2（30 届）的前身，但选手协议是 **OJ 文本**（非
JSON）：init 给选手发 ``"{player_id} {seed}\n"``，每回合发多行文本状态，选手回复
OJ 文本操作（带 4 字节长度前缀）。init 消息 config 可含 ``random_seed``（否则后端
自取随机），因此本对战器**固定 seed** 以保证可复现。

后端源码位于本 GamePack 的 ``backend/``。本模块只复用
``aa_arena.core.cpp_build`` 的游戏无关构建原语，不读取任何其他 GamePack。
"""

from __future__ import annotations

import csv
import platform
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from aa_arena.core.cpp_build import (
    EXECUTABLE_NAME,
    CppBuildError,
    build_cpp_player,
    compile_cpp_package,
    find_cpp_makefile_dir,
    has_cpp_build,
    sha256_file,
    tree_sha256,
)
from aa_arena.core.player_entry import find_python_entry

AntWarRuntimeError = CppBuildError
_EXE = EXECUTABLE_NAME
_find_makefile_dir = find_cpp_makefile_dir
_GAME_DIR = Path(__file__).resolve().parents[1]


SUPPORTS_COMPILED_PLAYERS = True
SUPPORTED_PLAYER_BUILD_SYSTEMS = ("make",)


@dataclass(frozen=True)
class AntWarLayout:
    aa_arena_root: Path
    build_root: Path
    backend_source_root: Path
    human_manifest: Path
    human_extracted_root: Path

    @classmethod
    def from_game_dir(
        cls, game_dir: str | Path, build_root: str | Path
    ) -> AntWarLayout:
        game = Path(game_dir).resolve()
        players = game / "players"
        return cls(
            aa_arena_root=game.parents[1],
            build_root=Path(build_root).resolve(),
            backend_source_root=game / "backend",
            human_manifest=players / "manifest.tsv",
            human_extracted_root=players / "pool",
        )

    @classmethod
    def from_root(cls, aa_arena_root: str | Path, build_root: str | Path) -> AntWarLayout:
        return cls.from_game_dir(Path(aa_arena_root) / "games" / "antwar", build_root)

    def backend_fingerprint(self) -> str:
        if self.backend_source_root.is_dir():
            return tree_sha256(self.backend_source_root)
        raise FileNotFoundError(self.backend_source_root)

    def validate(self) -> None:
        if not self.backend_source_root.is_dir():
            raise FileNotFoundError(self.backend_source_root)
        if not self.human_manifest.is_file():
            raise FileNotFoundError(self.human_manifest)
        if not self.human_extracted_root.is_dir():
            raise FileNotFoundError(self.human_extracted_root)


@dataclass(frozen=True)
class FrozenBackend:
    executable: Path
    source_sha256: str
    executable_sha256: str
    manifest_path: Path


def build_player(source_root: Path, build_root: Path) -> Path:
    """Build one immutable AntWar player through the common SDK-aware pipeline."""

    return build_cpp_player(
        player_dir=source_root,
        game_dir=_GAME_DIR,
        cache_root=build_root,
    )


def _load_manifest(manifest_path: Path):
    import json

    if not manifest_path.is_file():
        return None
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def build_backend(layout: AntWarLayout) -> FrozenBackend:
    import json

    layout.validate()
    source_hash = layout.backend_fingerprint()
    root = layout.build_root / f"backend-{source_hash[:16]}"
    manifest_path = root / "build-manifest.json"
    game_dir = root / "game"
    cached = _load_manifest(manifest_path)
    # 产物路径以 manifest 记录为准：antwar 的 Makefile 把二进制放在 `output/main`，
    # 若这里硬编码 `game_dir/main`，缓存永远校验不过 → 每一局都要重编译后端
    # （单局多花十几秒，全池评测会白烧几十核时）。
    exe = Path(str(cached["executable"])) if cached and cached.get("executable") else game_dir / _EXE
    if (
        cached is not None
        and cached.get("source_sha256") == source_hash
        and exe.is_file()
        and cached.get("executable_sha256") == sha256_file(exe)
    ):
        return FrozenBackend(exe, source_hash, str(cached["executable_sha256"]), manifest_path)
    built = compile_cpp_package(layout.backend_source_root, game_dir)
    exe = built
    exe_hash = sha256_file(exe)
    compiler = subprocess.run(
        ("g++", "--version"), capture_output=True, text=True, check=False, timeout=10
    )
    manifest = {
        "schema_version": "1.0",
        "source": str(layout.backend_source_root),
        "source_sha256": source_hash,
        "executable": str(exe),
        "executable_sha256": exe_hash,
        "platform": platform.platform(),
        "python": sys.version,
        "compiler": (compiler.stdout or compiler.stderr).splitlines()[0]
        if (compiler.stdout or compiler.stderr)
        else "unknown",
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return FrozenBackend(exe, source_hash, exe_hash, manifest_path)


@dataclass(frozen=True)
class Opponent:
    opponent_id: str
    rank: int
    username: str | None
    score: int | None
    package_root: Path
    package_sha256: str
    runnable: bool
    exclusion_diagnostic: str | None


def audit_human_pool(layout: AntWarLayout) -> tuple[Opponent, ...]:
    layout.validate()
    pool: list[Opponent] = []
    with layout.human_manifest.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            rank_raw = (row.get("rank") or "").strip()
            if not rank_raw:
                continue
            rank = int(rank_raw)
            packages = tuple(sorted(layout.human_extracted_root.glob(f"rank{rank:02d}__*")))
            if len(packages) != 1:
                raise AntWarRuntimeError(f"rank{rank:02d} maps to {len(packages)} pool packages")
            package = packages[0]
            try:
                has_cpp = has_cpp_build(package)
                if not has_cpp and find_python_entry(package) is None:
                    raise AntWarRuntimeError("no supported entry")
                runnable = True
                diag = None
            except (OSError, RuntimeError):
                runnable = False
                diag = "no runnable entry (main.py / C++ build)"
            pool.append(
                Opponent(
                    opponent_id=f"rank{rank:02d}",
                    rank=rank,
                    username=row.get("username") or None,
                    score=int(row["elo"]) if (row.get("elo") or "").strip() else None,
                    package_root=package,
                    package_sha256=tree_sha256(package),
                    runnable=runnable,
                    exclusion_diagnostic=diag,
                )
            )
    pool.sort(key=lambda item: item.rank)
    ranks = [item.rank for item in pool]
    if len(ranks) != len(set(ranks)):
        raise AntWarRuntimeError("human ranks must be unique")
    return tuple(pool)

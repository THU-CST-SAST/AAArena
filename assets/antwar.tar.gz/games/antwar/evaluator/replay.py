"""Decode AntWar (27th) replay JSON into public-state semantics.

AntWar 回放解码器（游戏资产），属仓库 A。把官方后端 ``dump_all`` 产出的回放 JSON
（一个数组，每元素是一回合记录 ``round_msg``）解码为角色感知的胜负与回合数。
**不依赖任何框架**，可被 A 的 evaluator 使用，也可被 B（回放技能翻译）复用。

回放数组每个记录含：
- ``round_state``：该回合局面（towers/ants/coins/camps/winner/message 等）；
- ``op0`` / ``op1``：两名玩家该回合的操作；
- ``seed``（仅第一回合）：本局随机种子。

整场胜者取自最后一个 ``round_state`` 的 ``winner`` 字段（0/1；-1 未定）。
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class ReplayReport:
    match_id: str
    winner: str | None    # "P0" / "P1" / None（平局/未定）
    rounds: int           # 回合数
    frame_count: int      # 回放记录数
    seed: int | None      # 本局随机种子（若记录）


def _round_states(replay: Sequence[Mapping[str, object]]) -> list[Mapping[str, object]]:
    states: list[Mapping[str, object]] = []
    for record in replay:
        if not isinstance(record, Mapping):
            continue
        state = record.get("round_state")
        if isinstance(state, Mapping):
            states.append(state)
    return states


def decode_replay(
    replay: Sequence[Mapping[str, object]],
    *,
    match_id: str,
) -> ReplayReport:
    if not match_id.strip() or "/" in match_id or ".." in match_id:
        raise ValueError("match_id must be a safe non-empty identifier")
    if not replay:
        raise ValueError("replay cannot be empty")
    states = _round_states(replay)
    if not states:
        raise ValueError("replay has no round_state records")

    # 整场胜者：取最后一个带有效 winner(0/1) 的 round_state。
    winner_player: int | None = None
    for state in reversed(states):
        raw = state.get("winner")
        if isinstance(raw, int) and raw in {0, 1}:
            winner_player = raw
            break

    if winner_player == 0:
        winner: str | None = "P0"
    elif winner_player == 1:
        winner = "P1"
    else:
        winner = None

    seed: int | None = None
    for record in replay:
        if isinstance(record, Mapping) and isinstance(record.get("seed"), int):
            seed = int(record["seed"])
            break

    return ReplayReport(
        match_id=match_id,
        winner=winner,
        rounds=len(states),
        frame_count=len(replay),
        seed=seed,
    )

"""AntWar match configuration and result interpretation.

Transport is provided by :mod:`aa_arena.saiblo`; this module contains no game-specific judge
loop. AntWar-specific code is limited to role placement and terminal score interpretation.
"""

from __future__ import annotations

import json
import subprocess
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from aa_arena.saiblo import (
    DEFAULT_MATCH_TIMEOUT_S,
    ProcessSpec,
    SaibloJudgerError,
    run_stdio_match,
)

Role = str
MatchStatus = Literal["complete", "incomplete"]
Outcome = Literal["win", "loss", "draw"]

FIXED_SEED = 20240117


@dataclass(frozen=True)
class MatchCase:
    candidate_id: str
    opponent_id: str
    role: Role
    seed: int

    def __post_init__(self) -> None:
        if not isinstance(self.role, str) or self.role not in {"P0", "P1"}:
            raise ValueError("match role must be 'P0' or 'P1'")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int):
            raise TypeError("match seed must be an integer")


@dataclass(frozen=True)
class MatchResult:
    case: MatchCase
    status: MatchStatus
    result: Outcome | None
    points: float | None
    rounds: int | None
    payload: Mapping[str, Any] = field(default_factory=dict)
    replay_path: Path | None = None
    events_path: Path | None = None
    error: str | None = None
    process_returncodes: tuple[int, int, int] | None = None

    def __post_init__(self) -> None:
        if self.status == "complete":
            if self.result is None or self.points is None or self.error is not None:
                raise ValueError("complete match has invalid completion fields")
        elif self.status == "incomplete":
            if self.result is not None or self.points is not None:
                raise ValueError("incomplete match cannot be scored")
            if not self.error:
                raise ValueError("incomplete match requires an error")
        else:
            raise ValueError(f"unknown match status: {self.status}")


class AntWarMatchError(RuntimeError):
    """The backend terminal payload cannot be interpreted as an AntWar result."""


def _winner_from_end_info(end_info: object) -> int | None:
    if isinstance(end_info, str):
        try:
            end_info = json.loads(end_info)
        except json.JSONDecodeError:
            return None
    if not isinstance(end_info, dict):
        return None
    try:
        score0 = float(end_info.get("0", 0))
        score1 = float(end_info.get("1", 0))
    except (TypeError, ValueError):
        return None
    if score0 > score1:
        return 0
    if score1 > score0:
        return 1
    return None


def run_native_match(
    *,
    game: ProcessSpec,
    candidate_process: ProcessSpec,
    opponent_process: ProcessSpec,
    case: MatchCase,
    replay_path: Path,
    events_path: Path,
    timeout_s: float,
) -> MatchResult:
    candidate_player = 0 if case.role == "P0" else 1
    players = (
        (candidate_process, opponent_process)
        if candidate_player == 0
        else (opponent_process, candidate_process)
    )
    judged = run_stdio_match(
        backend=game,
        players=players,
        config={"random_seed": FIXED_SEED},
        replay_path=replay_path,
        events_path=events_path,
        timeout_s=timeout_s,
    )
    winner_player = _winner_from_end_info(judged.end_message.get("end_info"))
    if winner_player is None:
        outcome: Outcome = "draw"
        points = 0.5
    elif winner_player == candidate_player:
        outcome = "win"
        points = 1.0
    else:
        outcome = "loss"
        points = 0.0
    return MatchResult(
        case=case,
        status="complete",
        result=outcome,
        points=points,
        rounds=max(judged.final_state, 0),
        payload={"winner_player": winner_player},
        replay_path=replay_path if replay_path.is_file() else None,
        events_path=events_path,
        process_returncodes=tuple(judged.process_returncodes[:3]),
    )


Runner = Callable[..., MatchResult]


class AntWarArena:
    def __init__(
        self,
        *,
        game: ProcessSpec,
        candidate: ProcessSpec,
        opponent: ProcessSpec,
        artifact_root: Path,
        timeout_s: float = DEFAULT_MATCH_TIMEOUT_S,
        runner: Runner = run_native_match,
    ) -> None:
        self.game = game
        self.candidate = candidate
        self.opponent = opponent
        self.artifact_root = Path(artifact_root)
        self.timeout_s = float(timeout_s)
        self.runner = runner

    def run_case(self, case: MatchCase) -> MatchResult:
        root = (
            self.artifact_root
            / case.candidate_id
            / case.opponent_id
            / case.role.lower()
            / f"seed-{case.seed}"
        )
        try:
            return self.runner(
                game=self.game,
                candidate_process=self.candidate,
                opponent_process=self.opponent,
                case=case,
                replay_path=root / "replay.json",
                events_path=root / "transport-events.jsonl",
                timeout_s=self.timeout_s,
            )
        except (
            AntWarMatchError,
            SaibloJudgerError,
            TimeoutError,
            OSError,
            subprocess.TimeoutExpired,
        ) as exc:
            return MatchResult(
                case=case,
                status="incomplete",
                result=None,
                points=None,
                rounds=None,
                error=str(exc),
            )

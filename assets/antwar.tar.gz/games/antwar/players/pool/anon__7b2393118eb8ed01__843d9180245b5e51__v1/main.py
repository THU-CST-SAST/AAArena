from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import *
from antwar.gamedata import *
import copy
import time
import random


CONSTANT = 10
STEP = 32
'''
player_tower_area = [[(6, 1), (7, 1), (4, 2), (6, 2), (8, 2), (4, 3), (5, 3), (6, 4), (8, 4), (7, 5), 
                      (5, 6), (5, 7), (6, 7), (8, 7), (7, 8), (4, 9), (5, 9), (6, 9), (7, 10), (5, 11), (6, 11), 
                      (8, 11), (5, 12), (7, 13), (6, 14), (8, 14), (4, 15), (5, 15), (4, 16), (6, 16), (8, 16), (6, 17), (7, 17)],
                      [(11, 1), (12, 1), (9, 2), (11, 2), (13, 2), (13, 3), (14, 3), (9, 4), (11, 4), (11, 5), 
                      (12, 6), (10, 7), (12, 7), (13, 7), (10, 8), (12, 9), (13, 9), (14, 9), (10, 10), (10, 11), 
                      (12, 11), (13, 11), (12, 12), (11, 13), (9, 14), (11, 14), (13, 15), (14, 15), (9, 16), (11, 16), (13, 16), (11, 17), (12, 17)]]
'''
# player_tower_area = [[(4, 3), (4, 15), (6, 7), (6, 11), (6, 2), (6, 16), (7, 5), (7, 13), (8, 7), (8, 11), (8, 4), (8, 14), (4, 9)], 
#                      [(14, 3), (14, 15), (12, 7), (12, 11), (11, 2), (11, 16), (11, 5), (11, 13), (10, 7), (10, 11), (9, 4), (9, 14), (14, 9)]]

player_tower_area = [[(8, 2), (8, 16), (8, 7), (8, 11), (7, 5), (7, 13), (6, 7), (6, 11), (5, 3), (5, 15), (5, 9), (4, 9)],
                     [(9, 2), (9, 16), (10, 7), (10, 11), (11, 5), (11, 13), (13, 7), (13, 11), (13, 3), (13, 15), (13, 9), (14, 9)]]


class MonteCarloAI:
    def __init__(self) -> None:
        
        self.actions = [OperationType.BUILD_TOWER, OperationType.UPGRADE_TOWER]
        
        
    def get_action(self, state, my_seat):
        
        '''
            my_towers = [1]
            for tower in state.towers:
                if tower.player == my_seat:
                    my_towers.append(tower)

            best_value = -10000
            best_op = None
            downgrade_op = None

            # 计算什么都不做的value
            noac_state = copy.deepcopy(state)
            value = self.simulate(my_seat, noac_state, None, None, None, 20)
            
            if value > best_value:
                best_value = value

            for tower in my_towers:
                step = 15
                tmp_state = copy.deepcopy(state)

                # 先拆塔 再建塔或升级塔的情况  注意此时step要少1
                if not isinstance(tower, int):
                    # 拆塔并更新
                    downgrade_op = downgrade_tower_op(tower.id)
                    tmp_state.apply_operation(my_seat, downgrade_op)
                    tmp_state.simulate_next_round()
                    step -= 1

                # 不拆塔 直接建塔或升级塔的情况  
                # 计算对塔做一次操作后的value
                for action in self.actions:

                    for action_pos in player_tower_area[my_seat]:
                        cur_state = copy.deepcopy(tmp_state)

                        # 创建operation
                        cur_op = self.action_rationality(cur_state, my_seat, action, action_pos)

                        # 判断是否为合法操作 
                        if cur_op is not None:
                            
                            # 做一次操作并更新
                            cur_state.apply_operation(my_seat, cur_op)
                            cur_state.simulate_next_round()

                            # 则假设自己和对手到模拟结束什么都不做 
                            value = self.simulate(my_seat, cur_state, cur_op, action, action_pos, step, True)

                            if value > best_value:
                                best_op = cur_op if downgrade_op is None else downgrade_op
                                best_value = value
                        

            return best_op
        '''

        # 判断什么都不做是否掉血
        cur_state = copy.deepcopy(state)
        cur_hp = cur_state.hp[my_seat]
        sim_hp = self.simulate(my_seat, cur_state)
        d_hp_noac = cur_hp - sim_hp
        
        # 没掉血 就什么都不做
        if d_hp_noac == 0:
            return None
        # 掉血就尝试建塔或尝试升级塔
        else:
            # 假设钱足够，在所有可选点模拟所有操作，并将这些操作按优略排序
            # 判别优略的因素优先级 hp > delta coin
            # 优先按delta 血量由低到高排序，在血量相同的情况下 按delta 金币由高到低
            tmp = []
            for action_index, action in enumerate(self.actions):

                for action_pos_index, action_pos in enumerate(player_tower_area[my_seat]):
                    target_coord = Coord(action_pos[0], action_pos[1])
                    cur_state = copy.deepcopy(state)
                
                    # 建塔
                    if action == OperationType.BUILD_TOWER and cur_state.tower_at(target_coord) is None:

                        # 做动作
                        tower = cur_state.build_tower(my_seat, target_coord)
                        cur_state.operated_tower_id.append(tower.id)
                        cur_state.coin[my_seat] -= cur_state.build_tower_cost(my_seat)
                        
                        # 模拟前的金币
                        pre_coin = cur_state.coin[my_seat]
                        pre_hp = cur_state.hp[my_seat]
                        # 模拟
                        sim_hp = self.simulate(my_seat, cur_state)
                        tmp.append([pre_hp - sim_hp, cur_state.coin[my_seat] - pre_coin, (action, target_coord)])

                    # 升级
                    if action == OperationType.UPGRADE_TOWER and cur_state.tower_at(target_coord) is not None and cur_state.tower_at(target_coord).type == TowerType.BASIC:
                        
                        # 做动作
                        tower = cur_state.tower_at(target_coord)
                        cur_state.operated_tower_id.append(tower.id)
                        cur_state.upgrade_tower(tower.id, TowerType.MORTAR)
                        cur_state.coin[my_seat] -= cur_state.upgrade_tower_cost(TowerType.MORTAR)
                        
                        # 模拟前的金币和血量
                        pre_coin = cur_state.coin[my_seat]
                        pre_hp = cur_state.hp[my_seat]
                        # 模拟
                        sim_hp = self.simulate(my_seat, cur_state)
                        tmp.append([pre_hp - sim_hp, cur_state.coin[my_seat] - pre_coin, (action, target_coord)])

            # 对tmp排序 排完序后索引越小 动作效果越好
            sort_list = sorted(tmp, key=lambda x: (x[0], -x[1]))

            # 先判断该态势下能否拆塔，即是否拆除某一塔模拟后血量不减少，并按拆除后的优略排序
            down_list = []
            down_state = copy.deepcopy(state)
            towers = down_state.towers
            for tower in towers:
                # 做动作
                down_state.apply_operation(my_seat, downgrade_tower_op(tower.id))

                # 模拟前的金币和血量
                pre_coin = down_state.coin[my_seat]
                pre_hp = down_state.hp[my_seat]
                # 模拟
                sim_hp = self.simulate(my_seat, down_state)
                down_list.append([pre_hp - sim_hp, down_state.coin[my_seat] - pre_coin, (OperationType.DOWNGRADE_TOWER, tower.coord)])

            sort_down_list = sorted(down_list, key=lambda x: (x[0], -x[1]))
            msg = 'tower id: '
            for t in sort_down_list:
                msg += str(state.tower_at(t[2][1]).id) + ' '
            debug('round: ' + str(state.round) + ' ' + msg)

            # 尝试从最优操作开始取 看在不拆塔的情况下(即钱够的情况)，是否可以做某一操作保持hp不减少
            # 当钱不够的最优解是 取让hp保持不变 且差钱差的最少的作为最优解 如果没有一个能让hp保持不变 则选择sort_list[0]作为最优解
            best_op = None
            best_cost_dis = 10000
            best_cost_index = -1
            for index, info in enumerate(sort_list):
                d_hp, d_coin, ac_info = info[0], info[1], info[2]

                if ac_info[0] == OperationType.BUILD_TOWER:
                    cost = state.build_tower_cost(my_seat)
                else:
                    cost = state.upgrade_tower_cost(TowerType.MORTAR)

                # 如果没有能让hp保持不掉血的 就选sort_list[0]作为最优解
                if d_hp != 0 and best_cost_index == -1:
                    best_cost_dis = cost - state.coin[my_seat]
                    best_cost_index = 0
                    break

                # 保持hp不变且钱够
                if state.coin[my_seat] >= cost:
                    if ac_info[0] == OperationType.BUILD_TOWER:
                        best_op = build_tower_op(ac_info[1])
                    else:
                        best_op = upgrade_tower_op(state.tower_at(ac_info[1]).id, TowerType.MORTAR)
                    break
                else:
                    # 保持hp不变但钱不够 需要保存能使hp不变且花费最少的钱 作为最优解
                    best_cost_dis = min(cost - state.coin[my_seat], best_cost_dis)
                    best_cost_index = index

            # 拆塔的情况
            if best_op is None:
                
                for info in sort_down_list:
                    
                    cur_state = copy.deepcopy(state)
                    # 拆哪个塔呢
                    # 拆 返还的钱比best_cost_dis多的，并且拆完后再执行sort_list[best_cost_index][2][0]操作的delta hp比什么都不做要低 这才执行拆塔操作
                    # 否则 什么都不做
                    d_hp_down, d_coin_down, ac_info_down = info[0], info[1], info[2]

                    # 注意 不能拆 最优解为升级的对应塔，即拆了之后无法升级 
                    if sort_list[best_cost_index][2][0] == OperationType.UPGRADE_TOWER and ac_info_down[1] == sort_list[best_cost_index][2][1]:
                        continue

                    # 模拟拆完后再执行sort_list[best_cost_index][2][0]操作
                    tower = cur_state.tower_at(ac_info_down[1])
                    pre_hp = cur_state.hp[my_seat]
                    cur_state.apply_operation(my_seat, downgrade_tower_op(tower.id))
                    cur_state.simulate_next_round()
                    if sort_list[best_cost_index][2][0] == OperationType.BUILD_TOWER:
                        cur_state.apply_operation(my_seat, build_tower_op(sort_list[best_cost_index][2][1]))
                    else:
                        
                        cur_state.apply_operation(my_seat, upgrade_tower_op(cur_state.tower_at(sort_list[best_cost_index][2][1]).id, TowerType.MORTAR))

                    sim_hp = self.simulate(my_seat, cur_state, True)

                    if state.downgrade_tower_income(state.tower_at(ac_info_down[1]).id) >= best_cost_dis and (pre_hp - sim_hp) < d_hp_noac:
                        best_op = downgrade_tower_op(state.tower_at(ac_info_down[1]).id)
                        break

            return best_op
            

        
    
    def action_rationality(self, cur_state, my_seat, action, action_pos):
        target_coord = Coord(action_pos[0], action_pos[1])
        if action == OperationType.BUILD_TOWER:
            valid = (
                    cur_state.coin[my_seat] >= cur_state.build_tower_cost(my_seat)
                    and is_player_highland(target_coord, my_seat)
                    and cur_state.tower_at(target_coord) is None
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
            )
            if valid:
                return build_tower_op(target_coord)
        if action == OperationType.UPGRADE_TOWER:
            # 先写死 升级只能升到mortar
            cur_tower = cur_state.tower_at(target_coord)
            valid = (
                    cur_tower is not None
                    and cur_tower.id not in cur_state.operated_tower_id
                    and cur_tower.player == my_seat
                    and cur_state.coin[my_seat] >= cur_state.upgrade_tower_cost(TowerType.MORTAR)
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
                    and can_tower_upgrade_to(cur_tower.type, TowerType.MORTAR)
            )
            if valid:
                return upgrade_tower_op(cur_tower.id, TowerType.MORTAR)
        if action == OperationType.DOWNGRADE_TOWER:
            cur_tower = cur_state.tower_at(target_coord)
            valid = (
                    cur_tower is not None
                    and cur_tower.id not in cur_state.operated_tower_id
                    and cur_tower.player == my_seat
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
            )
            if valid:
                return downgrade_tower_op(cur_tower.id)

        return None
    
    def get_operation(self, cur_state, action, target_coord):
        if action == OperationType.BUILD_TOWER:
            return build_tower_op(target_coord)
        if action == OperationType.UPGRADE_TOWER:
            # 先写死 升级只能升到mortar
            return upgrade_tower_op(cur_state.tower_at(target_coord).id, TowerType.MORTAR)
        if action == OperationType.DOWNGRADE_TOWER:
            return downgrade_tower_op(cur_state.tower_at(target_coord).id)
        
        return None

    def simulate(self, my_seat, cur_state, is_act = False):
        count = 0
        step = STEP - 1 if is_act else STEP
        while count < step and cur_state.round < 512 and cur_state.hp[0] != 0 and cur_state.hp[1] != 0:
            count += 1
            cur_state.simulate_next_round()
            
        return cur_state.hp[my_seat]



def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:

        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    else:
        ai = MonteCarloAI()

        operation = ai.get_action(state, my_seat)
        if operation is not None:
            operations.append(operation)
        
    return operations

def simple_ai_oppo(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    elif state.round == 1:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 4)))
        else:
            operations.append(build_tower_op(Coord(13, 4)))
    
    else:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 14)))
        else:
            operations.append(build_tower_op(Coord(13, 14)))

    return operations




# run_antwar_ai(simple_ai, simple_ai_oppo)
run_antwar_ai(simple_ai)
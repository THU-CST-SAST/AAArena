from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import *
from antwar.gamedata import *
import copy
import time
import random


CONSTANT = 10
'''
player_tower_area = [[(6, 1), (7, 1), (4, 2), (6, 2), (8, 2), (4, 3), (5, 3), (6, 4), (8, 4), (7, 5), 
                      (5, 6), (5, 7), (6, 7), (8, 7), (7, 8), (4, 9), (5, 9), (6, 9), (7, 10), (5, 11), (6, 11), 
                      (8, 11), (5, 12), (7, 13), (6, 14), (8, 14), (4, 15), (5, 15), (4, 16), (6, 16), (8, 16), (6, 17), (7, 17)],
                      [(11, 1), (12, 1), (9, 2), (11, 2), (13, 2), (13, 3), (14, 3), (9, 4), (11, 4), (11, 5), 
                      (12, 6), (10, 7), (12, 7), (13, 7), (10, 8), (12, 9), (13, 9), (14, 9), (10, 10), (10, 11), 
                      (12, 11), (13, 11), (12, 12), (11, 13), (9, 14), (11, 14), (13, 15), (14, 15), (9, 16), (11, 16), (13, 16), (11, 17), (12, 17)]]
'''
player_tower_area = [[(4, 3), (4, 15), (6, 7), (6, 11), (6, 2), (6, 16), (7, 5), (7, 13), (8, 7), (8, 11), (8, 4), (8, 14), (4, 9)], 
                     [(14, 3), (14, 15), (12, 7), (12, 11), (11, 2), (11, 16), (11, 5), (11, 13), (10, 7), (10, 11), (9, 4), (9, 14), (14, 9)]]

# player_tower_area = [[[(4, 3), (6, 2), (7, 5), (8, 4)], [(6, 7), (6, 11), (8, 7), (8, 11)], [(4, 15), (6, 16), (7, 13), (8, 14)]],
#                      [[(14, 3), (11, 2), (11, 5), (9, 4)], [(12, 7), (12, 11), (10, 7), (10, 11)], [(14, 15), (11, 16), (11, 13), (9, 14)]]]


class MonteCarloAI:
    def __init__(self) -> None:
        
        # self.action_poss = [0] * 33
        self.iterations = 50
        self.actions = [OperationType.BUILD_TOWER, OperationType.UPGRADE_TOWER, OperationType.DOWNGRADE_TOWER]
        
    def get_action(self, state, my_seat):

        best_value = -10000
        best_op = None

        # 计算什么都不做的value
        cur_state = copy.deepcopy(state)
        value = self.simulate(my_seat, cur_state, None, None, None, 32)
        
        if value > best_value:
            best_value = value

        # 计算对塔做一次操作后的value
        for action in self.actions:

            for action_pos in player_tower_area[my_seat]:
                cur_state = copy.deepcopy(state)
                # 创建operation
                cur_op = self.action_rationality(cur_state, my_seat, action, action_pos)

                # 判断是否为合法操作 
                if cur_op is not None:

                    # 做一次操作并更新
                    cur_state.apply_operation(my_seat, cur_op)
                    cur_state.simulate_next_round()

                    # 如果是建塔或升级塔的操作 则假设自己和对手到模拟结束什么都不做 
                    if cur_op.type != OperationType.DOWNGRADE_TOWER:
                        
                        value = self.simulate(my_seat, cur_state, cur_op, action, action_pos, 32, True)
                        

                    # 但拆塔之后不能什么都不做 拆塔本质是为别的动作做准备
                    else:
                        # 拆塔，遍历所有可能的一次后续操作
                        value = -10000
                        for index in range(2):
                            tmp_action = self.actions[index]
                            for tmp_action_pos in player_tower_area[my_seat]:
                                
                                # 不在原先拆塔的位置操作
                                if tmp_action_pos == action_pos:
                                    continue
                            
                                tmp_state = copy.deepcopy(cur_state)
                                tmp_op = self.action_rationality(tmp_state, my_seat, tmp_action, tmp_action_pos)
                                if tmp_op is not None:
                                    
                                    tmp_state.apply_operation(my_seat, tmp_op)
                                    tmp_state.simulate_next_round()
                        
                                    tmp_value = self.simulate(my_seat, tmp_state, tmp_op, tmp_action, tmp_action_pos, 31, True)
                                    if tmp_value > value:
                                        value = tmp_value

                    if value > best_value:
                        best_op = cur_op
                        best_value = value
                    

            # end = time.time()

        return best_op
    
    def action_rationality(self, cur_state, my_seat, action, action_pos):
        target_coord = Coord(action_pos[0], action_pos[1])
        if action == OperationType.BUILD_TOWER:
            valid = (
                    cur_state.coin[my_seat] >= cur_state.build_tower_cost(my_seat)
                    and is_player_highland(target_coord, my_seat)
                    and cur_state.tower_at(target_coord) is None
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
            )
            if valid:
                return build_tower_op(target_coord)
        if action == OperationType.UPGRADE_TOWER:
            # 先写死 升级只能升到mortar
            cur_tower = cur_state.tower_at(target_coord)
            valid = (
                    cur_tower is not None
                    and cur_tower.id not in cur_state.operated_tower_id
                    and cur_tower.player == my_seat
                    and cur_state.coin[my_seat] >= cur_state.upgrade_tower_cost(TowerType.MORTAR)
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
                    and can_tower_upgrade_to(cur_tower.type, TowerType.MORTAR)
            )
            if valid:
                return upgrade_tower_op(cur_tower.id, TowerType.MORTAR)
        if action == OperationType.DOWNGRADE_TOWER:
            cur_tower = cur_state.tower_at(target_coord)
            valid = (
                    cur_tower is not None
                    and cur_tower.id not in cur_state.operated_tower_id
                    and cur_tower.player == my_seat
                    and not cur_state.check_in_emp_range(my_seat, target_coord)
            )
            if valid:
                return downgrade_tower_op(cur_tower.id)

        return None

    '''
        def get_operation(self, cur_state, action, action_pos):
            target_coord = Coord(action_pos[0], action_pos[1])
            if action == OperationType.BUILD_TOWER:
                return build_tower_op(target_coord)
            if action == OperationType.UPGRADE_TOWER and cur_state.tower_at(target_coord) is not None:
                # 先写死 升级只能升到mortar
                return upgrade_tower_op(cur_state.tower_at(target_coord).id, TowerType.MORTAR)
            if action == OperationType.DOWNGRADE_TOWER and cur_state.tower_at(target_coord) is not None:
                return downgrade_tower_op(cur_state.tower_at(target_coord).id)
            if action == OperationType.UPGRADE_GENERATE_SPEED:
                return upgrade_generate_speed_op()
            if action == OperationType.UPGRADE_ANT_MAXHP:
                return upgrade_ant_maxhp_op()
            
            return None
    '''
    

    def simulate(self, my_seat, cur_state, cur_op, action, action_pos, step, flag = False):
        
        # 有操作flag为True 无操作flag为False
        if not flag:
            cur_state.simulate_next_round()

        # 记录当前的血量和金币
        pre_my_coin = cur_state.coin[my_seat]
        pre_my_hp = cur_state.hp[my_seat]
        is_decrease = False
        pre_oppo_coin = cur_state.coin[1 - my_seat]
        pre_oppo_hp = cur_state.hp[1 - my_seat]      
        
        reward = 0
        count = 0
        while count < step and cur_state.hp[0] != 0 and cur_state.hp[1] != 0:
            
            count += 1
            reward += 1

            cur_state.simulate_next_round()
            # 根据状态的更新给予reward
            reward += (cur_state.coin[my_seat] - pre_my_coin)
            pre_my_coin = cur_state.coin[my_seat]

            reward += 50 * (cur_state.hp[my_seat] - pre_my_hp)
            if cur_state.hp[my_seat] != pre_my_hp:
                is_decrease = True
            pre_my_hp = cur_state.hp[my_seat]
            
        # 越早消灭敌人，reward相对越高
        reward += 2 ** (8 - count)

        if is_decrease:
            reward -= 100
        
        return reward



def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:

        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    else:
        ai = MonteCarloAI()

        operation = ai.get_action(state, my_seat)
        if operation is not None:
            operations.append(operation)
        
    return operations

def simple_ai_oppo(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    elif state.round == 1:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 4)))
        else:
            operations.append(build_tower_op(Coord(13, 4)))
    
    else:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 14)))
        else:
            operations.append(build_tower_op(Coord(13, 14)))

    return operations




# run_antwar_ai(simple_ai, simple_ai_oppo)
run_antwar_ai(simple_ai)
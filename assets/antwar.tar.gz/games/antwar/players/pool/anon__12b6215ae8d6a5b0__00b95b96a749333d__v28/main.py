from antwar.controller import run_antwar_ai, self_play_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from AIs.fixpolicyai import FixPolicyAI
from AIs.defensiveai import DefensiveAI
from AIs.searchai import SearchOnStartAI, PlusTwoPolicy
from AIs.offensiveai import OffensiveAI

# TODO: 开局搜索最优三塔顺序
# TODO: 中间决策应对
# 完全模拟一局 2ai+game 要 1-2s 量级 

# fpai0 = SearchOnStartAI() 
# fpai1 = OffensiveAI()
# out = self_play_antwar_ai(fpai0, fpai1, seed=40)

# ais = [(PlusTwoPolicy(Coord(5,3), Coord(5,15), False, tp), PlusTwoPolicy(Coord(5,3), Coord(5,15), False, tp)) for tp in [TowerType.MORTAR, TowerType.HEAVY, TowerType.QUICK]]
# import numpy as np
# for ai0, ai1 in ais:
#     rsthp = []
#     for seed in range(100):
#         rst = self_play_antwar_ai(ai0, ai1, seed=seed)
#         rsthp+=rst.hp
#     print(ai1.tower_type, np.mean(rsthp))
# print(out)
    
fpai = SearchOnStartAI()
run_antwar_ai(fpai)

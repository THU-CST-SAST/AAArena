from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import distance
from copy import deepcopy
from typing import List

def getFromP0toSeat(wt, my_seat):
    return wt if my_seat==0 else getFromOpponent(wt)

def getFromOpponent(wt):
    if isinstance(wt,dict):
        new_wt = {}
        for k in wt:
            new_wt[k] = getFromOpponent(wt[k])
        return new_wt
    if isinstance(wt,list):
        new_wt = []
        for k in wt:
            new_wt.append(getFromOpponent(k))
        return new_wt
    if isinstance(wt, Coord):
        if wt.y % 2 == 0:
            new_wt = Coord(17-wt.x, 18-wt.y)
        else:
            new_wt = Coord(18-wt.x, 18-wt.y)
        return new_wt
    return None

def getAnts(ant_list, player):
    return objofPlayer(ant_list)

def objInRadius(objs: List[object], coord: Coord, radius: int):
    '''
    obj in `objs` should have .coord prop
    return the coordinates in the map of <= `radius`
    '''
    return [obj for obj in objs if distance(obj.coord, coord) <= radius]

def objofPlayer(objs: List[object], player):
    '''
    obj in `objs` should have .player prop
    '''
    return [obj for obj in objs if obj.player == player]
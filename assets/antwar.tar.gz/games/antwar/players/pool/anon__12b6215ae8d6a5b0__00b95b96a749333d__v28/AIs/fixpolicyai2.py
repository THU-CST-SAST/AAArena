from antwar.controller import run_antwar_ai, self_play_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import distance
import utils
import sys

class FixPolicyAI:
    def __init__(self):
        self.policy_states = ['init', 'next_1', 'next_2', 'mortar', 'double', 'double-up', 'double-up-up', 'emp_defend', 'defend', 'deflectors_defend', 'evasion_defend', 'offend', 'emp, deflectors']
        self.policy_state = 'init'
        self.cnt = 0
        self.time_delay = 0
        self.last_round = 0

    def __call__(self, my_seat, state: GameState):
        tower_coords_0 = {
                'init': Coord(4,9),
                'next_2': [Coord(5,3), Coord(5,15)],
                'emp': Coord(12,9),
                'def': Coord(13,9),
                'left': [Coord(6, 13), Coord(5, 14), Coord(6, 15), Coord(7, 18)],
                'right': [Coord(6, 5), Coord(5, 4), Coord(6, 3), Coord(7, 0)],
                'home': Coord(2, 9)
            }
        tower_coords = tower_coords_0 if my_seat == 0 else utils.getFromOpponent(tower_coords_0)
        # 第一轮中间建塔
        if self.policy_state == 'init':
            self.policy_state = 'next_1'
            return [build_tower_op(tower_coords['init'])]
        # 根据敌人路径依次再建两座塔
        if self.policy_state == 'next_1':
            if state.coin[my_seat] >= 89:
                self.policy_state = 'mortar'
                return [build_tower_op(tower_coords['next_2'][1])]
            ant_of_component = utils.getAnts(state.ants, my_seat^1)
            for ant in ant_of_component:
                ant: Ant
                if ant.coord in tower_coords['left']:
                    self.policy_state = 'mortar'
                    return [build_tower_op(tower_coords['next_2'][1])]
                if ant.coord in tower_coords['right']:
                    self.policy_state = 'mortar'
                    return [build_tower_op(tower_coords['next_2'][0])]                       
        # 升级mortor
        if self.policy_state == 'mortar':
            if state.coin[my_seat] >= 60:
                self.policy_state = 'next_2'
                tower_id = state.tower_at(tower_coords['init']).id
                return [upgrade_tower_op(tower_id, TowerType.MORTAR)] 
               
        if self.policy_state == 'next_2':
            ops = []
            for tower_coord in tower_coords['next_2']:
                if state.apply_operation(my_seat, build_tower_op(tower_coord), dry_run=True):
                    ops.append(build_tower_op(tower_coord))
            if len(ops) > 0:
                self.policy_state = 'double'
            return ops
        
        # 拆塔建double
        if self.policy_state == 'double':
            if state.coin[my_seat] >= 210:
                self.policy_state = 'double-up'
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
        if self.policy_state == 'double-up':
            self.policy_state = 'double-up-up'
            tower_id = state.tower_at(tower_coords['init']).id
            return [upgrade_tower_op(tower_id, TowerType.QUICK)]
        if self.policy_state == 'double-up-up':
            if state.hp[my_seat] > state.hp[my_seat^1]:
                self.policy_state = 'defend'
            else:
                self.policy_state = 'offend'
            tower_id = state.tower_at(tower_coords['init']).id
            return [upgrade_tower_op(tower_id, TowerType.DOUBLE)]
        
        # defend against different types of super weapon
        if self.policy_state == 'defend':
            if state.round >= 490 and state.round >= self.last_round + 101 and state.coin[my_seat] >= 150:
                print("entering end")
                self.policy_state = 'end'
                self.cnt = 0
            else:
                for i in state.active_super_weapon:
                    if i.player == my_seat:
                        continue
                    else:
                        # use lightning storm to defend against EMP
                        if i.type == SuperWeaponType.EMP_BLASTER:
                            self.policy_state = 'emp_defend'
                            min_delay = 0
                            ant_of_component = utils.getAnts(state.ants, my_seat^1)
                            for ant in ant_of_component:
                                ant: Ant
                                min_delay = min(min_delay, distance(ant.coord, tower_coords['home'])-1)
                            self.time_delay = 0
                            break
                        
                        # No need to defend against level 1 ants
                        if state.gen_speed_lv[my_seat^1] == 0 and state.ant_maxhp_lv[my_seat^1] == 0:
                            return []
                        
                        if i.type == SuperWeaponType.DEFLECTORS:
                            if state.tower_at(tower_coords['init']).type == TowerType.SNIPER:
                                continue
                            self.policy_state = 'deflectors_defend'
                            self.cnt = 0
                            break
                                
                        elif i.type == SuperWeaponType.EMERGENCY_EVASION:
                            if state.tower_at(tower_coords['init']).type == TowerType.QUICK_PLUS:
                                continue
                            self.policy_state = 'evasion_defend'
                            self.cnt = 0
                            break
        
        if self.policy_state == 'emp_defend':
            if self.time_delay != 0:
                self.time_delay -= 1
                return []
            else:
                self.policy_state = 'defend'
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.LIGHTNING_STORM, tower_coords['home']), dry_run=True):
                    self.last_round = state.round
                    return [deploy_super_weapon_op(SuperWeaponType.LIGHTNING_STORM, tower_coords['home'])]
                return []                    

        if self.policy_state == 'deflectors_defend':
            if self.cnt == 0:
                self.cnt = 1
                tower_id = state.tower_at(tower_coords['init']).id
                # print(state.tower_at(tower_coords['init']).type)
                return [downgrade_tower_op(tower_id)]
            else:
                self.policy_state = 'defend'
                tower_id = state.tower_at(tower_coords['init']).id
                return [upgrade_tower_op(tower_id, TowerType.SNIPER)]
            
        if self.policy_state == 'evasion_defend':
            if self.cnt == 0:
                self.cnt = 1
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
            else:
                self.policy_state = 'defend'
                tower_id = state.tower_at(tower_coords['init']).id
                return [upgrade_tower_op(tower_id, TowerType.QUICK_PLUS)]
        
        if self.policy_state == 'end':
            if self.cnt == 0:
                self.cnt = 1
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 1:
                self.cnt = 2
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 2:
                self.cnt = 3
                return [deploy_super_weapon_op(SuperWeaponType.LIGHTNING_STORM, tower_coords['home'])]
            elif self.cnt == 3:
                self.cnt = 4
                tower_id = state.tower_at(tower_coords['next_2'][0]).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 4:
                self.cnt = 5
                tower_id = state.tower_at(tower_coords['next_2'][1]).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 5:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp']), dry_run=True):
                    self.cnt = 6
                    return [deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp'])]
                return []
            elif self.cnt == 6:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.EMERGENCY_EVASION, tower_coords['emp']), dry_run=True):
                    self.cnt = 7
                    return [deploy_super_weapon_op(SuperWeaponType.EMERGENCY_EVASION, tower_coords['emp'])]
                return []
            elif self.cnt == 7:
                return []
            
            
        if self.policy_state == 'offend':
            if state.coin[my_seat] >= 340:
                if state.apply_operation(my_seat, upgrade_ant_maxhp_op(), dry_run=True):
                    self.policy_state = 'emp'
                    return [upgrade_ant_maxhp_op()]
        
        if self.policy_state == 'emp':
            self.cnt += 1
            if self.cnt == 30:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp']), dry_run=True) :
                    self.policy_state = 'deflectors'
                    return [deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp'])]
            
        if self.policy_state == 'deflectors':
            if state.coin[my_seat] >= 115:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def']), dry_run=True):
                    # sys.stderr.write('IE?')
                    return [deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def'])]  
        return []
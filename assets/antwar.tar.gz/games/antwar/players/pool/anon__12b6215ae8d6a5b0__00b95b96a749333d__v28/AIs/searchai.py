from antwar.controller import run_antwar_ai, self_play_antwar_ai, run_antwar_with_noopp
from antwar.gamestate import GameState
from antwar.protocol import *
from AIs.fixpolicyai import FixPolicyAI
from AIs.simpleai import build_tower_at_center_ai
from enum import IntEnum
from time import time as getTime
import utils
import sys

def timer(func):
    def new_func(*args, **kwargs):
        start_time = getTime()
        result = func(*args, **kwargs)
        sys.stderr.write(f'{getTime()-start_time}\n')
        return result
    return new_func
'''
protocol for policy:
just similar to ai but return None to show the policy stage is finished
'''
class PlusTwoPolicy:
    def __init__(self, coord_1, coord_2, update_first: bool, tower_type: TowerType):
        '''
        other 2 tower on coord_1 and coord_2
        '''
        self.coord_0 = Coord(4,9)
        self.coord_1 = coord_1
        self.coord_2 = coord_2
        self.update_first = update_first
        self.tower_type = tower_type
        
    def __call__(self, my_seat, state: GameState):
        coord_0 = utils.getFromP0toSeat(self.coord_0, my_seat)
        coord_1 = utils.getFromP0toSeat(self.coord_1, my_seat)
        coord_2 = utils.getFromP0toSeat(self.coord_2, my_seat)
        
        if state.tower_at(coord_0) is None:
            if state.apply_operation(my_seat, build_tower_op(coord_0), dry_run=True):
                return [build_tower_op(coord_0)]
        elif state.tower_at(coord_1) is None:
            if state.apply_operation(my_seat, build_tower_op(coord_1), dry_run=True):
                return [build_tower_op(coord_1)]
        elif self.update_first:
            center_tower = state.tower_at(coord_0)
            if center_tower.type == TowerType.BASIC:
                if state.apply_operation(
                    my_seat, 
                    upgrade_tower_op(center_tower.id, TowerType.MORTAR), 
                    dry_run=True
                ):
                    return [upgrade_tower_op(center_tower.id, TowerType.MORTAR)]
            elif state.tower_at(coord_2) is None:
                if state.apply_operation(my_seat, build_tower_op(coord_2), dry_run=True):
                    return [build_tower_op(coord_2)]
            else:
                return None
        else:
            center_tower = state.tower_at(coord_0)
            if state.tower_at(coord_2) is None:
                if state.apply_operation(my_seat, build_tower_op(coord_2), dry_run=True):
                    return [build_tower_op(coord_2)]
            elif center_tower.type == TowerType.BASIC:
                if state.apply_operation(
                    my_seat, 
                    upgrade_tower_op(center_tower.id, self.tower_type), 
                    dry_run=True
                ):
                    return [upgrade_tower_op(center_tower.id, self.tower_type)]
            else:
                return None
        return []
    
class MortarPlusTwoPolicy(PlusTwoPolicy):
    def __init__(self, coord_1, coord_2, mortar_first: bool):
        super().__init__(coord_1, coord_2, mortar_first, tower_type=TowerType.MORTAR)

class SearchOnStartAI:
    class State(IntEnum):
        INIT = 1
        NEXT2 = 11
        MID = 2
    
    def __init__(self, time_lim=0.85, start_round=150):
        '''
        search in the policy pool `start_ai`
        (we assume the situation does not change fast at the beginning of the game)
        Assume that we have enough time to decide to use witch ai
        '''
        # the ai in this pool should have a robust policy s.t. atarting from first n round, it should still work. The ai should also return None if no more action. Furthermore, the ai should not have memory.
        coords_l = [Coord(5,3), Coord(6, 4), Coord(4,3), Coord(8, 4)]
        coords_r = [Coord(5,15), Coord(6, 14), Coord(4,15), Coord(8, 14)]
        coord_s = [(c1, c2) for c1 in coords_l for c2 in coords_r]+[(c1, c2) for c1 in coords_r for c2 in coords_l]
        mortar_first = [True, False]
        self.start_ai = [
            MortarPlusTwoPolicy(c1, c2, mf) 
            for mf in mortar_first 
            for c1, c2 in coord_s
        ]
        # results is a list of [ai, state, finished_simu]
        self.start_ai_simuresult = [
            [ai, None, False] for ai in self.start_ai
        ]
        self.start_choosen_ai = None
        self.start_simu_rounds = start_round

        self.mid_ai = FixPolicyAI()
        self.mid_ai.policy_state = 'double'
        
        self.time_lim = time_lim
        self.policy_state = SearchOnStartAI.State.INIT
    
    #@timer
    def __call__(self, my_seat, state: GameState):
        start_time = getTime()
        stop_time = start_time+self.time_lim
        if self.policy_state == SearchOnStartAI.State.INIT or self.policy_state == SearchOnStartAI.State.NEXT2:
            if self.start_choosen_ai is not None:
                # we have already choosen an ai
                ops = self.start_choosen_ai(my_seat, state)
                if ops is not None:
                    return ops
                else:
                    self.policy_state = SearchOnStartAI.State.MID
                    # sys.stderr.write(f'Change to MID policy\n')
                    return []
            else:
                # simulate the some ai
                while True:
                    simu_result = None
                    # get an unfinished simulation
                    for sr in self.start_ai_simuresult:
                        _, _, simu_finished = sr
                        if simu_finished:
                            continue
                        else:
                            simu_result = sr
                    if simu_result is None:
                        # all ai in pool are simulated, update `self.start_choosen_ai`
                        best_ai = None
                        max_hp = 0
                        for sr in self.start_ai_simuresult:
                            simu_ai, last_state, _ = sr
                            if last_state.hp[my_seat] > max_hp:
                                best_ai = simu_ai
                                max_hp = last_state.hp[my_seat]
                        assert best_ai is not None
                        sys.stderr.write(f'{max_hp}')
                        self.start_choosen_ai = best_ai
                        break
                    else:
                        # continue simu
                        simu_ai, last_state, _ = simu_result
                        simu_finished, new_state = run_antwar_with_noopp(
                            state if last_state is None else last_state, 
                            simu_ai, 
                            my_seat, 
                            self.start_simu_rounds, 
                            stop_time-getTime()
                        )
                        simu_result[1] = new_state
                        simu_result[2] = simu_finished
                        
                        if simu_finished and new_state.hp[my_seat] == 50:
                            # this is already optimal, stop early
                            self.start_choosen_ai = simu_ai
                        
                        if stop_time<getTime():
                            # time run out ahhh!
                            break    
                # and output [] (since we do not really need to move in first 10 rounds)
                if self.policy_state == SearchOnStartAI.State.INIT:
                    self.policy_state = SearchOnStartAI.State.NEXT2
                    return build_tower_at_center_ai(my_seat, state)
                return []
        
        if self.policy_state == SearchOnStartAI.State.MID:
            ops = self.mid_ai(my_seat, state)
            return ops
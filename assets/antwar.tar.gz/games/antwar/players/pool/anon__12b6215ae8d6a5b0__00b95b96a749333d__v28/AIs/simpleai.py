from antwar.controller import run_antwar_ai, self_play_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
import utils
import sys

def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    tower_coords = [[Coord(6, 4), Coord(6, 14)], [Coord(11, 4), Coord(11, 14)]]

    if state.round == 0:
        return [build_tower_op(c) for c in tower_coords[my_seat]]
    return []

def empty_ai(my_seat, state):
    return []

def build_tower_at_center_ai(my_seat, state: GameState):
    ccoord_0 = Coord(4,9)
    ccoord = utils.getFromP0toSeat(ccoord_0, my_seat)
    if state.apply_operation(my_seat, build_tower_op(ccoord), dry_run=True):
        return [build_tower_op(ccoord)]
    else:
        return []
from antwar.controller import run_antwar_ai, self_play_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
import utils
import sys

class FixPolicyAI:
    def __init__(self):
        self.policy_states = ['init', 'next_1', 'next_2', 'mortar', 'double', 'double-up', 'double-up-up', 'emp', 'level_up', 'deflectors']
        self.policy_state = 'init'
        self.cnt = 0
        self.last_deflector = 0
        
    def __call__(self, my_seat, state: GameState):
        tower_coords_0 = {
                'init': Coord(4,9),
                'next_2': [Coord(5,3), Coord(5,15)],
                'def': Coord(13,9),
                # 'def': Coord(13,9),
                'emp':[Coord(12, 12), Coord(12, 6)],
                'left': [Coord(6, 13), Coord(5, 14), Coord(6, 15), Coord(7, 18)],
                'right': [Coord(6, 5), Coord(5, 4), Coord(6, 3), Coord(7, 0)],
                'home': Coord(2, 9)
            }
        tower_coords = utils.getFromP0toSeat(tower_coords_0, my_seat)
        # 第一轮中间建塔
        if self.policy_state == 'init':
            self.policy_state = 'next_1'
            return [build_tower_op(tower_coords['init'])]
        # 根据敌人路径依次再建两座塔
        if self.policy_state == 'next_1':
            if state.coin[my_seat] >= 89:
                self.policy_state = 'mortar'
                return [build_tower_op(tower_coords['next_2'][1])]
            ant_of_component = utils.getAnts(state.ants, my_seat^1)
            for ant in ant_of_component:
                ant: Ant
                if ant.coord in tower_coords['left']:
                    self.policy_state = 'mortar'
                    return [build_tower_op(tower_coords['next_2'][1])]
                if ant.coord in tower_coords['right']:
                    self.policy_state = 'mortar'
                    return [build_tower_op(tower_coords['next_2'][0])]                
        
        # 升级mortor
        if self.policy_state == 'mortar':
            if state.coin[my_seat] >= 60:
                self.policy_state = 'next_2'
                tower_id = state.tower_at(tower_coords['init']).id
                return [upgrade_tower_op(tower_id, TowerType.MORTAR)] 
               
        if self.policy_state == 'next_2':
            ops = []
            for tower_coord in tower_coords['next_2']:
                if state.apply_operation(my_seat, build_tower_op(tower_coord), dry_run=True):
                    ops.append(build_tower_op(tower_coord))
            if len(ops) > 0:
                self.policy_state = 'double'
            return ops
        
        # 拆塔建double
        if self.policy_state == 'double':
            if state.coin[my_seat] >= 210:
                self.policy_state = 'double-up'
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
        if self.policy_state == 'double-up':
            self.policy_state = 'double-up-up'
            tower_id = state.tower_at(tower_coords['init']).id
            return [upgrade_tower_op(tower_id, TowerType.QUICK)]
        if self.policy_state == 'double-up-up':
            self.policy_state = 'level_up'
            tower_id = state.tower_at(tower_coords['init']).id
            return [upgrade_tower_op(tower_id, TowerType.DOUBLE)]
        # 释放闪电
        if self.policy_state == 'level_up':
            if state.coin[my_seat] >= 270:
                if state.apply_operation(my_seat, upgrade_ant_maxhp_op(), dry_run=True):
                    self.policy_state = 'emp'
                    return [upgrade_ant_maxhp_op()]
        
        if self.policy_state == 'emp':
            self.cnt += 1
            if self.cnt == 30:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def']), dry_run=True) :
                    self.policy_state = 'deflectors'
                    self.last_deflector = state.round
                    return [deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def'])]
            
        if self.policy_state == 'deflectors':
            if state.round >= 490 and state.super_weapon_cd[my_seat][0] == 0 :
                # print("entering end")
                self.policy_state = 'end'
                self.cnt = 0
            # if state.coin[my_seat] >= 105 and state.round - self.last_deflector >= 51:
            elif state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def']), dry_run=True):
                # sys.stderr.write('IE?')
                return [deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def'])]  
        
        if self.policy_state == 'end':
            # print(self.cnt)
            # downgrade all the towers
            if self.cnt == 0:
                sys.stderr.write(str(self.cnt)+'\n')
                sys.stderr.write(str(state.coin[my_seat])+'\n')
                self.cnt = 1
                down_all = []
                for i in state.towers:
                    if i.player == my_seat:
                        down_all.append(downgrade_tower_op(i.id))
                return down_all
            if self.cnt == 1:
                sys.stderr.write(str(state.round)+'\n')
                sys.stderr.write(str(state.coin[my_seat])+'\n')
                self.cnt = 2
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 2:
                sys.stderr.write(str(state.round)+'\n')
                sys.stderr.write(str(state.coin[my_seat])+'\n')
                self.cnt = 3
                tower_id = state.tower_at(tower_coords['init']).id
                return [downgrade_tower_op(tower_id)]
            elif self.cnt == 3:
                sys.stderr.write(str(state.round)+'\n')
                sys.stderr.write(str(state.coin[my_seat])+'\n')
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.LIGHTNING_STORM, tower_coords['home']), dry_run=True):
                    self.cnt = 4
                    return [deploy_super_weapon_op(SuperWeaponType.LIGHTNING_STORM, tower_coords['home'])]
            elif self.cnt == 4:
                sys.stderr.write(str(state.round)+'\n')
                sys.stderr.write(str(state.coin[my_seat]))
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp'][0]), dry_run=True):
                    self.cnt = 5
                    return [deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, tower_coords['emp'][0])]
            elif self.cnt == 5:
                if state.apply_operation(my_seat, deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def']), dry_run=True):
                    self.cnt = 6
                    return [deploy_super_weapon_op(SuperWeaponType.DEFLECTORS, tower_coords['def'])]
            elif self.cnt == 6:
                return []        
        return []
    
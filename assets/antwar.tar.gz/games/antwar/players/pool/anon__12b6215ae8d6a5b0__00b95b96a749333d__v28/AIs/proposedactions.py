from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import distance, is_in_map
import utils

def getProposedEmpBlasters(player, state: GameState):
    """
    return list of Operation of proposed EmpBlasters operations for `player`
    """
    towers = utils.objofPlayer(state.towers, player^1)
    validCoords = [] # elements are (coord, count)
    supp_covered = 1
    for i in range(18):
        for j in range(18):
            if is_in_map(Coord(i, j)):
                count = len(utils.objInRadius(towers, Coord(i, j), 3))>0
                if count>=supp_covered:
                    validCoords.append((Coord(i, j), count))
                    supp_covered=count
    validCoords = [deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, vc) for vc in validCoords if vc[1]==supp_covered]
    return validCoords

def getProposedLightingStorm(player, state: GameState):
    coord_0 = Coord(2, 9)
    coord = utils.getFromP0toSeat(coord_0, player)
    return []

def getProposedDeflectors(player, state: GameState):
    pass

def getProposedEmergencyEvasion(player, state: GameState):
    pass

def getProposedDownGrade(player, state: GameState):
    pass

def getProposedUpGrade(player, state: GameState):
    pass

def getProposedLvUpGrade(player, state: GameState):
    pass
from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    
    operations = []

    if my_seat == 0:  # red
        operations.append(build_tower_op(Coord(8, 14)))

    if state.round == 1:
        operations.append(build_tower_op(Coord(6, 1)))

        
    return operations


run_antwar_ai(simple_ai)

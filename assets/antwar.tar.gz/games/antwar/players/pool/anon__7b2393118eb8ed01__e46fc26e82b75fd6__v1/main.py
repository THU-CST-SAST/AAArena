from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *

CONSTANT = 10


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    # if my_seat == 0:
        
    # else:
    #     if state.round == 0:
    #         operations.append(build_tower_op(Coord(14, 15)))
    #     if state.round == 1:
    #         operations.append(build_tower_op(Coord(14, 15)))

    if state.round == 0:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(13, 15)))

    if state.round == 1:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(8, 11)))
        else:
            operations.append(build_tower_op(Coord(14, 15)))
    
    return operations


run_antwar_ai(simple_ai)

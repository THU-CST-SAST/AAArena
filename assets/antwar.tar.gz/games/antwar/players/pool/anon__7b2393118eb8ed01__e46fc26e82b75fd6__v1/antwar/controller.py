from typing import Callable

from .gamestate import GameState
from .protocol import read_init_info, Operation, write_our_operation, RoundInfo, read_round_info, read_enemy_operations
# from vis import PgVis
# import pygame as pg
import sys
from .rawio import debug

class GameController:
    """游戏控制器。可以帮助选手处理通讯与数据维护有关的繁琐操作。"""

    my_seat: int = 0  #: 您的位置。0代表您是先手，1代表您是后手。
    game_state: GameState = GameState()  #: 游戏状态，一个 :class:`.gamestate.GameState` 对象
    my_operation_list: list[Operation] = []  #: 我方未发送的操作列表

    def init(self) -> None:
        """初始化游戏：接受游戏初始化信息，并使用给定的随机种子初始化双方信息素。"""
        init_info = read_init_info()
        self.my_seat = init_info.my_seat
        self.game_state.init_with_seed(init_info.seed)

    def read_enemy_ops(self) -> list[Operation]:
        """读取敌方操作列表"""
        return read_enemy_operations()

    def apply_enemy_ops(self, ops: list[Operation]) -> bool:
        """应用敌方操作。如果返回``False``说明敌方操作不合法。"""
        for op in ops:
            if not self.game_state.apply_operation(1 - self.my_seat, op):
                return False
        return True

    def read_and_apply_enemy_ops(self) -> bool:
        """读取并应用敌方操作。如果返回``False``说明敌方操作不合法。"""
        return self.apply_enemy_ops(self.read_enemy_ops())

    def try_apply_our_op(self, op: Operation) -> bool:
        """尝试执行我方操作。如果返回``False``说明我方操作不合法。"""
        if self.game_state.apply_operation(self.my_seat, op):
            self.my_operation_list.append(op)
            return True
        return False

    def try_apply_our_ops(self, ops: list[Operation]) -> bool:
        """尝试执行我方若干哥操作。如果返回``False``说明我方操作不合法，并停止执行后面的操作。"""
        for op in ops:
            if not self.try_apply_our_op(op):
                return False
        return True

    def finish_and_send_our_ops(self) -> None:
        """结束我方操作回合，将操作列表打包发送并清空。"""
        write_our_operation(self.my_operation_list)
        self.my_operation_list = []

    def next_round(self) -> RoundInfo:
        """执行下一回合：读取回合信息，进行 :class:`.gamestate.GameState` 的模拟以维护游戏数据。"""
        round_info = read_round_info()

        debug("round: {}, tower_num: {}, ant_num: {}, coin0: {}, coin1: {}, hp0: {}, hp1: {}".format(str(round_info.round), str(len(round_info.towers)), str(len(round_info.ants)), str(round_info.coin[0]), str(round_info.coin[1]), str(round_info.hp[0]), str(round_info.hp[1])))
        self.game_state.simulate_next_round()

        return round_info


def run_antwar_ai(ai_func: Callable[[int, GameState], list[Operation]]) -> None:
    """
    执行AI。将你的决策过程封装在一个函数中，我们帮你处理各类通讯相关的繁琐事项。
    如果你不喜欢这么做，也可以直接把下面的代码复制到你的主函数中重复利用。

    :param ai_func: 你的决策函数，第一个参数为``my_seat``，第二个参数为当前的 :class:`.gamestate.GameState` 对象。
    """
    game = GameController()
    game.init()
    # pg.init()
    # player0_base = (2, 9)
    # player1_base = (16, 9)
    # player0_tower_area = [(6, 1), (7, 1), (4, 2), (6, 2), (8, 2), (4, 3), (5, 3), (6, 4), (8, 4), (7, 5), (5, 6), (5, 7), (6, 7), (8, 7), (7, 8), (4, 9), (5, 9), (6, 9), (7, 10), (5, 11), (6, 11), (8, 11), (5, 12), (7, 13), (6, 14), (8, 14), (4, 15), (5, 15), (4, 16), (6, 16), (8, 16), (6, 17), (7, 17)]
    # player1_tower_area = [(11, 1), (12, 1), (9, 2), (11, 2), (13, 2), (13, 3), (14, 3), (9, 4), 
    # (11, 4), (11, 5), (12, 6), (10, 7), (12, 7), (13, 7), (10, 8), (12, 9), 
    # (13, 9), (14, 9), (10, 10), (10, 11), (12, 11), (13, 11), (12, 12), (11, 13), 
    # (9, 14), (11, 14), (13, 15), (14, 15), (9, 16), (11, 16), (13, 16), (11, 17), (12, 17)]
    # unmovable =[(6, 1), (7, 1), (9, 1), (11, 1), (12, 1), (4, 2), (6, 2), (8, 2), (9, 2), (11, 2), (13, 2), (4, 3), (5, 3), (13, 3), (14, 3), (6, 4), (8, 4), (9, 4), (11, 4), (3, 5), (4, 5), (7, 5), (9, 5), (11, 5), (14, 5), (15, 5), (3, 6), (5, 6), (12, 6), (14, 6), (2, 7), (5, 7), (6, 7), (8, 7), (9, 7), (10, 7), (12, 7), (13, 7), (16, 7), (1, 8), (2, 8), (7, 8), (10, 8), (15, 8), (16, 8), (0, 9), (4, 9), (5, 9), (6, 9), (9, 9), (12, 9), (13, 9), (14, 9), (18, 9), (1, 10), (2, 10), (7, 10), (10, 10), (15, 10), (16, 10), (2, 11), (5, 11), (6, 11), (8, 11), (9, 11), (10, 11), (12, 11), (13, 11), (16, 11), (3, 12), (5, 12), (12, 12), (14, 12), (3, 13), (4, 13), (7, 13), (9, 13), (11, 13), (14, 13), (15, 13), (6, 14), (8, 14), (9, 14), (11, 14), (4, 15), (5, 15), (13, 15), (14, 15), (4, 16), (6, 16), (8, 16), (9, 16), (11, 16), (13, 16), (6, 17), (7, 17), (9, 17), (11, 17), (12, 17)]
    # pg_vis = PgVis(
    #     19, 19, player0_base, player1_base, player0_tower_area, player1_tower_area, unmovable,    
    # )

    
    while True:
        
        
        if game.my_seat == 0:
            ops = ai_func(0, game.game_state)
            game.try_apply_our_ops(ops)
            game.finish_and_send_our_ops()
            
            # ops_op = ai_func(1, game.game_state)
            # game.apply_enemy_ops(ops_op)
            
            
            game.read_and_apply_enemy_ops()
        else:
            # ops_op = ai_func(1, game.game_state)
            # game.apply_enemy_ops(ops_op)
            game.read_and_apply_enemy_ops()

            ops = ai_func(1, game.game_state)
            game.try_apply_our_ops(ops)
            game.finish_and_send_our_ops()
    
        # pg_vis.draw(game.game_state)
        game.next_round()
        # input()
        # done = pg_vis.is_done(game.game_state)
        # if done != -1:
        #     if done == 1:
        #         print("player1 win")
        #     elif done == 0:
        #         print("player0 win")
        #     else:
        #         print("need compare super weapon!")

        #     input()
        #     break


from antwar.gamestate import GameState
from antwar.protocol import *

def simple_ai(my_seat: int, state: GameState, gamedict: dict) -> list[Operation]:
    tower_coord = [[Coord(6, 4), Coord(6, 14)], [Coord(11, 4), Coord(11, 14)]]

    if state.round == 0:
        return [build_tower_op(c) for c in tower_coord[my_seat]]

    return []

# if - else AI
# Finite State Machine
def FSM_ai_ver_1(my_seat: int, state: GameState, gamedict: dict) -> list[Operation]:
    my_coin = state.coin[my_seat]
    my_tower_num = 0
    for tower in state.towers:
        if tower.player == my_seat:
            my_tower_num += 1
    build_tower_cost = 15 * (2 ** my_tower_num)
    upgrade_level_1_cost = 60
    upgrade_level_2_cost = 200

    round = state.round
    debug('round' + str(round) + ',' + str(my_coin))

    # 第一回合
    if round == 1:
        tower_coord = [[Coord(7, 10),Coord(6, 4)],[Coord(10, 8),Coord(11, 14)]]
        gamedict['step1'] = True
        return [build_tower_op(c) for c in tower_coord[my_seat]]

    # 拆除塔 1
    if round > 1 and my_tower_num == 2 and my_coin >= 66 and 'step1' in gamedict.keys():
        op_list = []
        gamedict['remove1'] = True
        del gamedict['step1']
        remove_tower_coord = [Coord(7, 10), Coord(10, 8)]
        op_list.append(downgrade_tower_op(state.tower_at(remove_tower_coord[my_seat]).id))
        return op_list

    # 建设第 3 个塔
    if round > 1 and my_tower_num == 1 and 'remove1' in gamedict.keys() and my_coin >= 90:
        gamedict['step2'] = True
        del gamedict['remove1']
        tower_coord = [[Coord(6, 9), Coord(6, 14)], [Coord(12, 9), Coord(11, 4)]]
        return [build_tower_op(c) for c in tower_coord[my_seat]]

    # 标记升级数目
    if 'step2' in gamedict.keys() and 'update_num' not in gamedict.keys():
        gamedict['update_num'] = 0

    # 升级
    if round > 1 and my_tower_num == 3 and my_coin >= upgrade_level_1_cost \
        and 'step2' in gamedict.keys() and gamedict['update_num'] < 3:
        op_list = []
        tower_crood = [[Coord(6, 9), Coord(6, 14), Coord(6, 4)], [Coord(12, 9), Coord(11, 4), Coord(11, 14)]]
        tower_update_type = [TowerType.QUICK, TowerType.MORTAR, TowerType.MORTAR]
        update = False
        for (i,tower_pos) in enumerate(tower_crood[my_seat]):
            for tower in state.towers:
                if tower.type == 0 and tower.coord == tower_pos:
                    op_list.append(upgrade_tower_op(tower.id, tower_update_type[i]))
                    gamedict['update_num'] += 1
                    update = True
                    break
            if update:
                break
        if update > 0:
            return op_list

    # 升级完成
    if 'step2' in gamedict.keys() and gamedict['update_num'] == 3:
        del gamedict['step2']
        del gamedict['update_num']
        gamedict['step3'] = True

    # 升级主基地
    if 'step3' in gamedict.keys() and my_coin >= 200:
        del gamedict['step3']
        gamedict['step4'] = True
        return [upgrade_ant_maxhp_op()]

    return []

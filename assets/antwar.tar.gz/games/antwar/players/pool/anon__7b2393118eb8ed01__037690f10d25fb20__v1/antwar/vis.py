import copy
import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (768, 80)
from controller import GameController
import math
import sys
import time
import numpy as np
import pygame as pg

def evenq_to_axial(q, r):
    return q - 4 + int(r/2),  r

class PgVis:
    def __init__(self, width, height, player0_base, player1_base,
            player0_tower_area, player1_tower_area, unmovable):
        pg.init()
        self.width = width
        self.height = height
        self.player0_base = player0_base
        self.player1_base = player1_base
        self.player0_tower_area = player0_tower_area
        self.player1_tower_area = player1_tower_area
        self.unmovable = unmovable
        self.start_x = 50
        self.start_y = 173
        self.grid_r = 15.0
        self.grid_height = self.grid_r * 0.86603
        self.grid_width = self.grid_r * 0.5
        self.screen_width = 800
        self.screen_height = 800
        self.screen = pg.display.set_mode((self.screen_width, self.screen_height))
        self.font = pg.font.SysFont('Arial', 20)
        self.clock = pg.time.Clock()
        self.current_player = 0
        self.round = 1
        self.player0_health = 100
        self.player1_health = 100

    def draw(self, obs):
        self.event_monitor()
        self.screen.fill((240, 230, 188))
        self.draw_grid()
         
        #
        self.player0_health = obs.hp[0]
        self.player1_health = obs.hp[1]
        for ant in obs.ants:
            self.draw_ant(ant)
        self.draw_info()
        pg.display.update()
        # print(obs.ants)
        input()

    def event_monitor(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
    
    def draw_ant(self, ant):
        q, r = ant.coord.x, ant.coord.y
        y, x = evenq_to_axial(q, r)
        x, y = self.axial_to_cavans(x, y)
        if ant.player==1:
            color = (20,20,255)
            points = [
                (x, y - self.grid_height),
                (x + (self.grid_width+self.grid_r) / 2, y + self.grid_height/2),
                (x - (self.grid_width+self.grid_r) / 2, y + self.grid_height/2 )
            ]
        else:
            color = (255,20,20)
            points = [
                (x, y + self.grid_height),
                (x + (self.grid_width+self.grid_r) / 2, y - self.grid_height/2),
                (x - (self.grid_width+self.grid_r) / 2, y - self.grid_height/2 )
            ]
        pg.draw.polygon(self.screen, color, points, 3)
        '''
        line_width = 3  # 设置线宽度
        color = (255, 255, 255)  # 设置颜色
        pygame.draw.polygon(screen, color, vertices, line_width)
        '''

    def axial_to_cavans(self, x, y):
        return (self.start_x + x * 1.5 * self.grid_r,
            self.start_y + y * 2.0 * self.grid_height - x * self.grid_height)

    def draw_hexagon(self, x, y, color):
        # 这里xy是cv的xy，和蚂蚁坐标转置的
        # print(x,y)
        points = [(x + self.grid_r, y),
            (x + self.grid_width, y - self.grid_height),
            (x - self.grid_width, y - self.grid_height),
            (x - self.grid_r, y),
            (x - self.grid_width, y + self.grid_height),
            (x + self.grid_width, y + self.grid_height)]
        points = [(int(round(x)), int(round(y))) for x, y in points]
        pg.draw.polygon(self.screen, color, points)

    def draw_grid(self):
        for i in range(self.width):
            for j in range(self.height):
                # 这里j, i是蚂蚁坐标
                if j > 8 and j - i  > 9: continue
                if i > 8 and j - i < -9: continue
                x = self.start_x + i * 1.5 * self.grid_r 
                y = self.start_y + j * 2.0 * self.grid_height - i * self.grid_height
                if (j, i) == self.player0_base:
                    self.draw_hexagon(x, y, (255, 0, 0))
                elif (j, i) == self.player1_base:
                    self.draw_hexagon(x, y, (0, 0, 255))
                elif (j+4-int(i/2), i) in self.player0_tower_area:
                    self.draw_hexagon(x, y, (255, 192, 203))
                elif (j+4-int(i/2), i) in self.player1_tower_area:
                    self.draw_hexagon(x, y, (152, 251, 152))
                elif (j+4-int(i/2), i) in self.unmovable:
                    self.draw_hexagon(x, y, (100, 100, 100))
                else:
                    self.draw_hexagon(x, y, (176, 224, 230))

    def draw_info(self):
        text = self.font.render('HP0: {}'.format(self.player0_health), True, (255, 50, 50))
        self.screen.blit(text, (500, 100))
        text = self.font.render('HP1: {}'.format(self.player1_health), True, (50, 50, 255))
        self.screen.blit(text, (600, 100))
        text = self.font.render('Round: {}'.format(self.round), True, (0, 0, 0))
        self.screen.blit(text, (500, 50))
        text = self.font.render('Player: {}'.format(self.current_player), True, (0, 0, 0))
        self.screen.blit(text, (600, 50))
    
# demo

pg.init()
player0_base = (2, 9)
player1_base = (16, 9)
player0_tower_area = [(6, 1), (7, 1), (4, 2), (6, 2), (8, 2), (4, 3), (5, 3), (6, 4), (8, 4), (7, 5), (5, 6), (5, 7), (6, 7), (8, 7), (7, 8), (4, 9), (5, 9), (6, 9), (7, 10), (5, 11), (6, 11), (8, 11), (5, 12), (7, 13), (6, 14), (8, 14), (4, 15), (5, 15), (4, 16), (6, 16), (8, 16), (6, 17), (7, 17)]
player1_tower_area = [(11, 1), (12, 1), (9, 2), (11, 2), (13, 2), (13, 3), (14, 3), (9, 4), 
(11, 4), (11, 5), (12, 6), (10, 7), (12, 7), (13, 7), (10, 8), (12, 9), 
(13, 9), (14, 9), (10, 10), (10, 11), (12, 11), (13, 11), (12, 12), (11, 13), 
(9, 14), (11, 14), (13, 15), (14, 15), (9, 16), (11, 16), (13, 16), (11, 17), (12, 17)]
unmovable =[(6, 1), (7, 1), (9, 1), (11, 1), (12, 1), (4, 2), (6, 2), (8, 2), (9, 2), (11, 2), (13, 2), (4, 3), (5, 3), (13, 3), (14, 3), (6, 4), (8, 4), (9, 4), (11, 4), (3, 5), (4, 5), (7, 5), (9, 5), (11, 5), (14, 5), (15, 5), (3, 6), (5, 6), (12, 6), (14, 6), (2, 7), (5, 7), (6, 7), (8, 7), (9, 7), (10, 7), (12, 7), (13, 7), (16, 7), (1, 8), (2, 8), (7, 8), (10, 8), (15, 8), (16, 8), (0, 9), (4, 9), (5, 9), (6, 9), (9, 9), (12, 9), (13, 9), (14, 9), (18, 9), (1, 10), (2, 10), (7, 10), (10, 10), (15, 10), (16, 10), (2, 11), (5, 11), (6, 11), (8, 11), (9, 11), (10, 11), (12, 11), (13, 11), (16, 11), (3, 12), (5, 12), (12, 12), (14, 12), (3, 13), (4, 13), (7, 13), (9, 13), (11, 13), (14, 13), (15, 13), (6, 14), (8, 14), (9, 14), (11, 14), (4, 15), (5, 15), (13, 15), (14, 15), (4, 16), (6, 16), (8, 16), (9, 16), (11, 16), (13, 16), (6, 17), (7, 17), (9, 17), (11, 17), (12, 17)]
pg_vis = PgVis(
    18, 18, player0_base, player1_base, player0_tower_area, player1_tower_area, unmovable,    
)

game0 = GameController()
game0.init(0, 0)
state = game0.game_state
pg_vis.draw(state)
from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.rawio import print_debug

CONSTANT = 10


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []
    
    ally_ants_dict, enemy_ants_dict = get_ally_and_enemy_ants(state, my_seat)
    ally_supwps_dict, enemy_supwps_dict = get_ally_and_enemy_supwps(state, my_seat)
    default_optower(state, my_seat, operations, enemy_ants_dict)

    return operations


def default_optower(state, my_seat, operations, enemy_ants):

    if my_seat == 1:  # red
        default_tower_coord = [Coord(14, 9), Coord(11, 14), Coord(11, 4)]
    else:  # blue
        default_tower_coord = [Coord(4, 9), Coord(6, 11), Coord(6, 4)]

    tower_flag = '00000'
    for i in range(len(default_tower_coord)):
        if state.tower_at(default_tower_coord[i]) is not None:
            cur_tower = state.tower_at(default_tower_coord[i])
            if cur_tower.type == 0:
                level = '1'
            elif cur_tower.type == 1 or cur_tower.type == 2 or cur_tower.type == 3:
                level = '2'
            else:
                level = '3'
            tower_flag = tower_flag[ : i] + level + tower_flag[i + 1 : ]

    count = 0
    for i in range(3):
        if tower_flag[i] != '0':
            count += 1

    if state.ant_maxhp_lv[my_seat] > 0:
        tower_flag = tower_flag[ : -2] + str(state.ant_maxhp_lv[my_seat]) + tower_flag[-1]

    if state.gen_speed_lv[my_seat] > 0:
        tower_flag = tower_flag[ : -1] + str(state.gen_speed_lv[my_seat])

    print_debug(tower_flag)
    if tower_flag == '00000' and state.coin[my_seat] >= (15 * 2 ** count + CONSTANT):
        operations.append(build_tower_op(default_tower_coord[0]))

    # 中间的塔最少为2级别，再搞别的塔
    if tower_flag == '10000' and state.coin[my_seat] >= (60 + CONSTANT):
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.MORTAR))

    if tower_flag == '20000':
        if state.coin[my_seat] >= (15 * 2 ** count + CONSTANT):
            left, right = accord_enemy_count(my_seat, enemy_ants)
            if left > right:
                operations.append(build_tower_op(default_tower_coord[1]))
            else:
                operations.append(build_tower_op(default_tower_coord[2]))

    
    if tower_flag == '21000' and state.coin[my_seat] >= (15 * 2 ** count + CONSTANT):
        operations.append(build_tower_op(default_tower_coord[2]))

    if tower_flag == '20100' and state.coin[my_seat] >= (15 * 2 ** count + CONSTANT):
        operations.append(build_tower_op(default_tower_coord[1]))

    
    if tower_flag == '21100' and state.coin[my_seat] >= (200 + CONSTANT):
        operations.append(upgrade_ant_maxhp_op())

    # if tower_flag == '21110':
    #     operations.append(upgrade_generate_speed_op())
    
    if tower_flag == '21110':
        if state.coin[my_seat] >= (60 + CONSTANT):
            left, right = accord_enemy_count(my_seat, enemy_ants)
            if left > right:
                operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[1]).id, TowerType.MORTAR))
            else:
                operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[2]).id, TowerType.MORTAR))

    if tower_flag == '22110' and state.coin[my_seat] >= (60 + CONSTANT):
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[2]).id, TowerType.MORTAR))

    if tower_flag == '21210' and state.coin[my_seat] >= (60 + CONSTANT):
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[1]).id, TowerType.MORTAR))

    if tower_flag == '22210' and state.coin[my_seat] >= (200 + CONSTANT):
        operations.append(upgrade_generate_speed_op())

    if tower_flag == '22211' and state.coin[my_seat] >= (200 + CONSTANT):
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.MISSILE))

    if tower_flag == '32211' and state.coin[my_seat] >= (250 + CONSTANT):
        operations.append(upgrade_ant_maxhp_op())

    if tower_flag == '32221' and state.coin[my_seat] >= (250 + CONSTANT):
        operations.append(upgrade_generate_speed_op())

    print_debug(tower_flag)


# def upgrade_accord_enemy_phe(my_seat, enemy_ants):
#     left, right = 0, 0



def accord_enemy_count(my_seat, enemy_ants):
    left, right = 0, 0
    for ant_id, ant in enemy_ants.items():
        if my_seat == 1:   # red
            if ant.coord.x > 9 and ant.coord.y > 9:  # 左上
                left += 1
            if ant.coord.x > 9 and ant.coord.y < 9:  # 右上
                right += 1
        else:   # blue
            if ant.coord.x < 9 and ant.coord.y > 9:  # 左下
                left += 1
            if ant.coord.x < 9 and ant.coord.y < 9:  # 右下
                right += 1

    return left, right


def get_ally_and_enemy_ants(state, my_seat):
    ally_ants = {}
    enemy_ants = {}
    for ant in state.ants:
        if ant.player == my_seat:
            ally_ants[ant.id] = ant
        else:
            enemy_ants[ant.id] = ant

    return ally_ants, enemy_ants


def get_ally_and_enemy_supwps(state, my_seat):
    ally_supwps = {}
    enemy_supwpss = {}
    for weapon in state.active_super_weapon:
        if weapon.player == my_seat:
            ally_supwps[weapon.type] = weapon
        else:
            enemy_supwpss[weapon.type] = weapon

    return ally_supwps, enemy_supwpss


run_antwar_ai(simple_ai)

from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
import random
import antwar.coord as ac
from sys import stderr

secondTowerX = random.randint(1, 2)
# towerBuilt = 0
# kaidan = 0
# riverUpdated = False
# riverDoubleUpdated = False

def TowerToLoc(t: Tower):
    if t.coord == Coord(4,9) or t.coord == Coord(14, 9):
        return 0
    return 1

def simple_ai(me: int, state: GameState) -> list[Operation]:
    # tower_coord = [[Coord(6, 4), Coord(6, 14)], [Coord(11, 4), Coord(11, 14)]]
    # tower_coord = [[Coord(4, 9), Coord(5, 9)], [Coord(14, 9), Coord(13, 9)]]
    tower_coord = [[Coord(4, 9), Coord(5, 15), Coord(5, 3)], [Coord(14, 9), Coord(13, 3), Coord(13, 15)]]
    # tower_coord = [[Coord(4, 9), Coord(5, 9), Coord(6, 9)], [Coord(14, 9), Coord(13, 9), Coord(12, 9)]]

    # riverCoord = tower_coord[me][0]
    
    ops = []

    coin = state.coin[me]
    # tb = 2
    stderr.write('round {} coin {}\n'.format(state.round, coin))
    if len(state.active_super_weapon) != 0:
        for e in state.active_super_weapon:
            stderr.write(f'active weapon: {e.player}"s {e.type} at {e.coord}\n')
    if state.round == 0:
        ops.append(build_tower_op(tower_coord[me][0]))
        # ops.append(build_tower_op(tower_coord[me][secondTowerX]))
        # towerBuilt += 2
        coin -= 15
        # state.coin[me] -= 45
        # state.update_coin(me, -45)
        
        # return [build_tower_op(c) for c in tower_coord[my_seat]]
    
    myTowers = []
    for e in state.towers:
        if e.player == me:
            myTowers.append(e)
    zeroLvs = []
    for e in myTowers:
        if e.type == TowerType.BASIC:
            zeroLvs.append(e)

    riverFirstType = TowerType.MORTAR
    riverSecondType = TowerType.MORTAR_PLUS

    if len(zeroLvs) == 1 and len(myTowers) == 1:
        if coin >= 60 and not state.check_in_emp_range(me, tower_coord[me][0]):
            ops.append(upgrade_tower_op(zeroLvs[0].id, riverFirstType))
            coin -= 60
            stderr.write('up1 river\n')
            # riverUpdated = True

    if len(zeroLvs) == 0 and len(myTowers) == 1:
        if coin >= 30 and not state.check_in_emp_range(me, tower_coord[me][secondTowerX]):
            ops.append(build_tower_op(tower_coord[me][secondTowerX]))
            coin -= 30
            stderr.write(f'build flank1 at {tower_coord[me][secondTowerX]}\n')
    
    if len(myTowers) == 2:
        if coin >= 60 and not state.check_in_emp_range(me, tower_coord[me][3-secondTowerX]):
            ops.append(build_tower_op(tower_coord[me][3-secondTowerX]))
            coin -= 60
            stderr.write(f'build flank2 at {tower_coord[me][3-secondTowerX]}\n')

    if len(myTowers) == 3 and myTowers[0].type == riverFirstType:
        if coin >= 200 and not state.check_in_emp_range(me, tower_coord[me][0]):
            ops.append(upgrade_tower_op(myTowers[0].id, riverSecondType))
            coin -= 200
            stderr.write('up2 river\n')
            # riverDoubleUpdated = True

    if(len(zeroLvs) != 0) and myTowers[0].type == riverSecondType:
        curTower = zeroLvs[0]
        if coin >= 60 and not state.check_in_emp_range(me, zeroLvs[0].coord):
            newtype = TowerType.HEAVY
            # if TowerToLoc(curTower) == 1:
                # newtype = TowerType.QUICK
            ops.append(upgrade_tower_op(zeroLvs[0].id, newtype))
            coin -= 60
            stderr.write('up1 flank {}\n'.format(zeroLvs[0].coord.y))

    # shinjuku = [Coord(7,9), Coord(11,9)]
    # shibuya = [[Coord(5,6), Coord(5,12)], [Coord(12, 6), Coord(12, 12)]]


    if state.gen_speed_lv[me] == 1:
        if coin >= 150 and state.super_weapon_cd[me][1] == 0:
            hasEneTower = [[False] * 19] * 19
            for i in range(len(state.towers)):
                curTower = state.towers[i]
                if curTower.player == 1-me:
                    hasEneTower[curTower.coord.x][curTower.coord.y] = True
            maxCnt = -1
            pi = -1
            pj = -1
            for i in range(19):
                for j in range(19):
                    if ac.is_in_map(Coord(i, j)):
                        cnt = 0
                        for ii in range(19):
                            for jj in range(19):
                                if ac.is_in_map(Coord(ii, jj)) and ac.distance(Coord(ii, jj), Coord(i, j)) <= 3:
                                    if hasEneTower[ii][jj]:
                                        cnt += 1
                        if cnt > maxCnt:
                            maxCnt = cnt
                            pi = i
                            pj = j
            if maxCnt > 0:
                ops.append(deploy_super_weapon_op(SuperWeaponType.EMP_BLASTER, Coord(pi, pj)))
                coin -= 150
                stderr.write('emp at {}, {}\n'.format(pi, pj))

            
    if state.gen_speed_lv[me] == 0:
        if coin >= 200:
            ops.append(upgrade_generate_speed_op())
            coin -= 200
            kaidan = 10
            stderr.write('uplv gen 0->1\n')


    if state.ant_maxhp_lv[me] == 0:
        if coin >= 200:
            ops.append(upgrade_ant_maxhp_op())
            coin -= 200
            stderr.write('uplv ant 0->1\n')

    # if kaidan >= 10:

    #     pass

    if state.ant_maxhp_lv[me] == 1:
        if coin >= 250:
            ops.append(upgrade_ant_maxhp_op())
            coin -= 250

    if state.gen_speed_lv[me] == 1:
        if coin >= 250:
            ops.append(upgrade_generate_speed_op())
            coin -= 250
    # stderr.write('\n')
    return ops


run_antwar_ai(simple_ai)

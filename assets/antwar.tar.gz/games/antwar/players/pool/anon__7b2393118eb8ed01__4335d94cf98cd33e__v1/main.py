from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
import copy
import time
import random


CONSTANT = 10
'''
player_tower_area = [[(6, 1), (7, 1), (4, 2), (6, 2), (8, 2), (4, 3), (5, 3), (6, 4), (8, 4), (7, 5), 
                      (5, 6), (5, 7), (6, 7), (8, 7), (7, 8), (4, 9), (5, 9), (6, 9), (7, 10), (5, 11), (6, 11), 
                      (8, 11), (5, 12), (7, 13), (6, 14), (8, 14), (4, 15), (5, 15), (4, 16), (6, 16), (8, 16), (6, 17), (7, 17)],
                      [(11, 1), (12, 1), (9, 2), (11, 2), (13, 2), (13, 3), (14, 3), (9, 4), (11, 4), (11, 5), 
                      (12, 6), (10, 7), (12, 7), (13, 7), (10, 8), (12, 9), (13, 9), (14, 9), (10, 10), (10, 11), 
                      (12, 11), (13, 11), (12, 12), (11, 13), (9, 14), (11, 14), (13, 15), (14, 15), (9, 16), (11, 16), (13, 16), (11, 17), (12, 17)]]
'''
# player_tower_area = [[(4, 3), (4, 15), (6, 7), (6, 11), (6, 2), (6, 16), (7, 5), (7, 13), (8, 7), (8, 11), (8, 4), (8, 14)], 
#                      [(14, 3), (14, 15), (12, 7), (12, 11), (11, 2), (11, 16), (11, 5), (11, 13), (10, 7), (10, 11), (9, 4), (9, 14)]]

player_tower_area = [[[(4, 3), (6, 2), (7, 5), (8, 4)], [(6, 7), (6, 11), (8, 7), (8, 11)], [(4, 15), (6, 16), (7, 13), (8, 14)]],
                     [[(14, 3), (11, 2), (11, 5), (9, 4)], [(12, 7), (12, 11), (10, 7), (10, 11)], [(14, 15), (11, 16), (11, 13), (9, 14)]]]


class MonteCarloAI:
    def __init__(self) -> None:
        
        # self.action_poss = [0] * 33
        self.iterations = 50
        self.actions = [OperationType.BUILD_TOWER, OperationType.UPGRADE_TOWER, OperationType.DOWNGRADE_TOWER]
        
    def get_action(self, state, my_seat):

        best_value = -10000
        best_op = None

        # 确定每个状态下可用的行动集合
        for action in self.actions:
            # start = time.time()
            # 分了三个区域，先判断在哪个趋于最好
            tmp_list = []
            for area_list in range(len(player_tower_area[my_seat])):
                
                pos_list = player_tower_area[my_seat][area_list]
                index = random.randint(0,len(pos_list) - 1)
                tmp_list.append(pos_list[index])

            for action_pos in tmp_list:
                cur_state = copy.deepcopy(state)
                # 创建operation
                cur_op = self.get_operation(cur_state, action, action_pos)

                # 判断是否为合法操作 如果合法即操作
                if cur_op is not None:
                    value = self.simulate(my_seat, cur_state, cur_op, action, action_pos)
                    if value > best_value:
                        best_op = cur_op
                        best_value = value

            # end = time.time()

        return best_op

    def get_operation(self, cur_state, action, action_pos):
        target_coord = Coord(action_pos[0], action_pos[1])
        if action == OperationType.BUILD_TOWER:
            return build_tower_op(target_coord)
        if action == OperationType.UPGRADE_TOWER and cur_state.tower_at(target_coord) is not None:
            # 先写死 升级只能升到mortar
            return upgrade_tower_op(cur_state.tower_at(target_coord).id, TowerType.MORTAR)
        if action == OperationType.DOWNGRADE_TOWER and cur_state.tower_at(target_coord) is not None:
            return downgrade_tower_op(cur_state.tower_at(target_coord).id)
        if action == OperationType.UPGRADE_GENERATE_SPEED:
            return upgrade_generate_speed_op()
        if action == OperationType.UPGRADE_ANT_MAXHP:
            return upgrade_ant_maxhp_op()
        
        return None

    def simulate(self, my_seat, cur_state, cur_op, action, action_pos):

        # 记录当前的血量和金币
        cur_state.apply_operation(my_seat, cur_op)
        cur_state.simulate_next_round()

        pre_my_coin = cur_state.coin[my_seat]
        pre_my_hp = cur_state.hp[my_seat]
        pre_oppo_coin = cur_state.coin[1 - my_seat]
        pre_oppo_hp = cur_state.hp[1 - my_seat]      
        
        reward = 0
        count = 0
        while count < 32 and cur_state.hp[0] != 0 and cur_state.hp[1] != 0:
            # 假设之后自己和对手到结束什么都不做
            count += 1
            reward += 1
            cur_state.simulate_next_round()
            # 根据状态的更新给予reward
            reward += (cur_state.coin[my_seat] - pre_my_coin)
            pre_my_coin = cur_state.coin[my_seat]

            reward += (cur_state.hp[my_seat] - pre_my_hp)
            pre_my_hp = cur_state.hp[my_seat]

            
        if cur_state.hp[my_seat] > cur_state.hp[1 - my_seat]:
            reward += 50
        elif cur_state.hp[my_seat] < cur_state.hp[1 - my_seat]:
            reward -= 50
        return reward
    

def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:

        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    else:
        ai = MonteCarloAI()

        operation = ai.get_action(state, my_seat)
        if operation is not None:
            operations.append(operation)
        
    return operations

def simple_ai_oppo(my_seat: int, state: GameState) -> list[Operation]:
    operations = []

    if state.round == 0:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(4, 9)))
        else:
            operations.append(build_tower_op(Coord(14, 9)))

    elif state.round == 1:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 4)))
        else:
            operations.append(build_tower_op(Coord(13, 4)))
    
    else:
        if my_seat == 0:
            operations.append(build_tower_op(Coord(6, 14)))
        else:
            operations.append(build_tower_op(Coord(13, 14)))

    return operations




# run_antwar_ai(simple_ai, simple_ai_oppo)
run_antwar_ai(simple_ai)
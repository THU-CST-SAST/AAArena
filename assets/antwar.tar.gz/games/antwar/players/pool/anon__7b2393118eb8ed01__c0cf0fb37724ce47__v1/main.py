from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    operations = []
    
    ally_ants_dict, enemy_ants_dict = get_ally_and_enemy_ants(state, my_seat)
    ally_supwps_dict, enemy_supwps_dict = get_ally_and_enemy_supwps(state, my_seat)
    if my_seat == 1:  # 红方
        default_optower_red(state, my_seat, operations, enemy_ants_dict, ally_ants_dict)

    else:  # 蓝方
        default_optower_blue(state, my_seat, operations, enemy_ants_dict, ally_ants_dict)

    return operations


def default_optower_red(state, my_seat, operations, enemy_ants, ally_ants):
    default_tower_coord = [Coord(13, 9), Coord(13, 15), Coord(13, 3)]
    tower_flag = '0000'
    for i in range(len(default_tower_coord)):
        if state.tower_at(default_tower_coord[i]) is not None:
            cur_tower = state.tower_at(default_tower_coord[i])
            if cur_tower.type == 0:
                level = '1'
            elif cur_tower.type == 1 or cur_tower.type == 2 or cur_tower.type == 3:
                level = '2'
            else:
                level = '3'
            tower_flag = tower_flag[ : i] + level + tower_flag[i + 1 : ]

    if len(ally_ants) > 0 and obtain_ant_maxlevel(ally_ants) > 0:
        tower_flag = tower_flag[ : -1] + str(obtain_ant_maxlevel(ally_ants))
    

    if tower_flag == '0000':
        operations.append(build_tower_op(default_tower_coord[0]))

    # 中间的塔最少为2级别，再搞别的塔
    if tower_flag == '1000':
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.MORTAR))

    if tower_flag == '2000':
        left_top, right_top = count_enemy_ants_red(enemy_ants)
        if left_top > right_top:
            operations.append(build_tower_op(default_tower_coord[1]))
        else:
            operations.append(build_tower_op(default_tower_coord[2]))

    
    if tower_flag == '2100':
        operations.append(build_tower_op(default_tower_coord[2]))

    if tower_flag == '2010':
        operations.append(build_tower_op(default_tower_coord[1]))

    
    if tower_flag == '2110':
        if state.tower_at(default_tower_coord[0]).type == 3:
            if (state.coin[my_seat] + 48) >= 260 and state.tower_at(default_tower_coord[0]).cd >= 3:
                operations.append(downgrade_tower_op(state.tower_at(default_tower_coord[0]).id))
        else:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.SNIPER))

    if tower_flag == '1110':
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.QUICK))
    
    if tower_flag == '3110':
        operations.append(upgrade_ant_maxhp_op())

    if tower_flag == '3111':
        left_top, right_top = count_enemy_ants_red(enemy_ants)
        if left_top > right_top:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[1]).id, TowerType.MORTAR_PLUS))
        else:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[2]).id, TowerType.MORTAR_PLUS))


def default_optower_blue(state, my_seat, operations, enemy_ants, ally_ants):
    default_tower_coord = [Coord(4, 9), Coord(5, 15), Coord(5, 3)]
    tower_flag = '0000'
    for i in range(len(default_tower_coord)):
        if state.tower_at(default_tower_coord[i]) is not None:
            cur_tower = state.tower_at(default_tower_coord[i])
            if cur_tower.type == 0:
                level = '1'
            elif cur_tower.type == 1 or cur_tower.type == 2 or cur_tower.type == 3:
                level = '2'
            else:
                level = '3'
            tower_flag = tower_flag[ : i] + level + tower_flag[i + 1 : ]

    if len(ally_ants) > 0 and obtain_ant_maxlevel(ally_ants) > 0:
        tower_flag = tower_flag[ : -1] + str(obtain_ant_maxlevel(ally_ants))
    

    if tower_flag == '0000':
        operations.append(build_tower_op(default_tower_coord[0]))

    # 中间的塔最少为2级别，再搞别的塔
    if tower_flag == '1000':
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.MORTAR))

    if tower_flag == '2000':
        left_top, right_top = count_enemy_ants_red(enemy_ants)
        if left_top > right_top:
            operations.append(build_tower_op(default_tower_coord[1]))
        else:
            operations.append(build_tower_op(default_tower_coord[2]))

    
    if tower_flag == '2100':
        operations.append(build_tower_op(default_tower_coord[2]))

    if tower_flag == '2010':
        operations.append(build_tower_op(default_tower_coord[1]))

    
    if tower_flag == '2110':
        if state.tower_at(default_tower_coord[0]).type == 3:
            if (state.coin[my_seat] + 48) >= 260 and state.tower_at(default_tower_coord[0]).cd >= 3:
                operations.append(downgrade_tower_op(state.tower_at(default_tower_coord[0]).id))
        else:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.SNIPER))

    if tower_flag == '1110':
        operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[0]).id, TowerType.QUICK))
    
    if tower_flag == '3110':
        operations.append(upgrade_ant_maxhp_op())

    if tower_flag == '3111':
        left_top, right_top = count_enemy_ants_red(enemy_ants)
        if left_top > right_top:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[1]).id, TowerType.MORTAR_PLUS))
        else:
            operations.append(upgrade_tower_op(state.tower_at(default_tower_coord[2]).id, TowerType.MORTAR_PLUS))


def obtain_ant_maxlevel(ally_ants):
    max_level = 0
    for ant_id, ant in ally_ants.items():
        if ant.level > max_level:
            max_level = ant.level

    return max_level

def count_enemy_ants_red(enemy_ants):
    lt, rt = 0, 0
    for ant_id, ant in enemy_ants.items():
        if ant.coord.x > 9 and ant.coord.y > 9:  # 左上
            lt += 1
        if ant.coord.x > 9 and ant.coord.y < 9:  # 右上
            rt += 1

    return lt, rt


def get_ally_and_enemy_ants(state, my_seat):
    ally_ants = {}
    enemy_ants = {}
    for ant in state.ants:
        if ant.player == my_seat:
            ally_ants[ant.id] = ant
        else:
            enemy_ants[ant.id] = ant

    return ally_ants, enemy_ants


def get_ally_and_enemy_supwps(state, my_seat):
    ally_supwps = {}
    enemy_supwpss = {}
    for weapon in state.active_super_weapon:
        if weapon.player == my_seat:
            ally_supwps[weapon.type] = weapon
        else:
            enemy_supwpss[weapon.type] = weapon

    return ally_supwps, enemy_supwpss


run_antwar_ai(simple_ai)

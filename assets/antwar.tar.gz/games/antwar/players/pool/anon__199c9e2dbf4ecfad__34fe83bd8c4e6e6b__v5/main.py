from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    tower_coord = [[Coord(5, 7), Coord(5, 11)], [Coord(12, 7), Coord(12, 11)]]
    center_coord=[Coord(6,9),Coord(12,9)]

    heart_coord=[Coord(4,9),Coord(14,9)]

    # 建塔
    if state.round == 0:
        return [build_tower_op(c) for c in tower_coord[my_seat]]
    # 离基地最近位置的建塔
    heart_tower=state.tower_at(heart_coord[my_seat])
    if state.coin[my_seat]>=60 and not heart_tower:
        return [build_tower_op(heart_coord[my_seat])]
    
    
    # 升2级
    # 心脏塔升到二级
    if state.coin[my_seat]>=60 and heart_tower and heart_tower.type==TowerType.BASIC:
        return [upgrade_tower_op(heart_tower.id,TowerType.MORTAR)]
    for i in 0,1:
        if state.coin[my_seat]>=60:
            side_tower=state.tower_at(tower_coord[my_seat][i])
            if side_tower.type==TowerType.BASIC:
                return [upgrade_tower_op(side_tower.id,TowerType.QUICK)]
            
    my_center_tower=state.tower_at(center_coord[my_seat])
    if state.coin[my_seat]>=120 and not my_center_tower:
        return [build_tower_op(center_coord[my_seat])]
    if my_center_tower and my_center_tower.type==TowerType.BASIC:
        return [upgrade_tower_op(my_center_tower.id,TowerType.HEAVY)]
    
    
    
    
    

    # 升3级
    if state.coin[my_seat]>=200 and heart_tower and heart_tower.type ==TowerType.MORTAR:
        return [upgrade_tower_op(heart_tower.id,TowerType.MORTAR_PLUS)]
    if state.coin[my_seat]>=200 and my_center_tower and my_center_tower.type ==TowerType.HEAVY:
        return [upgrade_tower_op(my_center_tower.id,TowerType.ICE)]
    for i in 0,1:
        if state.coin[my_seat]>=200:
            side_tower=state.tower_at(tower_coord[my_seat][i])
            if side_tower.type==TowerType.QUICK:
                return [upgrade_tower_op(side_tower.id,TowerType.DOUBLE)]
    
    if heart_tower and state.coin[my_seat]>=200 and state.gen_speed_lv[my_seat]==1:
        return [upgrade_generate_speed_op()]
    


    return []


run_antwar_ai(simple_ai)

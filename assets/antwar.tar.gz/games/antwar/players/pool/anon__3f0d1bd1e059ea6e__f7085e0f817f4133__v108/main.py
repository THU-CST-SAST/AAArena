from antwar.controller import run_antwar_ai
from antwar.gamestate import *
from antwar.gamedata import *
from antwar.protocol import *
from utility import *
def try_op(op:Operation):
    if g_state.is_operation_valid(g_seat,op):
        return [op]
    return []
def ai(seat:int,state:GameState)->list[Operation]:
    cmd=[]
    global g_seat
    global g_state
    global g_coin
    g_seat=seat
    g_state=state
    g_coin=state.coin[g_seat]
    tower_center=g_state.tower_at(pair_center00[g_seat])
    tower_left=g_state.tower_at(pair_left4[g_seat])
    tower_right=g_state.tower_at(pair_right3[g_seat])
    if tower_center==None:
        return try_op(build_tower_op(pair_center00[g_seat]))
    elif tower_center.type==TowerType.BASIC:
        return try_op(upgrade_tower_op(tower_center.id,TowerType.MORTAR))
    elif tower_left==None:
        return try_op(build_tower_op(pair_left4[g_seat]))
    elif tower_right==None:
        return try_op(build_tower_op(pair_right3[g_seat]))
    elif tower_left.type==TowerType.BASIC:
        return try_op(upgrade_tower_op(tower_left.id,TowerType.MORTAR))
    elif tower_right.type==TowerType.BASIC:
        return try_op(upgrade_tower_op(tower_right.id,TowerType.MORTAR))
    elif tower_center.type==TowerType.MORTAR:
        return try_op(upgrade_tower_op(tower_center.id,TowerType.MORTAR_PLUS))
    elif g_state.ant_maxhp_lv[g_seat]==0:
        return try_op(upgrade_ant_maxhp_op())
    elif g_state.gen_speed_lv[g_seat]==0:
        return try_op(upgrade_generate_speed_op())
    elif g_state.gen_speed_lv[g_seat]==1:
        return try_op(upgrade_generate_speed_op())
    elif g_state.ant_maxhp_lv[g_seat]==1:
        return try_op(upgrade_ant_maxhp_op())
    return []
run_antwar_ai(ai)

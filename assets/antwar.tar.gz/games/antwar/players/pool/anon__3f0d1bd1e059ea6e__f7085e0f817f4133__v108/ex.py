a=0
try:a=5
except:None
a[0]=8
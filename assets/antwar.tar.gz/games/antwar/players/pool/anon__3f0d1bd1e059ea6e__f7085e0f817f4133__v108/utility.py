from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from enum import Enum
high_land=[
    # area
    [],
    [
        # subarea
        [
            [4,9]
        ]
    ],
    []
]
high_land_center00=[4,9]
pair_center00=[Coord(4,9),Coord(14,9)]
pair_center11=[Coord(5,6),Coord(12,6)]
pair_center21=[Coord(5,12),Coord(12,12)]
# pair_left21=[Coord(6,4),Coord(11,4)]
# pair_right11=[Coord(6,14),Coord(11,14)]
pair_left00=[Coord(4,3),Coord(14,3)]
pair_right00=[Coord(4,15),Coord(14,15)]
pair_left4=[Coord(8,4),Coord(9,4)]
pair_right3=[Coord(8,14),Coord(9,14)]
g_seat=0
g_state=GameState()
g_coin=0
basic_level=0
cost_tower_build=[15,30,60]
cost_tower_upgrade=[60,200]
class Defence_type(Enum):
    Center=0
    Flank=1
    Flank_Center=2
def try_upgrade(t:Tower,ttype:TowerType)->list[Operation]:
    global g_coin
    if t!=None and g_coin>=g_state.upgrade_tower_cost(ttype):
        g_coin-=g_state.upgrade_tower_cost(ttype)
        return [upgrade_tower_op(t.id,ttype)]
    return []
def try_build(pos:Coord):
    global g_coin
    t=g_state.tower_at(pos)
    if t==None and g_state.coin[g_seat]>=g_state.build_tower_cost(g_seat):
        g_coin-=g_state.build_tower_cost(g_seat)
        return [build_tower_op(pos)]
    return []
# row_sum=18
# def symp(coord:list)->list:
# 算法错误
#     return [Coord(coord[0],coord[1]),Coord(row_sum-coord[0],coord[1])]
动态防御
```py
def get_weak_flank():
    return None
def balance_flank_defence():
    cmd=[]
    weak_flank=get_weak_flank()
    left_tower=g_state.tower_at(pair_center11[g_seat])
    right_tower=g_state.tower_at(pair_center21[g_seat])
    if left_tower==None or right_tower==None:return None
    if weak_flank=="left":
        if right_tower.type!=TowerType.BASIC:
            cmd.append(downgrade_tower_op(right_tower.id))
        try: cmd.append(upgrade_tower_op(id=left_tower.id,type=TowerType.QUICK))
        except: None
    elif weak_flank=="right":
        if left_tower.type!=TowerType.BASIC:
            cmd.append(downgrade_tower_op(left_tower.id))
        try: cmd.append(upgrade_tower_op(id=right_tower.id,type=TowerType.QUICK))
        except: None
    return None
```
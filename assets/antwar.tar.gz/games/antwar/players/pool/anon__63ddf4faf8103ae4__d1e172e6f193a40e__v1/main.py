from antwar.controller import GameController
from antwar.gamestate import GameState
from antwar.protocol import *


def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    tower_coord = [[Coord(6, 4), Coord(6, 14)], [Coord(11, 4), Coord(11, 14)]]

    if state.round == 0:
        return [build_tower_op(c) for c in tower_coord[my_seat]]

    return []


game = GameController()
game.init()
while True:
    if game.my_seat == 0:
        ops = simple_ai(0, game.game_state)
        game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()

        game.read_and_apply_enemy_ops()
    else:
        game.read_and_apply_enemy_ops()

        ops = simple_ai(1, game.game_state)
        game.try_apply_our_ops(ops)
        game.finish_and_send_our_ops()

    game.next_round()

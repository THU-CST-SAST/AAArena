from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.ai import FSM_ai_ver_1,simple_ai,FSM_ai_ver_2

run_antwar_ai(FSM_ai_ver_2)

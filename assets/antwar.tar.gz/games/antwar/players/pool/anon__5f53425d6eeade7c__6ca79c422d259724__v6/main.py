from antwar.controller import run_antwar_ai
from antwar.gamestate import GameState
from antwar.protocol import *
from antwar.coord import distance
from antwar.gamedata import TowerType

cur_state = 0
my_tower = []

def ant_inside(pos: Coord, ants: list[Ant]) -> bool:
    for ant in ants:
        if distance(pos, ant.coord) <= 3:
            return True
    return False

def simple_ai(my_seat: int, state: GameState) -> list[Operation]:
    global cur_state
    global my_tower

    tower_coord_0 = [[Coord(4, 9)], [Coord(14, 9)]]
    tower_coord_left = [[Coord(5, 3)], [Coord(13, 3)]]
    tower_coord_right = [[Coord(5, 15)], [Coord(13, 15)]]

    if cur_state == 0: # build mid tower
        cur_state += 1
        return [build_tower_op(c) for c in tower_coord_0[my_seat]]
    elif cur_state == 1: # build side tower 1
        my_tower.extend(list(filter(lambda x: x.player == my_seat and x not in my_tower, state.towers)))

        oppo_ants = list(filter(lambda x: x.player == my_seat ^ 1, state.ants))
        if ant_inside(tower_coord_left[my_seat][0], oppo_ants):
            cur_state += 1
            return [build_tower_op(c) for c in tower_coord_left[my_seat]]
        elif ant_inside(tower_coord_right[my_seat][0], oppo_ants):
            cur_state += 101
            return [build_tower_op(c) for c in tower_coord_right[my_seat]]
        else:
            return []
    elif cur_state % 100 == 2: # update mid tower
        my_tower.extend(list(filter(lambda x: x.player == my_seat and x not in my_tower, state.towers)))

        if state.coin[my_seat] >= 60:
            cur_state += 1
            return [upgrade_tower_op(my_tower[0].id, TowerType.QUICK)]
        else:
            return []
    elif cur_state % 100 == 3: # build side tower 2
        my_tower.extend(list(filter(lambda x: x.player == my_seat and x not in my_tower, state.towers)))

        if cur_state > 100 and state.coin[my_seat] >= 60:
            cur_state += 101
            return [build_tower_op(c) for c in tower_coord_left[my_seat]]
        elif cur_state < 100 and state.coin[my_seat] >= 60:
            cur_state += 1
            return [build_tower_op(c) for c in tower_coord_right[my_seat]]
        else:
            return []
    elif cur_state % 100 == 4: # update ant level 1
        return []
    elif cur_state % 100 == 5: # update ant level 2
        return []
    else:
        return []


run_antwar_ai(simple_ai)